"""Unit tests for the high-level Batch API (v0.4.0)."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from scrapingpros import AsyncScrapingPros, Batch, AsyncBatch, ScrapingPros, SyncClient, AsyncClient
from scrapingpros.models import ScrapeRequest

BASE = "https://mock-api.scrapingpros.com"
TOKEN = "test-token"


@pytest.fixture
def client():
    c = SyncClient(TOKEN, base_url=BASE)
    yield c
    c.close()


# Shared collection+run stubs used by every test
def _mock_submit(httpx_mock: HTTPXMock, col_id: str, run_id: str):
    httpx_mock.add_response(
        url=f"{BASE}/v1/async/collections",
        json={"id": col_id, "name": "batch", "message": "Created"},
    )
    httpx_mock.add_response(
        url=f"{BASE}/v1/async/collections/{col_id}/run",
        json={"run_id": run_id, "collection_id": col_id, "status": "in_progress"},
    )


def _mock_run_status(
    httpx_mock: HTTPXMock, col_id: str, run_id: str, status: str,
    total: int = 0, success: int = 0, failed: int = 0, timeout: int = 0,
):
    httpx_mock.add_response(
        url=f"{BASE}/v1/async/collections/{col_id}/runs/{run_id}",
        json={
            "run_id": run_id, "collection_id": col_id, "status": status,
            "total_requests": total, "success_requests": success,
            "failed_requests": failed, "timeout_requests": timeout,
        },
    )


def _mock_jobs_page(
    httpx_mock: HTTPXMock, col_id: str, run_id: str,
    items: list[dict], cursor_next: str | None = None, has_more: bool = False,
    cursor: str | None = None,
    status_filter: str = "completed,failed,timeout",
    order_by: str = "completed_at",
    order_dir: str = "asc",
):
    """Mock a /jobs page with the query shape the Batch polling uses.

    Note: URL-encoded commas become %2C. We match the full URL so
    different status_filter values don't share a mock.
    """
    url = f"{BASE}/v1/async/collections/{col_id}/runs/{run_id}/jobs?limit=1000"
    if cursor is not None:
        url += f"&cursor={cursor}"
    url += f"&status_filter={status_filter.replace(',', '%2C')}"
    url += f"&order_by={order_by}&order_dir={order_dir}"
    httpx_mock.add_response(
        url=url,
        json={"items": items, "cursor_next": cursor_next, "has_more": has_more},
    )


def _mock_result(httpx_mock: HTTPXMock, col_id: str, run_id: str, job_id: str,
                  url: str, custom_id: str | None = None, success: bool = True):
    httpx_mock.add_response(
        url=f"{BASE}/v1/async/collections/{col_id}/runs/{run_id}/jobs/{job_id}/result",
        json={
            "url": url, "custom_id": custom_id,
            "html": f"<h1>{url}</h1>" if success else None,
            "statusCode": 200 if success else 403,
            "message": "OK",
            "guidance": {"success": success, "credits_charged": 1},
        },
    )


# ---------------------------------------------------------------------------
# submit_batch + get_batch
# ---------------------------------------------------------------------------

class TestSubmitBatch:
    def test_submit_batch_with_urls(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        batch = client.submit_batch("test", [
            "https://a.com",
            "https://b.com",
        ])
        assert isinstance(batch, Batch)
        assert batch.collection_id == "c1"
        assert batch.run_id == "r1"
        assert batch.total == 2

    def test_submit_batch_with_dicts(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        batch = client.submit_batch("test", [
            {"url": "https://a.com", "custom_id": "alpha", "browser": True},
            {"url": "https://b.com", "custom_id": "beta"},
        ])
        assert batch.total == 2

    def test_submit_batch_with_scrape_requests(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        batch = client.submit_batch("test", [
            ScrapeRequest(url="https://a.com", custom_id="alpha"),
            ScrapeRequest(url="https://b.com", format="markdown"),
        ])
        assert batch.total == 2

    def test_submit_batch_rejects_invalid_item_type(self, client: ScrapingPros):
        with pytest.raises(TypeError):
            client.submit_batch("test", [123])  # type: ignore

    def test_get_batch_refresh_false(self, client: ScrapingPros):
        # With refresh=False (the v0.5.1 behaviour) get_batch makes no
        # network call and counters stay at their defaults.
        batch = client.get_batch("c1", "r1", name="resumed", refresh=False)
        assert batch.collection_id == "c1"
        assert batch.run_id == "r1"
        assert batch.name == "resumed"
        assert batch.total == 0

    def test_get_batch_auto_refreshes(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        # Since v0.5.2 get_batch hits the server once on construction so
        # counters are populated immediately. The mock below intercepts
        # that call.
        httpx_mock.add_response(
            method="GET",
            url=f"{BASE}/v1/async/collections/c1/runs/r1",
            json={
                "run_id": "r1", "collection_id": "c1", "status": "in_progress",
                "total_requests": 17, "success_requests": 4, "failed_requests": 1,
                "timeout_requests": 0,
            },
        )
        batch = client.get_batch("c1", "r1")
        assert batch.total == 17
        assert batch.success_count == 4
        assert batch.failed_count == 1


# ---------------------------------------------------------------------------
# Batch properties
# ---------------------------------------------------------------------------

class TestBatchProperties:
    def test_defaults_before_iteration(self, client: ScrapingPros):
        # refresh=False to keep this test isolated from the network.
        batch = client.get_batch("c1", "r1", refresh=False)
        assert batch.total == 0
        assert batch.completed_count == 0
        assert batch.success_count == 0
        assert batch.failed_count == 0
        assert batch.processing_count == 0
        assert batch.pct == 0.0
        assert batch.elapsed_seconds == 0.0
        assert batch.jobs_per_second == 0.0
        assert batch.eta_seconds is None
        assert batch.status == "in_progress"
        assert batch.is_finished is False

    def test_total_override(self, client: ScrapingPros):
        batch = Batch(client, "c1", "r1", total=500)
        assert batch.total == 500

    def test_is_finished_terminal_states(self):
        from scrapingpros.models import RunPublic
        batch = Batch(None, "c1", "r1")  # type: ignore
        batch._last_run = RunPublic(run_id="r1", collection_id="c1", status="completed")
        assert batch.is_finished is True
        batch._last_run = RunPublic(run_id="r1", collection_id="c1", status="failed")
        assert batch.is_finished is True
        batch._last_run = RunPublic(run_id="r1", collection_id="c1", status="cancelled")
        assert batch.is_finished is True
        batch._last_run = RunPublic(run_id="r1", collection_id="c1", status="in_progress")
        assert batch.is_finished is False


# ---------------------------------------------------------------------------
# iter_results lifecycle
# ---------------------------------------------------------------------------

class TestIterResults:
    def test_iter_yields_completed_results(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        # Single poll: run already completed with 2 jobs → break immediately
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=2, success=2)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com", "custom_id": "alpha"},
            {"job_public_id": "j2", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://b.com", "custom_id": "beta"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", "alpha", success=True)
        _mock_result(httpx_mock, "c1", "r1", "j2", "https://b.com", "beta", success=True)

        batch = client.submit_batch("test", ["https://a.com", "https://b.com"])
        results = list(batch.iter_results(poll_interval=0))
        assert len(results) == 2
        custom_ids = {r.custom_id for r in results}
        assert custom_ids == {"alpha", "beta"}
        assert batch.success_count == 2
        assert batch.failed_count == 0
        assert batch.is_finished is True

    def test_iter_includes_failed(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=2, success=1, failed=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com", "custom_id": "alpha"},
            {"job_public_id": "j2", "run_public_id": "r1", "collection_id": "c1",
             "status": "failed", "url": "https://b.com", "custom_id": "beta",
             "message": "proxy error"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", "alpha", success=True)

        batch = client.submit_batch("test", ["https://a.com", "https://b.com"])
        results = list(batch.iter_results(poll_interval=0, include_failed=True))
        assert len(results) == 2
        failed = [r for r in results if not (r.guidance and r.guidance.success)]
        assert len(failed) == 1
        assert failed[0].url == "https://b.com"

    def test_iter_exclude_failed(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=2, success=1, failed=1)
        # With include_failed=False, the SDK only asks for status=completed
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com"},
        ], cursor_next=None, has_more=False, status_filter="completed")
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", None, success=True)

        batch = client.submit_batch("test", ["https://a.com", "https://b.com"])
        results = list(batch.iter_results(poll_interval=0, include_failed=False))
        # Only the successful one is yielded
        assert len(results) == 1
        assert results[0].url == "https://a.com"
        # failed_count falls back to server-side run stats (server tracked the failure)
        assert batch.failed_count == 1

    def test_callbacks_fire(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=1, success=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", None, success=True)

        result_calls = []
        progress_calls = []
        complete_calls = []

        batch = client.submit_batch("test", ["https://a.com"])
        batch.on_result(lambda r: result_calls.append(r.url))
        batch.on_progress(lambda b: progress_calls.append(b.completed_count))
        batch.on_complete(lambda b: complete_calls.append(b.status))

        list(batch.iter_results(poll_interval=0))

        assert result_calls == ["https://a.com"]
        assert len(progress_calls) >= 1
        assert complete_calls == ["completed"]

    def test_polling_sends_cursor_order_by_and_status_csv(
        self, httpx_mock: HTTPXMock, client: ScrapingPros
    ):
        """v0.4.1 polling must use the new server-side filters."""
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=1, success=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", None, success=True)

        batch = client.submit_batch("test", ["https://a.com"])
        list(batch.iter_results(poll_interval=0))

        # Verify the /jobs request carried the right query params
        jobs_req = None
        for req in httpx_mock.get_requests():
            if "/jobs" in str(req.url) and "result" not in str(req.url):
                jobs_req = req
        assert jobs_req is not None, "no /jobs request found"
        query = str(jobs_req.url)
        assert "order_by=completed_at" in query
        assert "order_dir=asc" in query
        # CSV with URL-encoded comma
        assert "status_filter=completed%2Cfailed%2Ctimeout" in query

    def test_polling_uses_since_completed_at_between_ticks(
        self, httpx_mock: HTTPXMock
    ):
        """Across ticks the SDK must use since_completed_at, not cursor.

        The server may respond with has_more=False and cursor_next=None
        on the first tick even when more jobs are about to complete. The
        SDK must NOT rely on the cursor advancing — it must use the
        max(completed_at) seen as the ``since_completed_at`` of the
        next poll.
        """
        from datetime import datetime

        c = SyncClient(TOKEN, base_url=BASE)
        _mock_submit(httpx_mock, "c1", "r1")

        # Tick 1: in_progress, 1 job completed at 12:00:05.100, has_more=False,
        # cursor_next=None
        _mock_run_status(httpx_mock, "c1", "r1", "in_progress", total=2, success=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com", "custom_id": "alpha",
             "completed_at": "2026-04-24T12:00:05.100"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", "alpha", success=True)

        # Tick 2: completed, 1 new job. The SDK should send
        # since_completed_at=2026-04-24T12:00:05.100 in this request.
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=2, success=2)
        httpx_mock.add_response(
            url=(
                f"{BASE}/v1/async/collections/c1/runs/r1/jobs"
                f"?limit=1000&status_filter=completed%2Cfailed%2Ctimeout"
                f"&order_by=completed_at&order_dir=asc"
                f"&since_completed_at=2026-04-24T12:00:05.100"
            ),
            json={
                "items": [
                    {"job_public_id": "j2", "run_public_id": "r1", "collection_id": "c1",
                     "status": "completed", "url": "https://b.com", "custom_id": "beta",
                     "completed_at": "2026-04-24T12:00:07.500"},
                ],
                "cursor_next": None, "has_more": False,
            },
        )
        _mock_result(httpx_mock, "c1", "r1", "j2", "https://b.com", "beta", success=True)

        batch = c.submit_batch("test", ["https://a.com", "https://b.com"])
        results = list(batch.iter_results(poll_interval=0))
        assert len(results) == 2
        assert {r.custom_id for r in results} == {"alpha", "beta"}
        # SDK advanced its high-water mark to the latest job's completed_at
        assert batch._last_completed_at == datetime.fromisoformat("2026-04-24T12:00:07.500")
        c.close()

    def test_batch_trusts_server_is_success_for_soft_blocks(
        self, httpx_mock: HTTPXMock, client: ScrapingPros
    ):
        """When server says is_success=False, SDK honors it even if the
        HTML looks OK (2xx + body). This covers soft-blocks (Google
        CAPTCHA page with 200 + large body, Amazon 'Robot Check', etc.).
        """
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=1, success=0, failed=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://google.com/search",
             "status_code": 200, "is_success": False,
             "custom_id": "soft-block"},
        ], cursor_next=None, has_more=False)
        # Fetch result — 200 with big body, server says fail via job.is_success
        httpx_mock.add_response(
            url=f"{BASE}/v1/async/collections/c1/runs/r1/jobs/j1/result",
            json={"url": "https://google.com/search", "custom_id": "soft-block",
                  "html": "<html>" + "x" * 90000 + "</html>",
                  "statusCode": 200, "message": "OK"},
        )
        batch = client.submit_batch("test", ["https://google.com/search"])
        results = list(batch.iter_results(poll_interval=0))
        assert len(results) == 1
        # Server verdict honored even though body is large and 2xx
        assert results[0].guidance.success is False
        assert batch.success_count == 0
        assert batch.failed_count == 1

    def test_batch_falls_back_to_heuristic_when_is_success_none(
        self, httpx_mock: HTTPXMock, client: ScrapingPros
    ):
        """Legacy runs (pre-migration) have is_success=None. SDK falls
        back to status_code + body heuristic."""
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=1, success=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com",
             "status_code": 200, "custom_id": "legacy"},
            # No is_success field — emulates pre-migration row
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", "legacy", success=True)
        batch = client.submit_batch("test", ["https://a.com"])
        results = list(batch.iter_results(poll_interval=0))
        # Falls back to heuristic: 2xx + body → success
        assert results[0].guidance.success is True
        assert batch.success_count == 1

    def test_run_until_complete(self, httpx_mock: HTTPXMock, client: ScrapingPros):
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=1, success=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com", "custom_id": "alpha"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", "alpha", success=True)

        batch = client.submit_batch("test", ["https://a.com"])
        results = batch.run_until_complete(poll_interval=0)
        assert len(results) == 1
        assert results[0].custom_id == "alpha"


# ---------------------------------------------------------------------------
# Async Batch
# ---------------------------------------------------------------------------

@pytest.fixture
async def async_client():
    c = AsyncClient(TOKEN, base_url=BASE)
    yield c
    await c.close()


class TestAsyncBatch:
    @pytest.mark.asyncio
    async def test_submit_batch_returns_async_batch(
        self, httpx_mock: HTTPXMock, async_client: AsyncScrapingPros
    ):
        _mock_submit(httpx_mock, "c1", "r1")
        batch = await async_client.submit_batch("test", ["https://a.com"])
        assert isinstance(batch, AsyncBatch)
        assert batch.collection_id == "c1"
        assert batch.run_id == "r1"
        assert batch.total == 1

    @pytest.mark.asyncio
    async def test_iter_results_async(
        self, httpx_mock: HTTPXMock, async_client: AsyncScrapingPros
    ):
        _mock_submit(httpx_mock, "c1", "r1")
        _mock_run_status(httpx_mock, "c1", "r1", "completed", total=1, success=1)
        _mock_jobs_page(httpx_mock, "c1", "r1", items=[
            {"job_public_id": "j1", "run_public_id": "r1", "collection_id": "c1",
             "status": "completed", "url": "https://a.com", "custom_id": "alpha"},
        ], cursor_next=None, has_more=False)
        _mock_result(httpx_mock, "c1", "r1", "j1", "https://a.com", "alpha", success=True)

        batch = await async_client.submit_batch("test", ["https://a.com"])
        results = []
        async for r in batch.iter_results(poll_interval=0):
            results.append(r)
        assert len(results) == 1
        assert results[0].custom_id == "alpha"
        assert batch.success_count == 1
