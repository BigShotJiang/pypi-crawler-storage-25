"""Attach to a running batch and stream what the user sees.

Uses client.get_batch() + iter_results() exactly as a user would.
Prints each result and progress tick to stdout with immediate flush so
you see what the feature reports in real time.
"""

import sys
from datetime import datetime

from scrapingpros import ScrapingPros

TOKEN = "3Fupbo6Qui4bl2w62Cz6"
COL_ID = "54d4c3b5-9c04-42f7-a113-d8e952b40294"
RUN_ID = "c00be6ac-c225-4df4-b470-62e19a393494"


def ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def main() -> None:
    client = ScrapingPros(TOKEN)
    batch = client.get_batch(COL_ID, RUN_ID)

    print(f"[{ts()}] Attached to batch:")
    print(f"  collection={batch.collection_id}")
    print(f"  run={batch.run_id}")
    sys.stdout.flush()

    def on_progress(b):
        eta = f"ETA {b.eta_seconds:.0f}s" if b.eta_seconds else "ETA n/a"
        print(f"[{ts()}] PROGRESS {b.completed_count}/{b.total} ({b.pct:5.1f}%) "
              f"| OK {b.success_count}, fail {b.failed_count} "
              f"| {b.jobs_per_second:.2f}/s | {eta} | status={b.status}",
              flush=True)

    batch.on_progress(on_progress)

    print(f"[{ts()}] Streaming results...", flush=True)
    i = 0
    for result in batch.iter_results(poll_interval=5.0, timeout=900):
        i += 1
        g = result.guidance
        ok = g is not None and g.success
        marker = "OK  " if ok else "FAIL"
        cid = (result.custom_id or "?")[:35].ljust(35)
        code = result.statusCode if result.statusCode else "---"
        size = len(result.content or "") if result.content else 0

        # If not ok, surface why
        detail = ""
        if not ok:
            parts = []
            if g is not None:
                if g.error_type:
                    parts.append(f"type={g.error_type}")
                if g.error_provider:
                    parts.append(f"provider={g.error_provider}")
                if g.stop_reason:
                    parts.append("stop")
            # Also surface server message (often has the real reason)
            if result.message and result.message != "OK":
                parts.append(f"msg={result.message[:80]!r}")
            if parts:
                detail = " [" + " | ".join(parts) + "]"

        print(f"[{ts()}] #{i:3d} {marker} {cid} http={code} {size:>7}c{detail}",
              flush=True)

    print(f"\n[{ts()}] FINISHED")
    print(f"  status={batch.status}")
    print(f"  total={batch.total}")
    print(f"  success={batch.success_count}")
    print(f"  failed={batch.failed_count}")
    print(f"  elapsed={batch.elapsed_seconds:.1f}s")
    print(f"  rate={batch.jobs_per_second:.2f} jobs/s")
    sys.stdout.flush()

    client.close()


if __name__ == "__main__":
    main()
