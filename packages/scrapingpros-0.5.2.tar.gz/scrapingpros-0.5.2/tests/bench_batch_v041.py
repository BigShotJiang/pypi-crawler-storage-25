"""Live test of Batch.iter_results() with 119 real-world URLs.

Uses the SP API token passed via CLI. Mix of easy/medium/hard targets.
Tests the v0.4.1 cursor-based polling end-to-end.

Usage:
    python tests/bench_batch_v041.py <token>
"""

import json
import sys
import time
from pathlib import Path

from scrapingpros import ScrapingPros


def main():
    if len(sys.argv) < 2:
        print("Usage: python tests/bench_batch_v041.py <token>")
        sys.exit(1)

    token = sys.argv[1]
    urls_file = Path("C:/Users/Lucho/Claude Code Projects/SP API Worker Coordinator/urls-export/default.json")
    data = json.loads(urls_file.read_text())
    urls = data["urls"]

    print(f"Loaded {len(urls)} URLs from {urls_file.name}")
    print(f"Mix: {sum(1 for u in urls if u['difficulty']=='easy')} easy, "
          f"{sum(1 for u in urls if u['difficulty']=='medium')} medium, "
          f"{sum(1 for u in urls if u['difficulty']=='hard')} hard")
    print()

    client = ScrapingPros(token)

    # Build items with custom_id and browser=True (most URLs benefit)
    items = [
        {
            "url": u["url"],
            "custom_id": f"{u['difficulty']}-{u['domain']}",
            "browser": True,
        }
        for u in urls
    ]

    t0 = time.monotonic()
    batch = client.submit_batch("bench-0.4.1", items)
    submitted_at = time.monotonic()
    print()
    print("=" * 72)
    print("  BATCH SUBMITTED — share these IDs with the SP API team:")
    print("=" * 72)
    print(f"  collection_id = {batch.collection_id}")
    print(f"  run_id        = {batch.run_id}")
    print(f"  total URLs    = {batch.total}")
    print(f"  submit time   = {submitted_at - t0:.2f}s")
    print("=" * 72)
    print()
    # Also save to a file for easy reference
    with open("last_batch_ids.txt", "w") as f:
        f.write(f"collection_id={batch.collection_id}\n")
        f.write(f"run_id={batch.run_id}\n")
        f.write(f"total={batch.total}\n")

    # Counters
    by_difficulty = {"easy": {"ok": 0, "fail": 0},
                     "medium": {"ok": 0, "fail": 0},
                     "hard": {"ok": 0, "fail": 0}}
    api_calls_before = 0  # we can't track exact but log progress
    poll_count = 0

    def on_progress(b):
        nonlocal poll_count
        poll_count += 1
        elapsed = b.elapsed_seconds
        eta = b.eta_seconds
        print(f"[{elapsed:5.1f}s] poll#{poll_count}: "
              f"{b.completed_count}/{b.total} ({b.pct:5.1f}%) | "
              f"OK {b.success_count}, fail {b.failed_count} | "
              f"rate {b.jobs_per_second:.2f}/s | "
              f"ETA {eta:.0f}s" if eta else "ETA n/a")

    batch.on_progress(on_progress)

    # Iterate and classify by difficulty
    for result in batch.iter_results(poll_interval=5.0, timeout=900):
        # custom_id format: "<difficulty>-<domain>"
        diff = (result.custom_id or "").split("-", 1)[0]
        if diff not in by_difficulty:
            continue
        success = result.guidance is not None and result.guidance.success
        by_difficulty[diff]["ok" if success else "fail"] += 1

    elapsed = time.monotonic() - t0
    print()
    print("=" * 60)
    print(f"DONE in {elapsed:.1f}s — {batch.success_count}/{batch.total} succeeded")
    print(f"Final status: {batch.status}")
    print()
    print("Success rate by difficulty:")
    for diff in ("easy", "medium", "hard"):
        s = by_difficulty[diff]
        total = s["ok"] + s["fail"]
        pct = s["ok"] / total * 100 if total else 0
        print(f"  {diff:7s}: {s['ok']:3d}/{total:3d} ({pct:5.1f}%)")

    client.close()


if __name__ == "__main__":
    main()
