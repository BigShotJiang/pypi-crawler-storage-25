# Handoff Coordinator → SDK team — features para agregar

**De:** Coordinator (ex-Workers)
**Para:** SDK team
**Fecha:** 2026-04-28
**Última corrección:** 2026-04-29 — Sección 2 reescrita (ver "Corrección 2026-04-29" abajo).
**Status:** 🟡 pendiente implementación SDK
**Source of truth**: `docs/sync/scrape.md` y `api/llms_txt.py` están al día (commit `f32f7b2` en master).

---

## ⚠️ Corrección 2026-04-29

La versión original de la **Sección 2 (ScrapeResponse)** describía 9 campos top-level (`success`, `error_type`, `error_provider`, `credits_charged`, `credits_refunded`, `next_steps`, `suggested_request`, `stop_reason`, `custom_id`) como contrato público. **Eso era incorrecto.**

Realidad confirmada por dos smokes independientes (SDK 2026-04-29 + Coordinator 2026-04-28) contra `POST /v1/sync/scrape`:

- El response trae `guidance: {...}` con todos esos campos **adentro del objeto guidance**.
- Top-level NO los emite (nunca lo hizo).
- `custom_id` sí está top-level (echo-back del request).

El error vino de confundir el shape interno del objeto `Verdict`/`Guidance` Python (`utils/html_validator.py`) con el wire format del endpoint sync. Ese shape interno con fields snake_case sí se persiste **en el async path** (`JobExecutionPublic`, ver Sección 3) — pero `ScrapeResponse` (sync) usa el shape `guidance.{...}` y siempre lo hizo.

**Decisión Coordinator + Lucho (2026-04-29)**: `guidance.*` queda como path canónico para el verdict del sync. SDK no necesita tipar fields top-level (sale del scope v0.5.0). Sección 2 reescrita abajo refleja la realidad.

Para el contrato del async path (`JobExecutionPublic`), Sección 3 sigue siendo correcta: top-level snake_case verificado en MySQL post-Track B (commits `cba64e2` + `03ca0a7` + `add9338`).

---

## Lista de features que el SDK debe agregar

### 1. ScrapeRequest — campos nuevos

#### `custom_id`

```
custom_id: Optional[str]    # max 255 chars
```

Identificador opcional del cliente. Se devuelve **echo-back** en:
- `ScrapeResponse.custom_id`
- Listado de jobs (`/v1/async/.../jobs` cada item)
- `/result` endpoint
- Webhooks

Ejemplo de uso típico: cliente pasa su SKU/ID interno y lo recupera del response sin tener que matchear por URL.

Doc: `docs/sync/scrape.md` sección `### custom_id`.

#### `MethodPOST.url`

Cuando el cliente arma un `http_method` POST, ahora puede agregar `url`:

```python
http_method = {
    "method": "post",
    "url": "https://example.com/api/search",   # nuevo campo opcional
    "payload": {"query": "rio rocket"}
}
```

Si `url` está presente, el POST va a esa URL (en vez del top-level `url` del scrape). Permite "navegar A pero POSTear a B" — útil para flujos donde la página que renderiza no es la misma que el endpoint API que el cliente quiere consumir.

Validación SSRF: debe empezar con `http://` o `https://`. El backend la valida; SDK puede agregar misma validación pre-flight para fallar fast.

Doc: `docs/sync/scrape.md` sección `### HttpMethod`, sub-bullet `url`.

---

### 2. ScrapeResponse — `guidance` es el path canónico (corregido 2026-04-29)

El response del sync endpoint devuelve el verdict **anidado bajo `guidance`** (no top-level). El SDK ya expone `guidance` desde v0.2.2 — sigue siendo el path correcto. **No hay fields top-level nuevos que tipar.**

#### Top-level (lo único nuevo)

```python
custom_id: Optional[str]             # echo-back desde request
```

#### `guidance: ScrapeGuidance` (objeto compuesto, ya tipado en SDK)

```python
class ScrapeGuidance:
    success: bool                        # always present
    error_type: Optional[str]            # rate_limit | captcha | ip_block | timeout | network | dns_fail | ...
    error_provider: Optional[str]        # cloudflare | akamai | datadome | perimeterx | recaptcha | ...
    credits_charged: int                 # 0 if refunded
    credits_refunded: bool
    next_steps: List[str]                # empty on success
    suggested_request: Optional[Dict[str, Any]]
    stop_reason: Optional[str]
```

**Recomendación al cliente**: usar `resp.guidance.success` para "fue éxito real" (en lugar del legacy `potentiallyBlockedByCaptcha`). El SDK puede marcar `potentiallyBlockedByCaptcha` como deprecated en docstring y apuntar a `resp.guidance.success` como path moderno.

**Nota sobre el contrato async**: si el SDK también expone `JobExecutionPublic` (Sección 3 abajo), **ahí sí** los fields del verdict son top-level snake_case (`is_success`, `block_reason`, `protection_stack`, `rule_hits`, `has_extractable_data`). Son dos contratos distintos: sync usa nested `guidance`, async usa top-level row de MySQL.

Doc: `docs/sync/scrape.md` sección `## Response` (sync) + `api/llms_txt.py` sección `JobExecutionPublic fields` (async).

---

### 3. JobExecutionPublic — modelo del listado async

Si el SDK expone helper para listar jobs de un run (`get_run_jobs(...)` o similar), el item del listado tiene estos campos:

```python
job_public_id: str
run_public_id: str
collection_id: str
client_id: str
url: str
url_truncated: bool                  # true si url se truncó a 2048 chars
custom_id: Optional[str]
status: Literal["processing", "completed", "failed", "timeout"]
status_code: Optional[int]
is_success: Optional[bool]           # verdict del HTML Validator (real content vs CAPTCHA wall)
block_reason: Optional[str]          # captcha | ip_block | rate_limit | soft_block_thin_content | ...
protection_stack: List[str]          # ["cloudflare", "akamai", ...] — empty si nada detectado
rule_hits: List[str]                 # rule IDs del validator que dispararon (diagnostics)
validator_version: Optional[str]
execution_time_ms: Optional[int]
execution_time_sec: Optional[float]  # legacy
queued_at: Optional[datetime]
started_at: Optional[datetime]
completed_at: Optional[datetime]
message: str                         # always populated
```

**`is_success` vs `status_code`**: usar `is_success` para "tasa de éxito real" (el HTML Validator descartó captchas/walls). `status_code` es el HTTP raw — puede ser 200 con un anti-bot wall y `is_success=false`.

**`protection_stack` y `rule_hits`** vienen del HTML Validator. Pueden venir como JSON string, CSV, o list — el serializer del API es defensivo. SDK debe ser igual de tolerante (parsear como list si viene str).

Doc: `api/llms_txt.py` sección `### JobExecutionPublic fields`.

---

### 4. Cursor pagination en `/jobs` listing

`GET /v1/async/collections/{cid}/runs/{rid}/jobs` ahora retorna:

```python
{
    "items": List[JobExecutionPublic],
    "cursor_next": Optional[str],
    "has_more": bool
}
```

Query params:
- `limit`: int, máximo 1000
- `cursor`: opaque string del response anterior. HMAC-signed (no enumerable).
- `status_filter`: Optional[Literal["completed", "failed", "timeout"]]

**Helper SDK recomendado**: `get_run_jobs()` sin parámetro de cursor debería loopear internamente y devolver todos los items, ocultando el cursor al usuario:

```python
# Ejemplo de comportamiento esperado
all_jobs = sdk.get_run_jobs(collection_id, run_id)
# → automáticamente paginea hasta has_more=False y junta todos los items
```

Para casos avanzados, el SDK puede exponer un iterador o un parámetro `paginate=False` que devuelve la primera página + `cursor_next` para que el cliente itere a mano.

Doc: `api/llms_txt.py` sección `### Cursor pagination`.

---

## Notas para el SDK team

### Nullability

Muchos campos del response son `Optional`. Según el path (success vs error vs partial), pueden venir `null`:
- `html` puede ser `null` cuando `format="markdown"` o en hard errors
- `markdown` puede ser `null` cuando `format="html"`
- `screenshot` siempre `null` salvo `screenshot=true`
- `extracted_data`, `evaluate_results`, `network_requests` `null` cuando no se pidió la feature
- `error_type`, `error_provider`, `suggested_request`, `stop_reason` `null` en success

SDK debe tolerar `null` en todos estos.

### Parsing defensivo

`protection_stack` y `rule_hits` pueden llegar como:
- list (formato canónico)
- JSON string (ej. `"[\"cloudflare\"]"`)
- CSV string (ej. `"cloudflare,akamai"`)
- `null`

El backend ya tiene serializer defensivo. SDK debe parsear cualquiera de estos formatos a `List[str]`.

### NO agregar todavía

- **`per_job_webhook_url`** — diseño en pausa (revisar `SP API/handoff-async-webhook-delivery-design.md` cuando Lucho firme).
- **Anything related to `tls_impersonate`** — internal-only en `browser_options`, NO exponer al cliente público.
- **Anything related to `browser_options.warmup_url`, `browser_options.return_cookies`** — internal-only.

---

## Pendiente del lado Coordinator

Si encuentran que algún field en `docs/sync/scrape.md` o `llms_txt.py` está incompleto o incorrecto, ping. Lo arreglamos upstream para que el tipado del SDK sea consistente.

Si quieren OpenAPI snapshot fresco (`api/openapi.json` desde prod) para auto-generar parte del tipado, decime y se los bajo.

Cualquier duda, pingback acá. Bajan estado a 🟢 cuando el release con estos campos esté listo.
