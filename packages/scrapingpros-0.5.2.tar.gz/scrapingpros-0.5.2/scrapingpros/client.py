"""Synchronous client for the Scraping Pros API.

Example:
    >>> from scrapingpros import ScrapingPros
    >>> client = ScrapingPros("your_token")
    >>> result = client.scrape("https://example.com")
    >>> print(result.html[:50])
    '<!doctype html>...'
"""

from __future__ import annotations

import time
import warnings
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Any, Callable, Literal

import httpx

from scrapingpros._base import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    RateLimitInfo,
    RetryConfig,
    _is_quota_error,
    logger,
    map_error,
    parse_rate_limit_headers,
    resolve_token,
)
from scrapingpros.exceptions import ConnectionError, RateLimitError, TimeoutError
from scrapingpros.models import (
    Action,
    CollectionPublic,
    DownloadResponse,
    HttpMethod,
    JobExecutionListPublic,
    JobExecutionPublic,
    NewCollectionResponse,
    BillingResponse,
    ClientMetricsResponse,
    ProxyCountriesResponse,
    ProxyRequestCountryResponse,
    ProxyStatusResponse,
    RunPublic,
    ScrapeRequest,
    ScrapeResponse,
    UseProxy,
    ViabilityRunPublic,
    NetworkCaptureConfig,
)


class ScrapingPros:
    """Synchronous Python client for the Scraping Pros API.

    The simplest way to start scraping:

    Example:
        >>> client = ScrapingPros("demo_6x595maoA6GdOdVb")
        >>> result = client.scrape("https://example.com")
        >>> print(result.html[:50])
        '<!doctype html>...'

        >>> # Or use the SP_TOKEN environment variable:
        >>> client = ScrapingPros()

    Args:
        token: Your API token. Falls back to the ``SP_TOKEN`` env var.
            Use ``"demo_6x595maoA6GdOdVb"`` for quick testing
            (5,000 credits/month, 30 req/min).
        base_url: API base URL. Defaults to ``https://api.scrapingpros.com``.
        timeout: Request timeout in seconds. Defaults to 120.
        max_retries: Max automatic retries on 429. Defaults to 3.
    """

    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        if type(self) is ScrapingPros:
            warnings.warn(
                "`ScrapingPros` was renamed to `SyncClient` in v0.5.1 and "
                "will be removed in v1.0. Update the import: "
                "`from scrapingpros import SyncClient`. The behaviour is "
                "identical — the rename clarifies that this client (and "
                "`AsyncClient`) can call every endpoint, sync or "
                "Collections; only the local I/O loop differs.",
                DeprecationWarning,
                stacklevel=2,
            )
        self._token = resolve_token(token)
        self._base_url = base_url.rstrip("/")
        self._retry = RetryConfig(max_retries=max_retries)
        self._last_rate_limit = RateLimitInfo()
        self._plan_max_concurrent: int | None = None  # lazy-loaded from /v1/plans
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
            limits=httpx.Limits(
                max_connections=200,
                max_keepalive_connections=100,
            ),
        )

    # -- Lifecycle ----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> ScrapingPros:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -- Rate limit properties ----------------------------------------------

    @property
    def rate_limit_remaining(self) -> int | None:
        """Remaining requests in the current rate-limit window.

        Updated after every API call. ``None`` until the first call.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.scrape("https://example.com")  # doctest: +SKIP
            >>> print(client.rate_limit_remaining)
            185
        """
        return self._last_rate_limit.rate_limit_remaining

    @property
    def quota_remaining(self) -> int | str | None:
        """Remaining requests in the monthly quota.

        Can be an ``int``, the string ``"unlimited"``, or ``None``
        until the first API call.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.scrape("https://example.com")  # doctest: +SKIP
            >>> print(client.quota_remaining)
            8477
        """
        return self._last_rate_limit.quota_remaining

    @property
    def credits_charged(self) -> int | None:
        """Credits charged for the last API call.

        1 for simple requests, 5 for browser requests, 0 for refunded
        infrastructure errors.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.scrape("https://example.com", browser=True)  # doctest: +SKIP
            >>> print(client.credits_charged)
            5
        """
        return self._last_rate_limit.credits_charged

    def _detect_max_concurrent(self) -> int:
        """Detect max concurrent jobs from the plan.

        Calls ``/v1/plans`` once and matches ``quota_limit`` from response
        headers to find the user's plan. For Enterprise or custom plans
        that don't match, estimates from rate limit headers. Caches result.
        """
        if self._plan_max_concurrent is not None:
            return self._plan_max_concurrent

        default = 5
        try:
            quota_limit = self._last_rate_limit.quota_limit
            rate_limit = self._last_rate_limit.rate_limit_limit

            if quota_limit is None and rate_limit is None:
                self._plan_max_concurrent = default
                return default

            # Try to match a known plan
            plans_data = self.plans()
            for plan in plans_data.get("plans", []):
                if plan.get("credits_monthly") == quota_limit:
                    self._plan_max_concurrent = plan.get("max_concurrent_jobs", default)
                    logger.info(
                        "Detected plan '%s' — max concurrent: %d",
                        plan.get("display_name"), self._plan_max_concurrent,
                    )
                    return self._plan_max_concurrent

            # Enterprise / custom plan — estimate from rate limit
            # Use rate_limit / 6 as a safe concurrent count
            # (assumes ~10s avg request time, leaving headroom)
            if rate_limit and rate_limit > 0:
                estimated = max(5, rate_limit // 6)
                self._plan_max_concurrent = min(estimated, 100)
                logger.info(
                    "Custom/Enterprise plan (rate=%d/min) — max concurrent: %d",
                    rate_limit, self._plan_max_concurrent,
                )
                return self._plan_max_concurrent

            self._plan_max_concurrent = default
        except Exception:
            self._plan_max_concurrent = default

        return self._plan_max_concurrent

    # -- Internal request with retry ----------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send an HTTP request with automatic retry on 429 and 5xx."""
        last_exc: Exception | None = None
        for attempt in range(self._retry.max_retries + 1):
            try:
                resp = self._http.request(method, path, **kwargs)
            except httpx.HTTPError as exc:
                raise ConnectionError(
                    f"Could not connect to {self._base_url}: {exc}"
                ) from exc

            # Update rate-limit tracking from every response
            self._last_rate_limit = parse_rate_limit_headers(
                dict(resp.headers),
            )

            if resp.status_code < 400:
                return resp

            # Quota exceeded — don't retry, it won't help
            if resp.status_code == 429 and _is_quota_error(resp.text):
                raise map_error(resp.status_code, resp.text, dict(resp.headers))

            # Retryable: 429 (rate limit) and 5xx (server errors)
            is_retryable = resp.status_code == 429 or resp.status_code >= 500
            if is_retryable and attempt < self._retry.max_retries:
                retry_after_raw = resp.headers.get("retry-after")
                retry_after: float | None = None
                if retry_after_raw:
                    try:
                        retry_after = float(retry_after_raw)
                    except (ValueError, TypeError):
                        pass
                delay = self._retry.delay_for_attempt(attempt, retry_after)
                # INFO (not WARNING) since v0.5.2: under load this can fire
                # thousands of times per minute, drowning legitimate WARNINGs
                # in the caller's log. Callers wanting visibility can lower
                # the SDK logger to INFO; default WARNING silences these.
                logger.info(
                    "Request %s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                    method, path, resp.status_code, delay,
                    attempt + 1, self._retry.max_retries,
                )
                time.sleep(delay)
                last_exc = map_error(resp.status_code, resp.text, dict(resp.headers))
                continue

            raise map_error(resp.status_code, resp.text, dict(resp.headers))

        # All retries exhausted
        if last_exc is not None:
            raise last_exc
        raise map_error(resp.status_code, resp.text, dict(resp.headers))  # pragma: no cover

    # -----------------------------------------------------------------------
    # Sync endpoints
    # -----------------------------------------------------------------------

    def scrape(
        self,
        url: str,
        *,
        format: Literal["html", "markdown"] = "html",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        screenshot: bool = False,
        actions: list[Action] | None = None,
        language: str = "",
        http_method: HttpMethod | None = None,
        headers: dict[str, str] | None = None,
        window_size: str = "",
        cookies: dict[str, Any] | None = None,
        extract: dict[str, str | dict[str, Any]] | None = None,
        network_capture: NetworkCaptureConfig | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
    ) -> ScrapeResponse:
        """Scrape a single URL.

        Args:
            url: The URL to scrape (http/https).
            format: Output format — ``"html"`` (default) or ``"markdown"``.
            browser: Enable headless browser rendering.
            browser_type: ``"heavy"`` (default, anti-detection), ``"light"`` (fast),
                or ``"stealth"`` (maximum anti-detection for hard sites).
            use_proxy: Proxy config — ``"any"`` (default), ``None`` for no proxy,
                a country code, or :class:`ProxyConfig`.
            screenshot: Capture a full-page screenshot (requires ``browser=True``).
            actions: Browser automation steps (click, input, etc.).
            language: Accept-Language header and browser locale.
            http_method: Override HTTP method (GET/POST with payload).
            headers: Custom HTTP headers for the request.
            window_size: Viewport — ``"desktop"``, ``"mobile"``, or ``"any"``.
            cookies: Cookies to set before loading the page.
            extract: CSS/XPath selectors for structured data extraction.
            network_capture: Capture network requests (requires ``browser=True``).
            retry_on_block: Auto-retry up to 3 times with different IP/fingerprint
                on CAPTCHA or 403. Only charges credits on the successful attempt.
            block_resources: Resource types to block (requires ``browser=True``).
                Valid types: ``"image"``, ``"stylesheet"``, ``"font"``, ``"media"``,
                ``"script"``, ``"xhr"``, ``"fetch"``, etc.
            block_requests: URL substrings to block (case-insensitive, requires
                ``browser=True``). For trackers, analytics, ads.

        Returns:
            :class:`ScrapeResponse` with ``html``, ``markdown``, ``extracted_data``, etc.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> result = client.scrape("https://example.com", format="markdown")
            >>> print(result.markdown)  # doctest: +SKIP
            '# Example Domain ...'
        """
        req = ScrapeRequest(
            url=url,
            format=format,
            browser=browser,
            browser_type=browser_type,
            use_proxy=use_proxy,
            screenshot=screenshot,
            actions=actions,
            language=language,
            http_method=http_method,
            headers=headers,
            window_size=window_size,
            cookies=cookies,
            extract=extract,
            network_capture=network_capture,
            retry_on_block=retry_on_block,
            block_resources=block_resources,
            block_requests=block_requests,
        )
        # retry_on_block makes the server do up to 3 internal retries,
        # so we need a longer timeout for that request
        extra_kwargs: dict[str, Any] = {}
        if retry_on_block:
            extra_kwargs["timeout"] = max(self._http.timeout.read or 120, 300)

        resp = self._request(
            "POST",
            "/v1/sync/scrape",
            json=req.model_dump(exclude_none=True, exclude_defaults=False),
            **extra_kwargs,
        )
        return ScrapeResponse.model_validate(resp.json())

    def scrape_many(
        self,
        urls: list[str] | list[ScrapeRequest | dict[str, Any]] | None = None,
        *,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
        max_concurrent: int | None = None,
        format: Literal["html", "markdown"] = "markdown",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        extract: dict[str, str | dict[str, Any]] | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
        actions: list[Action] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, Any] | None = None,
        language: str = "",
        window_size: str = "",
        screenshot: bool = False,
        http_method: HttpMethod | None = None,
        network_capture: NetworkCaptureConfig | None = None,
    ) -> list[ScrapeResponse | Exception]:
        """Scrape multiple URLs concurrently with automatic throttling.

        .. warning::
            ``scrape_many`` runs **client-side parallelism** — it opens
            up to ``max_concurrent`` simultaneous HTTP connections from
            your machine to ``/v1/sync/scrape``. That works for small
            ad-hoc batches (~10–50 URLs) but does **not** scale: the
            server treats every request as an independent sync call,
            so each pays full overhead and you compete with other
            sync traffic.

            For anything larger than a handful of URLs, prefer
            :meth:`submit_batch` + :meth:`Batch.iter_results`. That
            sends a single request to the **Collections** API, the
            server runs the batch in its async worker pool with
            optimised concurrency, and you stream results back as they
            complete — with progress, automatic refunds on failures,
            and resilience to worker restarts. See also the
            :meth:`batch_scrape` convenience wrapper that mirrors this
            method's signature but uses the Collections API.

        Accepts either a list of URL strings (all sharing the same parameters),
        or a list of :class:`ScrapeRequest` / dicts for heterogeneous batches
        where each request has its own parameters.

        Limits concurrency to ``max_concurrent`` requests at a time to
        avoid hitting rate limits. Returns results in the same order
        as the input. Failed requests return the exception instead of raising.

        Args:
            urls: List of URL strings (all use the same params), or list of
                :class:`ScrapeRequest` / dicts for per-URL params.
            requests: Alternative to ``urls`` for heterogeneous batches.
                Each item is a :class:`ScrapeRequest` or dict with per-URL params.
            max_concurrent: Max parallel requests. Auto-detected from your
                plan if ``None`` (reads ``max_concurrent_jobs`` from ``/v1/plans``).
            format: Output format for all URLs.
            browser: Enable browser rendering for all URLs.
            browser_type: Browser type for all URLs.
            use_proxy: Proxy config for all URLs.
            extract: CSS/XPath selectors for all URLs.
            retry_on_block: Auto-retry on CAPTCHA/403 for all URLs.
            block_resources: Resource types to block for all URLs.
            block_requests: URL substrings to block for all URLs.
            actions: Browser automation steps for all URLs.
            headers: Custom HTTP headers for all URLs.
            cookies: Cookies for all URLs.
            language: Accept-Language for all URLs.
            window_size: Viewport for all URLs.
            screenshot: Capture screenshots for all URLs.
            http_method: HTTP method override for all URLs.
            network_capture: Network capture config for all URLs.

        Returns:
            List of :class:`ScrapeResponse` or ``Exception`` for each input,
            in the same order.

        Example:
            >>> client = ScrapingPros("demo_6x595maoA6GdOdVb")
            >>> results = client.scrape_many([
            ...     "https://example.com",
            ...     "https://quotes.toscrape.com/",
            ... ], browser=True, actions=[...])  # doctest: +SKIP
        """
        warnings.warn(
            "`scrape_many` opens N parallel HTTP connections from your "
            "machine to /v1/sync/scrape and does not scale beyond a "
            "handful of URLs. For production batches use "
            "`client.batch_scrape(urls)` (drop-in list return) or "
            "`client.submit_batch(name, urls)` (streaming with progress) — "
            "both run server-side parallelism via the Collections API. "
            "`scrape_many` will be removed in v1.0. See "
            "https://docs.scrapingpros.com/docs/documentation/Python%20SDK/choosing-the-right-method",
            DeprecationWarning,
            stacklevel=2,
        )
        # Resolve inputs: support urls as strings, ScrapeRequests, or dicts
        items: list[ScrapeRequest | str] = []
        if requests is not None:
            # Explicit requests= kwarg (heterogeneous batch)
            for r in requests:
                if isinstance(r, dict):
                    items.append(ScrapeRequest(**r))
                else:
                    items.append(r)
        elif urls is not None:
            for u in urls:
                if isinstance(u, str):
                    items.append(u)
                elif isinstance(u, dict):
                    items.append(ScrapeRequest(**u))
                else:
                    items.append(u)  # ScrapeRequest
        else:
            raise ValueError("Either urls or requests must be provided")

        if max_concurrent is None:
            max_concurrent = self._detect_max_concurrent()

        result_list: list[ScrapeResponse | Exception] = [None] * len(items)  # type: ignore

        def _scrape_one(index: int, item: ScrapeRequest | str) -> tuple[int, ScrapeResponse | Exception]:
            try:
                if isinstance(item, ScrapeRequest):
                    # Heterogeneous: each request has its own params
                    req = item
                    extra_kwargs: dict[str, Any] = {}
                    if req.retry_on_block:
                        extra_kwargs["timeout"] = max(self._http.timeout.read or 120, 300)
                    resp = self._request(
                        "POST",
                        "/v1/sync/scrape",
                        json=req.model_dump(exclude_none=True, exclude_defaults=False),
                        **extra_kwargs,
                    )
                    return index, ScrapeResponse.model_validate(resp.json())
                else:
                    # Homogeneous: all URLs share the same params
                    resp = self.scrape(
                        item,
                        format=format,
                        browser=browser,
                        browser_type=browser_type,
                        use_proxy=use_proxy,
                        extract=extract,
                        retry_on_block=retry_on_block,
                        block_resources=block_resources,
                        block_requests=block_requests,
                        actions=actions,
                        headers=headers,
                        cookies=cookies,
                        language=language,
                        window_size=window_size,
                        screenshot=screenshot,
                        http_method=http_method,
                        network_capture=network_capture,
                    )
                    return index, resp
            except Exception as e:
                return index, e

        with ThreadPoolExecutor(max_workers=max_concurrent) as pool:
            futures = [
                pool.submit(_scrape_one, i, item)
                for i, item in enumerate(items)
            ]
            for future in as_completed(futures):
                idx, result = future.result()
                result_list[idx] = result

        return result_list

    def download(
        self,
        url: str,
        *,
        use_proxy: UseProxy = None,
    ) -> DownloadResponse:
        """Download a file and return its content as base64.

        Args:
            url: Direct link to the file (PDF, image, etc.).
            use_proxy: Proxy config — ``None``, ``"any"``, a country code, or :class:`ProxyConfig`.

        Returns:
            :class:`DownloadResponse` with ``content`` (base64), ``contentType``, etc.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> result = client.download("https://example.com/report.pdf")  # doctest: +SKIP
            >>> print(result.contentType)
            'application/pdf'
        """
        body: dict[str, Any] = {"url": url}
        if use_proxy is not None:
            body["use_proxy"] = use_proxy if isinstance(use_proxy, str) else use_proxy.model_dump()
        resp = self._request("POST", "/v1/sync/download", json=body)
        return DownloadResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Collections
    # -----------------------------------------------------------------------

    def create_collection(
        self,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
        *,
        callback_url: str | None = None,
        _timeout: float | None = None,
    ) -> NewCollectionResponse:
        """Create a new collection for async batch processing.

        Args:
            name: Collection name.
            requests: List of scrape requests. Accepts :class:`ScrapeRequest`
                objects or plain dicts with the same structure.
            callback_url: Webhook URL to receive a POST when runs complete.
                The POST is signed with HMAC-SHA256 (``X-SP-Signature`` header).

        Returns:
            :class:`NewCollectionResponse` with the collection ``id``.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> col = client.create_collection("my-batch", [
            ...     {"url": "https://example.com/1"},
            ...     {"url": "https://example.com/2"},
            ... ])  # doctest: +SKIP
            >>> print(col.id)
            'abc-123'
        """
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        if callback_url is not None:
            body["callback_url"] = callback_url
        kwargs: dict[str, Any] = {"json": body}
        if _timeout is not None:
            kwargs["timeout"] = _timeout
        resp = self._request("POST", "/v1/async/collections", **kwargs)
        return NewCollectionResponse.model_validate(resp.json())

    def list_collections(self) -> list[CollectionPublic]:
        """List all collections.

        Returns:
            List of :class:`CollectionPublic` objects.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> collections = client.list_collections()  # doctest: +SKIP
            >>> for col in collections:
            ...     print(col.name)
        """
        resp = self._request("GET", "/v1/async/collections")
        return [CollectionPublic.model_validate(c) for c in resp.json()]

    def get_collection(self, collection_id: str) -> CollectionPublic:
        """Get a specific collection by ID.

        Args:
            collection_id: The collection UUID.

        Returns:
            :class:`CollectionPublic` with ``id`` and ``name``.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> col = client.get_collection("abc-123")  # doctest: +SKIP
            >>> print(col.name)
        """
        resp = self._request("GET", f"/v1/async/collections/{collection_id}")
        return CollectionPublic.model_validate(resp.json())

    def update_collection(
        self,
        collection_id: str,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
    ) -> NewCollectionResponse:
        """Update an existing collection.

        Args:
            collection_id: The collection UUID.
            name: New collection name.
            requests: New list of scrape requests (replaces existing).

        Returns:
            :class:`NewCollectionResponse`.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.update_collection("abc-123", "updated-name")  # doctest: +SKIP
        """
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        resp = self._request(
            "PUT",
            f"/v1/async/collections/{collection_id}",
            json=body,
        )
        return NewCollectionResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Runs
    # -----------------------------------------------------------------------

    def create_run(self, collection_id: str, *, _timeout: float | None = None) -> RunPublic:
        """Start a run for a collection.

        Args:
            collection_id: The collection UUID to run.

        Returns:
            :class:`RunPublic` with ``run_id`` and initial status.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.create_run("abc-123")  # doctest: +SKIP
            >>> print(run.run_id)
        """
        kwargs: dict[str, Any] = {}
        if _timeout is not None:
            kwargs["timeout"] = _timeout
        resp = self._request(
            "POST",
            f"/v1/async/collections/{collection_id}/run",
            **kwargs,
        )
        return RunPublic.model_validate(resp.json())

    def get_run(self, collection_id: str, run_id: str) -> RunPublic:
        """Get the status of a run.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.

        Returns:
            :class:`RunPublic` with status, counts, and failed jobs.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.get_run("col-123", "run-456")  # doctest: +SKIP
            >>> print(run.status)
            'completed'
        """
        resp = self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}",
        )
        return RunPublic.model_validate(resp.json())

    def get_run_jobs(
        self,
        collection_id: str,
        run_id: str,
        *,
        cursor: str | None = None,
        limit: int = 1000,
        status_filter: Literal["processing", "completed", "failed", "timeout"] | None = None,
    ) -> JobExecutionListPublic:
        """Get detailed job executions for a run.

        The API paginates results. By default this method **fetches all
        pages internally** and returns the merged list (backward-compatible
        with previous behavior). To page manually, pass ``cursor`` —
        only one page is returned then. For very large runs prefer
        :meth:`iter_run_jobs` which streams jobs without loading everything
        into memory.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.
            cursor: Opaque pagination token from a previous response's
                ``cursor_next``. If provided, only one page is returned.
            limit: Items per page (1..1000). Default 1000.
            status_filter: Only return jobs with this status.

        Returns:
            :class:`JobExecutionListPublic` with individual job statuses.
            ``cursor_next`` and ``has_more`` are populated only when
            ``cursor`` is explicitly passed by the caller.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> jobs = client.get_run_jobs("col-123", "run-456")  # doctest: +SKIP
            >>> for job in jobs.items:
            ...     print(job.url, job.status, job.custom_id)
        """
        if cursor is not None:
            # Manual pagination: return a single page as-is
            return self._fetch_jobs_page(
                collection_id, run_id, cursor=cursor,
                limit=limit, status_filter=status_filter,
            )

        # Default: loop internally and return all items
        all_items: list = []
        next_cursor: str | None = None
        while True:
            page = self._fetch_jobs_page(
                collection_id, run_id, cursor=next_cursor,
                limit=limit, status_filter=status_filter,
            )
            all_items.extend(page.items)
            if not page.has_more or not page.cursor_next:
                break
            next_cursor = page.cursor_next
        return JobExecutionListPublic(items=all_items, cursor_next=None, has_more=False)

    def _fetch_jobs_page(
        self,
        collection_id: str,
        run_id: str,
        *,
        cursor: str | None,
        limit: int,
        status_filter: str | list[str] | None,
        order_by: Literal["id", "completed_at"] | None = None,
        order_dir: Literal["asc", "desc"] | None = None,
        since_completed_at: "datetime | str | None" = None,
    ) -> JobExecutionListPublic:
        """Fetch a single page of run jobs.

        Supports cursor pagination, status filtering (single value or CSV
        list), custom ordering, and incremental polling by
        ``since_completed_at``. These map to the server-side query params
        added in the 2026-04-24 async filters release.
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        if status_filter is not None:
            # Server accepts CSV; if caller passed a list, join it.
            if isinstance(status_filter, (list, tuple)):
                params["status_filter"] = ",".join(status_filter)
            else:
                params["status_filter"] = status_filter
        if order_by is not None:
            params["order_by"] = order_by
        if order_dir is not None:
            params["order_dir"] = order_dir
        if since_completed_at is not None:
            # Accept datetime or string; the server wants ISO 8601.
            if hasattr(since_completed_at, "isoformat"):
                params["since_completed_at"] = since_completed_at.isoformat(timespec="milliseconds")
            else:
                params["since_completed_at"] = str(since_completed_at)
        resp = self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs",
            params=params,
        )
        return JobExecutionListPublic.model_validate(resp.json())

    def iter_run_jobs(
        self,
        collection_id: str,
        run_id: str,
        *,
        page_size: int = 500,
        status_filter: Literal["processing", "completed", "failed", "timeout"] | None = None,
    ) -> Iterator[JobExecutionPublic]:
        """Stream jobs from a run, fetching pages lazily.

        Recommended for runs with hundreds or thousands of jobs — avoids
        loading the full list into memory.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.
            page_size: Items per page fetched from the API (1..1000). Default 500.
            status_filter: Only yield jobs with this status.

        Yields:
            :class:`JobExecutionPublic` one at a time, in cursor order.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> for job in client.iter_run_jobs("col-123", "run-456"):  # doctest: +SKIP
            ...     if job.status == "completed":
            ...         result = client.get_job_result(job.collection_id, job.run_public_id, job.job_public_id)
            ...         process(result, job.custom_id)
        """
        next_cursor: str | None = None
        while True:
            page = self._fetch_jobs_page(
                collection_id, run_id, cursor=next_cursor,
                limit=page_size, status_filter=status_filter,
            )
            for job in page.items:
                yield job
            if not page.has_more or not page.cursor_next:
                return
            next_cursor = page.cursor_next

    def run_and_wait(
        self,
        collection_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 3600.0,
    ) -> RunPublic:
        """Create a run and poll until it completes.

        .. tip::
            For most production workloads prefer :meth:`submit_batch` +
            :meth:`Batch.iter_results`. Streaming results as workers
            finish them removes the need to pick a single global
            timeout — large browser/stealth runs can take 20+ minutes
            but their per-job latency is normal.

        Args:
            collection_id: The collection UUID to run.
            poll_interval: Seconds between status checks. Defaults to 2.
            timeout: Max seconds to wait for the *entire* run to
                finish. Defaults to **3600** (1 hour) since v0.5.1 —
                browser-rendered batches with anti-bot retries
                routinely exceed several minutes per page. The previous
                default (300 s) timed out legitimate runs.

        Returns:
            :class:`RunPublic` with final status and results.

        Raises:
            TimeoutError: If the run does not complete within *timeout*.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.run_and_wait("col-123", timeout=60)  # doctest: +SKIP
            >>> print(f"Done: {run.success_requests}/{run.total_requests}")
        """
        run = self.create_run(collection_id)
        start = time.monotonic()
        while True:
            run = self.get_run(collection_id, run.run_id)
            if run.status in ("completed", "failed", "cancelled"):
                return run
            if time.monotonic() - start > timeout:
                raise TimeoutError(
                    f"Run {run.run_id} did not complete within {timeout}s"
                )
            time.sleep(poll_interval)

    # -----------------------------------------------------------------------
    # High-level batch API (v0.4.0+)
    # -----------------------------------------------------------------------

    def submit_batch(
        self,
        name: str,
        items: list[str] | list[ScrapeRequest | dict[str, Any]],
        *,
        callback_url: str | None = None,
        submit_timeout: float = 30.0,
        on_submitted: "Callable[[str, str | None], None] | None" = None,
    ) -> "Batch":
        """Submit a batch of scrapes and return a :class:`Batch` handle.

        Creates a collection, adds all the items, starts a run, and returns
        a :class:`Batch` with which you can stream results as they complete,
        track progress, and register callbacks.

        Accepts:
            - ``list[str]`` — URLs only, all default options.
            - ``list[dict]`` — full per-item params (url, custom_id, browser,
              actions, extract, etc.). Each ``url`` is validated client-side
              before submit (since v0.5.2) — empty / non-http(s) URLs raise
              :class:`ValueError` instead of silently failing in a worker.
            - ``list[ScrapeRequest]`` — typed per-item params.

        Args:
            name: Collection name. Use a unique value per submit (e.g.
                with a UUID suffix) so you can recover orphans via
                :meth:`find_recent_batch` if the submit times out.
            items: Items to scrape (see above).
            callback_url: Optional webhook to receive a signed POST
                notification when the run finishes. If set, you can
                run "fire-and-forget" without iterating results.
            submit_timeout: Per-step timeout for the underlying HTTP
                calls (collection create + run create). Default **30 s**
                — short enough to fail fast during API degradation but
                long enough for normal load. On timeout the SDK raises
                :class:`SubmitTimeout`; **do not blindly retry**, the
                batch may have been created server-side. Use
                :meth:`find_recent_batch` to look up the orphan first.
            on_submitted: Optional ``callable(collection_id, run_id)``
                invoked **between** the two server steps so the caller
                can persist IDs eagerly. Called once with
                ``(collection_id, None)`` after the collection exists,
                and once with ``(collection_id, run_id)`` after the run
                exists. If your script can crash between submit and the
                first time you persist IDs, register this callback to
                write to disk inside the SDK call itself.

        Raises:
            SubmitTimeout: If either underlying HTTP call exceeds
                ``submit_timeout``. The collection and/or run **may**
                exist server-side; check with :meth:`find_recent_batch`.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> batch = client.submit_batch("reviews-daily", [
            ...     {"url": tour.url, "custom_id": tour.id, "browser": True}
            ...     for tour in tours
            ... ])  # doctest: +SKIP
            >>> for result in batch.iter_results():
            ...     if result.guidance and result.guidance.success:
            ...         save(result.content, my_id=result.custom_id)

        Recovery pattern for crash-resilient pipelines::

            import uuid
            from datetime import datetime, timezone
            from scrapingpros import SubmitTimeout

            batch_name = f"daily-{uuid.uuid4().hex[:8]}"
            fired_at = datetime.now(timezone.utc)
            try:
                batch = client.submit_batch(
                    batch_name, items,
                    on_submitted=lambda cid, rid: persist_to_disk(cid, rid),
                )
            except SubmitTimeout:
                batch = client.find_recent_batch(name=batch_name, since=fired_at)
                if batch is None:
                    batch = client.submit_batch(batch_name, items)  # truly retry
        """
        from scrapingpros.batch import Batch, _normalize_items
        from scrapingpros.exceptions import (
            ConnectionError as SPConnectionError,
            SubmitTimeout,
        )

        payload = _normalize_items(items)
        try:
            col = self.create_collection(
                name, payload, callback_url=callback_url, _timeout=submit_timeout,
            )
        except SPConnectionError as exc:
            raise SubmitTimeout(
                f"submit_batch timed out creating collection {name!r} after "
                f"{submit_timeout}s. The collection MAY have been created "
                f"server-side; do NOT blindly retry. Call "
                f"client.find_recent_batch(name={name!r}, since=...) to recover "
                f"the orphan first. Underlying: {exc.message}"
            ) from exc
        if on_submitted is not None:
            on_submitted(col.id, None)

        try:
            run = self.create_run(col.id, _timeout=submit_timeout)
        except SPConnectionError as exc:
            raise SubmitTimeout(
                f"submit_batch timed out starting run for collection {col.id} "
                f"after {submit_timeout}s. The collection EXISTS server-side "
                f"but the run may or may not. Call "
                f"client.find_recent_batch(name={name!r}, since=...) — when "
                f"`list_runs` is available it will return the run; otherwise "
                f"call client.create_run({col.id!r}) explicitly. "
                f"Underlying: {exc.message}"
            ) from exc
        if on_submitted is not None:
            on_submitted(col.id, run.run_id)

        return Batch(
            self,
            collection_id=col.id,
            run_id=run.run_id,
            name=name,
            total=len(payload),
        )

    def submit_batch_lenient(
        self,
        name: str,
        items: list[str] | list[ScrapeRequest | dict[str, Any]],
        *,
        callback_url: str | None = None,
        submit_timeout: float = 30.0,
        on_submitted: "Callable[[str, str | None], None] | None" = None,
        max_drops: int = 50,
    ) -> "tuple[Batch, list[dict[str, Any]]]":
        """Like :meth:`submit_batch` but skips URLs the API rejects.

        For batches of hundreds of URLs a single bad URL (transient
        DNS resolving to ``::1``, takedown, redirect to a private IP)
        currently rejects the **entire** collection with HTTP 400.
        This wrapper retries the submit dropping the offending URL
        each time, until the batch is accepted or ``max_drops`` is
        exceeded.

        It works by parsing the URL out of the API's error string
        (``URL blocked: ... (resolved from 'X.com')``). This is
        fragile by design — the proper fix is server-side
        (request #6 in the SP API handoff: structured response with
        a list of blocked URLs). When that ships this wrapper will
        switch to using it; the public signature stays the same.

        Args:
            name: Same as :meth:`submit_batch`.
            items: Same as :meth:`submit_batch`.
            callback_url: Same as :meth:`submit_batch`.
            submit_timeout: Same as :meth:`submit_batch`.
            on_submitted: Same as :meth:`submit_batch`.
            max_drops: Safety cap on how many bad URLs to drop
                before giving up. Default **50**. If exceeded the
                last :class:`URLBlockedError` propagates so you can
                debug the input data.

        Returns:
            Tuple ``(batch, dropped)`` where ``dropped`` is a list
            of the original items that were rejected, each augmented
            with a ``__rejection_reason__`` key parsed from the API
            error message.

        Example:
            >>> batch, dropped = client.submit_batch_lenient(
            ...     "daily-scrape",
            ...     items_with_some_bad_urls,
            ... )  # doctest: +SKIP
            >>> print(f"submitted {batch.total}, dropped {len(dropped)}")
            >>> for d in dropped:
            ...     print("  ✗", d["url"], "—", d["__rejection_reason__"])
        """
        import re

        from scrapingpros.exceptions import APIError

        # Work on a mutable copy; preserve the original objects so we
        # can return them in `dropped` with provenance.
        remaining: list[Any] = list(items)
        dropped: list[dict[str, Any]] = []

        for _ in range(max_drops + 1):
            try:
                batch = self.submit_batch(
                    name, remaining,
                    callback_url=callback_url,
                    submit_timeout=submit_timeout,
                    on_submitted=on_submitted,
                )
                return batch, dropped
            except APIError as exc:
                # Only handle the URL-blocked variant; anything else
                # is a real failure (auth, 5xx, etc.) and should
                # propagate.
                if exc.status_code != 400 or "URL blocked" not in exc.detail:
                    raise
                m = re.search(r"https?://[^\s'\"]+", exc.detail)
                if not m:
                    raise
                bad_url = m.group(0)
                # Find and remove the offending item; record it.
                new_remaining: list[Any] = []
                rejected_record: dict[str, Any] | None = None
                for it in remaining:
                    item_url = (
                        it if isinstance(it, str)
                        else it.url if isinstance(it, ScrapeRequest)
                        else it.get("url") if isinstance(it, dict)
                        else None
                    )
                    if rejected_record is None and item_url == bad_url:
                        rejected_record = (
                            {"url": it} if isinstance(it, str)
                            else it.model_dump(exclude_none=True) if isinstance(it, ScrapeRequest)
                            else dict(it)
                        )
                        rejected_record["__rejection_reason__"] = exc.detail
                    else:
                        new_remaining.append(it)
                if rejected_record is None:
                    # Couldn't pinpoint — bail out with the original error.
                    raise
                dropped.append(rejected_record)
                remaining = new_remaining
                if not remaining:
                    raise APIError(
                        400,
                        f"All {len(dropped)} URLs were blocked; nothing to submit. "
                        f"Last reason: {exc.detail}",
                    ) from exc

        # Hit the cap.
        raise APIError(
            400,
            f"submit_batch_lenient gave up after dropping {max_drops} URLs. "
            f"Inspect input items for systematic problems.",
        )

    def iter_results(
        self,
        collection_id: str,
        run_id: str,
        *,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        include_failed: bool = True,
        fetch_workers: int = 5,
    ) -> "Iterator[ScrapeResponse]":
        """Stream results of an existing run as jobs complete.

        Convenience shortcut for the common pattern::

            batch = client.get_batch(cid, rid)
            for r in batch.iter_results(...):
                ...

        Use this when you already have ``(collection_id, run_id)``
        from a previous :meth:`submit_batch` (e.g. persisted to disk
        for crash recovery) and just want to iterate without dealing
        with the :class:`Batch` handle. Equivalent to
        :meth:`Batch.iter_results`; see that method for the full
        parameter contract.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.
            poll_interval: Seconds between polls. Default 5.0.
            timeout: Overall timeout in seconds. None means no
                timeout.
            include_failed: If True (default), failed/timeout jobs are
                yielded with a synthesised :class:`ScrapeResponse` so
                you can handle them. Check ``r.guidance.success``.
            fetch_workers: Parallel threads to fetch job results
                per tick.

        Yields:
            :class:`ScrapeResponse` for each completed job.

        Example:
            >>> # Recover after a crash, persist had ids:
            >>> for r in client.iter_results(saved_cid, saved_rid):
            ...     if r.guidance.success:
            ...         save(r.custom_id, r.content)
        """
        batch = self.get_batch(collection_id, run_id, refresh=False)
        yield from batch.iter_results(
            poll_interval=poll_interval,
            timeout=timeout,
            include_failed=include_failed,
            fetch_workers=fetch_workers,
        )

    def find_recent_batch(
        self,
        *,
        name: str,
        since: "datetime | None" = None,
    ) -> "Batch | None":
        """Look up a batch by collection name; return ``None`` if not found.

        Designed for orphan recovery after a :class:`SubmitTimeout`: the
        collection may have been created server-side even though the
        SDK never received the response. Pass the **same** ``name``
        used in the failed :meth:`submit_batch` call.

        Today this method scans :meth:`list_collections` client-side
        and filters by exact name match. The ``since`` parameter is
        accepted for API compatibility once the server starts returning
        ``created_at`` on collections (currently ignored).

        .. note::
            Recovering the *run* requires a server endpoint that does
            not yet exist (``GET /collections/{id}/runs``). Until then
            this method returns ``None`` if no obvious run can be
            attached, even when the collection exists. You can still
            call :meth:`get_collection` and :meth:`create_run`
            manually to continue. Tracked as concern #5 in the SP API
            handoff.

        Args:
            name: Exact collection name to look up.
            since: Optional ``datetime`` filter — accepted for forward
                compatibility, currently no-op.

        Returns:
            A :class:`Batch` handle pointing at the recovered run, or
            ``None`` if no collection with that name was found.
        """
        cols = self.list_collections()
        matches = [c for c in cols if c.name == name]
        if not matches:
            return None
        # Take the most recent — without created_at, we use the *last*
        # entry the API returned (servers typically order by created_at desc).
        target = matches[-1]
        # We can find the collection but cannot list its runs (concern #5).
        # Surface a partial Batch so the caller can at least grab the
        # collection_id; documenting the limitation in the docstring.
        from scrapingpros.batch import Batch

        return Batch(
            self,
            collection_id=target.id,
            run_id="",  # unknown — caller should call create_run if needed
            name=target.name,
        )

    def batch_scrape(
        self,
        items: list[str] | list[ScrapeRequest | dict[str, Any]],
        *,
        name: str | None = None,
        callback_url: str | None = None,
    ) -> list["ScrapeResponse"]:
        """Scrape a list of URLs via the Collections API and return all results.

        Convenience wrapper around :meth:`submit_batch` +
        :meth:`Batch.iter_results` that blocks until every job is done
        and returns the full result list. Designed as a drop-in
        replacement for :meth:`scrape_many` when you want the same
        ergonomics but server-side scaling — same input shape, same
        output shape, but the server runs the batch on its async
        worker pool instead of forcing your machine to open
        ``max_concurrent`` simultaneous HTTP connections.

        Use this when:

        - You have more than a handful of URLs (~50+).
        - You want the server to control concurrency, refunds, retries
          and soft-block detection.
        - You want a simple ``list[ScrapeResponse]`` return value and
          you're OK blocking until the whole batch finishes.

        For very large batches (thousands+) prefer :meth:`submit_batch`
        directly so you can stream results as they finish (lower
        memory, live progress, ability to cancel mid-flight).

        Args:
            items: Same shape as :meth:`submit_batch` — list of URL
                strings, dicts, or :class:`ScrapeRequest` objects.
            name: Optional name for the underlying collection. A
                timestamped name is generated if omitted.
            callback_url: Optional webhook URL to receive a
                completion notification.

        Returns:
            List of :class:`ScrapeResponse`, in completion order.
            Pair each response with its input via
            :attr:`ScrapeResponse.custom_id`.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> results = client.batch_scrape([
            ...     {"url": u, "custom_id": product_id, "browser": True}
            ...     for product_id, u in catalog.items()
            ... ])  # doctest: +SKIP
            >>> for r in results:
            ...     if r.guidance and r.guidance.success:
            ...         save(r.custom_id, r.content)
        """
        from datetime import datetime as _dt

        batch_name = name or f"batch_scrape-{_dt.now().strftime('%Y%m%d-%H%M%S')}"
        batch = self.submit_batch(batch_name, items, callback_url=callback_url)
        return list(batch.iter_results())

    def get_batch(
        self,
        collection_id: str,
        run_id: str,
        *,
        name: str | None = None,
        refresh: bool = True,
    ) -> "Batch":
        """Reattach to an existing batch (e.g. after a client restart).

        Does not re-submit or re-start anything — it just constructs a
        :class:`Batch` handle pointing to the existing run. Iterate from
        there; already-processed jobs will be re-yielded unless you track
        them on your side (e.g. by ``custom_id`` in your database).

        Since v0.5.2, ``get_batch`` performs **one round-trip to refresh
        run stats** on construction so that ``batch.total``,
        ``batch.success_count``, ``batch.pct``, etc. are populated
        immediately. Pass ``refresh=False`` to skip the round-trip
        (useful when you're about to call :meth:`Batch.iter_results`
        anyway, since iteration triggers the same refresh on its first
        tick).

        Example:
            >>> # Earlier
            >>> batch = client.submit_batch("reviews", items)
            >>> save_to_db(batch.collection_id, batch.run_id)
            >>>
            >>> # Later (after a crash or restart)
            >>> batch = client.get_batch(col_id, run_id)  # doctest: +SKIP
            >>> print(batch.pct, batch.success_count, batch.total)
            >>> for result in batch.iter_results():
            ...     if result.custom_id not in already_saved_ids:
            ...         save(result)
        """
        from scrapingpros.batch import Batch

        batch = Batch(self, collection_id=collection_id, run_id=run_id, name=name)
        if refresh:
            batch.refresh()
        return batch

    # -----------------------------------------------------------------------
    # Viability test
    # -----------------------------------------------------------------------

    def create_viability_test(
        self,
        urls: list[str],
        *,
        depth: Literal["quick", "standard", "full"] = "full",
        actions: list[Action] | None = None,
    ) -> ViabilityRunPublic:
        """Submit URLs for viability analysis.

        Tests each URL with multiple scraping modes (simple, proxy, browser)
        to find what works. Early-exits when a mode succeeds to save credits.

        Args:
            urls: List of URLs to analyze.
            depth: How many modes to test.
                ``"quick"`` — simple HTTP only (1 credit/URL).
                ``"standard"`` — simple + proxy + browser (up to 7 credits/URL).
                ``"full"`` — all modes including browser+proxy (up to 12 credits/URL).
            actions: Optional browser actions to test.

        Returns:
            :class:`ViabilityRunPublic` with ``run_id``. Poll with
            :meth:`get_viability_test` for results.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> test = client.create_viability_test(
            ...     ["https://example.com", "https://hard-site.com"],
            ...     depth="standard",
            ... )  # doctest: +SKIP
        """
        body: dict[str, Any] = {"urls": urls, "depth": depth}
        if actions is not None:
            body["actions"] = [a.model_dump() for a in actions]
        resp = self._request("POST", "/v1/async/viability-test", json=body)
        return ViabilityRunPublic.model_validate(resp.json())

    def get_viability_test(self, run_id: str) -> ViabilityRunPublic:
        """Poll the status and results of a viability test.

        Args:
            run_id: The viability test run ID.

        Returns:
            :class:`ViabilityRunPublic` with ``results`` when completed.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> result = client.get_viability_test("vt-123")  # doctest: +SKIP
            >>> if result.status == "completed":
            ...     for r in result.results:
            ...         print(r.recommended_strategy)
        """
        resp = self._request("GET", f"/v1/async/viability-test/{run_id}")
        return ViabilityRunPublic.model_validate(resp.json())

    def get_job_result(
        self,
        collection_id: str,
        run_id: str,
        job_id: str,
    ) -> ScrapeResponse:
        """Get the full scrape result for a specific job.

        Returns the HTML/markdown, extracted data, screenshot, etc.
        Results are available for 24 hours after job completion.

        Args:
            collection_id: The collection UUID.
            run_id: The run UUID.
            job_id: The job UUID.

        Returns:
            :class:`ScrapeResponse` with the full scrape result.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> run = client.run_and_wait("col-123")  # doctest: +SKIP
            >>> for job_id in run.job_ids:
            ...     result = client.get_job_result("col-123", run.run_id, job_id)
            ...     print(result.content)
        """
        resp = self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs/{job_id}/result",
        )
        return ScrapeResponse.model_validate(resp.json())

    def delete_collection(self, collection_id: str) -> None:
        """Delete a collection and its associated jobs.

        Runs that were already executed are not affected.

        Args:
            collection_id: The collection UUID.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> client.delete_collection("col-123")  # doctest: +SKIP
        """
        self._request("DELETE", f"/v1/async/collections/{collection_id}")

    # -----------------------------------------------------------------------
    # Proxy
    # -----------------------------------------------------------------------

    def list_proxy_countries(self) -> ProxyCountriesResponse:
        """List all 200+ countries available for geo-targeted scraping.

        Returns:
            :class:`ProxyCountriesResponse` with ISO country codes.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> resp = client.list_proxy_countries()  # doctest: +SKIP
            >>> print(resp.countries[:5])
            ['AD', 'AE', 'AF', 'AG', 'AI']
        """
        resp = self._request("GET", "/v1/proxy/countries")
        return ProxyCountriesResponse.model_validate(resp.json())

    def request_proxy_country(
        self,
        country_code: str,
        *,
        reason: str = "",
    ) -> ProxyRequestCountryResponse:
        """Request access to a country-specific proxy.

        Access requires admin approval. Once approved, use
        ``use_proxy="XX"`` in scrape calls.

        Args:
            country_code: ISO country code (e.g. ``"US"``, ``"BR"``).
            reason: Why you need this country's proxies.

        Returns:
            :class:`ProxyRequestCountryResponse` with approval status.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> resp = client.request_proxy_country("US", reason="Need US pricing")  # doctest: +SKIP
            >>> print(resp.status)  # "pending" or "already_approved"
        """
        resp = self._request(
            "POST",
            "/v1/proxy/request-country",
            json={"country_code": country_code, "reason": reason},
        )
        return ProxyRequestCountryResponse.model_validate(resp.json())

    def proxy_status(self) -> ProxyStatusResponse:
        """Check your country proxy approvals.

        Returns:
            :class:`ProxyStatusResponse` with approved and pending countries.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> status = client.proxy_status()  # doctest: +SKIP
            >>> print(status.approved_countries)
        """
        resp = self._request("GET", "/v1/proxy/status")
        return ProxyStatusResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Plans
    # -----------------------------------------------------------------------

    def plans(self) -> Any:
        """List all available plans with pricing, credits, and features.

        Public endpoint — no authentication required.

        **Credit system:** 1 simple request = 1 credit,
        1 browser request = 5 credits. Anti-bot protection and proxy
        rotation are included at no extra cost. Credits are NOT consumed
        for requests that fail due to infrastructure errors.

        Returns:
            API response with plan details.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> plans = client.plans()  # doctest: +SKIP
        """
        resp = self._request("GET", "/v1/plans")
        return resp.json()

    # -----------------------------------------------------------------------
    # Billing & Metrics
    # -----------------------------------------------------------------------

    def billing(self, *, month: str = "", detail: str = "") -> BillingResponse:
        """Get billing summary for the current or specified month.

        Args:
            month: Month in ``YYYY-MM`` format. Defaults to current month.
            detail: Pass ``"urls"`` for per-domain breakdown.

        Returns:
            :class:`BillingResponse` with request counts, credits, and breakdown.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> bill = client.billing(month="2026-04")  # doctest: +SKIP
            >>> print(bill.month)
        """
        params: dict[str, str] = {}
        if month:
            params["month"] = month
        if detail:
            params["detail"] = detail
        resp = self._request("GET", "/v1/sync/billing", params=params)
        return BillingResponse.model_validate(resp.json())

    def metrics(self, *, date: str = "", metric: str = "") -> Any:
        """Get API metrics (admin-level view).

        Args:
            date: ``YYYY-MM-DD`` or ``YYYY-MM-DD:YYYY-MM-DD`` range.
            metric: Filter — ``url``, ``proxy``, ``api_codes``, etc.

        Returns:
            API response with metrics data.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> m = client.metrics(date="2026-04-01")  # doctest: +SKIP
        """
        params: dict[str, str] = {}
        if date:
            params["date"] = date
        if metric:
            params["metric"] = metric
        resp = self._request("GET", "/v1/sync/metrics", params=params)
        return resp.json()

    def client_metrics(
        self,
        *,
        date: str = "",
        hourly: bool = False,
        detail: str = "",
    ) -> ClientMetricsResponse:
        """Get your usage metrics.

        Args:
            date: ``YYYY-MM-DD``, ``YYYY-MM-DD:YYYY-MM-DD``, or ``YYYY-MM``.
            hourly: Include per-hour breakdown (single-day only).
            detail: Pass ``"urls"`` for per-domain breakdown.

        Returns:
            :class:`ClientMetricsResponse` with usage data.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> m = client.client_metrics(date="2026-04")  # doctest: +SKIP
        """
        params: dict[str, Any] = {}
        if date:
            params["date"] = date
        if hourly:
            params["hourly"] = "true"
        if detail:
            params["detail"] = detail
        resp = self._request("GET", "/v1/sync/client-metrics", params=params)
        return ClientMetricsResponse.model_validate(resp.json())

    # -----------------------------------------------------------------------
    # Health
    # -----------------------------------------------------------------------

    def health(self) -> Any:
        """Check API health status (no auth required).

        Returns:
            API response with health status.

        Example:
            >>> client = ScrapingPros("your_token")
            >>> h = client.health()  # doctest: +SKIP
        """
        resp = self._request("GET", "/v1/health")
        return resp.json()
