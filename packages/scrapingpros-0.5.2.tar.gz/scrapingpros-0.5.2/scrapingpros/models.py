"""Pydantic v2 models for the Scraping Pros API.

All models match the OpenAPI spec at ``/openapi.json`` exactly.
Field names use the same casing as the API (camelCase where the API
uses it) so serialization round-trips cleanly.

Example:
    >>> from scrapingpros.models import ScrapeRequest
    >>> req = ScrapeRequest(url="https://example.com", format="markdown")
    >>> req.model_dump(exclude_none=True)
    {'url': 'https://example.com', 'format': 'markdown'}
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Union

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

class ClickAction(BaseModel):
    """Click an element on the page.

    Example:
        >>> action = ClickAction(selector="css:button.submit")
        >>> action.type
        'click'
    """

    type: Literal["click"] = "click"
    selector: str
    wait_for_navigation: bool = False
    optional: bool = False


class InputAction(BaseModel):
    """Type text into a form field.

    Example:
        >>> action = InputAction(selector="css:#search", text="python")
        >>> action.type
        'input'
    """

    type: Literal["input"] = "input"
    selector: str
    text: str


class SelectAction(BaseModel):
    """Select an option from a dropdown.

    Example:
        >>> action = SelectAction(selector="css:#country", value="US")
        >>> action.type
        'select'
    """

    type: Literal["select"] = "select"
    selector: str
    value: str


class KeyPressAction(BaseModel):
    """Press a keyboard key.

    Example:
        >>> action = KeyPressAction(key="Enter")
        >>> action.type
        'key-press'
    """

    type: Literal["key-press"] = "key-press"
    key: str


class WaitForSelectorAction(BaseModel):
    """Wait for an element to appear on the page.

    The ``state`` parameter controls what the wait considers a match:

    - ``"visible"`` (server default when ``state=None``) — element must
      be in the DOM and rendered (non-zero size, ``display`` not
      ``none``). Use for buttons, prices, results panels.
    - ``"attached"`` — element only needs to be in the DOM. Use for
      ``<script>`` tags (e.g. ``css:script#__NEXT_DATA__``) or other
      hidden nodes that ``"visible"`` never matches.
    - ``"hidden"`` — wait until the element is **not** visible. Useful
      after dismissing a loader / modal.

    Leave ``state=None`` for the default behaviour. Pass an explicit
    value when scraping JSON blobs from ``<script>`` tags or coordinating
    with overlays.

    Example:
        >>> action = WaitForSelectorAction(selector="css:.results", time=5000)
        >>> action.type
        'wait-for-selector'

        >>> # Wait for a hidden <script> tag with embedded JSON
        >>> action = WaitForSelectorAction(
        ...     selector="css:script#__NEXT_DATA__",
        ...     time=8000,
        ...     state="attached",
        ... )
        >>> action.state
        'attached'
    """

    type: Literal["wait-for-selector"] = "wait-for-selector"
    selector: str
    time: int
    state: Literal["visible", "attached", "hidden"] | None = None


class WaitForTimeoutAction(BaseModel):
    """Wait a fixed number of milliseconds.

    Example:
        >>> action = WaitForTimeoutAction(time=2000)
        >>> action.type
        'wait-for-timeout'
    """

    type: Literal["wait-for-timeout"] = "wait-for-timeout"
    time: int


class EvaluateAction(BaseModel):
    """Execute JavaScript in the browser page context.

    Example:
        >>> action = EvaluateAction(script="document.title")
        >>> action.type
        'evaluate'
    """

    type: Literal["evaluate"] = "evaluate"
    script: str
    timeout: int | None = 30000


class CollectAction(BaseModel):
    """Extract data from the current page during a while loop.

    The ``extract`` dict uses the same format as the top-level
    ``extract`` parameter on :class:`ScrapeRequest`.

    Example:
        >>> action = CollectAction(extract={"titles": {"selector": "css:h2", "multiple": True}})
        >>> action.type
        'collect'
    """

    type: Literal["collect"] = "collect"
    extract: dict[str, str | dict[str, Any]]


# ---------------------------------------------------------------------------
# Conditions (for While loops)
# ---------------------------------------------------------------------------

class SelectorVisibleCondition(BaseModel):
    """Condition: loop while a CSS selector is visible.

    Example:
        >>> cond = SelectorVisibleCondition(selector="css:.next-page")
        >>> cond.type
        'selector-visible'
    """

    type: Literal["selector-visible"] = "selector-visible"
    selector: str


class SelectorInvisibleCondition(BaseModel):
    """Condition: loop while a CSS selector is not visible.

    Example:
        >>> cond = SelectorInvisibleCondition(selector="css:.loading")
        >>> cond.type
        'selector-invisible'
    """

    type: Literal["selector-invisible"] = "selector-invisible"
    selector: str


WhileCondition = Union[SelectorVisibleCondition, SelectorInvisibleCondition]

InnerAction = Union[
    ClickAction,
    InputAction,
    SelectAction,
    KeyPressAction,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    EvaluateAction,
    CollectAction,
]


class WhileControl(BaseModel):
    """Loop that performs actions while a condition is met.

    Example:
        >>> loop = WhileControl(
        ...     condition=SelectorVisibleCondition(selector="css:.next"),
        ...     actions=[ClickAction(selector="css:.next", wait_for_navigation=True)],
        ...     max_iterations=10,
        ... )
        >>> loop.type
        'while'
    """

    type: Literal["while"] = "while"
    condition: WhileCondition
    actions: list[InnerAction]
    max_iterations: int = 20


Action = Union[
    WhileControl,
    ClickAction,
    InputAction,
    SelectAction,
    KeyPressAction,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    EvaluateAction,
    CollectAction,
]


# ---------------------------------------------------------------------------
# HTTP Method
# ---------------------------------------------------------------------------

class MethodGET(BaseModel):
    """HTTP GET method for ``http_method`` parameter.

    Example:
        >>> m = MethodGET()
        >>> m.method
        'get'
    """

    method: Literal["get"] = "get"


class MethodPOST(BaseModel):
    """HTTP POST method with optional payload.

    By default the POST is sent to the same URL as the scrape request.
    Set ``url`` to POST to a different endpoint (e.g. an internal API,
    GraphQL endpoint, or auth flow) while still using the scrape ``url``
    as the navigation target.

    The ``content_type`` parameter controls how ``payload`` is encoded
    in the request body:

    - ``"json"`` (default if omitted) — body sent as
      ``application/json``.
    - ``"form"`` — body sent as ``application/x-www-form-urlencoded``.
      Required by OAuth2 ``grant_type=client_credentials`` flows and
      most legacy form-based APIs.

    Example:
        >>> m = MethodPOST(payload={"key": "value"})
        >>> m.method
        'post'

        >>> # POST to a different URL than the navigation target
        >>> m = MethodPOST(url="https://api.example.com/graphql", payload={"query": "..."})
        >>> m.url
        'https://api.example.com/graphql'

        >>> # OAuth2 client_credentials (form-encoded)
        >>> m = MethodPOST(
        ...     payload={"grant_type": "client_credentials", "scope": "read"},
        ...     content_type="form",
        ... )
        >>> m.content_type
        'form'
    """

    method: Literal["post"] = "post"
    payload: dict[str, Any] | list[Any] | None = None
    url: str | None = None
    content_type: Literal["json", "form"] | None = None

    @field_validator("url")
    @classmethod
    def _validate_post_url(cls, v: str | None) -> str | None:
        if v is None:
            return v
        v = v.strip()
        if not v:
            return None
        if not v.startswith(("http://", "https://")):
            raise ValueError("MethodPOST.url must start with http:// or https://")
        return v


HttpMethod = Union[MethodGET, MethodPOST]


# ---------------------------------------------------------------------------
# Proxy
# ---------------------------------------------------------------------------

class ProxyConfig(BaseModel):
    """Advanced proxy configuration with retry settings.

    For simple usage, pass a string like ``"any"`` or ``"US"``
    directly to the ``use_proxy`` parameter instead.

    Example:
        >>> cfg = ProxyConfig(proxy="US", max_retries=5)
        >>> cfg.proxy
        'US'
    """

    proxy: str = "any"
    max_retries: int = 3
    delay_seconds: int = 1
    backoff_factor: int = 2


UseProxy = Union[ProxyConfig, str, None]
"""Type for the ``use_proxy`` parameter.

- ``None`` — no proxy (default)
- ``"any"`` — automatic proxy rotation
- ``"US"`` — country-specific proxy (requires approval)
- :class:`ProxyConfig` — advanced proxy with retry settings
"""


# ---------------------------------------------------------------------------
# Network Capture
# ---------------------------------------------------------------------------

class NetworkCaptureConfig(BaseModel):
    """Configuration for capturing network requests during browser scrape.

    Requires ``browser=True``.

    The basic capture (``resource_types`` + ``listen_after_load_ms``)
    records request URL, method, status and content type for every
    request the page makes. To also capture **response bodies** for
    matching URLs, set ``url_pattern`` to a glob — useful for
    extracting tokens from auth flows (Firebase ``identitytoolkit``,
    OAuth) or payloads from GraphQL / Apollo ``persistedQuery`` calls
    without having to re-execute them yourself.

    When a request URL matches ``url_pattern``, the corresponding entry
    in ``ScrapeResponse.network_requests`` gains:

    - ``body``: response body as a string (utf-8) or base64-encoded
      bytes. Capped at **64 KB** by the server.
    - ``body_truncated``: ``True`` if the response was larger than 64 KB
      and only the first chunk was kept.
    - ``body_error``: optional string with the reason a body could not
      be captured (e.g. ``"global_timeout_5s"`` if the body fetch took
      more than 5 s, ``"response_disposed"`` if the page navigated
      away before the body could be read). Body fetch never hangs the
      scrape — at worst you get ``body_error`` and no ``body`` field.

    Validated end-to-end on light and heavy browsers since the server-
    side rollout on 2026-04-29.

    Example:
        >>> cfg = NetworkCaptureConfig(resource_types=["xhr", "fetch"])
        >>> cfg.resource_types
        ['xhr', 'fetch']

        >>> # Capture the body of any Firebase identitytoolkit call
        >>> cfg = NetworkCaptureConfig(
        ...     resource_types=["xhr", "fetch"],
        ...     url_pattern="*identitytoolkit.googleapis.com*",
        ... )
        >>> cfg.url_pattern
        '*identitytoolkit.googleapis.com*'
    """

    resource_types: list[str] | None = None
    listen_after_load_ms: int | None = None
    url_pattern: str | None = None
    """Glob pattern (server-side ``fnmatch``) to select which responses
    to capture bodies for. ``None`` (default) keeps the legacy behaviour
    of metadata-only capture.

    Single pattern only; if you need multiple endpoints, use a broader
    glob (``*api*``) and filter client-side. Bodies are capped at 64 KB
    and body fetch has a 5 s global timeout — see the class docstring
    for the full contract on the ``body`` / ``body_truncated`` /
    ``body_error`` fields that appear on each matching entry."""


# ---------------------------------------------------------------------------
# Scrape Request / Response
# ---------------------------------------------------------------------------

class ScrapeRequest(BaseModel):
    """Request model for ``POST /v1/sync/scrape``.

    Example:
        >>> req = ScrapeRequest(url="https://example.com", format="markdown", browser=True)
        >>> req.model_dump(exclude_none=True)
        {'url': 'https://example.com', 'format': 'markdown', 'browser': True}

        >>> # Auto-prepends https:// if missing
        >>> req = ScrapeRequest(url="example.com")
        >>> req.url
        'https://example.com'
    """

    url: str

    @field_validator("url")
    @classmethod
    def _validate_url(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("URL cannot be empty")
        if not v.startswith(("http://", "https://")):
            v = f"https://{v}"
        return v
    format: Literal["html", "markdown"] = "html"
    browser: bool = False
    browser_type: Literal["light", "heavy", "stealth"] = "light"
    """The browser engine to use. **Soft-deprecated since v0.5.0.**

    The recommended interface is ``browser=True`` / ``browser=False``
    (1 vs 5 credits) and let the server route internally based on the
    target domain's profile. ``browser_type`` is kept for backwards
    compatibility but the server may ignore it in favour of profile
    routing. New code should omit this parameter; a future major
    release will emit a ``DeprecationWarning`` and eventually remove
    the field."""
    use_proxy: UseProxy = None
    screenshot: bool = False
    actions: list[Action] | None = None
    language: str = ""
    http_method: HttpMethod | None = None
    headers: dict[str, str] | None = None
    window_size: str = ""
    cookies: dict[str, Any] | None = None
    extract: dict[str, str | dict[str, Any]] | None = None
    network_capture: NetworkCaptureConfig | None = None
    retry_on_block: bool = False
    block_resources: list[str] | None = None
    block_requests: list[str] | None = None
    custom_id: str | None = None


class ScrapeGuidance(BaseModel):
    """Guidance included in every scrape response.

    Tells you why a request failed, what to do next, and when to stop.

    Example:
        >>> g = ScrapeGuidance(success=True)
        >>> g.success
        True
        >>> g = ScrapeGuidance(
        ...     success=False, error_type="captcha", error_provider="cloudflare",
        ...     next_steps=["Try with browser=true"],
        ...     suggested_request={"url": "https://x.com", "browser": True},
        ... )
        >>> g.error_type
        'captcha'
    """

    success: bool = False
    error_type: str | None = None
    error_provider: str | None = None
    credits_charged: int | None = None
    credits_refunded: bool | None = None
    next_steps: list[str] = Field(default_factory=list)
    suggested_request: dict[str, Any] | None = None
    stop_reason: str | None = None


class ScrapeResponse(BaseModel):
    """Response model for ``POST /v1/sync/scrape``.

    When ``format="html"``, the ``html`` field contains raw HTML and
    ``markdown`` is ``None``. When ``format="markdown"``, it is reversed.

    The **canonical path for the verdict** (success/failure, error
    type, suggested next steps, etc.) is :attr:`guidance` — see
    :class:`ScrapeGuidance` for the full contract. Read
    ``resp.guidance.success`` instead of any legacy top-level flag;
    the API does not duplicate verdict fields at the top level of the
    response, only inside ``guidance``.

    Example:
        >>> resp = ScrapeResponse(message="OK", html="<h1>Hello</h1>", statusCode=200)
        >>> resp.statusCode
        200
    """

    url: str | None = None
    custom_id: str | None = None
    html: str | None = None
    markdown: str | None = None
    statusCode: int | None = None
    message: str
    screenshot: str | None = None
    executionTime: float | None = None
    extracted_data: dict[str, Any] | None = None
    evaluate_results: list[Any] | None = None
    network_requests: list[dict[str, Any]] | None = None
    potentiallyBlockedByCaptcha: bool | None = None
    """Legacy block flag. **Soft-deprecated since v0.5.0** —
    prefer :attr:`guidance` / ``resp.guidance.success`` for the
    authoritative verdict. ``guidance`` also tells you why the request
    failed and what to try next (``error_type``, ``error_provider``,
    ``next_steps``, ``suggested_request``), which this boolean cannot.
    Kept for backwards compatibility; a future major release may
    remove it."""
    timings: dict[str, Any] | None = None
    guidance: ScrapeGuidance | None = None
    """Canonical verdict object for the scrape. Always populated.

    Read from this instead of inferring success from
    :attr:`statusCode` or :attr:`potentiallyBlockedByCaptcha`:

        >>> resp = client.scrape("https://example.com")
        >>> if resp.guidance.success:
        ...     process(resp.content)
        ... else:
        ...     log(resp.guidance.error_type, resp.guidance.next_steps)

    See :class:`ScrapeGuidance` for the full set of fields."""

    @property
    def content(self) -> str | None:
        """The page content — returns markdown if available, otherwise html.

        This is a convenience property so you don't need to check which
        format was requested.

        Example:
            >>> resp = ScrapeResponse(message="OK", markdown="# Hello")
            >>> resp.content
            '# Hello'
            >>> resp = ScrapeResponse(message="OK", html="<h1>Hello</h1>")
            >>> resp.content
            '<h1>Hello</h1>'
        """
        return self.markdown if self.markdown is not None else self.html


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

class DownloadRequest(BaseModel):
    """Request model for ``POST /v1/sync/download``.

    Example:
        >>> req = DownloadRequest(url="https://example.com/file.pdf")
        >>> req.url
        'https://example.com/file.pdf'
    """

    url: str

    @field_validator("url")
    @classmethod
    def _validate_url(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("URL cannot be empty")
        if not v.startswith(("http://", "https://")):
            v = f"https://{v}"
        return v
    use_proxy: UseProxy = None


class DownloadResponse(BaseModel):
    """Response model for ``POST /v1/sync/download``.

    The ``content`` field contains the file as a base64-encoded string.

    Example:
        >>> resp = DownloadResponse(statusCode=200, message="OK", contentType="application/pdf")
        >>> resp.contentType
        'application/pdf'
    """

    content: str | None = None
    contentType: str | None = None
    statusCode: int
    message: str
    executionTime: float | None = None


# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------

class CollectionPublic(BaseModel):
    """A scraping collection (list of URLs to process as a batch).

    Example:
        >>> col = CollectionPublic(id="abc-123", name="my-batch")
        >>> col.name
        'my-batch'
    """

    id: str
    name: str


class NewCollectionResponse(BaseModel):
    """Response after creating or updating a collection.

    Example:
        >>> resp = NewCollectionResponse(id="abc", name="batch", message="Created")
        >>> resp.message
        'Created'
    """

    id: str | None = None
    name: str | None = None
    message: str
    duplicates_skipped: int = 0


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------

class FailedJobPublic(BaseModel):
    """Details about a failed job in a run.

    Example:
        >>> job = FailedJobPublic(job_id="j1", url="https://fail.com", status="failed")
        >>> job.status
        'failed'
    """

    job_id: str
    url: str
    error: str | None = None
    status: str


class SuccessCriterion(BaseModel):
    """The policy the server uses to classify jobs as success/failure.

    Exposed on each :class:`RunPublic` so clients can pin the policy
    version in tests and detect silent changes.

    Example:
        >>> crit = SuccessCriterion(version="content_success_v1",
        ...     rules=["status == 'completed'", "200 <= status_code < 300"])
        >>> crit.version
        'content_success_v1'
    """

    version: str
    """Stable identifier of the active policy, e.g. ``"content_success_v1"``."""
    rules: list[str] = Field(default_factory=list)
    """Human-readable rules describing the criterion."""


class RunPublic(BaseModel):
    """Status and results of an async batch run.

    Example:
        >>> run = RunPublic(run_id="r1", collection_id="c1", status="completed")
        >>> run.status
        'completed'
    """

    run_id: str
    status: str = "in_progress"
    total_requests: int = 0
    success_requests: int = 0
    failed_requests: int = 0
    timeout_requests: int = 0
    collection_id: str
    failed_jobs: list[FailedJobPublic] = Field(default_factory=list)
    job_ids: list[str] = Field(default_factory=list)
    callback_url: str | None = None
    callback_status: str | None = None
    success_criterion: SuccessCriterion | None = None
    """The server-side policy used to classify jobs as success/failure.

    Pin the version in your tests to detect silent policy changes:

        >>> run = client.get_run(cid, rid)
        >>> assert run.success_criterion.version == "content_success_v1"

    ``None`` for runs created before the 2026-04-24 migration.
    """


class JobExecutionPublic(BaseModel):
    """Detailed execution info for a single job in a run.

    Includes the original URL and ``custom_id`` for traceability so you
    can map results back to your data without depending on list order.

    Example:
        >>> job = JobExecutionPublic(
        ...     job_public_id="j1", run_public_id="r1",
        ...     collection_id="c1", status="completed",
        ... )
        >>> job.status
        'completed'
    """

    job_public_id: str
    run_public_id: str
    collection_id: str
    client_id: str | None = None
    """The client that owns this job. Set on every job since v0.5.0."""
    status: Literal["processing", "completed", "failed", "timeout"]
    status_code: int | None = None
    message: str | None = None
    url: str | None = None
    custom_id: str | None = None
    queued_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    execution_time_ms: int | None = None
    retries_attempted: int | None = None
    block_reason: str | None = None
    url_truncated: bool = False
    protection_stack: list[str] = Field(default_factory=list)
    rule_hits: list[str] = Field(default_factory=list)
    validator_version: str | None = None
    """Version of the HTML Validator that produced ``is_success``,
    ``block_reason``, ``protection_stack`` and ``rule_hits`` on this job.

    Pin this in tests to detect silent classifier upgrades:

        >>> assert job.validator_version == "0.1.6"

    ``None`` for jobs created before the 2026-04-29 migration (Track B).
    """
    has_extractable_data: bool | None = None
    """Whether the page contained structured data the server could
    extract (JSON-LD, microdata, OpenGraph, ``__NEXT_DATA__``, etc.).

    Independent of ``is_success`` — a page can return 200 with usable
    content (``is_success=True``) but lack structured data
    (``has_extractable_data=False``), e.g. a plain article. Use this
    when you specifically need machine-parseable payloads.

    Values:
        - ``True``: structured data found.
        - ``False``: no structured data.
        - ``None``: not computed yet (jobs created before the
          2026-04-29 migration). Populated for all new jobs.
    """
    is_success: bool | None = None
    """Server-side verdict of whether this job returned usable content.

    Computed by the server using the active ``success_criterion`` of the
    run (see :class:`RunPublic.success_criterion`). The invariant
    ``sum(is_success == True) == run.success_requests`` holds by
    construction.

    Values:
        - ``True``: job produced usable content (2xx + no captcha/block).
        - ``False``: completed but not usable (4xx/5xx, captcha, block),
          or the worker failed / timed out.
        - ``None``: verdict not computed. This happens for jobs created
          before the 2026-04-24 migration. For new jobs it is always
          set to ``True`` or ``False``. The SDK's ``Batch`` class falls
          back to a client-side heuristic when this is ``None``.
    """

    @property
    def execution_time_sec(self) -> float | None:
        """Execution time in seconds.

        .. deprecated::
            Use :attr:`execution_time_ms` instead. This property is kept
            for backward compatibility and computes the value from
            ``execution_time_ms`` divided by 1000.
        """
        if self.execution_time_ms is None:
            return None
        return self.execution_time_ms / 1000.0


class JobExecutionListPublic(BaseModel):
    """List of job executions for a run, with cursor pagination.

    The API paginates results — use ``cursor_next`` to fetch the next
    page when ``has_more`` is ``True``. The SDK's
    :meth:`ScrapingPros.get_run_jobs` does this automatically; use
    :meth:`ScrapingPros.iter_run_jobs` for memory-efficient iteration
    over very large runs.

    Example:
        >>> lst = JobExecutionListPublic(items=[])
        >>> len(lst.items)
        0
        >>> lst.has_more
        False
    """

    items: list[JobExecutionPublic]
    cursor_next: str | None = None
    has_more: bool = False


# ---------------------------------------------------------------------------
# Viability Test
# ---------------------------------------------------------------------------

class ViabilityTestRequest(BaseModel):
    """Request model for ``POST /v1/async/viability-test``.

    Example:
        >>> req = ViabilityTestRequest(urls=["https://example.com"], depth="full")
        >>> req.depth
        'full'
    """

    urls: list[str]
    depth: Literal["quick", "standard", "full"] = "full"
    actions: list[Action] | None = None


class ViabilityModeResult(BaseModel):
    """Result of testing a single scraping mode on a URL.

    Keyed by mode name in the ``modes_tested`` dict (e.g. ``"simple"``,
    ``"browser_proxy"``).

    Example:
        >>> m = ViabilityModeResult(success=True, time_ms=2500, credits=5)
        >>> m.success
        True
    """

    success: bool = False
    blocked: bool = False
    captcha_type: str | None = None
    time_ms: int | None = None
    credits: int = 0
    error: str | None = None


class UrlViabilityResult(BaseModel):
    """Analysis result for a single URL from a viability test.

    Example:
        >>> r = UrlViabilityResult(
        ...     url="https://example.com", captcha_detected=False,
        ...     captcha_providers=[], javascript_detected=False,
        ...     javascript_required=False, browser_confidence=0.1,
        ...     content_type="text/html", rate_limited=False,
        ...     soft_block=False, retry_after=None, login_wall=False,
        ...     status_code=200, redirect_chain=[], protection_signals={},
        ...     api_detected=False, api_endpoints=[], graphql_detected=False,
        ...     api_auth_required=False, cloudflare_level="none",
        ...     can_use_simple_request=True, can_use_extract_html=True,
        ...     can_use_browser=True, recommended_strategy="simple",
        ...     proxy_recommended=False, proxy_type="none",
        ... )
        >>> r.recommended_strategy
        'simple'
    """

    url: str
    captcha_detected: bool
    captcha_providers: list[str]
    javascript_detected: bool
    javascript_required: bool
    browser_confidence: float
    content_type: str
    rate_limited: bool
    soft_block: bool
    retry_after: int | None
    login_wall: bool
    status_code: int
    redirect_chain: list[str]
    protection_signals: dict[str, str]
    api_detected: bool
    api_endpoints: list[str]
    graphql_detected: bool
    api_auth_required: bool
    cloudflare_level: str
    can_use_simple_request: bool
    can_use_extract_html: bool
    can_use_browser: bool
    recommended_strategy: str
    suggested_action: str | None = None
    blocked_by: list[str] | None = None
    difficulty: Literal["easy", "medium", "hard"] | None = None
    suggested_params: dict[str, Any] | None = None
    proxy_recommended: bool
    proxy_type: str
    modes_tested: dict[str, ViabilityModeResult] | None = None
    best_mode: str | None = None
    total_credits_used: int | None = None


class ViabilityRunPublic(BaseModel):
    """Status and results of a viability test run.

    Example:
        >>> run = ViabilityRunPublic(run_id="v1", status="completed", total_urls=1)
        >>> run.status
        'completed'
    """

    run_id: str
    status: str
    total_urls: int
    completed_urls: int = 0
    depth: str | None = None
    results: list[UrlViabilityResult] | None = None


# ---------------------------------------------------------------------------
# Proxy Endpoints
# ---------------------------------------------------------------------------

class CountryRequest(BaseModel):
    """Request model for ``POST /v1/proxy/request-country``.

    Example:
        >>> req = CountryRequest(country_code="US", reason="Need US pricing")
        >>> req.country_code
        'US'
    """

    country_code: str
    reason: str = ""


# ---------------------------------------------------------------------------
# Proxy Responses (typed)
# ---------------------------------------------------------------------------

class ProxyCountriesResponse(BaseModel):
    """Response from ``GET /v1/proxy/countries``.

    Example:
        >>> resp = ProxyCountriesResponse(countries=["US", "BR", "AR"])
        >>> "US" in resp.countries
        True
    """

    countries: list[str]
    error: str | None = None


class ProxyRequestCountryResponse(BaseModel):
    """Response from ``POST /v1/proxy/request-country``.

    Example:
        >>> resp = ProxyRequestCountryResponse(status="pending", country_code="US", message="Request submitted")
        >>> resp.status
        'pending'
    """

    status: str
    country_code: str
    message: str


class ProxyStatusResponse(BaseModel):
    """Response from ``GET /v1/proxy/status``.

    Example:
        >>> resp = ProxyStatusResponse(client_id="c1", approved_countries=["US"], pending_countries=["BR"])
        >>> "US" in resp.approved_countries
        True
    """

    client_id: str
    approved_countries: list[str]
    pending_countries: list[str]
    error: str | None = None


# ---------------------------------------------------------------------------
# Billing & Metrics Responses (typed)
# ---------------------------------------------------------------------------

class BillingCredits(BaseModel):
    """Credit breakdown in a billing response.

    Example:
        >>> c = BillingCredits(simple=100, browser=50, total=350)
        >>> c.total
        350
    """

    simple: int = 0
    browser: int = 0
    total: int = 0


class BillingClientData(BaseModel):
    """Billing data for a single client.

    Example:
        >>> d = BillingClientData(total_requests=10, total_success=9)
        >>> d.total_success
        9
    """

    simple_success: int = 0
    simple_failed: int = 0
    simple_total: int = 0
    browser_success: int = 0
    browser_failed: int = 0
    browser_total: int = 0
    total_requests: int = 0
    total_success: int = 0
    total_failed: int = 0
    credits: BillingCredits | None = None
    by_url: dict[str, Any] | None = None


class CreditSystemInfo(BaseModel):
    """Credit multipliers for request types.

    Example:
        >>> info = CreditSystemInfo(simple_request=1, browser_request=5)
        >>> info.browser_request
        5
    """

    simple_request: int = 1
    browser_request: int = 5


class BillingResponse(BaseModel):
    """Response from ``GET /v1/sync/billing``.

    Example:
        >>> resp = BillingResponse(month="2026-04", clients={}, credit_system=CreditSystemInfo())
        >>> resp.month
        '2026-04'
    """

    month: str
    clients: dict[str, BillingClientData]
    credit_system: CreditSystemInfo


class ClientMetricsResponse(BaseModel):
    """Response from ``GET /v1/sync/client-metrics``.

    Example:
        >>> resp = ClientMetricsResponse()
        >>> resp.date is None
        True
    """

    date: str | None = None
    scrape_type: dict[str, Any] | None = None
    url: dict[str, Any] | None = None
    hourly: dict[str, Any] | None = None
