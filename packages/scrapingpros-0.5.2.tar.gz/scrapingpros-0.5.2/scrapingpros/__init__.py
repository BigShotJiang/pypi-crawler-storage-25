"""Scraping Pros Python SDK.

Example:
    >>> from scrapingpros import ScrapingPros
    >>> client = ScrapingPros("your_token")
    >>> result = client.scrape("https://example.com")
    >>> print(result.html[:50])  # doctest: +SKIP
    '<!doctype html>...'
"""

from scrapingpros._base import DEMO_TOKEN
from scrapingpros._version import __version__
from scrapingpros.async_client import AsyncScrapingPros
from scrapingpros.batch import AsyncBatch, Batch
from scrapingpros.client import ScrapingPros

class SyncClient(ScrapingPros):
    """Preferred name for the synchronous SDK client (v0.5.1+).

    Same public surface as :class:`ScrapingPros` — they're literally
    the same class behaviour, only the import name changes.

    The rename clarifies what the two client classes really differ on:
    the **local I/O loop** (this one wraps :class:`httpx.Client`,
    :class:`AsyncClient` wraps :class:`httpx.AsyncClient`). Both can
    call **every** endpoint, sync (``/v1/sync/scrape``) and Collections
    (``/v1/async/collections``). The old names — :class:`ScrapingPros`
    and :class:`AsyncScrapingPros` — suggested otherwise and are
    deprecated; they will be removed in v1.0.
    """

    pass


class AsyncClient(AsyncScrapingPros):
    """Preferred name for the asynchronous SDK client (v0.5.1+).

    Same public surface as :class:`AsyncScrapingPros`. See
    :class:`SyncClient` for the rationale behind the rename.
    """

    pass
from scrapingpros.exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    CountryProxyNotApproved,
    QuotaExceededError,
    RateLimitError,
    ScrapingProsError,
    SubmitTimeout,
    TimeoutError,
    URLBlockedError,
    ValidationError,
)
from scrapingpros.models import (
    Action,
    BillingClientData,
    BillingCredits,
    BillingResponse,
    ClickAction,
    ClientMetricsResponse,
    CollectAction,
    CollectionPublic,
    CountryRequest,
    CreditSystemInfo,
    ProxyCountriesResponse,
    ProxyRequestCountryResponse,
    ProxyStatusResponse,
    DownloadRequest,
    DownloadResponse,
    EvaluateAction,
    FailedJobPublic,
    InputAction,
    JobExecutionListPublic,
    JobExecutionPublic,
    KeyPressAction,
    MethodGET,
    MethodPOST,
    NetworkCaptureConfig,
    NewCollectionResponse,
    ProxyConfig,
    RunPublic,
    ScrapeGuidance,
    SuccessCriterion,
    ScrapeRequest,
    ScrapeResponse,
    SelectAction,
    SelectorInvisibleCondition,
    SelectorVisibleCondition,
    UrlViabilityResult,
    ViabilityRunPublic,
    ViabilityModeResult,
    ViabilityTestRequest,
    WaitForSelectorAction,
    WaitForTimeoutAction,
    WhileControl,
)

__all__ = [
    # Version
    "__version__",
    # Clients
    "ScrapingPros",
    "AsyncScrapingPros",
    # Clients — preferred aliases (v0.5.1+)
    "SyncClient",
    "AsyncClient",
    # High-level batch API
    "Batch",
    "AsyncBatch",
    # Demo
    "DEMO_TOKEN",
    # Exceptions
    "ScrapingProsError",
    "APIError",
    "AuthenticationError",
    "ConnectionError",
    "CountryProxyNotApproved",
    "URLBlockedError",
    "ValidationError",
    "RateLimitError",
    "QuotaExceededError",
    "TimeoutError",
    "SubmitTimeout",
    # Models — Request/Response
    "ScrapeGuidance",
    "ScrapeRequest",
    "ScrapeResponse",
    "DownloadRequest",
    "DownloadResponse",
    # Models — Actions
    "Action",
    "ClickAction",
    "InputAction",
    "SelectAction",
    "KeyPressAction",
    "WaitForSelectorAction",
    "WaitForTimeoutAction",
    "EvaluateAction",
    "CollectAction",
    "WhileControl",
    "SelectorVisibleCondition",
    "SelectorInvisibleCondition",
    # Models — Config
    "ProxyConfig",
    "NetworkCaptureConfig",
    "MethodGET",
    "MethodPOST",
    # Models — Collections/Runs
    "CollectionPublic",
    "NewCollectionResponse",
    "RunPublic",
    "SuccessCriterion",
    "FailedJobPublic",
    "JobExecutionPublic",
    "JobExecutionListPublic",
    # Models — Viability
    "ViabilityTestRequest",
    "ViabilityRunPublic",
    "ViabilityModeResult",
    "UrlViabilityResult",
    # Models — Proxy
    "CountryRequest",
    "ProxyCountriesResponse",
    "ProxyRequestCountryResponse",
    "ProxyStatusResponse",
    # Models — Billing/Metrics
    "BillingResponse",
    "BillingClientData",
    "BillingCredits",
    "CreditSystemInfo",
    "ClientMetricsResponse",
]
