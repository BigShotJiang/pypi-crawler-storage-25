"""Asynchronous client for the Scraping Pros API.

Example:
    >>> import asyncio
    >>> from scrapingpros import AsyncScrapingPros
    >>> async def main():
    ...     async with AsyncScrapingPros("your_token") as client:
    ...         result = await client.scrape("https://example.com")
    ...         print(result.html[:50])
    >>> asyncio.run(main())  # doctest: +SKIP
"""

from __future__ import annotations

import asyncio
import time
import warnings
from datetime import datetime
from collections.abc import AsyncIterator, Awaitable
from typing import Any, Callable, Literal

import httpx

from scrapingpros._base import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    RateLimitInfo,
    RetryConfig,
    _is_quota_error,
    logger,
    map_error,
    parse_rate_limit_headers,
    resolve_token,
)
from scrapingpros.exceptions import ConnectionError, RateLimitError, TimeoutError
from scrapingpros.models import (
    Action,
    CollectionPublic,
    DownloadResponse,
    HttpMethod,
    JobExecutionListPublic,
    JobExecutionPublic,
    NewCollectionResponse,
    BillingResponse,
    ClientMetricsResponse,
    ProxyCountriesResponse,
    ProxyRequestCountryResponse,
    ProxyStatusResponse,
    RunPublic,
    ScrapeRequest,
    ScrapeResponse,
    UseProxy,
    ViabilityRunPublic,
    NetworkCaptureConfig,
)


class AsyncScrapingPros:
    """Asynchronous Python client for the Scraping Pros API.

    .. note::
        ``AsyncScrapingPros`` and :class:`ScrapingPros` expose **the
        same set of methods** and can hit **the same endpoints** —
        sync (``/v1/sync/scrape``) and async / Collections
        (``/v1/async/collections``). The only difference is the local
        I/O loop: this client uses :class:`httpx.AsyncClient` and is
        meant for ``async/await`` codebases.

        Switching from the sync to the async client **does not
        increase throughput on its own**. To scale to many URLs use
        :meth:`submit_batch` (Collections API, server-side
        parallelism) — that works identically on either client.

    Example:
        >>> async with AsyncScrapingPros("your_token") as client:
        ...     result = await client.scrape("https://example.com")
        ...     print(result.html[:50])  # doctest: +SKIP

    Args:
        token: Your API token. Falls back to the ``SP_TOKEN`` env var.
            Use ``"demo_6x595maoA6GdOdVb"`` for quick testing
            (5,000 credits/month, 30 req/min).
        base_url: API base URL. Defaults to ``https://api.scrapingpros.com``.
        timeout: Request timeout in seconds. Defaults to 120.
        max_retries: Max automatic retries on 429. Defaults to 3.
    """

    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        if type(self) is AsyncScrapingPros:
            warnings.warn(
                "`AsyncScrapingPros` was renamed to `AsyncClient` in "
                "v0.5.1 and will be removed in v1.0. Update the import: "
                "`from scrapingpros import AsyncClient`. The behaviour is "
                "identical — the rename clarifies that this client (and "
                "`SyncClient`) can call every endpoint, sync or "
                "Collections; only the local I/O loop differs.",
                DeprecationWarning,
                stacklevel=2,
            )
        self._token = resolve_token(token)
        self._base_url = base_url.rstrip("/")
        self._retry = RetryConfig(max_retries=max_retries)
        self._last_rate_limit = RateLimitInfo()
        self._plan_max_concurrent: int | None = None
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
            limits=httpx.Limits(
                max_connections=200,
                max_keepalive_connections=100,
            ),
        )

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncScrapingPros:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    @property
    def rate_limit_remaining(self) -> int | None:
        """Remaining requests in the current rate-limit window."""
        return self._last_rate_limit.rate_limit_remaining

    @property
    def quota_remaining(self) -> int | str | None:
        """Remaining requests in the monthly quota."""
        return self._last_rate_limit.quota_remaining

    @property
    def credits_charged(self) -> int | None:
        """Credits charged for the last API call."""
        return self._last_rate_limit.credits_charged

    async def _detect_max_concurrent(self) -> int:
        """Detect max concurrent jobs from the plan. Caches result."""
        if self._plan_max_concurrent is not None:
            return self._plan_max_concurrent

        default = 5
        try:
            quota_limit = self._last_rate_limit.quota_limit
            rate_limit = self._last_rate_limit.rate_limit_limit

            if quota_limit is None and rate_limit is None:
                self._plan_max_concurrent = default
                return default

            plans_data = await self.plans()
            for plan in plans_data.get("plans", []):
                if plan.get("credits_monthly") == quota_limit:
                    self._plan_max_concurrent = plan.get("max_concurrent_jobs", default)
                    return self._plan_max_concurrent

            if rate_limit and rate_limit > 0:
                self._plan_max_concurrent = min(max(5, rate_limit // 6), 100)
                return self._plan_max_concurrent

            self._plan_max_concurrent = default
        except Exception:
            self._plan_max_concurrent = default

        return self._plan_max_concurrent

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send an HTTP request with automatic retry on 429 and 5xx."""
        last_exc: Exception | None = None
        for attempt in range(self._retry.max_retries + 1):
            try:
                resp = await self._http.request(method, path, **kwargs)
            except httpx.HTTPError as exc:
                raise ConnectionError(
                    f"Could not connect to {self._base_url}: {exc}"
                ) from exc

            self._last_rate_limit = parse_rate_limit_headers(
                dict(resp.headers),
            )

            if resp.status_code < 400:
                return resp

            # Quota exceeded — don't retry, it won't help
            if resp.status_code == 429 and _is_quota_error(resp.text):
                raise map_error(resp.status_code, resp.text, dict(resp.headers))

            # Retryable: 429 (rate limit) and 5xx (server errors)
            is_retryable = resp.status_code == 429 or resp.status_code >= 500
            if is_retryable and attempt < self._retry.max_retries:
                retry_after_raw = resp.headers.get("retry-after")
                retry_after: float | None = None
                if retry_after_raw:
                    try:
                        retry_after = float(retry_after_raw)
                    except (ValueError, TypeError):
                        pass
                delay = self._retry.delay_for_attempt(attempt, retry_after)
                # See ScrapingPros._request — INFO since v0.5.2 to avoid
                # drowning caller logs under load. Lower SDK logger to INFO
                # for visibility.
                logger.info(
                    "Request %s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                    method, path, resp.status_code, delay,
                    attempt + 1, self._retry.max_retries,
                )
                await asyncio.sleep(delay)
                last_exc = map_error(resp.status_code, resp.text, dict(resp.headers))
                continue

            raise map_error(resp.status_code, resp.text, dict(resp.headers))

        if last_exc is not None:
            raise last_exc
        raise map_error(resp.status_code, resp.text, dict(resp.headers))  # pragma: no cover

    # -- Sync endpoints -----------------------------------------------------

    async def scrape(
        self,
        url: str,
        *,
        format: Literal["html", "markdown"] = "html",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        screenshot: bool = False,
        actions: list[Action] | None = None,
        language: str = "",
        http_method: HttpMethod | None = None,
        headers: dict[str, str] | None = None,
        window_size: str = "",
        cookies: dict[str, Any] | None = None,
        extract: dict[str, str | dict[str, Any]] | None = None,
        network_capture: NetworkCaptureConfig | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
    ) -> ScrapeResponse:
        """Scrape a single URL.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     result = await client.scrape("https://example.com", format="markdown")
            ...     print(result.markdown)  # doctest: +SKIP
        """
        req = ScrapeRequest(
            url=url,
            format=format,
            browser=browser,
            browser_type=browser_type,
            use_proxy=use_proxy,
            screenshot=screenshot,
            actions=actions,
            language=language,
            http_method=http_method,
            headers=headers,
            window_size=window_size,
            cookies=cookies,
            extract=extract,
            network_capture=network_capture,
            retry_on_block=retry_on_block,
            block_resources=block_resources,
            block_requests=block_requests,
        )
        extra_kwargs: dict[str, Any] = {}
        if retry_on_block:
            extra_kwargs["timeout"] = max(self._http.timeout.read or 120, 300)

        resp = await self._request(
            "POST",
            "/v1/sync/scrape",
            json=req.model_dump(exclude_none=True, exclude_defaults=False),
            **extra_kwargs,
        )
        return ScrapeResponse.model_validate(resp.json())

    async def scrape_many(
        self,
        urls: list[str] | list[ScrapeRequest | dict[str, Any]] | None = None,
        *,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
        max_concurrent: int | None = None,
        format: Literal["html", "markdown"] = "markdown",
        browser: bool = False,
        browser_type: Literal["light", "heavy", "stealth"] = "light",
        use_proxy: UseProxy = "any",
        extract: dict[str, str | dict[str, Any]] | None = None,
        retry_on_block: bool = False,
        block_resources: list[str] | None = None,
        block_requests: list[str] | None = None,
        actions: list[Action] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, Any] | None = None,
        language: str = "",
        window_size: str = "",
        screenshot: bool = False,
        http_method: HttpMethod | None = None,
        network_capture: NetworkCaptureConfig | None = None,
    ) -> list[ScrapeResponse | Exception]:
        """Scrape multiple URLs concurrently with automatic throttling.

        .. warning::
            ``scrape_many`` runs **client-side parallelism** — it opens
            up to ``max_concurrent`` simultaneous coroutines that each
            call ``/v1/sync/scrape``. Despite the ``async`` machinery,
            the server still treats every request as an independent
            sync call with full per-request overhead.

            For anything larger than a handful of URLs, prefer
            :meth:`submit_batch` + :meth:`AsyncBatch.iter_results`.
            That sends a single request to the **Collections** API,
            the server runs the batch in its async worker pool, and
            you stream results as they finish — the Python ``async``
            context only changes the local I/O loop. See also
            :meth:`batch_scrape` for a list-returning convenience
            wrapper around the Collections API.

        Uses an ``asyncio.Semaphore`` to limit concurrency. Returns
        results in the same order as input.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     results = await client.scrape_many([
            ...         "https://example.com",
            ...         "https://quotes.toscrape.com/",
            ...     ], browser=True, actions=[...])  # doctest: +SKIP
        """
        warnings.warn(
            "`scrape_many` opens N parallel coroutines that each call "
            "/v1/sync/scrape and does not scale beyond a handful of URLs. "
            "For production batches use `await client.batch_scrape(urls)` "
            "(drop-in list return) or `await client.submit_batch(name, urls)` "
            "(streaming with progress) — both run server-side parallelism "
            "via the Collections API. `scrape_many` will be removed in v1.0. "
            "See https://docs.scrapingpros.com/docs/documentation/Python%20SDK/choosing-the-right-method",
            DeprecationWarning,
            stacklevel=2,
        )
        # Resolve inputs
        items: list[ScrapeRequest | str] = []
        if requests is not None:
            for r in requests:
                if isinstance(r, dict):
                    items.append(ScrapeRequest(**r))
                else:
                    items.append(r)
        elif urls is not None:
            for u in urls:
                if isinstance(u, str):
                    items.append(u)
                elif isinstance(u, dict):
                    items.append(ScrapeRequest(**u))
                else:
                    items.append(u)
        else:
            raise ValueError("Either urls or requests must be provided")

        if max_concurrent is None:
            max_concurrent = await self._detect_max_concurrent()

        semaphore = asyncio.Semaphore(max_concurrent)

        async def _scrape_one(index: int, item: ScrapeRequest | str) -> tuple[int, ScrapeResponse | Exception]:
            async with semaphore:
                try:
                    if isinstance(item, ScrapeRequest):
                        req = item
                        extra_kwargs: dict[str, Any] = {}
                        if req.retry_on_block:
                            extra_kwargs["timeout"] = max(self._http.timeout.read or 120, 300)
                        resp = await self._request(
                            "POST",
                            "/v1/sync/scrape",
                            json=req.model_dump(exclude_none=True, exclude_defaults=False),
                            **extra_kwargs,
                        )
                        return index, ScrapeResponse.model_validate(resp.json())
                    else:
                        resp = await self.scrape(
                            item,
                            format=format,
                            browser=browser,
                            browser_type=browser_type,
                            use_proxy=use_proxy,
                            extract=extract,
                            retry_on_block=retry_on_block,
                            block_resources=block_resources,
                            block_requests=block_requests,
                            actions=actions,
                            headers=headers,
                            cookies=cookies,
                            language=language,
                            window_size=window_size,
                            screenshot=screenshot,
                            http_method=http_method,
                            network_capture=network_capture,
                        )
                        return index, resp
                except Exception as e:
                    return index, e

        tasks = [_scrape_one(i, item) for i, item in enumerate(items)]
        raw_results = await asyncio.gather(*tasks)

        result_list: list[ScrapeResponse | Exception] = [None] * len(items)  # type: ignore
        for idx, result in raw_results:
            result_list[idx] = result
        return result_list

    async def download(
        self,
        url: str,
        *,
        use_proxy: UseProxy = None,
    ) -> DownloadResponse:
        """Download a file and return its content as base64.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     result = await client.download("https://example.com/file.pdf")  # doctest: +SKIP
        """
        body: dict[str, Any] = {"url": url}
        if use_proxy is not None:
            body["use_proxy"] = use_proxy if isinstance(use_proxy, str) else use_proxy.model_dump()
        resp = await self._request("POST", "/v1/sync/download", json=body)
        return DownloadResponse.model_validate(resp.json())

    # -- Collections --------------------------------------------------------

    async def create_collection(
        self,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
        *,
        callback_url: str | None = None,
        _timeout: float | None = None,
    ) -> NewCollectionResponse:
        """Create a new collection for async batch processing.

        Example:
            >>> async with AsyncScrapingPros("token") as client:
            ...     col = await client.create_collection("batch", [
            ...         {"url": "https://example.com/1"},
            ...     ])  # doctest: +SKIP
        """
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        if callback_url is not None:
            body["callback_url"] = callback_url
        kwargs: dict[str, Any] = {"json": body}
        if _timeout is not None:
            kwargs["timeout"] = _timeout
        resp = await self._request("POST", "/v1/async/collections", **kwargs)
        return NewCollectionResponse.model_validate(resp.json())

    async def list_collections(self) -> list[CollectionPublic]:
        """List all collections."""
        resp = await self._request("GET", "/v1/async/collections")
        return [CollectionPublic.model_validate(c) for c in resp.json()]

    async def get_collection(self, collection_id: str) -> CollectionPublic:
        """Get a specific collection by ID."""
        resp = await self._request("GET", f"/v1/async/collections/{collection_id}")
        return CollectionPublic.model_validate(resp.json())

    async def update_collection(
        self,
        collection_id: str,
        name: str,
        requests: list[ScrapeRequest | dict[str, Any]] | None = None,
    ) -> NewCollectionResponse:
        """Update an existing collection."""
        body: dict[str, Any] = {"name": name}
        if requests is not None:
            serialized = []
            for r in requests:
                if isinstance(r, dict):
                    serialized.append(r)
                else:
                    serialized.append(r.model_dump(exclude_none=True))
            body["requests"] = serialized
        resp = await self._request(
            "PUT",
            f"/v1/async/collections/{collection_id}",
            json=body,
        )
        return NewCollectionResponse.model_validate(resp.json())

    # -- Runs ---------------------------------------------------------------

    async def create_run(
        self, collection_id: str, *, _timeout: float | None = None,
    ) -> RunPublic:
        """Start a run for a collection."""
        kwargs: dict[str, Any] = {}
        if _timeout is not None:
            kwargs["timeout"] = _timeout
        resp = await self._request(
            "POST",
            f"/v1/async/collections/{collection_id}/run",
            **kwargs,
        )
        return RunPublic.model_validate(resp.json())

    async def get_run(self, collection_id: str, run_id: str) -> RunPublic:
        """Get the status of a run."""
        resp = await self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}",
        )
        return RunPublic.model_validate(resp.json())

    async def get_run_jobs(
        self,
        collection_id: str,
        run_id: str,
        *,
        cursor: str | None = None,
        limit: int = 1000,
        status_filter: Literal["processing", "completed", "failed", "timeout"] | None = None,
    ) -> JobExecutionListPublic:
        """Get detailed job executions for a run.

        By default fetches all pages internally and returns the merged list.
        Pass ``cursor`` to get a single page. Use :meth:`iter_run_jobs`
        to stream lazily for very large runs.
        """
        if cursor is not None:
            return await self._fetch_jobs_page(
                collection_id, run_id, cursor=cursor,
                limit=limit, status_filter=status_filter,
            )

        all_items: list = []
        next_cursor: str | None = None
        while True:
            page = await self._fetch_jobs_page(
                collection_id, run_id, cursor=next_cursor,
                limit=limit, status_filter=status_filter,
            )
            all_items.extend(page.items)
            if not page.has_more or not page.cursor_next:
                break
            next_cursor = page.cursor_next
        return JobExecutionListPublic(items=all_items, cursor_next=None, has_more=False)

    async def _fetch_jobs_page(
        self,
        collection_id: str,
        run_id: str,
        *,
        cursor: str | None,
        limit: int,
        status_filter: str | list[str] | None,
        order_by: Literal["id", "completed_at"] | None = None,
        order_dir: Literal["asc", "desc"] | None = None,
        since_completed_at: "datetime | str | None" = None,
    ) -> JobExecutionListPublic:
        """Async counterpart of :meth:`ScrapingPros._fetch_jobs_page`."""
        params: dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        if status_filter is not None:
            if isinstance(status_filter, (list, tuple)):
                params["status_filter"] = ",".join(status_filter)
            else:
                params["status_filter"] = status_filter
        if order_by is not None:
            params["order_by"] = order_by
        if order_dir is not None:
            params["order_dir"] = order_dir
        if since_completed_at is not None:
            if hasattr(since_completed_at, "isoformat"):
                params["since_completed_at"] = since_completed_at.isoformat(timespec="milliseconds")
            else:
                params["since_completed_at"] = str(since_completed_at)
        resp = await self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs",
            params=params,
        )
        return JobExecutionListPublic.model_validate(resp.json())

    async def iter_run_jobs(
        self,
        collection_id: str,
        run_id: str,
        *,
        page_size: int = 500,
        status_filter: Literal["processing", "completed", "failed", "timeout"] | None = None,
    ) -> AsyncIterator[JobExecutionPublic]:
        """Stream jobs from a run, fetching pages lazily."""
        next_cursor: str | None = None
        while True:
            page = await self._fetch_jobs_page(
                collection_id, run_id, cursor=next_cursor,
                limit=page_size, status_filter=status_filter,
            )
            for job in page.items:
                yield job
            if not page.has_more or not page.cursor_next:
                return
            next_cursor = page.cursor_next

    async def run_and_wait(
        self,
        collection_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 3600.0,
    ) -> RunPublic:
        """Create a run and poll until it completes.

        For most production workloads prefer :meth:`submit_batch` +
        :meth:`AsyncBatch.iter_results` — streaming results removes
        the need for a global timeout.

        ``timeout`` defaults to 3600 s (1 h) since v0.5.1; the
        previous default (300 s) timed out legitimate browser/stealth
        runs.

        Raises:
            TimeoutError: If the run does not complete within *timeout*.
        """
        run = await self.create_run(collection_id)
        start = time.monotonic()
        while True:
            run = await self.get_run(collection_id, run.run_id)
            if run.status in ("completed", "failed", "cancelled"):
                return run
            if time.monotonic() - start > timeout:
                raise TimeoutError(
                    f"Run {run.run_id} did not complete within {timeout}s"
                )
            await asyncio.sleep(poll_interval)

    # -- High-level batch API (v0.4.0+) ------------------------------------

    async def submit_batch(
        self,
        name: str,
        items: list[str] | list[ScrapeRequest | dict[str, Any]],
        *,
        callback_url: str | None = None,
        submit_timeout: float = 30.0,
        on_submitted: "Callable[[str, str | None], Awaitable[None] | None] | None" = None,
    ) -> "AsyncBatch":
        """Submit a batch and return an :class:`AsyncBatch` handle.

        See :meth:`ScrapingPros.submit_batch` for the full contract,
        including ``submit_timeout`` and ``on_submitted`` semantics.
        ``on_submitted`` may return an awaitable; both sync and async
        callbacks are supported.
        """
        import inspect

        from scrapingpros.batch import AsyncBatch, _normalize_items
        from scrapingpros.exceptions import (
            ConnectionError as SPConnectionError,
            SubmitTimeout,
        )

        async def _maybe_await(value: Any) -> None:
            if inspect.isawaitable(value):
                await value

        payload = _normalize_items(items)
        try:
            col = await self.create_collection(
                name, payload, callback_url=callback_url, _timeout=submit_timeout,
            )
        except SPConnectionError as exc:
            raise SubmitTimeout(
                f"submit_batch timed out creating collection {name!r} after "
                f"{submit_timeout}s. Call client.find_recent_batch(name={name!r}, "
                f"since=...) before retrying. Underlying: {exc.message}"
            ) from exc
        if on_submitted is not None:
            await _maybe_await(on_submitted(col.id, None))

        try:
            run = await self.create_run(col.id, _timeout=submit_timeout)
        except SPConnectionError as exc:
            raise SubmitTimeout(
                f"submit_batch timed out starting run for {col.id} after "
                f"{submit_timeout}s. Collection EXISTS; call create_run("
                f"{col.id!r}) explicitly or find_recent_batch(name={name!r}). "
                f"Underlying: {exc.message}"
            ) from exc
        if on_submitted is not None:
            await _maybe_await(on_submitted(col.id, run.run_id))

        return AsyncBatch(
            self,
            collection_id=col.id,
            run_id=run.run_id,
            name=name,
            total=len(payload),
        )

    async def find_recent_batch(
        self,
        *,
        name: str,
        since: "datetime | None" = None,
    ) -> "AsyncBatch | None":
        """Async counterpart of :meth:`ScrapingPros.find_recent_batch`."""
        cols = await self.list_collections()
        matches = [c for c in cols if c.name == name]
        if not matches:
            return None
        target = matches[-1]
        from scrapingpros.batch import AsyncBatch
        return AsyncBatch(
            self,
            collection_id=target.id,
            run_id="",
            name=target.name,
        )

    async def batch_scrape(
        self,
        items: list[str] | list[ScrapeRequest | dict[str, Any]],
        *,
        name: str | None = None,
        callback_url: str | None = None,
    ) -> list[ScrapeResponse]:
        """Scrape a list of URLs via the Collections API and return all results.

        Convenience wrapper around :meth:`submit_batch` that awaits
        every job and returns the full list. See
        :meth:`ScrapingPros.batch_scrape` for the rationale (drop-in
        replacement for :meth:`scrape_many` with server-side scaling).

        For thousands of URLs prefer :meth:`submit_batch` directly so
        you can stream results as they finish.

        Returns:
            List of :class:`ScrapeResponse`, in completion order.
        """
        from datetime import datetime as _dt

        batch_name = name or f"batch_scrape-{_dt.now().strftime('%Y%m%d-%H%M%S')}"
        batch = await self.submit_batch(batch_name, items, callback_url=callback_url)
        results: list[ScrapeResponse] = []
        async for r in batch.iter_results():
            results.append(r)
        return results

    async def get_batch(
        self,
        collection_id: str,
        run_id: str,
        *,
        name: str | None = None,
        refresh: bool = True,
    ) -> "AsyncBatch":
        """Reattach to an existing batch.

        Async counterpart of :meth:`ScrapingPros.get_batch`. Since
        v0.5.2 performs a one-shot refresh by default; pass
        ``refresh=False`` to skip.
        """
        from scrapingpros.batch import AsyncBatch

        batch = AsyncBatch(self, collection_id=collection_id, run_id=run_id, name=name)
        if refresh:
            await batch.refresh()
        return batch

    async def iter_results(
        self,
        collection_id: str,
        run_id: str,
        *,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        include_failed: bool = True,
        fetch_workers: int = 5,
    ) -> AsyncIterator[ScrapeResponse]:
        """Stream results of an existing run as jobs complete.

        Async counterpart of :meth:`ScrapingPros.iter_results` —
        convenience shortcut equivalent to::

            batch = await client.get_batch(cid, rid, refresh=False)
            async for r in batch.iter_results(...):
                ...
        """
        batch = await self.get_batch(collection_id, run_id, refresh=False)
        async for r in batch.iter_results(
            poll_interval=poll_interval,
            timeout=timeout,
            include_failed=include_failed,
            fetch_workers=fetch_workers,
        ):
            yield r

    # -- Viability test -----------------------------------------------------

    async def create_viability_test(
        self,
        urls: list[str],
        *,
        depth: Literal["quick", "standard", "full"] = "full",
        actions: list[Action] | None = None,
    ) -> ViabilityRunPublic:
        """Submit URLs for viability analysis."""
        body: dict[str, Any] = {"urls": urls, "depth": depth}
        if actions is not None:
            body["actions"] = [a.model_dump() for a in actions]
        resp = await self._request("POST", "/v1/async/viability-test", json=body)
        return ViabilityRunPublic.model_validate(resp.json())

    async def get_viability_test(self, run_id: str) -> ViabilityRunPublic:
        """Poll the status and results of a viability test."""
        resp = await self._request("GET", f"/v1/async/viability-test/{run_id}")
        return ViabilityRunPublic.model_validate(resp.json())

    async def get_job_result(
        self,
        collection_id: str,
        run_id: str,
        job_id: str,
    ) -> ScrapeResponse:
        """Get the full scrape result for a specific job.

        Results are available for 24 hours after job completion.
        """
        resp = await self._request(
            "GET",
            f"/v1/async/collections/{collection_id}/runs/{run_id}/jobs/{job_id}/result",
        )
        return ScrapeResponse.model_validate(resp.json())

    async def delete_collection(self, collection_id: str) -> None:
        """Delete a collection and its associated jobs."""
        await self._request("DELETE", f"/v1/async/collections/{collection_id}")

    # -- Proxy --------------------------------------------------------------

    async def list_proxy_countries(self) -> ProxyCountriesResponse:
        """List all 200+ countries available for geo-targeted scraping."""
        resp = await self._request("GET", "/v1/proxy/countries")
        return ProxyCountriesResponse.model_validate(resp.json())

    async def request_proxy_country(
        self,
        country_code: str,
        *,
        reason: str = "",
    ) -> ProxyRequestCountryResponse:
        """Request access to a country-specific proxy."""
        resp = await self._request(
            "POST",
            "/v1/proxy/request-country",
            json={"country_code": country_code, "reason": reason},
        )
        return ProxyRequestCountryResponse.model_validate(resp.json())

    async def proxy_status(self) -> ProxyStatusResponse:
        """Check your country proxy approvals."""
        resp = await self._request("GET", "/v1/proxy/status")
        return ProxyStatusResponse.model_validate(resp.json())

    # -- Plans --------------------------------------------------------------

    async def plans(self) -> Any:
        """List all available plans with pricing, credits, and features."""
        resp = await self._request("GET", "/v1/plans")
        return resp.json()

    # -- Billing & Metrics --------------------------------------------------

    async def billing(self, *, month: str = "", detail: str = "") -> BillingResponse:
        """Get billing summary."""
        params: dict[str, str] = {}
        if month:
            params["month"] = month
        if detail:
            params["detail"] = detail
        resp = await self._request("GET", "/v1/sync/billing", params=params)
        return BillingResponse.model_validate(resp.json())

    async def metrics(self, *, date: str = "", metric: str = "") -> Any:
        """Get API metrics."""
        params: dict[str, str] = {}
        if date:
            params["date"] = date
        if metric:
            params["metric"] = metric
        resp = await self._request("GET", "/v1/sync/metrics", params=params)
        return resp.json()

    async def client_metrics(
        self,
        *,
        date: str = "",
        hourly: bool = False,
        detail: str = "",
    ) -> ClientMetricsResponse:
        """Get your usage metrics."""
        params: dict[str, Any] = {}
        if date:
            params["date"] = date
        if hourly:
            params["hourly"] = "true"
        if detail:
            params["detail"] = detail
        resp = await self._request("GET", "/v1/sync/client-metrics", params=params)
        return ClientMetricsResponse.model_validate(resp.json())

    # -- Health -------------------------------------------------------------

    async def health(self) -> Any:
        """Check API health status."""
        resp = await self._request("GET", "/v1/health")
        return resp.json()
