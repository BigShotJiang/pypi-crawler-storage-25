"""High-level batch processing API — submit many URLs and stream results.

The :class:`Batch` class wraps the collection + run + jobs + result flow
into a single object with progress tracking, callbacks, and streaming
iteration. Intended for batches of any size from a few URLs to 50,000+.

Example:
    >>> from scrapingpros import ScrapingPros
    >>> client = ScrapingPros("your_token")
    >>> batch = client.submit_batch("reviews", [
    ...     {"url": tour.url, "custom_id": tour.id} for tour in tours
    ... ])
    >>> for result in batch.iter_results():  # doctest: +SKIP
    ...     if result.guidance and result.guidance.success:
    ...         save(result.content, my_id=result.custom_id)
    ...     if batch.completed_count % 100 == 0:
    ...         print(f"{batch.pct:.1f}% — ETA {batch.eta_seconds}s")
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime
from collections.abc import AsyncIterator, Awaitable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, TYPE_CHECKING

from scrapingpros.exceptions import (
    APIError,
    ConnectionError as SPConnectionError,
    RateLimitError,
    TimeoutError,
)


def _is_transient_poll_error(exc: BaseException) -> bool:
    """Return True if a polling exception is transient and worth retrying.

    The polling loop in :meth:`Batch.iter_results` should survive:

    - Local network hiccups (:class:`SPConnectionError`).
    - Server 5xx (502 / 503 / 504 are classic load-balancer / restart
      signals; 500 with a generic body is usually a degraded backend).
    - 429 rate-limit (:class:`RateLimitError`) — the SDK already retries
      these at the request layer but a timing race can still surface
      one to the caller.

    Anything else (4xx other than 429, custom semantic errors) is a
    real failure mode the caller should see.
    """
    if isinstance(exc, (SPConnectionError, RateLimitError)):
        return True
    if isinstance(exc, APIError):
        return 500 <= exc.status_code < 600
    return False
from scrapingpros.models import (
    JobExecutionPublic,
    RunPublic,
    ScrapeGuidance,
    ScrapeRequest,
    ScrapeResponse,
)

if TYPE_CHECKING:
    from scrapingpros.async_client import AsyncScrapingPros
    from scrapingpros.client import ScrapingPros


# Parallelism for fetching individual job results
_DEFAULT_FETCH_WORKERS = 5


class Batch:
    """A submitted batch of scrape requests, with streaming result iteration
    and progress tracking.

    Obtain via :meth:`ScrapingPros.submit_batch` or
    :meth:`ScrapingPros.get_batch`.

    Lifecycle:
        1. Submit (server-side): ``client.submit_batch(name, items)`` creates
           a collection and starts a run. The returned ``Batch`` is live.
        2. Iterate (client-side): ``batch.iter_results()`` yields
           :class:`ScrapeResponse` as jobs complete, updating progress
           counters in the process.
        3. Finalize: when the run reaches a terminal status (``completed``,
           ``failed``, ``cancelled``), iteration stops. Optionally
           ``batch.delete()`` to clean up the collection.

    Progress attributes (updated during iteration):
        - :attr:`total` — total jobs submitted
        - :attr:`completed_count` — jobs in a terminal state we have seen
        - :attr:`success_count` — jobs where ``guidance.success`` is True
        - :attr:`failed_count` — jobs that failed, timed out, or returned
          unsuccessful content (``guidance.success`` is False)
        - :attr:`processing_count` — jobs still running (derived)
        - :attr:`pct` — percentage completed (0..100)
        - :attr:`elapsed_seconds` — time since iteration started
        - :attr:`jobs_per_second` — throughput (computed)
        - :attr:`eta_seconds` — estimated seconds remaining (computed)
        - :attr:`status` — run status from the server

    Callbacks (call before iterating):
        - :meth:`on_result` — called once per yielded result
        - :meth:`on_progress` — called every ``poll_interval`` with the
          batch itself, so the callback can read progress attributes
        - :meth:`on_complete` — called once when iteration finishes
    """

    def __init__(
        self,
        client: "ScrapingPros",
        collection_id: str,
        run_id: str,
        *,
        name: str | None = None,
        total: int | None = None,
    ) -> None:
        self._client = client
        self.collection_id = collection_id
        self.run_id = run_id
        self.name = name

        # Server-reported totals refresh on every poll
        self._total_override = total
        self._last_run: RunPublic | None = None

        # Local tracking during iteration.
        self._seen_job_ids: set[str] = set()
        self._success_count = 0
        self._failed_count = 0
        self._started_at: float | None = None

        # Incremental-polling state. We use the server-side
        # `since_completed_at` filter to bring only jobs that completed
        # after the previous tick's high-water mark. Ties within the same
        # millisecond are deduplicated via `_seen_job_ids`.
        self._last_completed_at: datetime | None = None
        # Legacy cursor field kept for backward compatibility with any
        # caller that persisted it; no longer used for polling.
        self._last_cursor: str | None = None

        # Callbacks
        self._on_result: list[Callable[[ScrapeResponse], None]] = []
        self._on_progress: list[Callable[["Batch"], None]] = []
        self._on_complete: list[Callable[["Batch"], None]] = []

    # -- Properties ---------------------------------------------------------

    @property
    def total(self) -> int:
        """Total jobs submitted. Available from the server after first poll,
        or from the ``total`` argument if passed at construction."""
        if self._last_run is not None and self._last_run.total_requests:
            return self._last_run.total_requests
        if self._total_override is not None:
            return self._total_override
        return 0

    @property
    def completed_count(self) -> int:
        """Jobs we have seen in a terminal state (completed/failed/timeout).

        If we have not iterated yet, falls back to the server-reported
        sum from :class:`RunPublic`.
        """
        if self._seen_job_ids:
            return len(self._seen_job_ids)
        if self._last_run is not None:
            return (
                (self._last_run.success_requests or 0)
                + (self._last_run.failed_requests or 0)
                + (self._last_run.timeout_requests or 0)
            )
        return 0

    @property
    def success_count(self) -> int:
        """Jobs where ``guidance.success`` is True.

        Computed locally during iteration. Before iterating, falls back to
        the server-reported ``success_requests`` from the run.
        """
        if self._seen_job_ids:
            return self._success_count
        if self._last_run is not None:
            return self._last_run.success_requests or 0
        return 0

    @property
    def failed_count(self) -> int:
        """Jobs that failed, timed out, or completed without success.

        Returns the max of local tracking (jobs we actually yielded that
        had ``guidance.success = False``) and the server-side run stats
        (``failed_requests + timeout_requests``). The fallback to server
        stats ensures correct totals when ``include_failed=False`` made
        us skip failed jobs locally.
        """
        run_side = 0
        if self._last_run is not None:
            run_side = (self._last_run.failed_requests or 0) + (self._last_run.timeout_requests or 0)
        return max(run_side, self._failed_count)

    @property
    def processing_count(self) -> int:
        """Jobs still running (total − completed)."""
        total = self.total
        done = self.completed_count
        return max(0, total - done)

    @property
    def pct(self) -> float:
        """Percentage completed, 0..100."""
        total = self.total
        if not total:
            return 0.0
        return self.completed_count / total * 100.0

    @property
    def elapsed_seconds(self) -> float:
        """Seconds since iteration started. 0 before :meth:`iter_results`."""
        if self._started_at is None:
            return 0.0
        return time.monotonic() - self._started_at

    @property
    def jobs_per_second(self) -> float:
        """Throughput computed from elapsed time and completed count."""
        elapsed = self.elapsed_seconds
        if elapsed <= 0:
            return 0.0
        return self.completed_count / elapsed

    @property
    def eta_seconds(self) -> float | None:
        """Estimated seconds remaining based on current throughput.

        Returns ``None`` if we don't have enough data yet (no completed
        jobs or throughput is zero).
        """
        rate = self.jobs_per_second
        if rate <= 0:
            return None
        remaining = self.total - self.completed_count
        if remaining <= 0:
            return 0.0
        return remaining / rate

    @property
    def status(self) -> str:
        """Run status. One of ``in_progress``, ``completed``, ``failed``, ``cancelled``."""
        return self._last_run.status if self._last_run else "in_progress"

    @property
    def is_finished(self) -> bool:
        """True when the run reached a terminal state."""
        return self.status in ("completed", "failed", "cancelled")

    # -- Callbacks ----------------------------------------------------------

    def on_result(self, fn: Callable[[ScrapeResponse], None]) -> "Batch":
        """Register a callback fired for each yielded result. Chainable."""
        self._on_result.append(fn)
        return self

    def on_progress(self, fn: Callable[["Batch"], None]) -> "Batch":
        """Register a callback fired each ``poll_interval``. Receives the
        batch itself so it can read progress attributes. Chainable."""
        self._on_progress.append(fn)
        return self

    def on_complete(self, fn: Callable[["Batch"], None]) -> "Batch":
        """Register a callback fired once iteration finishes. Chainable."""
        self._on_complete.append(fn)
        return self

    # -- Main iteration -----------------------------------------------------

    def iter_results(
        self,
        *,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        include_failed: bool = True,
        fetch_workers: int = _DEFAULT_FETCH_WORKERS,
    ) -> Iterator[ScrapeResponse]:
        """Stream results as jobs complete.

        In every poll tick this method:
            1. Refreshes the run stats (updates ``self._last_run``).
            2. Fetches the list of terminal jobs we haven't seen yet.
            3. Fetches results in parallel for those jobs.
            4. Yields each :class:`ScrapeResponse` and invokes callbacks.
            5. Sleeps ``poll_interval`` seconds.
            6. Repeats until the run is in a terminal state.

        Args:
            poll_interval: Seconds between polls. Default 5.0.
            timeout: Overall timeout in seconds. Raises :class:`TimeoutError`
                if the run does not finish in time. Default ``None`` (no
                timeout).
            include_failed: If True (default), yields synthesized responses
                for failed/timeout jobs so the caller can handle them
                explicitly. Check ``result.guidance.success`` to distinguish.
                If False, only completed jobs are yielded.
            fetch_workers: Number of parallel threads used to fetch job
                results in each tick. Default 5.

        Yields:
            :class:`ScrapeResponse` with ``url`` and ``custom_id`` populated.
            Check ``result.guidance.success`` to distinguish successful
            from failed results.

        Raises:
            TimeoutError: If ``timeout`` elapses before the run finishes.
        """
        self._started_at = time.monotonic()

        while True:
            # In each tick: fresh status first, then collect any newly
            # terminal jobs. The refresh+collect pair covers jobs that
            # completed between the previous sleep and this tick, so
            # no separate "final drain" is needed when is_finished.
            try:
                self._refresh_run_stats()
                new_jobs = self._collect_new_terminal_jobs(include_failed=include_failed)
            except Exception as exc:
                if not _is_transient_poll_error(exc):
                    # Real semantic failure (4xx other than 429, programming
                    # bug, etc.) — surface it to the caller. The batch is
                    # still running server-side; the caller can rebuild a
                    # Batch handle later via ``client.get_batch(...)``.
                    raise
                # Transient hiccup (network, 5xx, 429) — log and retry next
                # tick. The high-water mark persists so we don't lose
                # progress. Polling can ride out 30+ s of API degradation
                # because every tick re-queries from the cursor.
                from scrapingpros._base import logger
                logger.info(
                    "Batch %s poll failed transiently (%s: %s); will retry next tick",
                    self.run_id, type(exc).__name__, exc,
                )
                for fn in self._on_progress:
                    fn(self)
                if timeout is not None and self.elapsed_seconds > timeout:
                    raise TimeoutError(
                        f"Batch {self.run_id} did not complete within {timeout}s "
                        f"({self.completed_count}/{self.total} done)"
                    )
                time.sleep(poll_interval)
                continue

            if new_jobs:
                yield from self._fetch_and_yield(new_jobs, fetch_workers=fetch_workers)

            for fn in self._on_progress:
                fn(self)

            if self.is_finished:
                break

            if timeout is not None and self.elapsed_seconds > timeout:
                raise TimeoutError(
                    f"Batch {self.run_id} did not complete within {timeout}s "
                    f"({self.completed_count}/{self.total} done)"
                )

            time.sleep(poll_interval)

        for fn in self._on_complete:
            fn(self)

    def run_until_complete(
        self,
        *,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        include_failed: bool = True,
    ) -> list[ScrapeResponse]:
        """Block until the batch finishes and return all results as a list.

        Equivalent to ``list(batch.iter_results(...))`` but also suitable
        for fire-and-forget with callbacks registered via
        :meth:`on_result` / :meth:`on_progress`.

        For very large batches prefer :meth:`iter_results` to stream
        instead of holding everything in memory.
        """
        return list(
            self.iter_results(
                poll_interval=poll_interval,
                timeout=timeout,
                include_failed=include_failed,
            )
        )

    # -- Convenience --------------------------------------------------------

    def delete(self) -> None:
        """Delete the underlying collection. Results already fetched are
        not affected. Call after you have processed all results."""
        self._client.delete_collection(self.collection_id)

    # -- Internals ----------------------------------------------------------

    def _refresh_run_stats(self) -> None:
        """Pull the latest :class:`RunPublic` so progress properties are current."""
        self._last_run = self._client.get_run(self.collection_id, self.run_id)

    def refresh(self) -> "Batch":
        """Force a one-shot refresh of progress counters from the server.

        Useful when you're holding a :class:`Batch` handle outside of an
        :meth:`iter_results` loop (e.g. a monitoring dashboard, a
        progress bar in a UI thread, or a recovery script that just
        wants a snapshot). Returns ``self`` so you can chain.

        Example:
            >>> batch = client.get_batch(cid, rid).refresh()  # doctest: +SKIP
            >>> print(f"{batch.pct:.0%} ({batch.success_count}/{batch.total})")
        """
        self._refresh_run_stats()
        return self

    def _collect_new_terminal_jobs(
        self, *, include_failed: bool
    ) -> list[JobExecutionPublic]:
        """Fetch jobs that completed since the last poll.

        Uses the server-side ``since_completed_at`` + ``order_by=completed_at``
        filters (released in the 2026-04-24 async filters build) to bring
        only jobs that completed after the previous tick's high-water mark.
        Ties within the same millisecond are deduplicated via
        ``self._seen_job_ids``.
        """
        status_filter = "completed,failed,timeout" if include_failed else "completed"

        new_jobs: list[JobExecutionPublic] = []
        since = self._last_completed_at
        cursor: str | None = None

        # Paginate all results since our last high-water mark. Inside a
        # single tick we use cursor for continuation; across ticks we
        # use since_completed_at so we always resume correctly even if
        # the cursor wasn't advanced.
        while True:
            page = self._client._fetch_jobs_page(
                self.collection_id,
                self.run_id,
                cursor=cursor,
                limit=1000,
                status_filter=status_filter,
                order_by="completed_at",
                order_dir="asc",
                since_completed_at=since,
            )
            for job in page.items:
                # Same-ms tie breaker: ignore jobs we've already yielded.
                if job.job_public_id in self._seen_job_ids:
                    continue
                new_jobs.append(job)
                self._seen_job_ids.add(job.job_public_id)
                # Advance high-water mark to the job's completed_at
                if job.completed_at is not None and (
                    self._last_completed_at is None
                    or job.completed_at > self._last_completed_at
                ):
                    self._last_completed_at = job.completed_at
            if not page.has_more or not page.cursor_next:
                break
            cursor = page.cursor_next

        return new_jobs

    def _fetch_and_yield(
        self, jobs: list[JobExecutionPublic], *, fetch_workers: int
    ) -> Iterator[ScrapeResponse]:
        """For each terminal job, fetch its result (or synthesize one)
        and yield. Results come in completion order of the fetch, not
        insertion order of ``jobs``."""

        def _build_one(job: JobExecutionPublic) -> ScrapeResponse:
            return self._build_result(job)

        # Small batches: skip the thread pool overhead
        if len(jobs) == 1 or fetch_workers <= 1:
            for job in jobs:
                result = _build_one(job)
                self._track_and_callback(result)
                yield result
            return

        with ThreadPoolExecutor(max_workers=min(fetch_workers, len(jobs))) as pool:
            futures = {pool.submit(_build_one, job): job for job in jobs}
            for future in as_completed(futures):
                result = future.result()
                self._track_and_callback(result)
                yield result

    def _track_and_callback(self, result: ScrapeResponse) -> None:
        """Update counters and fire on_result callbacks."""
        if _is_success(result):
            self._success_count += 1
        else:
            self._failed_count += 1
        for fn in self._on_result:
            fn(result)

    def _build_result(self, job: JobExecutionPublic) -> ScrapeResponse:
        """Fetch the full result for a completed job, or synthesize one
        for failed/timeout jobs that have no body.

        Also ensures ``guidance`` is populated: today the async
        ``/jobs/{id}/result`` endpoint doesn't return the ``guidance``
        field (unlike sync ``/scrape``), so we fill it in client-side
        based on status_code + body so the user sees the same contract
        regardless of which path produced the result.
        """
        if job.status == "completed":
            try:
                result = self._client.get_job_result(
                    self.collection_id, self.run_id, job.job_public_id
                )
                _ensure_guidance(result, job)
                return result
            except Exception as exc:  # noqa: BLE001
                return _synthesize_error_response(job, message=f"result fetch failed: {exc}")
        # failed / timeout — no body available
        return _synthesize_error_response(job)


def _ensure_guidance(result: ScrapeResponse, job: JobExecutionPublic) -> None:
    """Populate ``result.guidance`` if the server didn't, deriving the
    verdict from the server's ``job.is_success`` when available.

    Priority:
        1. Trust ``result.guidance.success`` if already populated.
        2. Use ``job.is_success`` (server verdict since the 2026-04-24
           async filters build) as the source of truth for ``success``.
        3. Fallback to the client-side heuristic if neither is available
           (legacy runs or edge cases).

    ``error_type`` classification:
        - Validator ``block_reason`` if set
        - Job status (``failed`` / ``timeout``)
        - ``"worker_timeout"`` / ``"worker_error"`` when message signals it
        - ``"http_<code>"`` as last resort
    """
    if result.guidance is not None and result.guidance.success is not None:
        return

    if job.is_success is not None:
        success = bool(job.is_success)
    else:
        success = _is_success(result, job)

    error_type: str | None = None
    next_steps: list[str] = []

    if not success:
        if job.block_reason and job.block_reason != "none":
            error_type = job.block_reason
        elif job.status in ("failed", "timeout"):
            error_type = job.status
        elif result.message and "Timeout" in result.message:
            error_type = "worker_timeout"
            next_steps.append("Retry later; site was slow to respond or blocking.")
        elif result.message and "Error" in result.message:
            error_type = "worker_error"
        elif result.statusCode is not None and not (200 <= result.statusCode < 300):
            error_type = f"http_{result.statusCode}"

    result.guidance = ScrapeGuidance(
        success=success,
        error_type=error_type,
        next_steps=next_steps,
    )


def _synthesize_error_response(
    job: JobExecutionPublic, *, message: str | None = None
) -> ScrapeResponse:
    """Build a :class:`ScrapeResponse` for a job with no body."""
    msg = message or job.message or f"Job {job.status}"
    guidance = ScrapeGuidance(
        success=False,
        error_type=job.status if job.status != "completed" else None,
        credits_charged=0,
    )
    return ScrapeResponse(
        message=msg,
        url=job.url,
        custom_id=job.custom_id,
        statusCode=job.status_code,
        guidance=guidance,
    )


# ---------------------------------------------------------------------------
# Utilities used by ScrapingPros.submit_batch / get_batch
# ---------------------------------------------------------------------------


class AsyncBatch:
    """Async counterpart of :class:`Batch`.

    Obtain via :meth:`AsyncScrapingPros.submit_batch` or
    :meth:`AsyncScrapingPros.get_batch`. Same public surface as
    :class:`Batch` but every method is ``async``.

    Example:
        >>> async with AsyncScrapingPros("token") as client:  # doctest: +SKIP
        ...     batch = await client.submit_batch("reviews", items)
        ...     async for result in batch.iter_results():
        ...         save(result)
    """

    def __init__(
        self,
        client: "AsyncScrapingPros",
        collection_id: str,
        run_id: str,
        *,
        name: str | None = None,
        total: int | None = None,
    ) -> None:
        self._client = client
        self.collection_id = collection_id
        self.run_id = run_id
        self.name = name

        self._total_override = total
        self._last_run: RunPublic | None = None

        self._seen_job_ids: set[str] = set()
        self._success_count = 0
        self._failed_count = 0
        self._started_at: float | None = None
        self._last_completed_at: datetime | None = None
        self._last_cursor: str | None = None  # legacy, not used

        self._on_result: list[Callable[[ScrapeResponse], Any]] = []
        self._on_progress: list[Callable[["AsyncBatch"], Any]] = []
        self._on_complete: list[Callable[["AsyncBatch"], Any]] = []

    # -- Properties (same as Batch) -----------------------------------------

    @property
    def total(self) -> int:
        if self._last_run is not None and self._last_run.total_requests:
            return self._last_run.total_requests
        if self._total_override is not None:
            return self._total_override
        return 0

    @property
    def completed_count(self) -> int:
        if self._seen_job_ids:
            return len(self._seen_job_ids)
        if self._last_run is not None:
            return (
                (self._last_run.success_requests or 0)
                + (self._last_run.failed_requests or 0)
                + (self._last_run.timeout_requests or 0)
            )
        return 0

    @property
    def success_count(self) -> int:
        if self._seen_job_ids:
            return self._success_count
        if self._last_run is not None:
            return self._last_run.success_requests or 0
        return 0

    @property
    def failed_count(self) -> int:
        run_side = 0
        if self._last_run is not None:
            run_side = (self._last_run.failed_requests or 0) + (self._last_run.timeout_requests or 0)
        return max(run_side, self._failed_count)

    @property
    def processing_count(self) -> int:
        return max(0, self.total - self.completed_count)

    @property
    def pct(self) -> float:
        total = self.total
        return (self.completed_count / total * 100.0) if total else 0.0

    @property
    def elapsed_seconds(self) -> float:
        if self._started_at is None:
            return 0.0
        return time.monotonic() - self._started_at

    @property
    def jobs_per_second(self) -> float:
        elapsed = self.elapsed_seconds
        return (self.completed_count / elapsed) if elapsed > 0 else 0.0

    @property
    def eta_seconds(self) -> float | None:
        rate = self.jobs_per_second
        if rate <= 0:
            return None
        remaining = self.total - self.completed_count
        return max(0.0, remaining / rate)

    @property
    def status(self) -> str:
        return self._last_run.status if self._last_run else "in_progress"

    @property
    def is_finished(self) -> bool:
        return self.status in ("completed", "failed", "cancelled")

    # -- Callbacks ----------------------------------------------------------

    def on_result(self, fn: Callable[[ScrapeResponse], Any]) -> "AsyncBatch":
        self._on_result.append(fn)
        return self

    def on_progress(self, fn: Callable[["AsyncBatch"], Any]) -> "AsyncBatch":
        self._on_progress.append(fn)
        return self

    def on_complete(self, fn: Callable[["AsyncBatch"], Any]) -> "AsyncBatch":
        self._on_complete.append(fn)
        return self

    # -- Main iteration -----------------------------------------------------

    async def iter_results(
        self,
        *,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        include_failed: bool = True,
        fetch_workers: int = _DEFAULT_FETCH_WORKERS,
    ) -> AsyncIterator[ScrapeResponse]:
        """Async counterpart of :meth:`Batch.iter_results`.

        Uses ``asyncio.Semaphore`` + ``asyncio.gather`` to fetch job
        results in parallel within each polling tick.
        """
        self._started_at = time.monotonic()

        while True:
            try:
                await self._refresh_run_stats()
                new_jobs = await self._collect_new_terminal_jobs(include_failed=include_failed)
            except Exception as exc:
                if not _is_transient_poll_error(exc):
                    raise
                from scrapingpros._base import logger
                logger.info(
                    "AsyncBatch %s poll failed transiently (%s: %s); will retry next tick",
                    self.run_id, type(exc).__name__, exc,
                )
                await self._fire_progress()
                if timeout is not None and self.elapsed_seconds > timeout:
                    raise TimeoutError(
                        f"Batch {self.run_id} did not complete within {timeout}s "
                        f"({self.completed_count}/{self.total} done)"
                    )
                await asyncio.sleep(poll_interval)
                continue

            if new_jobs:
                async for r in self._fetch_and_yield(new_jobs, fetch_workers=fetch_workers):
                    yield r
            await self._fire_progress()

            if self.is_finished:
                break

            if timeout is not None and self.elapsed_seconds > timeout:
                raise TimeoutError(
                    f"Batch {self.run_id} did not complete within {timeout}s "
                    f"({self.completed_count}/{self.total} done)"
                )

            await asyncio.sleep(poll_interval)

        for fn in self._on_complete:
            await _maybe_await(fn(self))

    async def run_until_complete(
        self,
        *,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        include_failed: bool = True,
    ) -> list[ScrapeResponse]:
        """Block until the batch finishes and return all results."""
        results: list[ScrapeResponse] = []
        async for r in self.iter_results(
            poll_interval=poll_interval,
            timeout=timeout,
            include_failed=include_failed,
        ):
            results.append(r)
        return results

    async def delete(self) -> None:
        await self._client.delete_collection(self.collection_id)

    # -- Internals ----------------------------------------------------------

    async def _refresh_run_stats(self) -> None:
        self._last_run = await self._client.get_run(self.collection_id, self.run_id)

    async def refresh(self) -> "AsyncBatch":
        """Force a one-shot refresh of progress counters from the server.

        Async counterpart of :meth:`Batch.refresh`. Returns ``self`` so
        you can chain.
        """
        await self._refresh_run_stats()
        return self

    async def _collect_new_terminal_jobs(
        self, *, include_failed: bool
    ) -> list[JobExecutionPublic]:
        """Async version. See :meth:`Batch._collect_new_terminal_jobs`."""
        status_filter = "completed,failed,timeout" if include_failed else "completed"
        new_jobs: list[JobExecutionPublic] = []
        since = self._last_completed_at
        cursor: str | None = None
        while True:
            page = await self._client._fetch_jobs_page(
                self.collection_id,
                self.run_id,
                cursor=cursor,
                limit=1000,
                status_filter=status_filter,
                order_by="completed_at",
                order_dir="asc",
                since_completed_at=since,
            )
            for job in page.items:
                if job.job_public_id in self._seen_job_ids:
                    continue
                new_jobs.append(job)
                self._seen_job_ids.add(job.job_public_id)
                if job.completed_at is not None and (
                    self._last_completed_at is None
                    or job.completed_at > self._last_completed_at
                ):
                    self._last_completed_at = job.completed_at
            if not page.has_more or not page.cursor_next:
                break
            cursor = page.cursor_next
        return new_jobs

    async def _fetch_and_yield(
        self, jobs: list[JobExecutionPublic], *, fetch_workers: int
    ) -> AsyncIterator[ScrapeResponse]:
        sem = asyncio.Semaphore(max(1, fetch_workers))

        async def _build_one(job: JobExecutionPublic) -> ScrapeResponse:
            async with sem:
                return await self._build_result(job)

        tasks = [asyncio.create_task(_build_one(job)) for job in jobs]
        for coro in asyncio.as_completed(tasks):
            result = await coro
            await self._track_and_callback(result)
            yield result

    async def _track_and_callback(self, result: ScrapeResponse) -> None:
        if _is_success(result):
            self._success_count += 1
        else:
            self._failed_count += 1
        for fn in self._on_result:
            await _maybe_await(fn(result))

    async def _fire_progress(self) -> None:
        for fn in self._on_progress:
            await _maybe_await(fn(self))

    async def _build_result(self, job: JobExecutionPublic) -> ScrapeResponse:
        if job.status == "completed":
            try:
                result = await self._client.get_job_result(
                    self.collection_id, self.run_id, job.job_public_id
                )
                _ensure_guidance(result, job)
                return result
            except Exception as exc:  # noqa: BLE001
                return _synthesize_error_response(job, message=f"result fetch failed: {exc}")
        return _synthesize_error_response(job)


async def _maybe_await(value: Any) -> None:
    """Await the value if it is a coroutine, otherwise ignore.

    Lets callbacks be either sync or async without the caller caring.
    """
    if asyncio.iscoroutine(value):
        await value


def _is_success(
    result: ScrapeResponse,
    job: JobExecutionPublic | None = None,
) -> bool:
    """Return True if the scrape produced usable content.

    Priority order:
        1. ``job.is_success`` if populated — server-side verdict using
           the active ``success_criterion`` of the run. Source of truth.
        2. ``result.guidance.success`` if populated by the server.
        3. Client-side fallback heuristic: 2xx + non-empty body. Only
           used for legacy runs or when the server didn't compute a
           verdict.
    """
    # 1. Server's authoritative verdict (2026-04-24+)
    if job is not None and job.is_success is not None:
        return bool(job.is_success)
    # 2. Server's guidance if populated (sync /scrape always, async
    #    /result since the 2026-04-24 migration)
    if result.guidance is not None and result.guidance.success is not None:
        return bool(result.guidance.success)
    # 3. Client-side heuristic fallback (legacy runs, edge cases)
    if result.statusCode is None:
        return False
    if not (200 <= result.statusCode < 300):
        return False
    body_len = 0
    if result.html:
        body_len = len(result.html)
    elif result.markdown:
        body_len = len(result.markdown)
    return body_len > 0


def _normalize_items(
    items: list[str] | list[ScrapeRequest | dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert a mixed list of URLs / ScrapeRequest / dicts into the
    payload format expected by ``POST /v1/async/collections``.

    Performs **client-side URL validation** (since v0.5.2) so that a
    bad URL fails fast with the input index in the error, instead of
    silently failing in a worker downstream. Validation rules:

    - URL must be a non-empty string after trimming whitespace.
    - URL must start with ``http://`` or ``https://`` (the same auto-
      prepend that :class:`ScrapeRequest` does is also applied here).

    Other fields are passed through unchanged so that the API can
    evolve its schema without the SDK blocking valid payloads.
    """
    payload: list[dict[str, Any]] = []
    for idx, item in enumerate(items):
        if isinstance(item, str):
            url = _validate_batch_url(item, idx)
            payload.append({"url": url})
        elif isinstance(item, ScrapeRequest):
            payload.append(item.model_dump(exclude_none=True))
        elif isinstance(item, dict):
            url_raw = item.get("url")
            if not isinstance(url_raw, str):
                raise ValueError(
                    f"submit_batch item at index {idx} is missing a string `url` "
                    f"(got {url_raw!r}). Each item must be a URL string, a "
                    f"ScrapeRequest, or a dict with at minimum a non-empty `url`."
                )
            normalised = dict(item)
            normalised["url"] = _validate_batch_url(url_raw, idx)
            payload.append(normalised)
        else:
            raise TypeError(
                f"submit_batch items must be str, ScrapeRequest, or dict — got {type(item)}"
            )
    return payload


def _validate_batch_url(url: str, idx: int) -> str:
    """Normalise + sanity-check a URL before submitting a batch.

    Mirrors :class:`ScrapeRequest._validate_url` but emits an error
    message that includes the input index so the caller can pinpoint
    which item is bad in a list of thousands.
    """
    stripped = url.strip()
    if not stripped:
        raise ValueError(
            f"submit_batch item at index {idx} has an empty URL. "
            f"Provide a non-empty http(s) URL."
        )
    if not stripped.startswith(("http://", "https://")):
        stripped = f"https://{stripped}"
    return stripped
