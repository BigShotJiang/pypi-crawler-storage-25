# scrapingpros SDK

Python SDK for the Scraping Pros API — web scraping with browser rendering, proxy rotation, and structured data extraction.

## Quick Start

```python
from scrapingpros import SyncClient

client = SyncClient("demo_6x595maoA6GdOdVb")  # 5,000 credits/month, no signup
result = client.scrape("https://example.com")
print(result.content)
```

## When to Use This SDK

Use `scrapingpros` when a user needs to:
- Scrape web pages (HTML or clean markdown for AI/LLM)
- Extract structured data from websites using CSS/XPath selectors
- Render JavaScript-heavy pages with a headless browser
- Download files (PDF, images) from URLs
- Batch-scrape multiple URLs asynchronously
- Analyze site protections before scraping (viability test)
- Use geo-targeted proxies from 200+ countries

## Install

```bash
pip install scrapingpros
```

## Key Patterns

### HTML vs Markdown
```python
result = client.scrape("https://example.com")                    # HTML
result = client.scrape("https://example.com", format="markdown")  # Clean text for AI
print(result.content)  # Returns whichever is available
```

### Browser for JS-heavy / protected sites
```python
result = client.scrape("https://spa-site.com", browser=True)
# For hard sites, combine with retry_on_block + resource blocking:
result = client.scrape("https://hard-site.com", browser=True, retry_on_block=True,
                       block_resources=["image", "font", "media"])
```
The API picks the best engine automatically — you don't configure which browser to use.

### Anti-bot bypass (CAPTCHA, Cloudflare, etc.)
```python
result = client.scrape("https://protected-site.com", browser=True, retry_on_block=True)
# Retries up to 3x with different IP/fingerprint. Only charges on success.
```

### Resource blocking (faster loads, less detection)
```python
result = client.scrape("https://heavy-site.com", browser=True,
    block_resources=["image", "font", "media"],                      # by resource type
    block_requests=["google-analytics", "doubleclick", "tracker"],   # by URL substring
)
```

### JavaScript execution in the page (EvaluateAction)
```python
from scrapingpros import EvaluateAction, WaitForSelectorAction

result = client.scrape("https://example.com", browser=True, actions=[
    WaitForSelectorAction(selector="css:.loaded", time=5000),
    EvaluateAction(script="fetch('/api/data').then(r => r.json())"),
])
api_data = result.evaluate_results[0]  # parsed JSON from the internal API call
```
Use `EvaluateAction` when data comes from JS variables, internal APIs, or isn't in the DOM.
Use `extract` (CSS/XPath) when data is visible in the HTML.

### Data extraction
```python
result = client.scrape("https://quotes.toscrape.com/", extract={
    "quotes": {"selector": "css:.text", "multiple": True},
    "authors": {"selector": "css:.author", "multiple": True},
})
for quote, author in zip(result.extracted_data["quotes"], result.extracted_data["authors"]):
    print(f"{quote} — {author}")
```

### Large batches with progress streaming (submit_batch)
**For batches over ~100 URLs, use `submit_batch()` — the high-level async API with streaming results and progress tracking.** Scales to 50,000+ URLs.
```python
batch = client.submit_batch("daily", [
    {"url": u, "custom_id": my_id} for u, my_id in items
])
for result in batch.iter_results():
    if result.guidance.success:
        save(my_id=result.custom_id, content=result.content)
    if batch.completed_count % 100 == 0:
        print(f"{batch.pct:.1f}% — ETA {batch.eta_seconds}s")
```
Check `result.guidance.success` / `result.guidance.error_type` for failed jobs (they are yielded too by default). Callbacks: `batch.on_result(fn).on_progress(fn).on_complete(fn)`.

### Multiple URLs — list return (batch_scrape)
**Use `batch_scrape()` when you want a flat `list[ScrapeResponse]` for many URLs.** Drop-in replacement for the deprecated `scrape_many()`; uses the Collections API server-side instead of opening N parallel sync HTTP connections from the client.
```python
results = client.batch_scrape([
    {"url": "https://example.com/1", "custom_id": "a", "browser": True},
    {"url": "https://example.com/2", "custom_id": "b", "browser": True},
])
for r in results:
    if r.guidance.success:
        save(r.custom_id, r.content)
```

> **Avoid `scrape_many()` going forward** — it emits a `DeprecationWarning` (slated for removal in v1.0). It only made sense for ad-hoc 5–20 URL probes; for anything else `batch_scrape()` (list) or `submit_batch()` (streaming) is the right tool.

### Batch processing (collections)
For very large batches (1000+ URLs), use collections with server-side execution. Use `custom_id` for traceability so you can map results back to your data without depending on order:
```python
col = client.create_collection("batch", [
    {"url": "https://example.com/tour/1", "custom_id": "tour_1"},
    {"url": "https://example.com/tour/2", "custom_id": "tour_2"},
])
run = client.run_and_wait(col.id)

# iter_run_jobs streams jobs and includes url + custom_id + is_success for each
# Use job.is_success (server verdict) — catches soft-blocks (Google CAPTCHA
# pages, Amazon "Robot Check") that a naive 2xx check would miss.
for job in client.iter_run_jobs(col.id, run.run_id):
    if job.is_success:
        result = client.get_job_result(col.id, run.run_id, job.job_public_id)
        save(my_id=job.custom_id, content=result.content)
```

Pin the success policy in integration tests:
```python
run = client.get_run(col.id, run.run_id)
assert run.success_criterion.version == "content_success_v1"
```

### POST to a different URL than the navigation target
```python
from scrapingpros import MethodPOST
# Useful for sites where you must navigate one URL but POST to another (GraphQL, internal API)
result = client.scrape("https://example.com/page", http_method=MethodPOST(
    url="https://api.example.com/graphql", payload={"query": "..."},
))
```

### POST with form-encoded body (OAuth2, legacy APIs)
```python
from scrapingpros import MethodPOST
# OAuth2 client_credentials requires application/x-www-form-urlencoded
result = client.scrape("https://api.example.com/v1/oauth2/token", http_method=MethodPOST(
    payload={"grant_type": "client_credentials", "scope": "read"},
    content_type="form",   # default is "json"
))
```

### Wait for non-visible elements (e.g. <script> tags with JSON)
```python
from scrapingpros import WaitForSelectorAction
# Default `state` is server-side "visible" — use "attached" for hidden nodes
result = client.scrape("https://example.com", browser=True, actions=[
    WaitForSelectorAction(selector="css:script#__NEXT_DATA__", time=8000, state="attached"),
])
```

### Capture response bodies for selected URLs (auth flows, GraphQL)
```python
from scrapingpros import NetworkCaptureConfig
# Capture the body of any matching response (64 KB cap, 5s fetch timeout)
result = client.scrape("https://app.example.com", browser=True, network_capture=NetworkCaptureConfig(
    resource_types=["xhr", "fetch"],
    url_pattern="*identitytoolkit.googleapis.com*",
))
for entry in result.network_requests or []:
    if "body" in entry:                # only present when url_pattern matched
        token = parse_token(entry["body"])
```

### Async client
```python
from scrapingpros import AsyncClient

async with AsyncClient("demo_6x595maoA6GdOdVb") as client:
    result = await client.scrape("https://example.com", format="markdown")
```

## Response Guidance

Every scrape response includes `guidance` that tells you why it failed and what to do:

```python
result = client.scrape("https://hard-site.com")
if not result.guidance.success:
    print(result.guidance.error_type)      # "captcha", "ssl_error", etc.
    print(result.guidance.next_steps)      # ["Try with browser=true", ...]
    print(result.guidance.suggested_request)  # ready-to-use params dict
    if result.guidance.stop_reason:
        print("Don't retry:", result.guidance.stop_reason)
```

## Error Handling
```python
from scrapingpros import SyncClientError, AuthenticationError, QuotaExceededError

try:
    result = client.scrape(url)
except QuotaExceededError:
    print("Credits exhausted — check client.plans() to upgrade")
except AuthenticationError:
    print("Bad token — use demo_6x595maoA6GdOdVb for testing")
except ScrapingProsError as e:
    print(f"SDK error: {e}")
```

## Credit System
- 1 simple request = 1 credit
- 1 browser request = 5 credits
- Failed requests due to infrastructure errors are refunded
- Demo token: 5,000 credits/month
- Check usage: `client.billing()`, view plans: `client.plans()`

## All Methods
| Method | Purpose |
|---|---|
| `scrape(url, ...)` | Scrape URL → HTML or markdown |
| `download(url)` | Download file → base64 |
| `create_collection(name, requests)` | Create batch |
| `run_and_wait(collection_id)` | Execute batch, poll until done |
| `get_job_result(col, run, job)` | Get individual batch result |
| `delete_collection(id)` | Cleanup |
| `create_viability_test(urls)` | Analyze site protections |
| `list_proxy_countries()` | Available proxy countries |
| `plans()` | Pricing and features |
| `billing()` | Monthly usage |
| `health()` | API status |

## Full Reference
See `llms-full.txt` in this repo for complete API documentation with all parameters.
