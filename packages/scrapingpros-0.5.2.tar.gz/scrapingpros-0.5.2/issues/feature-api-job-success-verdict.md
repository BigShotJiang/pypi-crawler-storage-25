# Feature Request — API: Exponer el verdict de success al cliente

**Para:** equipo SP API (Endpoints + Validator)
**De:** SDK team (Lucho)
**Fecha:** 2026-04-24
**Prioridad:** Media — bloquea la última milla de la validación SDK/server del Batch API

---

## Contexto

El 2026-04-24 ustedes deployaron el nuevo criterio oficial de success documentado en `docs.scrapingpros.com/docs/documentation/Asynchronous%20Operations/async_flow`:

> **Success**: "jobs that returned usable content (HTTP 2xx + no captcha/block signal)"
> **Failed**: "worker failures and jobs that completed but whose target returned 4xx/5xx or a block page"
> **Timeout**: "jobs that exceeded the worker-level timeout"
>
> Invariant: `total_requests = success + failed + timeout`

Lo consumimos desde el SDK v0.4.2 (`Batch.iter_results()`) y validamos end-to-end contra un batch mixto de 30 URLs. **El criterio funciona, pero hay un gap de visibilidad** entre lo que el server sabe y lo que el cliente puede deducir.

---

## El problema concreto

Ejecutamos un batch de 30 URLs (easy + medium + hard mix). Al final:

```
Server (criterio oficial):
  success_requests:  10
  failed_requests:   19
  timeout_requests:   0

SDK (heurística client-side `_is_success`):
  success:  16
  failed:   13

Delta: 6 jobs que el server clasifica como failed pero el SDK como success.
```

**Run de referencia para investigar en DB**:
- `collection_id`: `553e10a3-ddcd-452d-8fb4-082aca15f419`
- `run_id`: `a5b00445-c972-4e6f-b96a-39970166abed`

**Los 6 mismatches** — soft-blocks que el server detecta y el SDK no:

| Job | HTTP | Body size | Qué es realmente |
|---|---|---|---|
| `hard-www.google.com` | 200 | 90,174 | Página "Google Search" / CAPTCHA pre-results (no son resultados) |
| `hard-www.google.com` | 200 | 90,336 | idem |
| `hard-www.google.com` | 200 | 89,661 | idem |
| `hard-www.google.com` | 200 | 90,206 | idem |
| `hard-www.google.com` | 200 | 850,039 | Google results con challenge embedded |
| `hard-www.amazon.com` | 200 | 5,169 | "Robot Check" page |

El server los detecta correctamente — tiene rules por dominio (probablemente del HTML Validator) que detectan estos soft-blocks. El SDK no tiene esa información y los cuenta como success.

---

## Por qué el SDK no puede replicar el criterio client-side

El SDK mira los 3 campos que el listing expone: `status_code`, `block_reason`, `protection_stack`/`rule_hits`. En los 6 jobs mencionados, todos tienen:

```python
status_code = 200
block_reason = None
protection_stack = []
rule_hits = []
```

Nada indica que es soft-block. El Validator todavía no está cableando esos fields en `job_executions` (como ya dijeron en §12.C del handoff anterior — "NULL en todas las rows"). Así que el SDK no tiene forma de decidir sin **replicar la lógica de clasificación del server**, lo cual:

1. **Es frágil**: el server cambia rules por dominio sin avisar; el SDK quedaría desactualizado.
2. **Duplica lógica**: tendríamos que mantener un clasificador en 2 lenguajes (Python SDK + lo que sea que use el server).
3. **Rompe el contrato**: la spec dice "HTTP 2xx + no captcha/block signal" pero el "block signal" es opaco para el cliente.

---

## Lo que pedimos

### Opción A (preferida) — `is_success: bool` en `JobExecutionPublic`

Agregar un campo booleano al listing que exponga el verdict que usa el server para `run.success_requests`:

```json
{
  "job_public_id": "...",
  "run_public_id": "...",
  "collection_id": "...",
  "status": "completed",
  "status_code": 200,
  "is_success": false,        // ← NUEVO
  "url": "...",
  "custom_id": "...",
  "queued_at": "...",
  ...
}
```

**Ventajas**:
- El SDK clasifica con 0 logic propia — solo lee `job.is_success`.
- Zero round-trips extra: viene en el mismo listing que el SDK ya pollea cada 5s.
- Agreement con `run.success_requests` garantizado por construcción (`sum(is_success == True) == success_requests`).
- El usuario final del SDK ve lo mismo que ve en la UI / billing.

**Implementación server-side**: la lógica ya existe (es la que popula `success_requests`). Solo exponerla por job.

### Opción B (alternativa) — populate `guidance` en `/jobs/{id}/result`

Hoy `GET /v1/async/collections/{cid}/runs/{rid}/jobs/{jid}/result` **no popula `guidance`** (lo vimos empíricamente: `guidance = None`). Sí lo popula `POST /v1/sync/scrape`.

Alinear: que el async `/result` también devuelva `guidance` con `success`, `error_type`, etc.

```json
{
  "url": "...",
  "html": "...",
  "statusCode": 200,
  "guidance": {                 // ← hoy es null en async
    "success": false,
    "error_type": "soft_block",
    "error_provider": "google",
    ...
  }
}
```

**Ventajas**: contrato unificado entre sync y async.
**Desventaja**: requiere fetch del `/result` para clasificar — más round-trips. El SDK hoy hace ese fetch solo para jobs exitosos; si tiene que fetch también los fallidos para saber si fallaron, duplica tráfico.

### Opción C (mínima) — ambos

`is_success` en el listing **y** `guidance` populado en el `/result`. El SDK usa `is_success` para clasificar (eficiente, sin fetch) y `guidance` cuando el usuario quiere el detalle del error.

**Esto es lo que recomiendo.** Son ~50 líneas de serializer del lado server.

---

## Impacto práctico sin este cambio

- **SDK subcuenta fails**. Hoy reporta 6 soft-blocks como "OK" en batches mixtos con Google/Amazon.
- **Usuario recibe datos inservibles sin marca**: `result.guidance.success = True` mientras el body es una CAPTCHA page → el usuario guarda basura en su DB.
- **Agreement roto con billing**: el usuario ve en `client.billing()` un nro de success distinto al que cuenta localmente.
- **Barrera para "50k URLs, despreocupate"**: parte de nuestro pitch de marketing del Batch API es que "cada result te dice si fue útil o no". Hoy eso es mentira para soft-blocks.

---

## Compatibilidad

**100% aditivo**. Agregar `is_success` a `JobExecutionPublic` es opcional: clientes viejos ignoran el campo; el SDK actualizado lo usa.

Populate `guidance` en `/result` tampoco rompe nada — hoy es `null`, pasa a ser un objeto con `success: bool`. Clientes viejos que ya manejan `guidance` nativo (porque viene del `/sync/scrape`) ganan consistencia.

---

## Plan del SDK

Cuando alguno de los dos cambios esté live:

1. **`is_success` en listing** → SDK v0.4.3: `Batch` usa `job.is_success` directo. `_ensure_guidance` queda como fallback defensivo para jobs viejos sin el campo.
2. **`guidance` en `/result`** → SDK v0.4.3: confiamos en `guidance.success` del server, `_is_success` heurística queda solo como triple-fallback.

**Ambas cubiertas** → v0.4.3 usa `is_success` para clasificar sin fetch (eficiencia), y cuando el user accede `result.guidance.*` lo ve con detalle real del server.

---

## Resumen

| # | Pedido | Prioridad | Esfuerzo server |
|---|---|---|---|
| A | `is_success: bool` en `JobExecutionPublic` | 🔴 alta | Chico (1 serializer) |
| B | populate `guidance` en `/jobs/{id}/result` | 🟡 media | Chico (1 serializer) |
| C | ambos | 🟢 ideal | Chico (2 serializers) |

**Voto del SDK**: opción C. Alinea el contrato sync/async y elimina la única zona donde el SDK tiene que adivinar.

Cuando lo decidan, pingback en este file o abrimos issue separado.

— SDK team

---

## 🟢 Entregado en prod — 2026-04-24

Hicimos **la opción C + un extra** (tu idea original + `success_criterion` metadata en el run para declarar la política activa).

### Commits

- **feat**: `28f8dfb` en master — `is_success` column + flusher + worker write + pydantic + guidance en /result + success_criterion en /runs/{id}`
- **docs**: `52d085a` en master — scrapeo_asincronico.md con los 3 nuevos campos
- **Migration 007**: aplicada (ONLINE DDL, sin downtime)
- **Deploy**: API + flusher + 9 async workers recompilados con el nuevo código

### Lo que ahora podés hacer desde el SDK

1. **`job.is_success` directo en el listing** — sin lógica propia:
   ```python
   for job in client.iter_run_jobs(cid, rid):
       if job.is_success is True:
           save_ok(job)
       elif job.is_success is False:
           log_failed(job)
       else:  # None — pre-migration o edge
           # fallback al heurístico client-side del v0.4.2
           ...
   ```

2. **`run.success_criterion` para pinear la política** — asserteable en tus tests:
   ```python
   run = client.get_run(cid, rid)
   assert run.success_criterion.version == "content_success_v1"
   # Si cambiamos la política, tu test va a fallar explícitamente en CI
   # en vez de divergir silenciosamente.
   ```

3. **`guidance` populado en async `/result`** — parity sync/async:
   ```python
   result = client.get_job_result(cid, rid, job_id)
   if not result.guidance.success:
       print(result.guidance.error_type)       # "site_error" / "captcha" / etc.
       print(result.guidance.next_steps)       # ["Try with browser=true", ...]
       print(result.guidance.suggested_request)
   ```

### Política activa (v1)

`content_success_v1`:
1. `status == 'completed'`
2. `200 <= status_code < 300`
3. `potentiallyBlockedByCaptcha is false`
4. `block_reason is null or 'none'`

Declarado explícitamente en `GET /runs/{id}.success_criterion` de cada run. Si algún día cambiamos la regla bumpamos a `content_success_v2` y los clientes con pin lo ven inmediatamente.

### Semántica `is_success`

| Valor | Qué significa | Cuándo ocurre |
|---|---|---|
| `true` | Cliente recibió HTML usable | 2xx + no captcha/block |
| `false` | Completado pero inútil, o worker failed/timeout | 4xx/5xx, captcha, worker error |
| `null` | Verdict no computado | Rows pre-migration (113 rows del pasado). SDKs nuevos: fallback al heurístico. Rows nuevas nunca son null |

### Invariante

`sum(is_success == True for jobs in run) == run.success_requests` por construcción — el worker usa el mismo `_is_content_success()` para ambos. Si el SDK encuentra que no matchea, **es un bug nuestro**, reportalo acá.

### Smoke end-to-end verificado

Batch de 3 jobs (200 + 500 + 404):

```
run.success_requests  = 1
run.failed_requests   = 2
run.timeout_requests  = 0
run.success_criterion = {version: "content_success_v1", rules: [...]}

listing:
  custom_id=ok        status=completed code=200 is_success=True
  custom_id=fail-500  status=completed code=500 is_success=False
  custom_id=fail-404  status=completed code=404 is_success=False

/result guidance:
  success: False
  error_type: "site_error"
```

Todo alineado.

### Tu turno — SDK v0.4.3

- Reemplazá el heurístico client-side por `job.is_success` con fallback al heurístico cuando es `null`
- Pinneá `success_criterion.version == "content_success_v1"` en tests de integración
- Usá `result.guidance` para error messaging al usuario final
- Si encontrás mismatch con `run.success_requests`, abrí issue acá — reabrimos.

### Billing alignment — pendiente decisión

Mencionamos arriba que Zyte explícitamente **no cobra** responses bloqueadas. Hoy nosotros seguimos cobrando jobs con `is_success=False`. Ese cambio de política queda como **issue separado** — lo alineamos cuando tengamos data de cuántos créditos se reembolsarían (posible hit en revenue corto plazo pero diferencial competitivo).

### Docs live

- [`docs.scrapingpros.com/docs/apiReference/scrapeo_asincronico`](https://docs.scrapingpros.com/docs/apiReference/scrapeo_asincronico) — las 3 novedades documentadas (`is_success`, `success_criterion`, `guidance`)

— Endpoints team (Claude + Lucho)

---

## 🟢 SDK v0.4.3 entregado — 2026-04-24

Issue **cerrado**. Los 3 puntos consumidos end-to-end.

### Release

- **PyPI**: https://pypi.org/project/scrapingpros/0.4.3/
- **GitLab**: merge `20a0fe5` en `main`
- **Commit**: `0b0d15c` (feature branch `feature/0.4.3-success-verdict`)

### Scope implementado

1. **`JobExecutionPublic.is_success: bool | None`** expuesto en el modelo Pydantic del SDK.
2. **`SuccessCriterion` nuevo modelo** con `version` + `rules`. Exportado desde `scrapingpros` package. Agregado como `RunPublic.success_criterion: SuccessCriterion | None`.
3. **`Batch._is_success()` priority chain**:
   ```
   1. job.is_success (server verdict)   → authoritative
   2. result.guidance.success            → trusted (sync + async)
   3. Client heuristic (2xx + body)      → legacy fallback
   ```
4. **`_ensure_guidance()` usa `job.is_success`** como fuente primaria cuando popula `guidance` para results que no lo traen.

### Verdict alignment validado en vivo

Run de referencia `5a5f0f4c-7d5c-415a-90a2-dbe52ca44ec5` (smoke de 3 jobs: 200, 404, 500):

| Field | Server | SDK parse |
|---|---|---|
| `run.success_criterion.version` | `"content_success_v1"` | ✅ |
| `run.success_criterion.rules` (4 reglas) | listadas | ✅ |
| job `ok` (200) `is_success` | `true` | `True` ✅ |
| job `fail-404` `is_success` | `false` | `False` ✅ |
| job `fail-500` `is_success` | `false` | `False` ✅ |

### Tests

224 unit tests (+5 nuevos):
- `test_job_execution_is_success_field` — True / False / None
- `test_success_criterion_on_run_public` — version + rules
- `test_run_public_without_success_criterion` — legacy sin criterion
- `test_batch_trusts_server_is_success_for_soft_blocks` — server dice False, SDK lo honra aunque HTML parezca OK
- `test_batch_falls_back_to_heuristic_when_is_success_none` — legacy runs

### Para el usuario final

**Uso típico** — zero cambios en el código cliente, internamente honra el verdict server:

```python
batch = client.submit_batch("daily", items)
for result in batch.iter_results():
    if result.guidance.success:     # ← server verdict ahora
        save(result)
```

**Pin del criterio en tests de integración**:

```python
run = client.get_run(cid, rid)
assert run.success_criterion.version == "content_success_v1"
```

### Status final

🟢 **Cerrado**. Nueva linea base alineada sync/async + client/server. Si aparece un caso donde `batch.success_count != run.success_requests`, abrimos issue con evidencia.

— SDK team (Lucho + Claude)
