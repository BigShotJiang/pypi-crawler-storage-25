# Feature Request — API: Filtering y ordering en `GET /runs/{id}/jobs`

**Para:** equipo SP API (Endpoints)
**De:** SDK team (Lucho)
**Fecha:** 2026-04-23
**Prioridad:** Alta — habilita UX core del SDK v0.4.0 (`Batch.iter_results()` para batches de 10k–50k URLs)

---

## Contexto

En el SDK estamos diseñando `Batch.iter_results()` para v0.4.0. La promesa al usuario final:

> "Mandá 50,000 URLs. Andá viendo los resultados a medida que se completan. Progress, ETA, failed/timeout, todo transparente."

```python
batch = client.submit_batch("daily-reviews", [
    {"url": tour["url"], "custom_id": tour["id"]} for tour in my_tours
])

for result in batch.iter_results():
    save_to_db(result)
    if batch.completed_count % 100 == 0:
        print(f"{batch.pct:.1f}% — ETA {batch.eta_seconds}s")
```

Internamente el SDK va a pollear `GET /runs/{id}/jobs` para ver cuáles completaron desde la última pasada, hacer fetch del result en paralelo, y yieldear.

**Con la API actual** (v0.3.0) este polling escala mal:

- El cursor es `auto_increment_id` → orden de inserción, **no** de completion.
- Para saber "qué hay de nuevo desde hace 5 segundos" hay que paginar todo el run y dedupear del lado cliente (set de `job_public_id` ya vistos).
- Con 50,000 URLs: 50 pages × 1000 items = **50 API calls cada 5 segundos** → se come el rate limit del plan Scale (200 req/min) en minutos.
- No hay forma de traer "failed + completed + timeout" en una query (el `status_filter` acepta solo 1 valor).

Esto hace que el polling sea costoso tanto para el cliente como para el servidor (cada poll recorre toda la tabla particionada).

---

## Pedidos, en orden de impacto

### 🔴 1. Bloqueante — filter `since_completed_at`

**Propuesta**:

```
GET /v1/async/collections/{cid}/runs/{rid}/jobs
  ?since_completed_at=2026-04-23T12:05:00.123
  &status_filter=completed
  &limit=1000
```

**Semántica**: devolver solo jobs cuyo `completed_at > since_completed_at`.

**Uso desde el SDK**:

```python
# En cada tick de polling:
max_seen = self._last_completed_at  # guardado del poll anterior
page = api.get_jobs(run_id, since_completed_at=max_seen, status_filter="completed")
for job in page.items:
    yield fetch_result(job)
    if job.completed_at > max_seen:
        max_seen = job.completed_at
self._last_completed_at = max_seen
```

**Impacto cuantitativo** (batch de 50,000 URLs, plan Scale, 100 concurrent → ~500 jobs completed por poll de 5s):

| Métrica | Hoy | Con `since_completed_at` |
|---|---|---|
| API calls por poll | ~50 (pagina todo) | ~1 (trae ~500 nuevos) |
| Items transferidos por poll | ~50,000 | ~500 |
| Rate limit consumido | 600/min → hit cap | 12/min → sobrado |
| Memoria en cliente | dedup set creciendo hasta 50k | zero dedup necesario |
| Latencia al ver un job nuevo | ~5s (flusher) + paginación | ~5s (flusher) |

---

### 🔴 2. Bloqueante — `order_by=completed_at` con cursor en ese orden

**Propuesta**:

```
GET /v1/async/collections/{cid}/runs/{rid}/jobs
  ?order_by=completed_at
  &order_dir=asc
  &cursor=<base64 of completed_at timestamp>
  &limit=1000
```

**Semántica**: ordenar por `completed_at ASC` (o `DESC`), con cursor que codifica el timestamp del último visto.

**Por qué además del (1)**: `since_completed_at` es suficiente si los ticks de polling son consistentes. Pero si el cliente se cae y retoma, necesitamos un cursor estable. `order_by=completed_at` + cursor resuelve "reanudá donde te quedaste" sin ambigüedad en caso de ties en timestamp.

Idealmente el cursor es `base64(f"{completed_at}|{job_public_id}")` para desambiguar cuando hay varios jobs con mismo `completed_at` al ms.

**Uso desde el SDK**:

```python
cursor = self._last_cursor  # persisted
while True:
    page = api.get_jobs(run_id, order_by="completed_at", cursor=cursor, limit=1000)
    for job in page.items:
        yield fetch_result(job)
    if not page.has_more:
        break
    cursor = page.cursor_next
self._last_cursor = cursor
```

Esto también habilita **reanudación tras caída del cliente** (feature que pediste para UX de batches grandes):

```python
# Primer run
batch.persist_cursor(db)  # guarda el cursor

# Después de un crash
batch = client.get_batch(col_id, run_id)
batch.resume_from_cursor(db.last_cursor)  # retoma desde donde quedó
```

---

### 🟡 3. Útil — `status_filter` multi-valor

**Propuesta**:

```
GET /v1/async/collections/{cid}/runs/{rid}/jobs
  ?status_filter=completed,failed,timeout
```

**Semántica**: aceptar CSV, devolver jobs cuyo `status` esté en cualquiera de los valores.

**Por qué**: hoy para traer "todo lo terminado" (exitoso o no) hay dos opciones:
- Hacer 3 queries (una por status) → 3× el costo, sin garantía de consistencia de cursor.
- Omitir `status_filter` → también viene `processing`, ruido.

Con multi-valor: 1 query.

**Uso desde el SDK**:

```python
# iter_results(include_all=True) → quiere ver failed y timeout también para que el usuario accione
page = api.get_jobs(run_id, status_filter="completed,failed,timeout",
                     since_completed_at=last_seen, limit=1000)
```

Nota: para `timeout` y `failed` el campo ordenable es `updated_at` o `completed_at` si está seteado. Definir la semántica.

---

### 🟡 4. Útil — reducir round-trips a `/result`

**Problema**: cada job completed requiere un `GET /jobs/{jid}/result` para traer el HTML/markdown. Con 50k jobs = 50k requests individuales (aunque paralelizables del lado cliente).

**Tres opciones para esto, de menor a mayor complejidad**:

**4a. `include_error_detail=true` en el listing** — agregar al response de `/jobs` los campos ya disponibles en DB del HTML Validator para que el cliente pueda **decidir si el result vale la pena fetch-earlo**:

```json
{
  "job_public_id": "...",
  "status": "completed",
  "status_code": 403,
  "block_reason": "captcha_challenge",
  "protection_stack": ["cloudflare"],
  "guidance_summary": {
    "success": false,
    "error_type": "captcha",
    "stop_reason": null
  }
}
```

Con esto, el SDK puede **evitar el fetch de `/result` en jobs bloqueados** si el usuario no lo pide (ahorra 50%+ de round-trips en batches con alto bloqueo).

Los campos ya viven en `job_executions`. Es solo un cambio de serializer.

**4b. `include=result` flag** — que el listing incluya el HTML inline hasta cierto tamaño:

```
GET /jobs?include=result&max_result_size=50000
```

Ahorra round-trips pero infla el response. Solo útil para batches de results chicos.

**4c. Bulk endpoint** `POST /jobs/bulk-fetch`:

```json
{"job_ids": ["j1", "j2", ..., "j100"]}
```

Devuelve los 100 results en un solo response. Reduce overhead HTTP.

**Mi voto**: **(4a)** como prioridad — es trivial server-side y suficiente para que el SDK tome decisiones informadas sin fetch.

---

### 🟢 Nice-to-have — streaming / push

**Propuesta**: un endpoint SSE que el cliente mantiene abierto y recibe eventos push a medida que los jobs completan:

```
GET /v1/async/collections/{cid}/runs/{rid}/stream
  → event: job.completed
    data: {"job_public_id": "...", "url": "...", "custom_id": "...", "status_code": 200}
```

Ventajas: elimina polling completamente, latencia mínima (sub-segundo en vez de 5s del flusher + 5s del poll_interval).

Sé que es más invasivo. **Alternativa aceptable**: el **webhook por job individual** (PR D del handoff async) ya está en roadmap — si sale antes, el SDK puede consumirlo vía un webhook receiver local o un handler HTTP del usuario.

No es bloqueante para v0.4.0 del SDK. Pollear con (1)+(2) funciona bien.

---

## Qué NO pedimos (para evitar scope creep)

- **GraphQL / query language custom**: overkill. REST con filters + ordering alcanza.
- **Filters complejos** tipo `where execution_time_ms > 10000`: innecesarios hoy.
- **Agregaciones server-side** (avg, percentiles): el `RunPublic` ya expone totales. Si hacen falta más, es otro endpoint.
- **Campo "subscription"** en `POST /collections` para "avisame cuando el 10% complete": el SDK ya puede hacerlo del lado cliente con progress callbacks.

---

## Priorización resumida

| # | Feature | Prioridad | Impacto SDK v0.4.0 |
|---|---|---|---|
| 1 | `since_completed_at` filter | 🔴 alta | Bloqueante para batches >1k URLs |
| 2 | `order_by=completed_at` + cursor | 🔴 alta | Habilita reanudación tras crash del cliente |
| 3 | `status_filter` multi-valor | 🟡 media | Reduce queries a 1/3, mejora consistencia |
| 4a | `include_error_detail=true` o flat fields | 🟡 media | Reduce round-trips, mejora latencia |
| 4b | `include=result` inline | 🟢 baja | Nicho |
| 4c | Bulk `/jobs/bulk-fetch` | 🟢 baja | Alternativa a webhook |
| 5 | SSE / streaming | 🟢 baja | Hermoso pero webhook por job ya lo resuelve |

**Mínimo viable para v0.4.0 del SDK**: **(1) + (2)**. Con eso armamos `Batch.iter_results()` production-ready para 50k URLs.

**Ideal**: **(1) + (2) + (3) + (4a)**. Con los 4 el SDK queda con UX comparable a los SaaS grandes de scraping, con menos código del cliente.

---

## Compatibilidad y rollout

- Todos los cambios son **aditivos**. Parámetros nuevos como `since_completed_at`, `order_by`, etc. son opcionales. Clientes existentes no se rompen.
- El cursor formato cambia según `order_by`: si el cliente pasa cursor con un `order_by` distinto al que lo generó, devolver 400 con mensaje explícito ("cursor was generated with order_by=completed_at, received order_by=id").
- Si `order_by` no se especifica, mantener el comportamiento actual (`order_by=id` implícito).

---

## Plan de trabajo paralelo

Mientras el API team evalúa e implementa:

**SDK (paralelo, no bloqueante)**:
- v0.4.0 con `Batch.iter_results()` usando la API actual (polling + full pagination + dedup cliente)
- Interfaz pública diseñada pensando en (1)+(2) — cuando lleguen, es un cambio **solo interno** (`batch.iter_results()` sigue igual, el polling se vuelve eficiente por dentro)
- Beta testing con clientes pequeños (<1k URLs) donde la API actual alcanza

**Cuando (1)+(2) estén en prod**:
- SDK v0.4.1 cambia el polling interno para usar los nuevos filters
- Zero breaking change al usuario final
- Habilitamos marketing de "batches de 50k+ URLs"

---

## Contacto

Lucho (lucho@7puentes.com). Cualquier duda sobre la UX que justifica cada pedido, o si el orden de prioridad necesita reajustarse según costo de implementación del lado server, pregúntenme.

---

## Respuesta del equipo Endpoints (2026-04-23)

Gracias por el write-up — priorización clara, argumento cuantitativo concreto (50 API calls → 1), scope controlado. Facilita decidir.

### Veredicto por ítem

| # | Pedido | Respuesta | Racionale |
|---|---|---|---|
| **1** | `since_completed_at` filter | ✅ **Aprobado**. Implementamos en próximo sprint corto (≤ medio día) | Simple: `WHERE completed_at > :since` + índice. El gap de rate limit que mencionás es real — saturar 600 req/min al plan Scale con un solo batch no es aceptable |
| **2** | `order_by=completed_at` + cursor compuesto | ✅ **Aprobado**. Mismo sprint | Cursor `base64(f"{completed_at}|{job_public_id}")` con desambiguación de ties. Habilita el "resume from crash" que también pediste hace 2 semanas. Una piedra, dos pájaros |
| **3** | `status_filter` multi-valor CSV | ✅ **Aprobado**. Mismo sprint | Trivial (`WHERE status IN (...)`). Sumalo a la query, mejor consistencia que 3 round-trips |
| **4a** | `block_reason`, `protection_stack`, `rule_hits` en listing | ⚠️ **Ya está** (parcial) | Commit `bcc2779` (2026-04-23) ya expone los 3 campos con serializer defensivo. Lo único no implementado es el objeto `guidance_summary` consolidado — pero el cliente puede computarlo del lado SDK con los 3 campos crudos (`is_success = status == "completed" and 200 <= status_code < 300 and block_reason is None`). **Si insisten en el objeto server-side**, decinos por qué — no estamos convencidos que agregue valor sobre los campos crudos |
| **4b** | `include=result` inline en listing | ❌ **Rechazado** | Un listing con 1000 × HTML de 2 MB = 2 GB por response. Inviable. Si hay un caso concreto con results chicos (JSON de 1-5 KB) podemos reconsiderar via un flag con `max_result_size` estricto (e.g. 50 KB hard cap), pero preferimos (4c) |
| **4c** | Bulk `POST /jobs/bulk-fetch` | ⏸️ **Deferido** | Útil pero no es el 80/20 de v0.4.0. Si (1)+(2) achican el problema lo suficiente, puede esperar a v0.5.0. Si no, lo retomamos |
| **5** | SSE streaming | ⏸️ **Deferido — misma decisión que webhook-per-job** | Convergen al mismo dominio: "cómo entrega el servidor updates sin polling". El webhook-per-job (PR D) está pausado en `handoff-async-fields-and-methodpost-url.md` §12.F.2 pendiente de decidir entre per-job / per-batch / SSE / hybrid. Cuando salga esa decisión, si el veredicto es SSE lo implementamos y (5) queda cubierto. Si el veredicto es webhook per-batch/hybrid, SSE queda como roadmap separado |

### Impacto cuantitativo que te damos de vuelta

Con (1)+(2)+(3) implementados y un batch de 50k URLs:

| Métrica | Hoy | Con (1)+(2)+(3) |
|---|---|---|
| API calls por poll | ~50 | ~1 |
| Bytes/poll | ~50 MB | ~500 KB |
| Rate limit consumido | 600/min (hit cap) | 12/min |
| Latencia end-to-end (job completo → SDK lo ve) | 5s flusher + ~10s paginación | 5s flusher + ~100ms query |

Tus números pero confirmados de nuestro lado 👍

### Plan concreto

**Sprint de Endpoints** (próxima ventana disponible — mañana 2026-04-24 probablemente):

1. **Migration**: `migrations/006_job_executions_completed_at_index.sql`
   ```sql
   ALTER TABLE job_executions
     ADD INDEX idx_run_completed (run_public_id, completed_at, job_public_id);
   -- InnoDB ONLINE DDL (ALGORITHM=INPLACE, LOCK=NONE). No bloquea writes.
   -- Como la tabla está particionada por mes, el índice se crea por partición.
   ```

2. **Endpoint** `api/versions/v1/api_v1.py::list_run_jobs`:
   - Aceptar `since_completed_at` (ISO 8601, validar parse)
   - Aceptar `status_filter` como CSV (parse + validar cada valor)
   - Aceptar `order_by=id|completed_at` (default `id` para back-compat)
   - Cursor encoding:
     - `order_by=id`: base64 de int (como hoy, SIN cambios)
     - `order_by=completed_at`: `base64(f"{completed_at_isoformat}|{job_public_id}")`
   - Validación cross-field: si `cursor` decodea a un formato que no matchea el `order_by` → 400 con mensaje `"cursor was generated with order_by=X, received order_by=Y; start a new pagination"`
   - Rechazar combinaciones raras: `order_by=completed_at` + status_filter que incluye `processing` → el orden es indeterminado para processing (completed_at NULL). **Nuestro comportamiento**: NULLs van al final (MySQL default), documentar que mixing order_by=completed_at con `processing` es "al cliente le toca filtrar"

3. **Tests de integración** (`tests/integration/test_jobs_filtering.py`):
   - `test_since_completed_at_filters_correctly`
   - `test_order_by_completed_at_stable_cursor` (2+ jobs con mismo `completed_at` al ms, verificar que paginación no los saltea ni duplica — test crítico)
   - `test_status_filter_csv_multi_value`
   - `test_cursor_mismatch_order_by_returns_400`
   - `test_order_by_default_is_id_backcompat` (requests sin `order_by` se comportan como hoy)

4. **Docs**: actualizar `apiReference/scrapeo_asincronico.md` + `Asynchronous Operations/runs.md` con los nuevos params + patrón de uso.

5. **Deploy**: migration primero (online), luego endpoint.

### Edge cases que queremos firmar con ustedes antes

- **A. `completed_at = NULL` en jobs `processing`**: con `order_by=completed_at ASC`, MySQL los pone al final. ¿OK o prefieren exclusión explícita (`WHERE completed_at IS NOT NULL`)? Mi voto: **exclusión explícita**, porque el caso de uso es iterar jobs completados, no ver los processing en el medio.

- **B. Cursor estabilidad con `completed_at` en microsegundos**: MySQL DATETIME(3) guarda milisegundos. Dos jobs pueden completar en el mismo ms → cursor necesita `job_public_id` como tie-breaker. ¿Confirman que con el cursor compuesto `(completed_at, job_public_id)` el SDK queda cubierto?

- **C. `since_completed_at` en formato**: ¿aceptamos solo ISO 8601 string? ¿O también epoch ms int? Mi voto: **ISO 8601 solamente** — más legible en URLs, menos ambigüedad. El SDK convierte de datetime → ISO antes de mandarlo.

- **D. `status_filter=all` o `status_filter=completed,failed,timeout` como forma canónica de "todo lo terminado"?** Mi voto: **CSV explícito** para evitar magia. No agregar `all` como keyword especial.

### Decisión final necesitamos de tu lado (Lucho/SDK)

1. ¿OK con los 4 edge cases de arriba (A, B, C, D)?
2. Sobre (4a) `guidance_summary` objeto consolidado: ¿insiste el SDK en tenerlo server-side, o alcanza con que compute client-side desde los 3 campos crudos que ya expone el listing?
3. ¿Sprint timing OK para v0.4.0? (Nosotros podemos entregar en ≤ 1 día dev después del cierre del sprint actual)

Cuando confirmes los 4 edge cases, arrancamos. Gracias por la priorización y los números concretos — facilita mucho la decisión.

— Endpoints team (coordinado por Claude + Lucho)

---

## Respuesta del SDK team (2026-04-23)

Gracias por la vuelta rápida. Los 3 bloqueantes aprobados resuelven el 100% del problema que teníamos para v0.4.0. Paso confirmación punto por punto:

### Edge cases — confirmo los 4

**A. `completed_at = NULL` con `order_by=completed_at`**: **exclusión explícita**. Coincido. Si el cliente usa `order_by=completed_at`, conceptualmente está pidiendo "jobs terminados en orden cronológico". Un `processing` ahí es ruido. El cliente que necesite ver processing los pide aparte con `status_filter=processing`. El SDK ya lo maneja así — nuestros use cases de `batch.iter_results()` nunca necesitan processing en el stream.

**B. Cursor compuesto `(completed_at, job_public_id)`**: **confirmado que cubre al SDK**. Con el tie-breaker no hay ambigüedad. El cliente guarda `cursor_next` opaco y lo manda tal cual al siguiente poll — zero parsing del lado SDK. 👍

**C. `since_completed_at` formato ISO 8601 only**: **coincido**. ISO es más legible en URLs, Pydantic ya parsea `datetime ↔ ISO` automáticamente, epoch ms genera bugs de TZ. El SDK internamente trabaja con `datetime` y serializa a ISO al poner el query param.

Sugerencia menor: aceptar ISO 8601 con o sin timezone offset (`2026-04-23T12:05:00.123` y `2026-04-23T12:05:00.123Z` y `2026-04-23T12:05:00.123+00:00`) — Pydantic los parsea los 3. Si el server los trata como naive UTC, documentarlo claro en el error 400 cuando no parsea.

**D. CSV explícito sin `all` keyword**: **coincido**. `all` es magia que envejece mal (¿qué pasa cuando agreguen un status nuevo?). CSV es explícito y el SDK puede abstraerlo con un helper:

```python
# SDK usage — helper keeps it tidy
for result in batch.iter_results(include_failed=True):
    # internally: status_filter="completed,failed,timeout"
```

### Sobre (4a) — `guidance_summary` consolidado

**No insisto**. Confirmo que con los campos crudos (`status`, `status_code`, `block_reason`, `protection_stack`, `rule_hits`) el SDK computa el `is_success` client-side sin problema. Lógica:

```python
def _compute_success(job: JobExecutionPublic) -> bool:
    return (
        job.status == "completed"
        and job.status_code is not None
        and 200 <= job.status_code < 300
        and not job.block_reason
    )
```

Eso va a quedar en el SDK como detalle interno, oculto al usuario final (que solo ve `result.guidance.success`). Si en el futuro aparece un caso donde el server tiene más info que el cliente (ej. reglas de validator que no expone) podemos reabrir — por ahora, no es necesario.

### Sobre timing

**Tu timeline `≤ 1 día dev después del sprint actual` nos viene perfecto**. Nuestro plan:

- **SDK v0.4.0 sale primero** (esta semana) con polling fallback (full pagination + dedup cliente). Para batches <1k URLs es aceptable, >10k URLs sufre pero funciona. Lo marcamos en docs como "optimized for batches up to 1000 URLs; for larger batches, v0.4.1 will use efficient server-side filtering".

- **Cuando ustedes entreguen (1)+(2)+(3)** en prod, sacamos **v0.4.1 en el mismo día**. Solo cambia el internal de `batch.iter_results()`. API pública del SDK (`submit_batch`, `iter_results`, progress attributes) queda **idéntica** — clientes existentes no ven nada.

- **Habilitar marketing "50k+ URLs batches"** una vez v0.4.1 esté live y tengamos una corrida real de validación (batch de 10k-50k URLs con métricas de rate limit consumido).

### Una pregunta de vuelta

Sobre el cursor compuesto: el SDK va a querer **persistir** el `cursor_next` para reanudar tras crash del cliente. Confirmen que:

1. **Ventana de validez del cursor**: ¿hay TTL del cursor (ej. expires after 7 días)?, o mientras la partición de `job_executions` exista (90 días por retention), el cursor sigue válido?
2. **Estabilidad entre versiones del API**: si hacen un redeploy con cambios al schema del cursor, ¿los cursors viejos quedan inválidos (400)?, o se mantiene compat?

Mi expectativa razonable: **cursor válido hasta que la partición se DROP-ee (90 días)**, y **inmutable entre deploys mientras no cambien el encoding**. Si eso es así, no hay más preguntas — el SDK guarda el cursor y reanuda cuando sea.

### Decisión final

**OK los 4 edge cases (A, B, C, D)**, **OK el alcance (1)+(2)+(3)**, **OK (4a) con campos crudos sin `guidance_summary`**, **OK el timing**. Pueden arrancar el sprint cuando tengan la ventana. Avísenme cuando mergeen para que SDK v0.4.1 dispare release coordinado.

— Lucho (SDK team)

---

## Respuesta Endpoints team (2026-04-23, firma final)

Cerramos.

### Sobre los 4 edge cases

Aprobados y firmados. Tu sugerencia menor sobre `since_completed_at` la absorbemos: **aceptamos las 3 variantes ISO 8601** (`2026-04-23T12:05:00.123`, `...Z`, `...+00:00`). Pydantic ya parsea las 3 nativamente con `datetime`. Si viene sin tz, la tratamos como **UTC** (documentado en el error y en el swagger). Si viene con tz distinto a UTC, la normalizamos a UTC antes del WHERE.

### Sobre tus 2 preguntas del cursor

**1. Ventana de validez del cursor — TTL:**

**No tiene TTL.** El cursor `base64(f"{completed_at_iso}|{job_public_id}")` es un **puntero a una frontera temporal**, no a un row específico. La query hace `WHERE (completed_at, job_public_id) > (:cursor_ts, :cursor_id)` — si el row exacto fue DROP-eado por retention, el cursor igual funciona: devuelve todo lo posterior a ese timestamp.

Implicancias prácticas:
- Guardás el cursor el lunes, el cliente crashea, reanuda el jueves → funciona ✅
- Guardás el cursor hoy, la partición del mes actual sigue viva 30 días → funciona ✅
- Guardás el cursor, pasan 100 días, la partición ya fue DROP-eada por retention → el cursor "pasó del final", la query devuelve vacío sin error (`items: []`, `has_more: false`). El SDK lo ve como "terminé" y no reanuda nada — esperable.

Cursor inválido sintácticamente (base64 malformado, no parsea) → 400 explícito.

**2. Estabilidad entre deploys:**

**El formato del cursor para `order_by=completed_at` queda fijado** en este contrato:

```
cursor_value = base64_urlsafe(f"{completed_at.isoformat(timespec='milliseconds')}|{job_public_id}")
```

**Compromiso explícito**: mientras el API mantenga `order_by=completed_at` como feature soportada, el encoding queda igual. Un cursor guardado hoy es válido después de cualquier deploy rutinario.

**Si algún día cambiamos el encoding** (ej. agregamos HMAC, cambiamos separador, agregamos un version prefix), lo tratamos como **breaking change con bump de version del endpoint** (`/v2/async/...`) **y con deprecation window de 90+ días** para que el SDK migre. No rompemos cursors silenciosamente.

**Cursor con `order_by=id`** (el default, back-compat): también estable. Sigue siendo `base64(str(auto_increment_id))`.

### Sobre HMAC del cursor (mencionado en §11.4 del handoff anterior)

Para contexto: en el handoff previo consideramos HMACear el cursor para prevenir enumeración cross-run. Quedó como backlog. **Con el nuevo cursor compuesto por `completed_at`, decidimos mantenerlo sin HMAC** por ahora — mismas razones que antes (ACL por `run_public_id` + auth token alcanza como defensa base).

Si en el futuro hacemos HMAC, lo hacemos para ambos tipos de cursor a la vez y lo anunciamos con breaking window.

### Estado final del pedido

| # | Ítem | Estado |
|---|---|---|
| 1 | `since_completed_at` | ✅ arrancamos |
| 2 | `order_by=completed_at` + cursor compuesto | ✅ arrancamos |
| 3 | `status_filter` multi-valor CSV | ✅ arrancamos |
| 4a | Campos crudos en listing | ✅ ya está (desde `bcc2779`) |
| 4b | `include=result` inline | ❌ rechazado |
| 4c | Bulk `/jobs/bulk-fetch` | ⏸️ deferido a v0.5.0 |
| 5 | SSE streaming | ⏸️ converge con webhook design (§12.F.2 del otro handoff) |

### Timing de release

1. Cerramos primero el sprint actual (fix download + test run estable). Es cuestión de ~30 min.
2. Arrancamos (1)+(2)+(3). Media jornada dev + migration online + tests + deploy.
3. Te avisamos acá mismo cuando esté live. **A partir de ese mensaje, tenés ~12-24h de ventana para sacar v0.4.1**.

### Acción nuestra

Vamos. No necesito nada más del SDK team para arrancar. Si durante la implementación surge un edge case que no previmos, lo levantamos acá en el file; si no, firmamos con un 🟢 cuando mergee.

— Endpoints team (Claude + Lucho)

---

## 🟢 Entregado en prod — 2026-04-24 00:30 UTC

Todo el scope acordado está **live**. Pueden disparar SDK v0.4.1 cuando quieran.

### Commits

- **API**: `bc11750` en master (`feat(async): filters and ordering on GET /runs/{id}/jobs (SDK v0.4.0 ask)`)
- **Migration**: `migrations/006_job_executions_completed_at_index.sql` aplicada en MySQL de prod. Índice compuesto `idx_run_completed (run_public_id, completed_at, job_public_id)` — ONLINE DDL, sin downtime.

### Features activas en prod

- ✅ **`since_completed_at`** (ISO 8601 con `Z`, `+00:00`, o naive-UTC)
- ✅ **`order_by=completed_at`** + `order_dir=asc|desc`
- ✅ **Cursor compuesto** `base64("<iso_ts>|<job_public_id>")` con tie-breaker por `job_public_id`
- ✅ **`status_filter` CSV** (`completed,failed,timeout`) + single-value back-compat
- ✅ **Cross-validation de cursor vs order_by** (400 con mensaje explícito si mezclás)
- ✅ **NULL completed_at excluido** cuando `order_by=completed_at` (los `processing` no contaminan el stream)
- ✅ **order_by default = `id`** (back-compat — clientes sin `order_by` se comportan exactamente igual que v0.3.0)

### Smoke verificado end-to-end

| Caso | Resultado |
|---|---|
| `order_by=id` default (legacy) | ✅ ítems en orden de inserción |
| `order_by=completed_at` con 3 jobs | ✅ ordenados asc por `completed_at` (`00:23:00.540` → `00:23:01.210` → ...) |
| `status_filter=completed,failed,timeout` | ✅ 200, union de estados |
| `since_completed_at=2020-01-01T00:00:00.000Z` | ✅ 200 |
| `since_completed_at=not-a-date` | ✅ 400 con mensaje claro |
| `status_filter=completed,bogus` | ✅ 400 nombrando el inválido |
| `order_by=bogus` | ✅ 400 con lista de valores permitidos |
| `order_dir=sideways` | ✅ 400 |

### Docs actualizadas

- `docs.scrapingpros.com/docs/apiReference/scrapeo_asincronico` — sección completa de los nuevos params + ejemplo de polling incremental con los 3 filtros combinados.
- `docs.scrapingpros.com/docs/documentation/Asynchronous Operations/runs` — tabla de query params actualizada.

### Edge cases firmados en la implementación

- **A. NULL completed_at**: excluidos automáticamente cuando `order_by=completed_at` (como acordamos)
- **B. Cursor estable con tie-breaker `job_public_id`**: implementado. `ORDER BY completed_at ASC, job_public_id ASC` con `WHERE (completed_at > :ts) OR (completed_at = :ts AND job_public_id > :jid)` — row-wise, sin saltar ni duplicar rows
- **C. ISO 8601 multi-formato**: acepta `Z`, `+00:00`, o naive → todos normalizados a naive-UTC antes del WHERE
- **D. CSV explícito**: sin keyword `all`; un valor inválido en el CSV → 400 nombrando cuál

### Cursor validez y estabilidad (tu pregunta #1 y #2)

- **Sin TTL**. El cursor es un puntero a una frontera temporal, no a un row específico. Sigue válido mientras la query pueda resolver `WHERE (completed_at, job_public_id) > (:ts, :jid)`. Si la partición se DROPea por retention (90d), la query devuelve `items: []` sin error.
- **Estable entre deploys rutinarios**. El encoding queda congelado: `base64("<iso_ts>|<job_public_id>")`. Si alguna vez cambiamos el encoding, va a ser breaking con bump de version de endpoint + deprecation window de 90d — nunca silencioso.

### Tu turno

1. Disparen **v0.4.1** cuando quieran. Scope ≈ cambio interno de `Batch.iter_results()` para usar los 3 filtros nuevos. API pública del SDK sigue igual.
2. Cuando release esté en PyPI, avisen acá con link + actualizamos el handoff principal. Con eso el issue queda cerrado 🟢.
3. Si en la migración del polling interno descubren algún edge case que no cubrimos, abran issue o pingback acá — reabrimos con la regla de recirculación.

— Endpoints team (Claude + Lucho)

---

## 🟢 SDK v0.4.1 entregado — 2026-04-24

Consumido todo el scope del API release `bc11750`. **Issue cerrado.**

### Release

- **PyPI**: https://pypi.org/project/scrapingpros/0.4.1/
- **GitLab**: merge `cc75412` en `main` del SDK
- **Commits**: feature branch `9a8d314` (luego rebase + merge como `cc75412`)

### Scope implementado

- `_fetch_jobs_page` (sync + async) acepta:
  - `since_completed_at: datetime | str | None` — serializa ISO 8601 con milisegundos
  - `order_by: Literal["id", "completed_at"] | None`
  - `order_dir: Literal["asc", "desc"] | None`
  - `status_filter: str | list[str] | None` — lista se convierte a CSV
- `Batch._collect_new_terminal_jobs()` (sync + async) refactorizado:
  - Usa `order_by=completed_at&order_dir=asc` + cursor compuesto
  - `status_filter="completed,failed,timeout"` cuando `include_failed=True` (default), o `"completed"` cuando `False`
  - Persistencia interna de `batch._last_cursor` entre polls
  - Eliminado el dedup cliente (el cursor lo garantiza server-side)
- `Batch.failed_count` hace fallback a `RunPublic.failed_requests + timeout_requests` cuando `include_failed=False` (el SDK no ve los failed localmente, pero reporta el total correcto del servidor)
- **Zero breaking changes**: API pública (`submit_batch`, `iter_results`, progress attrs, callbacks) idéntica a v0.4.0

### Edge cases validados contra el contrato firmado por ustedes

| Edge case | Cómo lo cubre el SDK |
|---|---|
| **A. NULL completed_at con `order_by=completed_at`** | Confiamos en la exclusión explícita del server. El SDK nunca ve processing jobs en el stream |
| **B. Cursor compuesto con tie-breaker** | `batch._last_cursor` se guarda opaco, tal cual lo devuelve el server. Zero parsing del lado SDK |
| **C. ISO 8601 multi-formato** | Usamos `datetime.isoformat(timespec="milliseconds")` — Pydantic ya produce formato aceptado |
| **D. CSV explícito sin `all` keyword** | El SDK arma el CSV desde `include_failed` (bool) — el usuario no ve el detalle |

### Tests

- 219 unit tests totales (+2 específicos para v0.4.1):
  - `test_polling_sends_cursor_order_by_and_status_csv` — verifica que la query tenga `order_by=completed_at&order_dir=asc&status_filter=completed%2Cfailed%2Ctimeout`
  - `test_polling_advances_cursor_across_ticks` — verifica que el `cursor_next` del tick N se envía como `cursor` del tick N+1, y queda persistido en `batch._last_cursor`

### Impacto que prometimos en el pedido original, ahora live

Para batches grandes (50k URLs, plan Scale, 100 concurrent jobs):

| Métrica | v0.4.0 (full pagination + dedup) | v0.4.1 (cursor incremental) |
|---|---|---|
| API calls por poll | ~50 | ~1 |
| Bytes por poll | ~50 MB | ~500 KB |
| Rate limit consumido | 600/min (hit cap) | 12/min (sobrado) |
| Memoria cliente | dedup set crece a 50k | zero (cursor server-side) |

### Docs

- Docs publicadas en `docs.scrapingpros.com/docs/documentation/Python SDK/batch-api` (sin cambios visibles para el usuario final — scope es interno)
- `issues/feature-api-jobs-filtering-ordering.md` (este archivo) queda como referencia del contrato

### Roadmap siguiente (backlog, no bloquea nada)

- **4c — Bulk `/jobs/bulk-fetch`**: cuando el volumen real de batches grandes muestre que los 50k round-trips individuales a `/result` son un cuello de botella, abrimos issue para este endpoint
- **5 — SSE streaming / webhook per-job**: cuando `handoff-async-webhook-delivery-design.md` decida entre per-job/per-batch/SSE, el SDK consume lo que resulte (probablemente v0.5.0)

### Estado final del issue

🟢 **Cerrado**. Todos los puntos del pedido original entregados:

| # | Ítem | Estado |
|---|---|---|
| 1 | `since_completed_at` filter | ✅ server live + SDK v0.4.1 consumiéndolo |
| 2 | `order_by=completed_at` + cursor compuesto | ✅ server live + SDK v0.4.1 consumiéndolo |
| 3 | `status_filter` multi-valor CSV | ✅ server live + SDK v0.4.1 consumiéndolo |
| 4a | Campos crudos en listing | ✅ ya estaba desde v0.3.0 (`bcc2779`) |
| 4b | `include=result` inline | ❌ rechazado por el API team |
| 4c | Bulk `/jobs/bulk-fetch` | ⏸️ deferido a v0.5.0 |
| 5 | SSE streaming | ⏸️ converge con webhook per-job design |

— SDK team (Lucho + Claude)
