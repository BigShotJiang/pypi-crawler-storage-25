# Respuesta a los bug reports — `message: null` + lag `run=completed` vs `/jobs`

**Autor:** Endpoints team (Lucho) · **Fecha:** 2026-04-24
**Estado:** 🟢 **Bugs API resueltos en prod**; Bug 2 del SDK queda del lado SDK team.
**Commits relevantes:** [`befbde9`](https://gitlab.com/7Puentes/scraping-pros-api/-/commit/befbde9) (deploy 2026-04-24 ~17:30 UTC-3)

---

## §0 TL;DR

Gracias por los reports, prolijos y con repro. Analizamos los tres:

| # | Bug | Diagnóstico | Acción |
|---|---|---|---|
| **API** | `run.status=completed` pero `GET /jobs` vacío hasta ~5s | Real. Fix del lado del API. | ✅ Resuelto en `befbde9`. Gap medido pre-fix: **4.7 s**. Gap post-fix: **0.00 s**. |
| **SDK #1** | `ScrapeResponse.message` no acepta `null` | Real. **Fix del lado del API, no del SDK** — el endpoint async emitía `message=null` en algunos paths. | ✅ Resuelto en `befbde9`. El endpoint ahora garantiza `message: str` no-nulo siempre. SDK no necesita tocar su modelo. |
| **SDK #2** | `iter_results()` pierde jobs rápidos (race vs `is_finished`) | Real pero **lógica interna del SDK**. El API ya expone `run.job_ids` como path primario. | Pendiente del SDK team. Ver §3. |

Filosofía aplicada: no queremos que el SDK emparche comportamientos que deban cambiar del lado del API. Si fixeamos solo en el SDK, los clientes que nos consumen directo (cURL, OpenAPI codegen, SDKs en otros lenguajes) siguen rotos.

---

## §1 Bug API — lag de consistencia `run=completed` vs `/jobs`

### Causa raíz

Arquitectura async:

- `run:{id}` (Redis hash): counters + `status`. Actualizado por el worker.
- `job_executions` (MySQL, particionada): metadata por job, consultada por `GET /runs/{id}/jobs`.
- Entre las dos: un **buffer** (`job_executions_buffer` en Redis) y un **flusher** (`sp-metrics-flusher-1`) que batchea cada 5 s.

El orden del worker **antes del fix** era (para cada job que terminaba):

1. `_bump_run_counter` — HINCRBY en `run:{id}`.
2. `_check_run_completion` — si counters al total → **HSET `status=completed` INMEDIATAMENTE**.
3. `_write_job_execution_buffer` — LPUSH al buffer.

Es decir, el run se flipeaba a `completed` **antes incluso de que el último job entrara al buffer**, y el flusher recién lo escribía a MySQL hasta 5 s después. De ahí el 4.7 s que mediste.

### Fix (commit [`befbde9`](https://gitlab.com/7Puentes/scraping-pros-api/-/commit/befbde9))

Dos partes:

1. **Reordenar** los tres branches del worker (`FAILED_FINAL`, content-success, exception) para que `_write_job_execution_buffer` ocurra **antes** de `_check_run_completion`.
2. Dentro de `_check_run_completion`, cuando los counters indican que el run terminó, **drenar el buffer sincrónicamente a MySQL** (reusando `flush_job_executions` del flusher con una conexión pymysql local del worker) **antes** de hacer el HSET `status=completed`. El flusher periódico sigue corriendo normal en paralelo; esto solo lo pre-empta en la transición final.

### Garantía nueva

> Cuando `GET /runs/{id}` devuelve `status: "completed"`, `GET /runs/{id}/jobs?status_filter=completed,failed,timeout` devuelve **todos** los jobs del run inmediatamente.

El "lag de ~5 s" que figuraba documentado en el endpoint (frase "Jobs appear in the listing within ~5s of completion (flusher lag)") aplica ahora solo mientras el run está `in_progress` — no más en la transición a `completed`.

### Medición post-fix

```
smoke post-fix (1 URL a httpbin.org/get):
  run=completed   en t=36.0s
  /jobs populated en t=36.0s
  GAP = 0.00s
```

### Safety

- El flush sincrónico es best-effort: cualquier falla (p. ej. MySQL conn drop) cae al comportamiento anterior (el flusher periódico recoge más tarde). Nunca bloquea la completion del run.
- Latencia adicional: una query batch en el job que cierra el run, típicamente < 200 ms. Sin impacto en runs en curso.
- Sin contención con otros workers ni con el flusher: `RPOP` del buffer es atómico.

---

## §2 Bug SDK #1 — `message: null` rompe `ScrapeResponse`

### Causa raíz

El endpoint async `GET /runs/{id}/jobs/{job_id}/result` devolvía `"message": result.get("message")` sin fallback. En un scan de 500 `job:*` activos en Redis, 16 (~3 %) tenían un `result` sin la key `message` — estados parciales, edge cases de retry/timeout.

El schema público `ScrapeResponse` declara `message: str` (no-Optional). El endpoint mentía sobre su propio contrato.

### Fix (mismo commit `befbde9`)

En el endpoint, fallback explícito:

```python
"message": (
    result.get("message")
    or job.get("error")
    or ("Completed" if job.get("status") == "completed"
        else f"Job {job.get('status') or 'unknown'} without details")
),
```

El contrato `message: str` no-nulo vuelve a ser verdadero. Confirmado en mix test (200/404/500):

```
  job code=200 msg='OK'
  job code=404 msg='NOT FOUND'
  job code=500 msg='INTERNAL SERVER ERROR'
```

### Recomendación para el SDK team

**No necesitan hacer el cambio a `message: str | None = None` en `scrapingpros/models.py`.** El API ahora garantiza el invariante. Mantener `message: str` es correcto y consistente con el contrato.

Si prefieren tirar una red extra ante el caso de APIs legacy pre-`befbde9`, pueden hacerlo, pero no es un bloqueante.

---

## §3 Bug SDK #2 — `iter_results()` pierde jobs rápidos

Acá sí es lógica del SDK. El endpoint `GET /runs/{id}` ya incluye `run.job_ids` en la respuesta (schema `RunPublic`), que es el path recomendado para consumir resultados sin depender del listing paginado.

Dos opciones para el SDK, cualquiera resuelve:

**Opción A** — seguir con `iter_results()`, pero agregar un poll final al detectar `is_finished` antes de romper el loop. Ahora que el API garantiza `completed ⇒ /jobs populated`, ese poll final siempre va a traer los jobs pendientes.

**Opción B** — reemplazar la implementación actual por el flow que ya tienen documentado como workaround:

```python
run = client.run_and_wait(collection.id, ...)
for job_id in run.job_ids:
    result = client.get_job_result(collection.id, run.run_id, job_id)
```

No requiere listar `/jobs`, va directo a los ids que vienen en `RunPublic`. Más simple, deterministic, sin carrera.

Nuestro voto es Opción B — es menos código, más robusto, y alinea el SDK con el contrato público. Pero es decisión suya.

---

## §4 Verificación

- Smoke post-fix: ✅ Bug API y Bug SDK #1 resueltos (medidos arriba).
- Logs de workers post-deploy: zero "Pre-completion flush failed" en ~10 min de tráfico productivo; múltiples `Run completed` loggeados con el nuevo path.
- Regresión: test runner suite completo lanzado, reporta al terminar.

---

## §5 Cierre

- Los dos bugs del API ya están cerrados en prod al día 2026-04-24.
- El bug SDK #2 queda del lado del SDK team para elegir entre Opción A/B.
- Cualquier duda, avisen por este mismo archivo (siguiendo la convención §12.X del handoff protocol).
