# Feature Request — SDK Python: Trazabilidad de URL en modelos de Collections

> **Dependencia:** Este cambio requiere que la API primero retorne el campo `url`
> en los endpoints correspondientes. Ver `feature-api-url-traceability.md`.

## Contexto

Al usar el flujo de async collections con el SDK de Python, los modelos `JobExecutionPublic` y `ScrapeResponse` no exponen la URL de origen del job. Esto impide mapear resultados a entidades de la base de datos sin depender del orden de las listas retornadas por la API.

---

## Cambio 1 — `JobExecutionPublic`: agregar campo `url` (P1 — Bloqueante)

### Modelo actual (`scrapingpros/models.py`)

```python
class JobExecutionPublic(BaseModel):
    job_public_id: str
    run_public_id: str
    collection_id: str
    status: Literal["processing", "completed", "failed", "timeout"]
    status_code: int | None = None
    message: str | None = None
    execution_time_sec: float | None = None
```

### Modelo propuesto

```python
class JobExecutionPublic(BaseModel):
    job_public_id: str
    run_public_id: str
    collection_id: str
    url: str                  # ← nuevo campo
    status: Literal["processing", "completed", "failed", "timeout"]
    status_code: int | None = None
    message: str | None = None
    execution_time_sec: float | None = None
```

---

## Cambio 2 — `ScrapeResponse`: agregar campo `url` (P2 — Recomendado)

### Modelo actual (`scrapingpros/models.py`)

```python
class ScrapeResponse(BaseModel):
    html: str | None = None
    markdown: str | None = None
    statusCode: int | None = None
    message: str
    screenshot: str | None = None
    executionTime: float | None = None
    extracted_data: dict[str, Any] | None = None
    evaluate_results: list[Any] | None = None
    network_requests: list[dict[str, Any]] | None = None
    potentiallyBlockedByCaptcha: bool | None = None
    timings: dict[str, Any] | None = None
    guidance: ScrapeGuidance | None = None
```

### Modelo propuesto

```python
class ScrapeResponse(BaseModel):
    url: str | None = None    # ← nuevo campo
    html: str | None = None
    markdown: str | None = None
    # ... resto sin cambios
```

Aplica tanto a `scrape()` / `scrape_many()` (sync) como a `get_job_result()` (async collections).

---

## Impacto en el código del usuario

### Antes (workaround frágil — depende del orden)

```python
run = client.run_and_wait(collection_id)

# Asume que job_ids respeta el orden de inserción — no documentado
for stream, job_id in zip(my_streams, run.job_ids):
    result = client.get_job_result(collection_id, run.run_id, job_id)
    save_to_db(result, stream)
```

### Después (explícito y seguro)

```python
run = client.run_and_wait(collection_id)
jobs = client.get_run_jobs(collection_id, run.run_id)

job_by_url = {j.url: j for j in jobs.items}  # ← posible gracias al nuevo campo

for stream in my_streams:
    job = job_by_url[stream["url"]]
    if job.status == "completed":
        result = client.get_job_result(collection_id, run.run_id, job.job_public_id)
        save_to_db(result, stream)
```

---

## Resumen de cambios solicitados

| Modelo | Campo a agregar | Prioridad |
|--------|-----------------|-----------|
| `JobExecutionPublic` | `url: str` | **P1 — bloqueante** |
| `ScrapeResponse` | `url: str \| None = None` | P2 — recomendado |
