# Feature Request — API: Trazabilidad de URL en respuestas de Collections

## Contexto

Estamos usando el flujo de async collections para procesar ~820 URLs en batch diario:

```
POST /v1/async/collections          → crear colección con lista de URLs
POST /v1/async/collections/{id}/run → lanzar run
GET  /v1/async/collections/{id}/runs/{run_id}/jobs           → estado de cada job
GET  /v1/async/collections/{id}/runs/{run_id}/jobs/{job_id}/result → resultado
```

Cada job corresponde a una URL específica de nuestra base de datos. Al procesar los resultados necesitamos saber qué URL corresponde a cada job para guardar el resultado en el lugar correcto.

---

## Problema 1 — `GET .../runs/{run_id}/jobs` no retorna la URL (P1 — Bloqueante)

### Respuesta actual

```json
{
  "items": [
    {
      "job_public_id": "abc-123",
      "run_public_id": "run-456",
      "collection_id": "col-789",
      "status": "completed",
      "status_code": 200,
      "execution_time_sec": 45.2
    }
  ]
}
```

### El problema

No hay forma confiable de mapear `job_public_id` → URL de origen. El único workaround es asumir que el orden de `job_ids` en el run respeta el orden de inserción de la colección — lo cual no está documentado ni garantizado.

### Cambio propuesto

Agregar el campo `url` a cada item de la respuesta:

```json
{
  "items": [
    {
      "job_public_id": "abc-123",
      "run_public_id": "run-456",
      "collection_id": "col-789",
      "url": "https://www.getyourguide.com/barcelona-l45/...",
      "status": "completed",
      "status_code": 200,
      "execution_time_sec": 45.2
    }
  ]
}
```

---

## Problema 2 — `GET .../jobs/{job_id}/result` no retorna la URL (P2 — Recomendado)

### Respuesta actual

El resultado del job (`ScrapeResponse`) no incluye la URL que fue scrapeada. Esto obliga a mantener un índice externo para saber de dónde vino cada resultado.

### Cambio propuesto

Agregar `url` al body de la respuesta:

```json
{
  "url": "https://www.getyourguide.com/barcelona-l45/...",
  "html": "...",
  "statusCode": 200,
  "message": "OK",
  "extracted_data": { ... },
  "evaluate_results": [ ... ]
}
```

---

## Problema 3 — Garantía de orden de `job_ids` no está documentada (P2 — Documentación)

`RunPublic` retorna una lista `job_ids`. Si esta lista garantiza el mismo orden que el de inserción de la colección, por favor documentarlo explícitamente. Actualmente el comportamiento es ambiguo.

---

## Impacto

Sin el fix del **Problema 1**, el flujo de collections no es viable para casos de uso donde cada URL corresponde a una entidad distinta en la base de datos del cliente (que es el caso más común en scraping de reviews, precios, listings, etc.).

Con el fix aplicado, el código del cliente queda explícito y sin suposiciones de orden:

```python
jobs = get_run_jobs(collection_id, run_id)
job_by_url = {job["url"]: job for job in jobs["items"]}

for stream in my_streams:
    job = job_by_url[stream["url"]]
    if job["status"] == "completed":
        result = get_job_result(collection_id, run_id, job["job_public_id"])
        process(result, stream)
```

---

## Resumen de cambios solicitados

| Endpoint | Campo a agregar | Prioridad |
|----------|-----------------|-----------|
| `GET .../runs/{run_id}/jobs` | `url` en cada item | **P1 — bloqueante** |
| `GET .../jobs/{job_id}/result` | `url` en el body | P2 — recomendado |
| `GET .../runs/{run_id}` (`job_ids`) | Documentar garantía de orden | P2 — documentación |
