# Handoff SDK → SP API team — pedidos derivados de uso real (2026-04-30)

**Autor**: SDK team
**Para**: SP API team (Endpoints / Coordinator)
**Fecha**: 2026-04-30
**Origen**: `sdk-concerns.md` (Lucho + sesiones MLFQ + Lupa Google Shopping)
**Estado**: 🔴 abierto

Este documento consolida los pedidos al backend que **el SDK no puede
resolver solo**. Todos surgen de problemas que múltiples clientes
encontraron en producción esta semana — no son hipotéticos.

Cada item tiene **repro mínimo**, **impacto** y **propuesta concreta**.
Algunos son fixes chicos (~1-2h backend), otros requieren diseño de
contrato — agrupados por urgencia.

---

## §0 TL;DR · prioridad y owner

| # | Pedido | Prioridad | Tamaño | Bloquea SDK |
|---|---|---|---|---|
| 1 | **Idempotency-Key** en `POST /v1/async/collections` | 🔴 alta | Mediano | Sí (#2 SDK) |
| 2 | `GET /v1/async/collections/{cid}/runs` (listar runs) | 🔴 alta | Chico | Sí (#5 SDK) |
| 3 | `created_at` en `CollectionPublic` (`GET /collections`) | 🟡 media | Chico | Parcial (#5 + recovery) |
| 4 | Default de `GET /jobs` sin `status_filter` debe traer **todo**, no solo `completed` | 🟡 media | Chico | Sí (#13 SDK) |
| 5 | `run.job_ids` debe sobrevivir post-completion | 🟡 media | Chico | Sí (#12 SDK) |
| 6 | URL bloqueada: response 400 estructurado con lista de URLs ofensivas | 🟢 baja | Mediano | No (workaround SDK) |
| 7 | Mensajes diferenciados en 404 de `GET /jobs/{id}/result` | 🟢 baja | Chico | No |
| 8 | `POST /v1/async/collections` perf: ~7-16 j/s para 300 jobs | 🟢 baja | Investigación | No (verificar) |
| 9 | `name=` filter en `GET /v1/async/collections` (hoy se ignora) | 🟢 baja | Chico | Parcial (#5 + recovery) |

---

## §1 🔴 Idempotency-Key en `POST /v1/async/collections`

### Repro

```bash
curl -X POST https://api.scrapingpros.com/v1/async/collections \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"name": "daily-2026-04-30", "requests": [{"url": "..."}]}'
# Si la respuesta no llega al cliente (timeout, network drop, API degraded),
# el cliente reintenta y se crean DOS collections con el mismo name.
```

### Impacto

Patrón observado **3 veces** esta semana en clientes reales (sesión Lupa
Google Shopping):

1. Cliente llama `submit_batch()` → la API recibe, crea collection, arranca run.
2. La respuesta no llega al cliente en 120s (`httpx.ReadTimeout` durante `degraded`).
3. Cliente cree que falló, reintenta → segunda collection idéntica.
4. **Doble cobro de créditos**, dos batches procesando los mismos URLs.

El SDK no puede resolver esto correctamente del lado cliente sin un
mecanismo server-side de deduplicación.

### Pedido

Soportar header `Idempotency-Key: <uuid>` en `POST /v1/async/collections`.

```http
POST /v1/async/collections
Authorization: Bearer ...
Idempotency-Key: 7f3a2b1e-4c5d-...
Content-Type: application/json

{"name": "daily-...", "requests": [...]}
```

Comportamiento:
- **Primera vez con esa key** → crea collection normal, persistir
  `(client_id, key) → collection_id` en Redis con TTL 24h.
- **Segundo request con misma key dentro de 24h** → devolver la
  collection original (mismo `id`, mismo `created_at`), 200 OK,
  `Idempotency-Replayed: true` header opcional para diagnóstico.
- **Misma key con body diferente** → 422 con detalle "key reused with
  different payload".

Patrón estándar Stripe, AWS SQS, GitHub. Resuelve el caso "retry tras
timeout" sin riesgo de duplicado.

### Lo que el SDK va a hacer (v0.5.x)

- Generar UUID por submit, mandarlo en el header.
- Si el server lo ignora hoy, no rompe nada (header desconocido).
- Cuando shippeen el soporte, el SDK ya está listo.

---

## §2 🔴 `GET /v1/async/collections/{cid}/runs` (listar runs de una collection)

### Repro

```bash
curl -H "Authorization: Bearer ..." \
  https://api.scrapingpros.com/v1/async/collections/<cid>/runs
# → 404 Not Found
```

Endpoint no existe. Para enumerar runs de una collection, hoy el cliente
tiene que ir directo a MySQL.

### Impacto

Dos casos críticos para el SDK:

1. **Orphan recovery tras `submit_batch` timeout**: si el cliente
   recibe `httpx.ReadTimeout`, el `name` lo persiste antes del submit y
   con `GET /collections` puede encontrar la collection. Pero **no
   puede recuperar el `run_id`** que la API ya creó. Sin él, reintenta
   submit → duplicado.

2. **Monitoring / dashboards**: cliente persiste `collection_id` y quiere
   listar todas las corridas (run actual + reruns) para mostrar
   progreso o auditar. Hoy imposible vía API.

### Pedido

```http
GET /v1/async/collections/{cid}/runs
→ 200 [{run_id, status, created_at, total_requests, success_requests, ...}, ...]
```

Mismo shape que `GET /collections/{cid}/runs/{rid}` (un `RunPublic` por
entrada). Ordenado `created_at desc`. Paginado opcional pero no
bloqueante (la cardinalidad es baja — pocos reruns por collection).

Bonus opcional: `?status=in_progress` para pinpointear el run vivo.

### Lo que el SDK va a hacer

- `client.list_runs(cid) → list[RunPublic]` directo cuando exista.
- `find_recent_batch(name)` lo usa para reattacharse al run live tras
  un `SubmitTimeout`.

---

## §3 🟡 `created_at` en `CollectionPublic`

### Repro

```bash
curl -H "Authorization: Bearer ..." \
  https://api.scrapingpros.com/v1/async/collections | head -c 200
# → [{"id":"...","name":"qa_s_..."},{"id":"...","name":"..."}, ...]
# Solo {id, name}. No created_at.
```

### Impacto

`find_recent_batch(name=, since=)` del SDK necesita filtrar por timestamp
para distinguir "esta collection que recién creé" de "una collection
del mismo nombre de hace días". Sin `created_at` la única señal es el
nombre — funciona si el cliente usa nombres únicos por submit (con UUID
suffix) pero no si reutiliza nombres genéricos como `"daily"`.

### Pedido

Agregar `created_at` (ISO 8601) a cada entrada de `GET /v1/async/collections`:

```json
[{"id": "...", "name": "...", "created_at": "2026-04-30T10:23:45Z"}]
```

MySQL ya tiene la columna. Es un cambio de serializer.

Bonus: `updated_at` también, útil para "última actividad por collection".

---

## §4 🟡 `GET /collections/{cid}/runs/{rid}/jobs` default trae solo `completed`

### Repro

```python
# Run con 5 jobs: 3 completed, 2 timeout
curl -H "Authorization: Bearer ..." \
  https://api.scrapingpros.com/v1/async/collections/<cid>/runs/<rid>/jobs
# → 3 items (solo completed)

curl -H "Authorization: Bearer ..." \
  "https://api.scrapingpros.com/v1/async/collections/<cid>/runs/<rid>/jobs?status_filter=timeout"
# → 2 items (los timeouts)
```

### Impacto

Sin `status_filter` el endpoint silenciosamente filtra a `completed`.
Esto sorprende a clientes que asumen "sin filtro = todo" y **pierden
los timeouts/failed sin darse cuenta**. Reportado en sesión Lupa
(concern #13 de `sdk-concerns.md`).

### Pedido

Default `status_filter` ausente → devolver **todos los statuses**
(`processing`, `completed`, `failed`, `timeout`).

Si por compat hay clientes dependiendo del comportamiento actual:
exponer `?status_filter=all` explícito y deprecar el default actual con
header de respuesta `Deprecation`.

Voto SDK: cambiar el default. Es semánticamente correcto y los clientes
existentes que dependían de "completed only" deberían pedirlo
explícitamente.

---

## §5 🟡 `run.job_ids` viene vacío después de `status='completed'`

### Repro

```python
# Mientras run está in_progress
GET /collections/{cid}/runs/{rid}
→ {..., "status": "in_progress", "job_ids": ["a", "b", "c", ...]}   ✓

# Mismo run después de completed
GET /collections/{cid}/runs/{rid}
→ {..., "status": "completed", "job_ids": []}                        ❌
```

### Impacto

Caller que persiste solo `(cid, rid)` y vuelve a buscar los jobs por ID
después del fin del run no puede iterarlos sin paginar `GET /jobs`. La
fuente de truth de "qué jobs forman parte del run" no debería cambiar
con su status.

Reportado en sesión Lupa (concern #12). Workaround SDK actual: paginar
`get_run_jobs()` filtrando por cada `status_filter`.

### Pedido

Que `run.job_ids` esté **idempotente respecto a status** — presente
mientras exista el run. Si el TTL en Redis se vence, popular desde
MySQL on-demand.

Si por costos de storage no es viable: agregar
`GET /collections/{cid}/runs/{rid}/job_ids` que pagine por debajo y
devuelva una lista plana de strings.

---

## §6 🟢 URL bloqueada: response 400 estructurado

### Repro

```python
items = [
    {"url": "https://example.com/ok1"},     # válida
    {"url": "https://investors.claritev.com/x"},  # resuelve a ::1 transient
]
# Submit
POST /v1/async/collections {"requests": items}
→ 400 {"detail": "URL blocked: Blocked IP: ::1 (resolved from
   'investors.claritev.com'). Private/internal IP addresses are not allowed."}
# Toda la collection rechazada. Solo se sabe la URL ofensiva por string parsing.
```

### Impacto

Para batches grandes (200-300 URLs), una sola URL flaky por DNS
transient hace que el cliente pierda toda la collection. El error solo
informa cuál URL falló, no cuáles más fallarían — el cliente tiene que
parsear el detail string para extraerla y reintentar sin esa URL,
posiblemente varias veces.

Concern #7 de `sdk-concerns.md`. Workaround SDK
(`submit_batch_lenient`) parsea el string del detail — feo y frágil.

### Pedido

Response estructurado en el body cuando falla por URL bloqueada:

```json
HTTP 400
{
  "detail": "Some URLs were rejected.",
  "blocked_urls": [
    {
      "index": 73,
      "url": "https://investors.claritev.com/x",
      "reason": "private_ip",
      "resolved_to": "::1",
      "transient": true
    }
  ]
}
```

Y/o variante: `?on_blocked=skip` query param que crea la collection
ignorando las URLs bloqueadas y retorna `{collection_id, skipped: [...]}`.

Cualquiera de las dos elimina el parsing string-based del SDK.

---

## §7 🟢 404 diferenciado en `GET /jobs/{id}/result`

### Repro

Tres casos hoy devuelven el mismo string:

```http
GET /v1/async/.../jobs/<expired_id>/result
→ 404 {"detail":"Job result not found. Results are available for 24 hours after completion."}

GET /v1/async/.../jobs/<lost_during_degradation>/result
→ 404 {"detail":"Job result not found. Results are available for 24 hours after completion."}

GET /v1/async/.../jobs/<bogus_id>/result
→ 404 {"detail":"Job result not found. Results are available for 24 hours after completion."}
```

Reportado en sesión Lupa: en una ventana `degraded` del API, jobs
`completed` perdieron sus resultados **5-15 min después** de la
completion, no a las 24h documentadas. El cliente no puede actuar
porque el mensaje es genérico.

### Impacto

Caller no sabe si:
- el job_id es inválido (bug del cliente),
- expiró naturalmente (acción: rerun),
- se perdió por degradation (acción: contactar soporte / refund).

### Pedido

Distinguir los 3 casos con `error_code` o detail específico:

```json
404 {
  "detail": "...",
  "error_code": "result_expired" | "result_lost" | "job_id_invalid",
  "completed_at": "..."   // si aplicable
}
```

---

## §8 🟢 Performance de `POST /v1/async/collections` con batches grandes

### Observación

Test 10x mega (sesión MLFQ async):

| Batch | Items | Wall time submit | Throughput |
|---|---|---|---|
| A_mixed | 300 | 39.3 s | ~7.6 j/s |
| C_mixed_1 | 250 | 25.5 s | ~9.8 j/s |
| B_fast_run5 | 50 | 4.2 s | ~12 j/s |
| E_small_1 | 30 | 1.9 s | ~16 j/s |

Para batches >200 jobs, el submit toma 25-40s antes de que arranque
ningún workers. El SDK manda **un solo POST** con todos los items en el
body, así que el cuello no parece estar en el cliente.

Concern #9 de `sdk-concerns.md`.

### Pedido

Verificar server-side si `POST /v1/async/collections` está haciendo:
- Batch INSERT (1 statement con N rows) ✓ esperado
- vs INSERT por item en loop ❌ explicaría el throughput

Si es lo segundo, batchear. Esperaríamos 200-500 j/s para batches
grandes con batch INSERT real.

---

## §9 🟢 `name=` filter en `GET /v1/async/collections` (hoy se ignora)

### Repro

```bash
curl -H "Authorization: Bearer ..." \
  "https://api.scrapingpros.com/v1/async/collections?name=debug_single"
# → 200 con lista completa, sin filtrar
```

El query param es aceptado pero ignorado. El SDK hoy hace filter
client-side iterando toda la lista — funciona pero es O(N) en el total
de collections del cliente.

### Pedido

Soportar:
- `?name=<exact_match>` → exact match
- `?name_prefix=<...>` → prefix match (útil para "todos los `daily-*`")
- `?since=<iso8601>` → filter por `created_at >= since` (requiere §3 también)

---

## Resumen de impacto cruzado

| Pedido | Resuelve directamente |
|---|---|
| §1 Idempotency | concern #2 SDK (orphan post-timeout sin duplicar) |
| §2 list_runs | concern #5 SDK + recovery completo de orphan en `find_recent_batch` |
| §3 created_at | recovery preciso por timestamp |
| §4 default jobs filter | concern #13 SDK |
| §5 job_ids post-completion | concern #12 SDK |
| §6 blocked structured | concern #7 SDK (sacar parsing string-based) |
| §7 404 diferenciado | concern #14 SDK (mejor UX en errores) |
| §8 perf submit | concern #9 SDK |
| §9 name filter | concern #2 SDK eficiencia + dashboards |

§1 + §2 son los que más mueven la aguja para el SDK — destrabarían el
patrón completo de orphan recovery sin riesgo de duplicar batches.
§4 + §5 son fixes chicos con alto impacto en correctitud.

---

## Próximos pasos

- API team: reviewar prioridad y dar ETA tentativa por item.
- SDK team: implementar workarounds client-side donde sea posible
  mientras se shippean los fixes server-side. Lo que ya estamos
  haciendo en v0.5.2:
  - `find_recent_batch(name)` — funciona hoy con limitaciones (sin
    `created_at` ni `list_runs`).
  - `SubmitTimeout` con mensaje de recovery.
  - `submit_batch_lenient` parsea el string del detail (feo, hasta §6).
- Cuando `Idempotency-Key` (§1) o `list_runs` (§2) shippeen, ping al
  SDK team y publicamos v0.5.3 que los consume.

Pingback acá si algún pedido tiene blocker técnico, o si conviene
priorizar distinto.
