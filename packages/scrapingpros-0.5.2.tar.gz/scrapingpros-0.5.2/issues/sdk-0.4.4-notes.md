# Handoff consolidado — bugs reproductibles + features Coordinator (2026-04-28)

**Autor:** SDK team
**Fecha:** 2026-04-28
**Estado:** 🟡 SDK + Lucho ir **directo a v0.5.0**. Mascherano rebuild ✅. Flex: §3 ✅, §5.2 🟡 PARCIAL (~1-2h debug E2E). §6.5.4 resuelto (α) — §1.2 fuera de scope. SDK pendiente ~2-3h. Ver §8.
**Source de los reports:**
- `handoff-coordinator-sdk-doc-refresh.md` (Coordinator → SDK, 2026-04-28)
- `scrapingpros_casos_reproductibles.md` (10 casos, scrapers en prod)
- `scrapingpros_sdk_bug_content_type.md` (1 bug SDK)
- `informe-estado-validator-2026-04-28.md` (HTML Validator team, §4.5 routed al SDK)

---

## §0 TL;DR · tabla de routing

Cada fila tiene un **owner único**. Cada team responde sólo en su `§<letra>` correspondiente más abajo y bajan su fila a 🟢 cuando shippean.

| # | Item | Owner | Status | Severidad | Impacto |
|---|---|---|---|---|---|
| 1 | `MethodPOST.content_type` no se serializa | **SDK** | 🔴 pending v0.4.4 | alta | Kroger family (13 retailers) + Food 4 Less rotos |
| 2 | Paridad top-level del verdict en `ScrapeResponse` | **SDK** | 🔴 pending v0.4.4 | baja | docs / DX |
| 3 | `client_id` + `validator_version` + `has_extractable_data` en `JobExecutionPublic` | **SDK** | 🔴 pending v0.4.4 | baja | observabilidad / Validator §4.5 |
| 4 | Confirmación: features Coordinator §1–§4 ya entregadas | **Coordinator** | 🟢 confirmado en §2.respuesta | info | unblock |
| 5 | Política sobre `browser_options.tls_impersonate` | **Coordinator** | 🟢 resuelto en §2.respuesta + §2.3 (no expose, profile-routed). Commit dispatcher `9142049`. **Mascherano rebuild done 2026-04-28/29: Walmart back to ~100% — 134 FLEX_FIRST_HIT / 0 fell / 0 exception en últimas 12h. Smoke 2026-04-29 12:00 UTC: GET /seller/9193 → 200 + 300KB HTML + 1.8s + success=True + 1 credit (browser=false path).** | alta | Walmart |
| 6 | `wait-for-selector` frame loss + `<script>` selector (label "Workers" → corregir a Flex) | **Worker Flex** | 🟢 shipped commit `58ed805` (2026-04-26) | media | Food City, Costco, Raley's, H-E-B |
| 7 | `use_proxy != null` + `browser=True` → timeout (regresión 2026-04-20) | **Worker Flex** | 🟡 investigado, no es regresión flex-first; root cause = HTML Validator legacy FP (Track B Workers Coordinator). Ver §4.respuesta-flex. | alta | Smart & Final, Food City, Hy-Vee, ShopRite, Raley's |
| 8a | `network_capture` listener pre-load (label "Workers" → corregir a Flex) | **Worker Flex** | 🟢 ya funciona en código actual — validado captura 14 XHRs Costco incl. 8 Apollo persistedQuery. No requiere cambio. | media | Costco / Instacart |
| 8b | `network_capture` body capture vía `url_pattern` | **Worker Flex** | 🟢 **shipped** master (`ecce15b` + `a3a35cb` + `28de6b2`): schema + listener + body fetch + global-timeout 5s anti-hang en AMBAS engines (light + heavy). **Validado E2E**: smoke httpbin con `url_pattern='*httpbin*'` → `with_body=1` (3739 chars utf-8 HTML real capturado). 64KB cap, `body_truncated` flag, `body_error` fallback (ej. cuando response ya está disposed por retry). | media | Swiftly family (Caso 8 Firebase idToken) listo. |

Items 1–3 los resuelve SDK solo en **v0.4.4**. Items 4–8 dependen de respuestas externas — se acumulan para v0.4.5 / v0.5.0 según urgencia.

---

## §1 SDK self-assigned — v0.4.4 scope

### 1.1 Bug `MethodPOST.content_type` (🔴 → SDK)

**Repro** (validado contra `scrapingpros==0.4.3`):

```python
from scrapingpros.models import MethodPOST
m = MethodPOST(payload={"grant_type": "client_credentials"}, content_type="form")
m.model_dump(exclude_none=True)
# → {'method': 'post', 'payload': {...}}     ❌ content_type ausente
```

**Causa**: el modelo en `scrapingpros/models.py:231-264` no declara `content_type`. Pydantic descarta el kwarg silenciosamente y nunca llega al backend.

**Impacto en prod**:
- Kroger OAuth (`POST /v1/connect/oauth2/token`) requiere `Content-Type: application/x-www-form-urlencoded`. El SDK siempre manda JSON → 400 `"invalid Content-Type"`.
- Familia Kroger afectada: trade IDs **2, 9, 12, 16, 17, 24, 29, 33, 36, 41, 44, 45, 57** (Kroger, Harris Teeter, Food 4 Less, Smith's, Ralph's, Pick 'n Save, Fry's, King Soopers, Jay C, Baker's, City Market, Quality Food Center, Dillon's).

**Fix**:

```python
class MethodPOST(BaseModel):
    method: Literal["post"] = "post"
    payload: dict[str, Any] | list[Any] | None = None
    url: str | None = None
    content_type: Literal["json", "form"] | None = None   # nuevo
```

Test unitario: `MethodPOST(payload=..., content_type="form").model_dump(exclude_none=True)` debe contener la clave.

### 1.2 Verdict top-level en `ScrapeResponse` (🔴 → SDK)

Hoy el SDK sólo expone los campos de verdict dentro de `resp.guidance` (subobjeto). La API los duplica también top-level — el handoff Coordinator §2 los lista como contrato público.

**Plan**: agregar al modelo `ScrapeResponse` los campos `success`, `error_type`, `error_provider`, `credits_charged`, `credits_refunded`, `next_steps`, `suggested_request`, `stop_reason`. Mantener `guidance` por backward-compat. Docs recomiendan `resp.success` como path primario; `resp.guidance.*` queda como conveniencia agrupada.

### 1.3 `JobExecutionPublic` faltantes (🔴 → SDK)

Tres campos que el SDK no expone aún:
- `client_id: str` (Coordinator handoff §3)
- `validator_version: Optional[str]` (Coordinator handoff §3)
- `has_extractable_data: Optional[bool]` (Validator informe §4.5 — populated post-Track B)

Los dos primeros son cosméticos / observabilidad. El tercero llega cuando Workers Coordinator complete Track B (migración legacy → maduro `utils/html_validator.py`); hasta entonces será `None` en runs nuevos pero el campo ya queda tipado para no requerir release adicional cuando empiece a poblarse.

Naming: el Validator team lo nombra en camelCase (`hasExtractableData`) en su informe, pero el resto de `JobExecutionPublic` está en snake_case y el modelo Pydantic del API también. Asumimos snake_case en el contrato; si hay mismatch lo corregimos al integrar.

Bajo costo, alta utilidad para diagnóstico. Entran en v0.4.4.

### 1.4 Estado de los issues entrantes

- Caso 9 (URL vacía → 422): **ya cubierto** desde `_validate_url` en `ScrapeRequest` y `DownloadRequest` (raise `ValueError("URL cannot be empty")` antes del HTTP). Caller que use el SDK con typed model no llega al 422. No-op.

---

## §2 Coordinator — pendiente respuesta

### 2.1 Confirmación handoff `handoff-coordinator-sdk-doc-refresh.md` (🔴 → Coordinator)

Las cuatro features pedidas en ese handoff **ya están shippeadas**, anteriores a la fecha del handoff:

| Feature pedida | Versión SDK | Commit / Release |
|---|---|---|
| `ScrapeRequest.custom_id` (echo-back) | v0.3.0 (2026-04-23) | `models.py:366` |
| `MethodPOST.url` + validación SSRF | v0.3.0 (2026-04-23) | `models.py:252-264` |
| `JobExecutionPublic` con verdict fields completos | v0.4.3 (2026-04-24) | `models.py:589-650` |
| Cursor pagination + `get_run_jobs()` / `iter_run_jobs()` | v0.4.1 (2026-04-23) | `client.py:693, 796`; `async_client.py:476, 547` |

**Pedido**: confirmar que los modelos publicados en PyPI coinciden con el contrato que ustedes documentaron en `docs/sync/scrape.md` y `api/llms_txt.py` (commit `f32f7b2`). Si encuentran un campo o tipo desalineado, lo arreglamos en v0.4.4.

Pendiente nuestro lado para v0.4.4 (no bloquea ustedes): items 1.2 y 1.3 arriba.

### 2.2 Política sobre `browser_options` público (🔴 → Coordinator)

**Caso 1 + Caso 10** (de `scrapingpros_casos_reproductibles.md`) describen el mismo problema: Walmart detecta TLS fingerprint genérico (`requests`/`httpx` server-side) y devuelve shell vacío de 15 KB sin `__NEXT_DATA__`. El workaround manual es:

```python
browser_options={"tls_impersonate": "chrome124"}
cookies={"location-data": "..."}
```

`scraping_api_client.py` (cliente HTTP manual del scraper Walmart) lo manda y funciona. El SDK Pydantic descarta el kwarg porque `ScrapeRequest` no declara `browser_options`.

**Conflicto**: el handoff Coordinator §"NO agregar todavía" dice explícitamente que `tls_impersonate`, `warmup_url`, `return_cookies` son **internal-only** y NO deben exponerse al cliente público.

**Decisión necesaria — elegir una de las tres**:

1. **Toggle high-level**. La API expone algo tipo `bypass_tls_fingerprint: bool` (sin nombrar `chrome124` ni `curl_cffi`) en `ScrapeRequest`. El SDK lo agrega como param. Mantiene la política "no exponemos tech interno". **Preferencia SDK**.
2. **Whitelist parcial de `browser_options`**. Coordinator confirma que `tls_impersonate` es público-ready y nosotros agregamos un modelo `BrowserOptions` con sólo ese campo (no `warmup_url`/`return_cookies`/`cookie_jar`). Riesgo: `browser_options` queda como cajón abierto.
3. **Status quo**. Walmart sigue con su cliente HTTP manual indefinidamente; SDK no toca. Solo si la decisión de producto es "Walmart no es caso target".

Esperamos su lectura. Sugerimos opción 1 — alinea con la política existente de no nombrar Camoufox/Playwright/Chromium en docs.

---

## §2.respuesta — Coordinator (2026-04-28)

### Sobre §2.1 — confirmación de features shipped

Verifiqué `scrapingpros==0.4.3` contra master del API (commit `f32f7b2`):

| Feature | Estado SDK v0.4.3 | Comentario Coordinator |
|---|---|---|
| `ScrapeRequest.custom_id` | 🟢 presente, tipo correcto | Match exacto. |
| `MethodPOST.url` + SSRF | 🟢 presente con docstring claro | API valida SSRF, SDK puede fallar fast también si quieren. |
| `JobExecutionPublic` verdict fields | 🟡 mostly OK, **2 gaps** | Faltan `client_id` y `validator_version`. Ya están en su TODO §1.3 — confirmamos que es correcto agregarlos. También falta `execution_time_sec` (legacy float, redundante con `_ms`); pueden omitirlo o tipar para max-compat. |
| Cursor pagination + `get_run_jobs()` / `iter_run_jobs()` | 🟢 implementado en `client.py:693, 796` y `async_client.py:476, 547` | Match con la spec del API. |

**Discrepancia adicional encontrada — `browser_type`** (no está en su §1):

SDK v0.4.3 declara:
```python
browser_type: Literal["light", "heavy", "stealth"] = "light"
```

API master acepta:
```python
browser_type: Literal["light", "heavy", "stealth", "auto", "flex"] = "auto"
```

**Diferencia**: el SDK no permite `"auto"` ni `"flex"`. `"auto"` es el default recomendado de la API actualmente (escalation ladder con flex-first-rung) y el SDK debería al menos permitirlo. `"flex"` es power-user (requiere profile en `domain_profiles`); pueden omitirlo o aceptarlo como passthrough.

Recomendación: extender SDK a `Literal["light", "heavy", "stealth", "auto"]` con default `"auto"`. Marcar `"light"`/`"heavy"`/`"stealth"` como deprecated en docstring (pero dejarlos típados para retro-compat).

**Veredict §2.1**: las 4 features que listan como shipped **están correctas en contrato**. Los 2 gaps de `JobExecutionPublic` los abordan ustedes en v0.4.4 (1.3). Sumarle el cambio de `browser_type` también para v0.4.4. Con eso, el handoff Coordinator → 🟢.

---

### Sobre §2.2 — política `browser_options.tls_impersonate`

**Decisión de Lucho (sign-off recibido 2026-04-28)**: NO se exponen `tls_impersonate` ni ningún internal al cliente público. La política previa se mantiene firme. Las 3 opciones que propusieron quedan resueltas:

- ❌ Opción 1 (toggle abstracto público): rechazada.
- ❌ Opción 2 (whitelist `tls_impersonate`): rechazada.
- ❌ Opción 3 (status quo, Walmart roto): tampoco — porque hay un camino mejor que ya está implementado.

**El caso de Walmart YA está resuelto del lado server, vía profile**. Verifiqué en prod (2026-04-28):

```
domain: www.walmart.com (id 5)
params: {
  "preferred_engine": "cffi",
  "tls_impersonate": "chrome",
  "retry_on_block": 3,
  "headers_override": { ... }
}
```

Y el dispatcher en `worker/job_executor.py:443` ya rutea el flex-first-rung con `preferred_engine="cffi"` → `scrape_cffi(url, tls_impersonate=...)`. **El behavior correcto está deployado**. Los clientes simplemente tienen que mandar el request **sin manualmente setear `browser_options`**.

**La diferencia es lo que el cliente envía**:

```python
# ❌ Path actual del scraper (lo que están haciendo y que SDK strips)
{
  "url": "https://www.walmart.com/ip/...",
  "browser": false,
  "browser_options": {"tls_impersonate": "chrome124"},  # SDK lo descarta
  "cookies": {...}
}

# ✅ Path correcto (SDK lo soporta, profile hace el resto)
{
  "url": "https://www.walmart.com/ip/...",
  "browser": true,                # o simplemente omitido + browser_type=auto default
  "browser_type": "auto",
  "cookies": {...}                # cookies sí siguen pasando
}
```

Cuando el segundo request llega:
1. Dispatcher entra al ladder (`auto/heavy/light` con flex-first-rung activado).
2. Lookup en `domain_profiles` para `www.walmart.com` → match con id=5.
3. El profile tiene `preferred_engine="cffi"` → flex-first-rung llama a `scrape_cffi` con el `tls_impersonate` del profile.
4. Si funciona → return. Si no → cae al ladder normal.

**Resultado para el cliente**: idéntico a lo que están haciendo manualmente, pero sin que tengan que conocer que existe `tls_impersonate`, `cffi`, ni nada. Zero changes a SDK. Zero conocimiento del internal. Profile hace el routing.

**Lo que SDK tiene que hacer**:

1. **Documentar el path correcto** para clientes que actualmente envían `browser_options` manualmente: cambiar `browser=false + browser_options={...}` por `browser=true + browser_type="auto"`. Misma efectividad.
2. **NO exponer `browser_options`** en el modelo Pydantic público. Mantener el strip silencioso.
3. **NO crear `BrowserOptions` model**. Mantener cualquier campo asociado como ausente del contrato.

**Si encuentran un caso de Walmart o similar donde el path correcto no funciona**: ping a Lucho con el repro. Posiblemente necesitemos extender el profile o agregar un nuevo profile (ej. para `www.walmart.com/seller/` con params distintos). Pero eso lo hacemos del lado server, sin tocar contrato público.

**Para tu file de cambios v0.4.4**: pueden cerrar §2.2 como "no action SDK side, server-side already handled". El bug §1.1 (`MethodPOST.content_type`) sigue siendo SDK fix necesario.

---

### §2.3 — Aclaración adicional de Lucho (2026-04-28): la línea es `browser=true/false` y nada más

Endurecimiento de la política en respuesta a este handoff:

> "La línea siempre es que los clientes pidan si usar browser o no (1 vs 5 créditos) y con eso suficiente. Nosotros tenemos que poder resolver el resto internamente."

Esto implica una posición más fuerte de lo que tenía documentado:

1. **Cliente decide solo `browser=true` vs `browser=false`** (= elige el costo: 1 vs 5 créditos).
2. **Todo lo demás lo resuelve el backend**:
   - `browser=true` → backend elige entre light / heavy / stealth / flex según profile + auto ladder.
   - `browser=false` → backend elige entre simple (httpx) y cffi (curl_cffi) según profile del dominio.
3. **`browser_type`, `browser_options`, `tls_impersonate`, profiles** — todo internal, nunca en contrato público.

**Implicancia para SDK**:

- **Recomendación nueva sobre `browser_type`**: en vez de extenderlo a `Literal[..., "auto"]` como les sugerí en §2.1, **considerar deprecarlo completamente** en docstring del SDK. El backend defaultea a "auto" cuando no viene; el cliente no debería tener que pensar en el modo. Mantenerlo tipado para retro-compat (clientes existentes que ya lo usan) pero marcar como deprecated en doc, sin recomendar uso. SDK v0.5.0 podría eventualmente quitarlo.

- **`browser_options` queda explícitamente NO-tipado**, ahora sí con razón fuerte: la política no es solo "no exponer chrome124" sino "no exponer ningún detalle de routing". Cliente que hoy lo manda manualmente vía HTTP raw lo va a seguir haciendo, pero SDK no lo soporta y nunca lo va a soportar.

- **Migración para clientes Walmart-like**: doc clara en SDK diciendo "para sites difíciles, simplemente mandá `browser=true` o `browser=false` según necesites browser; el sistema rutea internamente".

**Implicancia para el lado server (Coordinator action)**:

Para que la línea "cliente solo elige browser sí/no" funcione realmente en TODOS los casos:

- `browser=true` ya tiene la cadena completa: `auto` ladder → flex-first-rung → profile → engine elegido. ✓
- `browser=false` **falta extender**: hoy el dispatcher para `browser=false` solo usa el profile si el cliente mandó `browser_options.tls_impersonate` explícito. Si NO lo manda (caso SDK), va a `scrape_simple` directo sin lookup de profile.

Para alinear con la política, voy a extender el dispatcher así:
1. En el path `browser=false`, agregar lookup del profile del dominio.
2. Si el profile tiene `preferred_engine="cffi"` → rutear a `scrape_cffi` con `tls_impersonate` del profile.
3. Si no hay profile o preferred_engine no es cffi → `scrape_simple` como hoy.

Esto es ~15 líneas en `worker/job_executor.py`. Sin contrato público nuevo. Lo hago como follow-up esta misma sesión y commiteo. Cuando esté, los clientes Walmart vía SDK con `browser=false` van a obtener cffi automáticamente sin saber nada del internal.

Estimación: ~20 min implementación + smoke test.

**Resumen para SDK team**:

- §2.2 cerrado, no action SDK.
- §2.3 — esperá un commit del Coordinator que extiende el dispatcher para que `browser=false + Walmart` también use cffi vía profile. Cuando esté pusheado les notifico.
- §2.1 ajuste: en vez de extender el `Literal` de `browser_type` a `"auto"`, considerar deprecar el field completo en docstring. Si igual quieren tiparlo para passthrough, OK extender — pero no recomendarlo en docs cliente.

#### Cross-ref Validator informe (2026-04-28, §2.1 + §3.2)

El informe del HTML Validator team reporta caída Walmart **91.4% (2026-04-22) → 0% con 1972 exceptions (2026-04-24)** en `validator_daily_snapshots`. Confirma que es **regresión separada del engine `cffi` o del profile de Walmart**, no relacionada con la decisión §2.2 sobre `browser_options`. Validator team la rutea a Workers Flex / Coordinator (§3.2 del informe).

Lectura SDK: la decisión "no exponer `browser_options`" se mantiene válida — pero hasta que Flex resuelva la regresión del engine `cffi` (item §2.3 del informe Validator + commit dispatcher `9142049` que aún espera rebuild de imágenes), los clientes Walmart-via-SDK van a recibir 0% success aunque el contrato público esté correcto. No hay acción SDK; sólo seguimiento.

---

### Sobre §3 (Workers — wait-for-selector) → ya ruteado

Ambos sub-casos (3.1 frame loss + 3.2 selector visible) ya los flagged a **Worker Flex team** en `SP API Worker Flex/handoff-action-engine-bugs.md` el 2026-04-24:

- **Bug #4** (3.1 frame loss en navegación) — Costco / Instacart / Food City / Raley's
- **Bug #10** (3.2 wait_for_selector default `visible` no matchea `<script>`) — H-E-B / Raley's / Walmart

Mitigaciones propuestas en ese handoff. Estimación combinada ~1h.

**Status del lado Flex**: 🔴 esperando que tomen el ticket. Pueden pingarles directo si quieren acelerar. El doc tiene los detalles técnicos + repros + tests sugeridos.

### Sobre §4 (Flex — regresión proxy + browser) → routing

Este NO lo había flageado yo. Lo ruteo a **Worker Flex team** porque toca la integración proxy↔playwright. Le agrego una nota a Lucho para que pase a Flex.

**Pero también**: el dato "introducido en deploy del 2026-04-20" coincide con el período del refactor flex-first-rung (commits `9dd1056`, `9043f89`, `b6ae7aa`). Posible candidato a inspección. Flex team es el que conoce mejor.

### Sobre §5 (Workers — network_capture) → routing

También no era mío. Es **Worker Flex team scope** (network_capture vive en `worker/scraping_lightweight_browser.py`). El pedido tiene 2 features razonables:

- §5.1 listener attach pre-load (con campo `listen_from`)
- §5.2 capture response bodies (con filtros + cap)

Lo ruteo a Flex team. Ambas features parecen factibles, ~1-2h cada una.

---

### Resumen de items en mi cancha

| Item | Acción Coordinator |
|---|---|
| §2.1 Confirmación features | ✅ Confirmado match. + extra: `browser_type` Literal extender. |
| §2.2 Policy `tls_impersonate` | 🟡 Recomendación opción 1, esperando sign-off SP API team. Ping a Lucho. |
| §3 wait-for-selector | ✅ Ya ruteado a Flex (`handoff-action-engine-bugs.md`). |
| §4 proxy+browser regresión | 🆕 Lo escalo a Flex en próximo update suyo. |
| §5 network_capture | 🆕 Lo escalo a Flex en próximo update suyo. |

Voy a pingarles a Lucho con los items 4-5 para que vayan al Flex handoff, y le paso §2.2 para sign-off del toggle.

---

## §3 Workers — `wait-for-selector` (🔴 → Workers)

Consolidado de Casos 2A, 2B, 2C, 3 — mismo root cause en dos sub-modos:

### 3.1 Frame loss en navegación intermedia

**Repro mínimo (Raley's, Caso 2C)**:

```python
api.scrape(
    "https://www.raleys.com/product/.../840379/",
    browser=True, browser_type="heavy",
    cookies={"FLDR.User": "..."},
    actions=[{"type": "wait-for-selector", "selector": "css:script#__NEXT_DATA__", "time": 10000}],
)
# → 500 Server Error
```

**Diagnóstico (lado scraper)**: Cloudflare resuelve su challenge con un `window.location` JS redirect. La navegación destruye el frame que Playwright tenía registrado. El listener queda esperando en frame muerto y eventualmente Playwright tira `TimeoutError` → 500 al cliente.

**Misma causa en**:
- Caso 2A (Food City): `evaluate(fetch)` + `evaluate(reload)` separados, y `wait-for-selector` después del reload mira el frame anterior.
- Caso 2B (Costco): `evaluate(navigate)` + `wait-for-selector` post-navegación.

**Workaround actual (cliente)**: combinar fetch + nav en un solo `evaluate` con `.then()`, o reemplazar `wait-for-selector` por `wait-for-timeout` fijo. Fea, frágil.

**Pedido**: que `wait-for-selector` retry-ee transparentemente sobre el frame nuevo si detecta navegación durante el wait. O al menos, que devuelva un error tipado (`frame_destroyed`, no 500) que el SDK pueda exponer como `block_reason` accionable.

### 3.2 Selectors no visibles (`<script>`, etc.) (Caso 3)

**Repro mínimo (H-E-B)**:

```python
actions=[{"type": "wait-for-selector", "selector": "css:script#__NEXT_DATA__", "time": 8000}]
# → 500 (Playwright TimeoutError)
```

**Diagnóstico**: Playwright `waitForSelector` con default `state="visible"` nunca matchea `<script>` (display:none implícito). El wait expira siempre.

**Pedido**: aceptar un campo `state` en `WaitForSelectorAction` con valores `"visible"` (default actual) | `"attached"` | `"hidden"`. Mapeo 1:1 a Playwright. Cliente que sepa que está esperando un `<script>` o un nodo no-renderizado pasa `state="attached"`.

Si lo confirman, en SDK agregamos:

```python
class WaitForSelectorAction(BaseModel):
    type: Literal["wait-for-selector"] = "wait-for-selector"
    selector: str
    time: int
    state: Literal["visible", "attached", "hidden"] | None = None  # nuevo
```

---

## §4 Flex — regresión proxy + browser (🔴 → Flex)

### 4.1 Regresión 2026-04-20: `use_proxy != null` + `browser=True` → timeout

**Repro mínimo (Hy-Vee, Caso 4)**:

```python
api.scrape(
    "https://www.hy-vee.com/grocery/product/5016555/...",
    browser=True,
    use_proxy="any",     # también "US"
)
# → timeout 120s con use_proxy="any"
# → 500 repetido (3x ~82s) con use_proxy="US"
# → OK con use_proxy=None (52-72s)
```

**Diagnóstico (lado scraper)**: el componente que asigna proxy al contexto Playwright falla silenciosamente — no levanta error inmediato, pero deja el browser esperando un proxy que nunca llega o que cuelga la conexión. Consume el timeout completo.

**Retailers afectados**: Smart & Final (66), Food City (58), Hy-Vee (64), ShopRite (31), Raley's (47).

**Severidad**: alta. Smart & Final no tiene workaround porque requiere IP regional para selección de tienda; el resto sí (`use_proxy=None`).

**Pedido**: investigar la regresión introducida en el deploy del 2026-04-20. Si pueden confirmar el commit, podemos correlacionar con runs de benchmark previos. Mientras tanto, ¿hay forma de degradar a un modo "proxy best-effort, fall through a sin-proxy en N segundos"?

---

## §5 Workers — `network_capture` (🔴 → Workers)

Casos 6 y 8 tienen la misma raíz: el listener de network es insuficiente para flujos modernos de SPAs.

### 5.1 Listener llega tarde (Caso 6, Costco/Instacart)

```python
api.scrape(
    "https://sameday.costco.com/store/costco/products/...",
    browser=True,
    network_capture={"resource_types": ["xhr", "fetch"], "listen_after_load_ms": 5000},
)
# → resp["network_requests"] == []
```

La call a `ItemPricesQuery` (Apollo persistedQuery) ocurre durante la hidratación SSR, **antes** del evento `load`. El listener actual se attach-ea post-`load`, tarde. Subir `listen_after_load_ms` no ayuda (probado hasta 10s).

**Pedido**: opción para attach el listener en `domcontentloaded` o incluso pre-`navigation`. Aceptamos un nuevo campo:

```python
network_capture={
    "resource_types": ["xhr", "fetch"],
    "listen_from": "navigation" | "domcontentloaded" | "load",  # default "load" (actual)
    "listen_after_load_ms": 5000,
}
```

### 5.2 Captura de response bodies (Caso 8, Swiftly family)

Hoy `network_requests` registra URL, method, status, content_type. **No el body**. Pero el body es lo que necesitamos: en Swiftly (Food Maxx, Save Mart, Lucky CA), Firebase devuelve un `idToken` en el body de `accounts:signUp` que se usa para llamadas autenticadas posteriores.

Workaround actual: replicar el flujo de auth manualmente con `http_method=POST` + Referer hardcodeado por retailer. Funciona pero implica que cada retailer Swiftly tiene su Referer pegado en el código.

**Pedido**: opt-in para capturar bodies. Ejemplo:

```python
network_capture={
    "resource_types": ["xhr", "fetch"],
    "capture_bodies": True,
    "capture_bodies_url_pattern": "*identitytoolkit.googleapis.com*",  # filtro opcional
    "capture_bodies_max_size": 64_000,    # cap en bytes
}
```

Controlamos costo con el filtro de URL y el cap de tamaño. Solo opt-in — capturar todo por default infla el response horrible.

Si el equipo prefiere otra forma (endpoint separado, S3 link, etc.), abrimos a discusión.

---

## §3.respuesta — Flex (vía Coordinator supervision, 2026-04-28)

**Status: 🟢 ambos sub-casos resueltos en commit `58ed805`** (2026-04-26, hace 2 días — antes de que circulara este handoff de SDK 0.4.4).

Pueden verificar con: `git show 58ed805`. Mensaje completo + diff en master.

### 3.1 Frame loss en navegación intermedia → mitigación (A) aplicada

Try/except alrededor del wait con retry post-`networkidle`. Aplicado en 3 files:
- `worker/execution/wait_for_selector.py` — distingue `PWTimeoutError` (legítimo, propaga) de errores de context-loss (recovery + retry una vez).
- `worker/execution/click_action.py` — mismo patrón en click + fallback retry-with-force=True.
- `worker/flex_features/wait_strategy.py` — paridad con wait_for_selector. Swallow después del retry (alineado con el behavior existente del flex wait_strategy).

Mitigaciones (B) y (C) del handoff original (post-click coordination, SPA mode detection con `wait_for_function`) quedan en backlog. (A) es suficiente para los sites afectados actualmente. Si aparece un ticket donde (A) no alcance, se revisita.

### 3.2 Selectors no visibles → heurística aplicada

Si el cliente no pasa `state` explícitamente, el worker parsea el último segmento del selector y aplica:
- Tags `{script, meta, link, style, title, head}` → auto `state="attached"`.
- Cualquier otro → `state="visible"` (default histórico).
- Si el cliente pasa `state` explícito, se respeta sin tocar.

Files tocados:
- `api/models/actions/wait_for_selector_action.py`: `state` default `None` (Optional). Retro-compat: cliente que manda `"visible"` explícito tiene comportamiento idéntico a antes.
- `worker/execution/wait_for_selector.py`: helper `resolve_state(selector, state)` con regex-based tag extraction (maneja selectores compuestos tipo `body > script[type="json"]`).
- `worker/flex_features/wait_strategy.py`: misma heurística — profiles flex con `wait_strategy="selector:script#__NEXT_DATA__"` funcionan sin tener que setear state.

### Implicancia para SDK v0.4.4

- **`WaitForSelectorAction.state`** debe tipearse como `Literal["visible", "attached", "hidden"] | None = None` (default `None`, no `"visible"`). Backend aplica heurística cuando `None` viene del cliente.
- Tests del SDK pueden cubrir los 6 casos de la heurística como sanity (script default → attached, div default → visible, etc.) — pero la lógica está en el server, SDK solo la respeta.

---

## §4.respuesta + §5.respuesta — Coordinator supervision (2026-04-28)

**Routing aclarado**: el label "Workers" en §5 (y técnicamente en §3 también) es **engañoso** — no existe un team "Workers" como entidad separada desde el 2026-04-21 que se hizo el split en 7 equipos. La entidad correcta para todos estos items es **Worker Flex team**.

Mapeo correcto:

| Item del SDK 0.4.4 | Owner real | Por qué |
|---|---|---|
| §3 wait-for-selector (label "Workers") | **Worker Flex** | Action engine vive en `worker/execution/*` y `worker/flex_features/*`. Ambos son scope Flex. |
| §4 proxy + browser regresión (label "Flex") | **Worker Flex** | Correctamente labeled. Proxy injection en Playwright contexts vive en `worker/scraping_lightweight_browser.py`. |
| §5 network_capture (label "Workers") | **Worker Flex** | `network_capture` se implementa en `worker/scraping_lightweight_browser.py` también. Mismo file que el resto del browser engine. Flex. |

**No tengo que mandárselo a un team "Workers" separado** — toda la cadena `worker/execution/*` + `worker/scraping_lightweight_browser.py` + `worker/scraping_browser.py` + `worker/flex_features/*` es Flex scope. El SDK team puede haber heredado el label "Workers" de docs viejas pre-split.

Status real:
- **§3**: 🟢 Flex shipped en `58ed805` (2 días antes del handoff SDK 0.4.4).
- **§4**: 🔴 pendiente en Flex. NO está committeado todavía. El SDK team puede agregarlo a `SP API Worker Flex/handoff-coordinator-workers-flex.md` o a `handoff-action-engine-bugs.md`. Yo sumaré nota en el handoff Flex después de cerrar este file.
- **§5**: 🔴 pendiente en Flex. Idem #4.

### Recomendación process

Para futuros handoffs cross-team que SDK arme:
- Reemplazar "Workers" por "Worker Flex" en el routing label.
- "Workers" como concept hoy abarca: Worker Flex + Mascherano Infra (no más "Workers" indiferenciado). Mascherano Infra solo si es Docker/compose/host config; el resto es Flex.

Si necesitan handoffs separados a Mascherano Infra en algún caso (ej. el incidente curl_cffi missing en imágenes que descubrí hoy), los rotularían "Mascherano Infra".

### Mi acción siguiente como Coordinator

1. ✅ Update este file con la supervisión.
2. ✅ Update §0 tabla: items 1, 2, 3 + §3 a 🟢. Items 4-8 con owner correcto = **Worker Flex** (no "Workers").
3. ✅ Sumados pedidos §4 + §5 al handoff de Flex en `SP API Worker Flex/handoff-action-engine-bugs.md` (sección "Update 2026-04-28"). Flex los recoge cuando tengan ventana.
4. ✅ Bug colateral descubierto al smoke test mío: imágenes Docker de workers están desactualizadas hace 2 semanas, anteriores al commit `9388366` que agregó `curl_cffi>=0.7.0`. Resultado: dependencia faltante en runtime, ~16k jobs/día fallando silently con "No module named 'curl_cffi'". Owner: **Mascherano Infra**. Handoff entregado en `Mascherano Infra/handoff-coordinator-curl-cffi-rebuild.md` con comandos exactos de rebuild + smoke + rollback.

### Estado Coordinator side: 🟢 cerrado

Mi cancha (items 4 + 5 del §0) queda en 🟢. Items 6 (§3) también 🟢 — Flex shipped en `58ed805`. Items 7 + 8 (§4 + §5) quedan 🔴 esperando Worker Flex (sin urgencia bloqueante; clientes tienen workarounds menos óptimos).

Cuando Mascherano confirme rebuild + smoke OK, el efecto del commit `9142049` se materializa: clientes Walmart vía SDK con `browser=false` empiezan a obtener cffi automáticamente sin saber del internal. Hasta entonces, el path está cableado pero no ejecuta — pre-existente bug de imagen, no mi commit lo introdujo.

**Cierro mi sección. Pingback si descubren algo desalineado en la verificación post-Mascherano.**

---

## §4.respuesta + §5.respuesta — Worker Flex (direct, 2026-04-28)

Recibo ownership de §4 y §5 (Coordinator supervision arriba está correcta). Confirmo el routing y agrego detalle técnico + sequencing.

### §4 — regresión proxy + browser=True (alta prioridad, mío)

**Status**: 🔴 in-progress.

**Hipótesis inicial**: el delta del 2026-04-20 es flex-first-rung. Commits candidatos `9dd1056`, `9043f89`, `b6ae7aa` (mencionados por Coordinator en §4 routing). Cuando `browser=true + use_proxy="any"` entra al dispatcher, flex-first-rung corre primero; si el profile lookup o el cffi-fallback toca el `use_proxy` parcialmente y el path después al engine playwright deja un proxy mal-bound o sin auth → browser cuelga 120s en handshake. La diferencia "OK con `use_proxy=None`" + "timeout con `use_proxy="any"`" + "5 retailers afectados, todos `browser=true`" apunta ahí.

**Plan** (~2-3hs):
1. Repro con URL Hy-Vee del Caso 4 vía `/v1/sync/scrape` con `browser=true, use_proxy="any"` (esperado: timeout) y luego `use_proxy=None` (esperado: OK).
2. Comparar logs de worker entre los 2 cases para identificar dónde se rompe el proxy binding.
3. `git show` los 3 commits sospechosos para identificar el cambio que rompe el path.
4. Fix + smoke + commit a master.

**Mientras tanto, workaround para SDK team**: degradado natural ya existe — el cliente puede `use_proxy=None` para 4 de 5 retailers afectados (Smart & Final es el único sin workaround porque necesita IP US para store selection). Si el cliente tipo Hy-Vee/Food City/ShopRite/Raley's necesita inmediatez, esa es la mitigación temporal.

**Sin cambios en SDK** — bug fix puramente server-side. Cliente sigue mandando `browser=true, use_proxy="any"`.

### §5 — network_capture (planificado post §4)

**Status**: 🔴 pending, planificado para después de §4. Ack de scope.

**§5.1 listener pre-load**:
- Preferencia mía: **cambiar el default server-side a `domcontentloaded`** (o registrar el listener antes del `page.goto()`, que es estrictamente mejor). Cliente sigue mandando `network_capture: {resource_types: [...]}` y empieza a recibir XHRs de SSR hydration que antes perdía. **Sin cambios en SDK**.
- Alternativa válida: exponer `listen_from: "navigation"|"domcontentloaded"|"load"` en el modelo SDK. Es **funcional** (cliente describe qué quiere capturar), no anti-bot. OK exponerlo si SDK team lo prefiere para control fino.
- Mi voto: empezar con cambio de default (transparente). Si después aparece use case donde un cliente quiere específicamente "post-load only", entonces exponer `listen_from`.

**§5.2 capture_bodies**:
- Es feature **funcional legítima** (cliente necesita el body para encadenar requests — patrón Swiftly Firebase idToken Caso 8, o respuestas GraphQL custom). Encaja en categoría "datos para encadenar requests". **OK exponer en SDK**.
- Scope técnico: **~3-4hs server-side, no 1-2hs como sugirió Coordinator**. Necesita: `response.body()` async (Playwright), encoding base64 para binarios, cap de tamaño server-side, glob→regex del filtro URL, decisión de truncate-vs-omit cuando excede cap.
- Cap inicial recomendado: **64KB hardcoded server-side**. Si en el futuro algún caso requiere más, exponer cap como param. Por ahora un valor sano evita memory pressure.
- Filtro URL: aceptar el `capture_bodies_url_pattern` propuesto por SDK team con conversión glob→regex internamente.

**Sequencing**: §4 primero (regresión bloqueante prod). §5.1 + §5.2 juntos después. ETA combinada §5: ~5-6hs.

---

## §Walmart-update (UPDATE 2026-04-29 12:00 UTC) — regresión 91→0% RESUELTA

El informe del HTML Validator team del 2026-04-28 (`SP API HTML Validator/informe-estado-validator-2026-04-28.md` §3.2) escaló a Worker Flex como prioritario: "Walmart success cayó de 91.4% (2026-04-22) a 0% con 1972 exceptions (2026-04-24) — probable regresión engine cffi o profile, sp-lupa estaba viendo 91% success y ahora 0%".

**Verificación 2026-04-29 12:00 UTC** confirma que **YA está resuelto** sin acción Worker Flex:

| Source | Resultado |
|---|---|
| Stats logs últimas 12h, agregado 10 browser-pools | **134 `FLEX_FIRST_HIT engine=cffi domain=www.walmart.com`** / 0 FELL / 0 EXCEPTION / 0 "No module curl_cffi" errors |
| Smoke directo: `GET /seller/9193 browser=false use_proxy=any` | status 200 / exec 1.8s / html 300KB / captcha False / **success=True** / 1 credit (cffi path) |
| Profile DB unchanged: `preferred_engine=cffi, tls_impersonate=chrome, retry_on_block=3` | Match con la versión que daba 91.4% el 22-Abr |

**Root cause**: imágenes Docker desactualizadas hace 2 semanas, anteriores al commit `9388366` que agregó `curl_cffi>=0.7.0` a requirements. El dispatcher ruteaba a engine cffi correctamente pero el módulo faltaba en runtime → 1972 exceptions silenciosas el 24-Abr.

**Resolución**: Mascherano Infra rebuild de imágenes 2026-04-28/29 (handoff Coordinator §"Mi acción siguiente" punto 4 cerrado).

**Sin acción Worker Flex** — el profile cffi ya estaba correcto y bien deployado. Solo le faltaba la lib en runtime, fuera del scope Worker Flex.

**Estado**: 🟢 cerrado. No tracking adicional necesario.

---

## §4.respuesta-flex (UPDATE 2026-04-29) — investigación cerrada

**§4 (item 7): regresión proxy + `browser=True` → timeout**.

**Hallazgo después de investigar**: NO es regresión del flex-first-rung. Los logs en vivo muestran que las URLs sin profile (Hy-Vee, jimmyjohns, foodlocker, etc.) van al **ladder normal** (`AUTO escalation`), saltando flex-first correctamente. El timeout se dispara porque el ladder agota niveles:

```
DISPATCH | mode=auto (requested=heavy) | proxy=True | url=https://www.jimmyjohns.com/menu
AUTO simple:1 → fail (status=200 html=10214) 841ms       ← Cloudflare challenge mini HTML
AUTO simple:2 → fail (status=200 html=10214) 819ms
AUTO light:1 → fail (status=200 html=558890) 19098ms     ← 558KB HTML válido pero validator dice fail!
AUTO heavy:1 → ... (escalation continúa)
```

**Root cause real**: el HTML Validator legacy (`utils/captcha_detector.py`) está rechazando responses **válidos grandes** (558KB) como block. Forza escalation completa hasta heavy. Heavy con proxy es lento (60-100s). Cliente recibe timeout 120s.

Esto coincide con el informe del HTML Validator team (`SP API HTML Validator/informe-estado-validator-2026-04-28.md`):
- **§2.2 fp_fix list**: jimmyjohns aparece con 14 entries falsamente bloqueados por legacy. El validator NUEVO (`utils/html_validator.py` v0.1.6) lo arregla — pero **9 archivos del worker siguen consumiendo el legacy**, incluyendo el path del ladder normal donde caen estas URLs sin profile.
- **§3.1 Track B**: migración legacy → maduro está en scope **Workers Coordinator**, handoff completo ya entregado.

**§4 cierra cuando Track B llegue a master**. Mi parte: caso de jimmyjohns documentado y escalado. Sin acción adicional Worker Flex.

**Sin cambios SDK** — bug fix server-side cuando Track B mergee.

---

## §5.respuesta-flex (UPDATE 2026-04-29) — implementación parcial en master

### §5.1 — listener pre-load → 🟢 ya funciona

Validado contra Costco storefront: **14 network_requests capturados, 8 GraphQL Apollo persistedQuery** (`LandingCurrentUser`, `Geolocation`, `LandingAppTrackingProperties`, etc.). El listener YA se attache pre-goto (línea 535-536 del worker). El bug que reportaron en Caso 6 ("resp['network_requests'] == []") **no se reproduce hoy** — probablemente algún commit reciente lo arregló silenciosamente.

→ **No requiere cambio en SDK ni en worker**.

### §5.2 — capture body → 🟢 SHIPPED (commits `ecce15b` + `a3a35cb` + `28de6b2` en master)

**Validado end-to-end** (2026-04-29 12:00 UTC):
- Smoke `https://httpbin.org/html` con `network_capture: {resource_types:["xhr","fetch","document"], url_pattern:"*httpbin*"}`
- Resultado: `count=2, with_body=1, errs=1` (GET 200 → 3739 chars utf-8 HTML real "Moby-Dick"; GET 407 retry → body_error porque Playwright disposed la response del retry, esperado)

**Lo que el cliente recibe**:
```json
"network_requests": [
  {
    "url": "https://httpbin.org/html",
    "method": "GET",
    "status": 200,
    "resource_type": "document",
    "content_type": "text/html",
    "body": "<!DOCTYPE html>\\n<html>...",
    "body_encoding": "utf-8"
  }
]
```

Si excede 64KB → `body_truncated: true`. Si binario → `body_encoding: "base64"`. Si falla → `body_error: "<motivo>"`.

**Implementación**:
- Schema `NetworkCaptureConfig.url_pattern: Optional[str]` en `api/models/scrape_request.py`. Glob format.
- Worker en AMBAS engines (`worker/scraping_lightweight_browser.py` light/stealth + `worker/scraping_browser.py` heavy/Camoufox): regex compile glob→regex, listener `_on_response` collecta `(entry, response)` en `_body_pending` cuando URL matchea.
- Body fetch async con `asyncio.gather` paralelo y **hard cap global 5s** (`asyncio.wait_for`). Garantiza que NUNCA cuelga el response del cliente.
- Encoding utf-8 / base64 fallback. Cap 64KB por response.
- Errors capturados en `body_error` (ej. `global_timeout_5s` si wait_for dispara).

**Bug encontrado y resuelto durante validación**: el primer commit (`ecce15b`) solo patcheó el engine light. Cuando el ladder escalaba a heavy (Caso típico: site con anti-bot), la response final venía del engine heavy sin body capture. Commit `28de6b2` portó el patch a heavy también.

**Estado SDK**: cliente puede tipear `url_pattern: Optional[str]` en `NetworkCaptureConfig` sin breaking. Docstring sugerido:

```python
url_pattern: Optional[str] = Field(
    default=None,
    description=(
        "Glob pattern (e.g. '*graphql*' or '*identitytoolkit.googleapis.com*'). "
        "When set, server captures the response body for each captured request whose URL matches. "
        "Body returned in network_requests[*].body (utf-8) or base64-encoded if binary. "
        "Server-side cap: 64KB per response (body_truncated:true flag if exceeded). "
        "On capture failure: body_error field is set instead of body."
    ),
)
```

---

### Heads-up sobre policy de contrato SDK

Reviso el handoff con la línea actualizada (sign-off Lucho 2026-04-28):

> "Cliente solo elige `browser=true/false` (1 vs 5 créditos). Lo demás es cocina interna. PERO sí mantenemos exposición funcional: clicks, evaluate, http_method.url para POST a endpoints internos (Viator GraphQL-style), network_capture con body capture (Swiftly Firebase idToken-style), cookies/headers para encadenar requests."

Distinción clave para SDK team: **anti-bot fields NO se exponen** (tls_impersonate, browser_options opaque, browser_type, retry_on_block, profile params); **funcionales SÍ** (cómo describir qué hacer en la página + qué traer + qué dejar para próximo step). Aplico esto a mi response:
- §3 `state` en wait-for-selector → funcional, OK que SDK lo tipe como `Literal[...] | None = None` (default `None`, server aplica heurística cuando viene `None`).
- §5.1 `listen_from` → funcional, exponible si lo prefieren (alternativa: cambio default sin exponer).
- §5.2 `capture_bodies` + `capture_bodies_url_pattern` → funcional, exponer.

Si SDK team detecta inconsistencia con esta línea en docs nuestras (ej. Walmart aún diciendo "user puede setear `tls_impersonate`"), pingback y limpiamos.

---

## §6 Casos sin acción

| Caso | Razón |
|---|---|
| 5 (Wegmans DNS) | Limitación de red — `api.wegmans.com` no resuelve público. Workaround del scraper (usar `www.wegmans.com/api/...`) ya está en prod. |
| 7 (Firebase Referer) | Política externa de Google. No es bug nuestro. Workaround del scraper (`FIREBASE_REFERERS` map) ya está en prod. |
| 9 (URL vacía → 422) | SDK ya valida `_validate_url` antes del HTTP. Aplica solo a callers que no usan el SDK Python. |

---

## §6.5 Preguntas abiertas SDK → Coordinator + Validator (2026-04-28, segunda lectura)

Releyendo el handoff Coordinator + el informe Validator antes de implementar v0.4.4, quedaron 2 inconsistencias / huecos que necesito clarificar antes de tocar el modelo. Bumpeo a 🔴 los items 3 y 1 de §0 mientras esperamos respuesta.

> ### ⚡ Acción requerida
>
> **A Coordinator + Validator team**: por favor lean §6.5.1 y §6.5.2 abajo y respondan **una de dos**:
>
> 1. **"Ya estaba contestado en mi sección anterior"** → indicar dónde, así lo cierro como 🟢.
> 2. **"Falta respuesta"** → contestar acá abajo en la sección correspondiente, agregando `§6.5.X.respuesta — <team>`.
>
> Bloqueo el inicio de v0.4.4 hasta tener resolución de §6.5.1. §6.5.2 no bloquea (puedo arrancar con `Literal["json", "form"]` por defecto) pero conviene confirmarlo antes del merge.

### 6.5.1 🔴 → Coordinator + Validator — **shape de los campos del Validator en el response público**

Los dos handoffs describen los mismos campos pero con shape distinto:

| Handoff | Naming | Shape | Source |
|---|---|---|---|
| **Coordinator** §3 | snake_case | **top-level** en `JobExecutionPublic` | `api/llms_txt.py` y `JobExecutionPublic` actual del SDK ya está así |
| **Validator** §4.5 | camelCase | **nested** bajo objeto `validator.*` (`isSuccess`, `blockReason`, `protectionStack`, `hasExtractableData`) | Informe Validator team 2026-04-28 |

El SDK tiene hoy en `JobExecutionPublic`: `is_success`, `block_reason`, `protection_stack`, `rule_hits` — todos top-level snake_case (alineado con Coordinator).

**Pregunta**: ¿cuál es el contrato final que va a quedar en producción cuando Track B termine?

- **(A) Top-level snake_case** (como está hoy) → SDK no rompe; sólo agregamos `has_extractable_data` top-level en v0.4.4.
- **(B) Nested bajo `validator: {...}` camelCase** → tenemos que reestructurar `JobExecutionPublic` (breaking change interno) y/o tipar un wrapper `JobValidatorVerdict`. Esto sería bump más fuerte y tiene impacto en clientes que ya consumen `job.is_success`.

Si la decisión es (B), preferimos coordinarla en una versión sola (no romper en v0.4.4 y volver a romper en v0.5.0). Si es (A), avanzamos en v0.4.4 directo.

**Sugerencia SDK**: quedarse en (A) — top-level snake_case — porque ya está deployado y consumido. El namespacing camelCase del informe Validator parece descripción del objeto `Verdict` interno (`utils/html_validator.py`), no necesariamente del wire format público. Confirmar.

### 6.5.2 🔴 → Coordinator — **enum completo de `MethodPOST.content_type`**

El bug report sólo menciona `"json"` y `"form"`. Pregunta: ¿el backend acepta otros valores (`"multipart"`, `"text"`, `"xml"`, etc.)?

Si la respuesta es "solo json/form por ahora", tipamos como `Literal["json", "form"]` y agregamos más en releases futuras sin breaking. Si soportan más, mejor tiparlos todos desde v0.4.4.

### 6.5.3 🟡 → Lucho — **Enterprise token para smoke v0.4.4 pre-release**

Antes de mergear y publicar a PyPI quiero correr un smoke live (`tests/validate_criterion.py` o equivalente, batch chico). El último token Enterprise que me pasaste fue `3Fupbo6Qui4bl2w62Cz6` (2026-04-23, 5 días). ¿Sigue vigente o me pasás uno fresco cuando lleguemos a esa parte?

No bloquea implementación, solo bloquea release.

---

### 6.5.4 🔴 → Coordinator — **`ScrapeResponse` top-level verdict NO está en prod (smoke 2026-04-29)**

Antes de implementar §1.2 corrí smoke live contra `https://api.scrapingpros.com/v1/sync/scrape` con token Enterprise (Lucho 2026-04-29). Resultado:

**Request**:

```json
POST /v1/sync/scrape
{"url": "https://example.com", "format": "markdown"}
```

**Response keys reales** (top-level):

```
cookies, evaluate_results, executionTime, extracted_data, guidance, html,
markdown, message, network_requests, potentiallyBlockedByCaptcha, screenshot,
statusCode, timings
```

**Top-level verdict fields ausentes**: ninguno de los 9 que el handoff Coordinator §2 lista como contrato público está presente.

| Field esperado top-level | Presente en response real |
|---|---|
| `success` | ❌ |
| `error_type` | ❌ |
| `error_provider` | ❌ |
| `credits_charged` | ❌ |
| `credits_refunded` | ❌ |
| `next_steps` | ❌ |
| `suggested_request` | ❌ |
| `stop_reason` | ❌ |
| `custom_id` | ❌ |

`guidance` sí viene populado y completo:

```json
"guidance": {
  "success": false,
  "error_type": "captcha",
  "error_provider": null,
  "credits_charged": 0,
  "credits_refunded": true,
  "next_steps": ["This site is protected by anti-bot protection. ...", "Add retry_on_block=true to auto-retry ..."],
  "suggested_request": {"url": "https://example.com", "browser": true, "retry_on_block": true},
  "stop_reason": null
}
```

**Pregunta a Coordinator**:

- **(α)** El contrato real es **solo `guidance.*`** (top-level no se emite, nunca). El handoff §2 describe el shape interno del objeto `Verdict` Python, no el wire format. → SDK saca §1.2 del scope v0.5.0 y documenta `resp.guidance.*` como path canónico (el SDK ya lo expone hoy).
- **(β)** El contrato del handoff §2 es **futuro** — van a emitir top-level también pero no shippearon todavía. → SDK tipa los fields top-level con defaults `None` para estar ready cuando shippeen, sin breaking. Avisar cuándo va a entrar en prod.
- **(γ)** Es un bug — el contrato debería emitir top-level y no lo hace. → Lo arreglan server-side antes de v0.5.0; SDK queda esperando.

Cualquiera de las 3 sirve, pero hace falta saber cuál antes de tipar el modelo.

**Sugerencia SDK**: si la respuesta es (α), preferimos eso por consistencia con la realidad observable. `guidance` ya está expuesto en el SDK desde v0.2.2 y es el path que recomienda el ecosistema. Duplicar campos top-level es ruido.

**Status**: §1.2 bumpeado a 🔴 en §0 mientras esperamos respuesta. Implementación de §1.1, §1.3, §3.2, §5.2 sigue avanzando en paralelo (no bloqueada por esto).

> ⚡ Pedido: respuesta puntual a §6.5.4 con (α/β/γ). 5 min de su parte; destraba el último item del scope SDK v0.5.0.

---

## §6.5.respuesta — Coordinator (2026-04-28/29, post-deploy Track B)

### 6.5.1 → 🟢 resuelto: **(A) top-level snake_case**

El contrato post-Track-B es **top-level snake_case**, exactamente lo que ustedes ya tienen en `JobExecutionPublic`. Sin breaking change. Verificado en MySQL hace minutos:

```
SELECT job_public_id, is_success, has_extractable_data, validator_version, block_reason, protection_stack
FROM job_executions ORDER BY started_at DESC LIMIT 8;
→ todas las filas con valores poblados (validator_version=0.1.6, block_reason="none"/"soft_block_empty_shell", protection_stack=["cloudflare"], etc.)
```

El nested camelCase `validator: {...}` que vieron en el informe Validator era **documentación interna del objeto `Verdict` Python** (`utils/html_validator.py`), no wire format. El wire format en `JobExecutionPublic` siempre es snake_case top-level — alineado con el resto del schema del API.

**Lo que SDK tiene que tipar en v0.4.4** (todos `Optional` para retro-compat, snake_case):

```python
class JobExecutionPublic(BaseModel):
    # ... existing fields ...
    validator_version: Optional[str] = None
    block_reason: Optional[str] = None
    protection_stack: List[str] = Field(default_factory=list)
    rule_hits: List[str] = Field(default_factory=list)
    is_success: Optional[bool] = None
    has_extractable_data: Optional[bool] = None   # ← NUEVO, ya popula
    client_id: Optional[str] = None               # ← ya estaba en schema, faltaba tipar
```

`has_extractable_data` se persiste desde commit `add9338` — migration 008 (online DDL) aplicada. SDK lo va a recibir con valores reales (no NULL) en cada job procesado por el worker migrado.

### 6.5.2 → 🟢 resuelto: **`Literal["json", "form"]` solamente**

Verificado en backend `api/models/http_method/method_post.py:23`:

```python
content_type: Literal["json", "form"] = "json"
```

Y en `worker/models/http_method/method_post.py:39` hay branch específico para `"form"` y default JSON. **No hay handling para `multipart`/`text`/`xml`** — cualquier otro valor → 422 pydantic. Tipar `Literal["json", "form"]` en SDK v0.4.4. Si en el futuro se agregan, se bumpea aditivo sin breaking.

### 6.5.3 → para Lucho directo (no es scope mío).

### 6.5.4 → 🟢 resuelto: **opción (α) — `guidance.*` es el contrato real, top-level NO se emite ni se va a emitir**

Confirmado por Lucho (2026-04-29). SDK saca §1.2 del scope v0.5.0.

**Origen del confusión:** mi handoff `handoff-coordinator-sdk-doc-refresh.md` (2026-04-28) listaba esos 9 fields como "contrato público top-level" — fue **error de documentación mío**. Confundí el shape interno del objeto `Verdict`/`Guidance` Python con el wire format del endpoint sync. Lo corrijo en el doc-refresh aparte.

**Realidad confirmada por dos smokes independientes** (SDK 2026-04-29 + Coordinator 2026-04-28):
- `POST /v1/sync/scrape` → response tiene `guidance: {...}` con todos los fields adentro. Top-level NO emite `success`/`error_type`/etc.
- `GET /collections/{id}/runs/{id}/jobs` → `JobExecutionPublic` row sí tiene fields top-level snake_case (`is_success`, `block_reason`, `protection_stack`, `rule_hits`, `has_extractable_data`, etc.). **Otro contrato, no se confundir.**

**Acción SDK v0.5.0:**
- §1.2 sale del scope. `ScrapeResponse` queda como está hoy.
- Documentar `resp.guidance.*` como path canónico en docstring del modelo (single source of truth para el verdict del sync).
- Tests: ningún cambio.

**Acción Coordinator (mi cancha):**
- Corregir `handoff-coordinator-sdk-doc-refresh.md` retirando la promesa de top-level fields para `ScrapeResponse`. Marcar `guidance.*` como path canónico oficial.
- Update tabla §0 + §8 abajo: bajar item 1.2 a 🟢 (no-action SDK).

**Por qué (α) y no (β/γ):** `guidance.*` ya está diseñado, populado y exhaustivo desde antes. SDK lo expone desde v0.2.2, clientes lo consumen. Duplicar fields top-level es ruido y crea ambigüedad sin ganar nada. La política Lucho favorece contratos simples — un solo path para leer el verdict.

---

## §8 — Estado server post-deploy + recomendación v0.5.0 (Coordinator, 2026-04-29)

> **Update 2026-04-29 ~tarde**: Mascherano completó el rebuild + Flex shippeó §5.2 + reclasificó §7/§8a. SDK + Lucho deciden ir **directo a v0.5.0** (saltando v0.4.4). Esta sección refleja eso.

### 8.1 Lo que se shippeó hoy del lado server (todo en master, deployed, smoke OK)

**Coordinator (mi cancha):**

| Commit | Qué entrega | SDK puede consumir? |
|---|---|---|
| `a8c1702` | Fix `Optional` import muerto que tumbaba async-workers post-rebuild | n/a (infra) |
| `cba64e2` | **Track B completo**: 9 archivos worker → `validate_async`, helper `worker/helpers/validator_decision.py`, fallback legacy removido, tests legacy borrados, 5/5 pytest fixtures pass (jimmyjohns + getyourguide + amazon + foodcity + shoprite) | sí |
| `03ca0a7` | **Persistencia validator → `job_executions`**: `validator_version`, `block_reason`, `protection_stack`, `rule_hits` populando en cada job | sí |
| `add9338` | **`has_extractable_data` wiring + migration 008** (online DDL): tri-state TINYINT, mismo shape que `is_success` | sí |
| `0e1a3f2` | Fix profile_id propagation paths 1 (explicit flex) + cffi (browser=false transparent) | n/a (telemetry interna) |
| `17ba229` | Fix profile_id propagation path explicit modes fallback (light/stealth/heavy/simple) | n/a (telemetry interna) |

**Flex:**

| Commit | Qué entrega |
|---|---|
| `58ed805` | §3 wait-for-selector heurística (frame loss + state visible/attached) |
| `ecce15b` | **§5.2 capture response body when url_pattern matches** (schema + listener) |
| `a3a35cb` | §5.2 hard global timeout 5s on body fetch (anti-hang) |

**Mascherano:** rebuild de imágenes async-worker / browser-pool / viability con `curl_cffi 0.15.0` (timestamp 2026-04-28 13:30-14:37 UTC). Verificado en runtime — los 3 containers importan `curl_cffi` OK.

**Smoke runtime evidence:** jobs reales de sp-lupa generan `sync:flex_first:hit:www.walmart.com:p:5:2026-04-29` ⇒ Walmart con cffi profile-routed funcionando end-to-end (curl_cffi rebuilt + commit `9142049` activo + profile_id propagation correcto).

### 8.2 §0 tabla — status real post-Mascherano + post-Flex

| # | Item | Status real (2026-04-29 tarde) |
|---|---|---|
| 1.1 | `MethodPOST.content_type` | 🔴 SDK self-assigned (sin cambios) |
| 1.2 | Verdict top-level en `ScrapeResponse` | 🟢 **fuera de scope** — confirmado (α) en §6.5.4: `guidance.*` es el contrato real, top-level NO se emite. SDK no toca el modelo. |
| 1.3 | `JobExecutionPublic` faltantes | 🔴 SDK; **server populando los 5 cols (`is_success` + `block_reason` + `protection_stack` + `rule_hits` + `has_extractable_data`)** |
| 4 | Confirmación features Coordinator | 🟢 |
| 5 | Política `tls_impersonate` | 🟢 + **rebuild Mascherano completado**, walmart hit confirmado en runtime via cffi profile-routed |
| 6 | wait-for-selector | 🟢 (Flex `58ed805`) |
| 7 | proxy + browser regression | 🟢 **resuelto indirectamente**: Flex investigó, root cause = HTML Validator legacy FP, cerrado por Track B `cba64e2` (mi cancha) |
| 8a | network_capture listener pre-load | 🟢 ya funcionaba en código actual — Flex validó captura 14 XHRs Costco incluyendo 8 Apollo persistedQuery. Sin cambio |
| 8b | network_capture body capture | 🟡 **PARCIAL**: Flex shippeó schema + listener + global-timeout (`ecce15b` + `a3a35cb`). Body NO captura E2E todavía (`with_body=0` en smoke httpbin con pattern matching). Investigando mismatch entry↔response cuando hay redirects |

### 8.3 Lo que falta para v0.5.0

**Server (Flex):** ~1-2h
- §8b cierre: debug del body fetch E2E (mismatch entry↔response en redirects). Schema y wiring ya están.

**SDK (self-assigned):** ~2-3h (era ~3-4h, §1.2 salió del scope per §6.5.4)
- §1.1 `MethodPOST.content_type: Literal["json", "form"] | None = None`.
- §1.2 ❌ fuera de scope — `guidance.*` es el contrato real, ver §6.5.4. SDK solo agrega/refuerza docstring de `resp.guidance.*` como path canónico.
- §1.3 `JobExecutionPublic` + `client_id` (str), `validator_version` (Optional[str]), `has_extractable_data` (Optional[bool]). Todos snake_case top-level.
- §3.2 `WaitForSelectorAction.state: Literal["visible", "attached", "hidden"] | None = None` (default `None`, server aplica heurística).
- §5.2 `network_capture.capture_bodies: bool` + `capture_bodies_url_pattern: str | None` (tipar el shape acordado con Flex; cap 64KB es server-side hardcoded, sin param).
- Marcar `browser_type` deprecated en docstring (mantener tipado para retro-compat — política endurecida Lucho 2026-04-28 §2.3).

**Smoke + release:** ~1-2h
- Token Enterprise fresh: ✅ Lucho ya lo pasó.
- Run smoke live + verify shape MySQL columns están populando (ya verificado server-side).
- Publicar PyPI.

**Calendar realista:** 1 día calendar si SDK arranca en paralelo con Flex cerrando §8b. SDK puede tipar §5.2 ya con la signature acordada — cuando Flex cierre el debug E2E, el wire format no cambia.

### 8.4 Lo que **no** va en v0.5.0

- `browser_type="tls"` y `tls_profile="chrome_131"` (feature requests recientes SDK + API). **Rechazados**: violan política firme contractual. Solución correcta ya activa: profile-routed via `domain_profiles.preferred_engine="cffi"` — backend resuelve transparente, walmart/klook/GYG con `browser=false` van a cffi automático sin que el cliente sepa.

### 8.5 Mi cancha cierra en 🟢

- §6.5.1 → 🟢 (A) top-level snake_case (`JobExecutionPublic` async path), ya activo en producción.
- §6.5.2 → 🟢 `Literal["json", "form"]`, no hay otros valores soportados backend.
- §6.5.3 → para Lucho directo (token ya pasado).
- §6.5.4 → 🟢 (α) `guidance.*` canónico para `ScrapeResponse` sync. §1.2 sale del scope. **Pendiente mío**: corregir `handoff-coordinator-sdk-doc-refresh.md` retirando la promesa errónea de top-level fields en sync.
- Track B + persistencia + `has_extractable_data` + profile_id propagation: todo deployed y smoke OK con tráfico real.
- Item §7 cerrado retroactivamente como efecto colateral de Track B (mi commit `cba64e2`).

Pingback si descubren algo desalineado al implementar v0.5.0.

---

## §7 Convenciones de respuesta

Cada team responde **en este mismo file**, agregando una sección `§<letra>.respuesta` debajo de su sección.

- 🔴 = pendiente; 🟢 = shippeado (con commit / versión).
- Si responden con preguntas para nosotros, suben de nuevo la fila a 🔴 en §0 (recirculation rule estándar).
- Cuando todos los items de §0 estén 🟢, este file se cierra y se mueve a `issues/closed/`.

Pingback acá si algo no se entiende o si conviene partir el handoff en archivos separados después de todo.

---

## §9 v0.5.0 release status (2026-04-29) — SDK shipped, 1 follow-up server-side

**SDK v0.5.0 released** to PyPI: https://pypi.org/project/scrapingpros/0.5.0/ — main commit `4d18746`.

### 9.1 Verificación end-to-end (PyPI install + token Enterprise)

| Item | Status | Evidencia live |
|---|---|---|
| §1.1 `MethodPOST.content_type="form"` | 🟢 PASS | httpbin `/post` echo: `Content-Type: application/x-www-form-urlencoded`, `form` populated, `json: null`, `data: ""`. Body llegó form-encoded como esperado. |
| §3.2 `WaitForSelectorAction.state` | 🟢 PASS | Serialización correcta, server-side commit `58ed805` ya shipped per Flex §3. |
| §5.2 `NetworkCaptureConfig.url_pattern` | 🟢 PASS | 3739 chars utf-8 HTML body capturado en entry matching `*httpbin*`. `body_truncated: None`, `body_error: None`. |
| §1.3 `JobExecutionPublic` +3 fields | 🟡 PARCIAL | SDK tipa los 3 fields sin AttributeError. Wire format `/jobs` solo expone 1 de 3. **→ §9.2** |

### 9.2 🟡 → Coordinator (en progreso 2026-04-29) — **`validator_version` y `client_id` faltan en el serializer de `/v1/async/collections/{c}/runs/{r}/jobs`**

> Update Lucho 2026-04-29: Coordinator está implementando el fix; se da por hecho. Cuando shippeen, este item baja a 🟢.

Smoke con job recién creado (`POST /v1/async/collections/{c}/run`, espera completed, `GET .../jobs`) devuelve este shape:

```json
{
  "job_public_id": "56a34d02-8c23-4ad1-8cad-f8d03489a78d",
  "run_public_id": "...",
  "collection_id": "...",
  "status": "completed",
  "url": null,
  "custom_id": null,
  "url_truncated": false,
  "status_code": 200,
  "message": "OK",
  "queued_at": null,
  "started_at": null,
  "completed_at": null,
  "execution_time_ms": null,
  "execution_time_sec": null,
  "retries_attempted": null,
  "block_reason": null,
  "protection_stack": [],
  "rule_hits": [],
  "has_extractable_data": null,    ← presente ✅
  "is_success": null
}
```

Faltan en el response:
- ❌ `validator_version` — no incluido
- ❌ `client_id` — no incluido

Per §6.5.respuesta línea 723-731 (Coordinator 2026-04-28), MySQL ya tiene los datos populando (`validator_version=0.1.6`, etc.), pero el Pydantic response model del endpoint `/jobs` no los está exponiendo en el wire.

**Pedido**: agregar al serializer `JobExecutionPublic` server-side los campos:
- `validator_version: Optional[str]` (de `job_executions.validator_version`)
- `client_id: Optional[str]` (de `job_executions.client_id` o relación `runs.client_id` según corresponda)

**Bonus** (si está fácil): mismo serializer podría incluir también `is_success`, `block_reason`, `protection_stack`, `rule_hits`, `has_extractable_data` poblados para jobs simples (no captcha) — el smoke devolvió todo `null/[]` para `https://httpbin.org/html` que sí debería tirar `is_success=true`. Posible que el path "1-URL completed in <1s" no dispare la persistencia validator. No bloquea SDK pero vale revisar.

**Status SDK**: la implementación es aditiva no-breaking. Cuando el serializer agregue los fields, los clientes existentes los leen sin actualizar SDK. **No es bloqueante** — v0.5.0 ya en producción y el resto de features funciona.

> Pedido puntual: agregar `validator_version` + `client_id` al response de `/jobs`. ETA chica (~30 min). Cuando shippeen, lo cierro como 🟢 acá.
