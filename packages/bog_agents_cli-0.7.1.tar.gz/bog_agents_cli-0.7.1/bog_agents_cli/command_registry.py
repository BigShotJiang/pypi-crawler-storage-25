"""Central slash-command registry for bog-agents-cli.

This module is intentionally lightweight so it can be imported from startup
paths like help rendering, autocomplete wiring, and command-palette helpers
without pulling in the SDK or Textual runtime.
"""

from __future__ import annotations

from dataclasses import dataclass
from difflib import get_close_matches
from pathlib import Path


@dataclass(frozen=True, slots=True)
class SlashCommandSpec:
    """Metadata for one slash command."""

    name: str
    description: str
    hidden_keywords: str = ""
    category: str = "general"
    shortcut: str = ""
    aliases: tuple[str, ...] = ()
    available: bool = False


SLASH_COMMAND_SPECS: tuple[SlashCommandSpec, ...] = (
    SlashCommandSpec(
        "/help",
        "Show slash command help and search by keyword",
        "commands reference",
        "general",
        "?",
        available=True,
    ),
    SlashCommandSpec(
        "/agent",
        "Manage parallel agent threads and worktrees (list/spawn/panel/switch/stop)",
        "thread multi parallel worktree watch dashboard live status panel",
        "agent",
        available=True,
    ),
    SlashCommandSpec(
        "/api",
        "Send API requests and test endpoints",
        "http rest curl",
        "web",
    ),
    SlashCommandSpec(
        "/audit",
        "Audit dependencies for vulnerabilities",
        "security deps",
        "quality",
        available=True,
    ),
    SlashCommandSpec(
        "/background",
        "Manage background agent tasks (run/list/cancel/status)",
        "bg task async",
        "agent",
        available=True,
    ),
    SlashCommandSpec(
        "/branch",
        "Manage git branches for local workflows",
        "git checkout switch create",
        "git",
        available=True,
    ),
    SlashCommandSpec(
        "/changelog",
        "Open the project changelog in your browser",
        "release notes",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/clear",
        "Clear chat history and start a fresh thread",
        "reset new conversation",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/commands",
        "Browse available slash commands and quick descriptions",
        "help reference discover",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/compact",
        "Summarize conversation to reduce context usage",
        "retain keep drop summarize",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/dashboard",
        "Show the multi-agent dashboard with status and costs",
        "agents monitor panel",
        "agent",
        available=True,
    ),
    SlashCommandSpec(
        "/diff",
        "Show pending file changes as a diff",
        "changes git",
        "git",
        available=True,
    ),
    SlashCommandSpec(
        "/docs",
        "Open documentation and project guides",
        "readme api",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/doctor",
        "Run health check diagnostics for the local CLI environment",
        "check status",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/effort",
        "Set effort level (low/medium/high/max)",
        "quality speed",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/extensions",
        "Manage extensions and extensibility packages",
        "plugins marketplace",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/feedback",
        "Open the issue tracker to report a bug or request a feature",
        "bug issue request",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/harbor",
        "Harbor benchmark evaluation — run tasks, view results, check evaluation status",
        "benchmark eval terminal-bench evaluation trajectory langsmith",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/health",
        "Codebase health score and analysis",
        "quality complexity coverage",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/image",
        "Analyze images or paste from clipboard",
        "screenshot multimodal",
        "multimodal",
        available=True,
    ),
    SlashCommandSpec(
        "/init",
        "Generate `AGENTS.md` for the current repository",
        "setup agents onboard",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/infra",
        "Generate infrastructure code (Docker/K8s/Terraform)",
        "devops deploy",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/keybindings",
        "Show current keybindings or the config file path",
        "keys shortcuts",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/logs",
        "Show the log file path and recent warnings or errors",
        "debug trace errors",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/mcp",
        "MCP server marketplace — browse, install, and manage servers (jira, terraform, github…)",
        "servers tools install registry catalog marketplace plugin integration",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/migrate",
        "Plan technology migration",
        "upgrade convert",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/model",
        "Switch models or manage the default model",
        "provider swap ollama",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/model-route",
        "Configure automatic model routing",
        "auto cost optimize",
        "config",
    ),
    SlashCommandSpec(
        "/onboard",
        "Start an interactive codebase onboarding guide",
        "tour walkthrough new",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/permissions",
        "Show approval mode and shell permission settings",
        "safety approvals shell trust",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/pipeline",
        "Run a saved pipeline (chained prompts, skills, slash commands)",
        "workflow chain schedule cron automate steps yaml",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/plan",
        "Toggle read-only plan mode",
        "readonly architect",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/plugin",
        "Manage plugins and extensions — includes Claude Code skill import and MCP sync",
        "marketplace skills extensions claude-code mcp sync import compatible",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/prompt",
        "Browse and run saved prompts with variable substitution",
        "template library saved custom variable",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/pr",
        "Pull request management (create/list/review)",
        "github merge",
        "git",
        available=True,
    ),
    SlashCommandSpec(
        "/preview",
        "Start or stop local dev server preview",
        "serve browser",
        "web",
        available=True,
    ),
    SlashCommandSpec(
        "/profile",
        "Switch configuration profile",
        "config preset",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/quit",
        "Exit the app",
        "close leave",
        "general",
        aliases=("/q",),
        available=True,
    ),
    SlashCommandSpec(
        "/recommend",
        "Run AI-powered code review and recommendation flows",
        "review audit advise persona focus",
        "quality",
        available=True,
    ),
    SlashCommandSpec(
        "/record",
        "Start or stop recording session for replay",
        "capture",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/repomap",
        "Show or refresh the semantic repository map (classes, functions, imports)",
        "index codebase symbols architecture structure repo-map",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/reload",
        "Reload config from environment variables and `.env`",
        "refresh",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/remember",
        "Update memory and skills from the current conversation",
        "memory skills capture",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/remote",
        "Submit a task for remote or cloud execution",
        "cloud",
        "web",
        available=True,
    ),
    SlashCommandSpec(
        "/rewind",
        "Browse checkpoints and fork a thread from an earlier snapshot",
        "checkpoint recover restore history",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/resume",
        "Resume a saved thread by id, tag, project, or browse history",
        "continue switch history recover",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/replay",
        "Replay agent actions for debugging",
        "debug trace",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/resolve",
        "AI-assisted merge conflict resolution",
        "conflict merge",
        "git",
        available=True,
    ),
    SlashCommandSpec(
        "/review",
        "Ask the agent for a structured code review",
        "lint check staged files commit",
        "quality",
        available=True,
    ),
    SlashCommandSpec(
        "/session",
        "Show or update session label, tags, project, summary, and exports",
        "name duration info metadata",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/settings",
        "Configure providers, models, and fallbacks",
        "config preferences setup",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/skills",
        "Show loaded skills and their search paths",
        "abilities memory",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/teach",
        "Start teaching mode to learn a workflow",
        "learn skill",
        "general",
    ),
    SlashCommandSpec(
        "/team",
        "Team shared config (members, context, prompts) and multi-agent coordination",
        "enterprise org swarm coordination invite members shared context prompts config",
        "enterprise",
        available=True,
    ),
    SlashCommandSpec(
        "/think",
        "Enable extended thinking / deep reasoning on the next query",
        "reasoning cot chain-of-thought extended-thinking budget tokens anthropic gemini",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/rules",
        "Manage project rules (.bog-agents/rules/) — auto-inject contextual guidelines",
        "mdc cursor-rules guidelines standards glob always inject frontmatter",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/search",
        "Hybrid codebase search — ripgrep exact + fuzzy filename + semantic",
        "ripgrep rg find grep vector embeddings semantic hybrid",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/compress",
        "Intelligent context compression — auto-compact with ratio report and progress",
        "compact context window tokens summarize reduce packing",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/jobs",
        "Manage autonomous background jobs — list, attach, cancel, and monitor long-running tasks",
        "background async detached autonomous worktree notification webhook",
        "agent",
        available=True,
    ),
    SlashCommandSpec(
        "/langsmith",
        "LangSmith integration — browse traces, runs, evals, datasets, feedback, and OTEL setup",
        "tracing observability langchain eval runs traces feedback otel opentelemetry langchain-hub",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/workspace",
        "Multi-repository context — define repos in .bog-agents/workspace.toml",
        "multi-repo cross-repo microservices monorepo symbol resolution",
        "enterprise",
        available=True,
    ),
    SlashCommandSpec(
        "/worktrees",
        "Manage parallel git worktrees — spawn agents in isolated branches",
        "parallel agents git worktree branch isolation conflict merge",
        "enterprise",
        available=True,
    ),
    SlashCommandSpec(
        "/test",
        "Run tests with coverage and generate test skeletons",
        "coverage pytest",
        "quality",
        available=True,
    ),
    SlashCommandSpec(
        "/threads",
        "Browse and resume previous threads",
        "continue history sessions",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/tokens",
        "Show current token usage and context breakdown",
        "cost context window budget spend",
        "info",
        aliases=("/cost", "/context"),
        available=True,
    ),
    SlashCommandSpec(
        "/trace",
        "Open the current thread in LangSmith",
        "langsmith observability",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/undo",
        "Inspect or restore tracked file changes with git",
        "revert rollback",
        "git",
        available=True,
    ),
    SlashCommandSpec(
        "/vars",
        "Manage secrets and variables (API keys, URLs, tokens)",
        "secrets env config keys tokens credentials",
        "config",
        available=True,
    ),
    SlashCommandSpec(
        "/version",
        "Show CLI and SDK versions",
        "build release",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/worktree",
        "Manage git worktrees for isolated work",
        "isolate parallel",
        "git",
        available=True,
    ),
    SlashCommandSpec(
        "/checkpoint",
        "Save, load, and list named session checkpoints for easy resume",
        "save restore resume snapshot session history",
        "info",
        available=True,
    ),
    SlashCommandSpec(
        "/benchmark",
        "Run evaluation suites and view recent benchmark results",
        "eval score perf suite tasks trajectory",
        "analysis",
        available=True,
    ),
    SlashCommandSpec(
        "/build",
        "Interactive wizard — create skills, prompts, and pipelines step by step",
        "wizard create new template scaffold variablize builder",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/explain",
        "Deep-dive explanation of any symbol, file, or concept in the codebase",
        "docs understand symbol function class architecture why",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/index",
        "Build and search a local knowledge-base index of the codebase",
        "search knowledge base symbol tfidf find query",
        "general",
        available=True,
    ),
    SlashCommandSpec(
        "/ambient",
        "Manage the ambient agent daemon — autonomous scheduled and triggered agents",
        "daemon service schedule cron background autonomous trigger webhook",
        "agent",
        available=True,
    ),
)

FEATURED_HELP_COMMANDS_LEFT: tuple[str, ...] = (
    "/help",
    "/commands",
    "/model",
    "/profile",
    "/plan",
    "/effort",
    "/compact",
    "/resume",
    "/threads",
    "/session",
    "/permissions",
)

FEATURED_HELP_COMMANDS_RIGHT: tuple[str, ...] = (
    "/diff",
    "/worktree",
    "/agent",
    "/mcp",
    "/trace",
    "/tokens",
    "/background",
    "/plugin",
    "/remote",
    "/review",
    "/quit",
)


def _load_dynamic_extension_specs() -> tuple[SlashCommandSpec, ...]:
    """Load slash-command specs contributed by enabled extensions."""
    try:
        from bog_agents_cli.extensibility import get_extension_commands

        commands = get_extension_commands(Path.home() / ".bog-agents")
    except Exception:
        return ()

    specs: list[SlashCommandSpec] = []
    for command in commands:
        specs.append(
            SlashCommandSpec(
                command.name,
                command.description,
                f"extension {command.extension_name} {command.hidden_keywords}".strip(),
                "extension",
                aliases=command.aliases,
                available=True,
            )
        )
    return tuple(specs)


def _select_specs(*, include_unavailable: bool = False) -> tuple[SlashCommandSpec, ...]:
    """Return the subset of command specs to expose to users."""
    combined: list[SlashCommandSpec] = list(SLASH_COMMAND_SPECS)
    known = {spec.name for spec in combined}
    known_aliases = {
        alias for spec in combined for alias in spec.aliases if isinstance(alias, str)
    }
    for spec in _load_dynamic_extension_specs():
        if spec.name in known or spec.name in known_aliases:
            continue
        combined.append(spec)
    if include_unavailable:
        return tuple(combined)
    return tuple(spec for spec in combined if spec.available)


def _lookup_maps(
    *, include_unavailable: bool = False
) -> tuple[dict[str, SlashCommandSpec], dict[str, SlashCommandSpec]]:
    specs = _select_specs(include_unavailable=include_unavailable)
    by_name = {spec.name: spec for spec in specs}
    by_alias = {alias: spec for spec in specs for alias in spec.aliases}
    return by_name, by_alias


def get_registered_command_names(
    *, include_aliases: bool = False, include_unavailable: bool = False
) -> list[str]:
    """Return registered command names for the requested command surface."""
    names = [
        spec.name for spec in _select_specs(include_unavailable=include_unavailable)
    ]
    if include_aliases:
        for spec in _select_specs(include_unavailable=include_unavailable):
            names.extend(spec.aliases)
    return names


def get_slash_commands(
    *, include_unavailable: bool = False
) -> list[tuple[str, str, str]]:
    """Return autocomplete-friendly slash command tuples."""
    return [
        (spec.name, spec.description, spec.hidden_keywords)
        for spec in _select_specs(include_unavailable=include_unavailable)
    ]


def get_command_palette_specs(
    *, include_unavailable: bool = False
) -> list[SlashCommandSpec]:
    """Return command specs suitable for palette and search views."""
    return list(_select_specs(include_unavailable=include_unavailable))


def get_command_spec(
    name: str, *, include_unavailable: bool = False
) -> SlashCommandSpec | None:
    """Look up one command spec by slash name or alias."""
    normalized = name.strip().lower()
    by_name, by_alias = _lookup_maps(include_unavailable=include_unavailable)
    spec = by_name.get(normalized) or by_alias.get(normalized)
    if spec is None:
        return None
    return spec


def describe_commands(
    command_names: tuple[str, ...] | list[str],
) -> list[tuple[str, str]]:
    """Return `(name, description)` pairs for known commands."""
    pairs: list[tuple[str, str]] = []
    for name in command_names:
        spec = get_command_spec(name)
        if spec is not None:
            pairs.append((spec.name, spec.description))
    return pairs


def search_slash_commands(
    query: str, *, limit: int = 8, include_unavailable: bool = False
) -> list[SlashCommandSpec]:
    """Search slash commands with fuzzy matching."""
    specs = _select_specs(include_unavailable=include_unavailable)
    normalized = query.lower().strip().lstrip("/")
    if not normalized:
        return list(specs[:limit])

    matches: list[tuple[int, SlashCommandSpec]] = []
    for spec in specs:
        names = [
            spec.name.lstrip("/"),
            *(alias.lstrip("/") for alias in spec.aliases),
        ]
        score = 0
        if normalized in names:
            score += 100
        if any(name.startswith(normalized) for name in names):
            score += 60
        elif any(normalized in name for name in names):
            score += 40
        if normalized in spec.description.lower():
            score += 20
        if normalized and any(
            normalized in keyword for keyword in spec.hidden_keywords.lower().split()
        ):
            score += 15
        if score:
            matches.append((score, spec))

    if not matches:
        close_lookup = {
            spec_name: spec
            for spec in specs
            for spec_name in [
                spec.name.lstrip("/"),
                *(alias.lstrip("/") for alias in spec.aliases),
            ]
        }
        close = get_close_matches(
            normalized,
            list(close_lookup),
            n=limit,
            cutoff=0.6,
        )
        deduped = {close_lookup[name].name: close_lookup[name] for name in close}
        matches = [(10, spec) for spec in deduped.values()]

    matches.sort(key=lambda item: (-item[0], item[1].name))
    return [spec for _score, spec in matches[:limit]]
