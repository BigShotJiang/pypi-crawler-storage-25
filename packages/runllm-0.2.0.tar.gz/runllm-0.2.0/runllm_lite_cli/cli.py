"""Command line entrypoint for the RunLLM Lite CLI."""

from __future__ import annotations

import argparse
import asyncio
import getpass
import os
import select
import signal
import subprocess
import sys
import threading
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from runllm_lite_cli import __version__
from runllm_lite_cli.client import (
    EngineClientError,
    PROACTIVE_GCP_DISCOVERY_PROMPT,
    ProactiveDiscoverySession,
    run_ask,
    run_interactive,
)
from runllm_lite_cli.config import (
    CliConfig,
    GcpObservabilityConfig,
    GrafanaConfig,
    KubectlConfig,
    ToolConfigs,
    _default_kubeconfig_path,
    configure_logging,
    load_config,
    save_config,
    validate_engine_url,
    validate_binary,
    validate_kubeconfig,
    validate_kubectl,
    validate_repo_path,
)
from runllm_lite_cli.credentials import (
    Credentials,
    load_credentials,
    save_credentials,
    validate_api_key,
)
from runllm_lite_cli.grafana import ensure_mcp_grafana

_ACTIVE_ARCHIVE_PATH: Path | None = None
PROD_ENGINE_URL = "https://gateway.runllm.com"
PROD_AUTH_URL = "https://cli.runllm.com"
DEV_ENGINE_URL = "http://127.0.0.1:5099"
DEV_AUTH_URL = "http://localhost:5185"
SCAN_MAX_FILES = 2_000
SCAN_MAX_FILE_BYTES = 32_000
SCAN_SKIP_DIRS = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "venv",
}
SCAN_TEXT_SUFFIXES = {
    ".cfg",
    ".conf",
    ".go",
    ".ini",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".py",
    ".sh",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".yaml",
    ".yml",
}
SUPPORTED_TOOL_HINTS = {
    "grafana": ("grafana", "loki", "prometheus", "promql", "dashboard", "datasource"),
    "gcp_observability": (
        "cloud logging",
        "error reporting",
        "gcloud",
        "google_cloud",
        "logging.googleapis.com",
        "monitoring.googleapis.com",
    ),
    "kubectl": ("deployment.yaml", "helm", "k8s", "kubectl", "kubernetes", "namespace", "statefulset"),
}


def _is_dev_mode() -> bool:
    return os.getenv("RUNLLM_LITE_ENV", "").lower() in {"dev", "local"}


def _default_engine_url() -> str:
    return os.getenv("RUNLLM_LITE_ENGINE_URL") or (
        DEV_ENGINE_URL if _is_dev_mode() else PROD_ENGINE_URL
    )


def _default_auth_url() -> str:
    return os.getenv("RUNLLM_LITE_AUTH_URL") or (DEV_AUTH_URL if _is_dev_mode() else PROD_AUTH_URL)


@dataclass
class RepoScanHandle:
    repo_path: Path
    thread: threading.Thread | None = None
    matches: set[str] | None = None
    error: str | None = None


def _hard_exit_interactive(_signum: int, _frame: object) -> None:
    print()
    if _ACTIVE_ARCHIVE_PATH is not None:
        try:
            _ACTIVE_ARCHIVE_PATH.unlink(missing_ok=True)
        except Exception:
            pass
    os._exit(130)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="runllm",
        description="RunLLM Lite incident investigation CLI",
    )
    parser.add_argument("--verbose", action="store_true", help="Print debug logs to the console.")
    parser.add_argument("--version", action="version", version=f"runllm {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    configure_parser = subparsers.add_parser(
        "configure",
        help="Configure the Lite engine URL and repo path.",
    )
    configure_parser.add_argument("--engine-url", default=None, help="Lite engine URL.")
    configure_parser.add_argument("--repo-path", default=None, help="Path to the local cloned repo.")
    configure_parser.add_argument("--auth-url", default=None, help="RunLLM Lite auth UI URL.")
    configure_parser.add_argument(
        "--api-key",
        nargs="?",
        const="",
        default=None,
        help="Validate and cache a RunLLM API key. Omit the value to enter it securely.",
    )

    tools_parser = subparsers.add_parser("tools", help="Configure and inspect local tool integrations.")
    tools_subparsers = tools_parser.add_subparsers(dest="tools_command")
    tools_subparsers.add_parser("list", help="List configured local tools.")

    kubectl_parser = tools_subparsers.add_parser("configure-kubectl", help="Configure local kubectl access.")
    kubectl_parser.add_argument("--kubectl-path", default=None, help="Path to kubectl. Defaults to PATH lookup.")
    kubectl_parser.add_argument(
        "--kubeconfig",
        default=None,
        help="Path to kubeconfig. Defaults to KUBECONFIG or ~/.kube/config when present.",
    )

    grafana_parser = tools_subparsers.add_parser(
        "configure-grafana",
        help="Configure local Grafana MCP access.",
    )
    grafana_parser.add_argument("--grafana-url", default=None, help="Grafana base URL.")
    grafana_parser.add_argument("--service-account-token", default=None, help="Grafana service account token.")
    grafana_parser.add_argument("--mcp-grafana-path", default=None, help="Path to mcp-grafana.")
    grafana_parser.add_argument(
        "--no-auto-install",
        action="store_true",
        help="Do not download mcp-grafana if it is not installed.",
    )

    gcp_parser = tools_subparsers.add_parser(
        "configure-gcp-observability",
        help="Configure local gcloud observability access.",
    )
    gcp_parser.add_argument(
        "--gcloud-path",
        default=None,
        help="Path to gcloud. Defaults to PATH lookup.",
    )
    gcp_parser.add_argument("--project", default=None, help="Default Google Cloud project ID.")

    ask_parser = subparsers.add_parser(
        "ask",
        help="Ask one question with the configured repo and local tools.",
    )
    ask_parser.add_argument("question", nargs="+", help="Question to ask RunLLM.")

    investigate_parser = subparsers.add_parser(
        "investigate",
        help="Alias for `runllm ask`.",
    )
    investigate_parser.add_argument("question", nargs="+", help="Question to ask RunLLM.")
    return parser


def _configure(args: argparse.Namespace) -> int:
    try:
        existing_config = _load_config_or_none()
        engine_url_value = args.engine_url or _prompt_default(
            "Engine URL",
            existing_config.engine_url if existing_config else _default_engine_url(),
        )
        repo_path_value = args.repo_path or _prompt_default(
            "Repo path",
            existing_config.repo_path if existing_config else str(Path.cwd()),
        )
        auth_url_value = args.auth_url or _prompt_default(
            "Auth UI URL",
            existing_config.auth_url if existing_config else _default_auth_url(),
        )
        engine_url = validate_engine_url(engine_url_value)
        repo_path = validate_repo_path(repo_path_value)
    except ValueError as e:
        logger.error("Configuration failed: {}\n", e)
        return 1

    config = CliConfig(
        engine_url=engine_url,
        repo_path=str(repo_path),
        auth_url=auth_url_value.rstrip("/"),
        tools=existing_config.tools if existing_config else ToolConfigs(),
        created_by_version=__version__,
        metadata={"repo_path_was_relative": str(not Path(repo_path_value).is_absolute())},
    )
    save_config(config)
    if args.api_key is not None:
        try:
            _configure_api_key(config, args.api_key)
        except ValueError as e:
            logger.error("API key configuration failed: {}\n", e)
            return 1
    print("RunLLM configured successfully.")
    print(f"Engine URL: {config.engine_url}")
    print(f"Auth URL: {config.auth_url}")
    print(f"Repo path: {config.repo_path}")
    print(
            "Run `runllm tools configure-kubectl`, `runllm tools configure-gcp-observability`, "
        "or `runllm tools configure-grafana` to enable local tools."
    )
    return 0


def _prompt_default(label: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    if value:
        return value
    if default:
        return default
    raise ValueError(f"{label} is required.")


def _prompt_optional(label: str, default: str | None = None) -> str | None:
    suffix = f" [{default}]" if default else " [optional]"
    value = input(f"{label}{suffix}: ").strip()
    if value:
        return value
    return default


def _prompt_secret(label: str, existing_value: str | None = None) -> str:
    suffix = " [existing value]" if existing_value else ""
    value = getpass.getpass(f"{label}{suffix}: ").strip()
    if value:
        return value
    if existing_value:
        return existing_value
    raise ValueError(f"{label} is required.")


def _prompt_yes_no(label: str, *, default: bool) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    value = input(f"{label}{suffix}: ").strip().lower()
    if not value:
        return default
    if value in {"y", "yes"}:
        return True
    if value in {"n", "no"}:
        return False
    raise ValueError(f"Please answer yes or no for: {label}")


def _load_config_or_none() -> CliConfig | None:
    try:
        return load_config()
    except ValueError:
        return None


def _create_first_run_auth_config() -> CliConfig:
    print("Welcome to RunLLM. Let's connect your CLI.")
    return CliConfig(
        engine_url=_default_engine_url(),
        repo_path=str(Path.cwd().resolve()),
        auth_url=_default_auth_url(),
        tools=ToolConfigs(),
        created_by_version=__version__,
        metadata={"repo_path_was_relative": "False"},
    )


def _finish_first_run_config(config: CliConfig) -> tuple[CliConfig, RepoScanHandle]:
    repo_path_value = _prompt_default("Which repository should RunLLM use?", str(Path.cwd()))
    repo_path = validate_repo_path(repo_path_value)
    config = config.model_copy(
        update={
            "repo_path": str(repo_path),
            "metadata": {
                **config.metadata,
                "repo_path_was_relative": str(not Path(repo_path_value).is_absolute()),
            },
        }
    )
    save_config(config)
    scan_handle = _start_repo_scan(repo_path)
    print(f"RunLLM will connect to {config.engine_url}.")
    return config, scan_handle


def _configure_api_key(config: CliConfig, api_key_arg: str) -> None:
    api_key = api_key_arg.strip() or getpass.getpass("RunLLM API key: ").strip()
    if not api_key:
        raise ValueError("API key must not be empty.")
    credentials = validate_api_key(config.engine_url, api_key)
    save_credentials(credentials)
    print("RunLLM API key saved.")


def _ensure_credentials(config: CliConfig) -> Credentials:
    credentials = load_credentials()
    if credentials is not None:
        return credentials
    print("RunLLM needs an API key before connecting to the Lite engine.")
    print(f"Open this URL, sign in, then paste the displayed API key here:\n{config.auth_url}")
    api_key = getpass.getpass("RunLLM API key: ").strip()
    if not api_key:
        raise ValueError("API key must not be empty.")
    credentials = validate_api_key(config.engine_url, api_key)
    save_credentials(credentials)
    print("RunLLM API key saved.")
    return credentials


def _ensure_cli_setup(*, allow_proactive_discovery: bool = False) -> tuple[
    CliConfig,
    Credentials,
    ProactiveDiscoverySession | None,
]:
    config = _load_config_or_none()
    scan_handle: RepoScanHandle | None = None
    proactive_session: ProactiveDiscoverySession | None = None
    is_first_run = False
    if config is None:
        config = _create_first_run_auth_config()
        is_first_run = True
    credentials = _ensure_credentials(config)
    if is_first_run:
        config, scan_handle = _finish_first_run_config(config)
        config, proactive_session = _configure_detected_tools(
            config,
            scan_handle,
            credentials,
            allow_proactive_discovery=allow_proactive_discovery,
        )
    return config, credentials, proactive_session


def _start_repo_scan(repo_path: Path) -> RepoScanHandle:
    handle = RepoScanHandle(repo_path=repo_path)

    def scan() -> None:
        try:
            handle.matches = _scan_repo_for_supported_tools(repo_path)
        except Exception as e:
            handle.error = str(e)
            logger.warning("Repo integration scan failed: repo_path={} error={}\n", repo_path, e)

    thread = threading.Thread(target=scan, name="runllm-repo-scan", daemon=True)
    handle.thread = thread
    thread.start()
    return handle


def _scan_repo_for_supported_tools(repo_path: Path) -> set[str]:
    matches: set[str] = set()
    scanned_files = 0
    for relative_path in _iter_scan_candidate_paths(repo_path):
        if scanned_files >= SCAN_MAX_FILES:
            break
        scanned_files += 1
        lowered_path = relative_path.lower()
        for tool_name, keywords in SUPPORTED_TOOL_HINTS.items():
            if any(keyword in lowered_path for keyword in keywords):
                matches.add(tool_name)
        file_path = repo_path / relative_path
        try:
            content = file_path.read_text(errors="ignore")[:SCAN_MAX_FILE_BYTES].lower()
        except Exception:
            continue
        for tool_name, keywords in SUPPORTED_TOOL_HINTS.items():
            if any(keyword in content for keyword in keywords):
                matches.add(tool_name)
    logger.info(
        "Repo integration scan completed: repo_path={} scanned_files={} matches={}\n",
        repo_path,
        scanned_files,
        sorted(matches),
    )
    return matches


def _iter_scan_candidate_paths(repo_path: Path) -> list[str]:
    try:
        result = subprocess.run(
            ["git", "ls-files"],
            cwd=repo_path,
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return [
                path
                for path in result.stdout.splitlines()
                if path and _should_scan_relative_path(Path(path))
            ]
    except Exception as e:
        logger.info("git ls-files unavailable for repo scan: repo_path={} error={}\n", repo_path, e)
    candidates: list[str] = []
    for path in repo_path.rglob("*"):
        if not path.is_file():
            continue
        relative_path = path.relative_to(repo_path)
        if _should_scan_relative_path(relative_path):
            candidates.append(str(relative_path))
    return candidates


def _should_scan_relative_path(relative_path: Path) -> bool:
    if any(part in SCAN_SKIP_DIRS for part in relative_path.parts):
        return False
    suffix = relative_path.suffix.lower()
    return suffix in SCAN_TEXT_SUFFIXES or not suffix


def _configure_detected_tools(
    config: CliConfig,
    scan_handle: RepoScanHandle | None,
    credentials: Credentials,
    *,
    allow_proactive_discovery: bool,
) -> tuple[CliConfig, ProactiveDiscoverySession | None]:
    print("\nChecking for local tools RunLLM can use...")
    had_gcp_config_at_start = config.tools.gcp_observability is not None
    config = _maybe_configure_detected_kubectl(config)
    had_gcp_config = config.tools.gcp_observability is not None
    config = _maybe_configure_detected_gcloud(config)
    proactive_session: ProactiveDiscoverySession | None = None
    if allow_proactive_discovery and not had_gcp_config and config.tools.gcp_observability is not None:
        proactive_session = _start_proactive_gcp_discovery(config, credentials)
    save_config(config)
    config = _handle_repo_scan_suggestions(config, scan_handle)
    if (
        allow_proactive_discovery
        and proactive_session is None
        and not had_gcp_config_at_start
        and config.tools.gcp_observability is not None
    ):
        proactive_session = _start_proactive_gcp_discovery(config, credentials)
    _print_tool_registration_hint()
    return config, proactive_session


def _start_proactive_gcp_discovery(
    config: CliConfig,
    credentials: Credentials,
) -> ProactiveDiscoverySession:
    print("Starting proactive GCP discovery in the background.")
    proactive_session = ProactiveDiscoverySession(
        config=config,
        repo_path=Path(config.repo_path),
        api_key=credentials.api_key,
        prompt_text=PROACTIVE_GCP_DISCOVERY_PROMPT,
    )
    proactive_session.start()
    return proactive_session


def _maybe_configure_detected_kubectl(config: CliConfig) -> CliConfig:
    if config.tools.kubectl is not None:
        return config
    try:
        kubectl_path = validate_kubectl()
    except ValueError:
        print("kubectl was not detected.")
        return config
    if not _prompt_yes_no(f"Detected kubectl at {kubectl_path}. Configure Kubernetes access?", default=True):
        return config
    default_kubeconfig = _default_kubeconfig_path()
    kubeconfig_value = _prompt_optional(
        "Kubeconfig path",
        str(default_kubeconfig) if default_kubeconfig else None,
    )
    kubeconfig_path = validate_kubeconfig(kubeconfig_value)
    config.tools.kubectl = KubectlConfig(
        kubectl_path=kubectl_path,
        kubeconfig_path=str(kubeconfig_path) if kubeconfig_path else None,
    )
    print("kubectl configured.")
    return config


def _maybe_configure_detected_gcloud(config: CliConfig) -> CliConfig:
    if config.tools.gcp_observability is not None:
        return config
    try:
        gcloud_path = validate_binary("gcloud")
    except ValueError:
        print("gcloud was not detected.")
        return config
    if not _prompt_yes_no(
        f"Detected gcloud at {gcloud_path}. Configure Google Cloud observability?",
        default=True,
    ):
        return config
    default_project = _default_gcloud_project(gcloud_path)
    project_id = _prompt_optional("Default Google Cloud project", default_project)
    config.tools.gcp_observability = GcpObservabilityConfig(
        gcloud_path=gcloud_path,
        project_id=project_id,
    )
    print("Google Cloud observability configured.")
    return config


def _default_gcloud_project(gcloud_path: str) -> str | None:
    try:
        result = subprocess.run(
            [gcloud_path, "config", "get-value", "project"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception as e:
        logger.info("Unable to read default gcloud project: error={}\n", e)
        return None
    project = result.stdout.strip()
    if result.returncode != 0 or not project or project == "(unset)":
        return None
    return project


def _handle_repo_scan_suggestions(
    config: CliConfig,
    scan_handle: RepoScanHandle | None,
) -> CliConfig:
    if scan_handle is None:
        print()
        print("Repo scan found supported integrations: none")
        return config
    if scan_handle.thread is not None and scan_handle.thread.is_alive():
        print()
        print("Repo scan is still running; skipping repo-based integration suggestions for now.")
        return config
    if scan_handle.error:
        print()
        print(f"Repo scan failed: {scan_handle.error}")
        print("Repo scan found supported integrations: none")
        return config
    matches = scan_handle.matches or set()
    print()
    print(f"Repo scan found supported integrations: {_format_scan_matches(matches)}")
    if "grafana" in matches and config.tools.grafana is None:
        print("We noticed this repo references Grafana/Loki/Prometheus.")
        if _prompt_yes_no(
            "RunLLM can query Grafana during investigations. Configure Grafana now?",
            default=False,
        ):
            result = _configure_grafana(
                argparse.Namespace(
                    grafana_url=None,
                    service_account_token=None,
                    mcp_grafana_path=None,
                    no_auto_install=False,
                )
            )
            if result == 0:
                config = load_config()
    if "gcp_observability" in matches and config.tools.gcp_observability is None:
        print("We noticed this repo references Google Cloud observability.")
        if _prompt_yes_no("Configure Google Cloud observability now?", default=False):
            config = _maybe_configure_detected_gcloud(config)
            save_config(config)
    if "kubectl" in matches and config.tools.kubectl is None:
        print("We noticed this repo references Kubernetes.")
        if _prompt_yes_no("Configure Kubernetes access now?", default=False):
            config = _maybe_configure_detected_kubectl(config)
            save_config(config)
    return config


def _format_scan_matches(matches: set[str]) -> str:
    if not matches:
        return "none"
    return ", ".join(sorted(matches))


def _print_tool_registration_hint() -> None:
    print(
        "\n"
        "You can add or update integrations later with `runllm tools configure-kubectl`, "
        "`runllm tools configure-gcp-observability`, or `runllm tools configure-grafana`."
    )


def _tools(args: argparse.Namespace) -> int:
    if args.tools_command == "list":
        return _list_tools()
    if args.tools_command == "configure-kubectl":
        return _configure_kubectl(args)
    if args.tools_command == "configure-grafana":
        return _configure_grafana(args)
    if args.tools_command == "configure-gcp-observability":
        return _configure_gcp_observability(args)
    print("Run `runllm tools --help` for available tool commands.")
    return 1


def _list_tools() -> int:
    try:
        config = load_config()
    except ValueError as e:
        logger.error("{}\n", e)
        return 1
    kubectl = config.tools.kubectl
    grafana = config.tools.grafana
    gcp_observability = config.tools.gcp_observability
    print("Configured tools")
    print(f"- kubectl: {'enabled' if kubectl and kubectl.enabled else 'not configured'}")
    if kubectl:
        print(f"  kubectl path: {kubectl.kubectl_path}")
        print(f"  kubeconfig: {kubectl.kubeconfig_path or 'kubectl default'}")
    print(f"- grafana: {'enabled' if grafana and grafana.enabled else 'not configured'}")
    if grafana:
        print(f"  Grafana URL: {grafana.grafana_url}")
        print(f"  mcp-grafana: {grafana.mcp_grafana_path}")
    print(
        f"- gcp_observability: "
        f"{'enabled' if gcp_observability and gcp_observability.enabled else 'not configured'}"
    )
    if gcp_observability:
        print(f"  gcloud: {gcp_observability.gcloud_path}")
        print(f"  project: {gcp_observability.project_id or 'gcloud default'}")
    return 0


def _configure_kubectl(args: argparse.Namespace) -> int:
    try:
        config = load_config()
        kubectl_path = (
            validate_binary("kubectl", args.kubectl_path)
            if args.kubectl_path
            else validate_kubectl()
        )
        kubeconfig_path = validate_kubeconfig(args.kubeconfig)
    except ValueError as e:
        logger.error("kubectl configuration failed: {}\n", e)
        return 1
    config.tools.kubectl = KubectlConfig(
        kubectl_path=kubectl_path,
        kubeconfig_path=str(kubeconfig_path) if kubeconfig_path else None,
    )
    save_config(config)
    print("kubectl configured successfully.")
    print(f"kubectl: {kubectl_path}")
    print(f"kubeconfig: {config.tools.kubectl.kubeconfig_path or 'kubectl default'}")
    return 0


def _configure_grafana(args: argparse.Namespace) -> int:
    try:
        config = load_config()
        existing_grafana = config.tools.grafana
        grafana_url = args.grafana_url or _prompt_default(
            "Grafana URL",
            existing_grafana.grafana_url if existing_grafana else None,
        )
        service_account_token = args.service_account_token or _prompt_secret(
            "Grafana service account token",
            existing_grafana.service_account_token if existing_grafana else None,
        )
        mcp_grafana_path = ensure_mcp_grafana(
            args.mcp_grafana_path,
            auto_install=not args.no_auto_install,
        )
    except ValueError as e:
        logger.error("Grafana configuration failed: {}\n", e)
        return 1
    config.tools.grafana = GrafanaConfig(
        mcp_grafana_path=mcp_grafana_path,
        grafana_url=grafana_url.rstrip("/"),
        service_account_token=service_account_token,
    )
    save_config(config)
    print("Grafana configured successfully.")
    return 0


def _configure_gcp_observability(args: argparse.Namespace) -> int:
    try:
        config = load_config()
        gcloud_path = validate_binary("gcloud", args.gcloud_path)
    except ValueError as e:
        logger.error("GCP observability configuration failed: {}\n", e)
        return 1
    config.tools.gcp_observability = GcpObservabilityConfig(
        gcloud_path=gcloud_path,
        project_id=args.project,
    )
    save_config(config)
    print("GCP observability configured successfully.")
    print(f"gcloud: {gcloud_path}")
    print(f"project: {args.project or 'gcloud default'}")
    return 0


def _run_question(question: str, *, interactive: bool) -> int:
    try:
        config, credentials, proactive_session = _ensure_cli_setup()
        if proactive_session is not None:
            proactive_session.discard()
        repo_path = validate_repo_path(config.repo_path)
        if not question:
            raise ValueError("Question must not be empty.")
    except ValueError as e:
        logger.error("RunLLM setup failed: {}\n", e)
        return 1

    try:
        if interactive:
            return asyncio.run(run_interactive(config, question, repo_path, credentials.api_key))
        return asyncio.run(run_ask(config, question, repo_path, credentials.api_key))
    except KeyboardInterrupt:
        logger.warning("RunLLM interrupted by user.\n")
        return 130
    except EngineClientError as e:
        logger.error("Engine client error: {}\n", e)
        return 1
    except Exception as e:
        logger.exception("RunLLM failed: {}\n", e)
        return 1


def _ask(args: argparse.Namespace) -> int:
    return _run_question(" ".join(args.question).strip(), interactive=False)


def _read_first_prompt_or_surface_proactive(
    proactive_session: ProactiveDiscoverySession | None,
) -> str | None:
    if proactive_session is None:
        return input("RunLLM> ").strip()
    sys.stdout.write("RunLLM> ")
    sys.stdout.flush()
    while True:
        if proactive_session.ready_event.is_set():
            if proactive_session.error:
                logger.warning("Proactive discovery finished with error: {}\n", proactive_session.error)
                proactive_session = None
                continue
            if proactive_session.final_text:
                sys.stdout.write("\r\033[K")
                sys.stdout.flush()
                return None
            proactive_session = None
            continue
        readable, _, _ = select.select([sys.stdin], [], [], 0.2)
        if readable:
            value = sys.stdin.readline()
            if value == "":
                raise EOFError()
            if proactive_session is not None:
                proactive_session.discard()
            return value.strip()


def _run_adopted_proactive_session(proactive_session: ProactiveDiscoverySession) -> int:
    print()
    print("RunLLM proactive discovery")
    print("──────────────────────────")
    print(proactive_session.final_text)
    print("\nType a follow-up question, or /exit to quit.")
    while True:
        try:
            next_prompt = input("\nRunLLM> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            proactive_session.close()
            return 0
        if next_prompt in {"/exit", "exit", "quit", "/quit"}:
            proactive_session.close()
            return 0
        if not next_prompt:
            continue
        try:
            response = proactive_session.ask_followup(next_prompt, stream_events=True)
        except EngineClientError as e:
            logger.error("Engine client error: {}\n", e)
            proactive_session.close()
            return 1
        print("\nRunLLM response")
        print("────────────────")
        print(response)


def _interactive() -> int:
    try:
        _config, _credentials, proactive_session = _ensure_cli_setup(
            allow_proactive_discovery=True,
        )
        first_question = _read_first_prompt_or_surface_proactive(proactive_session)
    except (EOFError, KeyboardInterrupt):
        return 0
    except ValueError as e:
        logger.error("RunLLM setup failed: {}\n", e)
        return 1
    previous_handler = signal.signal(signal.SIGINT, _hard_exit_interactive)
    try:
        if first_question is None and proactive_session is not None:
            return _run_adopted_proactive_session(proactive_session)
        if first_question in {"/exit", "exit", "quit", "/quit"}:
            if proactive_session is not None:
                proactive_session.discard()
            return 0
        return _run_question(first_question, interactive=True)
    finally:
        signal.signal(signal.SIGINT, previous_handler)


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()
    configure_logging(verbose=args.verbose)
    if args.command == "configure":
        raise SystemExit(_configure(args))
    if args.command == "tools":
        raise SystemExit(_tools(args))
    if args.command in {"ask", "investigate"}:
        raise SystemExit(_ask(args))
    if args.command is None:
        raise SystemExit(_interactive())
    parser.error(f"Unknown command: {args.command}")


if __name__ == "__main__":
    main()
