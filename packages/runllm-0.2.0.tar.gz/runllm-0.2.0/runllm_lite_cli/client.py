"""RunLLM Lite engine client."""

from __future__ import annotations

import asyncio
import json
import queue
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from loguru import logger
from websockets.asyncio.client import connect as ws_connect
from websockets.exceptions import ConnectionClosed

from runllm_lite_cli import __version__
from runllm_lite_cli.archive import RepoSnapshotReuse, collect_git_repo_metadata, create_repo_archive
from runllm_lite_cli.config import CliConfig
from runllm_lite_cli.protocol import (
    CloseSessionMessage,
    CommandRequestMessage,
    ErrorMessage,
    FinalRcaMessage,
    OpenCodeEventMessage,
    ProgressMessage,
    RepoMetadata,
    RepoUploadCompleteMessage,
    ResumeSessionMessage,
    SessionAcceptedMessage,
    SessionInitMessage,
    UserMessage,
    parse_engine_message,
)
from runllm_lite_cli.tools import configured_tool_capabilities, execute_tool_request

ARCHIVE_CHUNK_BYTES = 512 * 1024
WEBSOCKET_PING_INTERVAL_SEC = 10
WEBSOCKET_PING_TIMEOUT_SEC = 20
WEBSOCKET_RECONNECT_RETRY_SEC = 2
WEBSOCKET_RECONNECT_MAX_WAIT_SEC = 60
PROACTIVE_GCP_DISCOVERY_PROMPT = """This is a proactive RunLLM discovery shown before the user asks their first question.

Inspect the user's configured GCP observability data using as few tool calls as possible. Find one recent meaningful Error Reporting group or recent high-severity logging signal. Explain what it appears to be about in a helpful, non-alarming tone.

Format the final answer for proactive surfacing:
- Start with: "I proactively checked recent GCP signals and found..."
- Keep it under 5 sentences.
- Mention the evidence source briefly.
- If there is no recent signal, say that clearly and suggest what the user can ask next.
- Do not use RCA formatting unless there is a clear incident-like signal.
"""


class EngineClientError(Exception):
    """Raised when the CLI cannot talk to the Lite engine."""


class ProactiveDiscoverySession:
    """Background RunLLM session that can be adopted for interactive follow-ups."""

    def __init__(self, config: CliConfig, repo_path: Path, api_key: str, prompt_text: str) -> None:
        self.config = config
        self.repo_path = repo_path
        self.api_key = api_key
        self.prompt_text = prompt_text
        self.ready_event = threading.Event()
        self.final_text: str | None = None
        self.error: str | None = None
        self._followup_queue: queue.Queue[tuple[str, bool] | None] = queue.Queue()
        self._response_queue: queue.Queue[tuple[str | None, str | None]] = queue.Queue()
        self._discarded = False
        self._thread = threading.Thread(
            target=self._run_thread,
            name="runllm-proactive-discovery",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def discard(self) -> None:
        self._discarded = True
        self._followup_queue.put(None)

    def close(self) -> None:
        self._followup_queue.put(None)

    def ask_followup(self, prompt_text: str, *, stream_events: bool = False) -> str:
        self._followup_queue.put((prompt_text, stream_events))
        final_text, error = self._response_queue.get()
        if error:
            raise EngineClientError(error)
        return final_text or "RunLLM completed without returning a response."

    def _run_thread(self) -> None:
        try:
            asyncio.run(self._run())
        except Exception as e:
            logger.warning("Proactive discovery failed: error={}\n", e)
            self.error = str(e)
            self.ready_event.set()

    async def _run(self) -> None:
        archive = None
        ws: Any | None = None
        try:
            repo_metadata = collect_git_repo_metadata(self.repo_path)
            repo_snapshot = (
                lookup_repo_snapshot(self.config, self.api_key, repo_metadata)
                if repo_metadata is not None
                else None
            )
            if repo_snapshot is None:
                archive = create_repo_archive(self.repo_path)
                repo_metadata = archive.metadata
            session_id, session_token = create_session(self.config, self.api_key)
            logger.info(
                "Starting proactive discovery session: session_id={} repo_path={}\n",
                session_id,
                self.repo_path,
            )
            ws = await _open_websocket(self.config, session_id, session_token)
            await _send_json(
                ws,
                SessionInitMessage(
                    question=self.prompt_text,
                    cli_version=__version__,
                    repo=repo_metadata,
                    repo_snapshot_id=repo_snapshot.repo_snapshot_id if repo_snapshot else None,
                    available_tools=configured_tool_capabilities(self.config),
                ),
            )
            if archive is not None:
                await _upload_archive(ws, archive.path)
            self.final_text = await _run_until_final(ws, self.config, quiet=True)
            self.ready_event.set()
            await ws.close()
            ws = None
            while True:
                followup_request = await asyncio.to_thread(self._followup_queue.get)
                if followup_request is None:
                    if ws is None:
                        ws = await _resume_websocket(self.config, session_id, session_token)
                    await _send_json(
                        ws,
                        CloseSessionMessage(reason="proactive_discovery_closed"),
                    )
                    return
                try:
                    next_prompt, stream_events = followup_request
                    if ws is None:
                        ws = await _resume_websocket(self.config, session_id, session_token)
                    try:
                        await _send_json(ws, UserMessage(message=next_prompt))
                    except ConnectionClosed:
                        ws = await _resume_websocket(self.config, session_id, session_token)
                        await _send_json(ws, UserMessage(message=next_prompt))
                    final_text = await _run_until_final(
                        ws,
                        self.config,
                        quiet=not stream_events,
                        hide_setup_progress=stream_events,
                        show_working_spinner=stream_events,
                    )
                    await ws.close()
                    ws = None
                except Exception as e:
                    self._response_queue.put((None, str(e)))
                else:
                    self._response_queue.put((final_text, None))
        finally:
            if ws is not None:
                await ws.close()
            if archive is not None:
                archive.path.unlink(missing_ok=True)


class Spinner:
    def __init__(self, message: str) -> None:
        self._message = message
        self._running = False
        self._task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run())

    def update(self, message: str) -> None:
        self._message = message

    async def stop(self, final_message: str | None = None) -> None:
        if not self._running:
            return
        self._running = False
        if self._task is not None:
            await self._task
            self._task = None
        sys.stdout.write("\r\033[K")
        if final_message:
            print(final_message)
        sys.stdout.flush()

    async def _run(self) -> None:
        frames = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
        index = 0
        while self._running:
            sys.stdout.write(f"\r{frames[index % len(frames)]} {self._message}")
            sys.stdout.flush()
            index += 1
            await asyncio.sleep(0.12)


def _request_headers(api_key: str | None = None) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["x-api-key"] = api_key
    return headers


def _websocket_url(config: CliConfig, session_id: str, session_token: str) -> str:
    parsed = urllib.parse.urlparse(config.engine_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    path = f"/v1/sessions/{session_id}/ws"
    query = urllib.parse.urlencode({"session_token": session_token})
    return urllib.parse.urlunparse((scheme, parsed.netloc, path, "", query, ""))


async def _open_websocket(config: CliConfig, session_id: str, session_token: str) -> Any:
    ws_url = _websocket_url(config, session_id, session_token)
    logger.info("Connecting to Lite engine WebSocket: session_id={} url={}\n", session_id, ws_url)
    return await ws_connect(
        ws_url,
        additional_headers=_request_headers(),
        close_timeout=0.1,
        open_timeout=30,
        ping_interval=WEBSOCKET_PING_INTERVAL_SEC,
        ping_timeout=WEBSOCKET_PING_TIMEOUT_SEC,
        max_size=None,
    )


async def _resume_websocket(config: CliConfig, session_id: str, session_token: str) -> Any:
    deadline = asyncio.get_running_loop().time() + WEBSOCKET_RECONNECT_MAX_WAIT_SEC
    while True:
        ws: Any | None = None
        try:
            ws = await _open_websocket(config, session_id, session_token)
            await _send_json(ws, ResumeSessionMessage())
            while True:
                raw = await ws.recv()
                if not isinstance(raw, str):
                    continue
                message = parse_engine_message(raw)
                if isinstance(message, SessionAcceptedMessage):
                    continue
                if isinstance(message, ProgressMessage) and message.message == "Session resumed":
                    logger.info("Resumed Lite engine WebSocket: session_id={}\n", session_id)
                    return ws
                if isinstance(message, ErrorMessage):
                    if message.code == "session_already_attached":
                        await ws.close()
                        break
                    await ws.close()
                    raise EngineClientError(f"{message.code}: {message.message}")
        except ConnectionClosed:
            if ws is not None:
                await ws.close()
        if asyncio.get_running_loop().time() >= deadline:
            raise EngineClientError("Timed out waiting to resume Lite engine session.")
        await asyncio.sleep(WEBSOCKET_RECONNECT_RETRY_SEC)


def create_session(config: CliConfig, api_key: str) -> tuple[str, str]:
    url = f"{config.engine_url}/v1/sessions"
    request = urllib.request.Request(
        url,
        data=b"{}",
        headers=_request_headers(api_key),
        method="POST",
    )
    logger.info("Creating Lite investigation session: url={}\n", url)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise EngineClientError(f"Engine rejected session creation: {e.code} {body}") from e
    except Exception as e:
        raise EngineClientError(f"Failed to create engine session: {e}") from e

    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        raise EngineClientError(f"Engine returned invalid session response: {payload}")
    session_token = payload.get("session_token")
    if not isinstance(session_token, str) or not session_token:
        raise EngineClientError(f"Engine returned invalid session token response: {payload}")
    logger.info("Created Lite investigation session: session_id={}\n", session_id)
    return session_id, session_token


def lookup_repo_snapshot(
    config: CliConfig,
    api_key: str,
    repo_metadata: RepoMetadata,
) -> RepoSnapshotReuse | None:
    if not repo_metadata.root_name or not repo_metadata.commit:
        return None
    url = f"{config.engine_url}/v1/repo-snapshots/lookup"
    request = urllib.request.Request(
        url,
        data=json.dumps({"repo": repo_metadata.model_dump(mode="json")}).encode("utf-8"),
        headers=_request_headers(api_key),
        method="POST",
    )
    logger.info(
        "Looking up reusable repo snapshot: url={} root_name={} commit={}\n",
        url,
        repo_metadata.root_name,
        repo_metadata.commit,
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        logger.warning("Repo snapshot lookup failed: status={} body={}\n", e.code, body)
        return None
    except Exception as e:
        logger.warning("Repo snapshot lookup failed: error={}\n", e)
        return None

    if not payload.get("matched"):
        return None
    repo_snapshot_id = payload.get("repo_snapshot_id")
    object_uri = payload.get("object_uri")
    if not isinstance(repo_snapshot_id, int) or not isinstance(object_uri, str):
        logger.warning("Ignoring invalid repo snapshot lookup response: payload={}\n", payload)
        return None
    logger.info(
        "Reusing repo snapshot: repo_snapshot_id={} object_uri={}\n",
        repo_snapshot_id,
        object_uri,
    )
    return RepoSnapshotReuse(repo_snapshot_id=repo_snapshot_id, object_uri=object_uri)


async def _send_json(ws: Any, model: Any) -> None:
    payload = model.model_dump(mode="json")
    await ws.send(json.dumps(payload))


async def _upload_archive(ws: Any, archive_path: Path) -> None:
    total_bytes = archive_path.stat().st_size
    sent_bytes = 0
    chunk_count = 0
    logger.info("Uploading repo archive: archive={} total_bytes={}\n", archive_path, total_bytes)
    with archive_path.open("rb") as file:
        while True:
            chunk = file.read(ARCHIVE_CHUNK_BYTES)
            if not chunk:
                break
            await ws.send(chunk)
            sent_bytes += len(chunk)
            chunk_count += 1
            logger.info(
                "Uploaded repo archive chunk: chunk_count={} sent_bytes={} total_bytes={}\n",
                chunk_count,
                sent_bytes,
                total_bytes,
            )
    await _send_json(ws, RepoUploadCompleteMessage())
    logger.info(
        "Repo archive upload complete: archive={} total_bytes={} chunk_count={}\n",
        archive_path,
        total_bytes,
        chunk_count,
    )


async def _handle_progress(message: ProgressMessage, spinner: Spinner | None) -> None:
    friendly_messages = {
        "Session initialized": "Setting up your workspace",
        "Repo upload complete": "Setting up your workspace",
        "Repo archive stored": "Setting up your workspace",
        "Repo archive reused": "Setting up your workspace",
        "Creating investigation workspace": "Setting up your workspace",
        "Workspace ready": "✓ Workspace ready",
        "Starting RunLLM response": "✓ Workspace ready",
    }
    friendly = friendly_messages.get(message.message)
    if friendly and spinner is not None:
        if message.message in {"Workspace ready", "Starting OpenCode investigation"}:
            await spinner.stop(friendly)
        else:
            spinner.update(friendly)
        return
    if friendly:
        print(friendly)
        return
    print(f"[runllm] {message.message}")


def _print_opencode_event(message: OpenCodeEventMessage) -> None:
    event = message.event
    line = event.get("line")
    if isinstance(line, str) and line.strip():
        print(f"• {line}")
        return
    part = event.get("part")
    if isinstance(part, dict):
        metadata = part.get("metadata")
        if isinstance(metadata, dict):
            openai_metadata = metadata.get("openai")
            if isinstance(openai_metadata, dict) and openai_metadata.get("phase") == "final_answer":
                return
        value = part.get("text")
        if isinstance(value, str) and value.strip():
            print(f"• {value}")
            return
    for key in ("text", "content", "message", "output"):
        value = event.get(key)
        if isinstance(value, str) and value.strip():
            print(f"• {value}")
            return


async def _restart_working_spinner(spinner: Spinner) -> None:
    await spinner.stop()
    spinner.update("Working...")
    await spinner.start()


async def _read_next_prompt() -> str | None:
    try:
        value = await _async_input("\nRunLLM> ")
    except EOFError:
        print()
        return None
    except KeyboardInterrupt:
        print()
        raise
    value = value.strip()
    if value in {"/exit", "exit", "quit", "/quit"}:
        return None
    return value or await _read_next_prompt()


async def _async_input(prompt: str) -> str:
    loop = asyncio.get_running_loop()
    future: asyncio.Future[str] = loop.create_future()

    def read_input() -> None:
        try:
            value = input(prompt)
        except BaseException as e:
            loop.call_soon_threadsafe(future.set_exception, e)
            return
        loop.call_soon_threadsafe(future.set_result, value)

    thread = threading.Thread(target=read_input, daemon=True)
    thread.start()
    return await future


async def _run_until_final(
    ws: Any,
    config: CliConfig,
    *,
    quiet: bool,
    hide_setup_progress: bool = False,
    show_working_spinner: bool = False,
) -> str:
    working_spinner = Spinner("Working...") if show_working_spinner and not quiet else None
    if working_spinner is not None:
        await working_spinner.start()
    try:
        async for raw in ws:
            if not isinstance(raw, str):
                logger.warning("Ignoring unexpected binary message from engine: bytes={}\n", len(raw))
                continue
            message = parse_engine_message(raw)
            if isinstance(message, SessionAcceptedMessage):
                logger.info("Engine accepted session: session_id={}\n", message.session_id)
            elif isinstance(message, ProgressMessage):
                logger.info(
                    "Engine progress: session_id={} message={} metadata={}\n",
                    message.session_id,
                    message.message,
                    message.metadata,
                )
                should_hide_progress = (
                    hide_setup_progress
                    and message.message
                    in {
                        "Session initialized",
                        "Repo upload complete",
                        "Creating investigation workspace",
                        "Workspace ready",
                        "Starting RunLLM response",
                    }
                )
                if not quiet and not should_hide_progress:
                    if working_spinner is not None:
                        await working_spinner.stop()
                    await _handle_progress(message, None)
                    if working_spinner is not None:
                        await _restart_working_spinner(working_spinner)
            elif isinstance(message, CommandRequestMessage):
                result = await execute_tool_request(config, message)
                await _send_json(ws, result)
            elif isinstance(message, OpenCodeEventMessage):
                logger.debug(
                    "OpenCode event received: session_id={} keys={}\n",
                    message.session_id,
                    sorted(message.event.keys()),
                )
                if not quiet:
                    if working_spinner is not None:
                        await working_spinner.stop()
                    _print_opencode_event(message)
                    if working_spinner is not None:
                        await _restart_working_spinner(working_spinner)
            elif isinstance(message, FinalRcaMessage):
                if working_spinner is not None:
                    await working_spinner.stop()
                logger.info(
                    "RunLLM response received: session_id={} metadata={} bytes={}\n",
                    message.session_id,
                    message.metadata,
                    len(message.rca.encode()),
                )
                return message.rca
            elif isinstance(message, ErrorMessage):
                if working_spinner is not None:
                    await working_spinner.stop()
                logger.warning(
                    "Engine error: session_id={} code={} message={} metadata={}\n",
                    message.session_id,
                    message.code,
                    message.message,
                    message.metadata,
                )
                raise EngineClientError(f"{message.code}: {message.message}")
    finally:
        if working_spinner is not None:
            await working_spinner.stop()
    raise EngineClientError("Engine WebSocket closed before RunLLM returned a response.")


async def run_session(
    config: CliConfig,
    question: str,
    repo_path: Path,
    *,
    api_key: str,
    interactive: bool,
) -> int:
    setup_spinner = Spinner("Setting up your workspace")
    working_spinner = Spinner("Working...")
    archive = None
    ws: Any | None = None
    await setup_spinner.start()
    try:
        repo_metadata = collect_git_repo_metadata(repo_path)
        repo_snapshot = (
            lookup_repo_snapshot(config, api_key, repo_metadata)
            if repo_metadata is not None
            else None
        )
        if repo_snapshot is None:
            archive = create_repo_archive(repo_path)
            repo_metadata = archive.metadata
        session_id, session_token = create_session(config, api_key)
    except Exception:
        await setup_spinner.stop()
        raise
    try:
        ws = await _open_websocket(config, session_id, session_token)
        await _send_json(
            ws,
            SessionInitMessage(
                question=question,
                cli_version=__version__,
                repo=repo_metadata,
                repo_snapshot_id=repo_snapshot.repo_snapshot_id if repo_snapshot else None,
                available_tools=configured_tool_capabilities(config),
            ),
        )
        logger.info(
            "Sent session init: session_id={} question_bytes={}\n",
            session_id,
            len(question.encode()),
        )
        if archive is not None:
            await _upload_archive(ws, archive.path)

        while True:
            if ws is None:
                ws = await _resume_websocket(config, session_id, session_token)
            raw = await ws.recv()
            if not isinstance(raw, str):
                logger.warning("Ignoring unexpected binary message from engine: bytes={}\n", len(raw))
                continue
            message = parse_engine_message(raw)
            if isinstance(message, SessionAcceptedMessage):
                logger.info("Engine accepted session: session_id={}\n", message.session_id)
            elif isinstance(message, ProgressMessage):
                logger.info(
                    "Engine progress: session_id={} message={} metadata={}\n",
                    message.session_id,
                    message.message,
                    message.metadata,
                )
                await _handle_progress(message, setup_spinner)
            elif isinstance(message, CommandRequestMessage):
                result = await execute_tool_request(config, message)
                await _send_json(ws, result)
            elif isinstance(message, OpenCodeEventMessage):
                await setup_spinner.stop()
                await working_spinner.stop()
                logger.debug(
                    "OpenCode event received: session_id={} keys={}\n",
                    message.session_id,
                    sorted(message.event.keys()),
                )
                _print_opencode_event(message)
                await _restart_working_spinner(working_spinner)
            elif isinstance(message, FinalRcaMessage):
                await setup_spinner.stop()
                await working_spinner.stop()
                logger.info(
                    "RunLLM response received: session_id={} metadata={} bytes={}\n",
                    message.session_id,
                    message.metadata,
                    len(message.rca.encode()),
                )
                print("\nRunLLM response")
                print("────────────────")
                print(message.rca)
                if not interactive:
                    return 0
                await ws.close()
                ws = None
                print("\nType a follow-up question, or /exit to quit.")
                try:
                    next_prompt = await _read_next_prompt()
                except KeyboardInterrupt:
                    logger.info("Interactive session interrupted by user: session_id={}\n", session_id)
                    raise SystemExit(130)
                if next_prompt is None:
                    ws = await _resume_websocket(config, session_id, session_token)
                    await _send_json(ws, CloseSessionMessage(reason="user_exit"))
                    return 0
                ws = await _resume_websocket(config, session_id, session_token)
                try:
                    await _send_json(ws, UserMessage(message=next_prompt))
                except ConnectionClosed:
                    ws = await _resume_websocket(config, session_id, session_token)
                    await _send_json(ws, UserMessage(message=next_prompt))
                await _restart_working_spinner(working_spinner)
            elif isinstance(message, ErrorMessage):
                await working_spinner.stop()
                logger.warning(
                    "Engine error: session_id={} code={} message={} metadata={}\n",
                    message.session_id,
                    message.code,
                    message.message,
                    message.metadata,
                )
                print(f"[runllm:error] {message.code}: {message.message}")
                return 1
    except ConnectionClosed as e:
        await setup_spinner.stop()
        await working_spinner.stop()
        logger.info("Engine WebSocket closed: session_id={} error={}\n", session_id, e)
        if interactive:
            print("[runllm:error] Engine connection closed during a response. Try another prompt to resume.")
        else:
            print("[runllm:error] Engine connection closed. Start a new session with `runllm`.")
        return 1
    finally:
        if ws is not None:
            await ws.close()
        if archive is not None:
            archive.path.unlink(missing_ok=True)


async def run_ask(config: CliConfig, question: str, repo_path: Path, api_key: str) -> int:
    return await run_session(config, question, repo_path, api_key=api_key, interactive=False)


async def run_interactive(config: CliConfig, question: str, repo_path: Path, api_key: str) -> int:
    return await run_session(config, question, repo_path, api_key=api_key, interactive=True)
