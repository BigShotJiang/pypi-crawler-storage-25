"""Customer-side CLI for the RunLLM Lite prototype."""

__version__ = "0.2.0"
