"""Models module implementation."""

from __future__ import annotations

from typing import Any

import requests

from ._base import BaseApiClient, HeaderProvider
from .utils.types import AIModel, ApplicationModelSetting, ApplicationModelSettingUpdate


class ModelsClient(BaseApiClient):
    """List model catalog and manage application model settings."""

    def __init__(
        self,
        *,
        api_url: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(
        self,
        *,
        category: str | None = None,
        only_active: bool | None = True,
        timeout: float | None = None,
    ) -> list[AIModel]:
        payload = self._request(
            "GET",
            "/api/v1/models",
            params={"category": category, "only_active": only_active},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        items = self._normalize_items(data)
        return [AIModel.model_validate(item) for item in items]

    def get(self, model_id: str, *, timeout: float | None = None) -> AIModel:
        payload = self._request("GET", f"/api/v1/models/{model_id}", timeout=timeout)
        data = self._extract_data(payload)
        return AIModel.model_validate(data)

    def list_application_settings(
        self,
        application_id: str,
        *,
        agent_id: str | None = None,
        category: str | None = None,
        timeout: float | None = None,
    ) -> list[ApplicationModelSetting]:
        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/model-settings",
            params={"agent_id": agent_id, "category": category},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        items = self._normalize_items(data)
        return [ApplicationModelSetting.model_validate(item) for item in items]

    def get_application_setting(
        self,
        application_id: str,
        agent_ref: str,
        *,
        category: str = "chat",
        timeout: float | None = None,
    ) -> ApplicationModelSetting:
        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/model-settings/{agent_ref}",
            params={"category": category},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ApplicationModelSetting.model_validate(data)

    def update_application_setting(
        self,
        application_id: str,
        agent_ref: str,
        payload: ApplicationModelSettingUpdate | dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> ApplicationModelSetting:
        body = (
            payload.model_dump(exclude_none=True)
            if isinstance(payload, ApplicationModelSettingUpdate)
            else payload
        )
        response = self._request(
            "PUT",
            f"/api/v1/applications/{application_id}/model-settings/{agent_ref}",
            json=body,
            timeout=timeout,
        )
        data = self._extract_data(response)
        return ApplicationModelSetting.model_validate(data)

    def delete_application_setting(
        self,
        application_id: str,
        agent_ref: str,
        *,
        category: str = "chat",
        timeout: float | None = None,
    ) -> None:
        self._request(
            "DELETE",
            f"/api/v1/applications/{application_id}/model-settings/{agent_ref}",
            params={"category": category},
            timeout=timeout,
            expect_json=False,
        )

    @staticmethod
    def _normalize_items(data: Any) -> list[dict[str, Any]]:
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
        if isinstance(data, dict):
            items = data.get("items")
            if isinstance(items, list):
                return [item for item in items if isinstance(item, dict)]
            return [data]
        return []
