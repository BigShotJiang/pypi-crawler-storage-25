"""Interact module for the current public API contract."""

from __future__ import annotations

from typing import Any, Callable

import requests

from .utils.errors import map_api_error
from .utils.types import InteractionResponse, build_interaction_response

HeaderProvider = Callable[[dict[str, str | None]], dict[str, str]]


class InteractClient:
    """Client wrapper for the `/api/v1/public/requests` endpoint."""

    _PUBLIC_REQUESTS_PATH = "/api/v1/public/requests"

    def __init__(
        self,
        *,
        api_url: str,
        application_id: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
        dry_run: bool = False,
    ) -> None:
        self._base_url = api_url.rstrip("/")
        self._application_id = application_id
        self._session = session or requests.Session()
        self._header_provider = header_provider
        self._dry_run = dry_run

    def query(
        self,
        *,
        query: str,
        intent_id: str,
        intent: str | None = None,
        application_agent_id: str | None = None,
        agent_slug: str | None = None,
        agent_id: str | None = None,
        context_id: str | None = None,
        document_id: str | None = None,
        parameters: dict[str, Any] | None = None,
        stream: bool = False,
        timeout: float | None = None,
    ) -> InteractionResponse:
        """Execute a request against the current public API contract."""

        payload = self._build_payload(
            query=query,
            intent_id=intent_id,
            intent=intent,
            application_agent_id=application_agent_id,
            agent_slug=agent_slug,
            agent_id=agent_id,
            context_id=context_id,
            document_id=document_id,
            parameters=parameters,
            stream=stream,
        )

        response = self._execute(payload, timeout=timeout)
        data = response.get("data") or response
        if not isinstance(data, dict):
            data = {"answer": data}
        data = self._promote_structured_answer(data)
        meta = data.get("meta") if isinstance(data.get("meta"), dict) else {}
        return build_interaction_response(data, meta)

    def _build_payload(
        self,
        *,
        query: str,
        intent_id: str,
        intent: str | None,
        application_agent_id: str | None,
        agent_slug: str | None,
        agent_id: str | None,
        context_id: str | None,
        document_id: str | None,
        parameters: dict[str, Any] | None,
        stream: bool,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "application_id": self._application_id,
            "prompt": query,
            "intent_id": intent_id,
            "parameters": parameters or {},
            "stream": bool(stream),
        }
        if intent:
            payload["intent"] = intent
        if application_agent_id:
            payload["application_agent_id"] = application_agent_id
        if agent_slug:
            payload["agent_slug"] = agent_slug
        if agent_id:
            payload["agent_id"] = agent_id
        if self._dry_run:
            payload["parameters"]["dry_run"] = True
        if context_id or document_id:
            payload["context"] = {
                "context_id": context_id,
                "document_id": document_id,
            }
        if not (payload.get("application_agent_id") or payload.get("agent_slug") or payload.get("agent_id")):
            raise ValueError("Provide one agent reference: application_agent_id, agent_slug, or agent_id")
        return payload

    def _execute(self, payload: dict[str, Any], timeout: float | None) -> dict[str, Any]:
        url = f"{self._base_url}{self._PUBLIC_REQUESTS_PATH}"
        try:
            response = self._session.post(
                url,
                json=payload,
                headers=self._header_provider(),
                timeout=timeout,
            )
        except requests.RequestException as exc:  # pragma: no cover - network failure
            raise map_api_error(500, {"error": {"message": str(exc)}}) from exc

        return self._parse_response(response)

    @staticmethod
    def _promote_structured_answer(data: dict[str, Any]) -> dict[str, Any]:
        promoted = dict(data)
        if promoted.get("answer") is not None:
            return promoted
        envelope = promoted.get("envelope")
        if not isinstance(envelope, dict):
            return promoted
        user_output = envelope.get("user_output")
        if not isinstance(user_output, dict):
            return promoted
        structured_json = user_output.get("structured_json")
        if isinstance(structured_json, (dict, list)):
            promoted["answer"] = structured_json
        return promoted

    def _parse_response(self, response: requests.Response) -> dict[str, Any]:
        try:
            if response.status_code == 204 or not response.content:
                payload: Any = {}
            else:
                payload = response.json()
        except ValueError:
            text_body = (response.text or "").strip()
            payload = {} if not text_body else text_body

        if response.status_code >= 400:
            error_payload: Any = payload
            if not isinstance(error_payload, dict):
                error_payload = {"error": {"message": str(error_payload)}}
            raise map_api_error(response.status_code, error_payload)

        if not isinstance(payload, dict):
            return {"data": payload}

        return payload
