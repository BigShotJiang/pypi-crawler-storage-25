"""Contexts module implementation."""

from __future__ import annotations

import logging
from typing import Any, Mapping, MutableMapping, Sequence, Union

import requests

from ._base import BaseApiClient, HeaderProvider
from .utils.types import (
    ContextDetail,
    ContextDocumentLink,
    ContextList,
    ContextSessionDetail,
    ContextSessionList,
    ContextSessionMessage,
)

DocumentReference = Union[str, Mapping[str, Any], ContextDocumentLink]
CONFIG_CONTEXTS_BASE_PATH = "/api/v1/config/contexts"
LOGGER = logging.getLogger(__name__)


class ContextsClient(BaseApiClient):
    """Manage persistent contexts that aggregate document links."""

    def __init__(
        self,
        *,
        api_url: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(
        self,
        *,
        offset: int = 0,
        limit: int = 50,
        timeout: float | None = None,
    ) -> ContextList:
        """Return paginated contexts for the authenticated application."""

        payload = self._request(
            "GET",
            CONFIG_CONTEXTS_BASE_PATH,
            params={"offset": offset, "limit": limit},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ContextList.model_validate(data)

    def create(
        self,
        *,
        name: str,
        description: str | None = None,
        status: str | None = None,
        metadata: Mapping[str, Any | None] | None = None,
        documents: Sequence[DocumentReference | None] = None,
        payload: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> ContextDetail:
        """Create a new context with optional linked documents."""

        body = self._build_context_body(
            name=name,
            description=description,
            status=status,
            metadata=metadata,
            documents=documents,
            payload=payload,
            operation="create",
        )

        payload = self._request("POST", CONFIG_CONTEXTS_BASE_PATH, json=body, timeout=timeout)
        data = self._extract_data(payload)
        return ContextDetail.model_validate(data)

    def get(self, context_id: Union[str, ContextDetail], *, timeout: float | None = None) -> ContextDetail:
        """Retrieve a single context."""

        identifier = context_id.id if isinstance(context_id, ContextDetail) else context_id
        payload = self._request("GET", f"{CONFIG_CONTEXTS_BASE_PATH}/{identifier}", timeout=timeout)
        data = self._extract_data(payload)
        return ContextDetail.model_validate(data)

    def add_documents(
        self,
        context_id: Union[str, ContextDetail],
        documents: Sequence[DocumentReference],
        *,
        timeout: float | None = None,
    ) -> ContextDetail:
        """Attach additional documents to an existing context."""

        context = self.get(context_id, timeout=timeout)
        normalized_existing = self._serialize_document_links(context.documents)
        normalized_new = self._normalize_documents(documents)
        payload = self._request(
            "PATCH",
            f"{CONFIG_CONTEXTS_BASE_PATH}/{context.id}",
            json={"documents": normalized_existing + normalized_new},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ContextDetail.model_validate(data)

    def update(
        self,
        context_id: Union[str, ContextDetail],
        *,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        metadata: Mapping[str, Any | None] | None = None,
        documents: Sequence[DocumentReference | None] = None,
        payload: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> ContextDetail:
        """Update the context metadata or its associated documents."""

        identifier = context_id.id if isinstance(context_id, ContextDetail) else context_id
        body = self._build_context_body(
            name=name,
            description=description,
            status=status,
            metadata=metadata,
            documents=documents,
            payload=payload,
            operation="update",
        )

        payload = self._request(
            "PATCH",
            f"{CONFIG_CONTEXTS_BASE_PATH}/{identifier}",
            json=body,
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ContextDetail.model_validate(data)

    def _build_context_body(
        self,
        *,
        operation: str,
        name: str | None,
        description: str | None,
        status: str | None,
        metadata: Mapping[str, Any | None] | None,
        documents: Sequence[DocumentReference | None] | None,
        payload: Mapping[str, Any] | None,
    ) -> MutableMapping[str, Any]:
        body: MutableMapping[str, Any] = {}
        if payload is not None:
            body.update(dict(payload))
            LOGGER.info(
                "contexts_client_legacy_payload_argument_detected",
                extra={
                    "operation": operation,
                    "payload_keys": sorted(list(payload.keys())),
                },
            )

        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if status is not None:
            body["status"] = status
        if metadata is not None:
            body["metadata"] = dict(metadata)
        if documents is not None:
            body["documents"] = self._normalize_documents(documents)
        elif isinstance(body.get("documents"), Sequence) and not isinstance(
            body.get("documents"), (str, bytes)
        ):
            body["documents"] = self._normalize_documents(body["documents"])

        return body

    def delete(self, context_id: Union[str, ContextDetail], *, timeout: float | None = None) -> None:
        """Remove a context and its document associations."""

        identifier = context_id.id if isinstance(context_id, ContextDetail) else context_id
        self._request(
            "DELETE",
            f"{CONFIG_CONTEXTS_BASE_PATH}/{identifier}",
            timeout=timeout,
            expect_json=False,
        )

    def _serialize_document_links(
        self,
        documents: Sequence[ContextDocumentLink],
    ) -> list[dict[str, Any]]:
        return [
            {
                "document_id": str(entry.document_id),
                "metadata": dict(entry.metadata),
            }
            for entry in documents
        ]

    def _normalize_documents(self, documents: Sequence[DocumentReference]) -> list[dict[str, Any]]:
        normalized: list[dict[str, Any]] = []
        for entry in documents:
            if isinstance(entry, ContextDocumentLink):
                normalized.append(
                    {
                        "document_id": str(entry.document_id),
                        "metadata": dict(entry.metadata),
                    }
                )
                continue
            if isinstance(entry, Mapping):
                document_id = entry.get("document_id") or entry.get("id")
                metadata = entry.get("metadata") or entry.get("metadata_")
                normalized.append(
                    {
                        "document_id": str(document_id),
                        "metadata": dict(metadata or {}),
                    }
                )
                continue
            normalized.append({"document_id": str(entry), "metadata": {}})
        return normalized


class ContextSessionsClient(BaseApiClient):
    """Manage runtime sessions that reuse existing contexts."""

    def __init__(
        self,
        *,
        api_url: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(
        self,
        *,
        offset: int = 0,
        limit: int = 50,
        timeout: float | None = None,
    ) -> ContextSessionList:
        payload = self._request(
            "GET",
            "/api/v1/chat/context-sessions",
            params={"offset": offset, "limit": limit},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ContextSessionList.model_validate(data)

    def create(
        self,
        *,
        name: str,
        context_id: str | None = None,
        status: str = "active",
        metadata: Mapping[str, Any | None] | None = None,
        timeout: float | None = None,
    ) -> ContextSessionDetail:
        body: MutableMapping[str, Any] = {"name": name, "status": status}
        if context_id is not None:
            body["context_id"] = context_id
        if metadata is not None:
            body["metadata"] = dict(metadata)
        payload = self._request("POST", "/api/v1/chat/context-sessions", json=body, timeout=timeout)
        data = self._extract_data(payload)
        return ContextSessionDetail.model_validate(data)

    def get(self, session_id: str, *, timeout: float | None = None) -> ContextSessionDetail:
        payload = self._request(
            "GET", f"/api/v1/chat/context-sessions/{session_id}", timeout=timeout
        )
        data = self._extract_data(payload)
        return ContextSessionDetail.model_validate(data)

    def add_message(
        self,
        session_id: str,
        *,
        agent_name: str,
        intent: str | None = None,
        role: str = "assistant",
        query: str | None = None,
        answer: str | None = None,
        tokens_used: int = 0,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        context_id: str | None = None,
        metadata: Mapping[str, Any | None] | None = None,
        timeout: float | None = None,
    ) -> ContextSessionMessage:
        body: MutableMapping[str, Any] = {
            "agent_name": agent_name,
            "role": role,
            "tokens_used": tokens_used,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
        }
        if intent is not None:
            body["intent"] = intent
        if query is not None:
            body["query"] = query
        if answer is not None:
            body["answer"] = answer
        if context_id is not None:
            body["context_id"] = context_id
        if metadata is not None:
            body["metadata"] = dict(metadata)

        payload = self._request(
            "POST",
            f"/api/v1/chat/context-sessions/{session_id}/messages",
            json=body,
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ContextSessionMessage.model_validate(data)

    # Backwards compatibility alias
    append_message = add_message

    def delete(self, session_id: str, *, timeout: float | None = None) -> None:
        self._request(
            "DELETE",
            f"/api/v1/chat/context-sessions/{session_id}",
            timeout=timeout,
            expect_json=False,
        )
