"""Application agents module implementation."""

from __future__ import annotations

from typing import Any

import requests

from ._base import BaseApiClient, HeaderProvider
from .utils.types import (
    ApplicationAgent,
    ApplicationAgentIntent,
    IntentConnectorCompatibility,
)


class ApplicationAgentsClient(BaseApiClient):
    """Inspect application-level agent configuration and intents."""

    def __init__(
        self,
        *,
        api_url: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(self, application_id: str, *, timeout: float | None = None) -> list[ApplicationAgent]:
        """Return all agents configured for an application."""

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/agents",
            timeout=timeout,
        )
        data = self._extract_data(payload)
        items = self._normalize_items(data)
        return [ApplicationAgent.model_validate(item) for item in items]

    def get(
        self,
        application_id: str,
        application_agent_id: str,
        *,
        timeout: float | None = None,
    ) -> ApplicationAgent:
        """Fetch a single application agent by identifier."""

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/agents/{application_agent_id}",
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ApplicationAgent.model_validate(data)

    def get_intents(
        self,
        application_id: str,
        application_agent_id: str,
        *,
        timeout: float | None = None,
    ) -> list[ApplicationAgentIntent]:
        """Return intents enabled for an application agent."""

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/agents/{application_agent_id}/intents",
            timeout=timeout,
        )
        data = self._extract_data(payload)
        items = self._normalize_items(data)
        return [ApplicationAgentIntent.model_validate(item) for item in items]

    def get_intent_connector_compatibility(
        self,
        application_id: str,
        application_agent_id: str,
        intent_id: str,
        *,
        timeout: float | None = None,
    ) -> IntentConnectorCompatibility:
        """Validate connector compatibility for an intent in an application agent."""

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/agents/{application_agent_id}/intents/{intent_id}/connector-compatibility",
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return IntentConnectorCompatibility.model_validate(data)

    @staticmethod
    def _normalize_items(data: Any) -> list[dict[str, Any]]:
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
        if isinstance(data, dict):
            items = data.get("items")
            if isinstance(items, list):
                return [item for item in items if isinstance(item, dict)]
            return [data]
        return []
