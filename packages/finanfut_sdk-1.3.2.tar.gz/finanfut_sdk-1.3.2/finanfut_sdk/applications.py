"""Applications module implementation."""

from __future__ import annotations

from typing import Any

import requests

from ._base import BaseApiClient, HeaderProvider
from .application_agents import ApplicationAgentsClient
from .utils.types import (
    Application,
    SdkBootstrapResult,
    SdkManifest,
)


class ApplicationsClient(BaseApiClient):
    """Manage applications linked to the account."""

    def __init__(
        self,
        *,
        api_url: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)
        self._agents = ApplicationAgentsClient(
            api_url=api_url, session=session, header_provider=header_provider
        )

    def list(self, *, timeout: float | None = None) -> list[Application]:
        """List available applications for the API key."""

        payload = self._request("GET", "/api/v1/applications", timeout=timeout)
        data = self._extract_data(payload)
        if isinstance(data, list):
            return [Application.model_validate(item) for item in data]
        if isinstance(data, dict):
            return [Application.model_validate(data)]
        return []

    def get(self, application_id: str, *, timeout: float | None = None) -> Application:
        """Fetch a single application by identifier."""

        payload = self._request(
            "GET", f"/api/v1/applications/{application_id}", timeout=timeout
        )
        data: dict[str, Any] = self._extract_data(payload)
        return Application.model_validate(data)



    def get_manifest(
        self,
        application_id: str,
        *,
        timeout: float | None = None,
        if_none_match: str | None = None,
    ) -> SdkManifest | None:
        """Fetch the SDK manifest for an application.

        Returns ``None`` when the provided ETag matches and the backend replies ``304``.
        """

        headers: dict[str, str] | None = None
        if if_none_match:
            headers = {"If-None-Match": if_none_match}

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/sdk-manifest",
            timeout=timeout,
            headers=headers,
        )
        data: dict[str, Any] = self._extract_data(payload)
        if not data:
            return None
        return SdkManifest.model_validate(data)

    def bootstrap_manifest(
        self,
        application_id: str,
        *,
        timeout: float | None = None,
        if_none_match: str | None = None,
    ) -> SdkBootstrapResult | None:
        """Return manifest plus convenience maps for SDK bootstrap flows."""

        manifest = self.get_manifest(
            application_id,
            timeout=timeout,
            if_none_match=if_none_match,
        )
        if manifest is None:
            return None

        agents_by_id = {agent.application_agent_id: agent for agent in manifest.agents}
        intents_by_agent_id = {
            agent.application_agent_id: list(agent.intents) for agent in manifest.agents
        }
        return SdkBootstrapResult(
            manifest=manifest,
            agents_by_id=agents_by_id,
            intents_by_agent_id=intents_by_agent_id,
        )
    @property
    def agents(self) -> ApplicationAgentsClient:
        """Access application-specific agent helpers."""

        return self._agents
