"""Requests module interfaces."""

from __future__ import annotations

import json
import time
from typing import Any, Callable, Iterator

import requests

from .utils.errors import RequestTimeoutError, map_api_error
from .utils.types import InteractionResponse, build_interaction_response

HeaderProvider = Callable[[dict[str, str | None]], dict[str, str]]


class RequestsClient:
    """Inspect asynchronous requests triggered by the SDK."""

    def __init__(
        self,
        *,
        api_url: str,
        session: requests.Session | None = None,
        header_provider: HeaderProvider,
    ) -> None:
        self._base_url = api_url.rstrip("/")
        self._session = session or requests.Session()
        self._header_provider = header_provider

    def get(self, request_id: str, *, timeout: float | None = None) -> dict[str, Any]:
        """Retrieve the status of a specific request."""

        return self._perform_get(f"/api/v1/requests/{request_id}", timeout=timeout)

    def events(self, request_id: str, *, timeout: float | None = None) -> list[dict[str, Any]]:
        """Return events emitted by a request."""

        payload = self._perform_get(
            f"/api/v1/requests/{request_id}/events",
            timeout=timeout,
        )
        data = payload.get("data") or []
        return data if isinstance(data, list) else []

    def wait(
        self,
        request_id: str,
        *,
        interval: float = 1.0,
        timeout: float = 60.0,
    ) -> InteractionResponse:
        """Block until a request finishes and return its payload."""

        deadline = time.monotonic() + timeout
        while True:
            payload = self.get(request_id)
            data = payload.get("data") or {}
            state = str(
                data.get("status")
                or data.get("state")
                or payload.get("status")
                or payload.get("state")
                or ""
            ).lower()

            if state in {"completed", "success", "succeeded", "done"}:
                response_payload = self._extract_response_payload(data)
                meta = payload.get("meta") or {}
                return build_interaction_response(response_payload, meta)

            if state in {"failed", "error", "cancelled"}:
                error_payload = payload.get("error") or data.get("error")
                raise map_api_error(500, {"error": error_payload or {"message": "Request failed"}})

            if time.monotonic() >= deadline:
                raise RequestTimeoutError(
                    f"Request {request_id} did not complete within {timeout} seconds"
                )

            time.sleep(max(interval, 0.1))

    def stream_events(
        self,
        request_id: str,
        *,
        after_sequence: int = 0,
        timeout: float | None = 60.0,
    ) -> Iterator[dict[str, Any]]:
        """Yield streaming events from the SSE endpoint for a request."""

        query = f"?after_sequence={int(after_sequence)}" if int(after_sequence) > 0 else ""
        url = f"{self._base_url}/api/v1/chat/requests/{request_id}/stream{query}"
        headers = self._header_provider(
            {
                "Accept": "text/event-stream",
                "Cache-Control": "no-cache",
            }
        )
        try:
            response = self._session.get(
                url,
                headers=headers,
                timeout=timeout,
                stream=True,
            )
        except requests.RequestException as exc:  # pragma: no cover - network failure
            raise map_api_error(500, {"error": {"message": str(exc)}}) from exc

        if response.status_code >= 400:
            try:
                payload: Any = response.json()
            except ValueError:
                payload = {"error": {"message": (response.text or "").strip() or "SSE request failed"}}
            raise map_api_error(response.status_code, payload if isinstance(payload, dict) else {"error": {"message": str(payload)}})

        event_type = "message"
        event_id = None
        data_lines: list[str] = []

        def _flush() -> dict[str, Any] | None:
            nonlocal event_type, event_id, data_lines
            if not data_lines:
                event_type = "message"
                event_id = None
                return None
            raw_payload = "\n".join(data_lines)
            payload_data: Any = raw_payload
            try:
                payload_data = json.loads(raw_payload)
            except ValueError:
                payload_data = {"raw": raw_payload}
            emitted = {
                "event": event_type,
                "id": event_id,
                "data": payload_data,
            }
            event_type = "message"
            event_id = None
            data_lines = []
            return emitted

        try:
            for raw in response.iter_lines(decode_unicode=True):
                if raw is None:
                    continue
                line = str(raw)
                if not line:
                    emitted = _flush()
                    if emitted is not None:
                        yield emitted
                    continue
                if line.startswith(":"):
                    continue
                if line.startswith("event:"):
                    event_type = line[6:].strip() or "message"
                elif line.startswith("id:"):
                    event_id = line[3:].strip() or None
                elif line.startswith("data:"):
                    data_lines.append(line[5:].lstrip())
            emitted = _flush()
            if emitted is not None:
                yield emitted
        finally:
            response.close()

    def _perform_get(self, path: str, *, timeout: float | None) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        try:
            response = self._session.get(url, headers=self._header_provider(), timeout=timeout)
        except requests.RequestException as exc:  # pragma: no cover - network failure
            raise map_api_error(500, {"error": {"message": str(exc)}}) from exc

        try:
            payload: Any = response.json()
        except ValueError:
            text_body = (response.text or "").strip()
            payload = {} if not text_body else text_body

        if response.status_code >= 400:
            error_payload: Any = payload
            if not isinstance(error_payload, dict):
                error_payload = {"error": {"message": str(error_payload)}}
            raise map_api_error(response.status_code, error_payload)

        if not isinstance(payload, dict):
            return {"data": payload}

        status_flag = str(payload.get("status") or "").lower()
        if status_flag in {"error", "failed", "failure"}:
            raise map_api_error(response.status_code, payload)

        return payload

    @staticmethod
    def _extract_response_payload(data: dict[str, Any]) -> dict[str, Any]:
        if isinstance(data.get("response"), dict):
            return data["response"]
        if isinstance(data.get("result"), dict):
            return data["result"]
        return data
