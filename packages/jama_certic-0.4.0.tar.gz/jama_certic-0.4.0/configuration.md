# Configuration JAMA

Ce document recense les variables d'environnement `JAMA_*` utilisées par
l'application. Les valeurs booléennes sont généralement activées avec `"1"` et
désactivées avec `"0"`.

Au démarrage, JAMA lit aussi un fichier `env` dans `JAMA_VAR_DIR`. Si ce fichier
n'existe pas, il est créé automatiquement avec toutes les variables `JAMA_*`,
leurs valeurs par défaut, des commentaires explicatifs et un `JAMA_SECRET`
aléatoire.

## Paramètres généraux

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_VAR_DIR` | `~/.jama` | Répertoire de base utilisé pour les données persistantes quand aucun chemin plus spécifique n'est configuré. |
| `JAMA_SECRET` | Généré dans `JAMA_VAR_DIR/env`, sinon valeur de secours codée dans les settings | Secret Django. En production, il doit être défini explicitement et rester confidentiel. |
| `JAMA_API_KEY_HASH_SECRET` | Même valeur que `JAMA_SECRET` | Secret utilisé pour calculer les empreintes des clefs d'API stockées en base. Le modifier invalide les clefs existantes. |
| `JAMA_DEBUG` | `0` | Active le mode debug Django avec `1`. Ne pas activer en production. |
| `JAMA_SITE` | `http://localhost:8000/` | URL publique de base du site. Utilisée pour construire des URLs absolues, notamment RPC, IIIF, ARK et notifications. |
| `JAMA_URL_BASE_PATH` | chaîne vide | Préfixe ajouté aux URLs Django. Utile si l'application est servie sous un sous-chemin. |
| `JAMA_ROOT_URL_REDIRECT` | non défini | Si renseigné, la page racine redirige vers cette URL. |
| `JAMA_APPS` | chaîne vide | Liste d'applications Python additionnelles, séparées par des virgules, à charger au démarrage. |
| `JAMA_ADMINS` | liste vide | Liste d'administrateurs Django, séparés par des virgules. |
| `JAMA_MANAGERS` | liste vide | Liste de managers Django, séparés par des virgules. |
| `JAMA_SHOW_RPC_DOCS` | `0` | Affiche la documentation RPC sur l'endpoint RPC GET si la valeur vaut `1`. |
| `JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS` | `1` | Active les URLs publiques `rpc/download_public/<hash>` et `rpc/serve/<hash>`. Mettre `0` pour répondre en `404` sur ces endpoints et ne plus générer ces URLs dans les sérialisations RPC. |
| `JAMA_RPC_MAX_BODY_SIZE` | `1048576` | Taille maximale du corps JSON accepté par l'endpoint RPC, en octets. Le défaut correspond à 1 Mio. Mettre `0` pour désactiver cette limite. |

## Stockage et fichiers temporaires

| Variable | Défaut                               | Description |
| --- |--------------------------------------| --- |
| `JAMA_FILES_DIR` | `${JAMA_VAR_DIR}/media_source_files` | Répertoire de stockage des fichiers sources originaux, organisés par hash. |
| `JAMA_PARTIAL_UPLOADS_DIR` | `${JAMA_VAR_DIR}/partial_uploads`    | Répertoire des morceaux d'upload incomplets. |
| `JAMA_UPLOAD_MAX_CHUNK_SIZE` | `134217728`                          | Taille maximale acceptée pour un morceau d'upload, en octets. Le défaut correspond à 128 Mio. |
| `JAMA_UPLOAD_MAX_TOTAL_CHUNKS` | `10000`                              | Nombre maximal de morceaux autorisés pour un upload. |
| `JAMA_TMP_THUMBNAILS_DIR` | répertoire temporaire système        | Répertoire de cache des miniatures temporaires générées par les vues `resources`. |
| `JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS` | `604800`                             | Âge maximal des miniatures temporaires avant suppression par la tâche de nettoyage. Le défaut correspond à 7 jours. Mettre `0` pour désactiver le nettoyage. |
| `JAMA_THUMBNAIL_MAX_SIZE` | `2000`                               | Taille maximale acceptée pour les miniatures simples générées par `resources/simple_thumb`. |
| `JAMA_THUMBNAIL_MAX_CROP_PIXELS` | `100000`                             | Valeur maximale autorisée pour chaque marge de crop dans l'endpoint `resources/thumb`. |
| `JAMA_MAX_IMAGE_PIXELS` | `100000000`                          | Nombre maximal de pixels qu'une image peut contenir lors de son ouverture par Pillow. Le défaut correspond à une image de 10000 x 10000 pixels. |
| `JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS` | `1800`                               | Timeout appliqué aux outils médias lancés en sous-processus (`ffmpeg`, `ffprobe`, `convert`, `vips`, `pdftoppm`, `pdftotext`, etc.). Le défaut correspond à 30 minutes. Mettre `0` pour désactiver le timeout. |
| `JAMA_STATIC_ROOT` | `${JAMA_VAR_DIR}/static`             | Destination de `collectstatic` pour les fichiers statiques en production. |

## Base de données et cache

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_DB_ADAPTER` | `sqlite` | Type de base de données. `sqlite` utilise SQLite, toute autre valeur utilise PostgreSQL/PostGIS selon `JAMA_USE_POSTGIS`. |
| `JAMA_SQLITE_DB_PATH` | `${JAMA_VAR_DIR}/db.sqlite3` | Chemin de la base SQLite lorsque `JAMA_DB_ADAPTER=sqlite`. |
| `JAMA_USE_POSTGIS` | `0` | Si `1`, utilise le backend Django PostGIS au lieu du backend PostgreSQL standard. |
| `JAMA_DB_HOST` | `localhost` | Hôte PostgreSQL. Utilisé uniquement hors SQLite. |
| `JAMA_DB_PORT` | `5432` | Port PostgreSQL. Utilisé uniquement hors SQLite. |
| `JAMA_DB_NAME` | `django` | Nom de la base PostgreSQL. Utilisé uniquement hors SQLite. |
| `JAMA_DB_USER` | `django` | Utilisateur PostgreSQL. Utilisé uniquement hors SQLite. |
| `JAMA_DB_PASSWORD` | `django` | Mot de passe PostgreSQL. Utilisé uniquement hors SQLite. |
| `JAMA_CACHE_BACKEND` | `file` | Backend de cache. `memcached` utilise `127.0.0.1:11211`, toute autre valeur utilise le cache fichier. |

Note : l'emplacement du cache fichier est configuré par `CACHE_LOCATION`, pas par
une variable `JAMA_*`.

## IIIF

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_IIIF_DIR` | `${JAMA_VAR_DIR}/iiif` | Répertoire des fichiers tuilés servis par le serveur IIIF. |
| `JAMA_IIIF_PROCESSING_DIR` | `${JAMA_VAR_DIR}/processing` | Répertoire temporaire utilisé pendant la génération des fichiers IIIF. |
| `JAMA_IIIF_ENDPOINT` | `http://localhost/iip/IIIF=` | URL publique de base utilisée pour construire les URLs IIIF exposées aux clients. |
| `JAMA_IIIF_UPSTREAM_URL` | valeur de `JAMA_IIIF_ENDPOINT` | URL amont utilisée par le proxy IIIF intégré. Peut différer de l'URL publique. |
| `JAMA_IIIF_UPSCALING_PREFIX` | `^` | Préfixe IIIF utilisé dans les URLs de redimensionnement pour autoriser l'upscaling selon le serveur IIIF. |
| `JAMA_IIIF_PATH_SEPARATOR` | séparateur système (`/` sur Unix) | Séparateur utilisé pour construire les chemins IIIF à partir du hash. Avec certains serveurs comme Cantaloupe, utiliser un séparateur encodé comme `%2F`. |
| `JAMA_IIIF_URLS_NEED_AUTH` | `0` | Si `1`, le proxy IIIF vérifie que l'utilisateur connecté a le droit de lire la ressource correspondant au hash demandé. |
| `JAMA_USE_WEBP` | `1` | Si `1`, les pyramides d'images générées utilisent une compression WebP quand c'est possible. Vérifier la compatibilité du serveur IIIF. |

## HLS

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_HLS_DIR` | `${JAMA_VAR_DIR}/hls` | Répertoire des sorties HLS générées à partir des vidéos. |
| `JAMA_HLS_ENDPOINT` | `http://localhost:8000/hls/` | URL publique de base utilisée pour construire les URLs HLS exposées aux clients. |
| `JAMA_HLS_URLS_NEED_AUTH` | `0` | Si `1`, les fichiers HLS ne sont servis qu'aux utilisateurs authentifiés ayant un droit de lecture sur la ressource. |

## ARK

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_USE_ARK` | `0` | Active les routes ARK si la valeur vaut `1`. |
| `JAMA_ARK_SERVER` | chaîne vide | URL ou identifiant du serveur ARK utilisé par les tâches d'attribution d'ARK. |
| `JAMA_ARK_APP_ID` | chaîne vide | Identifiant applicatif pour le service ARK. |
| `JAMA_ARK_SECRET_KEY` | chaîne vide | Secret applicatif pour le service ARK. |

## Authentification et interface

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_USE_MODSHIB` | `1` | Charge l'application d'authentification ModShib si la valeur vaut `1`. |
| `JAMA_UI_ANNOTATIONS` | `0` | Active la fonctionnalité d'annotations dans l'application UI si la valeur vaut `1`. |
| `JAMA_UI_TITLE` | `JAMA UI` | Titre affiché par l'application UI. |

## Tâches et exports

| Variable | Défaut | Description |
| --- | --- | --- |
| `JAMA_PERIODIC_FILE_INTEGRITY_CHECK` | `0` | Active la tâche périodique de contrôle d'intégrité des fichiers si la valeur vaut `1`. |
| `JAMA_XLSX_EXPORT_AUTOMATIC_METADATAS` | `0` | Si `1`, les exports XLSX incluent aussi les métadonnées automatiques comme OCR et ExifTool. |
