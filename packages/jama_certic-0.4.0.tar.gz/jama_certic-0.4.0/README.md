# Jamā (जमा)

APIs et interfaces de stockage de médias.

## Pré-requis

- uv `curl -LsSf https://astral.sh/uv/install.sh | sh`
- imagemagick
- pdftoppm, pdftotext (poppler-utils)
- vips (libvips-tools)
- tesseract
- exiftool

## Installation

### Installation de JAMA, création d'un super-utilisateur et d'un projet de test

    make install

## Démarrage (développement)

    make run

Vous avez alors accès à la page d'accueil (par défaut http://localhost:8000).  

## Configuration

Au moment de l'installation, un fichier d'environnement est créé dans `$HOME/.jama/env`. Vous pouvez modifier
ce fichier pour modifier la configuration de Jama.

La liste complète des variables disponibles, leurs valeurs par défaut et leurs
effets sont documentés dans [configuration.md](configuration.md).

Concernant le serveur IIIF, pour un fonctionnement avec un serveur Cantaloupe par défaut :

    JAMA_USE_WEBP=0  # pas de prise en charge du WEBP par Cantaloupe 5.x. Utilisez IIPImage à la place
    JAMA_IIIF_PATH_SEPARATOR="%2F" # Le séparateur de dossier doit être URL-encoded
    JAMA_IIIF_ENDPOINT="http://localhost:8182/iiif/2/" # endpoint IIIF v2 par défaut

### Utilisation avec PostgreSQL

Si vous prévoyez d'utiliser Jama avec un nombre important d'utilisateurs en simultané, il est 
préférable d'utiliser PostgreSQL plutôt que SQLite.

Crééz une base de données :

```bash
source .env
sudo -u postgres psql -p $JAMA_DB_PORT -dpostgres -t -c "CREATE ROLE $JAMA_DB_USER ENCRYPTED PASSWORD '$JAMA_DB_PASSWORD' NOSUPERUSER NOCREATEDB NOCREATEROLE INHERIT LOGIN;"
sudo -u postgres createdb -p $JAMA_DB_PORT -O $JAMA_DB_USER -E UTF8 $JAMA_DB_NAME;
```

Modifiez `$HOME/.jama/env`:

    JAMA_DB_ADAPTER="postgresql"
    JAMA_DB_HOST="$JAMA_DB_HOST"
    JAMA_DB_NAME="$JAMA_DB_NAME"
    JAMA_DB_PASSWORD="$JAMA_DB_PASSWORD"
    JAMA_DB_PORT="$JAMA_DB_PORT"
    JAMA_DB_USER="$JAMA_DB_USER"

Lancez à nouveau l'installation :

    make install

## Commandes CLI

### Ajout de fichiers locaux

Une commande permet d'ajouter des fichiers locaux à Jama au nom d'un
utilisateur Jama :

    uv run jama addlocalfiles /var/fichiers_a_ajouter/ jacques 1 --extensions .jpg .tif

Ici, le dossier `fichiers_a_ajouter` sera parcouru récursivement et les fichiers
avec une extension _.jpg_ ou _.tif_ seront ajoutés dans Jama dans le project ayant l'identifiant 1,
par l'utilisateur jacques. L'utilisateur comme le projet doivet exister préalablement dans Jama.

### Création d'un nouveau projet :

    (venv) code/jama: uv run jama newjamaproject "mon projet"
    Projet "mon projet" créé avec le compte administrateur "admin_mon_projet" et la clef d'API "EOwy6laNTMBDUvH6pGuOvGdMEpYM2F9M"

### Snapshot et restauration d'un projet

Jama peut exporter un projet sous forme de snapshot réimportable. Le snapshot
est un dossier contenant des sections NDJSON (`*.ndjson`) et un fichier
`manifest.json`.

Lister les projets et leurs identifiants :

    uv run jama listprojects

Exporter seulement les données de base de données :

    uv run jama snapshotproject 1 /var/backups/jama/projet-1

Exporter les données et les fichiers sources originaux :

    uv run jama snapshotproject 1 /var/backups/jama/projet-1 --include-files

Restaurer dans un nouveau projet :

    uv run jama restoreproject /var/backups/jama/projet-1 "projet restauré"

Remplacer un projet existant en conservant son identifiant :

    uv run jama restoreproject /var/backups/jama/projet-1 "projet existant" --replace-in-place

Avant un remplacement en place, Jama écrit automatiquement un snapshot de
sécurité, sans les fichiers sources par défaut, à côté du snapshot utilisé pour
la restauration :

    /var/backups/jama/projet-1.pre-replace-42-20260523T143012Z/

Le dossier du snapshot de sécurité peut être choisi explicitement :

    uv run jama restoreproject /var/backups/jama/projet-1 "projet existant" \
        --replace-in-place \
        --safety-snapshot-dir /var/backups/jama/securite/projet-42

Pour inclure aussi les fichiers sources dans ce snapshot de sécurité :

    uv run jama restoreproject /var/backups/jama/projet-1 "projet existant" \
        --replace-in-place \
        --safety-include-files

Sans `--replace-in-place`, la restauration crée toujours un nouveau projet et le
nom du projet ne doit pas déjà exister. Avec `--replace-in-place`, le nom du projet doit déjà exister et le contenu du projet est remplacé en conservant son
identifiant. Les ARK des ressources et collections sont conservés ; si un ARK du
snapshot existe déjà dans l'instance cible en dehors du projet remplacé, la
restauration échoue.

Les fichiers sources sont optionnels dans le snapshot. Sans `--include-files`,
les lignes `File` sont restaurées en base mais les fichiers doivent déjà être
présents dans le stockage de Jama pour que les ressources soient pleinement
utilisables. Les fichiers dérivés IIIF ou HLS ne sont pas inclus
dans le snapshot et sont régénérés après restauration lorsque les fichiers
sources sont disponibles.

Pendant une restauration, le projet est marqué comme `restoring` et n'apparaît
pas dans les listes de projets ni dans les résolutions ARK publiques. En cas
d'échec, il reste marqué `restore_failed` pour inspection et nettoyage manuel.

Les annotations ne sont pas incluses dans le format de snapshot actuel, car le
modèle d'annotation n'est pas encore stabilisé.

## Étendre JAMA

Les fonctionnalités de JAMA peuvent être étendues par le biais habituel des
[applications Django](https://docs.djangoproject.com/fr/4.0/ref/applications/).

### Applications Django et ajout de vues

Afin de faciliter l'installation d'applications Django sans avoir besoin de toucher au fichier `jama/settings.py`, une
variable d'environnement `JAMA_APPS` peut contenir une liste (séparée par des virgules) de modules python à charger en
tant
qu'applications Django.

### Point de montage des URLs de l'application

Soit une application fictive `mon_application`, si la variable `endpoint` est définie dans le fichier
`mon_application/__init__.py`, alors `endpoint` est utilisé comme point de montage pour les URLs définies dans
l'application Django (fichier `mon_application/urls.py`).

Exemple :

Dans le fichier `mon_application/__init__.py`:

```
endpoint = "mon-appli/"
```

Dans `mon_application/urls.py`:

```
from django.urls import path
from . import views

urlpatterns = [
    path("test/", views.test),
]
```

La vue Django `test` sera accessible à l'URL `/mon-appli/test/`.

### Ajout de méthodes RPC

Il est possible d'ajouter des méthodes au point de montage RPC. Il suffit pour cela d'ajouter des fonctions dans un
module `mon_application/rpc/methods.py`. Toute fonction déclarée dans ce fichier sera ajoutée à la liste des fonctions
RPC, à l'exception des fonctions dont le nom commence par `_`.

Exemple, dans le fichier `mon_application/rpc/methods.py`:

```
from django.contrib.auth.models import User


def test_from_my_app(user: User, test_string: str) -> str:
    return test_string
```

Le premier argument de la méthode RPC est __toujours__ une instance de
[django.contrib.auth.models.User](https://docs.djangoproject.com/fr/4.0/ref/contrib/auth/#django.contrib.auth.models.User).

Le type des arguments et du retour de la fonction **doivent** être spécifiés.

⚠️ Il est possible d'écraser une méthode définie précédemment. À votre charge d'assurer l'unicité du nom de votre
méthode.
Une possibilité est de préfixer le nom de la méthode avec le nom de votre application.

⚠️ Le retour de la méthode RPC __doit__ être sérialisable par l'encodeur par défaut du module standard `json`.


### FAQ

##### Relancer un tuilage en échec
```
$ uv run jama repl
Python 3.13.1 (main, Jan 14 2025, 22:47:38) [Clang 19.1.6 ] on linux
Type "help", "copyright", "credits" or "license" for more information.
(InteractiveConsole)
>>> f = File.objects.filter(title="the_failed_filename").first()
>>> make_iiif(f, True)
```

##### Lister le nombre de tuilages manquant
```
$ uv run jama repl
Python 3.13.1 (main, Jan 14 2025, 22:47:38) [Clang 19.1.6 ] on linux
Type "help", "copyright", "credits" or "license" for more information.
(InteractiveConsole)
>>> File.objects.filter(tiled=False).count()
1481
```
_Attention, certains types de fichiers ne seront jamais tuilés, il conviendra de filtrer le champ file\_type pour s'assurer d'un résultat cohérent_
