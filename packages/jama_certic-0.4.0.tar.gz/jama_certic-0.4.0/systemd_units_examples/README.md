# Example systemd units

These are example service units for you to customize in your production setup.

- web.service is a base configuration for a gunicorn running the web app
- worker.service executes the background tasks
- cron.service registers the recurring tasks

You may have multiple copies of the worker.service to have multiple tasks workers.