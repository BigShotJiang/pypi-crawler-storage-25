import logging
from typing import List
from django.conf import settings
from django.urls import reverse
from django.utils import timezone
from django.db import connection
from resources import models
import os
import time
import shutil
import hashlib
from pathlib import Path
from django.core.mail import mail_admins
from django.tasks import task
from crontask import cron

logger = logging.getLogger(__name__)

TMP_THUMBNAIL_PREFIXES = ("thumb-", "simple_thumb-")


@task
def exif_task(file_id: int) -> int:
    from resources.models import File
    from resources.helpers import set_exif_metas

    try:
        f = File.objects.get(pk=file_id)
        return set_exif_metas(f)
    except File.DoesNotExist:
        logger.info(f"exif_task stopped: no file with id {file_id}")
        return 0
    except Exception as e:
        logger.warning("exit_task({}) failed".format(file_id))
        logger.info(repr(e))
        raise e


@task
def iiif_task(file_id: int) -> bool:
    from resources.models import File
    from resources.helpers import make_iiif

    try:
        f = File.objects.get(pk=file_id)
        make_iiif(f)
        return True
    except File.DoesNotExist:
        logger.info(f"iiif_task stopped: no file with id {file_id}")
        return False
    except Exception as e:
        logger.warning("iiif_task({}) failed: {}".format(file_id, repr(e)))
        raise e


@task
def hls_task(file_id: int):
    from resources.models import File
    from resources.helpers import make_hls

    try:
        f = File.objects.get(pk=file_id)
        make_hls(f)
        return True
    except File.DoesNotExist:
        logger.info(f"hls_task stopped: no file with id {file_id}")
        return False
    except Exception as e:
        logger.warning("hls_task({}) failed: {}".format(file_id, repr(e)))
        raise e


@task
def ocr_task(file_id: int):
    from resources.models import File
    from resources.helpers import make_ocr

    try:
        f = File.objects.get(pk=file_id)
        make_ocr(f)
    except File.DoesNotExist:
        logger.info(f"ocr_task stopped: no file with id {file_id}")
        return
    except Exception as e:
        logger.warning("ocr_task({}) failed".format(file_id))
        logger.info(repr(e))
        raise e


def _resource_ark_location(resource_id: int):
    base_url = (
        settings.JAMA_SITE[:-1] if settings.JAMA_SITE[-1] == "/" else settings.JAMA_SITE
    )
    return base_url + reverse("ark_resource", kwargs={"resource_id": resource_id})


@task
def set_ark_to_resource(resource_id: int, location: str = None):
    if settings.ARK_SERVER and settings.ARK_APP_ID and settings.ARK_SECRET_KEY:
        from resources.models import Resource

        resource = Resource.objects.filter(pk=resource_id).first()
        if not resource:
            logger.warning(f"resource {resource_id} does not exist")
            return
        if resource.ark and not location:
            logger.info(f"resource {resource_id} has ark already, no update needed.")
            return
        import ark_client

        if not location:
            location = _resource_ark_location(resource_id)
        client = ark_client.Client(
            settings.ARK_APP_ID, settings.ARK_SECRET_KEY, settings.ARK_SERVER
        )
        if resource.ark:
            client.update(resource.ark, location)
        else:
            ark_name = client.create(location)
            resource.ark = ark_name
            Resource.objects.filter(pk=resource.pk).update(ark=ark_name)


@task
def set_ark_to_collection(collection_id: int, location: str = None):
    if settings.ARK_SERVER and settings.ARK_APP_ID and settings.ARK_SECRET_KEY:
        from resources.models import Collection

        collection = Collection.objects.filter(pk=collection_id).first()
        if not collection:
            logger.warning(f"collection {collection_id} does not exist")
            return
        if collection.ark and not location:
            logger.info(
                f"collection {collection_id} has ark already, no update needed."
            )
            return
        import ark_client

        if not location:
            base_url = (
                settings.JAMA_SITE[:-1]
                if settings.JAMA_SITE[-1] == "/"
                else settings.JAMA_SITE
            )
            location = base_url + reverse(
                "ark_collection", kwargs={"collection_id": collection_id}
            )
        client = ark_client.Client(
            settings.ARK_APP_ID, settings.ARK_SECRET_KEY, settings.ARK_SERVER
        )
        if collection.ark:
            client.update(collection.ark, location)
        else:
            ark_name = client.create(location)
            collection.ark = ark_name
            Collection.objects.filter(pk=collection.pk).update(ark=ark_name)


@task
def recursive_set_metas_to_collection(
    user_id: int, collection_id: int, metas: List[dict], user_task_id: int = None
) -> bool:
    r"""
    Sets all metas for a unique metadata set.

    Metas is a list of metadata id => metadata value dictionaries.

    All metas must share the same metadata set.

    the meta will be set to all direct children resources.

    /!\ *Not* actually recursive: Descendants (sub-collections and sub-collections resources) are IGNORED.
    """
    if not metas:
        raise ValueError("empty metas list")
    from rpc.methods import (
        remove_meta_value_from_collection,
        add_meta_to_collection,
        set_metas_to_resource,
    )
    from resources.models import Metadata, Collection, MetadataSet, UserTask
    from django.contrib.auth.models import User

    user_task = UserTask.objects.filter(pk=user_task_id).first()
    if user_task:
        user_task.started_at = timezone.now()
        user_task.save()

    # prevent mixing metas from different sets
    metadatasets_ids = []
    for meta_dict in metas:
        meta = Metadata.objects.get(pk=meta_dict["id"])
        metadatasets_ids.append(meta.set.pk)
    metadatasets_ids = list(set(metadatasets_ids))
    if len(metadatasets_ids) > 1:
        if user_task:
            user_task.failed_at = timezone.now()
            user_task.save()
        return False

    # check that objects exist
    collection_instance = Collection.objects.filter(
        pk=collection_id, deleted_at__isnull=True
    ).first()
    if not collection_instance:
        if user_task:
            user_task.failed_at = timezone.now()
            user_task.save()
        return False
    metadataset_instance = MetadataSet.objects.filter(pk=metadatasets_ids[0]).first()
    if not metadataset_instance:
        if user_task:
            user_task.failed_at = timezone.now()
            user_task.save()
        return False

    user = User.objects.filter(pk=user_id).first()
    if not user:
        if user_task:
            user_task.failed_at = timezone.now()
            user_task.save()
        return False

    # remove all metas from the set
    for meta_value in collection_instance.metadatacollectionvalue_set.filter(
        metadata__set=metadataset_instance
    ):
        remove_meta_value_from_collection(user, collection_id, meta_value.pk)

    # add metas
    for meta_dict in metas:
        add_meta_to_collection(user, collection_id, meta_dict["id"], meta_dict["value"])

    for resource in collection_instance.resources.filter(deleted_at__isnull=True):
        set_metas_to_resource(user, resource.pk, metas)

    if user_task:
        user_task.finished_at = timezone.now()
        user_task.save()
    return True


@task
def update_data_from_xlsx_rows(
    user_id: int, xlsx_rows: List[dict], user_task_id: int = None
):
    from django.contrib.auth.models import User
    from resources.models import UserTask

    project = None

    # Try to find the project
    for r in xlsx_rows:
        if r.get("resource_pk"):
            first_resource = models.Resource.objects.filter(
                pk=r.get("resource_pk")
            ).first()
            if first_resource:
                project = first_resource.ptr_project
                break
        if r.get("collection_pk"):
            first_collection = models.Collection.objects.filter(
                pk=r.get("collection_pk")
            ).first()
            if first_collection:
                project = first_collection.project
                break
    user_task = None
    user = User.objects.filter(pk=user_id).first()
    if user:
        if user_task_id is not None:
            user_task = UserTask.objects.filter(pk=user_task_id).first()
            if user_task:
                user_task.project = project
                user_task.started_at = timezone.now()
                user_task.save()
        from rpc.methods import (
            update_resource_from_xlsx_row,
            update_collection_from_xlsx_row,
            ServiceException,
        )

        for xlsx_row in xlsx_rows:
            try:
                if xlsx_row.get("resource_pk"):
                    update_resource_from_xlsx_row(user, xlsx_row)
                if xlsx_row.get("collection_pk"):
                    update_collection_from_xlsx_row(user, xlsx_row)
            except ServiceException as e:
                logger.warning(e)
        if user_task:
            user_task.finished_at = timezone.now()
            user_task.save()
    else:
        logger.warning(
            f"No such user({user_id}) for update_data_from_xlsx_rows task, canceling."
        )


@cron("0 * * * *")
@task
def ensureiiif():
    logger.info("ensure IIIF...")
    from resources.models import File
    from resources.helpers import iiif_destination_dir_from_hash

    start_date = timezone.now() - timezone.timedelta(days=1)
    for f in (
        File.objects.filter(
            file_type__serve_with_iiif=True,
            deleted_at__isnull=True,
            created_at__gte=start_date,
            tiled=False,
        )
        .distinct()
        .iterator()
    ):
        iiif_destination_dir = iiif_destination_dir_from_hash(f.hash)
        iiif_destination_file = "{}{}".format(iiif_destination_dir, f.hash)
        if not os.path.exists(iiif_destination_file):
            iiif_task.enqueue(f.pk)
            logger.info(f"tasked missing IIIF for file({f.pk})")


@cron("0 * * * *")
@task
def clean_partial_uploads():
    logger.info("clean partial uploads...")
    now = time.time()
    max_age = 60 * 60 * 6
    sub_folders = [
        f.path for f in os.scandir(settings.PARTIAL_UPLOADS_DIR) if f.is_dir()
    ]
    for folder in sub_folders:
        folder_time = os.path.getmtime(folder)
        if now - folder_time > max_age:
            logger.info(f"removing partial uploads dir {folder}")
            shutil.rmtree(folder)


def clean_tmp_thumbnails_now(now: float = None) -> int:
    max_age = settings.JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS
    if max_age <= 0:
        return 0

    now = now if now is not None else time.time()
    thumbnails_dir = Path(settings.TMP_THUMBNAILS_DIR).resolve()
    if not thumbnails_dir.is_dir():
        return 0

    deleted_count = 0
    for path in thumbnails_dir.iterdir():
        if not path.is_file():
            continue
        if not path.name.startswith(TMP_THUMBNAIL_PREFIXES):
            continue
        if now - path.stat().st_mtime <= max_age:
            continue
        path.unlink(missing_ok=True)
        deleted_count += 1
    return deleted_count


@cron("15 * * * *")
@task
def clean_tmp_thumbnails():
    deleted_count = clean_tmp_thumbnails_now()
    logger.info(f"removed {deleted_count} temporary thumbnail(s)")
    return deleted_count


@cron("0 0 * * SUN")
@task
def check_files_integrity():
    logger.info("file integrity check...")
    if not settings.JAMA_PERIODIC_FILE_INTEGRITY_CHECK:
        logger.info(
            "skipping file integrity check as per JAMA_PERIODIC_FILE_INTEGRITY_CHECK"
        )
        return True

    def file_hash256(file_path: str) -> str:
        try:
            hsh = hashlib.sha256()
            with open(file_path, "rb") as f:
                for chnk in iter(lambda: f.read(8192), b""):
                    hsh.update(chnk)
            return hsh.hexdigest()
        except FileNotFoundError:
            return ""

    cursor = connection.cursor()
    cursor.execute(
        "select distinct(hash) from resources_file where resources_file.integrity_check_failed_at is null"
    )
    for row in cursor.fetchall():
        new_hash = file_hash256(models.hash_to_local_path(row[0]))
        if new_hash != row[0]:
            logger.warning(f"FILE INTEGRITY CHECK FAILED. File hash: {row[0]}")
            mail_admins(
                f"[{settings.JAMA_SITE}] FILE INTEGRITY CHECK FAILED",
                f"File hash: {row[0]}",
                fail_silently=True,
            )
            models.File.objects.filter(
                hash=row[0], integrity_check_failed_at__isnull=True
            ).update(integrity_check_failed_at=timezone.now())
    connection.close()
