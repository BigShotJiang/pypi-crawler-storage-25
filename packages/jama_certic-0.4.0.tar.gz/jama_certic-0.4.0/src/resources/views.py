from django.http import (
    HttpRequest,
    HttpResponse,
    HttpResponseForbidden,
    HttpResponseNotFound,
    HttpResponseBadRequest,
    FileResponse,
)
from django.contrib.auth.decorators import login_required
import pyvips
from resources.models import File
from resources.acl import UserAccess
from rpc.errors import ServiceException
import os.path
from typing import Union
from jama import settings
import re


def _get_authorized_file(
    request: HttpRequest, sha256: str, require_iiif: bool = False
) -> Union[File, None]:
    if re.fullmatch("[A-Fa-f0-9]{64}", sha256) is None:
        return None
    found_file = False
    for pic_file in File.objects.select_related("project", "file_type").filter(
        hash=sha256
    ):
        found_file = True
        if require_iiif and not pic_file.should_have_iiif:
            continue
        if UserAccess(request.user, pic_file.project).can_read(pic_file):
            return pic_file
    if found_file:
        raise ServiceException("Forbidden")
    return None


def _valid_simple_thumb_size(size: int) -> bool:
    return 1 <= int(size) <= settings.JAMA_THUMBNAIL_MAX_SIZE


def _valid_crop_values(*values: int) -> bool:
    return all(
        0 <= value <= settings.JAMA_THUMBNAIL_MAX_CROP_PIXELS for value in values
    )


@login_required
def simple_thumb(
    request: HttpRequest, sha256: str, size: int
) -> Union[FileResponse, HttpResponseNotFound, HttpResponseBadRequest, HttpResponse]:
    try:
        if not _valid_simple_thumb_size(size):
            return HttpResponseBadRequest("Bad Request")
        pic_file = _get_authorized_file(request, sha256, require_iiif=True)
    except ValueError:
        return HttpResponseBadRequest("Bad Request")
    except ServiceException:
        return HttpResponseForbidden("Forbidden")
    if not pic_file:
        return HttpResponseNotFound("Not Found")
    tmp_pic_path = "{}/simple_thumb-{}-{}.jpg".format(
        settings.TMP_THUMBNAILS_DIR, sha256, size
    )
    if not os.path.isfile(tmp_pic_path):
        thumbnail = pyvips.Image.thumbnail(
            pic_file.local_path(),
            int(size),  # crop="attention"
        )
        thumbnail.write_to_file(tmp_pic_path)
    return FileResponse(open(tmp_pic_path, "rb"))


@login_required
def thumb(
    request: HttpRequest, sha256: str, angle: float, scale: float, crop: str
) -> Union[FileResponse, HttpResponseNotFound, HttpResponseBadRequest, HttpResponse]:
    try:
        pic_file = _get_authorized_file(request, sha256)
        if not pic_file:
            return HttpResponseNotFound("Not Found")
        top, right, bottom, left = crop.split(",")
        top = int(top)
        right = int(right)
        bottom = int(bottom)
        left = int(left)
        angle = float(angle)
        scale = float(scale)
        if (
            angle > 360
            or angle < 0
            or scale <= 0
            or scale > 1
            or not _valid_crop_values(top, right, bottom, left)
        ):
            raise ValueError
    except ValueError:
        return HttpResponseBadRequest("Bad Request")
    except ServiceException:
        return HttpResponseForbidden("Forbidden")
    tmp_pic_path = "{}/thumb-{}-{}-{}-{}-{}-{}-{}.jpg".format(
        settings.TMP_THUMBNAILS_DIR, sha256, angle, scale, top, right, bottom, left
    )
    local_path = pic_file.local_path()
    if pic_file.file_type.mime == "image/jp2":
        local_path = pic_file.iiif_destination_file()
    if not os.path.isfile(tmp_pic_path):
        crop_color = [96]
        pyvips.cache_set_max(0)
        img = pyvips.Image.new_from_file(local_path)
        if angle:
            img = img.rotate(angle)
        img = img.draw_rect(crop_color, 0, 0, left, img.height, fill=True)
        img = img.draw_rect(crop_color, 0, 0, img.width, top, fill=True)
        img = img.draw_rect(
            crop_color, 0, img.height - bottom, img.width, bottom, fill=True
        )
        img = img.draw_rect(
            crop_color, img.width - right, 0, right, img.height, fill=True
        )
        img = img.resize(scale)
        img.write_to_file(tmp_pic_path)
    return FileResponse(open(tmp_pic_path, "rb"))
