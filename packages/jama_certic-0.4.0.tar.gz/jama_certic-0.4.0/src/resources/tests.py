from django.core.management import call_command
from django.test import RequestFactory, TestCase
from django.contrib.auth.models import User
from types import SimpleNamespace
from unittest.mock import Mock, patch
from tempfile import TemporaryDirectory
from io import StringIO
from pathlib import Path
import hashlib
import json
import os

from resources.acl import make_or_create_global_readonly_role_for_project, UserAccess
from resources import helpers
from resources import snapshots
from resources import tasks
from resources import views
from rpc import methods as rpc_methods
from resources.models import (
    File,
    FileExtension,
    FileType,
    ObjectPermission,
    Project,
    ProjectAccess,
    Role,
)
from resources import models


class ServiceTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def test_global_readonly_role_cannot_delete(self):
        user = User.objects.create(username="readonly_user")
        project = Project.objects.create(label="readonly project", description="")
        role = make_or_create_global_readonly_role_for_project(project)
        ProjectAccess.objects.create(project=project, user=user, role=role)
        access = UserAccess(user, project)

        self.assertTrue(access.can_read("resource"))
        self.assertFalse(access.can_create("resource"))
        self.assertFalse(access.can_update("resource"))
        self.assertFalse(access.can_delete("resource"))

    def test_media_command_uses_configured_timeout(self):
        with patch.object(
            helpers.settings, "JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS", 42
        ):
            with patch.object(helpers.subprocess, "run") as subprocess_run:
                helpers._run_media_command(["convert", "input", "output"])
        subprocess_run.assert_called_once()
        self.assertEqual(subprocess_run.call_args.kwargs["timeout"], 42)

    def test_media_command_timeout_can_be_disabled(self):
        with patch.object(helpers.settings, "JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS", 0):
            with patch.object(helpers.subprocess, "run") as subprocess_run:
                helpers._run_media_command(["convert", "input", "output"])
        subprocess_run.assert_called_once()
        self.assertIsNone(subprocess_run.call_args.kwargs["timeout"])

    def test_pillow_max_image_pixels_uses_setting(self):
        self.assertEqual(
            models.Image.MAX_IMAGE_PIXELS, models.settings.JAMA_MAX_IMAGE_PIXELS
        )

    def test_file_type_support_cache_is_invalidated_on_save(self):
        file_type = FileType.objects.create(
            title="cache test",
            mime="application/cache-test",
            serve_with_iiif=False,
            serve_with_hls=False,
        )
        self.assertFalse(models._file_type_is_served_with_iiif(file_type.pk))
        self.assertFalse(models._file_type_is_served_with_hls(file_type.pk))

        file_type.serve_with_iiif = True
        file_type.serve_with_hls = True
        file_type.save()

        self.assertTrue(models._file_type_is_served_with_iiif(file_type.pk))
        self.assertTrue(models._file_type_is_served_with_hls(file_type.pk))

    def test_clean_tmp_thumbnails_only_removes_old_thumbnail_files(self):
        with TemporaryDirectory() as temp_dir:
            base_dir = Path(temp_dir)
            old_thumb = base_dir / "thumb-a.jpg"
            old_simple_thumb = base_dir / "simple_thumb-a.jpg"
            old_unrelated = base_dir / "unrelated.jpg"
            fresh_thumb = base_dir / "thumb-fresh.jpg"
            nested_dir = base_dir / "nested"
            nested_dir.mkdir()
            nested_thumb = nested_dir / "thumb-nested.jpg"

            for path in [
                old_thumb,
                old_simple_thumb,
                old_unrelated,
                fresh_thumb,
                nested_thumb,
            ]:
                path.write_text("x", encoding="utf-8")

            old_time = 1000
            fresh_time = 2000
            os.utime(old_thumb, (old_time, old_time))
            os.utime(old_simple_thumb, (old_time, old_time))
            os.utime(old_unrelated, (old_time, old_time))
            os.utime(nested_thumb, (old_time, old_time))
            os.utime(fresh_thumb, (fresh_time, fresh_time))

            with patch.object(tasks.settings, "TMP_THUMBNAILS_DIR", str(base_dir)):
                with patch.object(
                    tasks.settings, "JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS", 500
                ):
                    deleted_count = tasks.clean_tmp_thumbnails_now(now=2000)

            self.assertEqual(deleted_count, 2)
            self.assertFalse(old_thumb.exists())
            self.assertFalse(old_simple_thumb.exists())
            self.assertTrue(old_unrelated.exists())
            self.assertTrue(fresh_thumb.exists())
            self.assertTrue(nested_thumb.exists())

    def test_clean_tmp_thumbnails_can_be_disabled(self):
        with TemporaryDirectory() as temp_dir:
            base_dir = Path(temp_dir)
            old_thumb = base_dir / "thumb-a.jpg"
            old_thumb.write_text("x", encoding="utf-8")
            os.utime(old_thumb, (1000, 1000))

            with patch.object(tasks.settings, "TMP_THUMBNAILS_DIR", str(base_dir)):
                with patch.object(
                    tasks.settings, "JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS", 0
                ):
                    deleted_count = tasks.clean_tmp_thumbnails_now(now=2000)

            self.assertEqual(deleted_count, 0)
            self.assertTrue(old_thumb.exists())


class ProjectSnapshotTestCase(TestCase):
    def setUp(self):
        self.extension = FileExtension.objects.create(label="txt")
        self.file_type = FileType.objects.create(
            title="Text",
            mime="text/plain",
            serve_with_iiif=False,
            serve_with_hls=False,
        )
        self.file_type.extensions.add(self.extension)
        self.user = User.objects.create(username="snapshot_user")
        self.project = Project.objects.create(
            label="snapshot source",
            description="source description",
            ark_redirect="https://example.test/[CLASS]/[ARK]/[PK]",
        )
        self.role = Role.objects.create(label="reader", project=self.project)
        ObjectPermission.objects.create(
            role=self.role,
            object_class="resource",
            object_pk=None,
            object_read=True,
        )
        ProjectAccess.objects.create(
            project=self.project, user=self.user, role=self.role
        )
        self.tag = models.Tag.objects.create(
            uid="tag:one", label="Tag One", ark="tag/ark", project=self.project
        )
        self.meta_set = models.MetadataSet.objects.create(
            title="Dublin Core", project=self.project
        )
        self.meta = models.Metadata.objects.create(
            title="title", set=self.meta_set, rank=1, project=self.project
        )
        self.root = models.Collection.objects.create(
            title="root", project=self.project, parent=None, ark="ark:/collection/root"
        )
        self.child = models.Collection.objects.create(
            title="child", project=self.project, parent=self.root
        )
        self.resource = models.Resource.objects.create(
            title="plain resource", ptr_project=self.project, ark="ark:/resource/plain"
        )
        self.file = File.objects.create(
            title="text file",
            original_name="file.txt",
            project=self.project,
            hash="b" * 64,
            file_type=self.file_type,
            size=4,
            denormalized_image_width=1,
            denormalized_image_height=1,
            ark="ark:/resource/file",
        )
        self.resource.tags.add(self.tag)
        self.child.tags.add(self.tag)
        models.CollectionMembership.objects.create(
            collection=self.child, resource=self.resource, rank=7
        )
        models.CollectionMembership.objects.create(
            collection=self.child, resource=self.file, rank=8
        )
        models.MetadataCollectionValue.objects.create(
            metadata=self.meta, collection=self.child, value="collection title"
        )
        models.MetadataResourceValue.objects.create(
            metadata=self.meta, resource=self.resource, value="resource title"
        )
        models.ProjectProperty.objects.create(
            project=self.project, key="client", value={"enabled": True}
        )

    def test_snapshot_restore_round_trip_without_blobs(self):
        with TemporaryDirectory() as snapshot_dir:
            manifest = snapshots.export_project_snapshot(self.project.pk, snapshot_dir)
            resource_rows = [
                json.loads(line)
                for line in Path(snapshot_dir, "resources.ndjson")
                .read_text()
                .splitlines()
            ]
            self.assertEqual(len(resource_rows), 2)
            self.assertEqual(
                {row["title"]: row["kind"] for row in resource_rows},
                {"plain resource": "resource", "text file": "file"},
            )
            self.user.delete()
            self.project.delete()
            self.assertFalse(manifest["include_files"])
            self.assertEqual(
                json.loads(Path(snapshot_dir, "manifest.json").read_text())[
                    "excluded_apps"
                ],
                {"annotations": "Annotation model is not stable yet"},
            )

            restored = snapshots.restore_project_snapshot(
                snapshot_dir, "snapshot restored"
            )

        self.assertEqual(restored.restore_state, Project.RESTORE_STATE_READY)
        self.assertEqual(restored.description, self.project.description)
        self.assertTrue(
            User.objects.filter(username="snapshot_user", is_active=False).exists()
        )
        self.assertTrue(
            models.Collection.objects.filter(
                project=restored, title="root", ark="ark:/collection/root"
            ).exists()
        )
        restored_resource = models.Resource.objects.get(
            ptr_project=restored, title="plain resource"
        )
        self.assertEqual(restored_resource.ark, "ark:/resource/plain")
        self.assertEqual(restored_resource.tags.get().uid, "tag:one")
        self.assertEqual(
            models.MetadataResourceValue.objects.get(resource=restored_resource).value,
            "resource title",
        )
        self.assertTrue(
            models.ProjectProperty.objects.filter(
                project=restored, key="client", value={"enabled": True}
            ).exists()
        )
        self.assertEqual(
            models.File.objects.get(project=restored).ark, "ark:/resource/file"
        )
        self.assertEqual(
            models.ProjectAccess.objects.get(project=restored).user.username,
            "snapshot_user",
        )

    def test_file_only_project_has_resource_rows(self):
        self.resource.delete()
        with TemporaryDirectory() as snapshot_dir:
            snapshots.export_project_snapshot(self.project.pk, snapshot_dir)
            resource_rows = [
                json.loads(line)
                for line in Path(snapshot_dir, "resources.ndjson")
                .read_text()
                .splitlines()
            ]

        self.assertEqual(len(resource_rows), 1)
        self.assertEqual(resource_rows[0]["title"], "text file")
        self.assertEqual(resource_rows[0]["kind"], "file")

    def test_snapshot_with_files_copies_blob_and_restore_installs_it(self):
        content = b"blob"
        file_hash = hashlib.sha256(content).hexdigest()
        self.file.hash = file_hash
        self.file.size = len(content)
        self.file.save()
        with TemporaryDirectory() as media_dir:
            source_path = Path(models.hash_to_local_path(file_hash))
            with patch.object(models.settings, "MEDIA_FILES_DIR", media_dir):
                source_path = Path(models.hash_to_local_path(file_hash))
                source_path.parent.mkdir(parents=True, exist_ok=True)
                source_path.write_bytes(content)
                with TemporaryDirectory() as snapshot_dir:
                    snapshots.export_project_snapshot(
                        self.project.pk, snapshot_dir, include_files=True
                    )
                    self.project.delete()
                    source_path.unlink()
                    task_stub = SimpleNamespace(
                        iiif_task=SimpleNamespace(enqueue=Mock()),
                        ocr_task=SimpleNamespace(enqueue=Mock()),
                        hls_task=SimpleNamespace(enqueue=Mock()),
                        exif_task=SimpleNamespace(enqueue=Mock()),
                    )
                    with patch.object(snapshots, "tasks", task_stub):
                        snapshots.restore_project_snapshot(
                            snapshot_dir, "snapshot restored with blobs"
                        )
                self.assertEqual(source_path.read_bytes(), content)

    def test_replace_in_place_preserves_project_id_and_writes_safety_snapshot(self):
        with TemporaryDirectory() as temp_dir:
            temp_dir = Path(temp_dir)
            source_snapshot = temp_dir / "source-snapshot"
            safety_snapshot = temp_dir / "safety-snapshot"
            snapshots.export_project_snapshot(self.project.pk, source_snapshot)
            self.project.delete()

            target = Project.objects.create(
                label="target project", description="old description"
            )
            old_collection = models.Collection.objects.create(
                title="old collection", project=target, parent=None
            )
            old_resource = models.Resource.objects.create(
                title="old resource", ptr_project=target
            )
            models.CollectionMembership.objects.create(
                collection=old_collection, resource=old_resource
            )
            target_id = target.pk

            restored = snapshots.restore_project_snapshot(
                source_snapshot,
                "target project",
                replace_in_place=True,
                safety_snapshot_dir=safety_snapshot,
            )
            self.assertTrue((safety_snapshot / "manifest.json").exists())

        self.assertEqual(restored.pk, target_id)
        self.assertEqual(restored.restore_state, Project.RESTORE_STATE_READY)
        self.assertEqual(restored.description, "source description")
        self.assertEqual(restored.safety_snapshot_dir, str(safety_snapshot))
        self.assertFalse(
            models.Resource.objects.filter(
                ptr_project=restored, title="old resource"
            ).exists()
        )
        self.assertTrue(
            models.Resource.objects.filter(
                ptr_project=restored, title="plain resource", ark="ark:/resource/plain"
            ).exists()
        )
        self.assertTrue(
            models.File.objects.filter(
                project=restored, title="text file", ark="ark:/resource/file"
            ).exists()
        )

    def test_replace_in_place_ignores_ark_conflicts_inside_target_project(self):
        with TemporaryDirectory() as temp_dir:
            source_snapshot = Path(temp_dir) / "source-snapshot"
            snapshots.export_project_snapshot(self.project.pk, source_snapshot)

            restored = snapshots.restore_project_snapshot(
                source_snapshot,
                self.project.label,
                replace_in_place=True,
            )

        self.assertEqual(restored.pk, self.project.pk)
        self.assertEqual(restored.restore_state, Project.RESTORE_STATE_READY)

    def test_restore_aborts_on_ark_conflict(self):
        with TemporaryDirectory() as snapshot_dir:
            snapshots.export_project_snapshot(self.project.pk, snapshot_dir)
            models.Resource.objects.create(
                title="conflict",
                ptr_project=Project.objects.create(label="other", description=""),
                ark="ark:/resource/plain",
            )
            with self.assertRaises(snapshots.SnapshotError):
                snapshots.restore_project_snapshot(snapshot_dir, "snapshot restored")

    def test_restoring_projects_are_hidden_from_project_listing(self):
        hidden = Project.objects.create(
            label="hidden restore",
            description="",
            restore_state=Project.RESTORE_STATE_RESTORING,
        )
        visible = Project.objects.create(label="visible", description="")
        admin = User.objects.create(username="admin", is_superuser=True)

        listed_ids = {item["id"] for item in rpc_methods.list_projects(admin)}

        self.assertIn(visible.pk, listed_ids)
        self.assertNotIn(hidden.pk, listed_ids)

    def test_listprojects_command_lists_ready_projects_by_default(self):
        hidden = Project.objects.create(
            label="hidden restore",
            description="",
            restore_state=Project.RESTORE_STATE_RESTORING,
        )
        visible = Project.objects.create(label="visible", description="")

        stdout = StringIO()
        call_command("listprojects", stdout=stdout)
        output = stdout.getvalue()

        self.assertIn(f"{visible.pk}\tvisible\tready", output)
        self.assertNotIn(f"{hidden.pk}\thidden restore", output)

        stdout = StringIO()
        call_command("listprojects", "--all", stdout=stdout)
        output = stdout.getvalue()

        self.assertIn(f"{visible.pk}\tvisible\tready", output)
        self.assertIn(f"{hidden.pk}\thidden restore\trestoring", output)


class ThumbnailViewsTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username="thumbnail_user")
        self.no_access_user = User.objects.create(username="thumbnail_no_access_user")
        self.project = Project.objects.create(label="thumbnail project", description="")
        role = make_or_create_global_readonly_role_for_project(self.project)
        ProjectAccess.objects.create(project=self.project, user=self.user, role=role)
        extension = FileExtension.objects.create(label="jpg")
        file_type = FileType.objects.create(
            title="JPEG",
            mime="image/jpeg",
            serve_with_iiif=True,
        )
        file_type.extensions.add(extension)
        self.file_hash = "a" * 64
        self.file = File.objects.create(
            title="thumbnail image",
            original_name="thumbnail.jpg",
            project=self.project,
            hash=self.file_hash,
            file_type=file_type,
            size=123,
            denormalized_image_width=1,
            denormalized_image_height=1,
        )

    def _request(self, user):
        request = self.factory.get(
            "/resources/simple_thumb/{}/100".format(self.file_hash)
        )
        request.user = user
        return request

    def test_simple_thumb_requires_read_access(self):
        response = views.simple_thumb(
            self._request(self.no_access_user), self.file_hash, 100
        )
        self.assertEqual(response.status_code, 403)

    def test_authorized_file_checks_all_files_with_same_hash(self):
        other_project = Project.objects.create(
            label="other thumbnail project", description=""
        )
        other_role = Role.objects.create(label="reader", project=other_project)
        ObjectPermission.objects.create(
            role=other_role,
            object_class="resource",
            object_pk=None,
            object_create=False,
            object_read=True,
            object_update=False,
            object_delete=False,
        )
        ProjectAccess.objects.create(
            project=other_project,
            user=self.no_access_user,
            role=other_role,
        )
        other_file = File.objects.create(
            title="same hash readable elsewhere",
            original_name="same-hash.jpg",
            project=other_project,
            hash=self.file_hash,
            file_type=self.file.file_type,
            size=123,
            denormalized_image_width=1,
            denormalized_image_height=1,
        )

        authorized_file = views._get_authorized_file(
            self._request(self.no_access_user), self.file_hash
        )
        self.assertEqual(authorized_file.pk, other_file.pk)

    def test_thumb_requires_read_access(self):
        response = views.thumb(
            self._request(self.no_access_user),
            self.file_hash,
            "0",
            "1",
            "0,0,0,0",
        )
        self.assertEqual(response.status_code, 403)

    def test_simple_thumb_rejects_size_bounds(self):
        response = views.simple_thumb(self._request(self.user), self.file_hash, 0)
        self.assertEqual(response.status_code, 400)

        response = views.simple_thumb(
            self._request(self.user),
            self.file_hash,
            views.settings.JAMA_THUMBNAIL_MAX_SIZE + 1,
        )
        self.assertEqual(response.status_code, 400)

    def test_thumb_rejects_invalid_crop_and_scale(self):
        response = views.thumb(
            self._request(self.user),
            self.file_hash,
            "0",
            "1",
            "-1,0,0,0",
        )
        self.assertEqual(response.status_code, 400)

        response = views.thumb(
            self._request(self.user),
            self.file_hash,
            "0",
            "1",
            "{},0,0,0".format(views.settings.JAMA_THUMBNAIL_MAX_CROP_PIXELS + 1),
        )
        self.assertEqual(response.status_code, 400)

        response = views.thumb(
            self._request(self.user),
            self.file_hash,
            "0",
            "0",
            "0,0,0,0",
        )
        self.assertEqual(response.status_code, 400)
