import hashlib
import hmac

from django.conf import settings
from django.db import migrations, models


def hash_key(key):
    secret = getattr(settings, "JAMA_API_KEY_HASH_SECRET", settings.SECRET_KEY)
    return hmac.new(secret.encode(), key.encode(), hashlib.sha256).hexdigest()


def populate_key_hash(apps, schema_editor):
    APIKey = apps.get_model("resources", "APIKey")
    for api_key in APIKey.objects.all():
        api_key.key_hash = hash_key(api_key.key)
        api_key.save(update_fields=["key_hash"])


def restore_key_from_hash(apps, schema_editor):
    APIKey = apps.get_model("resources", "APIKey")
    for api_key in APIKey.objects.all():
        api_key.key = api_key.key_hash
        api_key.save(update_fields=["key"])


class Migration(migrations.Migration):
    dependencies = [
        ("resources", "0051_file_hash_index"),
    ]

    operations = [
        migrations.AddField(
            model_name="apikey",
            name="key_hash",
            field=models.CharField(
                blank=True,
                max_length=64,
                null=True,
                unique=True,
                verbose_name="empreinte de la clef",
            ),
        ),
        migrations.RunPython(populate_key_hash, restore_key_from_hash),
        migrations.AlterUniqueTogether(
            name="apikey",
            unique_together={("key_hash", "user")},
        ),
        migrations.RemoveField(
            model_name="apikey",
            name="key",
        ),
        migrations.AlterField(
            model_name="apikey",
            name="key_hash",
            field=models.CharField(
                max_length=64,
                unique=True,
                verbose_name="empreinte de la clef",
            ),
        ),
    ]
