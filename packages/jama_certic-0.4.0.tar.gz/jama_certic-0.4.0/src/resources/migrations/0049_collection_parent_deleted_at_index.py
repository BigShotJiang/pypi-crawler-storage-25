from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("resources", "0048_objectpermission"),
    ]

    operations = [
        migrations.AddIndex(
            model_name="collection",
            index=models.Index(
                fields=["parent", "deleted_at"],
                name="res_col_parent_deleted_idx",
            ),
        ),
    ]
