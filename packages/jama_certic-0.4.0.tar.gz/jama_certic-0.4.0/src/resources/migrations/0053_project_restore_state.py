from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("resources", "0052_apikey_hash"),
    ]

    operations = [
        migrations.AddField(
            model_name="project",
            name="restore_state",
            field=models.CharField(
                choices=[
                    ("ready", "Ready"),
                    ("restoring", "Restoring"),
                    ("restore_failed", "Restore failed"),
                ],
                db_index=True,
                default="ready",
                max_length=32,
            ),
        ),
    ]
