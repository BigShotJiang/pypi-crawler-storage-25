import json
import shutil
from contextlib import contextmanager
from pathlib import Path
from typing import Iterable

from django.contrib.auth.models import User
from django.db import transaction
from django.db.models.signals import post_save
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from resources import tasks
from resources.models import (
    Collection,
    CollectionMembership,
    File,
    FileType,
    Metadata,
    MetadataCollectionValue,
    MetadataResourceValue,
    MetadataSet,
    ObjectPermission,
    Project,
    ProjectAccess,
    ProjectProperty,
    Resource,
    Role,
    Tag,
    collection_post_save,
    file_post_save,
    hash_to_local_path,
    resource_post_save,
)

SNAPSHOT_FORMAT = "jama.project_snapshot.v1"
SECTION_NAMES = [
    "project",
    "project_properties",
    "metadata_sets",
    "metadata",
    "tags",
    "collections",
    "resources",
    "files",
    "resource_tags",
    "collection_tags",
    "collection_memberships",
    "metadata_collection_values",
    "metadata_resource_values",
    "roles",
    "object_permissions",
    "project_accesses",
]


class SnapshotError(RuntimeError):
    pass


def _sid(model_name: str, pk: int) -> str:
    """Build a stable snapshot-local reference from a model name and old PK."""
    return f"{model_name}:{pk}"


def _parse_sid(value: str) -> int:
    """Return the old database PK portion of a snapshot-local reference."""
    return int(value.rsplit(":", 1)[1])


def _iso(value):
    """Serialize nullable datetimes without inventing sentinel values."""
    return value.isoformat() if value else None


def _dt(value):
    """Parse a snapshot datetime and normalize naive values to Django timezone."""
    if not value:
        return None
    parsed = parse_datetime(value)
    if parsed and timezone.is_naive(parsed):
        return timezone.make_aware(parsed)
    return parsed


def _write_jsonl(path: Path, rows: Iterable[dict]) -> int:
    """Write one JSON object per line and return the streamed row count."""
    count = 0
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
            handle.write("\n")
            count += 1
    return count


def _read_jsonl(path: Path) -> Iterable[dict]:
    """Yield JSON lines lazily so large snapshot sections stay streamable."""
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                yield json.loads(line)


def _bulk_create_stream(model, rows: Iterable, *, batch_size: int, **kwargs):
    """Bulk-create an iterable without materializing the whole section."""
    batch = []
    for row in rows:
        batch.append(row)
        if len(batch) >= batch_size:
            model.objects.bulk_create(batch, batch_size=batch_size, **kwargs)
            batch = []
    if batch:
        model.objects.bulk_create(batch, batch_size=batch_size, **kwargs)


def _file_blob_path(snapshot_dir: Path, file_hash: str) -> Path:
    """Return the content-addressed path for an optional file blob."""
    return snapshot_dir.joinpath("blobs", file_hash[:2], file_hash[2:4], file_hash)


def _project_collections_ordered(project: Project) -> list[Collection]:
    """Return collections parent-first so restore can recreate hierarchy in one pass."""
    collections = list(Collection.objects.filter(project=project).order_by("id"))
    by_parent = {}
    for collection in collections:
        by_parent.setdefault(collection.parent_id, []).append(collection)
    for children in by_parent.values():
        children.sort(key=lambda item: item.pk)

    ordered = []
    seen = set()

    def visit(collection):
        if collection.pk in seen:
            return
        seen.add(collection.pk)
        ordered.append(collection)
        for child in by_parent.get(collection.pk, []):
            visit(child)

    for root in by_parent.get(None, []):
        visit(root)
    for collection in collections:
        visit(collection)
    return ordered


def export_project_snapshot(
    project_id: int,
    output_dir: str | Path,
    *,
    include_files: bool = False,
    overwrite: bool = False,
    chunk_size: int = 2000,
) -> dict:
    project: Project = Project.objects.filter(pk=project_id).first()
    if not project:
        raise SnapshotError(f"Project {project_id} does not exist")

    output_dir = Path(output_dir)
    if output_dir.exists() and any(output_dir.iterdir()) and not overwrite:
        raise SnapshotError(f"Snapshot directory {output_dir} is not empty")
    output_dir.mkdir(parents=True, exist_ok=True)

    file_ids = set(File.objects.filter(project=project).values_list("pk", flat=True))
    counts = {}

    def project_rows():
        yield {
            "sid": _sid("project", project.pk),
            "old_pk": project.pk,
            "label": project.label,
            "description": project.description,
            "admin_mail": project.admin_mail,
            "ark_redirect": project.ark_redirect,
            "use_exiftool": project.use_exiftool,
            "resources_pipelines": project.resources_pipelines,
            "collections_pipelines": project.collections_pipelines,
        }

    def project_property_rows():
        for item in ProjectProperty.objects.filter(project=project).iterator(
            chunk_size=chunk_size
        ):
            yield {"key": item.key, "value": item.value}

    def metadata_set_rows():
        for item in (
            MetadataSet.objects.filter(project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "sid": _sid("metadata_set", item.pk),
                "old_pk": item.pk,
                "title": item.title,
                "created_at": _iso(item.created_at),
                "updated_at": _iso(item.updated_at),
            }

    def metadata_rows():
        for item in (
            Metadata.objects.filter(project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "sid": _sid("metadata", item.pk),
                "old_pk": item.pk,
                "title": item.title,
                "set": _sid("metadata_set", item.set_id),
                "rank": item.rank,
                "expose": item.expose,
            }

    def tag_rows():
        for item in (
            Tag.objects.filter(project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "sid": _sid("tag", item.pk),
                "old_pk": item.pk,
                "uid": item.uid,
                "ark": item.ark,
                "label": item.label,
            }

    def collection_rows():
        for item in _project_collections_ordered(project):
            yield {
                "sid": _sid("collection", item.pk),
                "old_pk": item.pk,
                "title": item.title,
                "parent": _sid("collection", item.parent_id)
                if item.parent_id
                else None,
                "created_at": _iso(item.created_at),
                "updated_at": _iso(item.updated_at),
                "deleted_at": _iso(item.deleted_at),
                "public_access": item.public_access,
                "published_at": _iso(item.published_at),
                "representative": _sid("resource", item.representative_id)
                if item.representative_id
                else None,
                "ark": item.ark,
            }

    def resource_rows():
        for item in (
            Resource.objects.filter(ptr_project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "sid": _sid("resource", item.pk),
                "old_pk": item.pk,
                "kind": "file" if item.pk in file_ids else "resource",
                "title": item.title,
                "created_at": _iso(item.created_at),
                "updated_at": _iso(item.updated_at),
                "deleted_at": _iso(item.deleted_at),
                "ark": item.ark,
            }

    def file_rows():
        for item in (
            File.objects.filter(project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "sid": _sid("resource", item.pk),
                "old_pk": item.pk,
                "title": item.title,
                "created_at": _iso(item.created_at),
                "updated_at": _iso(item.updated_at),
                "deleted_at": _iso(item.deleted_at),
                "ark": item.ark,
                "original_name": item.original_name,
                "hash": item.hash,
                "file_type_mime": item.file_type.mime,
                "size": item.size,
                "denormalized_image_width": item.denormalized_image_width,
                "denormalized_image_height": item.denormalized_image_height,
                "text_boxes": item.text_boxes,
                "tiled": item.tiled,
                "integrity_check_failed_at": _iso(item.integrity_check_failed_at),
            }

    def resource_tag_rows():
        through = Resource.tags.through
        for item in (
            through.objects.filter(resource__ptr_project=project)
            .order_by("resource_id", "tag_id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "resource": _sid("resource", item.resource_id),
                "tag": _sid("tag", item.tag_id),
            }

    def collection_tag_rows():
        through = Collection.tags.through
        for item in (
            through.objects.filter(collection__project=project)
            .order_by("collection_id", "tag_id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "collection": _sid("collection", item.collection_id),
                "tag": _sid("tag", item.tag_id),
            }

    def collection_membership_rows():
        for item in (
            CollectionMembership.objects.filter(collection__project=project)
            .order_by("collection_id", "rank", "resource_id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "collection": _sid("collection", item.collection_id),
                "resource": _sid("resource", item.resource_id),
                "rank": item.rank,
            }

    def metadata_collection_value_rows():
        for item in (
            MetadataCollectionValue.objects.filter(collection__project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "metadata": _sid("metadata", item.metadata_id),
                "collection": _sid("collection", item.collection_id),
                "value": item.value,
            }

    def metadata_resource_value_rows():
        for item in (
            MetadataResourceValue.objects.filter(resource__ptr_project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "metadata": _sid("metadata", item.metadata_id),
                "resource": _sid("resource", item.resource_id),
                "value": item.value,
            }

    def role_rows():
        for item in (
            Role.objects.filter(project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {"sid": _sid("role", item.pk), "old_pk": item.pk, "label": item.label}

    def object_permission_rows():
        for item in (
            ObjectPermission.objects.filter(role__project=project)
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {
                "role": _sid("role", item.role_id),
                "object_class": item.object_class,
                "object_pk": item.object_pk,
                "object_create": item.object_create,
                "object_read": item.object_read,
                "object_update": item.object_update,
                "object_delete": item.object_delete,
            }

    def project_access_rows():
        for item in (
            ProjectAccess.objects.filter(project=project)
            .select_related("user")
            .order_by("id")
            .iterator(chunk_size=chunk_size)
        ):
            yield {"username": item.user.username, "role": _sid("role", item.role_id)}

    writers = {
        "project": project_rows,
        "project_properties": project_property_rows,
        "metadata_sets": metadata_set_rows,
        "metadata": metadata_rows,
        "tags": tag_rows,
        "collections": collection_rows,
        "resources": resource_rows,
        "files": file_rows,
        "resource_tags": resource_tag_rows,
        "collection_tags": collection_tag_rows,
        "collection_memberships": collection_membership_rows,
        "metadata_collection_values": metadata_collection_value_rows,
        "metadata_resource_values": metadata_resource_value_rows,
        "roles": role_rows,
        "object_permissions": object_permission_rows,
        "project_accesses": project_access_rows,
    }
    for section, rows in writers.items():
        counts[section] = _write_jsonl(output_dir.joinpath(f"{section}.ndjson"), rows())

    copied_files = 0
    if include_files:
        for file_instance in File.objects.filter(project=project).iterator(
            chunk_size=chunk_size
        ):
            source = Path(file_instance.local_path())
            if not source.exists():
                raise SnapshotError(
                    f"Missing source file for hash {file_instance.hash}"
                )
            if file_instance.hash_is_ok() is False:
                raise SnapshotError(f"Source file hash verification failed: {source}")
            destination = _file_blob_path(output_dir, file_instance.hash)
            destination.parent.mkdir(parents=True, exist_ok=True)
            if not destination.exists():
                shutil.copyfile(source, destination)
                copied_files += 1

    manifest = {
        "format": SNAPSHOT_FORMAT,
        "created_at": timezone.now().isoformat(),
        "source_project": {"id": project.pk, "label": project.label},
        "include_files": include_files,
        "copied_files": copied_files,
        "counts": counts,
        "excluded_apps": {
            "annotations": "Annotation model is not stable yet",
        },
    }
    output_dir.joinpath("manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return manifest


@contextmanager
def _restore_without_model_side_effects():
    """Disable save signals that would enqueue ARK/media pipeline work mid-restore."""
    post_save.disconnect(resource_post_save, sender=Resource)
    post_save.disconnect(file_post_save, sender=File)
    post_save.disconnect(collection_post_save, sender=Collection)
    try:
        yield
    finally:
        post_save.connect(resource_post_save, sender=Resource)
        post_save.connect(file_post_save, sender=File)
        post_save.connect(collection_post_save, sender=Collection)


def _update_timestamps(instance, model, row):
    """Restore auto-managed timestamp fields after object creation."""
    updates = {}
    for field in ("created_at", "updated_at", "deleted_at", "published_at"):
        if field in row:
            updates[field] = _dt(row[field])
    if "integrity_check_failed_at" in row:
        updates["integrity_check_failed_at"] = _dt(row["integrity_check_failed_at"])
    if updates:
        model.objects.filter(pk=instance.pk).update(**updates)


def _digest(metadata_id: int, object_id: int, value: str) -> str:
    """Recompute metadata value uniqueness digests with restored object IDs."""
    import hashlib

    return hashlib.sha1(f"{metadata_id}-{object_id}-{value}".encode()).hexdigest()


def _load_required_manifest(snapshot_dir: Path) -> dict:
    """Validate the manifest and ensure every required NDJSON section exists."""
    manifest_path = snapshot_dir.joinpath("manifest.json")
    if not manifest_path.exists():
        raise SnapshotError("Missing manifest.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("format") != SNAPSHOT_FORMAT:
        raise SnapshotError(f"Unsupported snapshot format: {manifest.get('format')}")
    for section in SECTION_NAMES:
        if not (snapshot_dir.joinpath(f"{section}.ndjson")).exists():
            raise SnapshotError(f"Missing section {section}.ndjson")
    return manifest


def default_safety_snapshot_dir(snapshot_dir: str | Path, project_id: int) -> Path:
    timestamp = timezone.now().strftime("%Y%m%dT%H%M%SZ")
    return Path(f"{Path(snapshot_dir)}.pre-replace-{project_id}-{timestamp}")


def _clear_project_for_restore(project: Project):
    """Delete project-owned rows while preserving the Project row and its ID."""
    resource_ids = list(
        Resource.objects.filter(ptr_project=project).values_list("pk", flat=True)
    )
    collection_ids = list(
        Collection.objects.filter(project=project).values_list("pk", flat=True)
    )
    role_ids = list(Role.objects.filter(project=project).values_list("pk", flat=True))

    ProjectAccess.objects.filter(project=project).delete()
    ProjectProperty.objects.filter(project=project).delete()
    ObjectPermission.objects.filter(role_id__in=role_ids).delete()
    Role.objects.filter(pk__in=role_ids).delete()
    if resource_ids:
        MetadataResourceValue.objects.filter(resource_id__in=resource_ids).delete()
        Resource.tags.through.objects.filter(resource_id__in=resource_ids).delete()
        CollectionMembership.objects.filter(resource_id__in=resource_ids).delete()
    if collection_ids:
        MetadataCollectionValue.objects.filter(
            collection_id__in=collection_ids
        ).delete()
        Collection.tags.through.objects.filter(
            collection_id__in=collection_ids
        ).delete()
        CollectionMembership.objects.filter(collection_id__in=collection_ids).delete()
    File.objects.filter(project=project).delete()
    Resource.objects.filter(ptr_project=project).delete()
    Collection.objects.filter(project=project).delete()
    Metadata.objects.filter(project=project).delete()
    MetadataSet.objects.filter(project=project).delete()
    Tag.objects.filter(project=project).delete()


def restore_project_snapshot(
    snapshot_dir: str | Path,
    project_label: str,
    *,
    batch_size: int = 2000,
    replace_in_place: bool = False,
    safety_snapshot_dir: str | Path = None,
    safety_include_files: bool = False,
) -> Project:
    snapshot_dir = Path(snapshot_dir)
    _load_required_manifest(snapshot_dir)
    target_project = Project.objects.filter(label=project_label).first()
    if replace_in_place:
        if not target_project:
            raise SnapshotError(f"Project label does not exist: {project_label}")
    elif target_project:
        raise SnapshotError(f"Project label already exists: {project_label}")

    file_type_by_mime = {item.mime: item for item in FileType.objects.all()}
    required_mimes = {
        row["file_type_mime"]
        for row in _read_jsonl(snapshot_dir.joinpath("files.ndjson"))
    }
    missing_mimes = sorted(required_mimes - set(file_type_by_mime.keys()))
    if missing_mimes:
        raise SnapshotError(f"Missing file types: {', '.join(missing_mimes)}")

    resource_arks = [
        row["ark"]
        for row in _read_jsonl(snapshot_dir.joinpath("resources.ndjson"))
        if row.get("ark")
    ]
    resource_arks.extend(
        row["ark"]
        for row in _read_jsonl(snapshot_dir.joinpath("files.ndjson"))
        if row.get("ark")
    )
    collection_arks = [
        row["ark"]
        for row in _read_jsonl(snapshot_dir.joinpath("collections.ndjson"))
        if row.get("ark")
    ]
    resource_conflicts = Resource.objects.filter(ark__in=resource_arks)
    collection_conflicts = Collection.objects.filter(ark__in=collection_arks)
    if replace_in_place:
        resource_conflicts = resource_conflicts.exclude(ptr_project=target_project)
        collection_conflicts = collection_conflicts.exclude(project=target_project)
    if resource_arks and resource_conflicts.exists():
        raise SnapshotError("Resource ARK conflict")
    if collection_arks and collection_conflicts.exists():
        raise SnapshotError("Collection ARK conflict")

    safety_path = None
    if replace_in_place:
        safety_path = (
            Path(safety_snapshot_dir)
            if safety_snapshot_dir
            else default_safety_snapshot_dir(snapshot_dir, target_project.pk)
        )
        export_project_snapshot(
            target_project.pk,
            safety_path,
            include_files=safety_include_files,
            overwrite=False,
        )

    metadata_sets = {}
    metadata = {}
    tags = {}
    collections = {}
    resources = {}
    roles = {}
    restored_file_ids = []

    project_row = next(_read_jsonl(snapshot_dir.joinpath("project.ndjson")), None)
    if not project_row:
        raise SnapshotError("Missing project row")

    with _restore_without_model_side_effects():
        try:
            with transaction.atomic():
                if replace_in_place:
                    project = target_project
                    Project.objects.filter(pk=project.pk).update(
                        description=project_row.get("description") or "",
                        admin_mail=project_row.get("admin_mail"),
                        ark_redirect=project_row.get("ark_redirect"),
                        use_exiftool=project_row.get("use_exiftool") or False,
                        resources_pipelines=project_row.get("resources_pipelines"),
                        collections_pipelines=project_row.get("collections_pipelines"),
                        restore_state=Project.RESTORE_STATE_RESTORING,
                    )
                    _clear_project_for_restore(project)
                    project.refresh_from_db()
                else:
                    project = Project.objects.create(
                        label=project_label,
                        description=project_row.get("description") or "",
                        admin_mail=project_row.get("admin_mail"),
                        ark_redirect=project_row.get("ark_redirect"),
                        use_exiftool=project_row.get("use_exiftool") or False,
                        resources_pipelines=project_row.get("resources_pipelines"),
                        collections_pipelines=project_row.get("collections_pipelines"),
                        restore_state=Project.RESTORE_STATE_RESTORING,
                    )
        except Exception:
            raise

        try:
            with transaction.atomic():
                for row in _read_jsonl(snapshot_dir.joinpath("metadata_sets.ndjson")):
                    item = MetadataSet.objects.create(
                        title=row["title"], project=project
                    )
                    _update_timestamps(item, MetadataSet, row)
                    metadata_sets[row["sid"]] = item.pk

                for row in _read_jsonl(snapshot_dir.joinpath("metadata.ndjson")):
                    item = Metadata.objects.create(
                        title=row["title"],
                        set_id=metadata_sets[row["set"]],
                        rank=row.get("rank") or 0,
                        project=project,
                        expose=row.get("expose", True),
                    )
                    metadata[row["sid"]] = item.pk

                for row in _read_jsonl(snapshot_dir.joinpath("tags.ndjson")):
                    item = Tag.objects.create(
                        uid=row["uid"],
                        ark=row.get("ark"),
                        label=row.get("label"),
                        project=project,
                    )
                    tags[row["sid"]] = item.pk

                pending_representatives = []
                for row in _read_jsonl(snapshot_dir.joinpath("collections.ndjson")):
                    item = Collection.objects.create(
                        title=row["title"],
                        project=project,
                        parent_id=collections.get(row.get("parent")),
                        public_access=row.get("public_access") or False,
                        ark=row.get("ark"),
                    )
                    _update_timestamps(item, Collection, row)
                    collections[row["sid"]] = item.pk
                    if row.get("representative"):
                        pending_representatives.append((item.pk, row["representative"]))

                file_sids = {
                    row["sid"]
                    for row in _read_jsonl(snapshot_dir.joinpath("files.ndjson"))
                }
                for row in _read_jsonl(snapshot_dir.joinpath("resources.ndjson")):
                    if row.get("kind") == "file" or row["sid"] in file_sids:
                        continue
                    item = Resource.objects.create(
                        title=row["title"], ptr_project=project, ark=row.get("ark")
                    )
                    _update_timestamps(item, Resource, row)
                    resources[row["sid"]] = item.pk

                for row in _read_jsonl(snapshot_dir.joinpath("files.ndjson")):
                    item = File.objects.create(
                        title=row["title"],
                        original_name=row["original_name"],
                        project=project,
                        hash=row["hash"],
                        file_type=file_type_by_mime[row["file_type_mime"]],
                        size=row["size"],
                        denormalized_image_width=row.get("denormalized_image_width"),
                        denormalized_image_height=row.get("denormalized_image_height"),
                        text_boxes=row.get("text_boxes"),
                        tiled=row.get("tiled") or False,
                        ark=row.get("ark"),
                    )
                    _update_timestamps(item, File, row)
                    resources[row["sid"]] = item.pk
                    restored_file_ids.append(item.pk)

                for collection_id, representative_sid in pending_representatives:
                    Collection.objects.filter(pk=collection_id).update(
                        representative_id=resources[representative_sid]
                    )

                _bulk_create_stream(
                    Resource.tags.through,
                    (
                        Resource.tags.through(
                            resource_id=resources[row["resource"]],
                            tag_id=tags[row["tag"]],
                        )
                        for row in _read_jsonl(
                            snapshot_dir.joinpath("resource_tags.ndjson")
                        )
                    ),
                    batch_size=batch_size,
                    ignore_conflicts=True,
                )

                _bulk_create_stream(
                    Collection.tags.through,
                    (
                        Collection.tags.through(
                            collection_id=collections[row["collection"]],
                            tag_id=tags[row["tag"]],
                        )
                        for row in _read_jsonl(
                            snapshot_dir.joinpath("collection_tags.ndjson")
                        )
                    ),
                    batch_size=batch_size,
                    ignore_conflicts=True,
                )

                _bulk_create_stream(
                    CollectionMembership,
                    (
                        CollectionMembership(
                            collection_id=collections[row["collection"]],
                            resource_id=resources[row["resource"]],
                            rank=row.get("rank") or 0,
                        )
                        for row in _read_jsonl(
                            snapshot_dir.joinpath("collection_memberships.ndjson")
                        )
                    ),
                    batch_size=batch_size,
                    ignore_conflicts=True,
                )

                def metadata_collection_values():
                    for row in _read_jsonl(
                        snapshot_dir.joinpath("metadata_collection_values.ndjson")
                    ):
                        value = str(row.get("value") or "").strip()
                        yield MetadataCollectionValue(
                            metadata_id=metadata[row["metadata"]],
                            collection_id=collections[row["collection"]],
                            value=value,
                            sha1digest=_digest(
                                metadata[row["metadata"]],
                                collections[row["collection"]],
                                value,
                            ),
                        )

                _bulk_create_stream(
                    MetadataCollectionValue,
                    metadata_collection_values(),
                    batch_size=batch_size,
                    ignore_conflicts=True,
                )

                def metadata_resource_values():
                    for row in _read_jsonl(
                        snapshot_dir.joinpath("metadata_resource_values.ndjson")
                    ):
                        value = str(row.get("value") or "").strip()
                        yield MetadataResourceValue(
                            metadata_id=metadata[row["metadata"]],
                            resource_id=resources[row["resource"]],
                            value=value,
                            sha1digest=_digest(
                                metadata[row["metadata"]],
                                resources[row["resource"]],
                                value,
                            ),
                        )

                _bulk_create_stream(
                    MetadataResourceValue,
                    metadata_resource_values(),
                    batch_size=batch_size,
                    ignore_conflicts=True,
                )

                for row in _read_jsonl(snapshot_dir.joinpath("roles.ndjson")):
                    item = Role.objects.create(label=row["label"], project=project)
                    roles[row["sid"]] = item.pk

                object_class_maps = {
                    "collection": ("collection", collections),
                    "resource": ("resource", resources),
                    "file": ("resource", resources),
                    "metadata": ("metadata", metadata),
                    "metadataset": ("metadata_set", metadata_sets),
                    "tag": ("tag", tags),
                }

                def object_permission_values():
                    for row in _read_jsonl(
                        snapshot_dir.joinpath("object_permissions.ndjson")
                    ):
                        object_pk = row.get("object_pk")
                        if (
                            object_pk is not None
                            and row["object_class"] in object_class_maps
                        ):
                            sid_name, sid_map = object_class_maps[row["object_class"]]
                            object_pk = sid_map.get(_sid(sid_name, object_pk))
                        yield ObjectPermission(
                            role_id=roles[row["role"]],
                            object_class=row["object_class"],
                            object_pk=object_pk,
                            object_create=row.get("object_create") or False,
                            object_read=row.get("object_read") or False,
                            object_update=row.get("object_update") or False,
                            object_delete=row.get("object_delete") or False,
                        )

                _bulk_create_stream(
                    ObjectPermission,
                    object_permission_values(),
                    batch_size=batch_size,
                )

                for row in _read_jsonl(
                    snapshot_dir.joinpath("project_properties.ndjson")
                ):
                    ProjectProperty.objects.create(
                        project=project, key=row["key"], value=row.get("value")
                    )

                def project_access_values():
                    for row in _read_jsonl(
                        snapshot_dir.joinpath("project_accesses.ndjson")
                    ):
                        user, created = User.objects.get_or_create(
                            username=row["username"]
                        )
                        if created:
                            user.is_active = False
                            user.save(update_fields=["is_active"])
                        yield ProjectAccess(
                            project=project, user=user, role_id=roles[row["role"]]
                        )

                _bulk_create_stream(
                    ProjectAccess,
                    project_access_values(),
                    batch_size=batch_size,
                    ignore_conflicts=True,
                )

        except Exception:
            Project.objects.filter(pk=project.pk).update(
                restore_state=Project.RESTORE_STATE_FAILED
            )
            raise

    try:
        for row in _read_jsonl(snapshot_dir.joinpath("files.ndjson")):
            blob = _file_blob_path(snapshot_dir, row["hash"])
            destination = Path(hash_to_local_path(row["hash"]))
            if blob.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                if not destination.exists():
                    shutil.copyfile(blob, destination)
        Project.objects.filter(pk=project.pk).update(
            restore_state=Project.RESTORE_STATE_READY
        )
    except Exception:
        Project.objects.filter(pk=project.pk).update(
            restore_state=Project.RESTORE_STATE_FAILED
        )
        raise

    for file_id in restored_file_ids:
        file_instance = File.objects.filter(pk=file_id).first()
        if not file_instance or not Path(file_instance.local_path()).exists():
            continue
        tasks.iiif_task.enqueue(file_id)
        tasks.ocr_task.enqueue(file_id)
        tasks.hls_task.enqueue(file_id)
        if file_instance.project.use_exiftool:
            tasks.exif_task.enqueue(file_id)

    project = Project.objects.get(pk=project.pk)
    project.safety_snapshot_dir = str(safety_path) if safety_path else None
    return project
