from django.core.management.base import BaseCommand

from resources.models import Project


class Command(BaseCommand):
    help = "List projects with their IDs."

    def add_arguments(self, parser):
        parser.add_argument(
            "--all",
            action="store_true",
            help="Include projects that are restoring or failed to restore.",
        )

    def handle(self, *args, **options):
        projects = Project.objects.order_by("label", "id")
        if not options["all"]:
            projects = projects.filter(restore_state=Project.RESTORE_STATE_READY)

        self.stdout.write("id	label	restore_state")
        for project in projects:
            self.stdout.write(
                f"{project.pk}	{project.label}	{project.restore_state}"
            )
