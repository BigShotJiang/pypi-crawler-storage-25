from django.core.management.base import BaseCommand, CommandError

from resources.snapshots import SnapshotError, restore_project_snapshot


class Command(BaseCommand):
    help = "Restore a project snapshot into a new or existing project."

    def add_arguments(self, parser):
        parser.add_argument("snapshot_dir", type=str)
        parser.add_argument("project_label", type=str)
        parser.add_argument("--batch-size", type=int, default=2000)
        parser.add_argument(
            "--replace-in-place",
            action="store_true",
            help="Replace an existing project while preserving its ID.",
        )
        parser.add_argument(
            "--safety-snapshot-dir",
            type=str,
            help="Directory for the pre-replace safety snapshot.",
        )
        parser.add_argument(
            "--safety-include-files",
            action="store_true",
            help="Include source file blobs in the pre-replace safety snapshot.",
        )

    def handle(self, *args, **options):
        try:
            project = restore_project_snapshot(
                options["snapshot_dir"],
                options["project_label"],
                batch_size=options["batch_size"],
                replace_in_place=options["replace_in_place"],
                safety_snapshot_dir=options.get("safety_snapshot_dir"),
                safety_include_files=options["safety_include_files"],
            )
        except SnapshotError as error:
            raise CommandError(str(error)) from error
        self.stdout.write(
            self.style.SUCCESS(
                f'Restored project "{project.label}" ({project.pk}) from snapshot'
            )
        )
        if getattr(project, "safety_snapshot_dir", None):
            self.stdout.write(
                f"Safety snapshot written to {project.safety_snapshot_dir}"
            )
