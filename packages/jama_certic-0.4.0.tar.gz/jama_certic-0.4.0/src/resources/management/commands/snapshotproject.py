from django.core.management.base import BaseCommand, CommandError

from resources.snapshots import SnapshotError, export_project_snapshot


class Command(BaseCommand):
    help = "Export a project snapshot to a streamable directory of NDJSON sections."

    def add_arguments(self, parser):
        parser.add_argument("project_id", type=int)
        parser.add_argument("output_dir", type=str)
        parser.add_argument("--include-files", action="store_true")
        parser.add_argument("--overwrite", action="store_true")
        parser.add_argument("--chunk-size", type=int, default=2000)

    def handle(self, *args, **options):
        try:
            manifest = export_project_snapshot(
                options["project_id"],
                options["output_dir"],
                include_files=options["include_files"],
                overwrite=options["overwrite"],
                chunk_size=options["chunk_size"],
            )
        except SnapshotError as error:
            raise CommandError(str(error)) from error
        self.stdout.write(
            self.style.SUCCESS(
                "Snapshot written: {} sections, {} copied file(s)".format(
                    len(manifest["counts"]), manifest["copied_files"]
                )
            )
        )
