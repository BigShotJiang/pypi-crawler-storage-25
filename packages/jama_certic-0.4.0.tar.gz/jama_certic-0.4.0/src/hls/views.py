from django.http import HttpResponseBase, HttpRequest, Http404
from django.core.exceptions import PermissionDenied
from django.conf import settings
from resources.acl import UserAccess
from resources.models import Resource
from rpc.fileresponse import RangedFileResponse
from pathlib import Path
from typing import Union
import re


def _file_hash_from_hls_path(path: str) -> Union[str, None]:
    match = re.search(r"(?i)(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])", path)
    if not match:
        return None
    return match.group(0).lower()


def _hls_file_path(path: str) -> Path:
    hls_dir = Path(settings.HLS_DIR).resolve()
    tested_path = Path(hls_dir, path).resolve()
    if not tested_path.is_relative_to(hls_dir):
        raise PermissionDenied()
    if not tested_path.exists():
        raise Http404()
    return tested_path


def _hls_response(request: HttpRequest, path: str, resource_instance: Resource):
    return RangedFileResponse(
        request,
        open(_hls_file_path(path), "rb"),
        content_type=resource_instance.file.file_type.mime,
    )


def file_passthru_noauth(request: HttpRequest, path: str) -> HttpResponseBase:
    file_hash = _file_hash_from_hls_path(path)
    if not file_hash:
        raise Http404()
    resource_instance = (
        Resource.objects.filter(file__hash=file_hash, deleted_at__isnull=True)
        .select_related("file__file_type")
        .first()
    )
    if not resource_instance:
        raise Http404()
    return _hls_response(request, path, resource_instance)


def file_passthru_auth(request: HttpRequest, path: str) -> HttpResponseBase:
    if request.user.is_anonymous:
        raise PermissionDenied()

    file_hash = _file_hash_from_hls_path(path)
    if not file_hash:
        raise Http404()

    resources = Resource.objects.filter(
        file__hash=file_hash,
        deleted_at__isnull=True,
    ).select_related("ptr_project", "file__file_type")
    if not resources.exists():
        raise Http404()

    for resource_instance in resources:
        if UserAccess(request.user, resource_instance.ptr_project).can_read(
            resource_instance
        ):
            return _hls_response(request, path, resource_instance)
    raise PermissionDenied()


def file_passthru(request: HttpRequest, path: str) -> HttpResponseBase:
    if settings.HLS_URLS_NEED_AUTH:
        return file_passthru_auth(request, path)
    else:
        return file_passthru_noauth(request, path)
