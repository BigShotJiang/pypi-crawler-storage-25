from django.urls import re_path

from . import views

app_name = "hls"
urlpatterns = [
    re_path(r"(?P<path>.*)", views.file_passthru),
]
