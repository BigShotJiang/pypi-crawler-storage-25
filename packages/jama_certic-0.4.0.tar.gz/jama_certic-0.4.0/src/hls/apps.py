from django.apps import AppConfig


class HlsConfig(AppConfig):
    name = "hls"
