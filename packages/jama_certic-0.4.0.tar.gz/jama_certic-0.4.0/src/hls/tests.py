from tempfile import TemporaryDirectory
from pathlib import Path

from django.contrib.auth.models import AnonymousUser, User
from django.core.exceptions import PermissionDenied
from django.http import Http404
from django.test import RequestFactory, TestCase, override_settings

from hls.views import file_passthru, _file_hash_from_hls_path, _hls_file_path
from resources.models import (
    Collection,
    File,
    FileExtension,
    FileType,
    ObjectPermission,
    Project,
    ProjectAccess,
    Role,
    hash_to_hls_path,
)


class HLSAccessTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username="hls_user")
        self.no_access_user = User.objects.create(username="hls_no_access_user")
        self.project = Project.objects.create(label="hls project", description="")
        Collection.objects.create(title="root", project=self.project, parent=None)
        self.role = Role.objects.create(label="reader", project=self.project)
        ObjectPermission.objects.create(
            role=self.role,
            object_class="resource",
            object_pk=None,
            object_create=False,
            object_read=True,
            object_update=False,
            object_delete=False,
        )
        ProjectAccess.objects.create(
            project=self.project,
            user=self.user,
            role=self.role,
        )
        extension = FileExtension.objects.create(label="mp4")
        file_type = FileType.objects.create(
            title="MP4",
            mime="video/mp4",
            serve_with_hls=True,
        )
        file_type.extensions.add(extension)
        self.file_hash = "b" * 64
        self.file = File.objects.create(
            title="video",
            original_name="video.mp4",
            project=self.project,
            hash=self.file_hash,
            file_type=file_type,
            size=123,
        )

    def _path(self):
        return "{}/master.m3u8".format(hash_to_hls_path(self.file_hash))

    def _request(self, user):
        request = self.factory.get("/hls/{}".format(self._path()))
        request.user = user
        return request

    def _write_hls_file(self, hls_dir):
        hls_file = hls_dir / self._path()
        hls_file.parent.mkdir(parents=True)
        hls_file.write_text("#EXTM3U\n", encoding="utf-8")

    def test_file_hash_from_hls_path(self):
        self.assertEqual(_file_hash_from_hls_path(self._path()), self.file_hash)

    @override_settings(HLS_URLS_NEED_AUTH=False)
    def test_hls_access_allows_public_mode(self):
        with TemporaryDirectory() as temp_dir:
            hls_dir = Path(temp_dir)
            self._write_hls_file(hls_dir)
            with override_settings(HLS_DIR=str(hls_dir)):
                response = file_passthru(self._request(AnonymousUser()), self._path())
        self.assertEqual(response.status_code, 200)

    @override_settings(HLS_URLS_NEED_AUTH=True)
    def test_hls_access_rejects_anonymous_user(self):
        with self.assertRaises(PermissionDenied):
            file_passthru(self._request(AnonymousUser()), self._path())

    @override_settings(HLS_URLS_NEED_AUTH=True)
    def test_hls_access_rejects_user_without_resource_read_access(self):
        with self.assertRaises(PermissionDenied):
            file_passthru(self._request(self.no_access_user), self._path())

    @override_settings(HLS_URLS_NEED_AUTH=True)
    def test_hls_access_allows_user_with_resource_read_access(self):
        with TemporaryDirectory() as temp_dir:
            hls_dir = Path(temp_dir)
            self._write_hls_file(hls_dir)
            with override_settings(HLS_DIR=str(hls_dir)):
                response = file_passthru(self._request(self.user), self._path())
        self.assertEqual(response.status_code, 200)

    @override_settings(HLS_URLS_NEED_AUTH=True)
    def test_hls_access_404s_when_path_has_no_hash(self):
        with self.assertRaises(Http404):
            file_passthru(self._request(self.user), "master.m3u8")

    def test_hls_path_rejects_traversal(self):
        with TemporaryDirectory() as temp_dir:
            hls_dir = Path(temp_dir) / "hls"
            hls_dir.mkdir()
            with override_settings(HLS_DIR=str(hls_dir)):
                with self.assertRaises(PermissionDenied):
                    _hls_file_path("../hls-other/master.m3u8")
