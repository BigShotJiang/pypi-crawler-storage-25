from django.test import RequestFactory, TestCase
from django.contrib.auth.models import AnonymousUser, User
from rpc import methods
from rpc import serializers
from rpc import views
from resources import models
from resources.management.commands.loadfixtures import load_fixtures
from rpc.methods import ServiceException
from resources.acl import UserAccess
from pathlib import Path
import os
import base64
import tempfile
from io import BytesIO
from django.urls import reverse
from openpyxl import load_workbook
from unittest.mock import patch
import json

object_classes = [
    "collection",
    "file",
    "metadata",
    "metadataset",
    "permission",
    "project",
    "project_property",
    "resource",
    "role",
    "tag",
]

crud = ["create", "read", "update", "delete"]


class ServiceTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        # load file types, create permissions
        load_fixtures()

        self.test_user = User.objects.create(username="basic_user")
        self.basic_user_key = "acme"

        # only django superusers have access to certain rpc methods.
        self.admin_user = User.objects.create(username="admin_user", is_superuser=True)
        methods.activate_rpc_access(
            self.admin_user, self.test_user.username, self.basic_user_key
        )

        self.test_project = models.Project.objects.create(
            label="projet test", description="projet test"
        )
        self.test_project_root_collection = models.Collection.objects.create(
            title="root", parent_id=None, project=self.test_project
        )
        self.test_metadataset = models.MetadataSet.objects.create(
            title="test metadata set", project=self.test_project
        )

        self.admin_role = models.Role.objects.create(
            label="admin", project=self.test_project
        )

        # give all permissions to admin role
        for object_class in object_classes:
            models.ObjectPermission.objects.get_or_create(
                object_class=object_class,
                object_pk=None,
                role=self.admin_role,
                object_create=True,
                object_read=True,
                object_update=True,
                object_delete=True,
            )

        # give admin role to the user on the project
        models.ProjectAccess.objects.get_or_create(
            project=self.test_project, user=self.test_user, role=self.admin_role
        )
        models.ProjectAccess.objects.get_or_create(
            project=self.test_project, user=self.admin_user, role=self.admin_role
        )
        # public user
        self.public_user = User.objects.create(username="public_user")
        self.public_role = models.Role.objects.create(
            label="public", project=self.test_project
        )

        for object_class in object_classes:
            models.ObjectPermission.objects.get_or_create(
                object_class=object_class,
                object_pk=None,
                role=self.public_role,
                object_create=True,
                object_read=True,
                object_update=True,
                object_delete=True,
            )

        models.ProjectAccess.objects.get_or_create(
            project=self.test_project, user=self.public_user, role=self.public_role
        )

    def test_ping(self):
        self.assertEqual(
            methods.ping(self.test_user), "pong {}".format(self.test_user.username)
        )

    def test_get_user_from_request_uses_hashed_api_key(self):
        request = self.factory.get("/rpc/", HTTP_X_API_KEY=self.basic_user_key)
        request.user = AnonymousUser()

        self.assertEqual(views._get_user_from_request(request), self.test_user)
        self.assertFalse(
            models.APIKey.objects.filter(key_hash=self.basic_user_key).exists()
        )

    def test_metadatasets(self):
        metadatasets = methods.metadatasets(self.test_user, self.test_project.pk)
        self.assertEqual(1, len(metadatasets))

    def test_public_download_urls_can_be_disabled(self):
        request = self.factory.get("/rpc/download_public/{}".format("a" * 64))
        with patch.object(views.settings, "JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS", False):
            response = views.force_download_public(request, "a" * 64)
            self.assertEqual(response.status_code, 404)
            response = views.serve_file_public(request, "a" * 64)
            self.assertEqual(response.status_code, 404)

    def test_public_download_urls_are_enabled_by_default(self):
        file_instance = self._public_download_test_file()
        request = self.factory.get("/rpc/download_public/{}".format(file_instance.hash))
        with tempfile.NamedTemporaryFile() as tmp:
            tmp.write(b"test")
            tmp.flush()
            with patch.object(views.settings, "JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS", True):
                with patch.object(models.File, "local_path", return_value=tmp.name):
                    response = views.force_download_public(request, file_instance.hash)
                    self.assertEqual(response.status_code, 200)
                    response = views.serve_file_public(request, file_instance.hash)
                    self.assertEqual(response.status_code, 200)

    def test_file_serializer_omits_public_urls_when_disabled(self):
        with patch.object(
            serializers.settings, "JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS", False
        ):
            payload = serializers.file(self._public_download_test_file())

        self.assertIn("download", payload["urls"])
        self.assertNotIn("download_public", payload["urls"])
        self.assertNotIn("serve", payload["urls"])

    def test_file_serializer_includes_public_urls_when_enabled(self):
        with patch.object(
            serializers.settings, "JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS", True
        ):
            payload = serializers.file(self._public_download_test_file())

        self.assertIn("download", payload["urls"])
        self.assertIn("download_public", payload["urls"])
        self.assertIn("serve", payload["urls"])

    def _public_download_test_file(self):
        file_hash = "a" * 64
        file_type = models.FileType.objects.filter(extensions__label="png").first()
        return models.File.objects.create(
            title="test public file",
            original_name="test_public_file.png",
            project=self.test_project,
            hash=file_hash,
            file_type=file_type,
            size=4,
            denormalized_image_width=1,
            denormalized_image_height=1,
        )

    def _upload_partial_request(
        self,
        file_hash: str,
        file_chunk: str,
        data: bytes = b"test",
        content_length: str = None,
    ):
        request = self.factory.post(
            "/rpc/upload/partial/",
            data=data,
            content_type="application/octet-stream",
            HTTP_X_PROJECT=str(self.test_project.pk),
            HTTP_X_FILE_HASH=file_hash,
            HTTP_X_FILE_NAME=base64.b64encode(b"test.png").decode("ascii"),
            HTTP_X_FILE_CHUNK=file_chunk,
            CONTENT_LENGTH=content_length or str(len(data)),
        )
        request.user = self.test_user
        return request

    def _rpc_request(self, data: bytes, content_length: str = None):
        request = self.factory.post(
            "/rpc/",
            data=data,
            content_type="application/json",
            CONTENT_LENGTH=content_length or str(len(data)),
        )
        request.user = self.test_user
        return request

    def test_rpc_accepts_body_within_limit(self):
        payload = b'{"method": "ping", "params": [], "id": 1}'
        with patch.object(views.settings, "JAMA_RPC_MAX_BODY_SIZE", len(payload)):
            response = views.rpc(self._rpc_request(payload))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            json.loads(response.content),
            {"result": "pong basic_user", "error": None, "id": 1},
        )

    def test_rpc_rejects_oversized_body(self):
        payload = b'{"method": "ping", "params": [], "id": 1}'
        with patch.object(views.settings, "JAMA_RPC_MAX_BODY_SIZE", len(payload) - 1):
            with patch.object(views.json, "loads") as loads:
                response = views.rpc(self._rpc_request(payload))

        self.assertEqual(response.status_code, 413)
        loads.assert_not_called()

    def test_rpc_rejects_malformed_content_length(self):
        response = views.rpc(
            self._rpc_request(b'{"method": "ping", "params": [], "id": 1}', "invalid")
        )

        self.assertEqual(response.status_code, 400)

    def test_upload_partial_rejects_invalid_chunk_header(self):
        response = views.upload_partial(self._upload_partial_request("b" * 64, "0/1"))
        self.assertEqual(response.status_code, 400)

        response = views.upload_partial(self._upload_partial_request("c" * 64, "2/1"))
        self.assertEqual(response.status_code, 400)

        response = views.upload_partial(self._upload_partial_request("d" * 64, "abc/1"))
        self.assertEqual(response.status_code, 400)

    def test_upload_partial_rejects_oversized_chunk(self):
        with patch.object(views.settings, "JAMA_UPLOAD_MAX_CHUNK_SIZE", 3):
            response = views.upload_partial(
                self._upload_partial_request("e" * 64, "1/1", b"test")
            )
        self.assertEqual(response.status_code, 413)

    def test_upload_partial_rejects_malformed_content_length(self):
        response = views.upload_partial(
            self._upload_partial_request("f" * 64, "1/1", content_length="invalid")
        )
        self.assertEqual(response.status_code, 400)

    def test_upload_partial_rejects_too_many_chunks(self):
        with patch.object(views.settings, "JAMA_UPLOAD_MAX_TOTAL_CHUNKS", 1):
            response = views.upload_partial(
                self._upload_partial_request("1" * 64, "1/2")
            )
        self.assertEqual(response.status_code, 413)

    def test_metadata_methods_require_read_access(self):
        metadata = models.Metadata.objects.create(
            title="private metadata",
            set=self.test_metadataset,
            project=self.test_project,
        )
        no_access_user = User.objects.create(username="no_access_user")

        with self.assertRaises(ServiceException):
            methods.metadatasets(no_access_user, self.test_project.pk)
        with self.assertRaises(ServiceException):
            methods.metadatas(no_access_user, self.test_metadataset.pk)
        with self.assertRaises(ServiceException):
            methods.metadata(no_access_user, metadata.pk)

    def test_permissions(self):
        for object_class in object_classes:
            for c in crud:
                self.assertTrue(
                    UserAccess(self.test_user, self.test_project).can_crud(
                        object_class, c
                    )
                )
        with self.assertRaises(ServiceException):
            UserAccess(self.test_user, self.test_project).check_read(
                "some_unknown_class"
            )

    def test_add_collection(self):
        methods.add_collection(
            self.test_user,
            "test_collection",
            parent_id=self.test_project_root_collection.pk,
        )
        collections = methods.collections(
            self.test_user, parent_id=self.test_project_root_collection.pk
        )
        self.assertEqual(len(collections), 1)

    def test_add_tag(self):
        methods.set_tag(self.test_user, "tag bidon", self.test_project.pk)
        tags = methods.tags(self.test_user, self.test_project.pk)
        self.assertEqual(len(tags), 1)

    def test_add_collection_from_path(self):
        ancestors_labels = ["toto", "tata"]
        collections = methods.add_collection_from_path(
            self.test_user, "/toto/tata/tutu", self.test_project.pk
        )
        idx = 0
        for ancestor in collections[-1]["ancestors"]:
            self.assertEqual(ancestor["title"], ancestors_labels[idx])
            idx = idx + 1
        self.assertEqual(models.Collection.objects.filter(title="root").count(), 1)

    def test_require_superuser(self):
        with self.assertRaises(ServiceException):
            methods.delete_role(self.test_user, 1)

    def test_resources_bad_order_by(self):
        collection = methods.add_collection(
            self.test_user,
            "test_collection",
            parent_id=self.test_project_root_collection.pk,
        )
        with self.assertRaises(ServiceException):
            methods.resources(self.test_user, collection["id"], order_by="pouet")

    def test_collections_bad_order_by(self):
        with self.assertRaises(ServiceException):
            methods.collections(
                self.test_user,
                parent_id=self.test_project_root_collection.pk,
                order_by="pouet",
            )

    def test_recycle_bin(self):
        col = methods.add_collection(
            self.test_user, "delete me", self.test_project.root_collection.pk
        )
        methods.delete_collection(self.test_user, col["id"])
        self.assertEqual(
            len(methods.recycle_bin(self.test_user, self.test_project.pk)), 1
        )

    def test_search(self):
        terms = [
            {"property": "title", "term": "contains", "value": "cherbourg"},
        ]
        methods.advanced_search(
            self.public_user,
            terms,
            self.test_project.pk,
            include_metas=True,
            collection_id=321,
            limit_from=0,
            limit_to=2000,
        )
        methods.simple_search(self.public_user, "pouet", self.test_project.pk)

    def test_descendants_resources_count(self):
        col = models.Collection.objects.create(
            title="desc col",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        res = models.Resource.objects.create(
            title="test res", ptr_project=self.test_project
        )
        models.CollectionMembership.objects.create(collection=col, resource=res)
        self.assertEqual(col.descendants_resources_count(), 0)
        self.assertEqual(col.descendant_resources_count(), 1)

    def test_descendants_resources_count_excludes_soft_deleted_data(self):
        parent = models.Collection.objects.create(
            title="parent resources",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        child = models.Collection.objects.create(
            title="child resources",
            project=self.test_project,
            parent=parent,
        )
        grandchild = models.Collection.objects.create(
            title="grandchild resources",
            project=self.test_project,
            parent=child,
        )
        deleted_child = models.Collection.objects.create(
            title="deleted child resources",
            project=self.test_project,
            parent=parent,
        )
        active_resource = models.Resource.objects.create(
            title="active resource", ptr_project=self.test_project
        )
        shared_resource = models.Resource.objects.create(
            title="shared resource", ptr_project=self.test_project
        )
        deleted_resource = models.Resource.objects.create(
            title="deleted resource", ptr_project=self.test_project
        )

        models.CollectionMembership.objects.create(
            collection=child,
            resource=active_resource,
        )
        models.CollectionMembership.objects.create(
            collection=grandchild,
            resource=shared_resource,
        )
        models.CollectionMembership.objects.create(
            collection=child,
            resource=shared_resource,
        )
        models.CollectionMembership.objects.create(
            collection=deleted_child,
            resource=active_resource,
        )
        models.CollectionMembership.objects.create(
            collection=grandchild,
            resource=deleted_resource,
        )
        models.CollectionMembership.objects.create(
            collection=parent,
            resource=active_resource,
        )

        deleted_child.soft_delete()
        deleted_resource.soft_delete()

        self.assertEqual(parent.descendants_resources_count(), 3)
        self.assertEqual(parent.descendant_resources_count(), 4)
        self.assertEqual(child.descendants_resources_count(), 1)
        self.assertEqual(grandchild.descendants_resources_count(), 0)

    def test_descendants_count_excludes_soft_deleted_branches(self):
        parent = models.Collection.objects.create(
            title="parent",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        child = models.Collection.objects.create(
            title="child",
            project=self.test_project,
            parent=parent,
        )
        grandchild = models.Collection.objects.create(
            title="grandchild",
            project=self.test_project,
            parent=child,
        )
        deleted_child = models.Collection.objects.create(
            title="deleted child",
            project=self.test_project,
            parent=parent,
        )
        models.Collection.objects.create(
            title="deleted grandchild",
            project=self.test_project,
            parent=deleted_child,
        )

        deleted_child.soft_delete()

        self.assertEqual(parent.descendants_count(), 2)
        self.assertEqual(child.descendants_count(), 1)
        self.assertEqual(grandchild.descendants_count(), 0)

    def test_metas_count(self):
        col = models.Collection.objects.create(
            title="desc col",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        res = models.Resource.objects.create(
            title="test res", ptr_project=self.test_project
        )
        models.CollectionMembership.objects.create(collection=col, resource=res)
        meta_set = models.MetadataSet.objects.create(
            project=self.test_project, title="test metadataset"
        )
        metadata_id = methods.add_metadata(
            self.admin_user, "metadata test", meta_set.id
        )
        methods.add_meta_to_resource(
            self.admin_user, res.pk, metadata_id, "test meta value A"
        )
        methods.add_meta_to_resource(
            self.admin_user, res.pk, metadata_id, "test meta value B"
        )
        methods.add_meta_to_resource(
            self.admin_user, res.pk, metadata_id, "test meta value C"
        )
        methods.add_meta_to_resource(
            self.admin_user, res.pk, metadata_id, "test meta value C"
        )
        result = methods.meta_count(self.admin_user, metadata_id, col.pk)
        self.assertEqual(result["test meta value C"], 1)

    def test_project_properties(self):
        test_property = methods.set_project_property(
            self.admin_user,
            self.test_project.pk,
            "test_prop",
            {"some": "complex", "value": [1, 2, 3]},
        )
        self.assertEqual(test_property["value"]["some"], "complex")
        methods.delete_project_property(
            self.admin_user, self.test_project.pk, "test_prop"
        )
        all_props = methods.project_properties(self.admin_user, self.test_project.pk)
        self.assertEqual(len(all_props), 0)

    def test_ordering(self):
        GOOD_ORDERING = ["0001", "0002", "0002a", "0002b", "0002c", "0003"]
        methods.add_collection(
            self.test_user,
            "0003",
            parent_id=self.test_project_root_collection.pk,
        )
        methods.add_collection(
            self.test_user,
            "0001",
            parent_id=self.test_project_root_collection.pk,
        )
        methods.add_collection(
            self.test_user,
            "0002",
            parent_id=self.test_project_root_collection.pk,
        )
        methods.add_collection(
            self.test_user,
            "0002c",
            parent_id=self.test_project_root_collection.pk,
        )
        methods.add_collection(
            self.test_user,
            "0002b",
            parent_id=self.test_project_root_collection.pk,
        )
        methods.add_collection(
            self.test_user,
            "0002a",
            parent_id=self.test_project_root_collection.pk,
        )
        titles = []
        for item in methods.collections(
            self.test_user, self.test_project_root_collection.pk, order_by="title"
        ):
            titles.append(item["title"])
        self.assertEqual(titles, GOOD_ORDERING)

        r = models.Resource.objects.create(title="0003", ptr_project=self.test_project)
        methods.add_resource_to_collection(
            self.test_user, r.pk, self.test_project_root_collection.pk
        )
        r = models.Resource.objects.create(title="0001", ptr_project=self.test_project)
        methods.add_resource_to_collection(
            self.test_user, r.pk, self.test_project_root_collection.pk
        )
        r = models.Resource.objects.create(title="0002b", ptr_project=self.test_project)
        methods.add_resource_to_collection(
            self.test_user, r.pk, self.test_project_root_collection.pk
        )
        r = models.Resource.objects.create(title="0002c", ptr_project=self.test_project)
        methods.add_resource_to_collection(
            self.test_user, r.pk, self.test_project_root_collection.pk
        )
        r = models.Resource.objects.create(title="0002a", ptr_project=self.test_project)
        methods.add_resource_to_collection(
            self.test_user, r.pk, self.test_project_root_collection.pk
        )
        r = models.Resource.objects.create(title="0002", ptr_project=self.test_project)
        methods.add_resource_to_collection(
            self.test_user, r.pk, self.test_project_root_collection.pk
        )

        titles = []
        for item in methods.resources(
            self.test_user, self.test_project_root_collection.pk, order_by="title"
        ):
            titles.append(item["title"])
        self.assertEqual(titles, GOOD_ORDERING)

    def test_remove_selection(self):
        col = methods.add_collection(
            self.test_user, "some_test", parent_id=self.test_project_root_collection.pk
        )
        r = models.Resource.objects.create(title="0002", ptr_project=self.test_project)
        methods.add_resource_to_collection(self.test_user, r.pk, col.get("id"))

        res = methods.remove_selection(
            self.test_user,
            col.get("id"),
            {"include": {"resources_ids": [r.pk], "collections_ids": []}},
        )

        self.assertTrue(res)

    def test_user_tasks(self):
        models.UserTask.objects.create(
            owner=self.test_user, description="test description 1"
        )
        models.UserTask.objects.create(
            owner=self.test_user, description="test description 2"
        )
        self.assertEqual(models.UserTask.objects.count(), 2)

    def test_replace_file(self):
        from resources.helpers import handle_local_file

        self.assertTrue(
            models.Resource.objects.filter(deleted_at__isnull=True).count() == 0
        )
        id1 = handle_local_file(
            Path(os.path.dirname(__file__), "test_assets", "cat_1.png"),
            self.test_project,
        )
        id2 = handle_local_file(
            Path(os.path.dirname(__file__), "test_assets", "cat_2.png"),
            self.test_project,
        )
        self.assertTrue(
            models.Resource.objects.filter(deleted_at__isnull=True).count() == 2
        )
        methods.replace_file(self.test_user, id1, id2)
        self.assertTrue(
            models.Resource.objects.filter(deleted_at__isnull=True).count() == 1
        )

    def test_download_metas_xls_filters_metadatas_and_metadatasets(self):
        collection = models.Collection.objects.create(
            title="xlsx target",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        ds1 = models.MetadataSet.objects.create(
            project=self.test_project, title="set A"
        )
        ds2 = models.MetadataSet.objects.create(
            project=self.test_project, title="set B"
        )
        ds3 = models.MetadataSet.objects.create(
            project=self.test_project, title="set C"
        )
        m1 = models.Metadata.objects.create(
            title="meta A", set=ds1, project=self.test_project
        )
        m2 = models.Metadata.objects.create(
            title="meta B", set=ds2, project=self.test_project
        )
        m3 = models.Metadata.objects.create(
            title="meta C", set=ds3, project=self.test_project
        )
        models.MetadataCollectionValue.objects.create(
            metadata=m1, collection=collection, value="value A"
        )
        models.MetadataCollectionValue.objects.create(
            metadata=m2, collection=collection, value="value B"
        )
        models.MetadataCollectionValue.objects.create(
            metadata=m3, collection=collection, value="value C"
        )

        self.client.force_login(self.test_user)
        response = self.client.get(
            reverse("metas_download", kwargs={"collection_id": collection.pk}),
            {"metadata_ids": str(m1.pk), "metadataset_ids": str(ds2.pk)},
        )
        self.assertEqual(response.status_code, 200)

        wb = load_workbook(filename=BytesIO(b"".join(response.streaming_content)))
        ws = wb.active
        headers = [ws.cell(row=1, column=i).value for i in range(1, ws.max_column + 1)]
        headers_index = {h: i + 1 for i, h in enumerate(headers)}

        self.assertIn(str(m1), headers)
        self.assertIn(str(m2), headers)
        self.assertNotIn(str(m3), headers)
        self.assertEqual(ws.cell(row=2, column=headers_index[str(m1)]).value, "value A")
        self.assertEqual(ws.cell(row=2, column=headers_index[str(m2)]).value, "value B")

    def test_download_metas_xls_bad_query_params(self):
        collection = models.Collection.objects.create(
            title="xlsx bad query target",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        self.client.force_login(self.test_user)
        response = self.client.get(
            reverse("metas_download", kwargs={"collection_id": collection.pk}),
            {"metadata_ids": "abc"},
        )
        self.assertEqual(response.status_code, 400)

    def test_collections_resources_pair_requires_access(self):
        outsider = User.objects.create(username="outsider")
        with self.assertRaises(ServiceException):
            methods.collections_resources_pair(outsider, self.test_project.pk)

    def test_collections_resources_pair_filters_orders_and_scopes_results(self):
        first_collection = models.Collection.objects.create(
            title="first collection",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        second_collection = models.Collection.objects.create(
            title="second collection",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        active_resource_a = models.Resource.objects.create(
            title="active resource a", ptr_project=self.test_project
        )
        active_resource_b = models.Resource.objects.create(
            title="active resource b", ptr_project=self.test_project
        )
        deleted_resource = models.Resource.objects.create(
            title="deleted resource", ptr_project=self.test_project
        )
        deleted_collection = models.Collection.objects.create(
            title="deleted collection",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )

        first_membership_high_rank = models.CollectionMembership.objects.create(
            collection=first_collection,
            resource=active_resource_a,
            rank=20,
        )
        first_membership_low_rank = models.CollectionMembership.objects.create(
            collection=first_collection,
            resource=active_resource_b,
            rank=10,
        )
        second_membership = models.CollectionMembership.objects.create(
            collection=second_collection,
            resource=active_resource_a,
            rank=5,
        )
        models.CollectionMembership.objects.create(
            collection=first_collection,
            resource=deleted_resource,
            rank=0,
        )
        models.CollectionMembership.objects.create(
            collection=deleted_collection,
            resource=active_resource_a,
            rank=0,
        )

        deleted_resource.soft_delete()
        deleted_collection.soft_delete()

        results = methods.collections_resources_pair(
            self.test_user,
            self.test_project.pk,
        )

        self.assertEqual(
            [item["id"] for item in results],
            [
                first_membership_low_rank.id,
                first_membership_high_rank.id,
                second_membership.id,
            ],
        )
        self.assertEqual(
            results[0],
            {
                "id": first_membership_low_rank.id,
                "resource": {
                    "id": active_resource_b.pk,
                    "title": active_resource_b.title,
                },
                "collection": {
                    "id": first_collection.pk,
                    "title": first_collection.title,
                    "parent_id": first_collection.parent_id,
                    "path": None,
                },
                "rank": 10,
            },
        )

        scoped_results = methods.collections_resources_pair(
            self.test_user,
            self.test_project.pk,
            collection_id=second_collection.pk,
        )
        self.assertEqual(len(scoped_results), 1)
        self.assertEqual(scoped_results[0]["id"], second_membership.id)

    def test_collections_resources_pair_adds_collection_path(self):
        parent_collection = models.Collection.objects.create(
            title="parent collection",
            project=self.test_project,
            parent=self.test_project.root_collection,
        )
        child_collection = models.Collection.objects.create(
            title="child collection",
            project=self.test_project,
            parent=parent_collection,
        )
        resource = models.Resource.objects.create(
            title="resource with path", ptr_project=self.test_project
        )
        membership = models.CollectionMembership.objects.create(
            collection=child_collection,
            resource=resource,
            rank=1,
        )

        results = methods.collections_resources_pair(
            self.test_user,
            self.test_project.pk,
            collection_id=child_collection.pk,
            add_path=True,
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["id"], membership.id)
        self.assertEqual(
            results[0]["collection"]["path"],
            [
                {
                    "id": self.test_project.root_collection.pk,
                    "title": self.test_project.root_collection.title,
                },
                {"id": parent_collection.pk, "title": parent_collection.title},
                {"id": child_collection.pk, "title": child_collection.title},
            ],
        )
