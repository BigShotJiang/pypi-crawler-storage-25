from django.http import HttpRequest, HttpResponse, JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.shortcuts import render
from django import forms
from urllib.parse import unquote_plus
import json
import binascii
import rpc.methods as rpc_methods
from rpc.methods import ServiceException
from resources.acl import UserAccess
from inspect import getmembers, isfunction
from resources.helpers import (
    handle_uploaded_file,
    UnknownFileType,
    ResourceError,
    ConcurrencyError,
    FileAlreadyExists,
)
from resources import models
from typing import Union, List
from jama import settings
import re
import os
from glob import glob
import hashlib
from django.core.files.base import File
from django.db import transaction
from pathlib import Path
from shutil import rmtree
import base64
from .fileresponse import RangedFileResponse
from django.views.decorators.gzip import gzip_page
import logging
from functools import lru_cache
from resources.tasks import (
    exif_task,
    iiif_task,
    ocr_task,
    update_data_from_xlsx_rows,
    hls_task,
)
from openpyxl import load_workbook
import tempfile
from rpc.signals import rpc_success_signal


importlib = __import__("importlib")

logger = logging.getLogger(__name__)


class UploadLimitExceeded(ValueError):
    pass


class BadRequestBody(ValueError):
    pass


class RequestBodyTooLarge(ValueError):
    pass


def _rpc_request_body(request: HttpRequest) -> bytes:
    max_size = settings.JAMA_RPC_MAX_BODY_SIZE
    content_length_header = request.headers.get("Content-Length")
    if content_length_header:
        try:
            content_length = int(content_length_header)
        except ValueError as err:
            raise BadRequestBody("invalid Content-Length") from err
        if content_length < 0:
            raise BadRequestBody("negative Content-Length")
        if max_size > 0 and content_length > max_size:
            raise RequestBodyTooLarge

    body = request.body
    if max_size > 0 and len(body) > max_size:
        raise RequestBodyTooLarge
    return body


def _silent_rmdir(dir_path: str):
    rmtree(dir_path, ignore_errors=True)


def _silent_remove(file_path: str):
    try:
        os.remove(file_path)
    except FileNotFoundError:
        pass


def _file_hash256(file_path: str) -> str:
    hsh = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chnk in iter(lambda: f.read(8192), b""):
            hsh.update(chnk)
    return hsh.hexdigest()


def _collection_from_origin_dir(
    origin_dir: str, project: models.Project
) -> Union[models.Collection, None]:
    # root dir always first
    previous_dir = project.root_collection
    for dir_name in origin_dir.split("/"):
        dir_name = dir_name.strip()
        if not dir_name:
            continue
        dir_name = dir_name.strip()
        if dir_name:
            previous_dir, created = models.Collection.objects.get_or_create(
                project=project, title=dir_name, parent=previous_dir
            )
            # this was soft-deleted. Un-delete !
            if not created and previous_dir.deleted_at:
                previous_dir.deleted_at = None
                previous_dir.save()
    return previous_dir


def _join_parts(
    parts_dir: str, destination: str, sha256sum: str, total_parts: int
) -> bool:
    with open(destination, "wb") as f:
        for path in sorted(glob("{}/{}-*.part".format(parts_dir, total_parts))):
            with open(path, "rb") as s:
                f.write(s.read())

    for path in glob("{}/{}-*.part".format(parts_dir, total_parts)):
        _silent_remove(path)
    if _file_hash256(destination) != sha256sum:
        return False
    return True


def _get_user_from_request(request: HttpRequest) -> Union[User, None]:
    """
    Tries to find a user given the request. In this order:

    - try to find session user
    - try to find user associated with X-api-key header
    - try to find user corresponding to Authorization header
    """
    if request.user.is_authenticated:
        logger.debug(f"user {request.user.username} is authenticated")
        return request.user
    if "X-Api-Key" in request.headers:
        try:
            key_hash = models.APIKey.hash_key(request.headers["X-Api-Key"])
            return User.objects.get(apikey__key_hash=key_hash, apikey__active=True)
        except User.DoesNotExist:
            logger.warning("X-Api-Key was given but user was not found")
            return None
    if "Authorization" in request.headers:
        try:
            auth_header = request.headers["Authorization"]
            if not auth_header.startswith("Basic "):
                raise ValueError("Unsupported authorization scheme")
            auth_u, auth_p = (
                base64.decodebytes(auth_header[6:].encode("utf-8"))
                .decode("utf-8")
                .split(":", 1)
            )
            user = authenticate(username=auth_u, password=auth_p)
            if not user:
                logger.warning(
                    "Authorization was given in request headers but user was not authenticated"
                )
            return user
        except (KeyError, ValueError, UnicodeDecodeError, binascii.Error):
            logger.warning("Authorization was malformed")
            return None
    return None


def _get_project_from_request(request: HttpRequest) -> Union[models.Project, None]:
    if "X-Project" in request.headers:
        return models.Project.objects.filter(pk=request.headers["X-Project"]).first()
    return None


def _parse_int_list_query_param(
    request: HttpRequest, key: str
) -> Union[List[int], None]:
    if key not in request.GET:
        return None
    ids = []
    for raw_val in request.GET.getlist(key):
        for part in raw_val.split(","):
            part = part.strip()
            if not part:
                continue
            value = int(part)
            if value < 1:
                raise ValueError
            ids.append(value)
    # deduplicate while preserving order
    return list(dict.fromkeys(ids))


def _parse_upload_chunk_header(raw_chunk_header: str) -> tuple[int, int]:
    chunk_number, total_chunks = raw_chunk_header.split("/", 1)
    chunk_number = int(chunk_number)
    total_chunks = int(total_chunks)
    if chunk_number < 1 or total_chunks < 1 or chunk_number > total_chunks:
        raise ValueError
    if total_chunks > settings.JAMA_UPLOAD_MAX_TOTAL_CHUNKS:
        raise UploadLimitExceeded
    return chunk_number, total_chunks


def _request_content_length(request: HttpRequest) -> int:
    content_length = int(request.headers["Content-Length"])
    if content_length < 0 or content_length > settings.JAMA_UPLOAD_MAX_CHUNK_SIZE:
        raise UploadLimitExceeded
    return content_length


def _write_request_body_to_file(
    request: HttpRequest, destination: str, expected_size: int
) -> bool:
    tmp_destination = "{}.uploading".format(destination)
    bytes_written = 0
    try:
        with open(tmp_destination, "wb") as f:
            while True:
                chunk = request.read(1024 * 1024)
                if not chunk:
                    break
                bytes_written += len(chunk)
                if bytes_written > expected_size:
                    return False
                f.write(chunk)
        if bytes_written != expected_size:
            return False
        os.replace(tmp_destination, destination)
        return True
    finally:
        _silent_remove(tmp_destination)


@lru_cache(None, typed=True)
def _get_rpc_methods() -> dict:
    methods = {}
    for fn_name, _ in getmembers(rpc_methods, isfunction):
        if fn_name[0:1] == "_":
            continue
        methods[fn_name] = getattr(rpc_methods, fn_name)
    for app_name in settings.AUTO_REGISTER_APPS:
        try:
            rpc_module = importlib.import_module("{}.rpc.methods".format(app_name))
            for fn_name, _ in getmembers(rpc_module, isfunction):
                if fn_name[0:1] == "_":
                    continue
                methods[fn_name] = getattr(rpc_module, fn_name)
        except ModuleNotFoundError:
            continue
    return methods


@gzip_page
@transaction.atomic
@csrf_exempt
def rpc(request: HttpRequest) -> HttpResponse:
    req_id = None
    if request.method == "GET":
        if settings.JAMA_SHOW_RPC_DOCS:
            return render(request, "docs.html", {"methods": _get_rpc_methods()})
    if request.method != "POST":
        return HttpResponse("Method Not Allowed", status=405)
    try:
        request_body = _rpc_request_body(request)
        user = _get_user_from_request(request)
        if not user:
            logger.warning("could not find user for RPC request")
            return HttpResponse("Forbidden", status=403)
        methods = _get_rpc_methods()
        json_data = json.loads(request_body)
        method = json_data["method"]
        if method not in methods.keys():
            logger.warning(f'user {user} called unknown method "{method}"')
            return JsonResponse(
                {
                    "result": None,
                    "error": "no such method",
                    "id": req_id,
                }
            )
        params = json_data["params"] if "params" in json_data else None
        if not params:
            params = []
        params.insert(0, user)  # always add user to method call
        req_id = json_data["id"]
        result = methods[method](*params)
        logger.info(
            'User {}({}) called "{}" with params {}'.format(
                user.username, user.pk, method, params[1:]
            )
        )
        params[0] = user.username
        rpc_success_signal.send_robust(sender=method, params=params, result=result)
        return JsonResponse({"result": result, "error": None, "id": req_id})
    except json.JSONDecodeError:
        logger.warning("could not decode json request")
        return HttpResponse("Bad Request", status=400)
    except KeyError as err:
        logger.warning("client data dict key error")
        logger.exception(err)
        return HttpResponse("Bad Request", status=400)
    except TypeError as err:
        logger.warning("client data type error")
        logger.exception(err)
        return HttpResponse("Bad Request", status=400)
    except RequestBodyTooLarge:
        logger.warning("RPC request body exceeded configured limit")
        return HttpResponse("Payload Too Large", status=413)
    except BadRequestBody as err:
        logger.warning("bad RPC request body: %s", err)
        return HttpResponse("Bad Request", status=400)
    except ValueError as err:
        logger.warning("client data warning error")
        logger.exception(err)
        return HttpResponse("Bad Request", status=400)
    except ServiceException as e:
        return JsonResponse(
            {
                "result": None,
                "error": getattr(e, "message", repr(e)),
                "id": req_id,
            }
        )


@csrf_exempt
@require_http_methods(["POST"])
def upload_partial(request: HttpRequest) -> HttpResponse:
    user = _get_user_from_request(request)
    if not user:
        return HttpResponse("Forbidden", status=403)
    project = _get_project_from_request(request)
    if not project:
        return HttpResponse("Bad Request", status=400)
    try:
        UserAccess(user, project).check_create("resource")
    except ServiceException:
        return HttpResponse("Forbidden", status=403)
    # optional header, used to create collections
    origin_dir = request.headers.get("X-origin-dir", None)
    if origin_dir:
        try:
            origin_dir = unquote_plus(base64.b64decode(origin_dir).decode("utf-8"))
        except binascii.Error:
            logger.warning(f"X-origin-dir value is not base64-encoded: {origin_dir}")
    try:
        file_hash = request.headers["X-file-hash"]
        if re.fullmatch("[A-Fa-f0-9]{64}", file_hash) is None:
            raise ValueError
        file_name = unquote_plus(
            base64.b64decode(request.headers["X-file-name"]).decode("utf-8")
        )
        _, f_extension = os.path.splitext(file_name)
        if not f_extension:
            return HttpResponse("Type de fichier inconnu", status=400)
        chunk_number, total_chunks = _parse_upload_chunk_header(
            request.headers["X-file-chunk"]
        )
        file_instance = models.File.objects.get(hash=file_hash, project=project)
        # Rise from your grave !
        if file_instance.deleted_at:
            file_instance.deleted_at = None
            file_instance.title = file_name
            file_instance.original_name = file_name
            file_instance.save()
            logger.info(
                "User {}({}) respawned file {}".format(
                    user.username, user.pk, file_instance.pk
                )
            )
        if origin_dir:
            collection = _collection_from_origin_dir(origin_dir, project)
            collection.resources.add(file_instance)
            logger.info(
                "User {}({}) added file({}) to collection({})".format(
                    user.username, user.pk, file_instance.pk, collection.pk
                )
            )
        return HttpResponse(file_instance.pk, status=200)
    except UploadLimitExceeded:
        return HttpResponse("Payload Too Large", status=413)
    except (KeyError, ValueError):
        return HttpResponse(status=400)
    except models.File.DoesNotExist:
        pass

    partials_dir = "{}/{}-{}".format(settings.PARTIAL_UPLOADS_DIR, user.pk, file_hash)
    lock_file_path = "{}/.lock".format(partials_dir)
    if os.path.isfile(lock_file_path):
        return HttpResponse(status=202)
    os.makedirs(partials_dir, exist_ok=True)

    # We don't want to store an incomplete chunk.
    # (prevent client disconnect)
    try:
        content_length = _request_content_length(request)
        partial_destination = "{}/{}-{}.part".format(
            partials_dir,
            total_chunks,
            str(chunk_number).zfill(len(str(total_chunks))),
        )
        if not _write_request_body_to_file(
            request, partial_destination, content_length
        ):
            return HttpResponse("Content-Length does not match body size", status=400)
    except KeyError:  # Content-length header is mandatory
        return HttpResponse("Length Required", status=411)
    except UploadLimitExceeded:
        return HttpResponse("Payload Too Large", status=413)
    except ValueError:
        return HttpResponse("Bad Request", status=400)

    # All chunks are complete, time to assemble
    f_name = "{}/complete{}".format(partials_dir, f_extension)
    if len(glob("{}/{}-*.part".format(partials_dir, total_chunks))) == int(
        total_chunks
    ) or os.path.exists(f_name):
        Path(lock_file_path).touch()  # lock dir

        if not os.path.exists(f_name):
            checksum_ok = _join_parts(partials_dir, f_name, file_hash, total_chunks)
        elif file_hash == _file_hash256(f_name):
            checksum_ok = True
        else:
            checksum_ok = False
        try:
            with open(f_name, "rb") as f:
                try:
                    file_id = None
                    with transaction.atomic():
                        file_id = handle_uploaded_file(
                            File(f),
                            project,
                            force_file_name=file_name,
                        )
                        f.close()
                        _silent_rmdir(partials_dir)
                        logger.info(
                            "User {}({}) handled file {}".format(
                                user.username, user.pk, file_id
                            )
                        )
                        if origin_dir:
                            collection = _collection_from_origin_dir(
                                origin_dir, project
                            )
                            collection.resources.add(
                                models.File.objects.get(id=file_id)
                            )
                            logger.info(
                                "User {}({}) added file({}) to collection({})".format(
                                    user.username, user.pk, file_id, collection.pk
                                )
                            )
                    iiif_task.enqueue(file_id)
                    exif_task.enqueue(file_id)
                    ocr_task.enqueue(file_id)
                    hls_task.enqueue(file_id)
                    if not checksum_ok:
                        return HttpResponse(file_id, status=210)  # content different
                    else:
                        return HttpResponse(file_id, status=200)
                except UnknownFileType:
                    _silent_rmdir(partials_dir)
                    return HttpResponse("Type de fichier inconnu", status=400)
                except ResourceError:
                    _silent_rmdir(partials_dir)
                    return HttpResponse(
                        "Impossible d'enregistrer la ressource", status=400
                    )
                except FileAlreadyExists as already_exists:
                    return HttpResponse(str(already_exists), status=409)
                except ConcurrencyError:
                    # Concurrency problem with clients sending multiple chunks in parallel.
                    # Nothing to do here, work has already been done.
                    return HttpResponse("Too Many Requests", status=429)

        # another race condition
        except FileNotFoundError:
            return HttpResponse("Too Many Requests", status=429)
    return HttpResponse(status=202)


def force_download(
    request: HttpRequest, file_id: int
) -> Union[HttpResponse, RangedFileResponse]:
    file = models.File.objects.filter(id=file_id).first()
    if not file:
        return HttpResponse("Not Found", 404)
    try:
        user = _get_user_from_request(request)
        if not user:
            return HttpResponse("Forbidden", status=403)
        UserAccess(user, file.project).check_read(file)
    except ServiceException:
        return HttpResponse("Forbidden", status=403)
    return RangedFileResponse(
        request,
        open(file.local_path(), "rb"),
        filename=file.new_filename,
        # content_type=file.file_type.mime, # Firefox is bad
    )


def force_download_public(
    request: HttpRequest, file_hash: str
) -> Union[HttpResponse, RangedFileResponse]:
    if not settings.JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS:
        return HttpResponse("Not Found", status=404)
    file = models.File.objects.filter(hash=file_hash).first()
    if not file:
        return HttpResponse("Not Found", status=404)
    return RangedFileResponse(
        request,
        open(file.local_path(), "rb"),
        filename=file.new_filename,
        # content_type=file.file_type.mime, # Firefox is bad
    )


def serve_file_public(
    request: HttpRequest, file_hash: str
) -> Union[HttpResponse, RangedFileResponse]:
    if not settings.JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS:
        return HttpResponse("Not Found", status=404)
    file = models.File.objects.filter(hash=file_hash).first()
    if not file:
        return HttpResponse("Not Found", status=404)
    return RangedFileResponse(
        request,
        open(file.local_path(), "rb"),
        filename=file.new_filename,
        content_type=file.file_type.mime,  # Firefox is bad
    )


@csrf_exempt
@require_http_methods(["POST"])
def upload_metas_xls(request: HttpRequest) -> HttpResponse:
    data_rows = []
    user = _get_user_from_request(request)
    if not user:
        return HttpResponse("Forbidden", status=403)

    class MetasXSLXUploadForm(forms.Form):
        file = forms.FileField()

    form = MetasXSLXUploadForm(request.POST, request.FILES)
    if form.is_valid():
        with tempfile.NamedTemporaryFile(suffix=".xlsx") as tmp:
            with open(tmp.name, "wb+") as destination:
                for chunk in request.FILES["file"].chunks():
                    destination.write(chunk)
            wb = load_workbook(filename=tmp)
            ws = wb.active
            keys = []
            for row in ws.iter_rows(values_only=True):
                if not keys:
                    keys = list(row)
                else:
                    data = dict(zip(keys, list(row)))
                    data_rows.append(data)
            user_task = models.UserTask.objects.create(
                owner=user, description="Traitement de fichier XLS de métadonnées"
            )
            update_data_from_xlsx_rows.enqueue(user.pk, data_rows, user_task.pk)
            return HttpResponse("OK", status=200)
    return HttpResponse("Bad Request", status=400)


def download_metas_xls(request: HttpRequest, collection_id):
    collection_instance = (
        models.Collection.objects.select_related("project")
        .filter(pk=collection_id)
        .first()
    )
    if not collection_instance:
        return HttpResponse("Not Found", status=404)

    user = _get_user_from_request(request)
    if not user:
        return HttpResponse("Forbidden", status=403)
    UserAccess(user, collection_instance.project).check_read(collection_instance)
    try:
        metadata_ids = _parse_int_list_query_param(request, "metadata_ids")
        metadataset_ids = _parse_int_list_query_param(request, "metadataset_ids")
    except ValueError:
        return HttpResponse("Bad Request", status=400)

    with tempfile.NamedTemporaryFile(suffix=".xlsx") as tmp:
        collection_instance.export_to_xlsx(
            tmp.name,
            metadata_ids=metadata_ids,
            metadataset_ids=metadataset_ids,
        )
        return RangedFileResponse(
            request,
            open(tmp.name, "rb"),
            filename=f"collection_{collection_id}.xlsx",
            content_type="application/vnd.ms-excel",
        )
