class ServiceException(Exception):
    """
    Base exception for all RPC methods.
    Accepts a message
    """

    def __init__(self, *args, **kwargs):
        self.message = args[0]
