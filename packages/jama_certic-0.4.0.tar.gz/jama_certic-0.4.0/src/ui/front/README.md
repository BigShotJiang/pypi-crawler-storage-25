# UI

Instanciation de la lib [vue3-jama](https://git.unicaen.fr/pdn-certic/vue3-jama).

Pour activer les annotations, ajouter aux variables d'env JAMA : 

```
JAMA_UI_ANNOTATIONS="1"
```

