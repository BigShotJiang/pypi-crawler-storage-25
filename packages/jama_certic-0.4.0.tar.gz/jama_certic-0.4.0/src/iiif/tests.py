from django.contrib.auth.models import AnonymousUser, User
from django.core.exceptions import PermissionDenied
from django.http import Http404
from django.test import RequestFactory, TestCase, override_settings

from iiif.views import _check_iiif_access, _file_hash_from_iiif_path
from resources.models import (
    Collection,
    File,
    FileExtension,
    FileType,
    ObjectPermission,
    Project,
    ProjectAccess,
    Role,
)


class IIIFAccessTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username="iiif_user")
        self.no_access_user = User.objects.create(username="iiif_no_access_user")
        self.project = Project.objects.create(label="iiif project", description="")
        Collection.objects.create(title="root", project=self.project, parent=None)
        self.role = Role.objects.create(label="reader", project=self.project)
        ObjectPermission.objects.create(
            role=self.role,
            object_class="resource",
            object_pk=None,
            object_create=False,
            object_read=True,
            object_update=False,
            object_delete=False,
        )
        ProjectAccess.objects.create(
            project=self.project,
            user=self.user,
            role=self.role,
        )
        extension = FileExtension.objects.create(label="jpg")
        file_type = FileType.objects.create(
            title="JPEG",
            mime="image/jpeg",
            serve_with_iiif=True,
        )
        file_type.extensions.add(extension)
        self.file_hash = "a" * 64
        self.file = File.objects.create(
            title="image",
            original_name="image.jpg",
            project=self.project,
            hash=self.file_hash,
            file_type=file_type,
            size=123,
            denormalized_image_width=1,
            denormalized_image_height=1,
        )

    def _request(self, user):
        request = self.factory.get("/iiif/aa/aa/{}/info.json".format(self.file_hash))
        request.user = user
        return request

    def test_file_hash_from_iiif_path(self):
        path = "aa/aa/{}/full/max/0/default.jpg".format(self.file_hash)
        self.assertEqual(_file_hash_from_iiif_path(path), self.file_hash)

    @override_settings(IIIF_URLS_NEED_AUTH=False)
    def test_iiif_access_allows_public_mode(self):
        _check_iiif_access(self._request(AnonymousUser()), "no-hash-needed")

    @override_settings(IIIF_URLS_NEED_AUTH=True)
    def test_iiif_access_rejects_anonymous_user(self):
        with self.assertRaises(PermissionDenied):
            _check_iiif_access(
                self._request(AnonymousUser()),
                "aa/aa/{}/info.json".format(self.file_hash),
            )

    @override_settings(IIIF_URLS_NEED_AUTH=True)
    def test_iiif_access_rejects_user_without_resource_read_access(self):
        with self.assertRaises(PermissionDenied):
            _check_iiif_access(
                self._request(self.no_access_user),
                "aa/aa/{}/info.json".format(self.file_hash),
            )

    @override_settings(IIIF_URLS_NEED_AUTH=True)
    def test_iiif_access_allows_user_with_resource_read_access(self):
        _check_iiif_access(
            self._request(self.user),
            "aa/aa/{}/info.json".format(self.file_hash),
        )

    @override_settings(IIIF_URLS_NEED_AUTH=True)
    def test_iiif_access_404s_when_path_has_no_hash(self):
        with self.assertRaises(Http404):
            _check_iiif_access(self._request(self.user), "favicon.ico")
