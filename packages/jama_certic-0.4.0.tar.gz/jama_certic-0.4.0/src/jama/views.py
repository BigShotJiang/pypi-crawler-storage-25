from django.http import HttpResponse, HttpRequest
from django.shortcuts import render, get_object_or_404, redirect, Http404
from jama import settings
from django.contrib.auth.models import User
from django.contrib.auth.decorators import user_passes_test
from django.views.decorators.cache import never_cache
from django.core.paginator import Paginator
from django.db.models import F, TextField
from django.db.models.functions import Cast, TruncDate
from django.urls import reverse
from django.utils.dateparse import parse_date
from django_tasks_db.models import DBTaskResult
from resources.models import Resource, Collection, Project
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from .iiif import serialize_jama_collection
from django.views.decorators.cache import cache_page


def merge_query_string_to_url(url: str, qs: str) -> str:
    # Parse both URLs
    parsed1 = urlparse(url)

    # Parse query parameters
    query1 = parse_qs(parsed1.query)
    query2 = parse_qs(qs)

    # Merge the query parameters
    merged_query = query1.copy()
    for k, v in query2.items():
        if k in merged_query:
            merged_query[k].extend(v)
        else:
            merged_query[k] = v

    # Construct the new query string
    merged_query_str = urlencode(merged_query, doseq=True)

    # Create a new URL using components from url1 and the merged query
    merged_url = urlunparse(
        (
            parsed1.scheme,
            parsed1.netloc,
            parsed1.path,
            parsed1.params,
            merged_query_str,
            parsed1.fragment,
        )
    )

    return merged_url


BASE_PATH = "/" + settings.JAMA_URL_BASE_PATH


def handler404(request, *args, **argv):
    return HttpResponse("", status=404)


def homepage(request: HttpRequest) -> HttpResponse:
    if settings.JAMA_ROOT_URL_REDIRECT:
        return redirect(settings.JAMA_ROOT_URL_REDIRECT)
    return render(request, "homepage.html", {"BASE_PATH": BASE_PATH})


def status(request: HttpRequest) -> HttpResponse:
    # testing database connection
    try:
        User.objects.first()
    except:  # noqa: E722
        return HttpResponse("ko")
    return HttpResponse("ok")


@cache_page(60 * 60 * 24)
def ark_collection_iiif_manifest(
    request: HttpRequest, naan: str, assigned_name: str
) -> HttpResponse:
    ark_name = f"{naan}/{assigned_name}"
    collection = Collection.objects.filter(
        deleted_at__isnull=True,
        ark=ark_name,
        project__restore_state=Project.RESTORE_STATE_READY,
    ).first()
    if collection:
        return serialize_jama_collection(request, collection)
    raise Http404("no such collection")


def ark_resource_or_collection_iiif_manifest(
    request: HttpRequest, naan: str, assigned_name: str
) -> HttpResponse:
    ark_name = f"{naan}/{assigned_name}"
    resource = Resource.objects.filter(
        deleted_at__isnull=True,
        ark=ark_name,
        ptr_project__restore_state=Project.RESTORE_STATE_READY,
    ).first()
    if resource and resource.file and resource.file.iiif_infos_url():
        return redirect(resource.file.iiif_infos_url())
    collection = Collection.objects.filter(
        deleted_at__isnull=True,
        ark=ark_name,
        project__restore_state=Project.RESTORE_STATE_READY,
    ).first()
    if collection:
        return ark_collection_iiif_manifest(request, naan, assigned_name)
    raise Http404("no such resource")


def ark_resource_iiif_manifest_thumbnail(
    request: HttpRequest, naan: str, assigned_name: str, size: int
) -> HttpResponse:
    ark_name = f"{naan}/{assigned_name}"
    resource = Resource.objects.filter(
        deleted_at__isnull=True,
        ark=ark_name,
        ptr_project__restore_state=Project.RESTORE_STATE_READY,
    ).first()
    if resource and resource.file and resource.file.should_have_iiif:
        return redirect(resource.file.iiif_thumbnail_url(size))
    raise Http404("no such resource")


def ark_resource(request: HttpRequest, resource_id: int) -> HttpResponse:
    resource = get_object_or_404(
        Resource,
        pk=resource_id,
        deleted_at__isnull=True,
        ptr_project__restore_state=Project.RESTORE_STATE_READY,
    )
    if resource.ptr_project.ark_redirect:
        location = (
            resource.ptr_project.ark_redirect.replace("[CLASS]", "resource")
            .replace("[ARK]", str(resource.ark))
            .replace("[PK]", str(resource.pk))
        )
        if request.META["QUERY_STRING"]:
            location = merge_query_string_to_url(location, request.META["QUERY_STRING"])
        return redirect(location)
    return render(request, "ark_resource_placeholder.html", {"resource": resource})


def ark_collection(request: HttpRequest, collection_id: int) -> HttpResponse:
    collection = get_object_or_404(
        Collection,
        pk=collection_id,
        deleted_at__isnull=True,
        project__restore_state=Project.RESTORE_STATE_READY,
    )
    if collection.project.ark_redirect:
        location = (
            collection.project.ark_redirect.replace("[CLASS]", "collection")
            .replace("[ARK]", str(collection.ark))
            .replace("[PK]", str(collection.pk))
        )
        if request.META["QUERY_STRING"]:
            location = merge_query_string_to_url(location, request.META["QUERY_STRING"])
        return redirect(location)
    return render(
        request, "ark_collection_placeholder.html", {"collection": collection}
    )


def ark_generic(request: HttpRequest, naan: str, assigned_name: str) -> HttpResponse:
    ark_name = f"{naan}/{assigned_name}"
    resource_instance = Resource.objects.filter(
        ark=ark_name, ptr_project__restore_state=Project.RESTORE_STATE_READY
    ).first()
    if resource_instance:
        return ark_resource(request, resource_instance.pk)
    collection_instance = Collection.objects.filter(
        ark=ark_name, project__restore_state=Project.RESTORE_STATE_READY
    ).first()
    if collection_instance:
        return ark_collection(request, collection_instance.pk)
    raise Http404("no such ARK name")


def ark_resource_public_download(
    request: HttpRequest, naan: str, assigned_name: str
) -> HttpResponse:
    ark_name = f"{naan}/{assigned_name}"
    resource = Resource.objects.filter(
        deleted_at__isnull=True,
        ark=ark_name,
        ptr_project__restore_state=Project.RESTORE_STATE_READY,
    ).first()
    if resource and resource.file:
        return redirect("serve_file_public", resource.file.hash)
    raise Http404("no such resource")


@user_passes_test(lambda user: user.is_superuser)
@never_cache
def task_results(request: HttpRequest) -> HttpResponse:
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "delete_successful_tasks":
            DBTaskResult.objects.filter(status="SUCCESSFUL").delete()
        elif action == "delete_failed_tasks":
            DBTaskResult.objects.filter(status="FAILED").delete()
        return redirect(request.get_full_path())

    fields = list(DBTaskResult._meta.fields)
    field_names = [field.name for field in fields]
    status_filter_values = ["SUCCESSFUL", "FAILED", "RUNNING", "READY"]
    task_path_filter_values = list(
        DBTaskResult.objects.order_by("task_path")
        .values_list("task_path", flat=True)
        .distinct()
    )
    valid_task_paths = set(task_path_filter_values)
    enqueued_at_date_filter_values = [
        d.isoformat()
        for d in DBTaskResult.objects.annotate(enqueued_date=TruncDate("enqueued_at"))
        .values_list("enqueued_date", flat=True)
        .order_by("-enqueued_date")
        .distinct()
        if d is not None
    ]
    valid_enqueued_at_dates = set(enqueued_at_date_filter_values)
    displayed_field_names = ["task_path", "enqueued_at", "status"]
    displayed_field_labels = {
        "task_path": "task_path",
        "enqueued_at": "enqueued_at (UTC)",
        "status": "status",
    }
    filter_values = {
        field_name: request.GET.get(f"f_{field_name}", "").strip()
        for field_name in field_names
    }
    if "f_status" not in request.GET:
        filter_values["status"] = "FAILED"
    enqueued_at_date_value = request.GET.get("f_enqueued_at_date", "").strip()
    # keep selected value aligned with displayed column filter state
    filter_values["enqueued_at"] = enqueued_at_date_value

    task_results_queryset = DBTaskResult.objects.all()
    if enqueued_at_date_value in valid_enqueued_at_dates:
        selected_date = parse_date(enqueued_at_date_value)
        if selected_date:
            task_results_queryset = task_results_queryset.filter(
                enqueued_at__date=selected_date
            )

    for idx, (field_name, filter_value) in enumerate(filter_values.items()):
        if not filter_value:
            continue
        if field_name == "enqueued_at":
            # this field is filtered with f_enqueued_at_from / f_enqueued_at_to
            continue
        if field_name == "status":
            if filter_value not in status_filter_values:
                continue
            task_results_queryset = task_results_queryset.filter(status=filter_value)
            continue
        if field_name == "task_path":
            if filter_value not in valid_task_paths:
                continue
            task_results_queryset = task_results_queryset.filter(task_path=filter_value)
            continue
        # cast any field type to text so filtering can be done uniformly
        alias = f"_as_text_{idx}"
        task_results_queryset = task_results_queryset.annotate(
            **{alias: Cast(F(field_name), output_field=TextField())}
        ).filter(**{f"{alias}__icontains": filter_value})

    sort = request.GET.get("sort", "-enqueued_at")
    sort_field = sort[1:] if sort.startswith("-") else sort
    if sort_field not in field_names:
        sort = "-enqueued_at" if "enqueued_at" in field_names else field_names[0]
        sort_field = sort[1:] if sort.startswith("-") else sort

    task_results_queryset = task_results_queryset.order_by(sort)
    sort_desc = sort.startswith("-")

    def build_query_string(**updates) -> str:
        query = request.GET.copy()
        for key, value in updates.items():
            if value is None:
                query.pop(key, None)
            else:
                query[key] = str(value)
        return query.urlencode()

    columns = [
        {
            "name": "details",
            "label": "details",
            "sort_link": None,
            "filter_value": "",
            "is_sorted": False,
            "sortable": False,
            "filterable": False,
        }
    ]
    for field_name in displayed_field_names:
        next_sort = (
            f"-{field_name}"
            if sort_field == field_name and not sort_desc
            else field_name
        )
        columns.append(
            {
                "name": field_name,
                "label": displayed_field_labels[field_name],
                "sort_link": build_query_string(sort=next_sort, page=1),
                "filter_value": filter_values[field_name],
                "is_sorted": sort_field == field_name,
                "sortable": True,
                "filterable": True,
            }
        )

    paginator = Paginator(task_results_queryset, 100)
    page_obj = paginator.get_page(request.GET.get("page"))
    rows = []
    for item in page_obj.object_list:
        row = [
            reverse("task_result_details", kwargs={"task_result_id": item.id}),
        ]
        row.extend(
            [getattr(item, field_name, None) for field_name in displayed_field_names]
        )
        rows.append(row)

    previous_page_link = None
    next_page_link = None
    if page_obj.has_previous():
        previous_page_link = build_query_string(page=page_obj.previous_page_number())
    if page_obj.has_next():
        next_page_link = build_query_string(page=page_obj.next_page_number())

    return render(
        request,
        "task_results.html",
        {
            "columns": columns,
            "rows": rows,
            "sort": sort,
            "sort_desc": sort_desc,
            "status_filter_values": status_filter_values,
            "task_path_filter_values": task_path_filter_values,
            "enqueued_at_date_filter_values": enqueued_at_date_filter_values,
            "page_obj": page_obj,
            "previous_page_link": previous_page_link,
            "next_page_link": next_page_link,
        },
    )


@user_passes_test(lambda user: user.is_superuser)
@never_cache
def task_result_details(request: HttpRequest, task_result_id) -> HttpResponse:
    task_result = get_object_or_404(DBTaskResult, pk=task_result_id)
    preferred_order = ["id", "task_path", "status", "enqueued_at"]
    utc_label_fields = {"enqueued_at", "started_at", "finished_at"}
    fields_by_name = {field.name: field for field in DBTaskResult._meta.fields}
    ordered_field_names = [name for name in preferred_order if name in fields_by_name]
    for field in DBTaskResult._meta.fields:
        if field.name not in ordered_field_names:
            ordered_field_names.append(field.name)

    detail_rows = []
    for field_name in ordered_field_names:
        detail_rows.append(
            {
                "name": f"{field_name} (UTC)"
                if field_name in utc_label_fields
                else field_name,
                "value": getattr(task_result, field_name, None),
            }
        )
    return render(
        request,
        "task_result_details.html",
        {"task_result": task_result, "detail_rows": detail_rows},
    )
