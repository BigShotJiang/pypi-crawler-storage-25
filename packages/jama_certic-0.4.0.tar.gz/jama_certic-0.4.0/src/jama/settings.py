from pathlib import Path
import os
import tempfile
from shutil import which
from dotenv import load_dotenv
import sys
import secrets
import string

for tool in [
    "vips",
    "convert",
    "exiftool",
    "pdftoppm",
    "pdftotext",
    "tesseract",
    "ffmpeg",
]:
    if not Path(which(tool) or "/does/not/exist").exists():
        sys.exit(f"Couldn't find tool {tool}, please read installation instructions.")


DEFAULT_AUTO_FIELD = "django.db.models.AutoField"
BASE_DIR = Path(__file__).resolve().parent.parent


def _default_env_file_content(secret: str, var_dir: Path) -> str:
    var_dir = Path(var_dir).resolve()
    tmp_dir = tempfile.gettempdir()
    settings_with_comments = [
        (
            "JAMA_VAR_DIR",
            str(var_dir),
            "Base directory for persistent JAMA data. To relocate this env file, "
            "set JAMA_VAR_DIR before startup.",
        ),
        ("JAMA_SECRET", secret, "Django secret key. Keep this value private."),
        (
            "JAMA_API_KEY_HASH_SECRET",
            secret,
            "Secret used to hash API keys stored in the database.",
        ),
        (
            "JAMA_DEBUG",
            "0",
            "Enable Django debug mode with 1. Do not enable in production.",
        ),
        (
            "JAMA_SITE",
            "http://localhost:8000/",
            "Public base URL used to build absolute URLs.",
        ),
        (
            "JAMA_URL_BASE_PATH",
            "",
            "URL prefix when JAMA is served from a subpath.",
        ),
        ("JAMA_ROOT_URL_REDIRECT", "", "Redirect target for the site root, if set."),
        (
            "JAMA_APPS",
            "",
            "Comma-separated list of additional Python apps to load.",
        ),
        ("JAMA_ADMINS", "", "Comma-separated list of Django administrators."),
        ("JAMA_MANAGERS", "", "Comma-separated list of Django managers."),
        ("JAMA_SHOW_RPC_DOCS", "0", "Expose RPC documentation on GET /rpc/ with 1."),
        (
            "JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS",
            "1",
            "Enable public download and serve URLs. Set to 0 to disable them.",
        ),
        (
            "JAMA_RPC_MAX_BODY_SIZE",
            str(1024 * 1024),
            "Maximum RPC JSON request body size in bytes. Set to 0 to disable.",
        ),
        (
            "JAMA_FILES_DIR",
            str((var_dir / "media_source_files").resolve()),
            "Directory containing original source files.",
        ),
        (
            "JAMA_PARTIAL_UPLOADS_DIR",
            str((var_dir / "partial_uploads").resolve()),
            "Directory used to store incomplete chunked uploads.",
        ),
        (
            "JAMA_UPLOAD_MAX_CHUNK_SIZE",
            str(128 * 1024**2),
            "Maximum accepted chunk size for partial uploads, in bytes.",
        ),
        (
            "JAMA_UPLOAD_MAX_TOTAL_CHUNKS",
            "10000",
            "Maximum number of chunks accepted for one upload.",
        ),
        (
            "JAMA_TMP_THUMBNAILS_DIR",
            tmp_dir,
            "Directory used to cache temporary thumbnails.",
        ),
        (
            "JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS",
            str(7 * 24 * 60 * 60),
            "Maximum temporary thumbnail age before cleanup. Set to 0 to disable.",
        ),
        (
            "JAMA_THUMBNAIL_MAX_SIZE",
            "2000",
            "Maximum size accepted by the simple thumbnail endpoint.",
        ),
        (
            "JAMA_THUMBNAIL_MAX_CROP_PIXELS",
            "100000",
            "Maximum crop margin accepted by the thumbnail endpoint.",
        ),
        (
            "JAMA_MAX_IMAGE_PIXELS",
            str(10000 * 10000),
            "Maximum number of pixels Pillow accepts when opening an image.",
        ),
        (
            "JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS",
            str(30 * 60),
            "Timeout for media tools such as ffmpeg, vips and tesseract. "
            "Set to 0 to disable.",
        ),
        (
            "JAMA_STATIC_ROOT",
            str((var_dir / "static").resolve()),
            "Destination directory for Django collectstatic.",
        ),
        (
            "JAMA_DB_ADAPTER",
            "sqlite",
            "Database adapter. Use sqlite or PostgreSQL settings.",
        ),
        (
            "JAMA_SQLITE_DB_PATH",
            str((var_dir / "db.sqlite3").resolve()),
            "SQLite database path when JAMA_DB_ADAPTER=sqlite.",
        ),
        (
            "JAMA_USE_POSTGIS",
            "0",
            "Use the PostGIS backend with PostgreSQL when set to 1.",
        ),
        ("JAMA_DB_HOST", "localhost", "PostgreSQL host when not using SQLite."),
        ("JAMA_DB_PORT", "5432", "PostgreSQL port when not using SQLite."),
        ("JAMA_DB_NAME", "django", "PostgreSQL database name when not using SQLite."),
        ("JAMA_DB_USER", "django", "PostgreSQL user when not using SQLite."),
        ("JAMA_DB_PASSWORD", "django", "PostgreSQL password when not using SQLite."),
        (
            "JAMA_CACHE_BACKEND",
            "file",
            "Cache backend. Use memcached to select Memcached.",
        ),
        (
            "JAMA_IIIF_DIR",
            str((var_dir / "iiif").resolve()),
            "Directory containing tiled files served by the IIIF server.",
        ),
        (
            "JAMA_IIIF_PROCESSING_DIR",
            str((var_dir / "processing").resolve()),
            "Temporary directory used while generating IIIF files.",
        ),
        (
            "JAMA_IIIF_ENDPOINT",
            "http://localhost/iip/IIIF=",
            "Public IIIF endpoint used to build client URLs.",
        ),
        (
            "JAMA_IIIF_UPSTREAM_URL",
            "http://localhost/iip/IIIF=",
            "Upstream IIIF endpoint used by the built-in proxy.",
        ),
        (
            "JAMA_IIIF_UPSCALING_PREFIX",
            "^",
            "IIIF resize prefix used when generating upscaling URLs.",
        ),
        (
            "JAMA_IIIF_PATH_SEPARATOR",
            os.path.sep,
            "Separator used to build IIIF paths from file hashes.",
        ),
        (
            "JAMA_IIIF_URLS_NEED_AUTH",
            "0",
            "Require read permission checks on proxied IIIF URLs with 1.",
        ),
        (
            "JAMA_USE_WEBP",
            "1",
            "Generate IIIF pyramids with WebP compression when possible.",
        ),
        (
            "JAMA_HLS_DIR",
            str((var_dir / "hls").resolve()),
            "Directory containing generated HLS video outputs.",
        ),
        (
            "JAMA_HLS_ENDPOINT",
            "http://localhost:8000/hls/",
            "Public HLS endpoint used to build client URLs.",
        ),
        (
            "JAMA_HLS_URLS_NEED_AUTH",
            "0",
            "Require authentication and read permission checks on HLS files with 1.",
        ),
        ("JAMA_USE_ARK", "0", "Enable ARK routes with 1."),
        ("JAMA_ARK_SERVER", "", "ARK service server URL or identifier."),
        ("JAMA_ARK_APP_ID", "", "Application identifier for the ARK service."),
        ("JAMA_ARK_SECRET_KEY", "", "Application secret for the ARK service."),
        ("JAMA_USE_MODSHIB", "1", "Load ModShib authentication support with 1."),
        ("JAMA_UI_ANNOTATIONS", "0", "Enable annotation features in the UI with 1."),
        ("JAMA_UI_TITLE", "JAMA UI", "Title displayed by the UI application."),
        (
            "JAMA_PERIODIC_FILE_INTEGRITY_CHECK",
            "0",
            "Enable the periodic file integrity check task with 1.",
        ),
        (
            "JAMA_XLSX_EXPORT_AUTOMATIC_METADATAS",
            "0",
            "Include automatic metadata such as OCR and ExifTool in XLSX exports.",
        ),
    ]
    lines = [
        "# JAMA environment configuration",
        "#",
        "# This file was generated because it did not exist in JAMA_VAR_DIR.",
        '# Boolean values generally use "1" for enabled and "0" for disabled.',
        "",
    ]
    for name, value, comment in settings_with_comments:
        lines.append(f"# {comment}")
        lines.append(f"{name}={value}")
        lines.append("")
    return "\n".join(lines)


VAR_DIR = os.getenv("JAMA_VAR_DIR") or Path(Path.home(), ".jama")
VAR_DIR = Path(VAR_DIR).resolve()

os.makedirs(VAR_DIR, exist_ok=True)
env_file = Path(VAR_DIR, "env")
if not env_file.exists():
    secret = "".join(secrets.choice(string.ascii_letters) for _ in range(32))
    with open(env_file, "w", encoding="utf-8") as f:
        f.write(_default_env_file_content(secret, VAR_DIR))
load_dotenv(env_file)

if os.getenv("GDAL_LIBRARY_PATH"):
    GDAL_LIBRARY_PATH = os.getenv("GDAL_LIBRARY_PATH")

if os.getenv("GEOS_LIBRARY_PATH"):
    GEOS_LIBRARY_PATH = os.getenv("GEOS_LIBRARY_PATH")


MODSHIB_CREATE_ACCOUNT = True if os.getenv("MODSHIB_CREATE_ACCOUNT") == "1" else False
JAMA_SHOW_RPC_DOCS = False if os.getenv("JAMA_SHOW_RPC_DOCS") != "1" else True
JAMA_PERIODIC_FILE_INTEGRITY_CHECK = (
    True if os.getenv("JAMA_PERIODIC_FILE_INTEGRITY_CHECK") == "1" else False
)
JAMA_USE_POSTGIS = True if os.getenv("JAMA_USE_POSTGIS") == "1" else False
JAMA_ROOT_URL_REDIRECT = os.getenv("JAMA_ROOT_URL_REDIRECT")
JAMA_CACHE_BACKEND = os.getenv("JAMA_CACHE_BACKEND") or "file"
JAMA_DB_ADAPTER = os.getenv("JAMA_DB_ADAPTER") or "sqlite"
JAMA_URL_BASE_PATH = os.getenv("JAMA_URL_BASE_PATH") or ""
JAMA_USE_MODSHIB = True if os.getenv("JAMA_USE_MODSHIB", "1") == "1" else False
JAMA_USE_WEBP = True if os.getenv("JAMA_USE_WEBP", "1") == "1" else False
JAMA_USE_ARK = True if os.getenv("JAMA_USE_ARK", "0") == "1" else False
JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS = (
    False if os.getenv("JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS", "1") == "0" else True
)
JAMA_RPC_MAX_BODY_SIZE = int(os.getenv("JAMA_RPC_MAX_BODY_SIZE", 1024 * 1024))
JAMA_UPLOAD_MAX_CHUNK_SIZE = int(os.getenv("JAMA_UPLOAD_MAX_CHUNK_SIZE", 128 * 1024**2))
JAMA_UPLOAD_MAX_TOTAL_CHUNKS = int(os.getenv("JAMA_UPLOAD_MAX_TOTAL_CHUNKS", 10000))
JAMA_THUMBNAIL_MAX_SIZE = int(os.getenv("JAMA_THUMBNAIL_MAX_SIZE", 2000))
JAMA_THUMBNAIL_MAX_CROP_PIXELS = int(
    os.getenv("JAMA_THUMBNAIL_MAX_CROP_PIXELS", 100000)
)
JAMA_MAX_IMAGE_PIXELS = int(os.getenv("JAMA_MAX_IMAGE_PIXELS", 10000 * 10000))
JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS = int(
    os.getenv("JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS", 7 * 24 * 60 * 60)
)
JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS = int(
    os.getenv("JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS", 30 * 60)
)
JAMA_SQLITE_DB_PATH = os.getenv("JAMA_SQLITE_DB_PATH") or Path(VAR_DIR, "db.sqlite3")
JAMA_ADMINS = (
    os.getenv("JAMA_ADMINS", "").split(",") if os.getenv("JAMA_ADMINS") else []
)
JAMA_MANAGERS = (
    os.getenv("JAMA_MANAGERS", "").split(",") if os.getenv("JAMA_MANAGERS") else []
)
JAMA_XLSX_EXPORT_AUTOMATIC_METADATAS = (
    True if os.getenv("JAMA_XLSX_EXPORT_AUTOMATIC_METADATAS", "0") == "1" else False
)
JAMA_IIIF_PROCESSING_DIR = os.getenv(
    "JAMA_IIIF_PROCESSING_DIR", Path(VAR_DIR, "processing")
)
PARTIAL_UPLOADS_DIR = os.getenv("JAMA_PARTIAL_UPLOADS_DIR") or str(
    Path(VAR_DIR, "partial_uploads").resolve()
)
os.makedirs(PARTIAL_UPLOADS_DIR, exist_ok=True)

MEDIA_FILES_DIR = os.getenv("JAMA_FILES_DIR") or str(
    Path(VAR_DIR, "media_source_files").resolve()
)
os.makedirs(MEDIA_FILES_DIR, exist_ok=True)

TMP_THUMBNAILS_DIR = os.getenv("JAMA_TMP_THUMBNAILS_DIR") or tempfile.gettempdir()

ADMINS = JAMA_ADMINS
MANAGERS = JAMA_MANAGERS

JAMA_SITE = os.getenv("JAMA_SITE") or "http://localhost:8000/"

JAMA_IIIF_UPSCALING_PREFIX = (
    os.getenv("JAMA_IIIF_UPSCALING_PREFIX")
    if os.getenv("JAMA_IIIF_UPSCALING_PREFIX") is not None
    else "^"
)
IIIF_DIR = os.getenv("JAMA_IIIF_DIR") or str(Path(VAR_DIR, "iiif").resolve())
os.makedirs(IIIF_DIR, exist_ok=True)
IIIF_PATH_SEPARATOR = os.getenv("JAMA_IIIF_PATH_SEPARATOR") or os.path.sep
IIIF_URLS_NEED_AUTH = (
    False if os.getenv("JAMA_IIIF_URLS_NEED_AUTH", "0") == "0" else True
)

HLS_DIR = os.getenv("JAMA_HLS_DIR") or str(Path(VAR_DIR, "hls").resolve())
os.makedirs(HLS_DIR, exist_ok=True)
HLS_URLS_NEED_AUTH = False if os.getenv("JAMA_HLS_URLS_NEED_AUTH", "0") == "0" else True

ARK_SERVER = os.getenv("JAMA_ARK_SERVER", "")
ARK_APP_ID = os.getenv("JAMA_ARK_APP_ID", "")
ARK_SECRET_KEY = os.getenv("JAMA_ARK_SECRET_KEY", "")
CACHE_FILE_LOCATION = os.getenv("CACHE_LOCATION", str(Path(VAR_DIR, "cache").resolve()))
CACHE_FILE_LOCATION = Path(CACHE_FILE_LOCATION).resolve()
os.makedirs(CACHE_FILE_LOCATION, exist_ok=True)

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = (
    os.getenv("JAMA_SECRET") or "7d*_8c!d$vv963qpr45_x)@f2t-x6fu2&yi+m+d6s!p!lt+_j+"
)
JAMA_API_KEY_HASH_SECRET = os.getenv("JAMA_API_KEY_HASH_SECRET") or SECRET_KEY

# SECURITY WARNING: don't run with debug  on in production!
DEBUG = True if os.getenv("JAMA_DEBUG") == "1" else False

# This is the IIIF endpoint used to build manifests URLS
JAMA_IIIF_ENDPOINT = os.getenv("JAMA_IIIF_ENDPOINT") or "http://localhost/iip/IIIF="
# This is the IIIF endpoint used to proxy requests to the IIIF server
JAMA_IIIF_UPSTREAM_URL = os.getenv("JAMA_IIIF_UPSTREAM_URL") or JAMA_IIIF_ENDPOINT
ALLOWED_HOSTS = ["*"]
CSRF_TRUSTED_ORIGINS = [JAMA_SITE[:-1]]

JAMA_HLS_ENDPOINT = os.getenv("JAMA_HLS_ENDPOINT") or "http://localhost:8000/hls/"

JAMA_UI_ANNOTATIONS = True if os.getenv("JAMA_UI_ANNOTATIONS") == "1" else False
JAMA_UI_TITLE = os.getenv("JAMA_UI_TITLE") or "JAMA UI"
# Application definition

INSTALLED_APPS = [
    "corsheaders",
    "resources.apps.ResourcesConfig",
    "rpc.apps.RpcConfig",
    "django.contrib.auth",
    "revproxy.apps.RevProxyConfig",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django_tasks_db",
    "crontask",
    "authcli.apps.AuthcliConfig",
    "annotations.apps.AnnotationsConfig",
    "jama.apps.JamaConfig",
    "django_extensions",
    "django.contrib.humanize",
    "iiif.apps.IiifConfig",
    "hls.apps.HlsConfig",
]


AUTO_REGISTER_APPS = []
STATICFILES_DIRS = []
for app in os.getenv("JAMA_APPS", "").split(","):
    app = app.strip()
    if app:
        if app == "bibnum":
            INSTALLED_APPS.append("django_vite")
        INSTALLED_APPS.append(f"{app}.apps.{app.capitalize()}Config")
        AUTO_REGISTER_APPS.append(app)


if JAMA_USE_MODSHIB:
    MODSHIB_SHOW_LOCAL_LOGIN = (
        True if os.getenv("MODSHIB_SHOW_LOCAL_LOGIN", "1") == "1" else False
    )
    MODSHIB_SHOW_SSO_LOGIN = (
        True if os.getenv("MODSHIB_SHOW_SSO_LOGIN", "0") == "1" else False
    )
    MODSHIB_CHECK_CGU = os.getenv("MODSHIB_CHECK_CGU", False)
    MODSHIB_FORMS_TITLE = os.getenv("MODSHIB_FORMS_TITLE", "Authentification")

    MODSHIB_SSO_LOGOUT_REDIRECT_URL = os.getenv("MODSHIB_SSO_LOGOUT_REDIRECT_URL", "")

    MODSHIB_SSO_SUBMIT_LABEL = os.getenv(
        "MODSHIB_SSO_SUBMIT_LABEL", "Connexion via SSO"
    )
    MODSHIB_LOCAL_SUBMIT_LABEL = os.getenv(
        "MODSHIB_LOCAL_SUBMIT_LABEL", "Connexion avec mot de passe"
    )
    MODSHIB_STYLESHEET_URL = os.getenv("MODSHIB_STYLESHEET_URL")
    INSTALLED_APPS.append("modshib.apps.ModshibConfig")

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

CORS_ALLOW_ALL_ORIGINS = True

CORS_ALLOW_HEADERS = [
    "accept",
    "accept-encoding",
    "authorization",
    "content-type",
    "dnt",
    "origin",
    "user-agent",
    "x-csrftoken",
    "x-requested-with",
    "X-Api-Key",
    "X-file-chunk",
    "X-file-hash",
    "X-file-name",
    "X-origin-dir",
    "X-Project",
]

ROOT_URLCONF = "jama.urls"

context_processors = [
    "django.template.context_processors.debug",
    "django.template.context_processors.request",
    "django.contrib.auth.context_processors.auth",
    "django.contrib.messages.context_processors.messages",
]

if JAMA_USE_MODSHIB:
    context_processors.append("modshib.context_processors.modshib_context")

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": context_processors,
        },
    },
]

WSGI_APPLICATION = "jama.wsgi.application"


if JAMA_DB_ADAPTER == "sqlite":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": JAMA_SQLITE_DB_PATH,
            "OPTIONS": {
                "init_command": (
                    "PRAGMA foreign_keys=ON;"
                    "PRAGMA journal_mode = WAL;"
                    "PRAGMA synchronous = NORMAL;"
                    "PRAGMA busy_timeout = 5000;"
                    "PRAGMA temp_store = MEMORY;"
                    "PRAGMA mmap_size = 134217728;"
                    "PRAGMA journal_size_limit = 67108864;"
                    "PRAGMA cache_size = 2000;"
                ),
                "transaction_mode": "IMMEDIATE",
            },
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.contrib.gis.db.backends.postgis"
            if JAMA_USE_POSTGIS
            else "django.db.backends.postgresql",
            "HOST": os.getenv("JAMA_DB_HOST") or "localhost",
            "PORT": os.getenv("JAMA_DB_PORT") or "5432",
            "NAME": os.getenv("JAMA_DB_NAME") or "django",
            "USER": os.getenv("JAMA_DB_USER") or "django",
            "PASSWORD": os.getenv("JAMA_DB_PASSWORD") or "django",
        }
    }


AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]


LANGUAGE_CODE = "fr-fr"

TIME_ZONE = "UTC"

USE_I18N = True

USE_L10N = True

USE_TZ = True


STATIC_ROOT = os.getenv("JAMA_STATIC_ROOT") or Path(VAR_DIR, "static")
STATIC_URL = JAMA_URL_BASE_PATH + "/static/"


def ignore_spammy_task_logs(record):
    """
    Silences log messages for certain especially spammy tasks.
    (see https://github.com/codingjoe/django-crontask/discussions/18 )
    """
    # NOTE: If you need to debug this function by adding print statements, you MUST
    # use print("message", flush=True), or your prints will never appear.
    spammy_task_messages = [
        # These get emitted every 5 seconds due to an implementation detail in django-crontask.
        "crontask.utils.lock.extend",
        # This hides all but the ﮩ٨ـﮩﮩ٨ـ♡ﮩ٨ـﮩﮩ٨ـ log from our custom heartbeat task.
        "heartbeat_task",
        # ProxyView messages
        "ProxyView created",
        "Normalizing response headers",
        "Checking for invalid cookies",
        "Starting streaming HTTP Response",
    ]
    return not any(message in record.getMessage() for message in spammy_task_messages)


LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "console": {"format": "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"},
        "file": {"format": "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"},
    },
    "filters": {
        "ignore_spammy_task_logs": {
            "()": "django.utils.log.CallbackFilter",
            "callback": ignore_spammy_task_logs,
        },
    },
    "handlers": {
        "console": {
            "level": "INFO",
            "class": "logging.StreamHandler",
            "formatter": "console",
            "filters": ["ignore_spammy_task_logs"],
        },
    },
    "loggers": {
        "": {"level": "INFO", "handlers": ["console"]},
    },
}

INTERNAL_IPS = [
    "127.0.0.1",
]

TASKS = {
    "default": {"BACKEND": "django_tasks_db.DatabaseBackend", "QUEUES": ["default"]}
}

if JAMA_CACHE_BACKEND == "memcached":
    CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.memcached.PyMemcacheCache",
            "LOCATION": "127.0.0.1:11211",
        }
    }
else:
    CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.filebased.FileBasedCache",
            "LOCATION": CACHE_FILE_LOCATION,
            "OPTIONS": {"MAX_ENTRIES": 10000},
        }
    }

LOGIN_REDIRECT_URL = "/ui/"

if "bibnum" in AUTO_REGISTER_APPS:
    DJANGO_VITE_DEV_MODE = DEBUG
    DJANGO_VITE_STATIC_URL_PREFIX = "bibnum"

if "ui" in AUTO_REGISTER_APPS:
    STATICFILES_DIRS.append(Path(BASE_DIR, "ui", "front", "dist"))
