from django.core.management.base import BaseCommand
from resources.models import Role, ObjectPermission


class Command(BaseCommand):
    def handle(self, *args, **options):
        for role in Role.objects.all():
            for perm in role.permissions.order_by("label"):
                object_class, crud_right = perm.label.split(".")
                object_permission, _ = ObjectPermission.objects.get_or_create(
                    object_class=object_class, role=role
                )
                if crud_right == "create":
                    object_permission.object_create = True
                if crud_right == "read":
                    object_permission.object_read = True
                if crud_right == "update":
                    object_permission.object_update = True
                if crud_right == "delete":
                    object_permission.object_delete = True
                object_permission.save()
                print(object_class, " -> ", crud_right)
