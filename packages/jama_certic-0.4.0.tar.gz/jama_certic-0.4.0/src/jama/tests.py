import json
from pathlib import Path

from django.contrib.auth.models import User
from django.db import connection
from django.test import RequestFactory, SimpleTestCase, TestCase
from django.test.utils import CaptureQueriesContext

from jama import settings as jama_settings
from annotations.models import Annotation
from jama.iiif import serialize_jama_collection
from resources.models import Collection, CollectionMembership, File, FileType, Project


class SettingsEnvTemplateTestCase(SimpleTestCase):
    def test_default_env_file_content_lists_jama_settings_with_comments(self):
        var_dir = Path("/tmp/jama").resolve()
        content = jama_settings._default_env_file_content("testsecret", var_dir)
        expected_settings = [
            "JAMA_VAR_DIR",
            "JAMA_SECRET",
            "JAMA_DEBUG",
            "JAMA_SITE",
            "JAMA_URL_BASE_PATH",
            "JAMA_ROOT_URL_REDIRECT",
            "JAMA_APPS",
            "JAMA_ADMINS",
            "JAMA_MANAGERS",
            "JAMA_SHOW_RPC_DOCS",
            "JAMA_ENABLE_PUBLIC_DOWNLOAD_URLS",
            "JAMA_RPC_MAX_BODY_SIZE",
            "JAMA_FILES_DIR",
            "JAMA_PARTIAL_UPLOADS_DIR",
            "JAMA_UPLOAD_MAX_CHUNK_SIZE",
            "JAMA_UPLOAD_MAX_TOTAL_CHUNKS",
            "JAMA_TMP_THUMBNAILS_DIR",
            "JAMA_TMP_THUMBNAILS_MAX_AGE_SECONDS",
            "JAMA_THUMBNAIL_MAX_SIZE",
            "JAMA_THUMBNAIL_MAX_CROP_PIXELS",
            "JAMA_MAX_IMAGE_PIXELS",
            "JAMA_MEDIA_SUBPROCESS_TIMEOUT_SECONDS",
            "JAMA_STATIC_ROOT",
            "JAMA_DB_ADAPTER",
            "JAMA_SQLITE_DB_PATH",
            "JAMA_USE_POSTGIS",
            "JAMA_DB_HOST",
            "JAMA_DB_PORT",
            "JAMA_DB_NAME",
            "JAMA_DB_USER",
            "JAMA_DB_PASSWORD",
            "JAMA_CACHE_BACKEND",
            "JAMA_IIIF_DIR",
            "JAMA_IIIF_PROCESSING_DIR",
            "JAMA_IIIF_ENDPOINT",
            "JAMA_IIIF_UPSTREAM_URL",
            "JAMA_IIIF_UPSCALING_PREFIX",
            "JAMA_IIIF_PATH_SEPARATOR",
            "JAMA_IIIF_URLS_NEED_AUTH",
            "JAMA_USE_WEBP",
            "JAMA_HLS_DIR",
            "JAMA_HLS_ENDPOINT",
            "JAMA_HLS_URLS_NEED_AUTH",
            "JAMA_USE_ARK",
            "JAMA_ARK_SERVER",
            "JAMA_ARK_APP_ID",
            "JAMA_ARK_SECRET_KEY",
            "JAMA_USE_MODSHIB",
            "JAMA_UI_ANNOTATIONS",
            "JAMA_UI_TITLE",
            "JAMA_PERIODIC_FILE_INTEGRITY_CHECK",
            "JAMA_XLSX_EXPORT_AUTOMATIC_METADATAS",
        ]

        lines = content.splitlines()
        for setting in expected_settings:
            self.assertIn(f"{setting}=", content)
            setting_line_index = next(
                index
                for index, line in enumerate(lines)
                if line.startswith(f"{setting}=")
            )
            self.assertTrue(lines[setting_line_index - 1].startswith("# "))
        self.assertIn("JAMA_SECRET=testsecret", content)
        self.assertIn(f"JAMA_FILES_DIR={var_dir / 'media_source_files'}", content)


class IiifSerializationTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.project = Project.objects.create(
            label="iiif project", description="iiif project"
        )
        self.collection = Collection.objects.create(
            title="root", parent=None, project=self.project
        )
        self.file_type = FileType.objects.create(
            title="image", mime="image/jpeg", serve_with_iiif=True
        )
        self.owner = User.objects.create(
            username="annotator", first_name="Ada", last_name="Lovelace"
        )

    def test_serialize_jama_collection_batches_files_and_annotations(self):
        first_file = File.objects.create(
            title="page 1",
            original_name="page-1.jpg",
            project=self.project,
            hash="aa" * 32,
            file_type=self.file_type,
            size=100,
            denormalized_image_width=1200,
            denormalized_image_height=800,
        )
        second_file = File.objects.create(
            title="page 2",
            original_name="page-2.jpg",
            project=self.project,
            hash="bb" * 32,
            file_type=self.file_type,
            size=100,
            denormalized_image_width=1600,
            denormalized_image_height=900,
        )
        CollectionMembership.objects.create(
            collection=self.collection, resource=first_file, rank=1
        )
        CollectionMembership.objects.create(
            collection=self.collection, resource=second_file, rank=2
        )
        Annotation.objects.create(
            resource=first_file,
            owner=self.owner,
            data={
                "svg": '<rect x="1" y="2" width="3" height="4" />',
                "bodies": [{"title": "Note", "contents": "Alpha"}],
            },
        )
        Annotation.objects.create(
            resource=second_file,
            owner=self.owner,
            data={"svg": "", "bodies": [{"motivation": "tagging", "contents": {}}]},
        )

        request = self.factory.get("/iiif/manifest/")

        with CaptureQueriesContext(connection) as queries:
            response = serialize_jama_collection(request, self.collection)

        payload = json.loads(response.content)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(payload["items"]), 2)
        self.assertEqual(payload["items"][0]["width"], 1200)
        self.assertEqual(
            payload["items"][0]["annotations"][0]["items"][0]["creator"],
            "Ada Lovelace",
        )
        self.assertLessEqual(len(queries), 5)
