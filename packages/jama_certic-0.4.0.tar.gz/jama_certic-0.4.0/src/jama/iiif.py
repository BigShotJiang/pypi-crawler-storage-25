from annotations.models import Annotation
from collections import defaultdict
from django.http import HttpResponse, HttpRequest, JsonResponse
from django.db.models import prefetch_related_objects
from resources.models import Collection, File, Resource, hash_to_iiif_path
from django.conf import settings


def serialize_jama_collection(
    request: HttpRequest, collection_instance: Collection
) -> HttpResponse:
    resources = list(collection_instance.descendants_resources())
    if resources:
        prefetch_related_objects(resources, "file__file_type")

    annotations_by_resource_id = _annotations_by_resource_id(resources)
    items = []
    metadata = []  # @todo
    collection_title = collection_instance.title

    for resource_instance in resources:
        file_instance = _file_for_resource(resource_instance)
        if not file_instance or not file_instance.file_type.serve_with_iiif:
            continue
        items.append(
            serialize_jama_resource(
                resource_instance,
                file_instance=file_instance,
                annotations=annotations_by_resource_id.get(resource_instance.pk, []),
            )
        )

    return JsonResponse(
        {
            "@context": "http://iiif.io/api/presentation/3/context.json",
            "id": request.build_absolute_uri(),
            "type": "Manifest",
            "label": {"en": [collection_title]},
            "metadata": metadata,
            "items": items,
        },
        json_dumps_params={"indent": 2},
    )


def serialize_jama_resource(
    resource_instance: Resource,
    *,
    file_instance: File = None,
    annotations: list[Annotation] = None,
) -> dict:
    file_instance = file_instance or _file_for_resource(resource_instance)
    if not file_instance:
        raise File.DoesNotExist(f"resource({resource_instance.pk}) has no file")

    resource_id = resource_instance.pk
    canvas_id = (
        f"{settings.JAMA_SITE}iiif/canvas/{resource_instance.ark}"
        if resource_instance.ark
        else f"{settings.JAMA_SITE}iiif/canvas/{resource_id}"
    )
    page_id = f"{canvas_id}/page/{resource_id}"
    image_id = "{}{}/".format(
        settings.JAMA_IIIF_ENDPOINT,
        hash_to_iiif_path(file_instance.hash, settings.IIIF_PATH_SEPARATOR),
    )
    image_url = f"{image_id}full/max/0/default.jpg"
    width = file_instance.denormalized_image_width
    height = file_instance.denormalized_image_height
    if width is None:
        width = file_instance.image_width()
    if height is None:
        height = file_instance.image_height()
    metadata = []  # @todo
    annotation_page_id = f"{settings.JAMA_SITE}iiif/annotations/page/{resource_id}"
    serialized_annotations = _serialize_jama_resource_annotations(
        annotations or _annotations_for_resource(resource_instance.pk), canvas_id
    )
    resource_label = resource_instance.title
    return {
        "id": canvas_id,
        "type": "Canvas",
        "label": {"fr": [resource_label]},
        "height": height,
        "width": width,
        "metadata": metadata,
        "items": [
            {
                "id": page_id,
                "type": "AnnotationPage",
                "items": [
                    {
                        "id": image_id,
                        "type": "Annotation",
                        "motivation": "painting",
                        "body": {
                            "id": image_url,
                            "type": "Image",
                            "format": "image/jpeg",
                            "height": height,
                            "width": width,
                            "service": [
                                {
                                    "id": image_id,
                                    "profile": "level1",
                                    "type": "ImageService3",
                                }
                            ],
                        },
                        "target": canvas_id,
                    }
                ],
            }
        ],
        "annotations": [
            {
                "id": annotation_page_id,
                "type": "AnnotationPage",
                "items": serialized_annotations,
            }
        ],
    }


def _serialize_jama_resource_annotations(
    annotations: list[Annotation], canvas_id: str
) -> list[dict]:
    annotations_list = []
    for annotation in annotations:
        annotation_id = f"{settings.JAMA_SITE}iiif/annotation/{annotation.id}"
        creator = _annotation_creator(annotation)
        annotations_list.append(
            {
                "id": annotation_id,
                "type": "Annotation",
                "creator": creator,
                "motivation": "commenting",
                "body": _extract_annotation_bodies(annotation),
                "target": {
                    "source": canvas_id,
                    "selector": {
                        "type": "SvgSelector",
                        "value": f"<svg>{annotation.data.get('svg', '')}</svg>",
                    },
                },
            }
        )
    return annotations_list


def _annotations_by_resource_id(
    resources: list[Resource],
) -> dict[int, list[Annotation]]:
    annotations_by_resource_id = defaultdict(list)
    resource_ids = [resource.pk for resource in resources]
    if not resource_ids:
        return annotations_by_resource_id

    for annotation in (
        Annotation.objects.filter(resource_id__in=resource_ids)
        .select_related("owner")
        .order_by("created_at")
    ):
        annotations_by_resource_id[annotation.resource_id].append(annotation)

    return annotations_by_resource_id


def _annotations_for_resource(resource_id: int) -> list[Annotation]:
    return list(
        Annotation.objects.filter(resource_id=resource_id)
        .select_related("owner")
        .order_by("created_at")
    )


def _file_for_resource(resource_instance: Resource) -> File | None:
    if isinstance(resource_instance, File):
        return resource_instance
    try:
        return resource_instance.file
    except File.DoesNotExist:
        return None


def _annotation_creator(annotation: Annotation) -> str:
    return "{} {}".format(
        annotation.owner.first_name if annotation.owner.first_name else "",
        annotation.owner.last_name if annotation.owner.last_name else "",
    ).strip()


def _extract_annotation_bodies(annotation: Annotation) -> list[dict]:
    bodies = []
    creator = _annotation_creator(annotation)
    for body in annotation.data.get("bodies", []):
        bodies.append(
            {
                "type": "TextualBody",
                "language": "en",
                "format": "text/html",
                "purpose": body.get("motivation", "commenting").lower(),
                "value": body.get("contents", {}).get("label")
                if body.get("motivation", "commenting").lower() == "tagging"
                else f"<div><h1>{body.get('title', '')}</h1>{body.get('contents', '')} <p>({creator})</p></div>",
            }
        )
    return bodies
