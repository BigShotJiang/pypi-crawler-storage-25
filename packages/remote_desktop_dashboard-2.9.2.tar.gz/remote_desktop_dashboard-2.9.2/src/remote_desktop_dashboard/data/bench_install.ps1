# RDD Bench Agent installer (pure PowerShell, no Python needed).
#
# This script:
#   1. Writes config.json + bench_agent.ps1 into C:\ProgramData\RDD-Bench-Agent\
#   2. Locks the config to SYSTEM + Administrators only
#   3. Registers a scheduled task running as SYSTEM at startup
#
# Run as Administrator. Token and dashboard URL are substituted by the
# dashboard server when it serves this file.

$ErrorActionPreference = "Stop"

$DashboardUrl  = "{{DASHBOARD_URL}}"
$Token         = "{{TOKEN}}"
$MachineName   = if ($env:RDD_BENCH_MACHINE) { $env:RDD_BENCH_MACHINE } else { $env:COMPUTERNAME }
$InstallRoot   = "C:\ProgramData\RDD-Bench-Agent"
$AgentPath     = Join-Path $InstallRoot "bench_agent.ps1"
$ConfigPath    = Join-Path $InstallRoot "config.json"
$TaskName      = "RDD-Bench-Agent"

Write-Host "==> RDD Bench Agent install" -ForegroundColor Cyan
Write-Host "    Dashboard : $DashboardUrl"
Write-Host "    Machine   : $MachineName"
Write-Host "    Install   : $InstallRoot"

if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run this command in an ELEVATED PowerShell (Run as Administrator)."
}

New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null

# 1. config.json (overwritten on every install)
$config = [ordered]@{
    dashboard_url = $DashboardUrl
    machine_name  = $MachineName
    token         = $Token
    poll_seconds  = 5
} | ConvertTo-Json
Set-Content -Path $ConfigPath -Value $config -Encoding UTF8

# 2. bench_agent.ps1 — download if missing OR if dashboard's copy is newer.
#    (If the dashboard server has pushed it ahead of time, this is a no-op.)
if (-not (Test-Path $AgentPath)) {
    Write-Host "==> Downloading agent script from dashboard..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri "$DashboardUrl/agent/bench_agent.ps1" `
                      -OutFile $AgentPath -UseBasicParsing
}

# 3. Lock down the config (SYSTEM + Administrators only)
$acl = Get-Acl $ConfigPath
$acl.SetAccessRuleProtection($true, $false)
$rules = @(
    New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM","FullControl","Allow"),
    New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators","FullControl","Allow")
)
foreach ($r in $rules) { $acl.AddAccessRule($r) }
Set-Acl $ConfigPath $acl

# 4. Register / refresh the scheduled task
Write-Host "==> Registering scheduled task '$TaskName' as SYSTEM..." -ForegroundColor Cyan
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

$pwsh      = (Get-Command powershell.exe).Source
$action    = New-ScheduledTaskAction `
                -Execute $pwsh `
                -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$AgentPath`""
$trigger1  = New-ScheduledTaskTrigger -AtStartup
$trigger2  = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(15) `
                -RepetitionInterval (New-TimeSpan -Minutes 5) `
                -RepetitionDuration ([TimeSpan]::FromDays(365 * 5))
$principal = New-ScheduledTaskPrincipal `
                -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable `
                -RestartCount 9999 -RestartInterval (New-TimeSpan -Minutes 1) `
                -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                -MultipleInstances IgnoreNew

Register-ScheduledTask -TaskName $TaskName `
    -Action $action -Trigger @($trigger1, $trigger2) `
    -Principal $principal -Settings $settings | Out-Null

# 5. Kick off now
Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 3

Write-Host ""
Write-Host "RDD Bench Agent installed and started." -ForegroundColor Green
Write-Host "Logs: $InstallRoot\bench-agent.log"
