"""Pydantic schemas for the bench-side agent."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class BenchAccessResponse(BaseModel):
    """Returned to the bench agent on every poll."""

    machine_name: str
    locked: bool
    locked_by: str | None = None
    allow_users: list[str] = Field(default_factory=list)
    kick_other_sessions: bool = True
    poll_seconds: int = 5
    server_version: str = ""


class BenchHeartbeat(BaseModel):
    """Sent by the bench agent every poll."""

    agent_version: str
    applied_users: list[str] = Field(default_factory=list)
    current_rdp_users: list[str] = Field(default_factory=list)
    error: str | None = None
    os: str | None = None
    hostname: str | None = None


class BenchAgentStatus(BaseModel):
    """Used by the UI to show one machine's agent state."""

    machine_name: str
    installed: bool
    version: str | None = None
    last_seen: datetime | None = None
    last_seen_seconds_ago: float | None = None
    online: bool
    applied_users: list[str] = Field(default_factory=list)
    error: str | None = None
