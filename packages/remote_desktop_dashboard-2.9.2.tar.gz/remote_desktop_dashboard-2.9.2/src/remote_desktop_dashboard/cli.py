"""CLI entry points for remote-desktop-dashboard and seeding."""

import argparse
import json
import shutil
import sys
import threading
import webbrowser
from pathlib import Path

import uvicorn

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.database import SessionLocal, init_db
from remote_desktop_dashboard.crud.machine import (
    create_machine,
    get_machine_by_name,
    list_machines,
    upsert_machine,
)
from remote_desktop_dashboard.schemas.machine import MachineCreate

_PKG_DATA = Path(__file__).resolve().parent / "data"
_BUNDLED_MACHINES = _PKG_DATA / "machines.json"
_BUNDLED_EXAMPLE = _PKG_DATA / "machines.example.json"


def _resolve_seed_file(path: Path) -> Path | None:
    if path.is_file():
        return path.resolve()
    cwd_candidate = Path.cwd() / path
    if cwd_candidate.is_file():
        return cwd_candidate.resolve()
    if _BUNDLED_MACHINES.is_file():
        return _BUNDLED_MACHINES
    if _BUNDLED_EXAMPLE.is_file():
        return _BUNDLED_EXAMPLE
    return None


def _load_seed_entries(path: Path) -> list[dict]:
    resolved = _resolve_seed_file(path)
    if resolved is None:
        print(
            f"File not found: {path}\n"
            "Bundled machines.json is missing from the package.",
            file=sys.stderr,
        )
        sys.exit(1)
    if resolved in (_BUNDLED_MACHINES, _BUNDLED_EXAMPLE):
        print(f"Using bundled: {resolved.name}")
    return json.loads(resolved.read_text(encoding="utf-8"))


def init_example_file() -> Path:
    source = _BUNDLED_MACHINES if _BUNDLED_MACHINES.is_file() else _BUNDLED_EXAMPLE
    if not source.is_file():
        print("Bundled machines template is missing from the package.", file=sys.stderr)
        sys.exit(1)
    dest_dir = Path.cwd() / "data"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "machines.json"
    shutil.copy2(source, dest)
    print(f"Created: {dest}")
    print("Edit hostnames and IP addresses, then run:")
    print("  remote-desktop-dashboard-seed")
    return dest


def _seed_from_entries(entries: list[dict]) -> int:
    init_db()
    db = SessionLocal()
    created = 0
    try:
        for item in entries:
            name = item["name"].upper()
            if get_machine_by_name(db, name):
                continue
            create_machine(
                db,
                MachineCreate(
                    name=name,
                    hostname=item["hostname"],
                    ip_address=item["ip_address"],
                ),
            )
            created += 1
        return created
    finally:
        db.close()


def ensure_database_seeded() -> int:
    """Seed ATC1-ATC10 from bundled machines.json when the database is empty."""
    settings = get_settings()
    if not settings.auto_seed:
        return 0
    init_db()
    db = SessionLocal()
    try:
        if list_machines(db):
            return 0
    finally:
        db.close()
    if not _BUNDLED_MACHINES.is_file():
        return 0
    entries = json.loads(_BUNDLED_MACHINES.read_text(encoding="utf-8"))
    created = _seed_from_entries(entries)
    if created:
        print(f"Seeded {created} machine(s) from bundled machines.json (ATC1-ATC10).")
    return created


def _browser_url(host: str, port: int) -> str:
    browse_host = "127.0.0.1" if host in ("0.0.0.0", "::", "") else host
    return f"http://{browse_host}:{port}/"


def _schedule_browser_open(url: str) -> None:
    threading.Timer(1.5, lambda: webbrowser.open(url)).start()


def _prepare_install_layout() -> None:
    from remote_desktop_dashboard.services.bootstrap import bootstrap_install_layout

    bootstrap_install_layout()
    get_settings.cache_clear()


def main() -> None:
    """CLI entry: server, install-autostart, uninstall-autostart."""
    if len(sys.argv) > 1 and sys.argv[1] == "install-autostart":
        from remote_desktop_dashboard.services.autostart import install_autostart

        install_autostart()
        return
    if len(sys.argv) > 1 and sys.argv[1] == "uninstall-autostart":
        from remote_desktop_dashboard.services.autostart import uninstall_autostart

        uninstall_autostart()
        return
    run_server()


def run_server() -> None:
    parser = argparse.ArgumentParser(
        prog="remote-desktop-dashboard",
        description="Start the Remote Desktop Dashboard web server",
    )
    parser.add_argument("--host", help="Bind host (default: RDD_HOST or 0.0.0.0)")
    parser.add_argument("--port", type=int, help="Bind port (default: RDD_PORT or 8080)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the dashboard in your default browser",
    )
    parser.add_argument(
        "--no-seed",
        action="store_true",
        help="Do not auto-seed ATC1-ATC10 when the database is empty",
    )
    parser.add_argument(
        "--no-poller",
        action="store_true",
        help="Disable background remote polling (UI stays fast; no session data)",
    )
    parser.add_argument(
        "--no-reachability",
        action="store_true",
        help="Disable all TCP reachability checks (fastest UI)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    args, _unknown = parser.parse_known_args()

    import os

    if args.no_poller:
        os.environ["RDD_POLLER_ENABLED"] = "false"
    if args.no_reachability:
        os.environ["RDD_REACHABILITY_CHECK"] = "false"
        os.environ["RDD_REACHABILITY_BACKGROUND"] = "false"
        os.environ["RDD_REACHABILITY_ON_API"] = "false"

    _prepare_install_layout()
    settings = get_settings()
    host = args.host or settings.host
    port = args.port or settings.port
    reload = args.reload or settings.reload
    open_browser = settings.open_browser and not args.no_browser

    if not args.no_seed:
        ensure_database_seeded()

    from remote_desktop_dashboard.config import resolve_env_files
    from remote_desktop_dashboard.paths import resolve_data_dir, resolve_database_file

    data_dir = resolve_data_dir()
    db_file = resolve_database_file()
    env_files = resolve_env_files()
    print(f"Data folder:  {data_dir}")
    print(f"User config:  {data_dir / '.env'}")
    print(f"Admin config: {data_dir / 'admin.env'}")
    print(f"Database:     {db_file}")
    if env_files:
        print(f"Loading:      {', '.join(env_files)}")

    if open_browser:
        _schedule_browser_open(_browser_url(host, port))

    uvicorn.run(
        "remote_desktop_dashboard.main:app",
        host=host,
        port=port,
        reload=reload,
    )


def seed_machines() -> None:
    parser = argparse.ArgumentParser(
        description="Seed ATC machines into the database",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  remote-desktop-dashboard-seed\n"
            "  remote-desktop-dashboard-seed --init-example\n"
            "  remote-desktop-dashboard-seed --file data\\machines.json"
        ),
    )
    parser.add_argument(
        "--file",
        type=Path,
        help="JSON file (default: ./data/machines.json, else bundled machines.json)",
    )
    parser.add_argument(
        "--init-example",
        action="store_true",
        help="Copy bundled machines.json to ./data/machines.json",
    )
    parser.add_argument("--name", help="Single machine name (e.g. ATC1)")
    parser.add_argument("--hostname", help="Hostname for single machine")
    parser.add_argument("--ip", dest="ip_address", help="IP address for single machine")
    parser.add_argument(
        "--skip-update",
        action="store_true",
        help="Do not update hostname/IP when the machine name already exists",
    )
    args = parser.parse_args()

    if args.init_example:
        init_example_file()
        return

    _prepare_install_layout()
    init_db()
    db = SessionLocal()
    created = 0
    updated = 0
    skipped = 0
    try:
        entries: list[dict] = []
        if args.file or (not args.name and not args.hostname):
            seed_path = args.file or Path("data/machines.json")
            entries = _load_seed_entries(seed_path)
        elif args.name and args.hostname and args.ip_address:
            entries = [
                {
                    "name": args.name,
                    "hostname": args.hostname,
                    "ip_address": args.ip_address,
                }
            ]
        else:
            parser.print_help()
            sys.exit(1)

        for item in entries:
            name = item["name"].upper()
            payload = MachineCreate(
                name=name,
                hostname=item["hostname"],
                ip_address=item["ip_address"],
            )
            if args.skip_update and get_machine_by_name(db, name):
                print(f"Skip (exists): {name}")
                skipped += 1
                continue
            if args.skip_update:
                create_machine(db, payload)
                print(f"Created: {name}")
                created += 1
            else:
                _machine, action = upsert_machine(db, payload)
                if action == "created":
                    print(f"Created: {name}")
                    created += 1
                else:
                    print(f"Updated: {name} -> {payload.hostname} / {payload.ip_address}")
                    updated += 1
        print(
            f"Done. Created {created}, updated {updated}, skipped {skipped}. "
            f"Total: {len(list_machines(db))}"
        )
    finally:
        db.close()


if __name__ == "__main__":
    main()
