"""REST API routes."""

import asyncio
import logging
import threading

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from remote_desktop_dashboard.api.deps import verify_agent_key, verify_bench_agent_token
from remote_desktop_dashboard.crud.lock import (
    LockError,
    acquire_lock,
    admin_force_release,
    heartbeat_lock,
    is_locked_by_other,
    refresh_expired_locks,
    release_lock,
)
from remote_desktop_dashboard.crud.machine import (
    apply_status_report,
    create_machine,
    delete_machine,
    get_machine,
    get_machine_by_name,
    list_machines,
    refresh_online_flags,
    update_machine,
)
from remote_desktop_dashboard.database import get_db
from remote_desktop_dashboard.agent.monitor import MonitorSnapshot
from remote_desktop_dashboard.schemas.machine import (
    AdminReleaseRequest,
    ConnectRequest,
    ConnectResponse,
    LockHeartbeatRequest,
    MachineCreate,
    MachineRead,
    MachineStatusReport,
    MachineUpdate,
)
from remote_desktop_dashboard.schemas.settings import (
    MonitorSettingsRead,
    MonitorSettingsTest,
    MonitorSettingsWrite,
)
from remote_desktop_dashboard.services.connection_manager import manager
from remote_desktop_dashboard.services.dashboard import (
    bench_host,
    machines_payload,
    to_dashboard_machine,
)
from remote_desktop_dashboard.services.rdp_guard import (
    apply_rdp_guard,
    schedule_clear_rdp_guard,
)

logger = logging.getLogger(__name__)


_GUARD_RESULTS: dict[str, dict] = {}

# Machines for which an admin has explicitly requested a one-time kick of any
# unauthorized RDP sessions. Consumed (and cleared) by the next bench-agent
# /access poll so the agent kicks exactly once — kicking is never automatic.
_KICK_PENDING: set[str] = set()
_KICK_LOCK = threading.Lock()


def _run_guard(machine_name: str, host: str, allow_ips: list[str]) -> None:
    """Apply RDP guard in the background and record the result for later inspection."""
    import threading
    import time as _time

    started = _time.monotonic()
    _GUARD_RESULTS[machine_name] = {
        "host": host,
        "allow_ips": allow_ips,
        "applied": None,
        "status": "running",
        "started_at": started,
    }

    def _worker() -> None:
        try:
            ok = apply_rdp_guard(host, allow_ips)
            elapsed = _time.monotonic() - started
            _GUARD_RESULTS[machine_name] = {
                "host": host,
                "allow_ips": allow_ips,
                "applied": bool(ok),
                "status": "ok" if ok else "failed",
                "elapsed_seconds": round(elapsed, 1),
                "error": None
                if ok
                else (
                    "Remote 'netsh advfirewall' on this bench is timing out or "
                    "refusing the monitor account. The dashboard lock is still active "
                    "(prevents others from connecting through this dashboard). "
                    "To silence this warning, set RDD_RDP_GUARD_ENABLED=false in admin.env."
                ),
            }
        except Exception as exc:
            elapsed = _time.monotonic() - started
            logger.warning("RDP guard worker crashed for %s: %s", machine_name, exc)
            _GUARD_RESULTS[machine_name] = {
                "host": host,
                "allow_ips": allow_ips,
                "applied": False,
                "status": "error",
                "elapsed_seconds": round(elapsed, 1),
                "error": str(exc),
            }

    threading.Thread(target=_worker, name=f"rdd-guard-{machine_name}", daemon=True).start()
from remote_desktop_dashboard.services.rdp_launch import (
    build_launch_uris,
    build_rdp_file_content,
    local_launch_url,
)
from remote_desktop_dashboard.config import get_settings, permissions_dict
from remote_desktop_dashboard.services.reachability_cache import get_cached_reachability

router = APIRouter(prefix="/api/v1")


def _machine_or_404(db: Session, machine_name: str):
    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return machine


def _is_loopback(ip: str) -> bool:
    ip = (ip or "").strip().lower()
    return ip in ("127.0.0.1", "::1", "localhost") or ip.startswith("127.")


def _server_lan_ip_for(target: str) -> str:
    """Server's outbound LAN IP toward `target` — when dashboard is on the same PC as the RDP client."""
    import socket

    target = (target or "").strip()
    if not target:
        return ""
    candidates: list[tuple[str, int]] = []
    try:
        ip = socket.gethostbyname(target)
        candidates.append((ip, get_settings().rdp_port))
    except OSError:
        pass
    candidates.append(("8.8.8.8", 80))
    for host, port in candidates:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect((host, port))
                ip = s.getsockname()[0]
            finally:
                s.close()
            if ip and not _is_loopback(ip):
                return ip
        except OSError:
            continue
    return ""


def _client_ip(request: Request) -> str:
    """Client IP for RDP firewall allow rules (must match the PC running Windows App)."""
    for header in ("X-Forwarded-For", "X-Real-IP", "CF-Connecting-IP"):
        raw = request.headers.get(header)
        if raw:
            ip = raw.split(",")[0].strip()
            if ip and not _is_loopback(ip):
                return ip
    if request.client and request.client.host:
        host = request.client.host.strip()
        return host
    return ""


def _prepare_machines(
    db: Session, *, check_reachability: bool = False, refresh_locks: bool = True
):
    refresh_online_flags(db)
    if refresh_locks:
        refresh_expired_locks(db, remote_firewall=False)
    machines = list_machines(db)
    settings = get_settings()
    do_check = check_reachability and settings.reachability_check
    if do_check and settings.reachability_check:
        reachability = get_cached_reachability(machines, allow_refresh=True)
    else:
        reachability = get_cached_reachability(machines, allow_refresh=False)
    return machines, reachability


@router.get("/machines", response_model=list[MachineRead])
def api_list_machines(db: Session = Depends(get_db)) -> list[MachineRead]:
    machines, _ = _prepare_machines(db)
    return [MachineRead.model_validate(m) for m in machines]


@router.get("/machines/{machine_id}", response_model=MachineRead)
def api_get_machine(machine_id: int, db: Session = Depends(get_db)) -> MachineRead:
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return MachineRead.model_validate(machine)


@router.post("/machines", response_model=MachineRead, status_code=status.HTTP_201_CREATED)
async def api_create_machine(
    data: MachineCreate,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> MachineRead:
    _require_manage_machines(admin_pin)
    existing = get_machine_by_name(db, data.name)
    if existing:
        raise HTTPException(status_code=409, detail="Machine name already exists")
    machine = create_machine(db, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.patch("/machines/{machine_id}", response_model=MachineRead)
async def api_update_machine(
    machine_id: int,
    data: MachineUpdate,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> MachineRead:
    _require_manage_machines(admin_pin)
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    machine = update_machine(db, machine, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.delete("/machines/{machine_id}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine(
    machine_id: int,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> None:
    _require_manage_machines(admin_pin)
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.delete("/machines/by-name/{machine_name}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine_by_name(
    machine_name: str,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> None:
    _require_manage_machines(admin_pin)
    machine = _machine_or_404(db, machine_name)
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.post(
    "/machines/{machine_name}/status",
    response_model=MachineRead,
    dependencies=[Depends(verify_agent_key)],
)
async def api_post_status(
    machine_name: str,
    report: MachineStatusReport,
    db: Session = Depends(get_db),
) -> MachineRead:
    report.machine_name = machine_name.upper()
    try:
        machine = apply_status_report(db, report)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.get("/dashboard/fast")
def api_dashboard_fast(
    operator: str | None = None,
    db: Session = Depends(get_db),
) -> dict:
    """Dashboard with cached online/offline (never blocks on TCP refresh)."""
    refresh_online_flags(db)
    refresh_expired_locks(db, remote_firewall=False)
    machines = list_machines(db)
    reach = get_cached_reachability(machines, allow_refresh=False)
    return {
        **_dashboard_meta(),
        "machines": [
            to_dashboard_machine(m, operator, reach.get(m.name, False)).model_dump(mode="json")
            for m in machines
        ],
    }


def _verify_admin_pin(pin: str | None) -> None:
    required = (get_settings().admin_pin or "").strip()
    if not required:
        return
    if not pin or pin.strip() != required:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid admin PIN",
        )


def _require_users_can_connect() -> None:
    if not get_settings().users_can_connect:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Connecting is disabled in admin.env (RDD_USERS_CAN_CONNECT=false).",
        )


def _require_manage_machines(admin_pin: str | None = None) -> None:
    if get_settings().users_can_manage_machines:
        return
    _verify_admin_pin(admin_pin)
    if not (get_settings().admin_pin or "").strip():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Machine management requires admin.env (RDD_USERS_CAN_MANAGE_MACHINES or RDD_ADMIN_PIN).",
        )


def _dashboard_meta() -> dict:
    from remote_desktop_dashboard.services.monitor_credentials import (
        credentials_hint,
        monitor_credentials_source,
        resolve_monitor_credentials,
    )

    settings = get_settings()
    creds = resolve_monitor_credentials()
    data_dir = settings.config_directory
    return {
        "monitor_configured": creds is not None,
        "monitor_hint": None if creds else credentials_hint(),
        "monitor_source": monitor_credentials_source(),
        "poller_enabled": settings.poller_enabled,
        "admin_pin_required": settings.admin_pin_required,
        "config_dir": str(data_dir),
        "user_env_file": str(data_dir / ".env"),
        "admin_env_file": str(data_dir / "admin.env"),
        **permissions_dict(),
    }


@router.get("/dashboard")
def api_dashboard(
    operator: str | None = None,
    db: Session = Depends(get_db),
) -> dict:
    machines, reachability = _prepare_machines(db, check_reachability=False)
    return {
        **_dashboard_meta(),
        "machines": [
            to_dashboard_machine(m, operator, reachability.get(m.name, False)).model_dump(
                mode="json"
            )
            for m in machines
        ],
    }


@router.post("/machines/{machine_name}/connect", response_model=ConnectResponse)
async def api_connect(
    machine_name: str,
    body: ConnectRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> ConnectResponse:
    _require_users_can_connect()
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if is_locked_by_other(machine, body.operator):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Machine is in use by {machine.locked_by}. "
                "They must release it, or an admin can force release."
            ),
        )
    client_ip = _client_ip(request)
    try:
        acquire_lock(
            db,
            machine,
            body.operator,
            body.rdp_username,
            client_ip=client_ip or None,
            skip_expired_refresh=True,
        )
    except LockError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    settings = get_settings()
    guard_host = bench_host(machine, prefer_ip=settings.poll_prefer_ip)
    allow_ips: list[str] = []
    if client_ip and not _is_loopback(client_ip):
        allow_ips.append(client_ip)
    elif settings.rdp_guard_fallback_to_server_ip:
        fallback = _server_lan_ip_for(guard_host)
        if fallback:
            logger.info(
                "RDP guard: client IP is loopback; using dashboard server LAN IP %s as allow.",
                fallback,
            )
            allow_ips.append(fallback)
    if machine.lock_client_ip and machine.lock_client_ip not in allow_ips:
        allow_ips.append(machine.lock_client_ip)
    from remote_desktop_dashboard.services.settings_store import is_rdp_guard_enabled
    from datetime import datetime, timezone
    guard_enabled = is_rdp_guard_enabled()

    # If the bench agent has heartbeated recently, it is enforcing access
    # locally (via Remote Desktop Users group + session kicks). The legacy
    # remote-netsh firewall guard is redundant and we skip it.
    agent_online = False
    if machine.bench_agent_last_seen is not None:
        last = machine.bench_agent_last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        ago = (datetime.now(timezone.utc) - last).total_seconds()
        agent_online = ago <= max(15, settings.bench_agent_offline_grace_seconds)

    guard_info: dict = {
        "enabled": guard_enabled,
        "host": guard_host,
        "allow_ips": list(allow_ips),
        "applied": None,
        "status": "pending" if guard_enabled and allow_ips else "skipped",
    }
    if agent_online:
        guard_info["status"] = "agent"
        guard_info["reason"] = (
            "Bench agent is enforcing access locally on the bench "
            "(Remote Desktop Users group + session kicks). "
            "Legacy firewall guard skipped."
        )
        logger.info("RDP guard skipped for %s — bench agent online.", machine.name)
    elif guard_enabled and allow_ips:
        _GUARD_RESULTS.pop(machine.name, None)
        _run_guard(machine.name, guard_host, allow_ips)
    elif guard_enabled:
        guard_info["status"] = "no_client_ip"
        guard_info["reason"] = (
            "Dashboard server could not determine a usable client IP "
            f"(client={client_ip or '<empty>'}). Set RDD_RDP_GUARD_EXTRA_IPS "
            "in admin.env to your PC's LAN address, or open the dashboard "
            f"at http://<server-lan-ip>:{settings.port}."
        )
        logger.warning("RDP guard skipped: %s", guard_info["reason"])

    target = machine.hostname if body.use_hostname else machine.ip_address
    domain = None
    username = body.rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")

    uris = build_launch_uris(target, username=username, domain=domain)
    launch_url = local_launch_url(target, username=username, domain=domain)

    db.refresh(machine)
    reachability = get_cached_reachability([machine], allow_refresh=False)
    row = to_dashboard_machine(
        machine, body.operator, reachability.get(machine.name, False)
    )
    machines, reach_all = _prepare_machines(db, check_reachability=False)
    asyncio.create_task(
        manager.broadcast(
            machines_payload(machines, body.operator, reachability=reach_all)
        )
    )

    client = uris["client"]
    if client in ("windows_app", "windows365", "msrdc"):
        msg = f"Connecting directly to {target} via Windows App (msrdc)…"
    elif not uris["msrdc_found"]:
        msg = (
            "Windows App not found on this PC — use Download .rdp below, "
            "or set RDD_MSRDC_PATH on the server."
        )
    else:
        msg = "Opening remote session — sign in when prompted."

    if agent_online:
        msg += " Bench agent is enforcing exclusive access on the bench."
    elif guard_enabled and not allow_ips:
        msg += (
            " Direct RDP blocking needs your PC's IP in admin.env "
            "(RDD_RDP_GUARD_EXTRA_IPS) when the dashboard is opened on localhost."
        )
    elif guard_enabled:
        msg += " Direct RDP from other PCs is being blocked on the bench (may take a few seconds)."

    rdp_dl = f"/api/v1/machines/{machine.name}/session.rdp"
    if body.rdp_username:
        rdp_dl += f"?operator={body.operator}"

    return ConnectResponse(
        machine_name=machine.name,
        locked_by=body.operator,
        launch_uri=uris["primary_uri"],
        fallback_uri=uris["fallback_uri"],
        windows_app_uri=uris["rdp_uri"],
        rdp_uri=uris["rdp_uri"],
        mstsc_command=uris["mstsc_command"],
        powershell_command=uris["powershell_command"],
        local_launch_url=launch_url,
        rdp_download_url=rdp_dl,
        client=client,
        target_host=target,
        message=msg,
        machine=row.model_dump(mode="json"),
        guard=guard_info,
    )


@router.get("/machines/{machine_name}/guard")
def api_get_guard_status(machine_name: str) -> dict:
    """Return the latest RDP guard result for a machine (after Connect)."""
    return _GUARD_RESULTS.get(machine_name, {"status": "unknown"})


@router.get("/machines/{machine_name}/session.rdp")
def download_session_rdp(
    machine_name: str,
    operator: str | None = Query(None),
    use_hostname: bool = Query(True),
    rdp_username: str | None = Query(None),
    db: Session = Depends(get_db),
) -> Response:
    """Download .rdp file — works from any PC (uses that PC's default RDP client)."""
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if operator and is_locked_by_other(machine, operator):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Machine is reserved by {machine.locked_by}. Connect through the dashboard.",
        )
    target = machine.hostname if use_hostname else machine.ip_address
    domain = None
    username = rdp_username or machine.lock_rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")
    content = build_rdp_file_content(target, username=username, domain=domain)
    filename = f"{machine.name}.rdp"
    return Response(
        content=content,
        media_type="application/rdp",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/machines/{machine_name}/poll-now")
async def api_poll_now(
    machine_name: str,
    operator: str | None = Query(None),
    db: Session = Depends(get_db),
) -> dict:
    """Poll one machine in the background (does not block the HTTP worker)."""
    machine = _machine_or_404(db, machine_name)
    if not get_settings().poller_enabled:
        raise HTTPException(
            status_code=400,
            detail="Poller is disabled. Start server without --no-poller.",
        )
    if sys.platform != "win32":
        raise HTTPException(status_code=400, detail="Polling requires a Windows server.")

    from remote_desktop_dashboard.services.monitor_credentials import resolve_monitor_credentials
    from remote_desktop_dashboard.services.poller import poll_single_machine

    if resolve_monitor_credentials() is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "Server monitor credentials not set. Open Server settings and save "
                "domain, username, and password."
            ),
        )

    limit = get_settings().poll_timeout_seconds + 10.0
    try:
        ok, err = await asyncio.wait_for(
            asyncio.to_thread(poll_single_machine, machine.name),
            timeout=limit,
        )
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504,
            detail=f"Poll timed out after {int(limit)}s — bench may be slow or unreachable.",
        ) from None

    db.refresh(machine)
    machines, reachability = _prepare_machines(db, check_reachability=False)
    row = to_dashboard_machine(
        machine, operator, reachability.get(machine.name, False)
    )
    await manager.broadcast(machines_payload(machines, operator, reachability))
    return {
        "ok": ok,
        "status": "done",
        "error": err,
        "machine": row.model_dump(mode="json"),
    }


@router.post("/machines/{machine_name}/lock/heartbeat", response_model=MachineRead)
async def api_lock_heartbeat(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    try:
        machine = heartbeat_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, body.operator, reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/release", response_model=MachineRead)
async def api_lock_release(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    settings = get_settings()
    if not settings.users_can_release_own_lock:
        _verify_admin_pin(body.admin_pin)
    allow: list[str] = []
    if machine.lock_client_ip:
        allow.append(machine.lock_client_ip)
    try:
        machine = release_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    schedule_clear_rdp_guard(bench_host(machine, prefer_ip=settings.poll_prefer_ip), allow)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/admin-release", response_model=MachineRead)
async def api_admin_release(
    machine_name: str,
    body: AdminReleaseRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    """Admin: clear lock and RDP firewall rules without being the lock owner."""
    _verify_admin_pin(body.admin_pin)
    machine = _machine_or_404(db, machine_name)
    settings = get_settings()
    allow: list[str] = []
    if machine.lock_client_ip:
        allow.append(machine.lock_client_ip)
    schedule_clear_rdp_guard(bench_host(machine, prefer_ip=settings.poll_prefer_ip), allow)
    machine = admin_force_release(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/kick-others")
async def api_kick_others(
    machine_name: str,
    body: AdminReleaseRequest,
    db: Session = Depends(get_db),
) -> dict:
    """Admin: request a one-time kick of any RDP sessions not held by the lock owner.

    This never happens automatically. An admin must explicitly call this; the
    bench agent then logs off unauthorized sessions on its next poll, once.
    Requires the bench agent to be running on the target machine.
    """
    _verify_admin_pin(body.admin_pin)
    machine = _machine_or_404(db, machine_name)
    if not machine.locked_by:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Machine is not locked — nobody is authorized, so there is "
            "no 'others' to kick. Lock it first if you want exclusive access.",
        )
    with _KICK_LOCK:
        _KICK_PENDING.add(machine.name)
    logger.info(
        "Admin requested one-time session kick on %s (lock owner: %s)",
        machine.name,
        machine.locked_by,
    )
    return {
        "machine_name": machine.name,
        "kick_requested": True,
        "allow_users": _allow_users_for_lock(machine),
        "note": "Unauthorized sessions will be logged off on the next bench "
        "agent poll. Requires the bench agent to be installed and running.",
    }


@router.get("/settings/monitor", response_model=MonitorSettingsRead)
def api_get_monitor_settings(db: Session = Depends(get_db)) -> MonitorSettingsRead:
    from remote_desktop_dashboard.services.monitor_credentials import (
        monitor_credentials_source,
    )
    from remote_desktop_dashboard.services.settings_store import get_monitor_credentials_dict

    source = monitor_credentials_source()
    if source == "database":
        data = get_monitor_credentials_dict(db) or {}
        return MonitorSettingsRead(
            configured=True,
            domain=data.get("domain", ""),
            username=data.get("username", ""),
            password_set=True,
            source=source,
        )
    if source == "environment":
        s = get_settings()
        return MonitorSettingsRead(
            configured=True,
            domain=s.monitor_domain,
            username=s.monitor_username,
            password_set=bool(s.monitor_password),
            source=source,
        )
    return MonitorSettingsRead(configured=False, source="none")


@router.put("/settings/monitor", response_model=MonitorSettingsRead)
def api_save_monitor_settings(
    body: MonitorSettingsWrite,
    db: Session = Depends(get_db),
) -> MonitorSettingsRead:
    from remote_desktop_dashboard.services.settings_store import save_monitor_credentials

    _verify_admin_pin(body.admin_pin)
    try:
        save_monitor_credentials(
            db,
            domain=body.domain,
            username=body.username,
            password=body.password,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return api_get_monitor_settings(db)


@router.post("/settings/monitor/test")
async def api_test_monitor_settings(body: MonitorSettingsTest) -> dict:
    from remote_desktop_dashboard.services.monitor_credentials import (
        resolve_monitor_credentials,
    )
    from remote_desktop_dashboard.services.remote_users import probe_logged_in_users

    _verify_admin_pin(body.admin_pin)
    if resolve_monitor_credentials() is None:
        raise HTTPException(
            status_code=400,
            detail="Save monitor credentials first (Server settings).",
        )
    host = body.host.strip()
    limit = get_settings().settings_test_timeout_seconds + 3.0

    def _run() -> MonitorSnapshot:
        snap = probe_logged_in_users(host)
        return MonitorSnapshot(
            local_user=snap.local_user,
            rdp_users=snap.rdp_users,
            raw=snap.raw,
        )

    try:
        snap = await asyncio.wait_for(asyncio.to_thread(_run), timeout=limit)
    except asyncio.TimeoutError:
        return {
            "ok": False,
            "message": (
                f"Timed out after {int(limit)}s. Check IP, firewall, and that the service "
                "account can run remote tasklist on that bench."
            ),
        }
    except Exception as exc:
        return {"ok": False, "message": str(exc)}
    proc_n = snap.raw.get("process_count", 0) if isinstance(snap.raw, dict) else 0
    session_err = snap.raw.get("session_error") if isinstance(snap.raw, dict) else None
    return {
        "ok": True,
        "message": (
            f"OK — {proc_n} processes, local_user={snap.local_user!r}, "
            f"rdp_users={snap.rdp_users!r}, windows_app={snap.windows_app_users!r}, "
            f"mobaxterm={snap.mobaxterm_user!r}"
        ),
        "local_user": snap.local_user,
        "rdp_users": snap.rdp_users,
        "windows_app_users": snap.windows_app_users,
        "mobaxterm_user": snap.mobaxterm_user,
        "session_error": session_err,
    }


@router.get("/settings/rdp-guard")
def api_get_rdp_guard_setting() -> dict:
    """Return whether the firewall RDP guard is enabled (env + runtime override)."""
    from remote_desktop_dashboard.services.settings_store import (
        get_rdp_guard_runtime_override,
        is_rdp_guard_enabled,
    )

    return {
        "enabled": is_rdp_guard_enabled(),
        "env_default": bool(get_settings().rdp_guard_enabled),
        "override": get_rdp_guard_runtime_override(),
    }


@router.put("/settings/rdp-guard")
def api_set_rdp_guard_setting(body: dict, db: Session = Depends(get_db)) -> dict:
    """Admin-only: persistently enable/disable the RDP firewall guard at runtime."""
    from remote_desktop_dashboard.services.settings_store import (
        clear_rdp_guard_runtime_override,
        get_rdp_guard_runtime_override,
        is_rdp_guard_enabled,
        set_rdp_guard_runtime_override,
    )

    _verify_admin_pin(body.get("admin_pin"))
    if "enabled" in body and body["enabled"] is not None:
        set_rdp_guard_runtime_override(db, bool(body["enabled"]))
    else:
        clear_rdp_guard_runtime_override(db)
    return {
        "enabled": is_rdp_guard_enabled(),
        "env_default": bool(get_settings().rdp_guard_enabled),
        "override": get_rdp_guard_runtime_override(),
    }


# ---------------------------------------------------------------------------
# Bench-side agent (Option B): manages local "Remote Desktop Users" group.
# ---------------------------------------------------------------------------

def _allow_users_for_lock(machine) -> list[str]:
    """Who is currently allowed to RDP this bench (per the dashboard lock)?"""
    allowed: list[str] = []
    rdp = (machine.lock_rdp_username or "").strip()
    if rdp:
        allowed.append(rdp)
    locked_by = (machine.locked_by or "").strip()
    if locked_by and locked_by not in allowed:
        allowed.append(locked_by)
    return allowed


@router.get(
    "/machines/{machine_name}/access",
    dependencies=[Depends(verify_bench_agent_token)],
)
def api_bench_access(machine_name: str, db: Session = Depends(get_db)) -> dict:
    """Bench agent polls this endpoint to learn who is allowed to RDP right now."""
    from remote_desktop_dashboard.schemas.bench_agent import BenchAccessResponse
    from remote_desktop_dashboard import __version__

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    settings = get_settings()
    refresh_expired_locks(db)
    db.refresh(machine)
    locked = bool(machine.locked_by)
    with _KICK_LOCK:
        kick_requested = machine.name in _KICK_PENDING
        _KICK_PENDING.discard(machine.name)
    kick_other = locked and (
        kick_requested or settings.bench_agent_kick_other_sessions
    )
    return BenchAccessResponse(
        machine_name=machine.name,
        locked=locked,
        locked_by=machine.locked_by,
        allow_users=_allow_users_for_lock(machine) if locked else [],
        kick_other_sessions=kick_other,
        poll_seconds=max(2, int(settings.bench_agent_poll_seconds)),
        server_version=__version__,
    ).model_dump(mode="json")


@router.post(
    "/machines/{machine_name}/agent/heartbeat",
    dependencies=[Depends(verify_bench_agent_token)],
)
def api_bench_heartbeat(
    machine_name: str,
    body: "dict",
    db: Session = Depends(get_db),
) -> dict:
    """Bench agent reports what it has applied locally."""
    import json as _json
    from datetime import datetime, timezone

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    machine.bench_agent_version = (body.get("agent_version") or "")[:32] or None
    machine.bench_agent_last_seen = datetime.now(timezone.utc)
    applied = body.get("applied_users") or []
    if not isinstance(applied, list):
        applied = []
    machine.bench_agent_applied = _json.dumps(applied)
    err = body.get("error")
    machine.bench_agent_error = (err or "")[:500] or None
    db.commit()
    return {"ok": True}


@router.get("/machines/{machine_name}/agent/status")
def api_bench_status(machine_name: str, db: Session = Depends(get_db)) -> dict:
    """UI reads this to show 'Agent: connected 8s ago' badges."""
    import json as _json
    from datetime import datetime, timezone
    from remote_desktop_dashboard.schemas.bench_agent import BenchAgentStatus

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    settings = get_settings()
    ago: float | None = None
    online = False
    if machine.bench_agent_last_seen is not None:
        last = machine.bench_agent_last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        ago = max(0.0, (datetime.now(timezone.utc) - last).total_seconds())
        online = ago <= max(15, settings.bench_agent_offline_grace_seconds)
    applied: list[str] = []
    try:
        if machine.bench_agent_applied:
            parsed = _json.loads(machine.bench_agent_applied)
            if isinstance(parsed, list):
                applied = [str(x) for x in parsed]
    except Exception:
        applied = []
    return BenchAgentStatus(
        machine_name=machine.name,
        installed=bool(machine.bench_agent_last_seen),
        version=machine.bench_agent_version,
        last_seen=machine.bench_agent_last_seen,
        last_seen_seconds_ago=ago,
        online=online,
        applied_users=applied,
        error=machine.bench_agent_error,
    ).model_dump(mode="json")


@router.post("/machines/{machine_name}/agent/install")
def api_push_install_agent(
    machine_name: str,
    request: Request,
    body: dict | None = None,
    db: Session = Depends(get_db),
) -> dict:
    """Push-install the bench agent from this dashboard to the bench (one-click).

    Uses saved monitor credentials to SMB-copy the agent and register a SYSTEM
    scheduled task on the bench. Admin PIN required.
    """
    from remote_desktop_dashboard.services.bench_agent_push import push_install

    body = body or {}
    _verify_admin_pin(body.get("admin_pin"))

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")

    base_url = str(request.base_url).rstrip("/")
    target = (machine.hostname or machine.ip_address or "").strip()
    if not target:
        raise HTTPException(status_code=400, detail="Machine has no hostname/IP set.")

    # If the dashboard was opened on localhost, the bench can't call back.
    # Prefer the server-side LAN IP in that case.
    if any(part in base_url for part in ("//localhost", "//127.0.0.1", "//[::1]")):
        server_ip = _server_lan_ip_for(target)
        if server_ip:
            from urllib.parse import urlparse, urlunparse
            u = urlparse(base_url)
            base_url = urlunparse(u._replace(netloc=f"{server_ip}:{u.port or 8080}"))

    settings = get_settings()
    if not (settings.bench_agent_token or "").strip():
        raise HTTPException(
            status_code=400,
            detail="Set RDD_BENCH_AGENT_TOKEN in admin.env first, then restart.",
        )

    result = push_install(target, machine.name, base_url)
    return {
        "ok": result.ok,
        "host": result.host,
        "steps": result.steps,
        "error": result.error,
        "dashboard_url": base_url,
    }


@router.post("/machines/{machine_name}/agent/uninstall")
def api_push_uninstall_agent(
    machine_name: str,
    body: dict | None = None,
    db: Session = Depends(get_db),
) -> dict:
    from remote_desktop_dashboard.services.bench_agent_push import uninstall

    body = body or {}
    _verify_admin_pin(body.get("admin_pin"))

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    target = (machine.hostname or machine.ip_address or "").strip()
    if not target:
        raise HTTPException(status_code=400, detail="Machine has no hostname/IP set.")
    result = uninstall(target)
    if result.ok:
        machine.bench_agent_version = None
        machine.bench_agent_applied = None
        machine.bench_agent_error = None
        db.commit()
    return {
        "ok": result.ok,
        "host": result.host,
        "steps": result.steps,
        "error": result.error,
    }


@router.get("/agent/install-command")
def api_bench_install_command(request: Request, admin_pin: str | None = Query(None)) -> dict:
    """Return the one-liner PowerShell install command for the bench agent."""
    _verify_admin_pin(admin_pin)
    settings = get_settings()
    token = (settings.bench_agent_token or "").strip()
    if not token:
        raise HTTPException(
            status_code=400,
            detail="Set RDD_BENCH_AGENT_TOKEN in admin.env first, then restart the server.",
        )
    base = str(request.base_url).rstrip("/")
    installer_url = f"{base}/agent/install.ps1?token={token}"
    agent_url = f"{base}/agent/bench_agent.ps1"
    pwsh = (
        f"$ErrorActionPreference='Stop'; "
        f"$base='{base}'; "
        f"$token='{token}'; "
        f"iwr \"$base/agent/install.ps1?token=$token\" "
        f"-UseBasicParsing | iex"
    )
    return {
        "base_url": base,
        "installer_url": installer_url,
        "agent_url": agent_url,
        "command": f"powershell -ExecutionPolicy Bypass -NoProfile -Command \"{pwsh}\"",
    }
