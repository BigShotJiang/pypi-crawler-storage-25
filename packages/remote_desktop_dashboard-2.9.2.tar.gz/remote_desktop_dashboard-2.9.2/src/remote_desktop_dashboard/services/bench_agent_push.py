r"""Push-install the bench agent onto a remote machine.

Uses the saved monitor credentials (which have local-admin rights on each
bench) to:
  1. Establish an SMB session via ``net use \\HOST\IPC$``.
  2. Write bench_agent.ps1 + config.json into ``\\HOST\C$\ProgramData\RDD-Bench-Agent\``.
  3. Register the scheduled task remotely via ``schtasks /create /s HOST``.
  4. Start it via ``schtasks /run``.
  5. Tear down the SMB session.

All work is local-to-bench except the SMB/RPC channel, which is the same
underlying transport that ``quser /server:`` already uses successfully.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.monitor_credentials import (
    MonitorCredentials,
    resolve_monitor_credentials,
)
from remote_desktop_dashboard.services.windows_cmd import (
    redact_cmd_args,
    run_cmd,
    system32_dir,
)

logger = logging.getLogger(__name__)

_AGENT_DATA = Path(__file__).resolve().parent.parent / "data"
_BENCH_AGENT = _AGENT_DATA / "bench_agent.ps1"

TASK_NAME = "RDD-Bench-Agent"
REMOTE_DIR = r"C:\ProgramData\RDD-Bench-Agent"


@dataclass
class PushResult:
    ok: bool
    host: str
    steps: list[dict] = field(default_factory=list)
    error: str | None = None

    def add(self, name: str, ok: bool, detail: str = "") -> None:
        self.steps.append({"step": name, "ok": ok, "detail": detail})


def _net_use(host: str, creds: MonitorCredentials, timeout: float) -> None:
    args = [
        str(system32_dir() / "net.exe"),
        "use",
        f"\\\\{host}\\IPC$",
        creds.password,
        creds.net_use_user_arg(),
        "/persistent:no",
    ]
    run_cmd(args, timeout=timeout)


def _net_use_delete(host: str, timeout: float) -> None:
    args = [str(system32_dir() / "net.exe"), "use", f"\\\\{host}\\IPC$", "/delete", "/y"]
    try:
        run_cmd(args, timeout=timeout)
    except Exception as exc:
        logger.debug("net use /delete %s failed (ignored): %s", host, exc)


def _smb_path(host: str, sub: str = "") -> Path:
    """Map remote `C:\\ProgramData\\RDD-Bench-Agent\\<sub>` to a UNC path."""
    base = f"\\\\{host}\\C$\\ProgramData\\RDD-Bench-Agent"
    return Path(base if not sub else f"{base}\\{sub}")


def _write_remote_file(host: str, name: str, content: bytes | str) -> None:
    target = _smb_path(host, name)
    target.parent.mkdir(parents=True, exist_ok=True)
    mode = "wb" if isinstance(content, (bytes, bytearray)) else "w"
    if mode == "w":
        target.write_text(content, encoding="utf-8")
    else:
        target.write_bytes(content)


def _schtasks_create(
    host: str,
    creds: MonitorCredentials,
    agent_path: str,
    timeout: float,
) -> None:
    """Register the scheduled task remotely. /sc onstart fires after reboot;
    we /run it immediately below so it starts now too."""
    pwsh = (
        "powershell.exe -NoProfile -ExecutionPolicy Bypass "
        f'-File "{agent_path}"'
    )
    args = [
        str(system32_dir() / "schtasks.exe"),
        "/create",
        "/s", host,
        "/u", creds.qualified,
        "/p", creds.password,
        "/tn", TASK_NAME,
        "/tr", pwsh,
        "/sc", "onstart",
        "/ru", "SYSTEM",
        "/rl", "HIGHEST",
        "/f",
    ]
    run_cmd(args, timeout=timeout)


def _schtasks_run(host: str, creds: MonitorCredentials, timeout: float) -> None:
    args = [
        str(system32_dir() / "schtasks.exe"),
        "/run",
        "/s", host,
        "/u", creds.qualified,
        "/p", creds.password,
        "/tn", TASK_NAME,
    ]
    run_cmd(args, timeout=timeout)


def _schtasks_query(host: str, creds: MonitorCredentials, timeout: float) -> str:
    args = [
        str(system32_dir() / "schtasks.exe"),
        "/query",
        "/s", host,
        "/u", creds.qualified,
        "/p", creds.password,
        "/tn", TASK_NAME,
        "/fo", "LIST",
        "/v",
    ]
    return run_cmd(args, timeout=timeout)


def push_install(host: str, machine_name: str, dashboard_url: str) -> PushResult:
    """Install the bench agent on `host` using saved monitor credentials.

    `host`           — bench hostname or IP, resolvable from the dashboard server.
    `machine_name`   — the dashboard's name for this machine (goes into config.json).
    `dashboard_url`  — base URL the bench can use to reach this dashboard.
    """
    result = PushResult(ok=False, host=host)

    creds = resolve_monitor_credentials()
    if creds is None:
        result.error = (
            "No monitor credentials configured. Open Settings -> Server settings "
            "and save the service account first."
        )
        return result

    settings = get_settings()
    token = (settings.bench_agent_token or "").strip()
    if not token:
        result.error = "RDD_BENCH_AGENT_TOKEN is empty in admin.env."
        return result

    if not _BENCH_AGENT.is_file():
        result.error = f"bench_agent.ps1 missing from package data ({_BENCH_AGENT})."
        return result

    agent_text = _BENCH_AGENT.read_text(encoding="utf-8")
    config_text = json.dumps(
        {
            "dashboard_url": dashboard_url.rstrip("/"),
            "machine_name":  machine_name,
            "token":         token,
            "poll_seconds":  max(2, int(settings.bench_agent_poll_seconds)),
            "installer":     f"dashboard-push v{__version__}",
        },
        indent=2,
    )

    timeout_short = 15.0
    timeout_long  = 30.0
    connected = False

    try:
        try:
            _net_use(host, creds, timeout_short)
            connected = True
            result.add("smb_connect", True, f"\\\\{host}\\IPC$")
        except Exception as exc:
            result.add("smb_connect", False, str(exc))
            result.error = (
                f"Cannot reach \\\\{host}\\IPC$ as {creds.qualified}. "
                "The bench must allow SMB (port 445) from the dashboard server "
                "and the service account must be a local admin on the bench."
            )
            return result

        try:
            _write_remote_file(host, "bench_agent.ps1", agent_text)
            result.add("write_agent", True, _smb_path(host, "bench_agent.ps1").as_posix())
        except Exception as exc:
            result.add("write_agent", False, str(exc))
            result.error = f"Could not write bench_agent.ps1 to {host}: {exc}"
            return result

        try:
            _write_remote_file(host, "config.json", config_text)
            result.add("write_config", True, _smb_path(host, "config.json").as_posix())
        except Exception as exc:
            result.add("write_config", False, str(exc))
            result.error = f"Could not write config.json to {host}: {exc}"
            return result

        local_agent_path = f"{REMOTE_DIR}\\bench_agent.ps1"
        try:
            _schtasks_create(host, creds, local_agent_path, timeout_long)
            result.add("register_task", True, TASK_NAME)
        except Exception as exc:
            result.add("register_task", False, str(exc))
            result.error = (
                f"Could not register scheduled task '{TASK_NAME}' on {host}: {exc}. "
                "Most often this means the Task Scheduler service isn't reachable "
                "remotely. Try the manual one-liner option instead."
            )
            return result

        try:
            _schtasks_run(host, creds, timeout_short)
            result.add("start_task", True, "/run")
        except Exception as exc:
            result.add("start_task", False, str(exc))
            # Not fatal — task will fire at next boot anyway, and the dashboard
            # auto-creates a 5-minute repeat trigger via the install.ps1 path.
            result.error = (
                f"Files installed and task registered, but could not /run it now: "
                f"{exc}. It will start on the next reboot."
            )
            result.ok = True
            return result

        result.ok = True
        return result

    finally:
        if connected:
            _net_use_delete(host, timeout_short)


def uninstall(host: str) -> PushResult:
    """Remove the agent's scheduled task and config from the bench."""
    result = PushResult(ok=False, host=host)
    creds = resolve_monitor_credentials()
    if creds is None:
        result.error = "No monitor credentials configured."
        return result

    try:
        _net_use(host, creds, 15.0)
    except Exception as exc:
        result.add("smb_connect", False, str(exc))
        result.error = str(exc)
        return result

    try:
        args = [
            str(system32_dir() / "schtasks.exe"),
            "/delete", "/s", host,
            "/u", creds.qualified,
            "/p", creds.password,
            "/tn", TASK_NAME, "/f",
        ]
        try:
            run_cmd(args, timeout=15.0)
            result.add("delete_task", True, TASK_NAME)
        except Exception as exc:
            result.add("delete_task", False, str(exc))

        for name in ("bench_agent.ps1", "config.json", "baseline.json"):
            try:
                p = _smb_path(host, name)
                if p.exists():
                    p.unlink()
                result.add(f"delete_{name}", True, str(p))
            except Exception as exc:
                result.add(f"delete_{name}", False, str(exc))

        result.ok = True
    finally:
        _net_use_delete(host, 10.0)
    return result
