"""Install dashboard as a Windows scheduled task (starts on boot, restarts on failure)."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys

TASK_NAME = "RemoteDesktopDashboard"


def _dashboard_command() -> str:
    from remote_desktop_dashboard.paths import resolve_data_dir

    data_dir = resolve_data_dir()
    env_set = f'set RDD_DATA_DIR={data_dir}&& '
    exe = shutil.which("remote-desktop-dashboard")
    if exe:
        return f'{env_set}"{exe}" --no-browser --host 0.0.0.0'
    return (
        f'{env_set}"{sys.executable}" -m remote_desktop_dashboard.cli '
        f"--no-browser --host 0.0.0.0"
    )


def install_autostart() -> None:
    if sys.platform != "win32":
        print("Autostart is only supported on Windows.", file=sys.stderr)
        sys.exit(1)

    tr = _dashboard_command()
    user = os.environ.get("RDD_SERVICE_USER") or os.environ.get("USERNAME") or "SYSTEM"

    args = [
        "schtasks",
        "/Create",
        "/F",
        "/TN",
        TASK_NAME,
        "/TR",
        tr,
        "/SC",
        "ONSTART",
        "/RU",
        user,
        "/RL",
        "HIGHEST",
    ]
    if user.upper() != "SYSTEM":
        args.extend(["/IT"])  # interactive — needed for msrdc / network profile

    subprocess.run(args, check=True)
    print(f"Installed scheduled task '{TASK_NAME}' (runs at startup as {user}).")
    print(f"Command: {tr}")
    print("Start now: schtasks /Run /TN", TASK_NAME)
    print("Remove: remote-desktop-dashboard uninstall-autostart")


def uninstall_autostart() -> None:
    if sys.platform != "win32":
        sys.exit(1)
    subprocess.run(["schtasks", "/Delete", "/F", "/TN", TASK_NAME], check=True)
    print(f"Removed scheduled task '{TASK_NAME}'.")
