"""First-run layout: user .env, admin.env, and SQLite schema upgrades."""

from __future__ import annotations

import logging
import re
import shutil
from pathlib import Path

from sqlalchemy import inspect, text

from remote_desktop_dashboard import __version__

logger = logging.getLogger(__name__)

_PKG_DATA = Path(__file__).resolve().parent.parent / "data"

VERSION_MARKER = "# RDD_CONFIG_VERSION"

_MACHINE_COLUMNS: dict[str, str] = {
    "locked_by": "VARCHAR(128)",
    "locked_at": "DATETIME",
    "lock_heartbeat_at": "DATETIME",
    "lock_rdp_username": "VARCHAR(256)",
    "lock_client_ip": "VARCHAR(45)",
    "bench_agent_version": "VARCHAR(32)",
    "bench_agent_last_seen": "DATETIME",
    "bench_agent_applied": "TEXT",
    "bench_agent_error": "TEXT",
}

# Keys whose values must NEVER be overwritten on upgrade.
# They contain user secrets or per-site configuration.
_PRESERVE_KEYS: frozenset[str] = frozenset({
    "RDD_ADMIN_PIN",
    "RDD_MONITOR_DOMAIN",
    "RDD_MONITOR_USERNAME",
    "RDD_MONITOR_PASSWORD",
    "RDD_AGENT_API_KEY",
    "RDD_BENCH_AGENT_TOKEN",
    "RDD_SETTINGS_SECRET_KEY",
    "RDD_RDP_GUARD_EXTRA_IPS",
    "RDD_MSRDC_PATH",
    "RDD_RDP_DEFAULT_DOMAIN",
})


def bundled_env_template(name: str) -> Path:
    path = _PKG_DATA / name
    if not path.is_file():
        raise FileNotFoundError(f"Missing bundled config template: {path}")
    return path


def _read_env_file(path: Path) -> tuple[str, dict[str, str]]:
    """Return (raw_text, key->value map)."""
    if not path.is_file():
        return "", {}
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return "", {}
    values: dict[str, str] = {}
    for line in raw.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if "=" not in s:
            continue
        key, _, value = s.partition("=")
        values[key.strip()] = value.strip()
    return raw, values


def _detect_version(raw_text: str) -> str | None:
    """Look for `# RDD_CONFIG_VERSION=X.Y.Z` line."""
    for line in raw_text.splitlines():
        s = line.strip()
        if s.startswith(VERSION_MARKER):
            m = re.match(r"#\s*RDD_CONFIG_VERSION\s*[:=]\s*(\S+)", s)
            if m:
                return m.group(1)
    return None


def _annotate_with_version(text_body: str) -> str:
    """Add or update the version marker comment at the top of the env body."""
    lines = text_body.splitlines()
    out: list[str] = []
    inserted = False
    for line in lines:
        if line.strip().startswith(VERSION_MARKER):
            continue
        out.append(line)
    header = f"{VERSION_MARKER}={__version__}"
    if out and out[0].startswith("#"):
        out.insert(1, header)
    else:
        out.insert(0, header)
    inserted = True  # always inserted by here
    return "\n".join(out) + ("\n" if not text_body.endswith("\n") and inserted else "")


def _rebuild_env(
    template_path: Path,
    existing_values: dict[str, str],
) -> str:
    """Generate new env text from template, but keep `_PRESERVE_KEYS` from existing file."""
    template_text = template_path.read_text(encoding="utf-8")
    out_lines: list[str] = []
    for line in template_text.splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key, _, _ = line.partition("=")
            key = key.strip()
            if key in _PRESERVE_KEYS and key in existing_values:
                out_lines.append(f"{key}={existing_values[key]}")
                continue
        out_lines.append(line)
    body = "\n".join(out_lines)
    if not body.endswith("\n"):
        body += "\n"
    return _annotate_with_version(body)


def _write_env(path: Path, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(body, encoding="utf-8")


def ensure_config_files(data_dir: Path) -> tuple[Path, Path]:
    """Create or upgrade `.env` and `admin.env` in the per-user data folder.

    On a fresh install, copies the bundled templates verbatim and stamps the version.
    On every later install where the package version differs from the file's recorded
    version, regenerates the env from the new template while preserving user secrets
    (`_PRESERVE_KEYS` — admin PIN, monitor creds, secret keys, etc.).
    """
    data_dir.mkdir(parents=True, exist_ok=True)
    user_env = data_dir / ".env"
    admin_env = data_dir / "admin.env"

    for path, template_name in (
        (user_env, "default.env"),
        (admin_env, "admin.env"),
    ):
        template = bundled_env_template(template_name)
        if not path.is_file():
            shutil.copy2(template, path)
            new_body = _annotate_with_version(path.read_text(encoding="utf-8"))
            _write_env(path, new_body)
            logger.info("Created %s (version %s)", path, __version__)
            continue

        raw, existing = _read_env_file(path)
        recorded = _detect_version(raw)
        if recorded == __version__:
            continue

        backup = path.with_suffix(path.suffix + f".bak-{recorded or 'pre' }")
        try:
            shutil.copy2(path, backup)
        except OSError:
            backup = None
        new_body = _rebuild_env(template, existing)
        _write_env(path, new_body)
        kept = sorted(_PRESERVE_KEYS & existing.keys())
        logger.info(
            "Upgraded %s %s -> %s (kept %s; backup: %s)",
            path,
            recorded or "<unstamped>",
            __version__,
            ", ".join(kept) if kept else "<no user-set keys>",
            backup.name if backup else "n/a",
        )

    return user_env, admin_env


def upgrade_database_schema(engine) -> None:
    """Add any missing columns on existing SQLite DBs (pip install without alembic CLI)."""
    inspector = inspect(engine)
    if "machines" not in inspector.get_table_names():
        return
    existing = {col["name"] for col in inspector.get_columns("machines")}
    with engine.begin() as conn:
        for name, sql_type in _MACHINE_COLUMNS.items():
            if name in existing:
                continue
            conn.execute(text(f"ALTER TABLE machines ADD COLUMN {name} {sql_type}"))
            logger.info("Added machines.%s", name)


def bootstrap_install_layout() -> Path:
    """
    Call before loading settings / starting the server.
    Ensures %LOCALAPPDATA%\\RemoteDesktopDashboard\\.env and admin.env exist
    and are up-to-date with the installed package version.
    """
    from remote_desktop_dashboard.paths import resolve_data_dir

    data_dir = resolve_data_dir()
    ensure_config_files(data_dir)

    from remote_desktop_dashboard.database import engine
    from remote_desktop_dashboard.database import init_db as _init_tables

    upgrade_database_schema(engine)
    _init_tables()

    return data_dir
