"""Shared process/session analysis for local and remote monitoring."""

from __future__ import annotations

from dataclasses import dataclass

ETGUI_NAMES = {"etgui.exe"}
MOBAXTERM_NAMES = {"mobaxterm.exe", "mobaxterm personal edition.exe"}
WINDOWS_APP_NAMES = {"msrdc.exe", "msrdcw.exe", "windowsterminal.exe"}
RDP_PROCESS_HINTS = {"rdpclip.exe", "rdpinput.exe", "mstsc.exe"}
CAMERA_PROCESS_NAMES = {
    "windowscamera.exe",
    "camera.exe",
    "webcam.exe",
    "obs64.exe",
    "obs32.exe",
    "manycam.exe",
    "yawcam.exe",
}
CAMERA_PYTHON_HINTS = ("opencv", "cv2", "pyqt5", "pyside2", "picamera")
COM_PORT_PROCESS_NAMES = {
    "putty.exe",
    "teraterm.exe",
    "ttermpro.exe",
    "securecrt.exe",
    "hyperterminal.exe",
    "realterm.exe",
    "docklight.exe",
    "hercules.exe",
    "com0com.exe",
}
COM_PORT_CMDLINE_HINTS = ("com", "serial", "\\\\.\\com")

ALL_MONITORED_NAMES = (
    ETGUI_NAMES
    | MOBAXTERM_NAMES
    | WINDOWS_APP_NAMES
    | RDP_PROCESS_HINTS
    | CAMERA_PROCESS_NAMES
    | COM_PORT_PROCESS_NAMES
)

_ACTIVE_SESSION_STATES = frozenset({"active", "running", "connected", ""})


@dataclass
class ProcessInfo:
    name: str
    username: str | None
    pid: int
    cmdline: str
    session: str | None = None  # Session name from tasklist (e.g. Console, rdp-tcp#0)
    session_id: str | None = None  # Session# from tasklist (e.g. 1, 2)


def normalize_user(username: str | None) -> str | None:
    if not username:
        return None
    if "\\" in username:
        return username.split("\\", 1)[-1]
    return username


def analyze_sessions_and_processes(
    sessions: list[dict[str, str]],
    session_types: dict[str, str],
    processes: list[ProcessInfo],
) -> dict:
    active_users = [
        s["username"]
        for s in sessions
        if s.get("state", "").lower() in _ACTIVE_SESSION_STATES and s.get("username")
    ]

    local_user = (
        _console_user(sessions)
        or _console_user_from_processes(processes)
        or (active_users[0] if active_users else None)
    )
    fallback_user = local_user or (active_users[0] if active_users else None)

    rdp_users: set[str] = set()
    windows_app_users: set[str] = set()

    for s in sessions:
        user = s.get("username")
        if not user:
            continue
        sess = (s.get("session") or "").lower()
        stype = session_types.get(user, session_types.get(s.get("session", ""), ""))
        if "rdp" in sess or "rdp-tcp" in sess or stype in ("10", "rdp", "remote"):
            rdp_users.add(user)
        if any(p.name in WINDOWS_APP_NAMES for p in processes if p.username == user):
            windows_app_users.add(user)

    for proc in processes:
        if proc.name in RDP_PROCESS_HINTS and proc.username:
            rdp_users.add(proc.username)
        if proc.name in WINDOWS_APP_NAMES and proc.username:
            windows_app_users.add(proc.username)

    rdp_users.update(_users_in_process_sessions(processes, "rdp-tcp", "rdp#"))
    if not windows_app_users and _any_process_named(processes, WINDOWS_APP_NAMES):
        windows_app_users.add("(running)")

    camera_user, camera_tools = _detect_camera(processes)

    return {
        "local_user": local_user,
        "rdp_users": sorted(rdp_users),
        "windows_app_users": sorted(windows_app_users),
        "mobaxterm_user": _owner_for_processes(processes, MOBAXTERM_NAMES, fallback_user)
        or _running_marker(processes, MOBAXTERM_NAMES),
        "com_port_user": _detect_com_port_user(processes, fallback_user)
        or _running_marker(processes, COM_PORT_PROCESS_NAMES),
        "etgui_user": _owner_for_processes(processes, ETGUI_NAMES, fallback_user)
        or _running_marker(processes, ETGUI_NAMES),
        "camera_user": camera_user,
        "camera_tools": camera_tools,
    }


def _users_in_process_sessions(processes: list[ProcessInfo], *needles: str) -> set[str]:
    users: set[str] = set()
    for proc in processes:
        if not proc.username:
            continue
        sess = (proc.session or "").lower()
        if any(n in sess for n in needles):
            users.add(proc.username)
    return users


def _console_user_from_processes(processes: list[ProcessInfo]) -> str | None:
    for proc in processes:
        if not proc.username:
            continue
        sess = (proc.session or "").lower()
        if "console" in sess or sess in ("0", "1"):
            return proc.username
    return None


def _any_process_named(processes: list[ProcessInfo], names: set[str]) -> bool:
    return any(proc.name in names for proc in processes)


def _running_marker(processes: list[ProcessInfo], names: set[str]) -> str | None:
    if _any_process_named(processes, names):
        return "(running)"
    return None


def list_detected_tools(processes: list[ProcessInfo]) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    for proc in processes:
        if proc.name in ALL_MONITORED_NAMES and proc.name not in seen:
            seen.add(proc.name)
            found.append(proc.name)
    return sorted(found)


def _console_user(sessions: list[dict[str, str]]) -> str | None:
    for s in sessions:
        sess = (s.get("session") or "").lower()
        user = s.get("username")
        if user and ("console" in sess or sess in ("0", "1")):
            return user
    return None


def _owner_for_processes(
    processes: list[ProcessInfo],
    names: set[str],
    fallback_user: str | None = None,
) -> str | None:
    found = False
    for proc in processes:
        if proc.name in names:
            found = True
            if proc.username:
                return proc.username
    if found and fallback_user:
        return fallback_user
    return None


def _detect_com_port_user(
    processes: list[ProcessInfo],
    fallback_user: str | None = None,
) -> str | None:
    for proc in processes:
        if proc.name in COM_PORT_PROCESS_NAMES:
            if proc.username:
                return proc.username
            if fallback_user:
                return fallback_user
        if proc.username and any(h in proc.cmdline for h in COM_PORT_CMDLINE_HINTS):
            if proc.name in MOBAXTERM_NAMES:
                continue
            return proc.username
    return None


def enrich_process_users(
    processes: list[ProcessInfo], session_users: dict[str, str]
) -> None:
    """Map quser session ids/names onto tasklist rows (tasklist without /V has no user column)."""
    for proc in processes:
        if proc.username:
            continue
        keys: list[str] = []
        if proc.session_id:
            keys.extend([proc.session_id, proc.session_id.lower()])
        if proc.session:
            sn = proc.session.lower()
            keys.extend([sn, sn.split("#")[0]])
        for key in keys:
            if key and key in session_users:
                proc.username = session_users[key]
                break


def processes_missing_monitored_usernames(processes: list[ProcessInfo]) -> list[ProcessInfo]:
    """Processes we care about that still lack an owning user."""
    return [
        p
        for p in processes
        if p.pid and not p.username and p.name in ALL_MONITORED_NAMES
    ]


def _detect_camera(processes: list[ProcessInfo]) -> tuple[str | None, list[str]]:
    tools: list[str] = []
    user: str | None = None
    for proc in processes:
        matched = False
        if proc.name in CAMERA_PROCESS_NAMES:
            tools.append(proc.name)
            matched = True
        elif proc.name.startswith("python") and any(
            h in proc.cmdline for h in CAMERA_PYTHON_HINTS
        ):
            tools.append(f"python-camera ({proc.pid})")
            matched = True
        if matched and proc.username:
            user = proc.username
    return user, sorted(set(tools))
