# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-isv-admin>

import base64
import json
import time
from typing import Any
from joserfc import jwt, jwk
from joserfc.errors import (
    JoseError,
    InvalidTokenError as JoseInvalidTokenError,
    ExpiredTokenError as JoseExpiredTokenError,
    BadSignatureError,
    DecodeError,
)

# Exception classes matching PyJWT's API
class InvalidTokenError(JoseInvalidTokenError, ValueError):
    pass


class ExpiredSignatureError(JoseExpiredTokenError, InvalidTokenError):
    pass


def decode(
    jwt_string: str,
    key: Any = None,
    algorithms: list[str] | None = None,
    options: dict[str, Any] | None = None,
    audience: str | list[str] | None = None,
    issuer: str | None = None,
    leeway: int = 0,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Decodes a JWT token.
    Uses joserfc to replace PyJWT.
    """
    if options is None:
        options = {}

    if options.get("verify_signature") is False:
        # Decode without signature verification
        parts = jwt_string.split(".")
        if len(parts) != 3:
            raise InvalidTokenError("Malformed or invalid token: Expected 3 parts")

        payload_b64 = parts[1]
        rem = len(payload_b64) % 4
        if rem > 0:
            payload_b64 += "=" * (4 - rem)

        try:
            payload_bytes = base64.urlsafe_b64decode(payload_b64.encode("utf-8"))
            payload = json.loads(payload_bytes.decode("utf-8"))
            return payload
        except Exception as e:
            raise InvalidTokenError(
                f"Malformed or invalid token: Failed to decode: {e}"
            )

    # Signature verification requested
    if key is None:
        raise ValueError("Key is required for signature verification")

    # Adapt algorithms
    if not algorithms and "algorithm" in kwargs:
        algorithms = [kwargs["algorithm"]]

    try:
        parts = jwt_string.split(".")
        if len(parts) >= 1:
            header_b64 = parts[0]
            rem = len(header_b64) % 4
            if rem > 0:
                header_b64 += "=" * (4 - rem)
            header_data = json.loads(base64.urlsafe_b64decode(header_b64).decode("utf-8"))
            alg = header_data.get("alg")
            if alg and not algorithms:
                algorithms = [alg]
    except Exception:
        pass

    # Ensure joserfc key wrapper is used
    try:
        if not isinstance(key, jwk.KeyBase):
            from cryptography.hazmat.primitives.asymmetric import ed25519
            if (
                isinstance(key, (ed25519.Ed25519PrivateKey, ed25519.Ed25519PublicKey)) or 
                (algorithms and "EdDSA" in algorithms)
            ):
                jose_key = jwk.import_key(key, "OKP")
            elif isinstance(key, (bytes, str)):
                if isinstance(key, str) and key.startswith("-----BEGIN"):
                    jose_key = jwk.import_key(key)
                elif isinstance(key, bytes) and key.startswith(b"-----BEGIN"):
                    jose_key = jwk.import_key(key)
                else:
                    jose_key = jwk.import_key(key, "oct")
            else:
                jose_key = jwk.import_key(key)
        else:
            jose_key = key
    except Exception as e:
        raise InvalidTokenError(f"Invalid key: {e}")

    try:
        token_obj = jwt.decode(jwt_string, jose_key, algorithms=algorithms)
    except JoseExpiredTokenError as e:
        raise ExpiredSignatureError(str(e))
    except JoseInvalidTokenError as e:
        raise InvalidTokenError(str(e))
    except (BadSignatureError, DecodeError) as e:
        raise InvalidTokenError(str(e))
    except Exception as e:
        raise InvalidTokenError(str(e))

    # Claims validation
    verify_exp = options.get("verify_exp", True)
    verify_nbf = options.get("verify_nbf", True)
    verify_iat = options.get("verify_iat", True)
    verify_aud = options.get("verify_aud", True)
    verify_iss = options.get("verify_iss", True)

    class CustomClaimsRegistry(jwt.JWTClaimsRegistry):
        pass

    if not verify_exp:
        CustomClaimsRegistry.validate_exp = lambda self, value: None
    if not verify_nbf:
        CustomClaimsRegistry.validate_nbf = lambda self, value: None
    if not verify_iat:
        CustomClaimsRegistry.validate_iat = lambda self, value: None

    registry_kwargs = {}
    if verify_aud and audience is not None:
        registry_kwargs["aud"] = audience
    if verify_iss and issuer is not None:
        registry_kwargs["iss"] = issuer

    try:
        registry = CustomClaimsRegistry(now=int(time.time()), leeway=leeway, **registry_kwargs)
        registry.validate(token_obj.claims)
    except JoseExpiredTokenError as e:
        raise ExpiredSignatureError(str(e))
    except (JoseInvalidTokenError, JoseError) as e:
        raise InvalidTokenError(str(e))
    except Exception as e:
        raise InvalidTokenError(str(e))

    return token_obj.claims
