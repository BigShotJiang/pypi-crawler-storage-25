import json
from typing import Any
from modulith.capability import Capability, LocalCapability, RemoteCapability


class Modulith:
    def __init__(self, name: str):
        self.name = name
        self.capabilities: dict[str, Capability] = {}
        self.cache: dict[str, Any] = {}

    def _cache_call(self, name: str, kwargs: dict) -> Any:
        cache_key = f"{name}:{json.dumps(kwargs, sort_keys=True)}"
        # Check if the result is in the cache
        if cache_key in self.cache:
            return self.cache[cache_key]
        # If not, execute the capability and store the result in the cache
        capability: Capability = self.capabilities[name]
        result = capability.execute(kwargs)
        self.cache[cache_key] = result
        return result

    def __call__(self, name: str, kwargs: dict | None = None) -> Any:
        # NOTE: This method should be called by local only
        capability: Capability = self.capabilities[name]
        if capability.allow_cache:
            return self._cache_call(name, kwargs)
        return capability.execute(kwargs)

    def capability(
        self, 
        name: str, 
        allow_cache: bool = True,
        max_concurrency: int | None = None,
    ):
        def decorator(func):
            self.capabilities[name] = LocalCapability(
                name=name,
                func=func,
                allow_cache=allow_cache,
                max_concurrency=max_concurrency,
            )
            return func
        return decorator

    @classmethod
    def remote(
        cls,
        repository: str | None = None,
        url: str | None = None,
        urls: list[str] | None = None,
        access_token: str | None = None,
    ) -> None:
        import os
        import logging
        import keyring
        import requests
        from modulith.mns.module import resolve_module

        # Get access token from argument, environment variable, or keyring
        access_token = access_token or os.environ.get("MODULITH_API_TOKEN") or keyring.get_password("modulith", "api_key")

        # Set up headers for authentication if access token is provided
        headers = {"Authorization": f"Bearer {access_token}"} if access_token else {}

        # Resolve module URLs
        if repository:
            logging.info(f"Resolving module from repository: {repository}...")
            remote_urls = resolve_module(repository, access_token)
            logging.info(f"Resolved module URLs: {remote_urls}")
        elif url:
            remote_urls = [url]
        elif urls:
            remote_urls = urls
        else:
            raise ValueError("At least one of 'url', 'urls', or 'repository' must be provided to resolve the module.")

        # Fetch module info from the repository or URL
        module_info = None
        for url in remote_urls:
            response = requests.get(f"{url}/", headers=headers)
            if response.status_code == 200:
                module_info = response.json()
                logging.info(f"Fetched module info: {module_info}")
                break
        if module_info is None:
            raise Exception("Failed to fetch module info from all accessible URLs.")

        # Initialize the module with a LimitedExecution
        module = cls(name=module_info["name"])
        # Add remote capabilities
        for name, capability in module_info["capabilities"].items():
            module.capabilities[name] = RemoteCapability(
                name=name,
                repository=repository,
                signature=capability["signature"],
                docstring=capability["docstring"],
                urls=remote_urls,
                allow_cache=capability["allow_cache"],
                access_token=access_token,
            )
        return module