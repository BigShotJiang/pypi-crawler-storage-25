import typer
import subprocess
from typing import Annotated, Optional


push_app = typer.Typer()
@push_app.command("push")
def push_command(
    image_name: Annotated[
        str,
        typer.Argument(..., help="Name of the Docker image to push, e.g. 'myusername/mymodule'"),
    ],
    tag: Annotated[
        Optional[str],
        typer.Option("--tag", help="Tag for the Docker image. Defaults to the module name."),
    ] = "latest",
    docker_username: Annotated[
        Optional[str],
        typer.Option("--docker-username", help="Your Docker Hub username."),
    ] = None,
    docker_token: Annotated[
        Optional[str],
        typer.Option("--docker-token", help="Your Docker Hub token."),
    ] = None,
):
    if not docker_username:
        docker_username = typer.prompt("Docker Hub Username")

    # Check if tag is included in the image name, if yes, split it and use the provided tag instead of the default tag
    if ":" in image_name:
        image_name, provided_tag = image_name.split(":")
        tag = provided_tag
        typer.echo(f"🔖 Using provided tag '{tag}' from image name.")

    # Push Docker image to Docker Hub
    if not docker_token:
        docker_token = typer.prompt("Docker Hub Token", hide_input=True)
    subprocess.run(f"docker login -u {docker_username} --password-stdin", input=docker_token, text=True, shell=True, check=True)
    subprocess.run(f"docker push {image_name}:{tag}", shell=True, check=True)

    typer.echo(f"✅ Successfully pushed Docker image '{image_name}:{tag}' to Docker Hub.")