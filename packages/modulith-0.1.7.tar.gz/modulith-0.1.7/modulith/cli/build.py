import os
import typer
import keyring
import subprocess
from modulith import Modulith
from typing import Annotated, Optional
from modulith.mns.whoami import whoami
from modulith.cli.push import push_command
from modulith.utils.loaders import load_module
from modulith.mns.guest_signup import guest_signup


dockerfile = """
FROM python:3.12-slim

COPY . .

RUN pip install --no-cache-dir modulith
RUN if [ -f "requirements.txt" ]; then \
    pip install --no-cache-dir -r requirements.txt; \
fi
ENTRYPOINT ["modulith", "serve", "--source", "{MODULE_SOURCE}"]
"""


build_app = typer.Typer()
@build_app.command("build")
def build_command(
    module_source: Annotated[
        str,
        typer.Argument(..., help="Modulith's module source, e.g. 'calculator.module' or 'calculator:module'"),
    ],
    tag: Annotated[
        Optional[str],
        typer.Option("--tag", help="Tag for the Docker image. Defaults to the module name."),
    ] = "latest",
    push: Annotated[
        bool,
        typer.Option("--push", help="Whether to push the built image to Docker Hub."),
    ] = False,
    docker_username: Annotated[
        Optional[str],
        typer.Option("--docker-username", help="Your Docker Hub username."),
    ] = None,
    docker_token: Annotated[
        Optional[str],
        typer.Option("--docker-token", help="Your Docker Hub token."),
    ] = None,
    auth_token: Annotated[
        Optional[str],
        typer.Option("--auth-token", help="Your authentication token. If not provided, a token will be generated and displayed in the console."),
    ] = None,
):
    if not docker_username:
        docker_username = typer.prompt("Docker Hub Username")

    auth_token = auth_token or os.environ.get("MODULITH_API_TOKEN") or keyring.get_password("modulith", "api_key")
    if auth_token is None:
        auth_token = guest_signup()
        typer.echo()
        typer.echo(f"🔑 Your authentication token: {auth_token}")

    # Create Dockerfile
    with open("Dockerfile", "w") as f:
        f.write(dockerfile.format(MODULE_SOURCE=module_source))

    # Build Docker image
    module: Modulith = load_module(module_source)
    modulith_username = whoami(api_key=auth_token)
    image_name = f"{docker_username}/{modulith_username}.{module.name}"
    subprocess.run(f"docker build -t {image_name}:{tag} .", shell=True, check=True)
    typer.echo(f"✅ Successfully built '{module.name}' module's Docker image '{image_name}:{tag}'.")

    # Push Docker image to registry
    if push:
        push_command(
            image_name=image_name,
            tag=tag,
            docker_username=docker_username,
            docker_token=docker_token,
        )