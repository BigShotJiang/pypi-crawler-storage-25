import json
import typer
from modulith import Modulith
from typing import Annotated, Optional
from modulith.utils.loaders import load_module


run_app = typer.Typer()
@run_app.command("run")
def run_command(
    module_source: Annotated[
        str,
        typer.Argument(..., help="Python module source, e.g. 'calculator.module' for ./calculator/module.py or 'calculator:module' for ./calculator.py with a variable named 'module'"),
    ],
    capability: Annotated[
        str,
        typer.Argument(..., help="Capability to run the module with."),
    ],
    kwargs: Annotated[
        Optional[str],
        typer.Option("--kwargs", help="Input kwargs as a JSON string."),
    ] = None,
):
    kwargs = json.loads(kwargs) if kwargs else {}
    module: Modulith = load_module(module_source)
    output = module(capability, kwargs=kwargs)
    typer.echo(output)