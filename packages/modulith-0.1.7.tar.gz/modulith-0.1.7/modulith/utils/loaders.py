import os
import sys
import importlib
from modulith import Modulith


def load_module(module_ref: str):
    variable_name = None
    if ":" in module_ref:
        module_ref, variable_name = module_ref.split(":")
    
    # Add the current working directory to sys.path if it's not already there
    if os.getcwd() not in sys.path:
        sys.path.insert(0, os.getcwd())
    
    mod = importlib.import_module(module_ref)
    if variable_name is None:
        for name in ("module", "app", "service", "tool"):
            if hasattr(mod, name):
                variable_name = name
                break

    if variable_name is None:
        raise ValueError(f"Module reference '{module_ref}' does not specify a variable name and no default variable ('module', 'app', 'service', or 'tool') was found. Please specify the variable name explicitly, e.g. '{module_ref}:variable_name'.")

    module = getattr(mod, variable_name)
    if isinstance(module, Modulith):
        return module
    
    raise ValueError(f"Module '{module_ref}' is not an instance of Modulith.")