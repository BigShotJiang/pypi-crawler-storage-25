import math
import time
import threading


class Bucket:
    def __init__(
        self, 
        capacity: int,      # max burst size
        refill_rate: int    # tokens per minute
    ):
        self.capacity = math.ceil(capacity) if capacity < 1 else capacity
        self.refill_rate = refill_rate / 60  # tokens per minute to tokens per second
        self.tokens = float(capacity)
        self.last_refill = time.monotonic()

    def estimate_wait_time(self, amount: float = 1.0) -> float:
        if self.tokens >= amount:
            return 0.0
        needed_tokens = amount - self.tokens
        return needed_tokens / self.refill_rate

    def consume(self, amount: float = 1.0) -> bool:
        now = time.monotonic()
        elapsed = now - self.last_refill
        self.last_refill = now

        # refill
        self.tokens = min(
            self.capacity,
            self.tokens + elapsed * self.refill_rate
        )

        if self.tokens >= amount:
            self.tokens -= amount
            return True

        return False

class TokenBucketLimiter:
    def __init__(self, capacity: int = 1, refill_rate: int | None = None):
        self.capacity = capacity
        self.refill_rate = refill_rate
        self._buckets: dict[str, Bucket] = {}
        self._lock = threading.Lock()

    def get_quota(self, key: str) -> float:
        if self.refill_rate is None:
            return 1e18  # no limit

        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                return self.capacity  # full bucket for new keys
            else:
                # Refill the bucket before returning the token count
                now = time.monotonic()
                elapsed = now - bucket.last_refill
                bucket.last_refill = now
                bucket.tokens = min(
                    bucket.capacity,
                    bucket.tokens + elapsed * bucket.refill_rate
                )
                return bucket.tokens

    def estimate_wait_time(
        self,
        key: str,
        tokens: float = 1.0,
    ) -> float:
        if self.refill_rate is None:
            return 0.0  # no limit

        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                return 0.0  # no tokens consumed yet, so no wait time

            return bucket.estimate_wait_time(tokens)

    def consume(
        self,
        key: str,
        tokens: float = 1.0,
    ) -> bool:
        if self.refill_rate is None:
            return True  # no limit

        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                bucket = Bucket(capacity=self.capacity, refill_rate=self.refill_rate)
                self._buckets[key] = bucket

            return bucket.consume(tokens)