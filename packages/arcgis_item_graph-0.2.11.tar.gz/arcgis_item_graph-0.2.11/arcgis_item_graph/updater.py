"""
ItemGraphUpdater — incremental updates to the organization-wide dependency graph.
Designed for scheduled runs. Requires an existing GML file from ItemGraphCreator.
"""
import datetime
import time
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import networkx as nx
from arcgis.apps.itemgraph import create_dependency_graph, load_from_file, ItemGraph
from arcgis_item_graph.utils import categorize_hydration_error

logger = logging.getLogger(__name__)


class ItemGraphUpdater:
    """
    Manages incremental updates to an organization-wide item dependency graph.

    Attributes:
        gis: ArcGIS GIS connection object
        gml_file: Path to the GML file storing the graph
        timestamp_file: Path to the timestamp file
        max_retries: Maximum retry attempts for API calls
        retry_delay: Initial delay for exponential backoff (seconds)
    """

    def __init__(
        self,
        gis,
        gml_file: str,
        timestamp_file: str,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        max_items: int = 10000,
        hydration_workers: int = 10,
    ):
        """Initialize the updater with file paths and GIS connection."""
        self.gis = gis
        self.gml_file = Path(gml_file)
        self.timestamp_file = Path(timestamp_file)
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.max_items = max_items
        self.hydration_workers = hydration_workers

        # Ensure directories exist
        self.gml_file.parent.mkdir(parents=True, exist_ok=True)
        self.timestamp_file.parent.mkdir(parents=True, exist_ok=True)

    def get_last_timestamp(self) -> int:
        """
        Retrieve the timestamp of the last graph update.

        Returns:
            Timestamp in milliseconds since epoch

        Raises:
            FileNotFoundError: If timestamp file doesn't exist
        """
        if not self.timestamp_file.exists():
            logger.warning(
                f"Timestamp file not found: {self.timestamp_file}. "
                "This appears to be the first run."
            )
            raise FileNotFoundError(
                f"Timestamp file not found: {self.timestamp_file}"
            )

        try:
            with open(self.timestamp_file, 'r') as f:
                timestamp = int(f.read().strip())
            logger.info(f"Last update timestamp: {timestamp}")
            return timestamp
        except ValueError as e:
            logger.error(f"Invalid timestamp format: {e}")
            raise ValueError(
                f"Could not parse timestamp from {self.timestamp_file}"
            ) from e

    def save_timestamp(self, timestamp: int) -> None:
        """
        Save the current timestamp for the next update.

        Args:
            timestamp: Timestamp in milliseconds since epoch
        """
        with open(self.timestamp_file, 'w') as f:
            f.write(str(timestamp))
        logger.info(f"Saved new timestamp: {timestamp}")

    def get_current_timestamp(self) -> int:
        """Get the current timestamp in milliseconds."""
        return int(datetime.datetime.now().timestamp() * 1000)

    def get_modified_items_with_retry(
        self,
        old_timestamp: int,
        new_timestamp: int
    ) -> list:
        """
        Search for items modified between two timestamps with retry logic.

        Args:
            old_timestamp: Start timestamp (milliseconds)
            new_timestamp: End timestamp (milliseconds)

        Returns:
            List of modified Item objects
        """
        query = f"modified: [{old_timestamp} TO {new_timestamp}]"
        attempt = 0
        delay = self.retry_delay

        while attempt < self.max_retries:
            try:
                logger.info(
                    f"Searching for modified items "
                    f"(attempt {attempt + 1}/{self.max_retries})"
                )
                modified_items = self.gis.content.search(
                    query=query,
                    sort_field="modified",
                    sort_order="desc",
                    max_items=self.max_items,
                )
                logger.info(f"Found {len(modified_items)} modified items")

                if len(modified_items) >= self.max_items:
                    logger.warning(
                        f"Modified-items search returned {len(modified_items)} results, "
                        f"which equals max_items={self.max_items}. "
                        "Some modified items may have been truncated. "
                        "Consider increasing max_items or shortening the update interval."
                    )

                return modified_items

            except Exception as e:
                attempt += 1
                if attempt >= self.max_retries:
                    logger.error(
                        f"Failed to search for modified items after "
                        f"{self.max_retries} attempts: {e}"
                    )
                    raise

                logger.warning(
                    f"Search attempt {attempt} failed: {e}. "
                    f"Retrying in {delay} seconds..."
                )
                time.sleep(delay)
                delay *= 2  # Exponential backoff

    def load_old_graph_with_retry(self) -> ItemGraph:
        """
        Load the existing graph with comprehensive error diagnostics.
        """
        if not self.gml_file.exists():
            raise FileNotFoundError(f"GML file not found: {self.gml_file}")

        attempt = 0
        delay = self.retry_delay

        while attempt < self.max_retries:
            try:
                logger.info(
                    f"Loading graph from file "
                    f"(attempt {attempt + 1}/{self.max_retries})"
                )
                graph = load_from_file(
                    str(self.gml_file),
                    self.gis,
                    include_items=False
                )
                logger.info(f"Loaded graph structure with {len(graph.all_items())} nodes")

                # Graph loaded for structure only — item metadata is not needed for the
                # merge/cleanup pipeline.  Newly modified items are hydrated by
                # create_dependency_graph() in Step 4.  Full metadata is available in
                # query results via _hydrate_result_nodes().
                return graph

            except Exception as e:
                attempt += 1
                if attempt >= self.max_retries:
                    logger.error(
                        f"Failed to load graph after {self.max_retries} attempts: {e}"
                    )
                    raise

                logger.warning(
                    f"Load attempt {attempt} failed: {e}. "
                    f"Retrying in {delay} seconds..."
                )
                time.sleep(delay)
                delay *= 2

    def _hydrate_graph_items_with_diagnostics(
        self, graph: ItemGraph, nodes: list
    ) -> None:
        """
        Fetch portal metadata for all nodes in parallel, then process results serially.

        Phase 1 (parallel): ThreadPoolExecutor workers call gis.content.get() — no
        shared mutation happens in worker threads.
        Phase 2 (serial): main thread sets node.item and updates graph/diagnostics.

        Args:
            graph: ItemGraph whose nodes are being hydrated.
            nodes: List of ItemNode objects to hydrate (pre-fetched via all_items()).
        """
        logger.info(
            f"Hydrating {len(nodes)} graph items with {self.hydration_workers} workers..."
        )
        diagnostics = {
            "malformed_url_ids": [],
            "deleted_items": [],
            "network_errors": [],
            "permission_denied": [],
            "successfully_hydrated": 0,
            "removed": 0,
        }

        # ── Phase 1: parallel fetch ───────────────────────────────────────────
        def _fetch(node):
            """Worker: returns (node, item_or_none, error_str_or_none)."""
            try:
                return (node, self.gis.content.get(node.id), None)
            except Exception as exc:
                return (node, None, str(exc))

        results = []
        with ThreadPoolExecutor(max_workers=self.hydration_workers) as executor:
            futures = {executor.submit(_fetch, node): node for node in nodes}
            for i, future in enumerate(as_completed(futures), start=1):
                if i % 100 == 0:
                    logger.debug(f"Hydration progress: {i}/{len(nodes)} completed")
                results.append(future.result())

        # ── Phase 2: serial processing (all graph mutations here) ─────────────
        for node, item, error_str in results:
            if error_str is None:
                node.item = item
                node.deprecated = bool(getattr(item, "deprecated", False))
                diagnostics["successfully_hydrated"] += 1
                continue

            error_type = categorize_hydration_error(error_str, node.id)
            logger.warning(f"[{error_type}] Item {node.id}: {error_str}")
            node.broken_reason = error_type

            if error_type == "malformed_url":
                diagnostics["malformed_url_ids"].append(
                    {"id": node.id, "reason": "URL detected as item ID"}
                )
            elif error_type == "deleted":
                diagnostics["deleted_items"].append({"id": node.id, "error": error_str})
            elif error_type == "network":
                diagnostics["network_errors"].append({"id": node.id, "error": error_str})
            elif error_type == "permission":
                diagnostics["permission_denied"].append({"id": node.id, "error": error_str})

            if error_type in ("malformed_url", "deleted"):
                try:
                    graph.remove_node(node.id)
                    diagnostics["removed"] += 1
                    logger.debug(f"Removed node: {node.id}")
                except Exception as remove_err:
                    logger.warning(f"Could not remove node {node.id}: {remove_err}")
            else:
                logger.info(f"Keeping node {node.id} (transient error, not a deletion)")

        self._print_hydration_diagnostics(diagnostics)

    def _categorize_hydration_error(self, error_str: str, item_id: str) -> str:
        """Delegate to the shared utility in arcgis_item_graph.utils."""
        return categorize_hydration_error(error_str, item_id)

    def _print_hydration_diagnostics(self, diagnostics: dict) -> None:
        """
        Print a comprehensive diagnostic report of hydration results.
        """
        logger.info("=" * 70)
        logger.info("HYDRATION DIAGNOSTICS REPORT")
        logger.info("=" * 70)
        logger.info(f"Successfully hydrated: {diagnostics['successfully_hydrated']}")
        logger.info(f"Total removed from graph: {diagnostics['removed']}")
        logger.info("")

        if diagnostics['malformed_url_ids']:
            logger.warning(f"{len(diagnostics['malformed_url_ids'])} MALFORMED URL IDs detected:")
            logger.warning("These appear to be REST service references, not Portal item IDs.")
            for item in diagnostics['malformed_url_ids'][:5]:
                logger.warning(f"  - {item['id']}")
            if len(diagnostics['malformed_url_ids']) > 5:
                logger.warning(f"  ... and {len(diagnostics['malformed_url_ids']) - 5} more")

        if diagnostics['deleted_items']:
            logger.warning(f"{len(diagnostics['deleted_items'])} DELETED ITEMS detected:")
            logger.warning("These items no longer exist in the Portal (HTTP 500 / ItemInfo not found)")
            for item in diagnostics['deleted_items'][:5]:
                logger.warning(f"  - {item['id']}")
            if len(diagnostics['deleted_items']) > 5:
                logger.warning(f"  ... and {len(diagnostics['deleted_items']) - 5} more")

        if diagnostics['network_errors']:
            logger.error(f"{len(diagnostics['network_errors'])} NETWORK ERRORS encountered:")
            logger.error("These items could not be accessed due to connectivity issues.")
            logger.error("Consider re-running the script. These nodes were KEPT in the graph.")
            for item in diagnostics['network_errors'][:3]:
                logger.error(f"  - {item['id']}: {item['error'][:80]}")
            if len(diagnostics['network_errors']) > 3:
                logger.error(f"  ... and {len(diagnostics['network_errors']) - 3} more")

        if diagnostics['permission_denied']:
            logger.error(f"{len(diagnostics['permission_denied'])} PERMISSION DENIED errors:")
            logger.error("Check your ArcGIS authentication and item access permissions.")
            logger.error("These nodes were KEPT in the graph.")
            for item in diagnostics['permission_denied'][:3]:
                logger.error(f"  - {item['id']}")
            if len(diagnostics['permission_denied']) > 3:
                logger.error(f"  ... and {len(diagnostics['permission_denied']) - 3} more")

        logger.info("=" * 70)

    def merge_graphs(
        self,
        old_graph: ItemGraph,
        mod_graph: ItemGraph
    ) -> ItemGraph:
        """
        Merge old graph with modified items graph, handling conflicts.

        Args:
            old_graph: Existing ItemGraph
            mod_graph: ItemGraph with recently modified items

        Returns:
            Merged and updated ItemGraph
        """
        logger.info("Merging old and modified graphs...")
        merged = nx.compose(old_graph, mod_graph)
        logger.info(f"Composed graph has {len(merged.nodes())} nodes")

        old_ids = set(old_graph.all_items('id'))
        mod_ids = set(mod_graph.all_items('id'))
        intersects = old_ids & mod_ids

        logger.info(
            f"Found {len(intersects)} items that were modified "
            "(existed in both old and new graphs)"
        )

        updated_count = 0
        for itemid in list(intersects):
            try:
                old_node = old_graph.get_node(itemid)
                mod_node = mod_graph.get_node(itemid)

                old_contains = set(old_node.contains("id"))
                mod_contains = set(mod_node.contains("id"))

                # Find relationships that no longer exist
                outdated = old_contains - mod_contains

                if outdated:
                    logger.debug(
                        f"Item {itemid}: removing {len(outdated)} outdated relationships"
                    )
                    for dep in list(outdated):
                        merged.delete_relationship(itemid, dep)
                        updated_count += 1

            except Exception as e:
                logger.warning(f"Error updating item {itemid}: {e}")

        logger.info(f"Removed {updated_count} outdated relationships")
        new_graph = ItemGraph(self.gis, digraph=merged)
        logger.info("Successfully converted merged graph back to ItemGraph")

        return new_graph

    def update_node_references(self, graph: ItemGraph) -> None:
        """
        Ensure all nodes reference the current graph instance.

        Args:
            graph: ItemGraph to update
        """
        logger.info("Updating node graph references...")
        nodes = graph.all_items()

        for i, node in enumerate(nodes):
            try:
                node.graph = graph
                if (i + 1) % 100 == 0:
                    logger.debug(f"Updated {i + 1}/{len(nodes)} node references")
            except Exception as e:
                logger.warning(
                    f"Could not update reference for node {node.id}: {e}"
                )

        logger.info(f"Updated references for {len(nodes)} nodes")

    def remove_deleted_items(self, graph: ItemGraph) -> int:
        """Remove URL-shaped node IDs from the graph.

        These are REST service references embedded as dependency IDs — not portal
        items.  They cannot be hydrated and should not accumulate in the graph.

        Note: Cleanup of genuinely deleted portal items is deferred to the next
        full ``create`` run, which rebuilds the graph from scratch.

        Args:
            graph: ItemGraph to clean.

        Returns:
            Number of nodes removed.
        """
        from arcgis_item_graph.utils import classify_node_id

        logger.info("Removing URL-shaped node IDs from graph...")
        nodes = list(graph.all_items())
        removed_count = 0

        for node in nodes:
            if classify_node_id(node.id) != "portal_id":
                try:
                    graph.remove_node(node.id)
                    removed_count += 1
                    logger.debug("Removed URL node: %s", node.id[:80])
                except Exception as e:
                    logger.warning("Could not remove URL node %s: %s", node.id[:80], e)

        logger.info("Removed %d URL-shaped nodes", removed_count)
        return removed_count

    def save_graph(self, graph: ItemGraph) -> None:
        """
        Save the updated graph to the GML file.

        Args:
            graph: ItemGraph to save
        """
        logger.info(f"Saving graph to {self.gml_file}...")
        try:
            graph.write_to_file(str(self.gml_file))
            logger.info(f"Successfully saved graph ({len(graph.all_items())} items)")
        except Exception as e:
            logger.error(f"Failed to save graph: {e}")
            raise

    def update(self) -> dict:
        """
        Perform a complete incremental update of the graph.

        Returns:
            Dictionary with update statistics and diagnostics
        """
        logger.info("=" * 60)
        logger.info("Starting Item Graph Update")
        logger.info("=" * 60)

        stats = {
            'start_time': datetime.datetime.now(),
            'old_timestamp': None,
            'new_timestamp': None,
            'modified_items_found': 0,
            'old_graph_items': 0,
            'new_graph_items': 0,
            'relationships_updated': 0,
            'items_deleted': 0,
            'success': False,
            'error': None
        }

        try:
            # Step 1: Get timestamps
            logger.info("Step 1/6: Retrieving timestamps...")
            old_timestamp = self.get_last_timestamp()
            new_timestamp = self.get_current_timestamp()
            stats['old_timestamp'] = old_timestamp
            stats['new_timestamp'] = new_timestamp

            # Step 2: Load old graph
            logger.info("Step 2/6: Loading previous graph...")
            old_graph = self.load_old_graph_with_retry()
            stats['old_graph_items'] = len(old_graph.all_items())

            # Step 3: Find modified items
            logger.info("Step 3/6: Searching for modified items...")
            modified_items = self.get_modified_items_with_retry(
                old_timestamp,
                new_timestamp
            )
            stats['modified_items_found'] = len(modified_items)

            if not modified_items:
                logger.info("No modified items found. Skipping graph update.")
                stats['success'] = True
                stats['new_graph_items'] = stats['old_graph_items']
                return stats

            # Step 4: Create graph from modified items
            logger.info("Step 4/6: Creating graph from modified items...")
            mod_graph = create_dependency_graph(self.gis, modified_items)
            logger.info(f"Created modified graph with {len(mod_graph.all_items())} items")

            # Step 5: Merge graphs and clean up
            logger.info("Step 5/6: Merging graphs and removing outdated relationships...")
            new_graph = self.merge_graphs(old_graph, mod_graph)
            self.update_node_references(new_graph)
            deleted = self.remove_deleted_items(new_graph)
            stats['items_deleted'] = deleted
            stats['new_graph_items'] = len(new_graph.all_items())

            # Step 6: Save updated graph and timestamp
            logger.info("Step 6/6: Saving updated graph...")
            self.save_graph(new_graph)
            self.save_timestamp(new_timestamp)

            stats['success'] = True

        except Exception as e:
            stats['success'] = False
            stats['error'] = str(e)
            logger.error(f"Item Graph Update Failed: {e}", exc_info=True)
            logger.info("=" * 60)
            logger.info("Item Graph Update Failed")
            logger.info("=" * 60)
            raise

        finally:
            stats['end_time'] = datetime.datetime.now()
            stats['duration'] = (
                stats['end_time'] - stats['start_time']
            ).total_seconds()

        # Print results after duration is calculated
        logger.info("=" * 60)
        logger.info("Item Graph Update Completed Successfully")
        logger.info("=" * 60)
        self._print_stats(stats)

        return stats

    def _print_stats(self, stats: dict) -> None:
        """Print update statistics to log."""
        logger.info("Update Statistics:")
        logger.info(f"  Duration: {stats['duration']:.2f} seconds")
        logger.info(f"  Old graph items: {stats['old_graph_items']}")
        logger.info(f"  New graph items: {stats['new_graph_items']}")
        logger.info(f"  Modified items found: {stats['modified_items_found']}")
        logger.info(f"  Items deleted: {stats['items_deleted']}")

        items_added = (
            stats['new_graph_items'] -
            stats['old_graph_items'] +
            stats['items_deleted']
        )
        logger.info(f"  Net items added: {items_added}")
