# dbt-dagsterizer

`dbt-dagsterizer` is a Python package for building Dagster automation from dbt metadata.

It is designed to keep Dagster code locations mostly static, while letting developers declare orchestration intent in a small, reviewable YAML file alongside the dbt project.

## Documentation

- Docs index: [docs/README.md](docs/README.md)
- Getting started: [docs/getting-started.md](docs/getting-started.md)
- CLI reference: [docs/concepts/cli.md](docs/concepts/cli.md)
- Template docs (Dagster + dbt + StarRocks): [docs/templates/.../README.md](docs/templates/dagster-dbt-starrocks-code-location/README.md)

## Quick start

### CLI

```bash
dbt-dagsterizer --help
```

Initialize orchestration intent and refresh the dbt manifest:

```bash
dbt-dagsterizer meta init --dbt-project-dir dbt_project --parse
dbt-dagsterizer meta validate --dbt-project-dir dbt_project --prepare
```

### Python

```python
from dbt_dagsterizer.api import build_definitions

defs = build_definitions(dbt_project_dir="./dbt_project")
```

If the project has no dbt models yet (no `models/**/*.sql`), `build_definitions()` still returns a minimal, always-loadable `Definitions`.

## Development

Setup:

```bash
uv sync --dev
```

Run tests:

```bash
uv run pytest
```

Lint:

```bash
uv run ruff check .
```
