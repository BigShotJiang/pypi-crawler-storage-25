# Getting started

`dbt-dagsterizer` helps you generate and validate Dagster orchestration for a dbt project using dbt metadata (`manifest.json`) plus a small, reviewable orchestration file (`dagsterization.yml`).

## Install

If you are developing in this repository:

```bash
uv sync --dev
```

If you are consuming the package from another repo, install it however you install Python dependencies in that repo (for example as an editable dependency during development).

## Quick start (CLI)

Show help:

```bash
dbt-dagsterizer --help
```

List embedded project templates:

```bash
dbt-dagsterizer project list-templates
```

Initialize orchestration intent and refresh the dbt manifest:

```bash
dbt-dagsterizer meta init --dbt-project-dir dbt_project --parse
dbt-dagsterizer meta validate --dbt-project-dir dbt_project --prepare
```

Render a new code-location project (only `--project-name`/`--name` is required; app/package names are derived automatically):

```bash
dbt-dagsterizer project init \
  --output-dir . \
  --project-name "My App" \
  --author-name "You" \
  --author-email "you@example.com"
```

## Quick start (Python)

Build Dagster `Definitions` from a dbt project directory:

```python
from dbt_dagsterizer.api import build_definitions

defs = build_definitions(dbt_project_dir="./dbt_project")
```

If the project has no dbt models yet (no `models/**/*.sql`), `build_definitions()` still returns a minimal, always-loadable `Definitions` so the code location can import successfully.

## Next reads

- Concepts overview: `concepts/overview.md`
- CLI reference: `concepts/cli.md`
- Code location template docs: `templates/dagster-dbt-starrocks-code-location/README.md`
