from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from dbt_dagsterizer.cli import cli


def test_project_init_renders_into_output_dir(tmp_path: Path):
    runner = CliRunner()
    out_dir = tmp_path / "out"

    result = runner.invoke(
        cli,
        [
            "project",
            "init",
            "--output-dir",
            str(out_dir),
            "--project-name",
            "Demo App",
            "--author-name",
            "Demo",
            "--author-email",
            "demo@example.com",
        ],
    )
    assert result.exit_code == 0, result.output
    project_root = out_dir / "demo_app"
    assert project_root.exists()
    assert (project_root / "pyproject.toml").exists()
    assert (project_root / "dbt_project" / "dbt_project.yml").exists()
    assert (project_root / "src" / "demo_app" / "definitions.py").exists()
