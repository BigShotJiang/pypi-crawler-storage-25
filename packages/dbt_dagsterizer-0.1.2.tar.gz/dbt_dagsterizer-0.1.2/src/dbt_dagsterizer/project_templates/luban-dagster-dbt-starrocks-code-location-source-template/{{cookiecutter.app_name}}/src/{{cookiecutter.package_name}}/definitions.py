from dbt_dagsterizer.api import build_definitions


defs = build_definitions(
    dbt_project_dir="dbt_project",
    dbt_profiles_dir="dbt_project",
    default_dbt_target="{{ cookiecutter.default_env }}",
)
