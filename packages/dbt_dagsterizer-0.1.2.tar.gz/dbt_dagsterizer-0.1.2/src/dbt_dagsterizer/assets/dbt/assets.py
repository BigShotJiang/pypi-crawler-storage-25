import json
import os
import time
from pathlib import Path

from dagster import DailyPartitionsDefinition
from dagster_dbt import DbtCliResource, DbtProject, dbt_assets
from dagster_dbt.errors import DagsterDbtCliRuntimeError

from ...orchestration_config import (
    default_orchestration_path,
    index as index_orch,
    load_or_create as load_orch,
    resolve_orchestration_path,
)
from ...resources.dbt import get_dbt_project_dir
from ..sources.automation import load_automation_observable_sources
from .prepare import prepare_manifest_if_missing
from .translator import LubanDagsterDbtTranslator
from .vars import _get_dbt_vars_for_context


_dbt_assets_def = None


def get_dbt_assets():
    global _dbt_assets_def
    if _dbt_assets_def is not None:
        return _dbt_assets_def

    daily_partitions_start_date = os.getenv("DAGSTER_DAILY_PARTITIONS_START_DATE", "2026-03-01")
    daily_partitions_def = DailyPartitionsDefinition(start_date=daily_partitions_start_date)

    dbt_project_dir = get_dbt_project_dir()
    dbt_target = os.getenv("DBT_TARGET") or os.getenv("LUBAN_DEFAULT_DBT_TARGET") or "development"
    dbt_project = DbtProject(
        project_dir=dbt_project_dir,
        target=dbt_target,
        packaged_project_dir=dbt_project_dir,
    )

    prepare_manifest_if_missing()
    automation_observable_tables = {
        spec["table"] for spec in load_automation_observable_sources() if spec.get("table")
    }

    orch_cfg_path = resolve_orchestration_path(
        dbt_project_dir=dbt_project_dir,
        path_=Path(default_orchestration_path(dbt_project_dir=dbt_project_dir).name),
    )
    orch_cfg = load_orch(orch_cfg_path)
    orch_index = index_orch(orch_cfg)

    translator = LubanDagsterDbtTranslator(
        daily_partitions_def=daily_partitions_def,
        automation_observable_tables=automation_observable_tables,
        partitions_by_model=orch_index.partitions_by_model,
    )

    @dbt_assets(
        manifest=dbt_project.manifest_path,
        dagster_dbt_translator=translator,
    )
    def _dbt_assets(context, dbt: DbtCliResource):
        dbt_vars = _get_dbt_vars_for_context(context)
        dbt_args = ["build"]
        if dbt_vars:
            dbt_args += ["--vars", json.dumps(dbt_vars)]

        try:
            yield from dbt.cli(dbt_args, context=context).stream()
        except DagsterDbtCliRuntimeError as e:
            message = str(e)
            if "already exists" not in message:
                raise
            time.sleep(2)
            yield from dbt.cli(dbt_args, context=context).stream()

    _dbt_assets_def = _dbt_assets
    return _dbt_assets_def
