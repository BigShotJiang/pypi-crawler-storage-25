from __future__ import annotations

import click

from dbt_dagsterizer import __version__

from .macros import build_macros_group
from .meta import build_meta_group
from .project import build_project_group


def build_cli() -> click.Group:
    @click.group()
    @click.version_option(__version__, prog_name="dbt-dagsterizer")
    def cli() -> None:
        pass

    cli.add_command(build_meta_group())
    cli.add_command(build_macros_group())
    cli.add_command(build_project_group())
    return cli
