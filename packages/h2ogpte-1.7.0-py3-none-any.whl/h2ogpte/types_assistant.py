from datetime import datetime
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any


# AI Assistant types


class AiAssistant(BaseModel):
    """AI Assistant entity with wake/sleep lifecycle."""

    id: str
    user_id: str
    username: str = ""
    name: str
    description: str = ""
    system_prompt: Optional[str] = ""
    llm: str = ""
    llm_args: Optional[Dict[str, Any]] = None
    status: str = "stopped"
    custom_tool_definition: Optional[str] = None
    mcp_servers: Optional[List[Any]] = None
    credential_ids: Optional[List[str]] = Field(default_factory=list)
    memory_block_id: Optional[str] = None
    notification_email: Optional[str] = None
    notification_smtp: Optional[dict] = None
    wake_count: int = 0
    current_chat_session_id: Optional[str] = None
    history_management: str = "truncation"
    history_max_chars: Optional[int] = None
    history_recent_chars: Optional[int] = None
    history_retrieval_chars: Optional[int] = None
    allowed_tool_actions: Optional[List[str]] = None
    allowed_trigger_types: Optional[List[str]] = None
    tool_action_policies: Optional[Dict[str, str]] = None
    approval_user_id: Optional[str] = None
    custom_approval_text: Optional[str] = None
    policies_locked: bool = False
    custom_approval_locked: bool = False
    forum_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_wake_at: Optional[datetime] = None
    last_sleep_at: Optional[datetime] = None
    error_message: Optional[str] = None
    is_owner: bool = False
    user_access_mode: Optional[str] = None


class AiAssistantEvent(BaseModel):
    """Audit log entry for assistant wake/sleep events."""

    id: str
    assistant_id: str
    event_type: str
    trigger_type: Optional[str] = None
    trigger_detail: Optional[Dict[str, Any]] = None
    chat_session_id: Optional[str] = None
    wake_cycle: Optional[int] = None
    created_at: Optional[datetime] = None


class AiAssistantMessage(BaseModel):
    """Direct message between user and assistant."""

    id: str
    assistant_id: str
    sender_type: str = "user"
    sender_user_id: Optional[str] = None
    sender_username: Optional[str] = None
    assistant_name: Optional[str] = None
    content: str = ""
    file_ids: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    wake_cycle: Optional[int] = None
    created_at: Optional[datetime] = None


class AiAssistantForumLink(BaseModel):
    """Link between an assistant and a forum."""

    junction_id: Optional[str] = None
    forum_id: Optional[str] = None
    forum_name: str = ""
    description: str = ""
    user_id: Optional[str] = None
    username: Optional[str] = None
    access_mode: str = "read"
    connected_at: Optional[datetime] = None
    forum_created_at: Optional[datetime] = None
    forum_updated_at: Optional[datetime] = None
    post_count: int = 0


class AiAssistantScheduleLink(BaseModel):
    """Link between an assistant and a scheduled task."""

    junction_id: Optional[str] = None
    scheduled_task_id: str = ""
    name: str = ""
    description: Optional[str] = None
    schedule_type: Optional[str] = None
    schedule_expression: Optional[str] = None
    task_type: Optional[str] = None
    status: Optional[str] = None
    connected_at: Optional[datetime] = None
    last_execution_at: Optional[datetime] = None
    next_execution_at: Optional[datetime] = None
    execution_count: int = 0


class AiAssistantEventType(BaseModel):
    """Custom event type that assistants can subscribe to and emit."""

    id: str
    name: str
    description: str = ""
    payload_schema: Optional[Dict[str, Any]] = None
    user_id: Optional[str] = None
    subscriber_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class AiAssistantEventSubscription(BaseModel):
    """Subscription linking an assistant to a custom event type."""

    id: str
    assistant_id: str
    event_type_id: str
    event_type_name: Optional[str] = None
    created_at: Optional[datetime] = None


class AiAssistantInterMessage(BaseModel):
    """Direct message between two assistants."""

    id: str
    sender_assistant_id: str
    recipient_assistant_id: str
    content: str = ""
    metadata: Dict[str, Any] = Field(default_factory=dict)
    wake_cycle: Optional[int] = None
    created_at: Optional[datetime] = None


class Forum(BaseModel):
    """Threaded message board for assistant communication."""

    id: str
    user_id: str
    username: str = ""
    name: str
    description: str = ""
    post_count: int = 0
    assistant_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    is_owner: bool = False
    user_access_mode: Optional[str] = None


class ForumPost(BaseModel):
    """A post in a forum, supporting threading."""

    id: str
    forum_id: str
    author_user_id: Optional[str] = None
    author_assistant_id: Optional[str] = None
    author_owner_user_id: Optional[str] = None
    author_username: Optional[str] = None
    author_assistant_name: Optional[str] = None
    parent_post_id: Optional[str] = None
    content: str = ""
    is_pinned: bool = False
    vote_score: int = 0
    depth: int = 0
    file_ids: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    is_author: bool = False
    user_vote: int = 0
    reply_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class AiAssistantFile(BaseModel):
    """File stored by an AI assistant (from messages or forum posts)."""

    file_id: str
    created_at: Optional[datetime] = None
    source: str = "message"


class AiAssistantPermission(BaseModel):
    """Permission record for a shared AI assistant."""

    username: str
    can_read: bool = False
    can_edit: bool = False


class ForumPermission(BaseModel):
    """Permission record for a shared forum."""

    username: str
    can_read: bool = False
    can_edit: bool = False
