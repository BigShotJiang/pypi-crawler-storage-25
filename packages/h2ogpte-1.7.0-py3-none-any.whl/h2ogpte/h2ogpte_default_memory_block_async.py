import json
from typing import Optional


class _DefaultMemoryBlockMixin:
    """Mixin providing default memory block methods for H2OGPTEAsync.

    All methods call self._get() and self._client which are
    resolved via Python's MRO from the main H2OGPTEAsync class.
    """

    async def get_default_memory_blocks(self) -> dict:
        """Get the current user's default memory blocks.

        Returns a dict with key ``'defaults'`` containing a dict with keys
        ``'llm'`` and ``'agent'``, each either a memory block dict or ``None``.

        The two scopes are independent — LLM default applies to non-agent
        chats, agent default applies to agent chats. No cascade between them.

        Example::

            result = await client.get_default_memory_blocks()
            # result['defaults']['llm']    -> MemoryBlock dict or None
            # result['defaults']['agent']  -> MemoryBlock dict or None

        """
        return await self._get("/api/v1/users/current/default_memory_blocks")

    async def set_default_memory_block(
        self,
        scope: str,
        memory_block_id: Optional[str] = None,
    ) -> dict:
        """Set or clear a default memory block for a given scope.

        Args:
            scope: Which scope to set. Must be ``'llm'`` or ``'agent'``.
            memory_block_id: UUID of the memory block to set as default,
                or ``None`` to clear the default for this scope.

        Returns:
            A dict with ``'scope'`` and ``'memory_block'`` (the set
            block or ``None`` if cleared).

        Raises:
            ValueError: If scope is not 'llm' or 'agent'.

        Example::

            # Set default for LLM (non-agent) chats
            await client.set_default_memory_block('llm', '<block-id>')

            # Set default for agent chats
            await client.set_default_memory_block('agent', '<block-id>')

            # Clear the agent default
            await client.set_default_memory_block('agent', None)

        """
        if scope not in ("llm", "agent"):
            raise ValueError('scope must be "llm" or "agent"')
        endpoint = "/api/v1/users/current/default_memory_blocks"
        body = {"scope": scope, "memory_block_id": memory_block_id}
        headers = await self._get_auth_header()
        headers["Content-Type"] = "application/json"
        content = json.dumps(body, allow_nan=False, separators=(",", ":"))
        res = await self._client.put(
            self._address + endpoint,
            content=content,
            timeout=self.TIMEOUT,
            headers=headers,
        )
        self._raise_error_if_any(res)
        if res.status_code == 204:
            return None
        return res.json()
