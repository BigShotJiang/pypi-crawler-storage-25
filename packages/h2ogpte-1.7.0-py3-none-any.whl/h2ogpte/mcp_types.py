"""Type definitions for MCP inspection and Claude SDK options."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class McpToolInfo(BaseModel):
    """Information about a single MCP sub-tool."""

    name: str
    description: str = ""
    parameters: Optional[Dict[str, Any]] = None


class McpSecurityReport(BaseModel):
    """Security report from MCP server inspection."""

    is_safe: bool = True
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    checks_performed: List[str] = Field(default_factory=list)
    llm_security_rating: Optional[str] = None
    llm_security_score: Optional[int] = None
    llm_security_analysis: Optional[str] = None
    llm_model_used: Optional[str] = None


class McpInspectionResult(BaseModel):
    """Result from inspecting an MCP server."""

    status: str
    server_name: str = ""
    server_type: str = ""
    tools: List[McpToolInfo] = Field(default_factory=list)
    tool_count: int = 0
    total_tool_count: int = 0
    allowed_tools_filter: Optional[List[str]] = None
    security: Optional[McpSecurityReport] = None
    error: Optional[str] = None
    detection_method: str = ""


class McpUnifiedInspectResult(BaseModel):
    """Result from the unified inspect_mcp_tool endpoint."""

    status: str
    servers: List[McpInspectionResult] = Field(default_factory=list)
    error: Optional[str] = None


class McpListToolsResponse(BaseModel):
    """Response from listing MCP server tools."""

    status: str
    servers: Dict[str, Any] = Field(default_factory=dict)
    total_servers: int = 0
    total_tools: int = 0
    error: Optional[str] = None


class ClaudeSdkOptions(BaseModel):
    """Claude SDK options for MCP tool runner configuration.

    All fields are optional — only set fields are sent to the backend.
    """

    effort: Optional[str] = None
    permission_mode: Optional[str] = None
    max_budget_usd: Optional[float] = None
    max_thinking_tokens: Optional[int] = None
    fallback_model: Optional[str] = None
    fork_session: Optional[bool] = None
    enable_file_checkpointing: Optional[bool] = None
    setting_sources: Optional[List[str]] = None
    additional_directories: Optional[List[str]] = None
    betas: Optional[List[str]] = None
    resume_session_at: Optional[str] = None
    sandbox: Optional[Dict[str, Any]] = None
    output_format: Optional[Dict[str, Any]] = None
    hooks: Optional[Dict[str, Any]] = None
    plugins: Optional[List[Dict[str, Any]]] = None
    agent_tool_overrides: Optional[Dict[str, List[str]]] = None
    agent_disallowed_tools: Optional[Dict[str, List[str]]] = None
    agent_skills: Optional[Dict[str, List[str]]] = None

    def to_non_null_dict(self) -> Dict[str, Any]:
        """Return only fields that are explicitly set (not None)."""
        return {k: v for k, v in self.model_dump().items() if v is not None}
