from datetime import datetime
from pydantic import BaseModel
from typing import Optional


class UserApprovalConfig(BaseModel):
    """Admin-assigned approval governance config for a user."""

    id: Optional[str] = None
    user_id: str
    approval_user_id: Optional[str] = None
    approval_user_username: Optional[str] = None
    allow_custom_approval_text: bool = False
    allow_policy_override: bool = True
    allow_approval_user_change: bool = False
    set_by_user_id: Optional[str] = None
    set_by_username: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ApprovalRequest(BaseModel):
    """Approval request for a gated tool action."""

    id: str
    assistant_id: str
    action: str
    summary: str = ""
    details: Optional[dict] = None
    status: str = "pending"
    responded_by: Optional[str] = None
    responded_by_username: Optional[str] = None
    responded_at: Optional[datetime] = None
    reason: Optional[str] = None
    wake_cycle: Optional[int] = None
    chat_session_id: Optional[str] = None
    timeout_at: Optional[datetime] = None
    routed_to_user_id: Optional[str] = None
    routed_to_username: Optional[str] = None
    created_at: Optional[datetime] = None


class ApprovalRequestWithAssistant(ApprovalRequest):
    """Approval request with the owning assistant's name."""

    assistant_name: str = ""
    owner_username: Optional[str] = None
