import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import aiofiles


class _AiAssistantMixin:
    """Mixin providing AI assistant and forum methods for H2OGPTEAsync.

    All methods call self._post(), self._get(), self._delete(), and
    self._post_rest() which are defined on the main H2OGPTEAsync class.
    Python's MRO ensures correct resolution at runtime.
    """

    # ----------------------------------------------------------------------------------
    # AI Assistants
    # ----------------------------------------------------------------------------------

    async def create_ai_assistant(
        self,
        name: str,
        llm: str,
        description: str = "",
        system_prompt: str = "",
        llm_args: Optional[Dict[str, Any]] = None,
        custom_tool_definition: Optional[str] = None,
        mcp_servers: Optional[List[Any]] = None,
        credential_ids: Optional[List[str]] = None,
        memory_block_id: Optional[str] = None,
        notification_email: Optional[str] = None,
        history_management: str = "semantic_retrieval",
        history_max_chars: Optional[int] = None,
        history_recent_chars: Optional[int] = None,
        history_retrieval_chars: Optional[int] = None,
        allowed_tool_actions: Optional[List[str]] = None,
        allowed_trigger_types: Optional[List[str]] = None,
        default_wake_period: Optional[int] = None,
        tool_action_policies: Optional[Dict[str, str]] = None,
        approval_user_id: Optional[str] = None,
        custom_approval_text: Optional[str] = None,
    ) -> str:
        """Create a new AI assistant.

        Args:
            name: Name of the assistant (must be unique per user).
            description: Optional description.
            system_prompt: System prompt for the assistant's LLM calls.
            llm: Model identifier to use.
            llm_args: Optional dict of additional LLM arguments.
            custom_tool_definition: Optional custom tool Python code (None = use default).
            mcp_servers: Optional list of MCP server configuration objects.
            credential_ids: Optional list of credential/secret UUIDs.
            memory_block_id: Optional UUID of a memory block for private state.
            notification_email: Optional email for wake cycle notifications.
            history_management: 'truncation', 'compactification', or 'semantic_retrieval'.
            history_max_chars: Character threshold for history management.
            history_recent_chars: Characters of recent history to always include (semantic_retrieval mode).
            history_retrieval_chars: Characters of retrieved history to include (semantic_retrieval mode).
            allowed_tool_actions: List of allowed tool action names (None = all allowed).
            allowed_trigger_types: List of allowed trigger types (None = all allowed).
            default_wake_period: Periodic wake interval in seconds (None = no periodic wake).
            tool_action_policies: Dict mapping tool action names to policies (None = no policies).
            approval_user_id: Optional UUID of the designated approval user.
            custom_approval_text: Optional custom data protection instructions for the agent.

        Returns:
            str: The ID of the created assistant.
        """
        result = await self._post(
            "/rpc/db",
            [
                "create_ai_assistant",
                name,
                description,
                system_prompt,
                llm,
                llm_args,
                custom_tool_definition,
                mcp_servers,
                credential_ids,
                memory_block_id,
                notification_email,
                history_management,
                history_max_chars,
                history_recent_chars,
                history_retrieval_chars,
                allowed_tool_actions,
                allowed_trigger_types,
                default_wake_period,
                tool_action_policies,
                approval_user_id,
                custom_approval_text,
            ],
        )
        return result["id"]

    async def get_ai_assistant(self, assistant_id: str) -> "AiAssistant":
        """Get details of an AI assistant.

        Args:
            assistant_id: The assistant's UUID.

        Returns:
            AiAssistant: The assistant details.
        """
        from h2ogpte.types import AiAssistant

        result = await self._post("/rpc/db", ["get_ai_assistant", assistant_id])
        return AiAssistant(**result)

    async def list_ai_assistants(
        self,
        offset: int = 0,
        limit: int = 100,
        name_filter: Optional[str] = None,
        status_filter: Optional[str] = None,
    ) -> List["AiAssistant"]:
        """List AI assistants accessible to the current user.

        Args:
            offset: Pagination offset.
            limit: Maximum number of results.
            name_filter: Optional name filter (substring match).
            status_filter: Optional status filter ('stopped', 'running', 'sleeping', 'error').

        Returns:
            List[AiAssistant]: List of assistants.
        """
        from h2ogpte.types import AiAssistant

        result = await self._post(
            "/rpc/db",
            ["list_ai_assistants", offset, limit, name_filter, status_filter],
        )
        return [AiAssistant(**r) for r in result]

    async def update_ai_assistant(
        self,
        assistant_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
        llm: Optional[str] = None,
        llm_args: Optional[Dict[str, Any]] = None,
        custom_tool_definition: Optional[str] = None,
        mcp_servers: Optional[List[Any]] = None,
        credential_ids: Optional[List[str]] = None,
        memory_block_id: Optional[str] = None,
        notification_email: Optional[str] = None,
        history_management: Optional[str] = None,
        history_max_chars: Optional[int] = None,
        history_recent_chars: Optional[int] = None,
        history_retrieval_chars: Optional[int] = None,
        allowed_tool_actions: Optional[List[str]] = None,
        allowed_trigger_types: Optional[List[str]] = None,
        tool_action_policies: Optional[Dict[str, str]] = None,
        approval_user_id: Optional[str] = None,
        custom_approval_text: Optional[str] = None,
        policies_locked: Optional[bool] = None,
        custom_approval_locked: Optional[bool] = None,
    ) -> None:
        """Update an AI assistant's configuration.

        Args:
            assistant_id: The assistant's UUID.
            name: New name (optional).
            description: New description (optional).
            system_prompt: New system prompt (optional).
            llm: New model identifier (optional).
            llm_args: New LLM args dict (optional).
            custom_tool_definition: New custom tool Python code (optional).
            mcp_servers: New MCP server config list (optional).
            credential_ids: New credential UUID list (optional).
            memory_block_id: New memory block UUID (optional).
            notification_email: New notification email (optional).
            history_management: New history mode (optional).
            history_max_chars: New char threshold (optional).
            history_recent_chars: Characters of recent history to always include (optional).
            history_retrieval_chars: Characters of retrieved history to include (optional).
            allowed_tool_actions: List of allowed tool action names (optional).
            allowed_trigger_types: List of allowed trigger types (optional).
            tool_action_policies: Dict mapping tool action names to policies (optional).
            approval_user_id: UUID of the designated approval user (optional).
            custom_approval_text: Custom data protection instructions (optional).
            policies_locked: Lock tool action policies (admin-only) (optional).
            custom_approval_locked: Lock custom approval text (admin-only) (optional).
        """
        await self._post(
            "/rpc/db",
            [
                "update_ai_assistant",
                assistant_id,
                name,
                description,
                system_prompt,
                llm,
                llm_args,
                custom_tool_definition,
                mcp_servers,
                credential_ids,
                memory_block_id,
                notification_email,
                history_management,
                history_max_chars,
                history_recent_chars,
                history_retrieval_chars,
                allowed_tool_actions,
                allowed_trigger_types,
                tool_action_policies,
                approval_user_id,
                custom_approval_text,
                policies_locked,
                custom_approval_locked,
            ],
        )

    async def delete_ai_assistant(self, assistant_id: str) -> None:
        """Delete an AI assistant.

        Uses the REST API endpoint which both deletes from the DB and cleans
        up Redis wake/dedup keys, unlike calling the RPC directly.

        Args:
            assistant_id: The assistant's UUID.
        """
        await self._delete(f"/api/v1/ai_assistants/{assistant_id}")

    async def start_ai_assistant(self, assistant_id: str) -> None:
        """Start an AI assistant (sets status to 'sleeping' and records a start event).

        Uses the REST API endpoint which both updates the DB status and records
        the start event, unlike calling the RPC directly.

        Args:
            assistant_id: The assistant's UUID.
        """
        await self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/start",
            {},
        )

    async def stop_ai_assistant(self, assistant_id: str) -> None:
        """Stop an AI assistant (sets status to 'stopped' and records a stop event).

        Uses the REST API endpoint which both updates the DB status and records
        the stop event, unlike calling the RPC directly.

        Args:
            assistant_id: The assistant's UUID.
        """
        await self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/stop",
            {},
        )

    async def wake_ai_assistant(self, assistant_id: str) -> None:
        """Manually trigger a wake cycle for an AI assistant.

        The assistant must be in 'sleeping' status. This calls the REST API
        endpoint which pushes a wake event to Redis for the event loop to
        process.

        Uses the REST API endpoint which pushes the wake event via Redis,
        unlike calling the RPC directly which would only update the DB status.

        Args:
            assistant_id: The assistant's UUID.
        """
        await self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/wake",
            {},
        )

    async def reset_ai_assistant_tool(self, assistant_id: str) -> None:
        """Reset an AI assistant's custom tool definition to NULL.

        Uses the __CLEAR__ sentinel value recognized by the
        update_ai_assistant DB function to set custom_tool_definition to NULL.

        Args:
            assistant_id: The assistant's UUID.
        """
        await self._post(
            "/rpc/db",
            [
                "update_ai_assistant",
                assistant_id,
                None,  # name
                None,  # description
                None,  # system_prompt
                None,  # llm
                None,  # llm_args
                "__CLEAR__",  # custom_tool_definition - sentinel to set NULL
                None,  # mcp_servers
                None,  # credential_ids
                None,  # memory_block_id
                None,  # notification_email
                None,  # history_management
                None,  # history_max_chars
                None,  # history_recent_chars
                None,  # history_retrieval_chars
                None,  # allowed_tool_actions
                None,  # allowed_trigger_types
            ],
        )

    async def list_ai_assistant_files(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantFile"]:
        """List files stored by an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List[AiAssistantFile]: List of file metadata objects with
                ``file_id``, ``created_at``, and ``source`` fields.
        """
        from h2ogpte.types import AiAssistantFile

        result = await self._post(
            "/rpc/db",
            ["list_assistant_files", assistant_id, offset, limit],
        )
        items = result if isinstance(result, list) else []
        return [AiAssistantFile(**item) for item in items]

    async def download_ai_assistant_file(
        self,
        assistant_id: str,
        file_id: str,
        destination_directory: Union[str, Path],
        destination_file_name: str,
    ) -> Path:
        """Downloads a file stored by an AI assistant to a local directory.

        Args:
            assistant_id: The assistant's UUID.
            file_id: The file's UUID.
            destination_directory: Destination directory to save the file into.
            destination_file_name: Destination file name.

        Returns:
            Path: Path of the downloaded file.
        """
        destination_directory = Path(destination_directory)
        destination_file = destination_directory / destination_file_name
        if not destination_directory.is_dir():
            raise FileNotFoundError("Destination directory does not exist")
        if destination_file.exists():
            raise FileExistsError(f"File {destination_file} already exists")

        res = await self._get(
            f"/api/v1/ai_assistants/{assistant_id}/files/{file_id}/content",
            as_json=False,
        )

        async with aiofiles.open(destination_file, "wb") as f:
            await f.write(res.content)
        return destination_file

    async def send_message_to_assistant(
        self,
        assistant_id: str,
        content: str,
    ) -> str:
        """Send a direct message to an AI assistant.

        Creates the message in the database and automatically pushes a wake
        event if the assistant is in sleeping state. There is no need to call
        wake_ai_assistant() separately.

        Args:
            assistant_id: The assistant's UUID.
            content: The message text.

        Returns:
            str: The ID of the created message.
        """
        result = await self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/messages",
            {"content": content},
        )
        return result["id"]

    async def list_assistant_messages(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 50,
        since: Optional[datetime.datetime] = None,
    ) -> List["AiAssistantMessage"]:
        """List direct messages for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results.
            since: Optional cutoff timestamp — only return messages created
                after this time. Defaults to 2 years on the server side.

        Returns:
            List[AiAssistantMessage]: List of messages.
        """
        from h2ogpte.types import AiAssistantMessage

        since_str = since.isoformat() if since is not None else None
        result = await self._post(
            "/rpc/db",
            ["list_assistant_messages", assistant_id, offset, limit, since_str],
        )
        return [AiAssistantMessage(**r) for r in result]

    async def list_assistant_events(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 50,
        event_type: Optional[str] = None,
        since: Optional[datetime.datetime] = None,
    ) -> List["AiAssistantEvent"]:
        """List wake/sleep events for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results.
            event_type: Optional event type filter ('wake', 'sleep', 'error', 'start', 'stop', 'compactify', 'memory_index').
            since: Optional cutoff timestamp — only return events created
                after this time. Defaults to 2 years on the server side.

        Returns:
            List[AiAssistantEvent]: List of events.
        """
        from h2ogpte.types import AiAssistantEvent

        since_str = since.isoformat() if since is not None else None
        result = await self._post(
            "/rpc/db",
            [
                "list_assistant_events",
                assistant_id,
                offset,
                limit,
                event_type,
                since_str,
            ],
        )
        return [AiAssistantEvent(**r) for r in result]

    async def get_ai_assistant_chat_history(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 10000,
    ) -> str:
        """Get the assistant's full chat history as formatted text.

        Returns the complete conversation history across all wake cycles
        as a plain-text string with question/reply pairs in chronological
        order.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset (default 0).
            limit: Maximum number of chat turns to return (default 10000).

        Returns:
            str: The full chat history as formatted text.
        """
        params = f"?offset={offset}&limit={limit}"
        res = await self._get(
            f"/api/v1/ai_assistants/{assistant_id}/history/chat{params}",
            as_json=False,
        )
        return res.text

    async def get_ai_assistant_event_history(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 10000,
    ) -> str:
        """Get the assistant's full event history as formatted text.

        Returns the complete event/activity log across all wake cycles
        as a plain-text string with timestamps, event types, trigger
        details, and wake cycle numbers.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset (default 0).
            limit: Maximum number of events to return (default 10000).

        Returns:
            str: The full event history as formatted text.
        """
        params = f"?offset={offset}&limit={limit}"
        res = await self._get(
            f"/api/v1/ai_assistants/{assistant_id}/history/events{params}",
            as_json=False,
        )
        return res.text

    async def share_ai_assistant(
        self,
        assistant_id: str,
        username: str,
        access_mode: str = "read",
    ) -> None:
        """Share an AI assistant with another user.

        Args:
            assistant_id: The assistant's UUID.
            username: The username to share with.
            access_mode: Access level - 'read', 'write', or 'read_write'.
        """
        await self._post(
            "/rpc/db",
            ["share_ai_assistant", assistant_id, username, access_mode],
        )

    async def unshare_ai_assistant(
        self,
        assistant_id: str,
        username: str,
    ) -> None:
        """Remove sharing for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            username: The username to unshare from.
        """
        await self._post(
            "/rpc/db",
            ["unshare_ai_assistant", assistant_id, username],
        )

    async def update_ai_assistant_tool(
        self,
        assistant_id: str,
        custom_tool_definition: str,
    ) -> None:
        """Update the custom tool definition for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            custom_tool_definition: The Python code for the custom tool.
        """
        await self._post(
            "/rpc/db",
            [
                "update_ai_assistant",
                assistant_id,
                None,  # name
                None,  # description
                None,  # system_prompt
                None,  # llm
                None,  # llm_args
                custom_tool_definition,  # custom_tool_definition
                None,  # mcp_servers
                None,  # credential_ids
                None,  # memory_block_id
                None,  # notification_email
                None,  # history_management
                None,  # history_max_chars
                None,  # history_recent_chars
                None,  # history_retrieval_chars
                None,  # allowed_tool_actions
                None,  # allowed_trigger_types
            ],
        )

    async def connect_assistant_to_forum(
        self,
        assistant_id: str,
        forum_id: str,
        access_mode: str = "read",
    ) -> None:
        """Connect an AI assistant to a forum.

        Args:
            assistant_id: The assistant's UUID.
            forum_id: The forum's UUID.
            access_mode: Access level - 'read', 'write', or 'read_write'.
                Defaults to 'read' to follow principle of least privilege.
        """
        await self._post(
            "/rpc/db",
            [
                "connect_assistant_to_forum",
                assistant_id,
                forum_id,
                access_mode,
            ],
        )

    async def disconnect_assistant_from_forum(
        self,
        assistant_id: str,
        forum_id: str,
    ) -> None:
        """Disconnect an AI assistant from a forum.

        Args:
            assistant_id: The assistant's UUID.
            forum_id: The forum's UUID.
        """
        await self._post(
            "/rpc/db",
            ["disconnect_assistant_from_forum", assistant_id, forum_id],
        )

    async def list_assistant_forums(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantForumLink"]:
        """List forums connected to an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List[AiAssistantForumLink]: List of forum connections.
        """
        from h2ogpte.types import AiAssistantForumLink

        result = await self._post(
            "/rpc/db",
            ["list_assistant_forums", assistant_id, offset, limit],
        )
        return [AiAssistantForumLink(**r) for r in result]

    async def connect_assistant_to_schedule(
        self,
        assistant_id: str,
        scheduled_task_id: str,
    ) -> None:
        """Connect an AI assistant to a scheduled task as a wake trigger.

        Args:
            assistant_id: The assistant's UUID.
            scheduled_task_id: The scheduled task's UUID.
        """
        await self._post(
            "/rpc/db",
            ["connect_assistant_to_schedule", assistant_id, scheduled_task_id],
        )

    async def disconnect_assistant_from_schedule(
        self,
        assistant_id: str,
        scheduled_task_id: str,
    ) -> None:
        """Disconnect an AI assistant from a scheduled task.

        Args:
            assistant_id: The assistant's UUID.
            scheduled_task_id: The scheduled task's UUID.
        """
        await self._post(
            "/rpc/db",
            ["disconnect_assistant_from_schedule", assistant_id, scheduled_task_id],
        )

    async def list_assistant_schedules(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantScheduleLink"]:
        """List scheduled tasks connected to an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List[AiAssistantScheduleLink]: List of schedule connections.
        """
        from h2ogpte.types import AiAssistantScheduleLink

        result = await self._post(
            "/rpc/db",
            ["list_assistant_schedules", assistant_id, offset, limit],
        )
        return [AiAssistantScheduleLink(**r) for r in result]

    async def create_scheduled_task_for_assistant(
        self,
        assistant_id: str,
        name: str,
        message: str,
        schedule_type: str = "once",
        schedule_expression: str = "",
        run_at: Optional[str] = None,
        cron_expression: Optional[str] = None,
        max_executions: Optional[int] = None,
        notification_email: str = "",
    ) -> str:
        """Create a scheduled task and connect it to an AI assistant.

        This is a convenience method that:
        1. Creates a scheduled task via create_scheduled_task RPC.
        2. Connects the task to the assistant via connect_assistant_to_schedule.

        Args:
            assistant_id: The assistant's UUID.
            name: Task name.
            message: The message/prompt for the task.
            schedule_type: 'once', 'recurring', or 'interval'.
            schedule_expression: Cron expression (for recurring) or interval (for interval).
                Ignored if run_at is provided.
            run_at: ISO 8601 timestamp for one-shot tasks. Sets schedule_type='once'.
            cron_expression: Alias for schedule_expression with schedule_type='recurring'.
            max_executions: Maximum number of executions (null = unlimited).
            notification_email: Email for notifications.

        Returns:
            str: The created scheduled task UUID.
        """
        if run_at:
            schedule_type = "once"
            schedule_expression = run_at
        elif cron_expression:
            schedule_type = "recurring"
            schedule_expression = cron_expression

        task_config = {
            "message": message,
            "llm": "auto",
            "system_prompt": "",
        }
        result = await self._post(
            "/rpc/db",
            [
                "create_scheduled_task",
                name,
                f"Auto-created for assistant {assistant_id}",
                schedule_type,
                schedule_expression,
                "agent_task",
                task_config,
                max_executions,
                None,  # expires_at
                notification_email,
            ],
        )
        task_id = result.get("id") if isinstance(result, dict) else result
        # Connect to assistant
        await self._post(
            "/rpc/db",
            ["connect_assistant_to_schedule", assistant_id, task_id],
        )
        return task_id

    # ----------------------------------------------------------------------------------
    # Custom Event Types & Inter-Assistant Messaging
    # ----------------------------------------------------------------------------------

    async def create_event_type(
        self,
        name: str,
        description: str = "",
        payload_schema: Optional[Dict[str, Any]] = None,
    ) -> "AiAssistantEventType":
        """Create a custom event type that assistants can subscribe to and emit.

        Args:
            name: Name of the event type (max 200 chars, must not collide with built-in types).
            description: Optional description (max 5000 chars).
            payload_schema: Optional JSON schema for event payloads.

        Returns:
            AiAssistantEventType: The created event type.
        """
        from h2ogpte.types import AiAssistantEventType

        result = await self._post(
            "/rpc/db",
            ["create_event_type", name, description, payload_schema],
        )
        return AiAssistantEventType(**result)

    async def list_event_types(
        self,
        assistant_id: Optional[str] = None,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantEventType"]:
        """List custom event types.

        Args:
            assistant_id: Optional assistant ID to include subscription status for.
            offset: Pagination offset.
            limit: Maximum number of results.

        Returns:
            List[AiAssistantEventType]: List of event types.
        """
        from h2ogpte.types import AiAssistantEventType

        result = await self._post(
            "/rpc/db",
            ["list_event_types", limit, offset, assistant_id],
        )
        return [AiAssistantEventType(**r) for r in result]

    async def get_event_type(
        self,
        event_type_id: str,
    ) -> "AiAssistantEventType":
        """Get a custom event type by ID.

        Args:
            event_type_id: The event type's UUID.

        Returns:
            AiAssistantEventType: The event type.
        """
        from h2ogpte.types import AiAssistantEventType

        result = await self._post(
            "/rpc/db",
            ["get_event_type", event_type_id],
        )
        return AiAssistantEventType(**result)

    async def delete_event_type(
        self,
        event_type_id: str,
    ) -> None:
        """Delete a custom event type. Only the creator can delete.

        Cascades to all subscriptions.

        Args:
            event_type_id: The event type's UUID.
        """
        await self._post(
            "/rpc/db",
            ["delete_event_type", event_type_id],
        )

    async def subscribe_assistant_to_event_type(
        self,
        assistant_id: str,
        event_type_id: str,
    ) -> "AiAssistantEventSubscription":
        """Subscribe an assistant to a custom event type.

        Idempotent — re-subscribing returns the existing subscription.

        Args:
            assistant_id: The assistant's UUID.
            event_type_id: The event type's UUID.

        Returns:
            AiAssistantEventSubscription: The subscription record.
        """
        from h2ogpte.types import AiAssistantEventSubscription

        result = await self._post(
            "/rpc/db",
            ["subscribe_to_event_type", assistant_id, event_type_id],
        )
        return AiAssistantEventSubscription(**result)

    async def unsubscribe_assistant_from_event_type(
        self,
        assistant_id: str,
        event_type_id: str,
    ) -> None:
        """Unsubscribe an assistant from a custom event type.

        Args:
            assistant_id: The assistant's UUID.
            event_type_id: The event type's UUID.
        """
        await self._post(
            "/rpc/db",
            ["unsubscribe_from_event_type", assistant_id, event_type_id],
        )

    async def list_assistant_event_subscriptions(
        self,
        assistant_id: str,
    ) -> List["AiAssistantEventSubscription"]:
        """List an assistant's event type subscriptions.

        Args:
            assistant_id: The assistant's UUID.

        Returns:
            List[AiAssistantEventSubscription]: List of subscriptions.
        """
        from h2ogpte.types import AiAssistantEventSubscription

        result = await self._post(
            "/rpc/db",
            ["list_event_subscriptions", assistant_id],
        )
        return [AiAssistantEventSubscription(**r) for r in result]

    async def emit_event(
        self,
        assistant_id: str,
        event_type_name: str,
        payload: Optional[Dict[str, Any]] = None,
        target_assistant_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Emit a custom event that wakes subscribed sleeping assistants.

        This goes through the REST API which handles Redis wake event dispatch.

        Args:
            assistant_id: The emitting assistant's UUID.
            event_type_name: Name of the event type to emit.
            payload: Optional event payload data.
            target_assistant_ids: Optional list of specific assistant IDs to target.

        Returns:
            dict: Response with 'status' and 'woken_count' keys.
        """
        body: Dict[str, Any] = {"event_type_name": event_type_name}
        if payload is not None:
            body["payload"] = payload
        if target_assistant_ids is not None:
            body["target_assistant_ids"] = target_assistant_ids
        result = await self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/emit_event",
            body,
        )
        return result

    async def send_inter_assistant_message(
        self,
        assistant_id: str,
        recipient_assistant_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Send a direct message from one assistant to another.

        Triggers a wake event on the recipient assistant.
        This goes through the REST API which handles Redis wake event dispatch.

        Args:
            assistant_id: The sender assistant's UUID.
            recipient_assistant_id: The recipient assistant's UUID.
            content: Message content (max 100000 chars).
            metadata: Optional metadata dict.

        Returns:
            str: The created message UUID.
        """
        body: Dict[str, Any] = {
            "recipient_assistant_id": recipient_assistant_id,
            "content": content,
        }
        if metadata is not None:
            body["metadata"] = metadata
        result = await self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/send_to_assistant",
            body,
        )
        return (
            result.get("id", str(result)) if isinstance(result, dict) else str(result)
        )

    # ----------------------------------------------------------------------------------
    # Forums
    # ----------------------------------------------------------------------------------

    async def create_forum(
        self,
        name: str,
        description: str = "",
    ) -> str:
        """Create a new forum.

        Args:
            name: Name of the forum (must be unique per user).
            description: Optional description.

        Returns:
            str: The ID of the created forum.
        """
        result = await self._post(
            "/rpc/db",
            ["create_forum", name, description],
        )
        return result["id"]

    async def get_forum(self, forum_id: str) -> "Forum":
        """Get details of a forum.

        Args:
            forum_id: The forum's UUID.

        Returns:
            Forum: The forum details.
        """
        from h2ogpte.types import Forum

        result = await self._post("/rpc/db", ["get_forum", forum_id])
        return Forum(**result)

    async def list_forums(
        self,
        offset: int = 0,
        limit: int = 100,
        name_filter: Optional[str] = None,
    ) -> List["Forum"]:
        """List forums accessible to the current user.

        Args:
            offset: Pagination offset.
            limit: Maximum number of results.
            name_filter: Optional name filter (substring match).

        Returns:
            List[Forum]: List of forums.
        """
        from h2ogpte.types import Forum

        result = await self._post(
            "/rpc/db",
            ["list_forums", offset, limit, name_filter],
        )
        return [Forum(**r) for r in result]

    async def update_forum(
        self,
        forum_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> None:
        """Update a forum's configuration.

        Args:
            forum_id: The forum's UUID.
            name: New name (optional).
            description: New description (optional).
        """
        await self._post(
            "/rpc/db",
            ["update_forum", forum_id, name, description],
        )

    async def delete_forum(self, forum_id: str) -> None:
        """Delete a forum.

        Args:
            forum_id: The forum's UUID.
        """
        await self._post("/rpc/db", ["delete_forum", forum_id])

    async def share_forum(
        self,
        forum_id: str,
        username: str,
        access_mode: str = "read",
    ) -> None:
        """Share a forum with another user.

        Args:
            forum_id: The forum's UUID.
            username: The username to share with.
            access_mode: Access level - 'read', 'write', or 'read_write'.
        """
        await self._post(
            "/rpc/db",
            ["share_forum", forum_id, username, access_mode],
        )

    async def unshare_forum(
        self,
        forum_id: str,
        username: str,
    ) -> None:
        """Remove sharing for a forum.

        Args:
            forum_id: The forum's UUID.
            username: The username to unshare from.
        """
        await self._post(
            "/rpc/db",
            ["unshare_forum", forum_id, username],
        )

    async def create_forum_post(
        self,
        forum_id: str,
        content: str,
        parent_post_id: Optional[str] = None,
        assistant_id: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Create a post on a forum.

        Creates the post via the REST API. Sleeping assistants connected
        to this forum are automatically woken via a push to the event
        queue.

        Args:
            forum_id: The forum's UUID.
            content: The post content.
            parent_post_id: Optional parent post ID for threading (reply).
            assistant_id: Optional assistant ID if posting as an assistant.
            file_ids: Optional list of file UUIDs to attach.
            metadata: Optional metadata dict for custom key-value pairs.
                Note: the 'pinned' key is stripped server-side; use pin_forum_post() instead.

        Returns:
            str: The ID of the created post.
        """
        # All posts go through REST API which triggers wake events
        # for sleeping assistants connected to this forum.
        body: dict = {"content": content}
        if parent_post_id is not None:
            body["parent_post_id"] = parent_post_id
        if assistant_id is not None:
            body["author_assistant_id"] = assistant_id
        if file_ids is not None:
            body["file_ids"] = file_ids
        if metadata is not None:
            body["metadata"] = metadata
        result = await self._post_rest(
            f"/api/v1/forums/{forum_id}/posts",
            body,
        )
        return result["id"]

    async def reply_to_forum_post(
        self,
        forum_id: str,
        post_id: str,
        content: str,
        assistant_id: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Reply to a specific post in a forum.

        Creates a reply via the REST API endpoint, which also triggers
        wake events for sleeping assistants connected to the forum.

        Args:
            forum_id: The forum's UUID.
            post_id: The parent post's UUID to reply to.
            content: The reply content.
            assistant_id: Optional AI assistant UUID to post as.
            file_ids: Optional list of file UUIDs to attach.
            metadata: Optional metadata dict.

        Returns:
            str: The ID of the created reply post.
        """
        body: dict = {"content": content}
        if assistant_id is not None:
            body["author_assistant_id"] = assistant_id
        if file_ids is not None:
            body["file_ids"] = file_ids
        if metadata is not None:
            body["metadata"] = metadata
        result = await self._post_rest(
            f"/api/v1/forums/{forum_id}/posts/{post_id}/reply",
            body,
        )
        return result["id"]

    async def list_forum_posts(
        self,
        forum_id: str,
        offset: int = 0,
        limit: int = 50,
        sort_by: str = "newest",
        parent_post_id: Optional[str] = None,
        since: Optional[datetime.datetime] = None,
    ) -> List["ForumPost"]:
        """List posts in a forum.

        Args:
            forum_id: The forum's UUID.
            offset: Pagination offset.
            limit: Maximum number of results.
            sort_by: Sort order ('top', 'newest', or 'oldest').
            parent_post_id: Filter to replies of a specific post.
            since: Optional cutoff timestamp — only return posts created
                after this time.

        Returns:
            List[ForumPost]: List of posts.
        """
        from h2ogpte.types import ForumPost

        since_str = since.isoformat() if since is not None else None
        result = await self._post(
            "/rpc/db",
            [
                "list_forum_posts",
                forum_id,
                offset,
                limit,
                sort_by,
                parent_post_id,
                since_str,
            ],
        )
        return [ForumPost(**r) for r in result]

    async def get_forum_post(self, post_id: str) -> "ForumPost":
        """Get a single forum post.

        Args:
            post_id: The post's UUID.

        Returns:
            ForumPost: The post details.
        """
        from h2ogpte.types import ForumPost

        result = await self._post("/rpc/db", ["get_forum_post", post_id])
        return ForumPost(**result)

    async def update_forum_post(
        self,
        post_id: str,
        content: str,
    ) -> None:
        """Update a forum post (author only).

        Args:
            post_id: The post's UUID.
            content: New content.
        """
        await self._post("/rpc/db", ["update_forum_post", post_id, content])

    async def delete_forum_post(self, post_id: str) -> None:
        """Delete a forum post.

        Args:
            post_id: The post's UUID.
        """
        await self._post("/rpc/db", ["delete_forum_post", post_id])

    async def vote_on_forum_post(
        self,
        post_id: str,
        vote: int,
        assistant_id: Optional[str] = None,
    ) -> None:
        """Vote on a forum post.

        Args:
            post_id: The post's UUID.
            vote: +1 for upvote, -1 for downvote, 0 to clear vote.
            assistant_id: Optional assistant ID if voting as an assistant.
        """
        await self._post(
            "/rpc/db",
            ["vote_on_forum_post", post_id, vote, assistant_id],
        )

    async def pin_forum_post(
        self,
        post_id: str,
        is_pinned: bool,
    ) -> None:
        """Pin or unpin a forum post (forum owner only).

        Args:
            post_id: The post's UUID.
            is_pinned: True to pin, False to unpin.
        """
        await self._post("/rpc/db", ["pin_forum_post", post_id, is_pinned])

    async def list_ai_assistant_permissions(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantPermission"]:
        """List sharing permissions for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Number of records to skip (default 0).
            limit: Maximum number of records to return (default 100, max 100).

        Returns:
            List[AiAssistantPermission]: List of permission objects with
                ``username``, ``can_read``, ``can_edit`` fields.
        """
        from h2ogpte.types import AiAssistantPermission

        result = await self._post(
            "/rpc/db",
            ["list_ai_assistant_permissions", assistant_id, offset, limit],
        )
        items = result if isinstance(result, list) else []
        return [AiAssistantPermission(**item) for item in items]

    async def list_forum_permissions(
        self,
        forum_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["ForumPermission"]:
        """List sharing permissions for a forum.

        Args:
            forum_id: The forum's UUID.
            offset: Number of records to skip (default 0).
            limit: Maximum number of records to return (default 100, max 100).

        Returns:
            List[ForumPermission]: List of permission objects with
                ``username``, ``can_read``, ``can_edit`` fields.
        """
        from h2ogpte.types import ForumPermission

        result = await self._post(
            "/rpc/db",
            ["list_forum_permissions", forum_id, offset, limit],
        )
        items = result if isinstance(result, list) else []
        return [ForumPermission(**item) for item in items]

    # ----------------------------------------------------------------------------------
    # Webhooks (v3)
    # ----------------------------------------------------------------------------------

    async def create_assistant_webhook(
        self,
        assistant_id: str,
        name: str,
        description: str = "",
        rate_limit_per_minute: int = 10,
    ) -> Dict[str, Any]:
        """Create a webhook endpoint for an AI assistant.

        External systems can wake the assistant by POSTing to the webhook URL.
        The token is returned only once — save it immediately.

        Args:
            assistant_id: ID of the assistant.
            name: Human-readable name for the webhook.
            description: Optional description.
            rate_limit_per_minute: Max invocations per minute (default 10).

        Returns:
            Dict with 'id', 'token' (shown only once), 'name', and webhook URL.
        """
        return await self._post(
            f"/api/v1/ai_assistants_webhooks/{assistant_id}",
            {
                "name": name,
                "description": description,
                "rate_limit_per_minute": rate_limit_per_minute,
            },
        )

    async def list_assistant_webhooks(self, assistant_id: str) -> List[Dict[str, Any]]:
        """List webhooks for an AI assistant (tokens are masked).

        Args:
            assistant_id: ID of the assistant.

        Returns:
            List of webhook dicts with masked tokens.
        """
        result = await self._get(f"/api/v1/ai_assistants_webhooks/{assistant_id}")
        return result if isinstance(result, list) else []

    async def delete_assistant_webhook(
        self, assistant_id: str, webhook_id: str
    ) -> None:
        """Delete a webhook endpoint.

        Args:
            assistant_id: ID of the assistant.
            webhook_id: ID of the webhook to delete.
        """
        await self._delete(
            f"/api/v1/ai_assistants_webhooks/{assistant_id}/{webhook_id}"
        )

    async def regenerate_assistant_webhook_token(
        self, assistant_id: str, webhook_id: str
    ) -> Dict[str, Any]:
        """Regenerate the token for a webhook (invalidates the old token).

        Args:
            assistant_id: ID of the assistant.
            webhook_id: ID of the webhook.

        Returns:
            Dict with the new 'token' (shown only once).
        """
        return await self._post(
            f"/api/v1/ai_assistants_webhooks/{assistant_id}/{webhook_id}/regenerate",
            {},
        )

    # ----------------------------------------------------------------------------------
    # Slack Integration (v3)
    # ----------------------------------------------------------------------------------

    async def create_slack_integration(
        self,
        name: str,
        workspace_id: str,
        bot_token: str,
        signing_secret: str,
    ) -> Dict[str, Any]:
        """Create a Slack integration for connecting Slack channels as forums.

        Args:
            name: Display name for the integration.
            workspace_id: Slack workspace/team ID (e.g., T01234567).
            bot_token: Slack bot token (xoxb-...).
            signing_secret: Slack signing secret for webhook verification.

        Returns:
            Dict with integration details.
        """
        return await self._post(
            "/api/v1/integrations/slack/",
            {
                "name": name,
                "workspace_id": workspace_id,
                "bot_token": bot_token,
                "signing_secret": signing_secret,
            },
        )

    async def list_slack_integrations(self) -> List[Dict[str, Any]]:
        """List all Slack integrations for the current user.

        Returns:
            List of Slack integration dicts.
        """
        result = await self._get("/api/v1/integrations/slack/")
        return result if isinstance(result, list) else []

    async def delete_slack_integration(self, integration_id: str) -> None:
        """Delete a Slack integration and all linked channels.

        Args:
            integration_id: ID of the Slack integration.
        """
        await self._delete(f"/api/v1/integrations/slack/{integration_id}")

    async def link_slack_channel(
        self,
        integration_id: str,
        channel_id: str,
        channel_name: str = "",
        forum_name: str = "",
        sync_direction: str = "bidirectional",
        sync_threads: bool = True,
    ) -> Dict[str, Any]:
        """Link a Slack channel to a forum.

        Creates a new forum backed by the Slack channel. Messages in Slack
        appear as forum posts, and assistant posts appear in Slack.

        Args:
            integration_id: ID of the Slack integration.
            channel_id: Slack channel ID (e.g., C01234567).
            channel_name: Display name of the channel.
            forum_name: Name for the h2ogpte forum (defaults to channel name).
            sync_direction: 'bidirectional', 'slack_to_h2ogpte', or 'h2ogpte_to_slack'.
            sync_threads: Whether to sync Slack threads as forum post threads.

        Returns:
            Dict with channel-forum mapping details.
        """
        return await self._post(
            f"/api/v1/integrations/slack/{integration_id}/channels",
            {
                "channel_id": channel_id,
                "channel_name": channel_name,
                "forum_name": forum_name,
                "sync_direction": sync_direction,
                "sync_threads": sync_threads,
            },
        )

    # ----------------------------------------------------------------------------------
    # Approval Governance (v8)
    # ----------------------------------------------------------------------------------

    async def get_user_approval_config(self, user_id: str) -> "UserApprovalConfig":
        """Get approval governance config for a user. Admin-only.

        Args:
            user_id: The target user's UUID.

        Returns:
            UserApprovalConfig: The approval governance configuration.
        """
        from h2ogpte.types import UserApprovalConfig

        result = await self._get(f"/api/v1/admin/users/{user_id}/approval_config")
        if not result or result == {}:
            return UserApprovalConfig(user_id=user_id)
        return UserApprovalConfig(**result)

    async def set_user_approval_config(
        self,
        user_id: str,
        approval_user_id: Optional[str] = None,
        allow_custom_approval_text: bool = False,
        allow_policy_override: bool = True,
        allow_approval_user_change: bool = False,
    ) -> Dict[str, Any]:
        """Set approval governance config for a user. Admin-only.

        Args:
            user_id: The target user's UUID.
            approval_user_id: UUID of the designated approval user (None = clear).
            allow_custom_approval_text: Allow user to set custom approval text.
            allow_policy_override: Allow user to change tool action policies.
            allow_approval_user_change: Allow user to change their approval user.

        Returns:
            Dict with 'id' and 'status'.
        """
        import json as _json

        headers = await self._get_auth_header()
        headers["Content-Type"] = "application/json"
        res = await self._client.put(
            self._address + f"/api/v1/admin/users/{user_id}/approval_config",
            content=_json.dumps(
                {
                    "approval_user_id": approval_user_id or "",
                    "allow_custom_approval_text": allow_custom_approval_text,
                    "allow_policy_override": allow_policy_override,
                    "allow_approval_user_change": allow_approval_user_change,
                }
            ).encode(),
            timeout=60,
            headers=headers,
        )
        self._raise_error_if_any(res)
        return res.json()

    async def list_approvals_routed_to_me(
        self,
        offset: int = 0,
        limit: int = 50,
    ) -> List["ApprovalRequestWithAssistant"]:
        """List pending approval requests routed to the current user.

        Args:
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List of approval requests routed to the current user.
        """
        from h2ogpte.types import ApprovalRequestWithAssistant

        result = await self._get(
            f"/api/v1/ai_assistants_approvals/routed_to_me?offset={offset}&limit={limit}"
        )
        items = result if isinstance(result, list) else []
        return [ApprovalRequestWithAssistant(**item) for item in items]
