# This file was generated from `h2ogpte_async.py` by executing `make generate-sync-mux-py`.

from pathlib import Path
from typing import Iterable, Any, Union, List, Dict, Tuple, Callable
from h2ogpte.types import *
from h2ogpte.errors import *
from h2ogpte.connectors import *
from h2ogpte.h2ogpte_sync_base import H2OGPTESyncBase
from h2ogpte.h2ogpte_sync_base import (
    _rest_to_client_exceptions,
    _get_result,
    _get_share_permission_status,
)
from h2ogpte import rest_sync as rest
from h2ogpte.h2ogpte_async import (
    unmarshal_dict,
    _to_id,
    _convert_rest_job,
    _serialize_guardrails_response,
)

# Import Session to be be accessible via `from h2ogpte.h2ogpte import Session`
from h2ogpte.session import Session
import ast
import json
import uuid
import io
import datetime
from collections import defaultdict
from urllib.parse import quote
from h2ogpte.utils import _process_pdf_with_annotations, import_pymupdf, SizeConfig


class H2OGPTE(H2OGPTESyncBase):
    """Connect to and interact with an h2oGPTe server."""

    def answer_question(
        self,
        question: str,
        system_prompt: Union[
            str, None
        ] = "",  # "" to disable, 'auto' to use LLMs default, None for h2oGPTe default
        pre_prompt_query: Union[
            str, None
        ] = None,  # "" to disable, None for h2oGPTe default
        prompt_query: Union[
            str, None
        ] = None,  # "" to disable, None for h2oGPTe default
        text_context_list: Optional[List[str]] = None,
        llm: Union[str, int, None] = None,
        llm_args: Optional[Dict[str, Any]] = None,
        chat_conversation: Optional[List[Tuple[str, str]]] = None,
        guardrails_settings: Optional[Dict] = None,
        timeout: Union[float, None] = None,
        **kwargs: Any,
    ) -> Answer:
        """Send a message and get a response from an LLM.

        Note: This method is only recommended if you are passing a chat conversation or for low-volume testing.
        For general chat with an LLM, we recommend session.query() for higher throughput in multi-user environments.
        The following code sample shows the recommended method:

        .. code-block:: python

            # Establish a chat session
            chat_session_id = client.create_chat_session()
            # Connect to the chat session
            with client.connect(chat_session_id) as session:
                # Send a basic query and print the reply
                reply = session.query("Hello", timeout=60)
                print(reply.content)


        Format of inputs content:

            .. code-block::

                {text_context_list}
                \"\"\"\\n{chat_conversation}{question}

        Args:
            question:
                Text query to send to the LLM.
            text_context_list:
                List of raw text strings to be included, will be converted to a string like this: "\n\n".join(text_context_list)
            system_prompt:
                Text sent to models which support system prompts. Gives the model
                overall context in how to respond. Use `auto` for the model default, or None for h2oGPTe default. Defaults
                to '' for no system prompt.
            pre_prompt_query:
                Text that is prepended before the contextual document chunks in text_context_list. Only used if text_context_list is provided.
            prompt_query:
                Text that is appended after the contextual document chunks in text_context_list. Only used if text_context_list is provided.
            llm:
                Name or index of LLM to send the query. Use `H2OGPTE.get_llms()` to see all available options.
                Default value is to use the first model (0th index).
            llm_args:
                Dictionary of kwargs to pass to the llm. Valid keys:
                    # Core generation parameters
                    temperature (float, default: 0) — The value used to modulate the next token probabilities. Most deterministic: 0, Most creative: 1
                    seed (int, default: 0) — The seed for the random number generator, only used if temperature > 0, seed=0 will pick a random number for each call, seed > 0 will be fixed
                    top_k (int, default: 1) — The number of highest probability vocabulary tokens to keep for top-k-filtering
                    top_p (float, default: 1.0) — If set to float < 1, only the smallest set of most probable tokens with probabilities that add up to top_p or higher are kept for generation
                    repetition_penalty (float, default: 1.07) — The parameter for repetition penalty. 1.0 means no penalty
                    max_new_tokens (int, default: 1024) — Maximum number of new tokens to generate. This limit applies to each (map+reduce) step during summarization and each (map) step during extraction
                    min_max_new_tokens (int, default: 512) — Minimum value for max_new_tokens when auto-adjusting for content of prompt, docs, etc.
                    min_chars_per_yield (int) — Minimum number of characters to yield at a time during streaming
                    reasoning_effort (int, default: 0) — Level of reasoning effort for the model (higher values = deeper reasoning, e.g., 10000-65000). Use for models that support chain-of-thought reasoning. 0 means no additional reasoning effort

                    # Output format parameters
                    response_format (str, default: "text") — Output type, one of ["text", "json_object", "json_code"]
                    guided_json (dict, default: None) — If specified, the output will follow the JSON schema
                    guided_regex (str, default: "") — If specified, the output will follow the regex pattern. Only for models that support guided generation: check output of get_llms() for guided_vllm flag
                    guided_choice (Optional[List[str]], default: None) — If specified, the output will be exactly one of the choices. Only for models that support guided generation
                    guided_grammar (str, default: "") — If specified, the output will follow the context free grammar. Only for models that support guided generation
                    guided_whitespace_pattern (str, default: "") — If specified, will override the default whitespace pattern for guided json decoding. Only for models that support guided generation
                    json_preserve_system_prompt (bool) — Whether to preserve the system prompt when using JSON response format

                    # Vision and image parameters
                    images_num_max (int) — Maximum number of images to process
                    visible_vision_models (list) — List of vision models that can be used

                    # Agent parameters
                    use_agent (bool, default: False) — Whether to enable agent functionality for advanced task processing with access to tools
                    shared_agent (bool, default: False) — Whether to use shared agent instance across multiple requests for efficiency
                    agent_type (str, default: "auto") — Type of agent to use. Options: ["auto", "agent_analysis", "agent_chat_history_md", "agent_code", "agent_rag"]
                    selected_tool_type (str, default: "auto") — Type of tools to make available to the agent. Options: ["auto", "all", "any"] or specific tool names
                    selected_agent_type (str, optional) — Agent framework type for agents_builder. Options: ["crewai", "langgraph", "openai"]
                    agent_accuracy (str, default: "standard") — Accuracy level for agent operations. Options:
                        "quick" - Fastest, less verification (max_turns=10, timeout=30s)
                        "basic" - Best for simple tasks (max_turns=20, timeout=60s)
                        "standard" - Good for most tasks (max_turns=40, timeout=120s)
                        "maximum" - Highest accuracy, can take a long time (max_turns=80, timeout=240s)
                    agent_max_turns (Union[str, int], default: "auto") — Maximum number of back-and-forth turns the agent can take. Either "auto" or an integer
                    agent_original_files (list) — List of file paths for agent to process and analyze
                    agent_timeout (int) — Timeout in seconds for each individual agent turn/operation
                    agent_total_timeout (int, default: 3600) — Total timeout in seconds for all agent operations combined
                    agent_min_time (int) — Minimum time in seconds to run the agent before allowing completion
                    agent_tools (Union[str, list], default: "auto") — List of specific tools available to the agent. Options: "auto", "all", "any", or list of tool names
                    user_persona (str) — User persona description for agent context to customize agent behavior
                    agent_code_writer_system_message (str) — Custom system message for code writing agent to guide code generation
                    agent_code_restrictions_level (int) — Level of code execution restrictions for agent (typically 0 for unrestricted)
                    agent_num_executable_code_blocks_limit (int) — Maximum number of code blocks the agent can execute in a single session
                    agent_system_site_packages (bool, default: False) — Whether agent can use system site packages when executing code
                    agent_main_model (str) — Main model to use for agent operations (e.g., specific LLM name)
                    agent_max_stream_length (int, default: -1) — Maximum length for agent streaming responses, -1 for unlimited
                    agent_max_memory_usage (int) — Maximum memory usage in bytes for agent operations
                    agent_main_reasoning_effort (int) — Level of reasoning effort for main agent model (higher values = more reasoning, e.g., 10000)
                    agent_advanced_reasoning_effort (int) — Level of reasoning effort for advanced agent operations (e.g., 20000)
                    agent_max_confidence_level (int) — Maximum confidence level for agent decisions (typically 0, 1, or 2)
                    agent_planning_forced_mode (bool) — Whether to force planning mode for agent (True to always plan first)
                    agent_too_soon_forced_mode (bool) — Whether to force handling of premature agent decisions
                    agent_critique_forced_mode (int) — Whether to force critique mode for agent self-evaluation
                    agent_query_understanding_parallel_calls (int) — Number of parallel calls for query understanding
                    tool_building_mode (str) — Mode for tool building configuration
                    agent_stream_files (bool, default: True) — Whether to stream files from agent operations for real-time updates

                    # Other parameters
                    max_time (int) — Maximum time in seconds for the operation
                    client_metadata (dict) — Metadata to include with the request
            chat_conversation:
                List of tuples for (human, bot) conversation that will be pre-appended
                to an (question, None) case for a query.
            guardrails_settings:
                Guardrails Settings.
            timeout:
                Timeout in seconds.
            kwargs:
                Dictionary of kwargs to pass to h2oGPT. Not recommended, see https://github.com/h2oai/h2ogpt for source code. Valid keys:
                    h2ogpt_key: str = ""
                    chat_conversation: list[tuple[str, str]] | None = None
                    docs_ordering_type: str | None = "best_near_prompt"
                    max_input_tokens: int = -1
                    docs_token_handling: str = "split_or_merge"
                    docs_joiner: str = "\n\n"
                    image_file: Union[str, list] = None

        Returns:
            Answer: The response text and any errors.
        Raises:
            TimeoutError: If response isn't completed in timeout seconds.
        """

        header = self._get_auth_header()
        model_name = self.get_llm_name_for_rest(llm)
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.answer_question(
                    model_name=model_name,
                    question_request=rest.QuestionRequest(
                        question=question,
                        system_prompt=system_prompt,
                        pre_prompt_query=pre_prompt_query,
                        prompt_query=prompt_query,
                        text_context_list=text_context_list,
                        llm_args=llm_args,
                        chat_conversation=chat_conversation,
                        guardrails_settings=(
                            None
                            if guardrails_settings is None
                            else rest.GuardrailsSettings(**guardrails_settings)
                        ),
                        timeout=timeout,
                        additional_properties=kwargs,
                    ),
                    _headers=header,
                )
            )
        ret = response.to_dict()
        if ret["error"]:
            raise SessionError(ret["error"])
        return Answer(**ret)

    def get_llm_name_for_rest(self, llm: Union[str, int, None]):
        if llm is None:
            return "auto"
        if isinstance(llm, str):
            return llm
        if isinstance(llm, int):
            llms = self.get_llms()
            try:
                return llms[llm].get("display_name")
            except IndexError:
                raise IndexError(
                    f"Invalid model index {llm}. Valid range is between 0 and {len(llms)-1}"
                )
        raise ValueError("unexpected type")

    def summarize_content(
        self,
        text_context_list: Optional[List[str]] = None,
        system_prompt: str = "",  # '' to disable, 'auto' to use LLMs default
        pre_prompt_summary: Optional[str] = None,
        prompt_summary: Optional[str] = None,
        llm: Union[str, int, None] = None,
        llm_args: Optional[Dict[str, Any]] = None,
        guardrails_settings: Optional[Dict] = None,
        timeout: Union[float, None] = None,
        **kwargs: Any,
    ) -> Answer:
        """Summarize one or more contexts using an LLM.

        Effective prompt created (excluding the system prompt):

        .. code-block::

            "{pre_prompt_summary}
            \"\"\"
            {text_context_list}
            \"\"\"
            {prompt_summary}"

        Args:
            text_context_list:
                List of raw text strings to be summarized.
            system_prompt:
                Text sent to models which support system prompts. Gives the model
                overall context in how to respond. Use `auto` for the model default or None for h2oGPTe defaults. Defaults
                to '' for no system prompt.
            pre_prompt_summary:
                Text that is prepended before the list of texts. The default can be
                customized per environment, but the standard default is :code:`"In order to write a concise single-paragraph
                or bulleted list summary, pay attention to the following text:\\\\n"`
            prompt_summary:
                Text that is appended after the list of texts. The default can be customized
                per environment, but the standard default is :code:`"Using only the text above, write a condensed and concise
                summary of key results (preferably as bullet points):\\\\n"`
            llm:
                Name or index of LLM to send the query. Use `H2OGPTE.get_llms()` to see all available options.
                Default value is to use the first model (0th index).
            llm_args:
                Dictionary of kwargs to pass to the llm. Valid keys:
                    temperature (float, default: 0) — The value used to modulate the next token probabilities. Most deterministic: 0, Most creative: 1
                    seed (int, default: 0) — The seed for the random number generator, only used if temperature > 0, seed=0 will pick a random number for each call, seed > 0 will be fixed
                    top_k (int, default: 1) — The number of highest probability vocabulary tokens to keep for top-k-filtering
                    top_p (float, default: 1.0) — If set to float < 1, only the smallest set of most probable tokens with probabilities that add up to top_p or higher are kept for generation
                    repetition_penalty (float, default: 1.07) — The parameter for repetition penalty. 1.0 means no penalty
                    max_new_tokens (int, default: 1024) — Maximum number of new tokens to generate. This limit applies to each (map+reduce) step during summarization and each (map) step during extraction
                    min_max_new_tokens (int, default: 512) — Minimum value for max_new_tokens when auto-adjusting for content of prompt, docs, etc.
                    reasoning_effort (int, default: 0) — Level of reasoning effort for the model (higher values = deeper reasoning, e.g., 10000-65000). Use for models that support chain-of-thought reasoning. 0 means no additional reasoning effort
                    response_format (str, default: "text") — Output type, one of ["text", "json_object", "json_code"]
                    guided_json (dict, default: None) — If specified, the output will follow the JSON schema
                    guided_regex (str, default: "") — If specified, the output will follow the regex pattern. Only for models that support guided generation
                    guided_choice (Optional[List[str]], default: None) — If specified, the output will be exactly one of the choices. Only for models that support guided generation
                    guided_grammar (str, default: "") — If specified, the output will follow the context free grammar. Only for models that support guided generation
                    guided_whitespace_pattern (str, default: "") — If specified, will override the default whitespace pattern for guided json decoding. Only for models that support guided generation
            guardrails_settings:
                Guardrails Settings.
            timeout:
                Timeout in seconds.
            kwargs:
                Dictionary of kwargs to pass to h2oGPT. Not recommended, see https://github.com/h2oai/h2ogpt for source code. Valid keys:
                    h2ogpt_key: str = ""
                    chat_conversation: list[tuple[str, str]] | None = None
                    docs_ordering_type: str | None = "best_near_prompt"
                    max_input_tokens: int = -1
                    docs_token_handling: str = "split_or_merge"
                    docs_joiner: str = "\n\n"
                    image_file: Union[str, list] = None

        Returns:
            Answer: The response text and any errors.
        Raises:
            TimeoutError: If response isn't completed in timeout seconds.
        """
        header = self._get_auth_header()
        model_name = self.get_llm_name_for_rest(llm)
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.summarize_content(
                    model_name=model_name,
                    summarize_request=rest.SummarizeRequest(
                        text_context_list=text_context_list,
                        system_prompt=system_prompt,
                        pre_prompt_summary=pre_prompt_summary,
                        prompt_summary=prompt_summary,
                        llm_args=llm_args,
                        guardrails_settings=(
                            None
                            if guardrails_settings is None
                            else rest.GuardrailsSettings(**guardrails_settings)
                        ),
                        timeout=timeout,
                        additional_properties=kwargs,
                    ),
                    _headers=header,
                )
            )
        ret = response.to_dict()
        if ret["error"]:
            raise SessionError(ret["error"])
        return Answer(**ret)

    def extract_data(
        self,
        text_context_list: Optional[List[str]] = None,
        system_prompt: str = "",
        pre_prompt_extract: Optional[str] = None,
        prompt_extract: Optional[str] = None,
        llm: Union[str, int, None] = None,
        llm_args: Optional[Dict[str, Any]] = None,
        guardrails_settings: Optional[Dict] = None,
        timeout: Union[float, None] = None,
        **kwargs: Any,
    ) -> ExtractionAnswer:
        """Extract information from one or more contexts using an LLM.

        pre_prompt_extract and prompt_extract variables must be used together. If these
        variables are not set, the inputs texts will be summarized into bullet points.

        Format of extract content:

            .. code-block::

                "{pre_prompt_extract}\"\"\"
                {text_context_list}
                \"\"\"\\n{prompt_extract}"

        Examples:

            .. code-block:: python

                extract = h2ogpte.extract_data(
                    text_context_list=chunks,
                    pre_prompt_extract="Pay attention and look at all people. Your job is to collect their names.\\n",
                    prompt_extract="List all people's names as JSON.",
                )

        Args:
            text_context_list:
                List of raw text strings to extract data from.
            system_prompt:
                Text sent to models which support system prompts. Gives the model
                overall context in how to respond. Use `auto` or None for the model default. Defaults
                to '' for no system prompt.
            pre_prompt_extract:
                Text that is prepended before the list of texts. If not set,
                the inputs will be summarized.
            prompt_extract:
                Text that is appended after the list of texts. If not set, the inputs will be summarized.
            llm:
                Name or index of LLM to send the query. Use `H2OGPTE.get_llms()` to see all available options.
                Default value is to use the first model (0th index).
            llm_args:
                Dictionary of kwargs to pass to the llm. Valid keys:
                    temperature (float, default: 0) — The value used to modulate the next token probabilities. Most deterministic: 0, Most creative: 1
                    seed (int, default: 0) — The seed for the random number generator, only used if temperature > 0, seed=0 will pick a random number for each call, seed > 0 will be fixed
                    top_k (int, default: 1) — The number of highest probability vocabulary tokens to keep for top-k-filtering
                    top_p (float, default: 1.0) — If set to float < 1, only the smallest set of most probable tokens with probabilities that add up to top_p or higher are kept for generation
                    repetition_penalty (float, default: 1.07) — The parameter for repetition penalty. 1.0 means no penalty
                    max_new_tokens (int, default: 1024) — Maximum number of new tokens to generate. This limit applies to each (map+reduce) step during summarization and each (map) step during extraction
                    min_max_new_tokens (int, default: 512) — Minimum value for max_new_tokens when auto-adjusting for content of prompt, docs, etc.
                    reasoning_effort (int, default: 0) — Level of reasoning effort for the model (higher values = deeper reasoning, e.g., 10000-65000). Use for models that support chain-of-thought reasoning. 0 means no additional reasoning effort
                    response_format (str, default: "text") — Output type, one of ["text", "json_object", "json_code"]
                    guided_json (dict, default: None) — If specified, the output will follow the JSON schema
                    guided_regex (str, default: "") — If specified, the output will follow the regex pattern. Only for models that support guided generation
                    guided_choice (Optional[List[str]], default: None) — If specified, the output will be exactly one of the choices. Only for models that support guided generation
                    guided_grammar (str, default: "") — If specified, the output will follow the context free grammar. Only for models that support guided generation
                    guided_whitespace_pattern (str, default: "") — If specified, will override the default whitespace pattern for guided json decoding. Only for models that support guided generation
            guardrails_settings:
                Guardrails Settings.
            timeout:
                Timeout in seconds.
            kwargs:
                Dictionary of kwargs to pass to h2oGPT. Not recommended, see https://github.com/h2oai/h2ogpt for source code. Valid keys:
                    h2ogpt_key: str = ""
                    chat_conversation: list[tuple[str, str]] | None = None
                    docs_ordering_type: str | None = "best_near_prompt"
                    max_input_tokens: int = -1
                    docs_token_handling: str = "split_or_merge"
                    docs_joiner: str = "\n\n"
                    image_file: Union[str, list] = None

        Returns:
            ExtractionAnswer: The list of text responses and any errors.
        Raises:
            TimeoutError: If response isn't completed in timeout seconds.
        """
        header = self._get_auth_header()
        model_name = self.get_llm_name_for_rest(llm)
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.extract_data(
                    model_name=model_name,
                    extraction_request=rest.ExtractionRequest(
                        text_context_list=text_context_list,
                        system_prompt=system_prompt,
                        pre_prompt_extract=pre_prompt_extract,
                        prompt_extract=prompt_extract,
                        llm_args=llm_args,
                        guardrails_settings=(
                            None
                            if guardrails_settings is None
                            else rest.GuardrailsSettings(**guardrails_settings)
                        ),
                        timeout=timeout,
                        additional_properties=kwargs,
                    ),
                    _headers=header,
                )
            )
        ret = response.to_dict()
        if ret["error"]:
            raise SessionError(ret["error"])
        return ExtractionAnswer(**ret)

    def list_extractors(
        self,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
        name_filter: Optional[str] = None,
    ) -> List[Extractor]:
        """Lists available extractors.

        Args:
            offset: Number of extractors to skip. Defaults to server-side default (0).
            limit: Maximum number of extractors to return. Defaults to server-side default.
            name_filter: Filter extractors by name.

        Returns:
            List[Extractor]: A list of available extractors.
        """
        header = self._get_auth_header()

        with self._RESTClient(self) as rest_client:
            rest_response_items = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.list_extractors(
                    offset=offset, limit=limit, name_filter=name_filter, _headers=header
                )
            )

        client_extractors = []
        for rest_item in rest_response_items:
            item_dict = rest_item.to_dict()
            client_extractors.append(Extractor(**item_dict))
        return client_extractors

    def create_extractor(
        self,
        name: str,
        llm: str,
        extractor_schema: Dict[str, Any],
        description: str = "",
        prompt: str = "",
        pre_prompt_summary: str = "",
        keep_intermediate_results: bool = False,
        system_prompt: str = "",
        max_num_chunks: int = 100,
        vision: str = "auto",
        vision_llm: str = "auto",
        image_batch_image_prompt: str = "",
        image_batch_final_prompt: str = "",
        guardrails_settings: Optional[Dict] = None,
    ) -> Extractor:
        """Creates a new extractor.

        Args:
            name: Name of the extractor.
            llm: LLM to use for extraction.
            extractor_schema: JSON schema defining the extraction structure.  If not empty, extractor will return data as JSON object.
            description: Optional description of the extractor.
            prompt: Optional prompt text for the extractor. If combined with extractor_schema, prompt can modify the output, but not its format as it's set to be JSON object.
            pre_prompt_summary: Optional pre-prompt summary text for the extractor.
            keep_intermediate_results: Optional flag indicating whether to keep intermediate results during extraction.
            system_prompt: Optional system prompt text for the extractor.
            max_num_chunks: Optional maximum number of chunks to process.
            vision: Optional vision mode setting.
            vision_llm: Optional vision LLM model identifier.
            image_batch_image_prompt: Optional image batch processing prompt.
            image_batch_final_prompt: Optional final prompt for image batch processing.
            guardrails_settings: Optional guardrails settings configuration as a dictionary.

        Returns:
            Extractor: Details of the newly created extractor.
        """
        header = self._get_auth_header()

        # Convert guardrails_settings dict to GuardrailsSettings object if provided
        guardrails_settings_obj = None
        if guardrails_settings is not None:
            guardrails_settings_obj = rest.GuardrailsSettings(**guardrails_settings)

        request_body = rest.ExtractorCreateRequest(
            name=name,
            description=description,
            llm=llm,
            schema=json.dumps(extractor_schema),
            prompt=prompt,
            pre_prompt_summary=pre_prompt_summary,
            keep_intermediate_results=keep_intermediate_results,
            system_prompt=system_prompt,
            max_num_chunks=max_num_chunks,
            vision=vision,
            vision_llm=vision_llm,
            image_batch_image_prompt=image_batch_image_prompt,
            image_batch_final_prompt=image_batch_final_prompt,
            guardrails_settings=guardrails_settings_obj,
        )

        with self._RESTClient(self) as rest_client:
            rest_response = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.create_extractor(
                    extractor_create_request=request_body, _headers=header
                )
            )

        response_dict = rest_response.to_dict()
        parsed_schema = {}
        # The REST response gives 'schema' as a string
        if response_dict.get("schema") and isinstance(response_dict["schema"], str):
            try:
                parsed_schema = json.loads(response_dict["schema"])
            except json.JSONDecodeError:
                pass
        response_dict["extractor_schema"] = parsed_schema
        response_dict.pop("schema", None)  # Remove original schema
        return Extractor(**response_dict)

    def get_extractor(self, extractor_id: str) -> Extractor:
        """Fetches an extractor by its ID.

        Args:
            extractor_id: The ID of the extractor to retrieve.

        Returns:
            Extractor: Details of the extractor.

        Raises:
            ObjectNotFoundError: If the extractor is not found.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_response = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.get_extractor(
                    extractor_id=extractor_id, _headers=header
                )
            )

        response_dict = rest_response.to_dict()
        parsed_schema = {}
        if response_dict.get("schema") and isinstance(response_dict["schema"], str):
            try:
                parsed_schema = json.loads(response_dict["schema"])
            except json.JSONDecodeError:
                pass
        response_dict["extractor_schema"] = parsed_schema
        response_dict.pop("schema", None)
        return Extractor(**response_dict)

    def delete_extractor(self, extractor_id: str):
        """Deletes an extractor by its ID.

        Args:
            extractor_id: The ID of the extractor to delete.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.delete_extractor(
                    extractor_id=extractor_id, _headers=header
                )
            )
        return result

    def run_extractor(
        self,
        extractor_id: str,
        collection_id: Optional[str] = None,
        document_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> List[DocumentExtractionResult]:
        """Create a job to run an extractor on a collection or single document and wait for completion.

        This method creates a job to execute the specified extractor. Exactly one of
        collection_id or document_id must be provided.

        Args:
            extractor_id:
                String ID of the extractor to run.
            collection_id:
                String ID of the collection to run the extractor on.
            document_id:
                String ID of a single document to run the extractor on.
            timeout:
                Optional timeout in seconds.

        Returns:
            List[DocumentExtractionResult]: A list of extraction results containing
                document ID, document name, extracted content, and any errors.

        Raises:
            ObjectNotFoundError: If the extractor or collection is not found.
            UnauthorizedError: If the user doesn't have permission to access the extractor or collection.

        Example:
            .. code-block:: python

                # Run extraction on a collection and wait for results
                results = client.run_extractor(
                    extractor_id="extractor-123",
                    collection_id="collection-456"
                )

                # Run extraction on a single document and wait for results
                results = client.run_extractor(
                    extractor_id="extractor-123",
                    document_id="document-789"
                )

                for result in results:
                    print(f"Document: {result.document_name}")
                    print(f"Extracted content: {result.content}")
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            job_details = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.create_extractor_run_job(
                    extractor_id=extractor_id,
                    collection_id=collection_id,
                    document_id=document_id,
                    timeout=timeout,
                    _headers=header,
                )
            )

        # API returns 201 with JobDetails
        rest_job_details = _convert_rest_job(job_details)
        job_id = rest_job_details.id

        # Wait for job completion
        self._wait_for_completion(job_id, timeout=timeout)

        # Fetch and return results
        return self.list_extractor_results(extractor_id=extractor_id, job_id=job_id)

    def list_extractor_results(
        self,
        extractor_id: str,
        job_id: Optional[str] = None,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> List[DocumentExtractionResult]:
        """Retrieve extraction results produced by this extractor.

        If job_id is specified, returns results for that specific extraction run.
        If job_id is omitted, returns all results produced by this extractor across all runs.

        Args:
            extractor_id:
                String ID of the extractor.
            job_id:
                Optional job ID to retrieve results for a specific extraction run.
                If omitted, returns all results for this extractor.
            offset:
                Optional number of extraction results to skip before returning.
                Defaults to 0 if not specified.
            limit:
                Optional maximum number of extraction results to return.
                If not specified, returns all results.

        Returns:
            List[DocumentExtractionResult]: A list of extraction results containing
                document ID, document name, extracted content, and any errors.

        Raises:
            ObjectNotFoundError: If the extractor is not found.
            UnauthorizedError: If the user doesn't have permission to access the extractor.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.list_extractor_results(
                    extractor_id=extractor_id,
                    job_id=job_id,
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )

        client_results = []
        for rest_item in response:
            item_dict = rest_item.to_dict()
            client_results.append(DocumentExtractionResult(**item_dict))
        return client_results

    def cancel_job(self, job_id: str) -> Result:
        """Stops a specific job from running on the server.

        Args:
            job_id:
                String id of the job to cancel.

        Returns:
            Result: Status of canceling the job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.job_api.cancel_job(job_id=job_id, _headers=header)
            )

        return Result(status="completed")

    def cancel_user_job(self, job_id: str) -> Result:
        """As an admin, stops a specific user job from running on the server.

        Args:
            job_id:
                String id of the job to cancel.

        Returns:
            Result: Status of canceling the job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.job_api.cancel_user_job(
                    job_id=job_id, _headers=header
                )
            )

        return Result(status="completed")

    def count_chat_sessions(self) -> int:
        """Counts number of chat sessions owned by the user.

        Returns:
            int: The count of chat sessions owned by the user.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session_count(_headers=header)
            )
        return response.count

    def count_chat_sessions_for_collection(self, collection_id: str) -> int:
        """Counts number of chat sessions in a specific collection.

        Args:
            collection_id:
                String id of the collection to count chat sessions for.

        Returns:
            int: The count of chat sessions in that collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_chat_session_count_for_collection(
                    collection_id=collection_id, _headers=header
                )
            )
        return response.count

    def count_collections(self) -> int:
        """Counts number of collections owned by the user.

        Returns:
            int: The count of collections owned by the user.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_count(_headers=header)
            )
        return response.count

    def count_documents(self) -> int:
        """Counts number of documents accessed by the user.

        Returns:
            int: The count of documents accessed by the user.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_count(_headers=header)
            )
        return response.count

    def count_documents_owned_by_me(self) -> int:
        """Counts number of documents owned by the user.

        Returns:
            int: The count of documents owned by the user.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_count(
                    owned=True, _headers=header
                )
            )
        return response.count

    def count_documents_in_collection(self, collection_id: str) -> int:
        """Counts the number of documents in a specific collection.

        Args:
            collection_id:
                String id of the collection to count documents for.

        Returns:
            int: The number of documents in that collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_document_count_for_collection(
                    collection_id=collection_id, _headers=header
                )
            )
        return response.count

    def count_assets(self) -> ObjectCount:
        """Counts number of objects owned by the user.

        Returns:
            ObjectCount: The count of chat sessions, collections, and documents.
        """
        result = ObjectCount(
            chat_session_count=self.count_chat_sessions(),
            collection_count=self.count_collections(),
            document_count=self.count_documents(),
        )
        return result

    def create_chat_session(
        self, collection_id: Optional[str] = None, workspace: Optional[str] = None
    ) -> str:
        """Creates a new chat session for asking questions (of documents).

        Args:
            collection_id:
                String id of the collection to chat with.
                If None, chat with LLM directly.
            workspace:
                String id of the workspace this chat will be associated with.
                If None, the user's default workspace will be used.

        Returns:
            str: The ID of the newly created chat session.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.create_chat_session(
                    collection_id=collection_id,
                    create_chat_session_request=rest.CreateChatSessionRequest(
                        workspace=workspace,
                    ),
                    _headers=header,
                )
            )
            return response.id

    def create_chat_session_on_default_collection(self) -> str:
        """Creates a new chat session for asking questions of documents on the default collection.

        Returns:
            str: The ID of the newly created chat session.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.create_chat_session(
                    collection_id="default",
                    _headers=header,
                )
            )
        return response.id

    def list_embedding_models(self) -> List[str]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.list_embedding_models(_headers=header)
            )
        return [m.id for m in response]

    def run_selftest(self, llm: str, mode: str) -> dict:
        """
        Run a self-test for a given LLM
        Args:
            llm:
                Name of LLM
            mode:
                one of ["quick", "rag", "full", "agent"]
        Returns:
            Dictionary with performance stats. If "error" is filled, the test failed.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.run_model_self_test(
                    model_name=llm, mode=mode, _headers=header
                )
            )
        return response.to_dict()

    def get_guardrails_settings(
        self,
        action: str = "redact",
        sensitive: bool = True,
        non_sensitive: bool = True,
        all_guardrails: bool = True,
        guardrails_settings: Union[dict, None] = None,
    ) -> Dict[str, Union[str, List[str]]]:
        """
        Helper to get reasonable (easy to use) defaults for Guardrails/PII settings. To be further customized.
        :param action: what to do when detecting PII, either "redact" or "fail" ("allow" would keep PII intact). Guardrails models always fail upon detecting safety violations.
        :param sensitive: whether to include the most sensitive PII entities like SSN, bank account info
        :param non_sensitive: whether to include all non-sensitive PII entities, such as IP addresses, locations, names, e-mail addresses etc.
        :param all_guardrails: whether to include all possible entities for prompt guard and guardrails models, or just system defaults
        :param guardrails_settings: existing guardrails settings (e.g., from collection settings) to obtain guardrails entities, guardrails_entities_to_flag, column redaction custom_pii_entities, column_redaction_pii_to_flag from instead of system defaults
        :return: dictionary to pass to collection creation or process_document method
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.create_guardrails_settings(
                    guardrails_settings_create_request=rest.GuardrailsSettingsCreateRequest(
                        action=action,
                        sensitive=sensitive,
                        non_sensitive=non_sensitive,
                        all_guardrails=all_guardrails,
                        guardrails_settings=(
                            None
                            if guardrails_settings is None
                            else rest.GuardrailsSettings(**guardrails_settings)
                        ),
                    ),
                    _headers=header,
                )
            )
        return response.to_dict()

    def get_agent_tools_dict(self) -> dict:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_agent_tools(_headers=header)
            )
        return {t.name: t.model_dump(exclude={"name"}) for t in response}

    def list_builtin_mcps(self) -> dict:
        """List built-in MCPs (Model Context Protocol servers) available for use.

        Returns a dictionary with two lists:
        - oauth_apps: List of OAuth-based MCP applications
        - api_key_apps: List of API key-based MCP applications

        Each MCP includes information about whether it's already added as a tool
        and whether the related OAuth connector is connected.

        Returns:
            dict: Dictionary containing 'oauth_apps' and 'api_key_apps' lists
        """
        header = self._get_auth_header()

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_builtin_mcps(_headers=header)
            )

        # Convert the response model to a dictionary
        if hasattr(response, "model_dump"):
            return response.model_dump()
        elif hasattr(response, "to_dict"):
            return response.to_dict()
        return response

    def add_builtin_mcp(
        self,
        mcp_id: str,
        keys: Optional[List[dict]] = None,
        file_paths: Optional[List[str]] = None,
    ) -> str:
        """Add a built-in MCP (Model Context Protocol server) to user's tools.

        This configures and enables a predefined MCP for the user, automatically
        adding it to the user's tool preferences.

        Args:
            mcp_id: The ID of the built-in MCP to add (e.g., "playwright_builtin", "slack_builtin")
            keys: Optional list of agent key associations for the MCP.
                Each dict should have: {"name": "ENV_VAR_NAME", "key_id": "agent_key_id"}
            file_paths: Optional list of file paths to upload for MCP configuration.
                Files will be uploaded and attached to the MCP configuration.

        Returns:
            str: The ID of the added MCP tool

        Raises:
            InvalidArgumentError: If the MCP is an OAuth app type or file not found

        Example:
            ```python
            # Add Slack MCP with API key
            tool_id = client.add_builtin_mcp(
                mcp_id="slack_builtin",
                keys=[{"name": "SLACK_MCP_XOXP_TOKEN", "key_id": "my_key_id"}]
            )

            # Add MCP with file paths (files will be uploaded automatically)
            tool_id = client.add_builtin_mcp(
                mcp_id="custom_mcp",
                file_paths=["/path/to/config.json", "/path/to/schema.yaml"]
            )
            ```
        """

        # Get the list of built-in MCPs to check the type
        mcps_list = self.list_builtin_mcps()

        # Check if the MCP is an OAuth app
        all_mcps = mcps_list.get("oauth_apps", []) + mcps_list.get("api_key_apps", [])
        target_mcp = next((mcp for mcp in all_mcps if mcp.get("id") == mcp_id), None)

        if target_mcp and target_mcp.get("type") == "oauth_app":
            from h2ogpte.errors import InvalidArgumentError

            raise InvalidArgumentError(
                {
                    "error": f"Cannot add MCP '{mcp_id}' of type 'oauth_app' using add_builtin_mcp. "
                    "OAuth-based MCPs require OAuth authentication and cannot be added directly."
                }
            )

        header = self._get_auth_header()

        # Prepare file objects for upload if paths are provided
        file_objects = []

        if file_paths:
            for file_path in file_paths:
                file_path_str = str(file_path)
                if not os.path.exists(file_path_str):
                    from h2ogpte.errors import InvalidArgumentError

                    raise InvalidArgumentError(
                        {"error": f"File not found: {file_path_str}"}
                    )
                file_objects.append(file_path_str)

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.add_builtin_mcp(
                    mcp_id=mcp_id,
                    keys=json.dumps(keys) if keys else None,
                    files=file_objects if file_objects else None,
                    _headers=header,
                )
            )

        return response.tool_id

    def create_user_builtin_mcp(
        self, mcp_config: dict, logo_path: Optional[str] = None
    ) -> dict:
        """Create a new user-specific builtin MCP configuration.

        This allows admins to add custom predefined MCPs that will be available
        in the builtin MCPs list for users.

        Args:
            mcp_config: Dictionary containing the MCP configuration matching built_in_mcps.json structure.
                Required fields:
                - name: Display name of the MCP
                - description: Description of what the MCP does
                - type: Either "oauth_app" or "api_app"
                - mcp_config_json: The MCP server configuration JSON
            logo_path: Optional path to a logo image file to upload

        Returns:
            dict: Dictionary with the created MCP details including id, mcp_id, config, user_id, created_at, updated_at

        Raises:
            UnauthorizedError: If the user is not an admin
            InvalidArgumentError: If the MCP config is invalid or MCP ID already exists

        Example:
            ```python
            mcp_config = {
                "name": "My Custom MCP",
                "description": "Custom MCP for internal use",
                "type": "api_app",
                "mcp_config_json": {"command": "npx", "args": ["-y", "@my/mcp-server"]}
            }
            result = client.create_user_builtin_mcp(mcp_config, logo_path="/path/to/logo.png")
            ```
        """
        header = self._get_auth_header()

        # Validate logo path if provided
        if logo_path:
            logo_path_str = str(logo_path)
            if not os.path.exists(logo_path_str):
                from h2ogpte.errors import InvalidArgumentError

                raise InvalidArgumentError(
                    {"error": f"Logo file not found: {logo_path_str}"}
                )

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.create_user_builtin_mcp(
                    mcp_config=json.dumps(mcp_config),
                    logo_file=logo_path if logo_path else None,
                    _headers=header,
                )
            )

        # Convert the response model to a dictionary
        if hasattr(response, "model_dump"):
            return response.model_dump()
        elif hasattr(response, "to_dict"):
            return response.to_dict()
        return response

    def update_user_builtin_mcp(self, mcp_id: str, mcp_config: dict) -> dict:
        """Update an existing user builtin MCP configuration.

        This allows admins to modify custom predefined MCPs.

        Args:
            mcp_id: The ID of the MCP to update (e.g., "my_custom_builtin")
            mcp_config: Dictionary containing the updated MCP configuration.
                Required fields:
                - name: Display name of the MCP
                - description: Description of what the MCP does
                - type: Either "oauth_app" or "api_app"
                - mcp_config_json: The MCP server configuration JSON

        Returns:
            dict: Dictionary with the updated MCP details

        Raises:
            UnauthorizedError: If the user is not an admin
            ObjectNotFoundError: If the MCP doesn't exist
            InvalidArgumentError: If the MCP config is invalid

        Example:
            ```python
            mcp_config = {
                "name": "My Updated MCP",
                "description": "Updated description",
                "type": "api_app",
                "mcp_config_json": {"command": "npx", "args": ["-y", "@my/mcp-server"]}
            }
            result = client.update_user_builtin_mcp("my_custom_builtin", mcp_config)
            ```
        """
        header = self._get_auth_header()

        # Create request object from dict
        request_obj = rest.UpdateUserBuiltinMcpRequest.from_dict(mcp_config)

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.update_user_builtin_mcp(
                    mcp_id=mcp_id,
                    update_user_builtin_mcp_request=request_obj,
                    _headers=header,
                )
            )

        # Convert the response model to a dictionary
        if hasattr(response, "model_dump"):
            return response.model_dump()
        elif hasattr(response, "to_dict"):
            return response.to_dict()
        return response

    def delete_user_builtin_mcp(self, mcp_id: str) -> dict:
        """Delete a user builtin MCP by ID.

        This allows admins to remove custom predefined MCPs.

        Args:
            mcp_id: The ID of the MCP to delete (e.g., "my_custom_builtin")

        Returns:
            dict: Dictionary with success message

        Raises:
            UnauthorizedError: If the user is not an admin
            ObjectNotFoundError: If the MCP doesn't exist

        Example:
            ```python
            result = client.delete_user_builtin_mcp("my_custom_builtin")
            print(result["message"])  # "MCP deleted successfully"
            ```
        """
        header = self._get_auth_header()

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_user_builtin_mcp(
                    mcp_id=mcp_id,
                    _headers=header,
                )
            )

        # Convert the response model to a dictionary
        if hasattr(response, "model_dump"):
            return response.model_dump()
        elif hasattr(response, "to_dict"):
            return response.to_dict()
        return response

    def update_admin_mcp_logo(self, mcp_id: str, logo_path: str) -> dict:
        """Update the logo for an admin-created builtin MCP.

        Args:
            mcp_id: The ID of the MCP to update (e.g., "my_custom_builtin")
            logo_path: Path to the logo image file to upload

        Returns:
            dict: Dictionary with the updated MCP details

        Raises:
            UnauthorizedError: If the user is not an admin
            ObjectNotFoundError: If the MCP doesn't exist
            InvalidArgumentError: If the logo file is invalid or not found

        Example:
            ```python
            result = client.update_admin_mcp_logo("my_custom_builtin", "/path/to/logo.png")
            print(result["logo"])  # "/file?id=...&name=logo.png"
            ```
        """
        header = self._get_auth_header()

        # Validate logo path
        logo_path_str = str(logo_path)
        if not os.path.exists(logo_path_str):
            from h2ogpte.errors import InvalidArgumentError

            raise InvalidArgumentError(
                {"error": f"Logo file not found: {logo_path_str}"}
            )

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.update_admin_mcp_logo(
                    mcp_id=mcp_id,
                    file=logo_path,
                    _headers=header,
                )
            )

        # Convert the response model to a dictionary
        if hasattr(response, "model_dump"):
            return response.model_dump()
        elif hasattr(response, "to_dict"):
            return response.to_dict()
        return response

    def remove_admin_mcp_logo(self, mcp_id: str) -> dict:
        """Remove the logo from an admin-created builtin MCP.

        Args:
            mcp_id: The ID of the MCP to update (e.g., "my_custom_builtin")

        Returns:
            dict: Dictionary with the updated MCP details

        Raises:
            UnauthorizedError: If the user is not an admin
            ObjectNotFoundError: If the MCP doesn't exist

        Example:
            ```python
            result = client.remove_admin_mcp_logo("my_custom_builtin")
            print(result["message"])  # "Logo removed successfully"
            ```
        """
        header = self._get_auth_header()

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.remove_admin_mcp_logo(
                    mcp_id=mcp_id,
                    _headers=header,
                )
            )

        # Convert the response model to a dictionary
        if hasattr(response, "model_dump"):
            return response.model_dump()
        elif hasattr(response, "to_dict"):
            return response.to_dict()
        return response

    def inspect_mcp_tool(
        self,
        tool_id: Optional[str] = None,
        servers: Optional[dict] = None,
        file_path: Optional[str] = None,
        model: Optional[str] = None,
    ) -> dict:
        """Unified MCP tool inspection.

        Supports three modes (provide exactly one):
        1. tool_id — inspect an existing local or remote MCP tool by its ID.
        2. servers — inspect one or more remote MCP server configs (pre-add).
        3. file_path — inspect an uploaded MCP package file (pre-add).

        Args:
            tool_id: ID of an existing MCP tool to inspect.
            servers: Dict mapping server names to config dicts for pre-add inspection.
            file_path: Path to an MCP package file (.py, .zip, .tar.gz) for pre-add inspection.
            model: Optional LLM model for security inspection.

        Returns:
            dict: Unified result with keys:
                - status: 'success' or 'error'
                - servers: List of per-server inspection result dicts
                - error: Top-level error message if status is 'error'

        Example:
            ```python
            # Inspect an existing tool
            result = client.inspect_mcp_tool(tool_id="abc-123")
            for srv in result["servers"]:
                print(f"{srv['server_name']}: {srv['tool_count']} tools")

            # Inspect a remote config before adding
            result = client.inspect_mcp_tool(
                servers={"playwright": {"command": "npx", "args": ["@playwright/mcp@latest"]}}
            )
            ```
        """
        import base64
        import os

        payload: dict = {}
        if tool_id is not None:
            payload["tool_id"] = tool_id
        if servers is not None:
            payload["servers"] = servers
        if file_path is not None:
            file_name = os.path.basename(file_path)
            with open(file_path, "rb") as fh:
                file_data_base64 = base64.b64encode(fh.read()).decode("utf-8")
            payload["file_name"] = file_name
            payload["file_data_base64"] = file_data_base64
        if model is not None:
            payload["model"] = model

        return self._post("/api/v1/agents/mcp/inspect_tool", json.dumps(payload))

    def list_mcp_tools(
        self,
        config_type: str = "runner",
        server_names: Optional[List[str]] = None,
        mcp_dir: Optional[str] = None,
        include_remote: bool = True,
    ) -> dict:
        """List tools from configured MCP servers.

        Args:
            config_type: Type of config ('runner' or 'creator').
            server_names: Optional list of server names to filter.
            mcp_dir: Optional override directory for MCP configs.
            include_remote: Whether to include remote MCP servers (default True).

        Returns:
            dict: Result with keys:
                - status: 'success' or 'error'
                - servers: Dict mapping server names to tool lists
                - total_servers: Number of servers found
                - total_tools: Total number of tools across all servers
                - error: Error message if status is 'error'

        Example:
            ```python
            result = client.list_mcp_tools(config_type="runner")
            for server, info in result.get("servers", {}).items():
                print(f"{server}: {info['tool_count']} tools")
            ```
        """
        payload: dict = {"config_type": config_type}
        if server_names is not None:
            payload["server_names"] = server_names
        if mcp_dir is not None:
            payload["mcp_dir"] = mcp_dir
        if not include_remote:
            payload["include_remote"] = False

        return self._post("/api/v1/agents/mcp/list_tools", json.dumps(payload))

    def get_mcp_sdk_options(self) -> dict:
        """Get the schema of available Claude SDK options for MCP tool runners.

        Returns:
            dict: Schema with keys:
                - sdk_options_schema: Full ClaudeSdkAdvancedOptions JSON schema
                - permission_modes: List of valid permission mode strings
                - effort_levels: List of valid effort level strings
                - available_betas: List of available beta feature flags
                - hook_actions: List of valid hook action strings
                - hook_events: List of valid hook event strings
                - limitations: Dict of partially implemented features

        Example:
            ```python
            schema = client.get_mcp_sdk_options()
            print("Permission modes:", schema.get("permission_modes"))
            print("Effort levels:", schema.get("effort_levels"))
            ```
        """
        return self._get("/api/v1/agents/mcp/sdk_options")

    def create_collection(
        self,
        name: str,
        description: str,
        embedding_model: Union[str, None] = None,
        prompt_template_id: Union[str, None] = None,
        collection_settings: Union[dict, None] = None,
        thumbnail: Union[Path, None] = None,
        chat_settings: Union[dict, None] = None,
        workspace: Union[str, None] = None,
    ) -> str:
        r"""Creates a new collection.

        Args:
            name:
                Name of the collection.
            description:
                Description of the collection
            embedding_model:
                embedding model to use. call list_embedding_models() to list of options.
            prompt_template_id:
                ID of the prompt template to get the prompts from. None to fall back to system defaults.
            collection_settings:
                (Optional) Dictionary with key/value pairs to configure certain collection specific settings
                max_tokens_per_chunk: Approximate max. number of tokens per chunk for text-dominated document pages. For images, chunks can be larger.
                chunk_overlap_tokens: Approximate number of tokens that are overlapping between successive chunks.
                gen_doc_summaries: Whether to auto-generate document summaries (uses LLM)
                gen_doc_questions: Whether to auto-generate sample questions for each document (uses LLM)
                audio_input_language: Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
                ocr_model: Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                           Pass empty string to see choices.
                           docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                           Mississippi works well on handwriting.
                           auto - Automatic will auto-select the best OCR model for every page.
                           off - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
                tesseract_lang: Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
                keep_tables_as_one_chunk: When tables are identified by the table parser the table tokens will be kept in a single chunk.
                chunk_by_page: Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is `true`.
                handwriting_check: Check pages for handwriting. Will use specialized models if handwriting is found.
                follow_links: Whether to import all web pages linked from this URL will be imported. External links will be ignored. Links to other pages on the same domain will be followed as long as they are at the same level or below the URL you specify. Each page will be transformed into a PDF document.
                max_depth: Max depth of recursion when following links, only when follow_links is True. Max_depth of 0 means don't follow any links, max_depth of 1 means follow only top-level links, etc. Use -1 for automatic (system settings).
                max_documents: Max number of documents when following links, only when follow_links is True. Use None for automatic (system defaults). Use -1 for max (system limit).
                root_dir: Root directory for document storage
                copy_document: Whether to copy the document when importing an existing document.
                guardrails_settings itself is a dictionary of the following keys.
                    column_redaction_config: list of list for redacting columns from CSV/TSV files (regex_pattern, fill_value)
                    disallowed_regex_patterns: list of regular expressions that match custom PII
                    presidio_labels_to_flag: list of entities to be flagged as PII by the built-in Presidio model.
                    pii_labels_to_flag: list of entities to be flagged as PII by the built-in PII model.
                    pii_detection_parse_action: what to do when PII is detected during parsing of documents. One of ["allow", "redact", "fail"]. Redact will replace disallowed content in the ingested documents with redaction bars.
                    pii_detection_llm_input_action: what to do when PII is detected in the input to the LLM (document content and user prompts). One of ["allow", "redact", "fail"]. Redact will replace disallowed content with placeholders.
                    pii_detection_llm_output_action: what to do when PII is detected in the output of the LLM. One of ["allow", "redact", "fail"]. Redact will replace disallowed content with placeholders.
                    prompt_guard_labels_to_flag: list of entities to be flagged as safety violations in user prompts by the built-in prompt guard model.
                    guardrails_labels_to_flag: list of entities to be flagged as safety violations in user prompts. Must be a subset of guardrails_entities, if provided.
                    guardrails_safe_category: (Optional) name of the safe category for guardrails. Must be a key in guardrails_entities, if provided. Otherwise uses system defaults.
                    guardrails_entities: (Optional) dictionary of entities and their descriptions for the guardrails model to classify. The first entry is the "safe" class, the rest are "unsafe" classes.
                    custom_pii_entities_to_flag: list of entities to redact in tabular data files. Must be a subset of custom_pii_entities, if provided.
                    custom_pii_entities: (Optional) dictionary of entities and a short description for the LLM to check for and redact columns containing PII in tabular data files.
                    guardrails_llm: LLM to use for guardrails and PII detection. Use "auto" for automatic. Use `H2OGPTE.get_llms()` to see all available options.
                Example:
                    Note: Call client.get_guardrails_settings() to see all options for guardrails_settings.

                    collection_settings=dict(
                        max_tokens_per_chunk=320,
                        chunk_overlap_tokens=0,
                        guardrails_settings=dict(
                            disallowed_regex_patterns=["secret_disallowed_word", r"(?!0{3})(?!6{3})[0-8]\d{2}-(?!0{2})\d{2}-(?!0{4})\d{4}"],
                            presidio_labels_to_flag=["IBAN_CODE", "US_SSN"],
                            pii_labels_to_flag=["IBAN", "SSN"],
                            pii_detection_parse_action="redact",
                            pii_detection_llm_input_action="redact",
                            pii_detection_llm_output_action="allow",
                            prompt_guard_labels_to_flag=["JAILBREAK"],
                            guardrails_labels_to_flag=[
                                "Violent Crimes",
                                "Non-Violent Crimes",
                                "Intellectual Property",
                                "Code Interpreter Abuse",
                            ],
                            guardrails_safe_category="Safe",
                            guardrails_entities={
                                "Safe": "Messages that do not contain any of the following unsafe content",
                                "Violent Crimes": "Messages that enable, encourage, or endorse the commission of violent crimes, including: (1) unlawful violence toward people (ex: terrorism, genocide, murder, hate-motivated violent crimes, child abuse, assault, battery, kidnapping) and (2) unlawful violence toward animals (ex: animal abuse)",
                                "Non-Violent Crimes": "Messages that enable, encourage, or endorse the commission of non-violent crimes, including: (1) personal crimes (ex: labor trafficking, threats, intimidation, hate-motivated non-violent crimes), (2) financial crimes (ex: fraud, scams, money laundering), (3) property crimes (ex: theft, arson, vandalism), (4) drug crimes (ex: creating or using regulated substances), (5) weapons crimes (ex: producing unlicensed firearms), and (6) cyber crimes (ex: hacking)",
                                "Defamation": "Messages that are both verifiably false and likely to injure a living person’s reputation",
                                "Specialized Advice": "Messages that contain specialized financial, medical, or legal advice, or that indicate dangerous activities or objects are safe",
                                "Intellectual Property": "Messages that may violate the intellectual property rights of any third party",
                                "Code Interpreter Abuse": "Messages that seek to abuse code interpreters, including those that enable denial of service attacks, container escapes or privilege escalation exploits",
                            },
                            custom_pii_entities_to_flag=[
                                "Mother's Maiden Name"
                            ],
                            custom_pii_entities={
                                "Mother's Maiden Name": "Mother's maiden name."
                            },
                            guardrails_llm="meta-llama/Llama-3.3-70B-Instruct",
                        ),
                    )
            thumbnail:
                (Optional) Path to the thumbnail image for the collection. Must include appropriate file extension.
            chat_settings:
                (Optional) Dictionary with key/value pairs to configure the default values for certain chat specific settings
                The following keys are supported, see the client.session() documentation for more details.
                llm: str — Default LLM to use for chat sessions in this collection
                llm_args: dict — Default LLM arguments (see answer_question method for full list of valid keys)
                self_reflection_config: dict — Configuration for self-reflection functionality
                rag_config: dict — Configuration for RAG (Retrieval-Augmented Generation)
                include_chat_history: bool — Whether to include chat history in context
                tags: list[str] — Tags to associate with the collection
            workspace:
                (Optional) The workspace id to be associated with this collection. None to use the default workspace.
        Returns:
            str: The ID of the newly created collection.
        """
        headers = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            request = rest.CollectionCreateRequest(
                name=name,
                description=description,
                embedding_model=embedding_model,
                collection_settings=rest.CollectionSettings.from_dict(
                    collection_settings
                ),
                chat_settings=rest.ChatSettings.from_dict(chat_settings),
                workspace=workspace,
            )
            collection = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_collection(
                    request, _headers=headers
                )
            )

        if prompt_template_id is not None:
            self.set_collection_prompt_template(collection.id, prompt_template_id)
        if thumbnail is not None:
            self.set_collection_thumbnail(collection.id, thumbnail)
        return collection.id

    def set_collection_thumbnail(
        self, collection_id: str, file_path: Path, timeout: Union[float, None] = None
    ):
        """Upload an image file to be set as a collection's thumbnail.

        The image file will not be considered as a collection document.
        Acceptable image file types include: .png, .jpg, .jpeg, .svg

        Args:
            collection_id:
                Collection you want to add the thumbnail to.
            file_path:
                Path to the image file. Must include appropriate file extension.
            timeout:
                Amount of time in seconds to allow the request to run.

        Raises:
            ValueError: The file is invalid.
            Exception: The upload request was unsuccessful.
        """
        with self._RESTClient(self) as rest_client:
            size = os.stat(file_path).st_size
            if size >= 5242880:
                raise ValueError(
                    "File is too large. Please use an image smaller than 5MB"
                )

            header = self._get_auth_header()
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_update_collection_thumbnail_job(
                    collection_id=collection_id,
                    file=str(file_path),
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def remove_collection_thumbnail(
        self, collection_id: str, timeout: Union[float, None] = None
    ):
        """Remove a thumbnail from a collection.

        Args:
            collection_id:
                Collection you want to remove the thumbnail from.
            timeout:
                Amount of time in seconds to allow the request to run. The default is 86400 seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_delete_collection_thumbnail_job(
                    collection_id=collection_id, _headers=header
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def delete_chat_sessions(
        self,
        chat_session_ids: Iterable[str],
        timeout: Union[float, None] = None,
    ) -> Job:
        """Deletes chat sessions and related messages.

        Args:
            chat_session_ids:
                List of string ids of chat sessions to delete from the system.
            timeout:
                Timeout in seconds.

        Returns:
            Result: The delete job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.create_delete_chat_session_job(
                    delete_chat_sessions_job_request=rest.DeleteChatSessionsJobRequest(
                        session_ids=chat_session_ids
                    ),
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def delete_chat_messages(self, chat_message_ids: Iterable[str]) -> Result:
        """Deletes specific chat messages.

        Args:
            chat_message_ids:
                List of string ids of chat messages to delete from the system.

        Returns:
            Result: Status of the delete job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.delete_messages(
                        message_ids=chat_message_ids, _headers=header
                    )
                )
            )
        return result

    def delete_document_summaries(self, summaries_ids: Iterable[str]) -> Result:
        """Deletes document summaries.

        Args:
            summaries_ids:
                List of string ids of a document summary to delete from the system.

        Returns:
            Result: Status of the delete job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.document_api.delete_document_summaries(
                        summary_ids=summaries_ids, _headers=header
                    )
                )
            )
        return result

    def get_collection_questions(
        self, collection_id: str, limit: int
    ) -> List[SuggestedQuestion]:
        """List suggested questions

        Args:
            collection_id:
                A collection ID of which to return the suggested questions
            limit:
                How many questions to return.

        Returns:
            List: A list of questions.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_questions_for_collection(
                    collection_id=collection_id, limit=limit, _headers=header
                )
            )
        return [SuggestedQuestion(**d.to_dict()) for d in response]

    def get_chat_session_questions(
        self, chat_session_id: str, limit: int
    ) -> List[SuggestedQuestion]:
        """List suggested questions

        Args:
            chat_session_id:
                A chat session ID of which to return the suggested questions
            limit:
                How many questions to return.

        Returns:
            List: A list of questions.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.list_questions_for_chat_session(
                    session_id=chat_session_id, limit=limit, _headers=header
                )
            )
        return [SuggestedQuestion(**d.to_dict()) for d in response]

    def set_collection_expiry_date(
        self, collection_id: str, expiry_date: str, timezone: Optional[str] = None
    ) -> str:
        """Set an expiry date for a collection.

        Args:
            collection_id:
                ID of the collection to update.
            expiry_date:
                The expiry date as a string in 'YYYY-MM-DD' format.
            timezone:
                Optional timezone to associate with expiry date (with IANA timezone support).
        """
        try:
            datetime.datetime.strptime(expiry_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError(
                "Invalid date. Please enter a valid date that follows the 'YYYY-MM-DD' format."
            )

        if timezone is None:
            from tzlocal import get_localzone

            timezone = str(get_localzone())

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_expiry_date(
                    collection_id=collection_id,
                    update_collection_expiry_date_request=rest.UpdateCollectionExpiryDateRequest(
                        expiry_date=expiry_date,
                        timezone=timezone,
                    ),
                    _headers=header,
                )
            )
        return collection_id

    def remove_collection_expiry_date(self, collection_id: str) -> str:
        """Remove an expiry date from a collection.

        Args:
            collection_id:
                ID of the collection to update.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.delete_collection_expiry_date(
                    collection_id=collection_id, _headers=header
                )
            )
        return collection_id

    def set_collection_inactivity_interval(
        self, collection_id: str, inactivity_interval: int
    ) -> str:
        """Set an inactivity interval for a collection.

        Args:
            collection_id:
                ID of the collection to update.
            inactivity_interval:
                The inactivity interval as an integer number of days.
        """
        if not inactivity_interval and (
            inactivity_interval <= 0 or inactivity_interval > 36500
        ):
            raise ValueError(
                "Inactivity interval must be a positive integer and no larger than 36500 days."
            )

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_inactivity_interval(
                    collection_id=collection_id,
                    update_collection_inactivity_interval_request=rest.UpdateCollectionInactivityIntervalRequest(
                        inactivity_interval=inactivity_interval
                    ),
                    _headers=header,
                )
            )
        return collection_id

    def remove_collection_inactivity_interval(self, collection_id: str) -> str:
        """Remove an inactivity interval for a collection.

        Args:
            collection_id:
                ID of the collection to update.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.delete_collection_inactivity_interval(
                    collection_id=collection_id, _headers=header
                )
            )
        return collection_id

    def reset_all_collection_expirations(self):
        """
        Reset any expiry dates and inactivity intervals that have been set for all collections (admin only). This will also reset any archived collections back to active.
        """

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.reset_all_collection_expirations(
                        _headers=header,
                    )
                )
            )
        return result

    def set_collection_size_limit(
        self, collection_id: str, limit: Union[int, str]
    ) -> str:
        """Set a maximum limit on the total size of documents (sum) added to a collection.
        The limit is measured in bytes.

        Args:
            collection_id:
                ID of the collection to update.
            limit:
                The bytes limit, possible values follow the format: 12345, "1GB", or "1GiB".
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.set_collection_size_limit(
                    collection_id=collection_id,
                    set_collection_size_limit_request=rest.SetCollectionSizeLimitRequest(
                        size_limit=str(limit)
                    ),
                    _headers=header,
                )
            )
        return collection_id

    def remove_collection_size_limit(self, collection_id: str) -> str:
        """Remove a size limit for a collection.

        Args:
            collection_id:
                ID of the collection to update.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.remove_collection_size_limit(
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return collection_id

    def unarchive_collection(self, collection_id: str) -> str:
        """Restore an archived collection to an active status.

        Args:
            collection_id:
                ID of the collection to restore.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.unarchive_collection(
                    collection_id=collection_id, _headers=header
                )
            )
        return collection_id

    def archive_collection(self, collection_id: str) -> str:
        """Archive a collection along with its associated data.

        Args:
            collection_id:
                ID of the collection to archive.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.archive_collection(
                    collection_id=collection_id, _headers=header
                )
            )
        return collection_id

    def delete_collections(
        self,
        collection_ids: Iterable[str],
        timeout: Union[float, None] = None,
    ) -> Job:
        """Deletes collections from the environment.

        Documents in the collection that are owned by other users will not be deleted.

        Args:
            collection_ids:
                List of string ids of collections to delete from the system.
            timeout:
                Timeout in seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_delete_collection_job(
                    rest.DeleteCollectionsJobRequest(collection_ids=collection_ids),
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def delete_collections_as_admin(
        self,
        collection_ids: Iterable[str],
        timeout: Union[float, None] = None,
    ) -> Job:
        """Deletes collections and their associated data from the environment (needs appropriate permission).

        Args:
            collection_ids:
                List of string ids of collections to delete from the system.
            timeout:
                Timeout in seconds.
        """
        ret = self._job(
            "q:crawl_quick.DeleteCollectionsAsAdminJob", collection_ids=collection_ids
        )
        return self._wait_for_completion(_to_id(ret), timeout=timeout)

    def delete_documents(
        self,
        document_ids: Iterable[str],
        timeout: Union[float, None] = None,
    ) -> Job:
        """Deletes documents from the system.

        Args:
            document_ids:
                List of string ids to delete from the system and all collections.
            timeout:
                Timeout in seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.create_delete_document_job(
                    rest.DeleteDocumentsJobRequest(document_ids=document_ids),
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def delete_documents_from_collection(
        self,
        collection_id: str,
        document_ids: Iterable[str],
        timeout: Union[float, None] = None,
    ) -> Job:
        """Removes documents from a collection.

        See Also: H2OGPTE.delete_documents for completely removing the document from the environment.

        Args:
            collection_id:
                String of the collection to remove documents from.
            document_ids:
                List of string ids to remove from the collection.
            timeout:
                Timeout in seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_delete_document_from_collection_job(
                    collection_id=collection_id,
                    delete_documents_job_request=rest.DeleteDocumentsJobRequest(
                        document_ids=document_ids
                    ),
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def migrate_scheduled_connectors_to_collection(
        self,
        collection_id: str,
        src_collection_id: str,
        timeout: Union[float, None] = None,
    ) -> Job:
        """Move all scheduled connectors from a source collection to a target collection.

        Connectors are moved, meaning the source collection will have no
        scheduled connectors after this operation. Both collections must be
        owned by the same user.

        Args:
            collection_id:
                Target collection ID where scheduled connectors will be moved to.
            src_collection_id:
                Source collection ID to move scheduled connectors from.
            timeout:
                Timeout in seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.migrate_scheduled_connectors_to_collection(
                    collection_id=collection_id,
                    migrate_scheduled_connectors_to_collection_request=rest.MigrateScheduledConnectorsToCollectionRequest(
                        src_collection_id=src_collection_id,
                    ),
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def list_scheduled_connectors_for_collection(
        self, collection_id: str
    ) -> List[ScheduledConnectorDetails]:
        """List scheduled connectors associated with a collection.

        Args:
            collection_id:
                String id of the collection to list scheduled connectors for.

        Returns:
            List[ScheduledConnectorDetails]: Metadata about each scheduled connector.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_scheduled_connectors_for_collection(
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return [ScheduledConnectorDetails(**d.to_dict()) for d in response]

    def import_collection_into_collection(
        self,
        collection_id: str,
        src_collection_id: str,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        copy_document: Union[bool, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
        preserve_document_status: Union[bool, None] = None,
        preserve_metadata: Union[bool, None] = None,
        migrate_scheduled_connectors: Union[bool, None] = None,
        copy_lifecycle_settings: Union[bool, None] = None,
        skip_reparse: Union[bool, None] = None,
    ):
        """Import all documents from a collection into an existing collection

        Args:
            collection_id:
                Collection ID to add documents to.
            src_collection_id:
                Collection ID to import documents from.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            copy_document:
                Whether to save a new copy of the document
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
            preserve_document_status:
                Whether to preserve each document's original ingest mode (agent_only vs standard) when importing.
                When True, documents with agent_only status remain agent_only in the target collection.
                When False, all documents use the ingest_mode parameter uniformly.
            preserve_metadata:
                Whether to preserve the documents' existing metadata when importing.
            migrate_scheduled_connectors:
                Whether to move scheduled connectors from source collection to target collection
                after documents are imported. The source collection will have no scheduled connectors
                after this operation. Only the owner of both collections can use this flag.
            copy_lifecycle_settings:
                Whether to copy lifecycle settings (expiry_date, inactivity_interval, size_limit)
                from the source collection to the target collection.
            skip_reparse:
                Whether to skip re-parsing documents and only re-embed existing chunks with the
                target collection's embedding model. Much faster than full import since it skips
                file fetch, PDF conversion, OCR, and chunking. Only re-embeds the text chunks.
                Cannot be combined with copy_document=True.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_import_collection_to_collection_job(
                    collection_id=collection_id,
                    create_import_collection_to_collection_job_request=rest.CreateImportCollectionToCollectionJobRequest(
                        source_collection_id=src_collection_id,
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    copy_document=copy_document,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    preserve_document_status=preserve_document_status,
                    preserve_metadata=preserve_metadata,
                    migrate_scheduled_connectors=migrate_scheduled_connectors,
                    copy_lifecycle_settings=copy_lifecycle_settings,
                    skip_reparse=skip_reparse,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def import_document_into_collection(
        self,
        collection_id: str,
        document_id: str,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        copy_document: Union[bool, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
        preserve_metadata: Union[bool, None] = None,
    ):
        """Import an already stored document to an existing collection

        Args:
            collection_id:
                Collection ID to add documents to.
            document_id:
                Document ID to add.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            copy_document:
                Whether to save a new copy of the document
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
            preserve_metadata:
                Whether to preserve the document's existing metadata when importing.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_insert_document_to_collection_job(
                    collection_id=collection_id,
                    create_insert_document_to_collection_job_request=rest.CreateInsertDocumentToCollectionJobRequest(
                        document_id=document_id,
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    copy_document=copy_document,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    preserve_metadata=preserve_metadata,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def summarize_document(self, *args, **kwargs) -> DocumentSummary:
        assert not kwargs.get("keep_intermediate_results", False), (
            "Must not set keep_intermediate_results for summarize_document to preserve backward compatibility. "
            "Use process_document instead."
        )
        ret = self.process_document(*args, **kwargs)
        return DocumentSummary(**ret.model_dump())

    def process_document(
        self,
        document_id: str,
        system_prompt: Union[str, None] = None,
        pre_prompt_summary: Union[str, None] = None,
        prompt_summary: Union[str, None] = None,
        image_batch_image_prompt: Optional[str] = None,
        image_batch_final_prompt: Optional[str] = None,
        llm: Union[str, int, None] = None,
        llm_args: Optional[Dict[str, Any]] = None,
        max_num_chunks: Union[int, None] = None,
        sampling_strategy: Union[str, None] = None,
        pages: Union[List[int], None] = None,
        schema: Union[Dict[str, Any], None] = None,
        keep_intermediate_results: Union[bool, None] = None,
        guardrails_settings: Optional[Dict] = None,
        meta_data_to_include: Optional[Dict[str, bool]] = None,
        timeout: Optional[float] = None,
    ) -> ProcessedDocument:
        """Processes a document to either create a global or piecewise summary/extraction/transformation of a document.

        Effective prompt created (excluding the system prompt):

        .. code-block::

            "{pre_prompt_summary}
            \"\"\"
            {text from document}
            \"\"\"
            {prompt_summary}"

        Args:
            document_id:
                String id of the document to create a summary from.
            system_prompt:
                System Prompt
            pre_prompt_summary:
                Prompt that goes before each large piece of text to summarize
            prompt_summary:
                Prompt that goes after each large piece of text to summarize
            image_batch_final_prompt:
                Prompt for each image batch for vision models
            image_batch_image_prompt:
                Prompt to reduce all answers each image batch for vision models
            llm:
                LLM to use
            llm_args:
                Dictionary of kwargs to pass to the llm. Valid keys:
                    temperature (float, default: 0) — The value used to modulate the next token probabilities. Most deterministic: 0, Most creative: 1
                    top_k (int, default: 1) — The number of highest probability vocabulary tokens to keep for top-k-filtering
                    top_p (float, default: 1.0) — If set to float < 1, only the smallest set of most probable tokens with probabilities that add up to top_p or higher are kept for generation
                    seed (int, default: 0) — The seed for the random number generator when sampling during generation (if temp>0 or top_k>1 or top_p<1), seed=0 picks a random seed
                    repetition_penalty (float, default: 1.07) — The parameter for repetition penalty. 1.0 means no penalty
                    max_new_tokens (int, default: 1024) — Maximum number of new tokens to generate. This limit applies to each (map+reduce) step during summarization and each (map) step during extraction
                    reasoning_effort (int, default: 0) — Level of reasoning effort for the model (higher values = deeper reasoning, e.g., 10000-65000). Use for models that support chain-of-thought reasoning. 0 means no additional reasoning effort
                    min_max_new_tokens (int, default: 512) — Minimum value for max_new_tokens when auto-adjusting for content of prompt, docs, etc.
                    response_format (str, default: "text") — Output type, one of ["text", "json_object", "json_code"]
                    guided_json (dict, default: None) — If specified, the output will follow the JSON schema
                    guided_regex (str, default: "") — If specified, the output will follow the regex pattern. Only for models that support guided generation
                    guided_choice (Optional[List[str]], default: None) — If specified, the output will be exactly one of the choices. Only for models that support guided generation
                    guided_grammar (str, default: "") — If specified, the output will follow the context free grammar. Only for models that support guided generation
                    guided_whitespace_pattern (str, default: "") — If specified, will override the default whitespace pattern for guided json decoding. Only for models that support guided generation
                    enable_vision (str, default: "auto") — Controls vision mode, send images to the LLM in addition to text chunks. Only if have models that support vision, use get_vision_capable_llm_names() to see list. One of ["on", "off", "auto"]
                    visible_vision_models (List[str], default: ["auto"]) — Controls which vision model to use when processing images. Use get_vision_capable_llm_names() to see list. Must provide exactly one model. ["auto"] for automatic
            max_num_chunks:
                Max limit of chunks to send to the summarizer
            sampling_strategy:
                How to sample if the document has more chunks than max_num_chunks.
                Options are "auto", "uniform", "first", "first+last", default is "auto" (a hybrid of them all).
            pages:
                List of specific pages (of the ingested document in PDF form) to use from the document. 1-based indexing.
            schema:
                Optional JSON schema to use for guided json generation.
            keep_intermediate_results:
                Whether to keep intermediate results. Default: disabled.
                If disabled, further LLM calls are applied to the intermediate results until one global summary is obtained: map+reduce (i.e., summary).
                If enabled, the results' content will be a list of strings (the results of applying the LLM to different pieces of document context): map (i.e., extract).
            guardrails_settings:
                Guardrails Settings.
            meta_data_to_include:
                A dictionary containing flags that indicate whether each piece of document metadata is to be included as part of the context given to the LLM. Only used if enable_vision is disabled.
                Default is {
                    "name": True,
                    "text": True,
                    "page": True,
                    "captions": True,
                    "uri": False,
                    "connector": False,
                    "original_mtime": False,
                    "age": False,
                    "score": False,
                }
            timeout:
                Amount of time in seconds to allow the request to run. The default is 86400 seconds.

        Returns:
            ProcessedDocument: Processed document. The content is either a string (keep_intermediate_results=False) or a list of strings (keep_intermediate_results=True).

        Raises:
            TimeoutError: The request did not complete in time.
            SessionError: No summary or extraction created. Document wasn't part of a collection, or LLM timed out, etc.
        """
        if isinstance(llm, int):
            names = self.get_llm_names()
            llm = names[llm]

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            summary_id = str(uuid.uuid4())
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.create_process_document_job(
                    process_document_job_request=rest.ProcessDocumentJobRequest(
                        summary_id=summary_id,
                        document_id=document_id,
                        system_prompt=system_prompt,
                        pre_prompt_summary=pre_prompt_summary,
                        prompt_summary=prompt_summary,
                        llm=llm,
                        llm_args=llm_args,
                        max_num_chunks=max_num_chunks,
                        sampling_strategy=sampling_strategy,
                        pages=pages,
                        keep_intermediate_results=keep_intermediate_results,
                        schema=schema,
                        guardrails_settings=guardrails_settings,
                        meta_data_to_include=meta_data_to_include,
                        timeout=int(timeout) if timeout is not None else None,
                        image_batch_image_prompt=image_batch_image_prompt,
                        image_batch_final_prompt=image_batch_final_prompt,
                    ),
                    _headers=header,
                )
            )
            process_job = self._wait_for_completion(response.id, timeout=timeout)

            if process_job.failed:
                raise SessionError(str(process_job.errors))

            summary = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_summary(
                    summary_id=summary_id, _headers=header
                )
            )

        if summary.error:
            raise SessionError(summary.error)
        ret = ProcessedDocument(**summary.to_dict())
        if keep_intermediate_results:
            ret.content = ast.literal_eval(summary.content)
        return ret

    def list_recent_document_summaries(
        self, document_id: str, offset: int, limit: int
    ) -> List[ProcessedDocument]:
        """Fetches recent document summaries/extractions/transformations

        Args:
            document_id:
                document ID for which to return summaries
            offset:
                How many summaries to skip before returning summaries.
            limit:
                How many summaries to return.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_document_summaries(
                    document_id=document_id,
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )

        ret = [ProcessedDocument(**d.to_dict()) for d in response]
        for r in ret:
            kwargs = json.loads(r.kwargs)
            if kwargs.get("keep_intermedidate_results"):
                r.content = ast.literal_eval(r.content)
        return ret

    def encode_for_retrieval(
        self, chunks: Iterable[str], embedding_model: Union[str, None] = None
    ) -> List[List[float]]:
        """Encode texts for semantic searching.

        See Also: H2OGPTE.match for getting a list of chunks that semantically match
        each encoded text.

        Args:
            chunks:
                List of strings of texts to be encoded.
            embedding_model:
                embedding model to use. call list_embedding_models() to list of options.

        Returns:
            List of list of floats: Each list in the list is the encoded original text.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if embedding_model is None:
                rest_embedding_model = _rest_to_client_exceptions(
                    lambda: rest_client.model_api.get_default_embedding_model(
                        _headers=header
                    )
                )
                embedding_model = rest_embedding_model.id
            result = _rest_to_client_exceptions(
                lambda: rest_client.model_api.encode_chunks_for_retrieval(
                    encode_chunks_for_retrieval_request=rest.EncodeChunksForRetrievalRequest(
                        chunks=chunks
                    ),
                    model_id=embedding_model,
                    _headers=header,
                )
            )
        return result

    def get_chunks(self, collection_id: str, chunk_ids: Iterable[int]) -> List[Chunk]:
        """Get the text of specific chunks in a collection.

        Args:
            collection_id:
                String id of the collection to search in.
            chunk_ids:
                List of ints for the chunks to return. Chunks are indexed starting at 1.

        Returns:
            Chunk: The text of the chunk.

        Raises:
            Exception: One or more chunks could not be found.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_chunks = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_chunks(
                    collection_id=collection_id, chunk_ids=chunk_ids, _headers=header
                )
            )
        return [Chunk(**c.to_dict()) for c in rest_chunks]

    def get_collection(self, collection_id: str) -> Collection:
        """Get metadata about a collection.

        Args:
            collection_id:
                String id of the collection to search for.

        Returns:
            Collection: Metadata about the collection.

        Raises:
            KeyError: The collection was not found.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_collection = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection(
                    collection_id=collection_id, _headers=header
                )
            )
            collection = Collection(**rest_collection.to_dict())

            rest_settings = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_settings(
                    collection_id=collection_id, _headers=header
                )
            )
            collection.collection_settings = rest_settings.to_dict()

            rest_chat_settings = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_chat_settings(
                    collection_id=collection_id, _headers=header
                )
            )
            collection.chat_settings = rest_chat_settings.to_dict()

            metadata = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_metadata(
                    collection_id=collection_id, _headers=header
                )
            )
            if metadata != {}:
                collection.metadata_dict = metadata

        return collection

    def get_collection_for_chat_session(self, chat_session_id: str) -> Collection:
        """Get metadata about the collection of a chat session.

        Args:
            chat_session_id:
                String id of the chat session to search for.

        Returns:
            Collection: Metadata about the collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            chat_session = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session(
                    chat_session_id, _headers=header
                )
            )
        if chat_session.collection_id is None:
            raise ObjectNotFoundError({"error": "Collection not found"})
        return self.get_collection(chat_session.collection_id)

    def get_document(self, document_id: str, include_layout: bool = False) -> Document:
        """Fetches information about a specific document.

        Args:
            document_id:
                String id of the document.
            include_layout:
                Include the layout prediction results.

        Returns:
            Document: Metadata about the Document.

        Raises:
            KeyError: The document was not found.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_document = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document(
                    document_id=document_id, _headers=header
                )
            )
            document = Document(**rest_document.to_dict())

            if include_layout:
                document.page_layout_dict = _rest_to_client_exceptions(
                    lambda: rest_client.document_api.get_document_page_layout(
                        document_id=document_id, _headers=header
                    )
                )

            document.meta_data_dict = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_internal_metadata(
                    document_id=document_id, _headers=header
                )
            )
            document.user_source_file = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_user_source_file(
                    document_id=document_id, _headers=header
                )
            )
            document.page_ocr_model_dict = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_page_ocr_model(
                    document_id=document_id, _headers=header
                )
            )
            rest_guardrails_settings = _rest_to_client_exceptions(
                lambda: rest_client.document_api.get_document_guardrails_settings(
                    document_id=document_id, _headers=header
                )
            )
            if rest_guardrails_settings is not None:
                document.guardrails_settings = rest_guardrails_settings.to_dict()

        return document

    def get_job(self, job_id: str) -> Job:
        """Fetches information about a specific job.

        Args:
            job_id:
                String id of the job.

        Returns:
            Job: Metadata about the Job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_job = _rest_to_client_exceptions(
                lambda: rest_client.job_api.get_job(job_id=job_id, _headers=header)
            )
        return _convert_rest_job(rest_job)

    def get_meta(self) -> Meta:
        """Returns information about the environment and the user.

        Returns:
            Meta: Details about the version and license of the environment and
            the user's name and email.
        """
        response = self._get("/rpc/meta")
        return Meta(**response)

    def get_llm_usage_24h(self) -> float:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats(
                    interval="24 hours", _headers=header
                )
            )
        return response.current

    def get_llm_usage_24h_by_llm(self) -> List[LLMUsage]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats_by_model(
                    interval="24 hours", _headers=header
                )
            )
        return [LLMUsage(**d.to_dict()) for d in response]

    def get_llm_usage_24h_with_limits(self) -> LLMUsageLimit:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            usage = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats(
                    interval="24 hours", _headers=header
                )
            )
        return LLMUsageLimit(**usage.to_dict())

    def get_llm_usage_6h(self) -> float:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats(
                    interval="6 hours", _headers=header
                )
            )
        return response.current

    def get_llm_usage_6h_by_llm(self) -> List[LLMUsage]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats_by_model(
                    interval="6 hours", _headers=header
                )
            )
        return [LLMUsage(**d.to_dict()) for d in response]

    def get_llm_usage_with_limits(self, interval: str) -> LLMUsageLimit:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            usage = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats(
                    interval=interval, _headers=header
                )
            )
        return LLMUsageLimit(**usage.to_dict())

    def get_llm_usage_by_llm(self, interval: str) -> List[LLMUsage]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats_by_model(
                    interval=interval, _headers=header
                )
            )
        return [LLMUsage(**d.to_dict()) for d in response]

    def get_llm_usage_by_user(self, interval: str) -> List[UserWithLLMUsage]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats_by_user(
                    interval=interval, _headers=header
                )
            )
        return [UserWithLLMUsage(**d.to_dict()) for d in response]

    def get_llm_usage_by_llm_and_user(self, interval: str) -> List[LLMWithUserUsage]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_usage_stats_by_model_and_user(
                    interval=interval, _headers=header
                )
            )
        return [LLMWithUserUsage(**d.to_dict()) for d in response]

    def get_llm_performance_by_llm(self, interval: str) -> List[LLMPerformance]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_performance_stats_by_model(
                    interval=interval, _headers=header
                )
            )
        return [LLMPerformance(**d.to_dict()) for d in response]

    def get_scheduler_stats(self) -> SchedulerStats:
        """Count the number of global, pending jobs on the server.

        Returns:
            SchedulerStats: The queue length for number of jobs.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_stats = _rest_to_client_exceptions(
                lambda: rest_client.job_api.count_pending_jobs(_headers=header)
            )
        stats_dict = rest_stats.to_dict()
        stats_dict["queue_length"] = stats_dict["count"]
        return SchedulerStats(**stats_dict)

    def ingest_from_file_system(
        self,
        collection_id: str,
        root_dir: str,
        glob: str,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
    ) -> Job:
        """Add files from the local system into a collection.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            root_dir:
                String path of where to look for files.
            glob:
                String of the glob pattern used to match files in the root directory.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_file_system_job(
                    collection_id=collection_id,
                    ingest_from_file_system_body=rest.IngestFromFileSystemBody(
                        root_dir=root_dir, glob=glob
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def ingest_from_plain_text(
        self,
        collection_id: str,
        plain_text: str,
        file_name: str,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        metadata: Union[Dict[str, Any], None] = None,
        timeout: Union[float, None] = None,
    ):
        """Add plain text to a collection.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            plain_text:
                String of the plain text to ingest.
            file_name:
                String of the file name to use for the document.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            metadata:
                Dictionary of metadata to add to the document.
            timeout:
                Timeout in seconds
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_plain_text_job(
                    collection_id=collection_id,
                    body=plain_text,
                    file_name=file_name,
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    timeout=timeout,
                    metadata=None if metadata is None else json.dumps(metadata),
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def ingest_from_s3(
        self,
        collection_id: str,
        url: Union[str, List[str]],
        region: str = "us-east-1",
        credentials: Union[S3Credential, None] = None,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        metadata: Union[Dict[str, Any], None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
    ):
        """Add files from the AWS S3 storage into a collection.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            url:
                The path or list of paths of S3 files or directories. Examples: s3://bucket/file, s3://bucket/../dir/
            region:
                The name of the region used for interaction with AWS services.
            credentials:
                The object with S3 credentials. If the object is not provided, only public buckets will be accessible.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            metadata:
                Dictionary of metadata to add to the document.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_s3_job(
                    collection_id=collection_id,
                    ingest_from_s3_body=rest.IngestFromS3Body(
                        urls=[url] if isinstance(url, str) else url,
                        region=region,
                        credentials=(
                            None
                            if credentials is None
                            else rest.S3Credentials(**credentials.__dict__)
                        ),
                        metadata=metadata,
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def ingest_from_gcs(
        self,
        collection_id: str,
        url: Union[str, List[str]],
        credentials: Union[GCSServiceAccountCredential, None] = None,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        metadata: Union[Dict[str, Any], None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
    ):
        """Add files from the Google Cloud Storage into a collection.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            url:
                The path or list of paths of GCS files or directories. Examples: gs://bucket/file, gs://bucket/../dir/
            credentials:
                The object holding a path to a JSON key of Google Cloud service account. If the object is not provided,
                only public buckets will be accessible.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            metadata:
                Dictionary of metadata to add to the document.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_gcs_job(
                    collection_id=collection_id,
                    ingest_from_gcs_body=rest.IngestFromGcsBody(
                        urls=[url] if isinstance(url, str) else url,
                        credentials=(
                            None
                            if credentials is None
                            else rest.GCSCredentials(
                                service_account_json_key=credentials.load_key_as_string()
                            )
                        ),
                        metadata=metadata,
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def ingest_from_azure_blob_storage(
        self,
        collection_id: str,
        container: str,
        path: Union[str, List[str]],
        account_name: str,
        credentials: Union[AzureKeyCredential, AzureSASCredential, None] = None,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        metadata: Union[Dict[str, Any], None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
    ):
        """Add files from the Azure Blob Storage into a collection.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            container:
                Name of the Azure Blob Storage container.
            path:
                Path or list of paths to files or directories within an Azure Blob Storage container.
                Examples: file1, dir1/file2, dir3/dir4/
            account_name:
                Name of a storage account
            credentials:
                The object with Azure credentials. If the object is not provided,
                only a public container will be accessible.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            metadata:
                Metadata to be associated with the document.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_azure_blob_storage_job(
                    collection_id=collection_id,
                    ingest_from_azure_blob_storage_body=rest.IngestFromAzureBlobStorageBody(
                        container=container,
                        paths=[path] if isinstance(path, str) else path,
                        account_name=account_name,
                        credentials=(
                            None
                            if credentials is None
                            else rest.AzureCredentials(**credentials.__dict__)
                        ),
                        metadata=metadata,
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def ingest_from_confluence(
        self,
        collection_id: str,
        base_url: str,
        page_id: Union[str, List[str]],
        credentials: ConfluenceCredential,
        include_attachments: Union[bool, None] = None,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        metadata: Union[Dict[str, Any], None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
    ):
        """Ingests confluence pages into collection.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            base_url:
                Url of confluence instance. Example: https://h2oai.atlassian.net/wiki
            page_id:
                The page id or ids of pages to be ingested.
            credentials:
                The object with Confluence credentials.
            include_attachments:
                A flag indicating whether to also ingest attachments with the page.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            metadata:
                Dictionary of metadata to add to the document.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_confluence_job(
                    collection_id=collection_id,
                    ingest_from_confluence_body=rest.IngestFromConfluenceBody(
                        base_url=base_url,
                        page_ids=[page_id] if isinstance(page_id, str) else page_id,
                        credentials=rest.ConfluenceCredentials(**credentials.__dict__),
                        metadata=metadata,
                        include_attachments=include_attachments,
                    ),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def list_secret_ids(self, connector_type: Optional[str] = None) -> List[str]:
        """
        List available secret IDs from the SecureStore for cloud storage connectors.

        Args:
            connector_type: Type of connector ('s3', 'gcs', 'azure_key', 'azure_sas')
                           If None, returns secrets for all connector types.

        Returns:
            List of secret IDs available for the specified connector type
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.secrets_api.list_secret_ids(
                    connector_type=connector_type, _headers=header
                )
            )
        return response.ids

    def get_secret(self, secret_id: str) -> Union[Dict[str, Any], None]:
        """Get a secret from the SecureStore by its ID.

        Args:
            secret_id: The ID of the secret to retrieve.

        Returns:
            The secret object corresponding to the provided ID.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.secrets_api.get_secret(
                    secret_id=secret_id, _headers=header
                )
            )
        return response.to_dict()

    def get_secret_value(self, secret_id: str) -> Union[str, None]:
        """Get the value of a secret from the SecureStore by its ID.

        Args:
            secret_id: The ID of the secret to retrieve.

        Returns:
            The value of the secret corresponding to the provided ID.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.secrets_api.get_secret_value(
                    secret_id=secret_id, _headers=header
                )
            )
        return response.value if response else None

    def create_secret(self, secret: Dict[str, Any]) -> None:
        """Create a new secret in the SecureStore.

        Args:
            secret: A dictionary containing the secret data to be stored.

        Returns:
            The ID of the newly created secret.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.secrets_api.create_secret(
                    secret=secret, _headers=header
                )
            )
        return response.id

    def update_secret(self, secret_id: str, secret: Dict[str, Any]) -> None:
        """Update an existing secret in the SecureStore.

        Args:
            secret_id: The ID of the secret to update.
            secret: A dictionary containing the updated secret data.

        Returns:
            None
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.secrets_api.update_secret(
                    secret_id=secret_id, secret=secret, _headers=header
                )
            )

    def delete_secret(self, secret_id: str) -> None:
        """Delete a secret from the SecureStore by its ID.

        Args:
            secret_id: The ID of the secret to delete.

        Returns:
            None
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.secrets_api.delete_secret(
                    secret_id=secret_id, _headers=header
                )
            )

    def ingest_uploads(
        self,
        collection_id: str,
        upload_ids: Iterable[str],
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        restricted: bool = False,
        permissions: Union[List[SharePermission], None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        metadata: Union[Dict[str, Any], None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
        encrypt_document: Union[bool, None] = None,
        callback: Optional[Callable[[Job], None]] = None,
    ) -> Job:
        """Add uploaded documents into a specific collection.

        See Also:
            upload: Upload the files into the system to then be ingested into a collection.
            delete_upload: Delete uploaded file

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            upload_ids:
                List of string ids of each uploaded document to add to the collection.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            restricted:
                Whether the document should be restricted only to certain users.
            permissions:
                List of permissions. Each permission is a SharePermission object.
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            metadata:
                Dictionary mapping upload_ids to their metadata. Each key must be an upload_id
                from the upload_ids list, and each value is a dictionary of metadata key-value
                pairs to associate with that document.

                Example::

                    # Single document
                    metadata = {upload_id: {"category": "reports", "year": "2024"}}

                    # Multiple documents
                    metadata = {
                        upload_id_1: {"category": "reports"},
                        upload_id_2: {"category": "invoices"}
                    }
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
            encrypt_document:
                Whether to encrypt the document files at rest in object storage.
            callback:
                Function for processing job status info during the upload.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_upload_job(
                    collection_id=collection_id,
                    ingest_upload_body=rest.IngestUploadBody(metadata=metadata),
                    upload_ids=upload_ids,
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    encrypt_document=encrypt_document,
                    timeout=timeout,
                    restricted=restricted,
                    permissions=(
                        [permission.username for permission in permissions]
                        if permissions
                        else None
                    ),
                    _headers=header,
                )
            )
        return self._wait_for_completion(
            response.id, timeout=timeout, callback=callback
        )

    def ingest_website(
        self,
        collection_id: str,
        url: str,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        follow_links: Union[bool, None] = None,
        max_depth: Union[int, None] = None,
        max_documents: Union[int, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        timeout: Union[float, None] = None,
        ingest_mode: Union[str, None] = None,
    ) -> Job:
        """Crawl and ingest a URL into a collection.

        The web page or document linked from this URL will be imported.

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            url:
                String of the url to crawl.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            follow_links:
                Whether to import all web pages linked from this URL will be imported.
                External links will be ignored. Links to other pages on the same domain will
                be followed as long as they are at the same level or below the URL you specify.
                Each page will be transformed into a PDF document.
            max_depth:
                Max depth of recursion when following links, only when follow_links is True.
                Max_depth of 0 means don't follow any links, max_depth of 1 means follow only top-level links, etc.
                Use -1 for automatic (system settings).
            max_documents:
                Max number of documents when following links, only when follow_links is True.
                Use None for automatic (system defaults).
                Use -1 for max (system limit).
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            timeout:
                Timeout in seconds.
            ingest_mode:
                Ingest mode to use.
                "standard" - Files will be ingested for use with RAG
                "lite" - Files will be ingested for use with RAG, but minimal processing will be done, favoring ingest speed over accuracy
                "agent_only" - Bypasses standard ingestion. Files can only be used with agents.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_from_website_job(
                    collection_id=collection_id,
                    ingest_from_website_body=rest.IngestFromWebsiteBody(url=url),
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    follow_links=follow_links,
                    max_depth=max_depth,
                    max_documents=max_documents,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    ingest_mode=ingest_mode,
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def ingest_agent_only_to_standard(
        self,
        collection_id: str,
        document_id: str,
        gen_doc_summaries: Union[bool, None] = None,
        gen_doc_questions: Union[bool, None] = None,
        audio_input_language: Union[str, None] = None,
        ocr_model: Union[str, None] = None,
        restricted: bool = False,
        permissions: Union[List[SharePermission], None] = None,
        tesseract_lang: Union[str, None] = None,
        keep_tables_as_one_chunk: Union[bool, None] = None,
        chunk_by_page: Union[bool, None] = None,
        handwriting_check: Union[bool, None] = None,
        timeout: Union[float, None] = None,
    ):
        """For files uploaded in "agent_only" ingest mode, convert to PDF and parse

        See Also:
            upload: Upload the files into the system to then be ingested into a collection.
            delete_upload: Delete uploaded file

        Args:
            collection_id:
                String id of the collection to add the ingested documents into.
            document_id:
                ID of document to be parsed.
            gen_doc_summaries:
                Whether to auto-generate document summaries (uses LLM)
            gen_doc_questions:
                Whether to auto-generate sample questions for each document (uses LLM)
            audio_input_language:
                Language of audio files. Defaults to "auto" language detection. Pass empty string to see choices.
            ocr_model:
                Which method to use to extract text from images using AI-enabled optical character recognition (OCR) models.
                Pass empty string to see choices.
                docTR is best for Latin text, PaddleOCR is best for certain non-Latin languages, Tesseract covers a wide range of languages.
                Mississippi works well on handwriting.
                "auto" - Automatic will auto-select the best OCR model for every page.
                "off" - Disable OCR for speed, but all images will then be skipped (also no image captions will be made).
            restricted:
                Whether the document should be restricted only to certain users.
            permissions:
                List of permissions. Each permission is a SharePermission object.
            tesseract_lang:
                Which language to use when using ocr_model="tesseract". Pass empty string to see choices.
            keep_tables_as_one_chunk:
                When tables are identified by the table parser the table tokens will be kept in a single chunk.
            chunk_by_page:
                Each page will be a chunk. `keep_tables_as_one_chunk` will be ignored if this is True.
            handwriting_check:
                Check pages for handwriting. Will use specialized models if handwriting is found.
            timeout:
                Timeout in seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.ingestion_api.create_ingest_agent_only_to_standard_job(
                    collection_id=collection_id,
                    document_id=document_id,
                    gen_doc_summaries=gen_doc_summaries,
                    gen_doc_questions=gen_doc_questions,
                    audio_input_language=audio_input_language,
                    ocr_model=ocr_model,
                    tesseract_lang=tesseract_lang,
                    keep_tables_as_one_chunk=keep_tables_as_one_chunk,
                    chunk_by_page=chunk_by_page,
                    handwriting_check=handwriting_check,
                    restricted=restricted,
                    permissions=(
                        [permission.username for permission in permissions]
                        if permissions
                        else None
                    ),
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def list_chat_messages(
        self, chat_session_id: str, offset: int, limit: int
    ) -> List[ChatMessage]:
        """Fetch chat message and metadata for messages in a chat session.

        Messages without a `reply_to` are from the end user, messages with a `reply_to`
        are from an LLM and a response to a specific user message.

        Args:
            chat_session_id:
                String id of the chat session to filter by.
            offset:
                How many chat messages to skip before returning.
            limit:
                How many chat messages to return.

        Returns:
            list of ChatMessage: Text and metadata for chat messages.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session_messages(
                    session_id=chat_session_id,
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )

        data = [d.to_dict() for d in response]
        for d in data:
            value = d.get("type_list")
            if value == [None]:
                continue
            if value:
                d["type_list"] = [json.dumps(v) for v in value]

        return [ChatMessage(**d) for d in data]

    def list_chat_message_references(
        self, message_id: str, limit: Optional[int] = None
    ) -> List[ChatMessageReference]:
        """Fetch metadata for references of a chat message.

        References are only available for messages sent from an LLM, an empty list will be returned
        for messages sent by the user.

        Args:
            message_id:
                String id of the message to get references for.
            limit:
                The number of references to consider based on the highest confidence scores.

        Returns:
            list of ChatMessageReference: Metadata including the document name, polygon information,
            and score.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_message_references(
                    message_id=message_id, limit=limit, _headers=header
                )
            )
        return [ChatMessageReference(**d.to_dict()) for d in response]

    def list_list_chat_message_meta(self, message_id: str) -> List[ChatMessageMeta]:
        """Fetch chat message meta information.

        Args:
            message_id:
                Message id to which the metadata should be pulled.

        Returns:
            list of ChatMessageMeta: Metadata about the chat message.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_message_meta(
                    message_id=message_id, _headers=header
                )
            )
        return [ChatMessageMeta(**d.to_dict()) for d in response]

    def list_chat_message_meta_part(
        self, message_id: str, info_type: str
    ) -> ChatMessageMeta:
        """Fetch one chat message meta information.

        Args:
            message_id:
                Message id to which the metadata should be pulled.
            info_type:
                Metadata type to fetch.
                Valid choices are: "self_reflection", "usage_stats", "prompt_raw", "llm_only", "hyde1", "py_client_code"

        Returns:
            ChatMessageMeta: Metadata information about the chat message.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_message_meta(
                    message_id=message_id, info_type=info_type, _headers=header
                )
            )

        if len(response) == 0:
            raise ObjectNotFoundError(
                {"error": f"Chat meta type not found for {info_type}"}
            )

        return ChatMessageMeta(**response[0].to_dict())

    def list_chat_messages_full(
        self, chat_session_id: str, offset: int, limit: int
    ) -> List[ChatMessageFull]:
        """Fetch chat message and metadata for messages in a chat session.

        Messages without a `reply_to` are from the end user, messages with a `reply_to`
        are from an LLM and a response to a specific user message.

        Args:
            chat_session_id:
                String id of the chat session to filter by.
            offset:
                How many chat messages to skip before returning.
            limit:
                How many chat messages to return.

        Returns:
            list of ChatMessageFull: Text and metadata for chat messages.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session_messages(
                    session_id=chat_session_id,
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )

        data = [d.to_dict() for d in response]
        for d in data:
            value = d.get("type_list")
            if value == [None]:
                continue
            if value:
                d["type_list"] = [ChatMessageMeta(**v) for v in value]

        return [ChatMessageFull(**d) for d in data]

    def list_chat_sessions_for_collection(
        self, collection_id: str, offset: int, limit: int
    ) -> List[ChatSessionForCollection]:
        """Fetch chat session metadata for chat sessions in a collection.

        Args:
            collection_id:
                String id of the collection to filter by.
            offset:
                How many chat sessions to skip before returning.
            limit:
                How many chat sessions to return.

        Returns:
            list of ChatSessionForCollection: Metadata about each chat session including the
            latest message.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_chat_sessions_for_collection(
                    collection_id=collection_id,
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )
        return [ChatSessionForCollection(**d.to_dict()) for d in response]

    def list_chat_sessions_for_document(
        self, document_id: str, offset: int, limit: int
    ) -> List[ChatSessionForDocument]:
        """Fetch chat session metadata for chat session that produced a specific document (typically through agents).

        Args:
            document_id:
                String id of the document to filter by.
            offset:
                How many chat sessions to skip before returning.
            limit:
                How many chat sessions to return.

        Returns:
            list of ChatSessionForDocument: Metadata about each chat session including the
            latest message.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_chat_sessions_for_document(
                    document_id=document_id, offset=offset, limit=limit, _headers=header
                )
            )
        return [ChatSessionForDocument(**d.to_dict()) for d in response]

    def rename_chat_session(self, chat_session_id: str, name: str):
        """Update a chat session name

        Args:
            chat_session_id:
                String id of the document to search for.
            name:
                The new chat session name.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.update_chat_session(
                    session_id=chat_session_id,
                    chat_session_update_request=rest.ChatSessionUpdateRequest(
                        name=name
                    ),
                    _headers=header,
                )
            )

    def share_chat_session(
        self, chat_session_id: str, expiration_days: Optional[int] = None
    ) -> ChatShareUrl:
        """Share a chat session and get a publicly accessible URL.

        Args:
            chat_session_id:
                String id of the chat session to share.
            expiration_days:
                Number of days until the shared URL expires.
                If not provided, defaults to 7 days.

        Returns:
            ChatShareUrl: Object containing the shareable URL and relative path.
        """
        response = self._sharing("share_chat", chat_session_id, expiration_days)
        return ChatShareUrl(
            url=response["url"], relative_path=response["relative_path"]
        )

    def list_collections_for_document(
        self, document_id: str, offset: int, limit: int
    ) -> List[CollectionInfo]:
        """Fetch metadata about each collection the document is a part of.

        At this time, each document will only be available in a single collection.

        Args:
            document_id:
                String id of the document to search for.
            offset:
                How many collections to skip before returning.
            limit:
                How many collections to return.

        Returns:
            list of CollectionInfo: Metadata about each collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_collections_for_document(
                    document_id=document_id, offset=offset, limit=limit, _headers=header
                )
            )
        return [CollectionInfo(**d.to_dict()) for d in response]

    def get_default_collection(self) -> CollectionInfo:
        """Get the default collection, to be used for collection API-keys.

        Returns:
            CollectionInfo: Default collection info.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_collection = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection(
                    collection_id="default", _headers=header
                )
            )
            collection = CollectionInfo(**rest_collection.to_dict())
            metadata = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_metadata(
                    collection_id=rest_collection.id, _headers=header
                )
            )
            if metadata != {}:
                collection.metadata_dict = metadata

        return collection

    def list_documents_in_collection(
        self, collection_id: str, offset: int, limit: int, metadata_filter: dict = {}
    ) -> List[DocumentInfo]:
        """Fetch document metadata for documents in a collection.

        Args:
            collection_id:
                String id of the collection to filter by.
            offset:
                How many documents to skip before returning.
            limit:
                How many documents to return.
            metadata_filter:
                Metadata filter to apply to the documents.

        Returns:
            list of DocumentInfo: Metadata about each document.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            metadata_filter_json = None
            if metadata_filter and len(metadata_filter) > 0:
                metadata_filter_json = json.dumps(metadata_filter)
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_documents_for_collection(
                    collection_id=collection_id,
                    offset=offset,
                    limit=limit,
                    metadata_filter=metadata_filter_json,
                    _headers=header,
                )
            )

        dicts = [document.to_dict() for document in response]
        for d in dicts:
            unmarshal_dict(d)

        return [DocumentInfo(**d) for d in dicts]

    def list_jobs(self) -> List[Job]:
        """List the user's jobs.

        Returns:
            list of Job:
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.job_api.list_jobs(_headers=header)
            )

        return [_convert_rest_job(d) for d in response if d.kind in JobKind.__members__]

    def list_all_jobs(self) -> List[UserJobs]:
        """List all jobs (to be used by admins only).

        Returns:
            list of UserJobs
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.job_api.list_user_jobs(_headers=header)
            )

        def _convert_rest_user_job(user_jobs: rest.UserJobDetails) -> UserJobs:
            jobs = [_convert_rest_job(d) for d in user_jobs.jobs]
            return UserJobs(
                username=user_jobs.username,
                user_id=user_jobs.user_id,
                jobs=jobs,
            )

        return [_convert_rest_user_job(d) for d in response]

    def list_recent_chat_sessions(
        self, offset: int, limit: int
    ) -> List[ChatSessionInfo]:
        """Fetch user's chat session metadata sorted by last update time.

        Chats across all collections will be accessed.

        Args:
            offset:
                How many chat sessions to skip before returning.
            limit:
                How many chat sessions to return.

        Returns:
            list of ChatSessionInfo: Metadata about each chat session including the
            latest message.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.list_chat_sessions(
                    offset=offset, limit=limit, _headers=header
                )
            )
        return [ChatSessionInfo(**d.to_dict()) for d in response]

    def list_question_reply_feedback_data(
        self,
        offset: int,
        limit: int,
        collection_id: Optional[str] = None,
        interval: Optional[str] = None,
        no_collection: bool = False,
    ) -> List[QuestionReplyData]:
        """Fetch user's questions and answers that have a feedback.

        Questions and answers with metadata and feedback information.

        Args:
            offset:
                How many conversations to skip before returning.
            limit:
                How many conversations to return.
            collection_id:
                Optional collection ID to filter by.
            interval:
                Optional time interval to filter by (e.g. "7 days", "30 days", "90 days", "1 year").
            no_collection:
                If True, only return feedbacks with no collection.

        Returns:
            list of QuestionReplyData: Metadata about questions and answers.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.list_question_answer_feedbacks(
                    offset=offset,
                    limit=limit,
                    collection_id=collection_id,
                    interval=interval,
                    no_collection=no_collection,
                    _headers=header,
                )
            )
        return [QuestionReplyData(**d.to_dict()) for d in response]

    def update_question_reply_feedback(
        self, reply_id: str, expected_answer: str, user_comment: str
    ):
        """Update feedback for a specific answer to a question.

        Args:
            reply_id:
                UUID of the reply.
            expected_answer:
                Expected answer.
            user_comment:
                User comment.

        Returns:
            None
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.update_question_answer_feedback(
                    answer_id=reply_id,
                    update_qa_feedback_request=rest.UpdateQAFeedbackRequest(
                        expected_answer=expected_answer,
                        user_comment=user_comment,
                    ),
                    _headers=header,
                )
            )

    def count_question_reply_feedback(
        self,
        collection_id: Optional[str] = None,
        interval: Optional[str] = None,
        no_collection: bool = False,
    ) -> int:
        """Fetch user's questions and answers with feedback count.

        Args:
            collection_id:
                Optional collection ID to filter by.
            interval:
                Optional time interval to filter by (e.g. "7 days", "30 days", "90 days", "1 year").
            no_collection:
                If True, only count feedbacks with no collection.

        Returns:
            int: the count of questions and replies that have a user feedback.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_question_answer_feedback_count(
                    collection_id=collection_id,
                    interval=interval,
                    no_collection=no_collection,
                    _headers=header,
                )
            )
        return response.count

    def export_feedback_csv(
        self,
        destination_directory: Union[str, Path],
        destination_file_name: str = "feedback_export.csv",
        collection_id: Optional[str] = None,
        interval: Optional[str] = None,
        no_collection: bool = False,
        timeout: Union[float, None] = None,
    ) -> Path:
        """Export feedback data as CSV via job and save to disk.

        Submits an export job, waits for completion, then downloads the
        CSV file to the specified directory.

        Args:
            destination_directory:
                Destination directory to save the CSV file into.
            destination_file_name:
                Destination file name. Defaults to ``"feedback_export.csv"``.
            collection_id:
                Optional collection ID to filter by.
            interval:
                Optional time interval to filter by
                (e.g. "7 days", "30 days", "90 days", "1 year").
            no_collection:
                If True, only export feedbacks with no collection.
            timeout:
                Timeout in seconds for the export job.

        Returns:
            Path: Path of the downloaded CSV file.
        """
        destination_directory = Path(destination_directory)
        destination_file = destination_directory / destination_file_name
        if not destination_directory.is_dir():
            raise FileNotFoundError("Destination directory does not exist")
        if destination_file.exists():
            raise FileExistsError(f"File {destination_file} already exists")

        ret = self._job(
            "q:crawl.ExportFeedbackCSVJob",
            collection_id=collection_id,
            interval=interval,
            no_collection=no_collection,
        )
        job = self._wait_for_completion(_to_id(ret), timeout=timeout)
        endpoint = f"/api/v1/question_answer_feedbacks/export/{job.id}"
        res = self._get(endpoint, as_json=False)
        self._raise_error_if_any(res)

        with open(destination_file, "wb") as f:
            f.write(res.content)
        return destination_file

    def list_recent_collections(self, offset: int, limit: int) -> List[CollectionInfo]:
        """Fetch user's collection metadata sorted by last update time.

        Args:
            offset:
                How many collections to skip before returning.
            limit:
                How many collections to return.

        Returns:
            list of CollectionInfo: Metadata about each collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_collections(
                    offset=offset, limit=limit, _headers=header
                )
            )
        return [CollectionInfo(**collection.to_dict()) for collection in response]

    def list_recent_collections_sort(
        self, offset: int, limit: int, sort_column: str, ascending: bool
    ) -> List[CollectionInfo]:
        """Fetch user's collection metadata sorted by last update time.

        Args:
            offset:
                How many collections to skip before returning.
            limit:
                How many collections to return.
            sort_column:
                Sort column.
            ascending:
                When True, return sorted by sort_column in ascending order.

        Returns:
            list of CollectionInfo: Metadata about each collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_collections(
                    offset=offset,
                    limit=limit,
                    sort_column=sort_column,
                    ascending=ascending,
                    _headers=header,
                )
            )
        return [CollectionInfo(**collection.to_dict()) for collection in response]

    def list_recent_collections_filter(
        self,
        offset: int,
        limit: int,
        current_user_only: bool = False,
        name_filter: str = "",
    ) -> List[CollectionInfo]:
        """Fetch user's collection metadata sorted by last update time with filter options.

        Args:
            offset:
                How many collections to skip before returning.
            limit:
                How many collections to return.
            current_user_only:
                When true, will only return the user owned collections.
            name_filter:
                Only returns collections with names matching this filter.

        Returns:
            list of CollectionInfo: Metadata about each collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_collections(
                    offset=offset,
                    limit=limit,
                    name_filter=name_filter,
                    current_user_only=current_user_only,
                    _headers=header,
                )
            )
        return [CollectionInfo(**d.to_dict()) for d in response]

    def list_recent_collections_metadata_filter(
        self, offset: int, limit: int, current_user_only: bool, metadata_filter: dict
    ) -> List[CollectionInfo]:
        """Fetch user's collection metadata sorted by last update time with a filter on metadata.

        Args:
            offset:
                How many collections to skip before returning.
            limit:
                How many collections to return.
            current_user_only:
                When true, will only return the user owned collections.
            metadata_filter:
                Only returns collections with metadata matching this filter.

        Returns:
            list of CollectionInfo: Metadata about each collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_collections(
                    offset=offset,
                    limit=limit,
                    metadata_filter=json.dumps(metadata_filter),
                    current_user_only=current_user_only,
                    _headers=header,
                )
            )
        return [CollectionInfo(**d.to_dict()) for d in response]

    def list_all_collections_sort(
        self,
        offset: int,
        limit: int,
        sort_column: str,
        ascending: bool,
        filter: str = "",
    ) -> List[CollectionInfo]:
        """Fetch all users' collection metadata sorted by last update time.

        This is for admin use only and includes private, public, and shared collections in the result.

        Args:
            offset:
                How many collections to skip before returning.
            limit:
                How many collections to return.
            sort_column:
                Sort column.
            ascending:
                When True, return sorted by sort_column in ascending order.
            filter:
                Optional filter to return collections matching by name, id, or username.

        Returns:
            list of CollectionInfo: Metadata about each collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_all_collections(
                    offset=offset,
                    limit=limit,
                    sort_column=sort_column,
                    ascending=ascending,
                    filter=filter,
                    _headers=header,
                )
            )
        return [CollectionInfo(**d.to_dict()) for d in response]

    def list_collection_permissions(self, collection_id: str) -> List[SharePermission]:
        """Returns a list of access permissions for a given collection.

        The returned list of permissions denotes who has access to
        the collection and their access level.

        Args:
            collection_id:
                ID of the collection to inspect.

        Returns:
            list of SharePermission: Sharing permissions list for the given collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_permissions(
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return [SharePermission(**d.to_dict()) for d in response]

    def list_collection_group_permissions(
        self, collection_id: str
    ) -> List[GroupSharePermission]:
        """Returns a list of group access permissions for a given collection.

        The returned list of group permissions denoting which groups have access to
        the collection and their access level.

        Args:
            collection_id:
                ID of the collection to inspect.

        Returns:
            list of GroupSharePermission: Group sharing permissions list for the given collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection_group_permissions(
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return [GroupSharePermission(**d.to_dict()) for d in response]

    def list_collection_public_permissions(self, collection_id: str) -> List[str]:
        """Returns the public permissions for a given collection.

        The returned list contains the permission strings that apply to
        public access of the collection.

        Args:
            collection_id:
                ID of the collection to inspect.

        Returns:
            list of str: Public permissions list for the given collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.list_collection_public_permissions(
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return response

    def list_users(self, offset: int, limit: int) -> List[User]:
        """List system users.

        Returns a list of all registered users fo the system, a registered user,
        is a users that has logged in at least once.

        Args:
            offset:
                How many users to skip before returning.
            limit:
                How many users to return.

        Returns:
            list of User: Metadata about each user.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.list_users(
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )
        return [User(**d.to_dict()) for d in response]

    def request_current_user_deletion(
        self,
    ) -> str:
        """Request deletion of the current user account.

        This creates a deletion request and returns a delete ID that must be used
        to confirm the deletion within 5 minutes.

        Returns:
            str: Delete ID that must be used to confirm deletion.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.request_current_user_deletion(
                    _headers=header,
                )
            )
        return response.delete_id

    def confirm_current_user_deletion(
        self,
        delete_id: str,
        timeout: Union[float, None] = None,
    ) -> None:
        """Confirm deletion of the current user data.

        Args:
            delete_id:
                The delete ID returned from request_current_user_deletion().
            timeout:
                Timeout in seconds. Default is 300 seconds.
        """
        header = self._get_auth_header()
        if timeout is None:
            timeout = 300.0

        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.confirm_current_user_deletion(
                    confirm_user_deletion_request=rest.ConfirmUserDeletionRequest(
                        delete_id=delete_id,
                    ),
                    timeout=timeout,
                    _headers=header,
                )
            )

    def share_collection(
        self, collection_id: str, permission: SharePermission
    ) -> ShareResponseStatus:
        """Share a collection to a user.

        The permission attribute defined the level of access,
        and who can access the collection, the collection_id attribute
        denotes the collection to be shared.

        Args:
            collection_id:
                ID of the collection to share.
            permission:
                Defines the rule for sharing, i.e. permission level.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.share_collection(
                        collection_id=collection_id,
                        username=permission.username,
                        share_collection_request=rest.ShareCollectionRequest(
                            permissions=permission.permissions
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_collection(
        self, collection_id: str, permission: SharePermission
    ) -> ShareResponseStatus:
        """Remove sharing of a collection to a user.

        The permission attribute defined the level of access,
        and who can access the collection, the collection_id attribute
        denotes the collection to be shared.

        In case of un-sharing, the SharePermission's user is sufficient.

        Args:
            collection_id:
                ID of the collection to un-share.
            permission:
                Defines the user for which collection access is revoked.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.unshare_collection(
                        collection_id=collection_id,
                        username=permission.username,
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_collection_for_all(self, collection_id: str) -> ShareResponseStatus:
        """Remove sharing of a collection to all other users but the original owner.

        Args:
            collection_id:
                ID of the collection to un-share.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.unshare_collection_for_all(
                        collection_id=collection_id,
                        _headers=header,
                    )
                )
            )
        return result

    def make_collection_public(
        self, collection_id: str, permissions: Optional[List[str]] = None
    ):
        """Make a collection public

        Once a collection is public, it will be accessible to all
        authenticated users of the system.

        Args:
            collection_id:
                ID of the collection to make public.
            permissions:
                Optional: Collection specific permissions. If not provided, all permissions will default to true.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_privacy(
                    collection_id=collection_id,
                    update_collection_privacy_request=rest.UpdateCollectionPrivacyRequest(
                        is_public=True, permissions=permissions
                    ),
                    _headers=header,
                )
            )

    def make_collection_private(self, collection_id: str):
        """Make a collection private

        Once a collection is private, other users will no longer
        be able to access chat history or documents related to
        the collection.

        Args:
            collection_id:
                ID of the collection to make private.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_privacy(
                    collection_id=collection_id,
                    update_collection_privacy_request=rest.UpdateCollectionPrivacyRequest(
                        is_public=False
                    ),
                    _headers=header,
                )
            )

    def share_collection_with_group(
        self, collection_id: str, permission: GroupSharePermission
    ) -> ShareResponseStatus:
        """Share a collection to a group.

        The permission attribute defines the level of access,
        and which group can access the collection, the collection_id attribute
        denotes the collection to be shared.

        Args:
            collection_id:
                ID of the collection to share.
            permission:
                Defines the rule for sharing, i.e. permission level and group.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.share_collection_with_group(
                        collection_id=collection_id,
                        group_id=permission.group_id,
                        share_collection_request=rest.ShareCollectionRequest(
                            permissions=permission.permissions
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_collection_from_group(
        self, collection_id: str, permission: GroupSharePermission
    ) -> ShareResponseStatus:
        """Remove sharing of a collection from a group.

        The permission attribute defines which group to remove access from,
        the collection_id attribute denotes the collection to be unshared.
        In case of un-sharing, the GroupSharePermission's group_id is sufficient.

        Args:
            collection_id:
                ID of the collection to un-share.
            permission:
                Defines the group for which collection access is revoked.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.unshare_collection_from_group(
                        collection_id=collection_id,
                        group_id=permission.group_id,
                        _headers=header,
                    )
                )
            )
        return result

    def list_extractor_permissions(self, extractor_id: str) -> List[SharePermission]:
        """Returns a list of access permissions for a given extractor.

        The returned list of permissions denotes who has access to
        the extractor and their access level.

        Args:
            extractor_id:
                ID of the extractor to inspect.

        Returns:
            list of SharePermission: Sharing permissions list for the given extractor.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.get_extractor_permissions(
                    extractor_id=extractor_id,
                    _headers=header,
                )
            )
        return [SharePermission(**d.to_dict()) for d in response]

    def list_extractor_group_permissions(
        self, extractor_id: str
    ) -> List[GroupSharePermission]:
        """Returns a list of group access permissions for a given extractor.

        The returned list of group permissions denoting which groups have access to
        the extractor and their access level.

        Args:
            extractor_id:
                ID of the extractor to inspect.

        Returns:
            list of GroupSharePermission: Group sharing permissions list for the given extractor.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.get_extractor_group_permissions(
                    extractor_id=extractor_id,
                    _headers=header,
                )
            )
        return [GroupSharePermission(**d.to_dict()) for d in response]

    def share_extractor(
        self, extractor_id: str, permission: SharePermission
    ) -> ShareResponseStatus:
        """Share an extractor to a user.

        The permission attribute defined the level of access,
        and who can access the extractor, the extractor_id attribute
        denotes the extractor to be shared.

        Args:
            extractor_id:
                ID of the extractor to share.
            permission:
                Defines the rule for sharing, i.e. permission level.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.share_extractor(
                        extractor_id=extractor_id,
                        username=permission.username,
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_extractor(
        self, extractor_id: str, permission: SharePermission
    ) -> ShareResponseStatus:
        """Remove sharing of an extractor to a user.

        The permission attribute defined the level of access,
        and who can access the extractor, the extractor_id attribute
        denotes the extractor to be shared.

        In case of un-sharing, the SharePermission's user is sufficient.

        Args:
            extractor_id:
                ID of the extractor to un-share.
            permission:
                Defines the user for which extractor access is revoked.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.unshare_extractor(
                        extractor_id=extractor_id,
                        username=permission.username,
                        _headers=header,
                    )
                )
            )
        return result

    def reset_and_share_extractor(
        self, extractor_id: str, new_usernames: List[str]
    ) -> ShareResponseStatus:
        """Remove all users who have access to an extractor (except for the owner) and share it with the provided list of new users.

        Args:
            extractor_id:
                ID of the extractor to un-share.
            new_usernames:
                The list of usernames belonging to the users this extractor will be shared with.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.reset_and_share_extractor(
                        extractor_id=extractor_id,
                        reset_and_share_request=rest.ResetAndShareRequest(
                            usernames=new_usernames,
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_extractor_for_all(self, extractor_id: str) -> ShareResponseStatus:
        """Remove sharing of an extractor to all other users but the original owner.

        Args:
            extractor_id:
                ID of the extractor to un-share.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.unshare_extractor_for_all(
                        extractor_id=extractor_id,
                        _headers=header,
                    )
                )
            )
        return result

    def share_extractor_with_group(
        self, extractor_id: str, permission: GroupSharePermission
    ) -> ShareResponseStatus:
        """Share an extractor to a group.

        The permission attribute defines which group can access the extractor,
        the extractor_id attribute denotes the extractor to be shared.

        Args:
            extractor_id:
                ID of the extractor to share.
            permission:
                Defines the group for sharing with.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.share_extractor_with_group(
                        extractor_id=extractor_id,
                        group_id=permission.group_id,
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_extractor_from_group(
        self, extractor_id: str, permission: GroupSharePermission
    ) -> ShareResponseStatus:
        """Remove sharing of an extractor from a group.

        The permission attribute defines which group to remove access from,
        the extractor_id attribute denotes the extractor to be unshared.


        Args:
            extractor_id:
                ID of the extractor to un-share.
            permission:
                Defines the group for which extractor access is revoked.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.unshare_extractor_from_group(
                        extractor_id=extractor_id,
                        group_id=permission.group_id,
                        _headers=header,
                    )
                )
            )
        return result

    def reset_and_share_extractor_with_groups(
        self, extractor_id: str, new_groups: List[str]
    ) -> ShareResponseStatus:
        """Remove all groups who have access to an extractor and share it with the provided list of new group ids.

        Args:
            extractor_id:
                ID of the extractor to un-share.
            new_groups:
                The list of group ids this extractor will be shared with.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.extractor_api.reset_and_share_extractor_with_groups(
                        extractor_id=extractor_id,
                        reset_and_share_with_groups_request=rest.ResetAndShareWithGroupsRequest(
                            groups=new_groups,
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def make_extractor_public(self, extractor_id: str):
        """Make an extractor public

        Once an extractor is public, it can be seen and used by all users.

        Args:
            extractor_id:
                ID of the extractor to make public.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.update_extractor_privacy(
                    extractor_id=extractor_id,
                    update_extractor_privacy_request=rest.UpdateExtractorPrivacyRequest(
                        is_public=True
                    ),
                    _headers=header,
                )
            )

    def make_extractor_private(self, extractor_id: str):
        """Make an extractor private

        Once a extractor is private, other users will no longer
        be able to see or use it unless it has been shared individually or by group.

        Args:
            extractore_id:
                ID of the extractor to make private.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.extractor_api.update_extractor_privacy(
                    extractor_id=extractor_id,
                    update_extractor_privacy_request=rest.UpdateExtractorPrivacyRequest(
                        is_public=False
                    ),
                    _headers=header,
                )
            )

    def list_recent_documents(
        self, offset: int, limit: int, metadata_filter: dict = {}
    ) -> List[DocumentInfo]:
        """Fetch user's document metadata sorted by last update time.

        All documents owned by the user, regardless of collection, are accessed.

        Args:
            offset:
                How many documents to skip before returning.
            limit:
                How many documents to return.
            metadata_filter:
                Metadata filter to apply to the documents.

        Returns:
            list of DocumentInfo: Metadata about each document.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            metadata_filter_json = None
            if metadata_filter and len(metadata_filter) > 0:
                metadata_filter_json = json.dumps(metadata_filter)
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_documents(
                    offset=offset,
                    limit=limit,
                    metadata_filter=metadata_filter_json,
                    _headers=header,
                )
            )

        dicts = [document.to_dict() for document in response]
        for d in dicts:
            unmarshal_dict(d)

        return [DocumentInfo(**d) for d in dicts]

    def list_recent_documents_with_summaries(
        self, offset: int, limit: int
    ) -> List[DocumentInfoSummary]:
        """Fetch user's document metadata sorted by last update time, including the latest document summary.

        All documents owned by the user, regardless of collection, are accessed.

        Args:
            offset:
                How many documents to skip before returning.
            limit:
                How many documents to return.

        Returns:
            list of DocumentInfoSummary: Metadata about each document.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_documents(
                    offset=offset, limit=limit, with_summaries=True, _headers=header
                )
            )

        dicts = [document.to_dict() for document in response]
        for d in dicts:
            unmarshal_dict(d)

        return [DocumentInfoSummary(**d) for d in dicts]

    def list_recent_documents_with_summaries_sort(
        self, offset: int, limit: int, sort_column: str, ascending: bool
    ) -> List[DocumentInfoSummary]:
        """Fetch user's document metadata sorted by last update time, including the latest document summary.

        All documents owned by the user, regardless of collection, are accessed.

        Args:
            offset:
                How many documents to skip before returning.
            limit:
                How many documents to return.
            sort_column:
                Sort column.
            ascending:
                When True, return sorted by sort_column in ascending order.

        Returns:
            list of DocumentInfoSummary: Metadata about each document.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_documents(
                    offset=offset,
                    limit=limit,
                    with_summaries=True,
                    sort_column=sort_column,
                    ascending=ascending,
                    _headers=header,
                )
            )

        dicts = [document.to_dict() for document in response]
        for d in dicts:
            unmarshal_dict(d)

        return [DocumentInfoSummary(**d) for d in dicts]

    def match_chunks(
        self,
        collection_id: str,
        vectors: List[List[float]],
        topics: List[str],
        offset: int,
        limit: int,
        cut_off: float = 0,
        width: int = 0,
    ) -> List[SearchResult]:
        """Find chunks related to a message using semantic search.

        Chunks are sorted by relevance and similarity score to the message.

        See Also: H2OGPTE.encode_for_retrieval to create vectors from messages.

        Args:
            collection_id:
                ID of the collection to search within.
            vectors:
                A list of vectorized message for running semantic search.
            topics:
                A list of document_ids used to filter which documents in the collection to search.
            offset:
                How many chunks to skip before returning chunks.
            limit:
                How many chunks to return.
            cut_off:
                Exclude matches with distances higher than this cut off.
            width:
                How many chunks before and after a match to return - not implemented.

        Returns:
            list of SearchResult: The document, text, score and related information of
            the chunk.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.match_collection_chunks(
                    collection_id=collection_id,
                    match_collection_chunks_request=rest.MatchCollectionChunksRequest(
                        vectors=vectors,
                        topics=topics,
                        offset=offset,
                        limit=limit,
                        cut_off=cut_off,
                    ),
                    _headers=header,
                )
            )
        return [SearchResult(**c.to_dict()) for c in response]

    def search_chunks(
        self, collection_id: str, query: str, topics: List[str], offset: int, limit: int
    ) -> List[SearchResult]:
        """Find chunks related to a message using lexical search.

        Chunks are sorted by relevance and similarity score to the message.

        Args:
            collection_id:
                ID of the collection to search within.
            query:
                Question or imperative from the end user to search a collection for.
            topics:
                A list of document_ids used to filter which documents in the collection to search.
            offset:
                How many chunks to skip before returning chunks.
            limit:
                How many chunks to return.

        Returns:
            list of SearchResult: The document, text, score and related information of the chunk.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.search_collection_chunks(
                    collection_id=collection_id,
                    search_collection_chunks_request=rest.SearchCollectionChunksRequest(
                        query=query,
                        topics=topics,
                        offset=offset,
                        limit=limit,
                    ),
                    _headers=header,
                )
            )
        return [SearchResult(**c.to_dict()) for c in response]

    def list_document_chunks(
        self, document_id: str, collection_id: Optional[str] = None
    ) -> List[SearchResult]:
        """Returns all chunks for a specific document.

        Args:
            document_id:
                ID of the document.
            collection_id:
                ID of the collection the document belongs to. If not specified, an arbitrary collections containing
                the document is chosen.
        Returns:
            list of SearchResult: The document, text, score and related information of the chunk.
        """
        if collection_id is None:
            collections = self.list_collections_for_document(document_id, 0, 1)
            if len(collections) == 0:
                raise ValueError(
                    "The specified document is not associated with any collection."
                )
            collection_id = collections[0].id

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.list_document_chunks(
                    collection_id=collection_id,
                    document_id=document_id,
                    _headers=header,
                )
            )
        return [SearchResult(**c.to_dict()) for c in response]

    def set_chat_message_votes(self, chat_message_id: str, votes: int) -> Result:
        """Change the vote value of a chat message.

        Set the exact value of a vote for a chat message. Any message type can
        be updated, but only LLM response votes will be visible in the UI.
        The expectation is 0: unvoted, -1: dislike, 1 like. Values outside of this will
        not be viewable in the UI.

        Args:
            chat_message_id:
                ID of a chat message, any message can be used but only
                LLM responses will be visible in the UI.
            votes:
                Integer value for the message. Only -1 and 1 will be visible in the
                UI as dislike and like respectively.

        Returns:
            Result: The status of the update.

        Raises:
            Exception: The upload request was unsuccessful.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.set_message_votes(
                        message_id=chat_message_id,
                        message_vote_update_request=rest.MessageVoteUpdateRequest(
                            votes=votes
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def update_collection(self, collection_id: str, name: str, description: str) -> str:
        """Update the metadata for a given collection.

        All variables are required. You can use `h2ogpte.get_collection(<id>).name` or
        description to get the existing values if you only want to change one or the other.

        Args:
            collection_id:
                ID of the collection to update.
            name:
                New name of the collection, this is required.
            description:
                New description of the collection, this is required.

        Returns:
            str: ID of the updated collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            collection = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection(
                    collection_id=collection_id,
                    collection_update_request=rest.CollectionUpdateRequest(
                        name=name, description=description
                    ),
                    _headers=header,
                )
            )
        return collection.id

    def update_collection_rag_type(
        self, collection_id: str, name: str, description: str, rag_type
    ) -> str:
        """Update the metadata for a given collection.

        All variables are required. You can use `h2ogpte.get_collection(<id>).name` or
        description to get the existing values if you only want to change one or the other.

        Args:
            collection_id:
                ID of the collection to update.
            name:
                New name of the collection, this is required.
            description:
                New description of the collection, this is required.
            rag_type: str one of
                    :code:`"auto"` Automatically select the best rag_type.
                    :code:`"llm_only"` LLM Only - Answer the query without any supporting document contexts.
                        Requires 1 LLM or Agent call.
                    :code:`"agent_only"` Agent Only - Answer the query with only original files passed to agent.
                        Requires 1 Agent call.
                    :code:`"agentic_rag"` Agentic RAG - Agent with RAG tool that retrieves and answers from collection.
                        Requires 1 Agent call with RAG tool execution.
                    :code:`"rlm_rag"` RLM RAG - Agent programmatically analyzes documents using Python code
                        execution and sub-LLM calls. Best for complex multi-hop reasoning over large documents.
                        Requires 1 Agent call.
                    :code:`"rag"` RAG (Retrieval Augmented Generation) - Use supporting document contexts
                        to answer the query. Requires 1 LLM or Agent call.
                    :code:`"hyde1"` LLM Only + RAG composite - HyDE RAG (Hypothetical Document Embedding).
                        Use 'LLM Only' response to find relevant contexts from a collection for generating
                        a response. Requires 2 LLM calls.
                    :code:`"hyde2"` HyDE + RAG composite - Use the 'HyDE RAG' response to find relevant
                        contexts from a collection for generating a response. Requires 3 LLM calls.
                    :code:`"rag+"` Summary RAG - Like RAG, but uses more context and recursive
                        summarization to overcome LLM context limits. Keeps all retrieved chunks, puts
                        them in order, adds neighboring chunks, then uses the summary API to get the
                        answer. Can require several LLM calls.
                    :code:`"all_data"` All Data RAG - Like Summary RAG, but includes all document
                        chunks. Uses recursive summarization to overcome LLM context limits.
                        Can require several LLM calls.

        Returns:
            str: ID of the updated collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            collection = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection(
                    collection_id=collection_id,
                    collection_update_request=rest.CollectionUpdateRequest(
                        name=name, description=description, rag_type=rag_type
                    ),
                    _headers=header,
                )
            )
        return collection.id

    def reset_collection_prompt_settings(self, collection_id: str) -> str:
        """Reset the prompt settings for a given collection.

        Args:
            collection_id:
                ID of the collection to update.

        Returns:
            str: ID of the updated collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.reset_collection_prompt_settings(
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return collection_id

    def update_collection_settings(
        self, collection_id: str, collection_settings: dict
    ) -> str:
        """
        Set the new collection settings, must be complete.
        Be careful not to delete any settings you want to keep.

        Args:
            collection_id:
                ID of the collection to update.
            collection_settings:
                Dictionary containing the new collection settings.

        Returns:
            str: ID of the updated collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_settings(
                    collection_id=collection_id,
                    collection_settings=rest.CollectionSettings.from_dict(
                        collection_settings
                    ),
                    _headers=header,
                )
            )
        return collection_id

    def update_collection_metadata(
        self, collection_id: str, collection_metadata: dict
    ) -> str:
        """
        Set the new collection metadata overwriting the existing metadata.
        Be careful not to delete any settings you want to keep.

        Args:
            collection_id:
                ID of the collection to update.
            collection_metadata:
                Dictionary containing the new collection metadata.

        Returns:
            str: ID of the updated collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_metadata(
                    collection_id=collection_id,
                    request_body=collection_metadata,
                    _headers=header,
                )
            )
        return collection_id

    def update_collection_workspace(self, collection_id: str, workspace: str) -> str:
        """Update the workspace associated with a collection.

        Args:
            collection_id:
                ID of the collection to update.
            workspace:
                The workspace associated with the collection.
        """

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.collection_api.update_collection_workspace(
                    collection_id=collection_id,
                    update_collection_workspace_request=rest.UpdateCollectionWorkspaceRequest(
                        workspace=workspace
                    ),
                    _headers=header,
                )
            )
        return collection_id

    def update_document_name(self, document_id: str, name: str) -> str:
        """Update the name metadata for a given document.

        Args:
            document_id:
                ID of the document to update.
            name:
                New name of the document, must include file extension.

        Returns:
            str: ID of the updated document.
        """
        if not name.strip():
            raise ValueError("The new name of the document cannot be empty.")

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            document = _rest_to_client_exceptions(
                lambda: rest_client.document_api.update_document(
                    document_id=document_id,
                    document_update_request=rest.DocumentUpdateRequest(
                        name=name.strip()
                    ),
                    _headers=header,
                )
            )
        return document.id

    def update_document_metadata(
        self, document_id: str, document_metadata: dict
    ) -> str:
        """
        Set the new document metadata overwriting the existing metadata.
        Be careful not to delete any settings you want to keep.

        Args:
            document_id:
                ID of the document to update.
            document_metadata:
                Dictionary containing the new document metadata.

        Returns:
            str: ID of the updated document.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.document_api.update_document_metadata(
                    document_id=document_id,
                    request_body=document_metadata,
                    _headers=header,
                )
            )
        return document_id

    def update_document_uri(self, document_id: str, uri: str) -> str:
        """Update the URI metadata for a given document.

        Args:
            document_id:
                ID of the document to update.
            uri:
                New URI of the document, this is required.

        Returns:
            str: ID of the updated document.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            document = _rest_to_client_exceptions(
                lambda: rest_client.document_api.update_document(
                    document_id=document_id,
                    document_update_request=rest.DocumentUpdateRequest(uri=uri.strip()),
                    _headers=header,
                )
            )
        return document.id

    def upload(self, file_name: str, file: Any, uri: Optional[str] = None) -> str:
        """Upload a file to the H2OGPTE backend.

        Uploaded files are not yet accessible and need to be ingested into a collection.

        See Also:
            ingest_uploads: Add the uploaded files to a collection.
            delete_upload: Delete uploaded file

        Args:
            file_name:
                What to name the file on the server, must include file extension.
            file:
                File object to upload, often an opened file from `with open(...) as f`.
            uri:
                Optional - URI you would like to associate with the file.

        Returns:
            str: The upload id to be used in ingest jobs.

        Raises:
            Exception: The upload request was unsuccessful.
        """
        mtime = ""
        try:
            mtime = str(
                int(Path(file.name).stat().st_mtime) * 1000
            )  # millis since Epoch
        except:
            pass

        if isinstance(file, io.StringIO) or isinstance(file, io.TextIOBase):
            file = io.BytesIO(file.read().encode("utf8"))

        files_data = {
            "file": (file_name, file),
            "mtime": (None, mtime),
            "uri": (None, uri or ""),
        }

        res = self._put("/rpc/fs", files=files_data)
        self._raise_error_if_any(res)
        return _to_id(json.loads(res.text))

    def list_upload(self) -> List[str]:
        """List pending file uploads to the H2OGPTE backend.

        Uploaded files are not yet accessible and need to be ingested into a collection.

        See Also:
            upload: Upload the files into the system to then be ingested into a collection.
            ingest_uploads: Add the uploaded files to a collection.
            delete_upload: Delete uploaded file

        Returns:
            List[str]: The pending upload ids to be used in ingest jobs.

        Raises:
            Exception: The upload list request was unsuccessful.
        """
        res = self._get("/rpc/fs")
        self._raise_error_if_any(res)
        return json.loads(res.text)

    def delete_upload(self, upload_id: str) -> str:
        """Delete a file previously uploaded with the "upload" method.

        See Also:
            upload: Upload the files into the system to then be ingested into a collection.
            ingest_uploads: Add the uploaded files to a collection.

        Args:
            upload_id:
                ID of a file to remove

        Returns:
            upload_id: The upload id of the removed.

        Raises:
            Exception: The delete upload request was unsuccessful.
        """
        res = self._delete(f"/rpc/fs?id={upload_id}")
        return _to_id(res)

    def get_llms(self) -> List[Dict[str, Any]]:
        """Lists metadata information about available LLMs in the environment.

        Returns:
            list of dict (string, ANY): Name and details about each available model.

        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            models = _rest_to_client_exceptions(
                lambda: rest_client.model_api.list_models(_headers=header)
            )
        return [m.to_dict() for m in models]

    def get_llm_names(self) -> List[str]:
        """Lists names of available LLMs in the environment.

        Returns:
            list of string: Name of each available model.

        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            models = _rest_to_client_exceptions(
                lambda: rest_client.model_api.list_models(_headers=header)
            )
        return [m.display_name for m in models]

    def get_vision_capable_llm_names(self) -> List[str]:
        """Lists names of available vision-capable multi-modal LLMs (that can natively handle images as input) in the environment.

        Returns:
            list of string: Name of each available model.

        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_vision_capable_model_names(
                    _headers=header
                )
            )
        return response

    def get_llm_and_auto_vision_llm_names(self) -> Dict[str, str]:
        """
        Get mapping of llm to its vision_model when ["auto"] is passed as visible_vision_models

        Returns:
            dictionary {'llm1': 'llm1_vision_llm', etc.}
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_model_to_vision_model_mapping(
                    _headers=header
                )
            )
        return response

    def get_reasoning_capable_llm_names(self) -> List[str]:
        """Lists names of available reasoning-capable (that can natively reason) in the environment.

        Returns:
            list of string: Name of each available model.

        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_reasoning_capable_model_names(
                    _headers=header
                )
            )
        return response

    def get_llm_and_auto_reasoning_llm_names(self) -> Dict[str, str]:
        """
        Get mapping of llm to its reasoning_model when ["auto"] is passed as visible_reasoning_models

        Returns:
            dictionary {'llm1': 'llm1_reasoning_llm', etc.}
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.model_api.get_model_to_reasoning_model_mapping(
                    _headers=header
                )
            )
        return response

    def download_document(
        self,
        destination_directory: Union[str, Path],
        destination_file_name: str,
        document_id: str,
    ) -> Path:
        """Downloads a document to a local system directory.

        Args:
            destination_directory:
                Destination directory to save file into.
            destination_file_name:
                Destination file name.
            document_id:
                Document ID.

        Returns:
            Path: Path of downloaded document
        """
        destination_directory = Path(destination_directory)
        destination_file = destination_directory / destination_file_name
        if not destination_directory.is_dir():
            raise FileNotFoundError("Destination directory does not exist")
        if destination_file.exists():
            raise FileExistsError(f"File {destination_file} already exists")

        res = self._get(
            f"/file?id={document_id}&name={quote(destination_file_name)}", as_json=False
        )
        self._raise_error_if_any(res)

        with open(destination_file, "wb") as f:
            f.write(res.content)
        return destination_file

    def get_document_content(self, file_name: str, document_id: str) -> bytes:
        """Downloads a document and return its content as a byte array.

        Args:
            file_name:
                File name.
            document_id:
                Document ID.

        Returns:
            Path: File content

        """
        res = self._get(
            f"/file?id={document_id}&name={quote(file_name)}", as_json=False
        )
        self._raise_error_if_any(res)

        return res.content

    def list_recent_prompt_templates(
        self, offset: int, limit: int
    ) -> List[PromptTemplate]:
        """Fetch user's prompt templates sorted by last update time.

        Args:
            offset:
                How many prompt templates to skip before returning.
            limit:
                How many prompt templates to return.

        Returns:
            list of PromptTemplate: set of prompts
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.list_prompt_templates(
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )
        return [PromptTemplate(**d.to_dict()) for d in response]

    def list_recent_prompt_templates_sort(
        self,
        offset: int,
        limit: int,
        sort_column: str,
        ascending: bool,
        template_type: str = "all",
        filter: str = "",
    ) -> List[PromptTemplate]:
        """Fetch user's prompt templates sorted by last update time.

        Args:
            offset:
                How many prompt templates to skip before returning.
            limit:
                How many prompt templates to return.
            sort_column:
                Sort column.
            ascending:
                When True, return sorted by sort_column in ascending order.
            template_type:
                When set, will be used as a type filter, possible values are: all, user, system.
            filter:
                When set, will be used as a filter on some prompt template columns.

        Returns:
            list of PromptTemplate: set of prompts
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.list_prompt_templates(
                    offset=offset,
                    limit=limit,
                    sort_column=sort_column,
                    ascending=ascending,
                    template_type=template_type,
                    filter=filter,
                    _headers=header,
                )
            )
        return [PromptTemplate(**d.to_dict()) for d in response]

    def list_all_recent_prompt_templates(
        self, offset: int, limit: int
    ) -> List[PromptTemplate]:
        """Fetch user's prompt templates sorted by last update time.

        Note: Users with permission to manage prompt templates can use this to list hidden default prompt templates.

        Args:
            offset:
                How many prompt templates to skip before returning.
            limit:
                How many prompt templates to return.

        Returns:
            list of PromptTemplate: set of prompts
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.list_all_prompt_templates(
                    offset=offset,
                    limit=limit,
                    _headers=header,
                )
            )
        return [PromptTemplate(**d.to_dict()) for d in response]

    def list_all_recent_prompt_templates_sort(
        self,
        offset: int,
        limit: int,
        sort_column: str,
        ascending: bool,
        template_type: str = "all",
        filter: str = "",
    ) -> List[PromptTemplate]:
        """Fetch user's prompt templates sorted by last update time.

        Note: Users with permission to manage prompt templates can use this to list hidden default prompt templates.

        Args:
            offset:
                How many prompt templates to skip before returning.
            limit:
                How many prompt templates to return.
            sort_column:
                Sort column.
            ascending:
                When True, return sorted by sort_column in ascending order.
            template_type:
                When set, will be used as a type filter, possible values are: all, user, system.
            filter:
                When set, will be used as a filter on some prompt template columns.

        Returns:
            list of PromptTemplate: set of prompts
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.list_all_prompt_templates(
                    offset=offset,
                    limit=limit,
                    sort_column=sort_column,
                    ascending=ascending,
                    template_type=template_type,
                    filter=filter,
                    _headers=header,
                )
            )
        return [PromptTemplate(**d.to_dict()) for d in response]

    def get_prompt_template(self, id: Optional[str] = None) -> PromptTemplate:
        """Get a prompt template

        Args:
            id:
                String id of the prompt template to retrieve or None for default

        Returns:
            PromptTemplate: prompts

        Raises:
            KeyError: The prompt template was not found.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if id is None:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.get_default_prompt_template(
                        _headers=header
                    )
                )
            else:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.get_prompt_template(
                        prompt_template_id=id, _headers=header
                    )
                )
        return PromptTemplate(**response.to_dict())

    def delete_prompt_templates(self, ids: Iterable[str]) -> Result:
        """Deletes prompt templates

        Args:
            ids:
                List of string ids of prompte templates to delete from the system.

        Returns:
            Result: Status of the delete job.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.delete_prompt_template(
                        prompt_template_id=ids, _headers=header
                    )
                )
            )
        return result

    def update_prompt_template(
        self,
        id: str,
        name: str,
        description: Union[str, None] = None,
        lang: Union[str, None] = None,
        system_prompt: Union[str, None] = None,
        pre_prompt_query: Union[str, None] = None,
        prompt_query: Union[str, None] = None,
        hyde_no_rag_llm_prompt_extension: Union[str, None] = None,
        pre_prompt_summary: Union[str, None] = None,
        prompt_summary: Union[str, None] = None,
        system_prompt_reflection: Union[str, None] = None,
        pre_prompt_reflection: Union[str, None] = None,
        prompt_reflection: Union[str, None] = None,
        auto_gen_description_prompt: Union[str, None] = None,
        auto_gen_document_summary_pre_prompt_summary: Union[str, None] = None,
        auto_gen_document_summary_prompt_summary: Union[str, None] = None,
        auto_gen_document_sample_questions_prompt: Union[str, None] = None,
        default_sample_questions: Union[List[str], None] = None,
        image_batch_image_prompt: Union[str, None] = None,
        image_batch_final_prompt: Union[str, None] = None,
    ) -> str:
        """
        Update a prompt template

        Args:
            id:
                String ID of the prompt template to update
            name:
                Name of the prompt template
            description:
                Description of the prompt template
            lang:
                Language code
            system_prompt:
                System Prompt
            pre_prompt_query:
                Text that is prepended before the contextual document chunks.
            prompt_query:
                Text that is appended to the beginning of the user's message.
            hyde_no_rag_llm_prompt_extension:
                LLM prompt extension.
            pre_prompt_summary:
                Prompt that goes before each large piece of text to summarize
            prompt_summary:
                Prompt that goes after each large piece of text to summarize
            system_prompt_reflection:
                System Prompt for self-reflection
            pre_prompt_reflection:
                Deprecated - ignored
            prompt_reflection:
                Template for self-reflection, must contain two occurrences of %s for full previous prompt (including system prompt, document related context and prompts if applicable, and user prompts) and answer
            auto_gen_description_prompt:
                prompt to create a description of the collection.
            auto_gen_document_summary_pre_prompt_summary:
                pre_prompt_summary for summary of a freshly imported document (if enabled).
            auto_gen_document_summary_prompt_summary:
                prompt_summary for summary of a freshly imported document (if enabled).
            auto_gen_document_sample_questions_prompt:
                prompt to create sample questions for a freshly imported document (if enabled).
            default_sample_questions:
                default sample questions in case there are no auto-generated sample questions.
            image_batch_final_prompt:
                Prompt for each image batch for vision models
            image_batch_image_prompt:
                Prompt to reduce all answers each image batch for vision models

        Returns:
            str: The ID of the updated prompt template.
        """
        if prompt_reflection is not None:
            assert prompt_reflection.count("%s") == 2, (
                "prompt reflection must contain exactly two occurrences of %s "
                "(one for the full previous prompt including system prompt, document related context and prompts if applicable, and user prompts and one for the response)"
            )
        if pre_prompt_reflection:
            raise DeprecationWarning(
                "pre_prompt_reflection is no longer used, can be added to the beginning of prompt_reflection."
            )

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.update_prompt_template(
                    prompt_template_id=id,
                    body=rest.PromptTemplateBase(
                        name=name,
                        description=description,
                        lang=lang,
                        system_prompt=system_prompt,
                        pre_prompt_query=pre_prompt_query,
                        prompt_query=prompt_query,
                        hyde_no_rag_llm_prompt_extension=hyde_no_rag_llm_prompt_extension,
                        pre_prompt_summary=pre_prompt_summary,
                        prompt_summary=prompt_summary,
                        system_prompt_reflection=system_prompt_reflection,
                        prompt_reflection=prompt_reflection,
                        auto_gen_description_prompt=auto_gen_description_prompt,
                        auto_gen_document_summary_pre_prompt_summary=auto_gen_document_summary_pre_prompt_summary,
                        auto_gen_document_summary_prompt_summary=auto_gen_document_summary_prompt_summary,
                        auto_gen_document_sample_questions_prompt=auto_gen_document_sample_questions_prompt,
                        default_sample_questions=default_sample_questions,
                        image_batch_image_prompt=image_batch_image_prompt,
                        image_batch_final_prompt=image_batch_final_prompt,
                    ),
                    _headers=header,
                )
            )

        return response.id

    def create_prompt_template(
        self,
        name: str,
        description: Union[str, None] = None,
        lang: Union[str, None] = None,
        system_prompt: Union[str, None] = None,
        pre_prompt_query: Union[str, None] = None,
        prompt_query: Union[str, None] = None,
        hyde_no_rag_llm_prompt_extension: Union[str, None] = None,
        pre_prompt_summary: Union[str, None] = None,
        prompt_summary: Union[str, None] = None,
        system_prompt_reflection: Union[str, None] = None,
        pre_prompt_reflection: Union[str, None] = None,
        prompt_reflection: Union[str, None] = None,
        auto_gen_description_prompt: Union[str, None] = None,
        auto_gen_document_summary_pre_prompt_summary: Union[str, None] = None,
        auto_gen_document_summary_prompt_summary: Union[str, None] = None,
        auto_gen_document_sample_questions_prompt: Union[str, None] = None,
        default_sample_questions: Union[List[str], None] = None,
        image_batch_image_prompt: Union[str, None] = None,
        image_batch_final_prompt: Union[str, None] = None,
    ) -> str:
        """
        Create a new prompt template

        Args:
            name:
                Name of the prompt template
            description:
                Description of the prompt template
            lang:
                Language code
            system_prompt:
                System Prompt
            pre_prompt_query:
                Text that is prepended before the contextual document chunks.
            prompt_query:
                Text that is appended to the beginning of the user's message.
            hyde_no_rag_llm_prompt_extension:
                LLM prompt extension.
            pre_prompt_summary:
                Prompt that goes before each large piece of text to summarize
            prompt_summary:
                Prompt that goes after each large piece of text to summarize
            system_prompt_reflection:
                System Prompt for self-reflection
            pre_prompt_reflection:
                Deprecated - ignored
            prompt_reflection:
                Template for self-reflection, must contain two occurrences of %s for full previous prompt (including system prompt, document related context and prompts if applicable, and user prompts) and answer
            auto_gen_description_prompt:
                prompt to create a description of the collection.
            auto_gen_document_summary_pre_prompt_summary:
                pre_prompt_summary for summary of a freshly imported document (if enabled).
            auto_gen_document_summary_prompt_summary:
                prompt_summary for summary of a freshly imported document (if enabled).
            auto_gen_document_sample_questions_prompt:
                prompt to create sample questions for a freshly imported document (if enabled).
            default_sample_questions:
                default sample questions in case there are no auto-generated sample questions.
            image_batch_final_prompt:
                Prompt for each image batch for vision models
            image_batch_image_prompt:
                Prompt to reduce all answers each image batch for vision models

        Returns:
            str: The ID of the newly created prompt template.
        """
        if prompt_reflection is not None:
            assert prompt_reflection.count("%s") == 2, (
                "prompt reflection must contain exactly two occurrences of %s "
                "(one for the full previous prompt including system prompt, document related context and prompts if applicable, and user prompts and one for the response)"
            )
        if pre_prompt_reflection:
            raise DeprecationWarning(
                "pre_prompt_reflection is no longer used, can be added to the beginning of prompt_reflection."
            )

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.create_prompt_template(
                    prompt_template_create_request=rest.PromptTemplateCreateRequest(
                        name=name,
                        description=description,
                        lang=lang,
                        system_prompt=system_prompt,
                        pre_prompt_query=pre_prompt_query,
                        prompt_query=prompt_query,
                        hyde_no_rag_llm_prompt_extension=hyde_no_rag_llm_prompt_extension,
                        pre_prompt_summary=pre_prompt_summary,
                        prompt_summary=prompt_summary,
                        system_prompt_reflection=system_prompt_reflection,
                        prompt_reflection=prompt_reflection,
                        auto_gen_description_prompt=auto_gen_description_prompt,
                        auto_gen_document_summary_pre_prompt_summary=auto_gen_document_summary_pre_prompt_summary,
                        auto_gen_document_summary_prompt_summary=auto_gen_document_summary_prompt_summary,
                        auto_gen_document_sample_questions_prompt=auto_gen_document_sample_questions_prompt,
                        default_sample_questions=default_sample_questions,
                        image_batch_image_prompt=image_batch_image_prompt,
                        image_batch_final_prompt=image_batch_final_prompt,
                    ),
                    _headers=header,
                )
            )
        return response.id

    def count_prompt_templates(self) -> int:
        """Counts number of prompt templates

        Returns:
            int: The count of prompt templates
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.get_prompt_template_count(
                    _headers=header
                )
            )
        return response.count

    def share_prompt(
        self, prompt_id: str, permission: SharePermission
    ) -> ShareResponseStatus:
        """Share a prompt template to a user.

        Args:
            prompt_id:
                ID of the prompt template to share.
            permission:
                Defines the rule for sharing, i.e. permission level.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.share_prompt_template(
                        prompt_template_id=prompt_id,
                        username=permission.username,
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_prompt(
        self, prompt_id: str, permission: SharePermission
    ) -> ShareResponseStatus:
        """Remove sharing of a prompt template to a user.

        Args:
            prompt_id:
                ID of the prompt template to un-share.
            permission:
                Defines the user for which collection access is revoked.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.unshare_prompt_template(
                        prompt_template_id=prompt_id,
                        username=permission.username,
                        _headers=header,
                    )
                )
            )
        return result

    def share_prompt_with_group(
        self, prompt_id: str, permission: GroupSharePermission
    ) -> ShareResponseStatus:
        """Share a prompt to a group.

        Args:
            prompt_id:
                ID of the prompt to share.
            permission:
                Specific permissions for a group.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.share_prompt_template_with_group(
                        prompt_template_id=prompt_id,
                        group_id=permission.group_id,
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_prompt_from_group(
        self, prompt_id: str, permission: GroupSharePermission
    ) -> ShareResponseStatus:
        """Unshare a prompt from a group.

        Args:
            prompt_id:
                ID of the prompt to un-share.
            permission:
                Specific permissions for a group.

        Returns:
            ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.unshare_prompt_template_from_group(
                        prompt_template_id=prompt_id,
                        group_id=permission.group_id,
                        _headers=header,
                    )
                )
            )
        return result

    def reset_and_share_prompt_template_with_groups(
        self, prompt_id: str, new_groups: List[str]
    ) -> ShareResponseStatus:
        """Remove all groups who have access to a prompt template and share it with the provided list of new group ids.

        Args:
            prompt_id:
                ID of the prompt template to un-share.
            new_groups:
                The list of group ids this prompt template will be shared with.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.reset_and_share_prompt_template_with_groups(
                        prompt_template_id=prompt_id,
                        reset_and_share_with_groups_request=rest.ResetAndShareWithGroupsRequest(
                            groups=new_groups,
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def unshare_prompt_for_all(self, prompt_id: str) -> ShareResponseStatus:
        """Remove sharing of a prompt template to all other users but the original owner (owner action only).

        Args:
            prompt_id:
                ID of the prompt template to un-share.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.unshare_prompt_template_for_all(
                        prompt_template_id=prompt_id, _headers=header
                    )
                )
            )
        return result

    def reset_and_share_prompt_template(
        self, prompt_id: str, new_usernames: List[str]
    ) -> ShareResponseStatus:
        """Remove all users who have access to a prompt template (except for the owner) and share it with the provided list of new users.

        Args:
            prompt_id:
                ID of the prompt template to un-share.
            new_usernames:
                The list of usernames belonging to the users this prompt template will be shared with.

        ShareResponseStatus: Status of share request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_share_permission_status(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.prompt_template_api.reset_and_share_prompt_template(
                        prompt_template_id=prompt_id,
                        reset_and_share_request=rest.ResetAndShareRequest(
                            usernames=new_usernames,
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def make_prompt_template_public(self, prompt_template_id: str):
        """Make a prompt template public

        Once a prompt template is public, it can be seen and used by all users.

        Args:
            prompt_template_id:
                ID of the prompt template to make public.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.update_prompt_template_privacy(
                    prompt_template_id=prompt_template_id,
                    update_prompt_template_privacy_request=rest.UpdatePromptTemplatePrivacyRequest(
                        is_public=True
                    ),
                    _headers=header,
                )
            )

    def make_prompt_template_private(self, prompt_template_id: str):
        """Make a prompt template private

        Once a prompt template is private, other users will no longer
        be able to see or use it unless it has been shared individually or by group.

        Args:
            prompt_template_id:
                ID of the prompt template to make private.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.update_prompt_template_privacy(
                    prompt_template_id=prompt_template_id,
                    update_prompt_template_privacy_request=rest.UpdatePromptTemplatePrivacyRequest(
                        is_public=False
                    ),
                    _headers=header,
                )
            )

    def list_prompt_permissions(self, prompt_id: str) -> List[SharePermission]:
        """Returns a list of access permissions for a given prompt template.

        The returned list of permissions denotes who has access to
        the prompt template and their access level.

        Args:
            prompt_id:
                ID of the prompt template to inspect.

        Returns:
            list of SharePermission: Sharing permissions list for the given prompt template.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.get_prompt_template_permissions(
                    prompt_template_id=prompt_id, _headers=header
                )
            )
        return [SharePermission(**d.to_dict()) for d in response]

    def list_prompt_group_permissions(
        self, prompt_id: str
    ) -> List[GroupSharePermission]:
        """Returns a list of group access permissions for a given prompt template.

        The returned list of group permissions denoting which groups have access to
        the prompt template.

        Args:
            prompt_id:
                ID of the prompt template to inspect.

        Returns:
            list of GroupSharePermission: Group sharing permissions list for the given prompt template.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.get_prompt_template_group_permissions(
                    prompt_template_id=prompt_id, _headers=header
                )
            )
        return [GroupSharePermission(**d.to_dict()) for d in response]

    def set_default_prompt_template_visibility(self, prompt_id: str, is_visible: bool):
        """
        Updates a flag specifying whether a default prompt template is visible or hidden to users.

        Once you hide a default prompt template, users will no longer be able to use this prompt template.
        This will also affect collections and chats that have this as a default prompt template.
        Once you show a default prompt template, all users will be able to see and use this prompt template.

        Args:
            prompt_id:
                ID of the default prompt template you would like to change the visibility of.
            is_visible:
                Whether the default prompt template should be visible.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.prompt_template_api.update_default_prompt_template_visibility(
                    prompt_template_id=prompt_id,
                    update_default_prompt_template_visibility_request=rest.UpdateDefaultPromptTemplateVisibilityRequest(
                        is_visible=is_visible
                    ),
                    _headers=header,
                )
            )

    def set_collection_prompt_template(
        self,
        collection_id: str,
        prompt_template_id: Union[str, None],
        strict_check: bool = False,
    ) -> str:
        """Set the prompt template for a collection

        Args:
            collection_id:
                ID of the collection to update.
            prompt_template_id:
                ID of the prompt template to get the prompts from. None to delete and fall back to system defaults.
            strict_check:
                whether to check that the collection's embedding model and the prompt template are optimally compatible

        Returns:
            str: ID of the updated collection.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if prompt_template_id is None:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.delete_collection_prompt_template(
                        collection_id=collection_id, _headers=header
                    )
                )
            else:
                prompt_template = self.get_prompt_template(prompt_template_id)
                embedding_model = (self.get_collection(collection_id)).embedding_model
                if embedding_model:
                    all_embedding_models = _rest_to_client_exceptions(
                        lambda: rest_client.model_api.list_embedding_models(
                            _headers=header
                        )
                    )
                    relevant_embedding_models = [
                        m for m in all_embedding_models if m.id == embedding_model
                    ]
                    if len(relevant_embedding_models) > 0:
                        langs = relevant_embedding_models[0].languages
                        if (
                            langs
                            and prompt_template.lang
                            and prompt_template.lang not in langs
                        ):
                            msg = (
                                f"Warning: The embedding model only supports the following languages: {langs}, "
                                f"but the prompt template specifies the following language: {prompt_template.lang}. "
                                f"Retrieval performance may not be ideal."
                            )
                            print(msg)
                            if strict_check:
                                raise RuntimeError(msg)
                response = _rest_to_client_exceptions(
                    lambda: rest_client.collection_api.update_collection_prompt_template(
                        collection_id=collection_id,
                        prompt_template_change_request=rest.PromptTemplateChangeRequest(
                            prompt_template_id=prompt_template_id,
                        ),
                        _headers=header,
                    )
                )
        return response.id

    def get_collection_prompt_template(
        self, collection_id: str
    ) -> Union[PromptTemplate, None]:
        """Get the prompt template for a collection

        Args:
            collection_id:
                ID of the collection

        Returns:
            str: ID of the prompt template.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_collection = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.get_collection(
                    collection_id=collection_id, _headers=header
                )
            )
        if rest_collection.prompt_template_id is None:
            return None
        return self.get_prompt_template(rest_collection.prompt_template_id)

    def set_chat_session_prompt_template(
        self, chat_session_id: str, prompt_template_id: Union[str, None]
    ) -> str:
        """Set the prompt template for a chat_session

        Args:
            chat_session_id:
                ID of the chat session
            prompt_template_id:
                ID of the prompt template to get the prompts from. None to delete and fall back to system defaults.

        Returns:
            str: ID of the updated chat session
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if prompt_template_id is None:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.delete_chat_session_prompt_template(
                        session_id=chat_session_id,
                        _headers=header,
                    )
                )
            else:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.update_chat_session_prompt_template(
                        session_id=chat_session_id,
                        prompt_template_change_request=rest.PromptTemplateChangeRequest(
                            prompt_template_id=prompt_template_id,
                        ),
                        _headers=header,
                    )
                )
        return response.id

    def get_chat_session_prompt_template(
        self, chat_session_id: str
    ) -> Union[PromptTemplate, None]:
        """Get the prompt template for a chat_session

        Args:
            chat_session_id:
                ID of the chat session

        Returns:
            str: ID of the prompt template.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_session = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session(
                    session_id=chat_session_id,
                    _headers=header,
                )
            )

        if rest_session.prompt_template_id is None:
            return None

        return self.get_prompt_template(rest_session.prompt_template_id)

    def get_chat_session_workspace(self, chat_session_id: str) -> str:
        """Get the workspace associated with the chat session.

        Args:
            chat_session_id:
                String id of the chat session to search for.

        Returns:
            str: The identifier of the workspace
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session(
                    session_id=chat_session_id,
                    _headers=header,
                )
            )

        return response.workspace

    def set_chat_session_collection(
        self, chat_session_id: str, collection_id: Union[str, None]
    ) -> str:
        """Set the collection for a chat_session

        Args:
            chat_session_id:
                ID of the chat session
            collection_id:
                ID of the collection, or None to chat with the LLM only.

        Returns:
            str: ID of the updated chat session
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if collection_id is None:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.delete_chat_session_collection(
                        session_id=chat_session_id, _headers=header
                    )
                )
            else:
                response = _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.update_chat_session_collection(
                        session_id=chat_session_id,
                        collection_change_request=rest.CollectionChangeRequest(
                            collection_id=collection_id
                        ),
                        _headers=header,
                    )
                )
        return response.id

    def get_chat_session_guardrails(self, chat_session_id: str) -> str:
        """Get guardrails settings for a specific chat session.

        Args:
            chat_session_id:
                ID of the chat session

        Returns:
            str: JSON string containing guardrails settings or "null" if not set
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_chat_session_guardrails(
                    session_id=chat_session_id, _headers=header
                )
            )
        return _serialize_guardrails_response(response)

    def get_effective_guardrails(
        self, chat_session_id: Optional[str] = None, collection_id: Optional[str] = None
    ) -> str:
        """Get the effective guardrails settings based on the hierarchy.

        Args:
            chat_session_id:
                Optional chat session ID to check for chat-level settings
            collection_id:
                Optional collection ID to check for collection-level settings

        Returns:
            str: JSON string containing effective guardrails settings
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.guardrails_api.get_effective_guardrails(
                    chat_session_id=chat_session_id,
                    collection_id=collection_id,
                    _headers=header,
                )
            )
        return _serialize_guardrails_response(response, empty_value="{}")

    def migrate_chat_sessions_to_collection(
        self,
        source_collection_id: str,
        target_collection_id: str,
        timeout: Union[float, None] = None,
    ) -> Job:
        """Migrate chat sessions from one collection to another.

        This method creates a job to migrate chat sessions between collections.
        Only the collection owner can perform this operation.

        Args:
            source_collection_id:
                String ID of the source collection containing the chat sessions.
            target_collection_id:
                String ID of the target collection to migrate chat sessions to.
            timeout:
                Timeout in seconds.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.collection_api.create_migrate_collection_chat_sessions_job(
                    collection_id=source_collection_id,
                    migrate_collection_chat_sessions_job_request=rest.MigrateCollectionChatSessionsJobRequest(
                        target_collection_id=target_collection_id,
                    ),
                    timeout=timeout,
                    _headers=header,
                )
            )
        return self._wait_for_completion(response.id, timeout=timeout)

    def download_reference_highlighting(
        self,
        message_id: str,
        destination_directory: str,
        output_type: str = "combined",
        limit: Optional[int] = None,
    ) -> list:
        """Get PDFs with reference highlighting

        Args:
            message_id:
                ID of the message to get references from
            destination_directory:
                Destination directory to save files into.
            output_type: str one of
                :code:`"combined"` Generates a PDF file for each source document, with all relevant chunks highlighted
                in each respective file. This option consolidates all highlights for each source document into a single
                PDF, making it easy to view all highlights related to that document at once.
                :code:`"split"` Generates a separate PDF file for each chunk, with only the relevant chunk highlighted
                in each file. This option is useful for focusing on individual sections without interference from other
                parts of the text. The output files names will be in the format "{document_id}_{chunk_id}.pdf"
            limit:
                The number of references to consider based on the highest confidence scores.

        Returns:
            list[Path]: List of paths of downloaded documents with highlighting

        """
        if not os.path.exists(destination_directory) or not os.path.isdir(
            destination_directory
        ):
            raise FileNotFoundError("Destination directory does not exist")

        chat_references = self.list_chat_message_references(message_id, limit)
        doc_chat_references = defaultdict(list)
        for chat_ref in chat_references:
            doc_chat_references[(chat_ref.document_id, chat_ref.document_name)].append(
                chat_ref
            )

        files_list = []
        for (document_id, document_name), chat_refs in doc_chat_references.items():
            res = self._get(f"/file?id={document_id}&name={quote(document_name)}")
            if res.status_code != 200:
                print(
                    f"Warning: HTTP error: {res.status_code}. document_id={document_id}"
                )
                continue

            if not res.content:
                print(f"Warning: received an empty response. document_id={document_id}")
                continue

            pymupdf = import_pymupdf()
            pdf_document = pymupdf.open("pdf", res.content)
            markers = []

            for ref in chat_refs:
                markers.append(ref.model_dump_json())

            filepaths = _process_pdf_with_annotations(
                pdf_document, markers, destination_directory, document_id, output_type
            )
            files_list.extend(filepaths)

        return files_list

    def tag_document(self, document_id: str, tag_name: str) -> str:
        """Adds a tag to a document.

        Args:
            document_id:
                String id of the document to attach the tag to.
            tag_name:
                String representing the tag to attach.

        Returns:
            String: The id of the newly created tag.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.create_tag_on_document(
                    document_id=document_id,
                    tag_create_request=rest.TagCreateRequest(name=tag_name),
                    _headers=header,
                )
            )
        return response.id

    def untag_document(self, document_id: str, tag_name: str) -> str:
        """Removes an existing tag from a document.

        Args:
            document_id:
                String id of the document to remove the tag from.
            tag_name:
                String representing the tag to remove.

        Returns:
            String: The id of the removed tag.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.document_api.delete_tag_from_document(
                    document_id=document_id, tag_name=tag_name, _headers=header
                )
            )
        return response.tag_id

    def get_tag(self, tag_name: str) -> Tag:
        """Returns an existing tag.

        Args:
            tag_name:
                String The name of the tag to retrieve.

        Returns:
            Tag: The requested tag.

        Raises:
            KeyError: The tag was not found.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.tag_api.get_tag(tag_name=tag_name, _headers=header)
            )
        return Tag(**response.to_dict())

    def create_tag(self, tag_name: str) -> str:
        """Creates a new tag.

        Args:
            tag_name:
                String representing the tag to create.

        Returns:
            String: The id of the created tag.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.tag_api.create_tag(
                    tag_create_request=rest.TagCreateRequest(name=tag_name),
                    _headers=header,
                )
            )
        return response.id

    def update_tag(self, tag_name: str, description: str, format: str) -> str:
        """Updates a  tag.

        Args:
            tag_name:
                String representing the tag to update.
            description:
                String describing the tag.
            format:
                String representing the format of the tag.

        Returns:
            String: The id of the updated tag.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.tag_api.update_tag(
                    tag_name=tag_name,
                    tag_update_request=rest.TagUpdateRequest(
                        description=description, format=format
                    ),
                    _headers=header,
                )
            )
        return response.id

    def list_all_tags(self) -> List[Tag]:
        """Lists all existing tags.

        Returns:
            List of Tags: List of existing tags.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.tag_api.list_tags(_headers=header)
            )
        return [Tag(**d.to_dict()) for d in response]

    def list_documents_from_tags(
        self, collection_id: str, tags: List[str]
    ) -> List[Document]:
        """Lists documents that have the specified set of tags within a collection.
        Args:
            collection_id:
                String The id of the collection to find documents in.
            tags:
                List of Strings representing the tags to retrieve documents for.

        Returns:
            List of Documents: All the documents with the specified tags.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.tag_api.list_documents_for_tags(
                    collection_id=collection_id, tag_names=tags, _headers=header
                )
            )
        return [Document(**d.to_dict()) for d in response]

    def add_user_document_permission(
        self, user_id: str, document_id: str
    ) -> [str, str]:
        """Associates a user with a document they have permission on.
        Args:
            user_id:
                String The id of the user that has the permission.
            document_id:
                String The id of the document that the permission is for.

        Returns:
            [user_id, document_id]: A tuple containing the user_id and document_id.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.add_user_document_permission(
                    document_id=document_id,
                    user_id=user_id,
                    _headers=header,
                )
            )
        return [user_id, document_id]

    def list_system_permissions(self) -> List[UserPermission]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_permissions = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.list_permissions(_headers=header)
            )
        return [UserPermission(**p.to_dict()) for p in rest_permissions]

    def list_system_roles(self) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_roles = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.list_roles(_headers=header)
            )
        return [UserRole(**r.to_dict()) for r in rest_roles]

    def list_system_groups(self) -> List[UserGroup]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_groups = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.list_groups(_headers=header)
            )
        return [UserGroup(**r.to_dict()) for r in rest_groups]

    def list_user_roles(self, user_id: Optional[str] = None) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if user_id:
                rest_roles = _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.get_user_roles(
                        user_id=user_id, _headers=header
                    )
                )
            else:
                rest_roles = _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.get_current_user_roles(
                        _headers=header
                    )
                )
        return [UserRole(**r.to_dict()) for r in rest_roles]

    def list_group_roles(self, group_id: str) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_roles = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.get_group_roles(
                    group_id=group_id, _headers=header
                )
            )
        return [UserRole(**r.to_dict()) for r in rest_roles]

    def list_user_permissions(
        self, user_id: Optional[str] = None
    ) -> List[UserPermission]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            if user_id:
                rest_permissions = _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.get_user_permissions(
                        user_id=user_id, _headers=header
                    )
                )
            else:
                rest_permissions = _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.get_current_user_permissions(
                        _headers=header
                    )
                )
        return [UserPermission(**p.to_dict()) for p in rest_permissions]

    def list_group_permissions(self, group_id: str) -> List[UserPermission]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_permissions = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.get_group_permissions(
                    group_id=group_id, _headers=header
                )
            )
        return [UserPermission(**p.to_dict()) for p in rest_permissions]

    def list_group_permissions_by_name(
        self, group_names: List[str]
    ) -> List[UserPermission]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_permissions = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.list_permissions(
                    group_names=group_names, _headers=header
                )
            )
        return [UserPermission(**p.to_dict()) for p in rest_permissions]

    def list_user_role_permissions(self, roles: List[str]) -> List[UserPermission]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            rest_permissions = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.list_permissions(
                    role_names=roles, _headers=header
                )
            )
        return [UserPermission(**p.to_dict()) for p in rest_permissions]

    def add_role_to_user(self, user_id: str, roles: List[str]) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.assign_roles_to_user(
                    user_id=user_id, role_names=roles, _headers=header
                )
            )
        return self.list_user_roles(user_id=user_id)

    def reset_roles_for_user(self, user_id: str, roles: List[str]) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.reset_user_roles(
                    user_id=user_id,
                    roles_reset_request=rest.RolesResetRequest(new_roles=roles),
                    _headers=header,
                )
            )
        return self.list_user_roles(user_id=user_id)

    def remove_role_from_user(self, user_id: str, roles: List[str]) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.remove_roles_from_user(
                    user_id=user_id, role_names=roles, _headers=header
                )
            )
        return self.list_user_roles(user_id=user_id)

    def add_role_to_group(self, group_id: str, roles: List[str]) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.assign_roles_to_group(
                    group_id=group_id, role_names=roles, _headers=header
                )
            )
        return self.list_group_roles(group_id=group_id)

    def reset_roles_for_group(self, group_id: str, roles: List[str]) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.reset_group_roles(
                    group_id=group_id,
                    roles_reset_request=rest.RolesResetRequest(new_roles=roles),
                    _headers=header,
                )
            )
        return self.list_group_roles(group_id=group_id)

    def remove_role_from_group(self, group_id: str, roles: List[str]) -> List[UserRole]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.permission_api.remove_roles_from_group(
                    group_id=group_id, role_names=roles, _headers=header
                )
            )
        return self.list_group_roles(group_id=group_id)

    def is_permission_granted(self, permission: str) -> bool:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.is_permission_granted(
                    permission_check_request=rest.PermissionCheckRequest(
                        permission=permission
                    ),
                    _headers=header,
                )
            )
        return result

    def is_collection_permission_granted(
        self, collection_id: str, permission: str
    ) -> bool:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.is_collection_permission_granted(
                    collection_id=collection_id,
                    permission_check_request=rest.PermissionCheckRequest(
                        permission=permission
                    ),
                    _headers=header,
                )
            )
        return result

    def create_user_role(self, name: str, description: str) -> UserRole:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.create_role(
                    role_create_request=rest.RoleCreateRequest(
                        name=name,
                        description=description,
                    ),
                    _headers=header,
                )
            )
        return UserRole(**response.to_dict())

    def create_user_group(self, name: str, description: str) -> UserGroup:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.create_group(
                    group_create_request=rest.GroupCreateRequest(
                        name=name,
                        description=description,
                    ),
                    _headers=header,
                )
            )
        return UserGroup(**response.to_dict())

    def delete_user_roles_by_ids(self, roles_ids: Iterable[str]) -> Result:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.delete_roles(
                        role_ids=roles_ids,
                        _headers=header,
                    )
                )
            )
        return result

    def delete_user_roles_by_names(self, roles_names: Iterable[str]) -> Result:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.delete_roles_by_names(
                        names=roles_names,
                        _headers=header,
                    )
                )
            )
        return result

    def delete_user_groups_by_ids(self, groups_ids: Iterable[str]) -> Result:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.delete_groups(
                        group_ids=groups_ids,
                        _headers=header,
                    )
                )
            )
        return result

    def delete_user_groups_by_names(self, groups_names: Iterable[str]) -> Result:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.delete_groups_by_names(
                        names=groups_names,
                        _headers=header,
                    )
                )
            )
        return result

    def assign_permissions_to_role(
        self, role_name: str, permission_names: Iterable[str]
    ) -> Result:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.set_role_permissions(
                        role_id=role_name,
                        permission_reset_request=rest.PermissionResetRequest(
                            new_permissions=permission_names
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def remove_permissions_from_role(
        self, role_id: str, permission_name: str
    ) -> Result:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.permission_api.remove_permission_from_role(
                        role_id=role_id,
                        permission_name=permission_name,
                        _headers=header,
                    )
                )
            )
        return result

    def set_global_configuration(
        self,
        key_name: str,
        string_value: str,
        can_overwrite: bool,
        is_public: bool,
        value_type: str = None,
    ) -> List[GlobalConfigItem]:
        """Set a global configuration.

        Note: Both default collection size limit and inactivity interval can be disabled. To do so, pass '-1' as the string_value.

        Args:
            key_name:
                The name of the global config key.
            string_value:
                The value to be set for the global config.
            can_overwrite:
                Whether user settings can override this global setting.
            is_public:
                Whether users can see the value for this global setting.
            value_type:
                The type of the value to be set for the global config.

        Returns:
            List[GlobalConfigItem]: List of global configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.set_global_configuration(
                    key_name=key_name,
                    set_global_configuration_request=rest.SetGlobalConfigurationRequest(
                        string_value=string_value,
                        can_overwrite=can_overwrite,
                        is_public=is_public,
                        value_type=value_type,
                    ),
                    _headers=header,
                )
            )
        return [GlobalConfigItem(**c.to_dict()) for c in response]

    def get_global_configurations_by_admin(self) -> List[GlobalConfigItem]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.list_global_configurations(
                    as_admin=True,
                    _headers=header,
                )
            )
        return [GlobalConfigItem(**c.to_dict()) for c in response]

    def get_global_configurations(self) -> List[GlobalConfigItem]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.list_global_configurations(
                    as_admin=False,
                    _headers=header,
                )
            )
        return [GlobalConfigItem(**c.to_dict()) for c in response]

    def bulk_delete_global_configurations(
        self, key_names: List[str]
    ) -> List[GlobalConfigItem]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.delete_global_configurations(
                    key_names=key_names,
                    _headers=header,
                )
            )
        return [GlobalConfigItem(**c.to_dict()) for c in response]

    def set_user_configuration_for_user(
        self, key_name: str, string_value: str, user_id: str, value_type: str = None
    ) -> List[ConfigItem]:
        """Set a user configuration for a specific user (overrides the global configuration and to be used by admins only).

        Note: Both default collection size limit and inactivity interval can be disabled. To do so, pass '-1' as the string_value.

        Args:
            key_name:
                The name of the global config key.
            string_value:
                The value to be set for the config.
            user_id:
                The user id you want to apply the config for.
            value_type:
                The type of the value to be set for the config.

        Returns:
            List[ConfigItem]: List of user configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.set_user_configuration(
                    key_name=key_name,
                    user_id=user_id,
                    set_user_configuration_request=rest.SetUserConfigurationRequest(
                        string_value=string_value,
                        value_type=value_type,
                    ),
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def get_user_configurations_for_user(self, user_id: str) -> List[ConfigItem]:
        """Gets the user configurations for a specific user (to be used by admins only).

        Args:
            user_id:
                The unique identifier of the user.

        Returns:
            List[ConfigItem]: List of user configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.list_user_configurations(
                    user_id=user_id,
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def get_user_configurations(self) -> List[ConfigItem]:
        """Gets the user configurations for the current user.

        Returns:
            List[ConfigItem]: List of user configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.list_current_user_configurations(
                    _headers=header
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def bulk_delete_user_configurations_for_user(
        self, user_id: str, key_names: List[str]
    ) -> List[ConfigItem]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.delete_user_configurations(
                    user_id=user_id,
                    key_names=key_names,
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def reset_user_configurations_for_user(
        self, key_name: str, user_id: str
    ) -> List[ConfigItem]:
        """Reset a user configuration for a specific user (to be used by admins only).

        Returns:
            List[ConfigItem]: List of user configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.reset_user_configuration(
                    user_id=user_id,
                    key_name=key_name,
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def delete_agent_directories(self, chat_session_id: str) -> bool:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.delete_agent_server_directories(
                        session_ids=[chat_session_id],
                        _headers=header,
                    )
                )
            )
        return result.status == "completed"

    def set_role_configuration(
        self, key_name: str, role_id: str, string_value: str, value_type: str = None
    ) -> List[ConfigItem]:
        """Set a role configuration, overrides the global configuration.
        Args:
            role_id:
                The role id you want to apply the config for.
            key_name:
                The name of the global config key.
            string_value:
                The value to be set for the config.
            value_type:
                The type of the value to be set for the config.

        Returns:
            List[ConfigItem]: List of role configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.set_role_configuration(
                    key_name=key_name,
                    role_id=role_id,
                    user_configuration_item=rest.UserConfigurationItem(
                        key_name=key_name,
                        string_value=string_value,
                        value_type=value_type,
                    ),
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def list_role_configurations(self, role_id: str) -> List[ConfigItem]:
        """Lists role configurations for a given role.
        Args:
            role_id:
                The role id to get configurations for.

        Returns:
            List[ConfigItem]: List of role configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.list_role_configurations(
                    role_id=role_id,
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def bulk_delete_role_configurations(
        self, role_id: str, keys: List[str]
    ) -> List[ConfigItem]:
        """Delete role configuration items for a given role.
        Args:
            role_id:
                The role id to delete configurations for.
            keys:
                List of configuration keys to delete.

        Returns:
            List[ConfigItem]: List of remaining role configurations.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.configuration_api.delete_role_configurations(
                    key_names=keys,
                    role_id=role_id,
                    _headers=header,
                )
            )
        return [ConfigItem(**c.to_dict()) for c in response]

    def delete_multiple_agent_directories(
        self, chat_session_ids: List[str], dir_types: List[str]
    ) -> bool:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.delete_agent_server_directories(
                        session_ids=chat_session_ids,
                        dir_types=dir_types,
                        _headers=header,
                    )
                )
            )
        return result.status == "completed"

    def get_all_directory_stats(
        self, chat_session_id: str, detail_level: int = 0
    ) -> dict:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.list_all_agent_server_directories_stats(
                    session_id=chat_session_id,
                    detail_level=detail_level,
                    _headers=header,
                )
            )
        return {d.id: d.to_dict() for d in response}

    def get_directory_stats(
        self, directory_name: str, chat_session_id: str, detail_level: int = 0
    ) -> dict:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.get_agent_server_directory_stats(
                    session_id=chat_session_id,
                    detail_level=detail_level,
                    directory_name=directory_name,
                    _headers=header,
                )
            )
        return response.to_dict()

    def get_h2ogpt_system_stats(self) -> dict:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.system_api.get_h2ogpt_system_info(_headers=header)
            )
        return response.to_dict()

    def create_api_key_for_user(
        self,
        user_id: str,
        name: Optional[str] = None,
        collection_id: Optional[str] = None,
        expires_in: Optional[str] = None,
        inactivity_interval: Optional[int] = None,
    ) -> str:
        """Allows admins to create a new api key for a specific user and optionally make it specific to a collection.
        Args:
            user_id:
                String: The id of the user the API key is for.
            name:
                (Optional) String: The name of the API key.
            collection_id:
                (Optional) String: The id of the specific collection.
            expires_in:
                (Optional) String: The expiration for the API key as an interval. Ex. "30 days" or "30 minutes"
            inactivity_interval:
                (Optional) int: The number of days a key can be unused for (no activity) before it becomes invalid.

        Returns:
            String: The id of the API key.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.api_keys_api.create_api_key_for_user(
                    api_key_create_request=rest.APIKeyCreateRequest(
                        user_id=user_id,
                        name=name,
                        collection_id=collection_id,
                        expires_in=expires_in,
                        inactivity_interval=inactivity_interval,
                    ),
                    _headers=header,
                )
            )

        return response.secret_key

    def deactivate_api_key(self, api_key_id: str) -> Result:
        """Allows admins to deactivate an API key.

        Note: You cannot undo this action.

        Args:
            api_key_id:
                String: The id of the API key.

        Returns:
            Result: Status of the deactivate request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.api_keys_api.deactivate_api_key(
                        key_id=api_key_id,
                        _headers=header,
                    )
                )
            )
        return result

    def list_all_api_keys(
        self, offset: int, limit: int, key_filter: str = ""
    ) -> List[APIKey]:
        """Allows admins to list all the API keys that exist.

        Args:
            offset:
                Int: How many keys to skip before returning.
            limit:
                Int: How many keys to return.
            key_filter:
                String: Only returns keys for usernames matching this filter.

        Returns:
            List[APIKey]: List of APIKeys with metadata about each key.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.api_keys_api.list_all_api_keys(
                    offset=offset,
                    limit=limit,
                    filter=key_filter,
                    _headers=header,
                )
            )
        return [APIKey(**k.to_dict()) for k in response]

    def set_api_key_expiration(
        self, api_key_id: str, expires_in: Optional[str] = None
    ) -> Result:
        """Allows admins to set an expiration on an API key.

        Args:
            api_key_id:
                String: The id of the API key.
            expires_in:
                (Optional) String: The expiration for the API key as an interval or None (to remove an expiration that was previously set). Ex. "30 days" or "30 minutes"

        Returns:
            Result: Status of the expiration request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.api_keys_api.update_api_key_expiry(
                        key_id=api_key_id,
                        api_key_update_expiry_request=rest.APIKeyUpdateExpiryRequest(
                            expires_in=expires_in
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def set_api_key_inactivity_interval(
        self, api_key_id: str, inactivity_interval: Optional[int] = None
    ) -> Result:
        """Allows admins to set an inactivity interval for an API key. This is how many days a key can be unused for (no activity) before it becomes invalid.

        Args:
            api_key_id:
                String: The id of the API key.
            inactivity_interval:
                (Optional) int: The inactivity interval for the API key as an integer of days or None (to remove an inactivity interval that was previously set).

        Returns:
            Result: Status of the request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.api_keys_api.update_api_key_inactivity_interval(
                        key_id=api_key_id,
                        api_key_update_inactivity_interval_request=rest.APIKeyUpdateInactivityIntervalRequest(
                            inactivity_interval=inactivity_interval
                        ),
                        _headers=header,
                    )
                )
            )
        return result

    def delete_api_keys(self, api_key_ids: List[str]) -> Result:
        """Allows admins to delete API keys.

        Args:
            api_key_ids:
                List[str]: The API keys to delete.

        Returns:
            Result: Status of the delete request.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            for api_key_id in api_key_ids:
                _rest_to_client_exceptions(
                    lambda: rest_client.api_keys_api.delete_api_key(
                        key_id=api_key_id,
                        _headers=header,
                    )
                )
        return Result(status="completed")

    def get_agent_server_files(self, chat_session_id: str) -> List[dict]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.list_agent_server_files(
                    session_id=chat_session_id,
                    _headers=header,
                )
            )
        return [f.to_dict() for f in response]

    def delete_agent_server_files(self, chat_session_id: str) -> bool:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            result = _get_result(
                lambda: _rest_to_client_exceptions(
                    lambda: rest_client.chat_api.delete_agent_server_files(
                        session_id=chat_session_id,
                        _headers=header,
                    )
                )
            )
        return result.status == "completed"

    def get_user_all_agent_directories(
        self, offset: int, limit: int, filter_text: Optional[str]
    ) -> List[dict]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_agent_directory_stats(
                    offset=offset,
                    limit=limit,
                    filter_text=filter_text,
                    _headers=header,
                )
            )
        result = []
        for agent_session in response:
            stats = {s.id: s.to_dict() for s in agent_session.stats}
            stats["chat_preview"] = agent_session.chat_preview
            result.append({agent_session.agent_chat_session_id: stats})
        return result

    def get_agent_tool_preference(self) -> List[str]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_agent_tool_preference(
                    _headers=header
                )
            )
        return response

    def update_agent_tool_preference(self, reference_value: List[str]) -> None:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.agent_api.update_agent_tool_preference(
                    update_agent_tool_preference_request=rest.UpdateAgentToolPreferenceRequest(
                        reference_value=reference_value,
                    ),
                    _headers=header,
                )
            )

    def delete_agent_tool_preference(self) -> None:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_agent_tool_preference(
                    _headers=header
                )
            )

    def add_agent_key(self, agent_keys: List[dict]) -> List[dict]:
        """Create one or more agent keys for use with agent tools.

        Processes a list of agent key configurations and creates each key.
        Continues processing remaining keys if individual key creation fails.

        Args:
            agent_keys: List of key configuration dictionaries.

                Expected structure::

                    [
                        {
                            "name": str,
                                # Display name for the key

                            "value": str,
                                # The actual key/token value

                            "key_type": str,
                                # Type of key ("private" or "shared")

                            "description": str,
                                # (Optional) Description of the key's purpose
                        }
                    ]

        Returns:
            List[dict]: List of created key results. Each successful creation
                returns {"agent_key_id": str}. Failed creations are logged but
                don't appear in results.
        """
        result = []
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            for agent_key in agent_keys:
                try:
                    request = rest.CreateAgentKeyRequest(
                        name=agent_key["name"],
                        value=agent_key["value"],
                        type=agent_key["key_type"],
                        description=agent_key.get("description"),
                    )
                    agent_key = _rest_to_client_exceptions(
                        lambda: rest_client.agent_api.create_agent_key(
                            create_agent_key_request=request, _headers=header
                        )
                    )
                    result.append({"agent_key_id": agent_key.id})
                except FailedError:
                    print(
                        f"Failed to create agent key '{agent_key['name']}'"
                    )  # noqa: no exception details to avoid leaking secrets
        return result

    def get_agent_keys(self) -> List[dict]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_agent_keys(_headers=header)
            )
        return [k.to_dict() for k in response]

    def update_agent_key(
        self,
        key_id: str,
        name: Optional[str] = None,
        value: Optional[str] = None,
        key_type: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Optional[dict]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            try:
                request = rest.UpdateAgentKeyRequest(
                    name=name, value=value, type=key_type, description=description
                )
                agent_key = _rest_to_client_exceptions(
                    lambda: rest_client.agent_api.update_agent_key(
                        key_id=key_id, update_agent_key_request=request, _headers=header
                    )
                )
                return agent_key.to_dict()
            except FailedError as e:
                print(f"Failed to update the key with id '{key_id}': {e}")
                return None

    def delete_agent_keys(self, key_ids: List[str]) -> None:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_agent_keys(
                    key_ids=key_ids,
                    _headers=header,
                )
            )

    def assign_agent_key_for_tool(
        self, tool_dict_list: List[dict]
    ) -> Optional[List[Tuple]]:
        """Assign agent keys to tools by creating associations between them.

        Args:
            tool_dict_list: List of dictionaries containing tool association data.
                Each dictionary should have a "tool_dict" key with the association
                configuration data for creating agent tool key associations.

                Expected tool_dict structure::

                    {
                        "tool": str,        # Name of the tool (for example, "test_tool").
                        "keys": list[dict], # List of key definitions. Each item is a dictionary with:
                                           #   - "name": str
                                           #       Environment variable name (for example, "TEST_KEY").
                                           #   - "key_id": Any
                                           #       Identifier assigned to the key (for example, agent_key_id).
                    }

        Returns:
            Optional[List[Tuple]]: List of tuples containing association details.
                Each tuple contains (associate_id, tool, key_name, key_id, user_id).
                Returns None if no associations were created.
        """
        result = []
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            for association in tool_dict_list:
                request = rest.CreateAgentToolKeyAssociationsRequest.from_dict(
                    association["tool_dict"]
                )
                response = _rest_to_client_exceptions(
                    lambda: rest_client.agent_api.create_agent_key_tool_associations(
                        create_agent_tool_key_associations_request=request,
                        _headers=header,
                    )
                )
                for key in response.keys:
                    result.append(
                        (
                            key.associate_id,
                            response.tool,
                            key.name,
                            key.key_id,
                            key.user_id,
                        )
                    )
        return result

    def get_agent_key_tool_associations(self) -> List[dict]:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_agent_key_tool_associations(
                    _headers=header
                )
            )
        return [r.to_dict() for r in response]

    def delete_agent_tool_association(self, associate_ids: List[str]) -> int:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_agent_tool_association(
                    associate_ids=associate_ids,
                    _headers=header,
                )
            )
        return response.count

    def add_custom_agent_tool(
        self, tool_type: str, tool_args: dict, custom_tool_path: Optional[str] = None
    ) -> list:
        """Adds a custom agent tool.

        Args:
            tool_type: The type of custom tool being added. Valid values:
                - 'local_mcp': Model Context Protocol server running locally
                - 'remote_mcp': Model Context Protocol server running remotely
                - 'browser_action': Custom browser automation actions
                - 'general_code': General purpose code execution tools

            tool_args: Dictionary containing tool-specific arguments. Structure varies by tool_type:

                For 'remote_mcp':
                {
                    "mcp_config_json": "JSON string with MCP server configuration",
                    "enable_by_default": True/False (optional, defaults to True)
                }

                For 'local_mcp', 'browser_action', and 'general_code':
                {
                    "tool_name": "string (optional, defaults to filename without extension)",
                    "description": "string (optional, tool description)",
                    "enable_by_default": True/False (optional, defaults to True),
                    "should_unzip": True/False (optional, for general_code .zip files only),
                    "tool_usage_mode": ["runner", "creator"] (optional list of strings, for remote_mcp)
                }

            custom_tool_path: Path to the tool file to upload (optional). Requirements vary by tool_type:
                - 'local_mcp': .zip file containing MCP server code
                - 'remote_mcp': Optional .json file with MCP configuration
                - 'browser_action': .py file (must start with 'browser_') or .zip containing browser action scripts
                - 'general_code': .py or .zip file with custom code

        Returns:
            list: List of created custom agent tool IDs
        """
        header = self._get_auth_header()
        custom_tool_path = str(custom_tool_path) if custom_tool_path else None
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.add_custom_agent_tool(
                    file=custom_tool_path,
                    tool_type=tool_type,
                    tool_args=json.dumps(tool_args),
                    custom_tool_path=custom_tool_path,
                    filename=(
                        os.path.basename(custom_tool_path) if custom_tool_path else None
                    ),
                    _headers=header,
                )
            )
        return [obj.agent_custom_tool_id for obj in response]

    def delete_custom_agent_tool(self, tool_ids: List[str]) -> int:
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_custom_agent_tool(
                    tool_ids=tool_ids,
                    _headers=header,
                )
            )
        return response.count

    def update_custom_agent_tool(
        self,
        tool_id: str,
        tool_args: dict,
    ) -> str:
        """Updates a custom agent tool's arguments.

        Args:
            tool_id: The ID of the tool to update
            tool_args: New tool arguments

        Returns:
            The updated tool ID
        """
        header = self._get_auth_header()

        # Build request body with only tool_args
        request_obj = rest.UpdateCustomAgentToolRequest(tool_args=tool_args)

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.update_custom_agent_tool(
                    tool_id=tool_id,
                    update_custom_agent_tool_request=request_obj,
                    _headers=header,
                )
            )
        return response.agent_custom_tool_id

    def pause_chat(self, question_id: str) -> Result:
        """Pause a streaming chat response.

        Args:
            question_id: The ID of the chat message/question to pause.

        Returns:
            Result: Status of the pause operation.

        Raises:
            Exception: If the user is not authorized to pause this chat or if the operation fails.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.pause_chat_message(
                    question_id=question_id, _headers=header
                )
            )
        return Result(status="completed")

    def resume_chat(self, question_id: str) -> Result:
        """Resume a paused chat response.

        Args:
            question_id: The ID of the chat message/question to resume.

        Returns:
            Result: Status of the resume operation.

        Raises:
            Exception: If the user is not authorized to resume this chat or if the operation fails.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.resume_chat_message(
                    question_id=question_id, _headers=header
                )
            )
        return Result(status="completed")

    def finish_chat(self, question_id: str) -> Result:
        """Signal the LLM to complete its current thought and finish naturally.

        Unlike stop_chat which immediately halts response generation, finish_chat allows
        the LLM to complete its current thought naturally, providing a more coherent ending.

        Args:
            question_id: The ID of the chat message/question to finish gracefully.

        Returns:
            Result: Status of the finish operation.

        Raises:
            Exception: If the user is not authorized to finish this chat or if the operation fails.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.finish_chat_message(
                    question_id=question_id, _headers=header
                )
            )
        return Result(status="completed")

    def send_hitl_message(
        self,
        question_id: str,
        message: str,
    ) -> Result:
        """Send a course correction message to a running agent.

        Sends a human-in-the-loop message to a running agent. The agent will
        incorporate this guidance before its next LLM call.

        Args:
            question_id: The ID of the active streaming chat question.
            message: The course correction message to send to the agent.

        Returns:
            Result: Status of the send operation.

        Raises:
            Exception: If the user is not authorized or if the operation fails.
        """
        from h2ogpte.rest_async.models.send_hitl_message_request import (
            SendHitlMessageRequest,
        )

        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.send_hitl_message(
                    question_id=question_id,
                    send_hitl_message_request=SendHitlMessageRequest(
                        message=message,
                    ),
                    _headers=header,
                )
            )
        return Result(status="completed")

    def stop_chat(self, question_id: str) -> Result:
        """Immediately stop/cancel a streaming chat response.

        This will immediately halt response generation, which may result in an incomplete
        sentence or thought. For a more graceful termination, use finish_chat instead.

        Args:
            question_id: The ID of the chat message/question to stop immediately.

        Returns:
            Result: Status of the cancel operation.

        Raises:
            Exception: If the user is not authorized to cancel this chat or if the operation fails.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            _rest_to_client_exceptions(
                lambda: rest_client.chat_api.stop_chat_message(
                    question_id=question_id, _headers=header
                )
            )
        return Result(status="completed")

    def get_custom_agent_tools(self) -> List[dict]:
        """Gets all custom agent tools for the current user.

        Returns:
            List[dict]: A list of custom agent tools with their details.
                Each tool contains: id, tool_name, tool_type, tool_args, owner_email
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_custom_agent_tools(_headers=header)
            )
        return response

    def add_custom_agent(
        self,
        agent_type: str,
        agent_args: dict,
        agent_path: str,
        agent_name: Optional[str] = None,
    ) -> list:
        """Adds a custom agent by uploading a zip file.

        Args:
            agent_type: Type of agent (langgraph, crewai, openai, claude)
            agent_args: Agent configuration arguments
            agent_path: Path to the agent zip file
            agent_name: Optional user-provided name for the agent. If provided and the
                zip contains exactly one agent, this name will be used instead of the
                folder name inside the zip. If not provided (or empty), the agent name
                is derived from the folder name(s) inside the zip.

        Returns:
            List of agent IDs created from the upload
        """
        header = self._get_auth_header()
        agent_path = str(agent_path)
        # Send user-provided name or empty string (backend derives from folder names if empty)
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.add_custom_agent(
                    file=agent_path,
                    agent_type=agent_type,
                    agent_args=json.dumps(agent_args),
                    agent_name=agent_name or "",
                    _headers=header,
                )
            )
        return [obj.agent_custom_agent_id for obj in response]

    def delete_custom_agent(self, agent_ids: List[str]) -> int:
        """Deletes custom agents.

        Args:
            agent_ids: List of agent IDs to delete

        Returns:
            Count of deleted agents
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_custom_agent(
                    agent_ids=agent_ids,
                    _headers=header,
                )
            )
        return response.count

    def update_custom_agent(
        self,
        agent_id: str,
        agent_args: dict,
        mcp_servers_mapping: dict | None = None,
    ) -> str:
        """Updates a custom agent's arguments.

        Args:
            agent_id: The ID of the agent to update
            agent_args: New agent arguments
            mcp_servers_mapping: Optional dict mapping MCP server names to tool names (or None)
                Example: {"powerpoint_server": "powerpoint_mcp_tool", "web_search": None}

        Returns:
            The updated agent ID
        """
        header = self._get_auth_header()

        # Build request body with agent_args and optionally mcp_servers_mapping
        request_obj = rest.UpdateCustomAgentRequest(
            agent_args=agent_args, mcp_servers_mapping=mcp_servers_mapping
        )

        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.update_custom_agent(
                    agent_id=agent_id,
                    update_custom_agent_request=request_obj,
                    _headers=header,
                )
            )
        return response.agent_custom_agent_id

    def get_all_agents(self) -> List[dict]:
        """Gets all agents (both built-in and custom) for the current user.

        Returns:
            List[dict]: A list of all agents with unified structure.
                Each agent contains: id, value, label, enabled, type, owner, description,
                api_keys (grouped by optional/required/custom), and mcp_servers (for custom agents)
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.get_all_agents(_headers=header)
            )
        # Convert Pydantic models to dicts to match the return type annotation
        return [
            agent.to_dict()
            if hasattr(agent, "to_dict")
            else agent.model_dump()
            if hasattr(agent, "model_dump")
            else dict(agent)
            for agent in response
        ]

    def get_custom_agents(self) -> List[dict]:
        """Gets all custom agents for the current user.

        Returns:
            List[dict]: A list of custom agents with their details.
                Each agent contains: id, agent_name, agent_type, agent_args, owner_email, resolved_tool_mapping
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_custom_agents(_headers=header)
            )
        # Convert Pydantic models to dicts to match the return type annotation
        return [
            agent.to_dict()
            if hasattr(agent, "to_dict")
            else agent.model_dump()
            if hasattr(agent, "model_dump")
            else dict(agent)
            for agent in response
        ]

    def get_custom_agent(self, agent_id: str) -> dict:
        """Gets a single custom agent by ID for the current user.

        Args:
            agent_id: The unique identifier of the agent to retrieve.

        Returns:
            dict: A custom agent with details including: id, agent_name, agent_type,
                agent_args, owner_email, mcp_servers, api_keys

        Raises:
            NotFoundError: If the agent is not found or not owned by the user
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.get_custom_agent(
                    agent_id=agent_id, _headers=header
                )
            )
        # Convert Pydantic model to dict to match the return type annotation
        if hasattr(response, "to_dict"):
            return response.to_dict()
        elif hasattr(response, "model_dump"):
            return response.model_dump()
        else:
            return dict(response)

    def list_custom_agent_tool_associations(
        self, agent_id: str | None = None, agent_name: str | None = None
    ) -> List[dict]:
        """Lists custom agent tool associations, optionally filtered by agent_id or agent_name.

        Args:
            agent_id: Optional agent UUID to filter by
            agent_name: Optional agent name to filter by

        Returns:
            List[dict]: A list of association objects with agent_id, agent_name, tool_id, tool_name, mcp_server_name, etc.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_custom_agent_tool_associations(
                    agent_id=agent_id,
                    agent_name=agent_name,
                    _headers=header,
                )
            )
        # Convert Pydantic models to dicts to match the return type annotation
        return [
            assoc.to_dict()
            if hasattr(assoc, "to_dict")
            else assoc.model_dump()
            if hasattr(assoc, "model_dump")
            else dict(assoc)
            for assoc in response
        ]

    def create_custom_agent_tool_association(
        self,
        agent_id: str,
        mcp_server_name: str,
        tool_name: str | None = None,
    ) -> dict:
        """Creates a custom agent tool association.

        Args:
            agent_id: Agent UUID
            mcp_server_name: MCP server name
            tool_name: Optional tool name to associate (None for unresolved)

        Returns:
            dict: Created association object
        """
        header = self._get_auth_header()
        request_obj = rest.CreateCustomAgentToolAssociationRequest(
            agent_id=agent_id,
            mcp_server_name=mcp_server_name,
            tool_name=tool_name,
        )
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.create_custom_agent_tool_association(
                    create_custom_agent_tool_association_request=request_obj,
                    _headers=header,
                )
            )
        # Convert Pydantic model to dict
        if hasattr(response, "to_dict"):
            return response.to_dict()
        elif hasattr(response, "model_dump"):
            return response.model_dump()
        else:
            return dict(response)

    def delete_custom_agent_tool_associations(self, association_ids: List[str]) -> int:
        """Deletes custom agent tool associations by IDs.

        Args:
            association_ids: List of association UUIDs to delete

        Returns:
            int: Number of associations deleted
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_custom_agent_tool_associations(
                    association_ids=association_ids,
                    _headers=header,
                )
            )
        # Extract deleted_count from response
        if hasattr(response, "deleted_count"):
            return response.deleted_count
        elif isinstance(response, dict):
            return response.get("deleted_count", 0)
        else:
            return 0

    def list_custom_agent_key_associations(
        self, agent_id: str | None = None
    ) -> List[dict]:
        """Lists custom agent key associations, optionally filtered by agent_id.

        Args:
            agent_id: Optional agent UUID to filter by

        Returns:
            List[dict]: Association objects with id, agent_id, env_key_name, key_id,
                requirement_type, key_name, owner_email.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.list_custom_agent_key_associations(
                    agent_id=agent_id,
                    _headers=header,
                )
            )
        return [
            assoc.to_dict()
            if hasattr(assoc, "to_dict")
            else assoc.model_dump()
            if hasattr(assoc, "model_dump")
            else dict(assoc)
            for assoc in response
        ]

    def create_custom_agent_key_association(
        self,
        agent_id: str,
        env_key_name: str,
        key_id: str,
    ) -> dict:
        """Creates a custom agent key association (env var -> agent key).

        Args:
            agent_id: Custom agent UUID
            env_key_name: Env var name (from envs.json or user-added)
            key_id: Agent key UUID to associate

        Returns:
            dict: Created association with id, agent_id, env_key_name, key_id,
                requirement_type, key_name, owner_email.
        """
        header = self._get_auth_header()
        request_obj = rest.CreateCustomAgentKeyAssociationRequest(
            agent_id=agent_id,
            env_key_name=env_key_name,
            key_id=key_id,
        )
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.create_custom_agent_key_association(
                    create_custom_agent_key_association_request=request_obj,
                    _headers=header,
                )
            )
        if hasattr(response, "to_dict"):
            return response.to_dict()
        if hasattr(response, "model_dump"):
            return response.model_dump()
        return dict(response)

    def delete_custom_agent_key_associations(self, association_ids: List[str]) -> int:
        """Deletes custom agent key associations by IDs.

        Args:
            association_ids: List of association UUIDs to delete

        Returns:
            int: Number of associations deleted
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.delete_custom_agent_key_associations(
                    association_ids=association_ids,
                    _headers=header,
                )
            )
        if response is None:
            return 0
        if hasattr(response, "deleted_count"):
            return (
                int(response.deleted_count) if response.deleted_count is not None else 0
            )
        if hasattr(response, "deletedCount"):
            return (
                int(response.deletedCount) if response.deletedCount is not None else 0
            )
        if isinstance(response, dict) and "deleted_count" in response:
            return int(response["deleted_count"])
        return 0

    def get_agent_suggestions(self, agent_id: str) -> List[dict]:
        """Gets MCP tool suggestions for a custom agent.

        Returns suggested MCP tool configurations for a custom agent based on its
        metadata. Helps users identify and configure required tools.

        Args:
            agent_id: The unique identifier of the custom agent.

        Returns:
            List[dict]: A list of suggestion objects, each containing:
                - mcp_servers: List of MCP server suggestions with tool_name and tool_args
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.agent_api.get_agent_suggestions(
                    agent_id=agent_id,
                    _headers=header,
                )
            )
        # Convert Pydantic models to dicts to match the return type annotation
        return [
            suggestion.to_dict()
            if hasattr(suggestion, "to_dict")
            else suggestion.model_dump()
            if hasattr(suggestion, "model_dump")
            else dict(suggestion)
            for suggestion in response
        ]

    def set_role_priority(self, role_id: str, priority: int) -> UserRole:
        """Sets the priority for a role.
        Args:
            role_id:
                String: The id of the role to set the priority for.
            priority:
                Int: The priority value to set for the role. ex: 100, 200, 300...etc.
                The lower the number, the higher the priority.
        Returns:
            UserRole: The updated user role with the new priority.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.permission_api.set_role_priority(
                    role_id=role_id,
                    set_role_priority_request=rest.SetRolePriorityRequest(
                        priority=priority
                    ),
                    _headers=header,
                )
            )
        return UserRole(**response.to_dict())

    def fork_chat_session(
        self, chat_session_id: str, message_id: Optional[str] = None
    ) -> str:
        """Fork a chat session, creating an independent copy with all messages,
        references, metadata, and document associations preserved.

        When message_id is provided, only messages up to and including that
        message are copied (branch from a specific point in the conversation).

        Args:
            chat_session_id: The ID of the chat session to fork.
            message_id: Optional message ID to branch from.

        Returns:
            The ID of the newly created (forked) chat session.
        """
        header = self._get_auth_header()
        with self._RESTClient(self) as rest_client:
            response = _rest_to_client_exceptions(
                lambda: rest_client.chat_api.fork_chat_session(
                    session_id=chat_session_id,
                    fork_chat_session_request=rest.ForkChatSessionRequest(
                        message_id=message_id,
                    ),
                    _headers=header,
                )
            )
            return response.id

    def create_ai_assistant(
        self,
        name: str,
        llm: str,
        description: str = "",
        system_prompt: str = "",
        llm_args: Optional[Dict[str, Any]] = None,
        custom_tool_definition: Optional[str] = None,
        mcp_servers: Optional[List[Any]] = None,
        credential_ids: Optional[List[str]] = None,
        memory_block_id: Optional[str] = None,
        notification_email: Optional[str] = None,
        history_management: str = "semantic_retrieval",
        history_max_chars: Optional[int] = None,
        history_recent_chars: Optional[int] = None,
        history_retrieval_chars: Optional[int] = None,
        allowed_tool_actions: Optional[List[str]] = None,
        allowed_trigger_types: Optional[List[str]] = None,
        default_wake_period: Optional[int] = None,
        tool_action_policies: Optional[Dict[str, str]] = None,
        approval_user_id: Optional[str] = None,
        custom_approval_text: Optional[str] = None,
    ) -> str:
        """Create a new AI assistant.

        Args:
            name: Name of the assistant (must be unique per user).
            description: Optional description.
            system_prompt: System prompt for the assistant's LLM calls.
            llm: Model identifier to use.
            llm_args: Optional dict of additional LLM arguments.
            custom_tool_definition: Optional custom tool Python code (None = use default).
            mcp_servers: Optional list of MCP server configuration objects.
            credential_ids: Optional list of credential/secret UUIDs.
            memory_block_id: Optional UUID of a memory block for private state.
            notification_email: Optional email for wake cycle notifications.
            history_management: 'truncation', 'compactification', or 'semantic_retrieval'.
            history_max_chars: Character threshold for history management.
            history_recent_chars: Characters of recent history to always include (semantic_retrieval mode).
            history_retrieval_chars: Characters of retrieved history to include (semantic_retrieval mode).
            allowed_tool_actions: List of allowed tool action names (None = all allowed).
            allowed_trigger_types: List of allowed trigger types (None = all allowed).
            default_wake_period: Periodic wake interval in seconds (None = no periodic wake).
            tool_action_policies: Dict mapping tool action names to policies (None = no policies).
            approval_user_id: Optional UUID of the designated approval user.
            custom_approval_text: Optional custom data protection instructions for the agent.

        Returns:
            str: The ID of the created assistant.
        """
        result = self._post(
            "/rpc/db",
            [
                "create_ai_assistant",
                name,
                description,
                system_prompt,
                llm,
                llm_args,
                custom_tool_definition,
                mcp_servers,
                credential_ids,
                memory_block_id,
                notification_email,
                history_management,
                history_max_chars,
                history_recent_chars,
                history_retrieval_chars,
                allowed_tool_actions,
                allowed_trigger_types,
                default_wake_period,
                tool_action_policies,
                approval_user_id,
                custom_approval_text,
            ],
        )
        return result["id"]

    def get_ai_assistant(self, assistant_id: str) -> "AiAssistant":
        """Get details of an AI assistant.

        Args:
            assistant_id: The assistant's UUID.

        Returns:
            AiAssistant: The assistant details.
        """
        from h2ogpte.types import AiAssistant

        result = self._post("/rpc/db", ["get_ai_assistant", assistant_id])
        return AiAssistant(**result)

    def list_ai_assistants(
        self,
        offset: int = 0,
        limit: int = 100,
        name_filter: Optional[str] = None,
        status_filter: Optional[str] = None,
    ) -> List["AiAssistant"]:
        """List AI assistants accessible to the current user.

        Args:
            offset: Pagination offset.
            limit: Maximum number of results.
            name_filter: Optional name filter (substring match).
            status_filter: Optional status filter ('stopped', 'running', 'sleeping', 'error').

        Returns:
            List[AiAssistant]: List of assistants.
        """
        from h2ogpte.types import AiAssistant

        result = self._post(
            "/rpc/db",
            ["list_ai_assistants", offset, limit, name_filter, status_filter],
        )
        return [AiAssistant(**r) for r in result]

    def update_ai_assistant(
        self,
        assistant_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        system_prompt: Optional[str] = None,
        llm: Optional[str] = None,
        llm_args: Optional[Dict[str, Any]] = None,
        custom_tool_definition: Optional[str] = None,
        mcp_servers: Optional[List[Any]] = None,
        credential_ids: Optional[List[str]] = None,
        memory_block_id: Optional[str] = None,
        notification_email: Optional[str] = None,
        history_management: Optional[str] = None,
        history_max_chars: Optional[int] = None,
        history_recent_chars: Optional[int] = None,
        history_retrieval_chars: Optional[int] = None,
        allowed_tool_actions: Optional[List[str]] = None,
        allowed_trigger_types: Optional[List[str]] = None,
        tool_action_policies: Optional[Dict[str, str]] = None,
        approval_user_id: Optional[str] = None,
        custom_approval_text: Optional[str] = None,
        policies_locked: Optional[bool] = None,
        custom_approval_locked: Optional[bool] = None,
    ) -> None:
        """Update an AI assistant's configuration.

        Args:
            assistant_id: The assistant's UUID.
            name: New name (optional).
            description: New description (optional).
            system_prompt: New system prompt (optional).
            llm: New model identifier (optional).
            llm_args: New LLM args dict (optional).
            custom_tool_definition: New custom tool Python code (optional).
            mcp_servers: New MCP server config list (optional).
            credential_ids: New credential UUID list (optional).
            memory_block_id: New memory block UUID (optional).
            notification_email: New notification email (optional).
            history_management: New history mode (optional).
            history_max_chars: New char threshold (optional).
            history_recent_chars: Characters of recent history to always include (optional).
            history_retrieval_chars: Characters of retrieved history to include (optional).
            allowed_tool_actions: List of allowed tool action names (optional).
            allowed_trigger_types: List of allowed trigger types (optional).
            tool_action_policies: Dict mapping tool action names to policies (optional).
            approval_user_id: UUID of the designated approval user (optional).
            custom_approval_text: Custom data protection instructions (optional).
            policies_locked: Lock tool action policies (admin-only) (optional).
            custom_approval_locked: Lock custom approval text (admin-only) (optional).
        """
        self._post(
            "/rpc/db",
            [
                "update_ai_assistant",
                assistant_id,
                name,
                description,
                system_prompt,
                llm,
                llm_args,
                custom_tool_definition,
                mcp_servers,
                credential_ids,
                memory_block_id,
                notification_email,
                history_management,
                history_max_chars,
                history_recent_chars,
                history_retrieval_chars,
                allowed_tool_actions,
                allowed_trigger_types,
                tool_action_policies,
                approval_user_id,
                custom_approval_text,
                policies_locked,
                custom_approval_locked,
            ],
        )

    def delete_ai_assistant(self, assistant_id: str) -> None:
        """Delete an AI assistant.

        Uses the REST API endpoint which both deletes from the DB and cleans
        up Redis wake/dedup keys, unlike calling the RPC directly.

        Args:
            assistant_id: The assistant's UUID.
        """
        self._delete(f"/api/v1/ai_assistants/{assistant_id}")

    def start_ai_assistant(self, assistant_id: str) -> None:
        """Start an AI assistant (sets status to 'sleeping' and records a start event).

        Uses the REST API endpoint which both updates the DB status and records
        the start event, unlike calling the RPC directly.

        Args:
            assistant_id: The assistant's UUID.
        """
        self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/start",
            {},
        )

    def stop_ai_assistant(self, assistant_id: str) -> None:
        """Stop an AI assistant (sets status to 'stopped' and records a stop event).

        Uses the REST API endpoint which both updates the DB status and records
        the stop event, unlike calling the RPC directly.

        Args:
            assistant_id: The assistant's UUID.
        """
        self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/stop",
            {},
        )

    def wake_ai_assistant(self, assistant_id: str) -> None:
        """Manually trigger a wake cycle for an AI assistant.

        The assistant must be in 'sleeping' status. This calls the REST API
        endpoint which pushes a wake event to Redis for the event loop to
        process.

        Uses the REST API endpoint which pushes the wake event via Redis,
        unlike calling the RPC directly which would only update the DB status.

        Args:
            assistant_id: The assistant's UUID.
        """
        self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/wake",
            {},
        )

    def reset_ai_assistant_tool(self, assistant_id: str) -> None:
        """Reset an AI assistant's custom tool definition to NULL.

        Uses the __CLEAR__ sentinel value recognized by the
        update_ai_assistant DB function to set custom_tool_definition to NULL.

        Args:
            assistant_id: The assistant's UUID.
        """
        self._post(
            "/rpc/db",
            [
                "update_ai_assistant",
                assistant_id,
                None,  # name
                None,  # description
                None,  # system_prompt
                None,  # llm
                None,  # llm_args
                "__CLEAR__",  # custom_tool_definition - sentinel to set NULL
                None,  # mcp_servers
                None,  # credential_ids
                None,  # memory_block_id
                None,  # notification_email
                None,  # history_management
                None,  # history_max_chars
                None,  # history_recent_chars
                None,  # history_retrieval_chars
                None,  # allowed_tool_actions
                None,  # allowed_trigger_types
            ],
        )

    def list_ai_assistant_files(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantFile"]:
        """List files stored by an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List[AiAssistantFile]: List of file metadata objects with
                ``file_id``, ``created_at``, and ``source`` fields.
        """
        from h2ogpte.types import AiAssistantFile

        result = self._post(
            "/rpc/db",
            ["list_assistant_files", assistant_id, offset, limit],
        )
        items = result if isinstance(result, list) else []
        return [AiAssistantFile(**item) for item in items]

    def download_ai_assistant_file(
        self,
        assistant_id: str,
        file_id: str,
        destination_directory: Union[str, Path],
        destination_file_name: str,
    ) -> Path:
        """Downloads a file stored by an AI assistant to a local directory.

        Args:
            assistant_id: The assistant's UUID.
            file_id: The file's UUID.
            destination_directory: Destination directory to save the file into.
            destination_file_name: Destination file name.

        Returns:
            Path: Path of the downloaded file.
        """
        destination_directory = Path(destination_directory)
        destination_file = destination_directory / destination_file_name
        if not destination_directory.is_dir():
            raise FileNotFoundError("Destination directory does not exist")
        if destination_file.exists():
            raise FileExistsError(f"File {destination_file} already exists")

        res = self._get(
            f"/api/v1/ai_assistants/{assistant_id}/files/{file_id}/content",
            as_json=False,
        )

        with open(destination_file, "wb") as f:
            f.write(res.content)
        return destination_file

    def send_message_to_assistant(
        self,
        assistant_id: str,
        content: str,
    ) -> str:
        """Send a direct message to an AI assistant.

        Creates the message in the database and automatically pushes a wake
        event if the assistant is in sleeping state. There is no need to call
        wake_ai_assistant() separately.

        Args:
            assistant_id: The assistant's UUID.
            content: The message text.

        Returns:
            str: The ID of the created message.
        """
        result = self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/messages",
            {"content": content},
        )
        return result["id"]

    def list_assistant_messages(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 50,
        since: Optional[datetime.datetime] = None,
    ) -> List["AiAssistantMessage"]:
        """List direct messages for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results.
            since: Optional cutoff timestamp — only return messages created
                after this time. Defaults to 2 years on the server side.

        Returns:
            List[AiAssistantMessage]: List of messages.
        """
        from h2ogpte.types import AiAssistantMessage

        since_str = since.isoformat() if since is not None else None
        result = self._post(
            "/rpc/db",
            ["list_assistant_messages", assistant_id, offset, limit, since_str],
        )
        return [AiAssistantMessage(**r) for r in result]

    def list_assistant_events(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 50,
        event_type: Optional[str] = None,
        since: Optional[datetime.datetime] = None,
    ) -> List["AiAssistantEvent"]:
        """List wake/sleep events for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results.
            event_type: Optional event type filter ('wake', 'sleep', 'error', 'start', 'stop', 'compactify', 'memory_index').
            since: Optional cutoff timestamp — only return events created
                after this time. Defaults to 2 years on the server side.

        Returns:
            List[AiAssistantEvent]: List of events.
        """
        from h2ogpte.types import AiAssistantEvent

        since_str = since.isoformat() if since is not None else None
        result = self._post(
            "/rpc/db",
            [
                "list_assistant_events",
                assistant_id,
                offset,
                limit,
                event_type,
                since_str,
            ],
        )
        return [AiAssistantEvent(**r) for r in result]

    def get_ai_assistant_chat_history(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 10000,
    ) -> str:
        """Get the assistant's full chat history as formatted text.

        Returns the complete conversation history across all wake cycles
        as a plain-text string with question/reply pairs in chronological
        order.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset (default 0).
            limit: Maximum number of chat turns to return (default 10000).

        Returns:
            str: The full chat history as formatted text.
        """
        params = f"?offset={offset}&limit={limit}"
        res = self._get(
            f"/api/v1/ai_assistants/{assistant_id}/history/chat{params}",
            as_json=False,
        )
        return res.text

    def get_ai_assistant_event_history(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 10000,
    ) -> str:
        """Get the assistant's full event history as formatted text.

        Returns the complete event/activity log across all wake cycles
        as a plain-text string with timestamps, event types, trigger
        details, and wake cycle numbers.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset (default 0).
            limit: Maximum number of events to return (default 10000).

        Returns:
            str: The full event history as formatted text.
        """
        params = f"?offset={offset}&limit={limit}"
        res = self._get(
            f"/api/v1/ai_assistants/{assistant_id}/history/events{params}",
            as_json=False,
        )
        return res.text

    def share_ai_assistant(
        self,
        assistant_id: str,
        username: str,
        access_mode: str = "read",
    ) -> None:
        """Share an AI assistant with another user.

        Args:
            assistant_id: The assistant's UUID.
            username: The username to share with.
            access_mode: Access level - 'read', 'write', or 'read_write'.
        """
        self._post(
            "/rpc/db",
            ["share_ai_assistant", assistant_id, username, access_mode],
        )

    def unshare_ai_assistant(
        self,
        assistant_id: str,
        username: str,
    ) -> None:
        """Remove sharing for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            username: The username to unshare from.
        """
        self._post(
            "/rpc/db",
            ["unshare_ai_assistant", assistant_id, username],
        )

    def update_ai_assistant_tool(
        self,
        assistant_id: str,
        custom_tool_definition: str,
    ) -> None:
        """Update the custom tool definition for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            custom_tool_definition: The Python code for the custom tool.
        """
        self._post(
            "/rpc/db",
            [
                "update_ai_assistant",
                assistant_id,
                None,  # name
                None,  # description
                None,  # system_prompt
                None,  # llm
                None,  # llm_args
                custom_tool_definition,  # custom_tool_definition
                None,  # mcp_servers
                None,  # credential_ids
                None,  # memory_block_id
                None,  # notification_email
                None,  # history_management
                None,  # history_max_chars
                None,  # history_recent_chars
                None,  # history_retrieval_chars
                None,  # allowed_tool_actions
                None,  # allowed_trigger_types
            ],
        )

    def connect_assistant_to_forum(
        self,
        assistant_id: str,
        forum_id: str,
        access_mode: str = "read",
    ) -> None:
        """Connect an AI assistant to a forum.

        Args:
            assistant_id: The assistant's UUID.
            forum_id: The forum's UUID.
            access_mode: Access level - 'read', 'write', or 'read_write'.
                Defaults to 'read' to follow principle of least privilege.
        """
        self._post(
            "/rpc/db",
            [
                "connect_assistant_to_forum",
                assistant_id,
                forum_id,
                access_mode,
            ],
        )

    def disconnect_assistant_from_forum(
        self,
        assistant_id: str,
        forum_id: str,
    ) -> None:
        """Disconnect an AI assistant from a forum.

        Args:
            assistant_id: The assistant's UUID.
            forum_id: The forum's UUID.
        """
        self._post(
            "/rpc/db",
            ["disconnect_assistant_from_forum", assistant_id, forum_id],
        )

    def list_assistant_forums(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantForumLink"]:
        """List forums connected to an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List[AiAssistantForumLink]: List of forum connections.
        """
        from h2ogpte.types import AiAssistantForumLink

        result = self._post(
            "/rpc/db",
            ["list_assistant_forums", assistant_id, offset, limit],
        )
        return [AiAssistantForumLink(**r) for r in result]

    def connect_assistant_to_schedule(
        self,
        assistant_id: str,
        scheduled_task_id: str,
    ) -> None:
        """Connect an AI assistant to a scheduled task as a wake trigger.

        Args:
            assistant_id: The assistant's UUID.
            scheduled_task_id: The scheduled task's UUID.
        """
        self._post(
            "/rpc/db",
            ["connect_assistant_to_schedule", assistant_id, scheduled_task_id],
        )

    def disconnect_assistant_from_schedule(
        self,
        assistant_id: str,
        scheduled_task_id: str,
    ) -> None:
        """Disconnect an AI assistant from a scheduled task.

        Args:
            assistant_id: The assistant's UUID.
            scheduled_task_id: The scheduled task's UUID.
        """
        self._post(
            "/rpc/db",
            ["disconnect_assistant_from_schedule", assistant_id, scheduled_task_id],
        )

    def list_assistant_schedules(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantScheduleLink"]:
        """List scheduled tasks connected to an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List[AiAssistantScheduleLink]: List of schedule connections.
        """
        from h2ogpte.types import AiAssistantScheduleLink

        result = self._post(
            "/rpc/db",
            ["list_assistant_schedules", assistant_id, offset, limit],
        )
        return [AiAssistantScheduleLink(**r) for r in result]

    def create_scheduled_task_for_assistant(
        self,
        assistant_id: str,
        name: str,
        message: str,
        schedule_type: str = "once",
        schedule_expression: str = "",
        run_at: Optional[str] = None,
        cron_expression: Optional[str] = None,
        max_executions: Optional[int] = None,
        notification_email: str = "",
    ) -> str:
        """Create a scheduled task and connect it to an AI assistant.

        This is a convenience method that:
        1. Creates a scheduled task via create_scheduled_task RPC.
        2. Connects the task to the assistant via connect_assistant_to_schedule.

        Args:
            assistant_id: The assistant's UUID.
            name: Task name.
            message: The message/prompt for the task.
            schedule_type: 'once', 'recurring', or 'interval'.
            schedule_expression: Cron expression (for recurring) or interval (for interval).
                Ignored if run_at is provided.
            run_at: ISO 8601 timestamp for one-shot tasks. Sets schedule_type='once'.
            cron_expression: Alias for schedule_expression with schedule_type='recurring'.
            max_executions: Maximum number of executions (null = unlimited).
            notification_email: Email for notifications.

        Returns:
            str: The created scheduled task UUID.
        """
        if run_at:
            schedule_type = "once"
            schedule_expression = run_at
        elif cron_expression:
            schedule_type = "recurring"
            schedule_expression = cron_expression

        task_config = {
            "message": message,
            "llm": "auto",
            "system_prompt": "",
        }
        result = self._post(
            "/rpc/db",
            [
                "create_scheduled_task",
                name,
                f"Auto-created for assistant {assistant_id}",
                schedule_type,
                schedule_expression,
                "agent_task",
                task_config,
                max_executions,
                None,  # expires_at
                notification_email,
            ],
        )
        task_id = result.get("id") if isinstance(result, dict) else result
        # Connect to assistant
        self._post(
            "/rpc/db",
            ["connect_assistant_to_schedule", assistant_id, task_id],
        )
        return task_id

    def create_event_type(
        self,
        name: str,
        description: str = "",
        payload_schema: Optional[Dict[str, Any]] = None,
    ) -> "AiAssistantEventType":
        """Create a custom event type that assistants can subscribe to and emit.

        Args:
            name: Name of the event type (max 200 chars, must not collide with built-in types).
            description: Optional description (max 5000 chars).
            payload_schema: Optional JSON schema for event payloads.

        Returns:
            AiAssistantEventType: The created event type.
        """
        from h2ogpte.types import AiAssistantEventType

        result = self._post(
            "/rpc/db",
            ["create_event_type", name, description, payload_schema],
        )
        return AiAssistantEventType(**result)

    def list_event_types(
        self,
        assistant_id: Optional[str] = None,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantEventType"]:
        """List custom event types.

        Args:
            assistant_id: Optional assistant ID to include subscription status for.
            offset: Pagination offset.
            limit: Maximum number of results.

        Returns:
            List[AiAssistantEventType]: List of event types.
        """
        from h2ogpte.types import AiAssistantEventType

        result = self._post(
            "/rpc/db",
            ["list_event_types", limit, offset, assistant_id],
        )
        return [AiAssistantEventType(**r) for r in result]

    def get_event_type(
        self,
        event_type_id: str,
    ) -> "AiAssistantEventType":
        """Get a custom event type by ID.

        Args:
            event_type_id: The event type's UUID.

        Returns:
            AiAssistantEventType: The event type.
        """
        from h2ogpte.types import AiAssistantEventType

        result = self._post(
            "/rpc/db",
            ["get_event_type", event_type_id],
        )
        return AiAssistantEventType(**result)

    def delete_event_type(
        self,
        event_type_id: str,
    ) -> None:
        """Delete a custom event type. Only the creator can delete.

        Cascades to all subscriptions.

        Args:
            event_type_id: The event type's UUID.
        """
        self._post(
            "/rpc/db",
            ["delete_event_type", event_type_id],
        )

    def subscribe_assistant_to_event_type(
        self,
        assistant_id: str,
        event_type_id: str,
    ) -> "AiAssistantEventSubscription":
        """Subscribe an assistant to a custom event type.

        Idempotent — re-subscribing returns the existing subscription.

        Args:
            assistant_id: The assistant's UUID.
            event_type_id: The event type's UUID.

        Returns:
            AiAssistantEventSubscription: The subscription record.
        """
        from h2ogpte.types import AiAssistantEventSubscription

        result = self._post(
            "/rpc/db",
            ["subscribe_to_event_type", assistant_id, event_type_id],
        )
        return AiAssistantEventSubscription(**result)

    def unsubscribe_assistant_from_event_type(
        self,
        assistant_id: str,
        event_type_id: str,
    ) -> None:
        """Unsubscribe an assistant from a custom event type.

        Args:
            assistant_id: The assistant's UUID.
            event_type_id: The event type's UUID.
        """
        self._post(
            "/rpc/db",
            ["unsubscribe_from_event_type", assistant_id, event_type_id],
        )

    def list_assistant_event_subscriptions(
        self,
        assistant_id: str,
    ) -> List["AiAssistantEventSubscription"]:
        """List an assistant's event type subscriptions.

        Args:
            assistant_id: The assistant's UUID.

        Returns:
            List[AiAssistantEventSubscription]: List of subscriptions.
        """
        from h2ogpte.types import AiAssistantEventSubscription

        result = self._post(
            "/rpc/db",
            ["list_event_subscriptions", assistant_id],
        )
        return [AiAssistantEventSubscription(**r) for r in result]

    def emit_event(
        self,
        assistant_id: str,
        event_type_name: str,
        payload: Optional[Dict[str, Any]] = None,
        target_assistant_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Emit a custom event that wakes subscribed sleeping assistants.

        This goes through the REST API which handles Redis wake event dispatch.

        Args:
            assistant_id: The emitting assistant's UUID.
            event_type_name: Name of the event type to emit.
            payload: Optional event payload data.
            target_assistant_ids: Optional list of specific assistant IDs to target.

        Returns:
            dict: Response with 'status' and 'woken_count' keys.
        """
        body: Dict[str, Any] = {"event_type_name": event_type_name}
        if payload is not None:
            body["payload"] = payload
        if target_assistant_ids is not None:
            body["target_assistant_ids"] = target_assistant_ids
        result = self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/emit_event",
            body,
        )
        return result

    def send_inter_assistant_message(
        self,
        assistant_id: str,
        recipient_assistant_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Send a direct message from one assistant to another.

        Triggers a wake event on the recipient assistant.
        This goes through the REST API which handles Redis wake event dispatch.

        Args:
            assistant_id: The sender assistant's UUID.
            recipient_assistant_id: The recipient assistant's UUID.
            content: Message content (max 100000 chars).
            metadata: Optional metadata dict.

        Returns:
            str: The created message UUID.
        """
        body: Dict[str, Any] = {
            "recipient_assistant_id": recipient_assistant_id,
            "content": content,
        }
        if metadata is not None:
            body["metadata"] = metadata
        result = self._post_rest(
            f"/api/v1/ai_assistants/{assistant_id}/send_to_assistant",
            body,
        )
        return (
            result.get("id", str(result)) if isinstance(result, dict) else str(result)
        )

    def create_forum(
        self,
        name: str,
        description: str = "",
    ) -> str:
        """Create a new forum.

        Args:
            name: Name of the forum (must be unique per user).
            description: Optional description.

        Returns:
            str: The ID of the created forum.
        """
        result = self._post(
            "/rpc/db",
            ["create_forum", name, description],
        )
        return result["id"]

    def get_forum(self, forum_id: str) -> "Forum":
        """Get details of a forum.

        Args:
            forum_id: The forum's UUID.

        Returns:
            Forum: The forum details.
        """
        from h2ogpte.types import Forum

        result = self._post("/rpc/db", ["get_forum", forum_id])
        return Forum(**result)

    def list_forums(
        self,
        offset: int = 0,
        limit: int = 100,
        name_filter: Optional[str] = None,
    ) -> List["Forum"]:
        """List forums accessible to the current user.

        Args:
            offset: Pagination offset.
            limit: Maximum number of results.
            name_filter: Optional name filter (substring match).

        Returns:
            List[Forum]: List of forums.
        """
        from h2ogpte.types import Forum

        result = self._post(
            "/rpc/db",
            ["list_forums", offset, limit, name_filter],
        )
        return [Forum(**r) for r in result]

    def update_forum(
        self,
        forum_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> None:
        """Update a forum's configuration.

        Args:
            forum_id: The forum's UUID.
            name: New name (optional).
            description: New description (optional).
        """
        self._post(
            "/rpc/db",
            ["update_forum", forum_id, name, description],
        )

    def delete_forum(self, forum_id: str) -> None:
        """Delete a forum.

        Args:
            forum_id: The forum's UUID.
        """
        self._post("/rpc/db", ["delete_forum", forum_id])

    def share_forum(
        self,
        forum_id: str,
        username: str,
        access_mode: str = "read",
    ) -> None:
        """Share a forum with another user.

        Args:
            forum_id: The forum's UUID.
            username: The username to share with.
            access_mode: Access level - 'read', 'write', or 'read_write'.
        """
        self._post(
            "/rpc/db",
            ["share_forum", forum_id, username, access_mode],
        )

    def unshare_forum(
        self,
        forum_id: str,
        username: str,
    ) -> None:
        """Remove sharing for a forum.

        Args:
            forum_id: The forum's UUID.
            username: The username to unshare from.
        """
        self._post(
            "/rpc/db",
            ["unshare_forum", forum_id, username],
        )

    def create_forum_post(
        self,
        forum_id: str,
        content: str,
        parent_post_id: Optional[str] = None,
        assistant_id: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Create a post on a forum.

        Creates the post via the REST API. Sleeping assistants connected
        to this forum are automatically woken via a push to the event
        queue.

        Args:
            forum_id: The forum's UUID.
            content: The post content.
            parent_post_id: Optional parent post ID for threading (reply).
            assistant_id: Optional assistant ID if posting as an assistant.
            file_ids: Optional list of file UUIDs to attach.
            metadata: Optional metadata dict for custom key-value pairs.
                Note: the 'pinned' key is stripped server-side; use pin_forum_post() instead.

        Returns:
            str: The ID of the created post.
        """
        # All posts go through REST API which triggers wake events
        # for sleeping assistants connected to this forum.
        body: dict = {"content": content}
        if parent_post_id is not None:
            body["parent_post_id"] = parent_post_id
        if assistant_id is not None:
            body["author_assistant_id"] = assistant_id
        if file_ids is not None:
            body["file_ids"] = file_ids
        if metadata is not None:
            body["metadata"] = metadata
        result = self._post_rest(
            f"/api/v1/forums/{forum_id}/posts",
            body,
        )
        return result["id"]

    def reply_to_forum_post(
        self,
        forum_id: str,
        post_id: str,
        content: str,
        assistant_id: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Reply to a specific post in a forum.

        Creates a reply via the REST API endpoint, which also triggers
        wake events for sleeping assistants connected to the forum.

        Args:
            forum_id: The forum's UUID.
            post_id: The parent post's UUID to reply to.
            content: The reply content.
            assistant_id: Optional AI assistant UUID to post as.
            file_ids: Optional list of file UUIDs to attach.
            metadata: Optional metadata dict.

        Returns:
            str: The ID of the created reply post.
        """
        body: dict = {"content": content}
        if assistant_id is not None:
            body["author_assistant_id"] = assistant_id
        if file_ids is not None:
            body["file_ids"] = file_ids
        if metadata is not None:
            body["metadata"] = metadata
        result = self._post_rest(
            f"/api/v1/forums/{forum_id}/posts/{post_id}/reply",
            body,
        )
        return result["id"]

    def list_forum_posts(
        self,
        forum_id: str,
        offset: int = 0,
        limit: int = 50,
        sort_by: str = "newest",
        parent_post_id: Optional[str] = None,
        since: Optional[datetime.datetime] = None,
    ) -> List["ForumPost"]:
        """List posts in a forum.

        Args:
            forum_id: The forum's UUID.
            offset: Pagination offset.
            limit: Maximum number of results.
            sort_by: Sort order ('top', 'newest', or 'oldest').
            parent_post_id: Filter to replies of a specific post.
            since: Optional cutoff timestamp — only return posts created
                after this time.

        Returns:
            List[ForumPost]: List of posts.
        """
        from h2ogpte.types import ForumPost

        since_str = since.isoformat() if since is not None else None
        result = self._post(
            "/rpc/db",
            [
                "list_forum_posts",
                forum_id,
                offset,
                limit,
                sort_by,
                parent_post_id,
                since_str,
            ],
        )
        return [ForumPost(**r) for r in result]

    def get_forum_post(self, post_id: str) -> "ForumPost":
        """Get a single forum post.

        Args:
            post_id: The post's UUID.

        Returns:
            ForumPost: The post details.
        """
        from h2ogpte.types import ForumPost

        result = self._post("/rpc/db", ["get_forum_post", post_id])
        return ForumPost(**result)

    def update_forum_post(
        self,
        post_id: str,
        content: str,
    ) -> None:
        """Update a forum post (author only).

        Args:
            post_id: The post's UUID.
            content: New content.
        """
        self._post("/rpc/db", ["update_forum_post", post_id, content])

    def delete_forum_post(self, post_id: str) -> None:
        """Delete a forum post.

        Args:
            post_id: The post's UUID.
        """
        self._post("/rpc/db", ["delete_forum_post", post_id])

    def vote_on_forum_post(
        self,
        post_id: str,
        vote: int,
        assistant_id: Optional[str] = None,
    ) -> None:
        """Vote on a forum post.

        Args:
            post_id: The post's UUID.
            vote: +1 for upvote, -1 for downvote, 0 to clear vote.
            assistant_id: Optional assistant ID if voting as an assistant.
        """
        self._post(
            "/rpc/db",
            ["vote_on_forum_post", post_id, vote, assistant_id],
        )

    def pin_forum_post(
        self,
        post_id: str,
        is_pinned: bool,
    ) -> None:
        """Pin or unpin a forum post (forum owner only).

        Args:
            post_id: The post's UUID.
            is_pinned: True to pin, False to unpin.
        """
        self._post("/rpc/db", ["pin_forum_post", post_id, is_pinned])

    def list_ai_assistant_permissions(
        self,
        assistant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["AiAssistantPermission"]:
        """List sharing permissions for an AI assistant.

        Args:
            assistant_id: The assistant's UUID.
            offset: Number of records to skip (default 0).
            limit: Maximum number of records to return (default 100, max 100).

        Returns:
            List[AiAssistantPermission]: List of permission objects with
                ``username``, ``can_read``, ``can_edit`` fields.
        """
        from h2ogpte.types import AiAssistantPermission

        result = self._post(
            "/rpc/db",
            ["list_ai_assistant_permissions", assistant_id, offset, limit],
        )
        items = result if isinstance(result, list) else []
        return [AiAssistantPermission(**item) for item in items]

    def list_forum_permissions(
        self,
        forum_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> List["ForumPermission"]:
        """List sharing permissions for a forum.

        Args:
            forum_id: The forum's UUID.
            offset: Number of records to skip (default 0).
            limit: Maximum number of records to return (default 100, max 100).

        Returns:
            List[ForumPermission]: List of permission objects with
                ``username``, ``can_read``, ``can_edit`` fields.
        """
        from h2ogpte.types import ForumPermission

        result = self._post(
            "/rpc/db",
            ["list_forum_permissions", forum_id, offset, limit],
        )
        items = result if isinstance(result, list) else []
        return [ForumPermission(**item) for item in items]

    def create_assistant_webhook(
        self,
        assistant_id: str,
        name: str,
        description: str = "",
        rate_limit_per_minute: int = 10,
    ) -> Dict[str, Any]:
        """Create a webhook endpoint for an AI assistant.

        External systems can wake the assistant by POSTing to the webhook URL.
        The token is returned only once — save it immediately.

        Args:
            assistant_id: ID of the assistant.
            name: Human-readable name for the webhook.
            description: Optional description.
            rate_limit_per_minute: Max invocations per minute (default 10).

        Returns:
            Dict with 'id', 'token' (shown only once), 'name', and webhook URL.
        """
        return self._post(
            f"/api/v1/ai_assistants_webhooks/{assistant_id}",
            {
                "name": name,
                "description": description,
                "rate_limit_per_minute": rate_limit_per_minute,
            },
        )

    def list_assistant_webhooks(self, assistant_id: str) -> List[Dict[str, Any]]:
        """List webhooks for an AI assistant (tokens are masked).

        Args:
            assistant_id: ID of the assistant.

        Returns:
            List of webhook dicts with masked tokens.
        """
        result = self._get(f"/api/v1/ai_assistants_webhooks/{assistant_id}")
        return result if isinstance(result, list) else []

    def delete_assistant_webhook(self, assistant_id: str, webhook_id: str) -> None:
        """Delete a webhook endpoint.

        Args:
            assistant_id: ID of the assistant.
            webhook_id: ID of the webhook to delete.
        """
        self._delete(f"/api/v1/ai_assistants_webhooks/{assistant_id}/{webhook_id}")

    def regenerate_assistant_webhook_token(
        self, assistant_id: str, webhook_id: str
    ) -> Dict[str, Any]:
        """Regenerate the token for a webhook (invalidates the old token).

        Args:
            assistant_id: ID of the assistant.
            webhook_id: ID of the webhook.

        Returns:
            Dict with the new 'token' (shown only once).
        """
        return self._post(
            f"/api/v1/ai_assistants_webhooks/{assistant_id}/{webhook_id}/regenerate",
            {},
        )

    def create_slack_integration(
        self,
        name: str,
        workspace_id: str,
        bot_token: str,
        signing_secret: str,
    ) -> Dict[str, Any]:
        """Create a Slack integration for connecting Slack channels as forums.

        Args:
            name: Display name for the integration.
            workspace_id: Slack workspace/team ID (e.g., T01234567).
            bot_token: Slack bot token (xoxb-...).
            signing_secret: Slack signing secret for webhook verification.

        Returns:
            Dict with integration details.
        """
        return self._post(
            "/api/v1/integrations/slack/",
            {
                "name": name,
                "workspace_id": workspace_id,
                "bot_token": bot_token,
                "signing_secret": signing_secret,
            },
        )

    def list_slack_integrations(self) -> List[Dict[str, Any]]:
        """List all Slack integrations for the current user.

        Returns:
            List of Slack integration dicts.
        """
        result = self._get("/api/v1/integrations/slack/")
        return result if isinstance(result, list) else []

    def delete_slack_integration(self, integration_id: str) -> None:
        """Delete a Slack integration and all linked channels.

        Args:
            integration_id: ID of the Slack integration.
        """
        self._delete(f"/api/v1/integrations/slack/{integration_id}")

    def link_slack_channel(
        self,
        integration_id: str,
        channel_id: str,
        channel_name: str = "",
        forum_name: str = "",
        sync_direction: str = "bidirectional",
        sync_threads: bool = True,
    ) -> Dict[str, Any]:
        """Link a Slack channel to a forum.

        Creates a new forum backed by the Slack channel. Messages in Slack
        appear as forum posts, and assistant posts appear in Slack.

        Args:
            integration_id: ID of the Slack integration.
            channel_id: Slack channel ID (e.g., C01234567).
            channel_name: Display name of the channel.
            forum_name: Name for the h2ogpte forum (defaults to channel name).
            sync_direction: 'bidirectional', 'slack_to_h2ogpte', or 'h2ogpte_to_slack'.
            sync_threads: Whether to sync Slack threads as forum post threads.

        Returns:
            Dict with channel-forum mapping details.
        """
        return self._post(
            f"/api/v1/integrations/slack/{integration_id}/channels",
            {
                "channel_id": channel_id,
                "channel_name": channel_name,
                "forum_name": forum_name,
                "sync_direction": sync_direction,
                "sync_threads": sync_threads,
            },
        )

    def get_user_approval_config(self, user_id: str) -> "UserApprovalConfig":
        """Get approval governance config for a user. Admin-only.

        Args:
            user_id: The target user's UUID.

        Returns:
            UserApprovalConfig: The approval governance configuration.
        """
        from h2ogpte.types import UserApprovalConfig

        result = self._get(f"/api/v1/admin/users/{user_id}/approval_config")
        if not result or result == {}:
            return UserApprovalConfig(user_id=user_id)
        return UserApprovalConfig(**result)

    def set_user_approval_config(
        self,
        user_id: str,
        approval_user_id: Optional[str] = None,
        allow_custom_approval_text: bool = False,
        allow_policy_override: bool = True,
        allow_approval_user_change: bool = False,
    ) -> Dict[str, Any]:
        """Set approval governance config for a user. Admin-only.

        Args:
            user_id: The target user's UUID.
            approval_user_id: UUID of the designated approval user (None = clear).
            allow_custom_approval_text: Allow user to set custom approval text.
            allow_policy_override: Allow user to change tool action policies.
            allow_approval_user_change: Allow user to change their approval user.

        Returns:
            Dict with 'id' and 'status'.
        """
        import json as _json

        headers = self._get_auth_header()
        headers["Content-Type"] = "application/json"
        res = self._client.put(
            self._address + f"/api/v1/admin/users/{user_id}/approval_config",
            content=_json.dumps(
                {
                    "approval_user_id": approval_user_id or "",
                    "allow_custom_approval_text": allow_custom_approval_text,
                    "allow_policy_override": allow_policy_override,
                    "allow_approval_user_change": allow_approval_user_change,
                }
            ).encode(),
            timeout=60,
            headers=headers,
        )
        self._raise_error_if_any(res)
        return res.json()

    def list_approvals_routed_to_me(
        self,
        offset: int = 0,
        limit: int = 50,
    ) -> List["ApprovalRequestWithAssistant"]:
        """List pending approval requests routed to the current user.

        Args:
            offset: Pagination offset.
            limit: Maximum number of results (max 100).

        Returns:
            List of approval requests routed to the current user.
        """
        from h2ogpte.types import ApprovalRequestWithAssistant

        result = self._get(
            f"/api/v1/ai_assistants_approvals/routed_to_me?offset={offset}&limit={limit}"
        )
        items = result if isinstance(result, list) else []
        return [ApprovalRequestWithAssistant(**item) for item in items]

    def get_default_memory_blocks(self) -> dict:
        """Get the current user's default memory blocks.

        Returns a dict with key ``'defaults'`` containing a dict with keys
        ``'llm'`` and ``'agent'``, each either a memory block dict or ``None``.

        The two scopes are independent — LLM default applies to non-agent
        chats, agent default applies to agent chats. No cascade between them.

        Example::

            result = client.get_default_memory_blocks()
            # result['defaults']['llm']    -> MemoryBlock dict or None
            # result['defaults']['agent']  -> MemoryBlock dict or None

        """
        return self._get("/api/v1/users/current/default_memory_blocks")

    def set_default_memory_block(
        self,
        scope: str,
        memory_block_id: Optional[str] = None,
    ) -> dict:
        """Set or clear a default memory block for a given scope.

        Args:
            scope: Which scope to set. Must be ``'llm'`` or ``'agent'``.
            memory_block_id: UUID of the memory block to set as default,
                or ``None`` to clear the default for this scope.

        Returns:
            A dict with ``'scope'`` and ``'memory_block'`` (the set
            block or ``None`` if cleared).

        Raises:
            ValueError: If scope is not 'llm' or 'agent'.

        Example::

            # Set default for LLM (non-agent) chats
            client.set_default_memory_block('llm', '<block-id>')

            # Set default for agent chats
            client.set_default_memory_block('agent', '<block-id>')

            # Clear the agent default
            client.set_default_memory_block('agent', None)

        """
        if scope not in ("llm", "agent"):
            raise ValueError('scope must be "llm" or "agent"')
        endpoint = "/api/v1/users/current/default_memory_blocks"
        body = {"scope": scope, "memory_block_id": memory_block_id}
        headers = self._get_auth_header()
        headers["Content-Type"] = "application/json"
        content = json.dumps(body, allow_nan=False, separators=(",", ":"))
        import requests as _requests

        res = _requests.put(
            self._address + endpoint,
            data=content,
            headers=headers,
            verify=self._verify,
            timeout=self.TIMEOUT,
        )
        self._raise_error_if_any(res)
        if res.status_code == 204:
            return None
        return res.json()
