# tests/test_fetch.py

import pytest
import requests
import json
from opticedge_cloud_utils.fetch import fetch_url, fetch_image, URLResponse, ImageResponse

# ------------------- Helpers -------------------

def make_response(status_code=200, content=b"", content_type="application/json", json_data=None, headers=None):
    """
    Create a proper requests.Response object for testing.
    Do NOT assign to response.text; requests computes it automatically from _content.
    """
    response = requests.Response()
    response.status_code = status_code

    if json_data is not None:
        response._content = json.dumps(json_data).encode("utf-8")
    else:
        response._content = content

    # Set headers properly
    response.headers = headers or {}
    response.headers["Content-Type"] = content_type
    response.headers["Content-Length"] = str(len(response._content))
    return response

def patch_session(monkeypatch, response_or_func):
    """
    Patch requests.Session to return a mocked response.
    """
    class MockSession:
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_val, exc_tb):
            return False
        def get(self, *args, **kwargs):
            if callable(response_or_func):
                return response_or_func(*args, **kwargs)
            return response_or_func
    monkeypatch.setattr("requests.Session", lambda: MockSession())

# ------------------- fetch_url tests -------------------

def test_fetch_url_json_success(monkeypatch):
    resp_obj = make_response(json_data={"key": "value"})
    patch_session(monkeypatch, resp_obj)
    resp = fetch_url("https://example.com", response_type="json")
    assert isinstance(resp, URLResponse)
    assert resp.content == {"key": "value"}

def test_fetch_url_text_success(monkeypatch):
    resp_obj = make_response(content=b"Hello world", content_type="text/plain")
    patch_session(monkeypatch, resp_obj)
    resp = fetch_url("https://example.com", response_type="text")
    assert resp.content == "Hello world"

def test_fetch_url_invalid_json(monkeypatch):
    resp_obj = make_response(content=b"Not JSON", content_type="application/json")
    patch_session(monkeypatch, resp_obj)
    with pytest.raises(RuntimeError):
        fetch_url("https://example.com", response_type="json")

def test_fetch_url_retry_logic(monkeypatch):
    calls = []

    def mock_get(*args, **kwargs):
        if len(calls) < 2:
            calls.append(1)
            return make_response(status_code=500)
        return make_response(json_data={"ok": True})

    patch_session(monkeypatch, mock_get)
    resp = fetch_url("https://example.com", retries=3, response_type="json")
    assert resp.content == {"ok": True}
    assert len(calls) == 2  # retried twice

def test_fetch_url_non_retryable_error(monkeypatch):
    patch_session(monkeypatch, make_response(status_code=404))
    with pytest.raises(RuntimeError):
        fetch_url("https://example.com", retries=1, response_type="json")

def test_fetch_url_extra_retryable(monkeypatch):
    calls = []

    def mock_get(*args, **kwargs):
        if not calls:
            calls.append(1)
            return make_response(status_code=418)  # retryable only via extra
        return make_response(json_data={"ok": True})

    patch_session(monkeypatch, mock_get)
    resp = fetch_url("https://example.com", retries=2, extra_retryable_status_codes={418}, response_type="json")
    assert resp.content == {"ok": True}

# ------------------- fetch_image tests -------------------

def test_fetch_image_success(monkeypatch):
    resp_obj = make_response(content=b"fakeimagebytes", content_type="image/png")
    patch_session(monkeypatch, resp_obj)
    resp = fetch_image("https://example.com/image.png")
    assert isinstance(resp, ImageResponse)
    assert resp.content == b"fakeimagebytes"
    assert resp.content_type == "image/png"
    assert resp.content_length == len(b"fakeimagebytes")
    assert resp.status_code == 200

def test_fetch_image_missing_headers(monkeypatch):
    # No Content-Type or Content-Length headers
    resp_obj = make_response(content=b"imgdata", content_type="")
    resp_obj.headers.pop("Content-Type", None)
    resp_obj.headers.pop("Content-Length", None)
    patch_session(monkeypatch, resp_obj)
    resp = fetch_image("https://example.com/image.png")
    assert resp.content_type == "application/octet-stream"
    assert resp.content_length is None

def test_fetch_image_retry_logic(monkeypatch):
    calls = []

    def mock_get(*args, **kwargs):
        if not calls:
            calls.append(1)
            return make_response(status_code=503)
        return make_response(content=b"data", content_type="image/jpeg")

    patch_session(monkeypatch, mock_get)
    resp = fetch_image("https://example.com/image.jpg", retries=2)
    assert resp.content == b"data"
    assert resp.content_type == "image/jpeg"

def test_fetch_image_non_retryable_error(monkeypatch):
    patch_session(monkeypatch, make_response(status_code=400, content_type="image/png"))
    with pytest.raises(RuntimeError):
        fetch_image("https://example.com/image.jpg", retries=1)