# opticedge_cloud_utils/fetch.py (updated)

from typing import Any, Literal, Optional
from dataclasses import dataclass
import requests
import random
import time

DEFAULT_RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

@dataclass
class ImageResponse:
    content: bytes
    content_type: str
    content_length: int | None
    status_code: int

@dataclass
class URLResponse:
    status_code: int
    headers: dict
    content: Any

def fetch_url(
    url: str,
    params: Optional[dict] = None,
    retries: int = 4,
    timeout: int = 20,
    extra_retryable_status_codes: set[int] | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
    base_delay: float = 0.5,
    max_delay: float = 8.0,
    response_type: Literal["text", "json"] = "text",
) -> URLResponse:
    retryable_status_codes = set(DEFAULT_RETRYABLE_STATUS_CODES)
    if extra_retryable_status_codes:
        retryable_status_codes.update(extra_retryable_status_codes)

    headers = {
        "User-Agent": user_agent,
        "Accept": (
            "text/html,application/xhtml+xml,application/xml;q=0.9,"
            "image/avif,image/webp,*/*;q=0.8"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.google.com/",
        "Connection": "keep-alive",
    }

    with requests.Session() as session:
        for attempt in range(retries + 1):
            try:
                response = session.get(url, headers=headers, timeout=timeout, params=params)
                if response.status_code in retryable_status_codes:
                    raise requests.HTTPError(f"retryable status {response.status_code}", response=response)
                response.raise_for_status()

                content = response.json() if response_type == "json" else response.text
                return URLResponse(status_code=response.status_code, headers=dict(response.headers), content=content)

            except requests.RequestException as exc:
                retryable = exc.response is not None and exc.response.status_code in retryable_status_codes
                if attempt >= retries or not retryable:
                    raise RuntimeError(
                        f"Request failed after {attempt + 1} attempt(s). Retryable={retryable}. Error: {exc}"
                    ) from exc
                delay = random.uniform(0, min(max_delay, base_delay * (2 ** attempt)))
                time.sleep(delay)

    raise RuntimeError("unreachable")

def fetch_image(
    url: str,
    params: Optional[dict] = None,
    retries: int = 4,
    timeout: int = 20,
    extra_retryable_status_codes: set[int] | None = None,
    user_agent: str = DEFAULT_USER_AGENT,
    base_delay: float = 0.5,
    max_delay: float = 8.0,
) -> ImageResponse:
    retryable_status_codes = set(DEFAULT_RETRYABLE_STATUS_CODES)
    if extra_retryable_status_codes:
        retryable_status_codes.update(extra_retryable_status_codes)

    headers = {
        "User-Agent": user_agent,
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        "Referer": "https://www.google.com/",
        "Connection": "keep-alive",
    }

    with requests.Session() as session:
        for attempt in range(retries + 1):
            try:
                response = session.get(url, headers=headers, timeout=timeout, params=params, stream=True)
                if response.status_code in retryable_status_codes:
                    raise requests.HTTPError(f"retryable status {response.status_code}", response=response)
                response.raise_for_status()

                content_type = response.headers.get("Content-Type", "application/octet-stream")
                content_length = response.headers.get("Content-Length")
                return ImageResponse(
                    content=response.content,
                    content_type=content_type,
                    content_length=int(content_length) if content_length else None,
                    status_code=response.status_code,
                )

            except requests.RequestException as exc:
                retryable = exc.response is not None and exc.response.status_code in retryable_status_codes
                if attempt >= retries or not retryable:
                    raise RuntimeError(
                        f"Image request failed after {attempt + 1} attempt(s). Retryable={retryable}. Error: {exc}"
                    ) from exc
                delay = random.uniform(0, min(max_delay, base_delay * (2 ** attempt)))
                time.sleep(delay)

    raise RuntimeError("unreachable")