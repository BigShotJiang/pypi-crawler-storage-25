"""Tests for ``mgf-common catch-up`` subcommand."""

from __future__ import annotations

import argparse
import io
import json
from contextlib import redirect_stdout
from typing import TYPE_CHECKING

import pytest

from mgf.common.cli._catch_up import (
    _apply_bootstrap_claude_md_markers,
    _apply_bump_pin,
    _check_claude_md,
    _check_claude_settings,
    _check_closed_box_leaks,
    _check_four_gates,
    _check_pyproject_pin,
    _check_v01_patterns,
    _detect_kind,
    _extract_auto_block,
    _has_pip_tools_layout,
    _is_private_module,
    _pin_is_stale,
    _splice_auto_block,
    add_catch_up_args,
    run_catch_up,
)
from mgf.common.cli._init_project import (
    CLAUDE_MD_BEGIN_MARKER,
    CLAUDE_MD_END_MARKER,
    _render_claude_md,
)

if TYPE_CHECKING:
    from pathlib import Path


def _make_args(
    path: Path,
    *,
    apply: bool = False,
    name: str | None = None,
    kind: str | None = None,
) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    add_catch_up_args(parser)
    argv = ["--path", str(path)]
    if apply:
        argv.append("--apply")
    if name is not None:
        argv.extend(["--name", name])
    if kind is not None:
        argv.extend(["--kind", kind])
    return parser.parse_args(argv)


def _seed_minimal_project(target: Path, *, with_pyproject: bool = True) -> None:
    """Create a minimal project layout."""
    if with_pyproject:
        (target / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = ["mgf-common>=0.5.0,<0.6"]\n',
            encoding="utf-8",
        )


# ---------------------------------------------------------------------------
# Auto-block extraction + splicing.
# ---------------------------------------------------------------------------


class TestAutoBlockExtraction:
    def test_extract_returns_content_between_markers(self) -> None:
        rendered = _render_claude_md("demo", "cli")
        block = _extract_auto_block(rendered)
        # Block must be non-empty and contain the standing-instructions
        # heading + the rule index.
        assert "Standing instructions" in block
        assert "DP-01" in block
        # Markers themselves should NOT be inside the extracted block.
        assert CLAUDE_MD_BEGIN_MARKER not in block
        assert CLAUDE_MD_END_MARKER not in block

    def test_extract_empty_when_markers_missing(self) -> None:
        assert _extract_auto_block("# No markers here\nJust content") == ""

    def test_splice_replaces_block_in_place(self) -> None:
        rendered = _render_claude_md("demo", "cli")
        new_block = "\nNEW BLOCK CONTENT\n"
        spliced = _splice_auto_block(rendered, new_block)
        # Markers preserved.
        assert CLAUDE_MD_BEGIN_MARKER in spliced
        assert CLAUDE_MD_END_MARKER in spliced
        # New content appears between them.
        assert "NEW BLOCK CONTENT" in spliced
        # Old content (rules, etc.) gone.
        assert "DP-01" not in spliced

    def test_splice_preserves_text_around_markers(self) -> None:
        before = "# Project Title\n\nProject-specific stuff above.\n\n"
        original = (
            before
            + CLAUDE_MD_BEGIN_MARKER + "\n"
            + "OLD CONTENT\n"
            + CLAUDE_MD_END_MARKER + " -->\n"
            + "## Project-specific lookup\n\nTeam content.\n"
        )
        spliced = _splice_auto_block(original, "\nNEW\n")
        assert "Project-specific stuff above." in spliced
        assert "Team content." in spliced
        assert "OLD CONTENT" not in spliced
        assert "\nNEW\n" in spliced


# ---------------------------------------------------------------------------
# Individual audit checks.
# ---------------------------------------------------------------------------


class TestPinCheck:
    def test_no_pyproject_warns(self, tmp_path: Path) -> None:
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        assert "no pyproject.toml" in finding.detail.lower()

    def test_current_pin_returns_ok(self, tmp_path: Path) -> None:
        # v0.12.0+: the seed uses ``>=0.5.0,<0.6`` which IS stale
        # against today's running mgf-common (>=0.11) — so we
        # need a pin that's actually current. Use the running
        # version's window.
        from mgf.common import __version__ as current

        major, minor = current.split(".")[:2]
        upper_minor = int(minor) + 1
        (tmp_path / "pyproject.toml").write_text(
            f'[project]\nname = "demo"\ndependencies = '
            f'["mgf-common>={current},<{major}.{upper_minor}"]\n',
            encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "ok"
        assert finding.fix is None

    def test_stale_pin_warns_with_fix(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # The pin <0.2 cannot accommodate the running 0.11.x. Stale.
        # Force non-editable so the auto-rewrite path applies — our
        # own dev install IS editable, but the existing test pins
        # the PyPI-install behaviour, so we simulate that. The
        # editable-refusal path is covered by the dedicated
        # TestEditableInstallPinGuard class below.
        from mgf.common.cli import _catch_up as cu_module
        monkeypatch.setattr(cu_module, "_is_editable_install", lambda: False)
        _seed_minimal_project(tmp_path)
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        assert "STALE" in finding.detail
        assert finding.fix is not None  # has a mechanical fix

    def test_no_mgf_dep_warns(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\ndependencies = []\n',
            encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"


class TestPinStaleness:
    """``_pin_is_stale`` core staleness detection."""

    def test_pin_with_no_upper_bound_not_flagged(self) -> None:
        # A pin like `>=0.5.0` (no upper bound) should NOT be flagged
        # as stale — we don't know the user's intent.
        assert _pin_is_stale(">=0.5.0", "0.11.3") is False

    def test_pin_excluding_current_is_stale(self) -> None:
        assert _pin_is_stale(">=0.1.0,<0.2", "0.11.3") is True
        assert _pin_is_stale(">=0.6.0,<0.8", "0.11.3") is True
        assert _pin_is_stale(">=0.10.0,<0.11", "0.11.0") is True

    def test_pin_including_current_not_stale(self) -> None:
        assert _pin_is_stale(">=0.11.0,<0.13", "0.11.3") is False
        assert _pin_is_stale(">=0.5.0,<1.0", "0.11.3") is False

    def test_pin_at_exact_upper_bound_is_stale(self) -> None:
        # `<0.11` excludes 0.11.0 (strict-less-than).
        assert _pin_is_stale(">=0.10.0,<0.11", "0.11.0") is True

    def test_unparseable_constraint_not_flagged(self) -> None:
        # Non-numeric, weird shape, etc. — better to under-flag.
        assert _pin_is_stale("== latest", "0.11.3") is False
        assert _pin_is_stale("garbage", "0.11.3") is False


class TestApplyBumpPin:
    """``_apply_bump_pin`` rewrites the pin line conservatively."""

    def test_simple_pin_rewrite(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\n'
            'dependencies = [\n    "mgf-common>=0.1.0,<0.2",\n]\n',
            encoding="utf-8",
        )
        result = _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1.0,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        assert "mgf-common>=0.11.0,<0.13" in content
        assert "mgf-common>=0.1.0,<0.2" not in content
        assert "bumped pin" in result

    def test_extras_in_pin_preserved(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\n'
            'dependencies = ["mgf-common[fastapi]>=0.6.0,<0.8"]\n',
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common[fastapi]",
            old_constraint=">=0.6.0,<0.8",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        assert "mgf-common[fastapi]>=0.11.0,<0.13" in content
        assert "[fastapi]" in content  # extras preserved

    def test_backup_file_written(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "x"\ndependencies = ["mgf-common>=0.1,<0.2"]\n',
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        backups = list(tmp_path.glob("pyproject.toml.bak.*"))
        assert len(backups) == 1
        # Backup contains the original.
        assert ">=0.1,<0.2" in backups[0].read_text()
        # Live file has the new pin.
        assert ">=0.11.0,<0.13" in (tmp_path / "pyproject.toml").read_text()

    def test_other_lines_untouched(self, tmp_path: Path) -> None:
        # Conservative: only the mgf-common line changes; everything
        # else stays byte-for-byte.
        (tmp_path / "pyproject.toml").write_text(
            "[project]\n"
            'name = "x"\n'
            'dependencies = [\n'
            '    "click>=8.1",\n'
            '    "pyyaml>=6.0",\n'
            '    "mgf-common>=0.1.0,<0.2",\n'
            '    "rich>=13.7",\n'
            "]\n"
            "[tool.ruff]\n"
            "line-length = 100\n",
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1.0,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        # Other deps untouched.
        assert '"click>=8.1"' in content
        assert '"pyyaml>=6.0"' in content
        assert '"rich>=13.7"' in content
        # Ruff section untouched.
        assert "[tool.ruff]" in content
        assert "line-length = 100" in content
        # mgf-common line bumped.
        assert "mgf-common>=0.11.0,<0.13" in content

    def test_pin_line_with_comments_around_preserved(self, tmp_path: Path) -> None:
        # VManager-shape: the dep line is surrounded by a long comment.
        # Both the comment and adjacent context must survive.
        (tmp_path / "pyproject.toml").write_text(
            "[project]\n"
            'name = "vmanager"\n'
            "dependencies = [\n"
            "    # Comment above explaining the dep.\n"
            "    # Multiple lines of context.\n"
            '    "mgf-common>=0.1.0,<0.2",\n'
            "    # Comment below.\n"
            "]\n",
            encoding="utf-8",
        )
        _apply_bump_pin(
            tmp_path,
            extras_part="mgf-common",
            old_constraint=">=0.1.0,<0.2",
            new_constraint=">=0.11.0,<0.13",
        )
        content = (tmp_path / "pyproject.toml").read_text()
        assert "Comment above" in content
        assert "Multiple lines of context." in content
        assert "Comment below" in content
        assert "mgf-common>=0.11.0,<0.13" in content


class TestEndToEndPinBump:
    """Verify catch-up's apply path bumps the pin with a real audit run."""

    def test_apply_bumps_stale_pin(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Force non-editable so the auto-rewrite path applies — our
        # dev install is editable but PAPER-20 refuses rewrites for
        # editable installs to avoid producing an unsatisfiable pin.
        from mgf.common.cli import _catch_up as cu_module
        monkeypatch.setattr(cu_module, "_is_editable_install", lambda: False)
        _seed_minimal_project(tmp_path)  # pin = >=0.5.0,<0.6 (stale vs 0.11.x)
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))
        # Pin in pyproject.toml is now bumped to a current 2-minor window.
        content = (tmp_path / "pyproject.toml").read_text()
        assert ">=0.5.0,<0.6" not in content
        # New constraint contains current major + minor.
        from mgf.common import __version__ as current

        assert f">={current}" in content


class TestFourGatesCheck:
    def test_no_pyproject_warns(self, tmp_path: Path) -> None:
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "warn"

    def test_partial_config_lists_missing(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n[tool.ruff]\nline-length = 100\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "warn"
        # ruff present, others not.
        assert "[tool.mypy]" in finding.detail
        assert "filterwarnings" in finding.detail

    def test_full_config_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n"
            "[tool.ruff]\n\n"
            "[tool.mypy]\nstrict = true\n\n"
            '[tool.pytest.ini_options]\nfilterwarnings = ["error"]\n\n'
            "[tool.coverage.report]\nfail_under = 80\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "ok"

    def test_multiline_filterwarnings_array_returns_ok(self, tmp_path: Path) -> None:
        # v0.11.2 fix: parse with tomllib so the multi-line array form
        # (which apiprobe + many real projects use) is recognized.
        # The pre-fix substring-match required the exact single-line
        # `filterwarnings = ["error"]` form and gave a false positive
        # warning on multi-line.
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n"
            "[tool.ruff]\n\n"
            "[tool.mypy]\nstrict = true\n\n"
            "[tool.pytest.ini_options]\n"
            "filterwarnings = [\n"
            '    "error",\n'
            '    "ignore::DeprecationWarning:third_party.*",\n'
            "]\n\n"
            "[tool.coverage.report]\nfail_under = 80\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "ok", (
            f"multi-line filterwarnings array should pass, got "
            f"{finding.severity}: {finding.detail}"
        )

    def test_filterwarnings_without_error_string_warns(self, tmp_path: Path) -> None:
        # If filterwarnings is configured but doesn't contain "error",
        # the gate should fail (TS-04 requires error-level).
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'x'\n"
            "[tool.ruff]\n\n"
            "[tool.mypy]\nstrict = true\n\n"
            '[tool.pytest.ini_options]\nfilterwarnings = ["default"]\n\n'
            "[tool.coverage.report]\nfail_under = 80\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "warn"
        assert "filterwarnings" in finding.detail

    def test_corrupt_pyproject_returns_fail(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[project\nthis is not valid toml\n",
            encoding="utf-8",
        )
        finding = _check_four_gates(tmp_path)
        assert finding.severity == "fail"
        assert "could not parse" in finding.detail.lower()


class TestClaudeMdCheck:
    def test_missing_returns_fail_with_fix(self, tmp_path: Path) -> None:
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "fail"
        assert finding.fix is not None  # has mechanical fix

    def test_existing_with_markers_current_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "docs").mkdir()
        (tmp_path / "docs" / "CLAUDE.md").write_text(
            _render_claude_md("demo", "cli"),
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "ok"

    def test_existing_without_markers_warns(self, tmp_path: Path) -> None:
        (tmp_path / "docs").mkdir()
        (tmp_path / "docs" / "CLAUDE.md").write_text(
            "# Demo Project\n\nNo markers anywhere here.\n",
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "warn"
        assert "BEGIN/END" in finding.detail
        # PAPER-16 (v0.17.2+): catch-up now offers a fix-callable
        # that bootstraps markers + auto-block at the top of the
        # existing file (with backup), instead of pointing at the
        # destructive --force option.
        assert finding.fix is not None

    def test_stale_auto_block_warns_with_fix(self, tmp_path: Path) -> None:
        (tmp_path / "docs").mkdir()
        # Use library kind in the file but check for cli kind — kind
        # affects the quick-start block, so the auto-block content
        # differs.
        (tmp_path / "docs" / "CLAUDE.md").write_text(
            _render_claude_md("demo", "library"),
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "demo", "cli")
        assert finding.severity == "warn"
        assert "stale" in finding.detail
        assert finding.fix is not None  # refreshable


class TestClaudeSettingsCheck:
    def test_missing_warns_with_fix(self, tmp_path: Path) -> None:
        finding = _check_claude_settings(tmp_path, "cli")
        assert finding.severity == "warn"
        assert finding.fix is not None

    def test_existing_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / ".claude").mkdir()
        (tmp_path / ".claude" / "settings.json").write_text("{}", encoding="utf-8")
        finding = _check_claude_settings(tmp_path, "cli")
        assert finding.severity == "ok"


class TestV01PatternsCheck:
    def test_clean_project_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "demo.py").write_text(
            "from mgf.common import bootstrap\n"
            "with bootstrap(app_name='x', app_version='0.1') as ctx:\n"
            "    pass\n",
            encoding="utf-8",
        )
        finding = _check_v01_patterns(tmp_path)
        assert finding.severity == "ok"

    def test_legacy_calls_warn(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "legacy.py").write_text(
            "import mgf.common\n"
            "mgf.common.configure(app_name='x', app_version='0.1')\n"
            "from mgf.common.observability import setup_logging\n"
            "setup_logging(level='INFO')\n",
            encoding="utf-8",
        )
        finding = _check_v01_patterns(tmp_path)
        assert finding.severity == "warn"
        assert "configure(" in finding.detail
        assert "setup_logging(" in finding.detail
        # Catch-up does NOT auto-fix structural migrations.
        assert finding.fix is None

    def test_audit_skips_venv_and_caches(self, tmp_path: Path) -> None:
        # PAPER-14: without skip-dirs, the audit walked into .venv
        # where mgf-common's own deprecated shim definitions live
        # (def setup_logging(...) etc.) and counted them as user-
        # source v0.1 call sites. Skip-dirs eliminates the false
        # positives.
        (tmp_path / ".venv").mkdir()
        (tmp_path / ".venv" / "shim.py").write_text(
            "def setup_logging(*a, **kw):\n    pass\n"
            "def setup_otel(*a, **kw):\n    pass\n"
            "def install_excepthook():\n    pass\n",
            encoding="utf-8",
        )
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / "__pycache__" / "x.py").write_text(
            "setup_logging(level='INFO')\n", encoding="utf-8",
        )
        # No real consumer source — fall-back walks tmp_path itself.
        finding = _check_v01_patterns(tmp_path)
        assert finding.severity == "ok", (
            f"audit should skip .venv/ and __pycache__/, got: "
            f"{finding.detail}"
        )

    def test_audit_skips_tests_dir(self, tmp_path: Path) -> None:
        # tests/ is intentionally exempt — same convention as the
        # closed-box-leak audit.
        (tmp_path / "tests").mkdir()
        (tmp_path / "tests" / "test_legacy.py").write_text(
            "from mgf.common.observability import setup_logging\n"
            "setup_logging(level='INFO')\n",
            encoding="utf-8",
        )
        finding = _check_v01_patterns(tmp_path)
        assert finding.severity == "ok"


# ---------------------------------------------------------------------------
# Editable-install pin handling (PAPER-20).
# ---------------------------------------------------------------------------


class TestEditableInstallPinGuard:
    """When mgf-common is installed editable, catch-up MUST NOT
    auto-rewrite a consumer's pin to the editable __version__ —
    that pin would be unsatisfiable on PyPI. Closes PAPER-20.
    """

    def test_is_editable_install_predicate(self) -> None:
        # The predicate is testable in isolation. We don't pin its
        # value here (depends on how this test run installed
        # mgf-common — likely True in dev, False in CI from wheel).
        # We just confirm the function returns a bool without raising.
        from mgf.common.cli._catch_up import _is_editable_install
        result = _is_editable_install()
        assert isinstance(result, bool)

    def test_stale_pin_under_editable_refuses_rewrite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Force the editable-install detector to True regardless of
        # how this test run was actually installed.
        from mgf.common.cli import _catch_up as cu_module
        monkeypatch.setattr(cu_module, "_is_editable_install", lambda: True)

        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = ["mgf-common>=0.3,<0.4"]\n',
            encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        # The audit STILL surfaces staleness, but with no fix callable.
        assert "STALE" in finding.detail
        assert "editable" in finding.detail.lower()
        assert "NOT auto-rewriting" in finding.detail
        assert "pip index versions mgf-common" in finding.detail
        assert finding.fix is None, (
            "editable-install path MUST refuse the auto-rewrite; "
            "no fix callable should be attached"
        )

    def test_stale_pin_under_pypi_install_offers_rewrite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # The non-editable path retains the auto-rewrite behaviour.
        from mgf.common.cli import _catch_up as cu_module
        monkeypatch.setattr(cu_module, "_is_editable_install", lambda: False)

        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = ["mgf-common>=0.3,<0.4"]\n',
            encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        assert finding.fix is not None, (
            "PyPI-install path MUST keep the auto-rewrite fix-callable"
        )


# ---------------------------------------------------------------------------
# Closed-box leak detection (PAPER-08).
# ---------------------------------------------------------------------------


class TestIsPrivateModule:
    """Pin the `_is_private_module` predicate against every shape the
    audit needs to recognise — leak detection lives or dies on it."""

    @pytest.mark.parametrize(
        "module",
        [
            "mgf.common._identity",
            "mgf.common._lifecycle",
            "mgf.common._warnings",
            "mgf.common.observability._helpers",
            "mgf.common.observability.crash_reporter",  # public module
            "mgf.common.config._loader",                 # nested private
            "mgf.common.exceptions._well_known",
        ],
    )
    def test_classifies_correctly(self, module: str) -> None:
        # All modules above with an underscore-prefixed segment are private.
        has_private_segment = any(
            p.startswith("_") and not p.startswith("__")
            for p in module.split(".")[2:]
        )
        assert _is_private_module(module) is has_private_segment

    def test_public_modules_not_flagged(self) -> None:
        for m in (
            "mgf.common", "mgf.common.exceptions", "mgf.common.observability",
            "mgf.common.config", "mgf.common.versioned",
        ):
            assert _is_private_module(m) is False

    def test_non_mgf_modules_not_flagged(self) -> None:
        for m in ("os", "pydantic._internal", "_pytest.something"):
            assert _is_private_module(m) is False


class TestClosedBoxLeaksCheck:
    def test_clean_project_returns_ok(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "demo.py").write_text(
            "from mgf.common import bootstrap\n"
            "from mgf.common.observability import default_log_path\n"
            "from mgf.common.exceptions import AppConfigError, AppConfigErrorKind\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "ok"

    def test_private_module_import_warns(self, tmp_path: Path) -> None:
        # Case 1: `from mgf.common._x import Y` — module itself private.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "leak.py").write_text(
            "from mgf.common._identity import _APP_NAME\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"
        assert "src/leak.py" in finding.detail
        assert "mgf.common._identity" in finding.detail

    def test_private_name_import_warns(self, tmp_path: Path) -> None:
        # Case 2: `from mgf.common.X import _y` — public module, private name.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "leak.py").write_text(
            "from mgf.common.observability.logging_setup import _default_log_path\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"
        assert "_default_log_path" in finding.detail
        # The known-replacement table fires; suggestion names the public API.
        assert "default_log_path" in finding.detail

    def test_direct_private_module_import_warns(self, tmp_path: Path) -> None:
        # Case 3: `import mgf.common._x` — direct private module import.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "leak.py").write_text(
            "import mgf.common._lifecycle\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"
        assert "mgf.common._lifecycle" in finding.detail

    def test_nested_private_module_warns(self, tmp_path: Path) -> None:
        # `mgf.common.observability._helpers` — segment after a public
        # module is private. Catches the deeper case `mgf.common._x` misses.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "leak.py").write_text(
            "from mgf.common.observability._helpers import some_helper\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"
        assert "_helpers" in finding.detail

    def test_tests_directory_not_walked(self, tmp_path: Path) -> None:
        # Per spec: tests/ is exempt — `_internal_test_helpers/` style
        # imports inside the consumer's own test tree are legitimate.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "tests").mkdir()
        (tmp_path / "src" / "tests" / "test_something.py").write_text(
            "from mgf.common._identity import _APP_NAME\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "ok"

    def test_venv_and_caches_not_walked(self, tmp_path: Path) -> None:
        # .venv / __pycache__ / .pytest_cache shouldn't surface fake
        # leaks from vendored / cached source.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / ".venv").mkdir()
        (tmp_path / "src" / ".venv" / "vendored.py").write_text(
            "from mgf.common._lifecycle import _Stuff\n",
            encoding="utf-8",
        )
        (tmp_path / "src" / "__pycache__").mkdir()
        (tmp_path / "src" / "__pycache__" / "x.py").write_text(
            "from mgf.common._lifecycle import _Stuff\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "ok"

    def test_falls_back_to_root_when_no_src(self, tmp_path: Path) -> None:
        # No src/ → walk project root instead (matches _check_v01_patterns).
        (tmp_path / "leak.py").write_text(
            "from mgf.common._identity import _APP_NAME\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"

    def test_syntax_error_in_one_file_does_not_abort_audit(self, tmp_path: Path) -> None:
        # A malformed .py file shouldn't crash the audit — skip + continue.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "broken.py").write_text(
            "this is not valid python (",
            encoding="utf-8",
        )
        (tmp_path / "src" / "leak.py").write_text(
            "from mgf.common._identity import _APP_NAME\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"
        assert "leak.py" in finding.detail

    def test_known_replacement_named_in_warning(self, tmp_path: Path) -> None:
        # The PAPER-07 mapping table: `_default_log_path` should
        # surface its public replacement by name.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "old.py").write_text(
            "from mgf.common.observability.logging_setup import _default_log_path\n"
            "from mgf.common.observability.crash_reporter import _crash_dir\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.severity == "warn"
        assert "default_log_path" in finding.detail
        assert "default_crash_dir" in finding.detail

    def test_no_fix_callable(self, tmp_path: Path) -> None:
        # Like _check_v01_patterns: catch-up doesn't auto-fix structural
        # imports. The finding lists violations; the consumer migrates.
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "leak.py").write_text(
            "from mgf.common._identity import _APP_NAME\n",
            encoding="utf-8",
        )
        finding = _check_closed_box_leaks(tmp_path)
        assert finding.fix is None


# ---------------------------------------------------------------------------
# End-to-end: run + apply.
# ---------------------------------------------------------------------------


class TestRunCatchUp:
    def test_audit_only_creates_no_files(self, tmp_path: Path) -> None:
        _seed_minimal_project(tmp_path)
        buf = io.StringIO()
        with redirect_stdout(buf):
            exit_code = run_catch_up(_make_args(tmp_path, kind="cli"))
        # Critical fail (missing CLAUDE.md) → exit 1.
        assert exit_code == 1
        # No files created.
        assert not (tmp_path / "docs").exists()
        assert not (tmp_path / ".claude").exists()
        # Report mentions the fail.
        assert "CLAUDE.md" in buf.getvalue()
        assert "missing" in buf.getvalue().lower()

    def test_apply_creates_missing_files(self, tmp_path: Path) -> None:
        _seed_minimal_project(tmp_path)
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))

        claude_md = tmp_path / "docs" / "CLAUDE.md"
        settings = tmp_path / ".claude" / "settings.json"
        assert claude_md.is_file()
        assert settings.is_file()
        # CLAUDE.md has the markers + project name.
        content = claude_md.read_text()
        assert CLAUDE_MD_BEGIN_MARKER in content
        assert CLAUDE_MD_END_MARKER in content
        assert "demo — Claude Reference" in content
        # settings.json is valid JSON.
        json.loads(settings.read_text())

    def test_apply_refresh_preserves_project_specific_content(
        self,
        tmp_path: Path,
    ) -> None:
        _seed_minimal_project(tmp_path)
        # First apply creates CLAUDE.md.
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))

        claude_md = tmp_path / "docs" / "CLAUDE.md"
        # Append project-specific content below the END marker.
        claude_md.write_text(
            claude_md.read_text() + "\n\n## Custom team note\n\nKeep me!\n",
            encoding="utf-8",
        )

        # Tamper with the auto-block to make catch-up detect drift.
        content = claude_md.read_text()
        content = content.replace("Standing instructions", "TAMPERED HEADING")
        claude_md.write_text(content, encoding="utf-8")

        # Re-apply.
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))

        refreshed = claude_md.read_text()
        # Auto-block restored.
        assert "Standing instructions" in refreshed
        assert "TAMPERED HEADING" not in refreshed
        # Project-specific content survives.
        assert "## Custom team note" in refreshed
        assert "Keep me!" in refreshed

    def test_apply_creates_backup_for_refreshed_claude_md(
        self,
        tmp_path: Path,
    ) -> None:
        _seed_minimal_project(tmp_path)
        # Apply once (creates fresh CLAUDE.md).
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))
        # Tamper to induce drift.
        claude_md = tmp_path / "docs" / "CLAUDE.md"
        claude_md.write_text(
            claude_md.read_text().replace(
                "Standing instructions", "TAMPERED",
            ),
            encoding="utf-8",
        )
        # Apply again — backup should be created.
        buf = io.StringIO()
        with redirect_stdout(buf):
            run_catch_up(_make_args(tmp_path, apply=True, kind="cli"))
        backups = list((tmp_path / "docs").glob("CLAUDE.md.bak.*"))
        assert len(backups) == 1, "expected exactly one backup file"
        # Backup contains the tampered version.
        assert "TAMPERED" in backups[0].read_text()

    def test_invalid_target_dir(self, tmp_path: Path) -> None:
        from pathlib import Path

        bad = Path("/nonexistent/path/v11")
        out_buf = io.StringIO()
        # Don't redirect stderr — argparse error path uses different shape.
        with redirect_stdout(out_buf):
            from contextlib import redirect_stderr

            err_buf = io.StringIO()
            with redirect_stderr(err_buf):
                exit_code = run_catch_up(_make_args(bad, kind="cli"))
        assert exit_code == 1


@pytest.mark.parametrize(
    "kind", ["cli", "fastapi", "django", "library", "service"]
)
def test_apply_works_for_all_kinds(tmp_path: Path, kind: str) -> None:
    _seed_minimal_project(tmp_path)
    buf = io.StringIO()
    with redirect_stdout(buf):
        run_catch_up(_make_args(tmp_path, apply=True, kind=kind))
    assert (tmp_path / "docs" / "CLAUDE.md").is_file()
    assert (tmp_path / ".claude" / "settings.json").is_file()


# ---------------------------------------------------------------------------
# Round 1b: kind detection (PAPER-13 + PAPER-17), pip-tools layout
# detection (PAPER-15 partial), CLAUDE.md marker bootstrap (PAPER-16).
# ---------------------------------------------------------------------------


class TestKindDetection:
    """Heuristic kind detection — closes PAPER-13 + PAPER-17."""

    def test_no_pyproject_no_markers_returns_library(self, tmp_path: Path) -> None:
        # No pyproject, no manage.py, no scripts → library default.
        assert _detect_kind(tmp_path) == "library"

    def test_no_pyproject_with_manage_py_returns_django(self, tmp_path: Path) -> None:
        # Closes PAPER-13: Django consumers without pyproject.toml
        # (the inthewords shape).
        (tmp_path / "manage.py").write_text(
            "#!/usr/bin/env python\nimport django\n", encoding="utf-8",
        )
        assert _detect_kind(tmp_path) == "django"

    def test_pyproject_with_fastapi_dep_returns_fastapi(self, tmp_path: Path) -> None:
        # Closes PAPER-17: FastAPI consumers WITH pyproject.toml
        # (the PlasmaMapper shape).
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = [\n'
            '    "fastapi>=0.115",\n'
            '    "uvicorn[standard]>=0.30",\n'
            ']\n',
            encoding="utf-8",
        )
        assert _detect_kind(tmp_path) == "fastapi"

    def test_pyproject_with_django_dep_returns_django(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = [\n'
            '    "django>=5.0",\n'
            ']\n',
            encoding="utf-8",
        )
        assert _detect_kind(tmp_path) == "django"

    def test_pyproject_with_flask_dep_returns_service(self, tmp_path: Path) -> None:
        # No flask in init-project's _KINDS today; service is the closest fit.
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = [\n'
            '    "flask>=3.0",\n'
            ']\n',
            encoding="utf-8",
        )
        assert _detect_kind(tmp_path) == "service"

    def test_pyproject_with_scripts_no_framework_returns_cli(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = [\n'
            '    "click>=8.0",\n'
            ']\n'
            '[project.scripts]\n'
            'demo-cli = "demo:main"\n',
            encoding="utf-8",
        )
        assert _detect_kind(tmp_path) == "cli"

    def test_pyproject_no_deps_no_scripts_returns_library(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "lib"\nversion = "0.1.0"\n'
            'dependencies = [\n'
            '    "pydantic>=2.0",\n'
            ']\n',
            encoding="utf-8",
        )
        assert _detect_kind(tmp_path) == "library"

    def test_pyproject_dep_substring_matches_carefully(self, tmp_path: Path) -> None:
        # `flask-restful` HAS `flask` as a substring; the heuristic
        # may match either `service` (regex broad) or `library`
        # (no match). Either is acceptable until a real consumer
        # files concrete pain. The test pins the acceptable set.
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = [\n'
            '    "flask-restful>=0.3.10",\n'
            ']\n',
            encoding="utf-8",
        )
        assert _detect_kind(tmp_path) in ("service", "library")


class TestPipToolsLayoutDetection:
    """PAPER-15 partial: detect pip-tools layouts and warn helpfully."""

    def test_no_pyproject_with_requirements_dir_emits_pip_tools_info(
        self, tmp_path: Path,
    ) -> None:
        (tmp_path / "requirements").mkdir()
        (tmp_path / "requirements" / "base.txt").write_text(
            "mgf-common>=0.16,<0.18\nrequests>=2.31\n", encoding="utf-8",
        )
        (tmp_path / "requirements" / "dev.txt").write_text(
            "-r base.txt\nruff>=0.4\n", encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "info"
        assert "pip-tools" in finding.detail
        assert "Workaround" in finding.detail or "minimal pyproject.toml" in finding.detail

    def test_no_pyproject_with_flat_requirements_txt_emits_pip_tools_info(
        self, tmp_path: Path,
    ) -> None:
        (tmp_path / "requirements.txt").write_text(
            "mgf-common>=0.16,<0.18\n", encoding="utf-8",
        )
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "info"
        assert "pip-tools" in finding.detail

    def test_no_pyproject_no_requirements_keeps_old_warning(
        self, tmp_path: Path,
    ) -> None:
        # No pyproject, no pip-tools — keep the original warning.
        finding = _check_pyproject_pin(tmp_path)
        assert finding.severity == "warn"
        assert "no pyproject.toml found" in finding.detail
        assert "pip-tools" not in finding.detail

    def test_has_pip_tools_layout_detects_requirements_dir(
        self, tmp_path: Path,
    ) -> None:
        (tmp_path / "requirements").mkdir()
        (tmp_path / "requirements" / "base.txt").write_text("x\n")
        assert _has_pip_tools_layout(tmp_path) is True

    def test_has_pip_tools_layout_detects_flat_file(self, tmp_path: Path) -> None:
        (tmp_path / "requirements.txt").write_text("x\n")
        assert _has_pip_tools_layout(tmp_path) is True

    def test_has_pip_tools_layout_false_when_neither(self, tmp_path: Path) -> None:
        assert _has_pip_tools_layout(tmp_path) is False

    def test_has_pip_tools_layout_false_for_empty_requirements_dir(
        self, tmp_path: Path,
    ) -> None:
        (tmp_path / "requirements").mkdir()
        # empty dir — no .txt / .lock files
        assert _has_pip_tools_layout(tmp_path) is False


class TestClaudeMdMarkerBootstrap:
    """PAPER-16: catch-up --apply auto-inserts BEGIN/END markers + auto-block
    into an existing CLAUDE.md without clobbering project content."""

    def test_check_claude_md_no_markers_attaches_fix_callable(
        self, tmp_path: Path,
    ) -> None:
        # Pre-existing CLAUDE.md without markers (the inthewords shape:
        # 1100 lines of project content, no auto-managed block).
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "CLAUDE.md").write_text(
            "# MyProject — Claude Reference\n\n"
            "Standing instructions: be concise.\n\n"
            "Phase 8D critical fact: ...\n",
            encoding="utf-8",
        )
        finding = _check_claude_md(tmp_path, "myproject", "django")
        assert finding.severity == "warn"
        assert "lacks BEGIN/END" in finding.detail
        # PAPER-16: now has a fix callable instead of pointing at the
        # destructive --force option.
        assert finding.fix is not None

    def test_apply_bootstraps_markers_and_preserves_project_content(
        self, tmp_path: Path,
    ) -> None:
        # Seed an existing CLAUDE.md with multi-line project content.
        docs = tmp_path / "docs"
        docs.mkdir()
        original_content = (
            "# MyProject — Claude Reference\n\n"
            "Standing instructions: be concise.\n\n"
            "Phase 8D critical fact: AppContext is the source of truth.\n"
        )
        (docs / "CLAUDE.md").write_text(original_content, encoding="utf-8")

        result = _apply_bootstrap_claude_md_markers(
            tmp_path, "myproject", "django",
        )

        # Result message names what happened.
        assert "bootstrapped" in result.lower()
        assert "backup" in result.lower()

        # Markers now present at the top.
        new_content = (docs / "CLAUDE.md").read_text(encoding="utf-8")
        assert CLAUDE_MD_BEGIN_MARKER in new_content
        assert CLAUDE_MD_END_MARKER in new_content
        # The marker block precedes the original content.
        begin_idx = new_content.find(CLAUDE_MD_BEGIN_MARKER)
        end_idx = new_content.find(CLAUDE_MD_END_MARKER)
        original_idx = new_content.find("# MyProject — Claude Reference")
        assert begin_idx < end_idx < original_idx, (
            "BEGIN/END markers MUST precede the original project content"
        )

        # Original project content is still present, verbatim.
        assert "Standing instructions: be concise." in new_content
        assert "Phase 8D critical fact:" in new_content

    def test_apply_creates_backup_with_original_content(
        self, tmp_path: Path,
    ) -> None:
        docs = tmp_path / "docs"
        docs.mkdir()
        original = "# Project\n\n1100 lines of stuff here.\n"
        (docs / "CLAUDE.md").write_text(original, encoding="utf-8")

        _apply_bootstrap_claude_md_markers(tmp_path, "demo", "library")

        backups = list(docs.glob("CLAUDE.md.bak.*"))
        assert len(backups) == 1, f"expected exactly 1 backup, got {backups}"
        assert backups[0].read_text(encoding="utf-8") == original

    def test_apply_then_refresh_works_in_place(self, tmp_path: Path) -> None:
        # End-to-end: bootstrap markers → next catch-up --apply
        # refreshes the auto-block in place (rather than re-bootstrapping).
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "CLAUDE.md").write_text(
            "# Demo — Claude Reference\n\nProject content.\n",
            encoding="utf-8",
        )

        # First apply: bootstrap markers.
        _apply_bootstrap_claude_md_markers(tmp_path, "demo", "library")
        first_content = (docs / "CLAUDE.md").read_text(encoding="utf-8")
        assert CLAUDE_MD_BEGIN_MARKER in first_content

        # Now check_claude_md — the auto-block matches the template,
        # so this should be ✅. (If template content changes, would
        # be ⚠️ + refresh-fix-callable.)
        finding = _check_claude_md(tmp_path, "demo", "library")
        assert finding.severity in ("ok", "warn"), (
            f"after bootstrap, should be ok or warn (refresh-needed); "
            f"got {finding.severity}"
        )

