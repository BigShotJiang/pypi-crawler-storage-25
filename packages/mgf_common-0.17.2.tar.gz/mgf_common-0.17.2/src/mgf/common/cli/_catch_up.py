"""``mgf-common catch-up`` — audit + update an existing project against current standards.

Closes the v0.11.0 deliverable: existing projects (VManager,
inthewords, future adopters) need an audit-and-update flow, not
the create-from-scratch shape ``init-project`` ships. ``catch-up``:

  - Reads the project's pyproject.toml + docs/CLAUDE.md +
    .claude/settings.json + (optionally) src/.
  - Compares against the current init-project templates +
    standards.
  - Prints a drift report (✅ / ⚠️ / 🔴 per row).
  - With ``--apply``, performs ONLY safe mechanical updates:
    creates missing files, refreshes the auto-managed CLAUDE.md
    block (between BEGIN/END markers), backs up originals.
    Pyproject snippets and v0.1-pattern migrations are surfaced
    as suggestions, not auto-modified — too easy to clobber
    project-specific config.

Read-only by default. ``--apply`` is the explicit opt-in.
"""

from __future__ import annotations

import ast
import re
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from mgf.common.cli._init_project import (
    CLAUDE_MD_BEGIN_MARKER,
    CLAUDE_MD_END_MARKER,
    _render_claude_md,
    _render_claude_settings,
)

if TYPE_CHECKING:
    import argparse
    from collections.abc import Callable


_Severity = Literal["ok", "warn", "fail", "info"]
_SEVERITY_ICON: dict[_Severity, str] = {
    "ok": "✅",
    "warn": "⚠️ ",
    "fail": "🔴",
    "info": "ℹ️ ",  # noqa: RUF001 — INFORMATION SOURCE is intentional
}


class _Finding:
    """One row in the audit report."""

    __slots__ = ("detail", "fix", "severity", "title")

    def __init__(
        self,
        severity: _Severity,
        title: str,
        detail: str,
        fix: Callable[[Path], str] | None = None,
    ) -> None:
        self.severity = severity
        self.title = title
        self.detail = detail
        self.fix = fix


def add_catch_up_args(parser: argparse.ArgumentParser) -> None:
    """Register the ``catch-up`` subcommand's arguments."""
    parser.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help=(
            "Target project root (default: current working directory). "
            "Must contain a pyproject.toml or be the root of a project "
            "that depends on mgf-common."
        ),
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help=(
            "Apply mechanical fixes (create missing CLAUDE.md / "
            ".claude/settings.json; refresh CLAUDE.md auto-block "
            "between BEGIN/END markers). Originals are backed up to "
            "<file>.bak.<timestamp>. Read-only without this flag."
        ),
    )
    parser.add_argument(
        "--name",
        help=(
            "Project name (used when CLAUDE.md is missing entirely "
            "and we need to render a fresh one). Defaults to the "
            "project's name from pyproject.toml."
        ),
    )
    parser.add_argument(
        "--kind",
        choices=("cli", "fastapi", "django", "library", "service"),
        help=(
            "Project kind (used when CLAUDE.md is missing entirely). "
            "Defaults to 'library' if it can't be guessed."
        ),
    )


def run_catch_up(args: argparse.Namespace) -> int:
    """Run the audit, optionally apply fixes."""
    target_dir = args.path.resolve()
    if not target_dir.is_dir():
        print(
            f"error: target path {target_dir} is not a directory.",
            file=sys.stderr,
        )
        return 1

    project_name, project_kind = _resolve_project_identity(target_dir, args)

    findings: list[_Finding] = []
    findings.append(_check_pyproject_pin(target_dir))
    findings.append(_check_four_gates(target_dir))
    findings.append(_check_claude_md(target_dir, project_name, project_kind))
    findings.append(_check_claude_settings(target_dir, project_kind))
    findings.append(_check_v01_patterns(target_dir))
    findings.append(_check_closed_box_leaks(target_dir))

    _print_report(findings, target_dir, project_name, project_kind)

    if not args.apply:
        # Read-only mode. Done.
        return _exit_code_for(findings)

    # --apply mode: run any fixes that are safe + automatic.
    print()
    print("Applying mechanical fixes …")
    applied = 0
    for finding in findings:
        if finding.fix is None:
            continue
        result = finding.fix(target_dir)
        print(f"  {_SEVERITY_ICON['info']} {finding.title}: {result}")
        applied += 1
    if applied == 0:
        print("  (nothing to apply — everything mechanical is already current.)")
    else:
        print()
        print(
            f"Applied {applied} mechanical fix(es). Re-run "
            "`mgf-common catch-up` to verify, or check the .bak.* "
            "backups if anything looks wrong.",
        )

    return _exit_code_for(findings)


# ---------------------------------------------------------------------------
# Identity resolution.
# ---------------------------------------------------------------------------


def _resolve_project_identity(
    target_dir: Path,
    args: argparse.Namespace,
) -> tuple[str, str]:
    """Resolve project name + kind from CLI args + pyproject.toml.

    v0.17.2+: kind detection is heuristic when not given on the
    CLI. Closes PAPER-13 (no pyproject case) + PAPER-17 (with
    pyproject case). Returns one of the existing init-project
    template kinds: ``cli``, ``fastapi``, ``django``, ``library``,
    ``service``. Default fall-through is ``library`` when no
    framework / scripts / Django-marker is found.
    """
    name = args.name
    kind = args.kind

    if name is None:
        name = _read_pyproject_name(target_dir) or target_dir.name
    if kind is None:
        kind = _detect_kind(target_dir)

    return name, kind


def _detect_kind(target_dir: Path) -> str:
    """Heuristic kind detection. Returns one of cli / fastapi /
    django / library / service. Closes PAPER-13 + PAPER-17.

    Resolution ladder, most-specific first:

      1. ``pyproject.toml`` deps + scripts (PAPER-17). Reads
         ``[project] dependencies`` and ``[project.scripts]``;
         framework markers in deps → ``fastapi`` / ``django``;
         non-empty scripts without framework → ``cli``;
         otherwise → ``library``.
      2. No-pyproject markers (PAPER-13). ``manage.py`` at the
         project root → ``django``. Other no-pyproject project
         shapes fall through to ``library`` (the default).
    """
    pp_kind = _detect_kind_from_pyproject(target_dir)
    if pp_kind is not None:
        return pp_kind
    np_kind = _detect_kind_no_pyproject(target_dir)
    if np_kind is not None:
        return np_kind
    return "library"


def _detect_kind_from_pyproject(target_dir: Path) -> str | None:
    """PAPER-17: parse pyproject.toml deps + scripts to detect kind.

    Returns ``None`` when there's no pyproject.toml — the caller
    falls through to the no-pyproject heuristic.
    """
    pp = target_dir / "pyproject.toml"
    if not pp.is_file():
        return None
    try:
        text = pp.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    # Cheap line-grep: pyproject can't be parsed without tomllib /
    # tomli, and we want to stay stdlib-only on 3.11+. The heuristic
    # is forgiving — match the canonical declaration shape.
    deps_block = _extract_block(text, "dependencies")
    scripts_block = _extract_block(text, "[project.scripts]")

    deps_lower = deps_block.lower() if deps_block else ""

    # Framework markers (most-specific first).
    if re.search(r'["\']fastapi(?:\[|>=|<|=|~|"|\')', deps_lower):
        return "fastapi"
    if re.search(r'["\']django(?:\[|>=|<|=|~|"|\')', deps_lower):
        return "django"
    if re.search(r'["\']flask(?:\[|>=|<|=|~|"|\')', deps_lower):
        # No 'flask' in init-project's _KINDS today; closest match
        # is 'service' (generic web/service shape).
        return "service"

    # CLI shape — has console scripts, no web framework above.
    if scripts_block and "=" in scripts_block:
        return "cli"

    # No framework, no scripts → real library.
    return "library"


def _extract_block(text: str, marker: str) -> str | None:
    """Pull the ``[project] dependencies = [ ... ]`` array text or a
    section block following ``[project.scripts]``. Returns None when
    the marker isn't found. Cheap; doesn't validate TOML structure
    beyond what the heuristic needs."""
    if marker == "dependencies":
        # `dependencies = [ ... ]` — multiline array.
        m = re.search(r"^\s*dependencies\s*=\s*\[", text, re.MULTILINE)
        if m is None:
            return None
        # Find the matching closing bracket. Naive but fine for our
        # use — pyproject deps don't nest arrays.
        start = m.end()
        depth = 1
        i = start
        while i < len(text) and depth > 0:
            if text[i] == "[":
                depth += 1
            elif text[i] == "]":
                depth -= 1
            i += 1
        return text[start:i]
    # Section header marker like "[project.scripts]" — return the body
    # until the next section header.
    idx = text.find(marker)
    if idx == -1:
        return None
    body_start = text.find("\n", idx) + 1
    next_section = re.search(r"^\s*\[", text[body_start:], re.MULTILINE)
    body_end = body_start + next_section.start() if next_section else len(text)
    return text[body_start:body_end]


def _detect_kind_no_pyproject(target_dir: Path) -> str | None:
    """PAPER-13: detect kind when pyproject.toml is absent.

    ``manage.py`` at the project root → ``django`` (Django's
    canonical project layout marker). Other no-pyproject shapes
    return None (let the caller fall through to ``library``).
    """
    if (target_dir / "manage.py").is_file():
        return "django"
    return None


def _has_pip_tools_layout(target_dir: Path) -> bool:
    """PAPER-15: detect a pip-tools-style requirements layout.

    True if ``requirements/`` exists with at least one ``.txt`` /
    ``.lock`` inside, OR if a top-level ``requirements.txt`` /
    ``requirements.lock`` exists. The audit doesn't yet read the
    pin from these files (full pip-tools manifest support is a
    deferred follow-up); detection just enables a better-shaped
    warning message instead of "no pyproject.toml found".
    """
    req_dir = target_dir / "requirements"
    if req_dir.is_dir():
        for p in req_dir.iterdir():
            if p.is_file() and p.suffix in (".txt", ".lock"):
                return True
    if (target_dir / "requirements.txt").is_file():
        return True
    if (target_dir / "requirements.lock").is_file():
        return True
    return False


def _read_pyproject_name(target_dir: Path) -> str | None:
    """Pull `[project] name = "..."` from pyproject.toml."""
    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        return None
    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError:
        return None
    match = re.search(
        r'^\s*name\s*=\s*"([^"]+)"',
        text,
        re.MULTILINE,
    )
    return match.group(1) if match else None


# ---------------------------------------------------------------------------
# Individual audit checks. Each returns one _Finding.
# ---------------------------------------------------------------------------


def _is_editable_install() -> bool:
    """Return True if the running mgf-common is installed editable.

    Editable installs (``pip install -e ../mgf_common``,
    ``[tool.uv.sources]`` workspace pins) can run AHEAD of the
    latest PyPI-published version. Auto-rewriting a consumer's pin
    against an editable install produces a pin that no plain-PyPI
    resolver can satisfy (closes PAPER-20).

    Detection uses ``importlib.metadata.distribution(...).read_text(
    "direct_url.json")`` — the marker PEP 660 editable installers
    write to dist-info. Any ``"dir_info": {"editable": true}`` flag
    in the JSON means we're running from an editable.
    """
    import importlib.metadata
    import json
    try:
        dist = importlib.metadata.distribution("mgf-common")
    except importlib.metadata.PackageNotFoundError:
        return False
    try:
        raw = dist.read_text("direct_url.json")
    except (OSError, FileNotFoundError):
        return False
    if raw is None:
        return False
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return False
    return bool(payload.get("dir_info", {}).get("editable"))


def _check_pyproject_pin(target_dir: Path) -> _Finding:
    """Is the mgf-common pin in pyproject.toml current?

    v0.12.0+: when the pin's upper bound excludes the running
    mgf-common version (i.e., pin is stale), the finding gets a
    ``fix=`` callable that ``--apply`` can invoke to rewrite the
    line to a current 2-minor window (``>=<current>,<<major>.<minor+2>``).
    Conservative: only rewrites lines whose shape we fully understand.

    v0.17.1+: when the running mgf-common is an editable install
    (`pip install -e ../mgf_common`), the auto-rewrite is REFUSED
    — editable installs can be ahead of PyPI, and rewriting a
    consumer's pin to ``>=<editable_version>`` produces a pin no
    plain-PyPI resolver can satisfy. The audit row still surfaces
    the staleness; the consumer rewrites the pin by hand against
    `pip index versions mgf-common`. Closes PAPER-20.
    """
    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        # PAPER-15 partial: tailor the message when a pip-tools
        # layout is present. Full pip-tools manifest audit (reading
        # the pin from `requirements/base.txt`) is a deferred
        # follow-up.
        if _has_pip_tools_layout(target_dir):
            return _Finding(
                "info",
                "pyproject.toml — mgf-common pin",
                "no pyproject.toml found, but pip-tools-style "
                "`requirements/*.{txt,lock}` layout detected. "
                "Pin audit + four-gate audit currently require a "
                "pyproject.toml; full pip-tools-manifest support "
                "is a deferred follow-up. Workaround: add a minimal "
                "pyproject.toml with the standards-bar `[project] "
                "dependencies` + `[tool.ruff]` / `[tool.mypy]` / "
                "`[tool.pytest.ini_options]` sections. Your existing "
                "`requirements/*.{txt,lock}` files keep working "
                "alongside.",
            )
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            "no pyproject.toml found; standards adoption usually needs one.",
        )

    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError as exc:
        return _Finding(
            "fail",
            "pyproject.toml — mgf-common pin",
            f"could not read pyproject.toml: {exc}",
        )

    pin_match = re.search(
        r'"(mgf-common(?:\[[^\]]+\])?)\s*([^"]*)"',
        text,
    )
    if pin_match is None:
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            "no `mgf-common` dep found. Add it to "
            "`[project] dependencies`. See `mgf-common standards "
            "components` for the canonical pin shape.",
        )

    from mgf.common import __version__ as current

    pin_extras_part = pin_match.group(1)  # e.g., "mgf-common" or "mgf-common[fastapi]"
    pin_constraint = pin_match.group(2).strip(", ")
    if not pin_constraint:
        return _Finding(
            "info",
            "pyproject.toml — mgf-common pin",
            f"unpinned dep on `mgf-common`. Suggest pinning to "
            f"`>={current},<{_next_major(current)}`.",
        )

    # Determine if the pin is stale: does the upper bound exclude
    # the running mgf-common version?
    is_stale = _pin_is_stale(pin_constraint, current)
    if not is_stale:
        return _Finding(
            "ok",
            "pyproject.toml — mgf-common pin",
            f"declared (constraint: `{pin_constraint}`; current "
            f"mgf-common: `{current}`). Pin window includes "
            f"current; nothing to do.",
        )

    new_constraint = f">={current},<{_next_major(current)}"

    if _is_editable_install():
        # Editable installs can run ahead of PyPI; refusing the
        # auto-rewrite avoids producing a pin no plain-PyPI
        # resolver can satisfy. Per PAPER-20.
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            f"STALE: declared `{pin_constraint}` but current "
            f"(editable-install) mgf-common is `{current}`. "
            f"NOT auto-rewriting — editable installs can be "
            f"AHEAD of PyPI, and rewriting to "
            f"`>={current},<{_next_major(current)}` would "
            f"produce a pin no plain-PyPI resolver can satisfy. "
            f"Verify the latest PyPI-published window with "
            f"`pip index versions mgf-common` and bump the pin "
            f"by hand to that window.",
        )

    return _Finding(
        "warn",
        "pyproject.toml — mgf-common pin",
        f"STALE: declared `{pin_constraint}` but current "
        f"mgf-common is `{current}` — the upper bound excludes it. "
        f"Suggest bumping to `{new_constraint}` (2-minor window). "
        f"Run with --apply to rewrite the line; backup written.",
        fix=lambda root: _apply_bump_pin(
            root,
            extras_part=pin_extras_part,
            old_constraint=pin_constraint,
            new_constraint=new_constraint,
        ),
    )


def _pin_is_stale(constraint: str, current_version: str) -> bool:
    """Return True if ``current_version`` is excluded by the pin's upper bound.

    Parses the constraint string (PEP 440-ish, comma-separated). Recognises
    ``<X.Y[.Z]`` upper bounds (the canonical shape mgf-common projects
    use). Anything else (no upper bound, unparseable, or non-`<` bound)
    returns False — better to under-flag than to rewrite blindly.
    """
    upper_match = re.search(r"<\s*([0-9]+)\.([0-9]+)(?:\.([0-9]+))?", constraint)
    if upper_match is None:
        return False  # No `<X.Y` upper bound — can't reason; trust the user.

    upper_major = int(upper_match.group(1))
    upper_minor = int(upper_match.group(2))
    upper_patch = int(upper_match.group(3)) if upper_match.group(3) else 0

    cur_parts = current_version.split(".")
    if len(cur_parts) < 2:
        return False
    try:
        cur_major = int(cur_parts[0])
        cur_minor = int(cur_parts[1])
        cur_patch = int(cur_parts[2]) if len(cur_parts) >= 3 else 0
    except ValueError:
        return False

    # Strict-less than comparison: stale iff (cur_major, cur_minor, cur_patch)
    # >= upper bound.
    return (cur_major, cur_minor, cur_patch) >= (upper_major, upper_minor, upper_patch)


def _apply_bump_pin(
    target_dir: Path,
    *,
    extras_part: str,
    old_constraint: str,
    new_constraint: str,
) -> str:
    """Rewrite the mgf-common pin line in pyproject.toml.

    Conservative: targets ONLY the specific
    ``"mgf-common[…]<old_constraint>"`` substring, leaves the rest of
    the file untouched. Writes a backup before modifying.
    """
    pyproject = target_dir / "pyproject.toml"
    original = pyproject.read_text(encoding="utf-8")

    # Build the exact substring to find (so we don't accidentally
    # rewrite mentions of mgf-common in comments / urls).
    old_pin_str = f'"{extras_part}{old_constraint}"'
    # Some projects write "mgf-common>=0.1.0,<0.2" with no space; some
    # might have spaces. Try the exact form first.
    if old_pin_str not in original:
        # The match-group may have captured a slightly different form
        # (with spaces stripped vs preserved). Re-derive from the file.
        regex = re.compile(
            r'"(' + re.escape(extras_part) + r')\s*([^"]*)"',
        )
        match = regex.search(original)
        if match is None:
            return "could not locate the mgf-common pin line; manual edit required."
        old_pin_str = match.group(0)

    new_pin_str = f'"{extras_part}{new_constraint}"'
    rewritten = original.replace(old_pin_str, new_pin_str, 1)

    if rewritten == original:
        return "could not locate the mgf-common pin line; manual edit required."

    backup = pyproject.with_suffix(f".toml.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")
    pyproject.write_text(rewritten, encoding="utf-8")

    return f"bumped pin to `{new_constraint}` in {pyproject} (backup: {backup.name})"


def _check_four_gates(target_dir: Path) -> _Finding:
    """Are the four gates configured in pyproject.toml?

    Uses :mod:`tomllib` (stdlib in Python 3.11+) to parse the file
    properly rather than substring-matching, which gave false
    positives on the multi-line array form
    (``filterwarnings = [\\n    "error",\\n]``).
    """
    import tomllib

    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        return _Finding(
            "warn",
            "pyproject.toml — four gates",
            "no pyproject.toml; cannot check gate config.",
        )
    try:
        with pyproject.open("rb") as fh:
            data = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        return _Finding(
            "fail",
            "pyproject.toml — four gates",
            f"could not parse pyproject.toml: {exc}",
        )

    tool = data.get("tool", {})
    missing: list[str] = []

    # Ruff: presence of the table is enough; specific rule selection
    # is consumer-customisable.
    if "ruff" not in tool:
        missing.append("[tool.ruff]")

    # mypy: requires the table AND `strict = true` (per DP-04).
    mypy_cfg = tool.get("mypy", {})
    if not mypy_cfg or mypy_cfg.get("strict") is not True:
        missing.append("[tool.mypy] with strict = true")

    # pytest: requires the table AND filterwarnings contains "error"
    # (per TS-04). Accepts both the single-line and multi-line array
    # forms — they produce the same parsed list.
    pytest_cfg = tool.get("pytest", {}).get("ini_options", {})
    fw = pytest_cfg.get("filterwarnings", [])
    if not pytest_cfg or "error" not in fw:
        missing.append("[tool.pytest.ini_options] with filterwarnings = ['error']")

    # coverage: any of the coverage tables (run / report / paths) is
    # acceptable as a signal that coverage is configured. fail_under
    # specifically is in [tool.coverage.report].
    coverage_cfg = tool.get("coverage", {})
    if not coverage_cfg:
        missing.append("[tool.coverage.report] with fail_under")

    if not missing:
        return _Finding(
            "ok",
            "pyproject.toml — four gates",
            "ruff / mypy strict / pytest filterwarnings=error / "
            "coverage threshold all configured.",
        )

    return _Finding(
        "warn",
        "pyproject.toml — four gates",
        "missing or partial: "
        + "; ".join(missing)
        + ". Run `mgf-common init-project --kind <kind> --dry-run "
        "--path <tmp>` to print a fresh four-gate snippet, or paste "
        "from the recipe at `mgf-common standards components`.",
    )


def _check_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> _Finding:
    """Does docs/CLAUDE.md exist + does it have the auto-managed block?"""
    claude_md = target_dir / "docs" / "CLAUDE.md"
    if not claude_md.is_file():
        return _Finding(
            "fail",
            "docs/CLAUDE.md",
            "missing. Claude won't auto-load any standards on session "
            "start — manual prompting required for every task. "
            "Run with --apply to create a fresh CLAUDE.md from the "
            "current template.",
            fix=lambda root: _apply_create_claude_md(
                root,
                project_name,
                project_kind,
            ),
        )

    try:
        content = claude_md.read_text(encoding="utf-8")
    except OSError as exc:
        return _Finding(
            "fail",
            "docs/CLAUDE.md",
            f"could not read: {exc}",
        )

    has_begin = CLAUDE_MD_BEGIN_MARKER in content
    has_end = CLAUDE_MD_END_MARKER in content

    if not has_begin or not has_end:
        # PAPER-16: catch-up --apply auto-inserts the BEGIN/END
        # markers + auto-block at the top of the existing CLAUDE.md
        # (with backup), rather than forcing the consumer to choose
        # between init-project --force (which clobbers project-
        # specific content) and manual marker insertion (which is
        # undocumented).
        return _Finding(
            "warn",
            "docs/CLAUDE.md",
            "exists but lacks BEGIN/END auto-managed markers — "
            "either pre-v0.11 init-project output or hand-written. "
            "Run with --apply to bootstrap the markers + auto-block "
            "at the top of the existing file (your project-specific "
            "content stays below the END marker; original is backed "
            "up to .bak.<timestamp>). Closes PAPER-16.",
            fix=lambda root: _apply_bootstrap_claude_md_markers(
                root, project_name, project_kind,
            ),
        )

    # Compute the current expected auto-block; compare to existing.
    expected = _render_claude_md(project_name, project_kind)
    expected_block = _extract_auto_block(expected)
    actual_block = _extract_auto_block(content)

    if expected_block == actual_block:
        return _Finding(
            "ok",
            "docs/CLAUDE.md",
            "exists with current auto-managed block. "
            "Project-specific lookup preserved.",
        )

    return _Finding(
        "warn",
        "docs/CLAUDE.md",
        "exists with auto-block markers, but the auto-block content "
        "is stale relative to the current template (rules may have "
        "been added / wording changed in newer mgf-common). Run with "
        "--apply to refresh just the auto-block.",
        fix=lambda root: _apply_refresh_claude_md(
            root,
            project_name,
            project_kind,
        ),
    )


def _check_claude_settings(
    target_dir: Path,
    project_kind: str,
) -> _Finding:
    """Does .claude/settings.json exist?"""
    settings = target_dir / ".claude" / "settings.json"
    if not settings.is_file():
        return _Finding(
            "warn",
            ".claude/settings.json",
            "missing. Without it, Claude prompts for every Bash "
            "command — friction in normal dev. Run with --apply to "
            "create one with safe defaults for this project kind.",
            fix=lambda root: _apply_create_claude_settings(root, project_kind),
        )
    return _Finding(
        "ok",
        ".claude/settings.json",
        "exists. (catch-up doesn't audit allow-list contents — "
        "your team customizes them.)",
    )


def _check_v01_patterns(target_dir: Path) -> _Finding:
    """Grep src/ for v0.1-pattern usages that should migrate to bootstrap()."""
    src = target_dir / "src"
    if not src.is_dir():
        # Try the project root as a fallback.
        src = target_dir

    patterns: list[tuple[str, str]] = [
        ("mgf.common.configure(", "→ `with mgf.common.bootstrap(...)` (v0.3+)"),
        ("make_settings_config(", "→ `settings_config(...)` (v0.3+)"),
        ("setup_logging(", "→ folded into `bootstrap()` (v0.3+)"),
        ("setup_otel(", "→ folded into `bootstrap()` (v0.3+)"),
        ("install_excepthook(", "→ folded into `bootstrap()` (v0.3+)"),
        ("install_threading_excepthook(", "→ folded into `bootstrap()` (v0.3+)"),
    ]

    findings: list[str] = []
    for needle, suggestion in patterns:
        count = _count_matches(src, needle)
        if count > 0:
            findings.append(f"`{needle}` x {count}: {suggestion}")

    if not findings:
        return _Finding(
            "ok",
            "v0.1-pattern usage",
            "no legacy `configure() / setup_logging() / "
            "install_excepthook()` calls found.",
        )

    return _Finding(
        "warn",
        "v0.1-pattern usage",
        "legacy v0.1 call sites found: "
        + "; ".join(findings)
        + ". These still work via deprecation cycle, but the "
        "v0.3+ `bootstrap()` shape is the canonical replacement. "
        "Migration is NOT mechanical (the call shape changes from "
        "5 separate calls to 1 context manager); catch-up will not "
        "auto-modify. See `mgf-common standards design` for the "
        "bootstrap() pattern.",
    )


def _count_matches(root: Path, needle: str) -> int:
    """Count how many times ``needle`` appears across .py files under ``root``.

    Skips standard cache / build / vendor / venv directories per
    ``_AUDIT_SKIP_DIRS`` (closes PAPER-14 — without the skip, the
    audit walked into ``.venv/`` and counted mgf-common's own
    deprecated shim definitions as user-source v0.1 call sites,
    producing dozens of false positives on adopter projects).
    """
    if not root.is_dir():
        return 0
    total = 0
    for path in root.rglob("*.py"):
        if any(part in _AUDIT_SKIP_DIRS for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        total += text.count(needle)
    return total


# ---------------------------------------------------------------------------
# Closed-box leak detection (rule AP-14 / DP-13). Closes FEEDBACK PAPER-08.
# ---------------------------------------------------------------------------

# Skip these directory names anywhere in a .py file's path during
# any consumer-source audit walk. Tests are intentionally exempt:
# ``tests/unit/_internal_test_helpers/`` style imports are legitimate
# consumer-side per the PAPER-08 spec. ``.venv/`` exemption is what
# closed PAPER-14 (audit was walking installed mgf-common's own
# deprecated shim definitions and counting them as user-source v0.1
# call sites).
_AUDIT_SKIP_DIRS: frozenset[str] = frozenset({
    "tests", "test", ".venv", "venv", "__pycache__",
    "node_modules", "dist", "build", ".tox", ".pytest_cache",
    ".mypy_cache", ".ruff_cache",
})

# Backward-compat alias for the original PAPER-08 name. New code uses
# _AUDIT_SKIP_DIRS.
_LEAK_SKIP_DIRS = _AUDIT_SKIP_DIRS

# Map known private symbols to their public-API replacement so the
# audit row can name the fix, not just the violation. Extend as new
# private→public promotions happen.
_PRIVATE_TO_PUBLIC: dict[str, str] = {
    "_default_log_path": "mgf.common.observability.default_log_path  (since v0.13.0)",
    "_crash_dir": "mgf.common.observability.default_crash_dir  (since v0.13.0)",
}


def _is_private_module(module: str) -> bool:
    """True when any path segment after ``mgf.common`` starts with ``_``.

    Catches:
      - ``mgf.common._x``                — module itself private
      - ``mgf.common.observability._helpers`` — nested private module
      - ``mgf.common.X.Y._z``            — deeply nested

    Excludes ``__init__`` / ``__main__`` style dunders (those aren't
    "private" in the closed-box sense).
    """
    if not module.startswith("mgf.common"):
        return False
    parts = module.split(".")
    for p in parts[2:]:  # skip "mgf", "common"
        if p.startswith("_") and not p.startswith("__"):
            return True
    return False


def _check_closed_box_leaks(target_dir: Path) -> _Finding:
    """AST-walk consumer src/ for imports of mgf.common's private surface.

    Closes FEEDBACK PAPER-08. Pairs with ``tests/public_surface/
    test_no_private_imports.py`` (the upstream-side AST pin); this
    is the consumer-side runtime check, surfaced as a catch-up
    audit row so consumers don't have to copy the test.

    Three leak shapes detected:
      1. ``from mgf.common._x import Y``     — module itself private
      2. ``from mgf.common.X import _y``     — public module, private name
      3. ``import mgf.common._x``            — direct private-module import

    The consumer's ``tests/`` directory is NOT walked: legitimate
    test-helper imports inside ``tests/unit/_internal_test_helpers/``
    style directories aren't violations of the closed-box rule.
    """
    src = target_dir / "src"
    if not src.is_dir():
        # Match ``_check_v01_patterns`` — fall back to project root.
        src = target_dir

    leaks: list[str] = []

    for path in src.rglob("*.py"):
        if any(part in _LEAK_SKIP_DIRS for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        try:
            tree = ast.parse(text, filename=str(path))
        except SyntaxError:
            # Malformed source — skip rather than abort the whole audit.
            continue

        try:
            rel = path.relative_to(target_dir).as_posix()
        except ValueError:
            rel = path.as_posix()

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if not node.module or not node.module.startswith("mgf.common"):
                    continue
                if _is_private_module(node.module):
                    # Case 1: from mgf.common._x import ...
                    name_list = ", ".join(a.name for a in node.names)
                    leaks.append(
                        f"{rel}:{node.lineno}: "
                        f"from {node.module} import {name_list}",
                    )
                    continue
                # Case 2: from mgf.common.X import _private
                for alias in node.names:
                    if alias.name.startswith("_") and not alias.name.startswith("__"):
                        suggestion = _PRIVATE_TO_PUBLIC.get(
                            alias.name,
                            "use the public alternative from `mgf-common standards api`",
                        )
                        leaks.append(
                            f"{rel}:{node.lineno}: "
                            f"from {node.module} import {alias.name} → {suggestion}",
                        )
            elif isinstance(node, ast.Import):
                # Case 3: import mgf.common._x
                for alias in node.names:
                    if _is_private_module(alias.name):
                        leaks.append(f"{rel}:{node.lineno}: import {alias.name}")

    if not leaks:
        return _Finding(
            "ok",
            "closed-box leaks (private mgf.common imports)",
            "no `mgf.common._*` or `mgf.common.X._private` imports "
            "found in src/.",
        )

    leaks.sort()
    shown = leaks[:8]
    extra = len(leaks) - len(shown)
    body = "; ".join(shown)
    if extra > 0:
        body += f"; … and {extra} more"

    return _Finding(
        "warn",
        "closed-box leaks (private mgf.common imports)",
        f"private mgf.common imports found ({len(leaks)} site(s)): "
        f"{body}. Closed-box rule (AP-14 / DP-13): consumers MUST NOT "
        "import `mgf.common._*` modules or names starting with `_` "
        "from public modules — the private surface MAY change in any "
        "release. Replace with the public equivalent (printed inline "
        "above when known).",
    )


# ---------------------------------------------------------------------------
# Apply functions. Called only when --apply is passed.
# ---------------------------------------------------------------------------


def _apply_create_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """Create a fresh CLAUDE.md."""
    path = target_dir / "docs" / "CLAUDE.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_render_claude_md(project_name, project_kind), encoding="utf-8")
    return f"created {path}"


def _apply_refresh_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """Refresh just the auto-managed block of an existing CLAUDE.md."""
    path = target_dir / "docs" / "CLAUDE.md"
    original = path.read_text(encoding="utf-8")

    # Backup before modifying.
    backup = path.with_suffix(f".md.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")

    new_full = _render_claude_md(project_name, project_kind)
    new_auto_block = _extract_auto_block(new_full)

    # Splice: keep everything BEFORE the BEGIN marker + the new
    # auto-block + everything AFTER the END marker.
    refreshed = _splice_auto_block(original, new_auto_block)
    path.write_text(refreshed, encoding="utf-8")
    return f"refreshed auto-block in {path} (backup: {backup.name})"


def _apply_bootstrap_claude_md_markers(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """PAPER-16: bootstrap BEGIN/END markers + auto-block into an
    existing CLAUDE.md that lacks them.

    Reads the existing file, backs it up to ``.bak.<timestamp>``,
    writes a new file with:

      1. The auto-managed BEGIN marker.
      2. The current standards auto-block content.
      3. The auto-managed END marker.
      4. A blank separator line.
      5. The original CLAUDE.md content, verbatim.

    The consumer ends up with the auto-block at the top + their
    existing content below the END marker — exactly the shape
    ``init-project`` produces on a greenfield run, but
    non-destructively. Subsequent ``catch-up --apply`` invocations
    can refresh the auto-block in place via
    :func:`_apply_refresh_claude_md` (the markers are now present).
    """
    path = target_dir / "docs" / "CLAUDE.md"
    original = path.read_text(encoding="utf-8")

    # Backup before modifying. Suffix matches _apply_refresh_claude_md
    # so the backup naming is consistent across catch-up apply paths.
    backup = path.with_suffix(f".md.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")

    # Render a fresh full template; extract just the auto-block
    # (including its BEGIN/END markers) — that's what we prepend.
    fresh_template = _render_claude_md(project_name, project_kind)
    auto_block_with_markers = _extract_full_auto_block(fresh_template)
    if not auto_block_with_markers:
        # Defensive: if the template's structure changes such that
        # we can't extract the marker block, fall back to the full
        # template (project content prepended below).
        auto_block_with_markers = fresh_template.rstrip() + "\n"

    new_content = auto_block_with_markers.rstrip() + "\n\n" + original
    path.write_text(new_content, encoding="utf-8")
    return (
        f"bootstrapped BEGIN/END markers + auto-block at top of "
        f"{path} (backup: {backup.name}). Project-specific content "
        f"preserved below the END marker."
    )


def _extract_full_auto_block(content: str) -> str:
    """Return the BEGIN..END marker block (markers included). Used
    by :func:`_apply_bootstrap_claude_md_markers` to lift the
    auto-block out of a freshly-rendered template and prepend it
    onto an existing CLAUDE.md."""
    begin_idx = content.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = content.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        return ""
    end_line_end = content.find("\n", end_idx)
    if end_line_end == -1:
        end_line_end = len(content)
    return content[begin_idx : end_line_end + 1]


def _apply_create_claude_settings(target_dir: Path, project_kind: str) -> str:
    """Create a fresh .claude/settings.json."""
    path = target_dir / ".claude" / "settings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_render_claude_settings(project_kind), encoding="utf-8")
    return f"created {path}"


# ---------------------------------------------------------------------------
# Auto-block extraction + splicing.
# ---------------------------------------------------------------------------


def _extract_auto_block(content: str) -> str:
    """Return the substring between BEGIN and END markers (markers excluded)."""
    begin_idx = content.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = content.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        return ""
    # Slice from end-of-BEGIN-marker-line to start-of-END-marker-line.
    begin_line_end = content.find("\n", begin_idx)
    if begin_line_end == -1:
        return ""
    return content[begin_line_end + 1 : end_idx]


def _splice_auto_block(original: str, new_block: str) -> str:
    """Replace original's auto-block with new_block (keep markers + outside)."""
    begin_idx = original.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = original.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        # Shouldn't be called when markers are missing, but be safe.
        return original

    # Find the end of the BEGIN marker's line (so we keep the marker
    # itself but replace everything below it up to the END marker).
    begin_line_end = original.find("\n", begin_idx)
    return original[: begin_line_end + 1] + new_block + original[end_idx:]


# ---------------------------------------------------------------------------
# Reporting.
# ---------------------------------------------------------------------------


def _print_report(
    findings: list[_Finding],
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> None:
    """Print the audit report."""
    from mgf.common import __version__

    print(
        f"mgf-common catch-up — auditing {target_dir}",
    )
    print(
        f"  Project:        {project_name} (kind: {project_kind})",
    )
    print(
        f"  mgf-common:     {__version__}",
    )
    print()
    print("Drift report:")
    print()
    for finding in findings:
        icon = _SEVERITY_ICON[finding.severity]
        print(f"  {icon} {finding.title}")
        # Indent the detail.
        for line in finding.detail.splitlines() or [""]:
            print(f"      {line}")
        print()

    fixable = sum(1 for f in findings if f.fix is not None)
    if fixable > 0:
        print(
            f"{fixable} finding(s) have mechanical fixes. "
            f"Re-run with `--apply` to apply (originals backed up).",
        )


def _exit_code_for(findings: list[_Finding]) -> int:
    """Exit non-zero if anything failed; warnings are zero (advisory)."""
    if any(f.severity == "fail" for f in findings):
        return 1
    return 0


def _next_major(version: str) -> str:
    """Return ``X.<Y+1>`` for an ``X.Y[.Z]`` version (rough upper bound)."""
    parts = version.split(".")
    if len(parts) < 2:
        return version
    try:
        major = int(parts[0])
        minor = int(parts[1])
    except ValueError:
        return version
    return f"{major}.{minor + 1}"


__all__ = ["add_catch_up_args", "run_catch_up"]
