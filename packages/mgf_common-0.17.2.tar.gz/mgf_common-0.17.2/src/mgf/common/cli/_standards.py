"""``mgf-common standards`` — print engineering-standards docs.

Closes the v0.9.0 deliverable: every project that depends on
``mgf-common`` should be able to read the canonical engineering
standards on demand without vendoring or path-hacking. The
standards live in ``docs/standards/`` in the source tree and are
shipped as wheel data so ``importlib.resources`` finds them after
``pip install mgf-common``.

Two modes:

  - ``mgf-common standards`` (no arg) — list available topics.
  - ``mgf-common standards <topic>`` — print that doc to stdout.

Topic names are case-insensitive and accept either the full file
name ("DESIGN_PRINCIPLES") or a shortened alias ("design").
"""

from __future__ import annotations

import sys
from importlib.resources import as_file, files
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import argparse


# Aliases let consumers type ``mgf-common standards logging`` instead
# of ``mgf-common standards LOGGING``. The canonical file name (upper-
# case) is the value; the alias (lower-case) is the key.
_ALIASES: dict[str, str] = {
    "design": "DESIGN_PRINCIPLES",
    "principles": "DESIGN_PRINCIPLES",
    "errors": "ERROR_HANDLING",
    "error_handling": "ERROR_HANDLING",
    "logging": "LOGGING",
    "config": "CONFIGURATION",
    "configuration": "CONFIGURATION",
    "security": "SECURITY_STANDARD",
    "security_standard": "SECURITY_STANDARD",
    "testing": "TESTING",
    "api": "API_DESIGN",
    "api_design": "API_DESIGN",
    "scope": "SCOPE",
    "components": "COMMON_COMPONENTS",
    "common_components": "COMMON_COMPONENTS",
    "readme": "README",
    "index": "README",
}


def add_standards_args(parser: argparse.ArgumentParser) -> None:
    """Register the ``standards`` subcommand's arguments."""
    parser.add_argument(
        "topic",
        nargs="?",
        default=None,
        help=(
            "Standards-doc topic to print (e.g., LOGGING, ERROR_HANDLING, "
            "SECURITY). Case-insensitive; aliases accepted (logging / "
            "errors / config / api / security / testing / scope / "
            "components / design). Omit to list available topics."
        ),
    )
    parser.add_argument(
        "--paths",
        action="store_true",
        help=(
            "List the resolved file paths instead of printing the docs. "
            "Useful for piping into other tools or copying the canon."
        ),
    )


def run_standards(args: argparse.Namespace) -> int:
    """Print the requested standards doc, or list topics."""
    standards_dir = _resolve_standards_dir()
    if standards_dir is None:
        print(
            "error: could not locate the mgf-common engineering-standards "
            "docs. The wheel ships them as data; if you're running from "
            "an editable install, ensure docs/standards/ exists in the "
            "repo root.",
            file=sys.stderr,
        )
        return 1

    topics = _list_topics(standards_dir)

    if args.topic is None:
        if args.paths:
            for name in topics:
                print(standards_dir / f"{name}.md")
        else:
            _print_topic_index(topics)
        return 0

    canonical = _resolve_topic(args.topic, topics)
    if canonical is None:
        print(
            f"error: unknown standards topic {args.topic!r}. "
            f"Available: {', '.join(topics)}.",
            file=sys.stderr,
        )
        print(
            "(Aliases also accepted; run `mgf-common standards` "
            "with no arg for the topic list.)",
            file=sys.stderr,
        )
        return 1

    target = standards_dir / f"{canonical}.md"
    if args.paths:
        print(target)
        return 0

    print(target.read_text(encoding="utf-8"))
    return 0


# ---------------------------------------------------------------------------
# Path resolution. Tries `importlib.resources` first (works for installed
# wheels — the standards ship as package data via hatchling force-include),
# then falls back to a repo-relative path (works for editable installs in
# the source tree).
# ---------------------------------------------------------------------------


def _resolve_standards_dir() -> Path | None:
    """Find the directory holding ``DESIGN_PRINCIPLES.md`` etc.

    Resolution order:
      1. ``importlib.resources.files("mgf.common._standards")`` —
         wheel data shipped via ``force-include``.
      2. Repo-relative path: ``mgf.common.__file__`` walked back to
         the repo root + ``docs/standards/``.

    Returns ``None`` if neither path resolves to a directory
    containing the canonical README.md.
    """
    # 1. Wheel-shipped data.
    try:
        ref = files("mgf.common._standards")
    except (ModuleNotFoundError, ImportError):
        ref = None

    if ref is not None:
        try:
            with as_file(ref / "README.md") as readme:
                if readme.is_file():
                    return readme.parent
        except (FileNotFoundError, ValueError):
            pass

    # 2. Editable-install repo-relative path.
    import mgf.common as _mc

    pkg_root = Path(_mc.__file__).resolve().parent  # src/mgf/common
    candidate = pkg_root.parent.parent.parent / "docs" / "standards"
    if candidate.is_dir() and (candidate / "README.md").is_file():
        return candidate

    return None


def _list_topics(standards_dir: Path) -> list[str]:
    """Return canonical topic names (file stems, no extension)."""
    return sorted(p.stem for p in standards_dir.glob("*.md"))


def _resolve_topic(name: str, topics: list[str]) -> str | None:
    """Resolve a user-supplied name to the canonical file stem."""
    # Case-insensitive direct match.
    upper = name.upper()
    for canonical in topics:
        if canonical.upper() == upper:
            return canonical

    # Alias.
    aliased = _ALIASES.get(name.lower())
    if aliased and aliased in topics:
        return aliased

    return None


def _print_topic_index(topics: list[str]) -> None:
    """Print a human-readable index of available topics."""
    from mgf.common import __version__

    print(
        f"mgf-common {__version__} — engineering-standards docs",
    )
    print()
    print("Topics:")
    width = max(len(c) for c in topics) + 2
    for canonical in topics:
        print(f"  {canonical:<{width}}")
    print()
    print(
        "Print a topic:  mgf-common standards <topic>",
    )
    print(
        "List paths:     mgf-common standards --paths",
    )
    print(
        "Aliases accepted (case-insensitive): logging, errors, config, "
        "api, security, testing, scope, components, design.",
    )


__all__ = ["add_standards_args", "run_standards"]
