"""Tests for BaseBrowserPrinter.

Tests verify correctness and accuracy of all browser streaming logic.
Uses real objects with duck-typed attributes (SimpleNamespace) as
message inputs and real queue subscribers.
"""

import unittest
from types import SimpleNamespace

from kiss.agents.vscode.browser_ui import (
    _DISPLAY_EVENT_TYPES,
    BaseBrowserPrinter,
    _coalesce_events,
)


def _start(printer: BaseBrowserPrinter) -> None:
    printer.start_recording()


def _drain(printer: BaseBrowserPrinter) -> list[dict]:
    return printer.stop_recording()


class TestCoalesceEvents(unittest.TestCase):
    def test_no_merge_missing_text_in_current(self):
        events = [
            {"type": "thinking_delta", "text": "A"},
            {"type": "thinking_delta"},
        ]
        result = _coalesce_events(events)
        assert len(result) == 2


class TestHandleMessage(unittest.TestCase):
    def test_subtype_not_tool_output(self):
        p = BaseBrowserPrinter()
        _start(p)
        msg = SimpleNamespace(subtype="other", data={"content": "x"})
        p.print(msg, type="message")
        assert _drain(p) == []

    def test_unknown_message_type_no_crash(self):
        p = BaseBrowserPrinter()
        _start(p)
        msg = SimpleNamespace(unknown_attr="value")
        p.print(msg, type="message")
        assert _drain(p) == []


class TestDisplayEventTypes(unittest.TestCase):
    def test_expected_types_present(self):
        expected = {
            "clear", "thinking_start", "thinking_delta", "thinking_end",
            "text_delta", "text_end", "tool_call", "tool_result",
            "system_output", "result", "system_prompt", "prompt",
            "task_done", "task_error", "task_stopped",
            "followup_suggestion",
        }
        assert _DISPLAY_EVENT_TYPES == expected


if __name__ == "__main__":
    unittest.main()
