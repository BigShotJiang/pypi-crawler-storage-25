# PM Agent — Jira AI Project Management

AI-powered project management dashboard with Jira integration and Claude Desktop MCP support.

## Features

- **Live Jira dashboard** — sprints, team workload, risks, velocity, burndown
- **AI chat** — ask questions about your project in plain English
- **Claude Desktop MCP** — use all tools directly inside Claude Desktop
- **Requirement enhancement** — convert raw notes into structured user stories
- **Full pipeline** — PDF → Jira tickets → sub-tasks → assign → email team

## Install

```bash
pip install pm-agent-jira
```

Requires Python 3.10+.

## Quick Start

```bash
# 1. Create .env config template
pm-agent init

# 2. Fill in your credentials (Jira, Azure OpenAI)
nano .env

# 3. Start the server  →  http://localhost:8000
pm-agent serve
```

## Claude Desktop Integration

Add to your Claude Desktop config (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "pm-agent": {
      "command": "pm-agent",
      "args": ["mcp"],
      "cwd": "/path/where/.env/lives"
    }
  }
}
```

Then ask Claude: *"What are the blocked tickets?"*, *"Show team workload"*, *"List all projects with their teams"*.

## Commands

| Command | Description |
|---|---|
| `pm-agent init` | Create `.env` config template |
| `pm-agent serve` | Start the web server (port 8000) |
| `pm-agent serve --port 9000` | Custom port |
| `pm-agent mcp` | Start MCP stdio server for Claude Desktop |
| `pm-agent version` | Print version |

## Configuration

| Variable | Description |
|---|---|
| `JIRA_BASE_URL` | Your Jira URL, e.g. `https://yourco.atlassian.net` |
| `JIRA_USER_EMAIL` | Jira account email |
| `JIRA_API_TOKEN` | Jira API token (from id.atlassian.com) |
| `JIRA_PROJECT_KEY` | Default project key, e.g. `MYAPP` |
| `JIRA_BOARD_ID` | Default board ID |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI key |
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI endpoint URL |
| `AZURE_OPENAI_DEPLOYMENT` | Deployment name, e.g. `gpt-4o` |
| `SECRET_KEY` | JWT secret for web UI auth |

## License

MIT
