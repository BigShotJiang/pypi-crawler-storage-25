"""pm-agent command-line interface."""
import argparse
import sys
from pathlib import Path

_ENV_TEMPLATE = """\
# ── Jira ──────────────────────────────────────────────────────────────────────
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_USER_EMAIL=you@example.com
JIRA_API_TOKEN=your-jira-api-token
JIRA_PROJECT_KEY=MYPROJECT
JIRA_BOARD_ID=1

# ── Azure OpenAI ──────────────────────────────────────────────────────────────
AZURE_OPENAI_API_KEY=your-azure-openai-key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o
AZURE_OPENAI_API_VERSION=2024-08-01-preview

# ── Web UI auth (JWT secret — change this!) ───────────────────────────────────
SECRET_KEY=change-me-to-a-long-random-string

# ── Langfuse observability (optional — leave blank to disable) ────────────────
LANGFUSE_PUBLIC_KEY=
LANGFUSE_SECRET_KEY=
LANGFUSE_BASE_URL=http://localhost:3000

# ── Email / SendGrid (optional) ───────────────────────────────────────────────
SENDGRID_API_KEY=
FROM_EMAIL=
"""

_CLAUDE_DESKTOP_CONFIG = """\
Add this to your Claude Desktop config
(macOS: ~/Library/Application Support/Claude/claude_desktop_config.json)
(Windows: %APPDATA%\\Claude\\claude_desktop_config.json):

{
  "mcpServers": {
    "pm-agent": {
      "command": "pm-agent",
      "args": ["mcp"]
    }
  }
}

Your credentials are stored in ~/.pm-agent/.env and loaded automatically.
"""


def _load_env():
    from dotenv import load_dotenv
    # Search order: cwd/.env → ~/.pm-agent/.env
    for candidate in [Path.cwd() / ".env", Path.home() / ".pm-agent" / ".env"]:
        if candidate.exists():
            load_dotenv(candidate)
            return str(candidate)
    return None


def cmd_init(args):
    dest = Path.home() / ".pm-agent" / ".env"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and not args.force:
        print(f".env already exists at {dest}")
        print("Use --force to overwrite.")
        return
    dest.write_text(_ENV_TEMPLATE)
    print(f"Created .env at {dest}")
    print("Edit it with your Jira credentials, then add pm-agent to Claude Desktop:\n")
    print(_CLAUDE_DESKTOP_CONFIG)


def cmd_serve(args):
    env_path = _load_env()
    if env_path:
        print(f"[pm-agent] Loaded env from {env_path}", file=sys.stderr)
    else:
        print("[pm-agent] Warning: no .env found. Run 'pm-agent init' first.", file=sys.stderr)

    import uvicorn
    from backend.main import app

    print(f"[pm-agent] Starting server on http://{args.host}:{args.port}")
    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


def cmd_mcp(args):
    env_path = _load_env()
    if not env_path:
        print("[pm-agent] Warning: no .env found. Run 'pm-agent init' first.", file=sys.stderr)

    import asyncio
    from backend.mcp_server import main
    asyncio.run(main())


def cmd_version(args):
    from pm_agent import __version__
    print(f"pm-agent {__version__}")


def main():
    parser = argparse.ArgumentParser(
        prog="pm-agent",
        description="PM Agent — AI-powered Jira project management + Claude Desktop MCP",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # init
    p_init = sub.add_parser("init", help="Create a .env configuration template in the current directory")
    p_init.add_argument("--force", action="store_true", help="Overwrite an existing .env")
    p_init.set_defaults(func=cmd_init)

    # serve
    p_serve = sub.add_parser("serve", help="Start the PM Agent web server (API + dashboard)")
    p_serve.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    p_serve.add_argument("--port", type=int, default=8000, help="Port (default: 8000)")
    p_serve.add_argument("--reload", action="store_true", help="Auto-reload on code changes (dev mode)")
    p_serve.set_defaults(func=cmd_serve)

    # mcp
    p_mcp = sub.add_parser("mcp", help="Start the MCP stdio server for Claude Desktop")
    p_mcp.set_defaults(func=cmd_mcp)

    # version
    p_ver = sub.add_parser("version", help="Print version and exit")
    p_ver.set_defaults(func=cmd_version)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
