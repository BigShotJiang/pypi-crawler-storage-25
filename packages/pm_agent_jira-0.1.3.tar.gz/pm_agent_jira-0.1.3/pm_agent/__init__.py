"""PM Agent — AI-powered Jira project management with Claude Desktop MCP."""
__version__ = "0.1.0"
