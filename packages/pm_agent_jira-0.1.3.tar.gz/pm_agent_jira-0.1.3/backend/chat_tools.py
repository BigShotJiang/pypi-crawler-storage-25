from typing import Optional
from backend.routes.dashboard import (
    get_summary,
    get_sprints,
    get_team,
    get_risks,
    get_stale_tickets,
    get_velocity,
    get_burndown_active,
    get_assignee_tickets,
    get_projects_with_teams,
)
from backend.tools.jira_tool import jira_client

_NOT_CONFIGURED = (
    "Jira is not configured. Please run 'pm-agent init' in your terminal, "
    "then edit ~/.pm-agent/.env and set JIRA_BASE_URL, JIRA_EMAIL, and JIRA_API_TOKEN. "
    "Restart Claude Desktop after saving the file."
)


def _check_configured():
    if not jira_client.is_configured():
        raise RuntimeError(_NOT_CONFIGURED)


def tool_get_summary(project_key: Optional[str] = None, board_id: Optional[str] = None) -> dict:
    _check_configured()
    return get_summary(project_key=project_key, board_id=board_id, user=None, _max_results=100)


def tool_get_sprints(board_id: Optional[str] = None) -> list:
    _check_configured()
    return get_sprints(board_id=board_id, user=None)


def tool_get_team_workload(project_key: Optional[str] = None, board_id: Optional[str] = None) -> list:
    _check_configured()
    return get_team(project_key=project_key, board_id=board_id, user=None, _max_results=100)


def tool_get_risks(project_key: Optional[str] = None, board_id: Optional[str] = None) -> dict:
    _check_configured()
    return get_risks(project_key=project_key, board_id=board_id, user=None, _max_results=100)


def tool_get_stale_tickets(project_key: Optional[str] = None) -> list:
    _check_configured()
    return get_stale_tickets(project_key=project_key, user=None, _max_results=100)


def tool_get_velocity(project_key: Optional[str] = None, board_id: Optional[str] = None) -> dict:
    _check_configured()
    return get_velocity(project_key=project_key, board_id=board_id, user=None)


def tool_get_burndown(board_id: Optional[str] = None) -> dict:
    _check_configured()
    return get_burndown_active(board_id=board_id, user=None)


def tool_get_tickets_by_assignee(assignee: str, project_key: Optional[str] = None) -> dict:
    _check_configured()
    return get_assignee_tickets(assignee=assignee, project_key=project_key, user=None)


def tool_get_projects_with_teams() -> list:
    _check_configured()
    return get_projects_with_teams(max_results=100)


def tool_list_projects() -> list:
    _check_configured()
    projects = jira_client.list_projects()
    boards = jira_client.list_boards()
    board_by_project: dict = {}
    for b in boards:
        board_by_project[b["id"]] = b
    return [
        {
            "key": p["key"],
            "name": p["name"],
            "type": p.get("type", ""),
            "id": p["id"],
        }
        for p in projects
    ]
