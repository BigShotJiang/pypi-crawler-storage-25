import os
import re
import sys
from typing import Optional
from langfuse import Langfuse

# ── Sensitive data masking ────────────────────────────────────────────────────

_MASK_PATTERNS = [
    # Email addresses
    (re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'), '[email]'),
    # Jira API tokens (start with ATATT)
    (re.compile(r'ATATT[A-Za-z0-9+/=_.-]{10,}'), '[jira-token]'),
    # Langfuse keys
    (re.compile(r'(pk|sk)-lf-[a-f0-9-]{10,}'), '[langfuse-key]'),
    # Bearer / Authorization header values
    (re.compile(r'(?i)(bearer|token|authorization)[\s:]+[A-Za-z0-9+/=_.-]{20,}'), r'\1 [token]'),
    # Generic long API keys: 40+ contiguous alphanumeric chars (catches Azure/OpenAI keys)
    (re.compile(r'[A-Za-z0-9]{40,}'), '[api-key]'),
]


def mask_sensitive(text: str) -> str:
    """Replace known sensitive patterns in a string with safe placeholders."""
    if not isinstance(text, str):
        return text
    for pattern, replacement in _MASK_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def mask_dict(data) -> dict:
    """Recursively mask sensitive strings in a dict/list structure."""
    if isinstance(data, dict):
        return {k: mask_dict(v) for k, v in data.items()}
    if isinstance(data, list):
        return [mask_dict(v) for v in data]
    if isinstance(data, str):
        return mask_sensitive(data)
    return data

_langfuse_client: Optional[Langfuse] = None


def get_langfuse() -> Langfuse:
    global _langfuse_client
    if _langfuse_client is None:
        pk = os.environ.get("LANGFUSE_PUBLIC_KEY")
        sk = os.environ.get("LANGFUSE_SECRET_KEY")
        host = os.environ.get("LANGFUSE_BASE_URL", "http://localhost:3000")
        if not pk or not sk:
            print(
                f"[Langfuse] WARNING: LANGFUSE_PUBLIC_KEY or LANGFUSE_SECRET_KEY not set — tracing disabled",
                file=sys.stderr,
            )
        # Short timeout so a missing Langfuse server (Docker off) fails fast
        _langfuse_client = Langfuse(
            public_key=pk,
            secret_key=sk,
            host=host,
            request_timeout=2,
        )
    return _langfuse_client


def create_trace(name: str, metadata: dict = None, user_id: str = None):
    try:
        lf = get_langfuse()
        return lf.trace(name=name, metadata=metadata or {}, user_id=user_id)
    except Exception as e:
        print(f"[Langfuse] create_trace failed: {e}", file=sys.stderr)
        return None


def start_generation(trace_id: str, name: str, model: str, prompt: str):
    if not trace_id:
        return None
    try:
        lf = get_langfuse()
        return lf.generation(
            trace_id=trace_id,
            name=name,
            model=model,
            input=[{"role": "user", "content": mask_sensitive(prompt)}],
        )
    except Exception as e:
        print(f"[Langfuse] start_generation failed: {e}", file=sys.stderr)
        return None


def end_generation(generation, output: str, usage: dict = None):
    if generation is None:
        return
    try:
        generation.end(output=output, usage=usage)
    except Exception as e:
        print(f"[Langfuse] end_generation failed: {e}", file=sys.stderr)


def usage_from_response(response) -> dict:
    """Extract token counts from an OpenAI response object."""
    try:
        u = response.usage
        return {
            "input": u.prompt_tokens,
            "output": u.completion_tokens,
            "total": u.total_tokens,
        }
    except Exception:
        return {}


def record_pipeline_scores(trace_id: str, stats: dict):
    lf = get_langfuse()
    try:
        lf.score(trace_id=trace_id, name="tickets_created", value=stats.get("tickets_created", 0))
        lf.score(trace_id=trace_id, name="sub_tasks_created", value=stats.get("sub_tasks_created", 0))
        lf.score(trace_id=trace_id, name="emails_sent", value=stats.get("emails_sent", 0))
    except Exception as e:
        print(f"Warning: Could not record Langfuse scores: {e}")
