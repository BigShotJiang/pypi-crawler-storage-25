import asyncio
import os
from datetime import datetime
from typing import Optional

_last_check: Optional[datetime] = None
_ws_manager = None


def set_ws_manager(manager):
    global _ws_manager
    _ws_manager = manager


async def jira_sync_loop():
    """
    Poll Jira every JIRA_SYNC_INTERVAL seconds for recently updated issues
    across ALL projects (no project filter), then broadcast to WebSocket clients.
    """
    global _last_check
    from backend.tools.jira_tool import jira_client
    interval = int(os.environ.get("JIRA_SYNC_INTERVAL", "30"))

    while True:
        await asyncio.sleep(interval)
        try:
            # No project_key passed → queries across all accessible projects
            updated = jira_client.get_recently_updated_issues(since_minutes=1)
            if updated and _ws_manager:
                # Group by project so the frontend can selectively refresh
                by_project: dict = {}
                for issue in updated:
                    pk = issue.get("fields", {}).get("project", {}).get("key", "UNKNOWN")
                    by_project.setdefault(pk, []).append(issue["key"])

                await _ws_manager.broadcast({
                    "type": "jira_updated",
                    "updated_keys": [i["key"] for i in updated],
                    "by_project": by_project,
                    "timestamp": datetime.utcnow().isoformat(),
                })
            _last_check = datetime.utcnow()
        except Exception as e:
            print(f"Jira sync error: {e}")
