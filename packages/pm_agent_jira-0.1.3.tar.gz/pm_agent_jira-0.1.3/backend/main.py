import os
import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from dotenv import load_dotenv

load_dotenv()

from backend.routes.websocket import manager as ws_manager
from backend.nodes.node_8_broadcast_updates import set_ws_manager
from backend.jira_sync import jira_sync_loop, set_ws_manager as set_sync_manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    set_ws_manager(ws_manager)
    set_sync_manager(ws_manager)
    task = asyncio.create_task(jira_sync_loop())
    yield
    task.cancel()


app = FastAPI(title="PM Agent v2", version="2.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

from backend.routes import upload, dashboard, auth_routes, websocket, enhance, jira_meta, chat
from backend.mcp_server import create_starlette_app

app.include_router(upload.router, tags=["upload"])
app.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
app.include_router(auth_routes.router, tags=["auth"])
app.include_router(websocket.router, tags=["websocket"])
app.include_router(enhance.router, tags=["enhance"])
app.include_router(jira_meta.router)
app.include_router(chat.router, tags=["chat"])

app.mount("/mcp", create_starlette_app(prefix="/mcp"))


@app.get("/health")
def health():
    return {"status": "ok", "service": "PM Agent v2"}


# ── Serve React frontend ───────────────────────────────────────────────────────
# Look for the built frontend in two places:
#   1. pm_agent/static/ (bundled inside the installed package)
#   2. frontend/dist/  (local dev checkout)
def _find_static() -> Path | None:
    candidates = [
        Path(__file__).parent.parent / "pm_agent" / "static",  # installed
        Path(__file__).parent.parent / "frontend" / "dist",     # local dev
    ]
    for p in candidates:
        if p.is_dir() and (p / "index.html").exists():
            return p
    return None

_static_dir = _find_static()
if _static_dir:
    app.mount("/assets", StaticFiles(directory=str(_static_dir / "assets")), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def serve_spa(full_path: str):
        # Serve index.html for all non-API routes (SPA client-side routing)
        return FileResponse(str(_static_dir / "index.html"))
