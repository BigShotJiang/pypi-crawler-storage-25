import os
from typing import Optional

PROMPTS = {
    "pm-agent-extract-requirements": {
        "prompt": """You are an expert project manager and business analyst.
Analyze the following document text and extract ALL actionable requirements.

For each requirement provide a JSON object with:
- title: concise title max 10 words
- description: detailed description
- priority: one of "Critical", "High", "Medium", "Low"
- type: one of "Epic", "Story", "Task", "Bug"
- story_points: Fibonacci number only (1,2,3,5,8,13,21)
- acceptance_criteria: array of testable strings
- assignee_hint: team/role e.g. "Backend Developer", "Frontend Developer", "QA Engineer", "DevOps Engineer"
- labels: array of strings
- complexity: float 0.0-1.0

Document text:
{{document_text}}

Return ONLY valid JSON array. No markdown, no explanation.""",
        "version": 1,
        "labels": ["pm-agent", "extraction"],
    },
    "pm-agent-classify-complexity": {
        "prompt": """You are a sprint planning expert. Determine if this requirement is too large for a single sprint.

Title: {{title}}
Description: {{description}}
Story Points: {{story_points}}
Complexity: {{complexity}}

Auto-flag too_large=true if story_points > 8 OR complexity > 0.7

Return ONLY valid JSON: {"too_large": true/false, "reason": "one sentence"}""",
        "version": 1,
        "labels": ["pm-agent", "classification"],
    },
    "pm-agent-decompose-ticket": {
        "prompt": """You are a technical lead breaking down a large requirement into 3-7 sub-tasks.
Each sub-task must be independently completable within 1-3 days.

Parent:
Title: {{title}}
Description: {{description}}
Acceptance Criteria: {{acceptance_criteria}}
Story Points: {{story_points}}

Each sub-task needs: title, description, story_points (1-5 Fibonacci), acceptance_criteria (array), type ("Task" or "Story")

Return ONLY valid JSON array of sub-task objects.""",
        "version": 1,
        "labels": ["pm-agent", "decomposition"],
    },
    "pm-agent-enhance-requirement": {
        "prompt": """You are a senior business analyst creating professional specifications.

Raw requirement:
{{raw_text}}

{{feedback_section}}

Return structured specification JSON with:
- feature_title: professional name
- goal: business objective 1-2 sentences
- acceptance_criteria: array 4-8 items starting "The system shall..."
- dependencies: array (empty [] if none)
- effort_estimate: {"story_points": number, "time_estimate": "X days"}
- suggested_sprint: "Sprint 1", "Sprint 2", or "Sprint 3"
- technical_notes: array of considerations

Return ONLY valid JSON.""",
        "version": 1,
        "labels": ["pm-agent", "enhancement"],
    },
}


def upload_prompts_to_langfuse():
    """Create or update all prompts in Langfuse."""
    try:
        from langfuse import Langfuse
        lf = Langfuse(
            public_key=os.environ.get("LANGFUSE_PUBLIC_KEY"),
            secret_key=os.environ.get("LANGFUSE_SECRET_KEY"),
            host=os.environ.get("LANGFUSE_BASE_URL", "http://localhost:3000"),
        )
        for name, config in PROMPTS.items():
            try:
                lf.create_prompt(
                    name=name,
                    prompt=config["prompt"],
                    labels=config.get("labels", []),
                )
                print(f"Uploaded prompt: {name}")
            except Exception as e:
                print(f"Warning: Could not upload prompt '{name}': {e}")
    except Exception as e:
        print(f"Warning: Could not connect to Langfuse for prompt upload: {e}")


def get_prompt(name: str, **kwargs) -> str:
    """Fetch prompt from Langfuse with fallback to local PROMPTS dict, then compile with kwargs."""
    template: Optional[str] = None

    # Try to fetch from Langfuse
    try:
        from langfuse import Langfuse
        lf = Langfuse(
            public_key=os.environ.get("LANGFUSE_PUBLIC_KEY"),
            secret_key=os.environ.get("LANGFUSE_SECRET_KEY"),
            host=os.environ.get("LANGFUSE_BASE_URL", "http://localhost:3000"),
        )
        lf_prompt = lf.get_prompt(name)
        template = lf_prompt.prompt
    except Exception:
        pass

    # Fallback to local
    if template is None:
        local = PROMPTS.get(name)
        if local is None:
            raise ValueError(f"Prompt '{name}' not found locally or in Langfuse")
        template = local["prompt"]

    # Compile {{variable}} substitutions
    compiled = template
    for key, value in kwargs.items():
        compiled = compiled.replace("{{" + key + "}}", str(value) if value is not None else "")

    return compiled
