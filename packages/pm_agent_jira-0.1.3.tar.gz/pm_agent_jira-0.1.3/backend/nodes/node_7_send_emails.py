from backend.agent_state import AgentState


def node_send_emails(state: AgentState) -> AgentState:
    # Email notifications disabled — not required at this stage
    return {**state, "emails_sent": []}
