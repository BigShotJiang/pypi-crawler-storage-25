from backend.agent_state import AgentState
from backend.tools.jira_tool import jira_client


def node_assign_tickets(state: AgentState) -> AgentState:
    """Step 6: Assign tickets to team members based on workload."""
    board_id = state["board_id"]

    sprint = jira_client.get_active_sprint(board_id)
    if not sprint:
        return {**state, "assignees": {}}

    members = jira_client.get_sprint_members(sprint["id"])
    if not members:
        return {**state, "assignees": {}}

    all_tickets = state["jira_tickets"] + state["sub_tasks"]
    assignees = {}

    for ticket in all_tickets:
        hint = ticket.get("assignee_hint", "").lower()

        candidates = members
        if hint:
            filtered = [
                m for m in members
                if any(
                    word in m["displayName"].lower() or word in hint
                    for word in ["backend", "frontend", "qa", "devops", "full"]
                    if word in hint
                )
            ]
            candidates = filtered if filtered else members

        best = min(candidates, key=lambda m: m.get("openTickets", 0))

        try:
            success = jira_client.assign_issue(ticket["key"], best["accountId"])
            if success:
                assignees[ticket["key"]] = best["accountId"]
                ticket["assignee"] = {
                    "accountId": best["accountId"],
                    "displayName": best["displayName"],
                    "emailAddress": best.get("emailAddress", ""),
                }
                best["openTickets"] = best.get("openTickets", 0) + 1
        except Exception as e:
            print(f"Warning: Failed to assign ticket {ticket['key']}: {e}")

    return {
        **state,
        "assignees": assignees,
        "jira_tickets": state["jira_tickets"],
        "sub_tasks": state["sub_tasks"],
    }
