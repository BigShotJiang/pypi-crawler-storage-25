from backend.agent_state import AgentState
from backend.tools.jira_tool import jira_client


def node_create_tickets(state: AgentState) -> AgentState:
    """Step 4: Create Jira tickets for all requirements."""
    project_key = state["project_key"]
    requirements = state["requirements"]
    jira_tickets = []

    for req in requirements:
        try:
            result = jira_client.create_issue(
                project_key=project_key,
                title=req["title"],
                description=req["description"],
                issue_type=req.get("type", "Story"),
                priority=req.get("priority", "Medium"),
                story_points=req.get("story_points", 3),
                labels=req.get("labels", []),
                acceptance_criteria=req.get("acceptance_criteria", []),
            )
            ticket = {
                "key": result["key"],
                "id": result["id"],
                "title": req["title"],
                "description": req["description"],
                "priority": req.get("priority", "Medium"),
                "type": req.get("type", "Story"),
                "story_points": req.get("story_points", 3),
                "assignee": None,
                "status": "To Do",
                "url": result["url"],
                "labels": req.get("labels", []),
                "acceptance_criteria": req.get("acceptance_criteria", []),
                "parent_key": None,
                "too_large": req.get("too_large", False),
                "assignee_hint": req.get("assignee_hint", ""),
            }
            jira_tickets.append(ticket)
        except Exception as e:
            print(f"Warning: Failed to create Jira ticket for '{req.get('title')}': {e}")

    return {**state, "jira_tickets": jira_tickets}
