from backend.agent_state import AgentState

# WebSocket manager is injected from main.py
_ws_manager = None


def set_ws_manager(manager):
    global _ws_manager
    _ws_manager = manager


def node_broadcast_updates(state: AgentState) -> AgentState:
    """Step 8: Broadcast update to all WebSocket clients."""
    all_tickets = state["jira_tickets"] + state["sub_tasks"]
    ticket_keys = [t["key"] for t in all_tickets]

    if _ws_manager:
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            loop.create_task(
                _ws_manager.broadcast({
                    "type": "tickets_created",
                    "tickets": ticket_keys,
                    "count": len(ticket_keys),
                })
            )
        except Exception as e:
            print(f"Warning: WebSocket broadcast failed: {e}")

    return state
