import os
import json
from openai import AzureOpenAI
from backend.agent_state import AgentState
from backend.prompts import get_prompt
from backend.tools.jira_tool import jira_client
from backend.tracing import start_generation, end_generation, usage_from_response


def node_decompose_tickets(state: AgentState) -> AgentState:
    """Step 5: Decompose large tickets into sub-tasks."""
    client = AzureOpenAI(
        api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    )
    deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-5-nano")
    project_key = state["project_key"]
    trace_id = state.get("trace_id")

    large_tickets = [t for t in state["jira_tickets"] if t.get("too_large")]
    sub_tasks = []

    for ticket in large_tickets:
        try:
            prompt = get_prompt(
                "pm-agent-decompose-ticket",
                title=ticket["title"],
                description=ticket["description"],
                acceptance_criteria="\n".join(ticket.get("acceptance_criteria", [])),
                story_points=ticket.get("story_points", 8),
            )

            generation = start_generation(
                trace_id=trace_id,
                name=f"decompose_{ticket.get('key', 'ticket')}",
                model=deployment,
                prompt=prompt,
            )

            response = client.chat.completions.create(
                model=deployment,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=2000,
            )
            raw = response.choices[0].message.content.strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            sub_task_defs = json.loads(raw)

            end_generation(
                generation,
                output=f"Decomposed into {len(sub_task_defs)} sub-tasks",
                usage=usage_from_response(response),
            )

            for st_def in sub_task_defs[:7]:
                try:
                    result = jira_client.create_issue(
                        project_key=project_key,
                        title=st_def["title"],
                        description=st_def.get("description", ""),
                        issue_type=st_def.get("type", "Task"),
                        priority=ticket.get("priority", "Medium"),
                        story_points=st_def.get("story_points", 3),
                        labels=ticket.get("labels", []),
                        acceptance_criteria=st_def.get("acceptance_criteria", []),
                        parent_key=ticket["key"],
                    )
                    sub_tasks.append({
                        "key": result["key"],
                        "id": result["id"],
                        "title": st_def["title"],
                        "description": st_def.get("description", ""),
                        "priority": ticket.get("priority", "Medium"),
                        "type": st_def.get("type", "Task"),
                        "story_points": st_def.get("story_points", 3),
                        "assignee": None,
                        "status": "To Do",
                        "url": result["url"],
                        "labels": ticket.get("labels", []),
                        "acceptance_criteria": st_def.get("acceptance_criteria", []),
                        "parent_key": ticket["key"],
                        "too_large": False,
                        "assignee_hint": ticket.get("assignee_hint", ""),
                    })
                except Exception as e:
                    print(f"Warning: Failed to create sub-task: {e}")
        except Exception as e:
            print(f"Warning: Failed to decompose ticket {ticket.get('key')}: {e}")

    return {**state, "sub_tasks": sub_tasks}
