import os
import json
from openai import AzureOpenAI
from backend.agent_state import AgentState
from backend.prompts import get_prompt
from backend.tracing import start_generation, end_generation, usage_from_response

LARGE_KEYWORDS = {
    "integration", "migration", "refactor", "platform", "system", "module",
    "pipeline", "architecture", "onboarding", "rollout",
}


def node_classify_complexity(state: AgentState) -> AgentState:
    """Step 3: Classify each requirement's complexity."""
    client = AzureOpenAI(
        api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    )
    deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-5-nano")
    requirements = state["requirements"]
    trace_id = state.get("trace_id")

    for idx, req in enumerate(requirements):
        sp = req.get("story_points", 0)
        complexity = req.get("complexity", 0)
        text = f"{req.get('title', '')} {req.get('description', '')}".lower()

        if sp > 8 or complexity > 0.7 or any(kw in text for kw in LARGE_KEYWORDS):
            req["too_large"] = True
            continue

        try:
            prompt = get_prompt(
                "pm-agent-classify-complexity",
                title=req.get("title"),
                description=req.get("description"),
                story_points=sp,
                complexity=complexity,
            )

            generation = start_generation(
                trace_id=trace_id,
                name=f"classify_complexity_{idx}",
                model=deployment,
                prompt=prompt,
            )

            response = client.chat.completions.create(
                model=deployment,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=200,
            )
            raw = response.choices[0].message.content.strip()
            result = json.loads(raw)
            req["too_large"] = result.get("too_large", False)

            end_generation(
                generation,
                output=raw,
                usage=usage_from_response(response),
            )
        except Exception:
            req["too_large"] = sp > 5

    return {**state, "requirements": requirements}
