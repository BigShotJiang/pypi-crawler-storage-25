import os
import json
import re
from openai import AzureOpenAI
from backend.agent_state import AgentState
from backend.prompts import get_prompt
from backend.tracing import start_generation, end_generation, usage_from_response


def node_extract_requirements(state: AgentState) -> AgentState:
    """Step 2: Extract requirements from document text using GPT."""
    client = AzureOpenAI(
        api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    )
    deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-5-nano")
    prompt = get_prompt("pm-agent-extract-requirements", document_text=state["document_text"])

    generation = start_generation(
        trace_id=state.get("trace_id"),
        name="extract_requirements",
        model=deployment,
        prompt=prompt,
    )

    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=4000,
    )

    raw = response.choices[0].message.content.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    try:
        requirements = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r'\[.*\]', raw, re.DOTALL)
        requirements = json.loads(match.group()) if match else []

    end_generation(
        generation,
        output=f"Extracted {len(requirements)} requirements",
        usage=usage_from_response(response),
    )

    for req in requirements:
        req.setdefault("too_large", False)

    return {**state, "requirements": requirements}
