from backend.agent_state import AgentState
from backend.tools.pdf_tool import extract_text_from_pdf


def node_read_pdf(state: AgentState) -> AgentState:
    """Step 1: Extract text from PDF."""
    pdf_path = state["pdf_path"]
    document_text = extract_text_from_pdf(pdf_path)
    return {**state, "document_text": document_text}
