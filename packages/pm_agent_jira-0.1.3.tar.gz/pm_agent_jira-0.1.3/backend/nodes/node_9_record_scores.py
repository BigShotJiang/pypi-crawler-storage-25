from backend.agent_state import AgentState
from backend.tracing import record_pipeline_scores


def node_record_scores(state: AgentState) -> AgentState:
    """Step 9: Record performance scores in Langfuse."""
    stats = {
        "tickets_created": len(state.get("jira_tickets", [])),
        "sub_tasks_created": len(state.get("sub_tasks", [])),
        "emails_sent": len(state.get("emails_sent", [])),
        "requirements_extracted": len(state.get("requirements", [])),
    }

    trace_id = state.get("trace_id")
    if trace_id:
        try:
            record_pipeline_scores(trace_id, stats)
        except Exception as e:
            print(f"Warning: Could not record scores: {e}")

    return {**state, "pipeline_stats": stats}
