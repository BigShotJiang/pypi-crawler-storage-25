import os
import jwt
from datetime import datetime, timedelta
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer(auto_error=False)


def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)):
    if credentials is None:
        return {"sub": "dev", "email": "dev@example.com", "name": "Developer"}
    try:
        payload = jwt.decode(
            credentials.credentials,
            os.environ.get("SECRET_KEY", "dev-secret"),
            algorithms=["HS256"],
        )
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")


def get_current_user(user=Depends(verify_token)):
    return user
