from langgraph.graph import StateGraph, END
from backend.agent_state import AgentState
from backend.nodes.node_1_read_pdf import node_read_pdf
from backend.nodes.node_2_extract_requirements import node_extract_requirements
from backend.nodes.node_3_classify_complexity import node_classify_complexity
from backend.nodes.node_4_create_tickets import node_create_tickets
from backend.nodes.node_5_decompose_tickets import node_decompose_tickets
from backend.nodes.node_6_assign_tickets import node_assign_tickets
from backend.nodes.node_7_send_emails import node_send_emails
from backend.nodes.node_8_broadcast_updates import node_broadcast_updates
from backend.nodes.node_9_record_scores import node_record_scores


def build_graph():
    builder = StateGraph(AgentState)
    builder.add_node("read_pdf", node_read_pdf)
    builder.add_node("extract_requirements", node_extract_requirements)
    builder.add_node("classify_complexity", node_classify_complexity)
    builder.add_node("create_tickets", node_create_tickets)
    builder.add_node("decompose_tickets", node_decompose_tickets)
    builder.add_node("assign_tickets", node_assign_tickets)
    builder.add_node("send_emails", node_send_emails)
    builder.add_node("broadcast_updates", node_broadcast_updates)
    builder.add_node("record_scores", node_record_scores)

    builder.set_entry_point("read_pdf")
    builder.add_edge("read_pdf", "extract_requirements")
    builder.add_edge("extract_requirements", "classify_complexity")
    builder.add_edge("classify_complexity", "create_tickets")
    builder.add_edge("create_tickets", "decompose_tickets")
    builder.add_edge("decompose_tickets", "assign_tickets")
    builder.add_edge("assign_tickets", "send_emails")
    builder.add_edge("send_emails", "broadcast_updates")
    builder.add_edge("broadcast_updates", "record_scores")
    builder.add_edge("record_scores", END)

    return builder.compile()


pipeline_graph = build_graph()
