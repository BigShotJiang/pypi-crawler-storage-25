from typing import TypedDict, Optional, List, Dict, Any


class Requirement(TypedDict):
    title: str
    description: str
    priority: str
    type: str
    story_points: int
    acceptance_criteria: List[str]
    assignee_hint: str
    labels: List[str]
    complexity: float
    too_large: bool


class JiraTicket(TypedDict):
    key: str
    id: str
    title: str
    description: str
    priority: str
    type: str
    story_points: int
    assignee: Optional[Dict]
    status: str
    url: str
    labels: List[str]
    acceptance_criteria: List[str]
    parent_key: Optional[str]


class AgentState(TypedDict):
    pdf_path: str
    project_key: str   # Jira project key for this run (e.g. "MYAPP")
    board_id: str      # Jira board id for this run (e.g. "42")
    document_text: str
    requirements: List[Requirement]
    jira_tickets: List[JiraTicket]
    sub_tasks: List[JiraTicket]
    assignees: Dict[str, str]  # ticket_key -> assignee_account_id
    emails_sent: List[str]
    pipeline_stats: Dict[str, Any]
    error: Optional[str]
    trace_id: Optional[str]
