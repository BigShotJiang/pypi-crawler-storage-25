#!/usr/bin/env python3
"""
MCP Server for PM Agent.
Exposes Jira dashboard tools and the requirement enhancement pipeline
via the Model Context Protocol.

Usage:
    python -m backend.mcp_server

Claude Desktop config (~/.claude/claude_desktop_config.json):
    {
      "mcpServers": {
        "pm-agent": {
          "command": "python",
          "args": ["-m", "backend.mcp_server"],
          "cwd": "<path-to-project>",
          "env": { "PYTHONPATH": "<path-to-project>" }
        }
      }
    }
"""
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

# Ensure project root is on the path when run as a script
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv

def _load_env_file():
    """Search for .env in well-known locations; skip site-packages (wrong for PyPI installs)."""
    candidates = [
        Path.home() / ".pm-agent" / ".env",   # recommended: pm-agent init writes here
        Path.cwd() / ".env",                   # fallback: dev / local project run
    ]
    for p in candidates:
        if p.exists():
            load_dotenv(dotenv_path=p)
            return str(p)
    # Env vars may already be set via MCP server config 'env' section — that's fine too.
    return None

import time as _startup_time
_t_start = _startup_time.time()
_loaded_env = _load_env_file()
if _loaded_env:
    print(f"[PM Agent MCP] .env loaded from: {_loaded_env}", file=sys.stderr)
else:
    print("[PM Agent MCP] No .env file found — relying on environment variables.", file=sys.stderr)
print(f"[PM Agent MCP] JIRA_BASE_URL = {os.environ.get('JIRA_BASE_URL', 'NOT SET')}", file=sys.stderr)
print(f"[PM Agent MCP] LANGFUSE_PUBLIC_KEY = {'SET' if os.environ.get('LANGFUSE_PUBLIC_KEY') else 'NOT SET'}", file=sys.stderr)

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types
print(f"[PM Agent MCP] mcp imported at +{_startup_time.time()-_t_start:.2f}s", file=sys.stderr)

# Lightweight imports only — heavy modules (pipeline_graph, enhance, tracing) loaded lazily
from backend.chat_tools import (
    tool_get_summary,
    tool_get_sprints,
    tool_get_team_workload,
    tool_get_risks,
    tool_get_stale_tickets,
    tool_get_velocity,
    tool_get_burndown,
    tool_get_tickets_by_assignee,
    tool_list_projects,
    tool_get_projects_with_teams,
)
from backend.tools.jira_tool import jira_client
print(f"[PM Agent MCP] backend imported at +{_startup_time.time()-_t_start:.2f}s", file=sys.stderr)

server = Server("pm-agent")
print(f"[PM Agent MCP] server created at +{_startup_time.time()-_t_start:.2f}s", file=sys.stderr)


def _prewarm_cache():
    """Fetch all common Jira data in parallel background threads at startup."""
    if not jira_client.is_configured():
        print("[PM Agent MCP] Skipping cache warm-up — Jira credentials not set.", file=sys.stderr)
        return

    import threading
    from concurrent.futures import ThreadPoolExecutor

    def _safe(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception:
            return None

    def _run_all():
        from backend.routes.dashboard import get_projects_with_teams as _gpwt
        # Phase 1: fetch foundational data in parallel
        with ThreadPoolExecutor(max_workers=6) as pool:
            f_issues  = pool.submit(_safe, jira_client.get_project_issues, max_results=100)
            f_sprints = pool.submit(_safe, jira_client.get_sprints, board_id="")
            f_proj    = pool.submit(_safe, jira_client.list_projects)
            f_boards  = pool.submit(_safe, jira_client.list_boards)
            f_stale   = pool.submit(_safe, jira_client.get_stale_tickets, days=2, max_results=100)
            f_pwt     = pool.submit(_safe, _gpwt, 100)
            sprints = f_sprints.result() or []
            for f in [f_issues, f_proj, f_boards, f_stale, f_pwt]:
                f.result()

        # Phase 2: prewarm sprint issues for active + recent closed sprints
        active_ids = [s.get("id") for s in sprints if s.get("state") == "active"]
        recent_closed_ids = [s.get("id") for s in sprints if s.get("state") == "closed"][-5:]
        sprint_ids_to_warm = list(set(active_ids + recent_closed_ids))
        if sprint_ids_to_warm:
            with ThreadPoolExecutor(max_workers=min(len(sprint_ids_to_warm), 8)) as pool:
                futures = [pool.submit(_safe, jira_client.get_sprint_issues, sid) for sid in sprint_ids_to_warm]
                for f in futures:
                    f.result()

    threading.Thread(target=_run_all, daemon=True).start()


_prewarm_cache()


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="get_dashboard_summary",
            description=(
                "Get overall project summary: total tickets, completed, in progress, "
                "blocked, weekly activity, sprint completion rates, priority distribution."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_key": {
                        "type": "string",
                        "description": "Jira project key (optional, leave empty for all projects)",
                    }
                },
            },
        ),
        types.Tool(
            name="get_sprint_status",
            description=(
                "Get all sprints with completion %, story points done/total, "
                "days remaining, ticket counts (todo/in_progress/done/blocked)."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="get_team_workload",
            description=(
                "Get team members' workload for ONE specific project: tickets assigned, story points, "
                "in-progress/done/blocked counts. "
                "Use project_key to filter to a single project. "
                "IMPORTANT: If the user asks about multiple projects or all projects, "
                "use get_projects_with_teams instead — do NOT call this tool multiple times."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (required for single-project queries)"}
                },
            },
        ),
        types.Tool(
            name="get_projects_with_teams",
            description=(
                "Get ALL projects at once, each with their team members and workload counts. "
                "Call this ONCE when the user asks about team members across multiple projects, "
                "all projects, or 'list projects with their teams'. "
                "NEVER call get_team_workload multiple times — use this tool instead. "
                "Returns: [{project_key, project_name, member_count, members: [{name, email, todo, in_progress, done, blocked}]}]"
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="get_risks",
            description=(
                "Get project risks: blocked ticket count, dependencies, overdue items, "
                "overall risk score (0-100), radar scores by category."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        ),
        types.Tool(
            name="get_stale_tickets",
            description="Get tickets not updated recently — stuck or stale issues needing attention.",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        ),
        types.Tool(
            name="get_velocity",
            description=(
                "Get sprint velocity data: average velocity, best sprint, trend %, "
                "cycle time distribution, cumulative flow diagram data."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        ),
        types.Tool(
            name="get_burndown",
            description=(
                "Get active sprint burndown: remaining story points, ideal line, "
                "actual line, forecast line, sprint status (on_track/at_risk/behind)."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="get_tickets_by_assignee",
            description=(
                "Get all Jira tickets assigned to a specific team member. "
                "Returns ticket list with status, priority, story points, and URLs."
            ),
            inputSchema={
                "type": "object",
                "required": ["assignee"],
                "properties": {
                    "assignee": {
                        "type": "string",
                        "description": "Display name, email address, or Jira accountId of the assignee",
                    },
                    "project_key": {
                        "type": "string",
                        "description": "Jira project key to filter by (optional)",
                    },
                },
            },
        ),
        types.Tool(
            name="enhance_requirement",
            description=(
                "Take raw requirement text and return a structured user story with "
                "feature title, goal, acceptance criteria, effort estimate, story points, "
                "suggested sprint, dependencies, and technical notes."
            ),
            inputSchema={
                "type": "object",
                "required": ["raw_text"],
                "properties": {
                    "raw_text": {
                        "type": "string",
                        "description": "Raw requirement or user story text to enhance",
                    },
                    "feedback": {
                        "type": "string",
                        "description": "Optional feedback to guide the enhancement (e.g. 'focus on mobile UX')",
                    },
                },
            },
        ),
        types.Tool(
            name="enhance_from_pdf",
            description=(
                "Extract text from a PDF file and return a structured user story. "
                "The file must be accessible on the server's filesystem."
            ),
            inputSchema={
                "type": "object",
                "required": ["pdf_path"],
                "properties": {
                    "pdf_path": {
                        "type": "string",
                        "description": "Absolute path to the PDF file on the server",
                    },
                    "feedback": {
                        "type": "string",
                        "description": "Optional feedback to guide the enhancement",
                    },
                },
            },
        ),
        types.Tool(
            name="list_projects",
            description=(
                "List all Jira projects accessible to the PM Agent. "
                "Returns each project's key, name, and type. "
                "Use this to discover project keys before filtering other tools by project."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="get_server_info",
            description=(
                "ALWAYS call this tool when the user asks: how many tools are connected, "
                "what tools does PM Agent have, what are PM Agent's capabilities, or anything "
                "about the server or tool count. Do NOT answer from memory — always call this tool "
                "to get the live server information."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="run_agent_pipeline",
            description=(
                "Trigger the full PM Agent LangGraph pipeline: read PDF → extract requirements "
                "→ classify complexity → create Jira tickets → decompose into sub-tasks → "
                "assign tickets → send emails → broadcast updates → record scores. "
                "Returns created tickets, sub-tasks, and pipeline stats."
            ),
            inputSchema={
                "type": "object",
                "required": ["pdf_path", "project_key", "board_id"],
                "properties": {
                    "pdf_path": {
                        "type": "string",
                        "description": "Absolute path to the requirements PDF on the server",
                    },
                    "project_key": {
                        "type": "string",
                        "description": "Jira project key, e.g. MYAPP",
                    },
                    "board_id": {
                        "type": "string",
                        "description": "Jira board ID, e.g. 42",
                    },
                },
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    arguments = arguments or {}

    # Tracing: create trace in a background thread so Langfuse network calls never
    # block the asyncio event loop (Langfuse may be unreachable when Docker is off).
    trace = None
    trace_id = None
    try:
        from backend.tracing import create_trace, mask_dict
        trace = await asyncio.to_thread(
            create_trace,
            f"mcp/{name}",
            metadata={"tool": name, "arguments": mask_dict(arguments), "source": "claude-desktop-mcp"},
        )
        trace_id = trace.id if trace else None
    except Exception:
        pass

    def _flush(output=None, level: str = "DEFAULT"):
        # Always fire-and-forget in a daemon thread — never block the event loop.
        import threading
        def _do_flush():
            try:
                if trace and output is not None:
                    trace.update(output=str(output)[:4000], level=level)
                from backend.tracing import get_langfuse
                get_langfuse().flush()
            except Exception:
                pass
        threading.Thread(target=_do_flush, daemon=True).start()

    try:
        if name == "get_server_info":
            result = {
                "server_name": "pm-agent",
                "total_tools": 14,
                "tools": [
                    {"name": "get_server_info", "category": "server", "description": "Server info and tool list"},
                    {"name": "list_projects", "category": "projects", "description": "List all Jira projects"},
                    {"name": "get_projects_with_teams", "category": "projects", "description": "All projects with their team members in one call"},
                    {"name": "get_dashboard_summary", "category": "dashboard", "description": "Overall project summary"},
                    {"name": "get_sprint_status", "category": "sprint", "description": "Sprint completion and ticket counts"},
                    {"name": "get_team_workload", "category": "team", "description": "Team workload for a single project"},
                    {"name": "get_risks", "category": "risk", "description": "Project risks and radar scores"},
                    {"name": "get_stale_tickets", "category": "tickets", "description": "Stale or stuck tickets"},
                    {"name": "get_velocity", "category": "velocity", "description": "Sprint velocity and cycle time"},
                    {"name": "get_burndown", "category": "sprint", "description": "Active sprint burndown chart"},
                    {"name": "get_tickets_by_assignee", "category": "tickets", "description": "All tickets for a team member"},
                    {"name": "enhance_requirement", "category": "ai", "description": "Convert raw text to structured user story"},
                    {"name": "enhance_from_pdf", "category": "ai", "description": "Extract and enhance requirements from PDF"},
                    {"name": "run_agent_pipeline", "category": "ai", "description": "Full LangGraph pipeline: PDF → Jira tickets"},
                ],
            }
        elif name == "list_projects":
            result = await asyncio.wait_for(asyncio.to_thread(tool_list_projects), timeout=40)
        elif name == "get_projects_with_teams":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_projects_with_teams), timeout=40)
        elif name == "get_dashboard_summary":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_summary, project_key=arguments.get("project_key")), timeout=20)
        elif name == "get_sprint_status":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_sprints), timeout=20)
        elif name == "get_team_workload":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_team_workload, project_key=arguments.get("project_key")), timeout=20)
        elif name == "get_risks":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_risks, project_key=arguments.get("project_key")), timeout=20)
        elif name == "get_stale_tickets":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_stale_tickets, project_key=arguments.get("project_key")), timeout=20)
        elif name == "get_velocity":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_velocity, project_key=arguments.get("project_key")), timeout=20)
        elif name == "get_burndown":
            result = await asyncio.wait_for(asyncio.to_thread(tool_get_burndown), timeout=20)

        elif name == "get_tickets_by_assignee":
            assignee = arguments.get("assignee", "")
            if not assignee.strip():
                _flush(output="Error: assignee is required", level="ERROR")
                return [types.TextContent(type="text", text="Error: assignee is required")]
            result = await asyncio.to_thread(
                tool_get_tickets_by_assignee,
                assignee=assignee,
                project_key=arguments.get("project_key"),
            )

        elif name == "enhance_requirement":
            raw_text = arguments.get("raw_text", "")
            if not raw_text.strip():
                _flush(output="Error: raw_text is required", level="ERROR")
                return [types.TextContent(type="text", text="Error: raw_text is required and cannot be empty")]
            from backend.routes.enhance import _run_enhancement
            result = await asyncio.to_thread(
                _run_enhancement, raw_text, feedback=arguments.get("feedback", ""), trace_id=trace_id
            )

        elif name == "enhance_from_pdf":
            pdf_path = arguments.get("pdf_path", "")
            if not os.path.isfile(pdf_path):
                _flush(output=f"Error: file not found: {pdf_path}", level="ERROR")
                return [types.TextContent(type="text", text=f"Error: file not found: {pdf_path}")]
            from backend.tools.pdf_tool import extract_text_from_pdf
            from backend.routes.enhance import _run_enhancement
            extracted_text = await asyncio.to_thread(extract_text_from_pdf, pdf_path)
            if not extracted_text.strip():
                _flush(output="Error: no text extracted from PDF", level="ERROR")
                return [types.TextContent(type="text", text="Error: no text could be extracted from the PDF")]
            result = await asyncio.to_thread(
                _run_enhancement, extracted_text, feedback=arguments.get("feedback", ""), trace_id=trace_id
            )

        elif name == "run_agent_pipeline":
            pdf_path = arguments.get("pdf_path", "")
            project_key = arguments.get("project_key", "")
            board_id = arguments.get("board_id", "")
            if not os.path.isfile(pdf_path):
                _flush(output=f"Error: file not found: {pdf_path}", level="ERROR")
                return [types.TextContent(type="text", text=f"Error: file not found: {pdf_path}")]
            from backend.graph import pipeline_graph
            initial_state = {
                "pdf_path": pdf_path,
                "project_key": project_key,
                "board_id": board_id,
                "document_text": "",
                "requirements": [],
                "jira_tickets": [],
                "sub_tasks": [],
                "assignees": {},
                "emails_sent": [],
                "pipeline_stats": {},
                "error": None,
                "trace_id": trace_id,
            }
            final_state = await asyncio.to_thread(pipeline_graph.invoke, initial_state)
            result = {
                "status": "success",
                "project_key": project_key,
                "board_id": board_id,
                "tickets_created": final_state.get("jira_tickets", []),
                "sub_tasks_created": final_state.get("sub_tasks", []),
                "pipeline_stats": final_state.get("pipeline_stats", {}),
                "error": final_state.get("error"),
            }

        else:
            _flush(output=f"Unknown tool: {name}", level="ERROR")
            return [types.TextContent(type="text", text=f"Unknown tool: {name}")]

        serialized = json.dumps(result, default=str)
        _flush(output=serialized[:4000])
        return [types.TextContent(type="text", text=serialized)]
    except asyncio.TimeoutError:
        _flush(output="Timed out fetching Jira data", level="ERROR")
        return [types.TextContent(type="text", text=f"Error running {name}: Jira API took too long. Please try again in a few seconds.")]
    except Exception as e:
        _flush(output=f"Error: {e}", level="ERROR")
        return [types.TextContent(type="text", text=f"Error running {name}: {e}")]


def create_starlette_app(prefix: str = "/mcp"):
    """Return a Starlette sub-app that exposes the MCP server over SSE."""
    from mcp.server.sse import SseServerTransport
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import Response
    from starlette.routing import Mount, Route

    # Full absolute path so Claude Desktop POSTs to /mcp/messages/ not /messages/
    sse = SseServerTransport(f"{prefix}/messages/")

    async def handle_sse(request: Request):
        async with sse.connect_sse(
            request.scope, request.receive, request._send
        ) as streams:
            await server.run(
                streams[0], streams[1], server.create_initialization_options()
            )
        return Response()  # required to avoid NoneType error on client disconnect

    return Starlette(
        routes=[
            Route("/sse", endpoint=handle_sse),
            Mount("/messages/", app=sse.handle_post_message),
        ]
    )


async def main():
    import time as _time
    _t0 = _time.time()
    print(f"[PM Agent MCP] main() starting at +{_time.time()-_t0:.2f}s", file=sys.stderr)
    async with stdio_server() as (read_stream, write_stream):
        print(f"[PM Agent MCP] stdio_server ready at +{_time.time()-_t0:.2f}s", file=sys.stderr)
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    import time as _time
    _start = _time.time()
    print(f"[PM Agent MCP] starting asyncio.run at +0.00s", file=sys.stderr)
    asyncio.run(main())
    print(f"[PM Agent MCP] asyncio.run finished after {_time.time()-_start:.2f}s", file=sys.stderr)
