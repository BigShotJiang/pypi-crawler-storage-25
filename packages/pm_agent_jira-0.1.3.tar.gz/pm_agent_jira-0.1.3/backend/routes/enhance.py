import os
import json
import tempfile
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from openai import AzureOpenAI
from backend.auth import get_current_user
from backend.prompts import get_prompt
from backend.tools.pdf_tool import extract_text_from_pdf
from backend.tracing import create_trace, start_generation, end_generation, usage_from_response, get_langfuse

router = APIRouter()


class EnhanceRequest(BaseModel):
    raw_text: str
    feedback: str = ""


def _get_client():
    return AzureOpenAI(
        api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    )


_MAX_INPUT_CHARS = 8000  # ~2000 tokens; keeps prompt well under model limits


def _run_enhancement(raw_text: str, feedback: str = "", trace_id: str = None) -> dict:
    """Core enhancement logic shared by both endpoints and the MCP server."""
    client = _get_client()
    deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-5-nano")

    # Truncate very long inputs so the model has room to respond
    if len(raw_text) > _MAX_INPUT_CHARS:
        raw_text = raw_text[:_MAX_INPUT_CHARS] + "\n\n[... document truncated for processing ...]"

    feedback_section = (
        f"\nUser feedback for improvement:\n{feedback}" if feedback else ""
    )
    prompt = get_prompt(
        "pm-agent-enhance-requirement",
        raw_text=raw_text,
        feedback_section=feedback_section,
    )
    if trace_id is None:
        trace = create_trace("pm-agent-enhance", metadata={"source": "api", "has_feedback": bool(feedback)})
        trace_id = trace.id if trace else None
    generation = start_generation(
        trace_id=trace_id,
        name="enhance_requirement",
        model=deployment,
        prompt=prompt,
    )

    response = client.chat.completions.create(
        model=deployment,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=4000,
    )

    content = response.choices[0].message.content
    raw = (content or "").strip()

    # Strip code fences
    if raw.startswith("```"):
        raw = raw[3:]
        if raw.startswith("json"):
            raw = raw[4:]
        if raw.rstrip().endswith("```"):
            raw = raw.rstrip()[:-3]
    raw = raw.strip()

    # If fence-stripping left nothing, try to extract JSON object directly
    if not raw or not raw.startswith("{"):
        start = raw.find("{")
        end = raw.rfind("}")
        if start != -1 and end != -1 and end > start:
            raw = raw[start:end + 1]

    if not raw:
        raise ValueError(
            "The AI model returned an empty response. "
            "The document may be too complex — try submitting a shorter excerpt."
        )

    try:
        result = json.loads(raw)
    except json.JSONDecodeError:
        # Last resort: extract between first { and last }
        start = raw.find("{")
        end = raw.rfind("}")
        if start != -1 and end != -1 and end > start:
            result = json.loads(raw[start:end + 1])
        else:
            raise ValueError(
                "Could not parse the AI response as JSON. "
                "The document may be too complex — try submitting a shorter excerpt."
            )
    end_generation(generation, output=raw, usage=usage_from_response(response))
    try:
        get_langfuse().flush()
    except Exception:
        pass

    result["model_used"] = deployment

    # Normalize technical_notes: AI sometimes returns array, frontend expects string
    tn = result.get("technical_notes")
    if isinstance(tn, list):
        result["technical_notes"] = ("\n• ".join(tn)).strip()
        if result["technical_notes"]:
            result["technical_notes"] = "• " + result["technical_notes"]

    # Ensure required fields exist with safe defaults
    result.setdefault("feature_title", "Untitled Feature")
    result.setdefault("goal", "")
    result.setdefault("acceptance_criteria", [])
    result.setdefault("dependencies", [])
    result.setdefault("effort_estimate", {"story_points": 0, "time_estimate": "TBD"})
    result.setdefault("suggested_sprint", "Sprint 1")
    result.setdefault("technical_notes", "")

    return result


# ── POST /enhance  (original endpoint kept for backward compat) ───────────────

@router.post("/enhance")
async def enhance_requirement(body: EnhanceRequest, user=Depends(get_current_user)):
    try:
        return _run_enhancement(body.raw_text, body.feedback)
    except Exception as e:
        raise HTTPException(500, f"Enhancement failed: {str(e)}")


# ── POST /enhance/text  (frontend calls this for pasted text) ─────────────────

@router.post("/enhance/text")
async def enhance_text(body: EnhanceRequest, user=Depends(get_current_user)):
    try:
        return _run_enhancement(body.raw_text, body.feedback)
    except Exception as e:
        raise HTTPException(500, f"Enhancement failed: {str(e)}")


# ── POST /enhance/upload  (frontend calls this for PDF files) ─────────────────

@router.post("/enhance/upload")
async def enhance_upload(
    file: UploadFile = File(...),
    user=Depends(get_current_user),
):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are accepted")

    content = await file.read()
    if len(content) > 20 * 1024 * 1024:
        raise HTTPException(400, "File too large. Maximum size is 20 MB")

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        extracted_text = extract_text_from_pdf(tmp_path)
    except Exception as e:
        raise HTTPException(400, f"Could not read PDF: {str(e)}")
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)

    if not extracted_text.strip():
        raise HTTPException(400, "No text could be extracted from the PDF. Please ensure the file is not scanned/image-only.")

    try:
        return _run_enhancement(extracted_text)
    except Exception as e:
        raise HTTPException(500, f"Enhancement failed: {str(e)}")
