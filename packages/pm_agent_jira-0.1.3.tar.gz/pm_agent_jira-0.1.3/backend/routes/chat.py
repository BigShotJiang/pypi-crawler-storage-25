import json
import os
from typing import List, Optional
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from openai import AzureOpenAI

from backend.chat_tools import (
    tool_get_summary,
    tool_get_sprints,
    tool_get_team_workload,
    tool_get_risks,
    tool_get_stale_tickets,
    tool_get_velocity,
    tool_get_burndown,
    tool_get_tickets_by_assignee,
)
from backend.tracing import create_trace, start_generation, end_generation, usage_from_response, get_langfuse, mask_sensitive

router = APIRouter()

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_dashboard_summary",
            "description": "Get overall project summary: total tickets, completed, in progress, blocked, weekly activity, sprint completion rates, priority distribution.",
            "parameters": {
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional, leave empty for all projects)"}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_sprint_status",
            "description": "Get all sprints with completion %, story points done, days remaining, ticket counts (todo/in_progress/done/blocked).",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_team_workload",
            "description": "Get each team member's workload: number of tickets assigned, story points, in-progress/done/blocked counts.",
            "parameters": {
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_risks",
            "description": "Get project risks: blocked tickets, dependencies, overdue items, overall risk score and radar scores.",
            "parameters": {
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_stale_tickets",
            "description": "Get tickets that have not been updated recently — stuck or stale tickets needing attention.",
            "parameters": {
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_velocity",
            "description": "Get sprint velocity: average velocity, best sprint, trend %, cycle time distribution, cumulative flow data.",
            "parameters": {
                "type": "object",
                "properties": {
                    "project_key": {"type": "string", "description": "Jira project key (optional)"}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_burndown",
            "description": "Get active sprint burndown: remaining story points, ideal vs actual progress, forecast line, sprint status (on_track/at_risk/behind).",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_tickets_by_assignee",
            "description": (
                "Get all Jira tickets assigned to a specific person. "
                "Returns each ticket's key, title, status, priority, story points, and URL. "
                "Use this when someone asks about a person's tasks, workload, or ticket status."
            ),
            "parameters": {
                "type": "object",
                "required": ["assignee"],
                "properties": {
                    "assignee": {
                        "type": "string",
                        "description": "Full name, email address, or Jira accountId of the person",
                    },
                    "project_key": {
                        "type": "string",
                        "description": "Jira project key to filter by (optional)",
                    },
                },
            },
        },
    },
]

TOOL_MAP = {
    "get_dashboard_summary": lambda a: tool_get_summary(project_key=a.get("project_key")),
    "get_sprint_status": lambda a: tool_get_sprints(),
    "get_team_workload": lambda a: tool_get_team_workload(project_key=a.get("project_key")),
    "get_risks": lambda a: tool_get_risks(project_key=a.get("project_key")),
    "get_stale_tickets": lambda a: tool_get_stale_tickets(project_key=a.get("project_key")),
    "get_velocity": lambda a: tool_get_velocity(project_key=a.get("project_key")),
    "get_burndown": lambda a: tool_get_burndown(),
    "get_tickets_by_assignee": lambda a: tool_get_tickets_by_assignee(
        assignee=a.get("assignee", ""),
        project_key=a.get("project_key"),
    ),
}

SYSTEM_PROMPT = (
    "You are a PM Assistant embedded in a project management dashboard. "
    "You have live access to Jira data. "
    "IMPORTANT RULES:\n"
    "- Always respond in clear, readable plain English.\n"
    "- NEVER mention tool names, function calls, API calls, or data sources — just answer directly.\n"
    "- NEVER say things like 'I fetched', 'I called', 'based on the data returned', 'the tool returned', etc.\n"
    "- NEVER output raw JSON, data structures, or code blocks — always summarize the data in human language.\n"
    "- When listing tickets, use a bullet list with the key, title, and status.\n"
    "- Be concise and direct. If a list is long, group by status or show only the most important items.\n"
    "- Start your answer immediately with the relevant information, not with 'Sure!' or 'Of course!'."
)


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    history: List[ChatMessage] = []


def _az_client() -> AzureOpenAI:
    return AzureOpenAI(
        api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    )


@router.post("/chat")
async def chat_endpoint(request: ChatRequest):
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for m in request.history[-10:]:
        messages.append({"role": m.role, "content": m.content})
    messages.append({"role": "user", "content": request.message})

    async def generate():
        client = _az_client()
        deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-5-nano")

        trace = create_trace(
            "chatbot",
            metadata={"user_message": mask_sensitive(request.message), "history_length": len(request.history)},
        )
        trace_id = trace.id if trace else None

        # Non-streaming first call to handle tool use
        gen1 = start_generation(trace_id, "tool_detection", deployment, request.message)
        response = client.chat.completions.create(
            model=deployment,
            messages=messages,
            tools=TOOLS,
            tool_choice="auto",
            stream=False,
        )
        end_generation(gen1, response.choices[0].message.content or "", usage_from_response(response))

        msg = response.choices[0].message
        tool_messages = list(messages)

        if msg.tool_calls:
            tool_messages.append({
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                    }
                    for tc in msg.tool_calls
                ],
            })

            for tc in msg.tool_calls:
                fn_name = tc.function.name
                fn_args = json.loads(tc.function.arguments or "{}")
                try:
                    result = TOOL_MAP[fn_name](fn_args)
                    result_str = json.dumps(result, default=str)[:8000]
                except Exception as e:
                    result_str = f"Error fetching {fn_name}: {e}"

                tool_messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result_str,
                })

            stream = client.chat.completions.create(
                model=deployment,
                messages=tool_messages,
                stream=True,
                stream_options={"include_usage": True},
            )
        else:
            # No tool calls — stream a direct answer
            stream = client.chat.completions.create(
                model=deployment,
                messages=messages,
                stream=True,
                stream_options={"include_usage": True},
            )

        gen2 = start_generation(trace_id, "final_response", deployment, request.message)
        collected_content = []
        stream_usage = {}
        for chunk in stream:
            if not chunk.choices:
                # Last chunk with usage info when stream_options include_usage is set
                if hasattr(chunk, "usage") and chunk.usage:
                    stream_usage = usage_from_response(chunk)
                continue
            delta = chunk.choices[0].delta
            if delta and delta.content:
                collected_content.append(delta.content)
                yield f"data: {json.dumps({'text': delta.content})}\n\n"

        end_generation(gen2, "".join(collected_content), stream_usage)
        try:
            get_langfuse().flush()
        except Exception:
            pass
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
