import os
import tempfile
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends
from backend.graph import pipeline_graph
from backend.tracing import get_langfuse
from backend.auth import get_current_user

router = APIRouter()

MAX_PDF_SIZE = 20 * 1024 * 1024  # 20MB


@router.post("/upload")
async def upload_pdf(
    file: UploadFile = File(...),
    project_key: str = Form(..., description="Jira project key, e.g. MYAPP"),
    board_id: str = Form(..., description="Jira board ID, e.g. 42"),
    user=Depends(get_current_user),
):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are accepted")

    content = await file.read()
    if len(content) > MAX_PDF_SIZE:
        raise HTTPException(400, "File too large. Maximum size is 20MB")

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        lf = get_langfuse()
        trace_id = None
        try:
            trace = lf.trace(
                name="pm-agent-pipeline",
                metadata={
                    "filename": file.filename,
                    "project_key": project_key,
                    "board_id": board_id,
                    "user": user.get("email"),
                },
            )
            trace_id = trace.id
        except Exception:
            pass

        initial_state = {
            "pdf_path": tmp_path,
            "project_key": project_key,
            "board_id": board_id,
            "document_text": "",
            "requirements": [],
            "jira_tickets": [],
            "sub_tasks": [],
            "assignees": {},
            "emails_sent": [],
            "pipeline_stats": {},
            "error": None,
            "trace_id": trace_id,
        }

        final_state = pipeline_graph.invoke(initial_state)

        return {
            "status": "success",
            "project_key": project_key,
            "board_id": board_id,
            "tickets_created": final_state.get("jira_tickets", []),
            "sub_tasks_created": final_state.get("sub_tasks", []),
            "pipeline_stats": final_state.get("pipeline_stats", {}),
        }
    except Exception as e:
        raise HTTPException(500, f"Pipeline failed: {str(e)}")
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
