import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from backend.auth import get_current_user
from backend.tools.jira_tool import jira_client


def _parallel_sprint_issues(sprint_ids) -> Dict[Any, List[dict]]:
    """Fetch sprint issues for multiple sprints in parallel (max 6 workers)."""
    results: Dict[Any, List[dict]] = {}
    if not sprint_ids:
        return results
    workers = min(len(sprint_ids), 6)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        future_map = {ex.submit(jira_client.get_sprint_issues, sid): sid for sid in sprint_ids}
        for future in as_completed(future_map):
            sid = future_map[future]
            try:
                results[sid] = future.result()
            except Exception:
                results[sid] = []
    return results

router = APIRouter()


def _default_project_key(project_key: Optional[str]) -> str:
    # If caller passes a key use it; fall back to env; empty string = all projects
    if project_key is not None:
        return project_key
    return os.environ.get("JIRA_PROJECT_KEY", "")


def _default_board_id(board_id: Optional[str]) -> str:
    if board_id is not None:
        return board_id
    return os.environ.get("JIRA_BOARD_ID", "")


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _safe_field(issue: dict, *keys: str, default=None):
    fields = issue.get("fields", {})
    val = fields
    for key in keys:
        if not isinstance(val, dict):
            return default
        val = val.get(key, default)
        if val is None:
            return default
    return val


def _status_name(issue: dict) -> str:
    return (_safe_field(issue, "status", "name") or "Unknown").strip()


def _story_points(issue: dict) -> float:
    fields = issue.get("fields", {})
    for field in ("customfield_10016", "customfield_10028", "customfield_10004", "story_points"):
        sp = fields.get(field)
        try:
            if sp is not None:
                return float(sp)
        except (TypeError, ValueError):
            continue
    return 0.0


def _priority_name(issue: dict) -> str:
    return (_safe_field(issue, "priority", "name") or "Medium").strip()


def _issue_type(issue: dict) -> str:
    return (_safe_field(issue, "issuetype", "name") or "Task").strip()


def _assignee(issue: dict) -> Optional[dict]:
    return _safe_field(issue, "assignee")


def _parse_date(date_str: Optional[str]) -> Optional[datetime]:
    if not date_str:
        return None
    try:
        return datetime.fromisoformat(date_str.replace("Z", "+00:00"))
    except ValueError:
        pass
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def _is_done(issue: dict) -> bool:
    return _status_name(issue).lower() in ("done", "closed", "resolved")


def _is_in_progress(issue: dict) -> bool:
    return _status_name(issue).lower() in ("in progress", "in review", "in development")


def _is_blocked(issue: dict) -> bool:
    labels = _safe_field(issue, "labels") or []
    if isinstance(labels, list):
        return any("block" in str(lbl).lower() for lbl in labels)
    return False


def _tz(dt: Optional[datetime]) -> Optional[datetime]:
    if dt is None:
        return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


# ---------------------------------------------------------------------------
# GET /dashboard/summary
# ---------------------------------------------------------------------------

@router.get("/summary")
def get_summary(
    project_key: Optional[str] = Query(None),
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
    _max_results: int = 500,
):
    project_key = _default_project_key(project_key)
    board_id = _default_board_id(board_id)

    try:
        issues = jira_client.get_project_issues(project_key=project_key, max_results=_max_results)
    except Exception:
        issues = []

    total = len(issues)
    completed = sum(1 for i in issues if _is_done(i))
    in_progress = sum(1 for i in issues if _is_in_progress(i))
    unassigned = sum(1 for i in issues if _assignee(i) is None)
    blocked = sum(1 for i in issues if _is_blocked(i))

    status_counts: Dict[str, int] = {}
    for issue in issues:
        s = _status_name(issue)
        status_counts[s] = status_counts.get(s, 0) + 1

    now = datetime.now(timezone.utc)
    weekly_activity: List[Dict[str, Any]] = []
    for week_offset in range(7, -1, -1):
        week_start = now - timedelta(weeks=week_offset + 1)
        week_end = now - timedelta(weeks=week_offset)
        week_label = week_start.strftime("%b %d")
        opened = 0
        closed = 0
        for issue in issues:
            created_dt = _tz(_parse_date(issue.get("fields", {}).get("created", "")))
            updated_dt = _tz(_parse_date(issue.get("fields", {}).get("updated", "")))
            if created_dt and week_start <= created_dt < week_end:
                opened += 1
            if updated_dt and _is_done(issue) and week_start <= updated_dt < week_end:
                closed += 1
        weekly_activity.append({"week": week_label, "opened": opened, "closed": closed})

    sprint_completion: List[Dict[str, Any]] = []
    if _max_results >= 500:
        # Only compute sprint completion for full web-dashboard requests — skip for MCP (too slow)
        try:
            sprints_for_completion = jira_client.get_sprints(board_id=board_id)
        except Exception:
            sprints_for_completion = []
        recent_closed_sprints = [s for s in sprints_for_completion if s.get("state") == "closed"][-4:]
        summary_sprint_issues = _parallel_sprint_issues([s.get("id") for s in recent_closed_sprints])
        for sprint in recent_closed_sprints:
            sid = sprint.get("id")
            s_issues = summary_sprint_issues.get(sid, [])
            total_sp = sum(_story_points(i) for i in s_issues)
            done_sp = sum(_story_points(i) for i in s_issues if _is_done(i))
            pct = round((done_sp / total_sp * 100) if total_sp > 0 else 0, 1)
            sprint_completion.append({"name": sprint.get("name", f"Sprint {sid}"), "pct": pct})

    priority_dist: Dict[str, int] = {}
    for issue in issues:
        p = _priority_name(issue)
        priority_dist[p] = priority_dist.get(p, 0) + 1

    return {
        "total": total,
        "completed": completed,
        "in_progress": in_progress,
        "unassigned": unassigned,
        "blocked": blocked,
        "status_distribution": status_counts,
        "weekly_activity": weekly_activity,
        "sprint_completion": sprint_completion,
        "priority_distribution": priority_dist,
    }


# ---------------------------------------------------------------------------
# Burndown helper
# ---------------------------------------------------------------------------

def _build_burndown(sprint_info: Optional[dict], issues: List[dict]) -> dict:
    now = datetime.now(timezone.utc)

    start_dt = _tz(_parse_date(sprint_info.get("startDate"))) if sprint_info else None
    end_dt = _tz(_parse_date(sprint_info.get("endDate"))) if sprint_info else None

    if start_dt is None:
        start_dt = now - timedelta(days=14)
    if end_dt is None:
        end_dt = now

    total_days = max((end_dt - start_dt).days, 1)
    current_day = min(max((now - start_dt).days, 0), total_days)

    total_points = sum(_story_points(i) for i in issues)

    daily_completed_sp = [0.0] * (total_days + 1)
    for issue in issues:
        if _is_done(issue):
            updated_dt = _tz(_parse_date(issue.get("fields", {}).get("updated", "")))
            if updated_dt:
                day_index = max(0, min((updated_dt - start_dt).days, total_days))
                daily_completed_sp[day_index] += _story_points(issue)

    cumulative = [0.0] * (total_days + 1)
    running = 0.0
    for d in range(total_days + 1):
        running += daily_completed_sp[d]
        cumulative[d] = running

    ideal_line = [
        round(total_points - (total_points * d / total_days), 1)
        for d in range(total_days + 1)
    ]
    actual_line = [
        round(max(total_points - cumulative[d], 0), 1)
        for d in range(current_day + 1)
    ]

    remaining = total_points - cumulative[current_day] if current_day < len(cumulative) else 0
    forecast_line = list(actual_line)
    if current_day > 0 and remaining > 0:
        daily_velocity = cumulative[current_day] / current_day
        for d in range(current_day + 1, total_days + 1):
            projected = max(remaining - daily_velocity * (d - current_day), 0)
            forecast_line.append(round(projected, 1))

    daily_completed_list = [round(daily_completed_sp[d], 1) for d in range(current_day + 1)]

    # Compute on_track / at_risk / behind
    expected_remaining = ideal_line[current_day] if current_day < len(ideal_line) else 0
    if expected_remaining <= 0:
        sprint_status = "on_track"
    elif remaining <= expected_remaining * 1.1:
        sprint_status = "on_track"
    elif remaining <= expected_remaining * 1.4:
        sprint_status = "at_risk"
    else:
        sprint_status = "behind"

    return {
        "total_points": round(total_points, 1),
        "remaining_points": round(max(remaining, 0), 1),
        "current_day": current_day,
        "total_days": total_days,
        "status": sprint_status,
        "ideal_line": ideal_line,
        "actual_line": actual_line,
        "forecast_line": forecast_line,
        "daily_completed": daily_completed_list,
    }


# ---------------------------------------------------------------------------
# GET /dashboard/burndown  (active sprint)
# ---------------------------------------------------------------------------

@router.get("/burndown")
def get_burndown_active(
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    board_id = _default_board_id(board_id)
    try:
        active = jira_client.get_active_sprint(board_id)
    except Exception:
        active = None

    if active:
        try:
            issues = jira_client.get_sprint_issues(active["id"])
        except Exception:
            issues = []
        return _build_burndown(active, issues)

    return _build_burndown(None, [])


# ---------------------------------------------------------------------------
# GET /dashboard/burndown/{sprint_id}
# ---------------------------------------------------------------------------

@router.get("/burndown/{sprint_id}")
def get_burndown(
    sprint_id: int,
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    board_id = _default_board_id(board_id)
    try:
        sprints = jira_client.get_sprints(board_id=board_id)
    except Exception:
        sprints = []

    sprint_info = next((s for s in sprints if s.get("id") == sprint_id), None)

    try:
        issues = jira_client.get_sprint_issues(sprint_id)
    except Exception:
        issues = []

    return _build_burndown(sprint_info, issues)


# ---------------------------------------------------------------------------
# GET /dashboard/velocity
# ---------------------------------------------------------------------------

@router.get("/velocity")
def get_velocity(
    project_key: Optional[str] = Query(None),
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    project_key = _default_project_key(project_key)
    board_id = _default_board_id(board_id)

    try:
        sprints = jira_client.get_sprints(board_id=board_id)
    except Exception:
        sprints = []

    closed_sprints = [s for s in sprints if s.get("state") == "closed"]
    active_sprints = [s for s in sprints if s.get("state") == "active"]
    recent_closed = closed_sprints[-5:] if len(closed_sprints) > 5 else closed_sprints
    recent_sprints = recent_closed + active_sprints

    sprint_velocities: List[Dict[str, Any]] = []
    velocity_values: List[float] = []

    velocity_issues = _parallel_sprint_issues([s.get("id") for s in recent_sprints])
    for sprint in recent_sprints:
        sid = sprint.get("id")
        s_issues = velocity_issues.get(sid, [])
        committed = sum(_story_points(i) for i in s_issues)
        completed_sp = sum(_story_points(i) for i in s_issues if _is_done(i))
        velocity_values.append(completed_sp)
        sprint_velocities.append({
            "name": sprint.get("name", f"Sprint {sid}"),
            "committed": round(committed, 1),
            "completed": round(completed_sp, 1),
        })

    avg_velocity = round(sum(velocity_values) / len(velocity_values), 1) if velocity_values else 0

    if sprint_velocities:
        best = max(sprint_velocities, key=lambda s: s["completed"])
        best_sprint = {"name": best["name"], "points": best["completed"]}
    else:
        best_sprint = {"name": "N/A", "points": 0}

    trend_pct = 0.0
    if len(velocity_values) >= 2:
        prev = velocity_values[-2] or 1
        trend_pct = round((velocity_values[-1] - prev) / prev * 100, 1)

    pct_list = []
    for sv in sprint_velocities:
        if sv["committed"] > 0:
            pct_list.append(sv["completed"] / sv["committed"] * 100)
    predictability_pct = round(sum(pct_list) / len(pct_list), 1) if pct_list else 0

    try:
        all_issues = jira_client.get_project_issues(project_key=project_key, max_results=200)
    except Exception:
        all_issues = []

    # Cycle time: bucket into day ranges
    buckets: Dict[str, int] = {"0-1d": 0, "1-3d": 0, "3-7d": 0, "7-14d": 0, "14d+": 0}
    for issue in all_issues:
        if _is_done(issue):
            created_dt = _tz(_parse_date(issue.get("fields", {}).get("created", "")))
            updated_dt = _tz(_parse_date(issue.get("fields", {}).get("updated", "")))
            if created_dt and updated_dt:
                hours = (updated_dt - created_dt).total_seconds() / 3600
                if 0 < hours < 10000:
                    days = hours / 24
                    if days <= 1:
                        buckets["0-1d"] += 1
                    elif days <= 3:
                        buckets["1-3d"] += 1
                    elif days <= 7:
                        buckets["3-7d"] += 1
                    elif days <= 14:
                        buckets["7-14d"] += 1
                    else:
                        buckets["14d+"] += 1

    cycle_time = [{"range": k, "count": v} for k, v in buckets.items()]

    now = datetime.now(timezone.utc)
    cumulative_flow: List[Dict[str, Any]] = []
    for week_offset in range(7, -1, -1):
        week_end = now - timedelta(weeks=week_offset)
        week_label = week_end.strftime("%b %d")
        todo = in_prog = done = 0
        for issue in all_issues:
            created_dt = _tz(_parse_date(issue.get("fields", {}).get("created", "")))
            if created_dt and created_dt <= week_end:
                s = _status_name(issue).lower()
                if s in ("done", "closed", "resolved"):
                    done += 1
                elif s in ("in progress", "in review", "in development"):
                    in_prog += 1
                else:
                    todo += 1
        cumulative_flow.append({"week": week_label, "todo": todo, "in_progress": in_prog, "done": done})

    return {
        "sprints": sprint_velocities,
        "avg_velocity": avg_velocity,
        "best_sprint": best_sprint,
        "trend_pct": trend_pct,
        "predictability_pct": predictability_pct,
        "cycle_time": cycle_time,
        "cumulative_flow": cumulative_flow,
    }


# ---------------------------------------------------------------------------
# GET /dashboard/sprints
# ---------------------------------------------------------------------------

@router.get("/sprints")
def get_sprints(
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    board_id = _default_board_id(board_id)
    try:
        sprints = jira_client.get_sprints(board_id=board_id)
    except Exception:
        sprints = []

    now = datetime.now(timezone.utc)

    # Only fetch issue details for active sprint + last 5 closed sprints.
    # Fetch them all IN PARALLEL to avoid N+1 sequential latency.
    active_ids = {s.get("id") for s in sprints if s.get("state") == "active"}
    recent_closed = [s for s in sprints if s.get("state") == "closed"][-5:]
    recent_closed_ids = {s.get("id") for s in recent_closed}
    fetch_ids = active_ids | recent_closed_ids

    issues_by_sprint = _parallel_sprint_issues(fetch_ids)

    result: List[Dict[str, Any]] = []

    for sprint in sprints:
        sid = sprint.get("id")
        state = sprint.get("state", "future")
        end_dt = _tz(_parse_date(sprint.get("endDate")))

        days_remaining = 0
        if end_dt:
            days_remaining = max((end_dt - now).days, 0)

        s_issues = issues_by_sprint.get(sid, [])

        total_sp = sum(_story_points(i) for i in s_issues)
        done_sp = sum(_story_points(i) for i in s_issues if _is_done(i))
        completion_pct = round((done_sp / total_sp * 100) if total_sp > 0 else 0, 1)
        if state == "closed" and sid not in fetch_ids:
            completion_pct = 100.0

        at_risk = 0
        if days_remaining < 2 and state == "active":
            at_risk = sum(1 for i in s_issues if _is_in_progress(i))

        ticket_counts = {"todo": 0, "in_progress": 0, "done": 0, "blocked": 0}
        for issue in s_issues:
            if _is_done(issue):
                ticket_counts["done"] += 1
            elif _is_blocked(issue):
                ticket_counts["blocked"] += 1
            elif _is_in_progress(issue):
                ticket_counts["in_progress"] += 1
            else:
                ticket_counts["todo"] += 1

        result.append({
            "id": str(sid),
            "name": sprint.get("name", f"Sprint {sid}"),
            "status": state,
            "start_date": sprint.get("startDate", ""),
            "end_date": sprint.get("endDate", ""),
            "days_remaining": days_remaining,
            "completion_pct": completion_pct,
            "points_done": round(done_sp, 1),
            "at_risk": at_risk,
            "ticket_counts": ticket_counts,
            "total_tickets": len(s_issues),
        })

    return result


# ---------------------------------------------------------------------------
# GET /dashboard/sprint/{sprint_id}/tickets
# ---------------------------------------------------------------------------

@router.get("/sprint/{sprint_id}/tickets")
def get_sprint_tickets(
    sprint_id: int,
    user=Depends(get_current_user),
):
    base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
    try:
        issues = jira_client.get_sprint_issues(sprint_id)
    except Exception:
        issues = []
    return [_to_jira_ticket(i, base_url) for i in issues]


# ---------------------------------------------------------------------------
# GET /dashboard/backlog  — returns JiraTicket[] matching frontend type
# ---------------------------------------------------------------------------

def _to_jira_ticket(issue: dict, base_url: str) -> dict:
    assignee_raw = _assignee(issue)
    assignee = None
    if assignee_raw:
        assignee = {
            "displayName": assignee_raw.get("displayName", ""),
            "emailAddress": assignee_raw.get("emailAddress", ""),
        }
    key = issue.get("key", "")
    return {
        "key": key,
        "id": issue.get("id", ""),
        "title": _safe_field(issue, "summary") or key,
        "description": "",
        "priority": _priority_name(issue),
        "type": _issue_type(issue),
        "story_points": _story_points(issue) or None,
        "assignee": assignee,
        "status": _status_name(issue),
        "url": f"{base_url}/browse/{key}" if key else "",
        "labels": _safe_field(issue, "labels") or [],
        "acceptance_criteria": [],
    }


@router.get("/backlog")
def get_backlog(
    project_key: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    project_key = _default_project_key(project_key)
    base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
    try:
        issues = jira_client.get_backlog_issues(project_key=project_key, max_results=500)
    except Exception:
        issues = []
    return [_to_jira_ticket(i, base_url) for i in issues]


@router.get("/project_tickets")
def get_project_tickets(
    project_key: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    project_key = _default_project_key(project_key)
    base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
    try:
        issues = jira_client.get_project_issues(project_key=project_key, max_results=500)
    except Exception:
        issues = []
    return [_to_jira_ticket(i, base_url) for i in issues]


# ---------------------------------------------------------------------------
# Team member builder (shared by /team and /members)
# ---------------------------------------------------------------------------

def _build_members(issues: List[dict], sprints: List[dict], skip_heatmap: bool = False) -> List[dict]:
    now = datetime.now(timezone.utc)
    members: Dict[str, Dict[str, Any]] = {}

    for issue in issues:
        assignee = _assignee(issue)
        if not assignee:
            continue
        aid = assignee.get("accountId", "")
        if not aid:
            continue
        if aid not in members:
            members[aid] = {
                "id": aid,
                "name": assignee.get("displayName", "Unknown"),
                "email": assignee.get("emailAddress", ""),
                "role": "",
                "workload": {"todo": 0, "in_progress": 0, "done": 0, "blocked": 0},
                "story_points": 0.0,
                "heatmap": [],
                "_sprint_counts": {},
            }
        m = members[aid]
        m["story_points"] = round(m["story_points"] + _story_points(issue), 1)
        if _is_done(issue):
            m["workload"]["done"] += 1
        elif _is_blocked(issue):
            m["workload"]["blocked"] += 1
        elif _is_in_progress(issue):
            m["workload"]["in_progress"] += 1
        else:
            m["workload"]["todo"] += 1

    if not skip_heatmap:
        # Build heatmap: tickets per member per sprint (last 6 closed + active)
        relevant_sprints = [s for s in sprints if s.get("state") in ("closed", "active")][-6:]
        heatmap_ids = [s.get("id") for s in relevant_sprints]
        heatmap_issues = _parallel_sprint_issues(heatmap_ids)
        for sprint in relevant_sprints:
            sid = sprint.get("id")
            sprint_name = sprint.get("name", f"Sprint {sid}")
            for issue in heatmap_issues.get(sid, []):
                assignee = _assignee(issue)
                if not assignee:
                    continue
                aid = assignee.get("accountId", "")
                if aid in members:
                    sc = members[aid]["_sprint_counts"]
                    sc[sprint_name] = sc.get(sprint_name, 0) + 1

    for m in members.values():
        m["heatmap"] = [{"sprint": k, "count": v} for k, v in m["_sprint_counts"].items()]
        del m["_sprint_counts"]

    return list(members.values())


# ---------------------------------------------------------------------------
# GET /dashboard/team
# ---------------------------------------------------------------------------

@router.get("/team")
def get_projects_with_teams(max_results: int = 100) -> List[dict]:
    """Return all projects, each with its unique assignees. One call covers every project."""
    try:
        all_issues = jira_client.get_project_issues(project_key="", max_results=max_results)
    except Exception:
        all_issues = []

    project_map: Dict[str, dict] = {}
    for issue in all_issues:
        fields = issue.get("fields", {})
        proj = fields.get("project") or {}
        pkey = proj.get("key", "")
        pname = proj.get("name", pkey)
        if not pkey:
            continue
        if pkey not in project_map:
            project_map[pkey] = {"project_key": pkey, "project_name": pname, "members": {}}

        assignee = _assignee(issue)
        if not assignee:
            continue
        aid = assignee.get("accountId", "")
        if not aid:
            continue
        members = project_map[pkey]["members"]
        if aid not in members:
            members[aid] = {
                "name": assignee.get("displayName", "Unknown"),
                "email": assignee.get("emailAddress", ""),
                "todo": 0, "in_progress": 0, "done": 0, "blocked": 0,
            }
        m = members[aid]
        if _is_done(issue):
            m["done"] += 1
        elif _is_blocked(issue):
            m["blocked"] += 1
        elif _is_in_progress(issue):
            m["in_progress"] += 1
        else:
            m["todo"] += 1

    result = []
    for pkey, pdata in sorted(project_map.items()):
        members_list = sorted(pdata["members"].values(), key=lambda x: x["name"])
        result.append({
            "project_key": pdata["project_key"],
            "project_name": pdata["project_name"],
            "member_count": len(members_list),
            "members": members_list,
        })
    return result


def get_team(
    project_key: Optional[str] = Query(None),
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
    _max_results: int = 500,
):
    project_key = _default_project_key(project_key)
    board_id = _default_board_id(board_id)

    try:
        issues = jira_client.get_project_issues(project_key=project_key, max_results=_max_results)
    except Exception:
        issues = []

    try:
        sprints = jira_client.get_sprints(board_id=board_id)
    except Exception:
        sprints = []

    return _build_members(issues, sprints, skip_heatmap=(_max_results < 500))


# ---------------------------------------------------------------------------
# GET /dashboard/members
# ---------------------------------------------------------------------------

@router.get("/members")
def get_members(
    project_key: Optional[str] = Query(None),
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    project_key = _default_project_key(project_key)
    board_id = _default_board_id(board_id)

    try:
        issues = jira_client.get_project_issues(project_key=project_key, max_results=500)
    except Exception:
        issues = []

    try:
        sprints = jira_client.get_sprints(board_id=board_id)
    except Exception:
        sprints = []

    return _build_members(issues, sprints)


# ---------------------------------------------------------------------------
# GET /dashboard/risks
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# GET /dashboard/stale-tickets
# ---------------------------------------------------------------------------

def _extract_adf_text(node) -> str:
    """Recursively pull plain text from an Atlassian Document Format node."""
    if not isinstance(node, dict):
        return str(node) if node else ""
    if node.get("type") == "text":
        return node.get("text", "")
    parts = [_extract_adf_text(c) for c in node.get("content", [])]
    return " ".join(p for p in parts if p).strip()


@router.get("/stale-tickets")
def get_stale_tickets(
    project_key: Optional[str] = Query(None),
    user=Depends(get_current_user),
    _max_results: int = 500,
):
    project_key = _default_project_key(project_key)
    base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
    now = datetime.now(timezone.utc)

    try:
        issues = jira_client.get_stale_tickets(project_key=project_key, days=2, max_results=_max_results)
    except Exception:
        issues = []

    result = []
    for issue in issues:
        key = issue.get("key", "")
        fields = issue.get("fields", {})

        assignee_raw = _assignee(issue)
        assignee = None
        if assignee_raw:
            assignee = {
                "displayName": assignee_raw.get("displayName", ""),
                "emailAddress": assignee_raw.get("emailAddress", ""),
            }

        updated_dt = _tz(_parse_date(fields.get("updated", "")))
        days_stale = (now - updated_dt).days if updated_dt else 0

        latest_comment = None
        comment_field = fields.get("comment", {})
        comments = comment_field.get("comments", []) if isinstance(comment_field, dict) else []
        if comments:
            last = comments[-1]
            body = last.get("body", "")
            body_text = _extract_adf_text(body) if isinstance(body, dict) else str(body)
            comment_author = last.get("author", {})
            latest_comment = {
                "author": comment_author.get("displayName", "Unknown"),
                "body": body_text[:400],
                "created": last.get("created", ""),
            }

        result.append({
            "key": key,
            "title": _safe_field(issue, "summary") or key,
            "status": _status_name(issue),
            "priority": _priority_name(issue),
            "type": _issue_type(issue),
            "created": fields.get("created", ""),
            "updated": fields.get("updated", ""),
            "days_stale": days_stale,
            "assignee": assignee,
            "url": f"{base_url}/browse/{key}" if key else "",
            "latest_comment": latest_comment,
        })

    return result


@router.get("/assignee-tickets")
def get_assignee_tickets(
    assignee: str = Query(..., description="Display name, email, or accountId of the assignee"),
    project_key: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    project_key = _default_project_key(project_key)
    base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
    try:
        issues = jira_client.get_issues_by_assignee(
            assignee=assignee, project_key=project_key, max_results=100
        )
    except Exception:
        issues = []

    # Deduplicate by Jira key — pagination bug can return the same issue multiple times
    seen: set = set()
    unique_issues = []
    for i in issues:
        key = i.get("key") or i.get("id", "")
        if key and key not in seen:
            seen.add(key)
            unique_issues.append(i)

    return {
        "assignee": assignee,
        "total": len(unique_issues),
        "tickets": [_to_jira_ticket(i, base_url) for i in unique_issues],
    }


@router.get("/risks")
def get_risks(
    project_key: Optional[str] = Query(None),
    board_id: Optional[str] = Query(None),
    user=Depends(get_current_user),
    _max_results: int = 500,
):
    project_key = _default_project_key(project_key)
    board_id = _default_board_id(board_id)

    try:
        issues = jira_client.get_project_issues(project_key=project_key, max_results=_max_results)
    except Exception:
        issues = []

    try:
        sprints = jira_client.get_sprints(board_id=board_id)
    except Exception:
        sprints = []

    active_sprint = next((s for s in sprints if s.get("state") == "active"), None)
    sprint_end: Optional[datetime] = None
    if active_sprint:
        sprint_end = _tz(_parse_date(active_sprint.get("endDate")))

    now = datetime.now(timezone.utc)
    open_issues = [i for i in issues if not _is_done(i)]
    blocked_issues = [i for i in open_issues if _is_blocked(i)]
    blocked_count = len(blocked_issues)

    overdue_count = 0
    if sprint_end and sprint_end < now:
        overdue_count = len(open_issues)

    dependency_issues = []
    for issue in open_issues:
        summary = (_safe_field(issue, "summary") or "").lower()
        labels = _safe_field(issue, "labels") or []
        label_str = " ".join(str(l).lower() for l in labels)
        if "depend" in summary or "block" in label_str or "depend" in label_str:
            dependency_issues.append(issue)
    dependency_count = len(dependency_issues)

    total_open = len(open_issues) or 1
    risk_score = min(
        round(
            (blocked_count / total_open * 40)
            + (overdue_count / total_open * 40)
            + (dependency_count / total_open * 20)
        ),
        100,
    )

    large_ticket_count = len([i for i in open_issues if _story_points(i) > 8])
    unassigned_count = len([i for i in open_issues if _assignee(i) is None])

    radar_scores = {
        "schedule": min(round(overdue_count / total_open * 100), 100),
        "scope": min(round(large_ticket_count / total_open * 100), 100),
        "resources": min(round(unassigned_count / total_open * 100), 100),
        "technical_debt": min(round(blocked_count / total_open * 100), 100),
        "dependencies": min(round(dependency_count / total_open * 100), 100),
        "quality": 0,
    }

    blocked_ages = []
    for issue in blocked_issues[:20]:
        created_dt = _tz(_parse_date(issue.get("fields", {}).get("created", "")))
        age_days = (now - created_dt).days if created_dt else 0
        blocked_ages.append({
            "key": issue.get("key", ""),
            "summary": _safe_field(issue, "summary") or issue.get("key", ""),
            "days": age_days,
        })

    dependency_map = []
    for issue in dependency_issues[:20]:
        summary = _safe_field(issue, "summary") or ""
        dependency_map.append({
            "key": issue.get("key", ""),
            "depends_on": [summary] if summary else [],
        })

    return {
        "blocked": blocked_count,
        "dependencies": dependency_count,
        "overdue": overdue_count,
        "risk_score": risk_score,
        "radar_scores": radar_scores,
        "blocked_ages": blocked_ages,
        "dependency_map": dependency_map,
    }
