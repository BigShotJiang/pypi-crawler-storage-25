"""
Discovery endpoints so the frontend can list all Jira projects and boards
without any hardcoded project key or board ID.
"""
import os
import httpx
from fastapi import APIRouter, Depends, Query
from typing import Optional
from backend.auth import get_current_user
from backend.tools.jira_tool import jira_client

router = APIRouter(prefix="/jira", tags=["jira-meta"])


@router.get("/status")
def jira_status():
    """Check Jira connection — no auth required so the UI can show it before login."""
    base_url = jira_client.base_url
    email = jira_client.email

    missing = []
    if not base_url:
        missing.append("JIRA_BASE_URL")
    if not email:
        missing.append("JIRA_EMAIL")
    if not jira_client.token:
        missing.append("JIRA_API_TOKEN")
    if missing:
        return {
            "connected": False,
            "error": f"Missing env vars: {', '.join(missing)}",
            "base_url": base_url,
            "email": email,
            "project_key": os.environ.get("JIRA_PROJECT_KEY", ""),
            "board_id": os.environ.get("JIRA_BOARD_ID", ""),
        }

    try:
        r = httpx.get(
            f"{base_url}/rest/api/3/myself",
            auth=jira_client.auth,
            headers=jira_client.headers,
            timeout=10,
        )
        if r.status_code == 200:
            user = r.json()
            return {
                "connected": True,
                "display_name": user.get("displayName", ""),
                "email": user.get("emailAddress", email),
                "base_url": base_url,
                "project_key": os.environ.get("JIRA_PROJECT_KEY", ""),
                "board_id": os.environ.get("JIRA_BOARD_ID", ""),
            }
        return {
            "connected": False,
            "error": f"Jira returned HTTP {r.status_code} — check your API token or base URL",
            "base_url": base_url,
            "email": email,
            "project_key": os.environ.get("JIRA_PROJECT_KEY", ""),
            "board_id": os.environ.get("JIRA_BOARD_ID", ""),
        }
    except httpx.ConnectError:
        return {
            "connected": False,
            "error": f"Cannot reach {base_url} — check JIRA_BASE_URL",
            "base_url": base_url,
            "email": email,
            "project_key": os.environ.get("JIRA_PROJECT_KEY", ""),
            "board_id": os.environ.get("JIRA_BOARD_ID", ""),
        }
    except Exception as exc:
        return {
            "connected": False,
            "error": str(exc),
            "base_url": base_url,
            "email": email,
            "project_key": os.environ.get("JIRA_PROJECT_KEY", ""),
            "board_id": os.environ.get("JIRA_BOARD_ID", ""),
        }


@router.get("/debug")
def jira_debug():
    """Debug: test Jira search directly and surface the real error."""
    projects = jira_client.list_projects()
    if not projects:
        return {"error": "list_projects returned empty — check Jira permissions"}

    test_key = projects[0]["key"]
    try:
        r = httpx.post(
            f"{jira_client.base_url}/rest/api/3/search/jql",
            auth=jira_client.auth,
            headers=jira_client.headers,
            json={
                "jql": f'project = "{test_key}" ORDER BY created DESC',
                "maxResults": 5,
                "fields": ["summary", "status"],
            },
            timeout=30,
        )
        return {
            "projects_found": len(projects),
            "test_project": test_key,
            "http_status": r.status_code,
            "jira_response": r.json(),
        }
    except Exception as e:
        return {
            "projects_found": len(projects),
            "test_project": test_key,
            "error": str(e),
        }


@router.get("/projects")
def list_projects(user=Depends(get_current_user)):
    """Return all Jira projects the authenticated user can access."""
    return {"projects": jira_client.list_projects()}


@router.get("/boards")
def list_boards(
    project_key: Optional[str] = Query(None, description="Filter boards by project key"),
    user=Depends(get_current_user),
):
    """Return all Jira boards, optionally filtered to a project."""
    return {"boards": jira_client.list_boards(project_key=project_key)}
