import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List

EMAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><style>
  body {{ font-family: Arial, sans-serif; background: #f5f5f5; }}
  .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; }}
  .header {{ background: #0d2e5c; color: white; padding: 24px; }}
  .header h1 {{ margin: 0; font-size: 22px; }}
  .content {{ padding: 24px; }}
  table {{ width: 100%; border-collapse: collapse; margin: 16px 0; }}
  th {{ background: #e8f0fe; text-align: left; padding: 10px; }}
  td {{ padding: 10px; border-bottom: 1px solid #eee; }}
  .ac-item {{ margin: 4px 0; padding-left: 16px; }}
  .btn {{ display: inline-block; background: #185fa5; color: white; padding: 12px 24px;
          text-decoration: none; border-radius: 6px; margin: 16px 0; }}
  .btn:hover {{ background: #0c447c; }}
  .footer {{ background: #f8f9fa; padding: 16px; text-align: center; color: #666; font-size: 12px; }}
</style></head>
<body>
<div class="container">
  <div class="header">
    <h1>New Ticket Assigned: {ticket_key}</h1>
    <p style="margin:8px 0 0">PM Agent v2 — Automated Assignment</p>
  </div>
  <div class="content">
    <h2 style="color:#0d2e5c">{title}</h2>
    <table>
      <tr><th>Field</th><th>Value</th></tr>
      <tr><td><strong>Ticket Key</strong></td><td>{ticket_key}</td></tr>
      <tr><td><strong>Priority</strong></td><td>{priority}</td></tr>
      <tr><td><strong>Type</strong></td><td>{issue_type}</td></tr>
      <tr><td><strong>Story Points</strong></td><td>{story_points}</td></tr>
    </table>
    <h3>Description</h3>
    <p>{description}</p>
    <h3>Acceptance Criteria</h3>
    {ac_html}
    <a href="{ticket_url}" class="btn">View in Jira</a>
  </div>
  <div class="footer">Sent by PM Agent v2 | Do not reply to this email</div>
</div>
</body>
</html>
"""


def send_assignment_email(
    to_email: str,
    ticket_key: str,
    title: str,
    description: str,
    priority: str,
    issue_type: str,
    story_points: int,
    acceptance_criteria: List[str],
    ticket_url: str,
) -> bool:
    """Send HTML assignment notification email. Returns True on success, False on failure (never raises)."""
    try:
        sender = os.environ.get("EMAIL_SENDER", "")
        smtp_host = os.environ.get("SMTP_HOST", "smtp.office365.com")
        smtp_port = int(os.environ.get("SMTP_PORT", "587"))
        smtp_password = os.environ.get("SMTP_PASSWORD", os.environ.get("AZURE_OPENAI_API_KEY", ""))

        ac_html = "".join(f'<div class="ac-item">• {ac}</div>' for ac in acceptance_criteria)
        html_body = EMAIL_TEMPLATE.format(
            ticket_key=ticket_key,
            title=title,
            description=description,
            priority=priority,
            issue_type=issue_type,
            story_points=story_points,
            ac_html=ac_html,
            ticket_url=ticket_url,
        )
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[PM Agent] New ticket assigned: {ticket_key} - {title}"
        msg["From"] = sender
        msg["To"] = to_email
        msg.attach(MIMEText(html_body, "html"))

        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            server.login(sender, smtp_password)
            server.sendmail(sender, [to_email], msg.as_string())
        return True
    except Exception as e:
        print(f"Warning: Email to {to_email} failed: {e}")
        return False
