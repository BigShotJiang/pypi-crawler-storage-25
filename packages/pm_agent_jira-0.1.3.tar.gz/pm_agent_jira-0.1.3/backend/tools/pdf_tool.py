import pdfplumber
from typing import Optional


def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract all text and tables from a PDF file."""
    text_parts = []
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            page_text = page.extract_text()
            if page_text:
                text_parts.append(f"--- Page {page_num} ---\n{page_text}")
            tables = page.extract_tables()
            for table in tables:
                table_text = "\n".join(
                    " | ".join(str(cell) if cell else "" for cell in row)
                    for row in table if row
                )
                if table_text.strip():
                    text_parts.append(f"[Table on page {page_num}]\n{table_text}")
    return "\n\n".join(text_parts)
