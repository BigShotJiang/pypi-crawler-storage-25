import os
import time
import json
import hashlib
import threading
import httpx
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple

# Module-level TTL cache shared across all requests within the process.
# Key: hash of (url + sorted params/body), Value: (timestamp, result).
_CACHE: Dict[str, Tuple[float, Any]] = {}
_SHORT_TTL = 300     # 5 min — sprint issues, project issues, sprints list
_LONG_TTL  = 600     # 10 min — projects list, boards list (rarely change)
_DISK_TTL  = 1800    # 30 min — max age to load from disk cache on startup

# Persist cache to disk so restarts serve data immediately without Jira API calls.
# Use project root (2 levels up from this file) so the path is the same on Windows and WSL.
_CACHE_FILE = Path(__file__).parent.parent.parent / ".jira_cache.json"
_write_timer: Optional[threading.Timer] = None


def _load_disk_cache():
    """Load persisted cache from disk on startup (non-blocking, best-effort)."""
    try:
        if not _CACHE_FILE.exists():
            return
        with open(_CACHE_FILE) as f:
            data = json.load(f)
        now = time.time()
        loaded = 0
        for key, entry in data.items():
            ts, val = entry[0], entry[1]
            if now - ts < _DISK_TTL:
                _CACHE[key] = (ts, val)
                loaded += 1
    except Exception:
        pass


def _write_disk_cache():
    """Write current cache to disk (called from background thread)."""
    try:
        snapshot = {k: list(v) for k, v in list(_CACHE.items())}
        with open(_CACHE_FILE, "w") as f:
            json.dump(snapshot, f)
    except Exception:
        pass


def _schedule_disk_write():
    """Debounced: write cache to disk 3 seconds after the last update."""
    global _write_timer
    if _write_timer is not None:
        _write_timer.cancel()
    _write_timer = threading.Timer(3.0, _write_disk_cache)
    _write_timer.daemon = True
    _write_timer.start()


# Load persisted cache immediately on module import
_load_disk_cache()


def _cache_key(*parts) -> str:
    raw = json.dumps(parts, sort_keys=True, default=str)
    return hashlib.md5(raw.encode()).hexdigest()


def _cache_get(key: str, ttl: int):
    entry = _CACHE.get(key)
    if entry:
        ts, val = entry
        if time.time() - ts < ttl:
            return val
    return None


def _cache_set(key: str, val: Any):
    _CACHE[key] = (time.time(), val)
    _schedule_disk_write()


class JiraClient:
    def __init__(self):
        self.base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
        self.email = os.environ.get("JIRA_EMAIL", "")
        self.token = os.environ.get("JIRA_API_TOKEN", "")
        self.auth = (self.email, self.token)
        self.headers = {"Content-Type": "application/json", "Accept": "application/json"}

    def is_configured(self) -> bool:
        return bool(self.base_url and self.email and self.token)

    def _get(self, path: str, params: dict = None) -> dict:
        if not self.is_configured():
            raise RuntimeError(
                "Jira credentials not configured. "
                "Run 'pm-agent init' and fill in ~/.pm-agent/.env with "
                "JIRA_BASE_URL, JIRA_EMAIL, and JIRA_API_TOKEN."
            )
        url = f"{self.base_url}/rest/api/3{path}"
        r = httpx.get(url, auth=self.auth, headers=self.headers, params=params or {}, timeout=15)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, data: dict) -> dict:
        url = f"{self.base_url}/rest/api/3{path}"
        r = httpx.post(url, auth=self.auth, headers=self.headers, json=data, timeout=15)
        r.raise_for_status()
        return r.json()

    def _put(self, path: str, data: dict) -> dict:
        url = f"{self.base_url}/rest/api/3{path}"
        r = httpx.put(url, auth=self.auth, headers=self.headers, json=data, timeout=15)
        r.raise_for_status()
        return r.json()

    # ------------------------------------------------------------------
    # List accessible projects and boards
    # ------------------------------------------------------------------

    def list_projects(self) -> List[dict]:
        """Return all projects the authenticated user can access."""
        key = _cache_key("list_projects")
        cached = _cache_get(key, _LONG_TTL)
        if cached is not None:
            return cached
        try:
            result = self._get("/project/search", {"maxResults": 100, "orderBy": "name"})
            projects = [
                {
                    "key": p["key"],
                    "id": p["id"],
                    "name": p["name"],
                    "type": p.get("projectTypeKey", ""),
                }
                for p in result.get("values", [])
            ]
            _cache_set(key, projects)
            return projects
        except Exception:
            return []

    def list_boards(self, project_key: Optional[str] = None) -> List[dict]:
        """Return all boards, optionally filtered to a project."""
        key = _cache_key("list_boards", project_key)
        cached = _cache_get(key, _LONG_TTL)
        if cached is not None:
            return cached
        try:
            params: dict = {"maxResults": 100}
            if project_key:
                params["projectKeyOrId"] = project_key
            url = f"{self.base_url}/rest/agile/1.0/board"
            r = httpx.get(url, auth=self.auth, params=params, timeout=8)
            r.raise_for_status()
            boards = [
                {"id": b["id"], "name": b["name"], "type": b.get("type", "")}
                for b in r.json().get("values", [])
            ]
            _cache_set(key, boards)
            return boards
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Issue operations (project_key passed per call)
    # ------------------------------------------------------------------

    def create_issue(
        self,
        project_key: str,
        title: str,
        description: str,
        issue_type: str,
        priority: str,
        story_points: int,
        labels: List[str],
        acceptance_criteria: List[str],
        parent_key: Optional[str] = None,
    ) -> dict:
        ac_text = "\n".join(f"• {ac}" for ac in acceptance_criteria)
        full_description = f"{description}\n\n*Acceptance Criteria:*\n{ac_text}"
        fields: Dict[str, Any] = {
            "project": {"key": project_key},
            "summary": title,
            "description": {
                "type": "doc",
                "version": 1,
                "content": [
                    {
                        "type": "paragraph",
                        "content": [{"type": "text", "text": full_description}],
                    }
                ],
            },
            "issuetype": {"name": issue_type},
            "priority": {"name": priority},
            "labels": labels,
            "customfield_10016": story_points,
        }
        if parent_key:
            fields["parent"] = {"key": parent_key}
        result = self._post("/issue", {"fields": fields})
        return {
            "key": result["key"],
            "id": result["id"],
            "url": f"{self.base_url}/browse/{result['key']}",
        }

    def assign_issue(self, issue_key: str, account_id: str) -> bool:
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}/assignee"
            r = httpx.put(
                url,
                auth=self.auth,
                headers=self.headers,
                json={"accountId": account_id},
                timeout=8,
            )
            return r.status_code < 300
        except Exception:
            return False

    def _search(self, jql: str, max_results: int = 500, fields: str = "") -> List[dict]:
        """POST to /search/jql with cursor pagination to fetch all results."""
        cache_key = _cache_key("search", jql, max_results, fields)
        cached = _cache_get(cache_key, _SHORT_TTL)
        if cached is not None:
            return cached

        field_list = fields.split(",") if fields else [
            "summary", "status", "assignee", "priority",
            "issuetype", "customfield_10016", "labels", "created", "updated", "parent",
        ]
        all_issues: List[dict] = []
        next_page_token: Optional[str] = None
        page_size = min(100, max_results)

        try:
            while len(all_issues) < max_results:
                body: Dict[str, Any] = {
                    "jql": jql,
                    "maxResults": page_size,
                    "fields": field_list,
                }
                if next_page_token:
                    body["nextPageToken"] = next_page_token

                result = self._post("/search/jql", body)
                issues = result.get("issues", [])
                all_issues.extend(issues)

                if result.get("isLast", True) or not issues:
                    break
                next_page_token = result.get("nextPageToken")
                if not next_page_token:
                    break

            result_list = all_issues[:max_results]
            _cache_set(cache_key, result_list)
            return result_list
        except Exception:
            return all_issues

    def get_project_issues(self, project_key: str = '', max_results: int = 500) -> List[dict]:
        if project_key:
            jql = f"project = \"{project_key}\" ORDER BY created DESC"
        else:
            projects = self.list_projects()
            if not projects:
                return []
            keys = ", ".join(f'"{p["key"]}"' for p in projects)
            jql = f"project in ({keys}) ORDER BY created DESC"
        return self._search(jql, max_results)

    def get_recently_updated_issues(
        self,
        since_minutes: int = 1,
        project_key: Optional[str] = None,
    ) -> List[dict]:
        base = f"updated >= -{since_minutes}m ORDER BY updated DESC"
        if project_key:
            jql = f"project = \"{project_key}\" AND {base}"
        else:
            projects = self.list_projects()
            if not projects:
                return []
            keys = ", ".join(f'"{p["key"]}"' for p in projects)
            jql = f"project in ({keys}) AND {base}"
        return self._search(jql, 100, "summary,status,assignee,updated,project")

    # ------------------------------------------------------------------
    # Board / sprint operations (board_id passed per call)
    # ------------------------------------------------------------------

    def get_active_sprint(self, board_id: str) -> Optional[dict]:
        if not board_id:
            for board in self.list_boards():
                try:
                    url = f"{self.base_url}/rest/agile/1.0/board/{board['id']}/sprint"
                    r = httpx.get(url, auth=self.auth, params={"state": "active"}, timeout=8)
                    r.raise_for_status()
                    sprints = r.json().get("values", [])
                    if sprints:
                        return sprints[0]
                except Exception:
                    continue
            return None
        try:
            url = f"{self.base_url}/rest/agile/1.0/board/{board_id}/sprint"
            r = httpx.get(url, auth=self.auth, params={"state": "active"}, timeout=8)
            r.raise_for_status()
            sprints = r.json().get("values", [])
            return sprints[0] if sprints else None
        except Exception:
            return None

    def get_sprint_members(self, sprint_id: int) -> List[dict]:
        try:
            url = f"{self.base_url}/rest/agile/1.0/sprint/{sprint_id}/issue"
            r = httpx.get(url, auth=self.auth, params={"maxResults": 200}, timeout=8)
            r.raise_for_status()
            issues = r.json().get("issues", [])
            members: dict = {}
            for issue in issues:
                assignee = issue.get("fields", {}).get("assignee")
                if assignee:
                    aid = assignee["accountId"]
                    if aid not in members:
                        members[aid] = {
                            "accountId": aid,
                            "displayName": assignee.get("displayName", ""),
                            "emailAddress": assignee.get("emailAddress", ""),
                            "openTickets": 0,
                        }
                    status = issue.get("fields", {}).get("status", {}).get("name", "")
                    if status.lower() not in ("done", "closed"):
                        members[aid]["openTickets"] += 1
            return list(members.values())
        except Exception:
            return []

    def _fetch_board_sprints(self, board_id) -> List[dict]:
        """Fetch sprints for a single board (used for parallel fetching)."""
        try:
            url = f"{self.base_url}/rest/agile/1.0/board/{board_id}/sprint"
            r = httpx.get(url, auth=self.auth, params={"maxResults": 50}, timeout=8)
            r.raise_for_status()
            return r.json().get("values", [])
        except Exception:
            return []

    def get_sprints(self, board_id: str) -> List[dict]:
        cache_key = _cache_key("get_sprints", board_id)
        cached = _cache_get(cache_key, _SHORT_TTL)
        if cached is not None:
            return cached

        if not board_id:
            # Only fetch from scrum boards (not kanban/simple) in parallel
            scrum_boards = [b for b in self.list_boards() if b.get("type") == "scrum"]
            all_sprints: List[dict] = []
            seen_ids: set = set()
            from concurrent.futures import ThreadPoolExecutor, as_completed
            with ThreadPoolExecutor(max_workers=min(len(scrum_boards), 8)) as ex:
                futures = {ex.submit(self._fetch_board_sprints, b["id"]): b["id"] for b in scrum_boards}
                for future in as_completed(futures):
                    for s in future.result():
                        if s.get("id") not in seen_ids:
                            seen_ids.add(s.get("id"))
                            all_sprints.append(s)
            _cache_set(cache_key, all_sprints)
            return all_sprints

        sprints = self._fetch_board_sprints(board_id)
        if sprints:
            _cache_set(cache_key, sprints)
            return sprints

        # Board has no sprints (e.g. simple/kanban board). Cache this fact so we
        # don't re-hit the API on every call, then fall back to all scrum boards.
        _cache_set(cache_key, [])
        fallback_key = _cache_key("get_sprints", "")
        fallback = _cache_get(fallback_key, _SHORT_TTL)
        if fallback is not None:
            return fallback
        return self.get_sprints("")

    def get_sprint_issues(self, sprint_id: int) -> List[dict]:
        cache_key = _cache_key("get_sprint_issues", sprint_id)
        cached = _cache_get(cache_key, _SHORT_TTL)
        if cached is not None:
            return cached
        try:
            url = f"{self.base_url}/rest/agile/1.0/sprint/{sprint_id}/issue"
            r = httpx.get(
                url,
                auth=self.auth,
                params={
                    "maxResults": 500,
                    "fields": "summary,status,assignee,customfield_10016,issuetype,priority,created,updated",
                },
                timeout=8,
            )
            r.raise_for_status()
            issues = r.json().get("issues", [])
            _cache_set(cache_key, issues)
            return issues
        except Exception:
            return []

    def get_backlog_issues(self, project_key: str = '', max_results: int = 500) -> List[dict]:
        """Return only true backlog items: not in any sprint and not done."""
        if project_key:
            jql = (
                f'project = "{project_key}" AND sprint is EMPTY '
                f'AND statusCategory != Done ORDER BY created DESC'
            )
        else:
            projects = self.list_projects()
            if not projects:
                return []
            keys = ", ".join(f'"{p["key"]}"' for p in projects)
            jql = (
                f'project in ({keys}) AND sprint is EMPTY '
                f'AND statusCategory != Done ORDER BY created DESC'
            )
        return self._search(jql, max_results)

    def get_stale_tickets(self, project_key: str = '', days: int = 2, max_results: int = 500) -> List[dict]:
        """Return issues not updated in the past `days` days, excluding terminal statuses."""
        excluded = '"Done", "In Production", "Closed", "Resolved"'
        interval = f'-{days * 24}h'
        if project_key:
            jql = (
                f'project = "{project_key}" '
                f'AND status not in ({excluded}) '
                f'AND updated <= "{interval}" '
                f'ORDER BY updated DESC'
            )
        else:
            projects = self.list_projects()
            if not projects:
                return []
            keys = ", ".join(f'"{p["key"]}"' for p in projects)
            jql = (
                f'project in ({keys}) '
                f'AND status not in ({excluded}) '
                f'AND updated <= "{interval}" '
                f'ORDER BY updated DESC'
            )
        return self._search(
            jql, max_results,
            "summary,status,assignee,priority,issuetype,created,updated,labels,comment",
        )


    def get_issues_by_assignee(
        self,
        assignee: str,
        project_key: str = "",
        max_results: int = 100,
    ) -> List[dict]:
        """Return open issues assigned to a user (search by display name, email, or accountId)."""
        assignee_escaped = assignee.replace('"', '\\"')
        if project_key:
            jql = (
                f'project = "{project_key}" '
                f'AND assignee in membersOf("{assignee_escaped}") OR '
                f'(project = "{project_key}" AND assignee = "{assignee_escaped}") '
                f'ORDER BY priority DESC, updated DESC'
            )
        else:
            jql = (
                f'assignee = "{assignee_escaped}" '
                f'ORDER BY priority DESC, updated DESC'
            )
        try:
            return self._search(
                jql, max_results,
                "summary,status,assignee,priority,issuetype,created,updated,labels,customfield_10016,customfield_10028",
            )
        except Exception:
            # Fallback: simple text match on assignee field
            fallback_jql = (
                f'assignee = "{assignee_escaped}" ORDER BY updated DESC'
                if not project_key
                else f'project = "{project_key}" AND assignee = "{assignee_escaped}" ORDER BY updated DESC'
            )
            return self._search(
                fallback_jql, max_results,
                "summary,status,assignee,priority,issuetype,created,updated,labels,customfield_10016,customfield_10028",
            )


jira_client = JiraClient()
