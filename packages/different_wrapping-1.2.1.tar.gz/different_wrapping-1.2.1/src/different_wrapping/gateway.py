def generate_gateway(service_name, service, challenge, args):
    # First we need to determine the port that the ingress is supposed to be pointed towards
    if "ports" not in service.container_dict:
        raise RuntimeError(
            f"Tried to create gateway for {service_name} but it has no ports exposed(and therefore no k8s service to point to)"
        )

    external_ports = service.ports()

    if len(external_ports) == 0:
        raise RuntimeError(
            f"Unable to create gateway for {service_name} as there are no ports"
        )
    elif len(external_ports) > 1:
        raise RuntimeError(
            f"Unable to determine external port for {service_name} as there are more than one ports exposed"
        )

    external_port, internal_port = external_ports[0]

    # Determine DNS name
    host = service.get_dns_name(args.dns_host)

    return {
        "apiVersion": "gateway.networking.k8s.io/v1",
        "kind": "HTTPRoute",
        "metadata": {
            "name": f"gateway-{challenge.safe_name()}-{service_name}",
        },
        "spec": {
            "parentRefs": [
                {
                    "name": args.gateway_parent_name,
                    "namespace": args.gateway_parent_namespace,
                    "sectionName": "https",
                    "kind": "Gateway",
                    "group": "gateway.networking.k8s.io",
                }
            ],
            "hostnames": [host],
            "rules": [
                {
                    "matches": [{"path": {"type": "PathPrefix", "value": "/"}}],
                    "backendRefs": [
                        {
                            "name": service_name,
                            "port": external_port,
                            "weight": 1,
                            "group": "",
                            "kind": "Service",
                        }
                    ],
                }
            ],
        },
    }


def generate_tcp_gateway(service_name, service, challenge, args):
    # First we need to determine the port that the ingress is supposed to be pointed towards
    if "ports" not in service.container_dict:
        raise RuntimeError(
            f"Tried to create TCP gateway for {service_name} but it has no ports exposed(and therefore no k8s service to point to)"
        )

    external_ports = service.ports()

    if len(external_ports) == 0:
        raise RuntimeError(
            f"Unable to create TCP gateway for {service_name} as there are no ports"
        )
    elif len(external_ports) > 1:
        raise RuntimeError(
            f"Unable to determine external port for {service_name} as there are more than one ports exposed"
        )

    # Determine DNS name
    # host = service.get_dns_name(args.dns_host)

    if args.tcp_xlistenerset_gateway_name is None:
        raise RuntimeError(
            "Unable to create TCP gateway - no xlistenerset gateway name is set"
        )

    gateway_name = f"tcp-xlistener-{challenge.safe_name()}-{service_name}"

    # listen_port = random.randint(2048, 64000)  # yolo
    external_port, internal_port = external_ports[0]

    xlistenerset = {
        "apiVersion": "gateway.networking.x-k8s.io/v1alpha1",
        "kind": "XListenerSet",
        "metadata": {"name": gateway_name},
        "spec": {
            "parentRef": {
                "name": args.tcp_xlistenerset_gateway_name,
                "kind": "Gateway",
                "group": "gateway.networking.k8s.io",
                "namespace": "envoy-gateway-system",
            },
            "listeners": [
                {
                    "name": "challenge",  # Custom name
                    "allowedRoutes": {
                        "namespaces": {
                            "from": "Selector",
                            "selector": {"matchLabels": {"chall": challenge.name()}},
                        },
                        "kinds": [{"kind": "TCPRoute"}],
                    },
                    "protocol": "TCP",
                    "port": external_port,  # Custom port
                }
            ],
        },
    }

    tcproute = {
        "apiVersion": "gateway.networking.k8s.io/v1alpha2",
        "kind": "TCPRoute",
        "metadata": {
            "name": f"tcproute-{challenge.safe_name()}-{service_name}",
        },
        "spec": {
            "parentRefs": [
                {
                    "name": gateway_name,
                    "sectionName": "challenge",
                    "group": "gateway.networking.x-k8s.io",
                    "kind": "XListenerSet",
                }
            ],
            "rules": [
                {
                    "backendRefs": [
                        {
                            "name": service_name,
                            "port": external_port,
                            "weight": 1,
                            "group": "",
                            "kind": "Service",
                        }
                    ]
                }
            ],
        },
    }

    return [xlistenerset, tcproute]


def generate_udp_gateway(service_name, service, challenge, args):
    # First we need to determine the port that the ingress is supposed to be pointed towards
    if "ports" not in service.container_dict:
        raise RuntimeError(
            f"Tried to create UDP gateway for {service_name} but it has no ports exposed(and therefore no k8s service to point to)"
        )

    external_ports = service.ports()

    if len(external_ports) == 0:
        raise RuntimeError(
            f"Unable to create UDP gateway for {service_name} as there are no ports"
        )
    elif len(external_ports) > 1:
        raise RuntimeError(
            f"Unable to determine external port for {service_name} as there are more than one ports exposed"
        )

    # Determine DNS name
    # host = service.get_dns_name(args.dns_host)

    if args.tcp_xlistenerset_gateway_name is None:
        raise RuntimeError(
            "Unable to create UDP gateway - no xlistenerset gateway name is set"
        )

    gateway_name = f"udp-xlistener-{challenge.safe_name()}-{service_name}"

    # listen_port = random.randint(2048, 64000)  # yolo
    external_port, internal_port = external_ports[0]

    xlistenerset = {
        "apiVersion": "gateway.networking.x-k8s.io/v1alpha1",
        "kind": "XListenerSet",
        "metadata": {"name": gateway_name},
        "spec": {
            "parentRef": {
                "name": args.tcp_xlistenerset_gateway_name,
                "kind": "Gateway",
                "group": "gateway.networking.k8s.io",
                "namespace": "envoy-gateway-system",
            },
            "listeners": [
                {
                    "name": "challenge",  # Custom name
                    "allowedRoutes": {
                        "namespaces": {
                            "from": "Selector",
                            "selector": {"matchLabels": {"chall": challenge.name()}},
                        },
                        "kinds": [{"kind": "UDPRoute"}],
                    },
                    "protocol": "UDP",
                    "port": external_port,  # Custom port
                }
            ],
        },
    }

    tcproute = {
        "apiVersion": "gateway.networking.k8s.io/v1alpha2",
        "kind": "UDPRoute",
        "metadata": {
            "name": f"tcproute-{challenge.safe_name()}-{service_name}",
        },
        "spec": {
            "parentRefs": [
                {
                    "name": gateway_name,
                    "sectionName": "challenge",
                    "group": "gateway.networking.x-k8s.io",
                    "kind": "XListenerSet",
                }
            ],
            "rules": [
                {
                    "backendRefs": [
                        {
                            "name": service_name,
                            "port": external_port,
                            "weight": 1,
                            "group": "",
                            "kind": "Service",
                        }
                    ]
                }
            ],
        },
    }

    return [xlistenerset, tcproute]
