"""
Cross-validate architecture.json dependency entries against <include> tags in prompts.

Phase 5: surface drift between declarative architecture dependencies and the module
prompts the LLM actually pulls in via <include>.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, FrozenSet, List, Optional

from .architecture_registry import extract_modules
from .sync_order import extract_includes_from_file, extract_module_from_include


def _module_prompt_include_target(include_path: str) -> Optional[str]:
    """
    Map an <include> path to a module basename only when it names another module prompt.

    Context/example files (e.g. ``context/foo_example.py``) are ignored so validation
    matches architecture.json, which lists dependencies between module prompts, not
    every referenced artifact.
    """
    p = (include_path or "").strip()
    if not p.lower().endswith(".prompt"):
        return None
    return extract_module_from_include(p)

# Top-level directories in the PDD repo that ship sample architecture (not app code).
_BUNDLED_SAMPLE_TOPLEVEL_DIRS: FrozenSet[str] = frozenset(
    {"examples", "example_project", "example_workspace", "staging"}
)


def _arch_path_under_skipped_sample_tree(
    arch_path: Path,
    project_root: Path,
    skip_roots: FrozenSet[str],
) -> bool:
    if not skip_roots:
        return False
    try:
        rel = arch_path.resolve().relative_to(project_root.resolve())
    except ValueError:
        return False
    return len(rel.parts) >= 2 and rel.parts[0] in skip_roots


def collect_architecture_include_validation_warnings(
    project_root: Path,
    *,
    skip_bundled_sample_arch: bool = True,
) -> List[str]:
    """
    Run cross-validation for every ``architecture.json`` under ``project_root``.

    Each file is validated with its **parent directory** as the project root for
    resolving ``prompts/…`` paths, so nested packages (e.g. ``services/api/``) work.

    When ``skip_bundled_sample_arch`` is true (default), skips trees like
    ``examples/`` used in the PDD repository so routine sync stays focused on app code.
    """
    from .architecture_registry import find_architecture_for_project

    root = project_root.resolve()
    skip = _BUNDLED_SAMPLE_TOPLEVEL_DIRS if skip_bundled_sample_arch else frozenset()
    warnings: List[str] = []
    for arch_path in find_architecture_for_project(project_root):
        if _arch_path_under_skipped_sample_tree(arch_path, root, skip):
            continue
        try:
            with open(arch_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        modules = extract_modules(data)
        if not modules:
            continue
        base = arch_path.parent
        for w in cross_validate_architecture_with_prompt_includes(modules, base):
            warnings.append(f"{arch_path}: {w}")
    return warnings


def run_validate_arch_includes_cli(
    project_root: Path,
    *,
    strict: bool,
    quiet: bool,
) -> None:
    """
    Print validation messages and exit with code 1 if there are issues.

    Used by ``pdd checkup --validate-arch-includes``.
    """
    import click

    warnings = list_validate_arch_include_warnings(project_root, strict=strict)
    if not warnings:
        if not quiet:
            click.echo("No architecture / <include> mismatches found.")
        return
    for w in warnings:
        if not quiet:
            click.echo(click.style(f"Warning: {w}", fg="yellow"), err=True)
    raise click.exceptions.Exit(1)


def list_validate_arch_include_warnings(project_root: Path, *, strict: bool) -> List[str]:
    """
    Return cross-validation issues for ``project_root``.

    When ``strict`` is False (default CLI), skip bundled sample trees under
    ``examples/``, ``example_project/``, etc. When True, validate those too
    (useful for maintainer / CI runs against the full repo).
    """
    return collect_architecture_include_validation_warnings(
        project_root,
        skip_bundled_sample_arch=not strict,
    )


def print_architecture_include_validation_warnings(*, quiet: bool, verbose: bool = False) -> None:
    """Print yellow warnings for the current project only when ``--verbose`` (and not ``--quiet``)."""
    if quiet or not verbose:
        return
    from rich import print as rprint

    from .architecture_registry import find_project_root

    for w in collect_architecture_include_validation_warnings(find_project_root()):
        rprint(f"[yellow]Warning: {w}[/yellow]")


def _resolve_architecture_prompt_path(filename: str, project_root: Path) -> Path:
    """Resolve architecture ``filename`` to an on-disk path under the project."""
    rel = filename.replace("\\", "/").lstrip("/")
    if rel.startswith("prompts/"):
        return (project_root / rel).resolve()
    return (project_root / "prompts" / rel).resolve()


def resolve_architecture_prompt_path(filename: str, project_root: Path) -> Path:
    """Public API for resolving an architecture ``filename`` to an on-disk path."""
    return _resolve_architecture_prompt_path(filename, project_root)


def _pdd_dependency_modules(prompt_path: Path, self_mod: str) -> set[str]:
    """
    Return module basenames declared via ``<pdd-dependency>`` tags in the prompt header.

    Per ``docs/prompting_guide.md``, ``<pdd-dependency>`` is the authoritative
    architectural declaration and ``<include>`` is purely for LLM context.
    The forward check treats a ``<pdd-dependency>`` tag as proof that the prompt
    has declared the dependency, so arch-listed deps backed only by a tag (no
    ``<include>`` of the module's prompt) are not flagged as drift.
    """
    try:
        content = prompt_path.read_text(encoding="utf-8")
    except OSError:
        return set()
    if not content:
        return set()

    from .architecture_sync import parse_prompt_tags

    modules: set[str] = set()
    tags = parse_prompt_tags(content)
    for dep in tags.get("dependencies", []) or []:
        m = extract_module_from_include(dep)
        if m and m != self_mod:
            modules.add(m)
    return modules


def cross_validate_architecture_with_prompt_includes(
    arch_data: List[Dict[str, Any]],
    project_root: Path,
) -> List[str]:
    """
    Compare each architecture entry's ``dependencies`` (as module basenames) with
    module targets of ``<include>`` tags in the corresponding prompt file.

    A declared dependency is satisfied if the prompt either ``<include>``s the
    dependency's prompt OR declares it via ``<pdd-dependency>`` (the metadata
    tag the prompting guide calls the authoritative architectural declaration).

    The reverse direction (``<include>`` of a module prompt without a matching
    arch dep) still warns; drift between ``<pdd-dependency>`` tags and
    ``architecture.json`` is handled by ``architecture_sync``, not this check.

    Non-module includes (docs, preambles, etc.) are ignored via
    ``extract_module_from_include``.

    Returns:
        Human-readable warning strings (empty if no mismatches / nothing to check).
    """
    warnings: List[str] = []

    filename_to_basename: Dict[str, str] = {}
    for entry in arch_data:
        fn = entry.get("filename") or ""
        if not fn:
            continue
        b = extract_module_from_include(fn)
        if b:
            filename_to_basename[fn] = b

    for entry in arch_data:
        fn = entry.get("filename") or ""
        if not fn:
            continue
        mod_base = filename_to_basename.get(fn)
        if not mod_base:
            continue

        prompt_path = _resolve_architecture_prompt_path(fn, project_root)
        if not prompt_path.is_file():
            warnings.append(
                f"Cross-validation skipped for architecture entry {fn!r}: "
                f"prompt file not found at {prompt_path}"
            )
            continue

        includes = extract_includes_from_file(prompt_path)
        include_modules: set[str] = set()
        include_proof: Dict[str, str] = {}
        for inc in includes:
            m = _module_prompt_include_target(inc)
            if m and m != mod_base:
                include_modules.add(m)
                include_proof.setdefault(m, inc)

        tag_modules = _pdd_dependency_modules(prompt_path, mod_base)
        forward_declared = include_modules | tag_modules

        arch_modules: set[str] = set()
        for dep_fn in entry.get("dependencies", []):
            db = filename_to_basename.get(dep_fn)
            if db and db != mod_base:
                arch_modules.add(db)

        for d in sorted(arch_modules - forward_declared):
            dep_fn_proof = next(
                (
                    df
                    for df in entry.get("dependencies", [])
                    if filename_to_basename.get(df) == d
                ),
                None,
            )
            extra = f" ({dep_fn_proof!r})" if dep_fn_proof else ""
            warnings.append(
                f"architecture.json / <include> mismatch: {fn!r} declares dependency on module "
                f"{d!r}{extra} but the prompt has no <include> or <pdd-dependency> of that module's prompt"
            )

        for i in sorted(include_modules - arch_modules):
            inc_s = include_proof.get(i, "")
            warnings.append(
                f"architecture.json / <include> mismatch: {fn!r} <include>s module {i!r} "
                f"({inc_s!r}) but architecture.json dependencies do not list that module"
            )

    return warnings
