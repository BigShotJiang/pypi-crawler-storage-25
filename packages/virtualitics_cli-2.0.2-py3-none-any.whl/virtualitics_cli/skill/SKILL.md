---
name: vaip
description: Drive the Virtualitics AI Platform CLI (vaip) end-to-end — scaffold, validate, build, deploy, manage VAIP custom apps. Use when the user wants to create, ship, or operate a VAIP app via the vaip command-line tool. Requires vaip 2.0.1+ installed.
---

# Drive the Virtualitics AI Platform CLI (vaip)

`vaip` is the CLI for scaffolding, building, and deploying custom apps to the Virtualitics AI Platform. This skill teaches you how to drive it deterministically.

## Always pass `--json` first

Every `vaip` command supports a global `--json` flag that emits a stable structured envelope. Use it for every invocation in agent contexts. The shape never varies:

```json
{"status": "ok" | "error", "code": <int>, "message": "<string>", "data": <object | null>}
```

`status` and `code` together determine success. `data` carries command-specific payload (the backend response, a checks array, the config, etc.). `message` is a one-line human summary suitable to surface to the user.

Example:
```bash
vaip --json status
# {"status": "ok", "code": 200, "message": "Connected to VAIP", "data": {"username": "...", "organization_id": "...", "installed_modules": [...]}}
```

## Exit codes

Branch on these — they're stable and meaningful:

| Code | Constant | Meaning |
|---|---|---|
| 0 | EXIT_OK | Success |
| 1 | EXIT_GENERIC | Unspecified failure |
| 2 | EXIT_CONFIG_ERROR | Config file missing, unreadable, or `current_context` invalid |
| 3 | EXIT_VALIDATION_ERROR | Bad arguments, scaffold validation failed, missing required flag |
| 4 | EXIT_NETWORK_ERROR | Connection refused or request timeout |
| 5 | EXIT_AUTH_ERROR | Backend returned 401/403 |
| 6 | EXIT_NOT_FOUND | Backend returned 404 (route missing OR resource missing) |
| 7 | EXIT_BACKEND_ERROR | Backend returned 5xx |

If you see exit code 6 ("not found"), inspect `data.message` to disambiguate "endpoint missing — backend too old" from "resource missing — empty store". The text usually makes it obvious.

## Commands

### Context management

A "context" is a named set of `{host, token, username}` for a VAIP instance. The CLI stores them in `~/Library/Application Support/virtualitics-cli/virtualitics_config.json` (macOS) or the platform equivalent.

| Command | Purpose | Notes |
|---|---|---|
| `vaip --json show-context` | Read the current config file | `data` is the full config dict — **includes bearer tokens at `data.<context>.token`. Do NOT echo this output verbatim to the user or write it to logs/transcripts.** Read what you need (e.g. `data.current_context`) and discard the rest. |
| `vaip --json use-context <name>` | Switch the active context | Errors with code 6 if `<name>` doesn't exist |
| `vaip --json config -N <name> -H <host> -T <token> -U <user>` | Add a new context AND switch to it | Always swaps `current_context` to the new entry |
| `vaip --json edit-context <name> [--host H] [--token T] [--username U]` | Update fields on an existing context | At least one flag required in `--json` mode (no prompts) |
| `vaip --json delete-context <name>` | Remove a context | `data.current_context_dangling: true` if you just deleted the active one — call `use-context` to pick a new one |

### App lifecycle

| Command | Purpose | Notes |
|---|---|---|
| `vaip --json init -n <project_name> -d "<description>" [-v <version>] [-a <author>] -y` | Scaffold a new app dir | `<project_name>` MUST be snake_case (no digits, spaces, punctuation other than `_`). Pass `-y` to skip the interactive confirmation. |
| `vaip --json validate` | Static checks on a scaffolded project | Run from inside the project dir. `data.checks` array shows each check; `data.failed` is the count of failures. |
| `vaip --json build` | Build the wheel via `python -m build` | Wheel ends up in `dist/`. |
| `vaip --json deploy --file dist/<wheel-name>` | Upload + install a wheel on the VAIP instance | **Always pass `--file` explicitly.** Without it, the CLI picks the lex-last wheel from `dist/` and warns. |
| `vaip --json status` | List installed modules on the current context's instance | Empty store may return code 6 (see "Known backend gotchas" below). |
| `vaip --json destroy -n <project_name> --yes` | Remove an installed module | `--yes` is a REQUIRED flag (the CLI refuses without it; no interactive prompt). |
| `vaip --json publish` | Publish to other users in your group | Stub on most VAIP versions ("This endpoint is under construction"). |

### Skill management

| Command | Purpose |
|---|---|
| `vaip skill install` | Copy this SKILL.md into `~/.claude/skills/vaip/SKILL.md`. Pass `--force` to overwrite, `--dest <path>` to install elsewhere. |

## Workflow: deploy a new app from scratch

```bash
# 1. Make sure a context is set
vaip --json show-context     # check data.current_context

# 2. Confirm backend is reachable
vaip --json status           # exit 0 means good

# 3. Scaffold
vaip --json init -n my_app -d "Description" -y

# 4. Build
cd my_app
vaip --json validate         # all checks passed
vaip --json build            # produces dist/my_app-0.1.0-py3-none-any.whl

# 5. Deploy with explicit --file
vaip --json deploy --file dist/my_app-0.1.0-py3-none-any.whl

# 6. Confirm
vaip --json status           # my_app appears in data.installed_modules
```

## Workflow: update a context's token

```bash
vaip --json edit-context my-instance --token <new-token>
# data.updated_fields == ["token"]
```

## Workflow: tear down

```bash
vaip --json destroy -n my_app --yes
```

## Known backend gotchas

These aren't CLI bugs — they're VAIP backend issues you may hit on older versions.

- **"No organization ID. Please login to your instance." (exit 5)** on a freshly-started backend: the user has never logged into the backend's web UI, so there's no user→org binding in the local database. Direct them to `http://<host>` to log in via browser, then retry. If the error persists even after a successful UI login, the backend is caching the pre-login lookup — tell the user to restart the backend container(s) and retry.
- **Empty store returns 404 instead of empty list (exit 6 from `status`)**: an org with zero installed apps may surface as "VAIP instance does not support the status endpoint. Upgrade to VAIP 1.65+." The CLI message overstates the issue when the org is just empty. Workaround: deploy something first, or treat this specific 404-with-that-message as "no modules installed" if the user confirms the backend is recent.
- **`status` requires VAIP 1.65+** for the endpoint to exist at all. If exit 6 with that exact message AND backend is on a known-old version, the upgrade message is genuinely correct.

## Quoting and shell tips

- Project names: snake_case only. Example: `-n fleet_tracker` works; `-n fleet-tracker` is silently converted to `fleet_tracker` on `destroy` but rejected by `init`.
- Descriptions: free-form, can contain spaces. Always quote: `-d "My fleet tracker app"`.
- The CLI's scaffolded `App(name=...)` uses `--project-name` (snake_case) for the validated app name and `--description` for the human-readable description.

## Common parsing pattern

```python
import json, subprocess
result = subprocess.run(["vaip", "--json", "status"], capture_output=True, text=True)
envelope = json.loads(result.stdout.strip().splitlines()[-1])
if envelope["status"] != "ok":
    handle_error(envelope["message"], result.returncode, envelope.get("data"))
else:
    modules = envelope["data"].get("installed_modules", [])
```

Always parse the *last* JSON-looking line of stdout — some commands may print rich-decorated text BEFORE the envelope if the user combines `--json` with `--verbose`.

## When NOT to use this skill

- The user is asking about VAIP backend internals (worker processes, RBAC, ARQ, etc.) — that's not the CLI's domain.
- The user wants to write Python *inside* a VAIP app's steps — the SDK (virtualitics-sdk) is the relevant docs, not vaip.
- The user wants to mint API tokens — vaip doesn't help with that; tokens come from the accounts portal.
