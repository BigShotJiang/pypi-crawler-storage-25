import ast
import importlib.metadata
import importlib.resources
import json
import string
import subprocess
import sys
import tomllib
from json import JSONDecodeError
from pathlib import Path
from typing import Annotated, Optional
from zipfile import ZipFile

import requests
import typer
from art import *
from rich import print, print_json
from rich.progress import Progress, SpinnerColumn, TextColumn

app = typer.Typer(name="vaip", pretty_exceptions_show_locals=False)
debug_state = {"verbose": False, "json": False}

APP_NAME = "virtualitics-cli"
CONFIG_FILE_NAME = "virtualitics_config.json"
HTTP_NOT_FOUND = 404
INVALID_CONFIG_MSG = ":warning: Your configuration file is invalid or `vaip config` has not been run."
REQUEST_ERRORS = (requests.exceptions.ConnectionError, requests.exceptions.Timeout)

# Granular exit codes so agents can branch on failure type.
EXIT_OK = 0
EXIT_GENERIC = 1
EXIT_CONFIG_ERROR = 2     # missing/unreadable config file or context
EXIT_VALIDATION_ERROR = 3  # bad arguments, validation failure
EXIT_NETWORK_ERROR = 4     # connection refused / timeout reaching backend
EXIT_AUTH_ERROR = 5        # 401/403 from backend
EXIT_NOT_FOUND = 6         # 404 from backend (route missing or resource missing)
EXIT_BACKEND_ERROR = 7     # 5xx from backend, or non-JSON / unexpected payload


def _envelope(*, ok: bool, code: int, message: str, data: Optional[dict] = None) -> dict:
    """Canonical --json output shape for every command.

    {status: "ok"|"error", code: int, message: str, data: <dict or null>}
    Agents can rely on this top-level shape across all commands.
    """
    return {
        "status": "ok" if ok else "error",
        "code": code,
        "message": message,
        "data": data,
    }


def _print_structured(data: dict, ok: bool) -> None:
    icon = "✓" if ok else "✗"
    print(f"{icon} {data['message']}")
    skip = {"status", "message", "details"}
    for key, value in data.items():
        if key in skip or not value:
            continue
        label = key.replace("_", " ").title()
        if isinstance(value, list):
            print(f"  {label}: {', '.join(str(v) for v in value)}")
        else:
            print(f"  {label}: {value}")
    if not ok and data.get("details"):
        for detail in data["details"]:
            print(f"  - {detail.get('msg', detail)}")


HTTP_UNAUTHORIZED = 401
HTTP_FORBIDDEN = 403
HTTP_INTERNAL_ERROR_MIN = 500
HTTP_STATUS_MAX = 600


def _http_status_to_exit_code(status_code: int) -> int:
    if status_code in (HTTP_UNAUTHORIZED, HTTP_FORBIDDEN):
        return EXIT_AUTH_ERROR
    if status_code == HTTP_NOT_FOUND:
        return EXIT_NOT_FOUND
    if HTTP_INTERNAL_ERROR_MIN <= status_code < HTTP_STATUS_MAX:
        return EXIT_BACKEND_ERROR
    return EXIT_GENERIC


def print_response(r: requests.Response, *, success_message: str = "OK") -> None:
    """Render an HTTP response in either JSON or human-readable mode.

    In --json mode emits the canonical envelope with the backend payload nested
    under `data`. The envelope's top-level `code` is the HTTP status code and
    `message` prefers the backend's `message` field if present, otherwise
    `success_message`.
    """
    try:
        backend_data = json.loads(r.text)
    except (JSONDecodeError, TypeError):
        backend_data = None

    if debug_state["json"]:
        if isinstance(backend_data, dict) and "message" in backend_data:
            message = backend_data["message"]
        else:
            message = success_message if r.ok else f"HTTP {r.status_code}"
        emit_json(_envelope(
            ok=r.ok,
            code=r.status_code,
            message=str(message),
            data=backend_data if isinstance(backend_data, dict) else None,
        ))
        return

    if isinstance(backend_data, dict) and "message" in backend_data:
        _print_structured(backend_data, r.ok)
    else:
        try:
            print_json(r.text)
        except JSONDecodeError:
            print(f"Server response ({r.status_code}):\n{r.text[:500]}")


def emit_json(data: dict) -> None:
    sys.stdout.write(json.dumps(data) + "\n")


def emit_ok(message: str, data: Optional[dict] = None, *, code: int = EXIT_OK) -> None:
    """Emit a canonical success envelope in --json mode (no-op otherwise)."""
    if debug_state["json"]:
        emit_json(_envelope(ok=True, code=code, message=message, data=data))


def _error_exit(msg: str, code: int = EXIT_GENERIC, *, data: Optional[dict] = None) -> None:
    if debug_state["json"]:
        emit_json(_envelope(ok=False, code=code, message=msg, data=data))
    else:
        print(f"Error: {msg}")
    raise typer.Exit(code=code)


def get_current_context() -> tuple[str, str, str]:
    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir) / CONFIG_FILE_NAME
    if not config_path.exists():
        _error_exit(
            "No configuration file found. Please run `vaip config` before using this command.",
            code=EXIT_CONFIG_ERROR,
        )

    with config_path.open("r+") as f:
        try:
            current_config = json.load(f)
        except JSONDecodeError as e:
            _error_exit(
                f"{INVALID_CONFIG_MSG}. Config file location: {config_path}. {e}",
                code=EXIT_CONFIG_ERROR,
            )
        try:
            current_context = current_config[current_config["current_context"]]
        except KeyError:
            _error_exit(
                f"current_context '{current_config.get('current_context')}' is not in the config."
                " Run `vaip use-context <name>`.",
                code=EXIT_CONFIG_ERROR,
            )

        return current_context["host"], current_context["token"], current_context["username"]


def app_name_callback(ctx: typer.Context, app_name: str) -> str | None:
    if ctx.resilient_parsing:
        return None
    invalid_characters = set(string.punctuation.replace("_", ""))
    invalid_characters.update(string.digits)  # Add numbers (0-9)
    invalid_characters.update(string.whitespace)  # Add whitespace
    if any(char in invalid_characters for char in app_name):
        raise typer.BadParameter(
            "Invalid project name. The only special character allowed is '_'."
            " Numbers, whitespace, and other special characters are not accepted."
        )
    return app_name


def context_name_callback(config_name: str):
    if config_name.lower() == "default_config_data":
        raise typer.BadParameter("It is not possible to use default_config_data as a config name.")

    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir) / CONFIG_FILE_NAME
    if config_path.exists():
        with config_path.open("r") as f:
            try:
                current_config = json.load(f)
            except JSONDecodeError as e:
                print(INVALID_CONFIG_MSG)
                print(f"Config file location: {config_path}")
                print(e)
                raise typer.Exit(code=1) from None

        if config_name in list(current_config.keys()):
            msg = f"The configuration name '{config_name}' is already present."
            raise typer.BadParameter(msg)

    return config_name


def version_callback(value: bool):
    if value:
        tprint("Virtualitics AI Platform", font="cybermedium")
        print(f"{APP_NAME}: {importlib.metadata.version(APP_NAME)}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool], typer.Option("--version", callback=version_callback)
    ] = False,
    verbose: bool = False,
    json_output: Annotated[
        bool, typer.Option("--json", help="Emit JSON output for programmatic/agent consumption"),
    ] = False,
) -> None:
    """
    Virtualitics AI Platform CLI
    """
    if verbose is True:
        debug_state["verbose"] = True
    if json_output:
        debug_state["json"] = True


def get_yes_no(prompt: str) -> bool:
    while True:
        response = typer.prompt(prompt).strip().lower()
        if response in {"y", "yes"}:
            return True
        if response in {"n", "no"}:
            return False
        typer.echo("Invalid response. Please enter 'y' or 'n'.")


def _resolve_credentials(
    api_token: str | None,
    vaip_username: str | None,
    current_config: dict | None,
    accept_defaults: bool,
) -> tuple[str, str]:
    has_defaults = (
        current_config is not None
        and "default_config_data" in current_config
        and current_config["default_config_data"].get("token")
    )

    if api_token is not None and vaip_username is not None:
        return api_token, vaip_username

    if has_defaults and accept_defaults:
        return (
            api_token or current_config["default_config_data"]["token"],
            vaip_username or current_config["default_config_data"]["username"],
        )

    if has_defaults and not debug_state["json"]:
        default_token = current_config["default_config_data"]["token"]
        default_username = current_config["default_config_data"]["username"]
        print("\nDefault config:")
        print(f"Token: * * * {default_token[-5:]}")
        print(f"Username: {default_username}")
        reuse = get_yes_no("Do you want to use the default settings for Token and Username? [y/n]")
        typer.echo(f"You chose: {'Yes' if reuse else 'No'}")
        if reuse:
            return api_token or default_token, vaip_username or default_username

    if debug_state["json"]:
        _error_exit(
            "Token and username required with --json. "
            "Use --token/-T and --username/-U, or --yes/-y to accept defaults."
        )

    if api_token is None:
        api_token = typer.prompt("token")
    if vaip_username is None:
        vaip_username = typer.prompt("username")
    return api_token, vaip_username


@app.command()
def config(config_name: Annotated[str, typer.Option("--name", "-N",
                                                    help="User-specified friendly name for a given "
                                                         "VAIP instance, i.e. predict-dev",
                                                    callback=context_name_callback,
                                                    prompt=True)],
           backend_host: Annotated[str, typer.Option("--host", "-H",
                                                     help="Backend hostname for a given VAIP instance, "
                                                          "i.e. https://predict-api-dev.virtualitics.com",
                                                     prompt=True)],
           api_token: Annotated[str | None, typer.Option("--token", "-T",
                                                        help="API token used to verify the user's access "
                                                             "to the given VAIP instance")] = None,
           vaip_username: Annotated[str | None, typer.Option("--username", "-U",
                                                              help="Username associated with API token")] = None,
           accept_defaults: Annotated[
               bool, typer.Option("--yes", "-y", help="Accept default token/username without prompting"),
           ] = False):
    """
    Used to create or update a configuration file in the default Typer directory within the CLI app.
    Requires a friendly name of a VAIP instance, host of a VAIP instance, and an API token, and a username.
    """

    config_data = {
        "current_context": config_name,
        config_name: {
            "host": backend_host,
            "token": api_token,
            "username": vaip_username
        },
        "default_config_data": {
            "host": None,
            "token": api_token,
            "username": vaip_username
        }
    }

    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir)
    config_file: Path = Path(app_dir) / CONFIG_FILE_NAME
    if not config_path.exists():
        config_path.mkdir(parents=True, exist_ok=False)
    if not config_file.exists():
        config_file.touch(exist_ok=False)

    with config_file.open("r") as f:
        if config_file.stat().st_size == 0:
            current_config = None
        else:
            try:
                current_config = json.load(f)
            except JSONDecodeError as e:
                print(":warning: Your configuration file is invalid.")
                print(f"Config file location: {config_path}")
                print(e)
                raise typer.Exit(code=1) from None

    api_token, vaip_username = _resolve_credentials(
        api_token, vaip_username, current_config, accept_defaults,
    )

    config_data[config_name]["token"] = api_token
    config_data[config_name]["username"] = vaip_username

    if not current_config:
        config_data["default_config_data"]["token"] = api_token
        config_data["default_config_data"]["username"] = vaip_username
    elif "default_config_data" not in current_config:
        config_data["default_config_data"]["token"] = api_token
        config_data["default_config_data"]["username"] = vaip_username
        current_config[config_name] = config_data[config_name]
        current_config["default_config_data"] = config_data["default_config_data"]
        current_config["current_context"] = config_name
        config_data = current_config
    else:
        current_config[config_name] = config_data[config_name]
        current_config["current_context"] = config_name
        config_data = current_config

    with config_file.open("r+") as f:
        if not debug_state["json"]:
            print_json(json.dumps(config_data))
        json.dump(config_data, f)

    if debug_state["json"]:
        emit_json({"status": "ok", "message": "Configuration updated", "context": config_name})
    else:
        print(f"Configuration file location: {config_file}")
        print("Configuration file updated. Use `vaip show-context` if you wish to see it.")


@app.command()
def use_context(context_name: Annotated[
    str, typer.Argument(help="The name of a previously configured context referenced in the configuration file.")]):
    """
    Used to set the context referenced for uploading in the config file
    """
    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir) / CONFIG_FILE_NAME
    if not config_path.exists():
        _error_exit(
            "Could not successfully switch context. No configuration file found."
            " Please run `vaip config` before using this command.",
            code=EXIT_CONFIG_ERROR,
        )

    with config_path.open("r+") as f:
        try:
            current_config = json.load(f)
        except JSONDecodeError as e:
            _error_exit(
                "Configuration file is invalid or `vaip config` has not been run."
                f" Config file location: {config_path}. {e}",
                code=EXIT_CONFIG_ERROR,
            )
        if context_name not in current_config:
            _error_exit(
                f"Context '{context_name}' does not exist.",
                code=EXIT_NOT_FOUND,
                data={"context": context_name, "available": [k for k in current_config if k != "default_config_data"]},
            )
        current_config["current_context"] = context_name
    with config_path.open("w") as f:
        json.dump(current_config, f)
    if debug_state["json"]:
        emit_ok(f"Now referencing {context_name}", data={"current_context": context_name})
    else:
        print(f"Now referencing [bold]{context_name}[/bold]")


@app.command()
def show_context():
    """
    Used to display the configuration file
    """
    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir) / CONFIG_FILE_NAME
    if not config_path.exists():
        _error_exit(
            "No configuration file found. Please run `vaip config` before using this command.",
            code=EXIT_CONFIG_ERROR,
        )
    with config_path.open("r") as f:
        try:
            current_config = json.load(f)
        except JSONDecodeError as e:
            _error_exit(
                f"{INVALID_CONFIG_MSG}. Config file location: {config_path}. {e}",
                code=EXIT_CONFIG_ERROR,
            )
    if debug_state["json"]:
        emit_json(_envelope(ok=True, code=EXIT_OK, message="Current configuration", data=current_config))
    else:
        print_json(data=current_config)


@app.command()
def delete_context(context_name: Annotated[
    str, typer.Argument(
        help="The name of a previously configured context referenced in the configuration file to delete.")]):
    """
    Used to delete a specific context from the configuration file.
    """
    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir) / CONFIG_FILE_NAME
    if not config_path.exists():
        _error_exit(
            "No configuration file found. Please run `vaip config` before using this command.",
            code=EXIT_CONFIG_ERROR,
        )
    with config_path.open("r+") as f:
        try:
            current_config = json.load(f)
        except JSONDecodeError as e:
            _error_exit(
                f"{INVALID_CONFIG_MSG}. Config file location: {config_path}. {e}",
                code=EXIT_CONFIG_ERROR,
            )
        deleted_context = current_config.pop(context_name, None)
    if not deleted_context:
        _error_exit(
            f"Context '{context_name}' could not be found.",
            code=EXIT_NOT_FOUND,
            data={"context": context_name, "available": [k for k in current_config if k != "default_config_data"]},
        )
    current_context_dangling = current_config.get("current_context") == context_name
    with config_path.open("w") as f:
        json.dump(current_config, f)
    if debug_state["json"]:
        emit_ok(
            f"Context '{context_name}' was deleted",
            data={
                "deleted": context_name,
                "current_context_dangling": current_context_dangling,
                "config": current_config,
            },
        )
    else:
        print(f"Context: [bold]{context_name}[/bold] was deleted. Current configuration file:")
        print_json(data=current_config)
        if current_context_dangling:
            print(
                f":warning: [bold red] current context is set to the deleted context {context_name}."
                " Please run `vaip use-context [context]` [/bold red]."
            )


@app.command()
def edit_context(
    context_name: Annotated[
        str, typer.Argument(
            help="The name of a previously configured context referenced in the configuration file to modify."),
    ],
    new_host: Annotated[
        Optional[str],
        typer.Option("--host", "-H", help="New backend hostname (skip prompt if set)"),
    ] = None,
    new_token: Annotated[
        Optional[str],
        typer.Option("--token", "-T", help="New API token (skip prompt if set)"),
    ] = None,
    new_username: Annotated[
        Optional[str],
        typer.Option("--username", "-U", help="New username (skip prompt if set)"),
    ] = None,
):
    """
    Used to modify a specific context from the configuration file.

    Pass any combination of --host/--token/--username to update those fields
    non-interactively. With no flags, falls back to the legacy interactive
    prompt (one field at a time). In --json mode, at least one flag is
    required.
    """
    app_dir = typer.get_app_dir(APP_NAME)
    config_path: Path = Path(app_dir) / CONFIG_FILE_NAME
    if not config_path.exists():
        _error_exit(
            "No configuration file found. Please run `vaip config` before using this command.",
            code=EXIT_CONFIG_ERROR,
        )
    with config_path.open("r+") as f:
        try:
            current_config = json.load(f)
        except JSONDecodeError as e:
            _error_exit(
                f"{INVALID_CONFIG_MSG}. Config file location: {config_path}. {e}",
                code=EXIT_CONFIG_ERROR,
            )
        modified_context = current_config.pop(context_name, None)
    if not modified_context:
        _error_exit(
            f"Context '{context_name}' could not be found.",
            code=EXIT_NOT_FOUND,
            data={"context": context_name, "available": [k for k in current_config if k != "default_config_data"]},
        )

    updates = {k: v for k, v in (("host", new_host), ("token", new_token), ("username", new_username)) if v is not None}

    if not updates:
        if debug_state["json"]:
            _error_exit(
                "At least one of --host, --token, --username is required in --json mode.",
                code=EXIT_VALIDATION_ERROR,
            )
        print(f"Host: {modified_context['host']}")
        print(f"Token: * * * {modified_context['token'][-5:]}")
        print(f"Username: {modified_context['username']}")
        key = typer.prompt("Which value do you want to modify? [host/token/username]")
        if key not in modified_context:
            _error_exit(f"Invalid choice: {key}. Must be one of host/token/username.",
                        code=EXIT_VALIDATION_ERROR)
        updates[key] = typer.prompt(f"Enter the new value for {key}", type=str)

    modified_context.update(updates)
    current_config[context_name] = modified_context

    with config_path.open("w") as f:
        json.dump(current_config, f)

    if debug_state["json"]:
        emit_ok(
            f"Context '{context_name}' updated",
            data={"context": context_name, "updated_fields": sorted(updates.keys())},
        )
    else:
        print(f"Context [bold]{context_name}[/bold] updated: {', '.join(sorted(updates.keys()))}")
        print("Use `vaip show-context` to see the result.")


@app.command()
def init(
    project_name: Annotated[
        str,
        typer.Option(
            "--project-name", "-n",
            callback=app_name_callback,
            help="Project name (snake_case, no spaces/digits/special chars besides '_')",
            prompt=True,
        ),
    ],
    description: Annotated[
        str,
        typer.Option(
            "--description", "-d",
            help="App description",
            prompt=True,
        ),
    ],
    version: Annotated[
        str,
        typer.Option("--version", "-v", help="App version"),
    ] = "0.1.0",
    authors: Annotated[
        str | None,
        typer.Option("--authors", "-a", help="Author name"),
    ] = None,
    confirm: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
):
    """
    Scaffold a new VAIP app with a working two-step example.

    Generates a project with a CSV upload step and a results step
    showing a data table and chart. Ready to build and deploy immediately.
    """
    project_name = project_name.lower()

    if authors is None:
        try:
            result = subprocess.run(
                ["git", "config", "user.name"],  # noqa: S607
                capture_output=True,
                text=True,
                check=True,
            )
            authors = result.stdout.strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            authors = "Author"

    project_path = Path(project_name)
    if project_path.exists():
        _error_exit(f"Directory '{project_name}' already exists.")

    if not confirm:
        print(f"\n  Project: {project_name}")
        print(f"  Description: {description}")
        print(f"  Version: {version}")
        print(f"  Author: {authors}")
        if not typer.confirm("\nCreate this project?"):
            print("Cancelled.")
            raise typer.Exit(code=0)

    def _escape(value: str) -> str:
        return value.replace("\\", "\\\\").replace('"', '\\"')

    template_vars = {
        "project_name": project_name,
        "description": _escape(description),
        "version": _escape(version),
        "authors": _escape(authors),
    }

    template_dir = importlib.resources.files("virtualitics_cli") / "templates" / "basic_app"

    package_dir = project_path / project_name
    package_dir.mkdir(parents=True)

    template_files = {
        "__init__.py.template": package_dir / "__init__.py",
        "app.py.template": package_dir / "app.py",
        "upload_step.py.template": package_dir / "upload_step.py",
        "results_step.py.template": package_dir / "results_step.py",
        "pyproject.toml.template": project_path / "pyproject.toml",
        "README.md.template": project_path / "README.md",
    }

    for template_name, output_path in template_files.items():
        template_content = (template_dir / template_name).read_text()
        rendered = string.Template(template_content).safe_substitute(template_vars)
        output_path.write_text(rendered)

    if debug_state["json"]:
        emit_json({"status": "ok", "message": f"Created VAIP app '{project_name}'", "path": str(project_path)})
    else:
        print(f"\nCreated VAIP app '{project_name}'")
        print("\nNext steps:")
        print(f"  cd {project_name}")
        print("  vaip build")
        print("  vaip deploy")


def _check_project_structure() -> tuple[list[dict], str | None]:
    checks: list[dict] = []

    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        return [{"name": "pyproject.toml", "passed": False, "detail": "Not found"}], None
    checks.append({"name": "pyproject.toml", "passed": True, "detail": "Found"})

    try:
        with pyproject_path.open("rb") as f:
            pyproject = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        checks.append({"name": "TOML syntax", "passed": False, "detail": str(e)})
        return checks, None
    checks.append({"name": "TOML syntax", "passed": True, "detail": "Valid"})

    project_name = pyproject.get("project", {}).get("name")
    if not project_name:
        checks.append({"name": "Project name", "passed": False, "detail": "Missing [project].name"})
        return checks, None

    project_name = project_name.replace("-", "_")
    checks.append({"name": "Project name", "passed": True, "detail": project_name})

    pkg_dir = Path(project_name)
    if not pkg_dir.is_dir():
        checks.append({"name": "Package directory", "passed": False, "detail": f"{project_name}/ not found"})
        return checks, None
    checks.append({"name": "Package directory", "passed": True, "detail": f"{project_name}/"})

    return checks, project_name


def _run_validation_checks() -> tuple[list[dict], int]:
    checks, project_name = _check_project_structure()
    if project_name is None:
        return checks, 1

    failed = 0
    pkg_dir = Path(project_name)
    app_py = pkg_dir / "app.py"

    if not app_py.exists():
        checks.append({"name": "App module", "passed": False, "detail": f"{project_name}/app.py not found"})
        failed += 1
    else:
        checks.append({"name": "App module", "passed": True, "detail": f"{project_name}/app.py"})

    py_files = list(pkg_dir.glob("**/*.py"))
    compile_errors = []
    for py_file in py_files:
        try:
            ast.parse(py_file.read_text(), filename=str(py_file))
        except SyntaxError as e:
            compile_errors.append(f"{py_file}: {e.msg}")
    if compile_errors:
        checks.append({"name": "Python syntax", "passed": False, "detail": "; ".join(compile_errors)})
        failed += 1
    else:
        checks.append({"name": "Python syntax", "passed": True, "detail": f"{len(py_files)} file(s) OK"})

    if app_py.exists():
        content = app_py.read_text()
        if "App(" not in content and "Flow(" not in content:
            checks.append(
                {"name": "App definition", "passed": False, "detail": "No App() or Flow() found in app.py"},
            )
            failed += 1
        else:
            checks.append({"name": "App definition", "passed": True, "detail": "Found"})

    return checks, failed


@app.command()
def validate():
    """
    Validate a VAIP app project before building.

    Checks pyproject.toml, package structure, Python syntax,
    and App/Flow definition.
    """
    checks, failed = _run_validation_checks()
    if debug_state["json"]:
        emit_json({
            "status": "ok" if failed == 0 else "error",
            "checks": checks,
            "failed": failed,
        })
    else:
        for check in checks:
            icon = "✓" if check["passed"] else "✗"
            line = f"  {icon} {check['name']}"
            if check.get("detail"):
                line += f": {check['detail']}"
            print(line)
        if failed:
            print(f"\n{failed} check(s) failed.")
        else:
            print("\nAll checks passed. Ready to build.")
    if failed:
        raise typer.Exit(code=1)


@app.command()
def build():
    """
    Builds a VAIP App Python wheel file.
    """
    try:
        subprocess.check_call([sys.executable, '-m', 'build'])
    except subprocess.CalledProcessError as e:
        if debug_state["json"]:
            emit_json({"status": "error", "message": str(e)})
        else:
            print(f"There was an error during build: {e}")
            print("Try running `python -m build` if you are having issues.")
        raise typer.Exit(code=1) from None
    if debug_state["json"]:
        emit_json({"status": "ok", "message": "Build complete"})
    else:
        print("Successfully built VAIP App, check your /dist directory.")


def _resolve_wheel(file: str) -> str:
    if not file:
        # Sort so resolution is deterministic when multiple wheels are present
        # (lexicographic order roughly tracks version order for normal naming).
        wheels = sorted(Path("dist").glob("*.whl"))
        if not wheels:
            _error_exit(
                "Unable to locate a suitable wheel file. Try running vaip build, or provide a path with --file.",
                code=EXIT_NOT_FOUND,
            )
        if len(wheels) > 1 and not debug_state["json"]:
            print(f"[yellow]Multiple wheels in dist/; picking {wheels[-1].name}. Pass --file to disambiguate.[/yellow]")
        file = str(wheels[-1])
    if not file.endswith(".whl"):
        _error_exit(f"File {file} does not appear to be a wheel file.", code=EXIT_VALIDATION_ERROR)
    return file


@app.command()
def status():
    """
    Check connection to the configured VAIP instance and show installed modules.
    """
    host, token, username = get_current_context()

    try:
        r = requests.post(
            f"{host}/cli/status/",
            data={"username": username},
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
    except REQUEST_ERRORS as e:
        err_type = "timed out" if isinstance(e, requests.exceptions.Timeout) else "Unable to connect to"
        _error_exit(f"Request {err_type} {host}. Please check your connections and try again.",
                    code=EXIT_NETWORK_ERROR)

    if r.status_code == HTTP_NOT_FOUND:
        _error_exit("VAIP instance does not support the status endpoint. Upgrade to VAIP 1.65+.",
                    code=EXIT_NOT_FOUND)
    if not r.ok:
        print_response(r)
        raise typer.Exit(code=_http_status_to_exit_code(r.status_code))
    if debug_state["json"]:
        print_response(r, success_message="Connected to VAIP")
        return
    try:
        data = json.loads(r.text)
    except (JSONDecodeError, TypeError):
        print_response(r)
        return
    print(f"[green]✓[/green] Connected to {host} as {data.get('username', username)}")
    print(f"  Organization: {data.get('organization_id', '<unknown>')}")
    modules = data.get("installed_modules") or []
    print(f"  Installed modules ({len(modules)}):")
    if not modules:
        print("    [dim](none)[/dim]")
    for m in modules:
        deployer = m.get("deployed_by") or "<unknown>"
        print(f"    - {m.get('module', '<unnamed>')} [dim](deployed by {deployer})[/dim]")


@app.command()
def deploy(file: Annotated[str, typer.Option("--file", "-f",
                                             help="Absolute path to the wheel file "
                                                  "if not in current project /dist")] = ""):
    """
    Deploys the VAIP App to a VAIP Instance
    """
    host, token, username = get_current_context()
    file = _resolve_wheel(file)
    with Path(file).open("rb") as fh:
        files = {"file": fh}
        if debug_state["verbose"]:
            print(f"Attempting to send files: {files}\n")
            names = ZipFile(file).namelist()
            print(f"Unzipped file contents: {names}\n")
        if not debug_state["json"]:
            print(f"Using:\n username {username} \n token: ...{token[-4:]} \n host: {host} \n ")
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True,
                disable=debug_state["json"],
        ) as progress:
            try:
                progress.add_task(description="Uploading...", total=None)
                r = requests.post(
                    f"{host}/cli/deploy/",
                    data={"username": username},
                    headers={"Authorization": f"Bearer {token}"},
                    files=files,
                    timeout=30,
                )
            except requests.exceptions.Timeout:
                _error_exit(f"Request to {host} timed out. The deploy may still be processing.",
                            code=EXIT_NETWORK_ERROR)
            except requests.exceptions.ConnectionError:
                _error_exit(f"Unable to connect to {host}. Please check your connections and try again.",
                            code=EXIT_NETWORK_ERROR)
    if r.status_code == HTTP_NOT_FOUND:
        _error_exit("VAIP instance is not configured for CLI App uploads.",
                    code=EXIT_NOT_FOUND)
    if not r.ok:
        print_response(r)
        raise typer.Exit(code=_http_status_to_exit_code(r.status_code))
    print_response(r, success_message="Wheel deployed")
    raise typer.Exit(code=EXIT_OK)


@app.command()
def destroy(
        project_name: Annotated[
            str, typer.Option("--project-name", "-n",
                              help="Project name to delete (ie, name in pyproject.toml)", prompt=True)],
        confirm_delete: Annotated[
            bool,
            typer.Option(
                "--yes", "-y",
                help="Confirm deletion. Required (will not prompt) so destroy is safe to invoke from agents.",
            ),
        ] = False):
    """
    Deletes a VAIP module, and all the apps of that module.
    """
    project_name = project_name.replace("-", "_")
    if not confirm_delete:
        _error_exit(
            "Refusing to delete without --yes. Pass --yes/-y to confirm.",
            code=EXIT_VALIDATION_ERROR,
        )
    host, token, username = get_current_context()
    with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
            disable=debug_state["json"],
    ) as progress:
        try:
            progress.add_task(description="Deleting...", total=None)
            r = requests.post(
                f"{host}/cli/delete/",
                data={"username": username, "project_name": project_name},
                headers={"Authorization": f"Bearer {token}"},
                timeout=30,
            )
        except REQUEST_ERRORS as e:
            err_type = "timed out" if isinstance(e, requests.exceptions.Timeout) else "Unable to connect to"
            _error_exit(f"Request {err_type} {host}. Please check your connections and try again.",
                        code=EXIT_NETWORK_ERROR)
    if r.status_code == HTTP_NOT_FOUND:
        _error_exit(f"Project '{project_name}' was not found, or VAIP instance is not configured for CLI App uploads.",
                    code=EXIT_NOT_FOUND)
    if not r.ok:
        print_response(r)
        raise typer.Exit(code=_http_status_to_exit_code(r.status_code))
    print_response(r, success_message="Project deleted")
    raise typer.Exit(code=EXIT_OK)


@app.command()
def publish():
    """
    Publishes a VAIP App to other users in your group
    """
    host, token, username = get_current_context()

    try:
        r = requests.post(
            f"{host}/cli/publish/",
            data={"username": username},
            headers={"Authorization": f"Bearer {token}"},
            timeout=30,
        )
    except REQUEST_ERRORS as e:
        err_type = "timed out" if isinstance(e, requests.exceptions.Timeout) else "Unable to connect to"
        _error_exit(f"Request {err_type} {host}. Please check your connections and try again.",
                    code=EXIT_NETWORK_ERROR)

    if not r.ok:
        print_response(r)
        raise typer.Exit(code=_http_status_to_exit_code(r.status_code))
    print_response(r, success_message="Publish request accepted")


# ---------------------------------------------------------------------------
# `vaip skill ...` — manage the bundled Claude Code skill.
# ---------------------------------------------------------------------------

skill_app = typer.Typer(help="Manage the bundled Claude Code skill for vaip.")
app.add_typer(skill_app, name="skill")


def _default_skill_dest() -> Path:
    return Path.home() / ".claude" / "skills" / "vaip" / "SKILL.md"


@skill_app.command("install")
def skill_install(
    dest: Annotated[
        Optional[Path],
        typer.Option(
            "--dest", "-d",
            help="Override install path. Defaults to ~/.claude/skills/vaip/SKILL.md.",
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Overwrite an existing SKILL.md if present."),
    ] = False,
):
    """
    Install the bundled vaip Claude Code skill.

    Copies the SKILL.md that ships with this `vaip` install into the user's
    Claude Code skills directory so the `vaip` skill becomes loadable via
    Claude Code's Skill tool.
    """
    bundled = importlib.resources.files("virtualitics_cli") / "skill" / "SKILL.md"
    if not bundled.is_file():
        _error_exit(
            "Bundled SKILL.md not found in this vaip install. Reinstall vaip.",
            code=EXIT_NOT_FOUND,
            data={"bundled": str(bundled)},
        )

    target = dest if dest is not None else _default_skill_dest()

    if target.exists() and not force:
        _error_exit(
            f"SKILL.md already exists at {target}. Pass --force to overwrite.",
            code=EXIT_VALIDATION_ERROR,
            data={"path": str(target)},
        )

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
    except (OSError, NotADirectoryError) as e:
        _error_exit(
            f"Cannot create parent directory for {target}: {e}",
            code=EXIT_VALIDATION_ERROR,
            data={"path": str(target)},
        )
    target.write_text(bundled.read_text())

    if debug_state["json"]:
        emit_ok(
            f"Installed SKILL.md to {target}",
            data={"path": str(target), "bytes": target.stat().st_size},
        )
    else:
        print(f"[green]✓[/green] Installed Claude skill to [bold]{target}[/bold]")
        print("Open Claude Code and the 'vaip' skill will be available via the Skill tool.")
