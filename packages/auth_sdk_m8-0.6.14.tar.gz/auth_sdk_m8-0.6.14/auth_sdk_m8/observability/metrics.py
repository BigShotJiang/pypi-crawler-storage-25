"""Prometheus metrics registry and setup.

Metric groups (set via METRICS_GROUPS, comma-separated):
  all          — enable every group below
  traffic      — http_requests_total (method, endpoint, status_code)
  performance  — http_request_duration_seconds histogram (method, endpoint)
  reliability  — http_errors_total for 4xx/5xx (method, endpoint, status_class)
  health       — http_status_total by exact status code
  auth         — auth_login_attempts_total, auth_token_refresh_total,
                 auth_logout_total, auth_token_validation_failures_total,
                 auth_oauth_attempts_total, auth_revocation_failure_total,
                 auth_degraded_decision_total,
                 auth_redis_circuit_breaker_open,
                 auth_degradation_mode_active,
                 auth_session_integrity_denial_total,
                 auth_api_key_validations_total, auth_api_key_rate_limit_checks_total,
                 auth_api_key_rate_limit_hits_total, auth_api_key_lifecycle_total,
                 auth_api_key_flush_duration_seconds,
                 auth_code_exchange_total
                 (only meaningful in services that have auth routes)

Requires: pip install auth-sdk-m8[observability]

When METRICS_ENABLED=false (default) this module has zero runtime cost:
get() returns None and the middleware is never registered.
"""

from typing import Optional

from prometheus_client import (
    CONTENT_TYPE_LATEST,
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)

# Prometheus histogram buckets tuned for sub-second Redis/DB flush latency.
_FLUSH_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0)

REGISTRY = CollectorRegistry(auto_describe=False)

GROUP_ALL = "all"
GROUP_TRAFFIC = "traffic"
GROUP_PERFORMANCE = "performance"
GROUP_RELIABILITY = "reliability"
GROUP_HEALTH = "health"
GROUP_AUTH = "auth"

_ALL_GROUPS = frozenset(
    {GROUP_TRAFFIC, GROUP_PERFORMANCE, GROUP_RELIABILITY, GROUP_HEALTH, GROUP_AUTH}
)

_LATENCY_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)


class _Metrics:
    """Container for all metric objects; None means the group is disabled."""

    # traffic
    requests_total: Optional[Counter] = None
    # performance
    request_duration_seconds: Optional[Histogram] = None
    # reliability
    errors_total: Optional[Counter] = None
    # health
    status_total: Optional[Counter] = None
    # auth
    login_attempts_total: Optional[Counter] = None
    token_refresh_total: Optional[Counter] = None
    logout_total: Optional[Counter] = None
    token_validation_failures_total: Optional[Counter] = None
    oauth_attempts_total: Optional[Counter] = None
    revocation_failure_total: Optional[Counter] = None
    degraded_decision_total: Optional[Counter] = None
    redis_circuit_breaker_open: Optional[Gauge] = None
    degradation_mode_active: Optional[Gauge] = None
    session_integrity_denial_total: Optional[Counter] = None
    # OAuth native-app code exchange (part of auth group)
    auth_code_exchange_total: Optional[Counter] = None
    # api keys (part of auth group)
    api_key_validations_total: Optional[Counter] = None
    api_key_rate_limit_checks_total: Optional[Counter] = None
    api_key_rate_limit_hits_total: Optional[Counter] = None
    api_key_lifecycle_total: Optional[Counter] = None
    api_key_flush_duration_seconds: Optional[Histogram] = None


_m: Optional[_Metrics] = None


def _resolve_groups(groups_str: str) -> set[str]:
    raw = {g.strip().lower() for g in groups_str.split(",")}
    if GROUP_ALL in raw:
        return set(_ALL_GROUPS)
    return raw & _ALL_GROUPS


def _norm_prefix(api_prefix: str) -> str:
    """Derive a valid Prometheus metric name prefix from the API prefix."""
    p = api_prefix.strip().lstrip("/").replace("-", "_").replace("/", "_")
    return f"{p}_" if p else ""


def setup(enabled: bool, groups_str: str, api_prefix: str) -> None:
    """Initialize metrics registry. Call once at application startup.

    Args:
        enabled: Master switch — when False nothing is registered.
        groups_str: Comma-separated group names or ``"all"``.
        api_prefix: Service API prefix (e.g. ``"/user"``), used as metric
            name prefix to avoid collisions between services.
    """
    global _m
    if not enabled:
        _m = None
        return

    groups = _resolve_groups(groups_str)
    pfx = _norm_prefix(api_prefix)
    m = _Metrics()

    if GROUP_TRAFFIC in groups:
        m.requests_total = Counter(
            f"{pfx}http_requests_total",
            "Total HTTP requests",
            ["method", "endpoint", "status_code"],
            registry=REGISTRY,
        )

    if GROUP_PERFORMANCE in groups:
        m.request_duration_seconds = Histogram(
            f"{pfx}http_request_duration_seconds",
            "HTTP request latency in seconds",
            ["method", "endpoint"],
            buckets=_LATENCY_BUCKETS,
            registry=REGISTRY,
        )

    if GROUP_RELIABILITY in groups:
        m.errors_total = Counter(
            f"{pfx}http_errors_total",
            "Total 4xx and 5xx HTTP responses",
            ["method", "endpoint", "status_class"],
            registry=REGISTRY,
        )

    if GROUP_HEALTH in groups:
        m.status_total = Counter(
            f"{pfx}http_status_total",
            "HTTP responses by exact status code",
            ["status_code"],
            registry=REGISTRY,
        )

    if GROUP_AUTH in groups:
        m.login_attempts_total = Counter(
            f"{pfx}auth_login_attempts_total",
            "Login attempts (result: success | wrong_credentials | inactive_user | rate_limited)",
            ["result"],
            registry=REGISTRY,
        )
        m.token_refresh_total = Counter(
            f"{pfx}auth_token_refresh_total",
            "Token refresh attempts (result: success | invalid | revoked | rate_limited)",
            ["result"],
            registry=REGISTRY,
        )
        m.logout_total = Counter(
            f"{pfx}auth_logout_total",
            "Logout requests",
            registry=REGISTRY,
        )
        m.token_validation_failures_total = Counter(
            f"{pfx}auth_token_validation_failures_total",
            "Access token validation failures (reason: invalid | revoked | inactive)",
            ["reason"],
            registry=REGISTRY,
        )
        m.oauth_attempts_total = Counter(
            f"{pfx}auth_oauth_attempts_total",
            "OAuth callback attempts (provider: google, result: success | failed)",
            ["provider", "result"],
            registry=REGISTRY,
        )
        m.auth_code_exchange_total = Counter(
            f"{pfx}auth_code_exchange_total",
            "OAuth native-app auth code exchange results "
            "(result: success | expired_or_invalid | pkce_failed | redis_unavailable)",
            ["result"],
            registry=REGISTRY,
        )
        m.revocation_failure_total = Counter(
            f"{pfx}auth_revocation_failure_total",
            "Token revocation failures by operation (operation: access_blacklist | refresh_allowlist | db_session)",
            ["operation"],
            registry=REGISTRY,
        )
        m.degraded_decision_total = Counter(
            f"{pfx}auth_degraded_decision_total",
            "Degraded-mode decisions when a Redis-dependent control is unavailable "
            "(control: rate_limit|refresh_validation|session_write|access_revocation, "
            "mode: fail_open|fail_closed, reason: redis_unavailable|revocation_failed)",
            ["control", "mode", "reason"],
            registry=REGISTRY,
        )
        m.redis_circuit_breaker_open = Gauge(
            f"{pfx}auth_redis_circuit_breaker_open",
            "Redis circuit breaker state: 1 = open (Redis unavailable, requests short-circuited), "
            "0 = closed (Redis healthy)",
            registry=REGISTRY,
        )
        m.degradation_mode_active = Gauge(
            f"{pfx}auth_degradation_mode_active",
            "Configured degradation mode per security control (value 1 for the active mode). "
            "Labels: control (rate_limit|refresh_validation|session_write|access_revocation), "
            "mode (fail_open|fail_closed)",
            ["control", "mode"],
            registry=REGISTRY,
        )
        m.session_integrity_denial_total = Counter(
            f"{pfx}auth_session_integrity_denial_total",
            "Token reuse attacks that triggered full session chain invalidation "
            "(trigger: reuse_detected)",
            ["trigger"],
            registry=REGISTRY,
        )
        m.api_key_validations_total = Counter(
            f"{pfx}auth_api_key_validations_total",
            "API key validation results (result: success | invalid | revoked | expired)",
            ["result"],
            registry=REGISTRY,
        )
        m.api_key_rate_limit_checks_total = Counter(
            f"{pfx}auth_api_key_rate_limit_checks_total",
            "Rate limit enforcement checks (result: allowed | blocked); "
            "invariant: allowed + blocked <= checks_total",
            ["result"],
            registry=REGISTRY,
        )
        m.api_key_rate_limit_hits_total = Counter(
            f"{pfx}auth_api_key_rate_limit_hits_total",
            "Rate limit window exceeded by period (period: minute | hour | day | month)",
            ["period"],
            registry=REGISTRY,
        )
        m.api_key_lifecycle_total = Counter(
            f"{pfx}auth_api_key_lifecycle_total",
            "API key lifecycle events (action: created | revoked)",
            ["action"],
            registry=REGISTRY,
        )
        m.api_key_flush_duration_seconds = Histogram(
            f"{pfx}auth_api_key_flush_duration_seconds",
            "Redis-to-DB last_used_at batch flush latency in seconds",
            buckets=_FLUSH_BUCKETS,
            registry=REGISTRY,
        )

    _m = m


def get() -> Optional[_Metrics]:
    """Return the metrics container, or None when observability is disabled."""
    return _m


def render() -> tuple[bytes, str]:
    """Return Prometheus text exposition and content-type header value."""
    return generate_latest(REGISTRY), CONTENT_TYPE_LATEST
