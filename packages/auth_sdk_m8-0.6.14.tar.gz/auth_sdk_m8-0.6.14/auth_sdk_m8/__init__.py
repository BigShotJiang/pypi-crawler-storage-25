"""auth-sdk-m8 shared authentication utilities for m8 microservices."""

__version__ = "0.6.14"

__all__ = ["__version__"]
