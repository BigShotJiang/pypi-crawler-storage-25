# upvertex-nvidia

Namespace reservation for UpVertex Inc. (www.upvertex.com)