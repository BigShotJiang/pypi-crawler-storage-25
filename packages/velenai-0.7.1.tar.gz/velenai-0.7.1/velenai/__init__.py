"""VelenAI — Agent economics in 2 lines of code.

Usage:
    from velenai import VelenAI

    vai = VelenAI(api_key="...", api_secret="...", host="https://your-instance.com")

    @vai.track("my-agent")
    def run_agent():
        ...

    vai.emit("my-agent", success=True, latency_ms=1200, tokens=150)
"""

from velenai_sdk.client import VelenAI
from velenai_sdk.gpu import GPUProfile, detect_gpus
from velenai_sdk.pricing import estimate_cost, get_price

__version__ = "0.7.0"
__all__ = ["VelenAI", "GPUProfile", "detect_gpus", "estimate_cost", "get_price"]
