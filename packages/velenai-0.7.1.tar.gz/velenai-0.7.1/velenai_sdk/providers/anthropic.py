"""Anthropic provider wrapper — auto-capture telemetry from messages.create().

Intercepts sync and streaming responses. Extracts model, token usage
(including prompt caching), computes cost, and emits telemetry in a
background thread. Zero latency on the critical path.

Usage:
    from anthropic import Anthropic
    from velenai_sdk import VelenAI
    from velenai_sdk.providers import wrap_anthropic

    vai = VelenAI(api_key="...", api_secret="...")
    client = wrap_anthropic(Anthropic(), vai=vai)
    # Use client.messages.create() as normal — telemetry is automatic
"""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING, Any

from ..pricing import cost_per_token, estimate_cost

if TYPE_CHECKING:
    from ..client import VelenAI

logger = logging.getLogger("velenai.providers.anthropic")


def _emit_telemetry(
    vai: VelenAI,
    agent_id: str,
    requested_model: str,
    actual_model: str,
    prompt_tokens: int,
    completion_tokens: int,
    cache_read_tokens: int,
    cache_write_tokens: int,
    latency_ms: int,
    ttft_ms: int | None,
    http_status: int,
    success: bool,
) -> None:
    """Emit telemetry event in a fire-and-forget background thread."""
    try:
        cost = estimate_cost(
            "anthropic",
            actual_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
        )

        per_token = cost_per_token("anthropic", actual_model)
        cpit = per_token[0] if per_token else None
        cpot = per_token[1] if per_token else None

        vai.emit(
            agent_id=agent_id,
            success=success,
            latency_ms=latency_ms,
            tokens=(prompt_tokens + completion_tokens),
            cost_usd=cost,
            provider="anthropic",
            model_name=actual_model,
            requested_model=requested_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            cost_model="cloud-api",
            cost_per_input_token=cpit,
            cost_per_output_token=cpot,
            provider_http_status=http_status,
            time_to_first_token_ms=ttft_ms,
        )
    except Exception as e:
        logger.debug(f"Telemetry emit failed: {e}")


def _extract_usage(response: Any) -> dict:
    """Extract token usage from an Anthropic Message response."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "cache_read_tokens": 0,
            "cache_write_tokens": 0,
        }
    return {
        "prompt_tokens": getattr(usage, "input_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "output_tokens", 0) or 0,
        "cache_read_tokens": getattr(usage, "cache_read_input_tokens", 0) or 0,
        "cache_write_tokens": getattr(usage, "cache_creation_input_tokens", 0) or 0,
    }


class _WrappedMessages:
    """Proxy for client.messages that intercepts create()."""

    def __init__(self, original_messages, vai: VelenAI, agent_id: str):
        self._original = original_messages
        self._vai = vai
        self._agent_id = agent_id

    def __getattr__(self, name: str):
        return getattr(self._original, name)

    def create(self, **kwargs) -> Any:
        requested_model = kwargs.get("model", "unknown")
        stream = kwargs.get("stream", False)

        start = time.monotonic()

        if stream:
            return self._handle_stream(kwargs, requested_model, start)

        # Sync (non-streaming)
        http_status = 200
        success = True
        try:
            response = self._original.create(**kwargs)
        except Exception as e:
            http_status = _extract_http_status(e)
            success = False
            latency_ms = int((time.monotonic() - start) * 1000)
            threading.Thread(
                target=_emit_telemetry,
                args=(
                    self._vai,
                    self._agent_id,
                    requested_model,
                    requested_model,
                    0,
                    0,
                    0,
                    0,
                    latency_ms,
                    None,
                    http_status,
                    success,
                ),
                daemon=True,
            ).start()
            raise

        latency_ms = int((time.monotonic() - start) * 1000)
        actual_model = getattr(response, "model", requested_model)
        usage = _extract_usage(response)

        threading.Thread(
            target=_emit_telemetry,
            args=(
                self._vai,
                self._agent_id,
                requested_model,
                actual_model,
                usage["prompt_tokens"],
                usage["completion_tokens"],
                usage["cache_read_tokens"],
                usage["cache_write_tokens"],
                latency_ms,
                None,
                http_status,
                success,
            ),
            daemon=True,
        ).start()

        return response

    def _handle_stream(self, kwargs, requested_model: str, start: float):
        """Wrap streaming response to capture usage from the final message."""
        stream_obj = self._original.create(**kwargs)

        # Anthropic's stream returns a context manager with MessageStream
        # We need to iterate and capture the final_message
        if hasattr(stream_obj, "__enter__"):
            return _StreamContextWrapper(
                stream_obj, self._vai, self._agent_id, requested_model, start
            )

        # If it's an iterator directly
        return _StreamIterWrapper(
            stream_obj, self._vai, self._agent_id, requested_model, start
        )


class _StreamContextWrapper:
    """Wraps Anthropic's MessageStream context manager."""

    def __init__(self, stream, vai, agent_id, requested_model, start):
        self._stream = stream
        self._vai = vai
        self._agent_id = agent_id
        self._requested_model = requested_model
        self._start = start
        self._ttft_ms = None
        self._first_token = True

    def __enter__(self):
        self._stream.__enter__()
        return self

    def __exit__(self, *args):
        result = self._stream.__exit__(*args)
        # Try to get final message for usage
        try:
            final = getattr(self._stream, "get_final_message", lambda: None)()
            if final:
                self._emit_from_message(final)
        except Exception:
            pass
        return result

    def __iter__(self):
        for event in self._stream:
            if self._first_token:
                self._ttft_ms = int((time.monotonic() - self._start) * 1000)
                self._first_token = False
            yield event

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def _emit_from_message(self, message):
        latency_ms = int((time.monotonic() - self._start) * 1000)
        actual_model = getattr(message, "model", self._requested_model)
        usage = _extract_usage(message)

        threading.Thread(
            target=_emit_telemetry,
            args=(
                self._vai,
                self._agent_id,
                self._requested_model,
                actual_model,
                usage["prompt_tokens"],
                usage["completion_tokens"],
                usage["cache_read_tokens"],
                usage["cache_write_tokens"],
                latency_ms,
                self._ttft_ms,
                200,
                True,
            ),
            daemon=True,
        ).start()


class _StreamIterWrapper:
    """Wraps an Anthropic stream iterator for non-context-manager usage."""

    def __init__(self, stream, vai, agent_id, requested_model, start):
        self._stream = stream
        self._vai = vai
        self._agent_id = agent_id
        self._requested_model = requested_model
        self._start = start
        self._ttft_ms = None
        self._first_token = True
        self._final_message = None

    def __iter__(self):
        for event in self._stream:
            if self._first_token:
                self._ttft_ms = int((time.monotonic() - self._start) * 1000)
                self._first_token = False
            # Capture message_stop events that carry the final message
            if hasattr(event, "type") and event.type == "message":
                self._final_message = event
            yield event

        # After iteration complete, emit telemetry
        if self._final_message:
            latency_ms = int((time.monotonic() - self._start) * 1000)
            actual_model = getattr(self._final_message, "model", self._requested_model)
            usage = _extract_usage(self._final_message)

            threading.Thread(
                target=_emit_telemetry,
                args=(
                    self._vai,
                    self._agent_id,
                    self._requested_model,
                    actual_model,
                    usage["prompt_tokens"],
                    usage["completion_tokens"],
                    usage["cache_read_tokens"],
                    usage["cache_write_tokens"],
                    latency_ms,
                    self._ttft_ms,
                    200,
                    True,
                ),
                daemon=True,
            ).start()

    def __getattr__(self, name):
        return getattr(self._stream, name)


def _extract_http_status(exc: Exception) -> int:
    """Try to extract HTTP status code from an Anthropic API error."""
    status = getattr(exc, "status_code", None)
    if status:
        return int(status)
    # anthropic.APIStatusError has .status_code
    response = getattr(exc, "response", None)
    if response:
        return getattr(response, "status_code", 500)
    return 500


class _WrappedClient:
    """Proxy for the Anthropic client that swaps in wrapped messages."""

    def __init__(self, client, vai: VelenAI, agent_id: str):
        self._client = client
        self.messages = _WrappedMessages(client.messages, vai, agent_id)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


def wrap_anthropic(client, vai: VelenAI, agent_id: str = "anthropic"):
    """Wrap an Anthropic client to auto-capture telemetry.

    Args:
        client: An anthropic.Anthropic instance.
        vai: VelenAI SDK instance for telemetry delivery.
        agent_id: Agent ID for telemetry events (default: "anthropic").

    Returns:
        A wrapped client that behaves identically but emits telemetry.
    """
    return _WrappedClient(client, vai, agent_id)
