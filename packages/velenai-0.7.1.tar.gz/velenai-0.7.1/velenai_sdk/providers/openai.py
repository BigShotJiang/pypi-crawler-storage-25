"""OpenAI provider wrapper — auto-capture telemetry from chat.completions.create().

Intercepts sync and streaming responses. Extracts model, token usage,
computes cost, and emits telemetry in a background thread.

Usage:
    from openai import OpenAI
    from velenai_sdk import VelenAI
    from velenai_sdk.providers import wrap_openai

    vai = VelenAI(api_key="...", api_secret="...")
    client = wrap_openai(OpenAI(), vai=vai)
    # Use client.chat.completions.create() as normal
"""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING, Any

from ..pricing import cost_per_token, estimate_cost

if TYPE_CHECKING:
    from ..client import VelenAI

logger = logging.getLogger("velenai.providers.openai")


def _emit_telemetry(
    vai: VelenAI,
    agent_id: str,
    requested_model: str,
    actual_model: str,
    prompt_tokens: int,
    completion_tokens: int,
    latency_ms: int,
    ttft_ms: int | None,
    http_status: int,
    success: bool,
) -> None:
    """Emit telemetry event — called in a background thread."""
    try:
        cost = estimate_cost(
            "openai",
            actual_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )

        per_token = cost_per_token("openai", actual_model)
        cpit = per_token[0] if per_token else None
        cpot = per_token[1] if per_token else None

        vai.emit(
            agent_id=agent_id,
            success=success,
            latency_ms=latency_ms,
            tokens=(prompt_tokens + completion_tokens),
            cost_usd=cost,
            provider="openai",
            model_name=actual_model,
            requested_model=requested_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cost_model="cloud-api",
            cost_per_input_token=cpit,
            cost_per_output_token=cpot,
            provider_http_status=http_status,
            time_to_first_token_ms=ttft_ms,
        )
    except Exception as e:
        logger.debug(f"Telemetry emit failed: {e}")


def _extract_usage(response: Any) -> dict:
    """Extract token usage from an OpenAI ChatCompletion response."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return {"prompt_tokens": 0, "completion_tokens": 0}
    return {
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
    }


class _WrappedCompletions:
    """Proxy for client.chat.completions that intercepts create()."""

    def __init__(self, original_completions, vai: VelenAI, agent_id: str):
        self._original = original_completions
        self._vai = vai
        self._agent_id = agent_id

    def __getattr__(self, name: str):
        return getattr(self._original, name)

    def create(self, **kwargs) -> Any:
        requested_model = kwargs.get("model", "unknown")
        stream = kwargs.get("stream", False)

        start = time.monotonic()

        if stream:
            return self._handle_stream(kwargs, requested_model, start)

        # Sync (non-streaming)
        http_status = 200
        success = True
        try:
            response = self._original.create(**kwargs)
        except Exception as e:
            http_status = _extract_http_status(e)
            success = False
            latency_ms = int((time.monotonic() - start) * 1000)
            threading.Thread(
                target=_emit_telemetry,
                args=(
                    self._vai,
                    self._agent_id,
                    requested_model,
                    requested_model,
                    0,
                    0,
                    latency_ms,
                    None,
                    http_status,
                    success,
                ),
                daemon=True,
            ).start()
            raise

        latency_ms = int((time.monotonic() - start) * 1000)
        actual_model = getattr(response, "model", requested_model)
        usage = _extract_usage(response)

        threading.Thread(
            target=_emit_telemetry,
            args=(
                self._vai,
                self._agent_id,
                requested_model,
                actual_model,
                usage["prompt_tokens"],
                usage["completion_tokens"],
                latency_ms,
                None,
                http_status,
                success,
            ),
            daemon=True,
        ).start()

        return response

    def _handle_stream(self, kwargs, requested_model: str, start: float):
        """Wrap streaming response to capture usage from stream chunks."""
        return _StreamWrapper(
            self._original.create(**kwargs),
            self._vai,
            self._agent_id,
            requested_model,
            start,
        )


class _StreamWrapper:
    """Wraps an OpenAI streaming response to capture usage."""

    def __init__(self, stream, vai, agent_id, requested_model, start):
        self._stream = stream
        self._vai = vai
        self._agent_id = agent_id
        self._requested_model = requested_model
        self._start = start
        self._ttft_ms = None
        self._first_token = True
        self._actual_model = requested_model
        self._prompt_tokens = 0
        self._completion_tokens = 0

    def __iter__(self):
        for chunk in self._stream:
            if self._first_token:
                self._ttft_ms = int((time.monotonic() - self._start) * 1000)
                self._first_token = False

            # Capture model from first chunk
            model = getattr(chunk, "model", None)
            if model:
                self._actual_model = model

            # OpenAI includes usage in the final chunk when stream_options
            # includes include_usage=True
            usage = getattr(chunk, "usage", None)
            if usage:
                self._prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
                self._completion_tokens = getattr(usage, "completion_tokens", 0) or 0

            yield chunk

        # After stream complete, emit telemetry
        latency_ms = int((time.monotonic() - self._start) * 1000)
        threading.Thread(
            target=_emit_telemetry,
            args=(
                self._vai,
                self._agent_id,
                self._requested_model,
                self._actual_model,
                self._prompt_tokens,
                self._completion_tokens,
                latency_ms,
                self._ttft_ms,
                200,
                True,
            ),
            daemon=True,
        ).start()

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return False

    def __getattr__(self, name):
        return getattr(self._stream, name)


def _extract_http_status(exc: Exception) -> int:
    """Try to extract HTTP status code from an OpenAI API error."""
    status = getattr(exc, "status_code", None)
    if status:
        return int(status)
    response = getattr(exc, "response", None)
    if response:
        return getattr(response, "status_code", 500)
    return 500


class _WrappedChat:
    """Proxy for client.chat with wrapped completions."""

    def __init__(self, original_chat, vai: VelenAI, agent_id: str):
        self._original = original_chat
        self.completions = _WrappedCompletions(original_chat.completions, vai, agent_id)

    def __getattr__(self, name: str):
        return getattr(self._original, name)


class _WrappedClient:
    """Proxy for the OpenAI client that swaps in wrapped chat.completions."""

    def __init__(self, client, vai: VelenAI, agent_id: str):
        self._client = client
        self.chat = _WrappedChat(client.chat, vai, agent_id)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


def wrap_openai(client, vai: VelenAI, agent_id: str = "openai"):
    """Wrap an OpenAI client to auto-capture telemetry.

    Args:
        client: An openai.OpenAI instance.
        vai: VelenAI SDK instance for telemetry delivery.
        agent_id: Agent ID for telemetry events (default: "openai").

    Returns:
        A wrapped client that behaves identically but emits telemetry.
    """
    return _WrappedClient(client, vai, agent_id)
