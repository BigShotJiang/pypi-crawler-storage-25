"""VelenAI provider wrappers — auto-capture telemetry from LLM calls.

Usage:
    # Cloud providers
    from velenai_sdk.providers import wrap_anthropic, wrap_openai

    # Local inference (llama.cpp, Ollama, vLLM, LMStudio)
    from velenai_sdk.providers import local_client, wrap_local
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import VelenAI


def wrap_anthropic(client, vai: VelenAI, agent_id: str = "anthropic"):
    """Wrap an Anthropic client to auto-emit telemetry."""
    from .anthropic import wrap_anthropic as _wrap

    return _wrap(client, vai, agent_id)


def wrap_openai(client, vai: VelenAI, agent_id: str = "openai"):
    """Wrap an OpenAI client to auto-emit telemetry."""
    from .openai import wrap_openai as _wrap

    return _wrap(client, vai, agent_id)


def wrap_local(client, vai: VelenAI, agent_id: str = "local"):
    """Wrap an OpenAI-compatible client pointed at a local server."""
    from .local import wrap_local as _wrap

    return _wrap(client, vai, agent_id)


def local_client(
    base_url: str,
    velenai_key: str | None = None,
    velenai_secret: str | None = None,
    velenai_host: str | None = None,
    agent_id: str = "local",
    electricity_rate_kwh: float | None = None,
    gpu_lifespan_years: float | None = None,
    api_key: str = "not-needed",
):
    """Create a ready-to-use client for a local inference server.

    One-liner that creates an OpenAI-compatible client, initializes VelenAI
    with auto GPU detection, and wires up telemetry capture.

    Works with llama.cpp, Ollama, vLLM, LMStudio, LocalAI — any server
    that speaks the OpenAI chat completions API.

    Example:
        from velenai_sdk.providers import local_client

        client = local_client("http://localhost:8081/v1", velenai_key="vai_xxx", velenai_secret="vas_xxx")
        response = client.chat.completions.create(
            model="qwen3.5-9b",
            messages=[{"role": "user", "content": "Hello"}]
        )
    """
    from .local import local_client as _local_client

    return _local_client(
        base_url,
        velenai_key=velenai_key,
        velenai_secret=velenai_secret,
        velenai_host=velenai_host,
        agent_id=agent_id,
        electricity_rate_kwh=electricity_rate_kwh,
        gpu_lifespan_years=gpu_lifespan_years,
        api_key=api_key,
    )
