"""Local inference server wrapper — auto-capture telemetry from any OpenAI-compatible server.

Works with llama.cpp, Ollama, vLLM, LMStudio, LocalAI, and any server
that speaks the OpenAI chat completions API.

Automatically:
- Detects GPU hardware and registers cost profile
- Captures token usage, latency, TTFT from responses
- Computes cost from GPU utilization (electricity + depreciation)
- Tags events with provider="self-hosted" and cost_model="gpu-time"
- Cleans up model names (strips paths and quant suffixes for display)

Usage:
    from velenai_sdk.providers import local_client

    # Minimal — one line
    client = local_client("http://localhost:8081/v1", velenai_key="vai_xxx", velenai_secret="vas_xxx")

    # Use exactly like OpenAI
    response = client.chat.completions.create(
        model="qwen3.5-9b",
        messages=[{"role": "user", "content": "Hello"}]
    )

    # Custom agent ID + GPU cost overrides
    client = local_client(
        "http://localhost:8081/v1",
        velenai_key="vai_xxx",
        velenai_secret="vas_xxx",
        agent_id="research.analyst",
        electricity_rate_kwh=0.12,
    )
"""

from __future__ import annotations

import logging
import re
import threading
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import VelenAI

logger = logging.getLogger("velenai.providers.local")


def _clean_model_name(raw: str) -> str:
    """Clean local model names for dashboard display.

    llama.cpp returns paths like '/models/gguf/qwen3.5-9b-q4_k_m.gguf'
    Ollama returns 'qwen3:9b-q4_K_M'
    vLLM returns the HuggingFace model ID

    This strips paths, extensions, and common prefixes to get a readable name.
    """
    name = raw
    # Strip file path (take last component)
    if "/" in name:
        name = name.rsplit("/", 1)[-1]
    if "\\" in name:
        name = name.rsplit("\\", 1)[-1]
    # Strip .gguf extension
    name = re.sub(r"\.gguf$", "", name, flags=re.IGNORECASE)
    return name.strip() or raw


def _estimate_gpu_cost(
    vai: VelenAI,
    latency_ms: int,
) -> float | None:
    """Estimate cost from GPU time using detected hardware profile."""
    if not vai.gpu_profile or not vai.gpu_profile.gpus:
        return None
    hourly_cost = vai.gpu_profile.total_hourly_cost
    if hourly_cost <= 0:
        return None
    hours = latency_ms / 3_600_000
    return round(hourly_cost * hours, 8)


def _emit_telemetry(
    vai: VelenAI,
    agent_id: str,
    requested_model: str,
    actual_model: str,
    prompt_tokens: int,
    completion_tokens: int,
    latency_ms: int,
    ttft_ms: int | None,
    http_status: int,
    success: bool,
) -> None:
    """Emit telemetry event in background thread."""
    try:
        cost = _estimate_gpu_cost(vai, latency_ms)
        clean_model = _clean_model_name(actual_model)
        clean_requested = _clean_model_name(requested_model)

        vai.emit(
            agent_id=agent_id,
            success=success,
            latency_ms=latency_ms,
            tokens=(prompt_tokens + completion_tokens),
            cost_usd=cost,
            provider="self-hosted",
            model_name=clean_model,
            requested_model=clean_requested,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cost_model="gpu-time",
            provider_http_status=http_status,
            time_to_first_token_ms=ttft_ms,
        )
    except Exception as e:
        logger.debug(f"Local telemetry emit failed: {e}")


def _extract_usage(response: Any) -> dict:
    """Extract token usage from an OpenAI-compatible response."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return {"prompt_tokens": 0, "completion_tokens": 0}
    return {
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
    }


def _extract_http_status(exc: Exception) -> int:
    """Try to extract HTTP status code from an API error."""
    status = getattr(exc, "status_code", None)
    if status:
        return int(status)
    response = getattr(exc, "response", None)
    if response:
        return getattr(response, "status_code", 500)
    return 500


class _WrappedCompletions:
    """Proxy for client.chat.completions that intercepts create()."""

    def __init__(self, original_completions, vai: VelenAI, agent_id: str):
        self._original = original_completions
        self._vai = vai
        self._agent_id = agent_id

    def __getattr__(self, name: str):
        return getattr(self._original, name)

    def create(self, **kwargs) -> Any:
        requested_model = kwargs.get("model", "unknown")
        stream = kwargs.get("stream", False)

        start = time.monotonic()

        if stream:
            return self._handle_stream(kwargs, requested_model, start)

        # Sync (non-streaming)
        http_status = 200
        success = True
        try:
            response = self._original.create(**kwargs)
        except Exception as e:
            http_status = _extract_http_status(e)
            success = False
            latency_ms = int((time.monotonic() - start) * 1000)
            threading.Thread(
                target=_emit_telemetry,
                args=(
                    self._vai,
                    self._agent_id,
                    requested_model,
                    requested_model,
                    0,
                    0,
                    latency_ms,
                    None,
                    http_status,
                    success,
                ),
                daemon=True,
            ).start()
            raise

        latency_ms = int((time.monotonic() - start) * 1000)
        actual_model = getattr(response, "model", requested_model)
        usage = _extract_usage(response)

        threading.Thread(
            target=_emit_telemetry,
            args=(
                self._vai,
                self._agent_id,
                requested_model,
                actual_model,
                usage["prompt_tokens"],
                usage["completion_tokens"],
                latency_ms,
                None,
                http_status,
                success,
            ),
            daemon=True,
        ).start()

        return response

    def _handle_stream(self, kwargs, requested_model: str, start: float):
        """Wrap streaming response to capture usage from final chunk."""
        return _StreamWrapper(
            self._original.create(**kwargs),
            self._vai,
            self._agent_id,
            requested_model,
            start,
        )


class _StreamWrapper:
    """Wraps a streaming response to capture usage and TTFT."""

    def __init__(self, stream, vai, agent_id, requested_model, start):
        self._stream = stream
        self._vai = vai
        self._agent_id = agent_id
        self._requested_model = requested_model
        self._start = start
        self._ttft_ms = None
        self._first_token = True
        self._actual_model = requested_model
        self._prompt_tokens = 0
        self._completion_tokens = 0

    def __iter__(self):
        for chunk in self._stream:
            if self._first_token:
                self._ttft_ms = int((time.monotonic() - self._start) * 1000)
                self._first_token = False

            model = getattr(chunk, "model", None)
            if model:
                self._actual_model = model

            usage = getattr(chunk, "usage", None)
            if usage:
                self._prompt_tokens = getattr(usage, "prompt_tokens", 0) or 0
                self._completion_tokens = getattr(usage, "completion_tokens", 0) or 0

            yield chunk

        latency_ms = int((time.monotonic() - self._start) * 1000)
        threading.Thread(
            target=_emit_telemetry,
            args=(
                self._vai,
                self._agent_id,
                self._requested_model,
                self._actual_model,
                self._prompt_tokens,
                self._completion_tokens,
                latency_ms,
                self._ttft_ms,
                200,
                True,
            ),
            daemon=True,
        ).start()

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args):
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
        return False

    def __getattr__(self, name):
        return getattr(self._stream, name)


class _WrappedChat:
    """Proxy for client.chat with wrapped completions."""

    def __init__(self, original_chat, vai: VelenAI, agent_id: str):
        self._original = original_chat
        self.completions = _WrappedCompletions(original_chat.completions, vai, agent_id)

    def __getattr__(self, name: str):
        return getattr(self._original, name)


class _WrappedLocalClient:
    """Proxy for the OpenAI client configured for local inference."""

    def __init__(self, client, vai: VelenAI, agent_id: str):
        self._client = client
        self._vai = vai
        self.chat = _WrappedChat(client.chat, vai, agent_id)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


def wrap_local(client, vai: VelenAI, agent_id: str = "local"):
    """Wrap an OpenAI-compatible client pointing at a local inference server.

    Args:
        client: An openai.OpenAI instance with base_url set to your local server.
        vai: VelenAI SDK instance for telemetry delivery.
        agent_id: Agent ID for telemetry events.

    Returns:
        A wrapped client that behaves identically but emits self-hosted telemetry.
    """
    return _WrappedLocalClient(client, vai, agent_id)


def local_client(
    base_url: str,
    velenai_key: str | None = None,
    velenai_secret: str | None = None,
    velenai_host: str | None = None,
    agent_id: str = "local",
    electricity_rate_kwh: float | None = None,
    gpu_lifespan_years: float | None = None,
    api_key: str = "not-needed",
):
    """Create a ready-to-use client for a local inference server.

    One-liner that handles everything: OpenAI client creation, VelenAI SDK
    initialization, GPU detection, and telemetry wiring.

    Args:
        base_url: Local server URL (e.g. "http://localhost:8081/v1")
        velenai_key: VelenAI API key (or VELENAI_API_KEY env var)
        velenai_secret: VelenAI API secret (or VELENAI_API_SECRET env var)
        velenai_host: VelenAI server URL (or VELENAI_HOST env var)
        agent_id: Agent ID for telemetry events (default: "local")
        electricity_rate_kwh: Override electricity cost for GPU cost model
        gpu_lifespan_years: Override GPU lifespan for depreciation calc
        api_key: API key for the local server (default: "not-needed")

    Returns:
        A wrapped OpenAI-compatible client with auto-telemetry.

    Example:
        from velenai_sdk.providers import local_client

        client = local_client("http://localhost:8081/v1", velenai_key="vai_xxx", velenai_secret="vas_xxx")
        response = client.chat.completions.create(
            model="qwen3.5-9b",
            messages=[{"role": "user", "content": "Hello"}]
        )
    """
    from openai import OpenAI

    from ..client import VelenAI

    # Ensure base_url ends with /v1 for OpenAI compatibility
    url = base_url.rstrip("/")
    if not url.endswith("/v1"):
        url = f"{url}/v1"

    # Create OpenAI client pointed at local server
    openai_client = OpenAI(base_url=url, api_key=api_key)

    # Create VelenAI SDK instance with GPU detection
    vai = VelenAI(
        api_key=velenai_key,
        api_secret=velenai_secret,
        host=velenai_host,
        detect_gpu=True,
        electricity_rate_kwh=electricity_rate_kwh,
        gpu_lifespan_years=gpu_lifespan_years,
    )

    return _WrappedLocalClient(openai_client, vai, agent_id)
