"""VelenAI SDK — Agent economics in 2 lines of code.

Usage:
    from velenai_sdk import VelenAI

    vai = VelenAI(api_key="...", api_secret="...", host="https://your-instance.com")

    # Option 1: Decorator
    @vai.track("my-agent")
    def run_agent():
        ...
        return result

    # Option 2: Context manager
    with vai.trace("my-agent") as t:
        result = do_work()
        t.success = True
        t.tokens = 150

    # Option 3: Manual
    vai.emit("my-agent", success=True, latency_ms=1200, tokens=150)
"""

from velenai_sdk.client import VelenAI
from velenai_sdk.gpu import GPUProfile, detect_gpus

__version__ = "0.7.0"
__all__ = ["VelenAI", "GPUProfile", "detect_gpus"]
