"""GPU auto-detection for VelenAI cost modeling.

Detects NVIDIA GPUs via pynvml (optional dependency), falls back to
manual configuration. Sends GPU profile to VelenAI platform on first
connection so the server can compute accurate utilization-aware costs.

No hard dependency on pynvml — detection gracefully degrades to
"unknown" if the library or GPU drivers aren't available.
"""

from __future__ import annotations

import logging
import os
from dataclasses import asdict, dataclass, field

logger = logging.getLogger("velenai")

# Common inference GPUs: name → (TDP watts, typical street price USD)
# Used as fallback when NVML can't report power limit or user hasn't
# configured a price. Prices are rough 2025-2026 street averages.
GPU_CATALOG: dict[str, tuple[int, int]] = {
    # NVIDIA Consumer
    "NVIDIA GeForce RTX 5090": (575, 1999),
    "NVIDIA GeForce RTX 5080": (360, 999),
    "NVIDIA GeForce RTX 5070 Ti": (300, 749),
    "NVIDIA GeForce RTX 5070": (250, 549),
    "NVIDIA GeForce RTX 4090": (450, 1599),
    "NVIDIA GeForce RTX 4080 SUPER": (320, 999),
    "NVIDIA GeForce RTX 4080": (320, 1199),
    "NVIDIA GeForce RTX 4070 Ti SUPER": (285, 799),
    "NVIDIA GeForce RTX 4070 Ti": (285, 799),
    "NVIDIA GeForce RTX 4070 SUPER": (220, 599),
    "NVIDIA GeForce RTX 4070": (200, 549),
    "NVIDIA GeForce RTX 4060 Ti": (160, 399),
    "NVIDIA GeForce RTX 4060": (115, 299),
    "NVIDIA GeForce RTX 3090 Ti": (450, 1099),
    "NVIDIA GeForce RTX 3090": (350, 899),
    "NVIDIA GeForce RTX 3080 Ti": (350, 699),
    "NVIDIA GeForce RTX 3080": (320, 499),
    "NVIDIA GeForce RTX 3070 Ti": (290, 399),
    "NVIDIA GeForce RTX 3070": (220, 349),
    "NVIDIA GeForce RTX 3060": (170, 249),
    # NVIDIA Pro / Workstation
    "NVIDIA RTX PRO 6000 Blackwell": (300, 6800),
    "NVIDIA RTX 6000 Ada Generation": (300, 6800),
    "NVIDIA RTX 5000 Ada Generation": (250, 4000),
    "NVIDIA RTX 4000 Ada Generation": (130, 1250),
    "NVIDIA RTX A6000": (300, 4650),
    "NVIDIA RTX A5000": (230, 2250),
    "NVIDIA RTX A4000": (140, 1000),
    # NVIDIA Data Center
    "NVIDIA H100 80GB HBM3": (700, 30000),
    "NVIDIA H100 PCIe": (350, 25000),
    "NVIDIA A100-SXM4-80GB": (400, 15000),
    "NVIDIA A100-PCIE-40GB": (250, 10000),
    "NVIDIA A100-SXM4-40GB": (400, 10000),
    "NVIDIA L40S": (350, 7500),
    "NVIDIA L40": (300, 7000),
    "NVIDIA L4": (72, 2700),
    "NVIDIA A10": (150, 3500),
    "NVIDIA T4": (70, 2200),
    # AMD
    "AMD Instinct MI300X": (750, 15000),
    "AMD Instinct MI250X": (500, 10000),
    "AMD Radeon RX 7900 XTX": (355, 899),
    "AMD Radeon RX 7900 XT": (315, 749),
    "AMD Radeon RX 7800 XT": (263, 449),
    "AMD Radeon RX 7700 XT": (245, 399),
}


@dataclass
class GPUInfo:
    """Detected GPU hardware profile."""

    name: str = "unknown"
    vendor: str = "unknown"  # nvidia, amd, none
    vram_mb: int = 0
    tdp_watts: int = 0  # From NVML power limit or catalog
    gpu_count: int = 0
    driver_version: str = ""
    # User-configurable (not auto-detected)
    purchase_price_usd: float = 0.0
    electricity_rate_kwh: float = 0.0
    lifespan_years: float = 0.0

    @property
    def hourly_cost(self) -> float:
        """Compute all-in hourly cost from detected/configured values.

        Components:
          - Power: (tdp_watts / 1000) × electricity_rate_per_kwh
          - Depreciation: purchase_price / (lifespan_years × 8760 hours)

        Returns 0.0 if insufficient data to compute.
        """
        power_cost = 0.0
        depreciation = 0.0

        if self.tdp_watts and self.electricity_rate_kwh:
            power_cost = (self.tdp_watts / 1000) * self.electricity_rate_kwh

        if self.purchase_price_usd and self.lifespan_years:
            hours = self.lifespan_years * 8760
            depreciation = self.purchase_price_usd / hours

        return round(power_cost + depreciation, 4)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["hourly_cost"] = self.hourly_cost
        return d


@dataclass
class GPUProfile:
    """Complete GPU profile for an installation (may have multiple GPUs)."""

    gpus: list[GPUInfo] = field(default_factory=list)
    detection_method: str = "none"  # nvml, rocm, manual, none
    electricity_rate_kwh: float = 0.16  # Default US average
    default_lifespan_years: float = 3.0

    @property
    def primary_gpu(self) -> GPUInfo | None:
        return self.gpus[0] if self.gpus else None

    @property
    def total_hourly_cost(self) -> float:
        return sum(g.hourly_cost for g in self.gpus)

    def to_dict(self) -> dict:
        return {
            "gpus": [g.to_dict() for g in self.gpus],
            "detection_method": self.detection_method,
            "electricity_rate_kwh": self.electricity_rate_kwh,
            "default_lifespan_years": self.default_lifespan_years,
            "total_hourly_cost": self.total_hourly_cost,
            "gpu_count": len(self.gpus),
        }


def _lookup_catalog(name: str) -> tuple[int, int] | None:
    """Look up GPU in catalog by name. Tries exact match, then substring."""
    if name in GPU_CATALOG:
        return GPU_CATALOG[name]
    # Fuzzy: check if any catalog key is contained in the detected name
    name_lower = name.lower()
    for catalog_name, specs in GPU_CATALOG.items():
        if catalog_name.lower() in name_lower or name_lower in catalog_name.lower():
            return specs
    return None


def _detect_nvidia() -> list[GPUInfo]:
    """Detect NVIDIA GPUs via pynvml. Returns empty list if unavailable."""
    try:
        import pynvml

        pynvml.nvmlInit()
    except Exception:
        return []

    gpus = []
    try:
        count = pynvml.nvmlDeviceGetCount()
        driver = pynvml.nvmlSystemGetDriverVersion()
        if isinstance(driver, bytes):
            driver = driver.decode()

        for i in range(count):
            handle = pynvml.nvmlDeviceGetHandleByIndex(i)
            name = pynvml.nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode()

            mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            vram_mb = mem_info.total // (1024 * 1024)

            # Power limit in milliwatts → watts
            try:
                tdp_watts = pynvml.nvmlDeviceGetPowerManagementLimit(handle) // 1000
            except pynvml.NVMLError:
                tdp_watts = 0

            # Fall back to catalog if NVML didn't report power
            catalog = _lookup_catalog(name)
            if not tdp_watts and catalog:
                tdp_watts = catalog[0]

            price = catalog[1] if catalog else 0.0

            gpus.append(
                GPUInfo(
                    name=name,
                    vendor="nvidia",
                    vram_mb=vram_mb,
                    tdp_watts=tdp_watts,
                    gpu_count=1,
                    driver_version=driver,
                    purchase_price_usd=price,
                )
            )
    except Exception as e:
        logger.debug(f"NVML detection error: {e}")
    finally:
        try:
            pynvml.nvmlShutdown()
        except Exception:
            pass

    return gpus


def _detect_amd() -> list[GPUInfo]:
    """Detect AMD GPUs via rocm-smi. Returns empty list if unavailable."""
    try:
        import subprocess

        result = subprocess.run(
            ["rocm-smi", "--showproductname", "--showmeminfo", "vram", "--csv"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return []
    except Exception:
        return []

    # Parse rocm-smi CSV output
    gpus = []
    try:
        lines = result.stdout.strip().split("\n")
        # rocm-smi CSV is quirky — extract what we can
        for line in lines[1:]:  # Skip header
            parts = line.split(",")
            if len(parts) >= 2:
                name = parts[1].strip() if len(parts) > 1 else "AMD GPU"
                catalog = _lookup_catalog(name)
                gpus.append(
                    GPUInfo(
                        name=name,
                        vendor="amd",
                        tdp_watts=catalog[0] if catalog else 0,
                        gpu_count=1,
                        purchase_price_usd=catalog[1] if catalog else 0.0,
                    )
                )
    except Exception as e:
        logger.debug(f"ROCm detection error: {e}")

    return gpus


def detect_gpus(
    electricity_rate_kwh: float | None = None,
    lifespan_years: float | None = None,
) -> GPUProfile:
    """Auto-detect all available GPUs and build a cost profile.

    Args:
        electricity_rate_kwh: Override electricity cost (default: $0.16/kWh US avg).
            Can also be set via VELENAI_ELECTRICITY_RATE env var.
        lifespan_years: Override expected GPU lifespan (default: 3 years).
            Can also be set via VELENAI_GPU_LIFESPAN_YEARS env var.

    Returns:
        GPUProfile with detected hardware and computed hourly costs.
    """
    rate = electricity_rate_kwh or float(
        os.environ.get("VELENAI_ELECTRICITY_RATE", "0.16")
    )
    lifespan = lifespan_years or float(
        os.environ.get("VELENAI_GPU_LIFESPAN_YEARS", "3.0")
    )

    profile = GPUProfile(
        electricity_rate_kwh=rate,
        default_lifespan_years=lifespan,
    )

    # Try NVIDIA first
    nvidia_gpus = _detect_nvidia()
    if nvidia_gpus:
        profile.gpus = nvidia_gpus
        profile.detection_method = "nvml"
    else:
        # Try AMD
        amd_gpus = _detect_amd()
        if amd_gpus:
            profile.gpus = amd_gpus
            profile.detection_method = "rocm"

    # Apply electricity rate and lifespan to all detected GPUs
    for gpu in profile.gpus:
        gpu.electricity_rate_kwh = rate
        gpu.lifespan_years = lifespan

    if profile.gpus:
        logger.info(
            f"Detected {len(profile.gpus)} GPU(s): "
            f"{', '.join(g.name for g in profile.gpus)} "
            f"(${profile.total_hourly_cost:.4f}/hr)"
        )
    else:
        logger.info("No GPU detected — cost model will use platform defaults")

    return profile
