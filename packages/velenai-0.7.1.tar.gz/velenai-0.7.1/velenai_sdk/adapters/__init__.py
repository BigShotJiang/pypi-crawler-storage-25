"""Framework adapters for VelenAI.

Available adapters:
- CrewAI: `from velenai_sdk.adapters.crewai import VelenAICrewCallback`
- LangGraph: `from velenai_sdk.adapters.langgraph import velenai_langgraph_listener`
- AutoGen: `from velenai_sdk.adapters.autogen import VelenAIAutoGenHandler`
"""
