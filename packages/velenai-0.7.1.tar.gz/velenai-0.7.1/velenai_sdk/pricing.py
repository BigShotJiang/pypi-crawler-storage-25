"""Built-in cloud LLM pricing tables.

Prices are per 1M tokens. Override via environment variables for
custom/negotiated pricing.

Usage:
    from velenai_sdk.pricing import estimate_cost, get_price

    cost = estimate_cost("anthropic", "claude-sonnet-4-6", prompt_tokens=1000, completion_tokens=500)
    price = get_price("openai", "gpt-4o")  # {"input": 2.50, "output": 10.00}
"""

from __future__ import annotations

import os
from typing import TypedDict


class ModelPrice(TypedDict):
    input: float  # USD per 1M input tokens
    output: float  # USD per 1M output tokens


# Prices as of 2026-03-30. All values are USD per 1M tokens.
CLOUD_PRICING: dict[str, dict[str, ModelPrice]] = {
    "anthropic": {
        "claude-opus-4-6": {"input": 15.00, "output": 75.00},
        "claude-sonnet-4-6": {"input": 3.00, "output": 15.00},
        "claude-haiku-4-5": {"input": 0.80, "output": 4.00},
    },
    "openai": {
        "gpt-4o": {"input": 2.50, "output": 10.00},
        "gpt-4o-mini": {"input": 0.15, "output": 0.60},
        "gpt-4.1": {"input": 2.00, "output": 8.00},
        "gpt-4.1-mini": {"input": 0.40, "output": 1.60},
        "gpt-4.1-nano": {"input": 0.10, "output": 0.40},
        "o3": {"input": 2.00, "output": 8.00},
        "o3-mini": {"input": 1.10, "output": 4.40},
        "o4-mini": {"input": 1.10, "output": 4.40},
    },
    "google": {
        "gemini-2.5-pro": {"input": 1.25, "output": 10.00},
        "gemini-2.5-flash": {"input": 0.15, "output": 0.60},
        "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    },
    "mistral": {
        "mistral-large-latest": {"input": 2.00, "output": 6.00},
        "mistral-small-latest": {"input": 0.10, "output": 0.30},
        "codestral-latest": {"input": 0.30, "output": 0.90},
    },
}


def get_price(provider: str, model: str) -> ModelPrice | None:
    """Look up pricing for a provider/model pair.

    Checks environment variable overrides first:
        VELENAI_PRICE_{PROVIDER}_{MODEL}_INPUT  (per 1M tokens)
        VELENAI_PRICE_{PROVIDER}_{MODEL}_OUTPUT (per 1M tokens)

    Returns None if model is not found and no overrides are set.
    """
    env_prefix = f"VELENAI_PRICE_{provider.upper()}_{model.upper().replace('-', '_').replace('.', '_')}"
    env_input = os.environ.get(f"{env_prefix}_INPUT")
    env_output = os.environ.get(f"{env_prefix}_OUTPUT")

    if env_input is not None and env_output is not None:
        return {"input": float(env_input), "output": float(env_output)}

    provider_prices = CLOUD_PRICING.get(provider, {})
    price = provider_prices.get(model)

    if price and env_input is not None:
        return {"input": float(env_input), "output": price["output"]}
    if price and env_output is not None:
        return {"input": price["input"], "output": float(env_output)}

    return price


def estimate_cost(
    provider: str,
    model: str,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_write_tokens: int = 0,
) -> float | None:
    """Estimate cost in USD for a cloud API call.

    Cache pricing (Anthropic-style):
    - cache_read_tokens: 90% discount on input price
    - cache_write_tokens: 25% surcharge on input price

    Returns None if pricing is not available for the provider/model.
    """
    price = get_price(provider, model)
    if price is None:
        return None

    input_price = price["input"] / 1_000_000
    output_price = price["output"] / 1_000_000

    # Standard token costs
    cost = (prompt_tokens * input_price) + (completion_tokens * output_price)

    # Cache pricing adjustments
    if cache_read_tokens:
        cost += cache_read_tokens * input_price * 0.1  # 90% discount
    if cache_write_tokens:
        cost += cache_write_tokens * input_price * 1.25  # 25% surcharge

    return cost


def cost_per_token(provider: str, model: str) -> tuple[float, float] | None:
    """Return (cost_per_input_token, cost_per_output_token) in USD.

    Returns None if pricing is not available.
    """
    price = get_price(provider, model)
    if price is None:
        return None
    return (price["input"] / 1_000_000, price["output"] / 1_000_000)
