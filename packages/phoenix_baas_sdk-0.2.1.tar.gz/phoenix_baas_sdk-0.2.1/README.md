# phoenix-baas-sdk

Official Python SDK for the [Phoenix BaaS platform](https://getphoenix.io) — AI-powered banking infrastructure for Africa.

## Installation

```bash
pip install phoenix-baas-sdk
```

Requires Python 3.11+. The only dependency is [`httpx`](https://www.python-httpx.org/).

## Quickstart

```python
import phoenix_sdk as phoenix

client = phoenix.Client(api_key="sk_test_...")

# 1. Create a customer
customer = client.customers.create(
    "Amara Okafor",
    email="amara@example.com",
    phone="+2348012345678",
)

# 2. Score them with Eye (AI credit engine)
decision = client.eye.score(
    customer.id,
    requested_amount=500_000_00,   # ₦500,000 in kobo
    tenor_months=12,
    open_banking=phoenix.OpenBankingData(
        avg_monthly_inflow=200_000_00,
        salary_detected=True,
        bounce_count=0,
    ),
)
print(decision.outcome)   # "approve" | "refer" | "decline"
print(decision.pd)        # e.g. 0.042
print(decision.reasons[0].human_readable)  # "Strong salary history"

# 3. Apply for a loan (Rise)
if decision.outcome == "approve":
    loan = client.loans.apply(
        customer.id,
        requested_amount=500_000_00,
        tenor_months=12,
        eye_application_id=decision.application_id,
    )
    loan = client.loans.disburse(loan.id, disbursement_reference="TXN_001")
    print(loan.schedule[0].due_date)
```

## Async usage

```python
import asyncio
import phoenix_sdk as phoenix

async def main():
    async with phoenix.AsyncClient(api_key="sk_test_...") as client:
        customer = await client.customers.create("Amara Okafor")
        decision = await client.eye.score(customer.id, requested_amount=500_000_00, tenor_months=12)
        print(decision.outcome, decision.pd)

asyncio.run(main())
```

## Resources

| Resource | Methods |
|---|---|
| `client.customers` | `create`, `get`, `update`, `list` |
| `client.eye` | `score`, `get_decision`, `fraud_check`, `categorise` |
| `client.loans` | `apply`, `get`, `disburse`, `record_payment`, `list` |
| `client.accounts` | `open`, `get`, `transfer`, `transactions`, `list` |
| `client.shield` | `list_alerts`, `resolve_alert` |

## Configuration

```python
client = phoenix.Client(
    api_key="sk_test_...",
    base_url="https://api.getphoenix.io",   # default
    eye_url="https://eye.getphoenix.io",    # default
    timeout=30.0,                           # seconds
)
```

Set `base_url` and `eye_url` to `http://localhost:8001` / `http://localhost:8000` for local development.

## Error handling

```python
from phoenix_sdk.exceptions import AuthError, NotFoundError, PhoenixError

try:
    customer = client.customers.get("cust_nonexistent")
except NotFoundError:
    print("Customer not found")
except AuthError:
    print("Invalid API key")
except PhoenixError as e:
    print(f"API error {e.status_code}: {e}")
```

| Exception | HTTP status |
|---|---|
| `AuthError` | 401 |
| `ForbiddenError` | 403 |
| `NotFoundError` | 404 |
| `ConflictError` | 409 |
| `ValidationError` | 422 |
| `ServiceUnavailableError` | 503 |

## License

MIT
