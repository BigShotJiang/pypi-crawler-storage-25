"""
Phoenix SDK — Official Python client for the Phoenix BaaS platform.

Quickstart::

    import phoenix_sdk as phoenix

    client = phoenix.Client(
        api_key="sk_test_...",
        base_url="http://localhost:8001",   # local dev
        eye_url="http://localhost:8000",
    )

    # Create a customer
    customer = client.customers.create(
        "Amara Okafor",
        email="amara@example.com",
        phone="+2348012345678",
        bvn="12345678901",
    )

    # Score with Eye
    decision = client.eye.score(
        customer.id,
        requested_amount=50_000_00,   # ₦500,000 in kobo
        tenor_months=12,
        bureau=phoenix.BureauData(active_loans=1),
        open_banking=phoenix.OpenBankingData(avg_monthly_inflow=200_000_00, salary_detected=True),
    )
    print(decision.outcome, decision.pd)  # e.g. "approve" 0.04

    # Apply for a loan
    loan = client.loans.apply(
        customer.id,
        requested_amount=50_000_00,
        tenor_months=12,
        eye_application_id=decision.application_id,
    )

    # Disburse
    if loan.status == "pending":
        loan = client.loans.disburse(loan.id, disbursement_reference="DISB_001")
        print(f"Disbursed. First payment due {loan.schedule[0].due_date}")
"""
from phoenix_sdk.client import Client, AsyncClient
from phoenix_sdk.types import (
    Customer,
    Account, Transaction,
    BureauData, OpenBankingData, CustomerProfile,
    ScoreDecision, SHAPReason,
    FraudCheck,
    FraudAlert, BlacklistEntry,
    CategorisationResult, CategorisedTransaction,
    Loan, ScheduleEntry, LoanPayment,
)
from phoenix_sdk.exceptions import (
    PhoenixError,
    AuthError,
    ForbiddenError,
    NotFoundError,
    ConflictError,
    ValidationError,
    ServiceUnavailableError,
)

__version__ = "0.2.0"
__all__ = [
    "Client",
    "AsyncClient",
    # Types
    "Customer",
    "Account",
    "Transaction",
    "BureauData",
    "OpenBankingData",
    "CustomerProfile",
    "ScoreDecision",
    "SHAPReason",
    "FraudCheck",
    "FraudAlert",
    "BlacklistEntry",
    "CategorisationResult",
    "CategorisedTransaction",
    "Loan",
    "ScheduleEntry",
    "LoanPayment",
    # Exceptions
    "PhoenixError",
    "AuthError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "ServiceUnavailableError",
]
