from __future__ import annotations
from phoenix_sdk.http import (
    SyncTransport, AsyncTransport,
    _DEFAULT_BASE_URL, _DEFAULT_EYE_URL,
)
from phoenix_sdk.resources.customers import CustomersResource, AsyncCustomersResource
from phoenix_sdk.resources.eye import EyeResource, AsyncEyeResource
from phoenix_sdk.resources.loans import LoansResource, AsyncLoansResource
from phoenix_sdk.resources.accounts import AccountsResource, AsyncAccountsResource
from phoenix_sdk.resources.shield import ShieldResource, AsyncShieldResource
from phoenix_sdk.resources.wing import WingResource, AsyncWingResource
from phoenix_sdk.resources.aura import AuraResource, AsyncAuraResource


class Client:
    """
    Synchronous Phoenix SDK client.

    Usage::

        import phoenix_sdk as phoenix

        client = phoenix.Client(api_key="sk_test_...")

        customer = client.customers.create("Amara Okafor", email="amara@example.com")
        decision = client.eye.score(customer.id, requested_amount=50_000_00, tenor_months=12)
        loan = client.loans.apply(customer.id, 50_000_00, 12, eye_application_id=decision.application_id)
        account = client.accounts.open(customer.id, type="current", currency="NGN")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        eye_url: str = _DEFAULT_EYE_URL,
        timeout: float = 30.0,
    ):
        self._api = SyncTransport(api_key, base_url, timeout)
        self._eye = SyncTransport(api_key, eye_url, timeout)

        self.customers = CustomersResource(self._api)
        self.eye = EyeResource(self._eye)
        self.loans = LoansResource(self._api)
        self.accounts = AccountsResource(self._api)
        self.shield = ShieldResource(self._api)
        self.wing = WingResource(self._api)
        self.aura = AuraResource(self._api)

    def close(self) -> None:
        self._api.close()
        self._eye.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class AsyncClient:
    """
    Async Phoenix SDK client for use with asyncio.

    Usage::

        async with phoenix.AsyncClient(api_key="sk_test_...") as client:
            customer = await client.customers.create("Amara Okafor")
            decision = await client.eye.score(customer.id, requested_amount=50_000_00, tenor_months=12)
            loan = await client.loans.apply(
                customer.id, 50_000_00, 12,
                eye_application_id=decision.application_id,
            )
            account = await client.accounts.open(customer.id, type="current", currency="NGN")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        eye_url: str = _DEFAULT_EYE_URL,
        timeout: float = 30.0,
    ):
        self._api = AsyncTransport(api_key, base_url, timeout)
        self._eye = AsyncTransport(api_key, eye_url, timeout)

        self.customers = AsyncCustomersResource(self._api)
        self.eye = AsyncEyeResource(self._eye)
        self.loans = AsyncLoansResource(self._api)
        self.accounts = AsyncAccountsResource(self._api)
        self.shield = AsyncShieldResource(self._api)
        self.wing = AsyncWingResource(self._api)
        self.aura = AsyncAuraResource(self._api)

    async def aclose(self) -> None:
        await self._api.aclose()
        await self._eye.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.aclose()
