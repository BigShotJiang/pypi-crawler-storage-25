from __future__ import annotations
from typing import Optional
from phoenix_sdk.types import Loan, ScheduleEntry, LoanPayment


def _parse_schedule(entries: list[dict]) -> list[ScheduleEntry]:
    return [
        ScheduleEntry(
            id=e["id"],
            installment_number=e["installment_number"],
            due_date=e["due_date"],
            principal_due=e["principal_due"],
            interest_due=e["interest_due"],
            total_due=e["total_due"],
            paid_amount=e["paid_amount"],
            status=e["status"],
        )
        for e in entries
    ]


def _parse_payments(payments: list[dict]) -> list[LoanPayment]:
    return [
        LoanPayment(
            id=p["id"],
            amount=p["amount"],
            reference=p["reference"],
            channel=p["channel"],
            recorded_at=p["recorded_at"],
            created_at=p["created_at"],
        )
        for p in payments
    ]


def _parse(d: dict) -> Loan:
    return Loan(
        id=d["id"],
        tenant_id=d["tenant_id"],
        customer_id=d["customer_id"],
        eye_application_id=d.get("eye_application_id"),
        product=d["product"],
        principal=d["principal"],
        interest_rate=d["interest_rate"],
        tenor_months=d["tenor_months"],
        outstanding_balance=d["outstanding_balance"],
        status=d["status"],
        decline_reason=d.get("decline_reason"),
        disbursed_at=d.get("disbursed_at"),
        maturity_date=d.get("maturity_date"),
        created_at=d["created_at"],
        updated_at=d["updated_at"],
        schedule=_parse_schedule(d.get("schedule", [])),
        payments=_parse_payments(d.get("payments", [])),
    )


class LoansResource:
    def __init__(self, transport):
        self._t = transport

    def apply(
        self,
        customer_id: str,
        requested_amount: int,
        tenor_months: int,
        *,
        product: str = "personal",
        eye_application_id: Optional[str] = None,
    ) -> Loan:
        body = {
            "customer_id": customer_id,
            "product": product,
            "requested_amount": requested_amount,
            "tenor_months": tenor_months,
            "eye_application_id": eye_application_id,
        }
        return _parse(self._t.post("/v1/loans", body))

    def disburse(self, loan_id: str, *, disbursement_reference: str) -> Loan:
        return _parse(
            self._t.post(f"/v1/loans/{loan_id}/disburse", {"disbursement_reference": disbursement_reference})
        )

    def record_repayment(
        self,
        loan_id: str,
        *,
        amount: int,
        reference: str,
        channel: str = "bank_transfer",
        recorded_at: Optional[str] = None,
    ) -> Loan:
        body = {
            "amount": amount,
            "reference": reference,
            "channel": channel,
            "recorded_at": recorded_at,
        }
        return _parse(self._t.post(f"/v1/loans/{loan_id}/repayments", body))

    def get(self, loan_id: str) -> Loan:
        return _parse(self._t.get(f"/v1/loans/{loan_id}"))

    def list(
        self,
        *,
        customer_id: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> list[Loan]:
        params = {"skip": skip, "limit": limit}
        if customer_id:
            params["customer_id"] = customer_id
        if status:
            params["status"] = status
        data = self._t.get("/v1/loans", params=params)
        return [_parse(d) for d in data]

    def write_off(self, loan_id: str) -> Loan:
        return _parse(self._t.post(f"/v1/loans/{loan_id}/write-off", {}))


class AsyncLoansResource:
    def __init__(self, transport):
        self._t = transport

    async def apply(
        self,
        customer_id: str,
        requested_amount: int,
        tenor_months: int,
        *,
        product: str = "personal",
        eye_application_id: Optional[str] = None,
    ) -> Loan:
        body = {
            "customer_id": customer_id,
            "product": product,
            "requested_amount": requested_amount,
            "tenor_months": tenor_months,
            "eye_application_id": eye_application_id,
        }
        return _parse(await self._t.post("/v1/loans", body))

    async def disburse(self, loan_id: str, *, disbursement_reference: str) -> Loan:
        return _parse(
            await self._t.post(f"/v1/loans/{loan_id}/disburse", {"disbursement_reference": disbursement_reference})
        )

    async def record_repayment(
        self,
        loan_id: str,
        *,
        amount: int,
        reference: str,
        channel: str = "bank_transfer",
        recorded_at: Optional[str] = None,
    ) -> Loan:
        body = {
            "amount": amount,
            "reference": reference,
            "channel": channel,
            "recorded_at": recorded_at,
        }
        return _parse(await self._t.post(f"/v1/loans/{loan_id}/repayments", body))

    async def get(self, loan_id: str) -> Loan:
        return _parse(await self._t.get(f"/v1/loans/{loan_id}"))

    async def list(
        self,
        *,
        customer_id: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> list[Loan]:
        params = {"skip": skip, "limit": limit}
        if customer_id:
            params["customer_id"] = customer_id
        if status:
            params["status"] = status
        data = await self._t.get("/v1/loans", params=params)
        return [_parse(d) for d in data]

    async def write_off(self, loan_id: str) -> Loan:
        return _parse(await self._t.post(f"/v1/loans/{loan_id}/write-off", {}))
