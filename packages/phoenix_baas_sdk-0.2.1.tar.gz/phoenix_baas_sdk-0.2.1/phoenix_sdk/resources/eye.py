from __future__ import annotations
from dataclasses import asdict
from typing import Optional
from phoenix_sdk.types import (
    ScoreDecision, SHAPReason,
    FraudCheck,
    CategorisationResult, CategorisedTransaction,
    BureauData, OpenBankingData, CustomerProfile,
)


def _parse_decision(d: dict) -> ScoreDecision:
    return ScoreDecision(
        application_id=d["application_id"],
        customer_id=d["customer_id"],
        outcome=d["outcome"],
        pd=d["pd"],
        risk_band=d["risk_band"],
        assigned_limit=d.get("assigned_limit"),
        interest_rate=d.get("interest_rate"),
        model_version=d.get("model_version"),
        processing_ms=d["processing_ms"],
        reasons=[
            SHAPReason(
                feature=r["feature"],
                direction=r["direction"],
                magnitude=r["magnitude"],
                human_readable=r["human_readable"],
            )
            for r in d.get("reasons", [])
        ],
    )


def _parse_fraud(d: dict) -> FraudCheck:
    return FraudCheck(
        customer_id=d["customer_id"],
        fraud_score=d["fraud_score"],
        action=d["action"],
        severity=d["severity"],
        blacklisted=d["blacklisted"],
        rules_triggered=d.get("rules_triggered", []),
        alert_id=d.get("alert_id"),
    )


def _parse_categorisation(d: dict) -> CategorisationResult:
    return CategorisationResult(
        transactions=[
            CategorisedTransaction(
                narration=t["narration"],
                category=t["category"],
                subcategory=t.get("subcategory"),
                confidence=t["confidence"],
            )
            for t in d.get("transactions", [])
        ]
    )


class EyeResource:
    """Sync resource for Phoenix Eye (AI risk engine)."""

    def __init__(self, transport):
        self._t = transport

    def score(
        self,
        customer_id: str,
        *,
        requested_amount: Optional[int] = None,
        pull_bureau: bool = False,
        pull_open_banking: bool = False,
        bureau: Optional[BureauData] = None,
        open_banking: Optional[OpenBankingData] = None,
        profile: Optional[CustomerProfile] = None,
    ) -> ScoreDecision:
        body = {
            "customer_id": customer_id,
            "requested_amount": requested_amount,
            "pull_bureau": pull_bureau,
            "pull_open_banking": pull_open_banking,
            "bureau": asdict(bureau) if bureau else None,
            "open_banking": asdict(open_banking) if open_banking else None,
            "profile": asdict(profile) if profile else None,
        }
        return _parse_decision(self._t.post("/score", body))

    def get_decision(self, application_id: str) -> ScoreDecision:
        return _parse_decision(self._t.get(f"/score/{application_id}"))

    def fraud_check(
        self,
        customer_id: str,
        *,
        bvn_hash: Optional[str] = None,
        phone_hash: Optional[str] = None,
        email_hash: Optional[str] = None,
        device_fingerprint: Optional[str] = None,
        ip_address: Optional[str] = None,
        amount: Optional[int] = None,
        channel: Optional[str] = None,
    ) -> FraudCheck:
        body = {
            "customer_id": customer_id,
            "bvn_hash": bvn_hash,
            "phone_hash": phone_hash,
            "email_hash": email_hash,
            "device_fingerprint": device_fingerprint,
            "ip_address": ip_address,
            "amount": amount,
            "channel": channel,
        }
        return _parse_fraud(self._t.post("/shield/check", body))

    def categorise(self, transactions: list[dict]) -> CategorisationResult:
        return _parse_categorisation(
            self._t.post("/categorise", {"transactions": transactions})
        )


class AsyncEyeResource:
    """Async resource for Phoenix Eye."""

    def __init__(self, transport):
        self._t = transport

    async def score(
        self,
        customer_id: str,
        *,
        requested_amount: Optional[int] = None,
        pull_bureau: bool = False,
        pull_open_banking: bool = False,
        bureau: Optional[BureauData] = None,
        open_banking: Optional[OpenBankingData] = None,
        profile: Optional[CustomerProfile] = None,
    ) -> ScoreDecision:
        body = {
            "customer_id": customer_id,
            "requested_amount": requested_amount,
            "pull_bureau": pull_bureau,
            "pull_open_banking": pull_open_banking,
            "bureau": asdict(bureau) if bureau else None,
            "open_banking": asdict(open_banking) if open_banking else None,
            "profile": asdict(profile) if profile else None,
        }
        return _parse_decision(await self._t.post("/score", body))

    async def get_decision(self, application_id: str) -> ScoreDecision:
        return _parse_decision(await self._t.get(f"/score/{application_id}"))

    async def fraud_check(
        self,
        customer_id: str,
        *,
        bvn_hash: Optional[str] = None,
        phone_hash: Optional[str] = None,
        email_hash: Optional[str] = None,
        device_fingerprint: Optional[str] = None,
        ip_address: Optional[str] = None,
        amount: Optional[int] = None,
        channel: Optional[str] = None,
    ) -> FraudCheck:
        body = {
            "customer_id": customer_id,
            "bvn_hash": bvn_hash,
            "phone_hash": phone_hash,
            "email_hash": email_hash,
            "device_fingerprint": device_fingerprint,
            "ip_address": ip_address,
            "amount": amount,
            "channel": channel,
        }
        return _parse_fraud(await self._t.post("/shield/check", body))

    async def categorise(self, transactions: list[dict]) -> CategorisationResult:
        return _parse_categorisation(
            await self._t.post("/categorise", {"transactions": transactions})
        )
