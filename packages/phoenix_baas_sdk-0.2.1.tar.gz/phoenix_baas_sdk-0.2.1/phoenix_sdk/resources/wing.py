from __future__ import annotations
from typing import Optional
from phoenix_sdk.types import Card, CardTransaction


def _parse_card(d: dict) -> Card:
    return Card(
        id=d["id"],
        tenant_id=d["tenant_id"],
        customer_id=d["customer_id"],
        account_id=d["account_id"],
        card_number_masked=d["card_number_masked"],
        expiry=d["expiry"],
        type=d["type"],
        network=d["network"],
        status=d["status"],
        daily_limit=d.get("daily_limit"),
        monthly_limit=d.get("monthly_limit"),
        label=d.get("label"),
        created_at=d["created_at"],
        updated_at=d["updated_at"],
    )


def _parse_card_txn(d: dict) -> CardTransaction:
    return CardTransaction(
        id=d["id"],
        card_id=d["card_id"],
        amount=d["amount"],
        currency=d["currency"],
        merchant_name=d.get("merchant_name", ""),
        merchant_category=d.get("merchant_category", ""),
        status=d["status"],
        decline_reason=d.get("decline_reason"),
        created_at=d["created_at"],
    )


class WingResource:
    def __init__(self, transport):
        self._t = transport

    def issue(
        self,
        customer_id: str,
        account_id: str,
        *,
        type: str = "prepaid",
        network: str = "verve",
        label: Optional[str] = None,
        daily_limit: Optional[int] = None,
        monthly_limit: Optional[int] = None,
    ) -> Card:
        body: dict = {"customer_id": customer_id, "account_id": account_id, "type": type, "network": network}
        if label:
            body["label"] = label
        if daily_limit is not None:
            body["daily_limit"] = daily_limit
        if monthly_limit is not None:
            body["monthly_limit"] = monthly_limit
        return _parse_card(self._t.post("/v1/cards", body))

    def get(self, card_id: str) -> Card:
        return _parse_card(self._t.get(f"/v1/cards/{card_id}"))

    def list(self, *, customer_id: Optional[str] = None) -> list[Card]:
        params = {}
        if customer_id:
            params["customer_id"] = customer_id
        return [_parse_card(d) for d in self._t.get("/v1/cards", params=params)]

    def freeze(self, card_id: str) -> Card:
        return _parse_card(self._t.post(f"/v1/cards/{card_id}/freeze", {}))

    def unfreeze(self, card_id: str) -> Card:
        return _parse_card(self._t.post(f"/v1/cards/{card_id}/unfreeze", {}))

    def terminate(self, card_id: str) -> Card:
        return _parse_card(self._t.post(f"/v1/cards/{card_id}/terminate", {}))

    def set_limits(
        self,
        card_id: str,
        *,
        daily_limit: Optional[int] = None,
        monthly_limit: Optional[int] = None,
    ) -> Card:
        body: dict = {}
        if daily_limit is not None:
            body["daily_limit"] = daily_limit
        if monthly_limit is not None:
            body["monthly_limit"] = monthly_limit
        return _parse_card(self._t.patch(f"/v1/cards/{card_id}/limits", body))

    def transactions(
        self,
        card_id: str,
        *,
        skip: int = 0,
        limit: int = 50,
    ) -> list[CardTransaction]:
        params = {"skip": skip, "limit": limit}
        return [_parse_card_txn(d) for d in self._t.get(f"/v1/cards/{card_id}/transactions", params=params)]


class AsyncWingResource:
    def __init__(self, transport):
        self._t = transport

    async def issue(
        self,
        customer_id: str,
        account_id: str,
        *,
        type: str = "prepaid",
        network: str = "verve",
        label: Optional[str] = None,
        daily_limit: Optional[int] = None,
        monthly_limit: Optional[int] = None,
    ) -> Card:
        body: dict = {"customer_id": customer_id, "account_id": account_id, "type": type, "network": network}
        if label:
            body["label"] = label
        if daily_limit is not None:
            body["daily_limit"] = daily_limit
        if monthly_limit is not None:
            body["monthly_limit"] = monthly_limit
        return _parse_card(await self._t.post("/v1/cards", body))

    async def get(self, card_id: str) -> Card:
        return _parse_card(await self._t.get(f"/v1/cards/{card_id}"))

    async def list(self, *, customer_id: Optional[str] = None) -> list[Card]:
        params = {}
        if customer_id:
            params["customer_id"] = customer_id
        return [_parse_card(d) for d in await self._t.get("/v1/cards", params=params)]

    async def freeze(self, card_id: str) -> Card:
        return _parse_card(await self._t.post(f"/v1/cards/{card_id}/freeze", {}))

    async def unfreeze(self, card_id: str) -> Card:
        return _parse_card(await self._t.post(f"/v1/cards/{card_id}/unfreeze", {}))

    async def terminate(self, card_id: str) -> Card:
        return _parse_card(await self._t.post(f"/v1/cards/{card_id}/terminate", {}))

    async def set_limits(
        self,
        card_id: str,
        *,
        daily_limit: Optional[int] = None,
        monthly_limit: Optional[int] = None,
    ) -> Card:
        body: dict = {}
        if daily_limit is not None:
            body["daily_limit"] = daily_limit
        if monthly_limit is not None:
            body["monthly_limit"] = monthly_limit
        return _parse_card(await self._t.patch(f"/v1/cards/{card_id}/limits", body))

    async def transactions(
        self,
        card_id: str,
        *,
        skip: int = 0,
        limit: int = 50,
    ) -> list[CardTransaction]:
        params = {"skip": skip, "limit": limit}
        return [_parse_card_txn(d) for d in await self._t.get(f"/v1/cards/{card_id}/transactions", params=params)]
