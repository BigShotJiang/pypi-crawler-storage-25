from __future__ import annotations
from typing import Optional
from phoenix_sdk.types import CustomerSegment, Campaign, MessageResult


def _parse_segment(d: dict) -> CustomerSegment:
    return CustomerSegment(
        id=d["id"],
        name=d["name"],
        description=d.get("description", ""),
        filter_rules=d.get("filter_rules", {}),
        customer_count=d.get("customer_count", 0),
        created_at=d["created_at"],
    )


def _parse_campaign(d: dict) -> Campaign:
    return Campaign(
        id=d["id"],
        name=d["name"],
        channel=d["channel"],
        status=d["status"],
        segment_id=d.get("segment_id"),
        template_id=d.get("template_id"),
        sent_count=d.get("sent_count", 0),
        delivered_count=d.get("delivered_count", 0),
        scheduled_at=d.get("scheduled_at"),
        created_at=d["created_at"],
    )


def _parse_message_result(d: dict) -> MessageResult:
    return MessageResult(
        message_id=d["message_id"],
        status=d["status"],
        channel=d["channel"],
        recipient=d["recipient"],
    )


class AuraResource:
    def __init__(self, transport):
        self._t = transport

    # ── Segments ──────────────────────────────────────────────────────────────

    def create_segment(self, name: str, *, description: str = "", filter_rules: Optional[dict] = None) -> CustomerSegment:
        body = {"name": name, "description": description, "filter_rules": filter_rules or {}}
        return _parse_segment(self._t.post("/v1/aura/segments", body))

    def get_segment(self, segment_id: str) -> CustomerSegment:
        return _parse_segment(self._t.get(f"/v1/aura/segments/{segment_id}"))

    def list_segments(self) -> list[CustomerSegment]:
        return [_parse_segment(d) for d in self._t.get("/v1/aura/segments")]

    def delete_segment(self, segment_id: str) -> None:
        self._t.delete(f"/v1/aura/segments/{segment_id}")

    # ── Campaigns ─────────────────────────────────────────────────────────────

    def create_campaign(
        self,
        name: str,
        *,
        channel: str,
        segment_id: str,
        template_id: str,
        scheduled_at: Optional[str] = None,
    ) -> Campaign:
        body: dict = {"name": name, "channel": channel, "segment_id": segment_id, "template_id": template_id}
        if scheduled_at:
            body["scheduled_at"] = scheduled_at
        return _parse_campaign(self._t.post("/v1/aura/campaigns", body))

    def get_campaign(self, campaign_id: str) -> Campaign:
        return _parse_campaign(self._t.get(f"/v1/aura/campaigns/{campaign_id}"))

    def list_campaigns(self) -> list[Campaign]:
        return [_parse_campaign(d) for d in self._t.get("/v1/aura/campaigns")]

    def launch_campaign(self, campaign_id: str) -> Campaign:
        return _parse_campaign(self._t.post(f"/v1/aura/campaigns/{campaign_id}/launch", {}))

    def pause_campaign(self, campaign_id: str) -> Campaign:
        return _parse_campaign(self._t.post(f"/v1/aura/campaigns/{campaign_id}/pause", {}))

    # ── Direct messaging ──────────────────────────────────────────────────────

    def send_sms(self, customer_id: str, *, message: str) -> MessageResult:
        return _parse_message_result(self._t.post("/v1/aura/messages/sms", {"customer_id": customer_id, "message": message}))

    def send_email(self, customer_id: str, *, subject: str, body: str, template_id: Optional[str] = None) -> MessageResult:
        payload: dict = {"customer_id": customer_id, "subject": subject, "body": body}
        if template_id:
            payload["template_id"] = template_id
        return _parse_message_result(self._t.post("/v1/aura/messages/email", payload))


class AsyncAuraResource:
    def __init__(self, transport):
        self._t = transport

    async def create_segment(self, name: str, *, description: str = "", filter_rules: Optional[dict] = None) -> CustomerSegment:
        body = {"name": name, "description": description, "filter_rules": filter_rules or {}}
        return _parse_segment(await self._t.post("/v1/aura/segments", body))

    async def get_segment(self, segment_id: str) -> CustomerSegment:
        return _parse_segment(await self._t.get(f"/v1/aura/segments/{segment_id}"))

    async def list_segments(self) -> list[CustomerSegment]:
        return [_parse_segment(d) for d in await self._t.get("/v1/aura/segments")]

    async def delete_segment(self, segment_id: str) -> None:
        await self._t.delete(f"/v1/aura/segments/{segment_id}")

    async def create_campaign(
        self,
        name: str,
        *,
        channel: str,
        segment_id: str,
        template_id: str,
        scheduled_at: Optional[str] = None,
    ) -> Campaign:
        body: dict = {"name": name, "channel": channel, "segment_id": segment_id, "template_id": template_id}
        if scheduled_at:
            body["scheduled_at"] = scheduled_at
        return _parse_campaign(await self._t.post("/v1/aura/campaigns", body))

    async def get_campaign(self, campaign_id: str) -> Campaign:
        return _parse_campaign(await self._t.get(f"/v1/aura/campaigns/{campaign_id}"))

    async def list_campaigns(self) -> list[Campaign]:
        return [_parse_campaign(d) for d in await self._t.get("/v1/aura/campaigns")]

    async def launch_campaign(self, campaign_id: str) -> Campaign:
        return _parse_campaign(await self._t.post(f"/v1/aura/campaigns/{campaign_id}/launch", {}))

    async def pause_campaign(self, campaign_id: str) -> Campaign:
        return _parse_campaign(await self._t.post(f"/v1/aura/campaigns/{campaign_id}/pause", {}))

    async def send_sms(self, customer_id: str, *, message: str) -> MessageResult:
        return _parse_message_result(await self._t.post("/v1/aura/messages/sms", {"customer_id": customer_id, "message": message}))

    async def send_email(self, customer_id: str, *, subject: str, body: str, template_id: Optional[str] = None) -> MessageResult:
        payload: dict = {"customer_id": customer_id, "subject": subject, "body": body}
        if template_id:
            payload["template_id"] = template_id
        return _parse_message_result(await self._t.post("/v1/aura/messages/email", payload))
