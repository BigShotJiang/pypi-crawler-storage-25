from __future__ import annotations
from typing import Optional
from phoenix_sdk.types import FraudAlert, BlacklistEntry


def _parse_alert(d: dict) -> FraudAlert:
    return FraudAlert(
        id=d["id"],
        tenant_id=d["tenant_id"],
        customer_id=d["customer_id"],
        rule_triggered=d["rule_triggered"],
        fraud_score=d["fraud_score"],
        severity=d["severity"],
        action_taken=d["action_taken"],
        status=d["status"],
        resolved_by=d.get("resolved_by"),
        details=d.get("details", {}),
        created_at=d["created_at"],
    )


def _parse_blacklist(d: dict) -> BlacklistEntry:
    return BlacklistEntry(
        id=d["id"],
        identifier_type=d["identifier_type"],
        source_tenant_id=d["source_tenant_id"],
        reason=d.get("reason"),
        confirmed_at=d["confirmed_at"],
    )


class ShieldResource:
    def __init__(self, transport):
        self._t = transport

    def check(
        self,
        customer_id: str,
        *,
        event_type: str = "loan_application",
        amount: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> dict:
        """Run a real-time fraud check for a customer event. Returns the raw check result."""
        body: dict = {"customer_id": customer_id, "event_type": event_type}
        if amount is not None:
            body["amount"] = amount
        if metadata:
            body["metadata"] = metadata
        return self._t.post("/v1/shield/check", body)

    def list_alerts(
        self,
        *,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> list[FraudAlert]:
        params: dict = {"skip": skip, "limit": limit}
        if status:
            params["status"] = status
        return [_parse_alert(d) for d in self._t.get("/v1/shield/alerts", params=params)]

    def resolve_alert(
        self,
        alert_id: str,
        *,
        status: str,
        resolved_by: Optional[str] = None,
    ) -> FraudAlert:
        body: dict = {"status": status}
        if resolved_by:
            body["resolved_by"] = resolved_by
        return _parse_alert(self._t.patch(f"/v1/shield/alerts/{alert_id}", body))

    def list_blacklist(self, *, skip: int = 0, limit: int = 50) -> list[BlacklistEntry]:
        params = {"skip": skip, "limit": limit}
        return [_parse_blacklist(d) for d in self._t.get("/v1/shield/blacklist", params=params)]

    def add_blacklist(
        self,
        *,
        identifier_type: str,
        identifier_value: str,
        reason: Optional[str] = None,
    ) -> BlacklistEntry:
        body: dict = {"identifier_type": identifier_type, "identifier_value": identifier_value}
        if reason:
            body["reason"] = reason
        return _parse_blacklist(self._t.post("/v1/shield/blacklist", body))

    def remove_blacklist(self, entry_id: str) -> None:
        self._t.delete(f"/v1/shield/blacklist/{entry_id}")


class AsyncShieldResource:
    def __init__(self, transport):
        self._t = transport

    async def check(
        self,
        customer_id: str,
        *,
        event_type: str = "loan_application",
        amount: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> dict:
        body: dict = {"customer_id": customer_id, "event_type": event_type}
        if amount is not None:
            body["amount"] = amount
        if metadata:
            body["metadata"] = metadata
        return await self._t.post("/v1/shield/check", body)

    async def list_alerts(
        self,
        *,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> list[FraudAlert]:
        params: dict = {"skip": skip, "limit": limit}
        if status:
            params["status"] = status
        return [_parse_alert(d) for d in await self._t.get("/v1/shield/alerts", params=params)]

    async def resolve_alert(
        self,
        alert_id: str,
        *,
        status: str,
        resolved_by: Optional[str] = None,
    ) -> FraudAlert:
        body: dict = {"status": status}
        if resolved_by:
            body["resolved_by"] = resolved_by
        return _parse_alert(await self._t.patch(f"/v1/shield/alerts/{alert_id}", body))

    async def list_blacklist(self, *, skip: int = 0, limit: int = 50) -> list[BlacklistEntry]:
        params = {"skip": skip, "limit": limit}
        return [_parse_blacklist(d) for d in await self._t.get("/v1/shield/blacklist", params=params)]

    async def add_blacklist(
        self,
        *,
        identifier_type: str,
        identifier_value: str,
        reason: Optional[str] = None,
    ) -> BlacklistEntry:
        body: dict = {"identifier_type": identifier_type, "identifier_value": identifier_value}
        if reason:
            body["reason"] = reason
        return _parse_blacklist(await self._t.post("/v1/shield/blacklist", body))

    async def remove_blacklist(self, entry_id: str) -> None:
        await self._t.delete(f"/v1/shield/blacklist/{entry_id}")
