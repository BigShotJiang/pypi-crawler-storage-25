from __future__ import annotations
from typing import Optional
from phoenix_sdk.types import Customer


def _parse(d: dict) -> Customer:
    return Customer(
        id=d["id"],
        tenant_id=d["tenant_id"],
        full_name=d["full_name"],
        email=d.get("email"),
        phone=d.get("phone"),
        external_id=d.get("external_id"),
        status=d["status"],
        kyc_status=d["kyc_status"],
        metadata=d.get("metadata", {}),
        created_at=d["created_at"],
    )


class CustomersResource:
    def __init__(self, transport):
        self._t = transport

    def create(
        self,
        full_name: str,
        *,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        bvn: Optional[str] = None,
        external_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Customer:
        body = {
            "full_name": full_name,
            "email": email,
            "phone": phone,
            "bvn": bvn,
            "external_id": external_id,
            "metadata": metadata or {},
        }
        return _parse(self._t.post("/v1/customers", body))

    def get(self, customer_id: str) -> Customer:
        return _parse(self._t.get(f"/v1/customers/{customer_id}"))

    def update(
        self,
        customer_id: str,
        *,
        full_name: Optional[str] = None,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Customer:
        body = {"full_name": full_name, "email": email, "phone": phone, "metadata": metadata}
        return _parse(self._t.patch(f"/v1/customers/{customer_id}", body))

    def list(self, *, skip: int = 0, limit: int = 50) -> list[Customer]:
        data = self._t.get("/v1/customers", params={"skip": skip, "limit": limit})
        return [_parse(d) for d in data]


class AsyncCustomersResource:
    def __init__(self, transport):
        self._t = transport

    async def create(
        self,
        full_name: str,
        *,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        bvn: Optional[str] = None,
        external_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Customer:
        body = {
            "full_name": full_name,
            "email": email,
            "phone": phone,
            "bvn": bvn,
            "external_id": external_id,
            "metadata": metadata or {},
        }
        return _parse(await self._t.post("/v1/customers", body))

    async def get(self, customer_id: str) -> Customer:
        return _parse(await self._t.get(f"/v1/customers/{customer_id}"))

    async def update(
        self,
        customer_id: str,
        *,
        full_name: Optional[str] = None,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> Customer:
        body = {"full_name": full_name, "email": email, "phone": phone, "metadata": metadata}
        return _parse(await self._t.patch(f"/v1/customers/{customer_id}", body))

    async def list(self, *, skip: int = 0, limit: int = 50) -> list[Customer]:
        data = await self._t.get("/v1/customers", params={"skip": skip, "limit": limit})
        return [_parse(d) for d in data]
