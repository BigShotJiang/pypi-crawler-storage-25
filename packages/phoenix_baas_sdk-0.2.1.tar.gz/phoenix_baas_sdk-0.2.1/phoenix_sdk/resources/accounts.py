from __future__ import annotations
from typing import Optional
from phoenix_sdk.types import Account, Transaction


def _parse_account(d: dict) -> Account:
    return Account(
        id=d["id"],
        tenant_id=d["tenant_id"],
        customer_id=d["customer_id"],
        account_number=d["account_number"],
        type=d["type"],
        currency=d["currency"],
        status=d["status"],
        balance=d["balance"],
        label=d.get("label"),
        created_at=d["created_at"],
        updated_at=d["updated_at"],
    )


def _parse_transaction(d: dict) -> Transaction:
    return Transaction(
        id=d["id"],
        account_id=d["account_id"],
        type=d["type"],
        amount=d["amount"],
        balance_before=d["balance_before"],
        balance_after=d["balance_after"],
        description=d.get("description", ""),
        reference=d["reference"],
        channel=d.get("channel", ""),
        counterpart_account_id=d.get("counterpart_account_id"),
        created_at=d["created_at"],
    )


class AccountsResource:
    def __init__(self, transport):
        self._t = transport

    def open(
        self,
        customer_id: str,
        *,
        type: str = "current",
        currency: str = "NGN",
        label: Optional[str] = None,
    ) -> Account:
        body = {"customer_id": customer_id, "type": type, "currency": currency}
        if label:
            body["label"] = label
        return _parse_account(self._t.post("/v1/accounts", body))

    def get(self, account_id: str) -> Account:
        return _parse_account(self._t.get(f"/v1/accounts/{account_id}"))

    def list(self, *, customer_id: Optional[str] = None) -> list[Account]:
        params = {}
        if customer_id:
            params["customer_id"] = customer_id
        return [_parse_account(d) for d in self._t.get("/v1/accounts", params=params)]

    def deposit(
        self,
        account_id: str,
        *,
        amount: int,
        reference: str,
        description: Optional[str] = None,
        channel: str = "bank_transfer",
    ) -> Account:
        body = {"amount": amount, "reference": reference, "channel": channel}
        if description:
            body["description"] = description
        return _parse_account(self._t.post(f"/v1/accounts/{account_id}/deposit", body))

    def withdraw(
        self,
        account_id: str,
        *,
        amount: int,
        reference: str,
        description: Optional[str] = None,
        channel: str = "bank_transfer",
    ) -> Account:
        body = {"amount": amount, "reference": reference, "channel": channel}
        if description:
            body["description"] = description
        return _parse_account(self._t.post(f"/v1/accounts/{account_id}/withdraw", body))

    def freeze(self, account_id: str) -> Account:
        return _parse_account(self._t.post(f"/v1/accounts/{account_id}/freeze", {}))

    def unfreeze(self, account_id: str) -> Account:
        return _parse_account(self._t.post(f"/v1/accounts/{account_id}/unfreeze", {}))

    def transactions(
        self,
        account_id: str,
        *,
        skip: int = 0,
        limit: int = 50,
    ) -> list[Transaction]:
        params = {"skip": skip, "limit": limit}
        return [
            _parse_transaction(d)
            for d in self._t.get(f"/v1/accounts/{account_id}/transactions", params=params)
        ]


class AsyncAccountsResource:
    def __init__(self, transport):
        self._t = transport

    async def open(
        self,
        customer_id: str,
        *,
        type: str = "current",
        currency: str = "NGN",
        label: Optional[str] = None,
    ) -> Account:
        body = {"customer_id": customer_id, "type": type, "currency": currency}
        if label:
            body["label"] = label
        return _parse_account(await self._t.post("/v1/accounts", body))

    async def get(self, account_id: str) -> Account:
        return _parse_account(await self._t.get(f"/v1/accounts/{account_id}"))

    async def list(self, *, customer_id: Optional[str] = None) -> list[Account]:
        params = {}
        if customer_id:
            params["customer_id"] = customer_id
        return [_parse_account(d) for d in await self._t.get("/v1/accounts", params=params)]

    async def deposit(
        self,
        account_id: str,
        *,
        amount: int,
        reference: str,
        description: Optional[str] = None,
        channel: str = "bank_transfer",
    ) -> Account:
        body = {"amount": amount, "reference": reference, "channel": channel}
        if description:
            body["description"] = description
        return _parse_account(await self._t.post(f"/v1/accounts/{account_id}/deposit", body))

    async def withdraw(
        self,
        account_id: str,
        *,
        amount: int,
        reference: str,
        description: Optional[str] = None,
        channel: str = "bank_transfer",
    ) -> Account:
        body = {"amount": amount, "reference": reference, "channel": channel}
        if description:
            body["description"] = description
        return _parse_account(await self._t.post(f"/v1/accounts/{account_id}/withdraw", body))

    async def freeze(self, account_id: str) -> Account:
        return _parse_account(await self._t.post(f"/v1/accounts/{account_id}/freeze", {}))

    async def unfreeze(self, account_id: str) -> Account:
        return _parse_account(await self._t.post(f"/v1/accounts/{account_id}/unfreeze", {}))

    async def transactions(
        self,
        account_id: str,
        *,
        skip: int = 0,
        limit: int = 50,
    ) -> list[Transaction]:
        params = {"skip": skip, "limit": limit}
        return [
            _parse_transaction(d)
            for d in await self._t.get(f"/v1/accounts/{account_id}/transactions", params=params)
        ]
