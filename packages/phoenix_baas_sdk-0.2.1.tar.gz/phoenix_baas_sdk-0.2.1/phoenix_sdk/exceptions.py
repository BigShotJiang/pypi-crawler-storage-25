class PhoenixError(Exception):
    """Base exception for all Phoenix SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, body: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body or {}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status_code={self.status_code}, message={str(self)})"


class AuthError(PhoenixError):
    """Invalid or inactive API key."""


class ForbiddenError(PhoenixError):
    """Tenant account is suspended or the key lacks permission."""


class NotFoundError(PhoenixError):
    """Requested resource does not exist."""


class ConflictError(PhoenixError):
    """Request conflicts with current state (e.g. duplicate reference)."""


class ValidationError(PhoenixError):
    """Request body failed schema validation."""


class ServiceUnavailableError(PhoenixError):
    """Upstream service (Eye, bureau, etc.) is unreachable."""


def _raise_for_status(status_code: int, body: dict) -> None:
    detail = body.get("detail", "Unknown error")
    mapping = {
        401: AuthError,
        403: ForbiddenError,
        404: NotFoundError,
        409: ConflictError,
        422: ValidationError,
        503: ServiceUnavailableError,
    }
    exc_class = mapping.get(status_code, PhoenixError)
    raise exc_class(detail, status_code=status_code, body=body)
