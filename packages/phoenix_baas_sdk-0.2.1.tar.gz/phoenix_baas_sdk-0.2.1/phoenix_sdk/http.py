"""
Thin httpx wrappers used by sync Client and async AsyncClient.
Both share the same _build_request / _parse helpers.
"""
from __future__ import annotations
from dataclasses import asdict
from typing import Any
import httpx

from phoenix_sdk.exceptions import PhoenixError, _raise_for_status

_DEFAULT_BASE_URL = "https://api.getphoenix.io"
_DEFAULT_EYE_URL = "https://eye.getphoenix.io"


def _headers(api_key: str) -> dict[str, str]:
    return {
        "X-API-Key": api_key,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _clean(obj: Any) -> Any:
    """Recursively drop None values so the API ignores unset fields."""
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items() if v is not None}
    if isinstance(obj, list):
        return [_clean(i) for i in obj]
    return obj


def _payload(body: Any) -> dict:
    """Convert a dataclass (or plain dict) to a cleaned dict."""
    if hasattr(body, "__dataclass_fields__"):
        return _clean(asdict(body))
    return _clean(body)


def _check(response: httpx.Response) -> dict:
    if response.status_code >= 400:
        try:
            body = response.json()
        except Exception:
            body = {"detail": response.text}
        _raise_for_status(response.status_code, body)
    return response.json() if response.content else {}


# ── Sync ──────────────────────────────────────────────────────────────────────

class SyncTransport:
    def __init__(self, api_key: str, base_url: str, timeout: float):
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers=_headers(api_key),
            timeout=timeout,
        )

    def get(self, path: str, params: dict | None = None) -> dict:
        return _check(self._client.get(path, params=params))

    def post(self, path: str, body: Any = None) -> dict:
        return _check(self._client.post(path, json=_payload(body) if body is not None else None))

    def patch(self, path: str, body: Any) -> dict:
        return _check(self._client.patch(path, json=_payload(body)))

    def delete(self, path: str) -> None:
        _check(self._client.delete(path))

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


# ── Async ─────────────────────────────────────────────────────────────────────

class AsyncTransport:
    def __init__(self, api_key: str, base_url: str, timeout: float):
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers=_headers(api_key),
            timeout=timeout,
        )

    async def get(self, path: str, params: dict | None = None) -> dict:
        return _check(await self._client.get(path, params=params))

    async def post(self, path: str, body: Any = None) -> dict:
        return _check(await self._client.post(path, json=_payload(body) if body is not None else None))

    async def patch(self, path: str, body: Any) -> dict:
        return _check(await self._client.patch(path, json=_payload(body)))

    async def delete(self, path: str) -> None:
        _check(await self._client.delete(path))

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.aclose()
