"""Integration tests for skillhub.router — all endpoints."""

from __future__ import annotations

import json

import pytest

from skillhub.tests.conftest import (
    VALID_SKILL_MD, VALID_SKILL_V2,
    VALID_SKILL_ZIP, VALID_SKILL_V2_ZIP,
    make_skill_zip,
)


# ── Create ──────────────────────────────────────────────────────


class TestCreateSkill:
    def test_success(self, client):
        resp = client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("SKILL.md", VALID_SKILL_MD, "text/markdown")},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Test Skill"
        assert data["slug"] == "test-skill"
        assert data["latest_version"] == "1.0.0"
        assert data["skill_id"].startswith("sk_")
        assert data["content_hash"].startswith("sha256:")
        assert data["owner_id"] == "user_1"

    def test_invalid_format(self, client):
        resp = client.post(
            "/api/skills",
            files={"file": ("SKILL.md", b"no frontmatter here", "text/markdown")},
        )
        assert resp.status_code == 400

    def test_missing_name(self, client):
        content = b"---\nversion: 1.0.0\n---\n# Body"
        resp = client.post(
            "/api/skills",
            files={"file": ("SKILL.md", content, "text/markdown")},
        )
        assert resp.status_code == 400

    def test_file_too_large(self, client):
        # Default limit is 50MB — use a custom client with lower limit to test
        import sqlite3
        from skillhub.tests.conftest import TestDBProvider
        from skillhub.config import SkillHubConfig
        from skillhub.routers import build_router
        from unittest.mock import MagicMock
        from fastapi import FastAPI
        from fastapi.testclient import TestClient as TC

        con = sqlite3.connect(":memory:", check_same_thread=False)
        con.row_factory = sqlite3.Row
        from skillhub.database import SCHEMA_SQL
        con.executescript(SCHEMA_SQL)
        small_config = SkillHubConfig(max_file_size=1000)
        mock_idx = MagicMock()
        mock_idx.add.return_value = [0.1] * 384
        router = build_router(
            db=TestDBProvider(con), s3_client_factory=lambda: MagicMock(),
            s3_bucket="b", config=small_config, search_index=mock_idx,
        )
        app = FastAPI()
        app.include_router(router)
        small_client = TC(app)

        huge = b"---\nname: Big\nversion: 1.0.0\n---\n" + b"x" * 2000
        resp = small_client.post(
            "/api/skills",
            files={"file": ("SKILL.md", huge, "text/markdown")},
        )
        assert resp.status_code == 400
        assert "exceeds" in resp.json()["detail"]
        con.close()

    def test_duplicate_slug(self, client):
        # "code-review" slug already exists in seed data
        content = b"---\nname: Code Review\nversion: 1.0.0\n---\n# Body"
        resp = client.post(
            "/api/skills",
            files={"file": ("SKILL.md", content, "text/markdown")},
        )
        assert resp.status_code == 409


# ── List ────────────────────────────────────────────────────────


class TestListSkills:
    def test_list_all(self, client):
        resp = client.get("/api/skills")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2

    def test_filter_by_tags(self, client):
        resp = client.get("/api/skills?tags=code-review")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["slug"] == "code-review"

    def test_filter_by_role(self, client):
        resp = client.get("/api/skills?role=analyst")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["slug"] == "data-analysis"

    def test_pagination(self, client):
        resp = client.get("/api/skills?limit=1")
        assert resp.status_code == 200
        assert len(resp.json()) == 1

        resp2 = client.get("/api/skills?limit=1&offset=1")
        assert resp2.status_code == 200
        assert len(resp2.json()) == 1
        assert resp.json()[0]["slug"] != resp2.json()[0]["slug"]


# ── Get Detail ──────────────────────────────────────────────────


class TestGetSkill:
    def test_found(self, client):
        resp = client.get("/api/skills/code-review")
        assert resp.status_code == 200
        data = resp.json()
        assert data["slug"] == "code-review"
        assert data["latest_version"] == "1.1.0"

    def test_not_found(self, client):
        resp = client.get("/api/skills/nonexistent")
        assert resp.status_code == 404


# ── Update ──────────────────────────────────────────────────────


class TestUpdateSkill:
    def test_update_description(self, client):
        resp = client.patch(
            "/api/skills/code-review",
            json={"description": "Updated description"},
        )
        assert resp.status_code == 200

    def test_update_tags(self, client):
        resp = client.patch(
            "/api/skills/code-review",
            json={"tags": ["new-tag"]},
        )
        assert resp.status_code == 200

    def test_update_status(self, client):
        resp = client.patch(
            "/api/skills/code-review",
            json={"status": "deprecated"},
        )
        assert resp.status_code == 200

    def test_invalid_status_transition(self, client):
        # First deprecate
        client.patch("/api/skills/code-review", json={"status": "deprecated"})
        # Then try invalid: deprecated → hidden
        resp = client.patch(
            "/api/skills/code-review",
            json={"status": "hidden"},
        )
        assert resp.status_code == 400

    def test_no_fields(self, client):
        resp = client.patch("/api/skills/code-review", json={})
        assert resp.status_code == 400

    def test_not_found(self, client):
        resp = client.patch("/api/skills/nonexistent", json={"description": "x"})
        assert resp.status_code == 404


# ── Delete ──────────────────────────────────────────────────────


class TestDeleteSkill:
    def test_soft_delete(self, client):
        resp = client.delete("/api/skills/code-review")
        assert resp.status_code == 200
        assert "removed" in resp.json()["message"].lower() or "removed" in str(resp.json())

    def test_already_removed(self, client):
        client.delete("/api/skills/code-review")
        resp = client.delete("/api/skills/code-review")
        assert resp.status_code == 400

    def test_not_found(self, client):
        resp = client.delete("/api/skills/nonexistent")
        assert resp.status_code == 404


# ── Versions ────────────────────────────────────────────────────


class TestVersions:
    def test_list_versions(self, client):
        resp = client.get("/api/skills/code-review/versions")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        # Should include tags
        latest = [v for v in data if v["version"] == "1.1.0"]
        assert len(latest) == 1

    def test_get_version(self, client):
        resp = client.get("/api/skills/code-review/versions/1.0.0")
        assert resp.status_code == 200
        assert resp.json()["version"] == "1.0.0"

    def test_version_not_found(self, client):
        resp = client.get("/api/skills/code-review/versions/9.9.9")
        assert resp.status_code == 404

    def test_publish_version(self, client):
        resp = client.post(
            "/api/skills/code-review/versions?changelog=Updated&owner_id=user_1",
            files={"file": ("SKILL.md", VALID_SKILL_V2, "text/markdown")},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["version"] == "2.0.0"
        assert data["changelog"] == "Updated"

    def test_publish_lower_version(self, client):
        content = b"---\nname: Test\nversion: 0.1.0\n---\n# Old"
        resp = client.post(
            "/api/skills/code-review/versions",
            files={"file": ("SKILL.md", content, "text/markdown")},
        )
        assert resp.status_code == 400
        assert "greater" in resp.json()["detail"]


# ── Version Tags ────────────────────────────────────────────────


class TestVersionTags:
    def test_set_tag(self, client):
        resp = client.put(
            "/api/skills/code-review/tags/stable",
            json={"version": "1.0.0"},
        )
        assert resp.status_code == 200

    def test_update_existing_tag(self, client):
        client.put("/api/skills/code-review/tags/stable", json={"version": "1.0.0"})
        resp = client.put(
            "/api/skills/code-review/tags/stable",
            json={"version": "1.1.0"},
        )
        assert resp.status_code == 200

    def test_cannot_set_latest(self, client):
        resp = client.put(
            "/api/skills/code-review/tags/latest",
            json={"version": "1.0.0"},
        )
        assert resp.status_code == 400

    def test_version_not_found(self, client):
        resp = client.put(
            "/api/skills/code-review/tags/stable",
            json={"version": "9.9.9"},
        )
        assert resp.status_code == 404

    def test_delete_tag(self, client):
        client.put("/api/skills/code-review/tags/stable", json={"version": "1.0.0"})
        resp = client.delete("/api/skills/code-review/tags/stable")
        assert resp.status_code == 200

    def test_cannot_delete_latest(self, client):
        resp = client.delete("/api/skills/code-review/tags/latest")
        assert resp.status_code == 400

    def test_delete_nonexistent_tag(self, client):
        resp = client.delete("/api/skills/code-review/tags/nonexistent")
        assert resp.status_code == 404


# ── Stars ───────────────────────────────────────────────────────


class TestStars:
    def test_star(self, client):
        resp = client.post(
            "/api/skills/data-analysis/star",
            json={"user_id": "user_1"},
        )
        assert resp.status_code == 201
        assert resp.json()["starred"] is True

    def test_star_idempotent(self, client):
        # user_2 already starred code-review in seed data
        resp = client.post(
            "/api/skills/code-review/star",
            json={"user_id": "user_2"},
        )
        assert resp.status_code == 201
        assert "Already" in resp.json()["message"]

    def test_unstar(self, client):
        resp = client.delete("/api/skills/code-review/star?user_id=user_2")
        assert resp.status_code == 200
        assert resp.json()["starred"] is False

    def test_unstar_not_starred(self, client):
        resp = client.delete("/api/skills/code-review/star?user_id=user_99")
        assert resp.status_code == 200
        assert resp.json()["starred"] is False


# ── Comments ────────────────────────────────────────────────────


class TestComments:
    def test_list_comments(self, client):
        resp = client.get("/api/skills/code-review/comments")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["content"] == "Great skill!"

    def test_add_comment(self, client):
        resp = client.post(
            "/api/skills/code-review/comments",
            json={"user_id": "user_1", "content": "Nice work!"},
        )
        assert resp.status_code == 201

        # Verify it appears
        comments = client.get("/api/skills/code-review/comments").json()
        assert len(comments) == 2

    def test_empty_comment(self, client):
        resp = client.post(
            "/api/skills/code-review/comments",
            json={"user_id": "user_1", "content": "   "},
        )
        assert resp.status_code == 400

    def test_delete_own_comment(self, client):
        comments = client.get("/api/skills/code-review/comments").json()
        comment_id = comments[0]["id"]
        user_id = comments[0]["user_id"]

        resp = client.delete(f"/api/skills/code-review/comments/{comment_id}?user_id={user_id}")
        assert resp.status_code == 200

    def test_delete_others_comment(self, client):
        comments = client.get("/api/skills/code-review/comments").json()
        comment_id = comments[0]["id"]

        resp = client.delete(f"/api/skills/code-review/comments/{comment_id}?user_id=wrong_user")
        assert resp.status_code == 403


# ── Reports ─────────────────────────────────────────────────────


class TestReports:
    def test_report(self, client):
        resp = client.post(
            "/api/skills/code-review/report",
            json={"reporter_id": "user_3", "reason": "spam", "detail": "Looks spammy"},
        )
        assert resp.status_code == 201

    def test_duplicate_report(self, client):
        client.post(
            "/api/skills/code-review/report",
            json={"reporter_id": "user_3", "reason": "spam"},
        )
        resp = client.post(
            "/api/skills/code-review/report",
            json={"reporter_id": "user_3", "reason": "malicious"},
        )
        assert resp.status_code == 409

    def test_invalid_reason(self, client):
        resp = client.post(
            "/api/skills/code-review/report",
            json={"reporter_id": "user_3", "reason": "invalid_reason"},
        )
        assert resp.status_code == 422  # Pydantic validation

    def test_auto_hide_at_threshold(self, client):
        """3 unique reporters should auto-hide the skill."""
        for i in range(3):
            client.post(
                "/api/skills/data-analysis/report",
                json={"reporter_id": f"reporter_{i}", "reason": "spam"},
            )

        # Skill should now be hidden
        resp = client.get("/api/skills/data-analysis")
        data = resp.json()
        assert data["status"] == "hidden"


# ── Rename ──────────────────────────────────────────────────────


class TestRename:
    def test_rename(self, client):
        resp = client.post(
            "/api/skills/code-review/rename",
            json={"new_slug": "code-review-v2", "owner_id": "user_1"},
        )
        assert resp.status_code == 200
        assert resp.json()["slug"] == "code-review-v2"

    def test_redirect_works(self, client):
        client.post(
            "/api/skills/code-review/rename",
            json={"new_slug": "code-review-v2", "owner_id": "user_1"},
        )
        resp = client.get("/api/skills/code-review", follow_redirects=False)
        assert resp.status_code == 301

    def test_invalid_slug(self, client):
        resp = client.post(
            "/api/skills/code-review/rename",
            json={"new_slug": "INVALID SLUG!", "owner_id": "user_1"},
        )
        assert resp.status_code == 400

    def test_slug_already_exists(self, client):
        resp = client.post(
            "/api/skills/code-review/rename",
            json={"new_slug": "data-analysis", "owner_id": "user_1"},
        )
        assert resp.status_code == 409

    def test_wrong_owner(self, client):
        resp = client.post(
            "/api/skills/code-review/rename",
            json={"new_slug": "new-name", "owner_id": "wrong_user"},
        )
        assert resp.status_code == 403


# ── Duplicates & Merge ──────────────────────────────────────────


class TestDuplicatesAndMerge:
    def test_find_duplicates(self, client):
        resp = client.get("/api/skills/code-review/duplicates")
        assert resp.status_code == 200
        # With mock search index returning empty, should still work
        assert isinstance(resp.json(), list)

    def test_merge(self, client, seeded_db):
        # Both owned by different users — need to match
        # Update both to same owner for test
        seeded_db.execute("UPDATE skills SET owner_id = 'user_1' WHERE skill_id = 'sk_bbb222'")
        seeded_db.commit()

        resp = client.post(
            "/api/skills/data-analysis/merge",
            json={"target_slug": "code-review", "owner_id": "user_1"},
        )
        assert resp.status_code == 200
        assert resp.json()["target_slug"] == "code-review"

    def test_merge_self(self, client):
        resp = client.post(
            "/api/skills/code-review/merge",
            json={"target_slug": "code-review", "owner_id": "user_1"},
        )
        assert resp.status_code == 400

    def test_merge_wrong_owner(self, client):
        resp = client.post(
            "/api/skills/data-analysis/merge",
            json={"target_slug": "code-review", "owner_id": "wrong_user"},
        )
        assert resp.status_code == 403


# ── Download & Verify ───────────────────────────────────────────


class TestDownloadAndVerify:
    def test_download(self, client):
        resp = client.get("/api/skills/code-review/download")
        assert resp.status_code == 200
        assert resp.headers.get("content-type") == "text/markdown; charset=utf-8"
        assert "X-Content-Hash" in resp.headers

    def test_download_specific_version(self, client):
        resp = client.get("/api/skills/code-review/download?version=1.0.0")
        assert resp.status_code == 200

    def test_download_not_found(self, client):
        resp = client.get("/api/skills/code-review/download?version=9.9.9")
        assert resp.status_code == 404

    def test_verify(self, client, mock_s3):
        # Mock S3 to return content matching the stored hash
        mock_s3.get_object.return_value = {
            "Body": type("Body", (), {"read": lambda self: b"test content"})()
        }
        resp = client.get("/api/skills/code-review/verify")
        assert resp.status_code == 200
        data = resp.json()
        assert "valid" in data
        assert "expected" in data
        assert "actual" in data


# ── Scan ────────────────────────────────────────────────────────


class TestScan:
    def test_get_scan(self, client):
        resp = client.get("/api/skills/code-review/scan")
        assert resp.status_code == 200
        data = resp.json()
        assert "version" in data
        assert "scan_status" in data

    def test_get_scan_specific_version(self, client):
        resp = client.get("/api/skills/code-review/scan?version=1.1.0")
        assert resp.status_code == 200

    def test_rescan(self, client):
        resp = client.post("/api/skills/code-review/rescan")
        assert resp.status_code == 200
        data = resp.json()
        assert "scan_result" in data


# ── Bundle Upload ───────────────────────────────────────────────


class TestBundleUpload:
    def test_create_with_zip(self, client):
        resp = client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_ZIP, "application/zip")},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "Test Skill"
        assert data["file_count"] == 3  # SKILL.md + setup.sh + settings.yaml
        assert len(data["files"]) == 3

    def test_create_with_zip_has_files(self, client):
        resp = client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_ZIP, "application/zip")},
        )
        data = resp.json()
        file_paths = [f["file_path"] for f in data["files"]]
        assert "SKILL.md" in file_paths
        assert "scripts/setup.sh" in file_paths
        assert "config/settings.yaml" in file_paths

    def test_bare_skill_md_still_works(self, client):
        resp = client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("SKILL.md", VALID_SKILL_MD, "text/markdown")},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["file_count"] == 1

    def test_zip_with_binary_rejected(self, client):
        bad_zip = make_skill_zip(VALID_SKILL_MD, {"bad.py": b"\x7fELF\x00"})
        resp = client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", bad_zip, "application/zip")},
        )
        assert resp.status_code == 400
        assert "binary" in resp.json()["detail"]

    def test_zip_with_disallowed_ext(self, client):
        bad_zip = make_skill_zip(VALID_SKILL_MD, {"evil.exe": b"not really binary"})
        resp = client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", bad_zip, "application/zip")},
        )
        assert resp.status_code == 400
        assert "disallowed" in resp.json()["detail"]

    def test_publish_version_as_zip(self, client):
        resp = client.post(
            "/api/skills/code-review/versions?changelog=Bundle+update&owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_V2_ZIP, "application/zip")},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["version"] == "2.0.0"
        assert data["file_count"] == 2
        assert len(data["files"]) == 2


# ── Bundle Download ─────────────────────────────────────────────


class TestBundleDownload:
    def test_download_bundle_as_zip(self, client):
        # Upload a bundle
        client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_ZIP, "application/zip")},
        )
        resp = client.get("/api/skills/test-skill/download")
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "application/zip"
        assert "X-Content-Hash" in resp.headers

    def test_download_legacy_as_markdown(self, client):
        # Seed data has legacy single-file versions
        resp = client.get("/api/skills/code-review/download")
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "text/markdown; charset=utf-8"


# ── File Endpoints ──────────────────────────────────────────────


class TestFileEndpoints:
    def test_list_version_files_bundle(self, client):
        client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_ZIP, "application/zip")},
        )
        resp = client.get("/api/skills/test-skill/versions/1.0.0/files")
        assert resp.status_code == 200
        files = resp.json()
        assert len(files) == 3
        assert any(f["file_path"] == "SKILL.md" for f in files)
        assert any(f["file_path"] == "scripts/setup.sh" for f in files)

    def test_list_version_files_legacy(self, client):
        """Legacy single-file version synthesizes SKILL.md entry."""
        resp = client.get("/api/skills/code-review/versions/1.0.0/files")
        assert resp.status_code == 200
        files = resp.json()
        assert len(files) == 1
        assert files[0]["file_path"] == "SKILL.md"

    def test_download_individual_file(self, client):
        client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_ZIP, "application/zip")},
        )
        resp = client.get("/api/skills/test-skill/files/1.0.0/scripts/setup.sh")
        assert resp.status_code == 200

    def test_download_file_not_found(self, client):
        client.post(
            "/api/skills?owner_id=user_1",
            files={"file": ("skill.zip", VALID_SKILL_ZIP, "application/zip")},
        )
        resp = client.get("/api/skills/test-skill/files/1.0.0/nonexistent.txt")
        assert resp.status_code == 404
