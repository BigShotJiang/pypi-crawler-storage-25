"""Unit tests for skillhub.search — mocked fastembed, real numpy."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from skillhub.search import SkillSearchIndex, build_embedding_text, name_similarity


# ── build_embedding_text ────────────────────────────────────────


class TestBuildEmbeddingText:
    def test_basic(self):
        text = build_embedding_text("Code Review", "Review code", ["quality"], "# Body")
        assert "Code Review" in text
        assert "Review code" in text
        assert "quality" in text
        assert "# Body" in text

    def test_max_chars(self):
        text = build_embedding_text("Name", "Desc", [], "x" * 5000, max_chars=100)
        assert len(text) == 100

    def test_empty_tags(self):
        text = build_embedding_text("Name", "Desc", [], "Body")
        assert "Name" in text

    def test_with_supplementary_files(self):
        text = build_embedding_text(
            "Name", "Desc", ["tag"], "Body",
            supplementary_files=[("setup.sh", "#!/bin/bash\necho hello")],
        )
        assert "setup.sh" in text
        assert "echo hello" in text

    def test_supplementary_respects_max_chars(self):
        text = build_embedding_text(
            "Name", "Desc", [], "Body",
            supplementary_files=[("big.py", "x" * 5000)],
            max_chars=100,
        )
        assert len(text) == 100


# ── name_similarity ─────────────────────────────────────────────


class TestNameSimilarity:
    def test_identical(self):
        assert name_similarity("test", "test") == 1.0

    def test_case_insensitive(self):
        assert name_similarity("Test", "test") == 1.0

    def test_different(self):
        sim = name_similarity("abc", "xyz")
        assert sim < 0.5

    def test_similar(self):
        sim = name_similarity("code-review", "code-reviewer")
        assert sim > 0.8


# ── SkillSearchIndex ────────────────────────────────────────────


class TestSkillSearchIndex:
    """Tests with mocked fastembed to avoid model download."""

    @pytest.fixture()
    def mock_embed(self):
        """Patch fastembed.TextEmbedding to return deterministic vectors."""
        dim = 384

        def fake_embed(texts):
            """Return a different but deterministic vector for each text."""
            for i, text in enumerate(texts):
                vec = np.zeros(dim, dtype=np.float32)
                # Use hash of text to seed deterministic values
                seed = hash(text) % 10000
                rng = np.random.RandomState(seed)
                vec = rng.randn(dim).astype(np.float32)
                norm = np.linalg.norm(vec)
                if norm > 0:
                    vec = vec / norm
                yield vec

        mock_model = MagicMock()
        mock_model.embed = fake_embed

        with patch("skillhub.search.SkillSearchIndex._get_model", return_value=mock_model):
            yield mock_model

    def test_add_and_search(self, mock_embed):
        index = SkillSearchIndex()
        index.add("sk_1", "code review guidelines", meta={"name": "Code Review", "slug": "code-review", "downloads": 0})
        index.add("sk_2", "data analysis techniques", meta={"name": "Data Analysis", "slug": "data-analysis", "downloads": 0})

        assert index.size == 2

        results = index.search("code review", top_k=5)
        assert len(results) > 0
        assert all(isinstance(r, tuple) and len(r) == 2 for r in results)

    def test_remove(self, mock_embed):
        index = SkillSearchIndex()
        index.add("sk_1", "test skill")
        assert index.size == 1

        index.remove("sk_1")
        assert index.size == 0

    def test_remove_nonexistent(self, mock_embed):
        index = SkillSearchIndex()
        index.remove("sk_nonexistent")  # should not raise

    def test_search_empty_index(self, mock_embed):
        index = SkillSearchIndex()
        results = index.search("anything")
        assert results == []

    def test_find_duplicates(self, mock_embed):
        index = SkillSearchIndex()
        # Add two very similar texts
        index.add("sk_1", "code review guidelines for agents")
        index.add("sk_2", "code review guidelines for agents")  # identical text
        index.add("sk_3", "completely different topic about cooking")

        dupes = index.find_duplicates("sk_1", threshold=0.5)
        # sk_2 (identical text) should have very high similarity
        assert len(dupes) >= 1

    def test_add_overwrites_existing(self, mock_embed):
        index = SkillSearchIndex()
        index.add("sk_1", "version 1 content")
        assert index.size == 1

        index.add("sk_1", "version 2 content")
        assert index.size == 1  # still 1, not 2

    def test_get_embedding(self, mock_embed):
        index = SkillSearchIndex()
        index.add("sk_1", "test")
        emb = index.get_embedding("sk_1")
        assert emb is not None
        assert len(emb) == 384

    def test_get_embedding_nonexistent(self, mock_embed):
        index = SkillSearchIndex()
        assert index.get_embedding("sk_nonexistent") is None

    def test_hybrid_scoring(self, mock_embed):
        """Verify that exact slug/name matches get a lexical boost."""
        index = SkillSearchIndex()
        index.add("sk_1", "code review", meta={"name": "code review", "slug": "code-review", "downloads": 100})
        index.add("sk_2", "something else", meta={"name": "something else", "slug": "something-else", "downloads": 0})

        results = index.search("code review")
        # sk_1 should score higher due to exact name match + popularity
        if len(results) >= 2:
            assert results[0][0] == "sk_1"
