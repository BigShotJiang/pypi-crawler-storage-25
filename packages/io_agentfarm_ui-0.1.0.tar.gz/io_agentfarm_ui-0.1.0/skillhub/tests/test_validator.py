"""Unit tests for skillhub.validator — pure functions, no I/O."""

from __future__ import annotations

import io
import zipfile

import pytest

from skillhub.schemas import SkillFrontmatter, SkillRequirements
from skillhub.tests.conftest import make_skill_zip
from skillhub.validator import (
    build_s3_key,
    compute_content_hash,
    generate_skill_id,
    generate_slug,
    is_binary_content,
    parse_skill_file,
    scan_content,
    validate_archive,
    validate_file_extension,
    validate_file_size,
    validate_frontmatter,
    validate_slug,
    validate_status_transition,
    validate_version_progression,
)


# ── parse_skill_file ────────────────────────────────────────────


class TestParseSkillFile:
    def test_valid_file(self):
        content = b"---\nname: Test\nversion: 1.0.0\n---\n# Body"
        fm, body = parse_skill_file(content)
        assert fm.name == "Test"
        assert fm.version == "1.0.0"
        assert body == "# Body"

    def test_full_frontmatter(self):
        content = (
            b"---\nname: Full Test\ndescription: A full test\nversion: 2.1.0\n"
            b"tags:\n  - test\n  - example\ntarget_roles:\n  - developer\n"
            b"requires:\n  tools:\n    - git\n  network: true\n---\n# Full"
        )
        fm, body = parse_skill_file(content)
        assert fm.name == "Full Test"
        assert fm.tags == ["test", "example"]
        assert fm.requires.network is True

    def test_missing_opening_delimiter(self):
        with pytest.raises(ValueError, match="must start with '---'"):
            parse_skill_file(b"name: Test\nversion: 1.0.0\n---\n# Body")

    def test_missing_closing_delimiter(self):
        with pytest.raises(ValueError, match="closing '---'"):
            parse_skill_file(b"---\nname: Test\n# Body")

    def test_empty_frontmatter(self):
        with pytest.raises(ValueError, match="empty"):
            parse_skill_file(b"---\n---\n# Body")

    def test_invalid_yaml(self):
        with pytest.raises(ValueError, match="Invalid YAML"):
            parse_skill_file(b"---\n: invalid: yaml: {{\n---\n# Body")

    def test_non_utf8(self):
        with pytest.raises(ValueError, match="UTF-8"):
            parse_skill_file(b"\xff\xfe---\nname: Test\n---\n")

    def test_bom_stripped(self):
        content = "\ufeff---\nname: BOM Test\nversion: 1.0.0\n---\n# Body".encode("utf-8")
        fm, _ = parse_skill_file(content)
        assert fm.name == "BOM Test"


# ── validate_frontmatter ────────────────────────────────────────


class TestValidateFrontmatter:
    def test_valid(self):
        fm = SkillFrontmatter(name="Test Skill", version="1.0.0")
        assert validate_frontmatter(fm) == []

    def test_missing_name(self):
        fm = SkillFrontmatter(name="", version="1.0.0")
        errors = validate_frontmatter(fm)
        assert any("name" in e for e in errors)

    def test_missing_version(self):
        fm = SkillFrontmatter(name="Test", version="")
        errors = validate_frontmatter(fm)
        assert any("version" in e for e in errors)

    def test_invalid_semver(self):
        fm = SkillFrontmatter(name="Test", version="1.0")
        errors = validate_frontmatter(fm)
        assert any("semver" in e for e in errors)

    def test_invalid_semver_alpha(self):
        fm = SkillFrontmatter(name="Test", version="1.0.0-beta")
        errors = validate_frontmatter(fm)
        assert any("semver" in e for e in errors)

    def test_name_too_long(self):
        fm = SkillFrontmatter(name="x" * 201, version="1.0.0")
        errors = validate_frontmatter(fm)
        assert any("200" in e for e in errors)

    def test_invalid_tag(self):
        fm = SkillFrontmatter(name="Test", version="1.0.0", tags=["UPPERCASE"])
        errors = validate_frontmatter(fm)
        assert any("Tag" in e for e in errors)

    def test_invalid_role(self):
        fm = SkillFrontmatter(name="Test", version="1.0.0", target_roles=["Bad-Role"])
        errors = validate_frontmatter(fm)
        assert any("Role" in e for e in errors)


# ── validate_file_size ──────────────────────────────────────────


class TestValidateFileSize:
    def test_within_limit(self):
        validate_file_size(100, 200)  # should not raise

    def test_at_limit(self):
        validate_file_size(200, 200)  # should not raise

    def test_over_limit(self):
        with pytest.raises(ValueError, match="exceeds limit"):
            validate_file_size(201, 200)

    def test_custom_limit(self):
        with pytest.raises(ValueError):
            validate_file_size(1000, 500)


# ── validate_slug ───────────────────────────────────────────────


class TestValidateSlug:
    def test_valid(self):
        assert validate_slug("code-review") == []

    def test_single_char_too_short(self):
        errors = validate_slug("a")
        assert any("at least 2" in e for e in errors)

    def test_too_short_empty(self):
        errors = validate_slug("")
        assert len(errors) > 0

    def test_too_long(self):
        errors = validate_slug("a" * 101)
        assert any("100" in e for e in errors)

    def test_uppercase(self):
        errors = validate_slug("BadSlug")
        assert len(errors) > 0

    def test_leading_hyphen(self):
        errors = validate_slug("-bad")
        assert len(errors) > 0


# ── compute_content_hash ────────────────────────────────────────


class TestComputeContentHash:
    def test_known_value(self):
        h = compute_content_hash(b"hello")
        assert h.startswith("sha256:")
        assert len(h) == 71  # "sha256:" + 64 hex chars

    def test_empty(self):
        h = compute_content_hash(b"")
        assert h.startswith("sha256:")

    def test_deterministic(self):
        assert compute_content_hash(b"test") == compute_content_hash(b"test")


# ── generate_slug ───────────────────────────────────────────────


class TestGenerateSlug:
    def test_simple(self):
        assert generate_slug("Code Review") == "code-review"

    def test_special_chars(self):
        assert generate_slug("Hello, World!") == "hello-world"

    def test_consecutive_hyphens(self):
        assert generate_slug("a   b") == "a-b"

    def test_leading_trailing(self):
        assert generate_slug("  test  ") == "test"

    def test_unicode(self):
        slug = generate_slug("café résumé")
        assert "--" not in slug

    def test_empty(self):
        assert generate_slug("") == "unnamed"


# ── generate_skill_id ──────────────────────────────────────────


class TestGenerateSkillId:
    def test_format(self):
        sid = generate_skill_id()
        assert sid.startswith("sk_")
        assert len(sid) == 15  # "sk_" + 12 hex

    def test_unique(self):
        ids = {generate_skill_id() for _ in range(100)}
        assert len(ids) == 100


# ── validate_version_progression ────────────────────────────────


class TestValidateVersionProgression:
    def test_major_bump(self):
        validate_version_progression("2.0.0", "1.0.0")

    def test_minor_bump(self):
        validate_version_progression("1.1.0", "1.0.0")

    def test_patch_bump(self):
        validate_version_progression("1.0.1", "1.0.0")

    def test_same_version(self):
        with pytest.raises(ValueError, match="must be greater"):
            validate_version_progression("1.0.0", "1.0.0")

    def test_lower_version(self):
        with pytest.raises(ValueError, match="must be greater"):
            validate_version_progression("0.9.0", "1.0.0")

    def test_first_version(self):
        validate_version_progression("0.1.0", "")  # should not raise


# ── validate_status_transition ──────────────────────────────────


class TestValidateStatusTransition:
    def test_active_to_hidden(self):
        validate_status_transition("active", "hidden")

    def test_active_to_deprecated(self):
        validate_status_transition("active", "deprecated")

    def test_active_to_removed(self):
        validate_status_transition("active", "removed")

    def test_removed_to_active(self):
        validate_status_transition("removed", "active")

    def test_invalid_transition(self):
        with pytest.raises(ValueError, match="Cannot transition"):
            validate_status_transition("removed", "hidden")

    def test_deprecated_to_active(self):
        validate_status_transition("deprecated", "active")


# ── build_s3_key ────────────────────────────────────────────────


class TestBuildS3Key:
    def test_format(self):
        key = build_s3_key("skills", "code-review", "1.0.0")
        assert key == "skills/code-review/1.0.0/SKILL.md"


# ── scan_content ────────────────────────────────────────────────


class TestScanContent:
    def test_clean_content(self):
        result = scan_content("# Hello\n\nThis is safe content.", {})
        assert result.risk_score == 0.0
        assert len(result.findings) == 0

    def test_exec_call(self):
        result = scan_content("Use eval('code') to run it.", {})
        assert result.risk_score > 0
        assert any(f.rule == "EXEC_CALL" for f in result.findings)

    def test_shell_cmd(self):
        result = scan_content("Run subprocess.run(['ls'])", {})
        assert any(f.rule == "SHELL_CMD" for f in result.findings)

    def test_file_write(self):
        result = scan_content("open('file', 'w') to write", {})
        assert any(f.rule == "FILE_WRITE" for f in result.findings)

    def test_credential_pattern(self):
        result = scan_content("Use key sk-abcdefghijklmnopqrstuvwxyz1234", {})
        assert any(f.rule == "CREDENTIAL_PATTERN" for f in result.findings)

    def test_aws_key(self):
        result = scan_content("AWS key: AKIAIOSFODNN7EXAMPLE", {})
        assert any(f.rule == "CREDENTIAL_PATTERN" for f in result.findings)

    def test_obfuscated_base64(self):
        long_b64 = "A" * 250
        result = scan_content(f"encoded: {long_b64}", {})
        assert any(f.rule == "OBFUSCATED" for f in result.findings)

    def test_network_undeclared(self):
        result = scan_content("import requests.get(url)", {"requires": {"network": False}})
        assert any(f.rule == "NETWORK_UNDECLARED" for f in result.findings)

    def test_network_declared(self):
        result = scan_content("import requests.get(url)", {"requires": {"network": True}})
        assert not any(f.rule == "NETWORK_UNDECLARED" for f in result.findings)

    def test_excessive_size(self):
        result = scan_content("x" * 60_000, {})
        assert any(f.rule == "EXCESSIVE_SIZE" for f in result.findings)

    def test_risk_score_capped(self):
        # Many findings should cap at 1.0
        evil = "eval('a') exec('b') compile('c') __import__('d')\n" * 20
        result = scan_content(evil, {})
        assert result.risk_score == 1.0

    def test_env_access(self):
        result = scan_content("os.environ['SECRET']", {})
        assert any(f.rule == "ENV_ACCESS" for f in result.findings)


# ── is_binary_content ───────────────────────────────────────────


class TestIsBinaryContent:
    def test_text_content(self):
        assert is_binary_content(b"hello world") is False

    def test_utf8_text(self):
        assert is_binary_content("hello world".encode("utf-8")) is False

    def test_elf_binary(self):
        assert is_binary_content(b"\x7fELF\x01\x01\x01") is True

    def test_pe_binary(self):
        assert is_binary_content(b"MZ\x90\x00\x03") is True

    def test_null_bytes(self):
        assert is_binary_content(b"text\x00binary") is True

    def test_png(self):
        assert is_binary_content(b"\x89PNG\r\n\x1a\n") is True

    def test_zip(self):
        assert is_binary_content(b"PK\x03\x04extra") is True


# ── validate_file_extension ─────────────────────────────────────


class TestValidateFileExtension:
    def test_allowed_extensions(self):
        for ext in [".md", ".py", ".sh", ".yaml", ".json", ".toml", ".txt"]:
            validate_file_extension(f"file{ext}")  # should not raise

    def test_extensionless(self):
        validate_file_extension("Makefile")  # should not raise
        validate_file_extension("Dockerfile")

    def test_disallowed_exe(self):
        with pytest.raises(ValueError, match="disallowed"):
            validate_file_extension("binary.exe")

    def test_disallowed_dll(self):
        with pytest.raises(ValueError, match="disallowed"):
            validate_file_extension("lib.dll")

    def test_disallowed_so(self):
        with pytest.raises(ValueError, match="disallowed"):
            validate_file_extension("lib.so")


# ── validate_archive ────────────────────────────────────────────


class TestValidateArchive:
    def test_valid_archive(self):
        data = make_skill_zip(b"---\nname: T\nversion: 1.0.0\n---\n# B", {
            "setup.sh": b"#!/bin/bash\necho hi\n",
        })
        files = validate_archive(data)
        assert files[0][0] == "SKILL.md"
        assert len(files) == 2

    def test_skill_md_always_first(self):
        data = make_skill_zip(b"---\nname: T\nversion: 1.0.0\n---\n# B", {
            "aaa.txt": b"first alphabetically",
            "zzz.txt": b"last alphabetically",
        })
        files = validate_archive(data)
        assert files[0][0] == "SKILL.md"

    def test_missing_skill_md(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("README.md", b"hello")
        with pytest.raises(ValueError, match="SKILL.md"):
            validate_archive(buf.getvalue())

    def test_binary_file_rejected(self):
        data = make_skill_zip(b"---\nname: T\nversion: 1.0.0\n---\n# B", {
            "bad.py": b"\x7fELF binary content",
        })
        with pytest.raises(ValueError, match="binary"):
            validate_archive(data)

    def test_path_traversal_rejected(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("SKILL.md", b"---\nname: T\nversion: 1.0.0\n---\n# B")
            zf.writestr("../etc/passwd", b"evil")
        with pytest.raises(ValueError, match="Invalid path"):
            validate_archive(buf.getvalue())

    def test_per_file_size_limit(self):
        data = make_skill_zip(b"---\nname: T\nversion: 1.0.0\n---\n# B", {
            "huge.txt": b"x" * 200,
        })
        with pytest.raises(ValueError, match="per-file limit"):
            validate_archive(data, max_per_file=100)

    def test_total_size_limit(self):
        data = make_skill_zip(b"---\nname: T\nversion: 1.0.0\n---\n# B", {
            "big.txt": b"x" * 1000,
        })
        with pytest.raises(ValueError, match="Total archive size"):
            validate_archive(data, max_total_size=100)

    def test_not_a_zip(self):
        with pytest.raises(ValueError, match="valid ZIP"):
            validate_archive(b"this is not a zip file")

    def test_macosx_folder_skipped(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("SKILL.md", b"---\nname: T\nversion: 1.0.0\n---\n# B")
            zf.writestr("__MACOSX/._SKILL.md", b"junk")
        files = validate_archive(buf.getvalue())
        assert len(files) == 1

    def test_ds_store_skipped(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("SKILL.md", b"---\nname: T\nversion: 1.0.0\n---\n# B")
            zf.writestr(".DS_Store", b"junk")
        files = validate_archive(buf.getvalue())
        assert len(files) == 1

    def test_disallowed_extension_in_archive(self):
        data = make_skill_zip(b"---\nname: T\nversion: 1.0.0\n---\n# B", {
            "malware.exe": b"not really",
        })
        with pytest.raises(ValueError, match="disallowed"):
            validate_archive(data)


# ── build_s3_key with filename ──────────────────────────────────


class TestBuildS3KeyFilename:
    def test_custom_filename(self):
        key = build_s3_key("skills", "code-review", "1.0.0", "scripts/setup.sh")
        assert key == "skills/code-review/1.0.0/scripts/setup.sh"

    def test_default_filename(self):
        key = build_s3_key("skills", "code-review", "1.0.0")
        assert key == "skills/code-review/1.0.0/SKILL.md"
