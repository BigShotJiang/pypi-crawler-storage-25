"""Self-contained test fixtures for SkillHub — no host project dependencies."""

from __future__ import annotations

import io
import sqlite3
import time
import zipfile
from contextlib import contextmanager
from typing import Any, Generator
from unittest.mock import MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from skillhub.config import SkillHubConfig
from skillhub.database import DBProvider, SCHEMA_SQL
from skillhub.routers import build_router
from skillhub.search import SkillSearchIndex


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


# ── SQLite test DB provider ─────────────────────────────────────


class TestDBProvider:
    """DBProvider backed by a shared in-memory SQLite connection."""

    def __init__(self, con: sqlite3.Connection) -> None:
        self._con = con

    @contextmanager
    def get_connection(self) -> Generator[Any, None, None]:
        yield self._con

    def placeholder(self) -> str:
        return "?"


# ── ZIP helpers ─────────────────────────────────────────────────


def make_skill_zip(skill_md: bytes, extra_files: dict[str, bytes] | None = None) -> bytes:
    """Create a ZIP archive containing SKILL.md and optional extra files."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("SKILL.md", skill_md)
        if extra_files:
            for path, content in extra_files.items():
                zf.writestr(path, content)
    return buf.getvalue()


# ── Fixtures ────────────────────────────────────────────────────


@pytest.fixture()
def test_db():
    """In-memory SQLite with SkillHub schema."""
    con = sqlite3.connect(":memory:", check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA_SQL)
    yield con
    con.close()


@pytest.fixture()
def seeded_db(test_db):
    """Seed test data: 2 skills, 2 versions, 1 star, 1 comment."""
    now = _now()

    # Skill 1: code-review
    test_db.execute(
        "INSERT INTO skills(skill_id, name, slug, description, tags, target_roles, "
        "requires, owner_id, status, latest_version, scan_status, created_at, updated_at) "
        "VALUES(?, ?, ?, ?, ?, ?, ?, ?, 'active', '1.1.0', 'clean', ?, ?)",
        (
            "sk_aaa111", "Code Review", "code-review",
            "Code review guidelines for agents",
            '["code-review","quality"]', '["reviewer"]',
            '{"tools":["git"],"env_vars":[],"network":false}',
            "user_1", now, now,
        ),
    )

    # Skill 1 versions
    test_db.execute(
        "INSERT INTO skill_versions(skill_id, version, content_hash, s3_key, file_size, "
        "file_count, bundle_size, frontmatter, published_by, embedding, scan_result, created_at) "
        "VALUES(?, '1.0.0', 'sha256:aaa', 'skills/code-review/1.0.0/SKILL.md', 1024, "
        "1, 1024, '{}', 'user_1', '[]', '{}', ?)",
        ("sk_aaa111", now),
    )
    test_db.execute(
        "INSERT INTO skill_versions(skill_id, version, content_hash, s3_key, file_size, "
        "file_count, bundle_size, frontmatter, published_by, embedding, scan_result, created_at) "
        "VALUES(?, '1.1.0', 'sha256:bbb', 'skills/code-review/1.1.0/SKILL.md', 2048, "
        "1, 2048, '{}', 'user_1', '[]', '{\"risk_score\":0.0,\"findings\":[]}', ?)",
        ("sk_aaa111", now),
    )

    # latest tag for skill 1
    test_db.execute(
        "INSERT INTO skill_version_tags(skill_id, tag, version, created_at) VALUES(?, 'latest', '1.1.0', ?)",
        ("sk_aaa111", now),
    )

    # Skill 2: data-analysis
    test_db.execute(
        "INSERT INTO skills(skill_id, name, slug, description, tags, target_roles, "
        "requires, owner_id, status, latest_version, scan_status, created_at, updated_at) "
        "VALUES(?, ?, ?, ?, ?, ?, ?, ?, 'active', '1.0.0', 'clean', ?, ?)",
        (
            "sk_bbb222", "Data Analysis", "data-analysis",
            "Data analysis techniques for agents",
            '["data","analysis"]', '["analyst"]',
            '{"tools":[],"env_vars":[],"network":false}',
            "user_2", now, now,
        ),
    )

    test_db.execute(
        "INSERT INTO skill_versions(skill_id, version, content_hash, s3_key, file_size, "
        "file_count, bundle_size, frontmatter, published_by, embedding, scan_result, created_at) "
        "VALUES(?, '1.0.0', 'sha256:ccc', 'skills/data-analysis/1.0.0/SKILL.md', 512, "
        "1, 512, '{}', 'user_2', '[]', '{}', ?)",
        ("sk_bbb222", now),
    )

    test_db.execute(
        "INSERT INTO skill_version_tags(skill_id, tag, version, created_at) VALUES(?, 'latest', '1.0.0', ?)",
        ("sk_bbb222", now),
    )

    # Star on skill 1
    test_db.execute(
        "INSERT INTO skill_stars(skill_id, user_id, created_at) VALUES('sk_aaa111', 'user_2', ?)",
        (now,),
    )
    test_db.execute("UPDATE skills SET star_count = 1 WHERE skill_id = 'sk_aaa111'")

    # Comment on skill 1
    test_db.execute(
        "INSERT INTO skill_comments(skill_id, user_id, content, created_at, updated_at) "
        "VALUES('sk_aaa111', 'user_2', 'Great skill!', ?, ?)",
        (now, now),
    )

    test_db.commit()
    yield test_db


@pytest.fixture()
def mock_s3():
    """Mock S3 client with in-memory store."""
    store: dict[str, bytes] = {}
    mock_client = MagicMock()

    def put_object(Bucket, Key, Body):
        store[Key] = Body if isinstance(Body, bytes) else Body
        return {}

    def get_object(Bucket, Key):
        data = store.get(Key, b"---\nname: Test\nversion: 1.0.0\n---\n# Test")
        return {"Body": MagicMock(read=lambda: data)}

    mock_client.put_object = MagicMock(side_effect=put_object)
    mock_client.get_object = MagicMock(side_effect=get_object)
    mock_client._store = store  # expose for test assertions
    return mock_client


@pytest.fixture()
def mock_search_index():
    """Mock SkillSearchIndex that doesn't need fastembed."""
    index = MagicMock(spec=SkillSearchIndex)
    index.add.return_value = [0.1] * 384  # fake embedding
    index.search.return_value = []
    index.find_duplicates.return_value = []
    index.remove.return_value = None
    index._skill_meta = {}
    index.size = 0
    return index


@pytest.fixture()
def client(seeded_db, mock_s3, mock_search_index):
    """FastAPI TestClient wired to seeded DB with mocked S3 and search."""
    db_provider = TestDBProvider(seeded_db)
    config = SkillHubConfig()

    router = build_router(
        db=db_provider,
        s3_client_factory=lambda: mock_s3,
        s3_bucket="test-bucket",
        config=config,
        search_index=mock_search_index,
    )

    app = FastAPI()
    app.include_router(router)
    yield TestClient(app)


# ── Helpers ─────────────────────────────────────────────────────


VALID_SKILL_MD = b"""---
name: Test Skill
description: A test skill for unit testing
version: 1.0.0
tags:
  - test
  - example
target_roles:
  - developer
requires:
  tools:
    - git
  env_vars: []
  network: false
---

# Test Skill

This is a test skill for verifying the SkillHub module.
"""

VALID_SKILL_V2 = b"""---
name: Test Skill
description: A test skill for unit testing - updated
version: 2.0.0
tags:
  - test
  - example
target_roles:
  - developer
requires:
  tools:
    - git
  env_vars: []
  network: false
---

# Test Skill v2

Updated test skill content.
"""

VALID_SKILL_ZIP = make_skill_zip(VALID_SKILL_MD, {
    "scripts/setup.sh": b"#!/bin/bash\necho hello\n",
    "config/settings.yaml": b"key: value\n",
})

VALID_SKILL_V2_ZIP = make_skill_zip(VALID_SKILL_V2, {
    "scripts/setup.sh": b"#!/bin/bash\necho updated\n",
})
