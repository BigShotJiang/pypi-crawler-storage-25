"""SkillHub — portable agent skills registry module.

Usage::

    from skillhub import create_skillhub_router, SkillHubConfig

    router = create_skillhub_router(
        db=my_db_provider,
        s3_client_factory=lambda: boto3.client("s3"),
        s3_bucket="my-bucket",
    )
    app.include_router(router)
"""

from __future__ import annotations

from typing import Any, Callable

from fastapi import APIRouter

from skillhub.config import SkillHubConfig
from skillhub.database import DBProvider


def create_skillhub_router(
    db: DBProvider,
    s3_client_factory: Callable[[], Any],
    s3_bucket: str,
    config: SkillHubConfig | None = None,
) -> APIRouter:
    """Build and return a fully-wired SkillHub APIRouter.

    Parameters
    ----------
    db:
        Object implementing the DBProvider protocol (get_connection + placeholder).
    s3_client_factory:
        Callable that returns a boto3 S3 client.
    s3_bucket:
        S3 bucket name for skill file storage.
    config:
        Optional config overrides. Uses defaults if not provided.
    """
    if config is None:
        config = SkillHubConfig()

    from skillhub.search import SkillSearchIndex
    search_index = SkillSearchIndex(config.embedding_model)

    from skillhub.routers import build_router
    return build_router(
        db=db,
        s3_client_factory=s3_client_factory,
        s3_bucket=s3_bucket,
        config=config,
        search_index=search_index,
    )


__all__ = ["create_skillhub_router", "SkillHubConfig", "DBProvider"]
