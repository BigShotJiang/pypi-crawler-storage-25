"""SkillHub database abstraction — protocol-based dependency injection.

The host project implements DBProvider (2 methods) and passes it in.
SkillHub never connects to a database directly.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, ContextManager, Protocol, runtime_checkable


@runtime_checkable
class DBProvider(Protocol):
    """Minimal contract a host project must satisfy."""

    def get_connection(self) -> ContextManager[Any]:
        """Return a context manager that yields a DB connection.

        The connection must support:
          - con.execute(sql, params) → cursor
          - cursor.fetchone() → dict-like row (or None)
          - cursor.fetchall() → list of dict-like rows
          - con.commit()
        """
        ...

    def placeholder(self) -> str:
        """Return the parameter placeholder for the backend.

        '?' for SQLite, '%s' for PostgreSQL.
        """
        ...


def q(sql: str, provider: DBProvider) -> str:
    """Rewrite ``?`` placeholders to the backend's style."""
    ph = provider.placeholder()
    if ph == "?":
        return sql
    return sql.replace("?", ph)


# ── Schema ──────────────────────────────────────────────────────────

SCHEMA_SQL = """
-- Core tables
CREATE TABLE IF NOT EXISTS skills (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL UNIQUE,
    name            TEXT NOT NULL,
    slug            TEXT NOT NULL UNIQUE,
    description     TEXT NOT NULL DEFAULT '',
    tags            TEXT NOT NULL DEFAULT '[]',
    target_roles    TEXT NOT NULL DEFAULT '[]',
    requires        TEXT NOT NULL DEFAULT '{}',
    owner_id        TEXT NOT NULL DEFAULT '',
    workspace_id    TEXT,
    status          TEXT NOT NULL DEFAULT 'active',
    latest_version  TEXT NOT NULL DEFAULT '',
    download_count  INTEGER NOT NULL DEFAULT 0,
    star_count      INTEGER NOT NULL DEFAULT 0,
    report_count    INTEGER NOT NULL DEFAULT 0,
    scan_status     TEXT NOT NULL DEFAULT 'pending',
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS skill_versions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    version         TEXT NOT NULL,
    content_hash    TEXT NOT NULL,
    s3_key          TEXT NOT NULL,
    file_size       INTEGER NOT NULL DEFAULT 0,
    file_count      INTEGER NOT NULL DEFAULT 1,
    bundle_size     INTEGER NOT NULL DEFAULT 0,
    frontmatter     TEXT NOT NULL DEFAULT '{}',
    changelog       TEXT NOT NULL DEFAULT '',
    published_by    TEXT NOT NULL DEFAULT '',
    embedding       TEXT NOT NULL DEFAULT '[]',
    scan_result     TEXT NOT NULL DEFAULT '{}',
    created_at      TEXT NOT NULL,
    UNIQUE(skill_id, version)
);

CREATE TABLE IF NOT EXISTS skill_audit_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    action          TEXT NOT NULL,
    actor_id        TEXT NOT NULL DEFAULT '',
    detail          TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL
);

-- Version tags
CREATE TABLE IF NOT EXISTS skill_version_tags (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    tag             TEXT NOT NULL,
    version         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    UNIQUE(skill_id, tag)
);

-- Community
CREATE TABLE IF NOT EXISTS skill_stars (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    user_id         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    UNIQUE(skill_id, user_id)
);

CREATE TABLE IF NOT EXISTS skill_comments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    user_id         TEXT NOT NULL,
    content         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS skill_reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    reporter_id     TEXT NOT NULL,
    reason          TEXT NOT NULL,
    detail          TEXT NOT NULL DEFAULT '',
    created_at      TEXT NOT NULL,
    UNIQUE(skill_id, reporter_id)
);

-- Files within a skill bundle
CREATE TABLE IF NOT EXISTS skill_files (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id        TEXT NOT NULL,
    version         TEXT NOT NULL,
    file_path       TEXT NOT NULL,
    file_size       INTEGER NOT NULL DEFAULT 0,
    content_hash    TEXT NOT NULL,
    s3_key          TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    UNIQUE(skill_id, version, file_path)
);

-- Rename redirects
CREATE TABLE IF NOT EXISTS skill_redirects (
    old_slug        TEXT PRIMARY KEY,
    new_slug        TEXT NOT NULL,
    created_at      TEXT NOT NULL
);
"""


def ensure_tables(provider: DBProvider) -> None:
    """Create all SkillHub tables if they don't exist."""
    with provider.get_connection() as con:
        # SQLite supports executescript; PostgreSQL does not.
        # Split on semicolons and execute each statement individually.
        for stmt in SCHEMA_SQL.split(";"):
            stmt = stmt.strip()
            if stmt:
                con.execute(q(stmt, provider))
        con.commit()
