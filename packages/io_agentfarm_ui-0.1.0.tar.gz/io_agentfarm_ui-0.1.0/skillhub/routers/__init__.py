"""SkillHub router assembly — wires service into thin route handlers."""

from __future__ import annotations

from typing import Any, Callable

from fastapi import APIRouter

from skillhub.config import SkillHubConfig
from skillhub.search import SkillSearchIndex
from skillhub.service import SkillService

__all__ = ["build_router"]


def build_router(
    db: Any,
    s3_client_factory: Callable[[], Any],
    s3_bucket: str,
    config: SkillHubConfig,
    search_index: SkillSearchIndex,
) -> APIRouter:
    service = SkillService(db, config, search_index, s3_client_factory, s3_bucket)
    router = APIRouter(prefix=config.api_prefix, tags=["skills"])

    from skillhub.routers.skills import register_routes as skills_routes
    from skillhub.routers.versions import register_routes as versions_routes
    from skillhub.routers.community import register_routes as community_routes
    from skillhub.routers.admin import register_routes as admin_routes

    skills_routes(router, service, config)
    versions_routes(router, service)
    community_routes(router, service)
    admin_routes(router, service)

    return router
