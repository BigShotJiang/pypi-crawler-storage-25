"""SkillHub routes — rename, merge, duplicates, scan."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from skillhub.errors import ConflictError, ForbiddenError, NotFoundError, ValidationError
from skillhub.schemas import MergeRequest, RenameRequest
from skillhub.service import SkillService


def register_routes(router: APIRouter, service: SkillService) -> None:

    @router.post("/{slug}/rename")
    def rename_skill(slug: str, body: RenameRequest):
        try:
            return service.rename(slug, body.new_slug, body.owner_id)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ForbiddenError as e:
            raise HTTPException(403, str(e))
        except (ConflictError,) as e:
            raise HTTPException(409, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))

    @router.get("/{slug}/duplicates")
    def find_duplicates(slug: str, threshold: float = Query(0.85)):
        try:
            return service.find_duplicates(slug, threshold)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.post("/{slug}/merge")
    def merge_skill(slug: str, body: MergeRequest):
        try:
            return service.merge(slug, body.target_slug, body.owner_id)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ForbiddenError as e:
            raise HTTPException(403, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))

    @router.get("/{slug}/scan")
    def get_scan(slug: str, version: str | None = Query(None)):
        try:
            return service.get_scan(slug, version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.post("/{slug}/rescan")
    def rescan_skill(slug: str, version: str | None = Query(None)):
        try:
            return service.rescan(slug, version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except RuntimeError as e:
            raise HTTPException(500, str(e))
