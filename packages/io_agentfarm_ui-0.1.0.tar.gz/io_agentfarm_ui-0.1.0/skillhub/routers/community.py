"""SkillHub routes — stars, comments, reports."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from skillhub.errors import ConflictError, ForbiddenError, NotFoundError, ValidationError
from skillhub.schemas import CommentCreate, ReportCreate, StarRequest
from skillhub.service import SkillService


def register_routes(router: APIRouter, service: SkillService) -> None:

    @router.post("/{slug}/star", status_code=201)
    def star_skill(slug: str, body: StarRequest):
        try:
            return service.star(slug, body.user_id)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.delete("/{slug}/star")
    def unstar_skill(slug: str, user_id: str = Query(...)):
        try:
            return service.unstar(slug, user_id)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.get("/{slug}/comments")
    def list_comments(slug: str):
        try:
            return service.list_comments(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.post("/{slug}/comments", status_code=201)
    def add_comment(slug: str, body: CommentCreate):
        try:
            return service.add_comment(slug, body.user_id, body.content)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))

    @router.delete("/{slug}/comments/{comment_id}")
    def delete_comment(slug: str, comment_id: int, user_id: str = Query(...)):
        try:
            return service.delete_comment(slug, comment_id, user_id)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ForbiddenError as e:
            raise HTTPException(403, str(e))

    @router.post("/{slug}/report", status_code=201)
    def report_skill(slug: str, body: ReportCreate):
        try:
            return service.report(slug, body.reporter_id, body.reason, body.detail)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ConflictError as e:
            raise HTTPException(409, str(e))
