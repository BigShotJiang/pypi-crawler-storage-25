"""SkillHub routes — CRUD operations."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from fastapi.responses import JSONResponse

from skillhub.config import SkillHubConfig
from skillhub.errors import ConflictError, NotFoundError, ValidationError
from skillhub.schemas import SkillUpdate
from skillhub.service import SkillService


def register_routes(router: APIRouter, service: SkillService, config: SkillHubConfig) -> None:

    @router.post("", status_code=201)
    async def create_skill(
        file: UploadFile = File(...),
        owner_id: str = Query(""),
        workspace_id: str | None = Query(None),
    ):
        content = await file.read()
        try:
            return service.create_skill(content, owner_id, workspace_id)
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))
        except ConflictError as e:
            raise HTTPException(409, str(e))
        except RuntimeError as e:
            raise HTTPException(500, str(e))

    @router.get("")
    def list_skills(
        q_param: str | None = Query(None, alias="q"),
        tags: str | None = Query(None),
        role: str | None = Query(None),
        status: str = Query("active"),
        workspace_id: str | None = Query(None),
        limit: int = Query(50, ge=1, le=200),
        offset: int = Query(0, ge=0),
    ):
        return service.list_skills(q_param, tags, role, status, workspace_id, limit, offset)

    @router.get("/{slug}")
    def get_skill(slug: str):
        try:
            result = service.get_skill(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        if "_redirect" in result:
            return JSONResponse(status_code=301,
                                headers={"Location": f"{config.api_prefix}/{result['_redirect']}"},
                                content={"redirect": result["_redirect"]})
        return result

    @router.patch("/{slug}")
    def update_skill(slug: str, body: SkillUpdate):
        try:
            return service.update_skill(slug, body.model_dump(exclude_none=True))
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))

    @router.delete("/{slug}")
    def delete_skill(slug: str):
        try:
            return service.delete_skill(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))
