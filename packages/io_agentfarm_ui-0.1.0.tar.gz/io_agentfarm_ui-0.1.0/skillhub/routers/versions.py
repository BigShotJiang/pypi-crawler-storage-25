"""SkillHub routes — versions, tags, download, verify, files."""

from __future__ import annotations

import io
import mimetypes

from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from fastapi.responses import StreamingResponse

from skillhub.errors import ConflictError, NotFoundError, ValidationError
from skillhub.schemas import VersionTagSet
from skillhub.service import SkillService


def register_routes(router: APIRouter, service: SkillService) -> None:

    @router.get("/{slug}/versions")
    def list_versions(slug: str):
        try:
            return service.list_versions(slug)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.get("/{slug}/versions/{version}")
    def get_version(slug: str, version: str):
        try:
            return service.get_version(slug, version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.post("/{slug}/versions", status_code=201)
    async def publish_version(
        slug: str,
        file: UploadFile = File(...),
        changelog: str = Query(""),
        owner_id: str = Query(""),
    ):
        content = await file.read()
        try:
            return service.publish_version(slug, content, changelog, owner_id)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except (ValidationError, ValueError) as e:
            raise HTTPException(400, str(e))
        except ConflictError as e:
            raise HTTPException(409, str(e))
        except RuntimeError as e:
            raise HTTPException(500, str(e))

    @router.get("/{slug}/download")
    def download_skill(slug: str, version: str | None = Query(None), tag: str | None = Query(None)):
        try:
            data, media_type, headers = service.download_skill(slug, version, tag)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except RuntimeError as e:
            raise HTTPException(500, str(e))
        return StreamingResponse(data, media_type=media_type, headers=headers)

    @router.get("/{slug}/versions/{version}/files")
    def list_version_files(slug: str, version: str):
        try:
            return service.list_version_files(slug, version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))

    @router.get("/{slug}/files/{version}/{file_path:path}")
    def download_file(slug: str, version: str, file_path: str):
        try:
            content, content_hash = service.get_file(slug, version, file_path)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except RuntimeError as e:
            raise HTTPException(500, str(e))
        ct, _ = mimetypes.guess_type(file_path)
        return StreamingResponse(io.BytesIO(content), media_type=ct or "text/plain",
                                 headers={"X-Content-Hash": content_hash})

    @router.get("/{slug}/verify")
    def verify_skill(slug: str, version: str | None = Query(None)):
        try:
            return service.verify_skill(slug, version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except RuntimeError as e:
            raise HTTPException(500, str(e))

    @router.put("/{slug}/tags/{tag}")
    def set_version_tag(slug: str, tag: str, body: VersionTagSet):
        """Point a named tag at a specific version."""
        if not tag.strip() or len(tag) > 100:
            raise HTTPException(400, "Tag must be 1-100 characters")
        try:
            return service.set_tag(slug, tag, body.version)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))

    @router.delete("/{slug}/tags/{tag}")
    def delete_version_tag(slug: str, tag: str):
        try:
            return service.delete_tag(slug, tag)
        except NotFoundError as e:
            raise HTTPException(404, str(e))
        except ValidationError as e:
            raise HTTPException(400, str(e))
