"""SkillHub configuration — pure dataclass, no environment variable access.

The host project constructs this with whatever config source it uses
(env vars, YAML, hardcoded values). SkillHub never reads env vars directly.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SkillHubConfig:
    """All tunables for the SkillHub module."""

    # File upload limits
    max_file_size: int = 52_428_800  # 50 MB total archive/file
    max_per_file_size: int = 10_485_760  # 10 MB per individual file in bundle

    # S3 storage prefix for skill files
    s3_prefix: str = "skills"

    # Embedding model name (fastembed-compatible)
    embedding_model: str = "BAAI/bge-small-en-v1.5"

    # Embedding text truncation limit (chars)
    embedding_max_chars: int = 2000

    # Community moderation
    report_auto_hide_threshold: int = 3

    # Security scanner
    scan_flag_threshold: float = 0.7

    # Duplicate detection
    duplicate_threshold: float = 0.85

    # API route prefix (no trailing slash)
    api_prefix: str = "/api/skills"
