"""SkillHub domain exceptions — no FastAPI dependency."""

from __future__ import annotations


class NotFoundError(Exception):
    """Resource not found."""


class ConflictError(Exception):
    """Resource already exists or duplicate content."""


class ForbiddenError(Exception):
    """Insufficient permissions."""


class ValidationError(Exception):
    """Input validation failed."""
