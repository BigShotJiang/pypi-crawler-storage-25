"""SkillHub in-memory vector search engine — fastembed + numpy."""

from __future__ import annotations

import json
import logging
import math
import threading
from difflib import SequenceMatcher
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)


class SkillSearchIndex:
    """In-memory vector index for semantic skill search.

    Uses fastembed for local ONNX-based embeddings and numpy for
    brute-force cosine similarity. Fast enough for <10K skills.
    """

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5") -> None:
        self._model_name = model_name
        self._model: Any = None  # lazy-loaded fastembed.TextEmbedding
        self._lock = threading.Lock()

        # Parallel arrays: _embeddings[i] corresponds to _skill_ids[i]
        self._embeddings: np.ndarray | None = None  # shape (N, dim)
        self._skill_ids: list[str] = []

        # Metadata for hybrid scoring
        self._skill_meta: dict[str, dict[str, Any]] = {}  # skill_id -> {name, slug, downloads}

    def _get_model(self) -> Any:
        """Lazy-load the embedding model on first use."""
        if self._model is None:
            try:
                from fastembed import TextEmbedding
                self._model = TextEmbedding(model_name=self._model_name)
                logger.info("Loaded embedding model: %s", self._model_name)
            except Exception as e:
                logger.warning("Failed to load embedding model: %s", e)
                raise
        return self._model

    def _embed(self, texts: list[str]) -> np.ndarray:
        """Embed a list of texts and return normalized vectors."""
        model = self._get_model()
        embeddings = list(model.embed(texts))
        arr = np.array(embeddings, dtype=np.float32)
        # L2 normalize for cosine similarity via dot product
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        return arr / norms

    def build_from_db(self, db_provider: Any) -> None:
        """Load stored embeddings from the database on startup.

        Reads skill_versions.embedding (JSON arrays) and skill metadata.
        No re-embedding needed — vectors were stored at publish time.
        """
        from skillhub.database import q as db_q

        with self._lock:
            self._skill_ids = []
            self._skill_meta = {}
            vectors: list[list[float]] = []

            with db_provider.get_connection() as con:
                # Get latest version embedding for each active skill
                sql = db_q(
                    "SELECT s.skill_id, s.name, s.slug, s.download_count, "
                    "sv.embedding "
                    "FROM skills s "
                    "JOIN skill_versions sv ON s.skill_id = sv.skill_id "
                    "  AND s.latest_version = sv.version "
                    "WHERE s.status IN ('active', 'deprecated')",
                    db_provider,
                )
                rows = con.execute(sql).fetchall()

            for row in rows:
                skill_id = row["skill_id"]
                emb_json = row["embedding"]
                if not emb_json or emb_json == "[]":
                    continue

                try:
                    vec = json.loads(emb_json)
                    if not vec or not isinstance(vec, list):
                        continue
                except (json.JSONDecodeError, TypeError):
                    continue

                self._skill_ids.append(skill_id)
                vectors.append(vec)
                self._skill_meta[skill_id] = {
                    "name": row["name"],
                    "slug": row["slug"],
                    "downloads": row["download_count"],
                }

            if vectors:
                self._embeddings = np.array(vectors, dtype=np.float32)
                # Normalize
                norms = np.linalg.norm(self._embeddings, axis=1, keepdims=True)
                norms = np.where(norms == 0, 1, norms)
                self._embeddings = self._embeddings / norms
                logger.info("Loaded %d skill embeddings into search index", len(vectors))
            else:
                self._embeddings = None
                logger.info("No skill embeddings found in database")

    def add(self, skill_id: str, text: str, meta: dict[str, Any] | None = None) -> list[float]:
        """Embed text and add to the index. Returns the embedding vector.

        Called on skill publish. The returned vector should be stored in DB
        for persistence across restarts.
        """
        vec = self._embed([text])[0]

        with self._lock:
            # Remove existing entry if present (version update)
            self._remove_unlocked(skill_id)

            self._skill_ids.append(skill_id)
            if self._embeddings is not None:
                self._embeddings = np.vstack([self._embeddings, vec.reshape(1, -1)])
            else:
                self._embeddings = vec.reshape(1, -1)

            if meta:
                self._skill_meta[skill_id] = meta

        return vec.tolist()

    def remove(self, skill_id: str) -> None:
        """Remove a skill from the index."""
        with self._lock:
            self._remove_unlocked(skill_id)

    def _remove_unlocked(self, skill_id: str) -> None:
        """Remove without acquiring the lock (caller holds it)."""
        if skill_id not in self._skill_ids:
            return
        idx = self._skill_ids.index(skill_id)
        self._skill_ids.pop(idx)
        self._skill_meta.pop(skill_id, None)
        if self._embeddings is not None and len(self._embeddings) > 0:
            self._embeddings = np.delete(self._embeddings, idx, axis=0)
            if len(self._embeddings) == 0:
                self._embeddings = None

    def search(
        self,
        query: str,
        top_k: int = 10,
        skill_meta_lookup: dict[str, dict[str, Any]] | None = None,
    ) -> list[tuple[str, float]]:
        """Semantic search with hybrid scoring.

        Returns list of (skill_id, score) tuples, sorted by score descending.
        """
        if self._embeddings is None or len(self._skill_ids) == 0:
            return []

        query_vec = self._embed([query])[0]

        with self._lock:
            if self._embeddings is None:
                return []

            # Cosine similarity via dot product (vectors are normalized)
            similarities = self._embeddings @ query_vec

            # Build scored results with hybrid scoring
            results: list[tuple[str, float]] = []
            max_downloads = 1.0

            # Find max downloads for normalization
            for sid in self._skill_ids:
                meta = self._skill_meta.get(sid, {})
                dl = meta.get("downloads", 0)
                if dl > 0:
                    max_downloads = max(max_downloads, math.log1p(dl))

            query_lower = query.lower().strip()

            for i, skill_id in enumerate(self._skill_ids):
                vector_score = float(similarities[i])
                meta = self._skill_meta.get(skill_id, {})
                name = meta.get("name", "").lower()
                slug = meta.get("slug", "").lower()
                downloads = meta.get("downloads", 0)

                # Lexical score
                lexical = 0.0
                if query_lower == slug:
                    lexical = 1.0
                elif slug.startswith(query_lower):
                    lexical = 0.8
                elif query_lower == name:
                    lexical = 1.0
                elif name.startswith(query_lower):
                    lexical = 0.6
                elif query_lower in slug or query_lower in name:
                    lexical = 0.3

                # Popularity score (normalized)
                popularity = math.log1p(downloads) / max_downloads if downloads > 0 else 0.0

                # Hybrid: vector 70% + lexical 20% + popularity 10%
                final_score = vector_score * 0.7 + lexical * 0.2 + popularity * 0.1
                results.append((skill_id, final_score))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]

    def find_duplicates(
        self, skill_id: str, threshold: float = 0.85
    ) -> list[tuple[str, float]]:
        """Find skills with embedding similarity above threshold.

        Returns list of (other_skill_id, similarity) tuples.
        """
        if self._embeddings is None or skill_id not in self._skill_ids:
            return []

        with self._lock:
            idx = self._skill_ids.index(skill_id)
            query_vec = self._embeddings[idx]
            similarities = self._embeddings @ query_vec

            results: list[tuple[str, float]] = []
            for i, sid in enumerate(self._skill_ids):
                if sid == skill_id:
                    continue
                sim = float(similarities[i])
                if sim >= threshold:
                    results.append((sid, sim))

        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def get_embedding(self, skill_id: str) -> list[float] | None:
        """Get the stored embedding for a skill (for persistence)."""
        with self._lock:
            if skill_id not in self._skill_ids or self._embeddings is None:
                return None
            idx = self._skill_ids.index(skill_id)
            return self._embeddings[idx].tolist()

    def get_meta(self, skill_id: str) -> dict[str, Any]:
        """Thread-safe access to skill metadata."""
        with self._lock:
            return self._skill_meta.get(skill_id, {}).copy()

    def update_meta(self, skill_id: str, **updates: Any) -> None:
        """Thread-safe update of skill metadata."""
        with self._lock:
            if skill_id in self._skill_meta:
                self._skill_meta[skill_id].update(updates)

    @property
    def size(self) -> int:
        """Number of skills in the index."""
        return len(self._skill_ids)


def build_embedding_text(
    name: str,
    description: str,
    tags: list[str],
    body: str,
    supplementary_files: list[tuple[str, str]] | None = None,
    max_chars: int = 2000,
) -> str:
    """Build the text to embed for a skill.

    Concatenates metadata, body, and optionally supplementary file content,
    capped at max_chars.
    """
    parts = [name, description]
    if tags:
        parts.append(" ".join(tags))
    parts.append(body)
    if supplementary_files:
        for file_path, file_content in supplementary_files:
            parts.append(f"{file_path}: {file_content[:200]}")
    text = "\n\n".join(p for p in parts if p)
    return text[:max_chars]


def name_similarity(a: str, b: str) -> float:
    """Compute name similarity using SequenceMatcher (0.0-1.0)."""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()
