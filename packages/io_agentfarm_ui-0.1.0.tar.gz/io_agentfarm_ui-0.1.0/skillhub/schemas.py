"""SkillHub Pydantic models — request/response schemas."""

from __future__ import annotations

from pydantic import BaseModel, Field
from typing import Any


# ── Skill content models ────────────────────────────────────────────


class SkillRequirements(BaseModel):
    """Declared runtime dependencies (sandboxing markers)."""
    tools: list[str] = Field(default_factory=list)
    env_vars: list[str] = Field(default_factory=list)
    network: bool = False


class SkillFrontmatter(BaseModel):
    """Parsed YAML frontmatter from a SKILL.md file."""
    name: str
    description: str = ""
    version: str
    tags: list[str] = Field(default_factory=list)
    target_roles: list[str] = Field(default_factory=list)
    requires: SkillRequirements = Field(default_factory=SkillRequirements)
    config: dict[str, Any] = Field(default_factory=dict)


# ── File models ─────────────────────────────────────────────────────


class SkillFileInfo(BaseModel):
    """Metadata for a single file within a skill bundle."""
    file_path: str
    file_size: int = 0
    content_hash: str = ""
    s3_key: str = ""


# ── Response models ─────────────────────────────────────────────────


class SkillSummary(BaseModel):
    """Lightweight skill info for list endpoints."""
    skill_id: str
    slug: str
    name: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    target_roles: list[str] = Field(default_factory=list)
    status: str = "active"
    latest_version: str = ""
    download_count: int = 0
    star_count: int = 0
    report_count: int = 0
    scan_status: str = "pending"
    owner_id: str = ""
    workspace_id: str | None = None
    created_at: str = ""
    updated_at: str = ""


class SkillDetail(SkillSummary):
    """Full skill info including latest version details."""
    requires: dict[str, Any] = Field(default_factory=dict)
    content_hash: str = ""
    s3_key: str = ""
    file_size: int = 0
    file_count: int = 1
    frontmatter: dict[str, Any] = Field(default_factory=dict)
    changelog: str = ""
    files: list[SkillFileInfo] = Field(default_factory=list)


class VersionSummary(BaseModel):
    """Version info for list endpoints."""
    version: str
    content_hash: str
    file_size: int = 0
    file_count: int = 1
    changelog: str = ""
    published_by: str = ""
    scan_result: dict[str, Any] = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)
    created_at: str = ""


class VersionDetail(VersionSummary):
    """Full version info including frontmatter."""
    skill_id: str = ""
    s3_key: str = ""
    frontmatter: dict[str, Any] = Field(default_factory=dict)
    files: list[SkillFileInfo] = Field(default_factory=list)


# ── Request models ──────────────────────────────────────────────────


class SkillUpdate(BaseModel):
    """PATCH request body for updating mutable skill metadata."""
    status: str | None = None
    tags: list[str] | None = None
    description: str | None = None
    target_roles: list[str] | None = None


class VersionTagSet(BaseModel):
    """PUT request body for setting a version tag."""
    version: str


class CommentCreate(BaseModel):
    """POST request body for adding a comment."""
    content: str
    user_id: str


class CommentOut(BaseModel):
    """Comment response model."""
    id: int
    skill_id: str
    user_id: str
    content: str
    created_at: str
    updated_at: str


class ReportCreate(BaseModel):
    """POST request body for reporting a skill."""
    reason: str = Field(..., pattern=r"^(inappropriate|malicious|duplicate|spam|other)$")
    detail: str = ""
    reporter_id: str


class RenameRequest(BaseModel):
    """POST request body for renaming a skill."""
    new_slug: str
    owner_id: str = ""


class MergeRequest(BaseModel):
    """POST request body for merging a skill into another."""
    target_slug: str
    owner_id: str = ""


class StarRequest(BaseModel):
    """POST request body for starring a skill."""
    user_id: str


# ── Security scanner models ────────────────────────────────────────


class SecurityFinding(BaseModel):
    """A single finding from the security scanner."""
    rule: str
    severity: str  # low, medium, high
    message: str
    line: int | None = None
    snippet: str = ""


class ScanResult(BaseModel):
    """Aggregate scan result for a skill version."""
    risk_score: float = 0.0
    findings: list[SecurityFinding] = Field(default_factory=list)


# ── Duplicate detection ────────────────────────────────────────────


class DuplicateCandidate(BaseModel):
    """A potential duplicate found by search or name similarity."""
    skill_id: str
    slug: str
    name: str
    similarity: float
    match_type: str  # "embedding" or "name"
