"""SkillHub validation and security scanning — pure functions, no I/O."""

from __future__ import annotations

import hashlib
import io
import os
import re
import secrets
import zipfile
from typing import Any

import yaml

from skillhub.schemas import (
    ScanResult,
    SecurityFinding,
    SkillFrontmatter,
    SkillRequirements,
)


# ── Parsing ─────────────────────────────────────────────────────────


def parse_skill_file(content: bytes) -> tuple[SkillFrontmatter, str]:
    """Parse a SKILL.md file into frontmatter + markdown body.

    The file must start with ``---``, contain YAML frontmatter,
    then another ``---``, followed by the markdown body.

    Raises ValueError on format or parsing errors.
    """
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("File must be valid UTF-8 text")

    text = text.lstrip("\ufeff")  # strip BOM

    if not text.startswith("---"):
        raise ValueError("SKILL.md must start with '---' (YAML frontmatter delimiter)")

    # Split on the second '---'
    parts = text.split("---", 2)
    if len(parts) < 3:
        raise ValueError("SKILL.md must contain opening and closing '---' delimiters")

    yaml_block = parts[1].strip()
    body = parts[2].strip()

    if not yaml_block:
        raise ValueError("YAML frontmatter is empty")

    try:
        data = yaml.safe_load(yaml_block)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in frontmatter: {e}")

    if not isinstance(data, dict):
        raise ValueError("YAML frontmatter must be a mapping (key-value pairs)")

    # Build SkillFrontmatter from parsed data
    requires_data = data.get("requires", {})
    if isinstance(requires_data, dict):
        requires = SkillRequirements(**requires_data)
    else:
        requires = SkillRequirements()

    try:
        fm = SkillFrontmatter(
            name=data.get("name", ""),
            description=data.get("description", ""),
            version=data.get("version", ""),
            tags=data.get("tags", []),
            target_roles=data.get("target_roles", []),
            requires=requires,
            config=data.get("config", {}),
        )
    except Exception as e:
        raise ValueError(f"Invalid frontmatter fields: {e}")

    return fm, body


# ── Validation ──────────────────────────────────────────────────────

_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$")
_SAFE_CHARS_RE = re.compile(r"^[\w\s\-.,!?()]+$", re.UNICODE)
_USER_ID_RE = re.compile(r"^[a-zA-Z0-9._@\-]+$")

# Maximum lengths for text fields
MAX_USER_ID_LENGTH = 255
MAX_COMMENT_LENGTH = 10_000
MAX_CHANGELOG_LENGTH = 5_000
MAX_TAG_NAME_LENGTH = 50


def validate_user_id(user_id: str) -> None:
    """Validate a user/owner ID. Raises ValueError if invalid."""
    if not user_id:
        return  # empty is allowed (anonymous)
    if len(user_id) > MAX_USER_ID_LENGTH:
        raise ValueError(f"User ID must be {MAX_USER_ID_LENGTH} characters or fewer")
    if not _USER_ID_RE.match(user_id):
        raise ValueError("User ID contains invalid characters")


def validate_comment_content(content: str) -> None:
    """Validate comment content. Raises ValueError if invalid."""
    stripped = content.strip()
    if not stripped:
        raise ValueError("Comment cannot be empty")
    if len(stripped) > MAX_COMMENT_LENGTH:
        raise ValueError(f"Comment must be {MAX_COMMENT_LENGTH:,} characters or fewer")


def escape_like_pattern(value: str) -> str:
    """Escape SQL LIKE wildcards for safe pattern matching."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def validate_frontmatter(fm: SkillFrontmatter) -> list[str]:
    """Validate frontmatter fields. Returns a list of error messages (empty = valid)."""
    errors: list[str] = []

    if not fm.name or not fm.name.strip():
        errors.append("'name' is required")
    elif len(fm.name) > 200:
        errors.append("'name' must be 200 characters or fewer")
    elif not _SAFE_CHARS_RE.match(fm.name):
        errors.append("'name' contains invalid characters")

    if not fm.version:
        errors.append("'version' is required")
    elif not _SEMVER_RE.match(fm.version):
        errors.append(f"'version' must be semver (major.minor.patch), got '{fm.version}'")

    for tag in fm.tags:
        if not re.match(r"^[a-z0-9][a-z0-9-]*$", tag):
            errors.append(f"Tag '{tag}' must be lowercase alphanumeric with hyphens")
        if len(tag) > 50:
            errors.append(f"Tag '{tag}' exceeds 50 characters")

    for role in fm.target_roles:
        if not re.match(r"^[a-z_][a-z0-9_]*$", role):
            errors.append(f"Role '{role}' must be lowercase with underscores")

    return errors


def validate_file_size(size: int, max_bytes: int = 52_428_800) -> None:
    """Raise ValueError if file exceeds the limit."""
    if size > max_bytes:
        raise ValueError(
            f"File size {size:,} bytes exceeds limit of {max_bytes:,} bytes"
        )


def validate_slug(slug: str) -> list[str]:
    """Validate a slug string. Returns error messages."""
    errors: list[str] = []
    if len(slug) < 2:
        errors.append("Slug must be at least 2 characters")
    if len(slug) > 100:
        errors.append("Slug must be 100 characters or fewer")
    if not _SLUG_RE.match(slug):
        errors.append("Slug must be lowercase alphanumeric with hyphens, no leading/trailing hyphens")
    return errors


def validate_version_progression(new_version: str, current_latest: str) -> None:
    """Raise ValueError if new_version is not strictly greater than current_latest."""
    if not current_latest:
        return  # first version, anything goes

    def _parse(v: str) -> tuple[int, ...]:
        return tuple(int(x) for x in v.split("."))

    try:
        new = _parse(new_version)
        cur = _parse(current_latest)
    except (ValueError, AttributeError):
        raise ValueError(f"Cannot compare versions: '{new_version}' vs '{current_latest}'")

    if new <= cur:
        raise ValueError(
            f"New version '{new_version}' must be greater than current '{current_latest}'"
        )


def validate_status_transition(current: str, target: str) -> None:
    """Raise ValueError if the status transition is not allowed."""
    allowed: dict[str, set[str]] = {
        "active": {"hidden", "deprecated", "removed"},
        "hidden": {"active", "deprecated", "removed"},
        "deprecated": {"active", "removed"},
        "removed": {"active"},  # restore
    }
    valid = allowed.get(current, set())
    if target not in valid:
        raise ValueError(
            f"Cannot transition from '{current}' to '{target}'. "
            f"Allowed: {sorted(valid)}"
        )


# ── Generators ──────────────────────────────────────────────────────


def generate_slug(name: str) -> str:
    """Convert a skill name to a URL-safe slug."""
    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)  # replace non-alphanum with hyphens
    slug = re.sub(r"-+", "-", slug)           # collapse consecutive hyphens
    slug = slug.strip("-")                    # strip leading/trailing hyphens
    return slug or "unnamed"


def generate_skill_id() -> str:
    """Generate a unique skill identifier."""
    return f"sk_{secrets.token_hex(6)}"


def compute_content_hash(content: bytes) -> str:
    """Compute SHA-256 hash of raw bytes."""
    return f"sha256:{hashlib.sha256(content).hexdigest()}"


def build_s3_key(prefix: str, slug: str, version: str, filename: str = "SKILL.md") -> str:
    """Build the S3 object key for a skill file."""
    return f"{prefix}/{slug}/{version}/{filename}"


def build_s3_prefix(prefix: str, slug: str, version: str) -> str:
    """Build the S3 key prefix for a skill version bundle."""
    return f"{prefix}/{slug}/{version}/"


# ── Archive / Binary validation ────────────────────────────────────

ALLOWED_TEXT_EXTENSIONS: set[str] = {
    ".md", ".py", ".sh", ".bash", ".zsh",
    ".yaml", ".yml", ".json", ".toml", ".txt",
    ".cfg", ".ini", ".sql", ".html", ".css",
    ".js", ".ts", ".jsx", ".tsx",
    ".xml", ".csv", ".env", ".conf",
    ".r", ".rb", ".go", ".java", ".kt",
    ".c", ".h", ".cpp", ".hpp", ".rs",
    ".ps1", ".bat", ".cmd",
    "",  # extensionless files (Makefile, Dockerfile, etc.)
}

# Magic bytes for common binary formats
_BINARY_MAGIC: list[bytes] = [
    b"\x7fELF",          # ELF (Linux executables)
    b"MZ",               # PE (Windows executables)
    b"\xfe\xed\xfa",     # Mach-O (32-bit)
    b"\xcf\xfa\xed\xfe", # Mach-O (64-bit, little-endian)
    b"\xca\xfe\xba\xbe", # Java class / Mach-O fat binary
    b"PK\x03\x04",       # ZIP (reject nested archives)
    b"\x89PNG",           # PNG
    b"\xff\xd8\xff",      # JPEG
    b"GIF8",              # GIF
    b"RIFF",              # WAV/AVI
    b"\x1f\x8b",          # gzip
    b"BZ",                # bzip2
    b"\xfd7zXZ",          # xz
    b"Rar!",              # RAR
]

_SKIP_PREFIXES = ("__MACOSX/", ".")
_SKIP_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}


def is_binary_content(data: bytes) -> bool:
    """Return True if data appears to be binary content."""
    for magic in _BINARY_MAGIC:
        if data.startswith(magic):
            return True
    # Null bytes in first 8KB are a strong binary indicator
    sample = data[:8192]
    if b"\x00" in sample:
        return True
    return False


def validate_file_extension(file_path: str) -> None:
    """Raise ValueError if the file extension is not in the allow-list."""
    name = os.path.basename(file_path).lower()
    _, ext = os.path.splitext(name)
    if ext not in ALLOWED_TEXT_EXTENSIONS:
        raise ValueError(
            f"File '{file_path}' has disallowed extension '{ext}'. "
            f"Only text-based files are permitted."
        )


def validate_archive(
    data: bytes,
    max_total_size: int = 52_428_800,
    max_per_file: int = 10_485_760,
) -> list[tuple[str, bytes]]:
    """Validate and extract files from a ZIP archive.

    Returns list of (relative_path, content) tuples.
    SKILL.md is always first in the returned list.

    Raises ValueError on any validation failure.
    """
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ValueError("Upload must be a valid ZIP archive")

    files: list[tuple[str, bytes]] = []
    total_size = 0
    found_skill_md = False

    for info in zf.infolist():
        if info.is_dir():
            continue
        path = info.filename

        # Security: reject path traversal
        if ".." in path or path.startswith("/"):
            raise ValueError(f"Invalid path in archive: '{path}'")

        # Skip OS junk
        basename = os.path.basename(path)
        if basename in _SKIP_NAMES:
            continue
        if any(path.startswith(p) for p in _SKIP_PREFIXES):
            continue

        # Per-file size check
        if info.file_size > max_per_file:
            raise ValueError(
                f"File '{path}' is {info.file_size:,} bytes, "
                f"exceeds per-file limit of {max_per_file:,} bytes"
            )
        total_size += info.file_size
        if total_size > max_total_size:
            raise ValueError(
                f"Total archive size exceeds limit of {max_total_size:,} bytes"
            )

        # Extension check
        validate_file_extension(path)

        # Read and check binary content
        content = zf.read(info.filename)
        if is_binary_content(content):
            raise ValueError(
                f"File '{path}' appears to be binary. "
                f"Only text-based files are allowed in skill bundles."
            )

        if path == "SKILL.md" or path.endswith("/SKILL.md") and path.count("/") == 0:
            found_skill_md = True
            files.insert(0, ("SKILL.md", content))
        else:
            files.append((path, content))

    if not found_skill_md:
        raise ValueError("Archive must contain SKILL.md at the root level")

    return files


# ── Security Scanner ───────────────────────────────────────────────

# Severity weights for risk score calculation
_SEVERITY_WEIGHT = {"high": 0.4, "medium": 0.2, "low": 0.05}

# Scanner rules: (rule_id, severity, pattern, message)
_SCAN_RULES: list[tuple[str, str, re.Pattern[str], str]] = [
    (
        "EXEC_CALL",
        "high",
        re.compile(r"\b(eval|exec|compile|__import__)\s*\(", re.IGNORECASE),
        "Dynamic code execution detected",
    ),
    (
        "SHELL_CMD",
        "high",
        re.compile(
            r"\b(subprocess|os\.system|os\.popen)\b|`[^`]+`|\$\([^)]+\)",
            re.IGNORECASE,
        ),
        "Shell command execution detected",
    ),
    (
        "FILE_WRITE",
        "medium",
        re.compile(
            r"""open\s*\([^)]*['"][wa]['"]|shutil\.rmtree|os\.remove|os\.unlink""",
            re.IGNORECASE,
        ),
        "File write/delete operation detected",
    ),
    (
        "OBFUSCATED",
        "high",
        re.compile(
            r"[A-Za-z0-9+/]{200,}={0,2}"  # base64 blocks > 200 chars
            r"|(?:0x[0-9a-fA-F]{2}[\s,]*){50,}"  # hex sequences > 100 chars
            r"|\\x[0-9a-fA-F]{2}(?:\\x[0-9a-fA-F]{2}){49,}",  # \x hex > 50 pairs
        ),
        "Potentially obfuscated content detected",
    ),
    (
        "CREDENTIAL_PATTERN",
        "high",
        re.compile(
            r"\b(?:sk-[a-zA-Z0-9]{20,})"     # OpenAI keys
            r"|(?:ghp_[a-zA-Z0-9]{36,})"      # GitHub PATs
            r"|(?:AKIA[A-Z0-9]{16})"           # AWS access keys
            r"|(?:password\s*[:=]\s*['\"][^'\"]{8,}['\"])",  # password assignments
            re.IGNORECASE,
        ),
        "Potential credential or secret detected",
    ),
    (
        "ENV_ACCESS",
        "medium",
        re.compile(
            r"\b(?:os\.environ|os\.getenv)\s*[\[(]",
            re.IGNORECASE,
        ),
        "Environment variable access detected",
    ),
]


def scan_content(body: str, frontmatter: dict[str, Any]) -> ScanResult:
    """Run the built-in security scanner on skill content.

    Returns a ScanResult with risk_score (0.0-1.0) and findings list.
    """
    findings: list[SecurityFinding] = []
    lines = body.split("\n")

    # Rule-based scanning
    for rule_id, severity, pattern, message in _SCAN_RULES:
        for line_num, line in enumerate(lines, 1):
            for match in pattern.finditer(line):
                findings.append(SecurityFinding(
                    rule=rule_id,
                    severity=severity,
                    message=message,
                    line=line_num,
                    snippet=match.group(0)[:100],
                ))

    # NETWORK_UNDECLARED: network usage when requires.network is false
    requires = frontmatter.get("requires", {})
    if not (isinstance(requires, dict) and requires.get("network", False)):
        network_pattern = re.compile(
            r"\b(?:requests\.|urllib\.|http\.client|socket\.)\b", re.IGNORECASE
        )
        for line_num, line in enumerate(lines, 1):
            for match in network_pattern.finditer(line):
                findings.append(SecurityFinding(
                    rule="NETWORK_UNDECLARED",
                    severity="medium",
                    message="Network access used but requires.network is not true",
                    line=line_num,
                    snippet=match.group(0)[:100],
                ))

    # EXCESSIVE_SIZE check
    if len(body) > 50_000:
        findings.append(SecurityFinding(
            rule="EXCESSIVE_SIZE",
            severity="low",
            message=f"Skill body is unusually large ({len(body):,} chars)",
        ))

    # Calculate risk score
    risk_score = 0.0
    for f in findings:
        risk_score += _SEVERITY_WEIGHT.get(f.severity, 0.0)
    risk_score = min(risk_score, 1.0)

    return ScanResult(risk_score=risk_score, findings=findings)
