"""SkillHub service layer — all DB operations and business logic.

No FastAPI imports. Raises domain exceptions (errors.py) instead of HTTPException.
"""

from __future__ import annotations

import io
import json
import logging
import zipfile
from typing import Any, Callable

from skillhub.config import SkillHubConfig
from skillhub.database import DBProvider, q
from skillhub.errors import ConflictError, ForbiddenError, NotFoundError, ValidationError
from skillhub.helpers import now, parse_json_field, row_to_dict
from skillhub.schemas import SkillFileInfo
from skillhub.search import SkillSearchIndex, build_embedding_text, name_similarity
from skillhub.validator import (
    build_s3_key,
    compute_content_hash,
    escape_like_pattern,
    generate_skill_id,
    generate_slug,
    parse_skill_file,
    scan_content,
    validate_archive,
    validate_comment_content,
    validate_file_size,
    validate_frontmatter,
    validate_slug,
    validate_status_transition,
    validate_user_id,
    validate_version_progression,
)

logger = logging.getLogger(__name__)


class SkillService:
    """Encapsulates all SkillHub business logic and DB operations."""

    def __init__(
        self,
        db: DBProvider,
        config: SkillHubConfig,
        search_index: SkillSearchIndex,
        s3_client_factory: Callable[[], Any],
        s3_bucket: str,
    ) -> None:
        self.db = db
        self.config = config
        self.search_index = search_index
        self.s3_client_factory = s3_client_factory
        self.s3_bucket = s3_bucket

    # ── Internal helpers ─────────────────────────────────────────

    def _resolve_slug(self, slug: str, con: Any) -> str:
        row = con.execute(q("SELECT slug FROM skills WHERE slug = ?", self.db), (slug,)).fetchone()
        if row:
            return slug
        redirect = con.execute(
            q("SELECT new_slug FROM skill_redirects WHERE old_slug = ?", self.db), (slug,)
        ).fetchone()
        if redirect:
            return row_to_dict(redirect)["new_slug"]
        return slug

    def _get_or_404(self, slug: str, con: Any) -> dict[str, Any]:
        resolved = self._resolve_slug(slug, con)
        row = con.execute(q("SELECT * FROM skills WHERE slug = ?", self.db), (resolved,)).fetchone()
        if not row:
            logger.warning("Skill not found: '%s'", slug)
            raise NotFoundError(f"Skill '{slug}' not found")
        result = row_to_dict(row)
        if resolved != slug:
            result["_redirected_from"] = slug
        return result

    def _audit(self, con: Any, skill_id: str, action: str, actor_id: str = "", detail: str = "") -> None:
        con.execute(
            q("INSERT INTO skill_audit_log(skill_id, action, actor_id, detail, created_at) VALUES(?, ?, ?, ?, ?)", self.db),
            (skill_id, action, actor_id, detail, now()),
        )

    def _to_summary(self, row: dict[str, Any]) -> dict[str, Any]:
        return {
            "skill_id": row["skill_id"], "slug": row["slug"], "name": row["name"],
            "description": row.get("description", ""),
            "tags": parse_json_field(row.get("tags"), []),
            "target_roles": parse_json_field(row.get("target_roles"), []),
            "status": row.get("status", "active"),
            "latest_version": row.get("latest_version", ""),
            "download_count": row.get("download_count", 0),
            "star_count": row.get("star_count", 0),
            "report_count": row.get("report_count", 0),
            "scan_status": row.get("scan_status", "pending"),
            "owner_id": row.get("owner_id", ""),
            "workspace_id": row.get("workspace_id"),
            "created_at": row.get("created_at", ""),
            "updated_at": row.get("updated_at", ""),
        }

    def _process_upload(self, content: bytes) -> tuple:
        """Parse upload (ZIP or bare SKILL.md). Returns (fm, body, archive_files, is_bundle)."""
        if zipfile.is_zipfile(io.BytesIO(content)):
            archive_files = validate_archive(content, self.config.max_file_size, self.config.max_per_file_size)
            fm, body = parse_skill_file(archive_files[0][1])
            return fm, body, archive_files, True
        else:
            fm, body = parse_skill_file(content)
            return fm, body, [("SKILL.md", content)], False

    def _upload_to_s3(self, slug: str, version: str, archive_files: list[tuple[str, bytes]]) -> list[dict[str, Any]]:
        s3 = self.s3_client_factory()
        records: list[dict[str, Any]] = []
        for file_path, file_content in archive_files:
            s3_key = build_s3_key(self.config.s3_prefix, slug, version, file_path)
            s3.put_object(Bucket=self.s3_bucket, Key=s3_key, Body=file_content)
            records.append({
                "file_path": file_path, "file_size": len(file_content),
                "content_hash": compute_content_hash(file_content), "s3_key": s3_key,
            })
        return records

    def _insert_files(self, con: Any, skill_id: str, version: str, records: list[dict[str, Any]]) -> None:
        for fr in records:
            con.execute(
                q("INSERT INTO skill_files(skill_id, version, file_path, file_size, content_hash, s3_key, created_at) VALUES(?, ?, ?, ?, ?, ?, ?)", self.db),
                (skill_id, version, fr["file_path"], fr["file_size"], fr["content_hash"], fr["s3_key"], now()),
            )

    def _get_version_files(self, con: Any, skill_id: str, version: str) -> list[dict[str, Any]]:
        rows = con.execute(
            q("SELECT * FROM skill_files WHERE skill_id = ? AND version = ?", self.db), (skill_id, version)
        ).fetchall()
        return [row_to_dict(r) for r in rows]

    def _build_scan_text(self, body: str, archive_files: list[tuple[str, bytes]]) -> str:
        all_text = body
        for path, content in archive_files[1:]:
            try:
                all_text += f"\n\n# --- {path} ---\n{content.decode('utf-8')}"
            except UnicodeDecodeError:
                pass
        return all_text

    def _build_supplementary(self, archive_files: list[tuple[str, bytes]]) -> list[tuple[str, str]]:
        result: list[tuple[str, str]] = []
        for path, content in archive_files[1:]:
            try:
                result.append((path, content.decode("utf-8")))
            except UnicodeDecodeError:
                pass
        return result

    # ── CRUD ─────────────────────────────────────────────────────

    def create_skill(self, content: bytes, owner_id: str = "", workspace_id: str | None = None) -> dict[str, Any]:
        """Create a new skill from uploaded content (SKILL.md or ZIP bundle).

        Raises ValidationError, ConflictError, or RuntimeError.
        """
        validate_user_id(owner_id)
        validate_file_size(len(content), self.config.max_file_size)
        fm, body, archive_files, is_bundle = self._process_upload(content)

        errors = validate_frontmatter(fm)
        if errors:
            raise ValidationError("; ".join(errors))

        skill_id = generate_skill_id()
        slug = generate_slug(fm.name)
        content_hash = compute_content_hash(content)
        ts = now()
        bundle_size = sum(len(f[1]) for f in archive_files)
        file_count = len(archive_files)

        scan_text = self._build_scan_text(body, archive_files) if is_bundle else body
        scan_result = scan_content(scan_text, fm.model_dump())
        scan_status = "flagged" if scan_result.risk_score >= self.config.scan_flag_threshold else "clean"

        supplementary = self._build_supplementary(archive_files) if is_bundle else None
        emb_text = build_embedding_text(fm.name, fm.description, fm.tags, body, supplementary_files=supplementary)
        try:
            embedding = self.search_index.add(skill_id, emb_text, meta={"name": fm.name, "slug": slug, "downloads": 0})
        except Exception:
            logger.warning("Failed to generate embedding for skill %s", slug)
            embedding = []

        try:
            file_records = self._upload_to_s3(slug, fm.version, archive_files)
        except Exception as e:
            self.search_index.remove(skill_id)
            raise RuntimeError(f"S3 upload failed: {e}")

        s3_key = build_s3_key(self.config.s3_prefix, slug, fm.version)

        with self.db.get_connection() as con:
            if con.execute(q("SELECT id FROM skills WHERE slug = ?", self.db), (slug,)).fetchone():
                raise ConflictError(f"Slug '{slug}' already exists")

            con.execute(
                q("INSERT INTO skills(skill_id, name, slug, description, tags, target_roles, requires, owner_id, workspace_id, status, latest_version, scan_status, created_at, updated_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)", self.db),
                (skill_id, fm.name, slug, fm.description, json.dumps(fm.tags), json.dumps(fm.target_roles),
                 json.dumps(fm.requires.model_dump()), owner_id, workspace_id, fm.version, scan_status, ts, ts),
            )
            con.execute(
                q("INSERT INTO skill_versions(skill_id, version, content_hash, s3_key, file_size, file_count, bundle_size, frontmatter, changelog, published_by, embedding, scan_result, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, ?, ?)", self.db),
                (skill_id, fm.version, content_hash, s3_key, len(content), file_count, bundle_size,
                 json.dumps(fm.model_dump()), owner_id, json.dumps(embedding), json.dumps(scan_result.model_dump()), ts),
            )
            if is_bundle:
                self._insert_files(con, skill_id, fm.version, file_records)
            con.execute(
                q("INSERT INTO skill_version_tags(skill_id, tag, version, created_at) VALUES(?, 'latest', ?, ?)", self.db),
                (skill_id, fm.version, ts),
            )
            self._audit(con, skill_id, "created", owner_id, json.dumps({"version": fm.version, "slug": slug, "file_count": file_count}))
            con.commit()

        logger.info("Created skill '%s' (id=%s, version=%s)", slug, skill_id, fm.version)
        return {
            "skill_id": skill_id, "slug": slug, "name": fm.name, "description": fm.description,
            "tags": fm.tags, "target_roles": fm.target_roles, "status": "active",
            "latest_version": fm.version, "scan_status": scan_status, "owner_id": owner_id,
            "workspace_id": workspace_id, "requires": fm.requires.model_dump(),
            "content_hash": content_hash, "s3_key": s3_key, "file_size": len(content),
            "file_count": file_count, "frontmatter": fm.model_dump(),
            "created_at": ts, "updated_at": ts,
            "files": [SkillFileInfo(**fr) for fr in file_records],
        }

    def list_skills(self, query: str | None, tags: str | None, role: str | None,
                    status: str, workspace_id: str | None, limit: int, offset: int) -> list[dict[str, Any]]:
        """List skills with optional search, tag/role filtering, and pagination.

        Raises NotFoundError if a semantic search yields no DB matches.
        """
        if query:
            results = self.search_index.search(query, top_k=limit + offset)
            if results:
                skill_ids = [sid for sid, _ in results[offset:offset + limit]]
                if not skill_ids:
                    return []
                with self.db.get_connection() as con:
                    placeholders = ",".join("?" for _ in skill_ids)
                    rows = con.execute(
                        q(f"SELECT * FROM skills WHERE skill_id IN ({placeholders}) AND status = ?", self.db),
                        (*skill_ids, status),
                    ).fetchall()
                row_map = {row_to_dict(r)["skill_id"]: row_to_dict(r) for r in rows}
                ordered: list[dict[str, Any]] = []
                for sid in skill_ids:
                    if sid in row_map:
                        row = row_map[sid]
                        if tags and not any(t in parse_json_field(row.get("tags"), []) for t in tags.split(",")):
                            continue
                        if role and role not in parse_json_field(row.get("target_roles"), []):
                            continue
                        if workspace_id and row.get("workspace_id") != workspace_id:
                            continue
                        ordered.append(self._to_summary(row))
                return ordered

        with self.db.get_connection() as con:
            clauses: list[str] = ["status = ?"]
            params: list[Any] = [status]
            if tags:
                for t in tags.split(","):
                    escaped = escape_like_pattern(t.strip())
                    clauses.append("tags LIKE ? ESCAPE '\\'")
                    params.append(f'%"{escaped}"%')
            if role:
                escaped_role = escape_like_pattern(role)
                clauses.append("target_roles LIKE ? ESCAPE '\\'")
                params.append(f'%"{escaped_role}"%')
            if workspace_id:
                clauses.append("workspace_id = ?")
                params.append(workspace_id)
            params.extend([limit, offset])
            rows = con.execute(
                q(f"SELECT * FROM skills WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC LIMIT ? OFFSET ?", self.db),
                tuple(params),
            ).fetchall()
        return [self._to_summary(row_to_dict(r)) for r in rows]

    def get_skill(self, slug: str) -> dict[str, Any]:
        """Retrieve a single skill by slug, following redirects.

        Raises NotFoundError if the skill does not exist.
        """
        with self.db.get_connection() as con:
            resolved = self._resolve_slug(slug, con)
            if resolved != slug:
                return {"_redirect": resolved}
            skill = self._get_or_404(slug, con)
            ver_row = None
            if skill.get("latest_version"):
                ver_row = con.execute(
                    q("SELECT * FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                    (skill["skill_id"], skill["latest_version"]),
                ).fetchone()
        result = self._to_summary(skill)
        result["requires"] = parse_json_field(skill.get("requires"), {})
        if ver_row:
            vr = row_to_dict(ver_row)
            result["content_hash"] = vr.get("content_hash", "")
            result["s3_key"] = vr.get("s3_key", "")
            result["file_size"] = vr.get("file_size", 0)
            result["frontmatter"] = parse_json_field(vr.get("frontmatter"), {})
            result["changelog"] = vr.get("changelog", "")
        return result

    def update_skill(self, slug: str, updates: dict[str, Any]) -> dict[str, Any]:
        """Update mutable fields (status, tags, description, target_roles) on a skill.

        Raises NotFoundError or ValidationError.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            sets: list[str] = []
            params: list[Any] = []
            if "status" in updates and updates["status"] is not None:
                validate_status_transition(skill["status"], updates["status"])
                sets.append("status = ?")
                params.append(updates["status"])
            if "tags" in updates and updates["tags"] is not None:
                sets.append("tags = ?")
                params.append(json.dumps(updates["tags"]))
            if "description" in updates and updates["description"] is not None:
                sets.append("description = ?")
                params.append(updates["description"])
            if "target_roles" in updates and updates["target_roles"] is not None:
                sets.append("target_roles = ?")
                params.append(json.dumps(updates["target_roles"]))
            if not sets:
                raise ValidationError("No fields to update")
            sets.append("updated_at = ?")
            params.append(now())
            params.append(skill["skill_id"])
            con.execute(q(f"UPDATE skills SET {', '.join(sets)} WHERE skill_id = ?", self.db), tuple(params))
            self._audit(con, skill["skill_id"], "updated", "", json.dumps(updates))
            con.commit()
        return {"message": "Skill updated", "slug": skill["slug"]}

    def delete_skill(self, slug: str) -> dict[str, Any]:
        """Soft-delete a skill by setting its status to 'removed'.

        Raises NotFoundError or ValidationError.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if skill["status"] == "removed":
                raise ValidationError("Skill is already removed")
            con.execute(q("UPDATE skills SET status = 'removed', updated_at = ? WHERE skill_id = ?", self.db), (now(), skill["skill_id"]))
            self._audit(con, skill["skill_id"], "deleted", "")
            con.commit()
        self.search_index.remove(skill["skill_id"])
        logger.info("Deleted skill '%s' (id=%s)", slug, skill["skill_id"])
        return {"message": "Skill removed", "slug": skill["slug"]}

    # ── Versions ─────────────────────────────────────────────────

    def publish_version(self, slug: str, content: bytes, changelog: str = "", owner_id: str = "") -> dict[str, Any]:
        """Publish a new version of an existing skill.

        Raises ValidationError, ConflictError, NotFoundError, or RuntimeError.
        """
        validate_user_id(owner_id)
        validate_file_size(len(content), self.config.max_file_size)
        fm, body, archive_files, is_bundle = self._process_upload(content)
        errors = validate_frontmatter(fm)
        if errors:
            raise ValidationError("; ".join(errors))

        content_hash = compute_content_hash(content)
        ts = now()
        bundle_size = sum(len(f[1]) for f in archive_files)
        file_count = len(archive_files)

        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            validate_version_progression(fm.version, skill["latest_version"])

            dup = con.execute(q("SELECT version FROM skill_versions WHERE skill_id = ? AND content_hash = ?", self.db),
                              (skill["skill_id"], content_hash)).fetchone()
            if dup:
                raise ConflictError(f"Content identical to version {row_to_dict(dup)['version']}")

            scan_text = self._build_scan_text(body, archive_files) if is_bundle else body
            scan_result = scan_content(scan_text, fm.model_dump())
            scan_status = "flagged" if scan_result.risk_score >= self.config.scan_flag_threshold else "clean"

            supplementary = self._build_supplementary(archive_files) if is_bundle else None
            emb_text = build_embedding_text(fm.name, fm.description, fm.tags, body, supplementary_files=supplementary)
            try:
                embedding = self.search_index.add(skill["skill_id"], emb_text,
                    meta={"name": fm.name, "slug": skill["slug"], "downloads": skill.get("download_count", 0)})
            except Exception:
                embedding = []

            s3_key = build_s3_key(self.config.s3_prefix, skill["slug"], fm.version)
            try:
                file_records = self._upload_to_s3(skill["slug"], fm.version, archive_files)
            except Exception as e:
                raise RuntimeError(f"S3 upload failed: {e}")

            con.execute(
                q("INSERT INTO skill_versions(skill_id, version, content_hash, s3_key, file_size, file_count, bundle_size, frontmatter, changelog, published_by, embedding, scan_result, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", self.db),
                (skill["skill_id"], fm.version, content_hash, s3_key, len(content), file_count, bundle_size,
                 json.dumps(fm.model_dump()), changelog, owner_id, json.dumps(embedding), json.dumps(scan_result.model_dump()), ts),
            )
            if is_bundle:
                self._insert_files(con, skill["skill_id"], fm.version, file_records)
            con.execute(q("UPDATE skills SET latest_version = ?, scan_status = ?, updated_at = ? WHERE skill_id = ?", self.db),
                        (fm.version, scan_status, ts, skill["skill_id"]))
            con.execute(q("UPDATE skill_version_tags SET version = ?, created_at = ? WHERE skill_id = ? AND tag = 'latest'", self.db),
                        (fm.version, ts, skill["skill_id"]))
            self._audit(con, skill["skill_id"], "version_published", owner_id,
                        json.dumps({"version": fm.version, "previous": skill["latest_version"], "file_count": file_count}))
            con.commit()

        logger.info("Published version %s for skill '%s' (id=%s)", fm.version, slug, skill["skill_id"])
        return {
            "skill_id": skill["skill_id"], "version": fm.version, "content_hash": content_hash,
            "s3_key": s3_key, "file_size": len(content), "file_count": file_count,
            "frontmatter": fm.model_dump(), "changelog": changelog, "published_by": owner_id,
            "scan_result": scan_result.model_dump(), "created_at": ts,
            "files": [SkillFileInfo(**fr) for fr in file_records],
        }

    def list_versions(self, slug: str) -> list[dict[str, Any]]:
        """List all published versions of a skill, newest first.

        Raises NotFoundError if the skill does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            versions = con.execute(q("SELECT * FROM skill_versions WHERE skill_id = ? ORDER BY created_at DESC", self.db),
                                   (skill["skill_id"],)).fetchall()
            tag_rows = con.execute(q("SELECT tag, version FROM skill_version_tags WHERE skill_id = ?", self.db),
                                   (skill["skill_id"],)).fetchall()
        vtags: dict[str, list[str]] = {}
        for tr in tag_rows:
            tr = row_to_dict(tr)
            vtags.setdefault(tr["version"], []).append(tr["tag"])
        result: list[dict[str, Any]] = []
        for r in versions:
            v = row_to_dict(r)
            result.append({
                "version": v["version"], "content_hash": v.get("content_hash", ""),
                "file_size": v.get("file_size", 0), "file_count": v.get("file_count", 1),
                "changelog": v.get("changelog", ""), "published_by": v.get("published_by", ""),
                "scan_result": parse_json_field(v.get("scan_result"), {}),
                "tags": vtags.get(v["version"], []), "created_at": v.get("created_at", ""),
            })
        return result

    def get_version(self, slug: str, version: str) -> dict[str, Any]:
        """Retrieve metadata for a specific version of a skill.

        Raises NotFoundError if the skill or version does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            row = con.execute(q("SELECT * FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                              (skill["skill_id"], version)).fetchone()
            if not row:
                logger.warning("Version '%s' not found for skill '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
            tag_rows = con.execute(q("SELECT tag FROM skill_version_tags WHERE skill_id = ? AND version = ?", self.db),
                                   (skill["skill_id"], version)).fetchall()
            version_files = self._get_version_files(con, skill["skill_id"], version)
        v = row_to_dict(row)
        return {
            "skill_id": v["skill_id"], "version": v["version"], "content_hash": v.get("content_hash", ""),
            "s3_key": v.get("s3_key", ""), "file_size": v.get("file_size", 0), "file_count": v.get("file_count", 1),
            "frontmatter": parse_json_field(v.get("frontmatter"), {}), "changelog": v.get("changelog", ""),
            "published_by": v.get("published_by", ""), "scan_result": parse_json_field(v.get("scan_result"), {}),
            "tags": [row_to_dict(t)["tag"] for t in tag_rows], "created_at": v.get("created_at", ""),
            "files": [SkillFileInfo(**{k: f[k] for k in ("file_path", "file_size", "content_hash", "s3_key")}) for f in version_files],
        }

    def download_skill(self, slug: str, version: str | None, tag: str | None) -> tuple[bytes | io.BytesIO, str, dict[str, Any]]:
        """Download skill content as a ZIP bundle or single SKILL.md.

        Raises NotFoundError if the skill, version, or tag does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if tag and not version:
                tag_row = con.execute(q("SELECT version FROM skill_version_tags WHERE skill_id = ? AND tag = ?", self.db),
                                      (skill["skill_id"], tag)).fetchone()
                if not tag_row:
                    logger.warning("Tag '%s' not found for skill '%s'", tag, slug)
                    raise NotFoundError(f"Tag '{tag}' not found")
                version = row_to_dict(tag_row)["version"]
            if not version:
                version = skill["latest_version"]
            ver_row = con.execute(q("SELECT s3_key, content_hash, file_count FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                                  (skill["skill_id"], version)).fetchone()
            if not ver_row:
                logger.warning("Version '%s' not found for skill '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
            vr = row_to_dict(ver_row)
            bundle_files = self._get_version_files(con, skill["skill_id"], version) if vr.get("file_count", 1) > 1 else []
            con.execute(q("UPDATE skills SET download_count = download_count + 1 WHERE skill_id = ?", self.db), (skill["skill_id"],))
            self._audit(con, skill["skill_id"], "downloaded", "", json.dumps({"version": version}))
            con.commit()

        s3 = self.s3_client_factory()
        if bundle_files:
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for bf in bundle_files:
                    obj = s3.get_object(Bucket=self.s3_bucket, Key=bf["s3_key"])
                    zf.writestr(bf["file_path"], obj["Body"].read())
            buf.seek(0)
            return buf, "application/zip", {
                "Content-Disposition": f'attachment; filename="{skill["slug"]}-{version}.zip"',
                "X-Content-Hash": vr.get("content_hash", ""),
            }
        else:
            obj = s3.get_object(Bucket=self.s3_bucket, Key=vr["s3_key"])
            return io.BytesIO(obj["Body"].read()), "text/markdown", {
                "Content-Disposition": 'attachment; filename="SKILL.md"',
                "X-Content-Hash": vr.get("content_hash", ""),
            }

    def verify_skill(self, slug: str, version: str | None) -> dict[str, Any]:
        """Verify a skill version's S3 content against its stored hash.

        Raises NotFoundError if the skill or version does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if not version:
                version = skill["latest_version"]
            ver_row = con.execute(q("SELECT s3_key, content_hash FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                                  (skill["skill_id"], version)).fetchone()
            if not ver_row:
                logger.warning("Version '%s' not found for skill '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
        vr = row_to_dict(ver_row)
        s3 = self.s3_client_factory()
        obj = s3.get_object(Bucket=self.s3_bucket, Key=vr["s3_key"])
        actual = compute_content_hash(obj["Body"].read())
        return {"valid": actual == vr["content_hash"], "expected": vr["content_hash"], "actual": actual, "version": version}

    def list_version_files(self, slug: str, version: str) -> list[dict[str, Any]]:
        """List files in a specific version of a skill bundle.

        Raises NotFoundError if the skill or version does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            files = self._get_version_files(con, skill["skill_id"], version)
            if not files:
                ver_row = con.execute(q("SELECT s3_key, content_hash, file_size FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                                      (skill["skill_id"], version)).fetchone()
                if not ver_row:
                    logger.warning("Version '%s' not found for skill '%s'", version, slug)
                    raise NotFoundError(f"Version '{version}' not found")
                vr = row_to_dict(ver_row)
                return [{"file_path": "SKILL.md", "file_size": vr.get("file_size", 0),
                         "content_hash": vr.get("content_hash", ""), "s3_key": vr.get("s3_key", "")}]
        return [{"file_path": f["file_path"], "file_size": f["file_size"],
                 "content_hash": f["content_hash"], "s3_key": f["s3_key"]} for f in files]

    def get_file(self, slug: str, version: str, file_path: str) -> tuple[bytes, str]:
        """Retrieve a single file's content from S3 for a given skill version.

        Raises NotFoundError if the skill or file does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            row = con.execute(q("SELECT s3_key, content_hash FROM skill_files WHERE skill_id = ? AND version = ? AND file_path = ?", self.db),
                              (skill["skill_id"], version, file_path)).fetchone()
            if not row:
                logger.warning("File '%s' not found in version '%s' of skill '%s'", file_path, version, slug)
                raise NotFoundError(f"File '{file_path}' not found in version '{version}'")
        fr = row_to_dict(row)
        s3 = self.s3_client_factory()
        obj = s3.get_object(Bucket=self.s3_bucket, Key=fr["s3_key"])
        return obj["Body"].read(), fr.get("content_hash", "")

    # ── Tags ─────────────────────────────────────────────────────

    def set_tag(self, slug: str, tag: str, version: str) -> dict[str, Any]:
        """Assign a version tag (e.g. 'stable') to a specific skill version.

        Raises ValidationError or NotFoundError.
        """
        if tag == "latest":
            raise ValidationError("'latest' tag is auto-managed")
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if not con.execute(q("SELECT id FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                               (skill["skill_id"], version)).fetchone():
                logger.warning("Version '%s' not found for skill '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
            ts = now()
            cur = con.execute(q("UPDATE skill_version_tags SET version = ?, created_at = ? WHERE skill_id = ? AND tag = ?", self.db),
                              (version, ts, skill["skill_id"], tag))
            if cur.rowcount == 0:
                con.execute(q("INSERT INTO skill_version_tags(skill_id, tag, version, created_at) VALUES(?, ?, ?, ?)", self.db),
                            (skill["skill_id"], tag, version, ts))
            self._audit(con, skill["skill_id"], "tag_set", "", json.dumps({"tag": tag, "version": version}))
            con.commit()
        return {"message": f"Tag '{tag}' now points to version {version}"}

    def delete_tag(self, slug: str, tag: str) -> dict[str, Any]:
        """Remove a version tag from a skill.

        Raises ValidationError or NotFoundError.
        """
        if tag == "latest":
            raise ValidationError("Cannot remove 'latest' tag")
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            cur = con.execute(q("DELETE FROM skill_version_tags WHERE skill_id = ? AND tag = ?", self.db), (skill["skill_id"], tag))
            if cur.rowcount == 0:
                logger.warning("Tag '%s' not found for skill '%s'", tag, slug)
                raise NotFoundError(f"Tag '{tag}' not found")
            con.commit()
        return {"message": f"Tag '{tag}' removed"}

    # ── Community ────────────────────────────────────────────────

    def star(self, slug: str, user_id: str) -> dict[str, Any]:
        """Star a skill for the given user.

        Raises NotFoundError if the skill does not exist.
        """
        validate_user_id(user_id)
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if con.execute(q("SELECT id FROM skill_stars WHERE skill_id = ? AND user_id = ?", self.db), (skill["skill_id"], user_id)).fetchone():
                return {"message": "Already starred", "starred": True}
            con.execute(q("INSERT INTO skill_stars(skill_id, user_id, created_at) VALUES(?, ?, ?)", self.db), (skill["skill_id"], user_id, now()))
            con.execute(q("UPDATE skills SET star_count = star_count + 1 WHERE skill_id = ?", self.db), (skill["skill_id"],))
            con.commit()
        return {"message": "Starred", "starred": True}

    def unstar(self, slug: str, user_id: str) -> dict[str, Any]:
        """Remove a star from a skill for the given user.

        Raises NotFoundError if the skill does not exist.
        """
        validate_user_id(user_id)
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            cur = con.execute(q("DELETE FROM skill_stars WHERE skill_id = ? AND user_id = ?", self.db), (skill["skill_id"], user_id))
            if cur.rowcount > 0:
                con.execute(q("UPDATE skills SET star_count = CASE WHEN star_count > 0 THEN star_count - 1 ELSE 0 END WHERE skill_id = ?", self.db), (skill["skill_id"],))
                con.commit()
                return {"message": "Unstarred", "starred": False}
        return {"message": "Was not starred", "starred": False}

    def list_comments(self, slug: str) -> list[dict[str, Any]]:
        """List all comments on a skill, ordered by creation time.

        Raises NotFoundError if the skill does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            rows = con.execute(q("SELECT * FROM skill_comments WHERE skill_id = ? ORDER BY created_at ASC", self.db), (skill["skill_id"],)).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            r = row_to_dict(row)
            result.append({
                "id": r["id"], "skill_id": skill["skill_id"], "user_id": r["user_id"],
                "content": r["content"], "created_at": r.get("created_at", ""), "updated_at": r.get("updated_at", ""),
            })
        return result

    def add_comment(self, slug: str, user_id: str, content: str) -> dict[str, Any]:
        """Add a comment to a skill.

        Raises ValidationError or NotFoundError.
        """
        validate_user_id(user_id)
        validate_comment_content(content)
        ts = now()
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            con.execute(q("INSERT INTO skill_comments(skill_id, user_id, content, created_at, updated_at) VALUES(?, ?, ?, ?, ?)", self.db),
                        (skill["skill_id"], user_id, content.strip(), ts, ts))
            con.commit()
        return {"message": "Comment added"}

    def delete_comment(self, slug: str, comment_id: int, user_id: str) -> dict[str, Any]:
        """Delete a comment owned by the given user.

        Raises NotFoundError or ForbiddenError.
        """
        validate_user_id(user_id)
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            comment = con.execute(q("SELECT * FROM skill_comments WHERE id = ? AND skill_id = ?", self.db), (comment_id, skill["skill_id"])).fetchone()
            if not comment:
                logger.warning("Comment %d not found for skill '%s'", comment_id, slug)
                raise NotFoundError("Comment not found")
            if row_to_dict(comment)["user_id"] != user_id:
                logger.warning("User '%s' attempted to delete comment %d owned by another user", user_id, comment_id)
                raise ForbiddenError("Can only delete your own comments")
            con.execute(q("DELETE FROM skill_comments WHERE id = ?", self.db), (comment_id,))
            con.commit()
        return {"message": "Comment deleted"}

    def report(self, slug: str, reporter_id: str, reason: str, detail: str = "") -> dict[str, Any]:
        """Report a skill for review; auto-hides after threshold reports.

        Raises NotFoundError or ConflictError.
        """
        validate_user_id(reporter_id)
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if con.execute(q("SELECT id FROM skill_reports WHERE skill_id = ? AND reporter_id = ?", self.db), (skill["skill_id"], reporter_id)).fetchone():
                raise ConflictError("You have already reported this skill")
            ts = now()
            con.execute(q("INSERT INTO skill_reports(skill_id, reporter_id, reason, detail, created_at) VALUES(?, ?, ?, ?, ?)", self.db),
                        (skill["skill_id"], reporter_id, reason, detail, ts))
            con.execute(q("UPDATE skills SET report_count = report_count + 1 WHERE skill_id = ?", self.db), (skill["skill_id"],))
            cnt = row_to_dict(con.execute(q("SELECT COUNT(DISTINCT reporter_id) as cnt FROM skill_reports WHERE skill_id = ?", self.db),
                                           (skill["skill_id"],)).fetchone()).get("cnt", 0)
            if cnt >= self.config.report_auto_hide_threshold and skill["status"] == "active":
                con.execute(q("UPDATE skills SET status = 'hidden', updated_at = ? WHERE skill_id = ?", self.db), (ts, skill["skill_id"]))
                self._audit(con, skill["skill_id"], "auto_hidden_by_reports", "", json.dumps({"report_count": cnt}))
            self._audit(con, skill["skill_id"], "reported", reporter_id, json.dumps({"reason": reason}))
            con.commit()
        logger.info("Skill '%s' reported by '%s' (reason=%s)", slug, reporter_id, reason)
        return {"message": "Report submitted"}

    # ── Admin ────────────────────────────────────────────────────

    def rename(self, slug: str, new_slug: str, owner_id: str = "") -> dict[str, Any]:
        """Rename a skill's slug, creating a redirect from the old slug.

        Raises ValidationError, ConflictError, NotFoundError, or ForbiddenError.
        """
        validate_user_id(owner_id)
        slug_errors = validate_slug(new_slug)
        if slug_errors:
            raise ValidationError("; ".join(slug_errors))
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if owner_id and skill["owner_id"] != owner_id:
                logger.warning("User '%s' attempted to rename skill '%s' owned by '%s'", owner_id, slug, skill["owner_id"])
                raise ForbiddenError("Only the owner can rename a skill")
            if con.execute(q("SELECT id FROM skills WHERE slug = ?", self.db), (new_slug,)).fetchone():
                raise ConflictError(f"Slug '{new_slug}' already exists")
            if con.execute(q("SELECT old_slug FROM skill_redirects WHERE old_slug = ?", self.db), (new_slug,)).fetchone():
                raise ConflictError(f"Slug '{new_slug}' is used by a redirect")
            ts = now()
            old_slug = skill["slug"]
            con.execute(q("UPDATE skills SET slug = ?, updated_at = ? WHERE skill_id = ?", self.db), (new_slug, ts, skill["skill_id"]))
            con.execute(q("INSERT INTO skill_redirects(old_slug, new_slug, created_at) VALUES(?, ?, ?)", self.db), (old_slug, new_slug, ts))
            con.execute(q("UPDATE skill_redirects SET new_slug = ? WHERE new_slug = ?", self.db), (new_slug, old_slug))
            self._audit(con, skill["skill_id"], "renamed", owner_id, json.dumps({"old_slug": old_slug, "new_slug": new_slug}))
            con.commit()
            self.search_index.update_meta(skill["skill_id"], slug=new_slug)
        logger.info("Renamed skill '%s' -> '%s' (id=%s)", old_slug, new_slug, skill["skill_id"])
        return {"message": f"Renamed '{old_slug}' \u2192 '{new_slug}'", "slug": new_slug}

    def find_duplicates(self, slug: str, threshold: float = 0.85) -> list[dict[str, Any]]:
        """Find potential duplicate skills using embedding similarity and name matching.

        Raises NotFoundError if the skill does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            emb_dupes = self.search_index.find_duplicates(skill["skill_id"], threshold=threshold)
            all_skills = con.execute(q("SELECT skill_id, slug, name FROM skills WHERE status = 'active' AND skill_id != ?", self.db),
                                     (skill["skill_id"],)).fetchall()
        candidates: list[dict[str, Any]] = []
        seen: set[str] = set()
        for sid, sim in emb_dupes:
            meta = self.search_index.get_meta(sid)
            candidates.append({"skill_id": sid, "slug": meta.get("slug", ""), "name": meta.get("name", ""),
                               "similarity": round(sim, 3), "match_type": "embedding"})
            seen.add(sid)
        for row in all_skills:
            r = row_to_dict(row)
            if r["skill_id"] in seen:
                continue
            sim = name_similarity(skill["name"], r["name"])
            if sim >= 0.8:
                candidates.append({"skill_id": r["skill_id"], "slug": r["slug"], "name": r["name"],
                                   "similarity": round(sim, 3), "match_type": "name"})
        candidates.sort(key=lambda c: c["similarity"], reverse=True)
        return candidates

    def merge(self, slug: str, target_slug: str, owner_id: str = "") -> dict[str, Any]:
        """Merge a source skill into a target skill, moving versions, stars, comments, and tags.

        Raises ValidationError, ForbiddenError, or NotFoundError.
        """
        validate_user_id(owner_id)
        with self.db.get_connection() as con:
            source = self._get_or_404(slug, con)
            target = self._get_or_404(target_slug, con)
            if source["skill_id"] == target["skill_id"]:
                raise ValidationError("Cannot merge a skill into itself")
            if owner_id:
                if source["owner_id"] != owner_id or target["owner_id"] != owner_id:
                    logger.warning("User '%s' attempted to merge skills without owning both", owner_id)
                    raise ForbiddenError("Must own both skills to merge")
            ts = now()
            # Re-assign versions (skip conflicts)
            target_vers: set[str] = set()
            for v in con.execute(q("SELECT version FROM skill_versions WHERE skill_id = ?", self.db), (target["skill_id"],)).fetchall():
                target_vers.add(row_to_dict(v)["version"])
            for sv in con.execute(q("SELECT id, version FROM skill_versions WHERE skill_id = ?", self.db), (source["skill_id"],)).fetchall():
                sv = row_to_dict(sv)
                if sv["version"] not in target_vers:
                    con.execute(q("UPDATE skill_versions SET skill_id = ? WHERE id = ?", self.db), (target["skill_id"], sv["id"]))
            # Stars
            existing_users: set[str] = set()
            for s in con.execute(q("SELECT user_id FROM skill_stars WHERE skill_id = ?", self.db), (target["skill_id"],)).fetchall():
                existing_users.add(row_to_dict(s)["user_id"])
            for s in con.execute(q("SELECT user_id, created_at FROM skill_stars WHERE skill_id = ?", self.db), (source["skill_id"],)).fetchall():
                s = row_to_dict(s)
                if s["user_id"] not in existing_users:
                    con.execute(q("INSERT INTO skill_stars(skill_id, user_id, created_at) VALUES(?, ?, ?)", self.db),
                                (target["skill_id"], s["user_id"], s["created_at"]))
            con.execute(q("DELETE FROM skill_stars WHERE skill_id = ?", self.db), (source["skill_id"],))
            con.execute(q("UPDATE skill_comments SET skill_id = ? WHERE skill_id = ?", self.db), (target["skill_id"], source["skill_id"]))
            # Tags
            for t in con.execute(q("SELECT tag, version FROM skill_version_tags WHERE skill_id = ?", self.db), (source["skill_id"],)).fetchall():
                t = row_to_dict(t)
                if t["tag"] == "latest":
                    continue
                if not con.execute(q("SELECT id FROM skill_version_tags WHERE skill_id = ? AND tag = ?", self.db), (target["skill_id"], t["tag"])).fetchone():
                    con.execute(q("INSERT INTO skill_version_tags(skill_id, tag, version, created_at) VALUES(?, ?, ?, ?)", self.db),
                                (target["skill_id"], t["tag"], t["version"], ts))
            con.execute(q("DELETE FROM skill_version_tags WHERE skill_id = ?", self.db), (source["skill_id"],))
            # Recalculate latest
            all_vers: list[str] = []
            for v in con.execute(q("SELECT version FROM skill_versions WHERE skill_id = ?", self.db), (target["skill_id"],)).fetchall():
                all_vers.append(row_to_dict(v)["version"])
            if all_vers:
                all_vers.sort(key=lambda v: tuple(int(x) for x in v.split(".")), reverse=True)
                con.execute(q("UPDATE skills SET latest_version = ?, updated_at = ? WHERE skill_id = ?", self.db), (all_vers[0], ts, target["skill_id"]))
                con.execute(q("UPDATE skill_version_tags SET version = ? WHERE skill_id = ? AND tag = 'latest'", self.db), (all_vers[0], target["skill_id"]))
            star_cnt = row_to_dict(con.execute(q("SELECT COUNT(*) as cnt FROM skill_stars WHERE skill_id = ?", self.db), (target["skill_id"],)).fetchone()).get("cnt", 0)
            con.execute(q("UPDATE skills SET star_count = ? WHERE skill_id = ?", self.db), (star_cnt, target["skill_id"]))
            con.execute(q("INSERT INTO skill_redirects(old_slug, new_slug, created_at) VALUES(?, ?, ?)", self.db), (source["slug"], target["slug"], ts))
            con.execute(q("UPDATE skill_redirects SET new_slug = ? WHERE new_slug = ?", self.db), (target["slug"], source["slug"]))
            con.execute(q("UPDATE skills SET status = 'removed', updated_at = ? WHERE skill_id = ?", self.db), (ts, source["skill_id"]))
            self._audit(con, source["skill_id"], "merged_into", owner_id, json.dumps({"target": target["slug"]}))
            self._audit(con, target["skill_id"], "merged_from", owner_id, json.dumps({"source": source["slug"]}))
            con.commit()
        self.search_index.remove(source["skill_id"])
        logger.info("Merged skill '%s' into '%s'", source["slug"], target["slug"])
        return {"message": f"Merged '{source['slug']}' into '{target['slug']}'", "target_slug": target["slug"]}

    def get_scan(self, slug: str, version: str | None) -> dict[str, Any]:
        """Retrieve the security scan result for a skill version.

        Raises NotFoundError if the skill or version does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if not version:
                version = skill["latest_version"]
            row = con.execute(q("SELECT scan_result FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                              (skill["skill_id"], version)).fetchone()
            if not row:
                logger.warning("Version '%s' not found for skill '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
        return {"version": version, "scan_status": skill.get("scan_status", "pending"),
                "scan_result": parse_json_field(row_to_dict(row).get("scan_result"), {})}

    def rescan(self, slug: str, version: str | None) -> dict[str, Any]:
        """Re-run the security scan on a skill version's content from S3.

        Raises NotFoundError if the skill or version does not exist.
        """
        with self.db.get_connection() as con:
            skill = self._get_or_404(slug, con)
            if not version:
                version = skill["latest_version"]
            ver_row = con.execute(q("SELECT s3_key, frontmatter FROM skill_versions WHERE skill_id = ? AND version = ?", self.db),
                                  (skill["skill_id"], version)).fetchone()
            if not ver_row:
                logger.warning("Version '%s' not found for skill '%s'", version, slug)
                raise NotFoundError(f"Version '{version}' not found")
        vr = row_to_dict(ver_row)
        s3 = self.s3_client_factory()
        content = s3.get_object(Bucket=self.s3_bucket, Key=vr["s3_key"])["Body"].read()
        fm, body = parse_skill_file(content)
        result = scan_content(body, fm.model_dump())
        scan_status = "flagged" if result.risk_score >= self.config.scan_flag_threshold else "clean"
        with self.db.get_connection() as con:
            ts = now()
            con.execute(q("UPDATE skill_versions SET scan_result = ? WHERE skill_id = ? AND version = ?", self.db),
                        (json.dumps(result.model_dump()), skill["skill_id"], version))
            if version == skill["latest_version"]:
                con.execute(q("UPDATE skills SET scan_status = ?, updated_at = ? WHERE skill_id = ?", self.db), (scan_status, ts, skill["skill_id"]))
            self._audit(con, skill["skill_id"], "rescanned", "", json.dumps({"version": version, "risk_score": result.risk_score}))
            con.commit()
        return {"version": version, "scan_status": scan_status, "scan_result": result.model_dump()}
