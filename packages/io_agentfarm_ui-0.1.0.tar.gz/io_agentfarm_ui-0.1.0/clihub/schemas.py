"""CLI Hub Pydantic models — request/response schemas."""

from __future__ import annotations

from pydantic import BaseModel, Field
from typing import Any


# ── Response models ─────────────────────────────────────────────────


class CLIToolSummary(BaseModel):
    """Lightweight CLI tool info for list endpoints."""
    cli_id: str
    slug: str
    name: str
    display_name: str = ""
    description: str = ""
    category: str = ""
    entry_point: str = ""
    install_cmd: str = ""
    latest_version: str = ""
    install_count: int = 0
    star_count: int = 0
    report_count: int = 0
    scan_status: str = "pending"
    tags: list[str] = Field(default_factory=list)
    contributor: str = ""
    owner_id: str = ""
    workspace_id: str | None = None
    created_at: str = ""
    updated_at: str = ""


class CLIToolDetail(CLIToolSummary):
    """Full CLI tool info including all metadata."""
    homepage: str = ""
    requires: str = ""
    skill_md_url: str = ""
    contributor_url: str = ""


class VersionSummary(BaseModel):
    """Version info for list endpoints."""
    version: str
    install_cmd: str = ""
    entry_point: str = ""
    requires: str = ""
    changelog: str = ""
    published_by: str = ""
    scan_result: dict[str, Any] = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)
    created_at: str = ""


class VersionDetail(VersionSummary):
    """Full version info."""
    cli_id: str = ""
    skill_md_url: str = ""


class CommentOut(BaseModel):
    """Comment response model."""
    id: int
    cli_id: str
    user_id: str
    content: str
    created_at: str
    updated_at: str


# ── Request models ──────────────────────────────────────────────────


class CLIToolCreate(BaseModel):
    """POST body for registering a new CLI tool."""
    name: str
    display_name: str = ""
    description: str = ""
    version: str
    category: str = ""
    entry_point: str
    install_cmd: str
    homepage: str = ""
    requires: str = ""
    skill_md_url: str = ""
    tags: list[str] = Field(default_factory=list)
    contributor: str = ""
    contributor_url: str = ""
    owner_id: str = ""
    workspace_id: str | None = None


class CLIToolUpdate(BaseModel):
    """PATCH body for updating mutable CLI tool metadata."""
    status: str | None = None
    tags: list[str] | None = None
    description: str | None = None
    category: str | None = None
    homepage: str | None = None
    requires: str | None = None


class VersionPublish(BaseModel):
    """POST body for publishing a new version."""
    version: str
    install_cmd: str
    entry_point: str = ""
    requires: str = ""
    skill_md_url: str = ""
    changelog: str = ""
    owner_id: str = ""


class VersionTagSet(BaseModel):
    """PUT body for setting a version tag."""
    version: str


class CommentCreate(BaseModel):
    """POST body for adding a comment."""
    content: str
    user_id: str


class ReportCreate(BaseModel):
    """POST body for reporting a CLI tool."""
    reason: str = Field(..., pattern=r"^(inappropriate|malicious|duplicate|spam|other)$")
    detail: str = ""
    reporter_id: str


class RenameRequest(BaseModel):
    """POST body for renaming a CLI tool."""
    new_slug: str
    owner_id: str = ""


class MergeRequest(BaseModel):
    """POST body for merging a CLI tool into another."""
    target_slug: str
    owner_id: str = ""


class StarRequest(BaseModel):
    """POST body for starring a CLI tool."""
    user_id: str


# ── Security models ────────────────────────────────────────────────


class SecurityFinding(BaseModel):
    """A single finding from the security scanner."""
    rule: str
    severity: str
    message: str
    snippet: str = ""


class ScanResult(BaseModel):
    """Aggregate scan result for a CLI tool."""
    risk_score: float = 0.0
    findings: list[SecurityFinding] = Field(default_factory=list)


class DuplicateCandidate(BaseModel):
    """A potential duplicate found by search or name similarity."""
    cli_id: str
    slug: str
    name: str
    similarity: float
    match_type: str
