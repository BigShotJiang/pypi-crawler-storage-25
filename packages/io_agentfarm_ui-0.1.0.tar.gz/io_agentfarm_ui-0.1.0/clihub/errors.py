"""CLI Hub domain exceptions — no FastAPI dependency."""

from __future__ import annotations


class NotFoundError(Exception):
    pass


class ConflictError(Exception):
    pass


class ForbiddenError(Exception):
    pass


class ValidationError(Exception):
    pass
