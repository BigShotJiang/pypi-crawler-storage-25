"""CLI Hub configuration — pure dataclass, no environment variable access."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CLIHubConfig:
    """All tunables for the CLI Hub module."""

    # Embedding model name (fastembed-compatible)
    embedding_model: str = "BAAI/bge-small-en-v1.5"

    # Embedding text truncation limit (chars)
    embedding_max_chars: int = 2000

    # Community moderation
    report_auto_hide_threshold: int = 3

    # Security scanner
    scan_flag_threshold: float = 0.7

    # Duplicate detection
    duplicate_threshold: float = 0.85

    # API route prefix (no trailing slash)
    api_prefix: str = "/api/cli-tools"

    # Allowed install command schemes
    allowed_install_schemes: list[str] = field(
        default_factory=lambda: ["pip", "git+https", "git+ssh"]
    )
