"""Integration tests for clihub.router."""

from __future__ import annotations

import pytest

from clihub.tests.conftest import VALID_CLI_TOOL


class TestCreateCLITool:
    def test_success(self, client):
        resp = client.post("/api/cli-tools", json=VALID_CLI_TOOL)
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "blender"
        assert data["slug"] == "blender"
        assert data["cli_id"].startswith("cli_")
        assert data["latest_version"] == "1.0.0"

    def test_missing_name(self, client):
        bad = {**VALID_CLI_TOOL, "name": ""}
        resp = client.post("/api/cli-tools", json=bad)
        assert resp.status_code == 400

    def test_missing_entry_point(self, client):
        bad = {**VALID_CLI_TOOL, "entry_point": ""}
        resp = client.post("/api/cli-tools", json=bad)
        assert resp.status_code == 400

    def test_bad_install_cmd(self, client):
        bad = {**VALID_CLI_TOOL, "install_cmd": "npm install something"}
        resp = client.post("/api/cli-tools", json=bad)
        assert resp.status_code == 400

    def test_duplicate_slug(self, client):
        tool = {**VALID_CLI_TOOL, "name": "GIMP"}  # slug "gimp" already exists
        resp = client.post("/api/cli-tools", json=tool)
        assert resp.status_code == 409


class TestListCLITools:
    def test_list_all(self, client):
        resp = client.get("/api/cli-tools")
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_filter_by_category(self, client):
        resp = client.get("/api/cli-tools?category=ai")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["slug"] == "ollama"

    def test_filter_by_tags(self, client):
        resp = client.get("/api/cli-tools?tags=image")
        assert resp.status_code == 200
        assert len(resp.json()) == 1

    def test_pagination(self, client):
        resp = client.get("/api/cli-tools?limit=1")
        assert len(resp.json()) == 1


class TestGetCLITool:
    def test_found(self, client):
        resp = client.get("/api/cli-tools/gimp")
        assert resp.status_code == 200
        data = resp.json()
        assert data["slug"] == "gimp"
        assert data["homepage"] == "https://www.gimp.org"

    def test_not_found(self, client):
        resp = client.get("/api/cli-tools/nonexistent")
        assert resp.status_code == 404


class TestUpdateCLITool:
    def test_update_description(self, client):
        resp = client.patch("/api/cli-tools/gimp", json={"description": "Updated"})
        assert resp.status_code == 200

    def test_update_status(self, client):
        resp = client.patch("/api/cli-tools/gimp", json={"status": "deprecated"})
        assert resp.status_code == 200

    def test_invalid_transition(self, client):
        client.patch("/api/cli-tools/gimp", json={"status": "deprecated"})
        resp = client.patch("/api/cli-tools/gimp", json={"status": "hidden"})
        assert resp.status_code == 400

    def test_no_fields(self, client):
        resp = client.patch("/api/cli-tools/gimp", json={})
        assert resp.status_code == 400


class TestDeleteCLITool:
    def test_soft_delete(self, client):
        resp = client.delete("/api/cli-tools/gimp")
        assert resp.status_code == 200

    def test_already_removed(self, client):
        client.delete("/api/cli-tools/gimp")
        resp = client.delete("/api/cli-tools/gimp")
        assert resp.status_code == 400


class TestVersions:
    def test_list_versions(self, client):
        resp = client.get("/api/cli-tools/gimp/versions")
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_get_version(self, client):
        resp = client.get("/api/cli-tools/gimp/versions/1.0.0")
        assert resp.status_code == 200
        assert resp.json()["version"] == "1.0.0"

    def test_publish_version(self, client):
        resp = client.post("/api/cli-tools/gimp/versions", json={
            "version": "2.0.0",
            "install_cmd": "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
            "changelog": "Major update",
            "owner_id": "user_1",
        })
        assert resp.status_code == 201
        assert resp.json()["version"] == "2.0.0"

    def test_lower_version_rejected(self, client):
        resp = client.post("/api/cli-tools/gimp/versions", json={
            "version": "0.1.0",
            "install_cmd": "pip install git+https://github.com/test.git",
        })
        assert resp.status_code == 400


class TestVersionTags:
    def test_set_tag(self, client):
        resp = client.put("/api/cli-tools/gimp/tags/stable", json={"version": "1.0.0"})
        assert resp.status_code == 200

    def test_cannot_set_latest(self, client):
        resp = client.put("/api/cli-tools/gimp/tags/latest", json={"version": "1.0.0"})
        assert resp.status_code == 400

    def test_delete_tag(self, client):
        client.put("/api/cli-tools/gimp/tags/stable", json={"version": "1.0.0"})
        resp = client.delete("/api/cli-tools/gimp/tags/stable")
        assert resp.status_code == 200

    def test_cannot_delete_latest(self, client):
        resp = client.delete("/api/cli-tools/gimp/tags/latest")
        assert resp.status_code == 400


class TestStars:
    def test_star(self, client):
        resp = client.post("/api/cli-tools/ollama/star", json={"user_id": "user_1"})
        assert resp.status_code == 201

    def test_star_idempotent(self, client):
        resp = client.post("/api/cli-tools/gimp/star", json={"user_id": "user_2"})
        assert "Already" in resp.json()["message"]

    def test_unstar(self, client):
        resp = client.delete("/api/cli-tools/gimp/star?user_id=user_2")
        assert resp.json()["starred"] is False


class TestComments:
    def test_list(self, client):
        resp = client.get("/api/cli-tools/gimp/comments")
        assert resp.status_code == 200
        assert len(resp.json()) == 1

    def test_add(self, client):
        resp = client.post("/api/cli-tools/gimp/comments", json={"user_id": "user_1", "content": "Nice!"})
        assert resp.status_code == 201

    def test_empty_rejected(self, client):
        resp = client.post("/api/cli-tools/gimp/comments", json={"user_id": "u", "content": "  "})
        assert resp.status_code == 400

    def test_delete_own(self, client):
        comments = client.get("/api/cli-tools/gimp/comments").json()
        resp = client.delete(f"/api/cli-tools/gimp/comments/{comments[0]['id']}?user_id={comments[0]['user_id']}")
        assert resp.status_code == 200

    def test_delete_others_forbidden(self, client):
        comments = client.get("/api/cli-tools/gimp/comments").json()
        resp = client.delete(f"/api/cli-tools/gimp/comments/{comments[0]['id']}?user_id=wrong")
        assert resp.status_code == 403


class TestReports:
    def test_report(self, client):
        resp = client.post("/api/cli-tools/gimp/report", json={"reporter_id": "u3", "reason": "spam"})
        assert resp.status_code == 201

    def test_duplicate_report(self, client):
        client.post("/api/cli-tools/gimp/report", json={"reporter_id": "u3", "reason": "spam"})
        resp = client.post("/api/cli-tools/gimp/report", json={"reporter_id": "u3", "reason": "malicious"})
        assert resp.status_code == 409

    def test_auto_hide(self, client):
        for i in range(3):
            client.post("/api/cli-tools/ollama/report", json={"reporter_id": f"r_{i}", "reason": "spam"})
        resp = client.get("/api/cli-tools/ollama")
        assert resp.json()["status"] == "hidden"


class TestRename:
    def test_rename(self, client):
        resp = client.post("/api/cli-tools/gimp/rename", json={"new_slug": "gimp-v2", "owner_id": "user_1"})
        assert resp.status_code == 200

    def test_redirect(self, client):
        client.post("/api/cli-tools/gimp/rename", json={"new_slug": "gimp-v2", "owner_id": "user_1"})
        resp = client.get("/api/cli-tools/gimp", follow_redirects=False)
        assert resp.status_code == 301

    def test_invalid_slug(self, client):
        resp = client.post("/api/cli-tools/gimp/rename", json={"new_slug": "BAD!", "owner_id": "user_1"})
        assert resp.status_code == 400

    def test_wrong_owner(self, client):
        resp = client.post("/api/cli-tools/gimp/rename", json={"new_slug": "new", "owner_id": "wrong"})
        assert resp.status_code == 403


class TestDuplicatesAndMerge:
    def test_find_duplicates(self, client):
        resp = client.get("/api/cli-tools/gimp/duplicates")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_merge(self, client, seeded_db):
        seeded_db.execute("UPDATE cli_tools SET owner_id = 'user_1' WHERE cli_id = 'cli_bbb222'")
        seeded_db.commit()
        resp = client.post("/api/cli-tools/ollama/merge", json={"target_slug": "gimp", "owner_id": "user_1"})
        assert resp.status_code == 200

    def test_merge_self(self, client):
        resp = client.post("/api/cli-tools/gimp/merge", json={"target_slug": "gimp", "owner_id": "user_1"})
        assert resp.status_code == 400

    def test_merge_wrong_owner(self, client):
        resp = client.post("/api/cli-tools/ollama/merge", json={"target_slug": "gimp", "owner_id": "wrong"})
        assert resp.status_code == 403


class TestScan:
    def test_get_scan(self, client):
        resp = client.get("/api/cli-tools/gimp/scan")
        assert resp.status_code == 200
        assert "scan_result" in resp.json()

    def test_rescan(self, client):
        resp = client.post("/api/cli-tools/gimp/rescan")
        assert resp.status_code == 200
        assert "scan_result" in resp.json()


class TestInstallInfo:
    def test_install_info(self, client):
        resp = client.get("/api/cli-tools/gimp/install-info")
        assert resp.status_code == 200
        data = resp.json()
        assert "install_cmd" in data
        assert "entry_point" in data
        assert data["entry_point"] == "cli-anything-gimp"


class TestCatalogTxt:
    def test_catalog(self, client):
        resp = client.get("/api/cli-tools/catalog.txt")
        assert resp.status_code == 200
        assert "text/plain" in resp.headers["content-type"]
        text = resp.text
        assert "GIMP" in text
        assert "Ollama" in text
        assert "pip install" in text
