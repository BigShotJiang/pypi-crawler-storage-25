"""Unit tests for clihub.search."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from clihub.search import CLISearchIndex, build_embedding_text, name_similarity


class TestBuildEmbeddingText:
    def test_basic(self):
        text = build_embedding_text("gimp", "GIMP", "Image editing", "creative", ["image"])
        assert "gimp" in text
        assert "GIMP" in text
        assert "creative" in text

    def test_max_chars(self):
        text = build_embedding_text("name", "display", "x" * 5000, "cat", [], max_chars=100)
        assert len(text) == 100

    def test_with_requires(self):
        text = build_embedding_text("gimp", "GIMP", "desc", "cat", [], requires="GIMP 2.10+")
        assert "GIMP 2.10+" in text


class TestNameSimilarity:
    def test_identical(self):
        assert name_similarity("gimp", "gimp") == 1.0

    def test_similar(self):
        assert name_similarity("gimp", "gimps") > 0.8

    def test_different(self):
        assert name_similarity("abc", "xyz") < 0.5


class TestCLISearchIndex:
    @pytest.fixture()
    def mock_embed(self):
        dim = 384

        def fake_embed(texts):
            for text in texts:
                seed = hash(text) % 10000
                rng = np.random.RandomState(seed)
                vec = rng.randn(dim).astype(np.float32)
                norm = np.linalg.norm(vec)
                if norm > 0:
                    vec = vec / norm
                yield vec

        mock_model = MagicMock()
        mock_model.embed = fake_embed
        with patch("clihub.search.CLISearchIndex._get_model", return_value=mock_model):
            yield

    def test_add_and_search(self, mock_embed):
        index = CLISearchIndex()
        index.add("cli_1", "image editing gimp", meta={"name": "gimp", "slug": "gimp", "installs": 0})
        index.add("cli_2", "local llm ollama", meta={"name": "ollama", "slug": "ollama", "installs": 0})
        assert index.size == 2
        results = index.search("image editing")
        assert len(results) > 0

    def test_remove(self, mock_embed):
        index = CLISearchIndex()
        index.add("cli_1", "test")
        index.remove("cli_1")
        assert index.size == 0

    def test_search_empty(self, mock_embed):
        index = CLISearchIndex()
        assert index.search("anything") == []

    def test_find_duplicates(self, mock_embed):
        index = CLISearchIndex()
        index.add("cli_1", "image editing tool")
        index.add("cli_2", "image editing tool")  # identical
        dupes = index.find_duplicates("cli_1", threshold=0.5)
        assert len(dupes) >= 1
