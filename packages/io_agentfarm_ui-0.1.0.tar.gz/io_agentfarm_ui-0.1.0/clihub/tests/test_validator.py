"""Unit tests for clihub.validator."""

from __future__ import annotations

import pytest

from clihub.validator import (
    generate_cli_id,
    generate_slug,
    scan_cli_tool,
    validate_cli_tool,
    validate_entry_point,
    validate_install_cmd,
    validate_name,
    validate_slug,
    validate_status_transition,
    validate_url,
    validate_version,
    validate_version_progression,
)


class TestValidateName:
    def test_valid(self):
        assert validate_name("GIMP") == []

    def test_empty(self):
        assert len(validate_name("")) > 0

    def test_too_long(self):
        assert any("200" in e for e in validate_name("x" * 201))


class TestValidateVersion:
    def test_valid(self):
        assert validate_version("1.0.0") == []

    def test_invalid(self):
        assert len(validate_version("1.0")) > 0

    def test_empty(self):
        assert len(validate_version("")) > 0


class TestValidateEntryPoint:
    def test_valid(self):
        assert validate_entry_point("cli-anything-gimp") == []

    def test_uppercase(self):
        assert len(validate_entry_point("CLI-Anything")) > 0

    def test_empty(self):
        assert len(validate_entry_point("")) > 0

    def test_too_long(self):
        assert len(validate_entry_point("a" * 101)) > 0


class TestValidateInstallCmd:
    def test_valid_pip(self):
        assert validate_install_cmd("pip install git+https://github.com/repo.git") == []

    def test_missing_pip(self):
        assert len(validate_install_cmd("npm install something")) > 0

    def test_empty(self):
        assert len(validate_install_cmd("")) > 0

    def test_shell_injection_semicolon(self):
        errors = validate_install_cmd("pip install pkg; rm -rf /")
        assert any("metacharacter" in e for e in errors)

    def test_shell_injection_pipe(self):
        errors = validate_install_cmd("pip install pkg | cat /etc/passwd")
        assert any("metacharacter" in e for e in errors)

    def test_shell_injection_backtick(self):
        errors = validate_install_cmd("pip install `evil`")
        assert any("metacharacter" in e for e in errors)

    def test_shell_injection_dollar(self):
        errors = validate_install_cmd("pip install $(evil)")
        assert any("metacharacter" in e for e in errors)


class TestValidateUrl:
    def test_valid_https(self):
        assert validate_url("https://github.com/repo") == []

    def test_empty_optional(self):
        assert validate_url("") == []

    def test_ip_address(self):
        assert len(validate_url("https://192.168.1.1/evil")) > 0

    def test_localhost(self):
        assert len(validate_url("http://localhost:8080")) > 0


class TestValidateSlug:
    def test_valid(self):
        assert validate_slug("cli-anything-gimp") == []

    def test_too_short(self):
        assert len(validate_slug("a")) > 0

    def test_uppercase(self):
        assert len(validate_slug("BadSlug")) > 0


class TestGenerateSlug:
    def test_simple(self):
        assert generate_slug("GIMP") == "gimp"

    def test_spaces(self):
        assert generate_slug("My CLI Tool") == "my-cli-tool"


class TestGenerateCliId:
    def test_format(self):
        cid = generate_cli_id()
        assert cid.startswith("cli_")
        assert len(cid) == 16  # "cli_" + 12 hex

    def test_unique(self):
        ids = {generate_cli_id() for _ in range(100)}
        assert len(ids) == 100


class TestValidateVersionProgression:
    def test_bump(self):
        validate_version_progression("2.0.0", "1.0.0")

    def test_same_rejected(self):
        with pytest.raises(ValueError):
            validate_version_progression("1.0.0", "1.0.0")

    def test_lower_rejected(self):
        with pytest.raises(ValueError):
            validate_version_progression("0.9.0", "1.0.0")

    def test_first_version(self):
        validate_version_progression("0.1.0", "")


class TestValidateStatusTransition:
    def test_valid(self):
        validate_status_transition("active", "hidden")

    def test_invalid(self):
        with pytest.raises(ValueError):
            validate_status_transition("removed", "hidden")

    def test_restore(self):
        validate_status_transition("removed", "active")


class TestScanCliTool:
    def test_clean(self):
        result = scan_cli_tool(
            "pip install git+https://github.com/HKUDS/CLI-Anything.git#subdirectory=gimp/agent-harness",
            "cli-anything-gimp", "GIMP 2.10+", "https://www.gimp.org", "SKILL.md",
        )
        assert result.risk_score < 0.3

    def test_shell_injection(self):
        result = scan_cli_tool("pip install pkg; rm -rf /", "cli-test")
        assert any(f.rule == "SHELL_INJECTION" for f in result.findings)

    def test_unsafe_http(self):
        result = scan_cli_tool("pip install git+http://evil.com/repo.git", "cli-test")
        assert any(f.rule == "UNSAFE_INSTALL_URL" for f in result.findings)

    def test_ip_address_url(self):
        result = scan_cli_tool("pip install git+https://192.168.1.1/repo.git", "cli-test")
        assert any(f.rule == "UNSAFE_INSTALL_URL" for f in result.findings)

    def test_localhost_url(self):
        result = scan_cli_tool("pip install git+https://localhost/repo.git", "cli-test")
        assert any(f.rule == "UNSAFE_INSTALL_URL" for f in result.findings)

    def test_suspicious_subdirectory(self):
        result = scan_cli_tool("pip install git+https://github.com/repo.git#subdirectory=../../etc", "cli-test")
        assert any(f.rule == "SUSPICIOUS_SUBDIRECTORY" for f in result.findings)

    def test_unknown_registry(self):
        result = scan_cli_tool("pip install git+https://evil-registry.com/repo.git", "cli-test")
        assert any(f.rule == "UNKNOWN_REGISTRY" for f in result.findings)

    def test_excessive_permissions(self):
        result = scan_cli_tool("pip install --system git+https://github.com/repo.git", "cli-test")
        assert any(f.rule == "EXCESSIVE_PERMISSIONS" for f in result.findings)

    def test_missing_homepage(self):
        result = scan_cli_tool("pip install git+https://github.com/repo.git", "cli-test", homepage="")
        assert any(f.rule == "MISSING_HOMEPAGE" for f in result.findings)

    def test_missing_skill_md(self):
        result = scan_cli_tool("pip install git+https://github.com/repo.git", "cli-test",
                               homepage="https://example.com")
        assert any(f.rule == "MISSING_SKILL_MD" for f in result.findings)

    def test_risk_score_capped(self):
        result = scan_cli_tool("pip install git+http://192.168.1.1/repo.git; rm -rf /; $(evil) && bad | worse",
                               "", "", "", "")
        assert result.risk_score <= 1.0
