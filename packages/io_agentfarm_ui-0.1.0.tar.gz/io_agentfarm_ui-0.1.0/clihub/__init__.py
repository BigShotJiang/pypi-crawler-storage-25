"""CLI Hub — portable agent CLI tools registry module.

Usage::

    from clihub import create_clihub_router, CLIHubConfig

    router = create_clihub_router(db=my_db_provider)
    app.include_router(router)
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from clihub.config import CLIHubConfig
from clihub.database import DBProvider


def create_clihub_router(
    db: DBProvider,
    config: CLIHubConfig | None = None,
) -> APIRouter:
    """Build and return a fully-wired CLI Hub APIRouter.

    Parameters
    ----------
    db:
        Object implementing the DBProvider protocol.
    config:
        Optional config overrides.
    """
    if config is None:
        config = CLIHubConfig()

    from clihub.search import CLISearchIndex
    search_index = CLISearchIndex(config.embedding_model)

    from clihub.routers import build_router
    return build_router(db=db, config=config, search_index=search_index)


__all__ = ["create_clihub_router", "CLIHubConfig", "DBProvider"]
