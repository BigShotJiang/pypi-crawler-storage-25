"""Lightweight DB layer — reads ioagentfarm's database.

Supports both SQLite and PostgreSQL (same DB as ioagentfarm).
All access is read-heavy; writes only happen when starting a session
(via ioagentfarm CLI subprocess, not direct INSERT).
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Any, Generator

from app.config import get_settings


def _parse_url(url: str) -> tuple[str, str]:
    """Returns (backend, connection_string)."""
    if url.startswith("postgresql://") or url.startswith("postgres://"):
        return "postgres", url
    path = ""
    if url.startswith("sqlite:///"):
        path = url[len("sqlite:///"):]
    elif url.startswith("sqlite://"):
        path = url[len("sqlite://"):]
    else:
        path = url
    return "sqlite", path


@contextmanager
def get_db() -> Generator[Any, None, None]:
    """Yield a DB connection with dict-like row access."""
    settings = get_settings()
    backend, connstr = _parse_url(settings.database_url)

    if backend == "postgres":
        import psycopg2
        import psycopg2.extras

        con = psycopg2.connect(connstr, cursor_factory=psycopg2.extras.RealDictCursor)
        con.autocommit = True
        cur = con.cursor()
        cur.execute("SET search_path TO iof, public;")
        try:
            yield con
        finally:
            con.close()
    else:
        con = sqlite3.connect(connstr)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL;")
        try:
            yield con
        finally:
            con.close()


def placeholder() -> str:
    """Parameter placeholder for the current backend."""
    settings = get_settings()
    backend, _ = _parse_url(settings.database_url)
    return "%s" if backend == "postgres" else "?"


def q(sql: str) -> str:
    """Rewrite ``?`` placeholders to the backend's style."""
    ph = placeholder()
    if ph == "?":
        return sql
    return sql.replace("?", ph)
