"""Configuration — reads from environment variables shared with ioagentfarm."""

from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()


def _parse_scopes(raw: str) -> list[str]:
    value = (raw or "").strip()
    if not value:
        return []

    if value.startswith("[") and value.endswith("]"):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return [str(scope).strip() for scope in parsed if str(scope).strip()]
            return []
        except json.JSONDecodeError:
            inner = value[1:-1].strip()
            if not inner:
                return []
            value = inner

    return [
        token.strip().strip('"').strip("'")
        for token in value.replace(",", " ").split()
        if token.strip().strip('"').strip("'")
    ]


class Settings:
    """App settings loaded from environment variables.

    Shared with ioagentfarm:
        IOF_ROOT          — state directory (default: .iof)
        IOF_DATABASE_URL  — database connection string

    UI-specific:
        IOF_AGENTFARM_DIR — path to io-agentfarm source (for workflow YAMLs)
        IOF_BIN           — ioagentfarm CLI binary
        IOF_UI_CORS       — comma-separated CORS origins (default: *)
        IOF_UI_SSE_POLL   — SSE poll interval in seconds (default: 0.5)
    """

    def __init__(self) -> None:
        self.iof_root = Path(os.getenv("IOF_ROOT", ".iof")).resolve()

        self.database_url = os.getenv("IOF_DATABASE_URL", "")
        if not self.database_url:
            self.database_url = f"sqlite:///{self.iof_root / 'state.db'}"

        # Path to ioagentfarm source root (for reading workflow YAMLs)
        default_agentfarm = str(Path(__file__).resolve().parent.parent.parent / "io-agentfarm")
        self.agentfarm_dir = Path(os.getenv("IOF_AGENTFARM_DIR", default_agentfarm))

        self.ioagentfarm_bin = os.getenv("IOF_BIN", "ioagentfarm")

        cors = os.getenv("IOF_UI_CORS", "*")
        self.cors_origins = [o.strip() for o in cors.split(",")]

        self.sse_poll_interval = float(os.getenv("IOF_UI_SSE_POLL", "0.5"))

        # Skills module
        self.skills_s3_prefix = os.getenv("IOF_SKILLS_S3_PREFIX", "skills")
        self.skills_embedding_model = os.getenv("IOF_SKILLS_EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5")

        # S3
        self.s3_bucket = os.getenv("IOF_S3_BUCKET", "")
        self.s3_prefix = os.getenv("IOF_S3_PREFIX", "")
        self.aws_region = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
        self.aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID", "")
        self.aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY", "")

        # Auth
        self.auth_jwt_secret = os.getenv("IOF_AUTH_JWT_SECRET", "change-me")
        self.auth_jwt_validity_hours = int(os.getenv("IOF_AUTH_JWT_HOURS", "12"))
        self.auth_frontend_url = os.getenv("IOF_AUTH_FRONTEND_URL", "http://localhost:5173")

        # SSO (Microsoft Entra)
        self.auth_sso_client_id = os.getenv("CLIENT_ID", "")
        self.auth_sso_client_secret = os.getenv("CLIENT_SECRET", "")
        self.auth_sso_tenant_id = os.getenv("TENANT_ID", "")
        self.auth_sso_scopes = _parse_scopes(os.getenv("SCOPES", "openid,profile,email"))
        self.auth_sso_redirect_uri = os.getenv("REDIRECT_URI", "")
        self.auth_sso_authorize_url = f"https://login.microsoftonline.com/{self.auth_sso_tenant_id}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
