"""Agent registry — DB-backed with smart cache.

Cache all agents from the DB ``agents`` table. TTL of 1 hour for cached entries.
On cache miss (unknown role), immediately query DB before falling back to
auto-generated display info. No static registry — DB is the source of truth.
"""

from __future__ import annotations

import logging
import time

logger = logging.getLogger(__name__)

_db_registry: dict[str, dict] = {}
_cache_loaded_at: float = 0
_CACHE_TTL = 3600  # 1 hour


def _load_all() -> dict[str, dict]:
    """Bulk-load all agents from DB (called once per TTL window)."""
    global _db_registry, _cache_loaded_at

    try:
        from app.database import get_db
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute("SELECT role, name, title, avatar, color FROM agents")
            registry = {}
            for row in cursor.fetchall():
                r = dict(row)
                registry[r["role"]] = {
                    "role": r["role"],
                    "name": r["name"],
                    "title": r["title"],
                    "avatar": r["avatar"],
                    "color": r["color"],
                }
            _db_registry = registry
            _cache_loaded_at = time.time()
            return _db_registry
    except Exception:
        logger.debug("agents table not available, using existing cache")
        return _db_registry


def _lookup_single(role: str) -> dict | None:
    """Query DB for a single agent by role (cache miss path)."""
    try:
        from app.database import get_db, q
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute(q("SELECT role, name, title, avatar, color FROM agents WHERE role=?"), (role,))
            row = cursor.fetchone()
            if row:
                r = dict(row)
                agent = {
                    "role": r["role"],
                    "name": r["name"],
                    "title": r["title"],
                    "avatar": r["avatar"],
                    "color": r["color"],
                }
                _db_registry[role] = agent  # warm cache for next call
                return agent
    except Exception:
        logger.debug("Single agent lookup failed for role=%s", role)
    return None


def reload_agents() -> None:
    """Force immediate cache refresh on next call."""
    global _cache_loaded_at
    _cache_loaded_at = 0


def get_agent(role: str) -> dict:
    """Get display info for a role.

    Fast path: serve from cache (TTL 1 hour).
    Cache miss: query DB for this specific role.
    Final fallback: auto-generate from role name.
    """
    # Refresh full cache if TTL expired
    now = time.time()
    if not _db_registry or (now - _cache_loaded_at) > _CACHE_TTL:
        _load_all()

    # Fast path — cache hit
    if role in _db_registry:
        return _db_registry[role].copy()

    # Cache miss — query DB for this specific role (new agent added recently)
    agent = _lookup_single(role)
    if agent:
        return agent.copy()

    # Final fallback — auto-generate (agent not in DB yet)
    return {
        "role": role,
        "name": role.replace("_", " ").title(),
        "title": role.replace("_", " ").title(),
        "color": "#888888",
        "avatar": role[:2].upper(),
    }


# Backwards compatibility alias
AGENT_REGISTRY = {}
