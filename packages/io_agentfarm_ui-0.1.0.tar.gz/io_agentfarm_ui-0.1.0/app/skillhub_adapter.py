"""Thin adapter wiring SkillHub into the agentfarm API.

Implements DBProvider using the host's database layer and constructs
the SkillHub router with the host's S3 client and configuration.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator

from fastapi import APIRouter

from skillhub import SkillHubConfig, create_skillhub_router
from skillhub.database import DBProvider


class _CursorWrapper:
    """Wraps a psycopg2 connection to expose cursor-based execute + commit.

    SkillHub modules call con.execute() / con.commit(). SQLite connections
    support this natively, but psycopg2 connections require a cursor.
    This wrapper bridges the gap.
    """

    def __init__(self, con: Any) -> None:
        self._con = con
        self._cursor = con.cursor()

    def execute(self, sql: str, params: tuple = ()) -> Any:
        self._cursor.execute(sql, params)
        return self._cursor

    def commit(self) -> None:
        self._con.commit()


class AgentFarmDBProvider:
    """DBProvider backed by the host's app.database module."""

    @contextmanager
    def get_connection(self) -> Generator[Any, None, None]:
        from app.database import get_db, _parse_url
        from app.config import get_settings

        settings = get_settings()
        backend, _ = _parse_url(settings.database_url)

        with get_db() as con:
            if backend == "postgres":
                yield _CursorWrapper(con)
            else:
                yield con

    def placeholder(self) -> str:
        from app.database import placeholder
        return placeholder()


def get_skills_router() -> APIRouter:
    """Build the SkillHub router wired to agentfarm's DB and S3."""
    from app.config import get_settings
    from app.routers.s3 import _get_s3_client

    settings = get_settings()

    config = SkillHubConfig(
        s3_prefix=getattr(settings, "skills_s3_prefix", "skills"),
        embedding_model=getattr(settings, "skills_embedding_model", "BAAI/bge-small-en-v1.5"),
    )

    return create_skillhub_router(
        db=AgentFarmDBProvider(),
        s3_client_factory=_get_s3_client,
        s3_bucket=settings.s3_bucket,
        config=config,
    )
