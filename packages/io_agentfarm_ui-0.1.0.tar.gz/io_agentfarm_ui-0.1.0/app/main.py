"""FastAPI backend for ioagentfarm Teams-like chat UI.

Reads from ioagentfarm's database (SQLite or PostgreSQL).
Starts workflow sessions via ioagentfarm CLI subprocess.
Streams agent output in real-time via SSE.

    uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import workspaces, workflows, sessions, messages, s3, auth, agentfarm_sessions
from app.routers.product_catalog import brand_router, play_router, mission_router
from app.skillhub_adapter import get_skills_router
from app.clihub_adapter import get_cli_router

app = FastAPI(
    title="ioagentfarm UI",
    description="Backend API for ioagentfarm Teams-like chat UI",
    version="0.1.0",
)

settings = get_settings()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(workspaces.router)
app.include_router(workflows.router)
app.include_router(sessions.router)
app.include_router(messages.router)
app.include_router(s3.router, prefix="/api")
app.include_router(auth.router)
app.include_router(agentfarm_sessions.router)
app.include_router(brand_router)
app.include_router(play_router)
app.include_router(mission_router)
app.include_router(get_skills_router())
app.include_router(get_cli_router())


@app.get("/api/health")
def health():
    """Health check."""
    return {"status": "ok"}


@app.get("/api/agents")
def list_agents():
    """Agent registry — names, titles, colors, avatars from the DB."""
    from app.agents import _load_all
    return list(_load_all().values())
