"""Product catalog — brands, plays, missions (read from product_* tables).

Source of truth: ``iof.product_brands``, ``iof.product_plays``,
``iof.product_missions``.  Synced from YAML via ``ioagentfarm sync-savants``.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, HTTPException

from app.database import get_db, q

logger = logging.getLogger(__name__)


def _parse_jsonb(row: dict, *keys: str) -> dict:
    """Parse JSONB text fields into Python objects."""
    for key in keys:
        val = row.get(key)
        if isinstance(val, str):
            try:
                row[key] = json.loads(val)
            except (json.JSONDecodeError, TypeError):
                pass
    return row


# ── Brands ───────────────────────────────────────────────────────

brand_router = APIRouter(prefix="/api/product_brands", tags=["product_catalog"])


@brand_router.get("")
def list_brands():
    """All brands with therapeutic area and goal scenario."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT brand_slug, name, brand, tagline, therapeutic_area, "
              "goal_scenario, config FROM product_brands ORDER BY name")
        )
        rows = []
        for r in cursor.fetchall():
            rows.append(_parse_jsonb(dict(r), "config"))
        return rows


@brand_router.get("/{brand_slug}")
def get_brand(brand_slug: str):
    """Single brand detail."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT brand_slug, name, brand, tagline, therapeutic_area, "
              "goal_scenario, config FROM product_brands WHERE brand_slug=?"),
            (brand_slug,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Brand '{brand_slug}' not found")
        return _parse_jsonb(dict(row), "config")


@brand_router.get("/{brand_slug}/plays")
def list_brand_plays(brand_slug: str):
    """All plays for a brand with signal/barrier mappings and impact ranges."""
    _assert_brand_exists(brand_slug)
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT play_id, name, description, type, addresses_signals, "
              "addresses_barriers, expected_impact, impact_metric, preconditions "
              "FROM product_plays WHERE brand_slug=? ORDER BY play_id"),
            (brand_slug,),
        )
        rows = []
        for r in cursor.fetchall():
            rows.append(_parse_jsonb(
                dict(r),
                "addresses_signals", "addresses_barriers",
                "expected_impact", "preconditions",
            ))
        return rows


@brand_router.get("/{brand_slug}/missions")
def list_brand_missions(brand_slug: str):
    """Missions for a brand with workflow_id, sub_barriers, and nested datasets."""
    _assert_brand_exists(brand_slug)
    datasets_by_mission = _fetch_datasets_by_mission(brand_slug)
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT name, display_name, tagline, difficulty, goal_category, "
              "scoring, workflow_id, sub_barriers "
              "FROM product_missions WHERE brand_slug=? ORDER BY name"),
            (brand_slug,),
        )
        rows = []
        for r in cursor.fetchall():
            row = _parse_jsonb(dict(r), "scoring", "sub_barriers")
            row["datasets"] = datasets_by_mission.get(row["name"], [])
            rows.append(row)
        return rows


def _assert_brand_exists(brand_slug: str) -> None:
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT 1 FROM product_brands WHERE brand_slug=?"),
            (brand_slug,),
        )
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail=f"Brand '{brand_slug}' not found")


def _public_dataset_fields(row: dict) -> dict:
    """Dataset fields safe to expose to non-admin callers.

    Intentionally omits ``hidden_sub_barrier`` and ``expected_evidence`` —
    those are scoring ground-truth and would leak the answer during a session.
    """
    return {
        "dataset_id": row["dataset_id"],
        "display_name": row.get("display_name", ""),
        "entities": row.get("entities") or [],
        "analyst_entities": row.get("analyst_entities") or [],
        "strategist_entities": row.get("strategist_entities") or [],
    }


def _fetch_datasets_by_mission(brand_slug: str) -> dict[str, list[dict]]:
    """Return {mission_name: [dataset, ...]} for all datasets under a brand."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT mission_name, dataset_id, display_name, entities, "
              "analyst_entities, strategist_entities "
              "FROM product_datasets WHERE brand_slug=? "
              "ORDER BY mission_name, dataset_id"),
            (brand_slug,),
        )
        grouped: dict[str, list[dict]] = {}
        for r in cursor.fetchall():
            row = _parse_jsonb(dict(r), "entities", "analyst_entities", "strategist_entities")
            grouped.setdefault(row["mission_name"], []).append(_public_dataset_fields(row))
        return grouped


def _fetch_datasets_for_mission(brand_slug: str, mission_name: str) -> list[dict]:
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT dataset_id, display_name, entities, analyst_entities, "
              "strategist_entities FROM product_datasets "
              "WHERE brand_slug=? AND mission_name=? ORDER BY dataset_id"),
            (brand_slug, mission_name),
        )
        out = []
        for r in cursor.fetchall():
            row = _parse_jsonb(dict(r), "entities", "analyst_entities", "strategist_entities")
            out.append(_public_dataset_fields(row))
        return out


# ── Plays ────────────────────────────────────────────────────────

play_router = APIRouter(prefix="/api/product_plays", tags=["product_catalog"])


@play_router.get("/{play_id}")
def get_play(play_id: str):
    """Full play detail."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT play_id, brand_slug, name, description, type, "
              "addresses_signals, addresses_barriers, expected_impact, "
              "impact_metric, preconditions "
              "FROM product_plays WHERE play_id=?"),
            (play_id,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Play '{play_id}' not found")
        return _parse_jsonb(
            dict(row),
            "addresses_signals", "addresses_barriers",
            "expected_impact", "preconditions",
        )


# ── Missions ─────────────────────────────────────────────────────

mission_router = APIRouter(prefix="/api/product_missions", tags=["product_catalog"])


@mission_router.get("/{brand_slug}/{mission_name}")
def get_mission(brand_slug: str, mission_name: str):
    """Full mission detail with workflow_id, sub_barriers, and nested datasets."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT name, brand_slug, display_name, tagline, difficulty, "
              "goal_category, scoring, workflow_id, sub_barriers "
              "FROM product_missions WHERE brand_slug=? AND name=?"),
            (brand_slug, mission_name),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(
                status_code=404,
                detail=f"Mission '{mission_name}' not found for brand '{brand_slug}'",
            )
        mission = _parse_jsonb(dict(row), "scoring", "sub_barriers")
        mission["datasets"] = _fetch_datasets_for_mission(brand_slug, mission_name)
        return mission
