"""Session (run) management — create, list, inspect, team roster.

All endpoints are nested under ``/api/workflows/{workflow}/sessions``.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import threading
import time
from typing import Any

from fastapi import APIRouter, HTTPException

from app.agents import get_agent
from app.config import get_settings
from app.database import get_db, q

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/workflows/{workflow}/sessions", tags=["sessions"])


# ── Helpers ───────────────────────────────────────────────────────

def _ioagentfarm_env() -> dict[str, str]:
    """Build env dict for ioagentfarm subprocess calls."""
    settings = get_settings()
    env = os.environ.copy()
    env["IOF_ROOT"] = str(settings.iof_root)
    if settings.database_url:
        env["IOF_DATABASE_URL"] = settings.database_url
    env.setdefault("PYTHONIOENCODING", "utf-8")
    return env


def _get_workflow_team(workflow_name: str) -> list[dict]:
    """Fetch team_json from the workflows table (source of truth)."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT team_json FROM workflows WHERE code=?"),
            (workflow_name,),
        )
        row = cursor.fetchone()
        if row and row["team_json"]:
            return json.loads(row["team_json"])
    return []


def _build_team_roster(steps: list[dict], workflow_name: str = "") -> list[dict]:
    """Build team roster from workflow's team_json, enriched with step status.

    team_json from the workflows table is the source of truth for team
    membership. Step data provides the live status (active/idle/done/failed).
    """
    # Compute status from steps
    role_status: dict[str, dict[str, Any]] = {}
    for s in steps:
        role = s["role"]
        if role not in role_status:
            role_status[role] = {"status": "idle", "current_step": None}

        if s["status"] == "running":
            role_status[role] = {"status": "active", "current_step": s["step_key"]}
        elif s["status"] == "failed":
            role_status[role] = {"status": "failed", "current_step": s["step_key"]}
        elif s["status"] == "done" and role_status[role]["status"] == "idle":
            role_status[role]["status"] = "done"

    # Use team_json as source of truth for team membership
    team_members = _get_workflow_team(workflow_name) if workflow_name else []

    if team_members:
        # TODO: fix ensure_workflow to always include project_lead in team_json
        if not any(m.get("role") == "project_lead" for m in team_members):
            team_members = [{"role": "project_lead"}] + team_members
        team = []
        seen_roles = set()
        for member in team_members:
            role = member.get("role", "")
            if not role or role in seen_roles:
                continue
            seen_roles.add(role)
            agent = get_agent(role)
            info = role_status.get(role, {"status": "idle", "current_step": None})
            agent["status"] = info["status"]
            agent["current_step"] = info["current_step"]
            team.append(agent)
        return team

    # Fallback: derive from steps if no team_json
    team = []
    for role, info in role_status.items():
        agent = get_agent(role)
        agent["status"] = info["status"]
        agent["current_step"] = info["current_step"]
        team.append(agent)

    # TODO: fix ensure_workflow to always include project_lead in team_json
    # Patch: ensure project_lead is always in the roster (orchestrates every run)
    if not any(t.get("role") == "project_lead" for t in team):
        pl = get_agent("project_lead")
        pl["status"] = "active"
        pl["current_step"] = None
        team.insert(0, pl)

    return team


def _get_run_or_404(run_id: str, workflow: str) -> dict:
    """Fetch a run and validate it belongs to the given workflow."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT id, workspace_id, workflow_name, workflow_id, goal, project_dir, status, "
              "created_at, updated_at FROM runs WHERE id=?"),
            (run_id,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Session '{run_id}' not found")
        run = dict(row)
        if run["workflow_name"] != workflow:
            raise HTTPException(
                status_code=404,
                detail=f"Session '{run_id}' belongs to workflow '{run['workflow_name']}', not '{workflow}'",
            )
        return run


def _execute_pipeline(run_id: str) -> None:
    """Drive the pipeline in a background thread.

    Loops: next-step → run-step (or step-complete for project_lead).
    Runs until all steps are done or the run fails.
    """
    settings = get_settings()
    env = _ioagentfarm_env()
    bin_path = settings.ioagentfarm_bin

    while True:
        # Get next runnable step
        try:
            result = subprocess.run(
                [bin_path, "next-step", "--run-id", run_id],
                capture_output=True, text=True, env=env, timeout=30,
            )
        except subprocess.TimeoutExpired:
            logger.error("next-step timed out for run %s", run_id)
            break

        if result.returncode != 0:
            logger.warning("next-step failed for run %s: %s", run_id, result.stderr)
            break

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            logger.error("next-step returned invalid JSON for run %s", run_id)
            break

        # Pipeline finished
        if data.get("done"):
            logger.info("Pipeline complete for run %s", run_id)
            break

        # Waiting for deps (running step not yet finished)
        if data.get("waiting"):
            time.sleep(2)
            continue

        step_key = data.get("step_key", "")
        role = data.get("role", "")
        if not step_key:
            break

        if role == "project_lead":
            # Auto-complete project_lead steps (assessment, signoff, etc.)
            subprocess.run(
                [bin_path, "step-complete",
                 "--step-key", step_key, "--run-id", run_id,
                 "--output", "STATUS: done\nOUTPUT: Approved and proceeding."],
                capture_output=True, text=True, env=env,
            )
        else:
            # Execute sub-agent step (blocking — waits for agent to finish)
            result = subprocess.run(
                [bin_path, "run-step",
                 "--step-key", step_key, "--run-id", run_id],
                capture_output=True, text=True, env=env,
                encoding="utf-8", errors="replace",
            )
            if result.returncode != 0:
                logger.error(
                    "run-step failed for %s/%s (rc=%d): %s",
                    run_id, step_key, result.returncode,
                    (result.stderr or result.stdout or "")[:500],
                )

    logger.info("Execution thread exiting for run %s", run_id)


# ── Endpoints ─────────────────────────────────────────────────────

@router.post("")
def start_session(workflow: str, req: dict):
    """Start a new workflow session.

    1. Calls ``ioagentfarm start-run`` to create the run + materialize steps.
    2. Launches a background thread to drive execution via next-step / run-step.
    """
    goal = req.get("goal", "")
    project_dir = req.get("project_dir", "")

    if not goal:
        raise HTTPException(status_code=400, detail="goal is required")

    settings = get_settings()
    env = _ioagentfarm_env()

    cmd = [settings.ioagentfarm_bin, "start-run", workflow, "--goal", goal]
    if project_dir:
        cmd += ["--project-dir", project_dir]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, env=env, timeout=30,
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="Timeout creating run")

    if result.returncode != 0:
        raise HTTPException(
            status_code=500,
            detail=f"start-run failed: {result.stderr.strip() or result.stdout.strip()}",
        )

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail=f"Invalid JSON from start-run: {result.stdout[:200]}")

    run_id = data.get("run_id", "")
    if not run_id:
        raise HTTPException(status_code=500, detail="No run_id in start-run response")

    # Launch execution in background thread
    thread = threading.Thread(
        target=_execute_pipeline, args=(run_id,),
        name=f"pipeline-{run_id}", daemon=True,
    )
    thread.start()

    return {
        "run_id": run_id,
        "workflow": workflow,
        "status": "running",
        "message": f"Session started. Workflow '{workflow}' is now executing.",
        "total_steps": data.get("total_steps", 0),
    }


@router.get("")
def list_sessions(workflow: str, limit: int = 20, status: str | None = None):
    """List sessions for a workflow (most recent first)."""
    with get_db() as con:
        cursor = con.cursor()
        sql = ("SELECT id, workspace_id, workflow_name, workflow_id, goal, project_dir, status, "
               "created_at, updated_at FROM runs WHERE workflow_name=?")
        params: list = [workflow]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        return [dict(r) for r in cursor.fetchall()]


@router.get("/{run_id}")
def get_session(workflow: str, run_id: str):
    """Session detail — run info, step progress, and team roster."""
    run = _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT step_key, role, status, attempt, max_attempts, "
              "COALESCE(output_text,'') AS output_text, created_at, updated_at "
              "FROM steps WHERE run_id=? ORDER BY seq ASC"),
            (run_id,),
        )
        steps = []
        for r in cursor.fetchall():
            s = dict(r)
            s["agent"] = get_agent(s["role"])
            steps.append(s)

    run["steps"] = steps
    run["team"] = _build_team_roster(steps, workflow)
    return run


@router.get("/{run_id}/status")
def get_session_status(workflow: str, run_id: str):
    """Lightweight status check for a session."""
    run = _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT status FROM steps WHERE run_id=?"), (run_id,),
        )
        steps = [dict(r) for r in cursor.fetchall()]

    total = len(steps)
    done = sum(1 for s in steps if s["status"] == "done")
    running = sum(1 for s in steps if s["status"] == "running")
    failed = sum(1 for s in steps if s["status"] == "failed")
    pending = sum(1 for s in steps if s["status"] == "pending")

    return {
        "run_id": run_id,
        "status": run["status"],
        "steps_total": total,
        "steps_done": done,
        "steps_running": running,
        "steps_failed": failed,
        "steps_pending": pending,
    }


@router.get("/{run_id}/steps")
def get_session_steps(workflow: str, run_id: str):
    """Step progress for a session."""
    _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT step_key, role, status, attempt, max_attempts, deps_json, "
              "meta_json, COALESCE(output_text,'') AS output_text, "
              "created_at, updated_at "
              "FROM steps WHERE run_id=? ORDER BY seq ASC"),
            (run_id,),
        )
        steps = []
        for r in cursor.fetchall():
            s = dict(r)
            s["agent"] = get_agent(s["role"])
            steps.append(s)
        return steps


@router.get("/{run_id}/team")
def get_session_team(workflow: str, run_id: str):
    """Team roster with current active/idle/done status."""
    _get_run_or_404(run_id, workflow)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT step_key, role, status FROM steps "
              "WHERE run_id=? ORDER BY seq ASC"),
            (run_id,),
        )
        steps = [dict(r) for r in cursor.fetchall()]
        return _build_team_roster(steps, workflow)
