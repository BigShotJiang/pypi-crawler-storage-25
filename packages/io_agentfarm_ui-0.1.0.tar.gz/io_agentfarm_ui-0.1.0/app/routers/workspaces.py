"""Workspace management — list, detail, workspace-scoped workflows and sessions.

Workspaces are the top-level grouping (team/group/dept):
  Workspace → Workflow(s) → Run(s)/Session(s).
"""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, HTTPException

from app.agents import get_agent
from app.database import get_db, q
from app.routers.workflows import _list_db_workflows, _discover_yaml_workflows, _parse_workflow, _extract_roles

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/workspaces", tags=["workspaces"])


def _get_workspace_or_404(workspace_id: int) -> dict:
    """Fetch a workspace by id or raise 404."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT id, code, name, description, "
              "created_at, updated_at FROM workspaces WHERE id=?"),
            (workspace_id,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Workspace id={workspace_id} not found")
        return dict(row)


@router.get("")
def list_workspaces():
    """List all workspaces with run/workflow counts."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            "SELECT id, code, name, description, "
            "created_at, updated_at FROM workspaces ORDER BY name ASC"
        )
        workspaces = [dict(r) for r in cursor.fetchall()]

    for ws in workspaces:
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute(
                q("SELECT COUNT(*) AS cnt FROM runs WHERE workspace_id=?"),
                (ws["id"],),
            )
            ws["run_count"] = int(cursor.fetchone()["cnt"])
            cursor.execute(
                q("SELECT COUNT(DISTINCT workflow_name) AS cnt FROM runs WHERE workspace_id=?"),
                (ws["id"],),
            )
            ws["workflow_count"] = int(cursor.fetchone()["cnt"])

    return workspaces


@router.get("/{workspace_id}")
def get_workspace(workspace_id: int):
    """Workspace detail with workflows and recent runs."""
    ws = _get_workspace_or_404(workspace_id)

    with get_db() as con:
        cursor = con.cursor()

        # Workflows used in this workspace (derived from runs)
        cursor.execute(
            q("SELECT DISTINCT workflow_name, workflow_id FROM runs "
              "WHERE workspace_id=? ORDER BY workflow_name ASC"),
            (workspace_id,),
        )
        wf_rows = cursor.fetchall()

        workflows = []
        for wr in wf_rows:
            wf_code = wr["workflow_name"]
            wf_id = wr["workflow_id"]
            wf_info = {"code": wf_code, "name": wf_code.replace("_", " ").title()}

            if wf_id:
                cursor.execute(
                    q("SELECT code, name, description FROM workflows WHERE id=?"),
                    (wf_id,),
                )
                wf_row = cursor.fetchone()
                if wf_row:
                    wf_info["name"] = wf_row["name"] or wf_code.replace("_", " ").title()
                    wf_info["description"] = wf_row["description"] or ""

            # Run counts for this workflow in this workspace
            cursor.execute(
                q("SELECT COUNT(*) AS total, "
                  "SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running, "
                  "SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done, "
                  "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed "
                  "FROM runs WHERE workspace_id=? AND workflow_name=?"),
                (workspace_id, wf_code),
            )
            counts = dict(cursor.fetchone())
            wf_info["runs"] = {
                "total": int(counts["total"] or 0),
                "running": int(counts["running"] or 0),
                "done": int(counts["done"] or 0),
                "failed": int(counts["failed"] or 0),
            }
            workflows.append(wf_info)

        # Recent runs across all workflows
        cursor.execute(
            q("SELECT id, workspace_id, workflow_name, workflow_id, goal, "
              "project_dir, status, created_at, updated_at "
              "FROM runs WHERE workspace_id=? ORDER BY created_at DESC LIMIT 20"),
            (workspace_id,),
        )
        recent_runs = [dict(r) for r in cursor.fetchall()]

    ws["workflows"] = workflows
    ws["recent_runs"] = recent_runs
    return ws


@router.get("/{workspace_id}/workflows")
def list_workspace_workflows(workspace_id: int):
    """All available workflows, enriched with run counts for this workspace.

    Merges DB workflows with YAML-discovered workflows (same as GET /api/workflows),
    then adds per-workflow run stats scoped to this workspace.
    """
    _get_workspace_or_404(workspace_id)

    # Build the full workflow map: YAML base layer + DB override layer
    result_map: dict[str, dict] = {}

    # 1. YAML-discovered workflows (base layer)
    yaml_workflows = _discover_yaml_workflows()
    for code, yaml_path in yaml_workflows.items():
        data = _parse_workflow(yaml_path)
        steps = [s.get("key", "") for s in data.get("steps", [])]
        roles = _extract_roles(data)
        result_map[code] = {
            "code": code,
            "name": code.replace("_", " ").title(),
            "description": data.get("description", code),
            "steps": steps,
            "roles": roles,
            "team": [get_agent(r) for r in roles],
        }

    # 2. DB workflows (override layer)
    db_workflows = _list_db_workflows()
    for code, row in db_workflows.items():
        steps = json.loads(row.get("steps_json") or "[]")
        roles = json.loads(row.get("roles_json") or "[]")
        result_map[code] = {
            "id": row["id"],
            "code": code,
            "name": row.get("name") or code.replace("_", " ").title(),
            "description": row.get("description") or code,
            "steps": steps,
            "roles": roles,
            "team": [get_agent(r) for r in roles],
        }

    # 3. Enrich each workflow with run counts scoped to this workspace
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT workflow_name, "
              "COUNT(*) AS total, "
              "SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) AS running, "
              "SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done, "
              "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed "
              "FROM runs WHERE workspace_id=? GROUP BY workflow_name"),
            (workspace_id,),
        )
        run_counts = {r["workflow_name"]: dict(r) for r in cursor.fetchall()}

    for code, wf in result_map.items():
        counts = run_counts.get(code, {})
        wf["runs"] = {
            "total": int(counts.get("total") or 0),
            "running": int(counts.get("running") or 0),
            "done": int(counts.get("done") or 0),
            "failed": int(counts.get("failed") or 0),
        }

    return list(result_map.values())


@router.get("/{workspace_id}/sessions")
def list_workspace_sessions(workspace_id: int, limit: int = 200, status: str | None = None):
    """All runs/sessions for a workspace, across all workflows."""
    _get_workspace_or_404(workspace_id)

    with get_db() as con:
        cursor = con.cursor()
        sql = ("SELECT id, workspace_id, workflow_name, workflow_id, goal, "
               "project_dir, status, created_at, updated_at "
               "FROM runs WHERE workspace_id=?")
        params: list = [workspace_id]
        if status:
            sql += " AND status=?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor.execute(q(sql), tuple(params))
        return [dict(r) for r in cursor.fetchall()]
