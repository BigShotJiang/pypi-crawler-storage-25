"""Authentication endpoints adapted from integration-platform auth module.

Implements DB-backed username/password login plus Microsoft Entra SSO.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone
from typing import Annotated

import bcrypt
import msal
from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import RedirectResponse

from app.config import get_settings
from app.database import get_db, q
from app.schemas import AuthLoginRequest, AuthTokenResponse

router = APIRouter(prefix="/api/auth", tags=["auth"])

INVALID_LOGIN_DETAIL = "Invalid email or password"


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _jwt_encode_hs256(payload: dict, secret: str) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    header_b64 = _b64url(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = _b64url(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    return f"{header_b64}.{payload_b64}.{_b64url(signature)}"


def _get_msal_app() -> msal.ConfidentialClientApplication:
    settings = get_settings()
    if not settings.auth_sso_client_id or not settings.auth_sso_client_secret:
        raise HTTPException(
            status_code=503,
            detail="SSO is not fully configured. Set CLIENT_ID and CLIENT_SECRET.",
        )
    return msal.ConfidentialClientApplication(
        client_id=settings.auth_sso_client_id,
        authority=settings.auth_sso_authorize_url,
        client_credential=settings.auth_sso_client_secret,
    )


def _get_sso_scopes() -> list[str]:
    scopes = get_settings().auth_sso_scopes
    if not scopes:
        raise HTTPException(
            status_code=503,
            detail="SSO scopes are not configured. Set SCOPES (e.g. openid,profile,email).",
        )
    return scopes


def _safe_decode_password(raw_password: str) -> str:
    try:
        return base64.b64decode(raw_password).decode("utf-8")
    except Exception:
        return raw_password


def _verify_password(input_password: str, stored_password: str) -> bool:
    try:
        return bcrypt.checkpw(
            input_password.encode("utf-8"),
            stored_password.encode("utf-8"),
        )
    except (ValueError, TypeError):
        return False


def _get_user_by_email(email: str) -> dict | None:
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q('SELECT id, sso_id, first_name, last_name, email, is_active FROM "user" WHERE lower(email)=lower(?)'),
            (email,),
        )
        row = cursor.fetchone()
        return dict(row) if row else None


def _get_password_by_user_id(user_id: int | str) -> str | None:
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT password FROM user_password WHERE user_id=?"),
            (user_id,),
        )
        row = cursor.fetchone()
        if not row:
            return None
        return row["password"] if not isinstance(row, dict) else row.get("password")


def _upsert_user_from_sso(email: str, first_name: str, last_name: str, sso_id: str) -> dict:
    existing = _get_user_by_email(email)
    if existing:
        if not existing.get("is_active", True):
            raise HTTPException(status_code=403, detail="User account is inactive")
        return existing

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q(
                'INSERT INTO "user"(sso_id, first_name, last_name, email, is_active, created_date) '
                "VALUES(?, ?, ?, ?, ?, ?)"
            ),
            (sso_id, first_name, last_name, email, 1, now),
        )
        if hasattr(con, "commit"):
            con.commit()

    created = _get_user_by_email(email)
    if not created:
        raise HTTPException(status_code=500, detail="Failed to create SSO user")
    return created


def _create_access_token(
    user_id: str,
    first_name: str,
    last_name: str,
    email: str,
    ipaddr: str,
    custom_claims: dict | None = None,
) -> str:
    settings = get_settings()
    iat = datetime.now(timezone.utc)
    exp = iat + timedelta(hours=settings.auth_jwt_validity_hours)
    full_name = f"{first_name} {last_name}".strip()

    payload = {
        "family_name": last_name,
        "given_name": first_name,
        "ipaddr": ipaddr,
        "name": full_name,
        "unique_name": email,
        "customClaims": custom_claims or {},
        "userId": user_id,
        "userName": email,
        "iat": int(iat.timestamp()),
        "exp": int(exp.timestamp()),
        "ssoProvider": "local",
    }
    return _jwt_encode_hs256(payload, settings.auth_jwt_secret)


@router.post(
    "/login",
    response_model=AuthTokenResponse,
    responses={401: {"description": "Invalid credentials"}, 403: {"description": "Inactive user"}},
)
def login(request: Request, data: AuthLoginRequest):
    """Authenticate against user and user_password tables and return JWT."""
    user = _get_user_by_email(data.email)
    if not user:
        raise HTTPException(status_code=401, detail=INVALID_LOGIN_DETAIL)

    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="User account is inactive")

    stored_password = _get_password_by_user_id(user["id"])
    if not stored_password:
        raise HTTPException(status_code=401, detail=INVALID_LOGIN_DETAIL)

    input_password = _safe_decode_password(data.password)
    if not _verify_password(input_password, stored_password):
        raise HTTPException(status_code=401, detail=INVALID_LOGIN_DETAIL)

    ipaddr = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    if not ipaddr and request.client:
        ipaddr = request.client.host

    first_name = str(user.get("first_name") or "")
    last_name = str(user.get("last_name") or "")
    email = str(user.get("email") or data.email)
    token = _create_access_token(
        user_id=str(user["id"]),
        first_name=first_name,
        last_name=last_name,
        email=email,
        ipaddr=ipaddr,
        custom_claims={"role": "user", "permissions": []},
    )
    return AuthTokenResponse(accessToken=token)


@router.get(
    "/sso/login",
    responses={503: {"description": "SSO not configured"}},
)
def sso_login(state: Annotated[str | None, Query()] = None):
    """Redirect to Microsoft Entra authorize endpoint."""
    settings = get_settings()
    if not settings.auth_sso_redirect_uri:
        raise HTTPException(
            status_code=503,
            detail="SSO is not fully configured. Set REDIRECT_URI.",
        )

    url = _get_msal_app().get_authorization_request_url(
        scopes=_get_sso_scopes(),
        redirect_uri=settings.auth_sso_redirect_uri,
        state=state,
    )
    return RedirectResponse(url)


@router.get(
    "/sso/callback",
    responses={
        400: {"description": "Missing authorization code"},
        401: {"description": "SSO authentication failed"},
        403: {"description": "Inactive user"},
        500: {"description": "User creation failed"},
        503: {"description": "SSO not configured"},
    },
)
def sso_callback(request: Request, code: Annotated[str | None, Query()] = None):
    """Handle Microsoft Entra callback and issue app JWT."""
    settings = get_settings()
    if not code:
        raise HTTPException(status_code=400, detail="Missing authorization code")

    if not settings.auth_sso_redirect_uri:
        raise HTTPException(status_code=503, detail="SSO is not fully configured. Set REDIRECT_URI.")

    try:
        result = _get_msal_app().acquire_token_by_authorization_code(
            code=code,
            scopes=_get_sso_scopes(),
            redirect_uri=settings.auth_sso_redirect_uri,
        )
    except Exception:
        raise HTTPException(status_code=401, detail="Failed to acquire token from SSO provider")

    if "error" in result:
        raise HTTPException(status_code=401, detail="SSO authentication failed")

    claims = result.get("id_token_claims")
    if not claims:
        raise HTTPException(status_code=401, detail="No claims found in token")

    email = claims.get("preferred_username") or claims.get("email") or claims.get("upn")
    if not email:
        raise HTTPException(status_code=401, detail="Email not found in token")

    full_name = str(claims.get("name") or "").strip()
    name_parts = full_name.split()
    first_name = name_parts[0] if name_parts else ""
    last_name = " ".join(name_parts[1:]) if len(name_parts) > 1 else ""

    sso_id = claims.get("oid")
    if not sso_id:
        raise HTTPException(status_code=401, detail="SSO ID (oid) not found")

    user = _upsert_user_from_sso(email=email, first_name=first_name, last_name=last_name, sso_id=sso_id)

    ipaddr = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    if not ipaddr and request.client:
        ipaddr = request.client.host

    token = _create_access_token(
        user_id=str(user["id"]),
        first_name=first_name,
        last_name=last_name,
        email=email,
        ipaddr=ipaddr,
        custom_claims={"role": "user", "permissions": []},
    )

    return RedirectResponse(f"{settings.auth_frontend_url}/auth/token-receiver?token={token}")
