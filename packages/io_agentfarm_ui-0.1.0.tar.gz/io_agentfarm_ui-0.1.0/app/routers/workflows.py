"""Workflow discovery — DB-first with YAML fallback.

The orchestrator lazily creates workflow records in the DB on first run.
This router reads from DB when available, falling back to YAML discovery
for workflows that haven't been run yet.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import yaml
from fastapi import APIRouter, HTTPException

from app.agents import get_agent
from app.config import get_settings
from app.database import get_db, q

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


# ── DB-backed workflows ──────────────────────────────────────────

def _list_db_workflows() -> dict[str, dict]:
    """Read workflows from the DB (populated lazily by orchestrator)."""
    try:
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute(
                "SELECT id, code, name, description, steps_json, roles_json, "
                "created_at, updated_at FROM workflows ORDER BY code ASC"
            )
            return {r["code"]: dict(r) for r in cursor.fetchall()}
    except Exception:
        # Table may not exist yet on fresh installs
        return {}


def _get_db_workflow(code: str) -> dict | None:
    """Read a single workflow from the DB by code."""
    try:
        with get_db() as con:
            cursor = con.cursor()
            cursor.execute(
                q("SELECT id, code, name, description, steps_json, roles_json, "
                  "created_at, updated_at FROM workflows WHERE code=?"),
                (code,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    except Exception:
        return None


# ── YAML-backed workflows (fallback) ────────────────────────────

def _discover_yaml_workflows() -> dict[str, Path]:
    """Find workflow YAML files from ioagentfarm source + local overrides."""
    settings = get_settings()
    workflows: dict[str, Path] = {}

    # Bundled workflows in ioagentfarm package
    pkg_dir = settings.agentfarm_dir / "ioagentfarm" / "workflows"
    if pkg_dir.is_dir():
        for wf_dir in sorted(pkg_dir.iterdir()):
            yaml_path = wf_dir / "workflow.yaml"
            if yaml_path.exists():
                workflows[wf_dir.name] = yaml_path

    # Local overrides (.iof/workflows/) take priority
    local_dir = settings.iof_root / "workflows"
    if local_dir.is_dir():
        for wf_dir in sorted(local_dir.iterdir()):
            yaml_path = wf_dir / "workflow.yaml"
            if yaml_path.exists():
                workflows[wf_dir.name] = yaml_path

    return workflows


def _parse_workflow(yaml_path: Path) -> dict:
    with open(yaml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _extract_roles(data: dict) -> list[str]:
    """Extract unique role names from the roles list."""
    role_names: list[str] = []
    for r in data.get("roles", []):
        if isinstance(r, dict):
            role_names.append(r.get("name", ""))
        elif isinstance(r, str):
            role_names.append(r)
    return list(dict.fromkeys(role_names))  # dedupe, preserve order


# ── Endpoints ────────────────────────────────────────────────────

@router.get("")
def list_workflows():
    """List available workflows with team info.

    Merges DB workflows (from runs) with YAML-discovered workflows.
    DB entries take priority when both exist for the same name.
    """
    result_map: dict[str, dict] = {}

    # 1. YAML-discovered workflows (base layer)
    yaml_workflows = _discover_yaml_workflows()
    for code, yaml_path in yaml_workflows.items():
        data = _parse_workflow(yaml_path)
        steps = [s.get("key", "") for s in data.get("steps", [])]
        roles = _extract_roles(data)
        # TODO: fix ensure_workflow to always include project_lead in team_json
        if "project_lead" not in roles:
            roles = ["project_lead"] + roles
        result_map[code] = {
            "code": code,
            "name": code.replace("_", " ").title(),
            "description": data.get("description", code),
            "steps": steps,
            "roles": roles,
            "team": [get_agent(r) for r in roles],
        }

    # 2. DB workflows (override layer — has id, name, and timestamps)
    db_workflows = _list_db_workflows()
    for code, row in db_workflows.items():
        steps = json.loads(row.get("steps_json") or "[]")
        roles = json.loads(row.get("roles_json") or "[]")
        # TODO: fix ensure_workflow to always include project_lead in team_json.
        # Patch: ensure project_lead is in every workflow's role list since
        # Alex orchestrates all workflows but isn't listed in roles_json.
        if "project_lead" not in roles:
            roles = ["project_lead"] + roles
        result_map[code] = {
            "id": row["id"],
            "code": code,
            "name": row.get("name") or code.replace("_", " ").title(),
            "description": row.get("description") or code,
            "steps": steps,
            "roles": roles,
            "team": [get_agent(r) for r in roles],
        }

    return list(result_map.values())


@router.get("/{code}")
def get_workflow(code: str):
    """Workflow detail with step graph and team roster.

    Tries DB first, falls back to YAML.
    """
    # Try DB first
    db_row = _get_db_workflow(code)
    if db_row:
        steps = json.loads(db_row.get("steps_json") or "[]")
        roles = json.loads(db_row.get("roles_json") or "[]")
        # TODO: fix ensure_workflow to always include project_lead in team_json
        if "project_lead" not in roles:
            roles = ["project_lead"] + roles
        return {
            "id": db_row["id"],
            "code": code,
            "name": db_row.get("name") or code.replace("_", " ").title(),
            "description": db_row.get("description") or code,
            "steps": steps,
            "roles": roles,
            "team": [get_agent(r) for r in roles],
        }

    # Fall back to YAML
    yaml_workflows = _discover_yaml_workflows()
    if code not in yaml_workflows:
        raise HTTPException(status_code=404, detail=f"Workflow '{code}' not found")

    data = _parse_workflow(yaml_workflows[code])
    roles = _extract_roles(data)
    # TODO: fix ensure_workflow to always include project_lead in team_json
    if "project_lead" not in roles:
        roles = ["project_lead"] + roles

    step_details = []
    for s in data.get("steps", []):
        key = s.get("key", "")
        role = s.get("role", "")
        step_details.append({
            "key": key,
            "title": s.get("title", key),
            "role": role,
            "deps": s.get("deps", []),
            "agent": get_agent(role),
        })

    return {
        "code": code,
        "name": code.replace("_", " ").title(),
        "description": data.get("description", code),
        "steps": [s["key"] for s in step_details],
        "roles": roles,
        "step_details": step_details,
        "team": [get_agent(r) for r in roles],
    }
