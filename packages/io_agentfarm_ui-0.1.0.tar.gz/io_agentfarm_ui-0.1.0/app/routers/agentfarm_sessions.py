"""agentfarm sessions — interactive session mode (read APIs for frontend).

Reads from ``iof.agentfarm_sessions``, ``iof.agentfarm_session_events``,
and ``iof.messages`` (where ``run_id = session_id``).

Session lifecycle (create, intel, dialogue, submit, challenge, complete)
is handled by the session engine in ioagentfarm.  This router provides the
read/query layer the frontend needs: listing, detail, events, messages,
leaderboard, and stats.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Query, Request
from sse_starlette.sse import EventSourceResponse

from app.agents import get_agent
from app.config import get_settings
from app.database import get_db, q

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/agentfarm_sessions", tags=["agentfarm_sessions"])


# ── Helpers ───────────────────────────────────────────────────────

def _get_session_or_404(session_id: str) -> dict:
    """Fetch a session row or raise 404."""
    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(
            q("SELECT id, session_id, user_name, brand_slug, mission, "
              "goal_type, difficulty, signals_detected, plays_selected, "
              "composition, sequencing, investment, dialogue_turns, "
              "score_breakdown, score_total, grade, badge, "
              "reviewer_note, challenge_msg, defense_msg, "
              "duration_seconds, conference_day, created_at, "
              "dataset_id, nominated_sub_barrier, discovery_confidence, "
              "discovery_impact_mn "
              "FROM agentfarm_sessions WHERE session_id=?"),
            (session_id,),
        )
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")
        return _parse_session_row(dict(row))


def _parse_session_row(row: dict) -> dict:
    """Parse JSONB text fields into Python objects."""
    for key in ("signals_detected", "plays_selected", "composition",
                "score_breakdown", "discovery_impact_mn"):
        val = row.get(key)
        if isinstance(val, str):
            try:
                row[key] = json.loads(val)
            except (json.JSONDecodeError, TypeError):
                pass
    # conference_day may be a date object — convert to string
    if row.get("conference_day") and not isinstance(row["conference_day"], str):
        row["conference_day"] = str(row["conference_day"])
    return row


# ── Leaderboard (must be before /{session_id} to avoid path clash) ─

@router.get("/leaderboard/grand")
def leaderboard_grand(
    conference_day: str | None = None,
    limit: int = Query(default=20, le=100),
):
    """Grand strategist ranking — best score per user across all brands.

    By default returns all days.  Pass ``conference_day=YYYY-MM-DD`` to scope.
    """
    day_clause = "WHERE conference_day=?" if conference_day else ""
    params: list[Any] = []
    if conference_day:
        params.append(conference_day)
    params.append(limit)

    sql = (
        "SELECT user_name, "
        "MAX(score_total) AS best_score, "
        "COUNT(DISTINCT brand_slug) AS brands_played, "
        "COUNT(*) AS total_sessions "
        f"FROM agentfarm_sessions {day_clause} "
        "GROUP BY user_name "
        "ORDER BY best_score DESC LIMIT ?"
    )

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(q(sql), tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        for i, row in enumerate(rows, 1):
            row["rank"] = i
        return rows


@router.get("/leaderboard/brand/{brand_slug}")
def leaderboard_brand(
    brand_slug: str,
    conference_day: str | None = None,
    limit: int = Query(default=20, le=100),
):
    """Per-brand leaderboard (all days by default; filter with conference_day)."""
    clauses = ["brand_slug=?"]
    params: list[Any] = [brand_slug]

    if conference_day:
        clauses.append("conference_day=?")
        params.append(conference_day)

    params.append(limit)

    sql = (
        "SELECT session_id, user_name, mission, score_total, grade, badge, "
        "duration_seconds, created_at "
        f"FROM agentfarm_sessions WHERE {' AND '.join(clauses)} "
        "ORDER BY score_total DESC LIMIT ?"
    )

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(q(sql), tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        for i, row in enumerate(rows, 1):
            row["rank"] = i
        return rows


@router.get("/leaderboard/mission/{mission_name}")
def leaderboard_mission(
    mission_name: str,
    conference_day: str | None = None,
    limit: int = Query(default=20, le=100),
):
    """Per-mission leaderboard (all days by default; filter with conference_day)."""
    clauses = ["mission=?"]
    params: list[Any] = [mission_name]

    if conference_day:
        clauses.append("conference_day=?")
        params.append(conference_day)

    params.append(limit)

    sql = (
        "SELECT session_id, user_name, brand_slug, score_total, grade, badge, "
        "duration_seconds, created_at "
        f"FROM agentfarm_sessions WHERE {' AND '.join(clauses)} "
        "ORDER BY score_total DESC LIMIT ?"
    )

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(q(sql), tuple(params))
        rows = [dict(r) for r in cursor.fetchall()]
        for i, row in enumerate(rows, 1):
            row["rank"] = i
        return rows


# ── Stats (must be before /{session_id} to avoid path clash) ─────

@router.get("/stats")
def get_stats(conference_day: str | None = None):
    """Aggregate statistics (all days by default; filter with conference_day)."""
    day_where = "WHERE conference_day=?" if conference_day else ""
    grade_clause = "AND grade != ''" if conference_day else "WHERE grade != ''"
    params: list[Any] = []
    if conference_day:
        params.append(conference_day)

    with get_db() as con:
        cursor = con.cursor()

        # Totals
        cursor.execute(
            q(f"SELECT COUNT(*) AS total_sessions, "
              f"COUNT(DISTINCT user_name) AS total_users, "
              f"COALESCE(AVG(score_total), 0) AS avg_score, "
              f"COALESCE(AVG(duration_seconds), 0) AS avg_duration_seconds "
              f"FROM agentfarm_sessions {day_where}"),
            tuple(params),
        )
        totals = dict(cursor.fetchone())

        # Highest score
        cursor.execute(
            q(f"SELECT user_name, score_total, brand_slug "
              f"FROM agentfarm_sessions {day_where} "
              f"ORDER BY score_total DESC LIMIT 1"),
            tuple(params),
        )
        top_row = cursor.fetchone()
        highest = None
        if top_row:
            top = dict(top_row)
            highest = {"user": top["user_name"], "score": top["score_total"], "brand": top["brand_slug"]}

        # Grade distribution
        cursor.execute(
            q(f"SELECT grade, COUNT(*) AS count "
              f"FROM agentfarm_sessions {day_where} {grade_clause} "
              f"GROUP BY grade "
              f"ORDER BY "
              f"CASE grade "
              f"  WHEN 'A+' THEN 1 WHEN 'A' THEN 2 WHEN 'A-' THEN 3 "
              f"  WHEN 'B+' THEN 4 WHEN 'B' THEN 5 WHEN 'B-' THEN 6 "
              f"  WHEN 'C+' THEN 7 WHEN 'C' THEN 8 END"),
            tuple(params),
        )
        grade_dist = {dict(r)["grade"]: dict(r)["count"] for r in cursor.fetchall()}

        # Brand breakdown
        cursor.execute(
            q(f"SELECT brand_slug, COUNT(*) AS sessions, "
              f"COALESCE(AVG(score_total), 0) AS avg_score "
              f"FROM agentfarm_sessions {day_where} "
              f"GROUP BY brand_slug"),
            tuple(params),
        )
        brand_breakdown = {
            dict(r)["brand_slug"]: {"sessions": dict(r)["sessions"], "avg_score": round(dict(r)["avg_score"], 1)}
            for r in cursor.fetchall()
        }

    return {
        "total_sessions": totals["total_sessions"],
        "total_users": totals["total_users"],
        "avg_score": round(float(totals["avg_score"]), 1),
        "avg_duration_seconds": round(float(totals["avg_duration_seconds"])),
        "highest_score": highest,
        "grade_distribution": grade_dist,
        "brand_breakdown": brand_breakdown,
    }


# ── Session listing & detail ─────────────────────────────────────

@router.get("")
def list_sessions(
    brand: str | None = None,
    mission: str | None = None,
    user_name: str | None = None,
    conference_day: str | None = None,
    limit: int = Query(default=50, le=200),
):
    """List agentfarm sessions, most recent first."""
    clauses: list[str] = []
    params: list[Any] = []

    if brand:
        clauses.append("brand_slug=?")
        params.append(brand)
    if mission:
        clauses.append("mission=?")
        params.append(mission)
    if user_name:
        clauses.append("user_name=?")
        params.append(user_name)
    if conference_day:
        clauses.append("conference_day=?")
        params.append(conference_day)

    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    sql = (
        "SELECT id, session_id, user_name, brand_slug, mission, "
        "difficulty, score_total, grade, badge, duration_seconds, "
        "conference_day, created_at, dataset_id, nominated_sub_barrier "
        f"FROM agentfarm_sessions{where} "
        "ORDER BY created_at DESC LIMIT ?"
    )
    params.append(limit)

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(q(sql), tuple(params))
        rows = []
        for r in cursor.fetchall():
            row = dict(r)
            if row.get("conference_day") and not isinstance(row["conference_day"], str):
                row["conference_day"] = str(row["conference_day"])
            rows.append(row)
        return rows


@router.get("/{session_id}")
def get_session(session_id: str):
    """Full session detail — metadata, scores, composition."""
    return _get_session_or_404(session_id)


# ── Session events (execution trace) ─────────────────────────────

@router.get("/{session_id}/events")
def get_session_events(
    session_id: str,
    from_seq: int | None = None,
):
    """Execution trace for session replay.

    Returns events ordered by ``seq``.  Pass ``from_seq`` for incremental
    polling during live sessions.
    """
    _get_session_or_404(session_id)

    clauses = ["session_id=?"]
    params: list[Any] = [session_id]
    if from_seq is not None:
        clauses.append("seq > ?")
        params.append(from_seq)

    sql = (
        "SELECT id, session_id, seq, phase, event_type, agent, "
        "content, artifact_path, duration_ms, metadata, created_at "
        f"FROM agentfarm_session_events WHERE {' AND '.join(clauses)} "
        "ORDER BY seq ASC"
    )

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(q(sql), tuple(params))
        events = []
        for r in cursor.fetchall():
            evt = dict(r)
            if isinstance(evt.get("metadata"), str):
                try:
                    evt["metadata"] = json.loads(evt["metadata"])
                except (json.JSONDecodeError, TypeError):
                    pass
            events.append(evt)

    return {
        "session_id": session_id,
        "total_events": len(events),
        "events": events,
    }


# ── Session messages (conversation log) ──────────────────────────

@router.get("/{session_id}/messages")
def get_session_messages(
    session_id: str,
    after_id: int | None = None,
):
    """Conversation log for a session.

    Messages table uses ``run_id = session_id`` as the join key.
    Pass ``after_id`` for incremental polling during live sessions.
    """
    _get_session_or_404(session_id)

    clauses = ["run_id=?"]
    params: list[Any] = [session_id]
    if after_id is not None:
        clauses.append("id > ?")
        params.append(after_id)

    sql = (
        "SELECT id, run_id, role, agent_name, source, msg_type, "
        "content, created_at "
        f"FROM messages WHERE {' AND '.join(clauses)} "
        "ORDER BY id ASC"
    )

    with get_db() as con:
        cursor = con.cursor()
        cursor.execute(q(sql), tuple(params))
        messages = [dict(r) for r in cursor.fetchall()]

    return {
        "session_id": session_id,
        "messages": messages,
    }


# ── SSE stream ───────────────────────────────────────────────────

def _build_agent(role: str, agent_name: str = "") -> dict:
    """Build agent display object, preferring agent_name over registry."""
    agent = get_agent(role)
    if agent_name:
        agent["name"] = agent_name
        agent["avatar"] = agent_name[:2].upper()
    return agent


@router.get("/{session_id}/messages/stream")
async def stream_messages(
    session_id: str, request: Request, after_id: int = 0, from_seq: int = 0,
):
    """SSE endpoint for real-time session message streaming.

    Polls both ``messages`` (conversation log) and
    ``agentfarm_session_events`` (execution trace) and emits unified SSE
    events.  The stream ends when the session reaches ``complete`` or
    ``failed``.

    SSE Event Types
    ===============

    1. **stream_start** — first event, describes the contract
    2. **phase_change** — session phase transition (briefing → dialogue → …)
    3. **agent_start** — agent began speaking (msg_type = start)
    4. **message** — agent/user output line (append to chat)
    5. **agent_end** — agent finished speaking (msg_type = end)
    6. **event** — session event from execution trace (signal_detected,
       score_computed, agent_call, agent_response, etc.)
    7. **session_end** — session completed or failed (last event)

    Query params:

    - ``after_id`` — last message id the client has (resume without replay)
    - ``from_seq`` — last event seq the client has (resume events)
    """
    _get_session_or_404(session_id)
    settings = get_settings()

    async def event_generator():
        yield {
            "event": "stream_start",
            "data": json.dumps({
                "session_id": session_id,
                "after_id": after_id,
                "from_seq": from_seq,
                "event_types": {
                    "stream_start": "First event — contract and resume positions",
                    "phase_change": "Session phase transition (created → briefing → dialogue → …)",
                    "agent_start": "Agent began speaking — light up avatar",
                    "message": "Output line — append to chat",
                    "agent_end": "Agent finished speaking — dim avatar",
                    "event": "Execution trace event (signal_detected, score_computed, etc.)",
                    "session_end": "Session completed or failed — last event",
                },
            }),
        }

        last_msg_id = after_id
        last_seq = from_seq
        idle_ticks_after_end = 0
        session_end_emitted = False

        while True:
            if await request.is_disconnected():
                break

            events: list[dict] = []
            session_phase = ""

            with get_db() as con:
                cursor = con.cursor()

                # ── New messages ──────────────────────────────
                cursor.execute(
                    q("SELECT id, run_id, role, agent_name, source, msg_type, "
                      "content, created_at FROM messages "
                      "WHERE run_id=? AND id>? ORDER BY id ASC LIMIT ?"),
                    (session_id, last_msg_id, 100),
                )
                new_messages = [dict(r) for r in cursor.fetchall()]

                # ── New session events ────────────────────────
                cursor.execute(
                    q("SELECT id, seq, phase, event_type, agent, content, "
                      "artifact_path, duration_ms, metadata, created_at "
                      "FROM agentfarm_session_events "
                      "WHERE session_id=? AND seq>? ORDER BY seq ASC LIMIT ?"),
                    (session_id, last_seq, 100),
                )
                new_events = [dict(r) for r in cursor.fetchall()]

                # ── Current phase (latest phase_start) ────────
                cursor.execute(
                    q("SELECT content FROM agentfarm_session_events "
                      "WHERE session_id=? AND event_type='phase_start' "
                      "ORDER BY seq DESC LIMIT 1"),
                    (session_id,),
                )
                phase_row = cursor.fetchone()
                if phase_row:
                    # content is like "scored -> complete"
                    session_phase = phase_row["content"].split("->")[-1].strip()

            # Emit session events (phase changes, signals, scores, etc.)
            for evt in new_events:
                last_seq = evt["seq"]
                metadata = evt.get("metadata")
                if isinstance(metadata, str):
                    try:
                        metadata = json.loads(metadata)
                    except (json.JSONDecodeError, TypeError):
                        pass

                if evt["event_type"] in ("phase_start", "phase_end"):
                    events.append({
                        "event": "phase_change",
                        "data": json.dumps({
                            "seq": evt["seq"],
                            "phase": evt["phase"],
                            "event_type": evt["event_type"],
                            "content": evt["content"],
                            "created_at": str(evt["created_at"]),
                        }),
                    })
                else:
                    events.append({
                        "event": "event",
                        "data": json.dumps({
                            "seq": evt["seq"],
                            "phase": evt["phase"],
                            "event_type": evt["event_type"],
                            "agent": evt["agent"],
                            "content": evt["content"],
                            "artifact_path": evt.get("artifact_path", ""),
                            "duration_ms": evt.get("duration_ms", 0),
                            "metadata": metadata or {},
                            "created_at": str(evt["created_at"]),
                        }),
                    })

            # Emit messages — map source/msg_type to SSE events
            for msg in new_messages:
                last_msg_id = msg["id"]
                agent = _build_agent(msg["role"], msg.get("agent_name", ""))
                msg_type = msg.get("msg_type") or ""
                source = msg.get("source") or ""

                if msg_type == "start":
                    events.append({
                        "event": "agent_start",
                        "data": json.dumps({
                            "role": msg["role"],
                            "agent": agent,
                        }),
                    })
                elif msg_type == "end":
                    events.append({
                        "event": "agent_end",
                        "data": json.dumps({
                            "role": msg["role"],
                            "agent": agent,
                            "content": msg["content"],
                        }),
                    })
                else:
                    events.append({
                        "event": "message",
                        "data": json.dumps({
                            "id": msg["id"],
                            "role": msg["role"],
                            "content": msg["content"],
                            "source": source or msg_type,
                            "msg_type": msg_type,
                            "timestamp": str(msg["created_at"]),
                            "agent": agent,
                        }),
                    })

            # Emit session end (once)
            if session_phase in ("complete", "failed") and not session_end_emitted:
                session_end_emitted = True
                events.append({
                    "event": "session_end",
                    "data": json.dumps({
                        "session_id": session_id,
                        "status": session_phase,
                    }),
                })

            for evt in events:
                yield evt

            # Stop after session completes and data drains
            if session_phase in ("complete", "failed") and not new_messages and not new_events:
                idle_ticks_after_end += 1
                if idle_ticks_after_end > 4:
                    break

            await asyncio.sleep(settings.sse_poll_interval)

    return EventSourceResponse(event_generator())
