"""S3 file operations — list, upload, download, delete, move, presigned URLs."""

from __future__ import annotations

import io
import logging
from typing import Optional

import boto3
from botocore.exceptions import ClientError
from fastapi import APIRouter, HTTPException, UploadFile, File, Query
from fastapi.responses import StreamingResponse

from app.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/s3", tags=["s3"])


def _get_s3_client():
    """Build an S3 client using explicit credentials if available, else default profile/IAM."""
    settings = get_settings()
    if settings.aws_access_key_id and settings.aws_secret_access_key:
        return boto3.client(
            "s3",
            region_name=settings.aws_region,
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
        )
    return boto3.client("s3", region_name=settings.aws_region)


def _resolve_bucket(bucket: str | None) -> str:
    """Use the provided bucket or fall back to the configured default."""
    if bucket:
        return bucket
    settings = get_settings()
    if not settings.s3_bucket:
        raise HTTPException(status_code=400, detail="No bucket specified and IOF_S3_BUCKET is not configured")
    return settings.s3_bucket


@router.get("/list")
def list_files(
    prefix: str = "",
    bucket: Optional[str] = None,
    max_keys: int = 1000,
):
    """List S3 files under a prefix."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    # Prepend configured prefix if no explicit prefix given
    settings = get_settings()
    full_prefix = prefix
    if not full_prefix and settings.s3_prefix:
        full_prefix = settings.s3_prefix

    try:
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(
            Bucket=bucket,
            Prefix=full_prefix,
            PaginationConfig={"MaxItems": max_keys},
        )
        files = []
        for page in pages:
            for obj in page.get("Contents", []):
                files.append({
                    "key": obj["Key"],
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                })
        return {"bucket": bucket, "prefix": full_prefix, "count": len(files), "files": files}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 list failed: {e}")


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    key: str = Query(..., description="S3 object key (path)"),
    bucket: Optional[str] = None,
):
    """Upload a file to S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        contents = await file.read()
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=contents,
            ContentType=file.content_type or "application/octet-stream",
        )
        return {"bucket": bucket, "key": key, "size": len(contents), "message": "Uploaded successfully"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 upload failed: {e}")


@router.delete("/delete")
def delete_file(
    key: str = Query(..., description="S3 object key to delete"),
    bucket: Optional[str] = None,
):
    """Delete a file from S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        s3.delete_object(Bucket=bucket, Key=key)
        return {"bucket": bucket, "key": key, "message": "Deleted successfully"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 delete failed: {e}")


@router.delete("/delete-by-prefix")
def delete_by_prefix(
    prefix: str = Query(..., description="S3 prefix — all objects under this path will be deleted"),
    bucket: Optional[str] = None,
):
    """Delete all files under a given S3 path."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        paginator = s3.get_paginator("list_objects_v2")
        deleted = 0
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            objects = [{"Key": obj["Key"]} for obj in page.get("Contents", [])]
            if objects:
                s3.delete_objects(Bucket=bucket, Delete={"Objects": objects})
                deleted += len(objects)
        return {"bucket": bucket, "prefix": prefix, "deleted_count": deleted, "message": "Deleted successfully"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 delete-by-prefix failed: {e}")


@router.get("/generate-url")
def generate_presigned_url(
    key: str = Query(..., description="S3 object key"),
    expiration: int = Query(3600, description="URL expiration in seconds"),
    bucket: Optional[str] = None,
):
    """Generate a presigned URL for an S3 object."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": key},
            ExpiresIn=expiration,
        )
        return {"bucket": bucket, "key": key, "expiration": expiration, "url": url}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 presigned URL failed: {e}")


@router.post("/move")
def move_file(
    source_key: str = Query(..., description="Source S3 object key"),
    destination_key: str = Query(..., description="Destination S3 object key"),
    bucket: Optional[str] = None,
):
    """Move (copy + delete) a file within S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        s3.copy_object(
            Bucket=bucket,
            CopySource={"Bucket": bucket, "Key": source_key},
            Key=destination_key,
        )
        s3.delete_object(Bucket=bucket, Key=source_key)
        return {
            "bucket": bucket,
            "source_key": source_key,
            "destination_key": destination_key,
            "message": "Moved successfully",
        }
    except ClientError as e:
        raise HTTPException(status_code=500, detail=f"S3 move failed: {e}")


@router.get("/download")
def download_file(
    key: str = Query(..., description="S3 object key to download"),
    bucket: Optional[str] = None,
):
    """Download a file from S3."""
    bucket = _resolve_bucket(bucket)
    s3 = _get_s3_client()

    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        filename = key.rsplit("/", 1)[-1] if "/" in key else key
        content_type = response.get("ContentType", "application/octet-stream")

        return StreamingResponse(
            response["Body"],
            media_type=content_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except s3.exceptions.NoSuchKey:
        raise HTTPException(status_code=404, detail=f"Object '{key}' not found")
    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code == "NoSuchKey":
            raise HTTPException(status_code=404, detail=f"Object '{key}' not found")
        raise HTTPException(status_code=500, detail=f"S3 download failed: {e}")
