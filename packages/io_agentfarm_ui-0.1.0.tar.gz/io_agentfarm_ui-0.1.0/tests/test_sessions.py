"""Tests for session (run) management endpoints."""

import json
from unittest.mock import patch, MagicMock


class TestListSessions:
    def test_returns_sessions_for_workflow(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions")
        assert resp.status_code == 200
        sessions = resp.json()
        assert len(sessions) == 2

    def test_session_fields(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions")
        s = next(s for s in resp.json() if s["id"] == "run_001")
        assert s["workflow_name"] == "feature_dev"
        assert s["goal"] == "Build a hello world CLI"
        assert s["status"] == "running"
        assert s["workspace_id"] == 1

    def test_filter_by_status(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions?status=done")
        sessions = resp.json()
        assert len(sessions) == 1
        assert sessions[0]["id"] == "run_002"

    def test_limit(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions?limit=1")
        sessions = resp.json()
        assert len(sessions) == 1

    def test_empty_for_other_workflow(self, client):
        resp = client.get("/api/workflows/bug_fix/sessions")
        assert resp.status_code == 200
        assert resp.json() == []


class TestGetSession:
    def test_returns_session_detail(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001")
        assert resp.status_code == 200
        s = resp.json()
        assert s["id"] == "run_001"
        assert s["goal"] == "Build a hello world CLI"

    def test_includes_steps(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001")
        s = resp.json()
        assert "steps" in s
        assert len(s["steps"]) == 5
        keys = [step["step_key"] for step in s["steps"]]
        assert keys == ["analyze", "plan", "implement", "test", "review"]

    def test_steps_have_agent_info(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001")
        step = resp.json()["steps"][0]
        assert "agent" in step
        assert step["agent"]["role"] == "analyst"
        assert step["agent"]["name"] == "Dana"

    def test_includes_team_roster(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001")
        s = resp.json()
        assert "team" in s
        team_roles = {m["role"] for m in s["team"]}
        # team_json is source of truth — includes project_lead even without steps
        assert team_roles == {"project_lead", "analyst", "developer", "reviewer"}

    def test_team_status(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001")
        team = {m["role"]: m for m in resp.json()["team"]}
        assert team["project_lead"]["status"] == "idle"  # no steps for this role
        assert team["analyst"]["status"] == "done"
        assert team["developer"]["status"] == "active"
        assert team["developer"]["current_step"] == "implement"
        assert team["reviewer"]["status"] == "idle"

    def test_404_for_missing_run(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/nonexistent")
        assert resp.status_code == 404

    def test_404_for_wrong_workflow(self, client):
        resp = client.get("/api/workflows/bug_fix/sessions/run_001")
        assert resp.status_code == 404
        assert "belongs to workflow" in resp.json()["detail"]


class TestGetSessionStatus:
    def test_returns_status(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "run_001"
        assert data["status"] == "running"
        assert data["steps_total"] == 5

    def test_step_counts(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/status")
        data = resp.json()
        assert data["steps_done"] == 2      # analyze, plan
        assert data["steps_running"] == 1   # implement
        assert data["steps_pending"] == 2   # test, review
        assert data["steps_failed"] == 0

    def test_404_for_missing_run(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/nonexistent/status")
        assert resp.status_code == 404

    def test_404_for_wrong_workflow(self, client):
        resp = client.get("/api/workflows/bug_fix/sessions/run_001/status")
        assert resp.status_code == 404


class TestGetSessionSteps:
    def test_returns_steps(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/steps")
        assert resp.status_code == 200
        steps = resp.json()
        assert len(steps) == 5

    def test_step_fields(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/steps")
        step = resp.json()[0]
        assert step["step_key"] == "analyze"
        assert step["role"] == "analyst"
        assert step["status"] == "done"
        assert "agent" in step
        assert "deps_json" in step
        assert "meta_json" in step

    def test_step_ordering(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/steps")
        keys = [s["step_key"] for s in resp.json()]
        assert keys == ["analyze", "plan", "implement", "test", "review"]

    def test_404_for_missing_run(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/nonexistent/steps")
        assert resp.status_code == 404


class TestGetSessionTeam:
    def test_returns_team(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/team")
        assert resp.status_code == 200
        team = resp.json()
        assert len(team) == 4  # from team_json: project_lead, analyst, developer, reviewer

    def test_team_member_fields(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/team")
        team = {m["role"]: m for m in resp.json()}
        dev = team["developer"]
        assert dev["name"] == "Sam"
        assert dev["status"] == "active"
        assert dev["current_step"] == "implement"

    def test_404_for_missing_run(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/nonexistent/team")
        assert resp.status_code == 404


class TestStartSession:
    def test_start_session_success(self, client):
        """Test starting a session via mocked subprocess."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"run_id": "run_new_001", "total_steps": 5})
        mock_result.stderr = ""

        with patch("app.routers.sessions.subprocess.run", return_value=mock_result):
            with patch("app.routers.sessions.threading.Thread") as mock_thread:
                mock_thread.return_value = MagicMock()
                resp = client.post(
                    "/api/workflows/feature_dev/sessions",
                    json={"goal": "Test goal", "project_dir": "/tmp/test"},
                )
                assert resp.status_code == 200
                data = resp.json()
                assert data["run_id"] == "run_new_001"
                assert data["status"] == "running"
                assert data["total_steps"] == 5
                # Background thread was started
                mock_thread.return_value.start.assert_called_once()

    def test_start_session_no_goal(self, client):
        resp = client.post(
            "/api/workflows/feature_dev/sessions",
            json={"goal": ""},
        )
        assert resp.status_code == 400
        assert "goal is required" in resp.json()["detail"]

    def test_start_session_subprocess_failure(self, client):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "workflow not found"

        with patch("app.routers.sessions.subprocess.run", return_value=mock_result):
            resp = client.post(
                "/api/workflows/feature_dev/sessions",
                json={"goal": "Test goal"},
            )
            assert resp.status_code == 500
            assert "start-run failed" in resp.json()["detail"]

    def test_start_session_timeout(self, client):
        import subprocess as sp

        with patch("app.routers.sessions.subprocess.run", side_effect=sp.TimeoutExpired("cmd", 30)):
            resp = client.post(
                "/api/workflows/feature_dev/sessions",
                json={"goal": "Test goal"},
            )
            assert resp.status_code == 504

    def test_start_session_invalid_json_response(self, client):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "not json"
        mock_result.stderr = ""

        with patch("app.routers.sessions.subprocess.run", return_value=mock_result):
            resp = client.post(
                "/api/workflows/feature_dev/sessions",
                json={"goal": "Test goal"},
            )
            assert resp.status_code == 500
            assert "Invalid JSON" in resp.json()["detail"]

    def test_start_session_no_run_id_in_response(self, client):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"status": "ok"})
        mock_result.stderr = ""

        with patch("app.routers.sessions.subprocess.run", return_value=mock_result):
            resp = client.post(
                "/api/workflows/feature_dev/sessions",
                json={"goal": "Test goal"},
            )
            assert resp.status_code == 500
            assert "No run_id" in resp.json()["detail"]
