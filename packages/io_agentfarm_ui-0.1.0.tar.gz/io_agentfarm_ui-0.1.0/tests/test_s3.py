"""Tests for S3 file operation endpoints."""

from __future__ import annotations

import io
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def s3_client():
    """TestClient with mocked S3 settings."""
    mock_settings = MagicMock()
    mock_settings.s3_bucket = "test-bucket"
    mock_settings.s3_prefix = "test/prefix"
    mock_settings.aws_region = "us-east-1"
    mock_settings.aws_access_key_id = "fake-key"
    mock_settings.aws_secret_access_key = "fake-secret"
    mock_settings.cors_origins = ["*"]

    with patch("app.routers.s3.get_settings", return_value=mock_settings):
        from app.config import get_settings
        get_settings.cache_clear()

        from app.main import app
        yield TestClient(app)

        get_settings.cache_clear()


class TestListFiles:
    def test_list_files(self, s3_client):
        mock_s3 = MagicMock()
        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [
            {
                "Contents": [
                    {"Key": "test/file1.txt", "Size": 100, "LastModified": datetime(2026, 1, 1, tzinfo=timezone.utc)},
                    {"Key": "test/file2.txt", "Size": 200, "LastModified": datetime(2026, 1, 2, tzinfo=timezone.utc)},
                ]
            }
        ]
        mock_s3.get_paginator.return_value = mock_paginator

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.get("/api/s3/list?prefix=test/")
            assert resp.status_code == 200
            data = resp.json()
            assert data["count"] == 2
            assert data["bucket"] == "test-bucket"
            assert len(data["files"]) == 2
            assert data["files"][0]["key"] == "test/file1.txt"

    def test_list_uses_default_prefix(self, s3_client):
        mock_s3 = MagicMock()
        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [{"Contents": []}]
        mock_s3.get_paginator.return_value = mock_paginator

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.get("/api/s3/list")
            assert resp.status_code == 200
            mock_paginator.paginate.assert_called_once()
            call_kwargs = mock_paginator.paginate.call_args
            assert call_kwargs[1]["Prefix"] == "test/prefix"


class TestUploadFile:
    def test_upload_success(self, s3_client):
        mock_s3 = MagicMock()

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.post(
                "/api/s3/upload?key=uploads/test.txt",
                files={"file": ("test.txt", b"hello world", "text/plain")},
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["key"] == "uploads/test.txt"
            assert data["size"] == 11
            mock_s3.put_object.assert_called_once()


class TestDeleteFile:
    def test_delete_success(self, s3_client):
        mock_s3 = MagicMock()

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.delete("/api/s3/delete?key=test/file.txt")
            assert resp.status_code == 200
            mock_s3.delete_object.assert_called_once_with(Bucket="test-bucket", Key="test/file.txt")


class TestDeleteByPrefix:
    def test_delete_by_prefix(self, s3_client):
        mock_s3 = MagicMock()
        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [
            {"Contents": [{"Key": "old/a.txt"}, {"Key": "old/b.txt"}]}
        ]
        mock_s3.get_paginator.return_value = mock_paginator

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.delete("/api/s3/delete-by-prefix?prefix=old/")
            assert resp.status_code == 200
            data = resp.json()
            assert data["deleted_count"] == 2
            mock_s3.delete_objects.assert_called_once()


class TestGenerateUrl:
    def test_generate_presigned_url(self, s3_client):
        mock_s3 = MagicMock()
        mock_s3.generate_presigned_url.return_value = "https://s3.amazonaws.com/test-bucket/file.txt?signature=abc"

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.get("/api/s3/generate-url?key=file.txt&expiration=600")
            assert resp.status_code == 200
            data = resp.json()
            assert "url" in data
            assert data["expiration"] == 600
            assert data["key"] == "file.txt"

    def test_default_expiration(self, s3_client):
        mock_s3 = MagicMock()
        mock_s3.generate_presigned_url.return_value = "https://example.com"

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.get("/api/s3/generate-url?key=file.txt")
            assert resp.status_code == 200
            assert resp.json()["expiration"] == 3600


class TestMoveFile:
    def test_move_success(self, s3_client):
        mock_s3 = MagicMock()

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.post("/api/s3/move?source_key=old/file.txt&destination_key=new/file.txt")
            assert resp.status_code == 200
            data = resp.json()
            assert data["source_key"] == "old/file.txt"
            assert data["destination_key"] == "new/file.txt"
            mock_s3.copy_object.assert_called_once()
            mock_s3.delete_object.assert_called_once_with(Bucket="test-bucket", Key="old/file.txt")


class TestDownloadFile:
    def test_download_success(self, s3_client):
        mock_s3 = MagicMock()
        mock_body = MagicMock()
        mock_body.read.return_value = b"file contents"
        mock_body.__iter__ = lambda self: iter([b"file contents"])
        mock_s3.get_object.return_value = {
            "Body": mock_body,
            "ContentType": "text/plain",
        }

        with patch("app.routers.s3._get_s3_client", return_value=mock_s3):
            resp = s3_client.get("/api/s3/download?key=test/hello.txt")
            assert resp.status_code == 200
            assert resp.headers["content-type"] == "text/plain; charset=utf-8"
            assert "content-disposition" in resp.headers
            assert "hello.txt" in resp.headers["content-disposition"]


class TestNoBucketConfigured:
    def test_error_when_no_bucket(self):
        mock_settings = MagicMock()
        mock_settings.s3_bucket = ""
        mock_settings.s3_prefix = ""
        mock_settings.aws_region = "us-east-1"
        mock_settings.aws_access_key_id = ""
        mock_settings.aws_secret_access_key = ""
        mock_settings.cors_origins = ["*"]

        with patch("app.routers.s3.get_settings", return_value=mock_settings):
            from app.config import get_settings
            get_settings.cache_clear()
            from app.main import app
            client = TestClient(app)

            resp = client.get("/api/s3/list")
            assert resp.status_code == 400
            assert "IOF_S3_BUCKET" in resp.json()["detail"]

            get_settings.cache_clear()


class TestProfileFallback:
    def test_uses_profile_when_no_keys(self):
        """When AWS keys are empty, boto3 should be called without explicit credentials."""
        mock_settings = MagicMock()
        mock_settings.s3_bucket = "test-bucket"
        mock_settings.s3_prefix = ""
        mock_settings.aws_region = "us-east-1"
        mock_settings.aws_access_key_id = ""
        mock_settings.aws_secret_access_key = ""

        with patch("app.routers.s3.get_settings", return_value=mock_settings):
            with patch("app.routers.s3.boto3.client") as mock_boto:
                from app.routers.s3 import _get_s3_client
                _get_s3_client()
                mock_boto.assert_called_once_with("s3", region_name="us-east-1")
