"""Tests for health check and agent registry endpoints."""


def test_health(client):
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_list_agents(client):
    resp = client.get("/api/agents")
    assert resp.status_code == 200
    agents = resp.json()
    assert isinstance(agents, list)
    assert len(agents) == 4

    roles = {a["role"] for a in agents}
    assert roles == {"project_lead", "analyst", "developer", "reviewer"}

    # Spot-check Alex
    alex = next(a for a in agents if a["role"] == "project_lead")
    assert alex["name"] == "Alex"
    assert alex["title"] == "Project Lead"
    assert alex["color"] == "#4A90D9"
    assert alex["avatar"] == "AL"
