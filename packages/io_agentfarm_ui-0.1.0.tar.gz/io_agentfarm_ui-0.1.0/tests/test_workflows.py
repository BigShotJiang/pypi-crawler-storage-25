"""Tests for workflow discovery endpoints (DB-first, YAML fallback)."""

from unittest.mock import patch
from pathlib import Path


class TestListWorkflows:
    def test_returns_db_workflows(self, client):
        """DB workflows are returned when available."""
        resp = client.get("/api/workflows")
        assert resp.status_code == 200
        workflows = resp.json()
        codes = {w["code"] for w in workflows}
        assert "feature_dev" in codes

    def test_db_workflow_has_id(self, client):
        """DB-backed workflows include their numeric id."""
        resp = client.get("/api/workflows")
        wf = next(w for w in resp.json() if w["code"] == "feature_dev")
        assert "id" in wf
        assert wf["id"] == 1

    def test_db_workflow_fields(self, client):
        resp = client.get("/api/workflows")
        wf = next(w for w in resp.json() if w["code"] == "feature_dev")
        assert wf["name"] == "Feature Dev"
        assert wf["description"] == "Feature development workflow"
        assert wf["steps"] == ["analyze", "plan", "implement", "test", "review"]
        assert wf["roles"] == ["analyst", "developer", "reviewer"]

    def test_team_roster_included(self, client):
        resp = client.get("/api/workflows")
        wf = next(w for w in resp.json() if w["code"] == "feature_dev")
        assert "team" in wf
        assert len(wf["team"]) == 3
        roles = {a["role"] for a in wf["team"]}
        assert roles == {"analyst", "developer", "reviewer"}

    def test_yaml_fallback(self, client):
        """Workflows not in DB are discovered from YAML."""
        fake_yaml = {"test_wf": Path("/fake/test_wf/workflow.yaml")}
        fake_data = {
            "description": "A test workflow",
            "steps": [{"key": "step1", "role": "developer"}],
            "roles": [{"name": "developer"}],
        }

        with (
            patch("app.routers.workflows._discover_yaml_workflows", return_value=fake_yaml),
            patch("app.routers.workflows._parse_workflow", return_value=fake_data),
        ):
            resp = client.get("/api/workflows")
            codes = {w["code"] for w in resp.json()}
            assert "test_wf" in codes

    def test_db_overrides_yaml(self, client):
        """When both DB and YAML have the same workflow, DB takes priority."""
        fake_yaml = {"feature_dev": Path("/fake/feature_dev/workflow.yaml")}
        fake_data = {
            "description": "YAML description should be overridden",
            "steps": [{"key": "yaml_step", "role": "developer"}],
            "roles": [{"name": "developer"}],
        }

        with (
            patch("app.routers.workflows._discover_yaml_workflows", return_value=fake_yaml),
            patch("app.routers.workflows._parse_workflow", return_value=fake_data),
        ):
            resp = client.get("/api/workflows")
            wf = next(w for w in resp.json() if w["code"] == "feature_dev")
            # DB values win
            assert wf["description"] == "Feature development workflow"
            assert "id" in wf


class TestGetWorkflow:
    def test_db_workflow_found(self, client):
        resp = client.get("/api/workflows/feature_dev")
        assert resp.status_code == 200
        wf = resp.json()
        assert wf["code"] == "feature_dev"
        assert wf["name"] == "Feature Dev"
        assert wf["id"] == 1

    def test_db_workflow_has_team(self, client):
        resp = client.get("/api/workflows/feature_dev")
        wf = resp.json()
        assert len(wf["team"]) == 3

    def test_yaml_fallback_with_step_details(self, client):
        """When not in DB, falls back to YAML with step_details."""
        fake_yaml = {"yaml_only": Path("/fake/yaml_only/workflow.yaml")}
        fake_data = {
            "description": "YAML-only workflow",
            "steps": [
                {"key": "analyze", "title": "Analyze", "role": "analyst", "deps": []},
                {"key": "implement", "title": "Implement", "role": "developer", "deps": ["analyze"]},
            ],
            "roles": [{"name": "analyst"}, {"name": "developer"}],
        }

        with (
            patch("app.routers.workflows._discover_yaml_workflows", return_value=fake_yaml),
            patch("app.routers.workflows._parse_workflow", return_value=fake_data),
        ):
            resp = client.get("/api/workflows/yaml_only")
            assert resp.status_code == 200
            wf = resp.json()
            assert wf["code"] == "yaml_only"
            assert "step_details" in wf
            assert len(wf["step_details"]) == 2
            assert wf["step_details"][1]["deps"] == ["analyze"]

    def test_404_for_missing_workflow(self, client):
        resp = client.get("/api/workflows/nonexistent")
        assert resp.status_code == 404
