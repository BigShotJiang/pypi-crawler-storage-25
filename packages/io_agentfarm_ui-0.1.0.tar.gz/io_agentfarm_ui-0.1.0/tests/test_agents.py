"""Tests for agent registry module (DB-first with static fallback)."""

from unittest.mock import patch
from app.agents import get_agent, reload_agents, _STATIC_REGISTRY, _load_db_registry


class TestStaticRegistry:
    def test_has_four_agents(self):
        assert len(_STATIC_REGISTRY) == 4

    def test_known_roles(self):
        assert set(_STATIC_REGISTRY.keys()) == {
            "project_lead", "analyst", "developer", "reviewer"
        }


class TestGetAgent:
    def test_known_agent(self):
        agent = get_agent("analyst")
        assert agent["role"] == "analyst"
        assert agent["name"] == "Dana"
        assert agent["title"] == "Analyst"
        assert agent["color"] == "#7B68EE"
        assert agent["avatar"] == "DA"

    def test_returns_copy(self):
        a1 = get_agent("developer")
        a2 = get_agent("developer")
        assert a1 == a2
        assert a1 is not a2  # different objects

    def test_unknown_role_fallback(self):
        agent = get_agent("unknown_role")
        assert agent["role"] == "unknown_role"
        assert agent["name"] == "Unknown Role"
        assert agent["title"] == "Unknown Role"
        assert agent["color"] == "#888888"
        assert agent["avatar"] == "UN"

    def test_single_word_unknown(self):
        agent = get_agent("tester")
        assert agent["name"] == "Tester"
        assert agent["avatar"] == "TE"


class TestDbAgent:
    def test_db_agent_from_seeded_data(self, client):
        """DB agents are returned via the /api/agents endpoint."""
        resp = client.get("/api/agents")
        assert resp.status_code == 200
        agents = resp.json()
        roles = {a["role"] for a in agents}
        assert "analyst" in roles
        assert "developer" in roles

    def test_db_agent_used_in_get_agent(self, client):
        """get_agent reads from the DB agents table."""
        agent = get_agent("analyst")
        assert agent["name"] == "Dana"
        assert agent["color"] == "#7B68EE"

    def test_reload_clears_cache(self):
        """reload_agents() forces a re-read from DB on next call."""
        reload_agents()
        # After reload, cache is None, next _load_db_registry will re-query
        from app.agents import _db_registry
        assert _db_registry is None
