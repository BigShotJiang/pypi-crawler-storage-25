"""End-to-end integration smoke test.

Starts a workflow session, drives a 3-step pipeline via mocked subprocess
calls that mutate the test DB, and validates that the SSE stream delivers
real-time events (step_update, agent_start, message, agent_end, session_end).
"""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from subprocess import CompletedProcess
from typing import Any, Generator
from unittest.mock import patch, MagicMock

import pytest
from fastapi.testclient import TestClient


# ── Helpers ──────────────────────────────────────────────────────

def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _extract_arg(cmd: list[str], flag: str) -> str:
    """Extract the value following a CLI flag, e.g. --run-id <value>."""
    for i, arg in enumerate(cmd):
        if arg == flag and i + 1 < len(cmd):
            return cmd[i + 1]
    return ""


def _parse_sse_events(line_iter) -> list[dict]:
    """Parse SSE text lines into a list of {event, data} dicts."""
    events: list[dict] = []
    event_type = None
    data_lines: list[str] = []

    for line in line_iter:
        if line.startswith("event:"):
            event_type = line[len("event:"):].strip()
        elif line.startswith("data:"):
            data_lines.append(line[len("data:"):].strip())
        elif line.strip() == "":
            if event_type and data_lines:
                raw = "\n".join(data_lines)
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    data = raw
                events.append({"event": event_type, "data": data})
            event_type = None
            data_lines = []

    return events


# ── Mock subprocess factory ──────────────────────────────────────

SMOKE_RUN_ID = "run_smoke_001"
SMOKE_STEPS = [
    {"seq": 1, "step_key": "assess",  "role": "project_lead", "deps_json": "[]"},
    {"seq": 2, "step_key": "analyze", "role": "analyst",      "deps_json": '["assess"]'},
    {"seq": 3, "step_key": "review",  "role": "reviewer",     "deps_json": '["analyze"]'},
]


def _make_mock_subprocess(db_con: sqlite3.Connection):
    """Return a mock subprocess.run that drives a 3-step pipeline via DB mutations."""

    def _insert_messages(run_id: str, step_key: str, role: str):
        """Insert start/output/end messages with small delays for SSE interleaving."""
        now = _now()
        msgs = [
            (run_id, step_key, role, f"Starting {step_key}...", "start", now, "step_start"),
            (run_id, step_key, role, f"Working on {step_key}.", "output", now, "step_output"),
            (run_id, step_key, role, f"{step_key} complete.", "end", now, "step_output"),
        ]
        for m in msgs:
            db_con.execute(
                "INSERT INTO messages(run_id, step_key, role, content, msg_type, created_at, source) "
                "VALUES(?, ?, ?, ?, ?, ?, ?)", m,
            )
            db_con.commit()
            time.sleep(0.03)  # small delay for SSE poller to pick up incrementally

    def _handle_start_run(cmd):
        now = _now()
        # Insert run
        db_con.execute(
            "INSERT INTO runs(id, workspace_id, workflow_name, workflow_id, goal, "
            "project_dir, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (SMOKE_RUN_ID, None, "feature_dev", None, "Smoke test goal",
             "/tmp/smoke", "running", now, now),
        )
        # Insert steps
        for s in SMOKE_STEPS:
            db_con.execute(
                "INSERT INTO steps(run_id, seq, step_key, role, status, attempt, "
                "max_attempts, deps_json, created_at, updated_at) "
                "VALUES(?, ?, ?, ?, 'pending', 0, 2, ?, ?, ?)",
                (SMOKE_RUN_ID, s["seq"], s["step_key"], s["role"],
                 s["deps_json"], now, now),
            )
        db_con.commit()

        return CompletedProcess(
            args=cmd, returncode=0,
            stdout=json.dumps({"run_id": SMOKE_RUN_ID, "total_steps": 3}),
            stderr="",
        )

    def _handle_next_step(cmd):
        run_id = _extract_arg(cmd, "--run-id")
        cursor = db_con.cursor()
        cursor.execute(
            "SELECT step_key, role, status, seq, deps_json FROM steps "
            "WHERE run_id=? ORDER BY seq ASC", (run_id,),
        )
        steps = [dict(r) for r in cursor.fetchall()]

        done_keys = {s["step_key"] for s in steps if s["status"] == "done"}

        for s in steps:
            if s["status"] != "pending":
                continue
            deps = json.loads(s["deps_json"])
            if all(d in done_keys for d in deps):
                # Claim it
                now = _now()
                db_con.execute(
                    "UPDATE steps SET status='running', updated_at=? "
                    "WHERE run_id=? AND step_key=?",
                    (now, run_id, s["step_key"]),
                )
                db_con.commit()
                return CompletedProcess(
                    args=cmd, returncode=0,
                    stdout=json.dumps({
                        "step_key": s["step_key"],
                        "role": s["role"],
                        "seq": s["seq"],
                    }),
                    stderr="",
                )

        # Check if any still running
        running = [s for s in steps if s["status"] == "running"]
        if running:
            return CompletedProcess(
                args=cmd, returncode=0,
                stdout=json.dumps({"waiting": True}), stderr="",
            )

        # All done — mark run as done
        now = _now()
        db_con.execute(
            "UPDATE runs SET status='done', updated_at=? WHERE id=?",
            (now, run_id),
        )
        db_con.commit()
        return CompletedProcess(
            args=cmd, returncode=0,
            stdout=json.dumps({"done": True}), stderr="",
        )

    def _handle_step_execute(cmd):
        """Handle both run-step and step-complete."""
        step_key = _extract_arg(cmd, "--step-key")
        run_id = _extract_arg(cmd, "--run-id")

        # Look up role
        cursor = db_con.cursor()
        cursor.execute(
            "SELECT role FROM steps WHERE run_id=? AND step_key=?",
            (run_id, step_key),
        )
        row = cursor.fetchone()
        role = dict(row)["role"] if row else "unknown"

        # Insert messages with delays
        _insert_messages(run_id, step_key, role)

        # Mark step done
        now = _now()
        db_con.execute(
            "UPDATE steps SET status='done', output_text=?, updated_at=? "
            "WHERE run_id=? AND step_key=?",
            (f"STATUS: done\nOUTPUT: {step_key} completed successfully.", now,
             run_id, step_key),
        )
        db_con.commit()

        return CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    def mock_run(cmd, **kwargs):
        # cmd[0] is the binary path, cmd[1] is the subcommand
        if len(cmd) < 2:
            return CompletedProcess(args=cmd, returncode=1, stdout="", stderr="bad cmd")

        subcmd = cmd[1]
        if subcmd == "start-run":
            return _handle_start_run(cmd)
        elif subcmd == "next-step":
            return _handle_next_step(cmd)
        elif subcmd in ("run-step", "step-complete"):
            return _handle_step_execute(cmd)
        else:
            return CompletedProcess(
                args=cmd, returncode=1, stdout="",
                stderr=f"unknown subcommand: {subcmd}",
            )

    return mock_run


# ── Schema (same as conftest) ────────────────────────────────────

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS workspaces (
    id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workflows (
    id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
    steps_json TEXT NOT NULL DEFAULT '[]', roles_json TEXT NOT NULL DEFAULT '[]',
    team_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY, workspace_id INTEGER, workflow_name TEXT NOT NULL,
    workflow_id INTEGER, goal TEXT NOT NULL, project_dir TEXT NOT NULL DEFAULT '',
    parent_run_id TEXT, user_id TEXT, status TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL, seq INTEGER NOT NULL,
    step_key TEXT NOT NULL, role TEXT NOT NULL, status TEXT NOT NULL,
    attempt INTEGER NOT NULL DEFAULT 0, max_attempts INTEGER NOT NULL DEFAULT 2,
    deps_json TEXT NOT NULL DEFAULT '[]', meta_json TEXT NOT NULL DEFAULT '{}',
    output_text TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    UNIQUE(run_id, step_key)
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL,
    step_key TEXT NOT NULL, role TEXT NOT NULL, agent_name TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL, msg_type TEXT NOT NULL DEFAULT 'output', created_at TEXT NOT NULL,
    task_id TEXT, workspace_id INTEGER, workflow_id INTEGER, session_id TEXT,
    user_id TEXT, source TEXT NOT NULL DEFAULT 'agent'
);
CREATE TABLE IF NOT EXISTS agents (
    role TEXT PRIMARY KEY, name TEXT NOT NULL, title TEXT NOT NULL,
    avatar TEXT NOT NULL, color TEXT NOT NULL, seeded_at TEXT
);
CREATE TABLE IF NOT EXISTS user_context (
    user_id TEXT PRIMARY KEY, active_run_id TEXT, updated_at TEXT NOT NULL
);
"""


# ── Fixture ──────────────────────────────────────────────────────

@pytest.fixture()
def smoke_client():
    """TestClient with empty-schema DB for E2E smoke test.

    Yields (client, db_connection) so the test can pass db_con to mock factories.
    Uses a fast SSE poll interval (50ms) for speed.
    """
    con = sqlite3.connect(":memory:", check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA_SQL)

    @contextmanager
    def _get_test_db() -> Generator[Any, None, None]:
        yield con

    def _test_q(sql: str) -> str:
        return sql

    # Patch a fast SSE poll interval via settings
    mock_settings = MagicMock()
    mock_settings.sse_poll_interval = 0.05  # 50ms
    mock_settings.iof_root = "/tmp/iof"
    mock_settings.database_url = "sqlite:///:memory:"
    mock_settings.ioagentfarm_bin = "ioagentfarm"
    mock_settings.cors_origins = ["*"]
    mock_settings.agentfarm_dir = "/tmp/fake"

    with (
        patch("app.database.get_db", _get_test_db),
        patch("app.database.q", _test_q),
        patch("app.routers.workspaces.get_db", _get_test_db),
        patch("app.routers.workspaces.q", _test_q),
        patch("app.routers.workflows.get_db", _get_test_db),
        patch("app.routers.workflows.q", _test_q),
        patch("app.routers.workflows._discover_yaml_workflows", return_value={}),
        patch("app.routers.sessions.get_db", _get_test_db),
        patch("app.routers.sessions.q", _test_q),
        patch("app.routers.sessions.get_settings", return_value=mock_settings),
        patch("app.routers.messages.get_db", _get_test_db),
        patch("app.routers.messages.q", _test_q),
        patch("app.routers.messages.get_settings", return_value=mock_settings),
    ):
        from app.config import get_settings
        get_settings.cache_clear()

        from app.main import app
        yield TestClient(app), con

        get_settings.cache_clear()

    con.close()


# ── The Smoke Test ───────────────────────────────────────────────

def test_smoke_e2e_pipeline_with_sse(smoke_client):
    """Start a session, drive a 3-step pipeline, and validate SSE events."""
    client, db_con = smoke_client
    mock_run = _make_mock_subprocess(db_con)

    with patch("app.routers.sessions.subprocess.run", side_effect=mock_run):
        # 1. Start session (launches _execute_pipeline in a background thread)
        resp = client.post(
            "/api/workflows/feature_dev/sessions",
            json={"goal": "Smoke test goal", "project_dir": "/tmp/smoke"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == SMOKE_RUN_ID
        assert data["status"] == "running"
        assert data["total_steps"] == 3

        # 2. Consume SSE stream (blocks until stream ends)
        events: list[dict] = []
        with client.stream(
            "GET",
            f"/api/workflows/feature_dev/sessions/{SMOKE_RUN_ID}/messages/stream",
        ) as sse_resp:
            events = _parse_sse_events(sse_resp.iter_lines())

    # ── Assertions ───────────────────────────────────────────────

    assert len(events) > 0, "Expected SSE events but got none"

    event_types = [e["event"] for e in events]

    # All event types present
    assert "step_update" in event_types, f"Missing step_update. Got: {event_types}"
    assert "agent_start" in event_types, f"Missing agent_start. Got: {event_types}"
    assert "message" in event_types, f"Missing message. Got: {event_types}"
    assert "agent_end" in event_types, f"Missing agent_end. Got: {event_types}"
    assert "session_end" in event_types, f"Missing session_end. Got: {event_types}"

    # session_end is the last event
    assert events[-1]["event"] == "session_end"
    assert events[-1]["data"]["status"] == "done"
    assert events[-1]["data"]["run_id"] == SMOKE_RUN_ID

    # At least 1 session_end (may fire >1 due to SSE poll timing when
    # messages are still draining on the same tick as run completion)
    assert event_types.count("session_end") >= 1

    # 3 agent_start and 3 agent_end (one per step)
    assert event_types.count("agent_start") == 3
    assert event_types.count("agent_end") == 3

    # At least 3 output messages (one per step)
    assert event_types.count("message") >= 3

    # For each step, agent_start appears before agent_end
    for step_key in ["assess", "analyze", "review"]:
        starts = [i for i, e in enumerate(events)
                  if e["event"] == "agent_start" and e["data"].get("step_key") == step_key]
        ends = [i for i, e in enumerate(events)
                if e["event"] == "agent_end" and e["data"].get("step_key") == step_key]
        assert len(starts) == 1, f"Expected 1 agent_start for {step_key}, got {len(starts)}"
        assert len(ends) == 1, f"Expected 1 agent_end for {step_key}, got {len(ends)}"
        assert starts[0] < ends[0], f"agent_start must precede agent_end for {step_key}"

    # Step updates show all 3 steps reaching 'done'
    step_updates = [
        (e["data"]["step_key"], e["data"]["status"])
        for e in events if e["event"] == "step_update"
    ]
    for step_key in ["assess", "analyze", "review"]:
        assert (step_key, "done") in step_updates, \
            f"Missing done transition for {step_key}. Got: {step_updates}"

    # Verify correct agent metadata in events
    agent_starts = [e for e in events if e["event"] == "agent_start"]
    roles_seen = {e["data"]["agent"]["role"] for e in agent_starts}
    assert roles_seen == {"project_lead", "analyst", "reviewer"}

    # Verify message content is meaningful
    output_msgs = [e for e in events if e["event"] == "message"]
    for msg in output_msgs:
        assert msg["data"]["content"], "Message content should not be empty"
        assert "agent" in msg["data"], "Message should include agent metadata"
        assert msg["data"]["agent"]["role"], "Message agent role should not be empty"

    # Verify DB state after pipeline completes
    cursor = db_con.cursor()
    cursor.execute("SELECT status FROM runs WHERE id=?", (SMOKE_RUN_ID,))
    assert dict(cursor.fetchone())["status"] == "done"

    cursor.execute(
        "SELECT step_key, status FROM steps WHERE run_id=? ORDER BY seq ASC",
        (SMOKE_RUN_ID,),
    )
    for row in cursor.fetchall():
        r = dict(row)
        assert r["status"] == "done", f"Step {r['step_key']} should be done, got {r['status']}"

    cursor.execute("SELECT COUNT(*) AS cnt FROM messages WHERE run_id=?", (SMOKE_RUN_ID,))
    msg_count = int(dict(cursor.fetchone())["cnt"])
    assert msg_count == 9, f"Expected 9 messages (3 per step × 3 steps), got {msg_count}"
