"""Tests for message polling endpoint."""


class TestGetMessages:
    def test_returns_messages(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/messages")
        assert resp.status_code == 200
        data = resp.json()
        assert "messages" in data
        assert "last_id" in data
        assert len(data["messages"]) == 5

    def test_message_fields(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/messages")
        msg = resp.json()["messages"][0]
        assert msg["run_id"] == "run_001"
        assert msg["step_key"] == "analyze"
        assert msg["role"] == "analyst"
        assert msg["content"] == "Starting analysis..."
        assert msg["msg_type"] == "start"
        assert msg["source"] == "step_start"
        assert "agent" in msg
        assert msg["agent"]["name"] == "Dana"

    def test_after_id_pagination(self, client):
        # Get all messages first
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/messages")
        all_msgs = resp.json()
        last_id = all_msgs["last_id"]
        assert last_id > 0

        # Get messages after the last one — should be empty
        resp2 = client.get(
            f"/api/workflows/feature_dev/sessions/run_001/messages?after_id={last_id}"
        )
        data2 = resp2.json()
        assert len(data2["messages"]) == 0
        assert data2["last_id"] == last_id  # unchanged

    def test_after_id_partial(self, client):
        # Get first message's id
        resp = client.get("/api/workflows/feature_dev/sessions/run_001/messages?limit=1")
        first_id = resp.json()["messages"][0]["id"]

        # Get messages after the first one
        resp2 = client.get(
            f"/api/workflows/feature_dev/sessions/run_001/messages?after_id={first_id}"
        )
        remaining = resp2.json()["messages"]
        assert len(remaining) == 4  # 5 total - 1 already seen

    def test_filter_by_step_key(self, client):
        resp = client.get(
            "/api/workflows/feature_dev/sessions/run_001/messages?step_key=implement"
        )
        msgs = resp.json()["messages"]
        assert len(msgs) == 2
        assert all(m["step_key"] == "implement" for m in msgs)

    def test_limit(self, client):
        resp = client.get(
            "/api/workflows/feature_dev/sessions/run_001/messages?limit=2"
        )
        assert len(resp.json()["messages"]) == 2

    def test_404_for_missing_run(self, client):
        resp = client.get("/api/workflows/feature_dev/sessions/nonexistent/messages")
        assert resp.status_code == 404

    def test_404_for_wrong_workflow(self, client):
        resp = client.get("/api/workflows/bug_fix/sessions/run_001/messages")
        assert resp.status_code == 404
        assert "belongs to workflow" in resp.json()["detail"]
