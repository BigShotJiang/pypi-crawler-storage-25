"""Tests for workspace management endpoints."""


class TestListWorkspaces:
    def test_returns_workspaces(self, client):
        resp = client.get("/api/workspaces")
        assert resp.status_code == 200
        workspaces = resp.json()
        assert isinstance(workspaces, list)
        assert len(workspaces) == 1

    def test_workspace_fields(self, client):
        resp = client.get("/api/workspaces")
        ws = resp.json()[0]
        assert ws["code"] == "default"
        assert ws["name"] == "Default"
        assert ws["description"] == "Default workspace"
        assert "created_at" in ws
        assert "updated_at" in ws

    def test_workspace_run_count(self, client):
        resp = client.get("/api/workspaces")
        ws = resp.json()[0]
        assert ws["run_count"] == 2  # run_001 + run_002

    def test_workspace_workflow_count(self, client):
        resp = client.get("/api/workspaces")
        ws = resp.json()[0]
        assert ws["workflow_count"] == 1  # feature_dev only


class TestGetWorkspace:
    def test_returns_workspace_detail(self, client):
        resp = client.get("/api/workspaces/1")
        assert resp.status_code == 200
        ws = resp.json()
        assert ws["code"] == "default"
        assert ws["name"] == "Default"

    def test_includes_workflows(self, client):
        resp = client.get("/api/workspaces/1")
        ws = resp.json()
        assert "workflows" in ws
        assert len(ws["workflows"]) == 1
        wf = ws["workflows"][0]
        assert wf["code"] == "feature_dev"
        assert "runs" in wf
        assert wf["runs"]["total"] == 2

    def test_includes_recent_runs(self, client):
        resp = client.get("/api/workspaces/1")
        ws = resp.json()
        assert "recent_runs" in ws
        assert len(ws["recent_runs"]) == 2

    def test_404_for_missing_workspace(self, client):
        resp = client.get("/api/workspaces/999")
        assert resp.status_code == 404


class TestListWorkspaceWorkflows:
    def test_returns_workflows(self, client):
        resp = client.get("/api/workspaces/1/workflows")
        assert resp.status_code == 200
        workflows = resp.json()
        assert len(workflows) == 1
        wf = workflows[0]
        assert wf["code"] == "feature_dev"
        assert wf["name"] == "Feature Dev"

    def test_includes_team(self, client):
        resp = client.get("/api/workspaces/1/workflows")
        wf = resp.json()[0]
        assert "team" in wf
        assert len(wf["team"]) == 3  # analyst, developer, reviewer
        roles = {a["role"] for a in wf["team"]}
        assert roles == {"analyst", "developer", "reviewer"}

    def test_404_for_missing_workspace(self, client):
        resp = client.get("/api/workspaces/999/workflows")
        assert resp.status_code == 404


class TestListWorkspaceSessions:
    def test_returns_sessions(self, client):
        resp = client.get("/api/workspaces/1/sessions")
        assert resp.status_code == 200
        sessions = resp.json()
        assert len(sessions) == 2

    def test_filter_by_status(self, client):
        resp = client.get("/api/workspaces/1/sessions?status=running")
        sessions = resp.json()
        assert len(sessions) == 1
        assert sessions[0]["id"] == "run_001"

    def test_filter_done(self, client):
        resp = client.get("/api/workspaces/1/sessions?status=done")
        sessions = resp.json()
        assert len(sessions) == 1
        assert sessions[0]["id"] == "run_002"

    def test_limit(self, client):
        resp = client.get("/api/workspaces/1/sessions?limit=1")
        sessions = resp.json()
        assert len(sessions) == 1

    def test_404_for_missing_workspace(self, client):
        resp = client.get("/api/workspaces/999/sessions")
        assert resp.status_code == 404
