# PyStator Examples

Runnable examples that demonstrate core features: loading FSMs, guards, actions, hierarchical and parallel states.

## Quick run

From the **project root**:

```bash
python examples/basic_usage.py
python examples/day_trading_example.py
python examples/portfolio_optimization_example.py
```

From the **examples** directory:

```bash
cd examples
python basic_usage.py
python day_trading_example.py
python portfolio_optimization_example.py
```

## Examples overview

| Example | Description |
|---------|-------------|
| **basic_usage.py** + **order_fsm.yaml** | Order lifecycle: `pending_new` → `open` → `partially_filled` / `filled` / `rejected` / `canceled`. Registers guards (`is_full_fill`, `is_partial_fill`, `is_cancellable`) and actions (notify, audit, positions). Simulates exchange_ack, partial fill, full fill, and a failed cancel. Best starting point. |
| **day_trading_example.py** + **day_trading_fsm.yaml** | Parallel states: multiple regions (e.g. trading, risk_monitor, data_feed) active at once. Uses `enter_parallel_state`, `process_parallel`, and region-scoped transitions. |
| **portfolio_optimization_example.py** + **portfolio_optimization_fsm.yaml** | Hierarchical (compound) states with parent/child and LCA-based exit/enter. Demonstrates statechart-style nesting and transitions from parent states. |

## Dependencies

- **pystator** (core) — all examples
- **`pystator[api]`** — only needed if the FSM uses inline guard expressions (`expr: "..."`); the listed examples use registered guards only.

## More

- [Documentation: Examples](../docs/examples.md) — Same list with more detail and links to tutorials.
- [Tutorial: Order workflow](../docs/tutorials/order-workflow.md) — Step-by-step build of an order FSM.
- [Concepts](../docs/guides/concepts.md) — States, transitions, guards, actions, parallel and hierarchical.
