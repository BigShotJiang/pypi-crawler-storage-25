"""Weekly Portfolio Optimization FSM Example.

This example demonstrates using PyStator for a portfolio optimization
workflow with hierarchical states (statecharts). The workflow goes through:

1. Analysis Phase:
   - Market analysis
   - Risk analysis
   - Opportunity identification

2. Optimization Phase:
   - Constraint setup
   - Solver execution
   - Validation

3. Execution Phase:
   - Trade planning
   - Trade execution
   - Settlement

4. Review Phase:
   - Performance analysis
   - Report generation

Hierarchical states allow:
- Transitions from parent states that apply to any child (e.g., error from analyzing)
- Clean LCA-based exit/enter action chains
- Natural organization of complex workflows
"""

import asyncio
from datetime import UTC, datetime
from typing import Any

from pystator import (
    ActionRegistry,
    GuardRegistry,
    StateMachine,
)
from pystator.actions import ActionExecutor, ExecutionMode

# =============================================================================
# Portfolio Context
# =============================================================================


def create_portfolio_context() -> dict[str, Any]:
    """Create initial portfolio context."""
    return {
        # Portfolio state
        "current_weights": {
            "SPY": 0.40,
            "AGG": 0.30,
            "GLD": 0.10,
            "VWO": 0.10,
            "CASH": 0.10,
        },
        "target_weights": {},
        "portfolio_value": 1_000_000.0,
        # Risk metrics
        "portfolio_var": 0.0,
        "portfolio_beta": 1.0,
        "drift": 0.0,
        "drift_threshold": 0.05,  # 5%
        # Optimization
        "expected_returns": {},
        "covariance_matrix": {},
        "risk_budget": 0.15,  # 15% annual vol target
        "turnover_limit": 0.20,  # 20% max turnover
        # Execution
        "trade_list": [],
        "executed_trades": [],
        "transaction_costs": 0.0,
        # State
        "rebalance_count": 0,
        "retry_count": 0,
        "max_retries": 3,
        "analysis_start": None,
        "optimization_start": None,
        "execution_start": None,
    }


# =============================================================================
# Guard Functions
# =============================================================================

guards = GuardRegistry()


@guards.decorator("is_market_hours")
def is_market_hours(ctx: dict) -> bool:
    """Check if market is open."""
    # Simplified - in production, check actual market hours
    hour = datetime.now().hour
    return 9 <= hour < 16  # 9 AM - 4 PM


@guards.decorator("drift_exceeds_threshold")
def drift_exceeds_threshold(ctx: dict) -> bool:
    """Check if portfolio drift exceeds threshold."""
    return ctx.get("drift", 0) > ctx.get("drift_threshold", 0.05)


@guards.decorator("has_actionable_opportunities")
def has_actionable_opportunities(ctx: dict) -> bool:
    """Check if there are actionable rebalancing opportunities."""
    target = ctx.get("target_weights", {})
    current = ctx.get("current_weights", {})

    if not target:
        return False

    # Check if any weight differs by more than 1%
    for asset in set(target.keys()) | set(current.keys()):
        diff = abs(target.get(asset, 0) - current.get(asset, 0))
        if diff > 0.01:
            return True
    return False


@guards.decorator("meets_risk_constraints")
def meets_risk_constraints(ctx: dict) -> bool:
    """Check if optimization meets risk constraints."""
    return ctx.get("portfolio_var", 999) <= ctx.get("risk_budget", 0.15)


@guards.decorator("acceptable_turnover")
def acceptable_turnover(ctx: dict) -> bool:
    """Check if turnover is within limits."""
    return ctx.get("estimated_turnover", 0) <= ctx.get("turnover_limit", 0.20)


@guards.decorator("trades_within_limits")
def trades_within_limits(ctx: dict) -> bool:
    """Check if trades are within execution limits."""
    return len(ctx.get("trade_list", [])) <= 50  # Max 50 trades


@guards.decorator("retry_allowed")
def retry_allowed(ctx: dict) -> bool:
    """Check if retry is allowed."""
    return ctx.get("retry_count", 0) < ctx.get("max_retries", 3)


@guards.decorator("can_safely_cancel")
def can_safely_cancel(ctx: dict) -> bool:
    """Check if cancellation is safe (no open orders)."""
    return len(ctx.get("pending_orders", [])) == 0


# =============================================================================
# Action Functions
# =============================================================================

actions = ActionRegistry()


# --- Idle Actions ---


@actions.decorator("log_idle_state")
def log_idle_state(ctx: dict) -> None:
    """Log entering idle state."""
    print("Portfolio optimization: IDLE - waiting for trigger")


# --- Analysis Actions ---


@actions.decorator("start_analysis_timer")
def start_analysis_timer(ctx: dict) -> None:
    """Start analysis timer."""
    ctx["analysis_start"] = datetime.now(UTC)
    print("\n=== ANALYSIS PHASE STARTED ===")


@actions.decorator("stop_analysis_timer")
def stop_analysis_timer(ctx: dict) -> None:
    """Stop analysis timer."""
    if ctx.get("analysis_start"):
        duration = datetime.now(UTC) - ctx["analysis_start"]
        print(f"Analysis phase completed in {duration.total_seconds():.1f}s")


@actions.decorator("fetch_market_data")
def fetch_market_data(ctx: dict) -> None:
    """Fetch market data."""
    print("Fetching market data...")
    # Simulated data
    ctx["expected_returns"] = {
        "SPY": 0.08,
        "AGG": 0.03,
        "GLD": 0.04,
        "VWO": 0.10,
        "CASH": 0.02,
    }


@actions.decorator("calculate_volatility")
def calculate_volatility(ctx: dict) -> None:
    """Calculate market volatility."""
    print("Calculating volatility...")
    ctx["market_volatility"] = 0.18  # 18% annualized


@actions.decorator("calculate_var")
def calculate_var(ctx: dict) -> None:
    """Calculate Value at Risk."""
    print("Calculating VaR...")
    ctx["portfolio_var"] = 0.12  # 12% VaR


@actions.decorator("calculate_beta")
def calculate_beta(ctx: dict) -> None:
    """Calculate portfolio beta."""
    print("Calculating beta...")
    ctx["portfolio_beta"] = 0.85


@actions.decorator("assess_concentration")
def assess_concentration(ctx: dict) -> None:
    """Assess portfolio concentration."""
    print("Assessing concentration...")
    max_weight = max(ctx["current_weights"].values())
    ctx["max_concentration"] = max_weight


@actions.decorator("screen_universe")
def screen_universe(ctx: dict) -> None:
    """Screen investment universe."""
    print("Screening universe...")
    ctx["screened_assets"] = ["SPY", "AGG", "GLD", "VWO", "QQQ", "TLT"]


@actions.decorator("rank_assets")
def rank_assets(ctx: dict) -> None:
    """Rank assets by expected risk-adjusted return."""
    print("Ranking assets...")
    ctx["ranked_assets"] = ["QQQ", "SPY", "VWO", "GLD", "TLT", "AGG"]


@actions.decorator("filter_constraints")
def filter_constraints(ctx: dict) -> None:
    """Apply portfolio constraints to filter assets."""
    print("Applying constraints...")


@actions.decorator("store_market_metrics")
def store_market_metrics(ctx: dict) -> None:
    """Store market analysis metrics."""
    print("Market metrics stored")


@actions.decorator("store_risk_metrics")
def store_risk_metrics(ctx: dict) -> None:
    """Store risk analysis metrics."""
    print("Risk metrics stored")


@actions.decorator("finalize_analysis_report")
def finalize_analysis_report(ctx: dict) -> None:
    """Finalize analysis report."""
    print("Analysis report finalized")


@actions.decorator("log_no_action")
def log_no_action(ctx: dict) -> None:
    """Log no action needed."""
    print("No rebalancing action needed")


@actions.decorator("schedule_next_check")
def schedule_next_check(ctx: dict) -> None:
    """Schedule next rebalance check."""
    print("Next check scheduled")


# --- Optimization Actions ---


@actions.decorator("start_optimization_timer")
def start_optimization_timer(ctx: dict) -> None:
    """Start optimization timer."""
    ctx["optimization_start"] = datetime.now(UTC)
    print("\n=== OPTIMIZATION PHASE STARTED ===")


@actions.decorator("stop_optimization_timer")
def stop_optimization_timer(ctx: dict) -> None:
    """Stop optimization timer."""
    if ctx.get("optimization_start"):
        duration = datetime.now(UTC) - ctx["optimization_start"]
        print(f"Optimization phase completed in {duration.total_seconds():.1f}s")


@actions.decorator("load_risk_limits")
def load_risk_limits(ctx: dict) -> None:
    """Load risk limits."""
    print("Loading risk limits...")
    ctx["risk_limits"] = {"max_var": 0.15, "max_beta": 1.2}


@actions.decorator("load_sector_constraints")
def load_sector_constraints(ctx: dict) -> None:
    """Load sector constraints."""
    print("Loading sector constraints...")
    ctx["sector_constraints"] = {"equity": 0.70, "fixed_income": 0.50}


@actions.decorator("load_position_limits")
def load_position_limits(ctx: dict) -> None:
    """Load position limits."""
    print("Loading position limits...")
    ctx["position_limits"] = {"min": 0.02, "max": 0.25}


@actions.decorator("log_constraints")
def log_constraints(ctx: dict) -> None:
    """Log optimization constraints."""
    print("Constraints configured")


@actions.decorator("run_mean_variance_optimizer")
def run_mean_variance_optimizer(ctx: dict) -> None:
    """Run mean-variance optimization."""
    print("Running mean-variance optimizer...")


@actions.decorator("run_risk_parity_optimizer")
def run_risk_parity_optimizer(ctx: dict) -> None:
    """Run risk parity optimization."""
    print("Running risk parity optimizer...")


@actions.decorator("select_optimal_portfolio")
def select_optimal_portfolio(ctx: dict) -> None:
    """Select optimal portfolio from candidates."""
    print("Selecting optimal portfolio...")
    # Simulated optimal weights
    ctx["target_weights"] = {
        "SPY": 0.35,
        "AGG": 0.25,
        "GLD": 0.15,
        "VWO": 0.15,
        "CASH": 0.10,
    }


@actions.decorator("store_optimal_weights")
def store_optimal_weights(ctx: dict) -> None:
    """Store optimal weights."""
    print(f"Optimal weights: {ctx['target_weights']}")


@actions.decorator("validate_constraints")
def validate_constraints(ctx: dict) -> None:
    """Validate optimization meets constraints."""
    print("Validating constraints...")
    ctx["constraints_valid"] = True


@actions.decorator("check_turnover")
def check_turnover(ctx: dict) -> None:
    """Check portfolio turnover."""
    print("Checking turnover...")
    # Calculate turnover
    current = ctx["current_weights"]
    target = ctx["target_weights"]
    turnover = (
        sum(
            abs(target.get(a, 0) - current.get(a, 0))
            for a in set(target) | set(current)
        )
        / 2
    )
    ctx["estimated_turnover"] = turnover
    print(f"Estimated turnover: {turnover:.1%}")


@actions.decorator("estimate_transaction_costs")
def estimate_transaction_costs(ctx: dict) -> None:
    """Estimate transaction costs."""
    print("Estimating transaction costs...")
    turnover_value = ctx["estimated_turnover"] * ctx["portfolio_value"]
    ctx["transaction_costs"] = turnover_value * 0.001  # 10 bps
    print(f"Estimated costs: ${ctx['transaction_costs']:,.2f}")


@actions.decorator("approve_trade_list")
def approve_trade_list(ctx: dict) -> None:
    """Approve trade list."""
    print("Trade list approved")


@actions.decorator("log_validation_failure")
def log_validation_failure(ctx: dict) -> None:
    """Log validation failure."""
    print("WARNING: Validation failed")


@actions.decorator("adjust_constraints")
def adjust_constraints(ctx: dict) -> None:
    """Adjust constraints for re-optimization."""
    print("Adjusting constraints...")


# --- Execution Actions ---


@actions.decorator("start_execution_timer")
def start_execution_timer(ctx: dict) -> None:
    """Start execution timer."""
    ctx["execution_start"] = datetime.now(UTC)
    print("\n=== EXECUTION PHASE STARTED ===")


@actions.decorator("stop_execution_timer")
def stop_execution_timer(ctx: dict) -> None:
    """Stop execution timer."""
    if ctx.get("execution_start"):
        duration = datetime.now(UTC) - ctx["execution_start"]
        print(f"Execution phase completed in {duration.total_seconds():.1f}s")


@actions.decorator("record_execution_stats")
def record_execution_stats(ctx: dict) -> None:
    """Record execution statistics."""
    print("Execution stats recorded")


@actions.decorator("generate_trade_list")
def generate_trade_list(ctx: dict) -> None:
    """Generate trade list from weight differences."""
    print("Generating trade list...")
    current = ctx["current_weights"]
    target = ctx["target_weights"]
    trades = []

    for asset in set(target) | set(current):
        diff = target.get(asset, 0) - current.get(asset, 0)
        if abs(diff) > 0.001:
            value = diff * ctx["portfolio_value"]
            trades.append(
                {
                    "asset": asset,
                    "direction": "BUY" if diff > 0 else "SELL",
                    "value": abs(value),
                }
            )

    ctx["trade_list"] = trades
    print(f"Generated {len(trades)} trades")


@actions.decorator("schedule_trades")
def schedule_trades(ctx: dict) -> None:
    """Schedule trade execution."""
    print("Scheduling trades...")


@actions.decorator("set_execution_limits")
def set_execution_limits(ctx: dict) -> None:
    """Set execution limits."""
    print("Setting execution limits...")


@actions.decorator("confirm_trade_plan")
def confirm_trade_plan(ctx: dict) -> None:
    """Confirm trade plan."""
    print("Trade plan confirmed")


@actions.decorator("start_execution_algo")
def start_execution_algo(ctx: dict) -> None:
    """Start execution algorithm."""
    print("Starting execution algo (TWAP)...")


@actions.decorator("monitor_fills")
def monitor_fills(ctx: dict) -> None:
    """Monitor order fills."""
    print("Monitoring fills...")


@actions.decorator("finalize_trades")
def finalize_trades(ctx: dict) -> None:
    """Finalize trades."""
    print("Trades finalized")
    ctx["executed_trades"] = ctx["trade_list"]
    ctx["current_weights"] = ctx["target_weights"].copy()


@actions.decorator("log_execution_summary")
def log_execution_summary(ctx: dict) -> None:
    """Log execution summary."""
    print(f"Executed {len(ctx['executed_trades'])} trades")


@actions.decorator("await_settlement")
def await_settlement(ctx: dict) -> None:
    """Await trade settlement."""
    print("Awaiting T+1 settlement...")


@actions.decorator("reconcile_positions")
def reconcile_positions(ctx: dict) -> None:
    """Reconcile positions."""
    print("Reconciling positions...")


@actions.decorator("update_portfolio_state")
def update_portfolio_state(ctx: dict) -> None:
    """Update portfolio state."""
    print("Portfolio state updated")


@actions.decorator("confirm_settlement")
def confirm_settlement(ctx: dict) -> None:
    """Confirm settlement."""
    print("Settlement confirmed")


# --- Review Actions ---


@actions.decorator("calculate_implementation_shortfall")
def calculate_implementation_shortfall(ctx: dict) -> None:
    """Calculate implementation shortfall."""
    print("Calculating implementation shortfall...")
    ctx["implementation_shortfall"] = ctx["transaction_costs"]


@actions.decorator("generate_rebalance_report")
def generate_rebalance_report(ctx: dict) -> None:
    """Generate rebalance report."""
    print("\n=== REBALANCE REPORT ===")
    print(f"Trades executed: {len(ctx['executed_trades'])}")
    print(f"Transaction costs: ${ctx['transaction_costs']:,.2f}")
    print(f"New weights: {ctx['current_weights']}")
    print("========================\n")


@actions.decorator("archive_trade_records")
def archive_trade_records(ctx: dict) -> None:
    """Archive trade records."""
    print("Trade records archived")


@actions.decorator("finalize_rebalance_cycle")
def finalize_rebalance_cycle(ctx: dict) -> None:
    """Finalize rebalance cycle."""
    ctx["rebalance_count"] = ctx.get("rebalance_count", 0) + 1
    print(f"Rebalance cycle #{ctx['rebalance_count']} complete")


@actions.decorator("schedule_next_rebalance")
def schedule_next_rebalance(ctx: dict) -> None:
    """Schedule next rebalance."""
    print("Next rebalance scheduled for next week")


# --- Error Actions ---


@actions.decorator("log_error_state")
def log_error_state(ctx: dict) -> None:
    """Log error state."""
    print("ERROR: Rebalance workflow error")


@actions.decorator("notify_portfolio_manager")
def notify_portfolio_manager(ctx: dict) -> None:
    """Notify portfolio manager."""
    print("Portfolio manager notified")


@actions.decorator("log_analysis_error")
def log_analysis_error(ctx: dict) -> None:
    """Log analysis error."""
    print("ERROR: Analysis phase failed")


@actions.decorator("log_optimization_error")
def log_optimization_error(ctx: dict) -> None:
    """Log optimization error."""
    print("ERROR: Optimization phase failed")


@actions.decorator("log_execution_error")
def log_execution_error(ctx: dict) -> None:
    """Log execution error."""
    print("ERROR: Execution phase failed")


@actions.decorator("halt_pending_trades")
def halt_pending_trades(ctx: dict) -> None:
    """Halt pending trades."""
    print("Pending trades halted")


@actions.decorator("clear_error_state")
def clear_error_state(ctx: dict) -> None:
    """Clear error state."""
    ctx["retry_count"] = ctx.get("retry_count", 0) + 1
    print(f"Error state cleared (retry {ctx['retry_count']})")


# --- Cancellation Actions ---


@actions.decorator("log_cancellation")
def log_cancellation(ctx: dict) -> None:
    """Log cancellation."""
    print("Rebalance cancelled")


@actions.decorator("rollback_pending_trades")
def rollback_pending_trades(ctx: dict) -> None:
    """Rollback pending trades."""
    print("Pending trades rolled back")


@actions.decorator("log_cancellation_request")
def log_cancellation_request(ctx: dict) -> None:
    """Log cancellation request."""
    print("Cancellation requested")


@actions.decorator("cancel_pending_trades")
def cancel_pending_trades(ctx: dict) -> None:
    """Cancel pending trades."""
    print("Pending trades cancelled")


# Trigger actions
for action_name in [
    "log_rebalance_start",
    "snapshot_portfolio",
    "log_manual_trigger",
    "log_drift_trigger",
]:
    if action_name not in actions:
        actions.register(action_name, lambda ctx, n=action_name: print(f"Action: {n}"))


# =============================================================================
# Example Usage
# =============================================================================


async def run_portfolio_optimization():
    """Run a simulated portfolio optimization cycle."""

    # Load FSM
    machine = StateMachine.from_yaml("examples/portfolio_optimization_fsm.yaml")
    machine.bind_guards(guards)

    # Create executor with phased execution
    executor = ActionExecutor(actions, default_mode=ExecutionMode.PHASED)

    # Initialize context
    context = create_portfolio_context()

    print("\n" + "=" * 60)
    print("Weekly Portfolio Optimization Simulation")
    print("=" * 60 + "\n")

    # === Start from idle ===
    current_state = machine.get_initial_state().name
    print(f"Starting state: {current_state}")

    # Simulate drift that triggers rebalance
    context["drift"] = 0.08  # 8% drift

    # === Trigger rebalance ===
    print("\n--- Triggering Rebalance (drift) ---")
    result = machine.process(current_state, "drift_trigger", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # === Analysis Phase ===
    # The machine automatically resolves to the initial child (analyzing.market)
    print(f"\n--- In analysis phase: {current_state} ---")

    # Market analysis complete
    result = machine.process(current_state, "market_analyzed", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # Risk analysis complete
    result = machine.process(current_state, "risk_analyzed", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # Opportunities identified
    result = machine.process(current_state, "opportunities_identified", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # === Optimization Phase ===
    print(f"\n--- In optimization phase: {current_state} ---")

    # Constraints set
    result = machine.process(current_state, "constraints_set", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # Optimization complete
    result = machine.process(current_state, "optimization_complete", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # Validation passed
    result = machine.process(current_state, "validation_passed", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # === Execution Phase ===
    print(f"\n--- In execution phase: {current_state} ---")

    # Planning complete
    result = machine.process(current_state, "planning_complete", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # Trades executed
    result = machine.process(current_state, "trades_executed", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # Settlement complete
    result = machine.process(current_state, "settlement_complete", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    # === Review Phase ===
    print(f"\n--- In review phase: {current_state} ---")

    # Review complete
    result = machine.process(current_state, "review_complete", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")

    print("\n" + "=" * 60)
    print("Portfolio Optimization Complete")
    print("=" * 60)


def main():
    """Main entry point."""
    import os

    # Change to project root for relative paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    os.chdir(project_root)

    asyncio.run(run_portfolio_optimization())


if __name__ == "__main__":
    main()
