"""Lightweight in-process pub/sub for config change notifications."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ChangeEvent:
    """A config artifact change notification.

    Attributes:
        topic: Resource type (e.g. "machine", "contract").
        action: What happened ("saved", "deleted", "activated").
        resource_id: Identifier of the changed resource.
        revision: Current revision after the change.
        actor: Who made the change.
        timestamp: Unix timestamp.
        metadata: Optional extra data.
    """

    topic: str
    action: str
    resource_id: str
    revision: int = 0
    actor: str = ""
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


class ChangeBus:
    """In-process pub/sub for config change events.

    Thread-safe. Supports multiple async subscribers per topic.
    Subscribers receive events via asyncio.Queue.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._queues: dict[str, list[asyncio.Queue[ChangeEvent | None]]] = defaultdict(
            list
        )
        self._buffer: list[ChangeEvent] = []
        self._max_buffer = 100

    def publish(self, event: ChangeEvent) -> None:
        """Publish a change event to all subscribers.

        Args:
            event: The change event to broadcast.
        """
        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) > self._max_buffer:
                self._buffer = self._buffer[-self._max_buffer :]
            for queue in self._queues.get(event.topic, []):
                self._try_enqueue(queue, event)
            for queue in self._queues.get("*", []):
                self._try_enqueue(queue, event)

    def subscribe(self, topic: str = "*") -> asyncio.Queue[ChangeEvent | None]:
        """Subscribe to change events for a topic.

        Args:
            topic: Topic to subscribe to, or "*" for all.

        Returns:
            Async queue that receives ChangeEvent objects.
        """
        queue: asyncio.Queue[ChangeEvent | None] = asyncio.Queue(maxsize=200)
        with self._lock:
            self._queues[topic].append(queue)
        return queue

    def unsubscribe(
        self,
        queue: asyncio.Queue[ChangeEvent | None],
        topic: str = "*",
    ) -> None:
        """Remove a subscription.

        Args:
            queue: The queue to unsubscribe.
            topic: Topic the queue was subscribed to.
        """
        with self._lock:
            if topic in self._queues:
                self._queues[topic] = [q for q in self._queues[topic] if q is not queue]

    @staticmethod
    def _try_enqueue(
        queue: asyncio.Queue[ChangeEvent | None],
        event: ChangeEvent,
    ) -> None:
        """Enqueue an event, logging a warning on overflow."""
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning(
                "Change event queue full for topic %s",
                event.topic,
            )
