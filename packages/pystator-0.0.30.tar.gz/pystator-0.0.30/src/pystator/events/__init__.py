"""Config change event bus for real-time collaboration."""

from __future__ import annotations

from pystator.events._change_bus import ChangeBus, ChangeEvent

__all__ = ["ChangeBus", "ChangeEvent"]
