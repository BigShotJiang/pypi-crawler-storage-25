"""Factory helpers for discovery store selection."""

from __future__ import annotations

from typing import Any

from pystator.discovery.stores.in_memory import InMemoryDiscoveryStore
from pystator.discovery.stores.mongodb import MongoDBDiscoveryStore
from pystator.discovery.stores.postgres import PostgresDiscoveryStore
from pystator.discovery.stores.redis import RedisDiscoveryStore
from pystator.discovery.stores.sqlite import SQLiteDiscoveryStore


def create_discovery_store(
    backend: str,
    *,
    connection_string: str | None = None,
    options: dict[str, Any] | None = None,
) -> (
    InMemoryDiscoveryStore
    | SQLiteDiscoveryStore
    | PostgresDiscoveryStore
    | MongoDBDiscoveryStore
    | RedisDiscoveryStore
):
    opts = options or {}
    normalized = backend.strip().lower()
    if normalized == "memory":
        return InMemoryDiscoveryStore()
    if normalized == "sqlite":
        if not connection_string:
            raise ValueError("connection_string is required for sqlite discovery store")
        return SQLiteDiscoveryStore(connection_string)
    if normalized in {"postgres", "postgresql"}:
        if not connection_string:
            raise ValueError(
                "connection_string is required for postgres discovery store"
            )
        return PostgresDiscoveryStore(connection_string)
    if normalized == "mongodb":
        if not connection_string:
            raise ValueError(
                "connection_string is required for mongodb discovery store"
            )
        return MongoDBDiscoveryStore(
            connection_string,
            database_name=str(opts.get("database_name", "pystator")),
        )
    if normalized == "redis":
        if not connection_string:
            raise ValueError("connection_string is required for redis discovery store")
        return RedisDiscoveryStore(
            connection_string,
            key_prefix=str(opts.get("key_prefix", "pystator:discovery")),
        )
    raise ValueError(f"Unsupported discovery backend: {backend}")
