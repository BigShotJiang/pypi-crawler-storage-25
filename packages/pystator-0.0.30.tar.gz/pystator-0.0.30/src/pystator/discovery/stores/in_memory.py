"""In-memory discovery store implementation."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import replace
from datetime import datetime
from typing import Any

from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)


class InMemoryDiscoveryStore:
    """Single in-memory store implementing all discovery protocols."""

    def __init__(self) -> None:
        self._observations: dict[str, list[ObservedStateEvent]] = defaultdict(list)
        self._dedupe: set[tuple[str, str, str, str, str | None, str]] = set()
        self._edges: dict[str, list[InferredEdge]] = defaultdict(list)
        self._built_candidates: dict[str, list[BuiltDiscoveryCandidate]] = defaultdict(
            list
        )
        self._shadow: dict[str, list[ShadowDiff]] = defaultdict(list)
        self._drafts: dict[str, DiscoveryDraft] = {}

    def add_observation(self, event: ObservedStateEvent) -> bool:
        key = (
            event.machine_name,
            event.entity_id,
            event.state,
            event.observed_at.isoformat(),
            event.source_event_id,
            event.source,
        )
        if key in self._dedupe:
            return False
        self._dedupe.add(key)
        self._observations[event.machine_name].append(event)
        return True

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        items = self._observations.get(machine_name, [])
        if entity_id is None:
            return list(items)
        return [ev for ev in items if ev.entity_id == entity_id]

    def list_entity_ids(self, machine_name: str) -> list[str]:
        items = self._observations.get(machine_name, [])
        return sorted({ev.entity_id for ev in items if ev.entity_id})

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        items = self._observations.get(machine_name, [])
        if not items:
            return 0
        kept = [ev for ev in items if ev.entity_id != entity_id]
        deleted = len(items) - len(kept)
        if deleted <= 0:
            return 0
        self._observations[machine_name] = kept
        self._dedupe = {
            key
            for key in self._dedupe
            if not (key[0] == machine_name and key[1] == entity_id)
        }
        return deleted

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        self._edges[machine_name] = list(edges)

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        return list(self._edges.get(machine_name, []))

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        existing = self._built_candidates[candidate.machine_name]
        for idx, item in enumerate(existing):
            if item.version == candidate.version:
                saved = replace(candidate, candidate_sequence=item.candidate_sequence)
                existing[idx] = saved
                return saved
        next_seq = max((c.candidate_sequence for c in existing), default=0) + 1
        saved = replace(candidate, candidate_sequence=next_seq)
        existing.append(saved)
        existing.sort(key=lambda c: c.created_at)
        return saved

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        for c in self._built_candidates.get(machine_name, []):
            if c.version == version:
                return c
        return None

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        items = self._built_candidates.get(machine_name, [])
        return items[-1] if items else None

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        return list(self._built_candidates.get(machine_name, []))

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        self._shadow[diff.machine_name].append(diff)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        items = self._shadow.get(machine_name, [])
        if limit <= 0:
            return []
        return list(items[-limit:])

    def as_dict(self) -> dict[str, Any]:
        return {
            "observations": {k: len(v) for k, v in self._observations.items()},
            "edges": {k: len(v) for k, v in self._edges.items()},
            "built_candidates": {k: len(v) for k, v in self._built_candidates.items()},
            "shadow": {k: len(v) for k, v in self._shadow.items()},
        }

    def list_fleet_summaries(self) -> list[dict[str, Any]]:
        """Same semantics as SQL store: shadow window = latest 200 diffs per machine."""
        names: set[str] = set()
        names |= set(self._observations.keys())
        names |= set(self._edges.keys())
        names |= set(self._built_candidates.keys())
        names |= set(self._shadow.keys())
        names |= {d.machine_name for d in self._drafts.values()}
        out: list[dict[str, Any]] = []
        for machine_name in sorted(names):
            obs = self._observations.get(machine_name, [])
            observation_count = len(obs)
            last_observation_at: datetime | None = None
            if obs:
                last_observation_at = max(e.observed_at for e in obs)

            cands = self._built_candidates.get(machine_name, [])
            candidate_count = len(cands)
            latest_candidate_version: str | None = None
            latest_candidate_created_at: datetime | None = None
            if cands:
                best = max(cands, key=lambda c: (c.created_at, c.version))
                latest_candidate_version = best.version
                latest_candidate_created_at = best.created_at

            shadow_all = self._shadow.get(machine_name, [])
            recent = sorted(shadow_all, key=lambda d: d.recorded_at, reverse=True)[:200]
            shadow_diff_count_recent = len(recent)
            differs_n = sum(1 for d in recent if d.differs)
            drift_rate_recent = (
                differs_n / shadow_diff_count_recent
                if shadow_diff_count_recent
                else 0.0
            )

            out.append(
                {
                    "machine_name": machine_name,
                    "last_observation_at": last_observation_at,
                    "observation_count": observation_count,
                    "candidate_count": candidate_count,
                    "latest_candidate_version": latest_candidate_version,
                    "latest_candidate_created_at": latest_candidate_created_at,
                    "shadow_diff_count_recent": shadow_diff_count_recent,
                    "drift_rate_recent": drift_rate_recent,
                }
            )
        return out

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        self._drafts[draft.id] = draft
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        return self._drafts.get(draft_id)

    def list_drafts(self, machine_name: str) -> list[DiscoveryDraft]:
        items = [d for d in self._drafts.values() if d.machine_name == machine_name]
        items.sort(key=lambda d: d.updated_at, reverse=True)
        return items

    def delete_draft(self, draft_id: str) -> bool:
        if draft_id in self._drafts:
            del self._drafts[draft_id]
            return True
        return False
