"""MongoDB discovery store."""

from __future__ import annotations

from datetime import datetime

from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)

try:
    import pymongo  # type: ignore[import-not-found,import-untyped]

    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    pymongo = None  # type: ignore[assignment]


def _mongo_built_from_doc(row: dict) -> BuiltDiscoveryCandidate:
    return BuiltDiscoveryCandidate(
        machine_name=row["machine_name"],
        version=row["version"],
        status=row["status"],
        config=dict(row["config"]),
        metadata=dict(row.get("metadata") or {}),
        created_at=row.get("created_at") or datetime.utcnow(),
        candidate_sequence=int(row.get("candidate_sequence") or 0),
    )


class MongoDBDiscoveryStore:
    def __init__(self, connection_string: str, database_name: str = "pystator") -> None:
        if not MONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDBDiscoveryStore. Install with: pip install pymongo"
            )
        if not connection_string.startswith(("mongodb://", "mongodb+srv://")):
            raise ValueError(
                f"MongoDBDiscoveryStore requires a mongodb:// URL, got: {connection_string!r}"
            )
        self.connection_string = connection_string
        self.database_name = database_name
        self._client = None
        self._db = None

    def connect(self) -> None:
        self._client = pymongo.MongoClient(self.connection_string)
        self._db = self._client[self.database_name]
        db = self._db
        coll_names = db.list_collection_names()
        if (
            "discovery_candidates" in coll_names
            and "discovery_built_candidates" not in coll_names
        ):
            db["discovery_candidates"].rename("discovery_built_candidates")
        if (
            "discovery_workspaces" in coll_names
            and "discovery_drafts" not in coll_names
        ):
            db["discovery_workspaces"].rename("discovery_drafts")
        db["discovery_observations"].create_index(
            [
                ("machine_name", 1),
                ("entity_id", 1),
                ("state", 1),
                ("observed_at", 1),
                ("source", 1),
                ("source_event_id", 1),
            ],
            unique=True,
        )
        db["discovery_built_candidates"].create_index(
            [("machine_name", 1), ("version", 1)], unique=True
        )
        db["discovery_drafts"].create_index([("id", 1)], unique=True)
        db["discovery_drafts"].create_index([("machine_name", 1), ("updated_at", -1)])

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
        self._client = None
        self._db = None

    def _require_db(self):
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._db

    def add_observation(self, event: ObservedStateEvent) -> bool:
        db = self._require_db()
        doc = {
            "machine_name": event.machine_name,
            "entity_id": event.entity_id,
            "state": event.state,
            "observed_at": event.observed_at,
            "source": event.source,
            "source_event_id": event.source_event_id,
            "metadata": event.metadata,
            "ingested_at": event.ingested_at,
            "ingest_seq": event.ingest_seq,
        }
        try:
            db["discovery_observations"].insert_one(doc)
            return True
        except Exception:
            return False

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        db = self._require_db()
        query = {"machine_name": machine_name}
        if entity_id:
            query["entity_id"] = entity_id
        rows = (
            db["discovery_observations"]
            .find(query)
            .sort(
                [
                    ("entity_id", 1),
                    ("observed_at", 1),
                    ("ingest_seq", 1),
                    ("ingested_at", 1),
                ]
            )
        )
        return [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                machine_name=machine_name,
                state=row["state"],
                observed_at=row["observed_at"],
                source=row["source"],
                source_event_id=row.get("source_event_id"),
                metadata=dict(row.get("metadata") or {}),
                ingested_at=row["ingested_at"],
                ingest_seq=int(row.get("ingest_seq") or 0),
            )
            for row in rows
        ]

    def list_entity_ids(self, machine_name: str) -> list[str]:
        db = self._require_db()
        ids = db["discovery_observations"].distinct(
            "entity_id", {"machine_name": machine_name}
        )
        return sorted(str(x) for x in ids if x)

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        db = self._require_db()
        result = db["discovery_observations"].delete_many(
            {"machine_name": machine_name, "entity_id": entity_id}
        )
        return int(result.deleted_count or 0)

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        db = self._require_db()
        db["discovery_edges"].delete_many({"machine_name": machine_name})
        if not edges:
            return
        db["discovery_edges"].insert_many(
            [
                {
                    "machine_name": machine_name,
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                    "last_seen_at": e.last_seen_at,
                }
                for e in edges
            ]
        )

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        db = self._require_db()
        rows = (
            db["discovery_edges"]
            .find({"machine_name": machine_name})
            .sort([("source_state", 1), ("destination_state", 1)])
        )
        return [
            InferredEdge(
                source_state=row["source_state"],
                destination_state=row["destination_state"],
                count=int(row["count"]),
                unique_entities=int(row["unique_entities"]),
                unique_sources=int(row["unique_sources"]),
                confidence=float(row["confidence"]),
                last_seen_at=row.get("last_seen_at"),
            )
            for row in rows
        ]

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        db = self._require_db()
        coll = db["discovery_built_candidates"]
        existing = coll.find_one(
            {"machine_name": candidate.machine_name, "version": candidate.version}
        )
        if existing is not None:
            seq = int(existing.get("candidate_sequence") or 0)
        else:
            max_row = coll.find_one(
                {"machine_name": candidate.machine_name},
                sort=[("candidate_sequence", -1)],
            )
            max_seq = (
                int(max_row["candidate_sequence"])
                if max_row and max_row.get("candidate_sequence") is not None
                else 0
            )
            seq = max_seq + 1
        doc = {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "created_at": candidate.created_at,
            "candidate_sequence": seq,
        }
        coll.replace_one(
            {"machine_name": candidate.machine_name, "version": candidate.version},
            doc,
            upsert=True,
        )
        out = self.get_built_candidate(candidate.machine_name, candidate.version)
        assert out is not None
        return out

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        db = self._require_db()
        row = db["discovery_built_candidates"].find_one(
            {"machine_name": machine_name, "version": version}
        )
        if not row:
            return None
        return _mongo_built_from_doc(row)

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        db = self._require_db()
        row = db["discovery_built_candidates"].find_one(
            {"machine_name": machine_name}, sort=[("created_at", -1)]
        )
        if not row:
            return None
        return _mongo_built_from_doc(row)

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        db = self._require_db()
        rows = (
            db["discovery_built_candidates"]
            .find({"machine_name": machine_name})
            .sort([("created_at", -1)])
        )
        return [_mongo_built_from_doc(row) for row in rows]

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        db = self._require_db()
        db["discovery_shadow_diffs"].insert_one(
            {
                "machine_name": diff.machine_name,
                "source_state": diff.source_state,
                "trigger": diff.trigger,
                "active_success": diff.active_success,
                "active_target_state": diff.active_target_state,
                "candidate_success": diff.candidate_success,
                "candidate_target_state": diff.candidate_target_state,
                "differs": diff.differs,
                "reason": diff.reason,
                "recorded_at": diff.recorded_at,
                "metadata": diff.metadata,
            }
        )

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        db = self._require_db()
        rows = (
            db["discovery_shadow_diffs"]
            .find({"machine_name": machine_name})
            .sort([("recorded_at", -1)])
            .limit(max(0, limit))
        )
        return [
            ShadowDiff(
                machine_name=row["machine_name"],
                source_state=row["source_state"],
                trigger=row["trigger"],
                active_success=bool(row["active_success"]),
                active_target_state=row.get("active_target_state"),
                candidate_success=bool(row["candidate_success"]),
                candidate_target_state=row.get("candidate_target_state"),
                differs=bool(row["differs"]),
                reason=row.get("reason"),
                recorded_at=row["recorded_at"],
                metadata=dict(row.get("metadata") or {}),
            )
            for row in rows
        ]

    def _doc_to_draft(self, row: dict) -> DiscoveryDraft:
        sel = row.get("selected_entity_ids") or []
        manual = row.get("manual_edge_selection") or []
        pairs: list[tuple[str, str]] = []
        for item in manual:
            if isinstance(item, dict):
                s = item.get("source_state")
                d = item.get("destination_state")
                if isinstance(s, str) and isinstance(d, str):
                    pairs.append((s, d))
        return DiscoveryDraft(
            id=row["id"],
            machine_name=row["machine_name"],
            title=row.get("title"),
            selected_entity_ids=tuple(str(x) for x in sel),
            mode=str(row.get("mode") or "inference"),
            min_edge_count=int(row.get("min_edge_count") or 2),
            min_confidence=float(row.get("min_confidence") or 0.5),
            manual_edge_selection=tuple(pairs),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            last_built_version=row.get("last_built_version"),
        )

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        db = self._require_db()
        db["discovery_drafts"].replace_one(
            {"id": draft.id},
            {
                "id": draft.id,
                "machine_name": draft.machine_name,
                "title": draft.title,
                "selected_entity_ids": list(draft.selected_entity_ids),
                "mode": draft.mode,
                "min_edge_count": draft.min_edge_count,
                "min_confidence": draft.min_confidence,
                "manual_edge_selection": [
                    {"source_state": a, "destination_state": b}
                    for (a, b) in draft.manual_edge_selection
                ],
                "created_at": draft.created_at,
                "updated_at": draft.updated_at,
                "last_built_version": draft.last_built_version,
            },
            upsert=True,
        )
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        db = self._require_db()
        row = db["discovery_drafts"].find_one({"id": draft_id})
        if not row:
            return None
        return self._doc_to_draft(dict(row))

    def list_drafts(self, machine_name: str) -> list[DiscoveryDraft]:
        db = self._require_db()
        rows = (
            db["discovery_drafts"]
            .find({"machine_name": machine_name})
            .sort([("updated_at", -1)])
        )
        return [self._doc_to_draft(dict(r)) for r in rows]

    def delete_draft(self, draft_id: str) -> bool:
        db = self._require_db()
        r = db["discovery_drafts"].delete_one({"id": draft_id})
        return bool(r.deleted_count)
