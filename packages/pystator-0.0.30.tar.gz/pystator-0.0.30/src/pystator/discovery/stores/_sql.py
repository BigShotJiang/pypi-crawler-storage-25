"""Private SQL-backed discovery store shared by SQLite and PostgreSQL."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.sql_schema import apply_discovery_schema


def _dt_parse(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        return datetime.fromisoformat(value)
    raise ValueError(f"Cannot parse datetime value: {value!r}")


def _draft_from_row(row: Any) -> DiscoveryDraft:
    sel = json.loads(row["selected_entity_ids_json"] or "[]")
    if not isinstance(sel, list):
        sel = []
    manual = json.loads(row["manual_edge_selection_json"] or "[]")
    pairs: list[tuple[str, str]] = []
    if isinstance(manual, list):
        for item in manual:
            if isinstance(item, dict):
                s = item.get("source_state") or item.get("source")
                d = item.get("destination_state") or item.get("dest")
                if isinstance(s, str) and isinstance(d, str):
                    pairs.append((s, d))
            elif isinstance(item, (list, tuple)) and len(item) == 2:
                pairs.append((str(item[0]), str(item[1])))
    return DiscoveryDraft(
        id=row["id"],
        machine_name=row["machine_name"],
        title=row["title"] or None,
        selected_entity_ids=tuple(str(x) for x in sel),
        mode=str(row["mode"] or "inference"),
        min_edge_count=int(row["min_edge_count"] or 2),
        min_confidence=float(row["min_confidence"] or 0.5),
        manual_edge_selection=tuple(pairs),
        created_at=_dt_parse(row["created_at"]),
        updated_at=_dt_parse(row["updated_at"]),
        last_built_version=row["last_built_version"] or None,
    )


def _built_from_row(row: Any) -> BuiltDiscoveryCandidate:
    seq = row.get("candidate_sequence")
    if seq is None:
        seq = 0
    return BuiltDiscoveryCandidate(
        machine_name=row["machine_name"],
        version=row["version"],
        status=row["status"],
        config=json.loads(row["config_json"]),
        metadata=json.loads(row["metadata_json"] or "{}"),
        created_at=_dt_parse(row["created_at"]),
        candidate_sequence=int(seq),
    )


class _SQLDiscoveryStoreBase:
    def __init__(self, connection_string: str) -> None:
        self.connection_string = connection_string
        self._engine: Engine | None = None

    def connect(self) -> None:
        self._engine = create_engine(self.connection_string, future=True)
        self._initialize_schema()

    def disconnect(self) -> None:
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None

    def _require_engine(self) -> Engine:
        if self._engine is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._engine

    def _initialize_schema(self) -> None:
        apply_discovery_schema(self._require_engine())

    def list_fleet_summaries(self) -> list[dict[str, Any]]:
        """One row per machine with discovery aggregates.

        Shadow metrics use the **latest 200** shadow diffs per machine
        (``recorded_at`` DESC): ``shadow_diff_count_recent`` is the count in
        that window; ``drift_rate_recent`` is the fraction where ``differs`` is true.
        """
        engine = self._require_engine()
        sql = """
            WITH machine_names AS (
              SELECT machine_name FROM discovery_observations
              UNION SELECT machine_name FROM discovery_edges
              UNION SELECT machine_name FROM discovery_built_candidates
              UNION SELECT machine_name FROM discovery_shadow_diffs
              UNION SELECT machine_name FROM discovery_drafts
            ),
            obs_agg AS (
              SELECT machine_name,
                     COUNT(*) AS observation_count,
                     MAX(observed_at) AS last_observation_at
              FROM discovery_observations
              GROUP BY machine_name
            ),
            cand_agg AS (
              SELECT machine_name,
                     COUNT(*) AS candidate_count,
                     MAX(created_at) AS latest_candidate_created_at
              FROM discovery_built_candidates
              GROUP BY machine_name
            ),
            latest_cand AS (
              SELECT machine_name, version AS latest_candidate_version
              FROM (
                SELECT machine_name, version, created_at,
                       ROW_NUMBER() OVER (
                         PARTITION BY machine_name
                         ORDER BY created_at DESC, version DESC
                       ) AS rk
                FROM discovery_built_candidates
              ) z
              WHERE rk = 1
            ),
            shadow_recent AS (
              SELECT machine_name,
                     SUM(CASE WHEN differs = 1 THEN 1 ELSE 0 END) AS shadow_differs,
                     COUNT(*) AS shadow_total
              FROM (
                SELECT machine_name, differs,
                       ROW_NUMBER() OVER (
                         PARTITION BY machine_name
                         ORDER BY recorded_at DESC
                       ) AS rn
                FROM discovery_shadow_diffs
              ) t
              WHERE rn <= 200
              GROUP BY machine_name
            )
            SELECT
              mn.machine_name,
              COALESCE(oa.observation_count, 0) AS observation_count,
              oa.last_observation_at,
              COALESCE(ca.candidate_count, 0) AS candidate_count,
              lc.latest_candidate_version,
              ca.latest_candidate_created_at,
              COALESCE(sr.shadow_total, 0) AS shadow_diff_count_recent,
              CASE WHEN COALESCE(sr.shadow_total, 0) > 0
                   THEN CAST(sr.shadow_differs AS REAL) / sr.shadow_total
                   ELSE 0.0
              END AS drift_rate_recent
            FROM machine_names mn
            LEFT JOIN obs_agg oa ON mn.machine_name = oa.machine_name
            LEFT JOIN cand_agg ca ON mn.machine_name = ca.machine_name
            LEFT JOIN latest_cand lc ON mn.machine_name = lc.machine_name
            LEFT JOIN shadow_recent sr ON mn.machine_name = sr.machine_name
            """
        with engine.begin() as conn:
            rows = conn.execute(text(sql)).mappings().all()
        out: list[dict[str, Any]] = []
        for row in rows:
            loa = row["last_observation_at"]
            lcca = row["latest_candidate_created_at"]
            out.append(
                {
                    "machine_name": row["machine_name"],
                    "last_observation_at": _dt_parse(loa) if loa else None,
                    "observation_count": int(row["observation_count"] or 0),
                    "candidate_count": int(row["candidate_count"] or 0),
                    "latest_candidate_version": row["latest_candidate_version"],
                    "latest_candidate_created_at": _dt_parse(lcca) if lcca else None,
                    "shadow_diff_count_recent": int(
                        row["shadow_diff_count_recent"] or 0
                    ),
                    "drift_rate_recent": float(row["drift_rate_recent"] or 0.0),
                }
            )
        return out

    def add_observation(self, event: ObservedStateEvent) -> bool:
        engine = self._require_engine()
        machine_name = event.machine_name
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    """
                    INSERT INTO discovery_observations (
                      machine_name, entity_id, state, observed_at, source, source_event_id,
                      metadata_json, ingested_at, ingest_seq
                    ) VALUES (
                      :machine_name, :entity_id, :state, :observed_at, :source, :source_event_id,
                      :metadata_json, :ingested_at, :ingest_seq
                    )
                    ON CONFLICT(machine_name, entity_id, state, observed_at, source, source_event_id)
                    DO NOTHING
                    """
                ),
                {
                    "machine_name": machine_name,
                    "entity_id": event.entity_id,
                    "state": event.state,
                    "observed_at": event.observed_at.isoformat(),
                    "source": event.source,
                    "source_event_id": event.source_event_id,
                    "metadata_json": json.dumps(event.metadata),
                    "ingested_at": event.ingested_at.isoformat(),
                    "ingest_seq": event.ingest_seq,
                },
            )
        return bool(result.rowcount and result.rowcount > 0)

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        engine = self._require_engine()
        sql = """
            SELECT entity_id, state, observed_at, source, source_event_id, metadata_json, ingested_at, ingest_seq
            FROM discovery_observations
            WHERE machine_name = :machine_name
        """
        params: dict[str, Any] = {"machine_name": machine_name}
        if entity_id:
            sql += " AND entity_id = :entity_id"
            params["entity_id"] = entity_id
        sql += " ORDER BY entity_id, observed_at, ingest_seq, ingested_at"
        with engine.begin() as conn:
            rows = conn.execute(text(sql), params).mappings().all()
        return [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                machine_name=machine_name,
                state=row["state"],
                observed_at=_dt_parse(row["observed_at"]),
                source=row["source"],
                source_event_id=row["source_event_id"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                ingested_at=_dt_parse(row["ingested_at"]),
                ingest_seq=int(row["ingest_seq"] or 0),
            )
            for row in rows
        ]

    def list_entity_ids(self, machine_name: str) -> list[str]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT DISTINCT entity_id
                    FROM discovery_observations
                    WHERE machine_name = :machine_name
                    ORDER BY entity_id
                    """
                ),
                {"machine_name": machine_name},
            ).all()
        return [str(row[0]) for row in rows if row and row[0]]

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        engine = self._require_engine()
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    """
                    DELETE FROM discovery_observations
                    WHERE machine_name = :machine_name AND entity_id = :entity_id
                    """
                ),
                {"machine_name": machine_name, "entity_id": entity_id},
            )
        return int(result.rowcount or 0)

    def upsert_edges(self, machine_name: str, edges: list[InferredEdge]) -> None:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM discovery_edges WHERE machine_name = :machine_name"),
                {"machine_name": machine_name},
            )
            for edge in edges:
                conn.execute(
                    text(
                        """
                        INSERT INTO discovery_edges (
                          machine_name, source_state, destination_state, count,
                          unique_entities, unique_sources, confidence, last_seen_at
                        ) VALUES (
                          :machine_name, :source_state, :destination_state, :count,
                          :unique_entities, :unique_sources, :confidence, :last_seen_at
                        )
                        """
                    ),
                    {
                        "machine_name": machine_name,
                        "source_state": edge.source_state,
                        "destination_state": edge.destination_state,
                        "count": edge.count,
                        "unique_entities": edge.unique_entities,
                        "unique_sources": edge.unique_sources,
                        "confidence": edge.confidence,
                        "last_seen_at": edge.last_seen_at.isoformat()
                        if edge.last_seen_at
                        else None,
                    },
                )

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT source_state, destination_state, count, unique_entities, unique_sources,
                           confidence, last_seen_at
                    FROM discovery_edges
                    WHERE machine_name = :machine_name
                    ORDER BY source_state, destination_state
                    """
                ),
                {"machine_name": machine_name},
            ).mappings()
            result = rows.all()
        return [
            InferredEdge(
                source_state=row["source_state"],
                destination_state=row["destination_state"],
                count=int(row["count"]),
                unique_entities=int(row["unique_entities"]),
                unique_sources=int(row["unique_sources"]),
                confidence=float(row["confidence"]),
                last_seen_at=_dt_parse(row["last_seen_at"])
                if row["last_seen_at"]
                else None,
            )
            for row in result
        ]

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        engine = self._require_engine()
        mn = candidate.machine_name
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_built_candidates (
                      machine_name, version, status, config_json, metadata_json, created_at,
                      candidate_sequence
                    ) VALUES (
                      :machine_name, :version, :status, :config_json, :metadata_json, :created_at,
                      (SELECT COALESCE(MAX(candidate_sequence), 0) + 1
                       FROM discovery_built_candidates WHERE machine_name = :machine_name_seq)
                    )
                    ON CONFLICT(machine_name, version)
                    DO UPDATE SET
                      status = excluded.status,
                      config_json = excluded.config_json,
                      metadata_json = excluded.metadata_json,
                      created_at = excluded.created_at
                    """
                ),
                {
                    "machine_name": mn,
                    "version": candidate.version,
                    "status": candidate.status,
                    "config_json": json.dumps(candidate.config),
                    "metadata_json": json.dumps(candidate.metadata),
                    "created_at": candidate.created_at.isoformat(),
                    "machine_name_seq": mn,
                },
            )
        out = self.get_built_candidate(mn, candidate.version)
        assert out is not None
        return out

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at, candidate_sequence
                    FROM discovery_built_candidates
                    WHERE machine_name = :machine_name AND version = :version
                    """
                    ),
                    {"machine_name": machine_name, "version": version},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return _built_from_row(row)

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at, candidate_sequence
                    FROM discovery_built_candidates
                    WHERE machine_name = :machine_name
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                    ),
                    {"machine_name": machine_name},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return _built_from_row(row)

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at, candidate_sequence
                    FROM discovery_built_candidates
                    WHERE machine_name = :machine_name
                    ORDER BY created_at DESC
                    """
                ),
                {"machine_name": machine_name},
            ).mappings()
            result = rows.all()
        return [_built_from_row(row) for row in result]

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_shadow_diffs (
                      machine_name, source_state, trigger, active_success, active_target_state,
                      candidate_success, candidate_target_state, differs, reason, metadata_json, recorded_at
                    ) VALUES (
                      :machine_name, :source_state, :trigger, :active_success, :active_target_state,
                      :candidate_success, :candidate_target_state, :differs, :reason, :metadata_json, :recorded_at
                    )
                    """
                ),
                {
                    "machine_name": diff.machine_name,
                    "source_state": diff.source_state,
                    "trigger": diff.trigger,
                    "active_success": 1 if diff.active_success else 0,
                    "active_target_state": diff.active_target_state,
                    "candidate_success": 1 if diff.candidate_success else 0,
                    "candidate_target_state": diff.candidate_target_state,
                    "differs": 1 if diff.differs else 0,
                    "reason": diff.reason,
                    "metadata_json": json.dumps(diff.metadata),
                    "recorded_at": diff.recorded_at.isoformat(),
                },
            )

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT machine_name, source_state, trigger, active_success, active_target_state,
                           candidate_success, candidate_target_state, differs, reason, metadata_json, recorded_at
                    FROM discovery_shadow_diffs
                    WHERE machine_name = :machine_name
                    ORDER BY recorded_at DESC
                    LIMIT :limit
                    """
                ),
                {"machine_name": machine_name, "limit": max(0, limit)},
            ).mappings()
            result = rows.all()
        return [
            ShadowDiff(
                machine_name=row["machine_name"],
                source_state=row["source_state"],
                trigger=row["trigger"],
                active_success=bool(row["active_success"]),
                active_target_state=row["active_target_state"],
                candidate_success=bool(row["candidate_success"]),
                candidate_target_state=row["candidate_target_state"],
                differs=bool(row["differs"]),
                reason=row["reason"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                recorded_at=_dt_parse(row["recorded_at"]),
            )
            for row in result
        ]

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        engine = self._require_engine()
        manual_json = json.dumps(
            [
                {"source_state": a, "destination_state": b}
                for (a, b) in draft.manual_edge_selection
            ]
        )
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_drafts (
                      id, machine_name, title, selected_entity_ids_json, mode,
                      min_edge_count, min_confidence, manual_edge_selection_json,
                      created_at, updated_at, last_built_version
                    ) VALUES (
                      :id, :machine_name, :title, :selected_entity_ids_json, :mode,
                      :min_edge_count, :min_confidence, :manual_edge_selection_json,
                      :created_at, :updated_at, :last_built_version
                    )
                    ON CONFLICT(id) DO UPDATE SET
                      machine_name = excluded.machine_name,
                      title = excluded.title,
                      selected_entity_ids_json = excluded.selected_entity_ids_json,
                      mode = excluded.mode,
                      min_edge_count = excluded.min_edge_count,
                      min_confidence = excluded.min_confidence,
                      manual_edge_selection_json = excluded.manual_edge_selection_json,
                      updated_at = excluded.updated_at,
                      last_built_version = excluded.last_built_version
                    """
                ),
                {
                    "id": draft.id,
                    "machine_name": draft.machine_name,
                    "title": draft.title,
                    "selected_entity_ids_json": json.dumps(
                        list(draft.selected_entity_ids)
                    ),
                    "mode": draft.mode,
                    "min_edge_count": draft.min_edge_count,
                    "min_confidence": draft.min_confidence,
                    "manual_edge_selection_json": manual_json,
                    "created_at": draft.created_at.isoformat(),
                    "updated_at": draft.updated_at.isoformat(),
                    "last_built_version": draft.last_built_version,
                },
            )
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT id, machine_name, title, selected_entity_ids_json, mode,
                           min_edge_count, min_confidence, manual_edge_selection_json,
                           created_at, updated_at, last_built_version
                    FROM discovery_drafts
                    WHERE id = :id
                    """
                    ),
                    {"id": draft_id},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return _draft_from_row(row)

    def list_drafts(self, machine_name: str) -> list[DiscoveryDraft]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT id, machine_name, title, selected_entity_ids_json, mode,
                           min_edge_count, min_confidence, manual_edge_selection_json,
                           created_at, updated_at, last_built_version
                    FROM discovery_drafts
                    WHERE machine_name = :machine_name
                    ORDER BY updated_at DESC
                    """
                ),
                {"machine_name": machine_name},
            ).mappings()
            result = rows.all()
        return [_draft_from_row(row) for row in result]

    def delete_draft(self, draft_id: str) -> bool:
        engine = self._require_engine()
        with engine.begin() as conn:
            r = conn.execute(
                text("DELETE FROM discovery_drafts WHERE id = :id"),
                {"id": draft_id},
            )
        return bool(r.rowcount and r.rowcount > 0)
