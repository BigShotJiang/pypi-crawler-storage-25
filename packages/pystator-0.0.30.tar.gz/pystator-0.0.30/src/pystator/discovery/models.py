"""Core domain models for inferred FSM discovery."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


def _utc_now() -> datetime:
    return datetime.now(UTC)


@dataclass(frozen=True, slots=True)
class ObservedStateEvent:
    """One observed state for an entity.

    Attributes:
        entity_id: Identifier for the entity being observed.
        machine_name: FSM machine this observation belongs to.
        state: The observed state name.
        observed_at: When the state was observed.
        source: Origin system or label for this observation.
        source_event_id: Optional upstream event ID for traceability.
        metadata: Additional user-defined metadata.
        ingested_at: When this event was ingested into the store.
        ingest_seq: Monotonic sequence number within an ingestion session.
    """

    entity_id: str
    machine_name: str
    state: str
    observed_at: datetime
    source: str = "unknown"
    source_event_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    ingested_at: datetime = field(default_factory=_utc_now)
    ingest_seq: int = 0

    def __post_init__(self) -> None:
        if not self.entity_id:
            raise ValueError("entity_id cannot be empty")
        if not self.machine_name:
            raise ValueError("machine_name cannot be empty")
        if not self.state:
            raise ValueError("state cannot be empty")
        if not self.source:
            raise ValueError("source cannot be empty")


@dataclass(frozen=True, slots=True)
class InferredEdge:
    """Weighted transition inferred from observed sequences."""

    source_state: str
    destination_state: str
    count: int
    unique_entities: int
    unique_sources: int
    confidence: float
    last_seen_at: datetime | None = None

    def __post_init__(self) -> None:
        if not self.source_state:
            raise ValueError("source_state cannot be empty")
        if not self.destination_state:
            raise ValueError("destination_state cannot be empty")
        if self.count < 0:
            raise ValueError("count must be >= 0")
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError("confidence must be between 0 and 1")


@dataclass(frozen=True, slots=True)
class DiscoveryDraft:
    """Draft discovery scope: entity selection and inference settings before build."""

    id: str
    machine_name: str
    title: str | None
    selected_entity_ids: tuple[str, ...]
    mode: str  # "inference" | "manual"
    min_edge_count: int
    min_confidence: float
    manual_edge_selection: tuple[tuple[str, str], ...]
    created_at: datetime
    updated_at: datetime
    last_built_version: str | None = None

    def __post_init__(self) -> None:
        if not self.id:
            raise ValueError("id cannot be empty")
        if not self.machine_name:
            raise ValueError("machine_name cannot be empty")
        if self.mode not in ("inference", "manual"):
            raise ValueError("mode must be inference or manual")
        if self.min_edge_count < 1:
            raise ValueError("min_edge_count must be >= 1")
        if not (0.0 <= self.min_confidence <= 1.0):
            raise ValueError("min_confidence must be between 0 and 1")


@dataclass(frozen=True, slots=True)
class BuiltDiscoveryCandidate:
    """Persisted built FSM snapshot from discovery (a versioned candidate machine)."""

    machine_name: str
    version: str
    status: str
    config: dict[str, Any]
    created_at: datetime = field(default_factory=_utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)
    #: Per-machine monotonic display index (1, 2, 3, …). ``version`` remains the canonical identifier.
    candidate_sequence: int = 0

    def __post_init__(self) -> None:
        if not self.machine_name:
            raise ValueError("machine_name cannot be empty")
        if not self.version:
            raise ValueError("version cannot be empty")
        if not self.status:
            raise ValueError("status cannot be empty")
        if not isinstance(self.config, dict):
            raise ValueError("config must be a dict")
        if self.candidate_sequence < 0:
            raise ValueError("candidate_sequence must be >= 0")


@dataclass(frozen=True, slots=True)
class ShadowDiff:
    """Comparison between active and inferred machine outcomes."""

    machine_name: str
    source_state: str
    trigger: str
    active_success: bool
    active_target_state: str | None
    candidate_success: bool
    candidate_target_state: str | None
    differs: bool
    reason: str | None = None
    recorded_at: datetime = field(default_factory=_utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)
