"""Data ingester for streaming and batch classification into discovery."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from pystator.discovery.classification._classifier import StateClassifier
from pystator.discovery.classification._models import (
    ClassificationResult,
    IngestionResult,
)
from pystator.discovery.models import ObservedStateEvent
from pystator.discovery.service import InferenceEngine

logger = logging.getLogger(__name__)


class DataIngester:
    """Ingests raw data records through classification into InferenceEngine.

    Supports record-by-record streaming and batch (list) ingestion.
    For each record: classify state -> create ObservedStateEvent ->
    feed to InferenceEngine.record_observation().

    Args:
        classifier: StateClassifier with rules for state determination.
        engine: InferenceEngine to feed observations into.
        machine_name: Target machine name for observations.
        skip_unclassified: If True, silently skip records with no state.
            If False, raise ValueError for unclassified records.
    """

    def __init__(
        self,
        classifier: StateClassifier,
        engine: InferenceEngine,
        machine_name: str,
        *,
        skip_unclassified: bool = True,
    ) -> None:
        self._classifier = classifier
        self._engine = engine
        self._machine_name = machine_name
        self._skip_unclassified = skip_unclassified
        self._ingest_seq: int = 0

    @property
    def classifier(self) -> StateClassifier:
        """The state classifier."""
        return self._classifier

    @property
    def machine_name(self) -> str:
        """Target machine name for observations."""
        return self._machine_name

    def ingest_record(self, record: dict[str, Any]) -> ClassificationResult:
        """Classify and ingest a single record (streaming).

        Args:
            record: Raw data record with field values.

        Returns:
            ClassificationResult for this record.

        Raises:
            ValueError: If state is None and skip_unclassified is False.
            ValueError: If entity_id field is missing from record.
        """
        result = self._classifier.classify(record)
        if result.state is None:
            if not self._skip_unclassified:
                raise ValueError(
                    "No state determined for record and no default_state "
                    f"configured: {record}"
                )
            logger.debug("Skipping unclassified record")
            return result

        event = self._build_event(record, result.state)
        self._engine.record_observation(self._machine_name, event)
        return result

    def ingest_batch(self, records: list[dict[str, Any]]) -> IngestionResult:
        """Classify and ingest a batch of records.

        Each record is processed independently; one bad record does
        not abort the batch.

        Args:
            records: List of raw data records.

        Returns:
            IngestionResult with counts of accepted, skipped, and errors.
        """
        accepted = 0
        classified = 0
        skipped = 0
        errors = 0

        for record in records:
            try:
                result = self._classifier.classify(record)
                if result.state is None:
                    skipped += 1
                    continue
                event = self._build_event(record, result.state)
                classified += 1
                if self._engine.record_observation(self._machine_name, event):
                    accepted += 1
            except Exception:
                logger.warning(
                    "Error ingesting record: %s",
                    record,
                    exc_info=True,
                )
                errors += 1

        return IngestionResult(
            total=len(records),
            accepted=accepted,
            classified=classified,
            skipped=skipped,
            errors=errors,
        )

    def _build_event(self, record: dict[str, Any], state: str) -> ObservedStateEvent:
        """Create an ObservedStateEvent from a classified record."""
        rule_set = self._classifier.rule_set
        entity_id = str(record.get(rule_set.entity_id_field, ""))
        if not entity_id:
            raise ValueError(
                f"Record missing entity_id field '{rule_set.entity_id_field}': {record}"
            )

        observed_at: datetime
        if rule_set.timestamp_field and rule_set.timestamp_field in record:
            ts_val = record[rule_set.timestamp_field]
            if isinstance(ts_val, datetime):
                observed_at = ts_val
            else:
                observed_at = datetime.fromisoformat(str(ts_val))
        else:
            observed_at = datetime.now(UTC)

        self._ingest_seq += 1

        return ObservedStateEvent(
            entity_id=entity_id,
            machine_name=self._machine_name,
            state=state,
            observed_at=observed_at,
            source=rule_set.source,
            ingest_seq=self._ingest_seq,
        )
