"""Data models for state classification from data records."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pystator._types import State


@dataclass(frozen=True, slots=True)
class ClassificationRuleSet:
    """Ordered collection of classifiable states with ingestion settings.

    States are evaluated in tuple order; first state whose ``when``
    checks all pass wins.

    Attributes:
        states: States that have ``when`` clauses, in evaluation order.
        default_state: State name when no rule matches. None means unclassified.
        entity_id_field: Record field to extract entity_id from.
        timestamp_field: Record field to extract observed_at from.
        source: Source label for ObservedStateEvent.
    """

    states: tuple[State, ...]
    default_state: str | None = None
    entity_id_field: str = "entity_id"
    timestamp_field: str | None = None
    source: str = "classifier"

    def __post_init__(self) -> None:
        for state in self.states:
            if not state.when:
                raise ValueError(
                    f"State '{state.name}' has no 'when' clause and "
                    f"cannot be part of a ClassificationRuleSet"
                )


@dataclass(frozen=True, slots=True)
class ClassificationResult:
    """Outcome of classifying a single data record.

    Attributes:
        state: The classified state name, or None if no match and no default.
        matched: Whether a state's when clause matched (False means default).
        record: The original data record.
    """

    state: str | None
    matched: bool
    record: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class IngestionResult:
    """Summary of a batch ingestion operation.

    Attributes:
        total: Total number of records processed.
        accepted: Records accepted by the observation store.
        classified: Records successfully classified.
        skipped: Records skipped (no state determined).
        errors: Records that caused errors during ingestion.
    """

    total: int
    accepted: int
    classified: int
    skipped: int
    errors: int
