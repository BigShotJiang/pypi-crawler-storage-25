"""State classifier that evaluates per-state when rules against data records."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from pystator.checks import evaluate_when_check
from pystator.discovery.classification._models import (
    ClassificationResult,
    ClassificationRuleSet,
)

if TYPE_CHECKING:
    from pystator.machine import StateMachine

logger = logging.getLogger(__name__)


class StateClassifier:
    """Evaluates state ``when`` rules against data records to determine states.

    States are evaluated in their definition order within the rule set.
    The first state whose ``when`` checks all pass wins.

    Args:
        rule_set: The classification rule set containing states and settings.
    """

    def __init__(self, rule_set: ClassificationRuleSet) -> None:
        self._rule_set = rule_set

    @property
    def rule_set(self) -> ClassificationRuleSet:
        """The classification rule set."""
        return self._rule_set

    def classify(self, record: dict[str, Any]) -> ClassificationResult:
        """Classify a single data record into a state.

        Iterates classifiable states in order. For each state, all
        top-level ``when`` items are AND'd together. The first state
        where all checks pass wins.

        Args:
            record: Dict of field values from the data source.

        Returns:
            ClassificationResult with the matched state, or
            default_state if no rule matched.
        """
        for state in self._rule_set.states:
            if all(evaluate_when_check(wc, record) for wc in state.when):
                logger.debug("Record matched state '%s'", state.name)
                return ClassificationResult(
                    state=state.name,
                    matched=True,
                    record=record,
                )

        logger.debug(
            "No state matched; default_state=%s",
            self._rule_set.default_state,
        )
        return ClassificationResult(
            state=self._rule_set.default_state,
            matched=False,
            record=record,
        )

    @classmethod
    def from_machine(
        cls,
        machine: StateMachine,
        *,
        entity_id_field: str | None = None,
        timestamp_field: str | None = None,
        source: str | None = None,
        default_state: str | None = None,
    ) -> StateClassifier:
        """Create a classifier from a loaded StateMachine.

        Extracts states that have ``when`` clauses in their definition
        order. Classification settings are read from
        ``machine.meta["classification"]`` and can be overridden via
        keyword arguments.

        Args:
            machine: A loaded StateMachine instance.
            entity_id_field: Override for entity_id_field.
            timestamp_field: Override for timestamp_field.
            source: Override for source label.
            default_state: Override for default_state.

        Returns:
            A configured StateClassifier.

        Raises:
            ValueError: If no states have ``when`` clauses.
        """
        classifiable = [s for s in machine.states.values() if s.when]
        if not classifiable:
            raise ValueError(
                "No states with 'when' clauses found in machine "
                f"'{machine.meta.get('machine_name', '?')}'"
            )

        meta_cls = machine.meta.get("classification", {})

        rule_set = ClassificationRuleSet(
            states=tuple(classifiable),
            default_state=(
                default_state
                if default_state is not None
                else meta_cls.get("default_state")
            ),
            entity_id_field=(
                entity_id_field or meta_cls.get("entity_id_field", "entity_id")
            ),
            timestamp_field=(
                timestamp_field
                if timestamp_field is not None
                else meta_cls.get("timestamp_field")
            ),
            source=source or meta_cls.get("source", "classifier"),
        )
        return cls(rule_set)
