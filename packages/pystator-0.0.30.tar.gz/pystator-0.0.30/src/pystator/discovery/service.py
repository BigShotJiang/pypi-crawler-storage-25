"""Stateless inference engine for observed-state machine discovery."""

from __future__ import annotations

import re
import uuid
from collections import defaultdict
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from typing import Any, Literal

from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.protocols import (
    BuiltDiscoveryCandidateStore,
    DraftStore,
    InferenceStore,
    ObservationStore,
    ShadowResultStore,
)
from pystator.machine import StateMachine

_UNSET = object()


@dataclass(frozen=True, slots=True)
class InferenceThresholds:
    min_edge_count: int = 2
    min_confidence: float = 0.5


class InferenceEngine:
    """Primary discovery API: ingest, infer, and shadow-compare."""

    def __init__(
        self,
        observation_store: ObservationStore,
        inference_store: InferenceStore,
        built_candidate_store: BuiltDiscoveryCandidateStore,
        shadow_store: ShadowResultStore,
        thresholds: InferenceThresholds | None = None,
        *,
        draft_store: DraftStore | None = None,
    ) -> None:
        """Initialize the inference engine.

        Args:
            observation_store: Store for observed state events.
            inference_store: Store for inferred edges.
            built_candidate_store: Store for built (persisted) candidate FSM snapshots.
            shadow_store: Store for shadow comparison results.
            thresholds: Optional edge-count and confidence thresholds.
            draft_store: Draft scopes before build; defaults to *observation_store* if it
                implements draft persistence (same combined store).
        """
        self._observations = observation_store
        self._inference = inference_store
        self._built_candidates = built_candidate_store
        self._shadow = shadow_store
        self._thresholds = thresholds or InferenceThresholds()
        self._drafts: DraftStore = draft_store or observation_store  # type: ignore[assignment]

    def record_observation(self, machine_name: str, event: ObservedStateEvent) -> bool:
        """Record an observed state event for a machine.

        Args:
            machine_name: Expected machine name (must match event).
            event: The observed state event to record.

        Returns:
            True if the observation was successfully stored.

        Raises:
            ValueError: If the event's machine_name does not match.
        """
        if event.machine_name != machine_name:
            raise ValueError(
                f"Event machine_name '{event.machine_name}' does not match "
                f"expected '{machine_name}'"
            )
        return self._observations.add_observation(event)

    def _resolve_thresholds(
        self, min_edge_count: int | None, min_confidence: float | None
    ) -> InferenceThresholds:
        return InferenceThresholds(
            min_edge_count=max(
                1, int(min_edge_count or self._thresholds.min_edge_count)
            ),
            min_confidence=min(
                1.0,
                max(
                    0.0,
                    float(
                        min_confidence
                        if min_confidence is not None
                        else self._thresholds.min_confidence
                    ),
                ),
            ),
        )

    @staticmethod
    def _edges_to_dict(edges: list[InferredEdge]) -> list[dict[str, Any]]:
        return [
            {
                "source_state": e.source_state,
                "destination_state": e.destination_state,
                "count": e.count,
                "unique_entities": e.unique_entities,
                "unique_sources": e.unique_sources,
                "confidence": e.confidence,
                "last_seen_at": e.last_seen_at.isoformat() if e.last_seen_at else None,
            }
            for e in edges
        ]

    def preview_inference(
        self,
        machine_name: str,
        *,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
    ) -> dict[str, Any]:
        """Preview inferred edges without creating a candidate.

        Args:
            machine_name: Machine to infer edges for.
            mode: Inference mode (``"inference"`` or ``"manual"``).
            entity_ids: Optional filter to specific entities.
            min_edge_count: Override minimum edge count threshold.
            min_confidence: Override minimum confidence threshold.

        Returns:
            Dict with inferred edges, selected edges, and metadata.
        """
        normalized_ids = sorted(
            {x.strip() for x in (entity_ids or []) if x and x.strip()}
        )
        if normalized_ids:
            observations: list[ObservedStateEvent] = []
            for entity_id in normalized_ids:
                observations.extend(
                    self._observations.list_observations(
                        machine_name, entity_id=entity_id
                    )
                )
        else:
            observations = self._observations.list_observations(machine_name)
        edges = self._infer_edges(observations)
        thresholds = self._resolve_thresholds(min_edge_count, min_confidence)
        selected = [
            e
            for e in edges
            if e.count >= thresholds.min_edge_count
            and e.confidence >= thresholds.min_confidence
        ]
        entity_ids_used = sorted(
            {obs.entity_id for obs in observations if obs.entity_id}
        )
        return {
            "machine_name": machine_name,
            "mode": mode,
            "entity_ids_used": entity_ids_used,
            "observation_count": len(observations),
            "edges": edges,
            "selected_edges": selected,
            "thresholds": {
                "min_edge_count": thresholds.min_edge_count,
                "min_confidence": thresholds.min_confidence,
            },
        }

    def build_candidate(
        self,
        machine_name: str,
        version: str | None = None,
        *,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        edge_selection: list[tuple[str, str]] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        draft_id: str | None = None,
    ) -> BuiltDiscoveryCandidate:
        """Build and store a candidate machine from observations.

        Args:
            machine_name: Machine to build a candidate for.
            version: Explicit version string (auto-incremented if omitted).
            mode: ``"inference"`` uses threshold filtering; ``"manual"``
                requires explicit *edge_selection*.
            entity_ids: Optional filter to specific entities.
            edge_selection: Required for manual mode; list of
                ``(source, dest)`` pairs to include.
            min_edge_count: Override minimum edge count threshold.
            min_confidence: Override minimum confidence threshold.
            draft_id: Optional originating draft id (recorded in metadata).

        Returns:
            The persisted built discovery candidate.

        Raises:
            ValueError: If manual mode is used without *edge_selection*
                or selection contains unknown edge pairs.
        """
        preview = self.preview_inference(
            machine_name,
            mode=mode,
            entity_ids=entity_ids,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
        )
        edges: list[InferredEdge] = preview["edges"]
        thresholds = self._resolve_thresholds(min_edge_count, min_confidence)
        selected: list[InferredEdge]
        normalized_selection = sorted(set(edge_selection or []))
        if mode == "manual":
            if not normalized_selection:
                raise ValueError("manual mode requires non-empty edge_selection")
            allowed = set(normalized_selection)
            selected = [
                e for e in edges if (e.source_state, e.destination_state) in allowed
            ]
            if len(selected) != len(allowed):
                existing = {(e.source_state, e.destination_state) for e in edges}
                missing = sorted(allowed - existing)
                raise ValueError(
                    "edge_selection contains pairs not present in inferred edges: "
                    f"{missing}"
                )
        else:
            selected = [
                e
                for e in edges
                if e.count >= thresholds.min_edge_count
                and e.confidence >= thresholds.min_confidence
            ]
        config = self._build_machine_config(machine_name, selected)
        meta: dict[str, Any] = {
            "edge_count": len(edges),
            "selected_edge_count": len(selected),
            "build_mode": mode,
            "build_scope": {
                "entity_ids": preview["entity_ids_used"],
                "edge_selection": [
                    {"source_state": src, "destination_state": dst}
                    for (src, dst) in normalized_selection
                ],
            },
            "observation_count": preview["observation_count"],
            "thresholds": {
                "min_edge_count": thresholds.min_edge_count,
                "min_confidence": thresholds.min_confidence,
            },
            "inferred_edges_snapshot": self._edges_to_dict(edges),
            "selected_edges_snapshot": self._edges_to_dict(selected),
        }
        if draft_id:
            meta["draft_id"] = draft_id
        candidate = BuiltDiscoveryCandidate(
            machine_name=machine_name,
            version=version or self._next_version(machine_name),
            status="candidate",
            config=config,
            metadata=meta,
        )
        return self._built_candidates.save_built_candidate(candidate)

    def create_draft(
        self, machine_name: str, title: str | None = None
    ) -> DiscoveryDraft:
        now = datetime.now(UTC)
        thr = self._thresholds
        d = DiscoveryDraft(
            id=str(uuid.uuid4()),
            machine_name=machine_name,
            title=title,
            selected_entity_ids=(),
            mode="inference",
            min_edge_count=thr.min_edge_count,
            min_confidence=thr.min_confidence,
            manual_edge_selection=(),
            created_at=now,
            updated_at=now,
            last_built_version=None,
        )
        return self._drafts.save_draft(d)

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        return self._drafts.get_draft(draft_id)

    def list_drafts(self, machine_name: str) -> list[DiscoveryDraft]:
        return self._drafts.list_drafts(machine_name)

    def delete_draft(self, draft_id: str) -> bool:
        return self._drafts.delete_draft(draft_id)

    def update_draft(
        self,
        draft_id: str,
        *,
        title: Any = _UNSET,
        selected_entity_ids: list[str] | None | Any = _UNSET,
        mode: str | Any = _UNSET,
        min_edge_count: int | Any = _UNSET,
        min_confidence: float | Any = _UNSET,
        manual_edge_selection: list[tuple[str, str]] | None | Any = _UNSET,
    ) -> DiscoveryDraft:
        d = self._drafts.get_draft(draft_id)
        if d is None:
            raise ValueError(f"draft not found: {draft_id}")
        updates: dict[str, Any] = {"updated_at": datetime.now(UTC)}
        if title is not _UNSET:
            updates["title"] = title
        if selected_entity_ids is not _UNSET:
            updates["selected_entity_ids"] = tuple(selected_entity_ids or ())
        if mode is not _UNSET:
            if mode not in ("inference", "manual"):
                raise ValueError("mode must be inference or manual")
            updates["mode"] = mode
        if min_edge_count is not _UNSET:
            updates["min_edge_count"] = max(1, int(min_edge_count or 1))
        if min_confidence is not _UNSET:
            mc = float(min_confidence if min_confidence is not None else 0.5)
            updates["min_confidence"] = min(1.0, max(0.0, mc))
        if manual_edge_selection is not _UNSET:
            updates["manual_edge_selection"] = tuple(
                (str(a), str(b)) for a, b in (manual_edge_selection or [])
            )
        new_d = replace(d, **updates)
        return self._drafts.save_draft(new_d)

    def preview_draft(self, draft_id: str) -> dict[str, Any]:
        d = self._drafts.get_draft(draft_id)
        if d is None:
            raise ValueError(f"draft not found: {draft_id}")
        if not d.selected_entity_ids:
            raise ValueError(
                "draft has no selected entity IDs; add at least one before preview"
            )
        return self.preview_inference(
            d.machine_name,
            mode=d.mode,
            entity_ids=list(d.selected_entity_ids),
            min_edge_count=d.min_edge_count,
            min_confidence=d.min_confidence,
        )

    def build_from_draft(self, draft_id: str) -> BuiltDiscoveryCandidate:
        d = self._drafts.get_draft(draft_id)
        if d is None:
            raise ValueError(f"draft not found: {draft_id}")
        if not d.selected_entity_ids:
            raise ValueError(
                "draft has no selected entity IDs; add at least one before build"
            )
        edge_sel: list[tuple[str, str]] | None = None
        if d.mode == "manual":
            edge_sel = list(d.manual_edge_selection)
            if not edge_sel:
                raise ValueError(
                    "manual mode requires manual_edge_selection on the draft"
                )
        cand = self.build_candidate(
            d.machine_name,
            mode=d.mode,
            entity_ids=list(d.selected_entity_ids),
            edge_selection=edge_sel,
            min_edge_count=d.min_edge_count,
            min_confidence=d.min_confidence,
            draft_id=d.id,
        )
        updated = replace(
            d,
            last_built_version=cand.version,
            updated_at=datetime.now(UTC),
        )
        self._drafts.save_draft(updated)
        return cand

    def run_shadow_compare(
        self,
        *,
        machine_name: str,
        active_config: dict[str, Any],
        source_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
        candidate_version: str | None = None,
    ) -> ShadowDiff | None:
        candidate = (
            self._built_candidates.get_built_candidate(machine_name, candidate_version)
            if candidate_version
            else self._built_candidates.get_latest_built_candidate(machine_name)
        )
        if candidate is None:
            return None
        active_result = StateMachine.from_dict(active_config).process(
            source_state, trigger, context or {}
        )
        candidate_result = StateMachine.from_dict(candidate.config).process(
            source_state, trigger, context or {}
        )
        differs = (active_result.success != candidate_result.success) or (
            active_result.target_state != candidate_result.target_state
        )
        reason: str | None = None
        if differs:
            if active_result.success != candidate_result.success:
                reason = "success_mismatch"
            else:
                reason = "target_state_mismatch"
        diff = ShadowDiff(
            machine_name=machine_name,
            source_state=source_state,
            trigger=trigger,
            active_success=active_result.success,
            active_target_state=active_result.target_state,
            candidate_success=candidate_result.success,
            candidate_target_state=candidate_result.target_state,
            differs=differs,
            reason=reason,
            metadata={"candidate_version": candidate.version},
        )
        self._shadow.record_shadow_diff(diff)
        return diff

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        return self._built_candidates.get_latest_built_candidate(machine_name)

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        """Return all saved built candidates for *machine_name*, store-defined order."""
        return self._built_candidates.list_built_candidates(machine_name)

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        """Return a specific built candidate version, if present."""
        return self._built_candidates.get_built_candidate(machine_name, version)

    def list_edges(self, machine_name: str) -> list[InferredEdge]:
        return self._inference.list_edges(machine_name)

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        return self._built_candidates.save_built_candidate(candidate)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        return self._shadow.list_shadow_diffs(machine_name, limit=limit)

    @staticmethod
    def _infer_edges(observations: list[ObservedStateEvent]) -> list[InferredEdge]:
        by_entity: dict[str, list[ObservedStateEvent]] = defaultdict(list)
        for ev in observations:
            by_entity[ev.entity_id].append(ev)

        edge_counts: dict[tuple[str, str], int] = defaultdict(int)
        edge_entities: dict[tuple[str, str], set[str]] = defaultdict(set)
        edge_sources: dict[tuple[str, str], set[str]] = defaultdict(set)
        edge_last_seen: dict[tuple[str, str], datetime] = {}

        for entity_events in by_entity.values():
            ordered = sorted(
                entity_events,
                key=lambda x: (x.observed_at, x.ingest_seq, x.ingested_at),
            )
            for idx in range(len(ordered) - 1):
                src = ordered[idx]
                dst = ordered[idx + 1]
                key = (src.state, dst.state)
                edge_counts[key] += 1
                edge_entities[key].add(src.entity_id)
                edge_sources[key].add(src.source)
                edge_last_seen[key] = max(
                    edge_last_seen.get(key, src.observed_at), dst.observed_at
                )

        outgoing_totals: dict[str, int] = defaultdict(int)
        for (src, _), count in edge_counts.items():
            outgoing_totals[src] += count

        edges: list[InferredEdge] = []
        for (src, dst), count in edge_counts.items():
            total = outgoing_totals[src]
            confidence = (count / total) if total > 0 else 0.0
            edges.append(
                InferredEdge(
                    source_state=src,
                    destination_state=dst,
                    count=count,
                    unique_entities=len(edge_entities[(src, dst)]),
                    unique_sources=len(edge_sources[(src, dst)]),
                    confidence=confidence,
                    last_seen_at=edge_last_seen.get((src, dst)),
                )
            )
        edges.sort(key=lambda e: (e.source_state, e.destination_state))
        return edges

    @staticmethod
    def _build_machine_config(
        machine_name: str, edges: list[InferredEdge]
    ) -> dict[str, Any]:
        def normalize(name: str) -> str:
            return re.sub(r"[^a-z0-9_]+", "_", name.strip().lower()).strip("_")

        states = set()
        transitions: list[dict[str, Any]] = []
        for edge in edges:
            src = normalize(edge.source_state)
            dst = normalize(edge.destination_state)
            if not src or not dst:
                continue
            states.add(src)
            states.add(dst)
            trigger = f"to_{dst}"
            transitions.append(
                {
                    "trigger": trigger,
                    "source": src,
                    "dest": dst,
                    "meta": {
                        "inferred": True,
                        "count": edge.count,
                        "confidence": edge.confidence,
                    },
                }
            )
        sorted_states = sorted(states)
        initial_state = sorted_states[0] if sorted_states else "unknown"
        state_defs = [
            {
                "name": name,
                "type": "initial" if name == initial_state else "stable",
            }
            for name in sorted_states
        ]
        return {
            "meta": {
                "machine_name": machine_name,
                "version": "0.1.0",
                "source": "pystator.discovery",
            },
            "states": state_defs,
            "transitions": transitions,
        }

    def _next_version(self, machine_name: str) -> str:
        latest = self._built_candidates.get_latest_built_candidate(machine_name)
        if latest is None:
            return "0.1.0"
        parts = latest.version.split(".")
        if len(parts) != 3 or not all(part.isdigit() for part in parts):
            return "0.1.0"
        major, minor, patch = (int(p) for p in parts)
        return f"{major}.{minor}.{patch + 1}"
