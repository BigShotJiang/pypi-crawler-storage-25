"""HTTP action executor for config-defined HTTP requests.

Allows FSM transitions to fire HTTP requests defined entirely in YAML
config, with context-driven ``{{ expr }}`` template substitution.

Example YAML::

    actions:
      - http:
          url: "https://api.example.com/orders/{{ order_id }}"
          method: POST
          headers:
            Authorization: "Bearer {{ api_token }}"
          body:
            order_id: "{{ order_id }}"
            status: "{{ dest }}"
          timeout: 10
          retry: 2
          on_error: "log"
"""

from __future__ import annotations

import json
import logging
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from pystator._expr import render_template_value
from pystator.actions import ActionResult

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class HttpActionConfig:
    """Parsed HTTP action configuration.

    Attributes:
        url: Target URL (supports ``{{ }}`` templates).
        method: HTTP method (default POST).
        headers: Custom headers (values support templates).
        body: Request body (dict or string, values support templates).
        timeout: Request timeout in seconds.
        on_success: Optional dict with ``status_key`` and ``body_key``
            for storing response data in context.
        on_error: Error handling mode: ``"fail"``, ``"log"``, or ``"ignore"``.
    """

    url: str
    method: str = "POST"
    headers: dict[str, str] = field(default_factory=dict)
    body: dict[str, Any] | str | None = None
    timeout: float = 10.0
    on_success: dict[str, str] | None = None
    on_error: str = "log"

    @classmethod
    def from_params(cls, params: dict[str, Any]) -> HttpActionConfig:
        """Create from ActionSpec.params dict."""
        return cls(
            url=params["url"],
            method=params.get("method", "POST"),
            headers=params.get("headers", {}),
            body=params.get("body"),
            timeout=params.get("timeout", 10.0),
            on_success=params.get("on_success"),
            on_error=params.get("on_error", "log"),
        )


def execute_http_action(
    params: dict[str, Any],
    context: dict[str, Any],
) -> ActionResult:
    """Execute an HTTP action synchronously.

    Renders templates in the URL, headers, and body using context values,
    then fires the HTTP request.

    Args:
        params: Raw params dict from ActionSpec (contains url, method, etc.).
        context: FSM context dict for template rendering.

    Returns:
        ActionResult with success/failure status.
    """
    config = HttpActionConfig.from_params(params)

    # Render templates
    url = str(render_template_value(config.url, context))
    headers = {
        k: str(v)
        for k, v in (render_template_value(config.headers, context) or {}).items()
    }
    headers.setdefault("Content-Type", "application/json")

    body_data: bytes | None = None
    if config.body is not None:
        rendered_body = render_template_value(config.body, context)
        if isinstance(rendered_body, dict | list):
            body_data = json.dumps(rendered_body).encode("utf-8")
        else:
            body_data = str(rendered_body).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=body_data,
        headers=headers,
        method=config.method.upper(),
    )

    try:
        with urllib.request.urlopen(req, timeout=config.timeout) as resp:
            status_code = resp.status
            resp_body: str | None = None
            try:
                resp_body = resp.read().decode("utf-8")
            except Exception:
                pass

            # Store response in context if configured
            if config.on_success:
                if "status_key" in config.on_success:
                    context[config.on_success["status_key"]] = status_code
                if "body_key" in config.on_success and resp_body:
                    try:
                        context[config.on_success["body_key"]] = json.loads(resp_body)
                    except json.JSONDecodeError:
                        context[config.on_success["body_key"]] = resp_body

            logger.debug("HTTP %s %s → %s", config.method, url, status_code)
            return ActionResult.ok(
                "_http",
                {"status_code": status_code, "url": url},
            )

    except Exception as exc:
        logger.warning("HTTP action failed: %s %s → %s", config.method, url, exc)
        if config.on_error == "fail":
            return ActionResult.fail("_http", exc)
        if config.on_error == "ignore":
            return ActionResult.ok("_http", {"error": str(exc), "url": url})
        # Default "log": log warning and return ok
        return ActionResult.ok(
            "_http",
            {"error": str(exc), "url": url, "logged": True},
        )


async def async_execute_http_action(
    params: dict[str, Any],
    context: dict[str, Any],
) -> ActionResult:
    """Execute an HTTP action asynchronously.

    Delegates to the sync implementation via ``asyncio.to_thread``.
    """
    import asyncio

    return await asyncio.to_thread(execute_http_action, params, context)
