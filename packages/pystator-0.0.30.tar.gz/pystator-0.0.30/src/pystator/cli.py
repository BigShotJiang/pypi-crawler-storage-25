"""CLI entry-point for PyStator: ``pystator api | ui | db | worker``."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="PyStator — FSM library",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command", required=True)

    # --- api ---------------------------------------------------------------
    api_p = sub.add_parser("api", help="Start the API server")
    api_p.add_argument("--host", default="0.0.0.0")
    api_p.add_argument("--port", type=int, default=8004)
    api_p.add_argument("--reload", action="store_true", default=True)
    api_p.add_argument("--no-reload", dest="reload", action="store_false")

    # --- ui ----------------------------------------------------------------
    ui_p = sub.add_parser("ui", help="UI commands")
    ui_sub = ui_p.add_subparsers(dest="ui_command", required=True)

    serve_p = ui_sub.add_parser("serve", help="Serve built UI")
    serve_p.add_argument("--api-url", default=None)
    serve_p.add_argument("--host", default="127.0.0.1")
    serve_p.add_argument("--port", type=int, default=3004)

    dev_p = ui_sub.add_parser("dev", help="Run UI dev server")
    dev_p.add_argument("--api-url", default=None)
    dev_p.add_argument("--port", type=int, default=3004)

    ui_sub.add_parser("build", help="Build UI for production")

    # --- db ----------------------------------------------------------------
    sub.add_parser(
        "db",
        help="Database management commands",
        description="Manage PyStator database: init, upgrade, downgrade, seed, truncate",
    )

    # --- machines ----------------------------------------------------------
    sub.add_parser(
        "machines",
        help="Machine management commands",
        description="Manage FSM machines: list, get, create, delete, seed",
    )

    # --- schema ------------------------------------------------------------
    schema_p = sub.add_parser(
        "schema",
        help="Print the JSON Schema for FSM configuration",
        description="Generate the JSON Schema for PyStator FSM config files.",
    )
    schema_p.add_argument(
        "--output", "-o", default=None, help="Write schema to file instead of stdout"
    )

    # --- worker ------------------------------------------------------------
    worker_p = sub.add_parser(
        "worker",
        help="Run the worker (event processor)",
        description=(
            "Start the PyStator worker service.  Polls the worker_events "
            "table, claims events, and processes them through the "
            "appropriate FSM Orchestrator."
        ),
    )
    worker_p.add_argument(
        "--app",
        default=None,
        help=(
            "Python import path to a factory function that returns a "
            "configured Worker instance, e.g. 'myapp.worker:create_worker'."
        ),
    )
    worker_p.add_argument(
        "--concurrency",
        type=int,
        default=None,
        help="Number of concurrent event-processor tasks (default: 5).",
    )
    worker_p.add_argument(
        "--poll-interval",
        type=int,
        default=None,
        help="Milliseconds between event-source polls (default: 500).",
    )

    # --- docs (MkDocs) ------------------------------------------------------
    from pystator.docs.cli import DEFAULT_DOCS_PORT

    docs_p = sub.add_parser(
        "docs",
        help="Documentation (MkDocs): serve or build",
    )
    docs_sub = docs_p.add_subparsers(dest="docs_command", help="Docs command")
    docs_serve_p = docs_sub.add_parser(
        "serve",
        help=f"Serve docs locally (default: http://127.0.0.1:{DEFAULT_DOCS_PORT})",
    )
    docs_serve_p.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    docs_serve_p.add_argument(
        "--port",
        type=int,
        default=DEFAULT_DOCS_PORT,
        help=f"Port to bind to (default: {DEFAULT_DOCS_PORT})",
    )
    docs_sub.add_parser("build", help="Build static site (output: site/)")

    args, remaining = parser.parse_known_args()

    # -- dispatch -----------------------------------------------------------

    if args.command == "docs":
        from pystator.docs.cli import cmd_docs_build, cmd_docs_serve

        if not getattr(args, "docs_command", None):
            docs_p.print_help()
            return 0
        if args.docs_command == "serve":
            return cmd_docs_serve(host=args.host, port=args.port)
        if args.docs_command == "build":
            return cmd_docs_build()
        docs_p.print_help()
        return 0

    if args.command == "api":
        return _run_api(args)

    if args.command == "db":
        return _run_db(remaining)

    if args.command == "machines":
        return _run_machines(remaining)

    if args.command == "schema":
        return _run_schema(args)

    if args.command == "ui":
        return _run_ui(args)

    if args.command == "worker":
        return _run_worker(args)

    return 0


# ---------------------------------------------------------------------------
# Sub-command handlers
# ---------------------------------------------------------------------------


def _run_schema(args: argparse.Namespace) -> int:
    try:
        from pystator.config.models import MachineConfig
    except ImportError:
        print(
            "Pydantic is required for JSON Schema generation. "
            "Install with: pip install pystator[api]",
            file=sys.stderr,
        )
        return 1

    import json

    schema = MachineConfig.model_json_schema()
    schema_json = json.dumps(schema, indent=2)

    if args.output:
        Path(args.output).write_text(schema_json, encoding="utf-8")
        print(f"Schema written to {args.output}")
    else:
        print(schema_json)
    return 0


def _run_api(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError:
        print(
            "uvicorn is required. Install with: pip install pystator[api]",
            file=sys.stderr,
        )
        return 1
    uvicorn.run(
        "pystator.api.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )
    return 0


def _run_db(remaining: list[str]) -> int:
    try:
        from pystator.db.cli import main as db_main
    except ImportError as e:
        print(f"Database CLI not available: {e}", file=sys.stderr)
        return 1
    sys.argv = ["pystator db", *remaining]
    return db_main()


def _run_machines(remaining: list[str]) -> int:
    try:
        from pystator.machine_store.cli import main as machines_main
    except ImportError as e:
        print(f"Machines CLI not available: {e}", file=sys.stderr)
        return 1
    sys.argv = ["pystator machines", *remaining]
    return machines_main()


def _run_ui(args: argparse.Namespace) -> int:
    ui_path = Path(__file__).parent / "ui"
    if not ui_path.exists():
        print("UI module not found.", file=sys.stderr)
        return 1

    if args.ui_command == "build":
        from pystator.ui.build import build_ui

        return build_ui()

    api_url = getattr(args, "api_url", None)

    if args.ui_command == "serve":
        from pystator.ui.server import serve_ui

        serve_ui(api_url=api_url, host=args.host, port=args.port)
        return 0

    if args.ui_command == "dev":
        from pystator.ui.dev import run_dev

        run_dev(api_url=api_url, port=args.port)
        return 0

    return 1


def _run_worker(args: argparse.Namespace) -> int:
    import asyncio

    from pystator.worker import Worker
    from pystator.worker.config import WorkerConfig

    # Build config from CLI overrides
    kwargs: dict[str, object] = {}
    if args.concurrency is not None:
        kwargs["concurrency"] = args.concurrency
    if args.poll_interval is not None:
        kwargs["poll_interval_ms"] = args.poll_interval

    if args.app:
        # Import user factory: "myapp.worker:create_worker"
        try:
            module_path, attr_name = args.app.rsplit(":", 1)
            import importlib

            mod = importlib.import_module(module_path)
            factory = getattr(mod, attr_name)
            worker = factory()
            if not isinstance(worker, Worker):
                print(
                    f"Factory {args.app!r} must return a Worker instance, "
                    f"got {type(worker).__name__}",
                    file=sys.stderr,
                )
                return 1
        except Exception as e:
            print(f"Failed to load --app {args.app!r}: {e}", file=sys.stderr)
            return 1

        # Apply CLI overrides to the worker's config
        if kwargs:
            for key, value in kwargs.items():
                setattr(worker.config, key, value)
    else:
        config = WorkerConfig(**kwargs)  # type: ignore[arg-type]
        worker = Worker(config=config)

    async def _run() -> None:
        await worker.start()
        await worker.run()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        pass

    return 0


if __name__ == "__main__":
    sys.exit(main())
