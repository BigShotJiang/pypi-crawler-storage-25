"""Auth for PyStator API. Env or pystator.cfg [auth]; keys = env names (e.g. PYSTATOR_AUTH_JWT_SECRET)."""

from __future__ import annotations

import json
import logging
import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file

logger = logging.getLogger(__name__)


def _cfg(section: str, key: str) -> str | None:
    cfg_path = find_config_file("pystator.cfg")
    if not cfg_path:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(cfg_path)
        if cfg.has_section(section):
            return cfg.get(section, key, fallback=None)
    except Exception:
        pass
    return None


def get_auth_users() -> list[dict[str, str]]:
    """Parse PYSTATOR_AUTH_USERS JSON array.

    Returns:
        List of ``{"username", "password", "role"}`` dicts.
        Empty when not configured.
    """
    raw = os.getenv("PYSTATOR_AUTH_USERS") or _cfg("auth", "PYSTATOR_AUTH_USERS")
    if not raw or not raw.strip():
        return []
    try:
        users = json.loads(raw)
        if isinstance(users, list):
            return [
                {
                    "username": u["username"],
                    "password": u["password"],
                    "role": u.get("role", "User"),
                }
                for u in users
                if isinstance(u, dict) and "username" in u and "password" in u
            ]
    except (json.JSONDecodeError, KeyError):
        logger.warning("Invalid PYSTATOR_AUTH_USERS JSON")
    return []


def get_auth_jwt_secret() -> str | None:
    return os.getenv("PYSTATOR_AUTH_JWT_SECRET") or _cfg(
        "auth", "PYSTATOR_AUTH_JWT_SECRET"
    )


def get_auth_service_url() -> str | None:
    url = os.getenv("PYSTATOR_AUTH_SERVICE_URL") or _cfg(
        "auth", "PYSTATOR_AUTH_SERVICE_URL"
    )
    return url.rstrip("/") if url else None


def get_auth_service_introspect_path() -> str | None:
    return os.getenv("PYSTATOR_AUTH_SERVICE_INTROSPECT_PATH") or _cfg(
        "auth", "PYSTATOR_AUTH_SERVICE_INTROSPECT_PATH"
    )


def get_auth_admin_role_claims() -> set[str]:
    """Comma-separated external token role names that grant Admin."""
    raw = os.getenv("PYSTATOR_AUTH_ADMIN_ROLE_CLAIMS") or _cfg(
        "auth", "PYSTATOR_AUTH_ADMIN_ROLE_CLAIMS"
    )
    if raw and raw.strip():
        return {c.strip().lower() for c in raw.split(",") if c.strip()}
    return {"admin"}


def get_auth_admin_group_claims() -> set[str]:
    """Comma-separated external token group names that grant Admin."""
    raw = os.getenv("PYSTATOR_AUTH_ADMIN_GROUP_CLAIMS") or _cfg(
        "auth", "PYSTATOR_AUTH_ADMIN_GROUP_CLAIMS"
    )
    if raw and raw.strip():
        return {c.strip().lower() for c in raw.split(",") if c.strip()}
    return set()


def is_auth_disabled() -> bool:
    raw = (
        os.getenv("PYSTATOR_AUTH_DISABLED")
        or _cfg("auth", "PYSTATOR_AUTH_DISABLED")
        or ""
    )
    if raw.strip().lower() in ("1", "true", "yes"):
        return True
    if get_auth_service_url():
        return False
    if get_auth_users() and get_auth_jwt_secret():
        return False
    return True
