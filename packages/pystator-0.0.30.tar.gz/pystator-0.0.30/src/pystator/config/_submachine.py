"""SubMachine composition -- embed reusable machine definitions inside states.

Resolves at config-load time: submachine states become ``{parent}.{state}``
with ``parent`` set, and the parent gets ``initial_child`` from the
submachine's initial state.
"""

from __future__ import annotations

import copy
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Maximum nesting depth to prevent circular references
_MAX_DEPTH = 10


def resolve_submachines(
    config: dict[str, Any],
    base_path: Path | None = None,
    *,
    _depth: int = 0,
) -> dict[str, Any]:
    """Resolve all submachine references in a config dict.

    Modifies the config in-place and returns it. States with a ``submachine``
    field are expanded: their child states and transitions are inlined into
    the top-level config.

    Args:
        config: The raw config dict (must have ``states`` and ``transitions``).
        base_path: Base directory for resolving relative file references.
        _depth: Internal recursion depth counter.

    Returns:
        The modified config dict with submachines resolved.

    Raises:
        ValueError: If circular references or invalid submachine configs are found.
    """
    if _depth > _MAX_DEPTH:
        raise ValueError(
            f"SubMachine nesting depth exceeds {_MAX_DEPTH}; "
            "possible circular reference"
        )

    states = config.get("states", [])
    transitions = config.get("transitions", [])

    new_states: list[dict[str, Any]] = []
    new_transitions: list[dict[str, Any]] = []

    for state in states:
        submachine_ref = state.get("submachine")
        if submachine_ref is None:
            new_states.append(state)
            continue

        parent_name = state["name"]
        sub_config = _load_submachine(submachine_ref, base_path)

        # Recursively resolve nested submachines
        sub_config = resolve_submachines(sub_config, base_path, _depth=_depth + 1)

        child_states, child_transitions = _flatten_submachine(parent_name, sub_config)

        # Set initial_child on the parent from the submachine's initial state
        initial_name = _find_initial(sub_config)
        parent_copy = {k: v for k, v in state.items() if k != "submachine"}
        if initial_name is not None:
            parent_copy["initial_child"] = f"{parent_name}.{initial_name}"

        new_states.append(parent_copy)
        new_states.extend(child_states)
        new_transitions.extend(child_transitions)

    new_transitions.extend(transitions)

    config["states"] = new_states
    config["transitions"] = new_transitions
    return config


def _load_submachine(
    ref: str | dict[str, Any],
    base_path: Path | None,
) -> dict[str, Any]:
    """Load a submachine config from a file path or inline dict.

    Args:
        ref: File path string (relative to base_path) or inline config dict.
        base_path: Base directory for resolving file references.

    Returns:
        Parsed config dict with ``states`` and ``transitions``.
    """
    if isinstance(ref, dict):
        return copy.deepcopy(ref)

    if not isinstance(ref, str):
        raise ValueError(
            f"submachine must be a string (file path) or dict, got {type(ref).__name__}"
        )

    path = Path(ref)
    if base_path is not None and not path.is_absolute():
        path = base_path / path

    if not path.exists():
        raise ValueError(f"SubMachine file not found: {path}")

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as e:
        raise ValueError(f"Failed to read submachine file: {e}") from e

    suffix = path.suffix.lower()
    if suffix in (".yaml", ".yml"):
        try:
            import yaml

            result = yaml.safe_load(content)
        except ImportError as e:
            raise ValueError("PyYAML is required for YAML submachine files") from e
    elif suffix == ".json":
        import json

        result = json.loads(content)
    else:
        try:
            import yaml

            result = yaml.safe_load(content)
        except Exception:
            import json

            result = json.loads(content)

    if not isinstance(result, dict):
        raise ValueError(f"SubMachine file must contain a mapping: {path}")

    return result


def _find_initial(sub_config: dict[str, Any]) -> str | None:
    """Find the initial state name in a submachine config."""
    for state in sub_config.get("states", []):
        if state.get("type") == "initial":
            return state["name"]
    return None


def _flatten_submachine(
    parent_name: str,
    sub_config: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Flatten submachine states and transitions under a parent.

    State names become ``{parent_name}.{state_name}`` and ``parent`` is set
    to ``parent_name``.

    Returns:
        Tuple of (flattened_states, flattened_transitions).
    """
    prefix = f"{parent_name}."
    states: list[dict[str, Any]] = []
    transitions: list[dict[str, Any]] = []

    for state in sub_config.get("states", []):
        flat = dict(state)
        flat["name"] = f"{prefix}{state['name']}"
        flat["parent"] = state.get("parent", parent_name)
        if flat["parent"] != parent_name:
            flat["parent"] = f"{prefix}{flat['parent']}"
        if "initial_child" in flat and flat["initial_child"]:
            flat["initial_child"] = f"{prefix}{flat['initial_child']}"
        states.append(flat)

    for trans in sub_config.get("transitions", []):
        flat = dict(trans)
        # Prefix source(s)
        source = trans.get("source")
        if isinstance(source, str):
            flat["source"] = f"{prefix}{source}"
        elif isinstance(source, list):
            flat["source"] = [f"{prefix}{s}" for s in source]
        # Prefix dest
        flat["dest"] = f"{prefix}{trans['dest']}"
        transitions.append(flat)

    return states, transitions
