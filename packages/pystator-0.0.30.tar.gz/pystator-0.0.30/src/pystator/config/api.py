"""API base URL for UI proxy / dev (env overrides pystator.cfg [api])."""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file

_ENV_KEY = "PYSTATOR_API_URL"
_DEFAULT = "http://localhost:8004"


def get_api_url() -> str:
    """Return backend API URL. Order: env, ``[api] PYSTATOR_API_URL``, default."""
    raw = os.getenv(_ENV_KEY)
    if raw and raw.strip():
        return raw.strip().rstrip("/")
    cfg_path = find_config_file("pystator.cfg")
    if cfg_path:
        try:
            cfg = ConfigParser()
            cfg.read(cfg_path)
            if cfg.has_section("api"):
                from_cfg = cfg.get("api", _ENV_KEY, fallback=None)
                if from_cfg and from_cfg.strip():
                    return from_cfg.strip().rstrip("/")
        except Exception:
            pass
    return _DEFAULT.rstrip("/")
