"""Convert Pydantic config models to internal _types dataclasses."""

from __future__ import annotations

from typing import Any

from pystator._types import (
    ActionSpec,
    GuardSpec,
    InvokeSpec,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    WhenCheck,
    parse_delay,
)
from pystator.config._shared import (
    auto_trigger,
    expand_wildcard_sources,
    implicit_trigger_for_after,
    resolve_entry_exit_points,
)
from pystator.config.models import MachineConfig, StateDef, TransitionDef


def _state_def_metadata(s: StateDef) -> dict[str, Any]:
    meta = dict(s.metadata)
    if s.model_extra:
        meta.update(s.model_extra)
    return meta


def _transition_def_metadata(t: TransitionDef) -> dict[str, Any]:
    meta = dict(t.metadata)
    if t.model_extra:
        meta.update(t.model_extra)
    return meta


def state_def_to_state(s: StateDef) -> State:
    """Convert StateDef to State."""
    timeout = None
    if s.timeout is not None:
        timeout = Timeout(seconds=s.timeout.seconds, destination=s.timeout.destination)

    regions = tuple(
        Region(
            name=r.name,
            initial=r.initial,
            states=tuple(r.states),
            description=r.description or "",
            final=r.final,
        )
        for r in s.regions
    )

    on_enter = tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in (s.on_enter if isinstance(s.on_enter, list) else [s.on_enter])
    )
    on_exit = tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in (s.on_exit if isinstance(s.on_exit, list) else [s.on_exit])
    )

    invoke = tuple(
        InvokeSpec(id=inv.id, src=inv.src, on_done=inv.on_done) for inv in s.invoke
    )

    when = tuple(WhenCheck.from_config(c) for c in s.when)

    return State(
        name=s.name,
        type=StateType(s.type),
        description=s.description or "",
        parent=s.parent,
        initial_child=s.initial_child,
        regions=regions,
        on_enter=on_enter,
        on_exit=on_exit,
        invoke=invoke,
        timeout=timeout,
        group=s.group,
        entry_points=tuple(s.entry_points),
        exit_points=tuple(s.exit_points),
        metadata=_state_def_metadata(s),
        when=when,
    )


def transition_def_to_transition(t: TransitionDef) -> Transition:
    """Convert TransitionDef to Transition.

    Resolves implicit triggers for ``after`` and ``auto`` transitions.
    """
    source = t.source if isinstance(t.source, list) else [t.source]
    source_set = frozenset(source)

    after_ms: int | None = None
    if t.after is not None:
        after_ms = parse_delay(t.after)

    trigger = (t.trigger or "").strip()

    # Generate synthetic trigger when not provided
    if not trigger:
        if after_ms is not None:
            if len(source_set) != 1:
                raise ValueError(
                    "Delayed transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = implicit_trigger_for_after(single_source, after_ms)
        elif t.auto:
            if len(source_set) != 1:
                raise ValueError(
                    "Auto transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = auto_trigger(single_source)
        else:
            raise ValueError(
                "Transition must have either 'trigger', 'after', or 'auto'"
            )

    guards = tuple(
        GuardSpec.from_config(item) if isinstance(item, dict) else GuardSpec(name=item)
        for item in t.guards
    )
    actions = tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in t.actions
    )

    region = t.region if isinstance(t.region, str) else None

    # Merge ref (single) and refs (list) into one tuple
    refs_list: list[str] = list(t.refs) if t.refs else []
    if t.ref:
        refs_list.insert(0, t.ref)
    refs = tuple(refs_list)

    return Transition(
        trigger=trigger,
        source=source_set,
        dest=t.dest,
        region=region,
        guards=guards,
        actions=actions,
        after=after_ms,
        internal=t.internal,
        auto=t.auto,
        priority=getattr(t, "priority", None),
        description=t.description or "",
        refs=refs,
        metadata=_transition_def_metadata(t),
    )


def machine_config_to_core(
    config: MachineConfig,
) -> tuple[dict[str, State], list[Transition], dict[str, Any]]:
    """Convert validated MachineConfig to (states dict, transitions list, meta dict)."""
    states = {s.name: state_def_to_state(s) for s in config.states}
    transitions = [transition_def_to_transition(t) for t in config.transitions]

    # Expand wildcard sources
    transitions = expand_wildcard_sources(states, transitions)

    # Resolve entry/exit point references
    transitions = resolve_entry_exit_points(states, transitions)

    meta: dict[str, Any] = {}
    if isinstance(config.meta, dict):
        meta = dict(config.meta)
    else:
        m = config.meta
        if m.version is not None:
            meta["version"] = m.version
        if m.machine_name is not None:
            meta["machine_name"] = m.machine_name
        meta["strict_mode"] = m.strict_mode
        if m.event_normalizer is not None:
            meta["event_normalizer"] = m.event_normalizer
        if m.description is not None:
            meta["description"] = m.description
        meta["validate_context"] = m.validate_context
        if getattr(m, "model_extra", None):
            meta.update(m.model_extra)

    if config.groups is not None:
        meta["groups"] = config.groups

    if config.state_variables is not None:
        meta["state_variables"] = [
            sv.model_dump() if hasattr(sv, "model_dump") else dict(sv)
            for sv in config.state_variables
        ]
    if config.events is not None:
        meta["events"] = config.events

    return states, transitions, meta
