"""Database URL for PyStator. Env PYSTATOR_DATABASE_URL or pystator.cfg [database] PYSTATOR_DATABASE_URL; fallback alembic.ini."""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file

_ENV_KEY = "PYSTATOR_DATABASE_URL"


def get_database_url() -> str | None:
    db_url = os.getenv(_ENV_KEY)
    if db_url:
        return db_url
    cfg_path = find_config_file("pystator.cfg")
    if cfg_path:
        cfg = ConfigParser()
        cfg.read(cfg_path)
        if cfg.has_section("database"):
            db_url = cfg.get("database", _ENV_KEY, fallback=None)
            if db_url:
                return db_url
    alembic_ini = find_config_file("alembic.ini")
    if alembic_ini:
        cfg = ConfigParser()
        cfg.read(alembic_ini)
        db_url = cfg.get("alembic", "sqlalchemy.url", fallback=None)
        if db_url and db_url != "driver://user:pass@localhost/dbname":
            return db_url
    return None


def set_database_url(database_url: str) -> None:
    os.environ[_ENV_KEY] = database_url
