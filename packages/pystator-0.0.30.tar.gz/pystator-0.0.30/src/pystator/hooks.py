"""Transition lifecycle hooks for PyStator FSM.

Provides hooks for metrics, tracing, logging, and webhook integration.
"""

from __future__ import annotations

import json
import logging
import threading
import time
import urllib.request
from collections import deque
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pystator._types import TransitionResult

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Metrics dataclass
# ---------------------------------------------------------------------------


@dataclass
class TransitionMetrics:
    """Metrics for a single transition."""

    source_state: str
    target_state: str
    trigger: str
    success: bool
    duration_ms: float
    guards_evaluated: int = 0
    guards_passed: int = 0
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    machine_name: str = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Hook protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class TransitionHook(Protocol):
    """Protocol for transition lifecycle hooks.

    Hooks are called in the following order:

    1. ``on_before_process`` — before any processing (orchestrator level).
    2. ``on_transition_start`` — a candidate transition is about to fire.
    3. ``on_transition_complete`` — transition finished (success or fail).
    4. ``on_transition_error`` — an unhandled exception occurred.
    """

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None: ...

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None: ...

    def on_transition_complete(
        self, result: TransitionResult, duration_ms: float, context: dict[str, Any]
    ) -> None: ...

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None: ...


# ---------------------------------------------------------------------------
# Built-in hooks
# ---------------------------------------------------------------------------


class LoggingHook:
    """Logs transition details."""

    def __init__(
        self,
        log_level: int = logging.DEBUG,
        logger_name: str = "pystator.transitions",
    ) -> None:
        """Initialize the logging hook.

        Args:
            log_level: Logging level for transition messages.
            logger_name: Name of the logger to use.
        """
        self.log_level = log_level
        self.logger = logging.getLogger(logger_name)

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Log the start of event processing."""
        self.logger.log(
            self.log_level,
            "Processing: entity_id=%s state=%s trigger=%s",
            entity_id,
            current_state,
            trigger,
        )

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        """Log the start of a transition."""
        self.logger.log(
            self.log_level,
            "Transition starting: state=%s trigger=%s",
            current_state,
            trigger,
        )

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        """Log the completion of a transition."""
        if result.success:
            self.logger.log(
                self.log_level,
                "Transition completed: %s -> %s (trigger=%s, duration=%.2fms)",
                result.source_state,
                result.target_state,
                result.trigger,
                duration_ms,
            )
        else:
            self.logger.log(
                self.log_level,
                "Transition failed: state=%s trigger=%s error=%s (duration=%.2fms)",
                result.source_state,
                result.trigger,
                result.error,
                duration_ms,
            )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Log a transition error with full traceback."""
        self.logger.exception(
            "Transition error: state=%s trigger=%s error=%s",
            current_state,
            trigger,
            error,
        )


class MetricsCollector:
    """Collects and aggregates transition metrics.

    Thread-safe with bounded memory. The ``max_history`` parameter controls
    the maximum number of transition records and duration samples kept.
    """

    def __init__(self, max_history: int = 10_000) -> None:
        """Initialize the metrics collector.

        Args:
            max_history: Maximum number of transition records to retain.
        """
        self._lock = threading.Lock()
        self._max_history = max_history
        self._transitions: deque[TransitionMetrics] = deque(maxlen=max_history)
        self._counters: dict[str, int] = {
            "total": 0,
            "success": 0,
            "failure": 0,
            "errors": 0,
        }
        self._by_trigger: dict[str, int] = {}
        self._by_source_state: dict[str, int] = {}
        self._by_target_state: dict[str, int] = {}
        self._durations: deque[float] = deque(maxlen=max_history)

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """No-op before processing."""
        pass

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        """No-op on transition start."""
        pass

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        """Record transition metrics on completion."""
        with self._lock:
            self._counters["total"] += 1
            if result.success:
                self._counters["success"] += 1
            else:
                self._counters["failure"] += 1
            self._by_trigger[result.trigger] = (
                self._by_trigger.get(result.trigger, 0) + 1
            )
            self._by_source_state[result.source_state] = (
                self._by_source_state.get(result.source_state, 0) + 1
            )
            if result.success and result.target_state:
                self._by_target_state[result.target_state] = (
                    self._by_target_state.get(result.target_state, 0) + 1
                )
            self._durations.append(duration_ms)
            self._transitions.append(
                TransitionMetrics(
                    source_state=result.source_state,
                    target_state=result.target_state or "",
                    trigger=result.trigger,
                    success=result.success,
                    duration_ms=duration_ms,
                )
            )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Increment the error counter."""
        with self._lock:
            self._counters["errors"] += 1

    def get_summary(self) -> dict[str, Any]:
        """Return aggregated metrics snapshot."""
        with self._lock:
            total = self._counters["total"]
            rate = self._counters["success"] / total if total else 0.0
            duration_stats: dict[str, float] = {}
            if self._durations:
                s = sorted(self._durations)
                duration_stats = {
                    "min_ms": s[0],
                    "max_ms": s[-1],
                    "avg_ms": sum(s) / len(s),
                    "p50_ms": s[len(s) // 2],
                    "p95_ms": s[int(len(s) * 0.95)],
                    "p99_ms": s[int(len(s) * 0.99)],
                }
            return {
                "total_transitions": total,
                "successful": self._counters["success"],
                "failed": self._counters["failure"],
                "errors": self._counters["errors"],
                "success_rate": rate,
                "by_trigger": dict(self._by_trigger),
                "by_source_state": dict(self._by_source_state),
                "by_target_state": dict(self._by_target_state),
                "duration": duration_stats,
            }

    def reset(self) -> None:
        """Clear all accumulated metrics."""
        with self._lock:
            self._transitions.clear()
            self._counters = {
                "total": 0,
                "success": 0,
                "failure": 0,
                "errors": 0,
            }
            self._by_trigger.clear()
            self._by_source_state.clear()
            self._by_target_state.clear()
            self._durations.clear()


# ---------------------------------------------------------------------------
# Observer (manages multiple hooks)
# ---------------------------------------------------------------------------


class TransitionObserver:
    """Manages transition lifecycle hooks and provides timing.

    Per-thread timing state avoids races when concurrent transitions
    overwrite each other's start times.
    """

    def __init__(self) -> None:
        """Initialize the observer with empty hook list."""
        self._hooks: list[TransitionHook] = []
        self._local = threading.local()

    def add_hook(self, hook: TransitionHook) -> TransitionObserver:
        """Register a hook and return self for chaining."""
        self._hooks.append(hook)
        return self

    def remove_hook(self, hook: TransitionHook) -> None:
        """Unregister a previously added hook."""
        self._hooks.remove(hook)

    def before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Dispatch ``on_before_process`` to all hooks.

        Call this at the orchestrator level before any work begins.
        """
        for hook in self._hooks:
            try:
                hook.on_before_process(entity_id, current_state, trigger, context)
            except Exception as e:
                logger.warning("Hook on_before_process failed: %s", e)

    def before_transition(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        """Record start time and dispatch ``on_transition_start`` to all hooks."""
        self._local.start_time = time.perf_counter()
        self._local.current_state = current_state
        self._local.current_trigger = trigger
        for hook in self._hooks:
            try:
                hook.on_transition_start(current_state, trigger, context)
            except Exception as e:
                logger.warning("Hook on_transition_start failed: %s", e)

    def after_transition(
        self, result: TransitionResult, context: dict[str, Any]
    ) -> None:
        """Compute duration and dispatch ``on_transition_complete`` to all hooks."""
        duration_ms = 0.0
        start = getattr(self._local, "start_time", None)
        if start is not None:
            duration_ms = (time.perf_counter() - start) * 1000
            self._local.start_time = None
        for hook in self._hooks:
            try:
                hook.on_transition_complete(result, duration_ms, context)
            except Exception as e:
                logger.warning("Hook on_transition_complete failed: %s", e)

    def on_error(self, error: Exception, context: dict[str, Any]) -> None:
        """Dispatch ``on_transition_error`` to all hooks."""
        state = getattr(self._local, "current_state", None) or "unknown"
        trigger = getattr(self._local, "current_trigger", None) or "unknown"
        for hook in self._hooks:
            try:
                hook.on_transition_error(error, state, trigger, context)
            except Exception as e:
                logger.warning("Hook on_transition_error failed: %s", e)


# ---------------------------------------------------------------------------
# DwellTimeTracker (Phase 6.1)
# ---------------------------------------------------------------------------


class DwellTimeTracker:
    """Tracks how long entities spend in each state.

    Records state entry timestamps per entity and provides dwell-time
    queries. Uses bounded history to prevent unbounded memory growth.
    """

    def __init__(self, max_history: int = 10_000) -> None:
        """Initialize the dwell-time tracker.

        Args:
            max_history: Maximum number of dwell-time samples to retain.
        """
        self._lock = threading.Lock()
        self._entry_times: dict[str, float] = {}
        self._entry_states: dict[str, str] = {}
        self._dwell_history: deque[tuple[str, float]] = deque(maxlen=max_history)

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Record the state entry timestamp if not already tracked."""
        with self._lock:
            if entity_id not in self._entry_times:
                self._entry_times[entity_id] = time.perf_counter()
                self._entry_states[entity_id] = current_state

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        """No-op on transition start."""
        pass

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        """Compute and record dwell time when the state changes."""
        if not result.success or not result.target_state:
            return
        if result.target_state == result.source_state:
            return
        entity_id = context.get("_entity_id", "")
        with self._lock:
            entry_time = self._entry_times.pop(entity_id, None)
            old_state = self._entry_states.pop(entity_id, None)
            if entry_time is not None and old_state is not None:
                dwell_ms = (time.perf_counter() - entry_time) * 1000
                self._dwell_history.append((old_state, dwell_ms))
            self._entry_times[entity_id] = time.perf_counter()
            self._entry_states[entity_id] = result.target_state

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """No-op on transition error."""
        pass

    def get_dwell_time(self, entity_id: str) -> float | None:
        """Return current dwell time in ms for *entity_id*, or None."""
        with self._lock:
            entry = self._entry_times.get(entity_id)
            if entry is None:
                return None
            return (time.perf_counter() - entry) * 1000

    def get_avg_dwell_by_state(self) -> dict[str, float]:
        """Return average dwell time per state across all history."""
        with self._lock:
            totals: dict[str, float] = {}
            counts: dict[str, int] = {}
            for state, dwell_ms in self._dwell_history:
                totals[state] = totals.get(state, 0.0) + dwell_ms
                counts[state] = counts.get(state, 0) + 1
            return {s: totals[s] / counts[s] for s in totals}


# ---------------------------------------------------------------------------
# StructuredLoggingHook (Phase 6.2)
# ---------------------------------------------------------------------------


class StructuredLoggingHook:
    """Emits JSON-structured log entries for transitions.

    Drop-in replacement for ``LoggingHook`` in production environments
    where structured logging is preferred. Uses the standard ``logging``
    module — no external dependencies.
    """

    def __init__(
        self,
        log_level: int = logging.INFO,
        logger_name: str = "pystator.structured",
    ) -> None:
        """Initialize the structured logging hook.

        Args:
            log_level: Logging level for JSON messages.
            logger_name: Name of the logger to use.
        """
        self.log_level = log_level
        self.logger = logging.getLogger(logger_name)

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Emit a JSON log entry before processing."""
        self.logger.log(
            self.log_level,
            "%s",
            json.dumps(
                {
                    "event": "before_process",
                    "entity_id": entity_id,
                    "source_state": current_state,
                    "trigger": trigger,
                }
            ),
        )

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        """Emit a JSON log entry when a transition starts."""
        self.logger.log(
            self.log_level,
            "%s",
            json.dumps(
                {
                    "event": "transition_start",
                    "source_state": current_state,
                    "trigger": trigger,
                }
            ),
        )

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        """Emit a JSON log entry when a transition completes."""
        self.logger.log(
            self.log_level,
            "%s",
            json.dumps(
                {
                    "event": "transition_complete",
                    "source_state": result.source_state,
                    "target_state": result.target_state,
                    "trigger": result.trigger,
                    "success": result.success,
                    "duration_ms": round(duration_ms, 3),
                }
            ),
        )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Emit a JSON log entry when a transition error occurs."""
        self.logger.log(
            self.log_level,
            "%s",
            json.dumps(
                {
                    "event": "transition_error",
                    "source_state": current_state,
                    "trigger": trigger,
                    "error_type": type(error).__name__,
                    "error_message": str(error),
                }
            ),
        )


# ---------------------------------------------------------------------------
# WebhookHook (alerting)
# ---------------------------------------------------------------------------


class WebhookHook:
    """Fires HTTP POST to registered webhooks on matching events.

    Loads webhook configurations from a callable factory and caches them
    with a configurable TTL. Webhook HTTP requests are sent in background
    threads to avoid blocking the transition pipeline.

    Supported event types:
        - ``transition_failed``: A transition attempt failed or errored.
        - ``dead_letter_created``: (Must be triggered externally via ``fire``.)
        - ``dwell_time_exceeded``: (Must be triggered externally via ``fire``.)
    """

    def __init__(
        self,
        webhook_loader: Any,
        cache_ttl_seconds: float = 60.0,
    ) -> None:
        """Initialize the webhook hook.

        Args:
            webhook_loader: Callable returning list of webhook dicts, each with
                keys: ``url``, ``events_json`` (list of event type strings),
                ``headers_json`` (optional dict), ``enabled`` (bool).
            cache_ttl_seconds: How long to cache webhook configs before reloading.
        """
        self._loader = webhook_loader
        self._cache_ttl = cache_ttl_seconds
        self._cache: list[dict[str, Any]] = []
        self._cache_time: float = 0.0
        self._lock = threading.Lock()

    def _get_webhooks(self) -> list[dict[str, Any]]:
        """Return cached webhooks, reloading if TTL expired."""
        now = time.monotonic()
        if now - self._cache_time > self._cache_ttl:
            with self._lock:
                if now - self._cache_time > self._cache_ttl:
                    try:
                        self._cache = self._loader()
                    except Exception:
                        logger.warning("Failed to load webhooks, using cached")
                    self._cache_time = time.monotonic()
        return self._cache

    def _fire_webhooks(self, event_type: str, payload: dict[str, Any]) -> None:
        """Send HTTP POST to all webhooks subscribed to *event_type*."""
        webhooks = self._get_webhooks()
        for wh in webhooks:
            if not wh.get("enabled", True):
                continue
            events = wh.get("events_json") or []
            if event_type not in events:
                continue
            thread = threading.Thread(
                target=self._send,
                args=(wh["url"], payload, wh.get("headers_json")),
                daemon=True,
            )
            thread.start()

    @staticmethod
    def _send(
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str] | None,
    ) -> None:
        """Send a single webhook HTTP POST (runs in background thread)."""
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json", **(headers or {})},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                logger.debug("Webhook %s responded %s", url, resp.status)
        except Exception:
            logger.warning("Webhook delivery failed for %s", url)

    def fire(self, event_type: str, payload: dict[str, Any]) -> None:
        """Manually fire webhooks for a given event type.

        Use this for events not tied to the TransitionHook lifecycle
        (e.g. ``dead_letter_created``, ``dwell_time_exceeded``).

        Args:
            event_type: The event type string.
            payload: The payload dict to POST.
        """
        self._fire_webhooks(event_type, payload)

    # -- TransitionHook protocol -----------------------------------------------

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """No-op before processing."""

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        """No-op on transition start."""

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        """Fire ``transition_failed`` webhooks when a transition fails."""
        if result.success:
            return
        entity_id = context.get("_entity_id", "")
        self._fire_webhooks(
            "transition_failed",
            {
                "event_type": "transition_failed",
                "entity_id": entity_id,
                "source_state": result.source_state,
                "trigger": result.trigger,
                "error": str(result.error) if result.error else None,
                "timestamp": datetime.now(UTC).isoformat(),
            },
        )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Fire ``transition_failed`` webhooks on unhandled errors."""
        entity_id = context.get("_entity_id", "")
        self._fire_webhooks(
            "transition_failed",
            {
                "event_type": "transition_failed",
                "entity_id": entity_id,
                "source_state": current_state,
                "trigger": trigger,
                "error": str(error),
                "error_type": type(error).__name__,
                "timestamp": datetime.now(UTC).isoformat(),
            },
        )
