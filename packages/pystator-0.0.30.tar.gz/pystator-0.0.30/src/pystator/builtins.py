"""Built-in guards and actions for PyStator.

Universal, domain-agnostic guards and actions that can be referenced by name
in YAML configs with zero custom Python.

Guards:
    always        -- always passes (stub, testing)
    never         -- always blocks (disable transition, testing)
    key_present   -- context key is not None (parameterized)
    key_missing   -- context key is None (parameterized)

Actions:
    noop          -- does nothing (placeholder, stub)
    log           -- logs transition info (parameterized: message, level)
    trace         -- appends to ctx["_trace"] for test assertions
    set_context   -- copies action params into context
    snapshot      -- deep-copies context to ctx["_snapshots"] (parameterized: label)
    copy_key      -- copies one context key to another (parameterized: from, to)
    validate_keys -- checks required keys exist (parameterized: required)
    publish       -- sends event via EventSink (parameterized: topic, include)
    emit_metric   -- emits metric via MetricSink (parameterized: name, value, type, tags)

Usage::

    from pystator import builtin_registries

    guards, actions = builtin_registries()
    machine = StateMachine.from_yaml("my_fsm.yaml")
    # guards and actions are ready to use by name in the YAML
"""

from __future__ import annotations

import copy
import logging
from datetime import UTC, datetime
from typing import Any

from pystator.actions import ACTION_PARAMS_KEY, ActionRegistry
from pystator.guards import GuardRegistry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------


def always(ctx: dict[str, Any]) -> bool:
    """Always returns True. Use as a stub or to mark a transition as unconditional."""
    return True


def never(ctx: dict[str, Any]) -> bool:
    """Always returns False. Use to disable a transition or in tests."""
    return False


def key_present(ctx: dict[str, Any], *, key: str = "key") -> bool:
    """True if the named context key exists and is not None.

    Example YAML::

        guards:
          - name: key_present
            params: { key: order_id }
    """
    return ctx.get(key) is not None


def key_missing(ctx: dict[str, Any], *, key: str = "key") -> bool:
    """True if the named context key is absent or None.

    Example YAML::

        guards:
          - name: key_missing
            params: { key: error }
    """
    return ctx.get(key) is None


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------


def noop(ctx: dict[str, Any]) -> None:
    """Does nothing. Use as an explicit placeholder or stub action."""
    pass


def log(
    ctx: dict[str, Any], *, message: str | None = None, level: str = "info"
) -> None:
    """Log a message with transition context.

    Example YAML::

        actions:
          - name: log
            params: { message: "Order submitted", level: "info" }

    Supported levels: debug, info, warning, error. Defaults to info.
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    if message is None:
        state = ctx.get("current_state", ctx.get("state", "?"))
        trigger = ctx.get("trigger", "?")
        dest = ctx.get("dest", ctx.get("destination", "?"))
        message = f"{trigger}: {state} -> {dest}"
    logger.log(log_level, message)


def trace(ctx: dict[str, Any]) -> None:
    """Append a trace entry to ctx["_trace"] for test assertions.

    Each entry is a dict with action name, state, trigger, and timestamp.
    In tests::

        ctx = {"order_id": "123"}
        # ... process transitions ...
        assert len(ctx["_trace"]) == 2
        assert ctx["_trace"][0]["action"] == "trace"
    """
    entry = {
        "action": "trace",
        "state": ctx.get("current_state", ctx.get("state")),
        "trigger": ctx.get("trigger"),
        "timestamp": datetime.now(UTC).isoformat(),
    }
    ctx.setdefault("_trace", []).append(entry)


def set_context(ctx: dict[str, Any], **kwargs: Any) -> None:
    """Copy params into context.

    Example YAML::

        actions:
          - name: set_context
            params: { status: "processing", attempts: 0 }
    """
    ctx.update(kwargs)


def snapshot(ctx: dict[str, Any], *, label: str | None = None) -> None:
    """Deep-copy current context to ctx["_snapshots"] for debugging or audit.

    Example YAML::

        actions:
          - { name: snapshot, params: { label: "pre_execution" } }
    """
    effective_label = label or datetime.now(UTC).isoformat()
    entry = {
        "label": effective_label,
        "timestamp": datetime.now(UTC).isoformat(),
        "data": {k: v for k, v in copy.deepcopy(ctx).items() if not k.startswith("_")},
    }
    ctx.setdefault("_snapshots", []).append(entry)


def copy_key(ctx: dict[str, Any], *, key_from: str = "", key_to: str = "") -> None:
    """Copy value from one context key to another.

    Example YAML::

        actions:
          - { name: copy_key, params: { key_from: current_price, key_to: entry_price } }

    Also accepts legacy ``from``/``to`` param names via ``**kwargs``.
    """
    # Support legacy param names
    src = key_from or ctx.get(ACTION_PARAMS_KEY, {}).get("from", "")
    dst = key_to or ctx.get(ACTION_PARAMS_KEY, {}).get("to", "")
    if not src or not dst:
        logger.warning("copy_key: missing 'key_from' or 'key_to' param")
        return
    if src in ctx:
        ctx[dst] = ctx[src]


def validate_keys(ctx: dict[str, Any], *, required: list[str] | None = None) -> None:
    """Check that required context keys exist and are not None.

    Example YAML::

        actions:
          - { name: validate_keys, params: { required: [order_id, quantity] } }
    """
    keys = required or []
    if not isinstance(keys, list):
        logger.warning("validate_keys: 'required' param must be a list")
        return

    missing = [k for k in keys if ctx.get(k) is None]
    if missing:
        for item in missing:
            logger.warning("validate_keys: required key '%s' is missing or None", item)
        ctx.setdefault("_validation_errors", []).extend(missing)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

_BUILTIN_GUARDS: dict[str, Any] = {
    "always": always,
    "never": never,
    "key_present": key_present,
    "key_missing": key_missing,
}

_BUILTIN_ACTIONS: dict[str, Any] = {
    "noop": noop,
    "log": log,
    "trace": trace,
    "set_context": set_context,
    "snapshot": snapshot,
    "copy_key": copy_key,
    "validate_keys": validate_keys,
}


def register_builtins(
    guard_registry: GuardRegistry | None = None,
    action_registry: ActionRegistry | None = None,
) -> tuple[GuardRegistry, ActionRegistry]:
    """Register all built-in guards and actions into the given registries.

    Creates new registries if ``None`` is passed.
    Returns ``(guard_registry, action_registry)``.
    """
    if guard_registry is None:
        guard_registry = GuardRegistry()
    if action_registry is None:
        action_registry = ActionRegistry()

    for name, func in _BUILTIN_GUARDS.items():
        if not guard_registry.has(name):
            guard_registry.register(name, func)

    for name, func in _BUILTIN_ACTIONS.items():
        if not action_registry.has(name):
            action_registry.register(name, func)

    # Wire adapter-backed actions with logging defaults
    from pystator.sinks import configure_event_sink, configure_metric_sink

    if not action_registry.has("publish"):
        configure_event_sink(action_registry)
    if not action_registry.has("emit_metric"):
        configure_metric_sink(action_registry)

    return guard_registry, action_registry


def builtin_registries() -> tuple[GuardRegistry, ActionRegistry]:
    """Create fresh registries with all builtins pre-registered."""
    return register_builtins()


def _register_builtins_into(
    guard_registry: GuardRegistry,
    action_registry: ActionRegistry,
) -> None:
    """Register builtins into existing registries (used by StateMachine)."""
    register_builtins(guard_registry, action_registry)
