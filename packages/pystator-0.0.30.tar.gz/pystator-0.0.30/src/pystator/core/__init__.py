"""Core FSM definition and execution engine.

Re-exports the foundational types from their implementation modules,
providing a clean ``pystator.core`` namespace for:

- ``StateMachine`` / ``StateMachineBuilder`` — config-driven machine
- ``EntitySession`` — per-entity stateful wrapper
- ``Event`` — immutable event envelope
- ``TransitionResult`` — outcome of a transition
- Core value types (``State``, ``StateType``, ``Transition``, etc.)
"""

from __future__ import annotations

from pystator._parallel import ParallelStateConfig, ParallelStateManager
from pystator._types import (
    EFFECT_TYPES,
    ActionSpec,
    CheckSpec,
    DestinationCandidate,
    DestinationCheckResult,
    GuardSpec,
    HistoryType,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    TransitionResult,
    WhenCheck,
)
from pystator.context import TransitionContext
from pystator.event import Event
from pystator.instance import EntitySession
from pystator.machine import StateMachine, StateMachineBuilder, check_timeout
from pystator.state_parsing import parse_stored_state
from pystator.workflow_status import (
    WORKFLOW_STATUS_ACTIVE,
    WORKFLOW_STATUS_COMPLETE,
    WORKFLOW_STATUS_FAILED,
    WORKFLOW_VALID_STATUSES,
    compute_workflow_status,
    persistence_flags_for_state,
)

__all__ = [
    "EFFECT_TYPES",
    "ActionSpec",
    "CheckSpec",
    "DestinationCandidate",
    "DestinationCheckResult",
    "EntitySession",
    "Event",
    "GuardSpec",
    "HistoryType",
    "ParallelStateConfig",
    "ParallelStateManager",
    "Region",
    "State",
    "StateType",
    "StateMachine",
    "StateMachineBuilder",
    "Timeout",
    "Transition",
    "TransitionContext",
    "TransitionResult",
    "WhenCheck",
    "WORKFLOW_STATUS_ACTIVE",
    "WORKFLOW_STATUS_COMPLETE",
    "WORKFLOW_STATUS_FAILED",
    "WORKFLOW_VALID_STATUSES",
    "check_timeout",
    "compute_workflow_status",
    "parse_stored_state",
    "persistence_flags_for_state",
]
