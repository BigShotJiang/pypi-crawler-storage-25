"""CLI for documentation: ``pystator docs serve`` and ``pystator docs build``.

Delegates to MkDocs. Documentation is bundled with the installed package so
``pystator docs serve`` works after ``pip install pystator[api]``.  You can
also run from the project root or set DOCS_ROOT to override the location.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def _get_docs_root() -> Path | None:
    """Return the directory containing mkdocs.yml, or None if not found.

    Search order:
        1. ``DOCS_ROOT`` environment variable (explicit override).
        2. Current working directory (repo checkout convenience).
        3. Bundled docs shipped inside the installed package
           (``<pkg>/_bundled_docs/``).
        4. Walk up parent directories from the installed module
           (editable install / monorepo).
    """
    # 1. Environment variable override
    env_root = os.environ.get("DOCS_ROOT")
    if env_root:
        p = Path(env_root).resolve()
        if (p / "mkdocs.yml").exists():
            return p
        return None

    # 2. Current working directory
    cwd = Path.cwd()
    if (cwd / "mkdocs.yml").exists():
        return cwd

    # 3. Bundled docs (shipped with pip install)
    try:
        import pystator

        pkg_dir = Path(pystator.__file__).resolve().parent
        bundled = pkg_dir / "_bundled_docs"
        if (bundled / "mkdocs.yml").exists():
            return bundled
    except (ImportError, AttributeError):
        pass

    # 4. Walk up parent directories (editable install / repo checkout)
    try:
        import pystator

        start = Path(pystator.__file__).resolve().parent
    except (ImportError, AttributeError):
        return None

    current = start
    for _ in range(10):
        if (current / "mkdocs.yml").exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent

    return None


# Default port for docs serve; aligned with API (8004) and UI (3004).
DEFAULT_DOCS_PORT = 5004


def cmd_docs_serve(host: str = "127.0.0.1", port: int = DEFAULT_DOCS_PORT) -> int:
    """Run ``mkdocs serve`` for local preview."""
    root = _get_docs_root()
    if not root:
        print(
            "❌ mkdocs.yml not found. Run from the project root (where mkdocs.yml lives), "
            "or set DOCS_ROOT to that directory.",
            file=sys.stderr,
        )
        return 1

    try:
        subprocess.run(
            [sys.executable, "-m", "mkdocs", "serve", "-a", f"{host}:{port}"],
            cwd=str(root),
            check=True,
        )
    except FileNotFoundError:
        print(
            "❌ MkDocs not found. Install with: pip install pystator[api]",
            file=sys.stderr,
        )
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode

    return 0


def cmd_docs_build() -> int:
    """Run ``mkdocs build`` to produce the static site."""
    root = _get_docs_root()
    if not root:
        print(
            "❌ mkdocs.yml not found. Run from the project root (where mkdocs.yml lives), "
            "or set DOCS_ROOT to that directory.",
            file=sys.stderr,
        )
        return 1

    try:
        subprocess.run(
            [sys.executable, "-m", "mkdocs", "build"],
            cwd=str(root),
            check=True,
        )
    except FileNotFoundError:
        print(
            "❌ MkDocs not found. Install with: pip install pystator[api]",
            file=sys.stderr,
        )
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode

    return 0
