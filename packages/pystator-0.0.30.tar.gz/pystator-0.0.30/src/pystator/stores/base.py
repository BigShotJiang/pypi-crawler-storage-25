"""State store protocols, base class, and in-memory implementation.

Protocols define the duck-typed interface consumed by the Orchestrator.
StateStoreClient provides the shared connect/disconnect lifecycle for
persistent backends (SQLAlchemy, Redis). Mirrors the architecture of
pycharter's MetadataStoreClient.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pystator.errors import StaleVersionError

# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class StateStore(Protocol):
    """Protocol for synchronous state persistence."""

    def get_state(self, entity_id: str) -> str | None: ...

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None: ...

    def get_context(self, entity_id: str) -> dict[str, Any]: ...


@runtime_checkable
class AsyncStateStore(Protocol):
    """Protocol for asynchronous state persistence."""

    async def aget_state(self, entity_id: str) -> str | None: ...

    async def aset_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None: ...

    async def aget_context(self, entity_id: str) -> dict[str, Any]: ...


@runtime_checkable
class ContextPersistStore(Protocol):
    """Optional protocol for context persistence.

    Stores that implement this allow the Orchestrator to persist context
    updates after action execution. All built-in stores implement this.
    """

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None: ...


@runtime_checkable
class AsyncContextPersistStore(Protocol):
    """Async version of ContextPersistStore."""

    async def aset_context(self, entity_id: str, context: dict[str, Any]) -> None: ...


@runtime_checkable
class VersionedStateStore(Protocol):
    """Protocol for state stores with optimistic locking.

    Implementations track a monotonically increasing version per entity.
    ``set_state_versioned`` raises ``StaleVersionError`` when the caller's
    expected version does not match the stored version.
    """

    def get_state_versioned(self, entity_id: str) -> tuple[str | None, int | None]:
        """Return ``(state, version)`` for the entity."""
        ...

    def set_state_versioned(
        self,
        entity_id: str,
        state: str,
        *,
        expected_version: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        """Set state with optimistic locking. Returns the new version."""
        ...


@runtime_checkable
class BatchStateStore(Protocol):
    """Optional protocol for bulk entity operations."""

    def get_states_batch(self, entity_ids: list[str]) -> dict[str, str | None]: ...

    def set_states_batch(
        self,
        updates: dict[str, str],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None: ...


@runtime_checkable
class QueryableStateStore(Protocol):
    """Optional protocol for querying entities by state."""

    def list_entities(
        self,
        state: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[str]: ...

    def count_by_state(self) -> dict[str, int]: ...


@runtime_checkable
class AuditStore(Protocol):
    """Optional protocol for transition audit logging."""

    def record_transition(
        self,
        entity_id: str,
        source_state: str,
        trigger: str,
        *,
        target_state: str | None = None,
        success: bool = True,
        duration_ms: float | None = None,
    ) -> None: ...


@runtime_checkable
class EventStore(Protocol):
    """Optional protocol for append-only event persistence.

    Stores raw events (inputs) as the source of truth for each entity,
    enabling replay and event-sourcing patterns.
    """

    def append_event(
        self,
        entity_id: str,
        trigger: str,
        *,
        payload: dict[str, Any] | None = None,
        event_id: str | None = None,
        source: str = "",
        machine_name: str | None = None,
    ) -> int:
        """Append an event and return its sequence number."""
        ...

    def get_events(
        self,
        entity_id: str,
        *,
        after_sequence: int = 0,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Return events for *entity_id* ordered by sequence."""
        ...


# ---------------------------------------------------------------------------
# Batch fallback helper
# ---------------------------------------------------------------------------


def batch_fallback(store: StateStore) -> _BatchFallbackWrapper:
    """Wrap any StateStore with loop-based batch operations.

    Returns a wrapper that implements ``BatchStateStore`` by looping
    over the underlying ``StateStore``. Users who don't need optimized
    batch can use any store.
    """
    return _BatchFallbackWrapper(store)


class _BatchFallbackWrapper:
    """Loop-based BatchStateStore wrapper around any StateStore."""

    def __init__(self, store: StateStore) -> None:
        self._store = store

    def get_states_batch(self, entity_ids: list[str]) -> dict[str, str | None]:
        """Fetch states one-by-one."""
        return {eid: self._store.get_state(eid) for eid in entity_ids}

    def set_states_batch(
        self,
        updates: dict[str, str],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Set states one-by-one."""
        for eid, state in updates.items():
            self._store.set_state(eid, state, metadata=metadata)


# ---------------------------------------------------------------------------
# Base class for persistent backends
# ---------------------------------------------------------------------------


class StateStoreClient:
    """Base class for persistent state store implementations.

    Provides connect/disconnect lifecycle, context manager support, and
    connection guards.  Mirrors pycharter's ``MetadataStoreClient``.

    Subclasses must override ``connect()`` and should call
    ``_require_connection()`` at the top of every method that touches the
    backend.
    """

    def __init__(self, connection_string: str | None = None) -> None:
        self.connection_string = connection_string
        self._connection: Any = None

    # -- lifecycle -----------------------------------------------------------

    def connect(self) -> None:
        """Establish backend connection.  Subclasses must implement."""
        raise NotImplementedError("Subclasses must implement connect()")

    def disconnect(self) -> None:
        """Close the backend connection."""
        if self._connection is not None:
            self._connection = None

    # -- guards --------------------------------------------------------------

    def _require_connection(self) -> None:
        """Raise ``RuntimeError`` if ``connect()`` has not been called."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> StateStoreClient:
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.disconnect()


# ---------------------------------------------------------------------------
# In-memory implementation
# ---------------------------------------------------------------------------


class InMemoryStateStore:
    """In-memory state store for testing and simple use cases.

    Implements sync, async, versioned, batch, queryable, and event store
    protocols. Not suitable for production.
    """

    def __init__(self) -> None:
        self._state: dict[str, str] = {}
        self._context: dict[str, dict[str, Any]] = {}
        self._metadata: dict[str, dict[str, Any]] = {}
        self._versions: dict[str, int] = {}
        self._event_log: dict[str, list[dict[str, Any]]] = {}
        self._event_sequences: dict[str, int] = {}

    # Sync API

    def get_state(self, entity_id: str) -> str | None:
        return self._state.get(entity_id)

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._state[entity_id] = state
        self._versions[entity_id] = self._versions.get(entity_id, 0) + 1
        if metadata is not None:
            self._metadata[entity_id] = dict(metadata)

    def get_context(self, entity_id: str) -> dict[str, Any]:
        return dict(self._context.get(entity_id, {}))

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None:
        self._context[entity_id] = dict(context)

    def get_is_terminal(self, entity_id: str) -> bool | None:
        meta = self._metadata.get(entity_id)
        if meta is None:
            return None
        val = meta.get("is_terminal")
        return val if isinstance(val, bool) else None

    def get_workflow_status(self, entity_id: str) -> str | None:
        """Return persisted ``workflow_status`` (``active`` / ``complete`` / ``failed``), if any."""
        meta = self._metadata.get(entity_id)
        if meta is None:
            return None
        val = meta.get("workflow_status")
        return val if isinstance(val, str) else None

    # Versioned API (optimistic locking)

    def get_state_versioned(self, entity_id: str) -> tuple[str | None, int | None]:
        state = self._state.get(entity_id)
        version = self._versions.get(entity_id)
        return state, version

    def set_state_versioned(
        self,
        entity_id: str,
        state: str,
        *,
        expected_version: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        if expected_version is not None:
            current_version = self._versions.get(entity_id)
            if current_version != expected_version:
                raise StaleVersionError(
                    entity_id=entity_id,
                    expected_version=expected_version,
                    actual_version=current_version or 0,
                )
        self._state[entity_id] = state
        new_version = self._versions.get(entity_id, 0) + 1
        self._versions[entity_id] = new_version
        if metadata is not None:
            self._metadata[entity_id] = dict(metadata)
        return new_version

    # Batch API

    def get_states_batch(self, entity_ids: list[str]) -> dict[str, str | None]:
        """Fetch multiple entity states at once."""
        return {eid: self._state.get(eid) for eid in entity_ids}

    def set_states_batch(
        self,
        updates: dict[str, str],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Set multiple entity states at once."""
        for eid, state in updates.items():
            self.set_state(eid, state, metadata=metadata)

    # Queryable API

    def list_entities(
        self,
        state: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[str]:
        """List entity IDs, optionally filtered by state."""
        if state is not None:
            ids = [eid for eid, s in self._state.items() if s == state]
        else:
            ids = list(self._state.keys())
        return ids[offset : offset + limit]

    def count_by_state(self) -> dict[str, int]:
        """Return count of entities per state."""
        counts: dict[str, int] = {}
        for s in self._state.values():
            counts[s] = counts.get(s, 0) + 1
        return counts

    # Async API

    async def aget_state(self, entity_id: str) -> str | None:
        return self.get_state(entity_id)

    async def aset_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.set_state(entity_id, state, metadata=metadata)

    async def aget_context(self, entity_id: str) -> dict[str, Any]:
        return self.get_context(entity_id)

    async def aset_context(self, entity_id: str, context: dict[str, Any]) -> None:
        self.set_context(entity_id, context)

    # Event Store API

    def append_event(
        self,
        entity_id: str,
        trigger: str,
        *,
        payload: dict[str, Any] | None = None,
        event_id: str | None = None,
        source: str = "",
        machine_name: str | None = None,
    ) -> int:
        """Append an event and return its sequence number."""
        seq = self._event_sequences.get(entity_id, 0) + 1
        self._event_sequences[entity_id] = seq
        record = {
            "entity_id": entity_id,
            "sequence": seq,
            "trigger": trigger,
            "payload": dict(payload) if payload else {},
            "event_id": event_id,
            "source": source,
            "machine_name": machine_name,
        }
        self._event_log.setdefault(entity_id, []).append(record)
        return seq

    def get_events(
        self,
        entity_id: str,
        *,
        after_sequence: int = 0,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Return events for *entity_id* ordered by sequence."""
        events = self._event_log.get(entity_id, [])
        filtered = [e for e in events if e["sequence"] > after_sequence]
        return filtered[:limit]
