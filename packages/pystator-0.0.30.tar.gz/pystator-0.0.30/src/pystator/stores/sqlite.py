"""SQLite state store implementation.

Thin wrapper around ``_SQLAlchemyStateStoreBase`` that validates the
connection string and defaults to ``sqlite:///<cwd>/pystator.db``.
"""

from __future__ import annotations

import logging
from pathlib import Path

from pystator.db.config import get_db_url
from pystator.stores._sqlalchemy_base import _SQLAlchemyStateStoreBase

logger = logging.getLogger(__name__)


class SQLiteStateStore(_SQLAlchemyStateStoreBase):
    """SQLite-backed state store.

    Satisfies the ``StateStore`` and ``VersionedStateStore`` protocols.

    Usage::

        store = SQLiteStateStore("sqlite:///pystator.db")
        store.connect()  # auto_initialize=True by default

    Or with a context manager::

        with SQLiteStateStore() as store:
            store.get_state("order-123")

    If *connection_string* is ``None``, resolves from env / config / default.
    """

    def __init__(self, connection_string: str | None = None) -> None:
        resolved = connection_string or get_db_url(None, required=True)
        if not resolved.startswith("sqlite://"):
            raise ValueError(
                f"SQLiteStateStore requires a sqlite:// URL, got: {resolved!r}"
            )
        # Ensure parent directory exists for file-based databases.
        if resolved != "sqlite:///:memory:" and resolved.startswith("sqlite:///"):
            db_path = Path(resolved[len("sqlite:///") :])
            db_path.parent.mkdir(parents=True, exist_ok=True)
        super().__init__(resolved)

    def connect(
        self,
        validate_schema: bool = True,
        auto_initialize: bool = True,
    ) -> None:
        """Connect to the SQLite database.

        Args:
            validate_schema: Check that required tables exist.
            auto_initialize: Create tables if missing (default ``True``
                for SQLite since there is no separate migration step).
        """
        self._connect_engine(
            schema_name=None,
            validate_schema=validate_schema,
            auto_initialize=auto_initialize,
        )
