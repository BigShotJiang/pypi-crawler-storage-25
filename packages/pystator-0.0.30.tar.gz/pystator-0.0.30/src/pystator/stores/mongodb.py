"""MongoDB state store implementation.

Native ``pymongo`` backend — extends ``StateStoreClient`` directly (not
the SQLAlchemy base).  Mirrors pycharter's ``MongoDBMetadataStore``.

Collections::

    entity_states        — one document per entity
    transition_history   — append-only audit log
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from pystator.errors import StaleVersionError
from pystator.stores.base import StateStoreClient

logger = logging.getLogger(__name__)

try:
    import pymongo  # type: ignore[import-not-found,import-untyped]

    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    pymongo = None  # type: ignore[assignment]


def _utc_now() -> datetime:
    """Return the current UTC timestamp."""
    return datetime.now(UTC)


class MongoDBStateStore(StateStoreClient):
    """MongoDB-backed state store.

    Satisfies the ``StateStore`` and ``VersionedStateStore`` protocols.

    Usage::

        store = MongoDBStateStore("mongodb://localhost:27017", database_name="pystator")
        store.connect()
        store.set_state("order-123", "pending")

    Or with a context manager::

        with MongoDBStateStore("mongodb://localhost:27017") as store:
            store.get_state("order-123")
    """

    def __init__(
        self,
        connection_string: str,
        database_name: str = "pystator",
    ) -> None:
        if not MONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDBStateStore. "
                "Install with: pip install pymongo"
            )
        if not connection_string.startswith(("mongodb://", "mongodb+srv://")):
            raise ValueError(
                f"MongoDBStateStore requires a mongodb:// URL, got: {connection_string!r}"
            )
        super().__init__(connection_string)
        self._database_name = database_name
        self._client: Any = None
        self._db: Any = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def connect(self, ensure_indexes: bool = True) -> None:
        """Connect to MongoDB and optionally create indexes.

        Args:
            ensure_indexes: Create indexes on first connect (default ``True``).
        """
        self._client = pymongo.MongoClient(self.connection_string)
        self._db = self._client[self._database_name]
        self._connection = self._db  # sentinel for _require_connection

        if ensure_indexes:
            self._ensure_indexes()

    def disconnect(self) -> None:
        """Close the MongoDB connection."""
        if self._client is not None:
            self._client.close()
            self._client = None
        self._db = None
        self._connection = None

    def _ensure_indexes(self) -> None:
        """Create indexes for efficient queries."""
        entities = self._db["entity_states"]
        entities.create_index("entity_id", unique=True)
        entities.create_index("machine_name")
        entities.create_index("current_state")
        entities.create_index("is_terminal")

        history = self._db["transition_history"]
        history.create_index("entity_id")
        history.create_index("machine_name")
        history.create_index([("created_at", pymongo.DESCENDING)])

        event_log = self._db["event_log"]
        event_log.create_index("entity_id")
        event_log.create_index([("entity_id", 1), ("sequence", 1)], unique=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _entities(self) -> Any:
        """Return the ``entity_states`` collection."""
        self._require_connection()
        return self._db["entity_states"]

    def _history(self) -> Any:
        """Return the ``transition_history`` collection."""
        self._require_connection()
        return self._db["transition_history"]

    # ------------------------------------------------------------------
    # StateStore protocol (sync)
    # ------------------------------------------------------------------

    def get_state(self, entity_id: str) -> str | None:
        """Return the current state for *entity_id*, or ``None``."""
        doc = self._entities().find_one({"entity_id": entity_id})
        if doc is None:
            return None
        return doc.get("current_state")

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Persist state (upsert) for *entity_id*."""
        meta = metadata or {}
        now = _utc_now()
        update: dict[str, Any] = {
            "$set": {
                "current_state": state,
                "updated_at": now,
            },
            "$inc": {"version": 1},
            "$setOnInsert": {
                "entity_id": entity_id,
                "created_at": now,
            },
        }
        if "is_terminal" in meta:
            update["$set"]["is_terminal"] = meta["is_terminal"]
        if "workflow_status" in meta:
            update["$set"]["workflow_status"] = meta["workflow_status"]
        if "machine_name" in meta:
            update["$set"]["machine_name"] = meta["machine_name"]
        if "context" in meta:
            update["$set"]["context"] = meta["context"]
        self._entities().update_one({"entity_id": entity_id}, update, upsert=True)

    def get_context(self, entity_id: str) -> dict[str, Any]:
        """Return persisted context for *entity_id* (empty dict if none)."""
        doc = self._entities().find_one({"entity_id": entity_id})
        if doc is None:
            return {}
        return dict(doc.get("context") or {})

    # ------------------------------------------------------------------
    # VersionedStateStore protocol (optimistic locking)
    # ------------------------------------------------------------------

    def get_state_versioned(self, entity_id: str) -> tuple[str | None, int | None]:
        """Return ``(current_state, version)`` for *entity_id*."""
        doc = self._entities().find_one({"entity_id": entity_id})
        if doc is None:
            return None, None
        return doc.get("current_state"), doc.get("version")

    def set_state_versioned(
        self,
        entity_id: str,
        state: str,
        *,
        expected_version: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        """Set state with optimistic locking. Returns the new version.

        Raises:
            StaleVersionError: If *expected_version* doesn't match.
        """
        meta = metadata or {}
        now = _utc_now()
        doc = self._entities().find_one({"entity_id": entity_id})

        if doc is None:
            # Insert new entity at version 1.
            new_doc: dict[str, Any] = {
                "entity_id": entity_id,
                "current_state": state,
                "version": 1,
                "created_at": now,
                "updated_at": now,
            }
            if "is_terminal" in meta:
                new_doc["is_terminal"] = meta["is_terminal"]
            if "workflow_status" in meta:
                new_doc["workflow_status"] = meta["workflow_status"]
            if "machine_name" in meta:
                new_doc["machine_name"] = meta["machine_name"]
            if "context" in meta:
                new_doc["context"] = meta["context"]
            self._entities().insert_one(new_doc)
            return 1

        current_version = doc.get("version", 1)
        if expected_version is not None and current_version != expected_version:
            raise StaleVersionError(
                entity_id=entity_id,
                expected_version=expected_version,
                actual_version=current_version,
            )
        new_version = current_version + 1
        update_set: dict[str, Any] = {
            "current_state": state,
            "version": new_version,
            "updated_at": now,
        }
        if "is_terminal" in meta:
            update_set["is_terminal"] = meta["is_terminal"]
        if "workflow_status" in meta:
            update_set["workflow_status"] = meta["workflow_status"]
        if "machine_name" in meta:
            update_set["machine_name"] = meta["machine_name"]
        if "context" in meta:
            update_set["context"] = meta["context"]
        self._entities().update_one({"entity_id": entity_id}, {"$set": update_set})
        return new_version

    # ------------------------------------------------------------------
    # Extended helpers
    # ------------------------------------------------------------------

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None:
        """Persist context for *entity_id* (entity must already exist)."""
        result = self._entities().update_one(
            {"entity_id": entity_id},
            {"$set": {"context": context, "updated_at": _utc_now()}},
        )
        if result.matched_count == 0:
            raise ValueError(f"Entity not found: {entity_id!r}")

    def get_is_terminal(self, entity_id: str) -> bool | None:
        """Return the ``is_terminal`` flag for *entity_id*."""
        doc = self._entities().find_one({"entity_id": entity_id})
        if doc is None:
            return None
        val = doc.get("is_terminal")
        return val if isinstance(val, bool) else None

    def get_workflow_status(self, entity_id: str) -> str | None:
        """Return persisted workflow outcome for *entity_id*, or ``None`` if missing."""
        doc = self._entities().find_one({"entity_id": entity_id})
        if doc is None:
            return None
        val = doc.get("workflow_status")
        return val if isinstance(val, str) else None

    def list_entities(
        self,
        machine_name: str | None = None,
        is_terminal: bool | None = None,
        workflow_status: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List entity states with optional filters."""
        query: dict[str, Any] = {}
        if machine_name is not None:
            query["machine_name"] = machine_name
        if is_terminal is not None:
            query["is_terminal"] = is_terminal
        if workflow_status is not None:
            query["workflow_status"] = workflow_status
        cursor = (
            self._entities()
            .find(query)
            .sort("updated_at", pymongo.DESCENDING)
            .skip(offset)
            .limit(limit)
        )
        return [
            {
                "entity_id": doc["entity_id"],
                "current_state": doc.get("current_state"),
                "machine_name": doc.get("machine_name"),
                "is_terminal": doc.get("is_terminal"),
                "workflow_status": doc.get("workflow_status"),
                "context": doc.get("context") or {},
                "created_at": doc.get("created_at"),
                "updated_at": doc.get("updated_at"),
            }
            for doc in cursor
        ]

    def delete_entity(self, entity_id: str) -> bool:
        """Delete entity state. Returns ``True`` if a document was deleted."""
        result = self._entities().delete_one({"entity_id": entity_id})
        return result.deleted_count > 0

    # ------------------------------------------------------------------
    # Transition history (audit log)
    # ------------------------------------------------------------------

    def record_transition(
        self,
        entity_id: str,
        source_state: str,
        trigger: str,
        *,
        target_state: str | None = None,
        success: bool = True,
        machine_name: str | None = None,
        actions_executed: list[str] | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        context_snapshot: dict[str, Any] | None = None,
        duration_ms: int | float | None = None,
    ) -> str:
        """Write a document to ``transition_history``. Returns the record id."""
        record_id = str(uuid.uuid4())
        duration_int: int | None = None
        if duration_ms is not None:
            duration_int = int(duration_ms)
        doc: dict[str, Any] = {
            "id": record_id,
            "entity_id": entity_id,
            "machine_name": machine_name,
            "source_state": source_state,
            "target_state": target_state,
            "trigger": trigger,
            "success": success,
            "error_type": error_type,
            "error_message": error_message,
            "actions_executed": actions_executed,
            "context_snapshot": context_snapshot,
            "duration_ms": duration_int,
            "created_at": _utc_now(),
        }
        self._history().insert_one(doc)
        return record_id

    def get_transition_history(
        self,
        entity_id: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Return recent transition history for *entity_id*."""
        cursor = (
            self._history()
            .find({"entity_id": entity_id})
            .sort("created_at", pymongo.DESCENDING)
            .limit(limit)
        )
        return [
            {
                "id": doc.get("id", str(doc.get("_id", ""))),
                "entity_id": doc["entity_id"],
                "machine_name": doc.get("machine_name"),
                "source_state": doc.get("source_state"),
                "target_state": doc.get("target_state"),
                "trigger": doc.get("trigger"),
                "success": doc.get("success"),
                "error_type": doc.get("error_type"),
                "error_message": doc.get("error_message"),
                "actions_executed": doc.get("actions_executed"),
                "context_snapshot": doc.get("context_snapshot"),
                "created_at": doc.get("created_at"),
                "duration_ms": doc.get("duration_ms"),
            }
            for doc in cursor
        ]

    # -- Event Store -----------------------------------------------------------

    def _event_log(self) -> Any:
        """Return the ``event_log`` collection."""
        self._require_connection()
        return self._db["event_log"]

    def append_event(
        self,
        entity_id: str,
        trigger: str,
        *,
        payload: dict[str, Any] | None = None,
        event_id: str | None = None,
        source: str = "",
        machine_name: str | None = None,
    ) -> int:
        """Append an event to the log and return its sequence number."""
        last = self._event_log().find_one(
            {"entity_id": entity_id},
            sort=[("sequence", pymongo.DESCENDING)],
            projection={"sequence": 1},
        )
        seq = (last["sequence"] if last else 0) + 1
        self._event_log().insert_one(
            {
                "id": str(uuid.uuid4()),
                "entity_id": entity_id,
                "machine_name": machine_name,
                "sequence": seq,
                "trigger": trigger,
                "payload": payload,
                "event_id": event_id,
                "source": source,
                "created_at": datetime.now(UTC),
            }
        )
        return seq

    def get_events(
        self,
        entity_id: str,
        *,
        after_sequence: int = 0,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Return events for *entity_id* ordered by sequence."""
        cursor = (
            self._event_log()
            .find({"entity_id": entity_id, "sequence": {"$gt": after_sequence}})
            .sort("sequence", pymongo.ASCENDING)
            .limit(limit)
        )
        return [
            {
                "id": doc.get("id", str(doc.get("_id", ""))),
                "entity_id": doc["entity_id"],
                "machine_name": doc.get("machine_name"),
                "sequence": doc["sequence"],
                "trigger": doc["trigger"],
                "payload": doc.get("payload"),
                "event_id": doc.get("event_id"),
                "source": doc.get("source"),
                "created_at": doc.get("created_at"),
            }
            for doc in cursor
        ]
