"""CLI for machine management: ``pystator machines list|get|create|delete|seed``.

All commands use machine_parser + machine_store for a single canonical
code path — the same path used by the API and worker.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def cmd_list(database_url: str | None = None, name: str | None = None) -> int:
    """List all machines in the store."""
    store = _connect(database_url)
    if store is None:
        return 1
    try:
        definitions = store.list(name=name)
        if not definitions:
            print("No machines found.")
            return 0
        print(f"{'Name':<30} {'Version':<12} {'Description'}")
        print("-" * 72)
        for d in definitions:
            desc = (d.description or "")[:40]
            print(f"{d.name:<30} {d.version:<12} {desc}")
        print(f"\n{len(definitions)} machine(s)")
        return 0
    finally:
        store.disconnect()


def cmd_get(
    name: str,
    version: str | None = None,
    database_url: str | None = None,
    output_json: bool = False,
) -> int:
    """Get a machine definition by name (optionally version)."""
    store = _connect(database_url)
    if store is None:
        return 1
    try:
        defn = store.get(name, version)
        if defn is None:
            label = name + (f"@{version}" if version else "")
            print(f"Machine not found: {label}")
            return 1
        if output_json:
            print(json.dumps(defn.config, indent=2))
        else:
            print(f"Name:        {defn.name}")
            print(f"Version:     {defn.version}")
            print(f"Description: {defn.description or '(none)'}")
            print(f"Strict mode: {defn.strict_mode}")
            print(f"States:      {len(defn.states)}")
            print(f"Transitions: {len(defn.transitions)}")
        return 0
    finally:
        store.disconnect()


def cmd_create(
    path: str,
    database_url: str | None = None,
) -> int:
    """Create a machine from a YAML/JSON file."""
    from pystator.machine_parser import parse_machine_file

    file_path = Path(path)
    if not file_path.exists():
        print(f"File not found: {file_path}")
        return 1

    try:
        defn = parse_machine_file(file_path, validate=True)
    except Exception as exc:
        print(f"Failed to parse machine config: {exc}")
        return 1

    store = _connect(database_url)
    if store is None:
        return 1
    try:
        machine_id = store.save(defn)
        print(f"Created: {defn.name}@{defn.version} (id: {machine_id})")
        return 0
    except Exception as exc:
        print(f"Failed to save machine: {exc}")
        return 1
    finally:
        store.disconnect()


def cmd_delete(
    name: str,
    version: str,
    database_url: str | None = None,
) -> int:
    """Delete a machine version from the store."""
    store = _connect(database_url)
    if store is None:
        return 1
    try:
        deleted = store.delete(name, version)
        if deleted:
            print(f"Deleted: {name}@{version}")
            return 0
        print(f"Machine not found: {name}@{version}")
        return 1
    finally:
        store.disconnect()


def cmd_seed(
    seed_dir: str | None = None,
    database_url: str | None = None,
) -> int:
    """Seed machines from a directory of YAML files."""
    from pystator.db.cli import cmd_seed as db_cmd_seed

    return db_cmd_seed(seed_dir, database_url)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _connect(database_url: str | None = None):
    """Create and connect a SQLAlchemyMachineStore."""
    from pystator.db.config import get_db_url
    from pystator.machine_store import SQLAlchemyMachineStore

    db_url = get_db_url(database_url, required=True)
    if not db_url:
        print("No database URL configured. Set PYSTATOR_DATABASE_URL.", file=sys.stderr)
        return None

    store = SQLAlchemyMachineStore(db_url)
    try:
        store.connect()
        return store
    except Exception as exc:
        print(f"Failed to connect to database: {exc}", file=sys.stderr)
        return None


def main() -> int:
    """CLI entry point for ``pystator machines`` subcommands."""
    parser = argparse.ArgumentParser(
        description="PyStator machine management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command to run")

    # list
    list_p = sub.add_parser("list", help="List all machines")
    list_p.add_argument("--name", default=None, help="Filter by machine name")
    list_p.add_argument("database_url", nargs="?", help="Database URL")

    # get
    get_p = sub.add_parser("get", help="Get a machine definition")
    get_p.add_argument("name", help="Machine name")
    get_p.add_argument("--version", default=None, help="Specific version")
    get_p.add_argument("--json", dest="output_json", action="store_true")
    get_p.add_argument("database_url", nargs="?", help="Database URL")

    # create
    create_p = sub.add_parser("create", help="Create a machine from YAML/JSON file")
    create_p.add_argument("path", help="Path to YAML/JSON config file")
    create_p.add_argument("database_url", nargs="?", help="Database URL")

    # delete
    delete_p = sub.add_parser("delete", help="Delete a machine version")
    delete_p.add_argument("name", help="Machine name")
    delete_p.add_argument("version", help="Version to delete")
    delete_p.add_argument("database_url", nargs="?", help="Database URL")

    # seed
    seed_p = sub.add_parser("seed", help="Seed machines from YAML directory")
    seed_p.add_argument("seed_dir", nargs="?", help="Directory with seed YAML files")
    seed_p.add_argument("database_url", nargs="?", help="Database URL")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "list": lambda: cmd_list(
            database_url=getattr(args, "database_url", None),
            name=getattr(args, "name", None),
        ),
        "get": lambda: cmd_get(
            name=args.name,
            version=getattr(args, "version", None),
            database_url=getattr(args, "database_url", None),
            output_json=getattr(args, "output_json", False),
        ),
        "create": lambda: cmd_create(
            path=args.path,
            database_url=getattr(args, "database_url", None),
        ),
        "delete": lambda: cmd_delete(
            name=args.name,
            version=args.version,
            database_url=getattr(args, "database_url", None),
        ),
        "seed": lambda: cmd_seed(
            seed_dir=getattr(args, "seed_dir", None),
            database_url=getattr(args, "database_url", None),
        ),
    }

    return commands.get(args.command, lambda: (parser.print_help(), 1)[1])()


if __name__ == "__main__":
    sys.exit(main())
