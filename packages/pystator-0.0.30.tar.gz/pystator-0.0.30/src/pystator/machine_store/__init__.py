"""Machine Store — pluggable persistence for FSM machine definitions.

Available implementations:
- InMemoryMachineStore: Dict-backed store for testing and development.
- SQLAlchemyMachineStore: PostgreSQL / SQLite via the machines table.
"""

from __future__ import annotations

from pystator.machine_store.client import MachineStoreClient
from pystator.machine_store.in_memory import InMemoryMachineStore

try:
    from pystator.machine_store._sqlalchemy import SQLAlchemyMachineStore
except ImportError:
    SQLAlchemyMachineStore = None  # type: ignore[assignment,misc]

__all__ = [
    "MachineStoreClient",
    "InMemoryMachineStore",
    "SQLAlchemyMachineStore",
]
