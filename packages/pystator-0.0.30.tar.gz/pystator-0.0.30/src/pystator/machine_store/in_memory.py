"""In-memory machine store for testing and embedded use."""

from __future__ import annotations

from pystator.machine_parser.types import MachineDefinition
from pystator.machine_store.client import MachineStoreClient


class InMemoryMachineStore(MachineStoreClient):
    """Dict-backed machine store for tests, notebooks, and embedded use.

    Does not require a database. Machines are stored in a dict keyed
    by (name, version).
    """

    def __init__(self) -> None:
        super().__init__(connection_string=None)
        self._machines: dict[tuple[str, str], MachineDefinition] = {}

    def connect(self) -> None:
        self._connection = True

    def disconnect(self) -> None:
        self._connection = None

    def save(self, definition: MachineDefinition) -> str:
        key = (definition.name, definition.version)
        self._machines[key] = definition
        return f"{definition.name}@{definition.version}"

    def get(self, name: str, version: str | None = None) -> MachineDefinition | None:
        if version is not None:
            return self._machines.get((name, version))
        # Latest version: sort by version string descending
        versions = [defn for (n, _v), defn in self._machines.items() if n == name]
        if not versions:
            return None
        versions.sort(key=lambda d: d.version, reverse=True)
        return versions[0]

    def list(self, name: str | None = None) -> list[MachineDefinition]:
        if name is not None:
            return [defn for (n, _v), defn in self._machines.items() if n == name]
        return list(self._machines.values())

    def delete(self, name: str, version: str) -> bool:
        key = (name, version)
        if key in self._machines:
            del self._machines[key]
            return True
        return False
