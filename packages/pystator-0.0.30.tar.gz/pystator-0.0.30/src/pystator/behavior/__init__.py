"""Behavioral extensions — guards, actions, declarative DSL, and sinks.

Re-exports the behavioral subsystem from their implementation modules:

- ``GuardRegistry`` / ``ActionRegistry`` — named-function registries
- ``ActionExecutor`` — runs post-transition actions
- Declarative checks and effects (YAML-only, no Python required)
- Built-in guards/actions and sink protocols
"""

from __future__ import annotations

from pystator.actions import (
    ACTION_PARAMS_KEY,
    ActionRegistry,
    ActionResult,
    ActionStatus,
    ExecutionMode,
    ExecutionResult,
)
from pystator.builtins import builtin_registries, register_builtins
from pystator.checks import evaluate_check
from pystator.effects import apply_effect
from pystator.guards import (
    GUARD_PARAMS_KEY,
    GuardRegistry,
    GuardResult,
    all_of,
    any_of,
    equals,
    greater_than,
    in_list,
    negate,
)
from pystator.sinks import (
    EventSink,
    LoggingEventSink,
    LoggingMetricSink,
    MetricSink,
    configure_event_sink,
    configure_metric_sink,
    create_metric_action,
    create_publish_action,
)

__all__ = [
    # Guards
    "GuardRegistry",
    "GuardResult",
    "GUARD_PARAMS_KEY",
    "all_of",
    "any_of",
    "equals",
    "greater_than",
    "in_list",
    "negate",
    # Actions
    "ActionRegistry",
    # ActionExecutor is now internal (_ActionExecutor); import from pystator.actions if needed
    "ActionResult",
    "ActionStatus",
    "ExecutionMode",
    "ExecutionResult",
    "ACTION_PARAMS_KEY",
    # Declarative
    "evaluate_check",
    "apply_effect",
    # Builtins
    "register_builtins",
    "builtin_registries",
    # Sinks
    "EventSink",
    "MetricSink",
    "LoggingEventSink",
    "LoggingMetricSink",
    "configure_event_sink",
    "configure_metric_sink",
    "create_publish_action",
    "create_metric_action",
]
