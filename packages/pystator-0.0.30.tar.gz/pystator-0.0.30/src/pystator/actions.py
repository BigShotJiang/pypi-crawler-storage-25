"""Action registry and executor for PyStator FSM.

Actions are functions executed AFTER a transition has been persisted.
They handle side effects like notifications, DB writes, etc.

This module merges the registry and executor into a single file.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import threading
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pystator._types import ActionSpec, TransitionResult
from pystator.errors import ActionNotFoundError, is_transient_error

logger = logging.getLogger(__name__)

# Key used to inject action parameters into context
ACTION_PARAMS_KEY = "_action_params"


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class ActionFunc(Protocol):
    """Synchronous action function protocol."""

    def __call__(self, context: dict[str, Any]) -> Any: ...


@runtime_checkable
class AsyncActionFunc(Protocol):
    """Asynchronous action function protocol."""

    def __call__(self, context: dict[str, Any]) -> Awaitable[Any]: ...


AnyActionFunc = (
    ActionFunc | AsyncActionFunc | Callable[[dict[str, Any]], Any | Awaitable[Any]]
)


# ---------------------------------------------------------------------------
# ActionResult
# ---------------------------------------------------------------------------


class ActionStatus(str, Enum):
    """Outcome status of an executed action."""

    OK = "ok"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ActionResult:
    """Result of action execution.

    Attributes:
        success: Whether the action executed successfully.
        action_name: Name of the action.
        result: Return value from the action (if any).
        error: Exception if action failed.
        status: Detailed status (ok, failed, skipped).
    """

    success: bool
    action_name: str
    result: Any = None
    error: Exception | None = None
    status: ActionStatus = ActionStatus.OK

    @classmethod
    def ok(cls, action_name: str, result: Any = None) -> ActionResult:
        """Create a successful action result.

        Args:
            action_name: Name of the action that succeeded.
            result: Optional return value from the action.

        Returns:
            ActionResult with ``success=True``.
        """
        return cls(
            success=True, action_name=action_name, result=result, status=ActionStatus.OK
        )

    @classmethod
    def fail(cls, action_name: str, error: Exception) -> ActionResult:
        """Create a failed action result with error detail.

        Args:
            action_name: Name of the action that failed.
            error: The exception that caused the failure.

        Returns:
            ActionResult with ``success=False``.
        """
        return cls(
            success=False,
            action_name=action_name,
            error=error,
            status=ActionStatus.FAILED,
        )

    @classmethod
    def skipped(cls, action_name: str, reason: str = "") -> ActionResult:
        """Create a skipped action result.

        Args:
            action_name: Name of the action that was skipped.
            reason: Human-readable reason for skipping.

        Returns:
            ActionResult with ``status=SKIPPED``.
        """
        return cls(
            success=True,
            action_name=action_name,
            result=reason or "not_registered",
            status=ActionStatus.SKIPPED,
        )

    @property
    def is_skipped(self) -> bool:
        return self.status == ActionStatus.SKIPPED


# ---------------------------------------------------------------------------
# ExecutionMode / ExecutionResult
# ---------------------------------------------------------------------------


class ExecutionMode(str, Enum):
    """Strategy for executing multiple actions."""

    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    PHASED = "phased"


@dataclass
class ExecutionResult:
    """Result of executing all actions from a transition."""

    transition_result: TransitionResult
    action_results: list[ActionResult] = field(default_factory=list)
    execution_mode: ExecutionMode = ExecutionMode.SEQUENTIAL
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    completed_at: datetime | None = None

    @property
    def all_succeeded(self) -> bool:
        return all(r.success for r in self.action_results)

    @property
    def failed_actions(self) -> list[str]:
        return [r.action_name for r in self.action_results if not r.success]

    @property
    def succeeded_actions(self) -> list[str]:
        return [r.action_name for r in self.action_results if r.success]

    @property
    def action_count(self) -> int:
        return len(self.action_results)

    @property
    def duration_ms(self) -> float | None:
        if self.completed_at is None:
            return None
        return (self.completed_at - self.started_at).total_seconds() * 1000


# ---------------------------------------------------------------------------
# ActionRegistry
# ---------------------------------------------------------------------------


class ActionRegistry:
    """Registry for action functions (sync and async).

    Example:
        >>> registry = ActionRegistry()
        >>> registry.register("notify", lambda ctx: print("notified"))
        >>> registry.execute("notify", {"user": "alice"})
    """

    def __init__(self) -> None:
        self._actions: dict[str, AnyActionFunc] = {}
        self._metadata: dict[str, dict[str, Any]] = {}
        self._async_actions: set[str] = set()
        self._accepts_kwargs: set[str] = set()
        self._lock = threading.Lock()

    def register(
        self,
        name: str,
        func: AnyActionFunc,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Register an action function. Thread-safe.

        Re-registration replaces the existing action (allows overriding builtins).
        If the function accepts keyword arguments beyond ``ctx``, parameters
        from the action spec are passed as ``**kwargs`` instead of injected
        into the context dict.
        """
        if not name:
            raise ValueError("Action name cannot be empty")
        with self._lock:
            self._actions[name] = func
            self._metadata[name] = metadata or {}
            if asyncio.iscoroutinefunction(func) or (
                callable(func)
                and asyncio.iscoroutinefunction(getattr(func, "__call__", None))  # noqa: B004
            ):
                self._async_actions.add(name)
            else:
                self._async_actions.discard(name)
            # Introspect: does the function accept extra keyword args?
            try:
                sig = inspect.signature(func)
                has_extra = any(
                    p.kind
                    in (
                        inspect.Parameter.KEYWORD_ONLY,
                        inspect.Parameter.VAR_KEYWORD,
                    )
                    for p in sig.parameters.values()
                )
                if has_extra:
                    self._accepts_kwargs.add(name)
                else:
                    self._accepts_kwargs.discard(name)
            except (ValueError, TypeError):
                self._accepts_kwargs.discard(name)

    def accepts_kwargs(self, name: str) -> bool:
        """Return True if the named action accepts keyword arguments."""
        return name in self._accepts_kwargs

    def unregister(self, name: str) -> None:
        """Unregister an action function. Thread-safe."""
        with self._lock:
            if name not in self._actions:
                raise ActionNotFoundError(
                    f"Action '{name}' not found", action_name=name
                )
            del self._actions[name]
            del self._metadata[name]
            self._async_actions.discard(name)

    def get(self, name: str) -> AnyActionFunc:
        """Look up a registered action callable by name.

        Args:
            name: The registered action name.

        Returns:
            The action callable.

        Raises:
            ActionNotFoundError: If no action is registered under *name*.
        """
        if name not in self._actions:
            raise ActionNotFoundError(f"Action '{name}' not found", action_name=name)
        return self._actions[name]

    def has(self, name: str) -> bool:
        """Check whether an action is registered."""
        return name in self._actions

    def get_metadata(self, name: str) -> dict[str, Any]:
        """Get metadata for a registered action."""
        return dict(self._metadata.get(name, {}))

    def is_async(self, name: str) -> bool:
        """Return True if the named action is an async function."""
        return name in self._async_actions

    def execute(
        self, name: str, context: dict[str, Any], raise_on_error: bool = False
    ) -> ActionResult:
        """Execute a single named action synchronously.

        Args:
            name: Registered action name.
            context: Context dict passed to the action callable.
            raise_on_error: If True, re-raise exceptions instead of wrapping.

        Returns:
            ActionResult indicating success or failure.
        """
        func = self.get(name)
        try:
            result = func(context)
            return ActionResult.ok(name, result)
        except Exception as e:
            if raise_on_error:
                raise
            return ActionResult.fail(name, e)

    def execute_all(
        self,
        actions: tuple[str, ...] | list[str],
        context: dict[str, Any],
        stop_on_error: bool = False,
    ) -> list[ActionResult]:
        """Execute multiple actions with stop-on-error control.

        Args:
            actions: Sequence of action names to execute.
            context: Context dict passed to each action.
            stop_on_error: If True, halt after the first failure.

        Returns:
            List of ActionResult in execution order.
        """
        results: list[ActionResult] = []
        for action_name in actions:
            try:
                result = self.execute(action_name, context)
                results.append(result)
                if not result.success and stop_on_error:
                    break
            except ActionNotFoundError as e:
                results.append(ActionResult.fail(action_name, e))
                if stop_on_error:
                    break
        return results

    async def async_execute(
        self, name: str, context: dict[str, Any], raise_on_error: bool = False
    ) -> ActionResult:
        """Execute a single named action asynchronously.

        Falls back to synchronous execution if the action is not async.

        Args:
            name: Registered action name.
            context: Context dict passed to the action callable.
            raise_on_error: If True, re-raise exceptions instead of wrapping.

        Returns:
            ActionResult indicating success or failure.
        """
        func = self.get(name)
        try:
            if self.is_async(name):
                result = await func(context)  # type: ignore[misc]
            else:
                result = func(context)
            return ActionResult.ok(name, result)
        except Exception as e:
            if raise_on_error:
                raise
            return ActionResult.fail(name, e)

    async def async_execute_all(
        self,
        actions: tuple[str, ...] | list[str],
        context: dict[str, Any],
        stop_on_error: bool = False,
    ) -> list[ActionResult]:
        """Execute multiple actions asynchronously.

        Args:
            actions: Sequence of action names to execute.
            context: Context dict passed to each action.
            stop_on_error: If True, halt after the first failure.

        Returns:
            List of ActionResult in execution order.
        """
        results: list[ActionResult] = []
        for action_name in actions:
            try:
                result = await self.async_execute(action_name, context)
                results.append(result)
                if not result.success and stop_on_error:
                    break
            except ActionNotFoundError as e:
                results.append(ActionResult.fail(action_name, e))
                if stop_on_error:
                    break
        return results

    def list_actions(self) -> list[str]:
        """Return all registered action names."""
        return list(self._actions.keys())

    def clear(self) -> None:
        """Remove all registered actions."""
        self._actions.clear()
        self._metadata.clear()
        self._async_actions.clear()

    def __len__(self) -> int:
        """Return the number of registered actions."""
        return len(self._actions)

    def __contains__(self, name: str) -> bool:
        """Check whether an action name is registered."""
        return name in self._actions

    def decorator(
        self,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Callable[[AnyActionFunc], AnyActionFunc]:
        """Decorator to register an action function.

        Example:
            >>> @registry.decorator()
            ... def notify_user(ctx: dict) -> None:
            ...     send_email(ctx["user_email"], "Order updated")
        """

        def inner(func: AnyActionFunc) -> AnyActionFunc:
            self.register(name or func.__name__, func, metadata)
            return func

        return inner


# ---------------------------------------------------------------------------
# Declarative effect execution (no registry lookup)
# ---------------------------------------------------------------------------


def _execute_effect(
    action_name: str,
    params: dict[str, Any],
    context: dict[str, Any],
) -> ActionResult:
    """Execute a declarative effect, returning an ActionResult."""
    from pystator.effects import apply_effect

    effect_type = action_name[8:]  # strip "_effect."
    try:
        apply_effect(effect_type, params, context)
        return ActionResult.ok(action_name)
    except Exception as e:
        return ActionResult.fail(action_name, e)


# ---------------------------------------------------------------------------
# Action Executor (internal)
# ---------------------------------------------------------------------------


class _ActionExecutor:
    """Executes actions from transition results.

    Internal implementation — the Orchestrator creates this automatically.
    Supports sequential, parallel, and phased execution modes.

    Example:
        >>> executor = _ActionExecutor(action_registry)
        >>> execution = executor.execute(transition_result, context)
    """

    def __init__(
        self,
        registry: ActionRegistry,
        stop_on_error: bool = False,
        log_execution: bool = True,
        default_mode: ExecutionMode = ExecutionMode.SEQUENTIAL,
        strict: bool = False,
    ) -> None:
        """Initialize the action executor.

        Args:
            registry: ActionRegistry containing the action callables.
            stop_on_error: If True, halt batch execution on first failure.
            log_execution: If True, log action skips and errors.
            default_mode: Default execution mode for batches.
            strict: If True, raise on missing actions instead of skipping.
        """
        self.registry = registry
        self.stop_on_error = stop_on_error
        self.log_execution = log_execution
        self.default_mode = default_mode
        self.strict = strict

    def execute(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute all actions from a transition result sequentially."""
        result = ExecutionResult(
            transition_result=transition_result,
            started_at=datetime.now(UTC),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(UTC)
            return result

        for spec in transition_result.all_action_specs:
            action_result = self._execute_single(
                spec.name,
                context,
                spec.params if spec.has_params else None,
                retry=spec.retry,
                retry_backoff=spec.retry_backoff,
            )
            result.action_results.append(action_result)
            if not action_result.success and self.stop_on_error:
                break

        result.completed_at = datetime.now(UTC)
        return result

    def execute_specific(
        self,
        action_names: list[str] | tuple[str, ...],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Execute specific actions by name sequentially."""
        results: list[ActionResult] = []
        for name in action_names:
            results.append(self._execute_single(name, context, None))
        return results

    def validate_actions_exist(self, transition_result: TransitionResult) -> list[str]:
        """Return list of action names that are not registered."""
        missing: list[str] = []
        for spec in transition_result.all_action_specs:
            if spec.name.startswith("_effect.") or spec.name == "_http":
                continue  # Declarative effects and HTTP actions don't need registry
            if not self.registry.has(spec.name):
                missing.append(spec.name)
        return missing

    @staticmethod
    def _evaluate_when(when: Any, context: dict[str, Any]) -> bool:
        """Evaluate a ``when`` condition (CheckSpec or expression string)."""
        if isinstance(when, str):
            from pystator._expr import evaluate_bool_expr

            return evaluate_bool_expr(when, context)
        from pystator.checks import evaluate_check

        return evaluate_check(when, context)

    def execute_action_spec(
        self, action: ActionSpec, context: dict[str, Any]
    ) -> ActionResult:
        """Execute a single ActionSpec synchronously."""
        # Conditional: skip if when clause evaluates to False
        if action.when is not None and not self._evaluate_when(action.when, context):
            return ActionResult.skipped(action.name, "when_condition_false")
        # HTTP action: delegate to http_action module
        if action.name == "_http":
            from pystator.http_action import execute_http_action

            return execute_http_action(action.params, context)
        return self._execute_single(
            action.name,
            context,
            action.params if action.has_params else None,
            retry=action.retry,
            retry_backoff=action.retry_backoff,
        )

    def execute_action_specs(
        self,
        actions: tuple[ActionSpec, ...] | list[ActionSpec],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Execute multiple ActionSpecs sequentially."""
        results: list[ActionResult] = []
        for action in actions:
            result = self.execute_action_spec(action, context)
            results.append(result)
            if not result.success and self.stop_on_error:
                break
        return results

    def _prepare_action(
        self,
        action_name: str,
        context: dict[str, Any],
        params: dict[str, Any] | None,
    ) -> ActionResult | None:
        """Handle effects and missing-action checks.

        Returns an ActionResult if execution is complete (effect or skip),
        or None to signal that the caller should proceed with registry execution.
        """
        if action_name.startswith("_effect."):
            return _execute_effect(action_name, params or {}, context)

        if not self.registry.has(action_name):
            if self.strict:
                raise ActionNotFoundError(
                    f"Action '{action_name}' not registered (strict mode)",
                    action_name=action_name,
                )
            if self.log_execution:
                logger.warning("Action '%s' not registered, skipping", action_name)
            return ActionResult.skipped(action_name, "not_registered")
        return None

    def _execute_single(
        self,
        action_name: str,
        context: dict[str, Any],
        params: dict[str, Any] | None = None,
        retry: int = 0,
        retry_backoff: float = 1.0,
    ) -> ActionResult:
        """Execute a single action synchronously with optional retry."""
        prepared = self._prepare_action(action_name, context, params)
        if prepared is not None:
            return prepared

        import time as _time

        last_result: ActionResult | None = None
        attempts = 1 + max(retry, 0)

        for attempt in range(attempts):
            if attempt > 0:
                delay = retry_backoff * (2 ** (attempt - 1))
                _time.sleep(delay)

            try:
                if params and self.registry.accepts_kwargs(action_name):
                    # Pass params as explicit keyword arguments
                    func = self.registry.get(action_name)
                    raw = func(context, **params)  # type: ignore[call-arg]
                    result = ActionResult.ok(action_name, raw)
                elif params:
                    # Legacy: inject params into context
                    context[ACTION_PARAMS_KEY] = params
                    try:
                        result = self.registry.execute(action_name, context)
                    finally:
                        context.pop(ACTION_PARAMS_KEY, None)
                else:
                    result = self.registry.execute(action_name, context)

                if result.success or attempt == attempts - 1:
                    return result
                # Skip retries for permanent (non-transient) errors
                if result.error is not None and not is_transient_error(result.error):
                    if self.log_execution:
                        logger.info(
                            "Action '%s' failed with permanent error, skipping retries",
                            action_name,
                        )
                    return result
                last_result = result
            except Exception as e:
                if self.log_execution:
                    logger.exception("Action '%s' raised exception: %s", action_name, e)
                last_result = ActionResult.fail(action_name, e)
                if not is_transient_error(e):
                    return last_result
                if attempt == attempts - 1:
                    return last_result

        return last_result or ActionResult.fail(
            action_name, RuntimeError("Unexpected retry exhaustion")
        )

    # ------------------------------------------------------------------
    # Async execution
    # ------------------------------------------------------------------

    async def async_execute(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute all actions asynchronously in sequential order."""
        result = ExecutionResult(
            transition_result=transition_result,
            started_at=datetime.now(UTC),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(UTC)
            return result

        for spec in transition_result.all_action_specs:
            ar = await self._async_execute_single(
                spec.name,
                context,
                spec.params if spec.has_params else None,
                timeout=spec.timeout,
                retry=spec.retry,
                retry_backoff=spec.retry_backoff,
            )
            result.action_results.append(ar)
            if not ar.success and self.stop_on_error:
                break

        result.completed_at = datetime.now(UTC)
        return result

    async def async_execute_parallel(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute all actions concurrently using asyncio.gather."""
        result = ExecutionResult(
            transition_result=transition_result,
            execution_mode=ExecutionMode.PARALLEL,
            started_at=datetime.now(UTC),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(UTC)
            return result

        specs = transition_result.all_action_specs
        if specs:
            tasks = [
                self._async_execute_single(
                    s.name,
                    context,
                    s.params if s.has_params else None,
                    timeout=s.timeout,
                    retry=s.retry,
                    retry_backoff=s.retry_backoff,
                )
                for s in specs
            ]
            result.action_results = list(await asyncio.gather(*tasks))

        result.completed_at = datetime.now(UTC)
        return result

    async def async_execute_phased(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute actions in phases: exit -> transition -> enter (each parallel)."""
        result = ExecutionResult(
            transition_result=transition_result,
            execution_mode=ExecutionMode.PHASED,
            started_at=datetime.now(UTC),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(UTC)
            return result

        phases = [
            transition_result.on_exit_actions,
            transition_result.actions_to_execute,
            transition_result.on_enter_actions,
        ]
        all_results: list[ActionResult] = []
        for phase_specs in phases:
            if not phase_specs:
                continue
            tasks = [
                self._async_execute_single(
                    s.name,
                    context,
                    s.params if s.has_params else None,
                    timeout=s.timeout,
                    retry=s.retry,
                    retry_backoff=s.retry_backoff,
                )
                for s in phase_specs
            ]
            phase_results = await asyncio.gather(*tasks)
            all_results.extend(phase_results)
            if self.stop_on_error and any(not r.success for r in phase_results):
                break

        result.action_results = all_results
        result.completed_at = datetime.now(UTC)
        return result

    async def async_execute_with_mode(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
        mode: ExecutionMode = ExecutionMode.SEQUENTIAL,
    ) -> ExecutionResult:
        """Execute with explicit mode (sequential, parallel, or phased)."""
        if mode == ExecutionMode.PARALLEL:
            return await self.async_execute_parallel(transition_result, context)
        if mode == ExecutionMode.PHASED:
            return await self.async_execute_phased(transition_result, context)
        return await self.async_execute(transition_result, context)

    async def async_execute_specific_parallel(
        self,
        action_names: list[str] | tuple[str, ...],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Execute specific actions in parallel by name."""
        if not action_names:
            return []
        tasks = [
            self._async_execute_single(name, context, None) for name in action_names
        ]
        return list(await asyncio.gather(*tasks))

    async def async_execute_action_spec(
        self,
        action: ActionSpec,
        context: dict[str, Any],
    ) -> ActionResult:
        """Async execute a single ActionSpec."""
        return await self._async_execute_single(
            action.name,
            context,
            action.params if action.has_params else None,
            timeout=action.timeout,
            retry=action.retry,
            retry_backoff=action.retry_backoff,
        )

    async def async_execute_action_specs_parallel(
        self,
        actions: tuple[ActionSpec, ...] | list[ActionSpec],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Async execute multiple ActionSpecs in parallel."""
        if not actions:
            return []
        tasks = [self.async_execute_action_spec(a, context) for a in actions]
        return list(await asyncio.gather(*tasks))

    async def _async_execute_single(
        self,
        action_name: str,
        context: dict[str, Any],
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
        retry: int = 0,
        retry_backoff: float = 1.0,
    ) -> ActionResult:
        """Execute a single action asynchronously with optional timeout and retry."""
        prepared = self._prepare_action(action_name, context, params)
        if prepared is not None:
            return prepared

        last_result: ActionResult | None = None
        attempts = 1 + max(retry, 0)

        for attempt in range(attempts):
            if attempt > 0:
                delay = retry_backoff * (2 ** (attempt - 1))
                await asyncio.sleep(delay)

            try:
                if params and self.registry.accepts_kwargs(action_name):
                    func = self.registry.get(action_name)
                    if self.registry.is_async(action_name):
                        raw = await func(context, **params)  # type: ignore[call-arg,misc]
                    else:
                        raw = func(context, **params)  # type: ignore[call-arg]
                    result = ActionResult.ok(action_name, raw)
                elif params:
                    context[ACTION_PARAMS_KEY] = params
                    try:
                        coro = self.registry.async_execute(action_name, context)
                        if timeout is not None:
                            result = await asyncio.wait_for(coro, timeout=timeout)
                        else:
                            result = await coro
                    finally:
                        context.pop(ACTION_PARAMS_KEY, None)
                else:
                    coro = self.registry.async_execute(action_name, context)
                    if timeout is not None:
                        result = await asyncio.wait_for(coro, timeout=timeout)
                    else:
                        result = await coro

                if result.success or attempt == attempts - 1:
                    return result
                # Skip retries for permanent (non-transient) errors
                if result.error is not None and not is_transient_error(result.error):
                    if self.log_execution:
                        logger.info(
                            "Action '%s' failed with permanent error, skipping retries",
                            action_name,
                        )
                    return result
                last_result = result
            except TimeoutError:
                last_result = ActionResult.fail(
                    action_name,
                    TimeoutError(f"Action '{action_name}' timed out after {timeout}s"),
                )
                # TimeoutError is transient, allow retry
                if attempt == attempts - 1:
                    return last_result
            except Exception as e:
                if self.log_execution:
                    logger.exception("Action '%s' raised exception: %s", action_name, e)
                last_result = ActionResult.fail(action_name, e)
                if not is_transient_error(e):
                    return last_result
                if attempt == attempts - 1:
                    return last_result

        return last_result or ActionResult.fail(
            action_name, RuntimeError("Unexpected retry exhaustion")
        )


# Public alias kept for direct imports (e.g. from tests or advanced usage).
# Not exported from pystator top-level — use Orchestrator for typical workflows.
ActionExecutor = _ActionExecutor
