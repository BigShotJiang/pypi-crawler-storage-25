"""Machine Parser — parse FSM config files and dicts into MachineDefinition.

Reads YAML/JSON machine configs, resolves submachines, validates structure,
and produces a canonical MachineDefinition suitable for storage or building.
"""

from __future__ import annotations

from pystator.machine_parser.parser import parse_machine, parse_machine_file
from pystator.machine_parser.types import MachineDefinition

__all__ = [
    "MachineDefinition",
    "parse_machine",
    "parse_machine_file",
]
