"""Canonical type for a parsed FSM machine definition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class MachineDefinition:
    """A fully parsed and validated FSM machine definition.

    Analogous to PyCharter's ContractMetadata — the single canonical
    representation that flows between parser, store, and builder.

    Attributes:
        name: Machine name (lowercase, underscores only).
        version: Semantic version string.
        config: Full validated config dict (round-trip safe for persistence).
        states: List of state definition dicts from config.
        transitions: List of transition definition dicts from config.
        description: Human-readable description.
        strict_mode: Whether the machine enforces strict mode.
    """

    name: str
    version: str
    config: dict[str, Any]
    states: list[dict[str, Any]] = field(default_factory=list)
    transitions: list[dict[str, Any]] = field(default_factory=list)
    description: str | None = None
    strict_mode: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Return the full config dict (same as what gets persisted)."""
        return dict(self.config)

    def to_state_machine(self) -> Any:
        """Build a StateMachine from this definition (no guards/actions bound).

        Returns a pystator.machine.StateMachine. Import is deferred to
        avoid circular dependencies.
        """
        from pystator.machine import StateMachine

        return StateMachine.from_dict(self.config)
