"""Entity ID validation utilities.

Enforces naming conventions for entity identifiers.
Allowed: alphanumeric start, then alphanumeric + dots + hyphens + underscores, 1-255 chars.
Case-sensitive (unlike name_validator which lowercases).
"""

from __future__ import annotations

import re

# Pattern: alphanumeric start, then alphanumeric + dots + hyphens + underscores
ENTITY_ID_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,254}$")

# Error message template
ENTITY_ID_ERROR_MESSAGE = (
    "must start with an alphanumeric character and contain only "
    "letters (a-z, A-Z), numbers (0-9), dots (.), hyphens (-), "
    "and underscores (_). Length: 1-255 characters."
)


def validate_entity_id(entity_id: str, field_name: str = "entity_id") -> str:
    """Validate entity ID format.

    Args:
        entity_id: The entity ID to validate.
        field_name: The field name for error messages.

    Returns:
        The validated entity ID (whitespace-stripped).

    Raises:
        ValueError: If the entity ID doesn't match the pattern.
    """
    if not isinstance(entity_id, str):
        raise ValueError(f"{field_name} must be a string")

    stripped = entity_id.strip()

    if not stripped:
        raise ValueError(f"{field_name} cannot be empty")

    if not ENTITY_ID_PATTERN.match(stripped):
        raise ValueError(f"{field_name} {ENTITY_ID_ERROR_MESSAGE} Got: '{entity_id}'")

    return stripped


def is_valid_entity_id(entity_id: str) -> bool:
    """Check if an entity ID is valid without raising.

    Args:
        entity_id: The entity ID to check.

    Returns:
        True if valid, False otherwise.
    """
    try:
        validate_entity_id(entity_id)
    except (ValueError, TypeError):
        return False
    return True


def normalize_entity_id(entity_id: str) -> str | None:
    """Normalize an entity ID: strip whitespace, remove invalid characters.

    Attempts to convert invalid entity IDs to valid ones by:
    - Stripping leading/trailing whitespace
    - Removing characters that aren't alphanumeric, dots, hyphens, or underscores
    - Stripping leading non-alphanumeric characters

    Args:
        entity_id: The entity ID to normalize.

    Returns:
        Normalized entity ID, or None if normalization produces an empty result.
    """
    if not isinstance(entity_id, str) or not entity_id:
        return None

    stripped = entity_id.strip()

    # Remove characters that aren't allowed
    normalized = re.sub(r"[^a-zA-Z0-9._-]", "", stripped)

    # Strip leading non-alphanumeric characters
    normalized = re.sub(r"^[^a-zA-Z0-9]+", "", normalized)

    if not normalized:
        return None

    # Truncate to 255 chars
    return normalized[:255]
