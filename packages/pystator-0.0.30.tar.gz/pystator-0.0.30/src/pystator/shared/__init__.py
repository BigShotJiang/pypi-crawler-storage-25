"""Shared utilities used across pystator modules."""

from __future__ import annotations
