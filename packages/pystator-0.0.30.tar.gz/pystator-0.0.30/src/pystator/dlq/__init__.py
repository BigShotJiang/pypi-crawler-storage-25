"""Dead Letter Queue (DLQ) subpackage.

Provides a protocol-based, backend-agnostic dead letter queue with
support for in-memory, database (PostgreSQL/SQLite), and file-based
storage, plus automatic retry, TTL cleanup, and pagination.

Public API::

    from pystator.dlq import (
        # Core types
        DeadLetterRecord,
        DLQStatus,
        QueryResult,
        DLQStatistics,
        # Protocol
        DeadLetterStore,
        RetryHandler,
        # Backends
        InMemoryDeadLetterStore,
        DatabaseDeadLetterStore,
        FileDeadLetterStore,
        validate_table_name,
        # Retry
        RetryPolicy,
        BackoffStrategy,
        RetryEngine,
        RetryResult,
        # TTL
        RetentionPolicy,
        TTLCleaner,
        CleanupResult,
        # Config
        DLQConfig,
        RetryConfig,
        RetentionConfig,
        create_store,
        # Sync wrapper
        SyncDeadLetterStore,
        # Errors
        DLQError,
        RecordNotFoundError,
        StoreError,
        ConfigError,
    )
"""

from __future__ import annotations

from pystator.dlq._config import (
    DLQConfig,
    RetentionConfig,
    RetryConfig,
    create_store,
)
from pystator.dlq._errors import ConfigError, DLQError, RecordNotFoundError, StoreError
from pystator.dlq._protocols import DeadLetterStore, RetryHandler
from pystator.dlq._retry import (
    BackoffStrategy,
    RetryEngine,
    RetryPolicy,
    RetryResult,
)
from pystator.dlq._sync import SyncDeadLetterStore
from pystator.dlq._ttl import CleanupResult, RetentionPolicy, TTLCleaner
from pystator.dlq._types import DeadLetterRecord, DLQStatistics, DLQStatus, QueryResult
from pystator.dlq.database_store import DatabaseDeadLetterStore, validate_table_name
from pystator.dlq.file_store import FileDeadLetterStore
from pystator.dlq.memory_store import InMemoryDeadLetterStore

__all__ = [
    # Core types
    "DeadLetterRecord",
    "DLQStatus",
    "QueryResult",
    "DLQStatistics",
    # Protocol
    "DeadLetterStore",
    "RetryHandler",
    # Backends
    "InMemoryDeadLetterStore",
    "DatabaseDeadLetterStore",
    "FileDeadLetterStore",
    "validate_table_name",
    # Retry
    "RetryPolicy",
    "BackoffStrategy",
    "RetryEngine",
    "RetryResult",
    # TTL
    "RetentionPolicy",
    "TTLCleaner",
    "CleanupResult",
    # Config
    "DLQConfig",
    "RetryConfig",
    "RetentionConfig",
    "create_store",
    # Sync wrapper
    "SyncDeadLetterStore",
    # Errors
    "DLQError",
    "RecordNotFoundError",
    "StoreError",
    "ConfigError",
]
