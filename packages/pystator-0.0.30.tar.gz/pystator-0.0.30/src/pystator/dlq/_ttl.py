"""TTL-based cleanup for dead-lettered records.

Provides a retention policy and a cleaner that periodically purges
expired and old resolved records from the store.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pystator.dlq._protocols import DeadLetterStore

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RetentionPolicy:
    """Configuration for automatic DLQ record cleanup.

    Attributes:
        ttl_seconds: Time-to-live for pending records.  ``None`` disables
            TTL-based expiry.  When set, new records should have their
            ``expires_at`` computed as ``created_at + ttl_seconds``.
        resolved_retention_seconds: How long to keep resolved records
            before purging.  Defaults to 7 days.
        cleanup_interval_seconds: How often the cleaner loop runs.
            Defaults to 1 hour.
    """

    ttl_seconds: int | None = None
    resolved_retention_seconds: int = 604_800  # 7 days
    cleanup_interval_seconds: float = 3600.0  # 1 hour


@dataclass(frozen=True, slots=True)
class CleanupResult:
    """Summary of a single cleanup pass.

    Attributes:
        expired_purged: Number of TTL-expired records removed.
        resolved_purged: Number of old resolved records removed.
    """

    expired_purged: int = 0
    resolved_purged: int = 0


class TTLCleaner:
    """Periodically purges expired and old resolved records.

    Args:
        store: The dead letter store to clean.
        policy: Retention policy controlling TTL and resolved retention.
    """

    def __init__(
        self,
        store: DeadLetterStore,
        policy: RetentionPolicy,
    ) -> None:
        self._store = store
        self._policy = policy

    async def cleanup_once(self) -> CleanupResult:
        """Run a single cleanup pass.

        Returns:
            A :class:`CleanupResult` with counts of purged records.
        """
        expired_purged = 0
        resolved_purged = 0

        # Purge TTL-expired records
        if self._policy.ttl_seconds is not None:
            expired_purged = await self._store.purge_expired()

        # Purge old resolved records
        cutoff = datetime.now(UTC) - timedelta(
            seconds=self._policy.resolved_retention_seconds
        )
        resolved_purged = await self._store.purge_resolved(older_than=cutoff)

        if expired_purged > 0 or resolved_purged > 0:
            logger.info(
                "DLQ cleanup: expired=%s resolved=%s",
                expired_purged,
                resolved_purged,
            )

        return CleanupResult(
            expired_purged=expired_purged,
            resolved_purged=resolved_purged,
        )

    async def run_loop(self) -> None:
        """Run cleanup passes in a loop at the configured interval.

        This is intended to be launched as an ``asyncio.Task`` in a worker
        process.  It runs indefinitely until the task is cancelled.
        """
        interval = self._policy.cleanup_interval_seconds
        logger.info(
            "DLQ TTL cleaner started (interval=%ss, ttl=%s, resolved_retention=%ss)",
            interval,
            self._policy.ttl_seconds,
            self._policy.resolved_retention_seconds,
        )
        while True:
            try:
                await self.cleanup_once()
            except Exception:
                logger.exception("DLQ cleanup pass failed")
            await asyncio.sleep(interval)
