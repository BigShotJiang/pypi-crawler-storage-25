"""Synchronous wrapper for async DeadLetterStore implementations.

Provides ``SyncDeadLetterStore`` which delegates every call to an
underlying async store via ``asyncio.run()`` at the boundary.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import TYPE_CHECKING

from pystator.dlq._types import DeadLetterRecord, DLQStatistics, DLQStatus, QueryResult

if TYPE_CHECKING:
    from pystator.dlq._protocols import DeadLetterStore


class SyncDeadLetterStore:
    """Synchronous facade over an async :class:`DeadLetterStore`.

    Each method calls ``asyncio.run()`` to execute the underlying async
    operation.  This is intended for use in synchronous code paths (CLIs,
    scripts, synchronous pipeline steps) where an event loop is not
    already running.

    Args:
        store: The async store to wrap.
    """

    def __init__(self, store: DeadLetterStore) -> None:
        self._store = store

    def add(self, record: DeadLetterRecord) -> None:
        """Add a dead letter record.

        Args:
            record: The record to store.
        """
        asyncio.run(self._store.add(record))

    def add_batch(self, records: list[DeadLetterRecord]) -> int:
        """Add multiple records.

        Args:
            records: Records to store.

        Returns:
            Number of records actually inserted.
        """
        return asyncio.run(self._store.add_batch(records))

    def get(self, record_id: str) -> DeadLetterRecord | None:
        """Retrieve a single record by ID.

        Args:
            record_id: The unique record identifier.

        Returns:
            The record if found, or ``None``.
        """
        return asyncio.run(self._store.get(record_id))

    def query(
        self,
        *,
        source_name: str | None = None,
        reason: str | None = None,
        stage: str | None = None,
        status: DLQStatus | None = None,
        limit: int = 100,
        offset: int = 0,
        cursor: str | None = None,
    ) -> QueryResult:
        """Query records with optional filters and pagination.

        Args:
            source_name: Filter by source name.
            reason: Filter by reason string.
            stage: Filter by processing stage.
            status: Filter by lifecycle status.
            limit: Maximum records per page.
            offset: Number of records to skip.
            cursor: Opaque cursor for keyset pagination.

        Returns:
            A :class:`QueryResult` with the matching page.
        """
        return asyncio.run(
            self._store.query(
                source_name=source_name,
                reason=reason,
                stage=stage,
                status=status,
                limit=limit,
                offset=offset,
                cursor=cursor,
            )
        )

    def mark_retry(self, record_id: str) -> bool:
        """Mark a record as retrying.

        Args:
            record_id: The record to mark.

        Returns:
            ``True`` if the record was found and updated.
        """
        return asyncio.run(self._store.mark_retry(record_id))

    def resolve(self, record_id: str) -> bool:
        """Mark a record as resolved.

        Args:
            record_id: The record to resolve.

        Returns:
            ``True`` if the record was found and updated.
        """
        return asyncio.run(self._store.resolve(record_id))

    def ignore(self, record_id: str) -> bool:
        """Mark a record as permanently ignored.

        Args:
            record_id: The record to ignore.

        Returns:
            ``True`` if the record was found and updated.
        """
        return asyncio.run(self._store.ignore(record_id))

    def statistics(
        self,
        source_name: str | None = None,
    ) -> DLQStatistics:
        """Get aggregate statistics.

        Args:
            source_name: Optional filter by source name.

        Returns:
            A :class:`DLQStatistics` instance.
        """
        return asyncio.run(self._store.statistics(source_name))

    def purge_expired(self) -> int:
        """Delete TTL-expired records.

        Returns:
            Number of records removed.
        """
        return asyncio.run(self._store.purge_expired())

    def purge_resolved(
        self,
        older_than: datetime | None = None,
    ) -> int:
        """Delete old resolved records.

        Args:
            older_than: If provided, only delete resolved records created
                before this timestamp.

        Returns:
            Number of records removed.
        """
        return asyncio.run(self._store.purge_resolved(older_than))
