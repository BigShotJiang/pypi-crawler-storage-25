"""DLQ store and retry handler protocols.

Defines the async interface that all storage backends must implement,
plus the retry handler protocol for automatic reprocessing.
"""

from __future__ import annotations

from datetime import datetime
from typing import Protocol, runtime_checkable

from pystator.dlq._types import (
    DeadLetterRecord,
    DLQStatistics,
    DLQStatus,
    QueryResult,
)


@runtime_checkable
class DeadLetterStore(Protocol):
    """Async protocol for dead letter queue storage backends.

    Implementations must support adding records, querying with pagination,
    mutating status, collecting statistics, and TTL-based cleanup.
    """

    async def add(self, record: DeadLetterRecord) -> None:
        """Add a dead letter record to the store.

        Args:
            record: The record to store.  Duplicate ``record_id`` values
                should be silently ignored (idempotent).
        """
        ...

    async def add_batch(self, records: list[DeadLetterRecord]) -> int:
        """Add multiple records in a single operation.

        Args:
            records: Records to store.

        Returns:
            Number of records actually inserted (excluding duplicates).
        """
        ...

    async def get(self, record_id: str) -> DeadLetterRecord | None:
        """Retrieve a single record by ID.

        Args:
            record_id: The unique record identifier.

        Returns:
            The record if found, or ``None``.
        """
        ...

    async def query(
        self,
        *,
        source_name: str | None = None,
        reason: str | None = None,
        stage: str | None = None,
        status: DLQStatus | None = None,
        limit: int = 100,
        offset: int = 0,
        cursor: str | None = None,
    ) -> QueryResult:
        """Query records with optional filters and pagination.

        Results are ordered newest-first (``created_at DESC``).

        Args:
            source_name: Filter by source name.
            reason: Filter by reason string.
            stage: Filter by processing stage.
            status: Filter by lifecycle status.
            limit: Maximum records per page.
            offset: Number of records to skip (offset pagination).
            cursor: Opaque cursor from a previous ``QueryResult.next_cursor``
                (keyset pagination; takes precedence over *offset*).

        Returns:
            A :class:`QueryResult` with the matching page.
        """
        ...

    async def mark_retry(self, record_id: str) -> bool:
        """Mark a record as being retried.

        Sets status to ``RETRYING`` and increments ``retry_count``.

        Args:
            record_id: The record to mark.

        Returns:
            ``True`` if the record was found and updated, ``False`` otherwise.
        """
        ...

    async def resolve(self, record_id: str) -> bool:
        """Mark a record as resolved.

        Sets status to ``RESOLVED``.

        Args:
            record_id: The record to resolve.

        Returns:
            ``True`` if the record was found and updated, ``False`` otherwise.
        """
        ...

    async def ignore(self, record_id: str) -> bool:
        """Mark a record as permanently ignored.

        Sets status to ``IGNORED``.

        Args:
            record_id: The record to ignore.

        Returns:
            ``True`` if the record was found and updated, ``False`` otherwise.
        """
        ...

    async def statistics(
        self,
        source_name: str | None = None,
    ) -> DLQStatistics:
        """Get aggregate statistics for stored records.

        Args:
            source_name: Optional filter by source name.

        Returns:
            A :class:`DLQStatistics` with counts grouped by reason,
            status, and stage.
        """
        ...

    async def purge_expired(self) -> int:
        """Delete records whose ``expires_at`` is in the past.

        Returns:
            Number of records removed.
        """
        ...

    async def purge_resolved(
        self,
        older_than: datetime | None = None,
    ) -> int:
        """Delete resolved records, optionally filtered by age.

        Args:
            older_than: If provided, only delete resolved records created
                before this timestamp.

        Returns:
            Number of records removed.
        """
        ...


@runtime_checkable
class RetryHandler(Protocol):
    """Protocol for DLQ record reprocessing handlers.

    Each package provides its own implementation that knows how to
    re-execute the failed work represented by a dead letter record.
    """

    async def handle(self, record: DeadLetterRecord) -> bool:
        """Attempt to reprocess a dead-lettered record.

        Args:
            record: The record to retry.

        Returns:
            ``True`` if reprocessing succeeded (record will be resolved).
            ``False`` if it failed (record stays pending/retrying).
        """
        ...
