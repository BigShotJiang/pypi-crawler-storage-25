import { getApiBaseUrl } from '../settings'
import { authHeaders, fetchWithTimeout } from './client'

/** Response from GET /api/v1/auth/me */
export interface AuthMeResponse {
  username: string
  auth_disabled?: boolean
}

/** Response from POST /api/v1/auth/login */
export interface AuthLoginResponse {
  access_token: string
  token_type: string
  expires_in: number
}

/** GET /api/v1/auth/me with timeout. Used on initial load. */
export async function authMeWithTimeout(timeoutMs: number): Promise<AuthMeResponse> {
  const url = `${getApiBaseUrl()}/api/v1/auth/me`
  return fetchWithTimeout<AuthMeResponse>(
    url,
    { method: 'GET', headers: authHeaders() },
    timeoutMs
  )
}

/** POST /api/v1/auth/login with timeout. */
export async function loginWithTimeout(
  username: string,
  password: string,
  timeoutMs: number
): Promise<AuthLoginResponse> {
  const url = `${getApiBaseUrl()}/api/v1/auth/login`
  return fetchWithTimeout<AuthLoginResponse>(
    url,
    {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ username, password }),
    },
    timeoutMs
  )
}
