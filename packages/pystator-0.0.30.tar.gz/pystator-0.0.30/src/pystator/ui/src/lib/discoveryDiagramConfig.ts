import type { InferredEdgeApiItem } from '@/lib/api'
import type { FSMConfig, FSMState, FSMTransition } from '@/lib/types/fsm'

/** Single-node placeholder when there is nothing to draw yet. */
export const DISCOVERY_EMPTY_PREVIEW_CONFIG: FSMConfig = {
  meta: { machine_name: 'discovery', version: 'preview' },
  states: [{ name: 'No preview yet', type: 'stable', description: 'Run Preview with entity scope selected.' }],
  transitions: [],
}

export function coerceDiscoveryDetailConfig(raw: Record<string, unknown>, machineName: string): FSMConfig {
  const cfg = raw as unknown as FSMConfig
  return {
    ...cfg,
    meta: { ...cfg.meta, machine_name: cfg.meta?.machine_name ?? machineName },
    states: Array.isArray(cfg.states) ? cfg.states : [],
    transitions: Array.isArray(cfg.transitions) ? cfg.transitions : [],
  }
}

/**
 * Build a minimal {@link FSMConfig} from inferred observation edges for read-only diagram display.
 * Triggers are synthetic (`inf_0`, …) because the discovery preview API does not emit trigger names.
 */
export function inferredEdgesToPreviewFsmConfig(
  edges: InferredEdgeApiItem[],
  machineName: string
): FSMConfig {
  if (edges.length === 0) return DISCOVERY_EMPTY_PREVIEW_CONFIG

  const stateNames = new Set<string>()
  for (const e of edges) {
    stateNames.add(e.source_state)
    stateNames.add(e.destination_state)
  }
  const ordered = Array.from(stateNames).sort((a, b) => a.localeCompare(b))
  const states: FSMState[] = ordered.map((name, i) => ({
    name,
    type: i === 0 ? 'initial' : 'stable',
  }))

  const transitions: FSMTransition[] = edges.map((e, idx) => ({
    trigger: `inf_${idx}`,
    source: e.source_state,
    dest: e.destination_state,
    metadata: {
      inferred_count: e.count,
      confidence: e.confidence,
    },
  }))

  return {
    meta: { machine_name: machineName.trim() || 'discovery', version: 'preview' },
    states,
    transitions,
  }
}
