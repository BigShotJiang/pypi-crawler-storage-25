import { fetchApi } from './client'

// ---------------------------------------------------------------------------
// Webhooks
// ---------------------------------------------------------------------------

export interface Webhook {
  id: string
  name: string
  url: string
  events: string[]
  headers: Record<string, string> | null
  enabled: boolean
  created_at: string | null
  updated_at: string | null
}

export interface WebhookListResponse {
  webhooks: Webhook[]
  total: number
}

export interface WebhookTestResult {
  success: boolean
  status_code: number | null
  error: string | null
}

export async function listWebhooks(): Promise<WebhookListResponse> {
  return fetchApi<WebhookListResponse>('/api/v1/webhooks')
}

export async function createWebhook(body: {
  name: string
  url: string
  events: string[]
  headers?: Record<string, string>
  enabled?: boolean
}): Promise<Webhook> {
  return fetchApi<Webhook>('/api/v1/webhooks', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getWebhook(webhookId: string): Promise<Webhook> {
  return fetchApi<Webhook>(`/api/v1/webhooks/${encodeURIComponent(webhookId)}`)
}

export async function updateWebhook(
  webhookId: string,
  body: Partial<{
    name: string
    url: string
    events: string[]
    headers: Record<string, string>
    enabled: boolean
  }>
): Promise<Webhook> {
  return fetchApi<Webhook>(
    `/api/v1/webhooks/${encodeURIComponent(webhookId)}`,
    { method: 'PUT', body: JSON.stringify(body) }
  )
}

export async function deleteWebhook(webhookId: string): Promise<void> {
  await fetchApi<void>(`/api/v1/webhooks/${encodeURIComponent(webhookId)}`, {
    method: 'DELETE',
  })
}

export async function testWebhook(webhookId: string): Promise<WebhookTestResult> {
  return fetchApi<WebhookTestResult>(
    `/api/v1/webhooks/${encodeURIComponent(webhookId)}/test`,
    { method: 'POST' }
  )
}

export async function checkMachineCompatibility(
  machineId: string,
  targetVersion: string
): Promise<{
  compatible: boolean
  source_version: string
  target_version: string
  entities_checked: number
  issues: Array<{ entity_id: string; current_state: string; issue: string }>
}> {
  return fetchApi(
    `/api/v1/machines/${encodeURIComponent(machineId)}/compatibility?target_version=${encodeURIComponent(targetVersion)}`,
    { method: 'POST' }
  )
}
