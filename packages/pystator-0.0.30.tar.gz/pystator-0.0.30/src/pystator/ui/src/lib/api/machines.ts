import type { FSMConfig } from '../types/fsm'
import { fetchApi } from './client'

/** Machine list item from API */
export interface MachineListItem {
  id: string
  name: string
  version: string
  namespace?: string | null
  description?: string | null
  created_at?: string | null
  updated_at?: string | null
}

/** Machine list response */
export interface MachineListResponse {
  machines: MachineListItem[]
  count: number
}

/** Full machine response (single machine) */
export interface MachineResponse {
  id: string
  name: string
  version: string
  description?: string | null
  strict_mode: boolean
  config: FSMConfig
  created_at?: string | null
  updated_at?: string | null
}

export async function listMachines(): Promise<MachineListResponse> {
  return fetchApi<MachineListResponse>('/api/v1/machines')
}

export async function createMachine(config: FSMConfig): Promise<MachineResponse> {
  return fetchApi<MachineResponse>('/api/v1/machines', {
    method: 'POST',
    body: JSON.stringify({ config }),
  })
}

export async function updateMachine(machineId: string, config: FSMConfig): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(`/api/v1/machines/${encodeURIComponent(machineId)}`, {
    method: 'PUT',
    body: JSON.stringify({ config }),
  })
}

export async function getMachine(machineId: string): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(`/api/v1/machines/${encodeURIComponent(machineId)}`)
}

export async function promoteDiscoveryCandidate(
  machineName: string,
  version: string
): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}/${encodeURIComponent(version)}/promote`,
    { method: 'POST' }
  )
}

export async function deleteMachine(machineId: string): Promise<void> {
  await fetchApi<void>(`/api/v1/machines/${encodeURIComponent(machineId)}`, {
    method: 'DELETE',
  })
}
