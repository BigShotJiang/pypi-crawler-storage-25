import { fetchApi } from './client'

/** Database config from API (mirrors PyCharter settings/database-config) */
export interface DatabaseConfigResponse {
  configured_url: string | null
  actual_url: string
  database_type: string
  is_default: boolean
  machine_count: number
  message: string
}

/** Request body for testing database connection */
export interface DatabaseTestRequest {
  connection_string?: string
  host?: string
  port?: number
  database?: string
  username?: string
  password?: string
}

/** Response for database connection test */
export interface DatabaseTestResponse {
  success: boolean
  message: string
}

export interface DiscoveryConfigResponse {
  backend: string
  database_url: string | null
  shadow_enabled: boolean
  min_edge_count: number
  min_confidence: number
  drift_alert_threshold: number
  drift_severe_threshold: number
  drift_min_sample: number
  low_sample_threshold: number
}

export interface DiscoveryDatabaseTestRequest {
  backend: string
  connection_string?: string
}

export interface DiscoveryDatabaseTestResponse {
  success: boolean
  message: string
}

/** DLQ test / stats (mirrors PyCharter settings API) */
export interface DlqTestRequest {
  connection_string?: string
  host?: string
  port?: number
  database?: string
  username?: string
  password?: string
  table_name?: string
}

export interface DlqTestResponse {
  success: boolean
  message: string
}

export type DlqStatsRequest = DlqTestRequest

export interface DlqStatsResponse {
  total_messages: number
  by_reason: Record<string, number | null | undefined>
  by_stage: Record<string, number | null | undefined>
  by_status: Record<string, number | null | undefined>
}

export interface WorkerDlqConfigResponse {
  dlq_enabled: boolean
  dlq_database_url: string | null
  dlq_table_name: string
  persistence: string
}

export async function getDatabaseConfig(): Promise<DatabaseConfigResponse> {
  return fetchApi<DatabaseConfigResponse>('/api/v1/settings/database-config')
}

export async function testDatabase(
  body: DatabaseTestRequest
): Promise<DatabaseTestResponse> {
  return fetchApi<DatabaseTestResponse>('/api/v1/settings/test-database', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getDiscoveryConfig(): Promise<DiscoveryConfigResponse> {
  return fetchApi<DiscoveryConfigResponse>('/api/v1/settings/discovery-config')
}

export async function testDiscoveryDatabase(
  body: DiscoveryDatabaseTestRequest
): Promise<DiscoveryDatabaseTestResponse> {
  return fetchApi<DiscoveryDatabaseTestResponse>('/api/v1/settings/test-discovery-database', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getWorkerDlqConfig(): Promise<WorkerDlqConfigResponse> {
  return fetchApi<WorkerDlqConfigResponse>('/api/v1/settings/worker-dlq-config')
}

export async function testDlq(body: DlqTestRequest): Promise<DlqTestResponse> {
  return fetchApi<DlqTestResponse>('/api/v1/settings/test-dlq', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function getDlqStats(body: DlqStatsRequest): Promise<DlqStatsResponse> {
  return fetchApi<DlqStatsResponse>('/api/v1/settings/dlq-stats', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}
