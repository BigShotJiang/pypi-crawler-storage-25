import { fetchApi } from './client'

// ---- Entity types ----

/** Entity state from GET /api/v1/entities/{id}/state or list */
export interface EntityState {
  entity_id: string
  current_state: string
  machine_name: string | null
  context: Record<string, unknown>
  status: 'active' | 'archived' | 'deleted'
  /** FSM workflow outcome: in progress, completed terminal, or error terminal */
  workflow_status?: 'active' | 'complete' | 'failed'
  is_terminal?: boolean | null
  labels: Record<string, string>
  updated_at: string | null
  created_at: string | null
  archived_at: string | null
  deleted_at: string | null
}

/** Paginated entity list */
export interface EntityListResponse {
  entities: EntityState[]
  total: number
  limit: number
  offset: number
  next_cursor: string | null
}

/** Trigger info from available-triggers endpoint */
export interface TriggerInfo {
  trigger: string
  target_state: string
  has_guard: boolean
  guard_description: string | null
}

/** Response from GET /api/v1/entities/{id}/available-triggers */
export interface AvailableTriggersResponse {
  entity_id: string
  current_state: string
  triggers: TriggerInfo[]
}

/** Request body for POST /api/v1/entities/{id}/dry-run */
export interface DryRunRequest {
  trigger: string
  context?: Record<string, unknown>
}

/** Response from POST /api/v1/entities/{id}/dry-run */
export interface DryRunResponse {
  would_succeed: boolean
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  actions_that_would_execute: string[]
  error_detail: string | null
}

/** Response for entity labels */
export interface EntityLabelsResponse {
  entity_id: string
  labels: Record<string, string>
}

/** Response from GET /api/v1/entities/{id}/history/stats */
export interface HistoryStatsResponse {
  entity_id: string
  total_transitions: number
  first_at: string | null
  last_at: string | null
  success_count: number
  failure_count: number
}

/** Response from DELETE /api/v1/entities/{id}/history */
export interface HistoryPurgeResponse {
  entity_id: string
  deleted_count: number
  remaining_count: number
}

/** Single history record in a snapshot */
export interface TransitionHistorySnapshotItem {
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  created_at: string
  duration_ms: number | null
}

/** Full entity snapshot for export */
export interface EntitySnapshotResponse {
  entity_id: string
  machine_name: string | null
  current_state: string
  context: Record<string, unknown>
  status: string
  labels: Record<string, string>
  history: TransitionHistorySnapshotItem[]
  exported_at: string
}

/** Response from POST /api/v1/entities/import */
export interface ImportEntityResponse {
  entity_id: string
  history_count: number
  success: boolean
}

/** Request body for POST /api/v1/entities/import */
export interface ImportEntityRequest {
  entity_id: string
  machine_name?: string
  current_state: string
  context?: Record<string, unknown>
  status?: string
  labels?: Record<string, string>
  history?: Record<string, unknown>[]
  overwrite?: boolean
}

/** Single item in bulk create request */
export interface BulkCreateEntityItem {
  entity_id: string
  machine_name: string
  machine_version?: string
  context?: Record<string, unknown>
}

/** Response for one entity in bulk create */
export interface BulkCreateEntityResult {
  entity_id: string
  success: boolean
  current_state: string | null
  error: string | null
}

/** Response from POST /api/v1/entities/bulk/create */
export interface BulkCreateEntitiesResponse {
  results: BulkCreateEntityResult[]
  total: number
  succeeded: number
  failed: number
}

/** Response for one entity in bulk event processing */
export interface BulkProcessEventResult {
  entity_id: string
  success: boolean
  source_state: string | null
  target_state: string | null
  error: string | null
}

/** Response from POST /api/v1/entities/bulk/events */
export interface BulkProcessEventsResponse {
  trigger: string
  results: BulkProcessEventResult[]
  total: number
  succeeded: number
  failed: number
}

/** Request body for POST /api/v1/entities/{id}/events */
export interface ProcessEntityEventRequest {
  trigger: string
  context?: Record<string, unknown>
  machine_name?: string
  machine_version?: string
}

/** Response from POST /api/v1/entities/{id}/events */
export interface ProcessEntityEventResponse {
  success: boolean
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  actions: string[]
  error: string | null
  shadow_diff?: Record<string, unknown> | null
  transition_id: string | null
}

/** Request body for POST /api/v1/entities/{id}/create */
export interface CreateEntityRequest {
  machine_name: string
  machine_version?: string
  context?: Record<string, unknown>
}

/** Response from POST /api/v1/entities/{id}/create */
export interface CreateEntityResponse extends EntityState {
  transition_id: string
}

/** Single transition history entry */
export interface TransitionHistoryEntry {
  id: string
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  created_at: string
  duration_ms?: number | null
}

// ---- Entity functions ----

export async function listEntities(params?: {
  machine_name?: string
  state?: string
  status?: string
  include_archived?: boolean
  include_deleted?: boolean
  is_terminal?: boolean
  workflow_status?: 'active' | 'complete' | 'failed'
  created_after?: string
  created_before?: string
  updated_after?: string
  updated_before?: string
  labels?: string
  sort_by?: string
  sort_order?: 'asc' | 'desc'
  limit?: number
  offset?: number
  cursor?: string
  page_size?: number
}): Promise<EntityListResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.state) qs.set('state', params.state)
  if (params?.status) qs.set('status', params.status)
  if (params?.include_archived) qs.set('include_archived', 'true')
  if (params?.include_deleted) qs.set('include_deleted', 'true')
  if (params?.is_terminal != null) qs.set('is_terminal', String(params.is_terminal))
  if (params?.workflow_status) qs.set('workflow_status', params.workflow_status)
  if (params?.created_after) qs.set('created_after', params.created_after)
  if (params?.created_before) qs.set('created_before', params.created_before)
  if (params?.updated_after) qs.set('updated_after', params.updated_after)
  if (params?.updated_before) qs.set('updated_before', params.updated_before)
  if (params?.labels) qs.set('labels', params.labels)
  if (params?.sort_by) qs.set('sort_by', params.sort_by)
  if (params?.sort_order) qs.set('sort_order', params.sort_order)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  if (params?.cursor) qs.set('cursor', params.cursor)
  if (params?.page_size != null) qs.set('page_size', String(params.page_size))
  const query = qs.toString()
  return fetchApi<EntityListResponse>(`/api/v1/entities${query ? `?${query}` : ''}`)
}

export async function getEntityState(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(`/api/v1/entities/${encodeURIComponent(entityId)}/state`)
}

export async function createEntity(
  entityId: string,
  body: CreateEntityRequest
): Promise<CreateEntityResponse> {
  return fetchApi<CreateEntityResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/create`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function processEntityEvent(
  entityId: string,
  body: ProcessEntityEventRequest
): Promise<ProcessEntityEventResponse> {
  return fetchApi<ProcessEntityEventResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/events`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function getEntityHistory(
  entityId: string,
  limit = 50,
  offset = 0
): Promise<TransitionHistoryEntry[]> {
  return fetchApi<TransitionHistoryEntry[]>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history?limit=${limit}&offset=${offset}`
  )
}

export async function deleteEntity(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(`/api/v1/entities/${encodeURIComponent(entityId)}`, {
    method: 'DELETE',
  })
}

export async function archiveEntity(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/archive`,
    { method: 'POST' }
  )
}

export async function restoreEntity(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/restore`,
    { method: 'POST' }
  )
}

export async function purgeEntity(entityId: string): Promise<void> {
  await fetchApi<void>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/purge`,
    { method: 'DELETE' }
  )
}

export async function getAvailableTriggers(
  entityId: string
): Promise<AvailableTriggersResponse> {
  return fetchApi<AvailableTriggersResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/available-triggers`
  )
}

export async function dryRunTransition(
  entityId: string,
  body: DryRunRequest
): Promise<DryRunResponse> {
  return fetchApi<DryRunResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/dry-run`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function enqueueApplyData(
  entityId: string,
  body: {
    data: Record<string, unknown>
    machine_name?: string
    fires_at?: string
    idempotency_key?: string
    max_attempts?: number
  }
): Promise<{ entity_id: string; machine_name: string; event_id: string }> {
  return fetchApi<{ entity_id: string; machine_name: string; event_id: string }>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/apply-data`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function getEntityLabels(
  entityId: string
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels`
  )
}

export async function setEntityLabels(
  entityId: string,
  labels: Record<string, string>
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels`,
    { method: 'PUT', body: JSON.stringify({ labels }) }
  )
}

export async function mergeEntityLabels(
  entityId: string,
  labels: Record<string, string>
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels`,
    { method: 'PATCH', body: JSON.stringify({ labels }) }
  )
}

export async function deleteEntityLabel(
  entityId: string,
  key: string
): Promise<EntityLabelsResponse> {
  return fetchApi<EntityLabelsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/labels/${encodeURIComponent(key)}`,
    { method: 'DELETE' }
  )
}

export async function getHistoryStats(
  entityId: string
): Promise<HistoryStatsResponse> {
  return fetchApi<HistoryStatsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history/stats`
  )
}

export async function purgeHistory(
  entityId: string,
  before: string
): Promise<HistoryPurgeResponse> {
  return fetchApi<HistoryPurgeResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history?before=${encodeURIComponent(before)}`,
    { method: 'DELETE' }
  )
}

export async function getEntitySnapshot(
  entityId: string
): Promise<EntitySnapshotResponse> {
  return fetchApi<EntitySnapshotResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/snapshot`
  )
}

export async function importEntity(
  body: ImportEntityRequest
): Promise<ImportEntityResponse> {
  return fetchApi<ImportEntityResponse>('/api/v1/entities/import', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function bulkCreateEntities(body: {
  items: BulkCreateEntityItem[]
}): Promise<BulkCreateEntitiesResponse> {
  return fetchApi<BulkCreateEntitiesResponse>('/api/v1/entities/bulk/create', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function bulkProcessEvents(body: {
  trigger: string
  entity_ids: string[]
  context?: Record<string, unknown>
  machine_name?: string
}): Promise<BulkProcessEventsResponse> {
  return fetchApi<BulkProcessEventsResponse>('/api/v1/entities/bulk/events', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}
