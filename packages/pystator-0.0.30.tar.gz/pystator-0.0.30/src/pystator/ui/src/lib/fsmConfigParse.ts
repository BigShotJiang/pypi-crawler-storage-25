import yaml from 'js-yaml'
import type { FSMConfig } from '@/lib/types/fsm'

export type ConfigFormat = 'json' | 'yaml'

export function parseFsmConfig(
  raw: string,
  format: ConfigFormat
): { config: FSMConfig } | { error: string } {
  try {
    if (format === 'json') {
      const parsed = JSON.parse(raw) as FSMConfig
      return { config: parsed }
    }
    const parsed = yaml.load(raw) as FSMConfig
    if (!parsed || typeof parsed !== 'object') return { error: 'Invalid YAML' }
    return { config: parsed }
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Parse error'
    return { error: message }
  }
}

export function stringifyFsmConfig(
  config: FSMConfig,
  format: ConfigFormat
): string {
  if (format === 'json') {
    return JSON.stringify(config, null, 2)
  }
  return yaml.dump(config, { indent: 2 })
}
