/**
 * Format process endpoint action refs for display.
 * API returns { name, params? } per ActionRef (declarative effects use names like `_effect.increment`).
 */

import type { ProcessActionRef } from '@/lib/types/fsm'

function displayActionName(name: string): string {
  if (name.startsWith('_effect.')) return name.slice(8)
  return name
}

export function formatProcessAction(action: ProcessActionRef | string): string {
  if (typeof action === 'string') return action
  const { name, params } = action
  const label = displayActionName(name)
  if (params && Object.keys(params).length > 0) {
    return `${label} ${JSON.stringify(params)}`
  }
  return label
}

export function formatProcessActionsList(actions: (ProcessActionRef | string)[]): string {
  return actions.map(formatProcessAction).join(', ')
}
