import type { FSMConfig, FSMState, FSMTransition } from '@/lib/types/fsm'

export interface DiffItem<T> {
  key: string
  before: T | null
  after: T | null
}

export interface FsmDiffResult {
  meta: {
    machine_name: DiffItem<string | null>
    version: DiffItem<string | null>
    strict_mode: DiffItem<boolean | null>
    validate_context: DiffItem<boolean | null>
  }
  states: {
    added: FSMState[]
    removed: FSMState[]
    changed: Array<DiffItem<FSMState>>
  }
  transitions: {
    added: FSMTransition[]
    removed: FSMTransition[]
    changed: Array<DiffItem<FSMTransition>>
  }
}

function sortDeep(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(sortDeep)
  }
  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>
    return Object.keys(obj)
      .sort()
      .reduce<Record<string, unknown>>((acc, key) => {
        acc[key] = sortDeep(obj[key])
        return acc
      }, {})
  }
  return value
}

function stableJson(value: unknown): string {
  return JSON.stringify(sortDeep(value))
}

function stateKey(s: FSMState): string {
  return s.name
}

function normalizeSource(src: FSMTransition['source']): string[] {
  return Array.isArray(src) ? [...src].sort() : [src]
}

function transitionKey(t: FSMTransition): string {
  const trigger = t.trigger ?? ''
  const source = normalizeSource(t.source).join('|')
  return `${trigger}::${source}::${t.dest}`
}

function pickMeta(config: FSMConfig | null | undefined) {
  return {
    machine_name: config?.meta?.machine_name ?? null,
    version: config?.meta?.version ?? null,
    strict_mode: config?.meta?.strict_mode ?? null,
    validate_context: config?.meta?.validate_context ?? null,
  }
}

function diffScalar<T>(before: T, after: T): DiffItem<T> {
  return { key: 'meta', before, after }
}

export function diffFsmConfig(active: FSMConfig, candidate: FSMConfig): FsmDiffResult {
  const aStates = active.states ?? []
  const cStates = candidate.states ?? []
  const aTransitions = active.transitions ?? []
  const cTransitions = candidate.transitions ?? []

  const aMeta = pickMeta(active)
  const cMeta = pickMeta(candidate)

  const meta = {
    machine_name: diffScalar(aMeta.machine_name, cMeta.machine_name),
    version: diffScalar(aMeta.version, cMeta.version),
    strict_mode: diffScalar(aMeta.strict_mode, cMeta.strict_mode),
    validate_context: diffScalar(aMeta.validate_context, cMeta.validate_context),
  }

  const aStateMap = new Map(aStates.map((s) => [stateKey(s), s]))
  const cStateMap = new Map(cStates.map((s) => [stateKey(s), s]))
  const stateKeys = Array.from(new Set([...aStateMap.keys(), ...cStateMap.keys()])).sort()

  const statesAdded: FSMState[] = []
  const statesRemoved: FSMState[] = []
  const statesChanged: Array<DiffItem<FSMState>> = []

  for (const key of stateKeys) {
    const before = aStateMap.get(key) ?? null
    const after = cStateMap.get(key) ?? null
    if (!before && after) statesAdded.push(after)
    else if (before && !after) statesRemoved.push(before)
    else if (before && after) {
      const same =
        before.type === after.type &&
        before.parent === after.parent &&
        before.initial_child === after.initial_child &&
        stableJson(before.regions ?? null) === stableJson(after.regions ?? null)
      if (!same) statesChanged.push({ key, before, after })
    }
  }

  const aTransMap = new Map(aTransitions.map((t) => [transitionKey(t), t]))
  const cTransMap = new Map(cTransitions.map((t) => [transitionKey(t), t]))
  const transKeys = Array.from(new Set([...aTransMap.keys(), ...cTransMap.keys()])).sort()

  const transAdded: FSMTransition[] = []
  const transRemoved: FSMTransition[] = []
  const transChanged: Array<DiffItem<FSMTransition>> = []

  for (const key of transKeys) {
    const before = aTransMap.get(key) ?? null
    const after = cTransMap.get(key) ?? null
    if (!before && after) transAdded.push(after)
    else if (before && !after) transRemoved.push(before)
    else if (before && after) {
      const same =
        stableJson(normalizeSource(before.source)) === stableJson(normalizeSource(after.source)) &&
        before.dest === after.dest &&
        (before.trigger ?? '') === (after.trigger ?? '') &&
        stableJson(before.guards ?? null) === stableJson(after.guards ?? null) &&
        stableJson(before.actions ?? null) === stableJson(after.actions ?? null) &&
        stableJson(before.after ?? null) === stableJson(after.after ?? null) &&
        (before.region ?? null) === (after.region ?? null)
      if (!same) transChanged.push({ key, before, after })
    }
  }

  return {
    meta,
    states: { added: statesAdded, removed: statesRemoved, changed: statesChanged },
    transitions: { added: transAdded, removed: transRemoved, changed: transChanged },
  }
}

/** One-line summary for promote / review dialogs. */
export function summarizeFsmDiffImpact(diff: FsmDiffResult): string {
  const sa = diff.states.added.length
  const sr = diff.states.removed.length
  const sc = diff.states.changed.length
  const ta = diff.transitions.added.length
  const tr = diff.transitions.removed.length
  const tc = diff.transitions.changed.length
  const parts: string[] = []
  if (sa || sr || sc) {
    parts.push(`${sa} state(s) added, ${sr} removed${sc ? `, ${sc} changed` : ''}`)
  }
  if (ta || tr || tc) {
    parts.push(`${ta} transition(s) added, ${tr} removed${tc ? `, ${tc} changed` : ''}`)
  }
  return parts.length > 0 ? parts.join(' · ') : 'No structural changes vs baseline.'
}
