import { fetchApi } from './client'

// ---- Observability types ----

export interface ObservabilitySummaryResponse {
  window_start: string
  window_end: string
  active_entities: number
  transitions_total: number
  transitions_failed: number
  transition_failure_rate: number
  p95_transition_duration_ms: number | null
  worker_pending: number
  worker_claimed: number
  worker_failed: number
  worker_dead_letter: number
}

export interface ObservabilityTransitionItem {
  id: string
  entity_id: string
  machine_name: string | null
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  duration_ms: number | null
  created_at: string
}

export interface ObservabilityTransitionsResponse {
  items: ObservabilityTransitionItem[]
  total: number
  limit: number
  offset: number
}

export interface ObservabilityWorkerEventItem {
  id: string
  machine_name: string
  entity_id: string
  trigger: string
  status: 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  attempt: number
  max_attempts: number
  error_message: string | null
  fires_at: string
  claimed_by: string | null
  claimed_at: string | null
  created_at: string | null
  completed_at: string | null
  result_json: Record<string, unknown> | null
  transition_history_id: string | null
}

export interface ObservabilityWorkerEventsResponse {
  items: ObservabilityWorkerEventItem[]
  total: number
  limit: number
  offset: number
}

// ---- Analytics types ----

export interface StateDistributionItem { state: string; count: number; percentage: number }
export interface StatusDistribution { active: number; archived: number; deleted: number }
export interface MachineDistributionItem { machine_name: string; count: number }
export interface FailingEntityItem { entity_id: string; failure_count: number; last_failure_at: string }
export interface EntityHealthResponse {
  state_distribution: StateDistributionItem[]
  status_distribution: StatusDistribution
  machine_distribution: MachineDistributionItem[]
  top_failing_entities: FailingEntityItem[]
  terminal_rate: number
  total_entities: number
}

export interface TimeBucketItem { bucket_start: string; bucket_end: string; total: number; failed: number; failure_rate: number }
export interface DurationPercentiles { p50: number | null; p75: number | null; p95: number | null; p99: number | null }
export interface FailingTriggerItem { trigger: string; total: number; failed: number; failure_rate: number }
export interface FailingStateItem { state: string; total: number; failed: number; failure_rate: number }
export interface VolumeTrendItem { bucket_start: string; count: number }
export interface TransitionAnalyticsResponse {
  time_buckets: TimeBucketItem[]
  duration_percentiles: DurationPercentiles
  top_failing_triggers: FailingTriggerItem[]
  top_failing_states: FailingStateItem[]
  volume_trend: VolumeTrendItem[]
}

export interface TimelineStep {
  state: string
  entered_at: string
  exited_at: string | null
  dwell_ms: number | null
  trigger_in: string | null
  trigger_out: string | null
  success: boolean
}
export interface EntityTimelineResponse {
  entity_id: string
  machine_name: string | null
  current_state: string
  steps: TimelineStep[]
  total_dwell_ms: number
  states_visited: number
}

// ---- State ops metrics types ----

export interface StateOpsErrorTopItem {
  error_type: string | null
  error_message: string | null
  count: number
}

export interface StateOpsAgeBuckets {
  le_5m: number
  le_30m: number
  gt_30m: number
}

export interface StateOpsMetricsItem {
  state_name: string
  entity_count: number
  age_p95_seconds: number | null
  age_oldest_seconds: number | null
  age_buckets: StateOpsAgeBuckets
  failed_transition_count: number
  top_error: StateOpsErrorTopItem | null
}

export interface ObservabilityStateMetricsResponse {
  machine_name: string
  window_start: string
  window_end: string
  items: StateOpsMetricsItem[]
}

// ---- Entity Metrics types ----

export interface ErrorPatternItem {
  error_type: string | null
  trigger: string
  source_state: string
  count: number
  last_occurred: string
}

export interface DwellByStateItem {
  state: string
  avg_ms: number
  min_ms: number
  max_ms: number
  visit_count: number
}

export interface FleetComparison {
  entity_failure_rate: number
  fleet_failure_rate: number
  entity_avg_latency_ms: number | null
  fleet_avg_latency_ms: number | null
  latency_percentile_rank: number | null
}

export interface VelocityPoint {
  timestamp: string
  duration_ms: number
}

export interface EntityMetricsResponse {
  entity_id: string
  machine_name: string | null
  health_score: number
  health_status: 'healthy' | 'warning' | 'critical'
  staleness_seconds: number | null
  staleness_label: string
  error_patterns: ErrorPatternItem[]
  recent_failure_rate: number
  latency_percentiles: DurationPercentiles
  dwell_by_state: DwellByStateItem[]
  is_potentially_stuck: boolean
  stuck_state: string | null
  stuck_current_dwell_ms: number | null
  stuck_avg_dwell_ms: number | null
  state_revisits: Record<string, number>
  has_cycles: boolean
  fleet_comparison: FleetComparison | null
  velocity_points: VelocityPoint[]
}

// ---- Observability functions ----

export async function getObservabilitySummary(params?: {
  window_hours?: number
  machine_name?: string
  entity_id?: string
}): Promise<ObservabilitySummaryResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  const query = qs.toString()
  return fetchApi<ObservabilitySummaryResponse>(
    `/api/v1/observability/summary${query ? `?${query}` : ''}`
  )
}

export async function listObservabilityTransitions(params?: {
  machine_name?: string
  entity_id?: string
  status?: 'all' | 'success' | 'failed'
  start_at?: string
  end_at?: string
  limit?: number
  offset?: number
}): Promise<ObservabilityTransitionsResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  if (params?.status) qs.set('status', params.status)
  if (params?.start_at) qs.set('start_at', params.start_at)
  if (params?.end_at) qs.set('end_at', params.end_at)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<ObservabilityTransitionsResponse>(
    `/api/v1/observability/transitions${query ? `?${query}` : ''}`
  )
}

export async function listObservabilityWorkerEvents(params?: {
  machine_name?: string
  entity_id?: string
  status?: 'all' | 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  start_at?: string
  end_at?: string
  limit?: number
  offset?: number
}): Promise<ObservabilityWorkerEventsResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  if (params?.status) qs.set('status', params.status)
  if (params?.start_at) qs.set('start_at', params.start_at)
  if (params?.end_at) qs.set('end_at', params.end_at)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<ObservabilityWorkerEventsResponse>(
    `/api/v1/observability/worker-events${query ? `?${query}` : ''}`
  )
}

export async function getObservabilityStateMetrics(params: {
  machine_name: string
  window_hours?: number
}): Promise<ObservabilityStateMetricsResponse> {
  const qs = new URLSearchParams()
  qs.set('machine_name', params.machine_name)
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  const query = qs.toString()
  return fetchApi<ObservabilityStateMetricsResponse>(
    `/api/v1/observability/state-metrics?${query}`
  )
}

// ---- Analytics functions ----

export async function getEntityHealth(params?: {
  window_hours?: number
  machine_name?: string
}): Promise<EntityHealthResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  const query = qs.toString()
  return fetchApi<EntityHealthResponse>(
    `/api/v1/observability/entity-health${query ? `?${query}` : ''}`
  )
}

export async function getTransitionAnalytics(params?: {
  window_hours?: number
  machine_name?: string
  bucket_count?: number
}): Promise<TransitionAnalyticsResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.bucket_count != null) qs.set('bucket_count', String(params.bucket_count))
  const query = qs.toString()
  return fetchApi<TransitionAnalyticsResponse>(
    `/api/v1/observability/transition-analytics${query ? `?${query}` : ''}`
  )
}

export async function getEntityTimeline(entityId: string): Promise<EntityTimelineResponse> {
  return fetchApi<EntityTimelineResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/timeline`
  )
}

export async function getEntityMetrics(
  entityId: string,
  windowHours = 24
): Promise<EntityMetricsResponse> {
  const qs = new URLSearchParams()
  if (windowHours !== 24) qs.set('window_hours', String(windowHours))
  const query = qs.toString()
  return fetchApi<EntityMetricsResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/metrics${query ? `?${query}` : ''}`
  )
}
