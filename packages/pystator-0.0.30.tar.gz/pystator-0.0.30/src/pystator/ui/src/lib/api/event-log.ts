import { fetchApi } from './client'
import type { EntityState } from './entities'

// ---------------------------------------------------------------------------
// Event Log & Replay
// ---------------------------------------------------------------------------

export interface EventLogEntry {
  id: string
  entity_id: string
  machine_name: string | null
  sequence: number
  trigger: string
  payload: Record<string, unknown> | null
  event_id: string | null
  source: string | null
  created_at: string | null
}

export interface EventLogResponse {
  events: EventLogEntry[]
  total: number
  limit: number
  offset: number
}

export interface ReplayStep {
  sequence: number
  trigger: string
  source_state: string
  target_state: string | null
  success: boolean
  current_state: string
  error?: string
}

export interface ReplayResponse {
  steps: ReplayStep[]
  total_events: number
  final_state: string
}

export async function getEntityEvents(
  entityId: string,
  limit = 50,
  offset = 0
): Promise<EventLogResponse> {
  return fetchApi<EventLogResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/events?limit=${limit}&offset=${offset}`
  )
}

export async function replayEntity(
  entityId: string,
  upToSequence?: number
): Promise<ReplayResponse> {
  const params = upToSequence ? `?up_to_sequence=${upToSequence}` : ''
  return fetchApi<ReplayResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/replay${params}`,
    { method: 'POST' }
  )
}

export async function migrateEntity(
  entityId: string,
  machineName: string,
  machineVersion: string
): Promise<EntityState> {
  return fetchApi<EntityState>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/migrate?machine_name=${encodeURIComponent(machineName)}&machine_version=${encodeURIComponent(machineVersion)}`,
    { method: 'POST' }
  )
}
