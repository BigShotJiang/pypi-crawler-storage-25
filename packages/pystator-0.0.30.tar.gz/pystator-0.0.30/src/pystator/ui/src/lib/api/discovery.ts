import { fetchApi } from './client'

// ---- Discovery (infer / shadow) ----

export interface DiscoveryObserveRequest {
  machine_name: string
  entity_id: string
  state: string
  observed_at?: string
  source?: string
  source_event_id?: string
  ingest_seq?: number
  metadata?: Record<string, unknown>
}

export interface DiscoveryObserveResponse {
  accepted: boolean
}

export interface DiscoveryBuildCandidateRequest {
  machine_name: string
  version?: string
  mode?: 'inference' | 'manual'
  entity_ids?: string[]
  edge_selection?: Array<{ source_state: string; destination_state: string }>
  min_edge_count?: number
  min_confidence?: number
}

export interface InferredEdgeApiItem {
  source_state: string
  destination_state: string
  count: number
  unique_entities: number
  unique_sources: number
  confidence: number
}

export interface DiscoveryBuiltCandidateResponse {
  machine_name: string
  version: string
  candidate_sequence: number
  status: string
  config: Record<string, unknown>
  metadata: Record<string, unknown>
  edges: InferredEdgeApiItem[]
}

export interface DiscoveryPreviewRequest {
  machine_name: string
  mode?: 'inference' | 'manual'
  entity_ids?: string[]
  min_edge_count?: number
  min_confidence?: number
}

export interface DiscoveryPreviewResponse {
  machine_name: string
  mode: string
  entity_ids_used: string[]
  observation_count: number
  edges: InferredEdgeApiItem[]
  selected_edges: InferredEdgeApiItem[]
}

export interface DiscoveryEntityListResponse {
  machine_name: string
  entity_ids: string[]
}

export interface DiscoveryDeleteEntityObservationsResponse {
  machine_name: string
  entity_id: string
  deleted_count: number
}

export interface DiscoverySaveCandidateRequest {
  source_machine_name: string
  target_machine_name: string
  target_version?: string
  config: Record<string, unknown>
  metadata?: Record<string, unknown>
}

export interface DiscoveryBuiltCandidateSummaryItem {
  machine_name: string
  version: string
  candidate_sequence: number
  status: string
  created_at: string
  metadata: Record<string, unknown>
  observation_count_at_build: number
  shadow_diff_count_recent: number
  drift_rate_recent: number
  build_mode: string | null
}

export interface DiscoveryDraftResponse {
  id: string
  machine_name: string
  title: string | null
  selected_entity_ids: string[]
  mode: string
  min_edge_count: number
  min_confidence: number
  manual_edge_selection: Array<{ source_state: string; destination_state: string }>
  created_at: string
  updated_at: string
  last_built_version: string | null
}

export interface DiscoveryDraftMachineCreateResponse {
  machine_name: string
  draft: DiscoveryDraftResponse
}

// ---- Workspace annotations ----

export interface WorkspaceAnnotationItem {
  state_name: string
  body_markdown: string
  updated_at: string | null
}

export interface WorkspaceAnnotationsListResponse {
  machine_name: string
  machine_version: string
  items: WorkspaceAnnotationItem[]
}

export interface DiscoveryMachineDraftsResponse {
  machine_name: string
  drafts: DiscoveryDraftResponse[]
  built_candidates: DiscoveryBuiltCandidateSummaryItem[]
}

export interface DiscoveryDraftPatchRequest {
  title?: string | null
  selected_entity_ids?: string[]
  mode?: 'inference' | 'manual'
  min_edge_count?: number
  min_confidence?: number
  manual_edge_selection?: Array<{ source_state: string; destination_state: string }>
}

export interface DiscoveryShadowDiffResponse {
  machine_name: string
  source_state: string
  trigger: string
  active_success: boolean
  active_target_state: string | null
  candidate_success: boolean
  candidate_target_state: string | null
  differs: boolean
  reason: string | null
  metadata: Record<string, unknown>
}

/** One row from GET /api/v1/discovery/machines */
export interface DiscoveryFleetMachineItem {
  machine_name: string
  last_observation_at: string | null
  observation_count: number
  candidate_count: number
  latest_candidate_version: string | null
  latest_candidate_created_at: string | null
  shadow_diff_count_recent: number
  drift_rate_recent: number
}

export interface DiscoveryFleetListResponse {
  items: DiscoveryFleetMachineItem[]
  total: number
  limit: number
  offset: number
}

export type DiscoveryFleetQueryParams = {
  query?: string
  sort?: string
  order?: 'asc' | 'desc'
  limit?: number
  offset?: number
}

// ---- Workspace transition annotations ----

export interface WorkspaceTransitionAnnotationItem {
  transition_key: string
  body_markdown: string
  updated_at?: string | null
}

export interface WorkspaceTransitionAnnotationsListResponse {
  machine_name: string
  machine_version: string
  items: WorkspaceTransitionAnnotationItem[]
}

// ---- Discovery functions ----

export async function listDiscoveryMachines(
  params: DiscoveryFleetQueryParams = {}
): Promise<DiscoveryFleetListResponse> {
  const q = new URLSearchParams()
  if (params.query) q.set('query', params.query)
  if (params.sort) q.set('sort', params.sort)
  if (params.order) q.set('order', params.order)
  if (params.limit != null) q.set('limit', String(params.limit))
  if (params.offset != null) q.set('offset', String(params.offset))
  const s = q.toString()
  return fetchApi<DiscoveryFleetListResponse>(
    `/api/v1/discovery/machines${s ? `?${s}` : ''}`
  )
}

export async function recordDiscoveryObservation(
  body: DiscoveryObserveRequest
): Promise<DiscoveryObserveResponse> {
  return fetchApi<DiscoveryObserveResponse>('/api/v1/discovery/observations', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function buildDiscoveryCandidate(
  body: DiscoveryBuildCandidateRequest
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>('/api/v1/discovery/candidates/build', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function previewDiscoveryCandidate(
  body: DiscoveryPreviewRequest
): Promise<DiscoveryPreviewResponse> {
  return fetchApi<DiscoveryPreviewResponse>('/api/v1/discovery/candidates/preview', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function listDiscoveryMachineEntityIds(
  machineName: string
): Promise<DiscoveryEntityListResponse> {
  return fetchApi<DiscoveryEntityListResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/entities`
  )
}

export async function deleteDiscoveryEntityObservations(
  machineName: string,
  entityId: string
): Promise<DiscoveryDeleteEntityObservationsResponse> {
  return fetchApi<DiscoveryDeleteEntityObservationsResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/entities/${encodeURIComponent(entityId)}/observations`,
    { method: 'DELETE' }
  )
}

export async function listDiscoveryCandidates(
  machineName: string
): Promise<DiscoveryMachineDraftsResponse> {
  return fetchApi<DiscoveryMachineDraftsResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}`
  )
}

export async function createDiscoveryDraft(
  machineName: string,
  body: { title?: string | null } = {}
): Promise<DiscoveryDraftResponse> {
  return fetchApi<DiscoveryDraftResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function createDiscoveryDraftMachine(
  body: { title?: string | null } = {}
): Promise<DiscoveryDraftMachineCreateResponse> {
  return fetchApi<DiscoveryDraftMachineCreateResponse>('/api/v1/discovery/draft-machines', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function listWorkspaceAnnotations(params: {
  machine_name: string
  machine_version: string
}): Promise<WorkspaceAnnotationsListResponse> {
  const q = new URLSearchParams()
  q.set('machine_name', params.machine_name)
  q.set('machine_version', params.machine_version)
  return fetchApi<WorkspaceAnnotationsListResponse>(`/api/v1/annotations?${q.toString()}`)
}

export async function upsertWorkspaceAnnotation(params: {
  machine_name: string
  machine_version: string
  state_name: string
  body_markdown: string
}): Promise<{ ok: boolean }> {
  return fetchApi<{ ok: boolean }>(
    `/api/v1/annotations/${encodeURIComponent(params.machine_name)}/${encodeURIComponent(
      params.machine_version
    )}/${encodeURIComponent(params.state_name)}`,
    { method: 'PUT', body: JSON.stringify({ body_markdown: params.body_markdown }) }
  )
}

export async function deleteWorkspaceAnnotation(params: {
  machine_name: string
  machine_version: string
  state_name: string
}): Promise<void> {
  await fetchApi<void>(
    `/api/v1/annotations/${encodeURIComponent(params.machine_name)}/${encodeURIComponent(
      params.machine_version
    )}/${encodeURIComponent(params.state_name)}`,
    { method: 'DELETE' }
  )
}

export async function renameWorkspaceAnnotation(params: {
  machine_name: string
  machine_version: string
  old_state_name: string
  new_state_name: string
}): Promise<{ ok: boolean; moved: boolean }> {
  return fetchApi<{ ok: boolean; moved: boolean }>(
    `/api/v1/annotations/${encodeURIComponent(params.machine_name)}/${encodeURIComponent(
      params.machine_version
    )}/rename`,
    {
      method: 'POST',
      body: JSON.stringify({
        old_state_name: params.old_state_name,
        new_state_name: params.new_state_name,
      }),
    }
  )
}

export async function listWorkspaceTransitionAnnotations(params: {
  machine_name: string
  machine_version: string
}): Promise<WorkspaceTransitionAnnotationsListResponse> {
  const qs = new URLSearchParams()
  qs.set('machine_name', params.machine_name)
  qs.set('machine_version', params.machine_version)
  const query = qs.toString()
  return fetchApi<WorkspaceTransitionAnnotationsListResponse>(
    `/api/v1/transition-annotations${query ? `?${query}` : ''}`
  )
}

export async function upsertWorkspaceTransitionAnnotation(params: {
  machine_name: string
  machine_version: string
  transition_key: string
  body_markdown: string
}): Promise<{ ok: boolean }> {
  return fetchApi<{ ok: boolean }>(
    `/api/v1/transition-annotations/${encodeURIComponent(params.machine_name)}/${encodeURIComponent(
      params.machine_version
    )}/${encodeURIComponent(params.transition_key)}`,
    {
      method: 'PUT',
      body: JSON.stringify({ body_markdown: params.body_markdown }),
    }
  )
}

export async function deleteWorkspaceTransitionAnnotation(params: {
  machine_name: string
  machine_version: string
  transition_key: string
}): Promise<void> {
  return fetchApi<void>(
    `/api/v1/transition-annotations/${encodeURIComponent(params.machine_name)}/${encodeURIComponent(
      params.machine_version
    )}/${encodeURIComponent(params.transition_key)}`,
    { method: 'DELETE' }
  )
}

export async function patchDiscoveryDraft(
  machineName: string,
  draftId: string,
  body: DiscoveryDraftPatchRequest
): Promise<DiscoveryDraftResponse> {
  return fetchApi<DiscoveryDraftResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}`,
    { method: 'PATCH', body: JSON.stringify(body) }
  )
}

export async function deleteDiscoveryDraft(
  machineName: string,
  draftId: string
): Promise<void> {
  await fetchApi<void>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}`,
    { method: 'DELETE' }
  )
}

export async function previewDiscoveryDraft(
  machineName: string,
  draftId: string
): Promise<DiscoveryPreviewResponse> {
  return fetchApi<DiscoveryPreviewResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}/preview`,
    { method: 'POST' }
  )
}

export async function buildDiscoveryDraft(
  machineName: string,
  draftId: string
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>(
    `/api/v1/discovery/machines/${encodeURIComponent(machineName)}/drafts/${encodeURIComponent(draftId)}/build`,
    { method: 'POST' }
  )
}

export async function getDiscoveryCandidate(
  machineName: string,
  version: string
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}/${encodeURIComponent(version)}`
  )
}

export async function getLatestDiscoveryCandidate(
  machineName: string
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>(
    `/api/v1/discovery/candidates/${encodeURIComponent(machineName)}/latest`
  )
}

export async function listDiscoveryShadowDiffs(
  machineName: string,
  limit = 100
): Promise<DiscoveryShadowDiffResponse[]> {
  const q = new URLSearchParams()
  q.set('limit', String(limit))
  return fetchApi<DiscoveryShadowDiffResponse[]>(
    `/api/v1/discovery/shadow/${encodeURIComponent(machineName)}?${q.toString()}`
  )
}

export async function saveDiscoveryCandidate(
  body: DiscoverySaveCandidateRequest
): Promise<DiscoveryBuiltCandidateResponse> {
  return fetchApi<DiscoveryBuiltCandidateResponse>('/api/v1/discovery/candidates/save', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}
