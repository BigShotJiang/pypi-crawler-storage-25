import { fetchApi } from './client'

// ---------------------------------------------------------------------------
// Catalog (built-in guards, actions, effects, operators)
// ---------------------------------------------------------------------------

export interface CatalogParam {
  name: string
  default?: string
  type?: string
}

export interface CatalogEntry {
  name: string
  description: string
  params: CatalogParam[]
}

export interface CatalogEffect {
  name: string
  description: string
  syntax: string
}

export interface CatalogOperator {
  name: string
}

export interface BuiltinCatalog {
  guards: CatalogEntry[]
  actions: CatalogEntry[]
  effects: CatalogEffect[]
  check_operators: CatalogOperator[]
}

export async function getBuiltinCatalog(): Promise<BuiltinCatalog> {
  return fetchApi<BuiltinCatalog>('/api/v1/catalog/builtins')
}
