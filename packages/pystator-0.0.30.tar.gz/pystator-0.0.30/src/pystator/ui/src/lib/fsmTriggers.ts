import type { FSMConfig } from '@/lib/types/fsm'

function parseSource(source: string | string[]): string[] {
  if (Array.isArray(source)) return source
  return [source]
}

/** Returns trigger names that are valid from the given state (source matches current state). */
export function getAllowedTriggers(config: FSMConfig, currentState: string): string[] {
  const out = new Set<string>()
  for (const t of config.transitions ?? []) {
    if (!t.trigger) continue
    const sources = parseSource(t.source)
    if (sources.includes(currentState)) out.add(t.trigger)
  }
  return Array.from(out).sort()
}
