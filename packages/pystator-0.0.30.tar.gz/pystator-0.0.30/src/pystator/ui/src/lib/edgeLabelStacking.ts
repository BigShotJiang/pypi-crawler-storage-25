/**
 * Stacking order for FSM diagram edge labels (React Flow EdgeLabelRenderer).
 * Precedence: explicit edge label click > incident to focused node > default; timeouts stay lowest among non-focused.
 */

/** Default transition labels */
export const EDGE_LABEL_Z_BASE = 10

/** Timeout / lower-priority edge labels */
export const EDGE_LABEL_Z_TIMEOUT = 5

/** Labels on edges connected to the focused node */
export const EDGE_LABEL_Z_INCIDENT_NODE = 50

/** Label the user clicked to bring to front */
export const EDGE_LABEL_Z_FOCUSED_EDGE = 100

export interface EdgeLabelZIndexInput {
  edgeId: string
  edgeSourceId: string
  edgeTargetId: string
  focusedEdgeId: string | null
  focusedNodeId: string | null
  isTimeout: boolean
}

export function computeEdgeLabelZIndex(input: EdgeLabelZIndexInput): number {
  if (input.focusedEdgeId != null && input.focusedEdgeId === input.edgeId) {
    return EDGE_LABEL_Z_FOCUSED_EDGE
  }

  if (
    input.focusedNodeId != null &&
    (input.edgeSourceId === input.focusedNodeId || input.edgeTargetId === input.focusedNodeId)
  ) {
    return EDGE_LABEL_Z_INCIDENT_NODE
  }

  return input.isTimeout ? EDGE_LABEL_Z_TIMEOUT : EDGE_LABEL_Z_BASE
}
