import { clearAccessToken, getAccessToken } from '../auth-storage'
import { getApiBaseUrl } from '../settings'
import { AUTH_SESSION_EXPIRED_EVENT } from '../constants'

function handleUnauthorized(): void {
  clearAccessToken()
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT))
  }
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: unknown
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

/** Return a user-facing message from a fetch/API error, or a default. */
export function getApiErrorMessage(error: unknown, defaultMessage: string): string {
  if (error instanceof Error) return error.message || defaultMessage
  if (typeof error === 'string') return error
  return defaultMessage
}

export function authHeaders(): Record<string, string> {
  const token = getAccessToken()
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (token) headers['Authorization'] = `Bearer ${token}`
  return headers
}

export async function fetchApi<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${getApiBaseUrl()}${endpoint}`
  const response = await fetch(url, {
    ...options,
    headers: { ...authHeaders(), ...(options?.headers as Record<string, string>) },
  })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  // 204 No Content (e.g. DELETE) has no body; do not call response.json()
  if (response.status === 204) return undefined as T
  const ct = response.headers.get('content-type')
  if (ct?.includes('application/json')) return response.json()
  return response.text() as unknown as T
}

/** Fetch an endpoint and return the response body as a Blob (e.g. for ZIP download). */
export async function getBlob(endpoint: string): Promise<Blob> {
  const url = `${getApiBaseUrl()}${endpoint}`
  const response = await fetch(url, { method: 'GET', headers: authHeaders() })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  return response.blob()
}

/**
 * Fetch with timeout for auth endpoints. On 401 clears token; on AbortError or
 * network error throws ApiError with status 0 or connection message.
 */
export async function fetchWithTimeout<T>(
  url: string,
  options: RequestInit,
  timeoutMs: number
): Promise<T> {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, { ...options, signal: controller.signal })
    clearTimeout(timeoutId)
    if (response.status === 401) {
      handleUnauthorized()
      throw new ApiError('Not authenticated', 401, { detail: 'Not authenticated' })
    }
    if (!response.ok) {
      let errorData: { detail?: string }
      try {
        errorData = await response.json()
      } catch {
        errorData = { detail: response.statusText }
      }
      throw new ApiError(
        errorData.detail ?? `API request failed: ${response.statusText}`,
        response.status,
        errorData
      )
    }
    return await response.json()
  } catch (err) {
    clearTimeout(timeoutId)
    if (err instanceof ApiError) throw err
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ApiError('Request timed out', 0, { originalError: 'Timeout' })
    }
    if (err instanceof TypeError && err.message === 'Failed to fetch') {
      throw new ApiError(
        `Unable to connect to API server at ${getApiBaseUrl()}. Please ensure the API server is running.`,
        0,
        { originalError: 'NetworkError' }
      )
    }
    throw err
  }
}
