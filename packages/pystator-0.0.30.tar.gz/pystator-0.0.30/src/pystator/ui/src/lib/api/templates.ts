import { clearAccessToken } from '../auth-storage'
import { AUTH_SESSION_EXPIRED_EVENT } from '../constants'
import { getApiBaseUrl } from '../settings'
import { ApiError, authHeaders, fetchApi, getBlob } from './client'

/** FSM templates: list and get content (YAML text) */
export interface FsmTemplatesListResponse {
  templates: string[]
}

export async function listFsmTemplates(): Promise<FsmTemplatesListResponse> {
  return fetchApi<FsmTemplatesListResponse>('/api/v1/templates/fsm')
}

/** Fetch FSM template content as YAML text (parse in UI with js-yaml). */
export async function getFsmTemplate(filename: string): Promise<string> {
  const name = filename.endsWith('.yaml') || filename.endsWith('.yml') ? filename : `${filename}.yaml`
  const url = `${getApiBaseUrl()}/api/v1/templates/fsm/${encodeURIComponent(name)}`
  const response = await fetch(url, { headers: authHeaders() })
  if (response.status === 401) {
    clearAccessToken()
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT))
    }
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  return response.text()
}

/** Download all FSM templates as a ZIP file. */
export async function downloadFsmTemplatesZip(): Promise<Blob> {
  return getBlob('/api/v1/templates/fsm/zip')
}
