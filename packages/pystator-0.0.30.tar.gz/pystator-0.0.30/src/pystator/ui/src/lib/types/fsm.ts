/** Action ref: string name, parameterized, or declarative effect */
export type FSMActionRef =
  | string
  | { name: string; params?: Record<string, unknown> }
  | { set: Record<string, unknown> }
  | { timestamp: string }
  | { increment: string }
  | { decrement: string }
  | { append: { field: string; value: unknown } }
  | { clear: string }
  | { compute: Record<string, string> }
  | { http: Record<string, unknown> }

/** State variable definition (context contract for the machine) */
export interface FSMStateVariable {
  key: string
  type?: string
  description?: string
  default?: unknown
  required?: boolean
}

export interface FSMConfig {
  meta?: {
    machine_name?: string
    version?: string
    strict_mode?: boolean
    event_normalizer?: 'lower' | 'upper'
    validate_context?: boolean
  }
  states?: FSMState[]
  transitions?: FSMTransition[]
  error_policy?: { default_fallback?: string; retry_attempts?: number }
  /** State variables (context contract). */
  state_variables?: FSMStateVariable[]
  /** Optional metadata: documented events (no execution semantics) */
  events?: Array<{ name: string; description?: string; payload?: Record<string, unknown> }>
  /** Catalog of action definitions (documentation / table editor) */
  action_definitions?: FSMActionDefinition[]
  /** Catalog of guard definitions (documentation / table editor) */
  guard_definitions?: FSMGuardDefinition[]
  /** Per-state variable constraints: { stateName: { varKey: constraintExpr } } */
  state_variable_constraints?: Record<string, Record<string, string>>
}

/** Action definition for documentation / catalog */
export interface FSMActionDefinition {
  name: string
  description?: string
  parameters?: string
}

/** Guard definition for documentation / catalog */
export interface FSMGuardDefinition {
  name: string
  description?: string
  expression?: string
}

/** Region definition for parallel states */
export interface FSMRegion {
  name: string
  initial: string
  states?: string[]
  description?: string
}

export interface FSMState {
  name: string
  type?: 'initial' | 'stable' | 'terminal' | 'error' | 'parallel'
  description?: string
  /** Parent state for hierarchical states */
  parent?: string
  /** Default child state when entering this compound state */
  initial_child?: string
  /** Regions for parallel states (type must be 'parallel') */
  regions?: FSMRegion[]
  /** Actions on enter: string, string[], or array of { name, params? } */
  on_enter?: string | FSMActionRef[]
  /** Actions on exit: string, string[], or array of { name, params? } */
  on_exit?: string | FSMActionRef[]
  /** Optional invoke (long-lived services): id, src, on_done? */
  invoke?: Array<{ id: string; src: string; on_done?: string }>
  timeout?: { seconds: number; destination: string }
  /** Optional; use metadata.context_keys (string[]) for reference state variables (documentation only). */
  metadata?: Record<string, unknown>
}

/** Guard definition — named, expression, declarative check, or composite */
export type FSMGuard =
  | string
  | { expr: string }
  | { check: { field: string; op: string; value: unknown } }
  | { allOf: FSMGuard[] }
  | { anyOf: FSMGuard[] }
  | { not: FSMGuard }
  | { negate: FSMGuard }

/** Action definition - either a string name or parameterized action (same as FSMActionRef) */
export type FSMAction = FSMActionRef

export interface FSMTransition {
  /** Optional when 'after' is set (synthetic trigger assigned by loader) */
  trigger?: string
  source: string | string[]
  dest: string
  /** Region name for parallel state transitions */
  region?: string
  guards?: FSMGuard | FSMGuard[]
  actions?: FSMAction | FSMAction[]
  /** Delay before transition fires (ms or "5s"/"5m"/"1h") */
  after?: number | string
  description?: string
  metadata?: Record<string, unknown>
}

export interface ValidateResponse {
  valid: boolean
  errors: string[]
  info?: {
    machine_name: string
    version: string
    state_names: string[]
    trigger_names: string[]
    terminal_states: string[]
  }
}

/** Matches API ActionRef: transition / on_enter / on_exit action specs */
export interface ProcessActionRef {
  name: string
  params?: Record<string, unknown>
}

export interface ProcessResponse {
  success: boolean
  source_state: string
  target_state: string | null
  trigger: string
  actions_to_execute: ProcessActionRef[]
  on_exit_actions: ProcessActionRef[]
  on_enter_actions: ProcessActionRef[]
  error: { type: string; message: string } | null
  metadata: Record<string, unknown>
}
