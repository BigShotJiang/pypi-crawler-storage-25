/**
 * Client-side validation: cross-reference guard/action names against definitions.
 */
import type { FSMConfig, FSMGuard, FSMActionRef } from '@/lib/types/fsm'

export interface ValidationResult {
  unresolvedGuards: string[]
  unresolvedActions: string[]
}

const BUILTIN_GUARDS = new Set(['always', 'never', 'key_present', 'key_missing'])

const BUILTIN_ACTIONS = new Set([
  'noop',
  'log',
  'trace',
  'set_context',
  'snapshot',
  'copy_key',
  'validate_keys',
  'publish',
  'emit_metric',
])

/** Collect named string guards from a guard or guard array (skip exprs and checks). */
function collectGuardNames(guard: FSMGuard | FSMGuard[] | undefined, out: Set<string>): void {
  if (guard === undefined) return
  const items = Array.isArray(guard) ? guard : [guard]
  for (const g of items) {
    if (typeof g === 'string') {
      out.add(g)
    }
    // expr / check objects are not named guards -- skip them
  }
}

/** Collect action names from an action ref or array of action refs. */
function collectActionNames(
  actions: string | FSMActionRef | FSMActionRef[] | undefined,
  out: Set<string>
): void {
  if (actions === undefined) return
  const items = Array.isArray(actions) ? actions : [actions]
  for (const a of items) {
    if (typeof a === 'string') {
      out.add(a)
    } else if (typeof a === 'object' && a !== null && 'name' in a) {
      out.add(a.name)
    }
  }
}

/** Validate config: return guard/action names that are neither defined nor built-in. */
export function validateConfig(config: FSMConfig): ValidationResult {
  const usedGuards = new Set<string>()
  const usedActions = new Set<string>()

  for (const t of config.transitions ?? []) {
    collectGuardNames(t.guards, usedGuards)
    collectActionNames(t.actions, usedActions)
  }

  for (const s of config.states ?? []) {
    collectActionNames(s.on_enter, usedActions)
    collectActionNames(s.on_exit, usedActions)
  }

  const definedGuards = new Set((config.guard_definitions ?? []).map((d) => d.name))
  const definedActions = new Set((config.action_definitions ?? []).map((d) => d.name))

  const unresolvedGuards = [...usedGuards].filter(
    (name) => !definedGuards.has(name) && !BUILTIN_GUARDS.has(name)
  )
  const unresolvedActions = [...usedActions].filter(
    (name) => !definedActions.has(name) && !BUILTIN_ACTIONS.has(name)
  )

  return { unresolvedGuards, unresolvedActions }
}
