export type ConfigFormatFromFilename = 'json' | 'yaml'

export function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const text = e.target?.result as string
      resolve(text ?? '')
    }
    reader.onerror = () => reject(new Error('Failed to read file'))
    reader.readAsText(file)
  })
}

export function formatFromFilename(filename: string): ConfigFormatFromFilename {
  const lower = filename.toLowerCase()
  if (lower.endsWith('.json')) return 'json'
  return 'yaml'
}

export function isAllowedFsmConfigFile(filename: string): boolean {
  const lower = filename.toLowerCase()
  return lower.endsWith('.yaml') || lower.endsWith('.yml') || lower.endsWith('.json')
}
