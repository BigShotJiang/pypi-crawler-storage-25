/**
 * Convert FSM config to React Flow nodes and edges with dagre layout.
 * Supports hierarchical states, parallel states, and delayed transitions.
 */

import dagre from 'dagre'
import { Position } from '@xyflow/react'
import type { Node, Edge } from '@xyflow/react'
import type { FSMConfig, FSMState, FSMTransition, FSMGuard, FSMAction } from './types/fsm'
import { STATE_COLORS, EDGE_STROKE, HIERARCHY_COLORS } from './diagramColors'
import { annotateParallelEdgeLabelFan } from './edgeLabelFan'

const NODE_WIDTH = 180
const NODE_HEIGHT = 44
const GROUP_PADDING = 24
const GROUP_MIN_WIDTH = 380
const GROUP_MIN_HEIGHT = 240
const CHILD_GAP = 16
/** Height of the compound node header bar (label); children are placed below this */
const COMPOUND_HEADER_HEIGHT = 40
const DAGRE_DIRECTION = 'TB'
const DAGRE_NODESEP = 120
const DAGRE_RANKSEP = 140

export interface EdgeLabelData extends Record<string, unknown> {
  label?: string
  trigger?: string
  guardsText?: string
  actionsText?: string
  delayText?: string
  regionText?: string
  isTimeout?: boolean
  /** When set on a transition edge, show timeout in the same box (avoids overlapping timeout edge) */
  timeoutLabel?: string
  isDelayed?: boolean
  /** Index into config.transitions for this edge (undefined for synthetic edges) */
  transitionIndex?: number
  /** Source state name for this edge */
  sourceName?: string
  /** Destination state name for this edge */
  destName?: string
  /** True for synthetic edges (start/end/timeout/hierarchy) that cannot be edited */
  isSynthetic?: boolean
  /** True when source and destination state are the same (self-loop) */
  isSelfLoop?: boolean
  /** When multiple transitions share the same source→target, they are grouped into one label box. */
  groupedTransitions?: Array<{
    transitionIndex: number
    label?: string
    trigger?: string
    guardsText?: string
    actionsText?: string
    delayText?: string
    regionText?: string
    timeoutLabel?: string
    isDelayed?: boolean
  }>
  /** Used by grouped transition labels to open a specific transition editor. */
  onOpenTransition?: (transitionIndex: number) => void
  /** Workspace transition note support (per machine version). */
  transitionNoteEnabled?: boolean
  transitionNoteKey?: string
  hasTransitionNote?: boolean
  transitionNoteOpen?: boolean
  transitionNoteBody?: string
  transitionNoteInitialBody?: string
  transitionNoteSaving?: boolean
  transitionNoteDeleting?: boolean
  transitionNoteMachineName?: string
  transitionNoteMachineVersion?: string
  onOpenTransitionNote?: (transitionKey: string) => void
  onCloseTransitionNote?: () => void
  onSaveTransitionNote?: (body: string) => void
  onDeleteTransitionNote?: () => void
  /** Index within edges sharing the same source→target (for fanned label positions) */
  labelParallelIndex?: number
  /** Number of edges sharing the same source→target */
  labelParallelCount?: number
}

export interface NodeData extends Record<string, unknown> {
  label: string
  /** Original state name (before display prefix like "↳" or "◈") */
  stateName?: string
  /** State-level actions (shown when diagram \"Show actions\" is enabled). */
  onEnterText?: string
  onExitText?: string
  /** Optional ops augmentation badges (counts/age/failures). */
  opsBadges?: {
    entityCount: number
    ageP95Seconds: number | null
    failedTransitionCount: number
    ageBuckets?: { le_5m: number; le_30m: number; gt_30m: number }
    topError?: { error_type: string | null; error_message: string | null; count: number } | null
  }
  /** Workspace annotation availability for this state (one note per state) */
  annotationEnabled?: boolean
  /** True if a note exists for this state */
  hasAnnotation?: boolean
  /** True when this state's note popover is currently open */
  annotationOpen?: boolean
  /** Current body for this state (from workspace notes state) */
  annotationBody?: string
  /** Persisted body for this state (used to determine delete button visibility) */
  annotationInitialBody?: string
  /** UI flags forwarded from workspace state */
  annotationSaving?: boolean
  annotationDeleting?: boolean
  /** Open/close + actions for this state's note */
  onOpenAnnotation?: (stateName: string) => void
  onCloseAnnotation?: () => void
  onSaveAnnotation?: (body: string) => void
  onDeleteAnnotation?: () => void
  /** Machine identity for note header */
  annotationMachineName?: string
  annotationMachineVersion?: string
  /** Editor placement from palette/drop (metadata.diagram_position); top-level nodes only */
  diagramPosition?: { x: number; y: number }
  stateType?: string
  isParallel?: boolean
  isCompound?: boolean
  parent?: string
  regionName?: string
  regions?: string[]
  /** Set on compound nodes for custom renderer width/height */
  compoundWidth?: number
  compoundHeight?: number
  /** True when this node is the current state of an entity instance (entity detail view) */
  isCurrentState?: boolean
  /** Reference state variables (context keys) for tooltip display */
  contextKeys?: string[]
  /** Open state editor (e.g. settings); same as diagram double-click when editable */
  onOpenStateSettings?: (stateName: string) => void
}

export interface FsmFlowOptions {
  showGuards?: boolean
  showActions?: boolean
  showHierarchy?: boolean
  /** Highlight this transition (source → target) for last-transition display */
  highlightTransition?: { source: string; target: string; trigger: string } | null
  /** Highlight this state node as current (entity instance "you are here") */
  highlightState?: string | null
}

function getContextKeys(metadata: Record<string, unknown> | undefined): string[] {
  const raw = metadata?.context_keys
  if (!Array.isArray(raw)) return []
  return raw.filter((x): x is string => typeof x === 'string')
}

/** Read persisted editor position from state metadata (palette drop / future UI). */
export function readDiagramPositionFromMetadata(
  metadata: Record<string, unknown> | undefined
): { x: number; y: number } | undefined {
  if (!metadata) return undefined
  const raw = metadata.diagram_position
  if (!raw || typeof raw !== 'object') return undefined
  const o = raw as { x?: unknown; y?: unknown }
  const x = typeof o.x === 'number' ? o.x : Number(o.x)
  const y = typeof o.y === 'number' ? o.y : Number(o.y)
  if (!Number.isFinite(x) || !Number.isFinite(y)) return undefined
  return { x, y }
}

function diagramPositionForTopLevelNode(
  s: FSMState,
  stateNames: Set<string>,
  showHierarchy: boolean
): { x: number; y: number } | undefined {
  if (s.parent && stateNames.has(s.parent) && showHierarchy) return undefined
  return readDiagramPositionFromMetadata(s.metadata)
}

/** Format guard for display - handles string, expr, and declarative check */
function formatGuard(guard: FSMGuard): string {
  if (typeof guard === 'string') return guard
  if (guard && typeof guard === 'object') {
    if ('expr' in guard && typeof (guard as { expr: string }).expr === 'string') {
      return `expr: ${(guard as { expr: string }).expr}`
    }
    if ('check' in guard && guard.check && typeof guard.check === 'object') {
      const c = guard.check as { field?: string; op?: string; value?: unknown; values?: unknown[] }
      const field = c.field ?? '?'
      const op = c.op ?? '?'
      if (c.values != null) return `check: ${field} ${op} [...]`
      return `check: ${field} ${op} ${String(c.value ?? '')}`
    }
  }
  return '[guard]'
}

/** Format action for display - handles string, parameterized name, and declarative effects */
function formatAction(action: FSMAction): string {
  if (typeof action === 'string') return action
  if (action && typeof action === 'object') {
    if ('name' in action && typeof (action as { name: string }).name === 'string') {
      const a = action as { name: string; params?: Record<string, unknown> }
      if (a.params && Object.keys(a.params).length > 0) return `${a.name}(...)`
      return a.name
    }
    if ('set' in action && action.set != null)
      return 'set(...)'
    if ('timestamp' in action && action.timestamp != null)
      return `timestamp(${String(action.timestamp)})`
    if ('increment' in action && action.increment != null)
      return `increment(${String(action.increment)})`
    if ('decrement' in action && action.decrement != null)
      return `decrement(${String(action.decrement)})`
    if ('append' in action && action.append != null) {
      const a = action.append as { field?: string; value?: unknown }
      return a?.field != null ? `append(${a.field}, ...)` : 'append(...)'
    }
    if ('clear' in action && action.clear != null)
      return `clear(${String(action.clear)})`
  }
  return '[action]'
}

function formatStateActions(actions: FSMState['on_enter'] | undefined): string | undefined {
  if (!actions) return undefined
  const arr = Array.isArray(actions) ? actions : [actions]
  const text = arr.map((a) => formatAction(a as unknown as FSMAction)).join(', ')
  return text.length > 0 ? text : undefined
}

/** Format delay for display */
function formatDelay(delay: number | string): string {
  if (typeof delay === 'string') return delay
  if (delay >= 3600000) return `${delay / 3600000}h`
  if (delay >= 60000) return `${delay / 60000}m`
  if (delay >= 1000) return `${delay / 1000}s`
  return `${delay}ms`
}

function getLayoutedNodesAndEdges(
  nodes: Node<NodeData>[],
  edges: Edge<EdgeLabelData>[],
  childrenByParent: Map<string, string[]>
): { nodes: Node<NodeData>[]; edges: Edge<EdgeLabelData>[] } {
  const g = new dagre.graphlib.Graph()
  g.setGraph({
    rankdir: DAGRE_DIRECTION,
    nodesep: DAGRE_NODESEP,
    ranksep: DAGRE_RANKSEP,
    marginx: 24,
    marginy: 24,
  })
  g.setDefaultEdgeLabel(() => ({}))

  const topLevelNodes = nodes.filter(n => !('parentId' in n && n.parentId))
  topLevelNodes.forEach((node) => {
    let width: number
    let height: number
    if (node.data.isCompound && node.style?.width != null && node.style?.height != null) {
      width = typeof node.style.width === 'number' ? node.style.width : GROUP_MIN_WIDTH
      height = typeof node.style.height === 'number' ? node.style.height : GROUP_MIN_HEIGHT
    } else {
      width = node.data.isParallel ? NODE_WIDTH * 2 : NODE_WIDTH
      height = node.data.isParallel ? NODE_HEIGHT * 2 : NODE_HEIGHT
    }
    g.setNode(node.id, { width, height })
  })

  edges.forEach((edge) => {
    if (topLevelNodes.some(n => n.id === edge.source) && topLevelNodes.some(n => n.id === edge.target)) {
      g.setEdge(edge.source, edge.target)
    }
  })

  dagre.layout(g)

  const layoutedNodes = nodes.map((node, index) => {
    const parentId = 'parentId' in node ? node.parentId : undefined
    if (parentId) {
      // Child node: position inside parent group (vertical stack, below header)
      const siblings = childrenByParent.get(parentId) ?? []
      const childIndex = siblings.indexOf(node.id)
      const x = GROUP_PADDING
      const y =
        COMPOUND_HEADER_HEIGHT + GROUP_PADDING + childIndex * (NODE_HEIGHT + CHILD_GAP)
      return {
        ...node,
        position: { x, y },
        sourcePosition: Position.Top,
        targetPosition: Position.Bottom,
      } as Node<NodeData>
    }
    const manual = node.data.diagramPosition
    if (
      manual &&
      Number.isFinite(manual.x) &&
      Number.isFinite(manual.y)
    ) {
      return {
        ...node,
        position: { x: manual.x, y: manual.y },
        sourcePosition: Position.Top,
        targetPosition: Position.Bottom,
      } as Node<NodeData>
    }

    const nodeWithPosition = g.node(node.id)
    const width = node.data.isCompound && node.style?.width != null
      ? (typeof node.style.width === 'number' ? node.style.width : GROUP_MIN_WIDTH)
      : node.data.isParallel ? NODE_WIDTH * 2 : NODE_WIDTH
    const height = node.data.isCompound && node.style?.height != null
      ? (typeof node.style.height === 'number' ? node.style.height : GROUP_MIN_HEIGHT)
      : node.data.isParallel ? NODE_HEIGHT * 2 : NODE_HEIGHT
    const x = nodeWithPosition?.x != null ? nodeWithPosition.x - width / 2 : index * (NODE_WIDTH + 40)
    const y = nodeWithPosition?.y != null ? nodeWithPosition.y - height / 2 : index * (NODE_HEIGHT + 30)
    return {
      ...node,
      position: { x, y },
      sourcePosition: Position.Top,
      targetPosition: Position.Bottom,
    } as Node<NodeData>
  })

  return { nodes: layoutedNodes, edges }
}

function stateNodeStyle(stateType: FSMState['type'] | undefined, isCompound?: boolean, isParallel?: boolean) {
  const type = stateType ?? 'stable'
  const colors = STATE_COLORS[type] ?? STATE_COLORS.stable

  const baseStyle = {
    background: colors.background,
    border: `2px solid ${colors.border}`,
    color: colors.text,
  }

  if (isParallel) {
    return {
      ...baseStyle,
      borderStyle: 'double',
      borderWidth: '4px',
      minWidth: NODE_WIDTH * 1.5,
      minHeight: NODE_HEIGHT * 1.5,
    }
  }

  if (isCompound) {
    return {
      ...baseStyle,
      borderStyle: 'dashed',
    }
  }

  return baseStyle
}

export function fsmConfigToReactFlow(
  config: FSMConfig,
  options: FsmFlowOptions = {}
): { nodes: Node<NodeData>[]; edges: Edge<EdgeLabelData>[] } {
  const states = config.states ?? []
  const transitions = config.transitions ?? []
  const {
    showGuards = true,
    showActions = false,
    showHierarchy = true,
    highlightTransition = null,
    highlightState = null,
  } = options

  const stateNames = new Set(states.map((s) => s.name))
  const stateMap = new Map(states.map(s => [s.name, s]))

  // Build hierarchy info
  const childrenMap = new Map<string, string[]>()
  states.forEach(s => {
    if (s.parent && stateNames.has(s.parent)) {
      const children = childrenMap.get(s.parent) ?? []
      children.push(s.name)
      childrenMap.set(s.parent, children)
    }
  })

  // Build state -> region name (for states under a parallel parent)
  const stateToRegionName = new Map<string, string>()
  states.forEach(s => {
    if (!s.parent || !stateNames.has(s.parent)) return
    const parent = stateMap.get(s.parent)
    if (!parent?.regions?.length) return
    for (const region of parent.regions) {
      const regionStates = region.states ?? []
      if (regionStates.includes(s.name)) {
        stateToRegionName.set(s.name, region.name)
        break
      }
    }
  })

  const nodes: Node<NodeData>[] = []
  states.forEach((s: FSMState) => {
    const isCompound = childrenMap.has(s.name)
    const isParallel = s.type === 'parallel'
    const hasRegions = s.regions && s.regions.length > 0
    const children = childrenMap.get(s.name) ?? []
    const diagramPosition = diagramPositionForTopLevelNode(s, stateNames, showHierarchy)

    if (showHierarchy && isCompound) {
      // Compound state: create a large container node so children fit inside without overlap
      const childCount = children.length
      const groupWidth = Math.max(GROUP_MIN_WIDTH, NODE_WIDTH + GROUP_PADDING * 2)
      const contentHeight =
        GROUP_PADDING * 2 + childCount * NODE_HEIGHT + (childCount - 1) * CHILD_GAP
      const groupHeight = Math.max(
        GROUP_MIN_HEIGHT,
        COMPOUND_HEADER_HEIGHT + contentHeight
      )
      const c = HIERARCHY_COLORS.parent
      nodes.push({
        id: s.name,
        type: 'compound',
        data: {
          label: showHierarchy ? `◈ ${s.name}` : s.name,
          stateName: s.name,
          stateType: s.type,
          isParallel: false,
          isCompound: true,
          parent: undefined,
          regions: hasRegions ? s.regions!.map(r => r.name) : undefined,
          compoundWidth: groupWidth,
          compoundHeight: groupHeight,
          isCurrentState: highlightState === s.name,
          ...(showActions
            ? {
                onEnterText: formatStateActions(s.on_enter),
                onExitText: formatStateActions(s.on_exit),
              }
            : {}),
          contextKeys: getContextKeys(s.metadata),
          diagramPosition,
        },
        position: { x: 0, y: 0 },
        style: {
          width: groupWidth,
          height: groupHeight,
          minWidth: groupWidth,
          minHeight: groupHeight,
          background: c.background,
          border: `2px dashed ${c.border}`,
          color: c.text,
          zIndex: 0,
        },
      })
      return
    }

    let label = s.name
    if (showHierarchy) {
      if (isParallel && hasRegions) {
        label = `⊞ ${s.name} (${s.regions!.length} regions)`
      } else if (s.parent) {
        label = `↳ ${s.name}`
      }
    }

    const regionName = stateToRegionName.get(s.name)

    nodes.push({
      id: s.name,
      type: 'state',
      data: {
        label,
        stateName: s.name,
        stateType: s.type,
        isParallel,
        isCompound,
        parent: s.parent,
        regionName: regionName ?? undefined,
        regions: hasRegions ? s.regions!.map(r => r.name) : undefined,
        isCurrentState: highlightState === s.name,
        ...(showActions
          ? {
              onEnterText: formatStateActions(s.on_enter),
              onExitText: formatStateActions(s.on_exit),
            }
          : {}),
        contextKeys: getContextKeys(s.metadata),
        diagramPosition,
      },
      position: { x: 0, y: 0 },
      style: stateNodeStyle(s.type, isCompound, isParallel),
      ...(s.parent && showHierarchy ? { parentId: s.parent, extent: 'parent' as const } : {}),
    })
  })

  const edges: Edge<EdgeLabelData>[] = []
  let edgeId = 0
  const groupedByPair = new Map<string, {
    source: string
    target: string
    rows: NonNullable<EdgeLabelData['groupedTransitions']>
    anyHighlight: boolean
    anyDelayed: boolean
  }>()
  const pairKey = (source: string, target: string) => `${source}\0${target}`

  // Process transitions
  for (let tIdx = 0; tIdx < transitions.length; tIdx++) {
    const t = transitions[tIdx]
    const sources = Array.isArray(t.source) ? t.source : [t.source]

    // Format guards (handle both string and expr formats)
    let guardsText: string | undefined
    if (showGuards && t.guards) {
      const guards = Array.isArray(t.guards) ? t.guards : [t.guards]
      guardsText = guards.map(formatGuard).join(', ')
    }

    // Format actions (handle both string and parameterized formats)
    let actionsText: string | undefined
    if (showActions && t.actions) {
      const actions = Array.isArray(t.actions) ? t.actions : [t.actions]
      actionsText = actions.map(formatAction).join(', ')
    }

    // Format delay
    const delayText = t.after ? formatDelay(t.after) : undefined
    const isDelayed = !!t.after

    // Format region
    const regionText = t.region ?? undefined

    const label = [
      t.trigger,
      guardsText ? `[${guardsText}]` : null,
      actionsText ? `/ ${actionsText}` : null,
      delayText ? `⏱ ${delayText}` : null,
      regionText ? `@${regionText}` : null,
    ].filter(Boolean).join(' ')

    for (const src of sources) {
      if (!stateNames.has(src) || !stateNames.has(t.dest)) continue
      const isHighlight =
        highlightTransition &&
        highlightTransition.source === src &&
        highlightTransition.target === t.dest &&
        highlightTransition.trigger === t.trigger
      const srcState = states.find((st) => st.name === src)
      const hasTimeoutToDest = srcState?.timeout?.destination === t.dest
      const timeoutLabel = hasTimeoutToDest ? `timeout ${srcState!.timeout!.seconds}s` : undefined
      const isSelfLoop = src === t.dest
      const k = pairKey(src, t.dest)
      const existing = groupedByPair.get(k)
      const row = {
        transitionIndex: tIdx,
        label,
        trigger: t.trigger,
        guardsText,
        actionsText,
        delayText,
        regionText,
        timeoutLabel,
        isDelayed,
      }
      if (existing) {
        existing.rows.push(row)
        existing.anyHighlight = existing.anyHighlight || !!isHighlight
        existing.anyDelayed = existing.anyDelayed || isDelayed
      } else {
        groupedByPair.set(k, {
          source: src,
          target: t.dest,
          rows: [row],
          anyHighlight: !!isHighlight,
          anyDelayed: isDelayed,
        })
      }
    }
  }

  // Emit grouped edges (one per source→target)
  for (const group of groupedByPair.values()) {
    const id = `e-${edgeId++}-${group.source}-${group.target}`
    const isSelfLoop = group.source === group.target
    const hasGrouping = group.rows.length >= 2
    edges.push({
      id,
      source: group.source,
      target: group.target,
      label: hasGrouping ? `${group.rows.length} transitions` : (group.rows[0]?.label ?? ''),
      data: hasGrouping
        ? {
            groupedTransitions: group.rows,
            isTimeout: false,
            sourceName: group.source,
            destName: group.target,
            isSelfLoop,
          }
        : {
            ...(group.rows[0] ?? {}),
            isTimeout: false,
            transitionIndex: group.rows[0]?.transitionIndex,
            sourceName: group.source,
            destName: group.target,
            isSelfLoop,
          },
      type: 'smoothstep',
      ...(isSelfLoop ? { sourcePosition: Position.Bottom, targetPosition: Position.Top } : {}),
      animated: group.anyHighlight,
      style: {
        stroke: group.anyHighlight
          ? EDGE_STROKE.highlighted
          : group.anyDelayed
            ? EDGE_STROKE.delayed
            : EDGE_STROKE.default,
        strokeWidth: group.anyHighlight ? 2 : 1,
        strokeDasharray: group.anyDelayed ? '5 5' : undefined,
      },
    })
  }

  const existingEdgeKeys = new Set(edges.map((e) => `${e.source}-${e.target}`))
  for (const s of states) {
    if (s.timeout && stateNames.has(s.timeout.destination)) {
      if (existingEdgeKeys.has(`${s.name}-${s.timeout.destination}`)) continue
      const label = `timeout ${s.timeout.seconds}s`
      edges.push({
        id: `e-timeout-${s.name}-${s.timeout.destination}`,
        source: s.name,
        target: s.timeout.destination,
        label,
        data: { label, isTimeout: true, isSynthetic: true },
        type: 'smoothstep',
        style: { stroke: EDGE_STROKE.timeout, strokeDasharray: '5 5', strokeWidth: 1 },
        selectable: false,
        deletable: false,
      })
      edgeId++
    }
  }

  // Add hierarchy edges (parent → initial_child) if showing hierarchy
  if (showHierarchy) {
    for (const s of states) {
      if (s.initial_child && stateNames.has(s.initial_child)) {
        edges.push({
          id: `e-init-child-${s.name}-${s.initial_child}`,
          source: s.name,
          target: s.initial_child,
          label: 'initial',
          data: { label: 'initial', isSynthetic: true },
          type: 'smoothstep',
          style: {
            stroke: HIERARCHY_COLORS.parent.border,
            strokeDasharray: '3 3',
            strokeWidth: 1,
          },
          selectable: false,
          deletable: false,
        })
        edgeId++
      }
    }
  }

  annotateParallelEdgeLabelFan(edges)

  return getLayoutedNodesAndEdges(nodes, edges, childrenMap)
}
