import type { FSMConfig, ValidateResponse, ProcessResponse } from '../types/fsm'
import { fetchApi } from './client'

export async function validateConfig(config: FSMConfig): Promise<ValidateResponse> {
  return fetchApi<ValidateResponse>('/api/v1/machines/validate', {
    method: 'POST',
    body: JSON.stringify({ config }),
  })
}

export async function processEvent(
  config: FSMConfig,
  currentState: string,
  trigger: string,
  context?: Record<string, unknown>
): Promise<ProcessResponse> {
  return fetchApi<ProcessResponse>('/api/v1/process', {
    method: 'POST',
    body: JSON.stringify({ config, current_state: currentState, trigger, context: context ?? {} }),
  })
}

export async function healthCheck(): Promise<{ status: string; version?: string }> {
  return fetchApi<{ status: string; version?: string }>('/health')
}
