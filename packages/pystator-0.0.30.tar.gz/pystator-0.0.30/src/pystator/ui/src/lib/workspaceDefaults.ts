import type { FSMState, FSMTransition } from '@/lib/types/fsm'

/** Default blank state for add-state modal workflows. */
export function makeBlankState(name?: string): FSMState {
  return { name: name ?? '', type: 'stable' }
}

/** Default blank transition for add-transition modal workflows. */
export function makeBlankTransition(source?: string, dest?: string): FSMTransition {
  return { trigger: '', source: source ?? '', dest: dest ?? '' }
}
