/**
 * Types for the machine browse tree.
 *
 * The tree is derived from machine names using path segments (split on `/`).
 */

/** Tree node shape matching pycharter FolderTreeNode for consistent UI. */
export interface MachineBrowseTreeNode {
  id: string
  name: string
  kind: 'folder' | 'item'
  /** For tree building we use a single type 'machine'. */
  folder_type: string
  children?: MachineBrowseTreeNode[]
  /** Present for item nodes: machine name. */
  item_id?: string
  item_label?: string
  item_meta?: Record<string, unknown>
}
