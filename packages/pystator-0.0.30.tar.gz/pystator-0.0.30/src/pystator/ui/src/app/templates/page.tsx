'use client'

import { useCallback, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import { listFsmTemplates, getFsmTemplate } from '@/lib/api'
import { fsmTemplateLabel } from '@/lib/templates'
import { ROUTES } from '@/lib/constants'
import { RefreshCw, Download, ExternalLink, FileCode2 } from 'lucide-react'

export default function TemplatesPage() {
  const router = useRouter()
  const [templates, setTemplates] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [downloading, setDownloading] = useState<string | null>(null)

  const fetchTemplates = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await listFsmTemplates()
      setTemplates(res.templates ?? [])
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchTemplates()
  }, [fetchTemplates])

  /** Fetch YAML content and trigger a browser file download. */
  const handleDownload = async (filename: string) => {
    setDownloading(filename)
    try {
      const content = await getFsmTemplate(filename)
      const blob = new Blob([content], { type: 'application/x-yaml' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setDownloading(null)
    }
  }

  /**
   * Fetch template YAML, parse into FSMConfig, store in sessionStorage,
   * then navigate to the Workspace page which picks it up on mount.
   */
  const handleLoadInWorkspace = async (filename: string) => {
    try {
      const yamlText = await getFsmTemplate(filename)
      // Store raw YAML so workspace can parse it with its own loader
      sessionStorage.setItem('pystator_load_template_yaml', yamlText)
      router.push(ROUTES.WORKSPACE)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="Templates"
        description="Starter FSM configurations you can download or load directly into the Workspace"
        actions={
          <Button variant="outline" size="sm" onClick={fetchTemplates} disabled={loading} className="gap-1.5">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        }
      />

      {error && <ErrorDisplay error={error} className="mt-4" />}

      <div className="mt-6">
        {loading && templates.length === 0 ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner />
          </div>
        ) : templates.length === 0 && !loading ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">No templates found</CardTitle>
              <CardDescription>
                Templates are YAML files bundled with the PyStator package under <code className="text-xs bg-muted px-1 py-0.5 rounded">data/templates/fsm/</code>.
              </CardDescription>
            </CardHeader>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates.map((filename) => (
              <Card key={filename} className="hover:shadow-md transition-shadow flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-indigo-100 text-indigo-600 shrink-0">
                      <FileCode2 className="h-5 w-5" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-sm leading-tight">{fsmTemplateLabel(filename)}</CardTitle>
                      <p className="text-xs text-muted-foreground font-mono mt-1 truncate">{filename}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0 mt-auto">
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-1.5"
                      onClick={() => handleLoadInWorkspace(filename)}
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Open in Workspace
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-1.5"
                      disabled={downloading === filename}
                      onClick={() => handleDownload(filename)}
                    >
                      <Download className="h-3.5 w-3.5" />
                      {downloading === filename ? '...' : 'YAML'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </PageContainer>
  )
}
