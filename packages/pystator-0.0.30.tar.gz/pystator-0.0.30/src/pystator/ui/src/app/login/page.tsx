'use client'

import { useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useAuthStore, selectLogin, selectLoading, selectIsAuthenticated, selectAuthDisabled } from '@/stores/auth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ROUTES, LOGIN_REASON_SESSION_EXPIRED } from '@/lib/constants'
import { ApiError } from '@/lib/api'
import { useAppConfigStore, selectAppName } from '@/stores/app-config'

export default function LoginPage() {
  const appName = useAppConfigStore(selectAppName)
  const login = useAuthStore(selectLogin)
  const loading = useAuthStore(selectLoading)
  const isAuthenticated = useAuthStore(selectIsAuthenticated)
  const authDisabled = useAuthStore(selectAuthDisabled)
  const router = useRouter()
  const searchParams = useSearchParams()
  const isSessionExpired = searchParams.get('reason') === LOGIN_REASON_SESSION_EXPIRED
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (loading) return
    if (authDisabled || isAuthenticated) {
      router.replace(ROUTES.HOME)
    }
  }, [loading, authDisabled, isAuthenticated, router])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      const redirectPath = await login(username, password)
      router.push(redirectPath)
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message || 'Login failed')
      } else {
        setError('Login failed')
      }
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-pulse text-muted-foreground">Checking authentication...</div>
      </div>
    )
  }

  if (authDisabled || isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Sign in</CardTitle>
          <CardDescription>Sign in to {appName} with your credentials.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {isSessionExpired && (
              <div className="rounded-md bg-muted border border-border px-3 py-2 text-sm text-muted-foreground">
                Your session expired. Please sign in again.
              </div>
            )}
            {error && (
              <div className="rounded-md bg-destructive/10 border border-destructive/20 px-3 py-2 text-sm text-destructive">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={submitting}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={submitting}
              />
            </div>
            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? 'Signing in...' : 'Sign in'}
            </Button>
          </form>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Use initial credentials from environment or pystator.cfg for development.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
