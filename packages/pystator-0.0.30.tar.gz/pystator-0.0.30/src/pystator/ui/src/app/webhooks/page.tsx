"use client"

import { useState, useCallback, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  listWebhooks,
  createWebhook,
  updateWebhook,
  deleteWebhook,
  testWebhook,
  type Webhook,
  type WebhookTestResult,
} from "@/lib/api"
import LoadingSpinner from "@/components/LoadingSpinner"
import {
  Plus,
  Pencil,
  Trash2,
  Zap,
  CheckCircle2,
  XCircle,
  X,
} from "lucide-react"

const EVENT_TYPES = [
  "transition_failed",
  "dead_letter_created",
  "dwell_time_exceeded",
] as const

type EventType = (typeof EVENT_TYPES)[number]

interface WebhookFormState {
  name: string
  url: string
  events: EventType[]
  enabled: boolean
}

const EMPTY_FORM: WebhookFormState = {
  name: "",
  url: "",
  events: [],
  enabled: true,
}

export default function WebhooksPage() {
  const [webhooks, setWebhooks] = useState<Webhook[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Form state
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<WebhookFormState>(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  // Test state
  const [testingId, setTestingId] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<
    Record<string, WebhookTestResult>
  >({})

  const fetchWebhooks = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await listWebhooks()
      setWebhooks(res.webhooks)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load webhooks")
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchWebhooks()
  }, [fetchWebhooks])

  const openCreateForm = useCallback(() => {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setFormError(null)
    setShowForm(true)
  }, [])

  const openEditForm = useCallback((wh: Webhook) => {
    setEditingId(wh.id)
    setForm({
      name: wh.name,
      url: wh.url,
      events: wh.events as EventType[],
      enabled: wh.enabled,
    })
    setFormError(null)
    setShowForm(true)
  }, [])

  const closeForm = useCallback(() => {
    setShowForm(false)
    setEditingId(null)
    setForm(EMPTY_FORM)
    setFormError(null)
  }, [])

  const toggleEvent = useCallback((event: EventType) => {
    setForm((prev) => ({
      ...prev,
      events: prev.events.includes(event)
        ? prev.events.filter((e) => e !== event)
        : [...prev.events, event],
    }))
  }, [])

  const handleSave = useCallback(async () => {
    if (!form.name.trim()) {
      setFormError("Name is required")
      return
    }
    if (!form.url.trim()) {
      setFormError("URL is required")
      return
    }
    if (form.events.length === 0) {
      setFormError("Select at least one event")
      return
    }

    setSaving(true)
    setFormError(null)
    try {
      if (editingId) {
        await updateWebhook(editingId, {
          name: form.name,
          url: form.url,
          events: form.events,
          enabled: form.enabled,
        })
      } else {
        await createWebhook({
          name: form.name,
          url: form.url,
          events: form.events,
          enabled: form.enabled,
        })
      }
      closeForm()
      await fetchWebhooks()
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : "Failed to save webhook"
      )
    } finally {
      setSaving(false)
    }
  }, [form, editingId, closeForm, fetchWebhooks])

  const handleDelete = useCallback(
    async (id: string) => {
      try {
        await deleteWebhook(id)
        await fetchWebhooks()
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to delete webhook"
        )
      }
    },
    [fetchWebhooks]
  )

  const handleToggleEnabled = useCallback(
    async (wh: Webhook) => {
      try {
        await updateWebhook(wh.id, { enabled: !wh.enabled })
        await fetchWebhooks()
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to toggle webhook"
        )
      }
    },
    [fetchWebhooks]
  )

  const handleTest = useCallback(async (id: string) => {
    setTestingId(id)
    try {
      const result = await testWebhook(id)
      setTestResult((prev) => ({ ...prev, [id]: result }))
    } catch (err) {
      setTestResult((prev) => ({
        ...prev,
        [id]: {
          success: false,
          status_code: null,
          error: err instanceof Error ? err.message : "Test failed",
        },
      }))
    } finally {
      setTestingId(null)
    }
  }, [])

  return (
    <div className="container mx-auto max-w-5xl py-8 px-4 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Webhooks</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage webhook endpoints for state machine events.
          </p>
        </div>
        {!showForm && (
          <Button onClick={openCreateForm}>
            <Plus className="mr-1.5 h-4 w-4" />
            Create Webhook
          </Button>
        )}
      </div>

      {error && (
        <div className="rounded-md border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      )}

      {/* Inline create / edit form */}
      {showForm && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-base font-semibold">
              {editingId ? "Edit Webhook" : "Create Webhook"}
            </CardTitle>
            <Button size="sm" variant="ghost" onClick={closeForm}>
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {formError && (
              <div className="rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {formError}
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="wh-name">Name</Label>
                <Input
                  id="wh-name"
                  placeholder="My webhook"
                  value={form.name}
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, name: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="wh-url">URL</Label>
                <Input
                  id="wh-url"
                  placeholder="https://example.com/hook"
                  value={form.url}
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, url: e.target.value }))
                  }
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Events</Label>
              <div className="flex flex-wrap gap-2">
                {EVENT_TYPES.map((evt) => {
                  const selected = form.events.includes(evt)
                  return (
                    <button
                      key={evt}
                      type="button"
                      onClick={() => toggleEvent(evt)}
                      className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                        selected
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      {evt}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={form.enabled}
                onCheckedChange={(checked) =>
                  setForm((prev) => ({ ...prev, enabled: checked }))
                }
              />
              <Label>Enabled</Label>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <Button onClick={handleSave} disabled={saving}>
                {saving ? <LoadingSpinner /> : editingId ? "Update" : "Create"}
              </Button>
              <Button variant="outline" onClick={closeForm} disabled={saving}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Webhooks table */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <LoadingSpinner />
        </div>
      ) : webhooks.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Zap className="h-10 w-10 text-muted-foreground/50 mb-3" />
            <p className="text-sm text-muted-foreground">
              No webhooks configured yet.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="overflow-x-auto rounded-md border">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="px-4 py-2.5 text-left font-medium">Name</th>
                <th className="px-4 py-2.5 text-left font-medium">URL</th>
                <th className="px-4 py-2.5 text-left font-medium">Events</th>
                <th className="px-4 py-2.5 text-left font-medium">Enabled</th>
                <th className="px-4 py-2.5 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {webhooks.map((wh) => {
                const result = testResult[wh.id]
                return (
                  <tr key={wh.id} className="border-b hover:bg-muted/30">
                    <td className="px-4 py-2.5 font-medium">{wh.name}</td>
                    <td className="px-4 py-2.5">
                      <code className="rounded bg-muted px-1.5 py-0.5 text-xs break-all">
                        {wh.url}
                      </code>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex flex-wrap gap-1">
                        {wh.events.map((evt) => (
                          <span
                            key={evt}
                            className="rounded-full bg-muted px-2 py-0.5 text-xs"
                          >
                            {evt}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <Switch
                        checked={wh.enabled}
                        onCheckedChange={() => handleToggleEnabled(wh)}
                      />
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleTest(wh.id)}
                          disabled={testingId === wh.id}
                          title="Test webhook"
                        >
                          {testingId === wh.id ? (
                            <LoadingSpinner />
                          ) : (
                            <Zap className="h-3.5 w-3.5" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => openEditForm(wh)}
                          title="Edit webhook"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(wh.id)}
                          title="Delete webhook"
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>

                      {/* Test result feedback */}
                      {result && (
                        <div className="mt-1.5 flex items-center justify-end gap-1.5 text-xs">
                          {result.success ? (
                            <>
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                              <span className="text-emerald-600 dark:text-emerald-400">
                                OK {result.status_code && `(${result.status_code})`}
                              </span>
                            </>
                          ) : (
                            <>
                              <XCircle className="h-3.5 w-3.5 text-destructive" />
                              <span className="text-destructive truncate max-w-[160px]">
                                {result.error ?? "Failed"}
                                {result.status_code && ` (${result.status_code})`}
                              </span>
                            </>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
