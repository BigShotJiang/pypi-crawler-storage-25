'use client'

import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import { createPortal } from 'react-dom'
import type { NodeProps } from '@xyflow/react'
import type { Node } from '@xyflow/react'
import { Handle, Position, useStore } from '@xyflow/react'
import type { NodeData } from '@/lib/fsmToReactFlow'
import { STATE_COLORS, CURRENT_STATE_HIGHLIGHT } from '@/lib/diagramColors'
import { EDGE_LABEL_COLORS } from '@/lib/diagramColors'
import { cn } from '@/lib/utils'
import { useFsmDiagramFocus } from './FsmDiagramFocusContext'
import { StickyNote, BarChart3, Settings } from 'lucide-react'
import { StateAnnotationPopover } from '@/components/annotations/StateAnnotationPopover'
import { AugmentationRail } from './AugmentationRail'

function formatAge(seconds: number): string {
  if (seconds < 60) return `${seconds}s`
  if (seconds < 3600) return `${Math.round(seconds / 60)}m`
  if (seconds < 86400) return `${Math.round(seconds / 3600)}h`
  return `${Math.round(seconds / 86400)}d`
}

/** Matches transition `Chip` (Figma) styling in `EdgeWithLabel.tsx`. */
function chipTextClamp(): CSSProperties {
  return {
    display: '-webkit-box',
    WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical',
    overflow: 'hidden',
    wordBreak: 'break-word',
  }
}

function StateDiagramChip({
  kind,
  label,
  text,
  title,
}: {
  kind: keyof typeof EDGE_LABEL_COLORS
  label: string
  text: string
  title?: string
}) {
  const c = EDGE_LABEL_COLORS[kind]
  return (
    <div
      className="inline-flex max-w-full min-w-0 items-center gap-1.5 rounded-full border px-2 py-0.5 text-left text-[10px] leading-4 shadow-[0_1px_0_rgba(0,0,0,0.04)]"
      style={{
        background: c.bg,
        borderColor: c.border,
        color: c.text,
      }}
      title={title ?? text}
    >
      <span
        className="h-1.5 w-1.5 shrink-0 rounded-full"
        style={{ background: c.border }}
        aria-hidden
      />
      <span className="font-semibold shrink-0">{label}</span>
      <span className="min-w-0 flex-1" style={chipTextClamp()}>
        {text}
      </span>
    </div>
  )
}

function OpsDetailsPopover({
  stateName,
  ops,
}: {
  stateName: string
  ops: NonNullable<NodeData['opsBadges']>
}) {
  const b = ops.ageBuckets
  const top = ops.topError
  return (
    <div className="w-[320px] max-w-[calc(100vw-48px)] rounded-lg border bg-background shadow-lg">
      <div className="flex items-start justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold">State metrics</div>
          <div className="mt-1 font-mono text-[10px] text-muted-foreground truncate">{stateName}</div>
        </div>
      </div>
      <div className="space-y-2 p-4 text-xs">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Entities</span>
          <span className="font-medium">{ops.entityCount}</span>
        </div>
        {ops.ageP95Seconds != null ? (
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Age p95</span>
            <span className="font-medium">{formatAge(ops.ageP95Seconds)}</span>
          </div>
        ) : null}
        {b ? (
          <div className="space-y-1 rounded-md bg-muted/30 px-2 py-2">
            <div className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              Age buckets
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">≤5m</span>
              <span className="font-medium">{b.le_5m}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">5–30m</span>
              <span className="font-medium">{b.le_30m}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">&gt;30m</span>
              <span className="font-medium">{b.gt_30m}</span>
            </div>
          </div>
        ) : null}
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Failures (window)</span>
          <span className="font-medium">{ops.failedTransitionCount}</span>
        </div>
        {top ? (
          <div className="space-y-1 rounded-md border bg-background px-2 py-2">
            <div className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              Top error
            </div>
            <div className="text-[11px] font-medium">
              {(top.error_type ?? 'Error')}{' '}
              <span className="text-muted-foreground">({top.count})</span>
            </div>
            {top.error_message ? (
              <div className="text-[10px] text-muted-foreground whitespace-pre-wrap break-words">
                {top.error_message}
              </div>
            ) : null}
          </div>
        ) : null}
      </div>
    </div>
  )
}

/**
 * Custom state node that shows the state label and, when the state belongs to a
 * region (parallel state track), a small region badge inside the box for easier identification.
 * When isCurrentState is true (entity detail view), shows a ring to indicate "you are here".
 *
 * Handles become larger and show a crosshair cursor when the diagram is in connectable mode,
 * making it easier to initiate connections by dragging. Terminal states suppress the source
 * handle because you cannot create transitions FROM a terminal state.
 */
export function StateNode({ data, id }: NodeProps<Node<NodeData>>) {
  const d = data as NodeData
  const label = d.label ?? ''
  const regionName = d.regionName
  const stateType = (d.stateType ?? 'stable') as keyof typeof STATE_COLORS
  const colors = STATE_COLORS[stateType] ?? STATE_COLORS.stable
  const isCurrentState = d.isCurrentState === true
  const isTerminal = stateType === 'terminal'
  const contextKeys = (d.contextKeys ?? []) as string[]
  const hasContextKeys = contextKeys.length > 0
  const onEnterText = (d.onEnterText as string | undefined) ?? undefined
  const onExitText = (d.onExitText as string | undefined) ?? undefined
  const hasStateActions = (onEnterText != null && onEnterText !== '') || (onExitText != null && onExitText !== '')
  const { focusedEdgeSourceId, focusedEdgeTargetId } = useFsmDiagramFocus()
  const isFocusedSourceNode = focusedEdgeSourceId === id
  const isFocusedTargetNode = focusedEdgeTargetId === id
  const tooltipTitle = hasContextKeys
    ? `State variables: ${contextKeys.join(', ')}`
    : undefined
  const stateName = d.stateName ?? ''
  const annotationEnabled = d.annotationEnabled === true && stateName.length > 0
  const hasAnnotation = d.hasAnnotation === true
  const ops = d.opsBadges
  const hasChipRow =
    (regionName != null && regionName !== '') ||
    hasContextKeys ||
    (ops != null &&
      (ops.entityCount > 0 ||
        (ops.ageP95Seconds != null && ops.ageP95Seconds >= 600) ||
        ops.failedTransitionCount > 0))
  /** Match transition `isTriggerOnly`: center the title pill when it is the only body content. */
  const isStateTitleOnly = !hasChipRow && !hasStateActions
  const onOpenAnnotation = d.onOpenAnnotation
  const onOpenStateSettings = d.onOpenStateSettings
  const annotationOpen = d.annotationOpen === true
  const onCloseAnnotation = d.onCloseAnnotation
  const onSaveAnnotation = d.onSaveAnnotation
  const onDeleteAnnotation = d.onDeleteAnnotation
  const noteMachineName = d.annotationMachineName ?? ''
  const noteMachineVersion = d.annotationMachineVersion ?? ''
  const noteInitial = d.annotationInitialBody ?? ''
  const noteSaving = d.annotationSaving === true
  const noteDeleting = d.annotationDeleting === true
  const [noteBody, setNoteBody] = useState(d.annotationBody ?? '')
  const [mounted, setMounted] = useState(false)
  const [notePos, setNotePos] = useState<{ left: number; top: number } | null>(null)
  const notePanelRef = useRef<HTMLDivElement | null>(null)
  const noteBtnRef = useRef<HTMLButtonElement | null>(null)
  const nodeWrapRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => setMounted(true), [])

  useEffect(() => {
    if (!annotationOpen) return
    setNoteBody(d.annotationBody ?? '')
  }, [annotationOpen, d.annotationBody])

  useEffect(() => {
    if (!annotationOpen) return
    function onPointerDown(e: PointerEvent) {
      const t = e.target as HTMLElement
      if (notePanelRef.current && notePanelRef.current.contains(t)) return
      if (noteBtnRef.current && noteBtnRef.current.contains(t)) return
      onCloseAnnotation?.()
    }
    // Capture makes this robust against ReactFlow surfaces stopping propagation.
    document.addEventListener('pointerdown', onPointerDown, { capture: true })
    return () =>
      document.removeEventListener('pointerdown', onPointerDown, { capture: true } as any)
  }, [annotationOpen, onCloseAnnotation])

  useEffect(() => {
    if (!annotationOpen) {
      setNotePos(null)
      return
    }

    let raf = 0
    const tick = () => {
      const el = nodeWrapRef.current
      if (el) {
        const r = el.getBoundingClientRect()
        const left = Math.min(window.innerWidth - 16, r.right + 8)
        const top = Math.min(window.innerHeight - 16, Math.max(8, r.top))
        setNotePos((prev) => {
          if (prev && Math.abs(prev.left - left) < 0.5 && Math.abs(prev.top - top) < 0.5) return prev
          return { left, top }
        })
      }
      raf = window.requestAnimationFrame(tick)
    }
    raf = window.requestAnimationFrame(tick)
    return () => window.cancelAnimationFrame(raf)
  }, [annotationOpen])

  // Check if the diagram allows connections (editable mode)
  const isConnectable = useStore((s) => {
    const node = s.nodeLookup.get(id)
    return node?.internals?.handleBounds != null && s.nodesConnectable
  })

  const handleClass = isConnectable
    ? '!w-3 !h-3 !border-2 cursor-crosshair'
    : '!w-2 !h-2 !border-2'

  const [opsOpen, setOpsOpen] = useState(false)
  const opsPanelRef = useRef<HTMLDivElement | null>(null)
  const opsOpenEnabled = ops != null && stateName.length > 0
  const opsPos = useMemo(() => {
    if (!opsOpen) return null
    const el = nodeWrapRef.current
    if (!el) return null
    const r = el.getBoundingClientRect()
    const left = Math.min(window.innerWidth - 16, r.right + 8)
    const top = Math.min(window.innerHeight - 16, Math.max(8, r.top))
    return { left, top }
  }, [opsOpen])

  useEffect(() => {
    if (!opsOpen) return
    function onPointerDown(e: PointerEvent) {
      const t = e.target as HTMLElement
      if (opsPanelRef.current && opsPanelRef.current.contains(t)) return
      if (nodeWrapRef.current && nodeWrapRef.current.contains(t)) return
      setOpsOpen(false)
    }
    document.addEventListener('pointerdown', onPointerDown, { capture: true })
    return () =>
      document.removeEventListener('pointerdown', onPointerDown, { capture: true } as any)
  }, [opsOpen])

  return (
    <div
      ref={nodeWrapRef}
      className="group relative flex min-w-[180px] min-h-[44px] overflow-hidden rounded-lg shadow-sm"
      title={tooltipTitle}
      style={{
        border: `2px solid ${colors.border}`,
        ...(isCurrentState
          ? {
              boxShadow: CURRENT_STATE_HIGHLIGHT.shadow,
              outline: `${CURRENT_STATE_HIGHLIGHT.ringWidth}px solid ${CURRENT_STATE_HIGHLIGHT.ring}`,
              outlineOffset: 2,
            }
          : isFocusedSourceNode
            ? {
                boxShadow: '0 0 0 2px rgba(59,130,246,0.25)',
                outline: '2px solid rgba(37,99,235,0.9)',
                outlineOffset: 2,
              }
            : isFocusedTargetNode
              ? {
                  boxShadow: '0 0 0 2px rgba(14,165,233,0.18)',
                  outline: '2px solid rgba(14,165,233,0.65)',
                  outlineOffset: 2,
                }
              : {}),
      }}
    >
      <Handle type="target" position={Position.Top} className={handleClass} />
      <div
        className="flex min-w-0 flex-1 flex-col items-stretch justify-center gap-1 px-3 py-2 text-left"
        style={{
          background: colors.background,
          color: colors.text,
        }}
      >
        <div
          className={cn(
            'min-w-0 w-full',
            isStateTitleOnly ? 'flex items-center justify-center' : ''
          )}
        >
          <div className="min-w-0 text-[11px] font-semibold">
            <span
              className={
                isStateTitleOnly
                  ? 'inline-flex min-w-0 max-w-full items-center justify-center rounded-full px-2.5 py-1 text-center'
                  : 'inline-block max-w-full rounded px-1.5 py-0.5'
              }
              style={{
                background: EDGE_LABEL_COLORS.trigger.bg,
                border: `1px solid ${EDGE_LABEL_COLORS.trigger.border}`,
                color: EDGE_LABEL_COLORS.trigger.text,
              }}
              title={label}
            >
              <span className={isStateTitleOnly ? 'min-w-0 max-w-full truncate' : 'truncate'}>{label}</span>
            </span>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-start gap-1">
          {regionName != null && regionName !== '' ? (
            <StateDiagramChip kind="region" label="@" text={regionName} title={`Region: ${regionName}`} />
          ) : null}
          {hasContextKeys ? (
            <StateDiagramChip
              kind="trigger"
              label="ctx"
              text={`${contextKeys.length} var${contextKeys.length !== 1 ? 's' : ''}`}
              title={tooltipTitle}
            />
          ) : null}
          {ops && ops.entityCount > 0 ? (
            <StateDiagramChip
              kind="initial"
              label="n"
              text={`${ops.entityCount} entit${ops.entityCount !== 1 ? 'ies' : 'y'}`}
              title="Entities currently in this state"
            />
          ) : null}
          {ops && ops.ageP95Seconds != null && ops.ageP95Seconds >= 600 ? (
            <StateDiagramChip
              kind="delay"
              label="p95"
              text={formatAge(ops.ageP95Seconds)}
              title="Age p95 (stuckness signal)"
            />
          ) : null}
          {ops && ops.failedTransitionCount > 0 ? (
            <StateDiagramChip
              kind="guards"
              label="err"
              text={String(ops.failedTransitionCount)}
              title="Failed transitions (window)"
            />
          ) : null}
        </div>
        {hasStateActions ? (
          <div className="mt-0.5 flex w-full min-w-0 flex-col items-stretch gap-1 text-left">
            {onEnterText ? (
              <StateDiagramChip
                kind="actions"
                label="E"
                text={onEnterText}
                title={`on_enter: ${onEnterText}`}
              />
            ) : null}
            {onExitText ? (
              <StateDiagramChip
                kind="actions"
                label="X"
                text={onExitText}
                title={`on_exit: ${onExitText}`}
              />
            ) : null}
          </div>
        ) : null}
      </div>
      <AugmentationRail
        variant="attached"
        hasNote={hasAnnotation && annotationEnabled}
        noteButton={
          <button
            type="button"
            ref={noteBtnRef}
            disabled={!annotationEnabled}
            className={cn(
              'grid h-7 w-7 place-items-center rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1',
              !annotationEnabled && 'cursor-not-allowed opacity-40',
              annotationEnabled &&
                (hasAnnotation
                  ? 'text-amber-700 hover:bg-amber-100/80 dark:text-amber-300 dark:hover:bg-amber-950/40'
                  : 'text-muted-foreground hover:bg-muted/60 hover:text-foreground')
            )}
            title={
              !annotationEnabled
                ? 'Notes unavailable in this view'
                : hasAnnotation
                  ? 'View or edit note'
                  : 'Add note'
            }
            aria-label={
              !annotationEnabled
                ? 'Notes unavailable'
                : hasAnnotation
                  ? 'View or edit note'
                  : 'Add note'
            }
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              if (!annotationEnabled || !onOpenAnnotation) return
              onOpenAnnotation(stateName)
            }}
          >
            <StickyNote className="h-4 w-4" />
          </button>
        }
      >
        <button
          type="button"
          disabled={!opsOpenEnabled}
          className={cn(
            'grid h-7 w-7 place-items-center rounded-md text-muted-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1',
            !opsOpenEnabled && 'cursor-not-allowed opacity-40',
            opsOpenEnabled && 'hover:bg-muted/60 hover:text-foreground'
          )}
          title={!opsOpenEnabled ? 'Metrics unavailable in this view' : 'State metrics'}
          aria-label="State metrics"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation()
            if (!opsOpenEnabled) return
            setOpsOpen((v) => !v)
          }}
        >
          <BarChart3 className="h-4 w-4" />
        </button>
        <button
          type="button"
          disabled={!onOpenStateSettings}
          className={cn(
            'grid h-7 w-7 place-items-center rounded-md text-muted-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1',
            !onOpenStateSettings && 'cursor-not-allowed opacity-40',
            onOpenStateSettings && 'hover:bg-muted/60 hover:text-foreground'
          )}
          title={!onOpenStateSettings ? 'Edit state unavailable' : 'Edit state'}
          aria-label="Edit state"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation()
            if (!onOpenStateSettings || !stateName) return
            onOpenStateSettings(stateName)
          }}
        >
          <Settings className="h-4 w-4" />
        </button>
      </AugmentationRail>
      {opsOpenEnabled && opsOpen && mounted && typeof document !== 'undefined' && opsPos && ops ? createPortal(
        <div
          ref={opsPanelRef}
          className="fixed"
          style={{ left: opsPos.left, top: opsPos.top, zIndex: 999999 }}
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
        >
          <OpsDetailsPopover stateName={stateName} ops={ops} />
        </div>,
        document.body
      ) : null}
      {annotationEnabled && annotationOpen && mounted && typeof document !== 'undefined' && notePos
        ? createPortal(
            <div
              ref={notePanelRef}
              className="fixed"
              style={{
                left: notePos.left,
                top: notePos.top,
                zIndex: 999999,
              }}
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => e.stopPropagation()}
            >
              <StateAnnotationPopover
                machineName={noteMachineName}
                machineVersion={noteMachineVersion}
                stateName={stateName}
                body={noteBody}
                initialBody={noteInitial}
                saving={noteSaving}
                deleting={noteDeleting}
                onBodyChange={setNoteBody}
                onClose={() => onCloseAnnotation?.()}
                onSave={() => onSaveAnnotation?.(noteBody)}
                onDelete={() => onDeleteAnnotation?.()}
              />
            </div>,
            document.body
          )
        : null}
      {!isTerminal && (
        <Handle type="source" position={Position.Bottom} className={handleClass} />
      )}
    </div>
  )
}
