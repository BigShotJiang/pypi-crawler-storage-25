'use client'

import { AlertCircle, Settings } from 'lucide-react'
import Link from 'next/link'
import { ApiError } from '@/lib/api'
import { getApiBaseUrl } from '@/lib/settings'
import { cn } from '@/lib/utils'

interface ErrorDisplayProps {
  error: Error | ApiError | null
  title?: string
  className?: string
}

export default function ErrorDisplay({ error, title = 'Error', className }: ErrorDisplayProps) {
  if (!error) return null
  const message = error instanceof ApiError ? error.message : error.message
  const isConnection = message.includes('Unable to connect') || message.includes('Failed to fetch') || (error instanceof ApiError && error.status === 0)
  const apiUrl = isConnection ? getApiBaseUrl() : null

  return (
    <div className={cn('rounded-lg border border-destructive/50 bg-destructive/10 p-4', className)}>
      <div className="flex">
        <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
        <div className="ml-3 flex-1">
          <h3 className="text-sm font-medium text-destructive">{title}</h3>
          <p className="mt-2 text-sm text-destructive/90">{message}</p>
          {isConnection && apiUrl && (
            <div className="mt-4 p-3 bg-white/50 rounded border border-destructive/20">
              <p className="text-xs font-medium mb-2">To fix:</p>
              <ol className="text-xs text-slate-600 space-y-1 list-decimal list-inside">
                <li>Start API: <code className="px-1.5 py-0.5 bg-slate-100 rounded">uvicorn pystator.api.main:app --port 8000</code></li>
                <li>Or set API URL in <Link href="/settings/" className="text-indigo-600 hover:underline">Settings</Link></li>
              </ol>
              <p className="mt-2 text-xs text-slate-500">API URL: <code className="px-1 py-0.5 bg-slate-100 rounded">{apiUrl}</code></p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
