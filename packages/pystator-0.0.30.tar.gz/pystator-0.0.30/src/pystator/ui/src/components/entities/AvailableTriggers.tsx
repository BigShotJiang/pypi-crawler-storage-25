'use client'

import { useCallback, useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { getAvailableTriggers, dryRunTransition } from '@/lib/api'
import type { TriggerInfo, DryRunResponse } from '@/lib/api'
import { Shield, Zap, Eye, CheckCircle2, XCircle, Loader2 } from 'lucide-react'

/** Stable unique id per row: same trigger can appear on multiple transitions (guards/dest). */
function triggerRowKey(t: TriggerInfo, index: number): string {
  return `${index}-${t.trigger}-${t.target_state}`
}

interface AvailableTriggersProps {
  entityId: string
  currentState: string
  onTriggerSelect: (trigger: string) => void
}

export default function AvailableTriggers({
  entityId,
  currentState,
  onTriggerSelect,
}: AvailableTriggersProps) {
  const [triggers, setTriggers] = useState<TriggerInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [previewingKey, setPreviewingKey] = useState<string | null>(null)
  const [previewResult, setPreviewResult] = useState<Record<string, DryRunResponse>>({})

  const fetchTriggers = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getAvailableTriggers(entityId)
      setTriggers(res.triggers)
      setPreviewResult({})
      setPreviewingKey(null)
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      setError(msg)
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    fetchTriggers()
  }, [fetchTriggers, currentState])

  const handlePreview = async (rowKey: string, trigger: string) => {
    setPreviewingKey(rowKey)
    try {
      const result = await dryRunTransition(entityId, { trigger })
      setPreviewResult((prev) => ({ ...prev, [rowKey]: result }))
    } catch {
      // silently ignore preview errors
    } finally {
      setPreviewingKey(null)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        Loading triggers...
      </div>
    )
  }

  if (error) {
    return (
      <p className="text-sm text-muted-foreground py-2">
        Could not load triggers: {error}
      </p>
    )
  }

  if (triggers.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-2">
        No triggers available from current state.
      </p>
    )
  }

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground uppercase tracking-wider">
        Available Triggers
      </p>
      <div className="flex flex-wrap gap-2">
        {triggers.map((t, index) => {
          const rowKey = triggerRowKey(t, index)
          const preview = previewResult[rowKey]
          const isPreviewing = previewingKey === rowKey

          return (
            <div key={rowKey} className="space-y-1">
              <div className="flex items-center gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onTriggerSelect(t.trigger)}
                  className={`gap-1.5 text-xs ${t.has_guard ? 'opacity-80' : ''}`}
                >
                  {t.has_guard ? (
                    <Shield className="h-3 w-3 text-amber-500" />
                  ) : (
                    <Zap className="h-3 w-3" />
                  )}
                  {t.trigger}
                  <span className="text-muted-foreground">
                    &rarr; {t.target_state}
                  </span>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handlePreview(rowKey, t.trigger)}
                  disabled={isPreviewing}
                  className="h-7 w-7 p-0"
                  title="Preview transition (dry run)"
                >
                  {isPreviewing ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <Eye className="h-3 w-3" />
                  )}
                </Button>
              </div>

              {t.has_guard && t.guard_description && (
                <p className="text-xs text-muted-foreground pl-1">
                  Guard: {t.guard_description}
                </p>
              )}

              {preview && (
                <div
                  className={`rounded border px-2 py-1 text-xs ${
                    preview.would_succeed
                      ? 'border-emerald-300 bg-emerald-50 dark:border-emerald-700 dark:bg-emerald-950/30'
                      : 'border-destructive/50 bg-destructive/10'
                  }`}
                >
                  <span className="flex items-center gap-1">
                    {preview.would_succeed ? (
                      <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                    ) : (
                      <XCircle className="h-3 w-3 text-destructive" />
                    )}
                    {preview.would_succeed
                      ? `Would transition to ${preview.target_state}`
                      : preview.error_detail ?? 'Would fail'}
                  </span>
                  {preview.actions_that_would_execute.length > 0 && (
                    <p className="text-muted-foreground mt-0.5">
                      Actions: {preview.actions_that_would_execute.join(', ')}
                    </p>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
