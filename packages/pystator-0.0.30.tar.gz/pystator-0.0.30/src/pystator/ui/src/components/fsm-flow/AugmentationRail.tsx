'use client'

import { Children, type ReactNode } from 'react'
import { cn } from '@/lib/utils'

export type AugmentationRailVariant = 'overlay' | 'attached'

export function AugmentationRail({
  hasNote,
  noteButton,
  children,
  className,
  variant = 'overlay',
}: {
  /** When true, the note icon is subtly visible even when not hovering (overlay only). */
  hasNote: boolean
  noteButton: ReactNode | null
  /** Additional augmentation buttons (hover/focus-within only for overlay). */
  children?: ReactNode
  className?: string
  /** `overlay`: hover rail on diagram nodes/edges. `attached`: fixed sidebar with dividers (state nodes). */
  variant?: AugmentationRailVariant
}) {
  if (variant === 'attached') {
    const rows: ReactNode[] = []
    if (noteButton) rows.push(noteButton)
    Children.forEach(children, (c) => {
      if (c != null && c !== false) rows.push(c)
    })
    if (rows.length === 0) return null

    return (
      <div
        className={cn(
          'w-9 shrink-0 self-stretch',
          'flex flex-col border-l border-border/60 bg-muted/25 dark:bg-muted/15',
          className
        )}
      >
        {rows.map((row, i) => (
          <div
            key={i}
            className={cn(
              'flex min-h-[36px] flex-1 items-center justify-center border-b border-border/50 px-0.5 py-1 last:border-b-0',
              'first:pt-1.5 last:pb-1.5'
            )}
          >
            <div className="flex items-center justify-center">{row}</div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div
      className={cn(
        'w-7 shrink-0 self-stretch',
        'flex flex-col items-center justify-center gap-1',
        className
      )}
    >
      {noteButton ? (
        <div
          className={cn(
            hasNote ? 'opacity-60 pointer-events-auto' : 'opacity-0 pointer-events-none',
            'transition-opacity duration-150',
            'group-hover:opacity-100 group-hover:pointer-events-auto',
            'group-focus-within:opacity-100 group-focus-within:pointer-events-auto'
          )}
        >
          {noteButton}
        </div>
      ) : null}
      {children ? (
        <div
          className={cn(
            'opacity-0 pointer-events-none transition-opacity duration-150',
            'group-hover:opacity-100 group-hover:pointer-events-auto',
            'group-focus-within:opacity-100 group-focus-within:pointer-events-auto',
            'flex flex-col items-center gap-1'
          )}
        >
          {children}
        </div>
      ) : null}
    </div>
  )
}
