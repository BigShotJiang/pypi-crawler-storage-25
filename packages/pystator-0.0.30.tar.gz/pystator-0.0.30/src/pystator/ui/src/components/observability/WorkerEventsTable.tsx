'use client'

import { Button } from '@/components/ui/button'
import type { ObservabilityWorkerEventItem } from '@/lib/api'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface WorkerEventsTableProps {
  items: ObservabilityWorkerEventItem[]
  total: number
  limit: number
  offset: number
  status: 'all' | 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  loading: boolean
  onStatusChange: (value: 'all' | 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter') => void
  onPrev: () => void
  onNext: () => void
  onEntityClick: (entityId: string) => void
}

function formatTime(iso: string | null): string {
  if (!iso) return '—'
  return new Date(iso).toLocaleString()
}

function statusClass(status: ObservabilityWorkerEventItem['status']): string {
  if (status === 'completed') return 'bg-emerald-100 text-emerald-800'
  if (status === 'failed' || status === 'dead_letter') return 'bg-red-100 text-red-800'
  if (status === 'claimed') return 'bg-amber-100 text-amber-800'
  return 'bg-blue-100 text-blue-800'
}

export function WorkerEventsTable({
  items,
  total,
  limit,
  offset,
  status,
  loading,
  onStatusChange,
  onPrev,
  onNext,
  onEntityClick,
}: WorkerEventsTableProps) {
  const hasPrev = offset > 0
  const hasNext = offset + limit < total

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">Worker Queue Events</div>
        <select
          className="rounded-md border border-input bg-background px-2 py-1.5 text-sm"
          value={status}
          onChange={(e) => onStatusChange(e.target.value as WorkerEventsTableProps['status'])}
        >
          <option value="all">All statuses</option>
          <option value="pending">Pending</option>
          <option value="claimed">Claimed</option>
          <option value="completed">Completed</option>
          <option value="failed">Failed</option>
          <option value="dead_letter">Dead letter</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="min-w-full divide-y divide-border">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Created</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Machine</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Entity</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Trigger</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Status</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Transition ID</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Attempt</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Error</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border bg-background">
            {loading ? (
              <tr>
                <td colSpan={8} className="px-3 py-10 text-center text-sm text-muted-foreground">Loading worker events…</td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-3 py-10 text-center text-sm text-muted-foreground">No worker events for this filter scope.</td>
              </tr>
            ) : (
              items.map((item) => (
                <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{formatTime(item.created_at)}</td>
                  <td className="px-3 py-2 text-sm text-muted-foreground whitespace-nowrap">{item.machine_name}</td>
                  <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => onEntityClick(item.entity_id)}
                      className="text-primary hover:underline"
                    >
                      {item.entity_id}
                    </button>
                  </td>
                  <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">{item.trigger}</td>
                  <td className="px-3 py-2 text-xs whitespace-nowrap">
                    <span className={`inline-flex rounded px-2 py-0.5 font-medium ${statusClass(item.status)}`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs font-mono text-muted-foreground whitespace-nowrap">
                    {item.transition_history_id ?? '—'}
                  </td>
                  <td className="px-3 py-2 text-sm text-muted-foreground whitespace-nowrap">{item.attempt}/{item.max_attempts}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground max-w-[240px] truncate" title={item.error_message ?? ''}>
                    {item.error_message ?? '—'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {total === 0 ? 'No records' : `Showing ${offset + 1}–${Math.min(offset + limit, total)} of ${total}`}
        </p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={!hasPrev || loading} onClick={onPrev}>
            <ChevronLeft className="h-4 w-4 mr-1" /> Prev
          </Button>
          <Button variant="outline" size="sm" disabled={!hasNext || loading} onClick={onNext}>
            Next <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  )
}
