'use client'

import { useCallback, useMemo } from 'react'
import {
  StateTable,
  VariableTable,
  TransitionMatrix,
  TransitionList,
  StateVariableMatrix,
  EventTable,
  ActionGuardTable,
  ErrorPolicyForm,
} from '@/components/table-editor'
import {
  useWorkspaceStore,
  selectConfig,
  selectSetConfig,
  selectActiveTableTab,
  selectSetActiveTableTab,
} from '@/stores/workspace'
import type { TableTabId } from '@/stores/workspace'

// ---------------------------------------------------------------------------
// Tab definitions (mirrors table-editor/page.tsx)
// ---------------------------------------------------------------------------

const TABS: { id: TableTabId; label: string }[] = [
  { id: 'states', label: 'States' },
  { id: 'variables', label: 'Variables' },
  { id: 'transition_matrix', label: 'Transition matrix' },
  { id: 'transition_list', label: 'Transition list' },
  { id: 'state_variables', label: 'State × Variables' },
  { id: 'events', label: 'Events' },
  { id: 'actions_guards', label: 'Actions / Guards' },
  { id: 'error_policy', label: 'Error policy' },
]

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * Table editor embedded in the workspace center area.
 *
 * Reads and writes the FSM config from the workspace Zustand store,
 * so every cell edit automatically gets an undo point and stays in
 * sync with the diagram view and sidebar.
 */
export default function WorkspaceTableEditor() {
  const config = useWorkspaceStore(selectConfig)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const activeTab = useWorkspaceStore(selectActiveTableTab)
  const setActiveTab = useWorkspaceStore(selectSetActiveTableTab)

  // Derived data
  const stateNames = useMemo(
    () => (config.states ?? []).map((s) => s.name),
    [config.states],
  )

  const variableKeys = useMemo(
    () => (config.state_variables ?? []).map((v) => v.key),
    [config.state_variables],
  )

  // Config update helpers — each creates an undo point via setConfig
  const handleStatesChange = useCallback(
    (states: typeof config.states) => setConfig((prev) => ({ ...prev, states })),
    [setConfig],
  )

  const handleVariablesChange = useCallback(
    (state_variables: typeof config.state_variables) =>
      setConfig((prev) => ({ ...prev, state_variables })),
    [setConfig],
  )

  const handleTransitionsChange = useCallback(
    (transitions: typeof config.transitions) =>
      setConfig((prev) => ({ ...prev, transitions })),
    [setConfig],
  )

  const handleConstraintsChange = useCallback(
    (state_variable_constraints: typeof config.state_variable_constraints) =>
      setConfig((prev) => ({ ...prev, state_variable_constraints })),
    [setConfig],
  )

  const handleEventsChange = useCallback(
    (events: typeof config.events) => setConfig((prev) => ({ ...prev, events })),
    [setConfig],
  )

  const handleActionsChange = useCallback(
    (action_definitions: typeof config.action_definitions) =>
      setConfig((prev) => ({ ...prev, action_definitions })),
    [setConfig],
  )

  const handleGuardsChange = useCallback(
    (guard_definitions: typeof config.guard_definitions) =>
      setConfig((prev) => ({ ...prev, guard_definitions })),
    [setConfig],
  )

  const handleErrorPolicyChange = useCallback(
    (fallback: string, retries: number) =>
      setConfig((prev) => ({
        ...prev,
        error_policy:
          fallback || retries > 0
            ? { default_fallback: fallback || undefined, retry_attempts: retries }
            : undefined,
      })),
    [setConfig],
  )

  return (
    <div className="flex flex-col h-full">
      {/* Tab bar */}
      <div className="flex gap-1 px-4 pt-3 border-b overflow-x-auto shrink-0 bg-background/95">
        {TABS.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`px-3 py-2 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab === 'states' && (
          <StateTable
            states={config.states ?? []}
            allStateNames={stateNames}
            onChange={handleStatesChange}
          />
        )}

        {activeTab === 'variables' && (
          <VariableTable
            variables={config.state_variables ?? []}
            onChange={handleVariablesChange}
          />
        )}

        {activeTab === 'transition_matrix' && (
          <TransitionMatrix
            states={stateNames}
            transitions={config.transitions ?? []}
            onChange={handleTransitionsChange}
          />
        )}

        {activeTab === 'transition_list' && (
          <TransitionList
            transitions={config.transitions ?? []}
            stateNames={stateNames}
            onChange={handleTransitionsChange}
          />
        )}

        {activeTab === 'state_variables' && (
          <StateVariableMatrix
            states={stateNames}
            variables={variableKeys}
            constraints={config.state_variable_constraints ?? {}}
            onChange={handleConstraintsChange}
          />
        )}

        {activeTab === 'events' && (
          <EventTable
            events={
              (config.events ?? []) as {
                name: string
                description?: string
                payload?: Record<string, unknown>
              }[]
            }
            onChange={handleEventsChange}
          />
        )}

        {activeTab === 'actions_guards' && (
          <ActionGuardTable
            actions={config.action_definitions ?? []}
            guards={config.guard_definitions ?? []}
            onActionsChange={handleActionsChange}
            onGuardsChange={handleGuardsChange}
          />
        )}

        {activeTab === 'error_policy' && (
          <ErrorPolicyForm
            defaultFallback={config.error_policy?.default_fallback ?? ''}
            retryAttempts={config.error_policy?.retry_attempts ?? 0}
            stateNames={stateNames}
            onChange={handleErrorPolicyChange}
          />
        )}
      </div>
    </div>
  )
}
