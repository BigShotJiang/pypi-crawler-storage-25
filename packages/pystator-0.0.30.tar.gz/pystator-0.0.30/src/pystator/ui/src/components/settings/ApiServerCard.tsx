'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useApiHealth } from '@/hooks'
import { useAppConfigStore, selectAppName } from '@/stores/app-config'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface ApiServerCardProps {
  url: string
  onUrlChange: (url: string) => void
}

export function ApiServerCard({ url, onUrlChange }: ApiServerCardProps) {
  const appName = useAppConfigStore(selectAppName)
  const { testing, result, test } = useApiHealth()

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Server</CardTitle>
        <CardDescription>
          {`URL of the ${appName} API that this UI will connect to (e.g. http://localhost:8000)`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="api-url">API Server URL</Label>
          <Input
            id="api-url"
            type="text"
            value={url}
            onChange={(e) => onUrlChange(e.target.value)}
            placeholder="http://localhost:8000"
          />
        </div>
        <div className="flex items-center gap-2">
          <Button type="button" variant="outline" onClick={() => test(url)} disabled={testing}>
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test connection'
            )}
          </Button>
          {result && (
            <span className="inline-flex items-center gap-1 text-sm">
              {result.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {result.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
