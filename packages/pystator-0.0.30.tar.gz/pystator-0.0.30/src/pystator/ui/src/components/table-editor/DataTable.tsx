'use client'

import { useState, useCallback, useRef, useEffect, type ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { Trash2, Plus } from 'lucide-react'

// ---------------------------------------------------------------------------
// Column definition
// ---------------------------------------------------------------------------

export type EditorType = 'text' | 'select' | 'number' | 'checkbox' | 'multiselect'

export interface SelectOption {
  value: string
  label: string
}

export interface Column<TRow> {
  key: string
  header: string
  width?: string
  accessor: (row: TRow) => string | number | boolean | undefined
  editor?: EditorType
  editorOptions?: { options?: SelectOption[] }
  onChange: (row: TRow, value: string | number | boolean) => TRow
  required?: boolean
}

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface DataTableProps<TRow> {
  columns: Column<TRow>[]
  rows: TRow[]
  onRowsChange: (rows: TRow[]) => void
  onAddRow?: () => TRow
  rowKey: (row: TRow) => string
  canDeleteRow?: (row: TRow, index: number) => boolean
  emptyMessage?: string
  addLabel?: string
  /** Optional extra actions rendered per-row (before delete) */
  rowActions?: (row: TRow, index: number) => ReactNode
}

// ---------------------------------------------------------------------------
// Inline cell editor
// ---------------------------------------------------------------------------

function CellEditor<TRow>({
  column,
  row,
  onCommit,
  onCancel,
}: {
  column: Column<TRow>
  row: TRow
  onCommit: (updated: TRow) => void
  onCancel: () => void
}) {
  const value = column.accessor(row)
  const inputRef = useRef<HTMLInputElement | HTMLSelectElement>(null)

  const parsedMultiselect = (() => {
    if (column.editor !== 'multiselect') return []
    return String(value ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
  })()
  const [multiselectValue, setMultiselectValue] = useState<string[]>(parsedMultiselect)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const commit = (raw: string | number | boolean) => {
    onCommit(column.onChange(row, raw))
  }

  if (column.editor === 'checkbox') {
    return (
      <input
        ref={inputRef as React.RefObject<HTMLInputElement>}
        type="checkbox"
        checked={!!value}
        onChange={(e) => commit(e.target.checked)}
        onBlur={onCancel}
        className="rounded border-input"
      />
    )
  }

  if (column.editor === 'select') {
    return (
      <select
        ref={inputRef as React.RefObject<HTMLSelectElement>}
        className="w-full h-8 rounded-md border border-input bg-background px-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        defaultValue={String(value ?? '')}
        onChange={(e) => {
          commit(e.target.value)
          onCancel()
        }}
        onBlur={onCancel}
      >
        <option value="">—</option>
        {(column.editorOptions?.options ?? []).map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    )
  }

  if (column.editor === 'multiselect') {
    const options = column.editorOptions?.options ?? []
    return (
      <select
        ref={inputRef as React.RefObject<HTMLSelectElement>}
        multiple
        className="w-full min-h-[80px] rounded-md border border-input bg-background px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        value={multiselectValue}
        onChange={(e) => setMultiselectValue([...e.target.selectedOptions].map((o) => o.value))}
        onBlur={() => {
          commit(multiselectValue.join(', '))
          onCancel()
        }}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    )
  }

  if (column.editor === 'number') {
    return (
      <input
        ref={inputRef as React.RefObject<HTMLInputElement>}
        type="number"
        className="w-full h-8 rounded-md border border-input bg-background px-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        defaultValue={value != null ? String(value) : ''}
        onBlur={(e) => {
          const n = parseFloat(e.target.value)
          if (!isNaN(n)) commit(n)
          onCancel()
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            const n = parseFloat((e.target as HTMLInputElement).value)
            if (!isNaN(n)) commit(n)
            onCancel()
          }
          if (e.key === 'Escape') onCancel()
        }}
      />
    )
  }

  // Default: text
  return (
    <input
      ref={inputRef as React.RefObject<HTMLInputElement>}
      type="text"
      className="w-full h-8 rounded-md border border-input bg-background px-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
      defaultValue={value != null ? String(value) : ''}
      onBlur={(e) => {
        commit(e.target.value)
        onCancel()
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          commit((e.target as HTMLInputElement).value)
          onCancel()
        }
        if (e.key === 'Escape') onCancel()
      }}
    />
  )
}

// ---------------------------------------------------------------------------
// DataTable
// ---------------------------------------------------------------------------

export default function DataTable<TRow>({
  columns,
  rows,
  onRowsChange,
  onAddRow,
  rowKey,
  canDeleteRow,
  emptyMessage = 'No rows.',
  addLabel = 'Add row',
  rowActions,
}: DataTableProps<TRow>) {
  const [editCell, setEditCell] = useState<{ row: number; col: number } | null>(null)

  const updateRow = useCallback(
    (index: number, updated: TRow) => {
      const next = [...rows]
      next[index] = updated
      onRowsChange(next)
    },
    [rows, onRowsChange],
  )

  const deleteRow = useCallback(
    (index: number) => {
      onRowsChange(rows.filter((_, i) => i !== index))
    },
    [rows, onRowsChange],
  )

  const addRow = useCallback(() => {
    if (!onAddRow) return
    onRowsChange([...rows, onAddRow()])
  }, [rows, onRowsChange, onAddRow])

  return (
    <div>
      <div className="overflow-x-auto rounded-lg border">
        <table className="min-w-full divide-y divide-border">
          <thead className="bg-muted/50">
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key}
                  className="px-3 py-2.5 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                  style={col.width ? { width: col.width } : undefined}
                >
                  {col.header}
                </th>
              ))}
              <th className="px-3 py-2.5 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider w-16" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border bg-background">
            {rows.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + 1}
                  className="px-4 py-6 text-center text-sm text-muted-foreground"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              rows.map((row, ri) => (
                <tr key={rowKey(row)} className="hover:bg-muted/30 transition-colors">
                  {columns.map((col, ci) => {
                    const isEditing = editCell?.row === ri && editCell?.col === ci
                    const value = col.accessor(row)
                    return (
                      <td
                        key={col.key}
                        className="px-3 py-2 text-sm text-foreground cursor-pointer"
                        onClick={() => {
                          if (!isEditing) setEditCell({ row: ri, col: ci })
                        }}
                      >
                        {isEditing ? (
                          <CellEditor
                            column={col}
                            row={row}
                            onCommit={(updated) => {
                              updateRow(ri, updated)
                              setEditCell(null)
                            }}
                            onCancel={() => setEditCell(null)}
                          />
                        ) : col.editor === 'checkbox' ? (
                          <input
                            type="checkbox"
                            checked={!!value}
                            readOnly
                            className="rounded border-input pointer-events-none"
                          />
                        ) : (
                          <span className={!value && value !== 0 ? 'text-muted-foreground' : ''}>
                            {value != null && value !== '' ? String(value) : '—'}
                          </span>
                        )}
                      </td>
                    )
                  })}
                  <td className="px-3 py-2 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1">
                      {rowActions?.(row, ri)}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10"
                        disabled={canDeleteRow ? !canDeleteRow(row, ri) : false}
                        onClick={() => deleteRow(ri)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {onAddRow && (
        <div className="mt-2">
          <Button variant="outline" size="sm" onClick={addRow} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" />
            {addLabel}
          </Button>
        </div>
      )}
    </div>
  )
}
