'use client'

import { Button } from '@/components/ui/button'
import type { EntityState } from '@/lib/api'
import { Download, Eye, Trash2, ArrowUpDown, ChevronUp, ChevronDown } from 'lucide-react'

type SortField = 'entity_id' | 'current_state' | 'machine_name' | 'updated_at' | 'created_at'
type SortOrder = 'asc' | 'desc'

interface EntityTableProps {
  entities: EntityState[]
  /** Row click (and View icon if `onViewIconClick` is omitted). */
  onView: (entity: EntityState) => void
  /** View icon only; when set, row click still uses `onView`. */
  onViewIconClick?: (entity: EntityState) => void
  onDelete: (entity: EntityState) => void
  /** When set, shows a download control for the machine FSM config (YAML). */
  onDownloadMachineConfig?: (entity: EntityState) => void
  /** While a row’s config download is in progress. */
  downloadingEntityId?: string | null
  selectedIds?: Set<string>
  onToggleSelect?: (id: string) => void
  onToggleSelectAll?: () => void
  sortBy?: SortField
  sortOrder?: SortOrder
  onSort?: (field: SortField) => void
}

function formatDate(iso: string | null): string {
  if (!iso) return '\u2014'
  try {
    return new Date(iso).toLocaleString()
  } catch {
    return iso
  }
}

function LifecycleMiniPill({ status }: { status: string }) {
  let colorClass = 'bg-muted text-muted-foreground'
  if (status === 'archived') {
    colorClass = 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
  } else if (status === 'deleted') {
    colorClass = 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
  }
  return (
    <span
      className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium ${colorClass}`}
      title={`Lifecycle (admin): ${status}`}
    >
      {status}
    </span>
  )
}

function WorkflowPill({ workflowStatus }: { workflowStatus: string }) {
  const ws = workflowStatus || 'active'
  let colorClass = 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300'
  if (ws === 'complete') {
    colorClass = 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
  } else if (ws === 'failed') {
    colorClass = 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
  }
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${colorClass}`}
      title={`Workflow: ${ws}`}
    >
      {ws}
    </span>
  )
}

function LabelChips({ labels }: { labels: Record<string, string> }) {
  const entries = Object.entries(labels)
  if (entries.length === 0) {
    return <span className="text-muted-foreground">\u2014</span>
  }

  const visible = entries.slice(0, 2)
  const remaining = entries.length - 2

  return (
    <div className="flex flex-wrap items-center gap-1">
      {visible.map(([key, value]) => (
        <span
          key={key}
          className="inline-flex items-center rounded bg-muted px-1.5 py-0 text-[10px] font-mono leading-relaxed"
        >
          {key}={value}
        </span>
      ))}
      {remaining > 0 && (
        <span className="text-[10px] text-muted-foreground">+{remaining} more</span>
      )}
    </div>
  )
}

function SortIcon({ field, sortBy, sortOrder }: { field: SortField; sortBy?: SortField; sortOrder?: SortOrder }) {
  if (sortBy !== field) {
    return <ArrowUpDown className="h-3 w-3 ml-1 opacity-40" />
  }
  return sortOrder === 'asc' ? (
    <ChevronUp className="h-3 w-3 ml-1" />
  ) : (
    <ChevronDown className="h-3 w-3 ml-1" />
  )
}

export default function EntityTable({
  entities,
  onView,
  onViewIconClick,
  onDelete,
  onDownloadMachineConfig,
  downloadingEntityId,
  selectedIds,
  onToggleSelect,
  onToggleSelectAll,
  sortBy,
  sortOrder,
  onSort,
}: EntityTableProps) {
  const viewIconHandler = onViewIconClick ?? onView

  const hasSelection = selectedIds !== undefined && onToggleSelect !== undefined
  const allSelected =
    hasSelection &&
    entities.length > 0 &&
    entities.every((e) => selectedIds!.has(e.entity_id))

  const sortableHeader = (label: string, field: SortField) => {
    if (!onSort) {
      return (
        <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
          {label}
        </th>
      )
    }
    return (
      <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
        <button
          type="button"
          onClick={() => onSort(field)}
          className="inline-flex items-center hover:text-foreground transition-colors"
        >
          {label}
          <SortIcon field={field} sortBy={sortBy} sortOrder={sortOrder} />
        </button>
      </th>
    )
  }

  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="min-w-full divide-y divide-border">
        <thead className="bg-muted/50">
          <tr>
            {hasSelection && (
              <th className="px-3 py-3 w-10">
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={onToggleSelectAll}
                  className="rounded border-input"
                  aria-label="Select all entities"
                />
              </th>
            )}
            {sortableHeader('Entity ID', 'entity_id')}
            {sortableHeader('Machine', 'machine_name')}
            {sortableHeader('Current State', 'current_state')}
            <th
              className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider min-w-[120px]"
              title="FSM workflow outcome (active / complete / failed). Lifecycle shown when archived or deleted."
            >
              Status
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider hidden lg:table-cell">
              Labels
            </th>
            {sortableHeader('Updated', 'updated_at')}
            <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border bg-background">
          {entities.map((ent) => {
            const isSelected = hasSelection && selectedIds!.has(ent.entity_id)

            return (
              <tr
                key={ent.entity_id}
                className={`hover:bg-muted/30 transition-colors cursor-pointer ${isSelected ? 'bg-primary/5' : ''}`}
                onClick={() => onView(ent)}
              >
                {hasSelection && (
                  <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => onToggleSelect!(ent.entity_id)}
                      className="rounded border-input"
                      aria-label={`Select entity ${ent.entity_id}`}
                    />
                  </td>
                )}
                <td className="px-4 py-3 text-sm font-mono text-foreground whitespace-nowrap max-w-[200px] truncate">
                  {ent.entity_id}
                </td>
                <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">
                  {ent.machine_name || '\u2014'}
                </td>
                <td className="px-4 py-3 text-sm whitespace-nowrap">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary">
                    {ent.current_state}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm whitespace-nowrap">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <WorkflowPill workflowStatus={ent.workflow_status ?? 'active'} />
                    {ent.status !== 'active' && <LifecycleMiniPill status={ent.status} />}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm hidden lg:table-cell">
                  <LabelChips labels={ent.labels ?? {}} />
                </td>
                <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">
                  {formatDate(ent.updated_at)}
                </td>
                <td
                  className="px-4 py-3 text-sm text-right whitespace-nowrap"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-end gap-1">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 shrink-0 p-0"
                      onClick={() => viewIconHandler(ent)}
                      aria-label="Open full entity detail"
                      title="Open full detail"
                    >
                      <Eye className="h-3.5 w-3.5" />
                    </Button>
                    {onDownloadMachineConfig && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 shrink-0 p-0"
                        onClick={() => onDownloadMachineConfig(ent)}
                        disabled={downloadingEntityId === ent.entity_id}
                        aria-label="Download machine config"
                        title="Download machine config"
                      >
                        <Download
                          className={`h-3.5 w-3.5 ${downloadingEntityId === ent.entity_id ? 'animate-pulse' : ''}`}
                        />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 shrink-0 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => onDelete(ent)}
                      aria-label="Delete entity"
                      title="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
