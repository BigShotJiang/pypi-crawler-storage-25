'use client'

import type { NodeProps } from '@xyflow/react'
import type { Node } from '@xyflow/react'
import { Handle, Position, NodeResizer, useStore } from '@xyflow/react'
import type { NodeData } from '@/lib/fsmToReactFlow'
import { HIERARCHY_COLORS, CURRENT_STATE_HIGHLIGHT } from '@/lib/diagramColors'
import { useFsmDiagramFocus } from './FsmDiagramFocusContext'

/**
 * Custom node for compound (parent) states so the box has fixed width/height
 * and children don't overlap. Renders a dashed box with the state name at the top.
 * When isCurrentState is true (entity detail view), shows a ring to indicate "you are here".
 */
const DEFAULT_MIN_WIDTH = 380
const DEFAULT_MIN_HEIGHT = 240

export function CompoundStateNode({ data, selected, id }: NodeProps<Node<NodeData>>) {
  const d = data as NodeData
  const label = d.label ?? ''
  const minW = d.compoundWidth ?? DEFAULT_MIN_WIDTH
  const minH = d.compoundHeight ?? DEFAULT_MIN_HEIGHT
  const c = HIERARCHY_COLORS.parent
  const isCurrentState = d.isCurrentState === true
  const contextKeys = (d.contextKeys ?? []) as string[]
  const hasContextKeys = contextKeys.length > 0
  const { focusedEdgeSourceId, focusedEdgeTargetId } = useFsmDiagramFocus()
  const isFocusedSourceNode = focusedEdgeSourceId === id
  const isFocusedTargetNode = focusedEdgeTargetId === id
  const tooltipTitle = hasContextKeys
    ? `State variables: ${contextKeys.join(', ')}`
    : undefined

  const isConnectable = useStore((s) => {
    const node = s.nodeLookup.get(id)
    return node?.internals?.handleBounds != null && s.nodesConnectable
  })

  const handleClass = isConnectable
    ? '!w-3 !h-3 !border-2 cursor-crosshair'
    : '!w-2 !h-2 !border-2'

  return (
    <div
      className="rounded-md flex flex-col w-full h-full min-w-full min-h-full"
      title={tooltipTitle}
      style={{
        background: c.background,
        border: `2px dashed ${c.border}`,
        color: c.text,
        zIndex: 0,
        ...(isCurrentState
          ? {
              boxShadow: CURRENT_STATE_HIGHLIGHT.shadow,
              outline: `${CURRENT_STATE_HIGHLIGHT.ringWidth}px solid ${CURRENT_STATE_HIGHLIGHT.ring}`,
              outlineOffset: 2,
            }
          : isFocusedSourceNode
            ? {
                boxShadow: '0 0 0 2px rgba(59,130,246,0.25)',
                outline: '2px solid rgba(37,99,235,0.9)',
                outlineOffset: 2,
              }
            : isFocusedTargetNode
              ? {
                  boxShadow: '0 0 0 2px rgba(14,165,233,0.18)',
                  outline: '2px solid rgba(14,165,233,0.65)',
                  outlineOffset: 2,
                }
              : {}),
      }}
    >
      <NodeResizer
        minWidth={minW}
        minHeight={minH}
        isVisible={selected}
      />
      <Handle type="target" position={Position.Top} className={handleClass} />
      <div className="px-3 py-2 border-b shrink-0 font-medium text-sm truncate flex items-center justify-center text-center gap-1" style={{ borderColor: 'inherit' }}>
        {label}
        {hasContextKeys && (
          <span
            className="text-[10px] px-1 py-0.5 rounded bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300 shrink-0"
            title={tooltipTitle}
          >
            {contextKeys.length} var{contextKeys.length !== 1 ? 's' : ''}
          </span>
        )}
      </div>
      <div className="flex-1 min-h-0" />
      <Handle type="source" position={Position.Bottom} className={handleClass} />
    </div>
  )
}
