'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Loader2 } from 'lucide-react'

interface DiscoveryObservationCardProps {
  machineName: string
  entityId: string
  observedState: string
  observing: boolean
  onEntityIdChange: (value: string) => void
  onObservedStateChange: (value: string) => void
  onObserve: () => void | Promise<void>
  /** Paste many rows: `entity_id,state` per line or JSON `{"entity_id":"…","state":"…"}` per line. */
  onBulkRecord?: (text: string) => void | Promise<void>
}

export function DiscoveryObservationCard({
  machineName,
  entityId,
  observedState,
  observing,
  onEntityIdChange,
  onObservedStateChange,
  onObserve,
  onBulkRecord,
}: DiscoveryObservationCardProps) {
  const nameOk = machineName.trim().length > 0
  const [bulkText, setBulkText] = useState('')

  return (
    <Card>
      <CardHeader className="space-y-0 px-4 py-2">
        <CardTitle className="text-sm font-medium leading-none">Observations</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 px-4 pb-4 pt-0">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:gap-2">
          <div className="min-w-0 flex-1 space-y-1">
            <Label htmlFor="dm-entity" className="text-xs text-muted-foreground">
              Entity ID
            </Label>
            <Input
              id="dm-entity"
              value={entityId}
              onChange={(e) => onEntityIdChange(e.target.value)}
              placeholder="entity-123"
              className="h-9"
            />
          </div>
          <div className="min-w-0 flex-1 space-y-1">
            <Label htmlFor="dm-state" className="text-xs text-muted-foreground">
              Observed state
            </Label>
            <Input
              id="dm-state"
              value={observedState}
              onChange={(e) => onObservedStateChange(e.target.value)}
              placeholder="pending"
              className="h-9"
            />
          </div>
          <Button
            type="button"
            variant="secondary"
            className="h-9 shrink-0"
            aria-label="Record observation"
            onClick={() => void onObserve()}
            disabled={!nameOk || observing}
          >
            {observing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Record
          </Button>
        </div>

        {onBulkRecord ? (
          <details className="rounded-md border border-border/60 bg-muted/20">
            <summary className="cursor-pointer select-none px-3 py-2 text-sm font-medium">
              Bulk import
            </summary>
            <div className="space-y-2 border-t border-border/60 px-3 py-3">
              <p className="text-xs text-muted-foreground">
                One row per line: <code className="text-[11px]">entity_id,state</code> or JSON{' '}
                <code className="text-[11px]">{`{"entity_id":"a","state":"b"}`}</code>. Lines starting with{' '}
                <code className="text-[11px]">#</code> are ignored.
              </p>
              <textarea
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                disabled={!nameOk || observing}
                placeholder={'demo-1,pending\ndemo-2,ready'}
                className="flex min-h-[88px] w-full rounded-md border border-input bg-background px-3 py-2 text-xs font-mono"
              />
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={!nameOk || observing || !bulkText.trim()}
                onClick={() => void onBulkRecord(bulkText)}
              >
                {observing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Record batch
              </Button>
            </div>
          </details>
        ) : null}
      </CardContent>
    </Card>
  )
}
