'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Loader2, RefreshCw } from 'lucide-react'

interface DiscoveryMachineSelectorCardProps {
  machineName: string
  recentMachineNames: string[]
  loadingList: boolean
  building: boolean
  onMachineNameChange: (value: string) => void
  onSelectRecent: (value: string) => void
  onClearError: () => void
  onLoadCandidates: () => void
  onCreateDraftMachine?: () => void
  /** Omit to hide the build button (workspace-first flow uses the candidates panel). */
  onBuildCandidate?: () => void
}

export function DiscoveryMachineSelectorCard({
  machineName,
  recentMachineNames,
  loadingList,
  building,
  onMachineNameChange,
  onSelectRecent,
  onClearError,
  onLoadCandidates,
  onCreateDraftMachine,
  onBuildCandidate,
}: DiscoveryMachineSelectorCardProps) {
  const nameOk = machineName.trim().length > 0

  return (
    <Card>
      <CardHeader>
        <CardTitle>Machine name</CardTitle>
        <CardDescription>
          Use the same logical name you use for observations and candidate builds (e.g.{' '}
          <code className="text-xs">order_flow</code>).
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="dm-machine">Machine name</Label>
          <Input
            id="dm-machine"
            value={machineName}
            onChange={(e) => {
              onMachineNameChange(e.target.value)
              onClearError()
            }}
            placeholder="order_flow"
          />
        </div>

        {recentMachineNames.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Recent machines</p>
            <div className="flex flex-wrap gap-2">
              {recentMachineNames.map((name) => (
                <Button
                  key={name}
                  type="button"
                  variant={name === machineName.trim() ? 'default' : 'outline'}
                  size="sm"
                  className="h-7 text-xs"
                  onClick={() => onSelectRecent(name)}
                >
                  {name}
                </Button>
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {onCreateDraftMachine ? (
            <Button type="button" variant="outline" onClick={onCreateDraftMachine}>
              New draft
            </Button>
          ) : null}
          <Button
            type="button"
            variant="outline"
            onClick={onLoadCandidates}
            disabled={!nameOk || loadingList}
          >
            {loadingList ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="mr-2 h-4 w-4" />
            )}
            Load candidates
          </Button>
          {onBuildCandidate ? (
            <Button type="button" onClick={onBuildCandidate} disabled={!nameOk || building}>
              {building ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Build candidate
            </Button>
          ) : null}
        </div>
      </CardContent>
    </Card>
  )
}
