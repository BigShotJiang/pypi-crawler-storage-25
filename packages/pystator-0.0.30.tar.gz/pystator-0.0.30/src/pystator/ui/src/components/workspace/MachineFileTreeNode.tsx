'use client'

import { useCallback } from 'react'
import { ChevronRight, ChevronDown, Folder, FolderOpen, GitBranch } from 'lucide-react'
import type { MachineBrowseTreeNode } from '@/lib/types/machine-browse'
import { useMachineBrowseStore } from '@/stores/machine-browse'

export interface MachineFileTreeNodeProps {
  node: MachineBrowseTreeNode
  depth: number
  selectedMachineName: string | null
  onMachineNameSelect: (name: string) => void
}

/**
 * Renders a folder or machine item in the browse tree. Supports expand/collapse,
 * inline rename, and right-click context menu. Mirrors pycharter FileTreeNode.
 */
export function MachineFileTreeNode({
  node,
  depth,
  selectedMachineName,
  onMachineNameSelect,
}: MachineFileTreeNodeProps) {
  const expandedIds = useMachineBrowseStore((s) => s.expandedIds)
  const toggleExpand = useMachineBrowseStore((s) => s.toggleExpand)

  const isFolder = node.kind === 'folder'
  const isExpanded = expandedIds.has(node.id)
  const machineName = node.item_label ?? node.name
  const isSelected = !isFolder && selectedMachineName === machineName

  const handleClick = useCallback(() => {
    if (isFolder) {
      toggleExpand(node.id)
    } else {
      onMachineNameSelect(machineName)
    }
  }, [isFolder, node.id, machineName, toggleExpand, onMachineNameSelect])

  const chevron = isFolder ? (
    isExpanded ? (
      <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
    ) : (
      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
    )
  ) : (
    <span className="w-3.5 shrink-0" />
  )

  const icon = isFolder ? (
    isExpanded ? (
      <FolderOpen className="h-3.5 w-3.5 shrink-0 text-amber-500" />
    ) : (
      <Folder className="h-3.5 w-3.5 shrink-0 text-amber-500" />
    )
  ) : (
    <GitBranch className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
  )

  return (
    <div>
      <button
        type="button"
        onClick={handleClick}
        className={`flex w-full items-center gap-1.5 rounded-md px-1.5 py-1 text-left text-xs transition-colors hover:bg-muted ${
          isSelected ? 'bg-primary/10 text-primary' : 'text-foreground'
        }`}
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
      >
        {chevron}
        {icon}
        <span className="truncate">{node.name}</span>
      </button>

      {isFolder && isExpanded &&
        node.children?.map((child) => (
          <MachineFileTreeNode
            key={child.id}
            node={child}
            depth={depth + 1}
            selectedMachineName={selectedMachineName}
            onMachineNameSelect={onMachineNameSelect}
          />
        ))}
    </div>
  )
}
