'use client'

import { useMemo, useEffect, useCallback, type CSSProperties } from 'react'
import {
  ReactFlow,
  Controls,
  Background,
  BackgroundVariant,
  ReactFlowProvider,
  useNodesState,
  useEdgesState,
  useReactFlow,
  getConnectedEdges,
  type Connection,
  type Node,
  type Edge,
} from '@xyflow/react'
import '@xyflow/react/dist/base.css'
import '@xyflow/react/dist/style.css'
import { fsmConfigToReactFlow, type FsmFlowOptions, type NodeData, type EdgeLabelData } from '@/lib/fsmToReactFlow'
import type { FSMConfig } from '@/lib/types/fsm'
import { CompoundStateNode } from './CompoundStateNode'
import { FsmDiagramFocusProvider, useFsmDiagramFocus } from './FsmDiagramFocusContext'
import { EdgeWithLabel } from './EdgeWithLabel'
import { StateNode } from './StateNode'
import { getPaletteDragPayload, type PaletteDragPayload } from '@/components/workspace/paletteDnd'
import { useToastStore } from '@/stores/toast'

const edgeTypes = { smoothstep: EdgeWithLabel }
const nodeTypes = { state: StateNode, compound: CompoundStateNode }

/**
 * Merge layout nodes with current node positions so that:
 * - Data and style (e.g. highlight) come from the latest layout.
 * - Positions are preserved from current nodes when present (user may have dragged).
 * This prevents the diagram from jumping back to default layout after processing an event.
 */
function mergeNodesWithCurrentPositions(
  layoutNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes'],
  currentNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes']
): ReturnType<typeof fsmConfigToReactFlow>['nodes'] {
  const currentById = new Map(currentNodes.map((n) => [n.id, n]))
  return layoutNodes.map((layoutNode) => {
    const current = currentById.get(layoutNode.id)
    if (current?.position) {
      return { ...layoutNode, position: current.position }
    }
    return layoutNode
  })
}

export interface FsmFlowDiagramProps {
  config: FSMConfig
  /** Minimum height of the diagram container */
  minHeight?: number | string
  /** Show guards on edge labels (default true) */
  showGuards?: boolean
  /** Show actions on edge labels (default false) */
  showActions?: boolean
  /** Show hierarchy indicators (parent/child, parallel regions) (default true) */
  showHierarchy?: boolean
  /** Highlight this transition (e.g. last transition) */
  highlightTransition?: { source: string; target: string; trigger: string } | null
  /** Highlight this state as current (entity instance "you are here") */
  highlightState?: string | null
  /** Optional class name for the wrapper */
  className?: string
  /** Enable editing mode: double-click, drag-to-connect, delete */
  editable?: boolean
  /** Called when user double-clicks canvas (for adding a state). Receives flow position {x, y}. */
  onPaneDoubleClick?: (position: { x: number; y: number }) => void
  /** Called when user double-clicks a state node. Receives the original state name. */
  onNodeDoubleClick?: (stateName: string) => void
  /** Called when user double-clicks a transition edge. Receives the transition index in config. */
  onEdgeDoubleClick?: (transitionIndex: number) => void
  /** Called when user drags a connection between two nodes. Receives source and target state names. */
  onConnect?: (sourceName: string, destName: string) => void
  /** Called when user presses Delete on selected state nodes. Receives array of state names. */
  onNodesDelete?: (stateNames: string[]) => void
  /** Called when user presses Delete on selected edges. Receives array of transition indices. */
  onEdgesDelete?: (transitionIndices: number[]) => void
  /** Drop from Components palette onto the canvas (same semantics as clicking a palette row). */
  onPaletteDrop?: (
    payload: PaletteDragPayload,
    flowPosition: { x: number; y: number } | null
  ) => void
  /** Optional workspace annotations (state-anchored). */
  annotations?: {
    enabled: boolean
    statesWithNotes: Set<string>
    openStateName?: string
    getBody: (stateName: string) => string
    saving: boolean
    deleting: boolean
    machineName: string
    machineVersion: string
    onOpen: (stateName: string) => void
    onClose: () => void
    onSave: (stateName: string, body: string) => void
    onDelete: (stateName: string) => void
  }
  /** Optional ops badges (counts/age/errors) for state nodes. */
  opsMetrics?: {
    enabled: boolean
    /** Keyed by state name. */
    metricsByState: Record<
      string,
      {
        entity_count: number
        age_p95_seconds: number | null
        failed_transition_count: number
        age_buckets?: { le_5m: number; le_30m: number; gt_30m: number }
        top_error?: { error_type: string | null; error_message: string | null; count: number } | null
      }
    >
  }
  /** Optional transition notes (trigger/source/dest-anchored). */
  transitionNotes?: {
    enabled: boolean
    openKey?: string
    getBody: (transitionKey: string) => string
    saving: boolean
    deleting: boolean
    machineName: string
    machineVersion: string
    onOpen: (transitionKey: string) => void
    onClose: () => void
    onSave: (transitionKey: string, body: string) => void
    onDelete: (transitionKey: string) => void
    keysWithNotes: Set<string>
  }
}

export type { PaletteDragPayload }

type FsmFlowDiagramInnerProps = FsmFlowDiagramProps & {
  initialNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes']
  initialEdges: ReturnType<typeof fsmConfigToReactFlow>['edges']
}

function FsmFlowDiagramInner({
  initialNodes,
  initialEdges,
  config,
  minHeight = 480,
  showGuards = true,
  showActions = false,
  showHierarchy = true,
  highlightTransition = null,
  highlightState = null,
  className = '',
  editable = false,
  onPaneDoubleClick,
  onNodeDoubleClick,
  onEdgeDoubleClick,
  onConnect,
  onNodesDelete,
  onEdgesDelete,
  onPaletteDrop,
  annotations,
}: FsmFlowDiagramInnerProps) {
  const { clearFocus, requestFocusNode, requestFocusEdgeLabel } = useFsmDiagramFocus()
  const reactFlow = useReactFlow<Node<NodeData>, Edge<EdgeLabelData>>()
  const toastError = useToastStore((s) => s.error)

  const initialStateNames = useMemo(
    () => new Set((config.states ?? []).filter((s) => s.type === 'initial').map((s) => s.name)),
    [config.states]
  )

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)

  useEffect(() => {
    setNodes((current) => mergeNodesWithCurrentPositions(initialNodes, current))
    setEdges(initialEdges)
  }, [initialNodes, initialEdges, setNodes, setEdges])

  const handlePaneDoubleClick = useCallback(
    (event: React.MouseEvent) => {
      if (!editable || !onPaneDoubleClick) return
      // Ignore double-clicks that originated on a node or edge (they have their own handlers)
      const target = event.target as HTMLElement
      if (
        target.closest('.react-flow__node') ||
        target.closest('.react-flow__edge') ||
        target.closest('.react-flow__edgelabel-renderer')
      ) return
      const position = reactFlow.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })
      onPaneDoubleClick(position)
    },
    [editable, onPaneDoubleClick, reactFlow]
  )

  const handleNodeDoubleClick = useCallback(
    (_event: React.MouseEvent, node: Node<NodeData>) => {
      if (!editable || !onNodeDoubleClick) return
      const data = node.data as NodeData
      const stateName = data.stateName ?? node.id
      onNodeDoubleClick(stateName)
    },
    [editable, onNodeDoubleClick]
  )

  const handleNodeClick = useCallback(
    (_event: React.MouseEvent, node: Node<NodeData>) => {
      requestFocusNode(node.id)
    },
    [requestFocusNode]
  )

  const handleEdgeDoubleClick = useCallback(
    (_event: React.MouseEvent, edge: Edge<EdgeLabelData>) => {
      if (!editable || !onEdgeDoubleClick) return
      const data = (edge.data ?? {}) as EdgeLabelData
      if (data.isSynthetic) return
      if (data.transitionIndex != null) {
        onEdgeDoubleClick(data.transitionIndex)
      }
    },
    [editable, onEdgeDoubleClick]
  )

  const handleEdgeClick = useCallback(
    (_event: React.MouseEvent, edge: Edge<EdgeLabelData>) => {
      requestFocusEdgeLabel(edge.id, { sourceId: edge.source, targetId: edge.target })
    },
    [requestFocusEdgeLabel]
  )

  const handleConnect = useCallback(
    (connection: Connection) => {
      if (!editable || !onConnect) return
      if (!connection.source || !connection.target) return
      // Resolve source/target to state names from node data
      const sourceNode = nodes.find((n) => n.id === connection.source)
      const targetNode = nodes.find((n) => n.id === connection.target)
      if (!sourceNode || !targetNode) return
      const sourceData = sourceNode.data as NodeData
      const targetData = targetNode.data as NodeData
      const sourceName = sourceData.stateName ?? sourceNode.id
      const destName = targetData.stateName ?? targetNode.id
      onConnect(sourceName, destName)
    },
    [editable, onConnect, nodes]
  )

  const handleBeforeDelete = useCallback(
    async ({
      nodes: toDelete,
      edges: edgesToDelete,
    }: {
      nodes: Node<NodeData>[]
      edges: Edge<EdgeLabelData>[]
    }) => {
      if (toDelete.length === 0) {
        return true
      }

      const blocked = toDelete.filter((n) => {
        const name = (n.data as NodeData).stateName ?? n.id
        return initialStateNames.has(name)
      })
      const allowedNodes = toDelete.filter((n) => {
        const name = (n.data as NodeData).stateName ?? n.id
        return !initialStateNames.has(name)
      })

      if (blocked.length > 0) {
        const names = blocked.map((n) => (n.data as NodeData).stateName ?? n.id)
        if (allowedNodes.length === 0) {
          toastError(`Cannot delete initial state: ${names.join(', ')}`)
          return false
        }
        toastError(
          `Initial state(s) cannot be deleted (${names.join(', ')}). Other selected states will be removed.`
        )
      }

      if (blocked.length > 0) {
        const allowedEdges = getConnectedEdges(allowedNodes, edgesToDelete)
        return { nodes: allowedNodes, edges: allowedEdges }
      }

      return true
    },
    [initialStateNames, toastError]
  )

  // Note: we intentionally do not set `deletable: false` on initial-state nodes. Doing so would
  // remove them from the delete candidate set before `onBeforeDelete` runs, so Delete on an
  // initial-only selection would fail silently with no toast.

  const handleNodesDeleteCb = useCallback(
    (deletedNodes: Node<NodeData>[]) => {
      if (!editable || !onNodesDelete) return
      const stateNames = deletedNodes
        .map((n) => (n.data as NodeData).stateName ?? n.id)
      if (stateNames.length > 0) {
        onNodesDelete(stateNames)
      }
    },
    [editable, onNodesDelete]
  )

  const handleEdgesDeleteCb = useCallback(
    (deletedEdges: Edge<EdgeLabelData>[]) => {
      if (!editable || !onEdgesDelete) return
      const indices = deletedEdges
        .map((e) => ((e.data ?? {}) as EdgeLabelData).transitionIndex)
        .filter((idx): idx is number => idx != null)
      if (indices.length > 0) {
        onEdgesDelete(indices)
      }
    },
    [editable, onEdgesDelete]
  )

  const handlePaletteDragOver = useCallback(
    (event: React.DragEvent) => {
      if (!editable || !onPaletteDrop) return
      event.preventDefault()
      event.dataTransfer.dropEffect = 'move'
    },
    [editable, onPaletteDrop]
  )

  const handlePaletteDrop = useCallback(
    (event: React.DragEvent) => {
      if (!editable || !onPaletteDrop) return
      event.preventDefault()
      const payload = getPaletteDragPayload(event)
      if (!payload) return
      const flowPosition = reactFlow.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })
      onPaletteDrop(payload, flowPosition)
    },
    [editable, onPaletteDrop, reactFlow]
  )

  const isPercent = typeof minHeight === 'string' && minHeight.endsWith('%')
  const heightValue: number | string =
    typeof minHeight === 'number'
      ? minHeight
      : typeof minHeight === 'string' && minHeight.endsWith('px')
        ? parseInt(minHeight, 10) || 480
        : isPercent
          ? minHeight
          : 480
  const containerStyle: CSSProperties = {
    width: '100%',
    height: heightValue,
    minHeight: heightValue,
    position: 'relative',
  }

  const emptyDiagram = !config.states?.length
  const showEmptyFlow =
    emptyDiagram && editable && onPaletteDrop
  const heightPx =
    typeof heightValue === 'number' ? heightValue : parseInt(String(heightValue), 10) || 480

  if (emptyDiagram && !showEmptyFlow) {
    return (
      <div
        className={`flex items-center justify-center rounded border bg-muted/30 ${className}`}
        style={containerStyle}
      >
        <p className="text-muted-foreground text-sm">
          Add at least one state to see the diagram.
        </p>
      </div>
    )
  }

  return (
    <div className={`relative rounded border bg-muted/30 ${className}`} style={containerStyle}>
      {showEmptyFlow && (
        <p className="pointer-events-none absolute left-1/2 top-1/2 z-[1] max-w-[min(100%,20rem)] -translate-x-1/2 -translate-y-1/2 text-center text-muted-foreground text-sm">
          Double-click to add a state, drag components from the sidebar, or use the Components tab.
        </p>
      )}
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        defaultEdgeOptions={{ type: 'smoothstep' }}
        height={heightPx}
        fitView={!emptyDiagram}
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.2}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
        nodesDraggable
        nodesConnectable={editable}
        elementsSelectable
        panOnDrag
        zoomOnScroll
        zoomOnPinch
        onPaneClick={clearFocus}
        onNodeClick={handleNodeClick}
        onEdgeClick={handleEdgeClick}
        onDoubleClick={editable ? handlePaneDoubleClick : undefined}
        onNodeDoubleClick={editable ? handleNodeDoubleClick : undefined}
        onEdgeDoubleClick={editable ? handleEdgeDoubleClick : undefined}
        onConnect={editable ? handleConnect : undefined}
        onNodesDelete={editable ? handleNodesDeleteCb : undefined}
        onEdgesDelete={editable ? handleEdgesDeleteCb : undefined}
        onBeforeDelete={editable ? handleBeforeDelete : undefined}
        deleteKeyCode={editable ? ['Backspace', 'Delete'] : []}
        onDragOver={editable && onPaletteDrop ? handlePaletteDragOver : undefined}
        onDrop={editable && onPaletteDrop ? handlePaletteDrop : undefined}
      >
        <Controls showInteractive={false} />
        <Background variant={BackgroundVariant.Dots} gap={12} size={1} />
      </ReactFlow>
    </div>
  )
}

export default function FsmFlowDiagram(props: FsmFlowDiagramProps) {
  const {
    config,
    showGuards = true,
    showActions = false,
    showHierarchy = true,
    highlightTransition = null,
    highlightState = null,
    annotations,
    opsMetrics,
    transitionNotes,
  } = props

  const options: FsmFlowOptions = {
    showGuards,
    showActions,
    showHierarchy,
    highlightTransition,
    highlightState,
  }

  const { nodes: initialNodes, edges: initialEdges } = useMemo(
    () => {
      const base = fsmConfigToReactFlow(config, options)
      const buildTransitionKey = (idx: number): string | null => {
        const t = (config.transitions ?? [])[idx]
        if (!t) return null
        const src = Array.isArray(t.source) ? t.source : [t.source]
        const srcKey = src.map((s) => String(s)).sort().join('|')
        const trigger = String(t.trigger ?? '')
        const dest = String(t.dest ?? '')
        return `${srcKey}::${trigger}::${dest}`
      }

      const edges = base.edges.map((e) => {
        const data = (e.data ?? {}) as EdgeLabelData
        const idx = data.transitionIndex
        const key = idx != null ? buildTransitionKey(idx) : null
        const nextData: EdgeLabelData = {
          ...data,
          onOpenTransition: props.onEdgeDoubleClick,
        }
        if (transitionNotes?.enabled && key) {
          const body = transitionNotes.getBody(key)
          nextData.transitionNoteEnabled = true
          nextData.transitionNoteKey = key
          nextData.hasTransitionNote = transitionNotes.keysWithNotes.has(key)
          nextData.transitionNoteOpen = transitionNotes.openKey === key
          nextData.transitionNoteBody = body
          nextData.transitionNoteInitialBody = body
          nextData.transitionNoteSaving = transitionNotes.saving
          nextData.transitionNoteDeleting = transitionNotes.deleting
          nextData.transitionNoteMachineName = transitionNotes.machineName
          nextData.transitionNoteMachineVersion = transitionNotes.machineVersion
          nextData.onOpenTransitionNote = transitionNotes.onOpen
          nextData.onCloseTransitionNote = transitionNotes.onClose
          nextData.onSaveTransitionNote = (b: string) => transitionNotes.onSave(key, b)
          nextData.onDeleteTransitionNote = () => transitionNotes.onDelete(key)
        }
        return { ...e, data: nextData }
      })
      const nodes = base.nodes.map((n) => {
        const baseData = (n.data ?? {}) as NodeData
        const stateName = baseData.stateName
        const nextData: NodeData = { ...baseData }

        if (annotations?.enabled) {
          const set = annotations.statesWithNotes
          const has = !!(stateName && set.has(stateName))
          const isOpen = !!(stateName && annotations.openStateName && stateName === annotations.openStateName)
          const body = stateName ? annotations.getBody(stateName) : ''
          nextData.annotationEnabled = true
          nextData.hasAnnotation = has
          nextData.annotationOpen = isOpen
          nextData.annotationBody = body
          nextData.annotationInitialBody = body
          nextData.annotationSaving = annotations.saving
          nextData.annotationDeleting = annotations.deleting
          nextData.annotationMachineName = annotations.machineName
          nextData.annotationMachineVersion = annotations.machineVersion
          nextData.onOpenAnnotation = annotations.onOpen
          nextData.onCloseAnnotation = annotations.onClose
          nextData.onSaveAnnotation = (b: string) => {
            if (!stateName) return
            annotations.onSave(stateName, b)
          }
          nextData.onDeleteAnnotation = () => {
            if (!stateName) return
            annotations.onDelete(stateName)
          }
        }

        if (opsMetrics?.enabled && stateName) {
          const m = opsMetrics.metricsByState[stateName]
          if (m) {
            nextData.opsBadges = {
              entityCount: m.entity_count,
              ageP95Seconds: m.age_p95_seconds,
              failedTransitionCount: m.failed_transition_count,
              ageBuckets: m.age_buckets,
              topError: m.top_error,
            }
          }
        }

        if (n.type === 'state' && props.editable && props.onNodeDoubleClick && stateName) {
          nextData.onOpenStateSettings = props.onNodeDoubleClick
        }

        return { ...n, data: nextData }
      })
      return { ...base, nodes, edges }
    },
    [
      config,
      showGuards,
      showActions,
      showHierarchy,
      highlightTransition,
      highlightState,
      props.onEdgeDoubleClick,
      annotations?.enabled,
      annotations?.onOpen,
      annotations?.onClose,
      annotations?.onSave,
      annotations?.onDelete,
      annotations?.openStateName,
      annotations?.getBody,
      annotations?.saving,
      annotations?.deleting,
      annotations?.machineName,
      annotations?.machineVersion,
      annotations?.statesWithNotes,
      opsMetrics?.enabled,
      opsMetrics?.metricsByState,
      transitionNotes?.enabled,
      transitionNotes?.openKey,
      transitionNotes?.getBody,
      transitionNotes?.saving,
      transitionNotes?.deleting,
      transitionNotes?.machineName,
      transitionNotes?.machineVersion,
      transitionNotes?.onOpen,
      transitionNotes?.onClose,
      transitionNotes?.onSave,
      transitionNotes?.onDelete,
      transitionNotes?.keysWithNotes,
      props.editable,
      props.onNodeDoubleClick,
    ]
  )

  return (
    <ReactFlowProvider>
      <FsmDiagramFocusProvider resetSignal={initialEdges}>
        <FsmFlowDiagramInner {...props} initialNodes={initialNodes} initialEdges={initialEdges} />
      </FsmDiagramFocusProvider>
    </ReactFlowProvider>
  )
}
