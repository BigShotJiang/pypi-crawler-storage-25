'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import type { DiscoveryBuiltCandidateSummaryItem, DiscoveryDraftResponse } from '@/lib/api'
import { cn } from '@/lib/utils'
import { Trash2 } from 'lucide-react'

type CandidateSortKey = 'created_desc' | 'created_asc' | 'status' | 'sequence'
const DEFAULT_DRIFT_ALERT_THRESHOLD = 0.15
const DEFAULT_DRIFT_SEVERE_THRESHOLD = 0.4
const DEFAULT_DRIFT_MIN_SAMPLE = 3
const DEFAULT_LOW_SAMPLE_THRESHOLD = 10

interface DiscoveryCandidatesTableProps {
  drafts?: DiscoveryDraftResponse[]
  activeDraftId?: string | null
  onSelectDraft?: (id: string) => void
  onDeleteDraft?: (id: string) => void
  builtCandidates: DiscoveryBuiltCandidateSummaryItem[]
  selectedVersion: string | null
  loadingList: boolean
  promoting: boolean
  onSelectVersion: (version: string) => void
  onPromoteRequest: (version: string) => void
  /** Rail layout: no Card, fills height with internal scroll. */
  embedded?: boolean
  /** Embedded only: omit title/description; sort + table directly under parent header. */
  compactEmbedded?: boolean
  driftAlertThreshold?: number
  driftSevereThreshold?: number
  driftMinSample?: number
  lowSampleThreshold?: number
}

function shortVersionOrId(value: string | null | undefined): string {
  const t = (value ?? '').trim()
  if (!t) return '—'
  if (
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(t)
  ) {
    return `${t.slice(0, 8)}…`
  }
  return t
}

function candidateAttentionPills(
  c: DiscoveryBuiltCandidateSummaryItem,
  thresholds: {
    driftAlertThreshold: number
    driftSevereThreshold: number
    driftMinSample: number
    lowSampleThreshold: number
  }
): Array<{
  key: string
  label: string
  className: string
  title: string
}> {
  const pills: Array<{ key: string; label: string; className: string; title: string }> = []
  const shadowN = c.shadow_diff_count_recent ?? 0
  const drift = c.drift_rate_recent ?? 0
  if (shadowN === 0) {
    pills.push({
      key: 'noshadow',
      label: 'No shadow',
      className: 'bg-slate-500/15 text-slate-700 dark:text-slate-300 border border-slate-500/30',
      title: 'No shadow diffs recorded for this candidate version yet.',
    })
  } else if (shadowN < thresholds.lowSampleThreshold) {
    pills.push({
      key: 'lowsample',
      label: 'Low sample',
      className: 'bg-slate-500/15 text-slate-700 dark:text-slate-300 border border-slate-500/30',
      title: `Only ${shadowN} shadow sample(s) for this version (recommended: >=${thresholds.lowSampleThreshold}).`,
    })
  }
  if (drift >= thresholds.driftSevereThreshold && shadowN >= thresholds.driftMinSample) {
    pills.push({
      key: 'drift-severe',
      label: 'High drift',
      className: 'bg-red-500/15 text-red-800 dark:text-red-200 border border-red-500/40',
      title: `${(drift * 100).toFixed(0)}% differs over latest ${shadowN} shadow rows for this version (high drift).`,
    })
  } else if (drift >= thresholds.driftAlertThreshold && shadowN >= thresholds.driftMinSample) {
    pills.push({
      key: 'drift',
      label: 'Drift',
      className: 'bg-amber-500/15 text-amber-800 dark:text-amber-200 border border-amber-500/40',
      title: `${(drift * 100).toFixed(0)}% differs over latest ${shadowN} shadow rows for this version (alert threshold: ${(thresholds.driftAlertThreshold * 100).toFixed(0)}%).`,
    })
  }
  const mode = (c.build_mode ?? '').trim().toLowerCase()
  if (mode === 'manual' || mode === 'inference') {
    pills.push({
      key: 'mode',
      label: mode === 'manual' ? 'Manual' : 'Inference',
      className: 'bg-sky-500/15 text-sky-900 dark:text-sky-100 border border-sky-500/40',
      title: `Build mode: ${mode}.`,
    })
  }
  return pills
}

export function DiscoveryCandidatesTable({
  drafts = [],
  activeDraftId = null,
  onSelectDraft,
  onDeleteDraft,
  builtCandidates,
  selectedVersion,
  loadingList,
  promoting,
  onSelectVersion,
  onPromoteRequest,
  embedded = false,
  compactEmbedded = false,
  driftAlertThreshold = DEFAULT_DRIFT_ALERT_THRESHOLD,
  driftSevereThreshold = DEFAULT_DRIFT_SEVERE_THRESHOLD,
  driftMinSample = DEFAULT_DRIFT_MIN_SAMPLE,
  lowSampleThreshold = DEFAULT_LOW_SAMPLE_THRESHOLD,
}: DiscoveryCandidatesTableProps) {
  const thresholds = {
    driftAlertThreshold,
    driftSevereThreshold,
    driftMinSample,
    lowSampleThreshold,
  }

  const [sortBy, setSortBy] = useState<CandidateSortKey>('created_desc')

  const sortedWorkspaces = useMemo(() => {
    const next = [...drafts]
    next.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    return next
  }, [drafts])

  const sortedCandidates = useMemo(() => {
    const next = [...builtCandidates]
    next.sort((a, b) => {
      if (sortBy === 'status') return a.status.localeCompare(b.status)
      if (sortBy === 'sequence')
        return (b.candidate_sequence ?? 0) - (a.candidate_sequence ?? 0)
      const at = new Date(a.created_at).getTime()
      const bt = new Date(b.created_at).getTime()
      return sortBy === 'created_asc' ? at - bt : bt - at
    })
    return next
  }, [builtCandidates, sortBy])

  const hasWorkspacesUi = Boolean(onSelectDraft)

  const sortControl = (
    <div className="flex items-center gap-2">
      <label htmlFor="discovery-candidate-sort" className="text-xs text-muted-foreground">
        Sort
      </label>
      <select
        id="discovery-candidate-sort"
        value={sortBy}
        onChange={(e) => setSortBy(e.target.value as CandidateSortKey)}
        className="rounded-md border border-input bg-background px-2 py-1 text-xs"
      >
        <option value="created_desc">Newest first</option>
        <option value="created_asc">Oldest first</option>
        <option value="status">Status</option>
        <option value="sequence">No.</option>
      </select>
    </div>
  )

  const emptyCombined =
    !loadingList && drafts.length === 0 && builtCandidates.length === 0

  const tableSection =
    loadingList && drafts.length === 0 && builtCandidates.length === 0 ? (
      <p className="text-sm text-muted-foreground">Loading…</p>
    ) : emptyCombined ? (
      <div className="rounded-md border border-dashed p-4 text-sm text-muted-foreground">
        {hasWorkspacesUi
          ? 'Create a candidate workspace, pick entity IDs, then Preview or Build.'
          : 'No built candidates yet. Record observations, then build a candidate to review and promote.'}
      </div>
    ) : (
      <div
        className={cn(
          'overflow-auto rounded-md border',
          embedded ? 'min-h-0 flex-1' : 'max-h-80'
        )}
      >
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10 bg-muted/80 backdrop-blur">
            <tr className="border-b text-left">
              <th className="p-2 align-middle font-medium">No.</th>
              <th className="p-2 align-middle font-medium">Status</th>
              <th className="p-2 align-middle font-medium">Updated / created</th>
              <th className="p-2 align-middle font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {hasWorkspacesUi
              ? sortedWorkspaces.map((ws, draftIdx) => {
                  const active = !selectedVersion && activeDraftId === ws.id
                  const draftNum = draftIdx + 1
                  return (
                    <tr
                      key={ws.id}
                      className={`cursor-pointer border-b transition-colors ${active ? 'bg-primary/10' : 'hover:bg-muted/50'}`}
                      onClick={() => onSelectDraft?.(ws.id)}
                    >
                      <td className="p-2 align-middle">
                        <div className="flex flex-wrap items-center gap-2">
                          <span title={`Draft workspace id: ${ws.id}`}>{draftNum}</span>
                        </div>
                        {ws.title?.trim() ? (
                          <div className="mt-0.5 text-[11px] text-muted-foreground" title="Workspace title">
                            {ws.title.trim()}
                          </div>
                        ) : null}
                        {ws.last_built_version ? (
                          <div
                            className="mt-1 text-[11px] text-muted-foreground"
                            title={ws.last_built_version}
                          >
                            Last build {shortVersionOrId(ws.last_built_version)}
                          </div>
                        ) : null}
                      </td>
                      <td className="p-2 align-middle">
                        <span className="inline-flex w-fit items-center rounded-full border border-sky-500/40 bg-sky-500/10 px-2 py-0.5 text-xs font-medium leading-none text-sky-900 dark:text-sky-100">
                          Draft
                        </span>
                      </td>
                      <td className="p-2 align-middle text-muted-foreground">
                        {new Date(ws.updated_at).toLocaleString()}
                      </td>
                      <td className="p-2 align-middle">
                        {onDeleteDraft ? (
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            className="h-8 text-destructive hover:text-destructive"
                            title="Delete draft workspace"
                            onClick={(e) => {
                              e.stopPropagation()
                              onDeleteDraft(ws.id)
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        ) : null}
                      </td>
                    </tr>
                  )
                })
              : null}
            {sortedCandidates.map((c) => {
              const active = selectedVersion === c.version
              const pills = candidateAttentionPills(c, thresholds)
              const seq =
                typeof c.candidate_sequence === 'number' && c.candidate_sequence > 0
                  ? c.candidate_sequence
                  : null
              return (
                <tr
                  key={c.version}
                  className={`cursor-pointer border-b transition-colors ${active ? 'bg-primary/10' : 'hover:bg-muted/50'}`}
                  onClick={() => onSelectVersion(c.version)}
                >
                  <td className="p-2 align-middle">
                    <div className="flex flex-wrap items-center gap-2">
                      <span title={`Canonical version id: ${c.version}`}>{seq ?? '—'}</span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-1 text-[11px] text-muted-foreground">
                      <span title="Observation count snapshot at build time">
                        Obs {c.observation_count_at_build ?? 0}
                      </span>
                      <span aria-hidden>·</span>
                      <span title="Recent shadow sample count for this candidate version">
                        Shadow {c.shadow_diff_count_recent ?? 0}
                      </span>
                      <span aria-hidden>·</span>
                      <span title="Version-scoped drift in recent shadow rows">
                        Drift {((c.drift_rate_recent ?? 0) * 100).toFixed(0)}%
                      </span>
                    </div>
                    {pills.length > 0 ? (
                      <div className="mt-1 flex flex-wrap gap-1">
                        {pills.map((p) => (
                          <span
                            key={`${c.version}-${p.key}`}
                            title={p.title}
                            className={`inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium ${p.className}`}
                          >
                            {p.label}
                          </span>
                        ))}
                      </div>
                    ) : null}
                  </td>
                  <td className="p-2 align-middle">
                    <span className="inline-flex w-fit items-center rounded-full border border-border/70 bg-muted/60 px-2 py-0.5 text-xs font-medium leading-none text-foreground">
                      Built
                    </span>
                  </td>
                  <td className="p-2 align-middle text-muted-foreground">
                    {new Date(c.created_at).toLocaleString()}
                  </td>
                  <td className="p-2 align-middle">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={promoting}
                      onClick={(e) => {
                        e.stopPropagation()
                        onSelectVersion(c.version)
                        onPromoteRequest(c.version)
                      }}
                    >
                      Promote…
                    </Button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    )

  if (embedded) {
    if (compactEmbedded) {
      return (
        <div
          className={cn(
            'flex min-h-[200px] min-w-0 flex-col gap-2 px-3 pb-3 pt-2 lg:h-full lg:min-h-0 lg:border-r lg:border-border lg:pr-4'
          )}
        >
          <div className="shrink-0">{sortControl}</div>
          <div className="flex min-h-0 flex-1 flex-col">{tableSection}</div>
        </div>
      )
    }
    return (
      <div className="flex min-h-[200px] min-w-0 flex-col gap-3 p-3 lg:h-full lg:min-h-0 lg:border-r lg:border-border lg:pr-4">
        <div className="shrink-0 space-y-1">
          <h3 className="text-base font-semibold leading-none tracking-tight">
            {hasWorkspacesUi ? 'Workspaces & built versions' : 'Candidate versions'}
          </h3>
          <p className="text-sm text-muted-foreground">
            {hasWorkspacesUi
              ? 'Pick a draft workspace to set entity scope, or a built row to review and promote.'
              : 'Select a row to inspect config and edges, then promote when ready.'}
          </p>
        </div>
        {sortControl}
        <div className="flex min-h-0 flex-1 flex-col">{tableSection}</div>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{hasWorkspacesUi ? 'Workspaces & built versions' : 'Candidate versions'}</CardTitle>
        <CardDescription>
          {hasWorkspacesUi
            ? 'Pick a draft workspace to set entity scope, or a built row to review and promote.'
            : 'Select a row to inspect config and edges, then promote when ready.'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {sortControl}
        {tableSection}
      </CardContent>
    </Card>
  )
}
