'use client'

/**
 * Right-hand entity metrics panel: same interaction model as PyCharter unified Editor
 * `InspectorPanel` (absolute overlay, slide-in, left-edge resize, click-outside to close).
 */

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { EntityMetricsContent } from '@/components/entities/EntityMetricsContent'
import SendEventForm from '@/components/entities/SendEventForm'
import ApplyDataForm from '@/components/entities/ApplyDataForm'
import { getEntityState } from '@/lib/api'
import type { EntityState } from '@/lib/api'
import { useMachineConfigByName } from '@/hooks/useMachineConfigByName'
import { RefreshCw, X } from 'lucide-react'

const DEFAULT_WIDTH_PX = 380
const MIN_WIDTH = 340
const MAX_WIDTH_PERCENT = 0.8

export interface EntityMetricsInspectorOverlayProps {
  /** When null, the panel is not rendered. */
  entityId: string | null
  onClose: () => void
  /** Passed to {@link EntityMetricsContent} to refetch when the list refreshes. */
  refreshToken: number
  /** Header “Refresh” bumps metrics fetch. */
  onRequestMetricsRefresh: () => void
}

export function EntityMetricsInspectorOverlay({
  entityId,
  onClose,
  refreshToken,
  onRequestMetricsRefresh,
}: EntityMetricsInspectorOverlayProps) {
  const drawerRef = useRef<HTMLDivElement>(null)
  const [width, setWidth] = useState(DEFAULT_WIDTH_PX)
  const [isResizing, setIsResizing] = useState(false)
  const [tab, setTab] = useState<'metrics' | 'send' | 'apply_data'>('metrics')
  const [entity, setEntity] = useState<EntityState | null>(null)
  const [entityLoading, setEntityLoading] = useState(false)
  const [entityError, setEntityError] = useState<string | null>(null)

  const isOpen = Boolean(entityId)

  const maxWidthPx =
    typeof window !== 'undefined' ? Math.floor(window.innerWidth * MAX_WIDTH_PERCENT) : 900
  const clampedWidth = Math.min(Math.max(width, MIN_WIDTH), maxWidthPx)

  const handleResizeMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    setIsResizing(true)
  }, [])

  useEffect(() => {
    if (!isResizing) return
    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = window.innerWidth - e.clientX
      setWidth(Math.min(Math.max(newWidth, MIN_WIDTH), window.innerWidth * MAX_WIDTH_PERCENT))
    }
    const handleMouseUp = () => setIsResizing(false)
    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
    document.body.style.cursor = 'ew-resize'
    document.body.style.userSelect = 'none'
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }
  }, [isResizing])

  useEffect(() => {
    if (!isOpen) return
    const handleMouseDown = (e: MouseEvent) => {
      const target = e.target as Node | null
      if (!target) return
      if (!drawerRef.current?.contains(target)) {
        const hasOpenDropdown = drawerRef.current?.querySelector(
          '[data-state="open"][role="combobox"]'
        )
        if (!hasOpenDropdown) {
          onClose()
        }
      }
    }
    document.addEventListener('mousedown', handleMouseDown)
    return () => document.removeEventListener('mousedown', handleMouseDown)
  }, [isOpen, onClose])

  useEffect(() => {
    if (!isOpen) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [isOpen, onClose])

  const fetchEntity = useCallback(async () => {
    if (!entityId) return
    setEntityLoading(true)
    setEntityError(null)
    try {
      const data = await getEntityState(entityId)
      setEntity(data)
    } catch (e) {
      setEntity(null)
      setEntityError(e instanceof Error ? e.message : String(e))
    } finally {
      setEntityLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    if (!isOpen || !entityId) return
    fetchEntity()
  }, [isOpen, entityId, fetchEntity, refreshToken])

  const { config: machineConfig } = useMachineConfigByName(entity?.machine_name ?? null)

  if (!isOpen || !entityId) {
    return null
  }

  return (
    <div
      ref={drawerRef}
      role="complementary"
      aria-label="Entity metrics"
      style={{
        position: 'absolute',
        top: 0,
        right: 0,
        bottom: 0,
        width: clampedWidth,
        minWidth: MIN_WIDTH,
        maxWidth: maxWidthPx,
        display: 'flex',
        flexDirection: 'column',
        background: 'hsl(var(--background))',
        borderLeft: '1px solid hsl(var(--border))',
        boxShadow: '-4px 0 12px hsl(var(--foreground) / 0.06)',
        zIndex: 20,
        animation: 'inspectorPanelSlideIn 0.2s ease-out',
      }}
    >
      <style>{`
        @keyframes inspectorPanelSlideIn {
          from { transform: translateX(100%); opacity: 0.9; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>

      <div
        role="separator"
        aria-orientation="vertical"
        aria-label="Resize panel"
        onMouseDown={handleResizeMouseDown}
        className="absolute left-0 top-0 bottom-0 w-2 cursor-ew-resize touch-none z-10 -ml-px hover:bg-primary/20 active:bg-primary/30"
        style={{ cursor: isResizing ? 'ew-resize' : undefined }}
      />

      <header className="flex shrink-0 items-center justify-between gap-2 border-b border-border px-3 py-2">
        <div className="min-w-0">
          <h2 className="truncate text-xs font-semibold">Entity Inspector</h2>
          <p className="truncate text-[11px] text-muted-foreground">
            {entityLoading ? 'Loading…' : entity ? `${entity.entity_id} · ${entity.current_state}` : entityError ? entityError : entityId}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => {
              onRequestMetricsRefresh()
              fetchEntity()
            }}
            aria-label="Refresh"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
          <button
            type="button"
            onClick={onClose}
            className="rounded p-1 text-muted-foreground hover:text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/50"
            aria-label="Close panel"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden p-3">
        <div className="mb-3 flex flex-wrap gap-1.5">
          <Button
            type="button"
            variant={tab === 'metrics' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setTab('metrics')}
          >
            Metrics
          </Button>
          <Button
            type="button"
            variant={tab === 'send' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setTab('send')}
          >
            Send Trigger
          </Button>
          <Button
            type="button"
            variant={tab === 'apply_data' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setTab('apply_data')}
          >
            Apply Data
          </Button>
        </div>

        {tab === 'metrics' ? (
          <EntityMetricsContent entityId={entityId} refreshToken={refreshToken} />
        ) : tab === 'send' ? (
          <SendEventForm
            entityId={entityId}
            defaultMachineName={entity?.machine_name}
            stateVariables={machineConfig?.state_variables ?? []}
            onSuccess={() => {
              fetchEntity()
              onRequestMetricsRefresh()
            }}
          />
        ) : (
          <ApplyDataForm
            entityId={entityId}
            defaultMachineName={entity?.machine_name}
            stateVariables={machineConfig?.state_variables ?? []}
            onEnqueued={() => {
              onRequestMetricsRefresh()
            }}
          />
        )}
      </div>
    </div>
  )
}
