'use client'

import { useMemo } from 'react'
import DataTable, { type Column } from './DataTable'

export interface FSMEvent {
  name: string
  description?: string
  payload?: Record<string, unknown>
}

interface EventTableProps {
  events: FSMEvent[]
  onChange: (events: FSMEvent[]) => void
}

export default function EventTable({ events, onChange }: EventTableProps) {
  const columns: Column<FSMEvent>[] = useMemo(
    () => [
      {
        key: 'name',
        header: 'Name',
        width: '180px',
        accessor: (r) => r.name,
        editor: 'text',
        onChange: (r, v) => ({ ...r, name: String(v) }),
        required: true,
      },
      {
        key: 'description',
        header: 'Description',
        accessor: (r) => r.description ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, description: String(v) || undefined }),
      },
      {
        key: 'payload',
        header: 'Payload (JSON)',
        accessor: (r) => (r.payload ? JSON.stringify(r.payload) : ''),
        editor: 'text',
        onChange: (r, v) => {
          const raw = String(v).trim()
          if (!raw) return { ...r, payload: undefined }
          try {
            return { ...r, payload: JSON.parse(raw) }
          } catch {
            return r
          }
        },
      },
    ],
    [],
  )

  return (
    <DataTable<FSMEvent>
      columns={columns}
      rows={events}
      onRowsChange={onChange}
      rowKey={(r) => r.name || `event-${events.indexOf(r)}`}
      onAddRow={() => ({ name: `event_${events.length + 1}` })}
      emptyMessage="No events defined."
      addLabel="Add event"
    />
  )
}
