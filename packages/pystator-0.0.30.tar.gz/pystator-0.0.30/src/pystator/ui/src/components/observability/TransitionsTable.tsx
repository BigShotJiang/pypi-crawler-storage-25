'use client'

import { Button } from '@/components/ui/button'
import type { ObservabilityTransitionItem } from '@/lib/api'
import { AlertCircle, CheckCircle2, ChevronLeft, ChevronRight } from 'lucide-react'

interface TransitionsTableProps {
  items: ObservabilityTransitionItem[]
  total: number
  limit: number
  offset: number
  status: 'all' | 'success' | 'failed'
  loading: boolean
  onStatusChange: (value: 'all' | 'success' | 'failed') => void
  onPrev: () => void
  onNext: () => void
  onEntityClick: (entityId: string) => void
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleString()
}

export function TransitionsTable({
  items,
  total,
  limit,
  offset,
  status,
  loading,
  onStatusChange,
  onPrev,
  onNext,
  onEntityClick,
}: TransitionsTableProps) {
  const hasPrev = offset > 0
  const hasNext = offset + limit < total

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">Transition Feed</div>
        <select
          className="rounded-md border border-input bg-background px-2 py-1.5 text-sm"
          value={status}
          onChange={(e) => onStatusChange(e.target.value as 'all' | 'success' | 'failed')}
        >
          <option value="all">All statuses</option>
          <option value="success">Success only</option>
          <option value="failed">Failed only</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-lg border">
        <table className="min-w-full divide-y divide-border">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Time</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Machine</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Entity</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Trigger</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Transition</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Duration</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border bg-background">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-3 py-10 text-center text-sm text-muted-foreground">Loading transitions…</td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-3 py-10 text-center text-sm text-muted-foreground">No transition records for this filter scope.</td>
              </tr>
            ) : (
              items.map((item) => (
                <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{formatTime(item.created_at)}</td>
                  <td className="px-3 py-2 text-sm text-muted-foreground whitespace-nowrap">{item.machine_name ?? '—'}</td>
                  <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => onEntityClick(item.entity_id)}
                      className="text-primary hover:underline"
                    >
                      {item.entity_id}
                    </button>
                  </td>
                  <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">{item.trigger}</td>
                  <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                    {item.source_state} <span className="text-muted-foreground">→</span> {item.target_state ?? '—'}
                  </td>
                  <td className="px-3 py-2 text-sm text-muted-foreground whitespace-nowrap">
                    {item.duration_ms != null ? `${item.duration_ms} ms` : '—'}
                  </td>
                  <td className="px-3 py-2 text-xs whitespace-nowrap">
                    {item.success ? (
                      <span className="inline-flex items-center gap-1 text-emerald-600">
                        <CheckCircle2 className="h-4 w-4" /> Success
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-destructive" title={item.error_message ?? ''}>
                        <AlertCircle className="h-4 w-4" /> Failed
                      </span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {total === 0 ? 'No records' : `Showing ${offset + 1}–${Math.min(offset + limit, total)} of ${total}`}
        </p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={!hasPrev || loading} onClick={onPrev}>
            <ChevronLeft className="h-4 w-4 mr-1" /> Prev
          </Button>
          <Button variant="outline" size="sm" disabled={!hasNext || loading} onClick={onNext}>
            Next <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  )
}
