'use client'

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import {
  getApiErrorMessage,
  getObservabilitySummary,
  listObservabilityTransitions,
  listObservabilityWorkerEvents,
  type ObservabilitySummaryResponse,
  type ObservabilityTransitionItem,
  type ObservabilityWorkerEventItem,
} from '@/lib/api'
import { KpiCards } from '@/components/observability/KpiCards'
import { ObservabilityFilterBar } from '@/components/observability/ObservabilityFilterBar'
import { OverviewPanel } from '@/components/observability/OverviewPanel'
import { TransitionsTable } from '@/components/observability/TransitionsTable'
import { WorkerEventsTable } from '@/components/observability/WorkerEventsTable'
import { EntityHealthPanel } from '@/components/observability/EntityHealthPanel'
import { TransitionAnalyticsPanel } from '@/components/observability/TransitionAnalyticsPanel'
import type { ObservabilityFilters, ObservabilityTab } from '@/components/observability/types'
import { RefreshCw } from 'lucide-react'

const PAGE_SIZE = 25

function buildStartAtIso(windowHours: number): string {
  const d = new Date(Date.now() - windowHours * 60 * 60 * 1000)
  return d.toISOString()
}

const TAB_LABELS: { id: ObservabilityTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'transitions', label: 'Transitions' },
  { id: 'worker-events', label: 'Worker Events' },
  { id: 'analytics', label: 'Analytics' },
]

const DEFAULT_FILTERS: ObservabilityFilters = {
  machineName: '',
  entityId: '',
  windowHours: 24,
}

export interface ObservabilityDashboardProps {
  /** Called when the user clicks an entity id in a table or health panel. */
  onEntityClick: (entityId: string) => void
  /** Extra class on the outer wrapper. */
  className?: string
  /** Optional: replace the default auto-refresh + refresh toolbar (e.g. empty fragment when the shell renders actions elsewhere). */
  toolbar?: ReactNode | null
}

/**
 * Full observability data experience (filters, KPIs, tabs, tables). Page shells provide title and chrome.
 */
export function ObservabilityDashboard({ onEntityClick, className, toolbar }: ObservabilityDashboardProps) {
  const [filters, setFilters] = useState<ObservabilityFilters>(DEFAULT_FILTERS)
  const [draftFilters, setDraftFilters] = useState<ObservabilityFilters>(DEFAULT_FILTERS)
  const [activeTab, setActiveTab] = useState<ObservabilityTab>('overview')

  const [summary, setSummary] = useState<ObservabilitySummaryResponse | null>(null)
  const [summaryLoading, setSummaryLoading] = useState(true)

  const [transitionStatus, setTransitionStatus] = useState<'all' | 'success' | 'failed'>('all')
  const [transitionItems, setTransitionItems] = useState<ObservabilityTransitionItem[]>([])
  const [transitionTotal, setTransitionTotal] = useState(0)
  const [transitionOffset, setTransitionOffset] = useState(0)
  const [transitionsLoading, setTransitionsLoading] = useState(false)
  const [recentFailedTransitions, setRecentFailedTransitions] = useState<ObservabilityTransitionItem[]>([])
  const [recentFailuresLoading, setRecentFailuresLoading] = useState(false)

  const [workerStatus, setWorkerStatus] = useState<
    'all' | 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  >('all')
  const [workerItems, setWorkerItems] = useState<ObservabilityWorkerEventItem[]>([])
  const [workerTotal, setWorkerTotal] = useState(0)
  const [workerOffset, setWorkerOffset] = useState(0)
  const [workersLoading, setWorkersLoading] = useState(false)

  const [autoRefresh, setAutoRefresh] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const startAt = useMemo(() => buildStartAtIso(filters.windowHours), [filters.windowHours])

  const fetchSummary = useCallback(async () => {
    setSummaryLoading(true)
    try {
      const res = await getObservabilitySummary({
        window_hours: filters.windowHours,
        machine_name: filters.machineName || undefined,
        entity_id: filters.entityId || undefined,
      })
      setSummary(res)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setSummaryLoading(false)
    }
  }, [filters])

  const fetchTransitions = useCallback(
    async (offset: number) => {
      setTransitionsLoading(true)
      try {
        const res = await listObservabilityTransitions({
          machine_name: filters.machineName || undefined,
          entity_id: filters.entityId || undefined,
          status: transitionStatus,
          start_at: startAt,
          limit: PAGE_SIZE,
          offset,
        })
        setTransitionItems(res.items)
        setTransitionTotal(res.total)
      } catch (e) {
        setError(e instanceof Error ? e : new Error(String(e)))
      } finally {
        setTransitionsLoading(false)
      }
    },
    [filters, startAt, transitionStatus]
  )

  const fetchWorkers = useCallback(
    async (offset: number) => {
      setWorkersLoading(true)
      try {
        const res = await listObservabilityWorkerEvents({
          machine_name: filters.machineName || undefined,
          entity_id: filters.entityId || undefined,
          status: workerStatus,
          start_at: startAt,
          limit: PAGE_SIZE,
          offset,
        })
        setWorkerItems(res.items)
        setWorkerTotal(res.total)
      } catch (e) {
        setError(e instanceof Error ? e : new Error(String(e)))
      } finally {
        setWorkersLoading(false)
      }
    },
    [filters, startAt, workerStatus]
  )

  const fetchRecentFailures = useCallback(async () => {
    setRecentFailuresLoading(true)
    try {
      const res = await listObservabilityTransitions({
        machine_name: filters.machineName || undefined,
        entity_id: filters.entityId || undefined,
        status: 'failed',
        start_at: startAt,
        limit: 8,
        offset: 0,
      })
      setRecentFailedTransitions(res.items)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setRecentFailuresLoading(false)
    }
  }, [filters, startAt])

  const refreshAll = useCallback(async () => {
    await fetchSummary()
    if (activeTab === 'overview') {
      await fetchRecentFailures()
      await fetchTransitions(transitionOffset)
    } else if (activeTab === 'transitions') {
      await fetchTransitions(transitionOffset)
    }
    if (activeTab === 'worker-events') {
      await fetchWorkers(workerOffset)
    }
  }, [
    activeTab,
    fetchSummary,
    fetchRecentFailures,
    fetchTransitions,
    fetchWorkers,
    transitionOffset,
    workerOffset,
  ])

  useEffect(() => {
    refreshAll()
  }, [refreshAll])

  useEffect(() => {
    if (!autoRefresh) return
    const id = window.setInterval(() => {
      refreshAll().catch(() => {})
    }, 15000)
    return () => window.clearInterval(id)
  }, [autoRefresh, refreshAll])

  useEffect(() => {
    setTransitionOffset(0)
    if (activeTab === 'overview' || activeTab === 'transitions') {
      fetchTransitions(0)
    }
  }, [transitionStatus, activeTab, fetchTransitions])

  useEffect(() => {
    setWorkerOffset(0)
    if (activeTab === 'worker-events') {
      fetchWorkers(0)
    }
  }, [workerStatus, activeTab, fetchWorkers])

  const applyFilters = () => {
    setError(null)
    setFilters(draftFilters)
    setTransitionOffset(0)
    setWorkerOffset(0)
  }

  const clearFilters = () => {
    setDraftFilters(DEFAULT_FILTERS)
    setFilters(DEFAULT_FILTERS)
    setTransitionOffset(0)
    setWorkerOffset(0)
    setError(null)
  }

  const defaultToolbar = (
    <div className="flex gap-2">
      <Button variant={autoRefresh ? 'default' : 'outline'} size="sm" onClick={() => setAutoRefresh((v) => !v)}>
        Auto-refresh {autoRefresh ? 'On' : 'Off'}
      </Button>
      <Button variant="outline" size="sm" onClick={refreshAll}>
        <RefreshCw
          className={`h-4 w-4 mr-1.5 ${summaryLoading || transitionsLoading || workersLoading ? 'animate-spin' : ''}`}
        />
        Refresh
      </Button>
    </div>
  )

  const toolbarNode = toolbar === undefined ? defaultToolbar : toolbar

  return (
    <div className={className}>
      {toolbarNode}

      {error && (
        <ErrorDisplay
          error={new Error(getApiErrorMessage(error, 'Failed to load observability data'))}
          className="mt-4"
        />
      )}

      <div className="mt-6">
        <KpiCards
          summary={summary}
          onFailedTransitionsClick={() => {
            setActiveTab('transitions')
            setTransitionStatus('failed')
          }}
        />
      </div>

      <ObservabilityFilterBar
        draftFilters={draftFilters}
        onDraftChange={setDraftFilters}
        onApply={applyFilters}
        onClear={clearFilters}
      />

      <div className="mt-4 flex gap-2 border-b border-border">
        {TAB_LABELS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-4">
        {activeTab === 'overview' && (
          <div className="space-y-4">
            <OverviewPanel
              summary={summary}
              recentFailedTransitions={recentFailedTransitions}
              loadingRecentFailures={recentFailuresLoading}
              onOpenTransitions={() => setActiveTab('transitions')}
              onEntityClick={onEntityClick}
            />
            <EntityHealthPanel
              windowHours={filters.windowHours}
              machineName={filters.machineName || undefined}
              onEntityClick={onEntityClick}
            />
          </div>
        )}

        {activeTab === 'transitions' && (
          <TransitionsTable
            items={transitionItems}
            total={transitionTotal}
            limit={PAGE_SIZE}
            offset={transitionOffset}
            status={transitionStatus}
            loading={transitionsLoading}
            onStatusChange={setTransitionStatus}
            onPrev={() => {
              const next = Math.max(0, transitionOffset - PAGE_SIZE)
              setTransitionOffset(next)
              fetchTransitions(next)
            }}
            onNext={() => {
              const next = transitionOffset + PAGE_SIZE
              setTransitionOffset(next)
              fetchTransitions(next)
            }}
            onEntityClick={onEntityClick}
          />
        )}

        {activeTab === 'worker-events' && (
          <WorkerEventsTable
            items={workerItems}
            total={workerTotal}
            limit={PAGE_SIZE}
            offset={workerOffset}
            status={workerStatus}
            loading={workersLoading}
            onStatusChange={setWorkerStatus}
            onPrev={() => {
              const next = Math.max(0, workerOffset - PAGE_SIZE)
              setWorkerOffset(next)
              fetchWorkers(next)
            }}
            onNext={() => {
              const next = workerOffset + PAGE_SIZE
              setWorkerOffset(next)
              fetchWorkers(next)
            }}
            onEntityClick={onEntityClick}
          />
        )}

        {activeTab === 'analytics' && (
          <TransitionAnalyticsPanel
            windowHours={filters.windowHours}
            machineName={filters.machineName || undefined}
          />
        )}
      </div>
    </div>
  )
}
