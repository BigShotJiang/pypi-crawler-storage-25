'use client'

import { useState, useMemo, useEffect } from 'react'
import { ChevronDown, ChevronRight, GitBranch, Search, FilePlus2 } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { useMachineBrowseStore } from '@/stores/machine-browse'
import { MachineFileTreeNode } from './MachineFileTreeNode'

// ---------------------------------------------------------------------------
// Constants (single place for layout/styling; mirrors pycharter FileBrowser/FileTree)
// ---------------------------------------------------------------------------

const machineBrowseStyles = {
  searchBar: 'shrink-0 border-b border-border px-2 py-2',
  searchInput: 'h-8 pl-7 text-xs',
  sectionHeader: 'flex items-center gap-1.5 px-2 py-1.5',
  sectionHeaderButton: 'flex flex-1 items-center gap-1.5 text-left',
  sectionLabel: 'text-xs font-semibold uppercase tracking-wider',
  listContainer: 'space-y-0.5',
  rowBase:
    'flex w-full items-center gap-1.5 rounded-md px-1.5 py-1 text-left text-xs transition-colors hover:bg-muted',
  rowSelected: 'bg-primary/10 text-primary',
  rowDefault: 'text-foreground',
  emptyText: 'px-4 py-3 text-[11px] text-muted-foreground',
  errorBox: 'mx-2 rounded bg-destructive/10 px-2 py-1 text-xs text-destructive',
  skeletonContainer: 'space-y-1 px-4',
} as const

// ---------------------------------------------------------------------------
// Hook: filter machine names by search query (testable, reusable)
// ---------------------------------------------------------------------------

function useMachineFilter(uniqueNames: string[], searchQuery: string) {
  const filteredNames = useMemo(() => {
    const q = searchQuery.trim().toLowerCase()
    if (!q) return uniqueNames
    return uniqueNames.filter((name) => name.toLowerCase().includes(q))
  }, [uniqueNames, searchQuery])
  const hasActiveFilter = Boolean(searchQuery.trim())
  return { filteredNames, hasActiveFilter }
}

/** Props for the Browse panel content. Shows unique machine names in a file-system-style list (or tree when using store). */
export interface MachineBrowseContentProps {
  /** Machines to display (from listMachines). */
  machines: { name: string; namespace?: string | null }[]
  /** Currently selected machine name (for highlight and toolbar sync). */
  selectedMachineName: string | null
  /** Called when user selects a machine name (e.g. load that machine). */
  onMachineNameSelect: (name: string) => void
  /** Called when user creates a new machine draft from scratch. */
  onCreateMachineFromScratch?: () => void
  /** When true, show loading skeletons. */
  loading?: boolean
  /** Error message to show (e.g. failed to load machines). */
  error?: string | null
}

/**
 * Browse panel content: file-system-style list of unique machine names.
 * Mirrors pycharter FileBrowser + FileTree layout and styling.
 * Supports filter-by-search and optional folder tree (when using machine-browse store).
 */
export function MachineBrowseContent({
  machines,
  selectedMachineName,
  onMachineNameSelect,
  onCreateMachineFromScratch,
  loading = false,
  error = null,
}: MachineBrowseContentProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [sectionCollapsed, setSectionCollapsed] = useState(false)
  const uniqueNames = useMemo(
    () =>
      machines.map((m) => (m.namespace ? `${m.namespace}/${m.name}` : m.name)),
    [machines]
  )
  const { filteredNames, hasActiveFilter } = useMachineFilter(uniqueNames, searchQuery)

  const buildTree = useMachineBrowseStore((s) => s.buildTree)

  const filteredMachines = useMemo(() => {
    const allowed = new Set(filteredNames)
    return machines.filter((m) => allowed.has(m.namespace ? `${m.namespace}/${m.name}` : m.name))
  }, [machines, filteredNames])

  const roots = useMemo(
    () => buildTree(filteredMachines),
    [buildTree, filteredMachines]
  )
  const isEmpty = roots.length === 0

  const handleNewMachine = () => onCreateMachineFromScratch?.()

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <div className={machineBrowseStyles.searchBar}>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Filter..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={machineBrowseStyles.searchInput}
            aria-label="Filter machines"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-1">
        <div>
          <div className={machineBrowseStyles.sectionHeader}>
            <button
              type="button"
              onClick={() => setSectionCollapsed(!sectionCollapsed)}
              className={machineBrowseStyles.sectionHeaderButton}
            >
              {sectionCollapsed ? (
                <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
              )}
              <GitBranch className="h-3.5 w-3.5" />
              <span className={machineBrowseStyles.sectionLabel}>Machines</span>
            </button>
            <Button
              variant="ghost"
              size="sm"
              className="h-5 w-5 p-0"
              title="New state machine"
              onClick={handleNewMachine}
            >
              <FilePlus2 className="h-3 w-3" />
            </Button>
          </div>

          {!sectionCollapsed && (
            <div className="pb-2">
              {error ? (
                <div className={machineBrowseStyles.errorBox} role="alert">
                  {error}
                </div>
              ) : loading ? (
                <div className={machineBrowseStyles.skeletonContainer}>
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-5 w-1/2" />
                </div>
              ) : isEmpty ? (
                <p className={machineBrowseStyles.emptyText}>
                  {hasActiveFilter ? 'No matches.' : 'No items yet.'}
                </p>
              ) : (
                <div className={machineBrowseStyles.listContainer} role="tree" aria-label="Machines">
                  {roots.map((node) => (
                    <MachineFileTreeNode
                      key={node.id}
                      node={node}
                      depth={0}
                      selectedMachineName={selectedMachineName}
                      onMachineNameSelect={onMachineNameSelect}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
