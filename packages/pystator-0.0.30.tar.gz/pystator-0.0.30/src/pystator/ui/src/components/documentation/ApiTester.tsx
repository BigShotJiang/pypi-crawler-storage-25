'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { getApiBaseUrl } from '@/lib/settings'
import LoadingSpinner from '@/components/LoadingSpinner'
import { Play, Copy, Check } from 'lucide-react'
import type { ApiMethodDoc } from '@/data/apiMethods'

interface ApiTestResult {
  success: boolean
  data?: unknown
  error?: string
}

interface ApiTesterProps {
  method: ApiMethodDoc
}

export function ApiTester({ method }: ApiTesterProps) {
  const [requestBody, setRequestBody] = useState<string>(
    method.exampleRequest ? JSON.stringify(method.exampleRequest, null, 2) : ''
  )
  const [result, setResult] = useState<ApiTestResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)

  if (!method.apiEndpoint) return null

  /** Replace path parameters with placeholders so "Try it" works. */
  const resolvePath = (path: string): string =>
    path
      .replace(/\{machine_id\}/g, '00000000-0000-0000-0000-000000000000')
      .replace(/\{entity_id\}/g, 'test-entity-1')
      .replace(/\{filename:path\}/g, 'blank.yaml')
      .replace(/\{filename\}/g, 'blank.yaml')

  const handleTest = async () => {
    setLoading(true)
    setResult(null)
    try {
      const base = getApiBaseUrl()
      const endpoint = resolvePath(method.apiEndpoint ?? '')
      const url = `${base}${endpoint}`
      let response: Response
      if (method.apiMethod === 'GET' || method.apiMethod === 'DELETE') {
        response = await fetch(url, { method: method.apiMethod })
      } else {
        const body = requestBody ? JSON.parse(requestBody) : {}
        response = await fetch(url, {
          method: method.apiMethod,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        })
      }
      const contentType = response.headers.get('content-type')
      let data: unknown
      if (contentType?.includes('application/json')) {
        try {
          data = await response.json()
        } catch {
          data = { message: await response.text() }
        }
      } else {
        data = { message: await response.text() }
      }
      if (!response.ok) {
        const err = data as { detail?: string; message?: string }
        setResult({
          success: false,
          error: typeof err?.detail === 'string' ? err.detail : err?.message || `HTTP ${response.status}`,
        })
      } else {
        setResult({ success: true, data })
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to test API'
      setResult({
        success: false,
        error: message.includes('JSON') ? 'Invalid JSON in request body.' : message,
      })
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="border rounded-lg p-4 bg-muted/30">
      <div className="flex items-center justify-between mb-3">
        <h5 className="text-sm font-semibold">Test API</h5>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => copyToClipboard(method.apiEndpoint!)}
            className="h-7"
          >
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          </Button>
          <Button
            size="sm"
            onClick={handleTest}
            disabled={
              loading ||
              (method.apiMethod !== 'GET' && method.apiMethod !== 'DELETE' && !requestBody.trim())
            }
            className="h-7 flex items-center gap-1"
          >
            {loading ? (
              <>
                <LoadingSpinner size="sm" />
                <span>Testing...</span>
              </>
            ) : (
              <>
                <Play className="h-3 w-3 mr-1" />
                Test
              </>
            )}
          </Button>
        </div>
      </div>

      {method.apiMethod !== 'GET' && method.apiMethod !== 'DELETE' && (
        <div className="mb-3">
          <label className="block text-xs font-medium mb-1">Request body (JSON)</label>
          <textarea
            value={requestBody}
            onChange={(e) => setRequestBody(e.target.value)}
            rows={6}
            className="w-full px-2 py-1 border rounded text-xs font-mono bg-background"
            placeholder="Enter JSON request body..."
          />
        </div>
      )}

      <div className="text-xs text-muted-foreground mb-2">
        <span className="font-mono font-semibold">{method.apiMethod}</span> {method.apiEndpoint}
      </div>

      {result && (
        <div className="mt-3">
          {result.success ? (
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded p-2">
              <div className="text-xs font-semibold text-green-800 dark:text-green-200 mb-1">Success</div>
              <pre className="text-xs overflow-x-auto text-green-700 dark:text-green-300">
                {JSON.stringify(result.data, null, 2)}
              </pre>
            </div>
          ) : (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded p-2">
              <div className="text-xs font-semibold text-red-800 dark:text-red-200 mb-1">Error</div>
              <div className="text-xs text-red-700 dark:text-red-300">{result.error}</div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
