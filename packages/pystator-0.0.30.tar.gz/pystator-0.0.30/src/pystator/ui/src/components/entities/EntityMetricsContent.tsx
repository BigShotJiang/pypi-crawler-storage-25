'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import LoadingSpinner from '@/components/LoadingSpinner'
import { StateBadge, StatusBadge, WorkflowStatusBadge } from '@/components/entities/EntityBadges'
import {
  getEntityState,
  getEntityMetrics,
  getAvailableTriggers,
  getHistoryStats,
  getEntityHistory,
  type EntityState,
  type EntityMetricsResponse,
  type AvailableTriggersResponse,
  type HistoryStatsResponse,
  type TransitionHistoryEntry,
  type ErrorPatternItem,
  type DwellByStateItem,
  type FleetComparison,
  type VelocityPoint,
  type DurationPercentiles,
} from '@/lib/api'
import { entityDetailUrl } from '@/lib/constants'
import {
  ChevronDown,
  ChevronRight,
  ExternalLink,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Shield,
  BarChart3,
  TrendingUp,
  Activity,
  Repeat2,
  Zap,
  Clock,
} from 'lucide-react'

export interface EntityMetricsContentProps {
  entityId: string
  /** Bump to refetch all data. */
  refreshToken?: number
  /** Navigate to the full entity detail page. */
  onOpenDetail?: (entityId: string) => void
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                           */
/* ------------------------------------------------------------------ */

function formatMs(ms: number): string {
  if (ms < 1000) return `${Math.round(ms)}ms`
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
  return `${(ms / 60000).toFixed(1)}min`
}

function formatRelativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  return `${Math.floor(diff / 86400000)}d ago`
}

type HealthStatus = 'healthy' | 'warning' | 'critical'

function healthDotColor(status: HealthStatus): string {
  switch (status) {
    case 'healthy':
      return 'bg-emerald-500'
    case 'warning':
      return 'bg-amber-500'
    case 'critical':
      return 'bg-red-500'
  }
}

function healthStrokeClass(status: HealthStatus): string {
  switch (status) {
    case 'healthy':
      return 'stroke-emerald-500'
    case 'warning':
      return 'stroke-amber-500'
    case 'critical':
      return 'stroke-red-500'
  }
}

function healthTextClass(status: HealthStatus): string {
  switch (status) {
    case 'healthy':
      return 'fill-emerald-500'
    case 'warning':
      return 'fill-amber-500'
    case 'critical':
      return 'fill-red-500'
  }
}

function sparklineStrokeClass(status: HealthStatus): string {
  switch (status) {
    case 'healthy':
      return 'stroke-emerald-500'
    case 'warning':
      return 'stroke-amber-500'
    case 'critical':
      return 'stroke-red-500'
  }
}

function sparklineFillClass(status: HealthStatus): string {
  switch (status) {
    case 'healthy':
      return 'fill-emerald-500/10'
    case 'warning':
      return 'fill-amber-500/10'
    case 'critical':
      return 'fill-red-500/10'
  }
}

function failureBarColor(rate: number): string {
  if (rate <= 0.05) return 'bg-emerald-500'
  if (rate <= 0.2) return 'bg-amber-500'
  return 'bg-red-500'
}

/* ------------------------------------------------------------------ */
/*  CollapsibleSection                                                */
/* ------------------------------------------------------------------ */

function CollapsibleSection({
  title,
  defaultOpen = false,
  children,
  icon,
}: {
  title: string
  defaultOpen?: boolean
  children: React.ReactNode
  icon?: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="border-t border-border/50 pt-3 pb-2">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 w-full text-left text-xs font-medium text-muted-foreground uppercase tracking-wider hover:text-foreground transition-colors"
      >
        {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        {icon}
        {title}
      </button>
      {open && <div className="mt-2">{children}</div>}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Section sub-components                                            */
/* ------------------------------------------------------------------ */

/** SVG health-score ring (40x40). */
function HealthRing({ score, status }: { score: number; status: HealthStatus }) {
  const size = 40
  const strokeWidth = 3.5
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const filled = (Math.min(Math.max(score, 0), 100) / 100) * circumference

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        className="stroke-muted"
        strokeWidth={strokeWidth}
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        className={healthStrokeClass(status)}
        strokeWidth={strokeWidth}
        strokeDasharray={`${filled} ${circumference - filled}`}
        strokeDashoffset={circumference / 4}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <text
        x={size / 2}
        y={size / 2}
        textAnchor="middle"
        dominantBaseline="central"
        className={`text-[11px] font-bold ${healthTextClass(status)}`}
      >
        {score}
      </text>
    </svg>
  )
}

/** Stuck detection banner. */
function StuckBanner({
  stuckState,
  currentDwellMs,
  avgDwellMs,
}: {
  stuckState: string | null
  currentDwellMs: number | null
  avgDwellMs: number | null
}) {
  return (
    <div className="rounded-lg bg-amber-50 dark:bg-amber-950/20 p-2 flex items-start gap-2">
      <AlertTriangle className="h-3.5 w-3.5 text-amber-500 mt-0.5 shrink-0" />
      <div className="text-xs">
        <p className="font-medium text-amber-800 dark:text-amber-300">
          Potentially stuck in{' '}
          <code className="rounded bg-amber-100 dark:bg-amber-900/40 px-1 text-[10px]">
            {stuckState}
          </code>
        </p>
        {currentDwellMs != null && avgDwellMs != null && (
          <p className="text-amber-700 dark:text-amber-400 mt-0.5">
            current: {formatMs(currentDwellMs)}, avg: {formatMs(avgDwellMs)}
          </p>
        )}
      </div>
    </div>
  )
}

/** Failure rate bar. */
function FailureRateBar({ rate }: { rate: number }) {
  const pct = Math.min(rate * 100, 100)
  return (
    <div className="space-y-0.5">
      <div className="flex items-center justify-between text-[10px]">
        <span className="text-muted-foreground">Failure rate</span>
        <span className="font-medium">{pct.toFixed(1)}%</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${failureBarColor(rate)}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}

/** Expandable error patterns. */
function ErrorPatterns({ patterns }: { patterns: ErrorPatternItem[] }) {
  const [expanded, setExpanded] = useState(false)
  return (
    <div>
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="text-xs text-muted-foreground hover:text-foreground transition-colors"
      >
        {patterns.length} error pattern{patterns.length !== 1 ? 's' : ''}
        {expanded ? ' (hide)' : ' (show)'}
      </button>
      {expanded && (
        <div className="mt-1.5 space-y-1">
          {patterns.slice(0, 8).map((p, i) => (
            <div key={i} className="flex items-center gap-1.5 text-[10px]">
              <span className="text-foreground truncate">
                {p.error_type ?? 'Unknown'}
              </span>
              <span className="text-muted-foreground">on</span>
              <code className="rounded bg-muted px-1 text-[10px] font-mono">{p.trigger}</code>
              <span className="text-muted-foreground">from</span>
              <code className="rounded bg-muted px-1 text-[10px] font-mono">{p.source_state}</code>
              <span className="ml-auto inline-flex items-center px-1.5 py-0.5 rounded-full bg-destructive/10 text-destructive text-[10px] font-medium shrink-0">
                {p.count}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/** Latency percentile bars. */
function LatencyBars({ percentiles }: { percentiles: DurationPercentiles }) {
  const entries: { label: string; value: number | null }[] = [
    { label: 'p50', value: percentiles.p50 },
    { label: 'p75', value: percentiles.p75 },
    { label: 'p95', value: percentiles.p95 },
    { label: 'p99', value: percentiles.p99 },
  ]
  const maxVal = Math.max(...entries.map((e) => e.value ?? 0).filter((v) => v > 0), 1)

  return (
    <div className="space-y-1.5">
      {entries.map((entry) => {
        const pct = entry.value != null && maxVal > 0 ? (entry.value / maxVal) * 100 : 0
        return (
          <div key={entry.label} className="flex items-center gap-2">
            <span className="text-[10px] w-6 text-right font-mono text-muted-foreground">
              {entry.label}
            </span>
            <div className="flex-1 h-2 rounded-full bg-primary/20 overflow-hidden">
              <div
                className="h-full rounded-full bg-primary transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-foreground w-14 text-right">
              {entry.value != null ? formatMs(entry.value) : '--'}
            </span>
          </div>
        )
      })}
    </div>
  )
}

/** Compact dwell-by-state table. */
function DwellTable({ items }: { items: DwellByStateItem[] }) {
  if (items.length === 0) {
    return <p className="text-xs text-muted-foreground">No dwell data.</p>
  }
  return (
    <table className="w-full text-xs">
      <thead>
        <tr className="border-b text-muted-foreground">
          <th className="text-left py-1 pr-2 font-medium">State</th>
          <th className="text-right py-1 px-2 font-medium">Avg</th>
          <th className="text-right py-1 pl-2 font-medium">Visits</th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.state} className="border-b border-border/30">
            <td className="py-1 pr-2 font-mono">{item.state}</td>
            <td className="text-right py-1 px-2 font-mono">{formatMs(item.avg_ms)}</td>
            <td className="text-right py-1 pl-2">{item.visit_count}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

/** Behavioral patterns: revisits + fleet comparison. */
function BehavioralSection({
  stateRevisits,
  hasCycles,
  fleet,
}: {
  stateRevisits: Record<string, number>
  hasCycles: boolean
  fleet: FleetComparison | null
}) {
  const revisitEntries = hasCycles
    ? Object.entries(stateRevisits).filter(([, count]) => count > 1)
    : []

  return (
    <div className="space-y-3">
      {revisitEntries.length > 0 && (
        <div>
          <p className="text-[10px] text-muted-foreground uppercase mb-1">State revisits</p>
          <div className="flex flex-wrap gap-1">
            {revisitEntries.map(([state, count]) => (
              <span
                key={state}
                className="inline-flex items-center gap-0.5 rounded border border-border px-1.5 py-0.5 text-[10px]"
              >
                <code>{state}</code>
                <span className="text-muted-foreground">&times;{count}</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {fleet && (
        <div className="space-y-1 text-xs">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Failure rate</span>
            <span className="flex items-center gap-1.5">
              <span
                className={
                  fleet.entity_failure_rate <= fleet.fleet_failure_rate
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-red-600 dark:text-red-400'
                }
              >
                {(fleet.entity_failure_rate * 100).toFixed(1)}%
              </span>
              <span className="text-muted-foreground">vs fleet</span>
              <span>{(fleet.fleet_failure_rate * 100).toFixed(1)}%</span>
            </span>
          </div>
          {fleet.entity_avg_latency_ms != null && fleet.fleet_avg_latency_ms != null && (
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Avg latency</span>
              <span className="flex items-center gap-1.5">
                <span
                  className={
                    fleet.entity_avg_latency_ms <= fleet.fleet_avg_latency_ms
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-red-600 dark:text-red-400'
                  }
                >
                  {formatMs(fleet.entity_avg_latency_ms)}
                </span>
                <span className="text-muted-foreground">vs fleet</span>
                <span>{formatMs(fleet.fleet_avg_latency_ms)}</span>
              </span>
            </div>
          )}
          {fleet.latency_percentile_rank != null && (
            <p className="text-muted-foreground">
              Faster than{' '}
              <span className="font-medium text-foreground">
                {(fleet.latency_percentile_rank * 100).toFixed(0)}%
              </span>{' '}
              of entities
            </p>
          )}
        </div>
      )}
    </div>
  )
}

/** Velocity sparkline SVG. */
function VelocitySparkline({
  points,
  status,
}: {
  points: VelocityPoint[]
  status: HealthStatus
}) {
  const svgWidth = 300
  const svgHeight = 40

  const maxDuration = Math.max(...points.map((p) => p.duration_ms), 1)
  const coords = points.map((p, i) => {
    const x = (i / (points.length - 1)) * svgWidth
    const y = svgHeight - (p.duration_ms / maxDuration) * svgHeight
    return `${x},${y}`
  })

  const polylinePoints = coords.join(' ')
  const areaPoints = `0,${svgHeight} ${polylinePoints} ${svgWidth},${svgHeight}`

  return (
    <svg
      viewBox={`0 0 ${svgWidth} ${svgHeight}`}
      preserveAspectRatio="none"
      className="w-full h-10"
      role="img"
      aria-label="Transition velocity sparkline"
    >
      <polygon points={areaPoints} className={sparklineFillClass(status)} />
      <polyline
        points={polylinePoints}
        fill="none"
        className={sparklineStrokeClass(status)}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

/* ------------------------------------------------------------------ */
/*  Result type for settled promises                                  */
/* ------------------------------------------------------------------ */

function settled<T>(result: PromiseSettledResult<T>): T | null {
  return result.status === 'fulfilled' ? result.value : null
}

/* ------------------------------------------------------------------ */
/*  Main component                                                    */
/* ------------------------------------------------------------------ */

export function EntityMetricsContent({
  entityId,
  refreshToken = 0,
  onOpenDetail,
}: EntityMetricsContentProps) {
  const [loading, setLoading] = useState(true)
  const [entity, setEntity] = useState<EntityState | null>(null)
  const [metrics, setMetrics] = useState<EntityMetricsResponse | null>(null)
  const [triggers, setTriggers] = useState<AvailableTriggersResponse | null>(null)
  const [historyStats, setHistoryStats] = useState<HistoryStatsResponse | null>(null)
  const [recentHistory, setRecentHistory] = useState<TransitionHistoryEntry[] | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    const results = await Promise.allSettled([
      getEntityState(entityId),
      getEntityMetrics(entityId),
      getAvailableTriggers(entityId),
      getHistoryStats(entityId),
      getEntityHistory(entityId, 5, 0),
    ])
    setEntity(settled(results[0]))
    setMetrics(settled(results[1]))
    setTriggers(settled(results[2]))
    setHistoryStats(settled(results[3]))
    setRecentHistory(settled(results[4]))
    setLoading(false)
  }, [entityId])

  useEffect(() => {
    load()
  }, [load, refreshToken])

  /* ---- Loading / empty ---- */
  if (loading && !entity && !metrics) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    )
  }

  /* If nothing loaded at all, bail */
  if (!entity && !metrics) {
    return (
      <p className="text-sm text-muted-foreground py-4">
        Unable to load data for this entity.
      </p>
    )
  }

  /* Derived values */
  const currentState = entity?.current_state ?? metrics?.entity_id ?? entityId
  const machineName = entity?.machine_name ?? metrics?.machine_name ?? null
  const healthScore = metrics?.health_score ?? 0
  const healthStatus: HealthStatus = metrics?.health_status ?? 'healthy'
  const stalenessLabel = metrics?.staleness_label ?? ''
  const entityStatus = entity?.status ?? 'active'
  const workflowStatus = entity?.workflow_status ?? 'active'

  const showHealthAlerts =
    metrics &&
    (metrics.is_potentially_stuck ||
      metrics.recent_failure_rate > 0 ||
      metrics.error_patterns.length > 0)

  const totalTransitions = historyStats?.total_transitions ?? 0
  const successCount = historyStats?.success_count ?? 0
  const successRate = totalTransitions > 0 ? (successCount / totalTransitions) * 100 : 0
  const p50 = metrics?.latency_percentiles.p50
  const statesVisited = metrics ? Object.keys(metrics.state_revisits).length : 0

  return (
    <div className="space-y-3">
      {/* ── Section 1: Entity Header ─────────────────────────── */}
      <div className="flex items-start gap-3">
        {metrics && <HealthRing score={healthScore} status={healthStatus} />}
        <div className="min-w-0 flex-1">
          <p
            className="text-sm font-mono font-semibold truncate"
            title={entityId}
          >
            {entityId}
          </p>
          {machineName && (
            <p className="text-xs text-muted-foreground truncate">
              Machine: {machineName}
            </p>
          )}
          <div className="flex items-center gap-1.5 mt-1 flex-wrap">
            {entity && <StateBadge state={entity.current_state} />}
            {entity && <StatusBadge status={entityStatus} />}
            {entity && <WorkflowStatusBadge workflowStatus={workflowStatus} />}
          </div>
          {stalenessLabel && (
            <div className="flex items-center gap-1.5 mt-1.5">
              <span className={`h-1.5 w-1.5 rounded-full ${healthDotColor(healthStatus)}`} />
              <span className="text-[10px] text-muted-foreground">{stalenessLabel}</span>
            </div>
          )}
        </div>
      </div>

      {/* ── Section 2: Health & Alerts ───────────────────────── */}
      {showHealthAlerts && metrics && (
        <div className="space-y-2">
          {metrics.is_potentially_stuck && (
            <StuckBanner
              stuckState={metrics.stuck_state}
              currentDwellMs={metrics.stuck_current_dwell_ms}
              avgDwellMs={metrics.stuck_avg_dwell_ms}
            />
          )}
          {metrics.recent_failure_rate > 0 && (
            <FailureRateBar rate={metrics.recent_failure_rate} />
          )}
          {metrics.error_patterns.length > 0 && (
            <ErrorPatterns patterns={metrics.error_patterns} />
          )}
        </div>
      )}

      {/* ── Section 3: Quick Stats (2x2) ────────────────────── */}
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-md border border-border/50 p-2 text-center">
          <p className="text-lg font-semibold">{totalTransitions}</p>
          <p className="text-[10px] text-muted-foreground uppercase">total</p>
        </div>
        <div className="rounded-md border border-border/50 p-2 text-center">
          <p className="text-lg font-semibold">{successRate.toFixed(1)}%</p>
          <p className="text-[10px] text-muted-foreground uppercase">success</p>
        </div>
        <div className="rounded-md border border-border/50 p-2 text-center">
          <p className="text-lg font-semibold">{p50 != null ? formatMs(p50) : '--'}</p>
          <p className="text-[10px] text-muted-foreground uppercase">p50</p>
        </div>
        <div className="rounded-md border border-border/50 p-2 text-center">
          <p className="text-lg font-semibold">{statesVisited}</p>
          <p className="text-[10px] text-muted-foreground uppercase">states</p>
        </div>
      </div>

      {/* ── Section 4: Available Triggers ────────────────────── */}
      {triggers && (
        <CollapsibleSection
          title="Available Triggers"
          defaultOpen
          icon={<Zap className="h-3 w-3" />}
        >
          {triggers.triggers.length > 0 ? (
            <div>
              {triggers.triggers.map((t, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-1.5 py-1 text-xs font-mono ${
                    i < triggers.triggers.length - 1 ? 'border-b border-border/30' : ''
                  }`}
                >
                  <span className="truncate">{t.trigger}</span>
                  <span className="text-muted-foreground">&rarr;</span>
                  <span className="text-muted-foreground truncate">{t.target_state}</span>
                  {t.has_guard && (
                    <Shield className="h-3 w-3 text-amber-500 ml-auto shrink-0" />
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">No triggers from current state</p>
          )}
        </CollapsibleSection>
      )}

      {/* ── Section 5: Performance ───────────────────────────── */}
      {metrics && (
        <CollapsibleSection
          title="Performance"
          defaultOpen={false}
          icon={<BarChart3 className="h-3 w-3" />}
        >
          <div className="space-y-3">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase mb-1.5">
                Latency percentiles
              </p>
              <LatencyBars percentiles={metrics.latency_percentiles} />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase mb-1.5">
                Dwell by state
              </p>
              <DwellTable items={metrics.dwell_by_state} />
            </div>
          </div>
        </CollapsibleSection>
      )}

      {/* ── Section 6: Behavioral ────────────────────────────── */}
      {metrics &&
        (Object.keys(metrics.state_revisits).length > 0 || metrics.fleet_comparison) && (
          <CollapsibleSection
            title="Behavioral"
            defaultOpen={false}
            icon={<TrendingUp className="h-3 w-3" />}
          >
            <BehavioralSection
              stateRevisits={metrics.state_revisits}
              hasCycles={metrics.has_cycles}
              fleet={metrics.fleet_comparison}
            />
          </CollapsibleSection>
        )}

      {/* ── Section 7: Velocity Sparkline ────────────────────── */}
      {metrics && metrics.velocity_points.length >= 2 && (
        <div className="border-t border-border/50 pt-3 pb-1">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Activity className="h-3 w-3" />
            Velocity
          </p>
          <VelocitySparkline points={metrics.velocity_points} status={healthStatus} />
        </div>
      )}

      {/* ── Section 8: Recent History ────────────────────────── */}
      {recentHistory && (
        <CollapsibleSection
          title="Recent History"
          defaultOpen
          icon={<Clock className="h-3 w-3" />}
        >
          {recentHistory.length > 0 ? (
            <div>
              {recentHistory.map((h) => (
                <div
                  key={h.id}
                  className="flex items-center gap-1.5 py-1 border-b border-border/30 last:border-0"
                >
                  {h.success ? (
                    <CheckCircle2 className="h-3 w-3 text-emerald-500 shrink-0" />
                  ) : (
                    <XCircle className="h-3 w-3 text-red-500 shrink-0" />
                  )}
                  <span className="font-mono text-xs truncate">{h.trigger}</span>
                  <span className="text-xs text-muted-foreground truncate">
                    {h.source_state} &rarr; {h.target_state ?? '\u2014'}
                  </span>
                  <span className="text-[10px] text-muted-foreground ml-auto shrink-0">
                    {formatRelativeTime(h.created_at)}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">No transitions yet</p>
          )}
        </CollapsibleSection>
      )}

      {/* ── Footer ───────────────────────────────────────────── */}
      <div className="border-t border-border/50 pt-3">
        {onOpenDetail ? (
          <button
            type="button"
            onClick={() => onOpenDetail(entityId)}
            className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
          >
            Open Full Detail
            <ExternalLink className="h-3 w-3" />
          </button>
        ) : (
          <Link
            href={entityDetailUrl(entityId)}
            className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
          >
            Open Full Detail
            <ExternalLink className="h-3 w-3" />
          </Link>
        )}
      </div>
    </div>
  )
}
