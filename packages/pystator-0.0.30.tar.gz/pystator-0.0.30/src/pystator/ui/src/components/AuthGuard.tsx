'use client'

import { useEffect } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import LoadingSpinner from '@/components/LoadingSpinner'
import { useAuthStore, selectUser, selectLoading, selectAuthDisabled, selectApiUnavailable } from '@/stores/auth'
import { ROUTES } from '@/lib/constants'

/** Paths that do not require authentication (login + settings so users can set API URL first). */
function isPublicPath(pathname: string | null): boolean {
  if (!pathname) return false
  const normalized = pathname.replace(/\/+$/, '') || '/'
  const loginNorm = ROUTES.LOGIN.replace(/\/+$/, '') || '/'
  const settingsNorm = ROUTES.SETTINGS.replace(/\/+$/, '') || '/'
  return normalized === loginNorm || normalized === settingsNorm
}

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  const user = useAuthStore(selectUser)
  const loading = useAuthStore(selectLoading)
  const authDisabled = useAuthStore(selectAuthDisabled)
  const apiUnavailable = useAuthStore(selectApiUnavailable)
  const pathname = usePathname()
  const router = useRouter()

  useEffect(() => {
    if (loading) return
    if (isPublicPath(pathname)) return
    if (apiUnavailable || authDisabled || user) return
    sessionStorage.setItem('pystator_return_url', pathname || ROUTES.HOME)
    router.replace(ROUTES.LOGIN)
  }, [loading, pathname, user, authDisabled, apiUnavailable, router])

  if (isPublicPath(pathname)) {
    return <>{children}</>
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <LoadingSpinner />
      </div>
    )
  }

  if (apiUnavailable || authDisabled || user) {
    return <>{children}</>
  }

  return null
}
