'use client'

import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ROUTES } from '@/lib/constants'

interface DiscoveryBackendConfig {
  backend: string
  shadow_enabled: boolean
  min_edge_count: number
  min_confidence: number
  drift_alert_threshold: number
  drift_severe_threshold: number
  drift_min_sample: number
  low_sample_threshold: number
}

interface DiscoveryBackendSummaryCardProps {
  config: DiscoveryBackendConfig | null
}

export function DiscoveryBackendSummaryCard({ config }: DiscoveryBackendSummaryCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Discovery backend</CardTitle>
        <CardDescription>
          Server-side settings (configure persistence in <Link href={ROUTES.SETTINGS} className="underline">Settings</Link>).
        </CardDescription>
      </CardHeader>
      <CardContent>
        {config ? (
          <p className="text-sm text-muted-foreground">
            Backend: <span className="font-medium text-foreground">{config.backend}</span>
            {' · '}
            Shadow: {config.shadow_enabled ? 'on' : 'off'}
            {' · '}
            Min edges: {config.min_edge_count} · Min confidence: {config.min_confidence}
            {' · '}
            Drift alert: {(config.drift_alert_threshold * 100).toFixed(0)}% · Severe:{' '}
            {(config.drift_severe_threshold * 100).toFixed(0)}%
          </p>
        ) : (
          <p className="text-sm text-muted-foreground">Loading discovery settings…</p>
        )}
      </CardContent>
    </Card>
  )
}
