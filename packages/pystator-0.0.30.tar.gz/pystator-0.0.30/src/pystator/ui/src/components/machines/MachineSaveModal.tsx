'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { normalizeName, validateName } from '@/lib/utils'
import { Save, Loader2, AlertCircle } from 'lucide-react'

interface MachineSaveModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (name: string, version: string) => Promise<void>
  defaultName?: string
  defaultVersion?: string
}

export default function MachineSaveModal({
  isOpen,
  onClose,
  onSave,
  defaultName = '',
  defaultVersion = '1.0.0',
}: MachineSaveModalProps) {
  const [rawName, setRawName] = useState(defaultName)
  const [version, setVersion] = useState(defaultVersion)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Reset form when modal opens with new defaults
  useEffect(() => {
    if (isOpen) {
      setRawName(defaultName)
      setVersion(defaultVersion)
      setError(null)
      setSaving(false)
    }
  }, [isOpen, defaultName, defaultVersion])

  const normalized = useMemo(() => normalizeName(rawName), [rawName])

  const nameValidation = useMemo(() => {
    if (!rawName.trim()) return { valid: false, error: '' }
    if (!normalized) return { valid: false, error: 'Name produces no valid characters' }
    try {
      validateName(normalized)
      return { valid: true, error: '' }
    } catch (e) {
      return { valid: false, error: e instanceof Error ? e.message : 'Invalid name' }
    }
  }, [rawName, normalized])

  const versionValid = version.trim().length > 0

  const canSave = nameValidation.valid && versionValid && !saving

  const handleSave = useCallback(async () => {
    if (!canSave) return
    setSaving(true)
    setError(null)
    try {
      await onSave(normalized, version.trim())
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Save failed'
      setError(msg)
      setSaving(false)
    }
  }, [canSave, normalized, version, onSave])

  const showNormalizationHint = rawName.trim() !== '' && normalized !== '' && normalized !== rawName.trim().toLowerCase()

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Save Machine</DialogTitle>
          <DialogDescription>
            Choose a name and version for your FSM machine.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Machine name */}
          <div className="space-y-2">
            <Label htmlFor="machine-name">
              Machine name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="machine-name"
              value={rawName}
              onChange={(e) => {
                setRawName(e.target.value)
                setError(null)
              }}
              placeholder="e.g. order_lifecycle"
              disabled={saving}
              autoFocus
            />
            {showNormalizationHint && (
              <p className="text-xs text-muted-foreground">
                Will be saved as: <span className="font-mono font-medium text-foreground">{normalized}</span>
              </p>
            )}
            {nameValidation.error && (
              <p className="text-xs text-destructive">{nameValidation.error}</p>
            )}
            <p className="text-xs text-muted-foreground">
              Only lowercase letters, numbers, and underscores allowed.
            </p>
          </div>

          {/* Version */}
          <div className="space-y-2">
            <Label htmlFor="machine-version">
              Version <span className="text-destructive">*</span>
            </Label>
            <Input
              id="machine-version"
              value={version}
              onChange={(e) => {
                setVersion(e.target.value)
                setError(null)
              }}
              placeholder="e.g. 1.0.0"
              disabled={saving}
            />
          </div>

          {/* Error display */}
          {error && (
            <div className="flex items-start gap-2 p-3 bg-destructive/10 border border-destructive/50 rounded-md">
              <AlertCircle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
              <p className="text-sm text-destructive">{error}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!canSave}>
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Save
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
