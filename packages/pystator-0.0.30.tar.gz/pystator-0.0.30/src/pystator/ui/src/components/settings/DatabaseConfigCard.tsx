'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useDatabaseConfig } from '@/hooks'
import type { DatabaseTestRequest } from '@/lib/api'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface DatabaseConfigCardProps {
  connectionString: string
  host: string
  port: string
  database: string
  username: string
  password: string
  onConnectionStringChange: (v: string) => void
  onHostChange: (v: string) => void
  onPortChange: (v: string) => void
  onDatabaseChange: (v: string) => void
  onUsernameChange: (v: string) => void
  onPasswordChange: (v: string) => void
}

export function DatabaseConfigCard({
  connectionString,
  host,
  port,
  database,
  username,
  password,
  onConnectionStringChange,
  onHostChange,
  onPortChange,
  onDatabaseChange,
  onUsernameChange,
  onPasswordChange,
}: DatabaseConfigCardProps) {
  const { config: dbConfig, testing, testResult, test } = useDatabaseConfig()

  const handleTest = () => {
    const body: DatabaseTestRequest = {
      connection_string: connectionString || undefined,
      host: host || undefined,
      port: port ? parseInt(port, 10) : undefined,
      database: database || undefined,
      username: username || undefined,
      password: password || undefined,
    }
    test(body)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Database Configuration</CardTitle>
        <CardDescription>
          Configure database connection for persisting FSM machines (SQLite, PostgreSQL, etc.)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {dbConfig && (
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            {dbConfig.message}
            {dbConfig.machine_count >= 0 && (
              <span className="ml-2">Machines stored: {dbConfig.machine_count}</span>
            )}
          </div>
        )}
        <div className="space-y-2">
          <Label htmlFor="db-connection-string">Connection string (optional)</Label>
          <Input
            id="db-connection-string"
            type="text"
            value={connectionString}
            onChange={(e) => onConnectionStringChange(e.target.value)}
            placeholder="postgresql://user:password@host:5432/pystator or sqlite:///pystator.db"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="db-host">Host</Label>
            <Input
              id="db-host"
              type="text"
              value={host}
              onChange={(e) => onHostChange(e.target.value)}
              placeholder="localhost"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="db-port">Port</Label>
            <Input
              id="db-port"
              type="number"
              value={port}
              onChange={(e) => onPortChange(e.target.value)}
              placeholder="5432"
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="db-name">Database</Label>
          <Input
            id="db-name"
            type="text"
            value={database}
            onChange={(e) => onDatabaseChange(e.target.value)}
            placeholder="pystator"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="db-username">Username</Label>
            <Input
              id="db-username"
              type="text"
              value={username}
              onChange={(e) => onUsernameChange(e.target.value)}
              placeholder="user"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="db-password">Password</Label>
            <Input
              id="db-password"
              type="password"
              value={password}
              onChange={(e) => onPasswordChange(e.target.value)}
              placeholder="••••••••"
            />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button type="button" variant="outline" onClick={handleTest} disabled={testing}>
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test connection'
            )}
          </Button>
          {testResult && (
            <span className="inline-flex items-center gap-1 text-sm">
              {testResult.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {testResult.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
