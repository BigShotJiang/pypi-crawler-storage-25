'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { useDiscoveryConfig } from '@/hooks'
import type { DiscoveryDatabaseTestRequest } from '@/lib/api'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface DiscoveryConfigCardProps {
  backend: 'memory' | 'sqlite' | 'postgresql' | 'mongodb' | 'redis'
  connectionString: string
  shadowEnabled: boolean
  minEdgeCount: string
  minConfidence: string
  driftAlertThreshold: string
  driftSevereThreshold: string
  driftMinSample: string
  lowSampleThreshold: string
  onBackendChange: (v: DiscoveryConfigCardProps['backend']) => void
  onConnectionStringChange: (v: string) => void
  onShadowEnabledChange: (v: boolean) => void
  onMinEdgeCountChange: (v: string) => void
  onMinConfidenceChange: (v: string) => void
  onDriftAlertThresholdChange: (v: string) => void
  onDriftSevereThresholdChange: (v: string) => void
  onDriftMinSampleChange: (v: string) => void
  onLowSampleThresholdChange: (v: string) => void
}

export function DiscoveryConfigCard({
  backend,
  connectionString,
  shadowEnabled,
  minEdgeCount,
  minConfidence,
  driftAlertThreshold,
  driftSevereThreshold,
  driftMinSample,
  lowSampleThreshold,
  onBackendChange,
  onConnectionStringChange,
  onShadowEnabledChange,
  onMinEdgeCountChange,
  onMinConfidenceChange,
  onDriftAlertThresholdChange,
  onDriftSevereThresholdChange,
  onDriftMinSampleChange,
  onLowSampleThresholdChange,
}: DiscoveryConfigCardProps) {
  const { config, testing, testResult, test } = useDiscoveryConfig()

  const handleTest = () => {
    const body: DiscoveryDatabaseTestRequest = {
      backend,
      connection_string: connectionString || undefined,
    }
    test(body)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Discovery Configuration</CardTitle>
        <CardDescription>
          Configure inferred-state-machine discovery backend and shadow comparison behavior.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {config && (
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            Backend: {config.backend} • Shadow mode: {config.shadow_enabled ? 'on' : 'off'} •
            {' '}Min edge count: {config.min_edge_count} • Min confidence: {config.min_confidence} •
            {' '}Drift alert: {(config.drift_alert_threshold * 100).toFixed(0)}% •
            {' '}Drift severe: {(config.drift_severe_threshold * 100).toFixed(0)}% •
            {' '}Drift min sample: {config.drift_min_sample} •
            {' '}Low-sample threshold: {config.low_sample_threshold}
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="discovery-backend">Backend</Label>
          <select
            id="discovery-backend"
            className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
            value={backend}
            onChange={(e) => onBackendChange(e.target.value as DiscoveryConfigCardProps['backend'])}
          >
            <option value="memory">memory</option>
            <option value="sqlite">sqlite</option>
            <option value="postgresql">postgresql</option>
            <option value="mongodb">mongodb</option>
            <option value="redis">redis</option>
          </select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="discovery-connection-string">Connection string (optional for memory)</Label>
          <Input
            id="discovery-connection-string"
            type="text"
            value={connectionString}
            onChange={(e) => onConnectionStringChange(e.target.value)}
            placeholder="sqlite:///pystator_discovery.db"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="discovery-min-edge-count">Min edge count</Label>
            <Input
              id="discovery-min-edge-count"
              type="number"
              min={1}
              value={minEdgeCount}
              onChange={(e) => onMinEdgeCountChange(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="discovery-min-confidence">Min confidence (0-1)</Label>
            <Input
              id="discovery-min-confidence"
              type="number"
              min={0}
              max={1}
              step={0.01}
              value={minConfidence}
              onChange={(e) => onMinConfidenceChange(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="discovery-drift-alert-threshold">Drift alert (0-1)</Label>
            <Input
              id="discovery-drift-alert-threshold"
              type="number"
              min={0}
              max={1}
              step={0.01}
              value={driftAlertThreshold}
              onChange={(e) => onDriftAlertThresholdChange(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="discovery-drift-severe-threshold">Drift severe (0-1)</Label>
            <Input
              id="discovery-drift-severe-threshold"
              type="number"
              min={0}
              max={1}
              step={0.01}
              value={driftSevereThreshold}
              onChange={(e) => onDriftSevereThresholdChange(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="discovery-drift-min-sample">Drift min sample</Label>
            <Input
              id="discovery-drift-min-sample"
              type="number"
              min={1}
              value={driftMinSample}
              onChange={(e) => onDriftMinSampleChange(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="discovery-low-sample-threshold">Low-sample threshold</Label>
            <Input
              id="discovery-low-sample-threshold"
              type="number"
              min={1}
              value={lowSampleThreshold}
              onChange={(e) => onLowSampleThresholdChange(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-md border px-3 py-2">
          <div>
            <p className="text-sm font-medium">Shadow mode</p>
            <p className="text-xs text-muted-foreground">
              Compare inferred candidates without affecting active runtime decisions.
            </p>
          </div>
          <Switch checked={shadowEnabled} onCheckedChange={onShadowEnabledChange} />
        </div>

        <div className="flex items-center gap-2">
          <Button type="button" variant="outline" onClick={handleTest} disabled={testing}>
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test discovery backend'
            )}
          </Button>
          {testResult && (
            <span className="inline-flex items-center gap-1 text-sm">
              {testResult.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {testResult.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
