'use client'

import { useMemo } from 'react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useEntityListStore } from '@/stores/entity-list'
import { Plus, RefreshCw, Timer } from 'lucide-react'

const AUTO_REFRESH_OPTIONS: { label: string; value: number }[] = [
  { label: 'Off', value: 0 },
  { label: '5s', value: 5000 },
  { label: '10s', value: 10000 },
  { label: '30s', value: 30000 },
  { label: '60s', value: 60000 },
]

export interface EntitiesListToolbarProps {
  onCreateClick: () => void
  /** After manual refresh completes (list refetch). */
  onAfterManualRefresh?: () => void
}

/**
 * Create / refresh / auto-refresh controls shared by the entities list and the legacy page header.
 */
export function EntitiesListToolbar({ onCreateClick, onAfterManualRefresh }: EntitiesListToolbarProps) {
  const loading = useEntityListStore((s) => s.loading)
  const autoRefreshInterval = useEntityListStore((s) => s.autoRefreshInterval)
  const fetchEntities = useEntityListStore((s) => s.fetchEntities)
  const setAutoRefreshInterval = useEntityListStore((s) => s.setAutoRefreshInterval)

  const autoRefreshLabel = useMemo(() => {
    const opt = AUTO_REFRESH_OPTIONS.find((o) => o.value === autoRefreshInterval)
    return opt?.label ?? 'Off'
  }, [autoRefreshInterval])

  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="default" size="sm" onClick={onCreateClick} className="gap-1.5">
        <Plus className="h-4 w-4" /> Create entity
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          void fetchEntities().then(() => onAfterManualRefresh?.())
        }}
        disabled={loading}
        className="gap-1.5"
      >
        <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        Refresh
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-1.5">
            {autoRefreshInterval > 0 && (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
            )}
            <Timer className="h-4 w-4" />
            {autoRefreshLabel}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>Auto-refresh</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {AUTO_REFRESH_OPTIONS.map((opt) => (
            <DropdownMenuItem
              key={opt.value}
              onClick={() => setAutoRefreshInterval(opt.value as 0 | 5000 | 10000 | 30000 | 60000)}
            >
              {opt.label}
              {autoRefreshInterval === opt.value && (
                <span className="ml-auto text-xs text-primary">&#10003;</span>
              )}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
