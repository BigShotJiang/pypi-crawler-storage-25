'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  getTransitionAnalytics,
  getApiErrorMessage,
  type TransitionAnalyticsResponse,
  type DurationPercentiles,
} from '@/lib/api'
import { BarChart } from './BarChart'
import { Activity, Clock, AlertTriangle, TrendingUp } from 'lucide-react'

interface TransitionAnalyticsPanelProps {
  windowHours: number
  machineName?: string
}

function failureColor(rate: number): string {
  if (rate > 0.2) return 'hsl(0, 72%, 51%)'
  if (rate > 0.05) return 'hsl(38, 92%, 50%)'
  return 'hsl(142, 71%, 45%)'
}

function formatMs(ms: number | null): string {
  if (ms == null) return '--'
  if (ms < 1000) return `${Math.round(ms)} ms`
  return `${(ms / 1000).toFixed(2)} s`
}

function formatBucketLabel(iso: string): string {
  const d = new Date(iso)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

function pct(rate: number): string {
  return `${(rate * 100).toFixed(1)}%`
}

export function TransitionAnalyticsPanel({ windowHours, machineName }: TransitionAnalyticsPanelProps) {
  const [data, setData] = useState<TransitionAnalyticsResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getTransitionAnalytics({
        window_hours: windowHours,
        machine_name: machineName || undefined,
      })
      setData(res)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load transition analytics'))
    } finally {
      setLoading(false)
    }
  }, [windowHours, machineName])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  if (loading && !data) {
    return (
      <div className="space-y-4">
        <Card>
          <CardContent>
            <p className="text-sm text-muted-foreground py-8 text-center">Loading transition analytics...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <Card>
        <CardContent>
          <p className="text-sm text-destructive py-4 text-center">{error}</p>
        </CardContent>
      </Card>
    )
  }

  if (!data) return null

  const { time_buckets, duration_percentiles, top_failing_triggers, top_failing_states, volume_trend } = data

  const failureBarData = time_buckets.map((b) => ({
    label: formatBucketLabel(b.bucket_start),
    value: b.failed,
    color: failureColor(b.failure_rate),
  }))

  const volumeBarData = volume_trend.map((v) => ({
    label: formatBucketLabel(v.bucket_start),
    value: v.count,
  }))

  return (
    <div className="space-y-4">
      {/* Failure rate trend + Volume trend */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1.5">
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              Failure Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            {failureBarData.length > 0 ? (
              <BarChart data={failureBarData} height={180} showLabels />
            ) : (
              <p className="text-xs text-muted-foreground text-center py-6">No failure data in window</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              Volume Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            {volumeBarData.length > 0 ? (
              <BarChart data={volumeBarData} height={180} showLabels />
            ) : (
              <p className="text-xs text-muted-foreground text-center py-6">No transition data in window</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Duration percentiles */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-1.5">
            <Clock className="h-4 w-4 text-muted-foreground" />
            Duration Percentiles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <DurationBars percentiles={duration_percentiles} />
        </CardContent>
      </Card>

      {/* Failing triggers + Failing states */}
      <div className="grid gap-4 lg:grid-cols-2">
        {top_failing_triggers.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-1.5">
                <Activity className="h-4 w-4 text-muted-foreground" />
                Top Failing Triggers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/30">
                      <th className="text-left px-3 py-1.5 text-xs font-medium text-muted-foreground">Trigger</th>
                      <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Total</th>
                      <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Failed</th>
                      <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {top_failing_triggers.map((item) => (
                      <tr key={item.trigger} className="border-b last:border-0 hover:bg-muted/20">
                        <td className="px-3 py-1.5 font-mono text-xs">{item.trigger}</td>
                        <td className="text-right px-3 py-1.5 text-xs">{item.total}</td>
                        <td className="text-right px-3 py-1.5 text-xs text-destructive font-medium">{item.failed}</td>
                        <td className="text-right px-3 py-1.5 text-xs">{pct(item.failure_rate)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {top_failing_states.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                Top Failing States
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/30">
                      <th className="text-left px-3 py-1.5 text-xs font-medium text-muted-foreground">State</th>
                      <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Total</th>
                      <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Failed</th>
                      <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Rate</th>
                    </tr>
                  </thead>
                  <tbody>
                    {top_failing_states.map((item) => (
                      <tr key={item.state} className="border-b last:border-0 hover:bg-muted/20">
                        <td className="px-3 py-1.5 font-mono text-xs">{item.state}</td>
                        <td className="text-right px-3 py-1.5 text-xs">{item.total}</td>
                        <td className="text-right px-3 py-1.5 text-xs text-destructive font-medium">{item.failed}</td>
                        <td className="text-right px-3 py-1.5 text-xs">{pct(item.failure_rate)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

/** Horizontal nested bars for p50 / p75 / p95 / p99 */
function DurationBars({ percentiles }: { percentiles: DurationPercentiles }) {
  const entries: { label: string; value: number | null }[] = [
    { label: 'p50', value: percentiles.p50 },
    { label: 'p75', value: percentiles.p75 },
    { label: 'p95', value: percentiles.p95 },
    { label: 'p99', value: percentiles.p99 },
  ]

  const maxVal = Math.max(
    ...entries.map((e) => e.value ?? 0),
    1
  )

  const barColors = [
    'bg-blue-500',
    'bg-amber-500',
    'bg-orange-500',
    'bg-rose-500',
  ]

  return (
    <div className="space-y-2">
      {entries.map((entry, idx) => {
        const widthPct = entry.value != null ? (entry.value / maxVal) * 100 : 0
        return (
          <div key={entry.label} className="flex items-center gap-3">
            <span className="text-xs font-mono text-muted-foreground w-8 text-right">{entry.label}</span>
            <div className="flex-1 h-4 rounded-full bg-muted overflow-hidden">
              <div
                className={`h-full rounded-full ${barColors[idx]} transition-all`}
                style={{ width: `${Math.max(widthPct, entry.value != null ? 2 : 0)}%` }}
              />
            </div>
            <span className="text-xs font-medium text-foreground w-16 text-right">
              {formatMs(entry.value)}
            </span>
          </div>
        )
      })}
    </div>
  )
}
