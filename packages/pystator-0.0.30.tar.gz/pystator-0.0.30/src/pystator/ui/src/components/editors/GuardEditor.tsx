'use client'

import { useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Plus, X } from 'lucide-react'

// Re-export FSMGuard from the shared types
export type { FSMGuard } from '@/lib/types/fsm'
import type { FSMGuard } from '@/lib/types/fsm'

type GuardKind = 'named' | 'expression' | 'check'

const CHECK_OPS = [
  'eq', 'neq', 'gt', 'gte', 'lt', 'lte',
  'in', 'not_in', 'is_set', 'is_null',
  'contains', 'starts_with', 'ends_with', 'matches',
] as const

interface GuardEditorProps {
  guards: FSMGuard[]
  onChange: (guards: FSMGuard[]) => void
  guardDefinitions?: { name: string; description?: string }[]
  stateVariables?: { key: string }[]
}

const BORDER_COLORS: Record<GuardKind, string> = {
  named: 'border-l-amber-400',
  expression: 'border-l-blue-400',
  check: 'border-l-green-400',
}

function classifyGuard(g: FSMGuard): GuardKind {
  if (typeof g === 'string') return 'named'
  if ('expr' in g) return 'expression'
  if ('check' in g) return 'check'
  return 'named'
}

function makeDefault(kind: GuardKind): FSMGuard {
  if (kind === 'expression') return { expr: '' }
  if (kind === 'check') return { check: { field: '', op: 'eq', value: '' } }
  return ''
}

export default function GuardEditor({
  guards,
  onChange,
  guardDefinitions,
  stateVariables,
}: GuardEditorProps) {
  const update = useCallback(
    (index: number, value: FSMGuard) => {
      const next = [...guards]
      next[index] = value
      onChange(next)
    },
    [guards, onChange],
  )

  const remove = useCallback(
    (index: number) => onChange(guards.filter((_, i) => i !== index)),
    [guards, onChange],
  )

  const add = useCallback(() => onChange([...guards, '']), [guards, onChange])

  const changeKind = useCallback(
    (index: number, kind: GuardKind) => update(index, makeDefault(kind)),
    [update],
  )

  return (
    <div className="space-y-2">
      {guards.map((guard, idx) => {
        const kind = classifyGuard(guard)
        return (
          <div
            key={idx}
            className={`flex items-start gap-2 rounded border border-l-4 ${BORDER_COLORS[kind]} bg-muted/20 p-2`}
          >
            <select
              value={kind}
              onChange={(e) => changeKind(idx, e.target.value as GuardKind)}
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
            >
              <option value="named">Named</option>
              <option value="expression">Expression</option>
              <option value="check">Check</option>
            </select>

            <div className="flex-1 min-w-0">
              {kind === 'named' && (
                <NamedInput
                  value={typeof guard === 'string' ? guard : ''}
                  onChange={(v) => update(idx, v)}
                  suggestions={guardDefinitions}
                />
              )}
              {kind === 'expression' && (
                <Input
                  placeholder="e.g. ctx.amount > 100"
                  value={'expr' in (guard as object) ? (guard as { expr: string }).expr : ''}
                  onChange={(e) => update(idx, { expr: e.target.value })}
                  className="h-9"
                />
              )}
              {kind === 'check' && (
                <CheckInput
                  value={
                    'check' in (guard as object)
                      ? (guard as { check: { field: string; op: string; value: unknown } }).check
                      : { field: '', op: 'eq', value: '' }
                  }
                  onChange={(c) => update(idx, { check: c })}
                  stateVariables={stateVariables}
                />
              )}
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 shrink-0"
              onClick={() => remove(idx)}
              aria-label="Remove guard"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )
      })}

      <Button variant="outline" size="sm" onClick={add} className="gap-1">
        <Plus className="h-3.5 w-3.5" />
        Add guard
      </Button>
    </div>
  )
}

/* ---------- sub-components ---------- */

function NamedInput({
  value,
  onChange,
  suggestions,
}: {
  value: string
  onChange: (v: string) => void
  suggestions?: { name: string; description?: string }[]
}) {
  const listId = 'guard-names'
  return (
    <>
      <Input
        placeholder="Guard name"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        list={listId}
        className="h-9"
      />
      {suggestions && suggestions.length > 0 && (
        <datalist id={listId}>
          {suggestions.map((s) => (
            <option key={s.name} value={s.name}>
              {s.description}
            </option>
          ))}
        </datalist>
      )}
    </>
  )
}

function CheckInput({
  value,
  onChange,
  stateVariables,
}: {
  value: { field: string; op: string; value: unknown }
  onChange: (v: { field: string; op: string; value: unknown }) => void
  stateVariables?: { key: string }[]
}) {
  const fieldListId = 'guard-check-fields'
  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      <Input
        placeholder="Field"
        value={value.field}
        onChange={(e) => onChange({ ...value, field: e.target.value })}
        list={fieldListId}
        className="h-9 w-28"
      />
      {stateVariables && stateVariables.length > 0 && (
        <datalist id={fieldListId}>
          {stateVariables.map((v) => (
            <option key={v.key} value={v.key} />
          ))}
        </datalist>
      )}

      <select
        value={value.op}
        onChange={(e) => onChange({ ...value, op: e.target.value })}
        className="h-9 rounded-md border border-input bg-background px-2 text-sm"
      >
        {CHECK_OPS.map((op) => (
          <option key={op} value={op}>{op}</option>
        ))}
      </select>

      <Input
        placeholder="Value"
        value={String(value.value ?? '')}
        onChange={(e) => onChange({ ...value, value: e.target.value })}
        className="h-9 w-28"
      />
    </div>
  )
}
