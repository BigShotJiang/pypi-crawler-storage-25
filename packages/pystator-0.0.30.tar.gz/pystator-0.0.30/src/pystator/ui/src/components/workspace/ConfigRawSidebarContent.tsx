'use client'

import { useState, useEffect, useRef } from 'react'
import { useWorkspaceStore, selectConfig, selectSetConfig, selectSyncSessionFromConfig } from '@/stores/workspace'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { parseFsmConfig, stringifyFsmConfig, type ConfigFormat } from '@/lib/fsmConfigParse'

export interface ConfigRawSidebarContentProps {
  /** When true, the panel is visible and should seed the textarea from workspace config. */
  isActive?: boolean
}

export default function ConfigRawSidebarContent({ isActive = true }: ConfigRawSidebarContentProps) {
  const config = useWorkspaceStore(selectConfig)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const syncSessionFromConfig = useWorkspaceStore(selectSyncSessionFromConfig)
  const [raw, setRaw] = useState('')
  const [format, setFormat] = useState<ConfigFormat>('yaml')
  const [parseError, setParseError] = useState<string | null>(null)
  const prevActiveRef = useRef(false)

  useEffect(() => {
    if (!isActive) {
      prevActiveRef.current = false
      return
    }
    if (!prevActiveRef.current) {
      setRaw(stringifyFsmConfig(config, format))
      setParseError(null)
    }
    prevActiveRef.current = true
  }, [isActive])

  const handleApply = () => {
    setParseError(null)
    const result = parseFsmConfig(raw, format)
    if ('error' in result) {
      setParseError(result.error)
      return
    }
    setConfig(JSON.parse(JSON.stringify(result.config)))
    syncSessionFromConfig()
  }

  const handleFormatChange = (newFormat: ConfigFormat) => {
    if (newFormat === format) return
    setFormat(newFormat)
    setRaw(stringifyFsmConfig(config, newFormat))
    setParseError(null)
  }

  return (
    <div className="flex flex-col gap-2 h-full min-h-0">
      <div className="flex items-center justify-between gap-2 shrink-0">
        <Label className="text-xs text-muted-foreground">Format</Label>
        <select
          className="rounded-md border border-input bg-background px-2 py-1.5 text-xs"
          value={format}
          onChange={(e) => handleFormatChange(e.target.value as ConfigFormat)}
          aria-label="Config format"
        >
          <option value="json">JSON</option>
          <option value="yaml">YAML</option>
        </select>
      </div>
      <textarea
        className="flex-1 min-h-[200px] w-full font-mono text-xs rounded-md border border-input bg-background px-2 py-2 focus:outline-none focus:ring-2 focus:ring-ring resize-none"
        value={raw}
        onChange={(e) => {
          setRaw(e.target.value)
          setParseError(null)
        }}
        spellCheck={false}
        placeholder={format === 'json' ? '{}' : 'meta:\n  machine_name: ...'}
      />
      <Button size="sm" onClick={handleApply} className="shrink-0 text-xs">
        Apply
      </Button>
      {parseError && (
        <div className="rounded border border-destructive/50 bg-destructive/10 px-2 py-1.5 text-destructive text-xs shrink-0">
          {parseError}
        </div>
      )}
    </div>
  )
}
