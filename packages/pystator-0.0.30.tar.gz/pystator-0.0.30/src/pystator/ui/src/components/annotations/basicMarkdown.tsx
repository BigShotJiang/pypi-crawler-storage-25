'use client'

import React from 'react'

/**
 * Very small, safe markdown renderer for an MVP note system.
 * Supports:
 * - Headings: #, ##
 * - Bullets: - item
 * Everything else is rendered as text with line breaks.
 *
 * No HTML parsing, no links, no images.
 */
export function renderBasicMarkdown(text: string): React.ReactNode {
  const lines = (text ?? '').split(/\r?\n/)
  const blocks: React.ReactNode[] = []
  let bulletBuffer: string[] = []

  const flushBullets = () => {
    if (bulletBuffer.length === 0) return
    const items = bulletBuffer
    bulletBuffer = []
    blocks.push(
      <ul key={`ul-${blocks.length}`} className="list-disc pl-5 space-y-1">
        {items.map((t, i) => (
          <li key={i} className="whitespace-pre-wrap break-words">
            {t}
          </li>
        ))}
      </ul>
    )
  }

  for (const raw of lines) {
    const line = raw ?? ''
    const h2 = line.match(/^##\s+(.*)$/)
    const h1 = line.match(/^#\s+(.*)$/)
    const bullet = line.match(/^-+\s+(.*)$/)

    if (h1) {
      flushBullets()
      blocks.push(
        <h3 key={`h1-${blocks.length}`} className="text-sm font-semibold">
          {h1[1]}
        </h3>
      )
      continue
    }
    if (h2) {
      flushBullets()
      blocks.push(
        <h4 key={`h2-${blocks.length}`} className="text-sm font-medium">
          {h2[1]}
        </h4>
      )
      continue
    }
    if (bullet) {
      bulletBuffer.push(bullet[1])
      continue
    }

    flushBullets()
    if (line.trim().length === 0) {
      blocks.push(<div key={`sp-${blocks.length}`} className="h-2" />)
    } else {
      blocks.push(
        <p key={`p-${blocks.length}`} className="whitespace-pre-wrap break-words">
          {line}
        </p>
      )
    }
  }
  flushBullets()

  return <div className="space-y-2">{blocks}</div>
}
