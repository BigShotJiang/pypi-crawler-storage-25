'use client'

import Link from 'next/link'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { CheckCircle2 } from 'lucide-react'
import { ROUTES } from '@/lib/constants'
import type { MachineResponse } from '@/lib/api'

interface DiscoveryStatusBannerProps {
  error: string | null
  promoted: MachineResponse | null
}

export function DiscoveryStatusBanner({ error, promoted }: DiscoveryStatusBannerProps) {
  return (
    <>
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {promoted && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Saved machine <span className="font-medium">{promoted.name}</span> v{promoted.version}{' '}
            <Link href={ROUTES.MACHINES} className="font-medium underline">
              Open Machines
            </Link>
          </AlertDescription>
        </Alert>
      )}
    </>
  )
}
