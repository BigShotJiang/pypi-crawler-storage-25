"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getEntityEvents, replayEntity, type ReplayStep } from "@/lib/api"
import LoadingSpinner from "@/components/LoadingSpinner"
import {
  Play,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
} from "lucide-react"

interface ReplayPanelProps {
  entityId: string
}

export default function ReplayPanel({ entityId }: ReplayPanelProps) {
  const [steps, setSteps] = useState<ReplayStep[]>([])
  const [currentStep, setCurrentStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [finalState, setFinalState] = useState<string | null>(null)

  const loadAndReplay = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // Fetch events to confirm they exist, then replay
      await getEntityEvents(entityId, 1, 0)
      const result = await replayEntity(entityId)
      setSteps(result.steps)
      setFinalState(result.final_state)
      setCurrentStep(result.steps.length > 0 ? 1 : 0)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load replay")
      setSteps([])
      setFinalState(null)
    } finally {
      setLoading(false)
    }
  }, [entityId])

  const stepBack = useCallback(() => {
    setCurrentStep((prev) => Math.max(1, prev - 1))
  }, [])

  const stepForward = useCallback(() => {
    setCurrentStep((prev) => Math.min(steps.length, prev + 1))
  }, [steps.length])

  const totalSteps = steps.length

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-base font-semibold">Event Replay</CardTitle>
        <Button
          size="sm"
          variant="outline"
          onClick={loadAndReplay}
          disabled={loading}
        >
          {loading ? (
            <LoadingSpinner />
          ) : (
            <>
              <Play className="mr-1.5 h-3.5 w-3.5" />
              Load Events
            </>
          )}
        </Button>
      </CardHeader>

      <CardContent>
        {error && (
          <div className="rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2 text-sm text-destructive mb-4">
            {error}
          </div>
        )}

        {totalSteps === 0 && !loading && !error && (
          <p className="text-sm text-muted-foreground">
            Click &quot;Load Events&quot; to fetch and replay the entity
            transition history.
          </p>
        )}

        {totalSteps > 0 && (
          <>
            {/* Slider + step controls */}
            <div className="mb-4 space-y-3">
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>
                  Step{" "}
                  <span className="font-medium text-foreground">
                    {currentStep}
                  </span>{" "}
                  of {totalSteps}
                </span>
                {finalState && (
                  <span>
                    Final state:{" "}
                    <span className="font-medium text-foreground">
                      {finalState}
                    </span>
                  </span>
                )}
              </div>

              <input
                type="range"
                min={1}
                max={totalSteps}
                value={currentStep}
                onChange={(e) => setCurrentStep(Number(e.target.value))}
                className="w-full accent-primary"
              />

              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={stepBack}
                  disabled={currentStep <= 1}
                >
                  <ChevronLeft className="mr-1 h-3.5 w-3.5" />
                  Step Back
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={stepForward}
                  disabled={currentStep >= totalSteps}
                >
                  Step Forward
                  <ChevronRight className="ml-1 h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            {/* Steps table */}
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="px-3 py-2 text-left font-medium">Seq</th>
                    <th className="px-3 py-2 text-left font-medium">Trigger</th>
                    <th className="px-3 py-2 text-left font-medium">
                      Source State
                    </th>
                    <th className="px-3 py-2 text-left font-medium">
                      Target State
                    </th>
                    <th className="px-3 py-2 text-left font-medium">Result</th>
                  </tr>
                </thead>
                <tbody>
                  {steps.map((step) => {
                    const isSelected = step.sequence === currentStep
                    return (
                      <tr
                        key={step.sequence}
                        onClick={() => setCurrentStep(step.sequence)}
                        className={`cursor-pointer border-b transition-colors ${
                          isSelected
                            ? "bg-primary/10 dark:bg-primary/20"
                            : "hover:bg-muted/30"
                        }`}
                      >
                        <td className="px-3 py-2 font-mono tabular-nums">
                          {step.sequence}
                        </td>
                        <td className="px-3 py-2">
                          <code className="rounded bg-muted px-1.5 py-0.5 text-xs">
                            {step.trigger}
                          </code>
                        </td>
                        <td className="px-3 py-2">{step.source_state}</td>
                        <td className="px-3 py-2">
                          {step.target_state ?? (
                            <span className="text-muted-foreground">--</span>
                          )}
                        </td>
                        <td className="px-3 py-2">
                          {step.success ? (
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                          ) : (
                            <span className="flex items-center gap-1.5">
                              <XCircle className="h-4 w-4 text-destructive" />
                              {step.error && (
                                <span className="text-xs text-destructive truncate max-w-[120px]">
                                  {step.error}
                                </span>
                              )}
                            </span>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
