export interface ObservabilityFilters {
  machineName: string
  entityId: string
  windowHours: number
}

export type ObservabilityTab = 'overview' | 'transitions' | 'worker-events' | 'analytics'
