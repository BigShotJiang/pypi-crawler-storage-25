'use client'

import { type ReactNode } from 'react'
import { cn } from '@/lib/utils'

interface PageContainerProps {
  children: ReactNode
  className?: string
  /** Vertical padding: 'none' | 'sm' | 'md' | 'lg' (default: 'md') */
  padding?: 'none' | 'sm' | 'md' | 'lg'
}

const paddingClasses = {
  none: 'py-0',
  sm: 'py-4',
  md: 'py-6',
  lg: 'py-8',
} as const

export function PageContainer({
  children,
  className,
  padding = 'md',
}: PageContainerProps) {
  return (
    <div className={cn('min-h-screen bg-background', className)}>
      <div
        className={cn(
          'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8',
          paddingClasses[padding]
        )}
      >
        {children}
      </div>
    </div>
  )
}
