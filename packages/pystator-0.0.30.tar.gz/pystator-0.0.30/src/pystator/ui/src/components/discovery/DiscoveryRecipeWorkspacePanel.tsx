'use client'

import { Button } from '@/components/ui/button'
import {
  DiscoveryEntityScopeList,
  DiscoveryManualEdgeChecklist,
  DiscoveryWorkspaceModeTabs,
  DiscoveryWorkspaceScopeFields,
} from '@/components/discovery/DiscoveryWorkspaceScope'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { cn } from '@/lib/utils'
import { Loader2, RefreshCw } from 'lucide-react'

export interface DiscoveryRecipeWorkspacePanelProps {
  workspace: UseDiscoveryWorkspaceResult
  /** Wording for draft hint when no workspace selected. */
  layout: 'threeColumn' | 'standalone'
  className?: string
  /**
   * `full`: mode tabs + fetch + entity scope + thresholds (default).
   * `formOnly`: entity scope + thresholds + manual edges only — put mode/fetch in an external toolbar.
   */
  recipeToolbar?: 'full' | 'formOnly'
}

/**
 * Inference/manual mode, entity scope, thresholds, and manual edge checklist.
 * Used in the right panel; list actions (New/Preview/Build) stay in the middle column in fleet view.
 */
export function DiscoveryRecipeWorkspacePanel({
  workspace: d,
  layout,
  className,
  recipeToolbar = 'full',
}: DiscoveryRecipeWorkspacePanelProps) {
  const hasMachine = d.machineName.trim().length > 0
  const noRowSelected = !d.activeDraftId && !d.selectedVersion

  const draftHint =
    layout === 'threeColumn'
      ? 'Select a draft or built row in the middle panel to configure scope, preview, and build.'
      : 'Select a draft or built row in the list on the left to configure scope, preview, and build.'

  if (!hasMachine) {
    return (
      <div className={cn('rounded-md border border-dashed border-border/80 p-3', className)}>
        <p className="text-xs text-muted-foreground">
          Pin or enter a discovery machine to configure inference scope and build settings.
        </p>
      </div>
    )
  }

  if (noRowSelected) {
    return (
      <div className={cn('space-y-3', className)}>
        <div className="rounded-md border border-dashed border-border/80 p-3">
          <p className="text-xs text-muted-foreground">{draftHint}</p>
        </div>
        {recipeToolbar === 'full' ? <DiscoveryFetchObservationEntitiesButton d={d} /> : null}
      </div>
    )
  }

  if (recipeToolbar === 'formOnly') {
    return (
      <div className={cn('space-y-3', className)}>
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          <div className="min-w-0">
            <DiscoveryEntityScopeList d={d} />
          </div>
          <div className="min-w-0">
            {d.mode === 'inference' ? (
              <DiscoveryWorkspaceScopeFields d={d} />
            ) : (
              <DiscoveryManualEdgeChecklist d={d} />
            )}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={cn('space-y-3', className)}>
      <div className="flex flex-wrap items-center gap-x-2 gap-y-2 border-b border-border/50 pb-3">
        <DiscoveryWorkspaceModeTabs d={d} />
        <span className="select-none text-muted-foreground/50" aria-hidden>
          |
        </span>
        <DiscoveryFetchObservationEntitiesButton d={d} compact />
      </div>
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        <div className="min-w-0">
          <DiscoveryEntityScopeList d={d} />
        </div>
        <div className="min-w-0">
          {d.mode === 'inference' ? (
            <DiscoveryWorkspaceScopeFields d={d} />
          ) : (
            <DiscoveryManualEdgeChecklist d={d} />
          )}
        </div>
      </div>
    </div>
  )
}

export function DiscoveryFetchObservationEntitiesButton({
  d,
  compact = false,
}: {
  d: UseDiscoveryWorkspaceResult
  compact?: boolean
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        type="button"
        size="sm"
        variant="outline"
        title="Reload distinct entity IDs from the latest observations for this machine"
        disabled={d.loadingEntityIds}
        onClick={() => void d.refreshObservationEntities()}
      >
        {d.loadingEntityIds ? (
          <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
        ) : (
          <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
        )}
        Fetch observations
      </Button>
      {!compact ? (
        <span className="text-xs text-muted-foreground">
          Updates the entity scope list below from the server.
        </span>
      ) : null}
    </div>
  )
}
