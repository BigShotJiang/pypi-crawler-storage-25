'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import type { ObservabilitySummaryResponse, ObservabilityTransitionItem } from '@/lib/api'
import { Button } from '@/components/ui/button'

interface OverviewPanelProps {
  summary: ObservabilitySummaryResponse | null
  recentFailedTransitions: ObservabilityTransitionItem[]
  loadingRecentFailures: boolean
  onOpenTransitions: () => void
  onEntityClick: (entityId: string) => void
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleString()
}

export function OverviewPanel({
  summary,
  recentFailedTransitions,
  loadingRecentFailures,
  onOpenTransitions,
  onEntityClick,
}: OverviewPanelProps) {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Recent Failed Transitions</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingRecentFailures ? (
            <p className="text-sm text-muted-foreground py-8 text-center">Loading failure feed…</p>
          ) : recentFailedTransitions.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">No failed transitions in the current filter window.</p>
          ) : (
            <div className="space-y-2">
              {recentFailedTransitions.map((item) => (
                <div key={item.id} className="rounded-md border bg-background p-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground">
                        {item.machine_name ?? '—'} •{' '}
                        <button
                          type="button"
                          className="text-primary hover:underline font-mono"
                          onClick={() => onEntityClick(item.entity_id)}
                        >
                          {item.entity_id}
                        </button>
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {item.source_state} → {item.target_state ?? '—'} via {item.trigger}
                      </p>
                      {item.error_message && (
                        <p className="text-xs text-destructive mt-1 truncate" title={item.error_message}>
                          {item.error_message}
                        </p>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground whitespace-nowrap">{formatTime(item.created_at)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Health Signals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="text-xs text-muted-foreground">Window</p>
            <p className="text-sm text-foreground">
              {summary ? `${new Date(summary.window_start).toLocaleString()} - ${new Date(summary.window_end).toLocaleString()}` : '—'}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Worker failures</p>
            <p className="text-lg font-semibold text-foreground">{summary?.worker_failed ?? 0}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Dead letters</p>
            <p className="text-lg font-semibold text-foreground">{summary?.worker_dead_letter ?? 0}</p>
          </div>
          <Button variant="outline" size="sm" onClick={onOpenTransitions}>
            Open Transition Feed
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
