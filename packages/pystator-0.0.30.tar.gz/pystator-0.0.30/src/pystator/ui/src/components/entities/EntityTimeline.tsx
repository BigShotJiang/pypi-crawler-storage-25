'use client'

import { useCallback, useEffect, useState } from 'react'
import {
  getEntityTimeline,
  getApiErrorMessage,
  type EntityTimelineResponse,
  type TimelineStep,
} from '@/lib/api'

interface EntityTimelineProps {
  entityId: string
}

function formatDwell(ms: number | null): string {
  if (ms == null) return '--'
  if (ms < 1000) return `${Math.round(ms)} ms`
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)} s`
  if (ms < 3_600_000) return `${(ms / 60_000).toFixed(1)} min`
  return `${(ms / 3_600_000).toFixed(1)} h`
}

function formatTimestamp(iso: string): string {
  return new Date(iso).toLocaleString()
}

function StepDot({ success, isCurrent }: { success: boolean; isCurrent: boolean }) {
  const baseColor = success
    ? 'bg-emerald-500 dark:bg-emerald-400'
    : 'bg-red-500 dark:bg-red-400'

  return (
    <div className="relative flex items-center justify-center">
      {isCurrent && (
        <span className={`absolute h-5 w-5 rounded-full ${baseColor} opacity-30 animate-ping`} />
      )}
      <span className={`relative h-3 w-3 rounded-full ${baseColor} ${isCurrent ? 'ring-2 ring-offset-2 ring-primary' : ''}`} />
    </div>
  )
}

function TimelineStepRow({ step, isLast }: { step: TimelineStep; isLast: boolean }) {
  const isCurrent = step.exited_at === null

  return (
    <div className="flex gap-3">
      {/* Dot + vertical line */}
      <div className="flex flex-col items-center">
        <StepDot success={step.success} isCurrent={isCurrent} />
        {!isLast && <div className="flex-1 w-px border-l-2 border-border mt-1" />}
      </div>

      {/* Content */}
      <div className={`pb-5 min-w-0 ${isLast ? '' : ''}`}>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary">
            {step.state}
          </span>
          {isCurrent && (
            <span className="text-[10px] uppercase tracking-wider font-semibold text-emerald-600 dark:text-emerald-400">
              Current
            </span>
          )}
          {!step.success && (
            <span className="text-[10px] uppercase tracking-wider font-semibold text-destructive">
              Failed
            </span>
          )}
        </div>

        <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          {step.trigger_in && (
            <span>
              in: <code className="bg-muted px-1 rounded text-[11px]">{step.trigger_in}</code>
            </span>
          )}
          {step.trigger_out && (
            <span>
              out: <code className="bg-muted px-1 rounded text-[11px]">{step.trigger_out}</code>
            </span>
          )}
          <span>dwell: {formatDwell(step.dwell_ms)}</span>
        </div>

        <p className="text-[11px] text-muted-foreground mt-0.5">
          {formatTimestamp(step.entered_at)}
          {step.exited_at && ` \u2192 ${formatTimestamp(step.exited_at)}`}
        </p>
      </div>
    </div>
  )
}

export default function EntityTimeline({ entityId }: EntityTimelineProps) {
  const [data, setData] = useState<EntityTimelineResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchTimeline = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getEntityTimeline(entityId)
      setData(res)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load entity timeline'))
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    fetchTimeline()
  }, [fetchTimeline])

  if (loading && !data) {
    return (
      <p className="text-sm text-muted-foreground py-6 text-center">Loading timeline...</p>
    )
  }

  if (error) {
    return (
      <p className="text-sm text-destructive py-4 text-center">{error}</p>
    )
  }

  if (!data || data.steps.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-6 text-center">No timeline steps recorded.</p>
    )
  }

  return (
    <div>
      <p className="text-sm text-muted-foreground mb-4">
        Visited <span className="font-medium text-foreground">{data.states_visited}</span> state{data.states_visited !== 1 ? 's' : ''} in{' '}
        <span className="font-medium text-foreground">{formatDwell(data.total_dwell_ms)}</span>
      </p>

      <div className="ml-1">
        {data.steps.map((step, idx) => (
          <TimelineStepRow
            key={`${step.state}-${step.entered_at}`}
            step={step}
            isLast={idx === data.steps.length - 1}
          />
        ))}
      </div>
    </div>
  )
}
