'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import type { MachineListItem } from '@/lib/api'
import type { TriplePanelLayoutApi } from '@/components/layout/ResizableTriplePanelLayout'
import type { UseCatalogMachinesGroupedResult } from '@/hooks/useCatalogMachinesGrouped'
import type { UseDiscoveryPinnedCatalogMachinesResult } from '@/hooks/useDiscoveryPinnedCatalogMachines'
import { ChevronLeft, ChevronRight, Loader2, Plus, Trash2 } from 'lucide-react'

function machineInitialLetter(machineName: string): string {
  const t = machineName.trim()
  if (!t) return '?'
  return t.charAt(0).toUpperCase()
}

export interface DiscoveryCatalogPinsPanelProps {
  api: TriplePanelLayoutApi
  catalog: UseCatalogMachinesGroupedResult
  pinned: UseDiscoveryPinnedCatalogMachinesResult
  focusedPinId: string | null
  onFocusPin: (pin: MachineListItem) => void
  onFocusEmptyBaseline: () => void
  onClearFocus: () => void
}

const EMPTY_BASELINE_PIN_ID = '__empty_baseline__'

export function DiscoveryCatalogPinsPanel({
  api,
  catalog,
  pinned,
  focusedPinId,
  onFocusPin,
  onFocusEmptyBaseline,
  onClearFocus,
}: DiscoveryCatalogPinsPanelProps) {
  const isCollapsed = api.isPanelCollapsed
  const isCompact = api.panelDisplayMode === 'compact'
  const showLabels = !isCollapsed && !isCompact
  const [pickName, setPickName] = useState('')
  const [pickVersionId, setPickVersionId] = useState('')
  const [addPinDialogOpen, setAddPinDialogOpen] = useState(false)
  const [dialogPickName, setDialogPickName] = useState('')
  const [dialogPickVersionId, setDialogPickVersionId] = useState('')

  const versions = useMemo(
    () => (pickName ? catalog.versionsForName(pickName) : []),
    [pickName, catalog]
  )

  const dialogVersions = useMemo(
    () => (dialogPickName ? catalog.versionsForName(dialogPickName) : []),
    [dialogPickName, catalog]
  )

  useEffect(() => {
    setPickVersionId('')
  }, [pickName])

  useEffect(() => {
    setDialogPickVersionId('')
  }, [dialogPickName])

  const handleAdd = useCallback(() => {
    const item = versions.find((v) => v.id === pickVersionId)
    if (!item) return
    pinned.addPin(item)
    setPickVersionId('')
  }, [pinned, pickVersionId, versions])

  const handleRemove = useCallback(
    (id: string) => {
      if (id === focusedPinId) {
        onClearFocus()
      }
      pinned.removePin(id)
    },
    [focusedPinId, onClearFocus, pinned]
  )

  const canAdd =
    Boolean(pickVersionId) && !pinned.pins.some((p) => p.id === pickVersionId)

  const canAddDialog =
    Boolean(dialogPickVersionId) && !pinned.pins.some((p) => p.id === dialogPickVersionId)

  const handleDialogAdd = useCallback(() => {
    const item = dialogVersions.find((v) => v.id === dialogPickVersionId)
    if (!item) return
    pinned.addPin(item)
    setDialogPickVersionId('')
    setDialogPickName('')
    setAddPinDialogOpen(false)
  }, [dialogPickVersionId, dialogVersions, pinned])

  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <Dialog
        open={addPinDialogOpen}
        onOpenChange={(open) => {
          setAddPinDialogOpen(open)
          if (!open) {
            setDialogPickName('')
            setDialogPickVersionId('')
          }
        }}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add discovery machine</DialogTitle>
            <DialogDescription>
              Select a catalog state machine and version to pin. You can then run discovery against that
              machine.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="space-y-1">
              <Label htmlFor="disc-dialog-name" className="text-xs">
                State machine name
              </Label>
              <select
                id="disc-dialog-name"
                className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                value={dialogPickName}
                onChange={(e) => setDialogPickName(e.target.value)}
                disabled={catalog.loading}
              >
                <option value="">Select…</option>
                {catalog.uniqueNames.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="disc-dialog-ver" className="text-xs">
                Version
              </Label>
              <select
                id="disc-dialog-ver"
                className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                value={dialogPickVersionId}
                onChange={(e) => setDialogPickVersionId(e.target.value)}
                disabled={!dialogPickName || dialogVersions.length === 0}
              >
                <option value="">Select…</option>
                {dialogVersions.map((v) => (
                  <option key={v.id} value={v.id}>
                    v{v.version}
                  </option>
                ))}
              </select>
            </div>
            {catalog.error ? (
              <p className="text-xs text-destructive" role="alert">
                {catalog.error}
              </p>
            ) : null}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setAddPinDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              type="button"
              disabled={!canAddDialog || catalog.loading}
              onClick={handleDialogAdd}
            >
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              Add pin
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {isCollapsed ? (
        <div className="flex min-h-0 flex-1 flex-col">
          <div
            className={cn(
              'flex h-12 min-h-12 shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-0',
              'justify-center'
            )}
          >
            <button
              type="button"
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
              aria-label="Expand panel"
              onClick={() => api.onExpandRequested()}
            >
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
          <div className="flex shrink-0 justify-center border-b border-border/50 px-1 py-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-8 w-8 shrink-0"
              title="Add discovery machine"
              aria-label="Add discovery machine"
              onClick={() => {
                setDialogPickName('')
                setDialogPickVersionId('')
                setAddPinDialogOpen(true)
              }}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex min-h-0 flex-1 flex-col items-center gap-2 overflow-y-auto px-1 py-2">
            <Button
              type="button"
              variant={focusedPinId === EMPTY_BASELINE_PIN_ID ? 'default' : 'outline'}
              size="icon"
              className="h-8 w-8 shrink-0 rounded-full text-xs font-semibold"
              title="Empty baseline (start discovery from scratch)"
              aria-label="Focus empty baseline"
              aria-pressed={focusedPinId === EMPTY_BASELINE_PIN_ID}
              onClick={() => onFocusEmptyBaseline()}
            >
              ∅
            </Button>
            {pinned.pins.map((p) => {
              const active = p.id === focusedPinId
              const initial = machineInitialLetter(p.name)
              return (
                <Button
                  key={p.id}
                  type="button"
                  variant={active ? 'default' : 'outline'}
                  size="icon"
                  className="h-8 w-8 shrink-0 rounded-full text-xs font-semibold"
                  title={`${p.name} v${p.version}`}
                  aria-label={`Focus discovery machine ${p.name} version ${p.version}`}
                  aria-pressed={active}
                  onClick={() => onFocusPin(p)}
                >
                  {initial}
                </Button>
              )
            })}
          </div>
        </div>
      ) : (
        <>
      <div
        className={cn(
          'flex h-12 min-h-12 shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-0',
          'justify-between'
        )}
      >
        {showLabels ? (
          <span className="truncate px-1 text-xs font-semibold uppercase leading-none tracking-wide text-muted-foreground">
            Discovery Machine
          </span>
        ) : null}
        <button
          type="button"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
          aria-label="Collapse panel"
          onClick={() => api.onCollapseRequested()}
        >
          <ChevronLeft className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      <div className="shrink-0 space-y-2 border-b border-border/50 p-3">
        <div className="space-y-1">
          <Label htmlFor="disc-pick-name" className="text-xs">
            Name
          </Label>
          <select
            id="disc-pick-name"
            className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={pickName}
            onChange={(e) => setPickName(e.target.value)}
            disabled={catalog.loading}
          >
            <option value="">Select…</option>
            {catalog.uniqueNames.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-1">
          <Label htmlFor="disc-pick-ver" className="text-xs">
            Version
          </Label>
          <select
            id="disc-pick-ver"
            className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={pickVersionId}
            onChange={(e) => setPickVersionId(e.target.value)}
            disabled={!pickName || versions.length === 0}
          >
            <option value="">Select…</option>
            {versions.map((v) => (
              <option key={v.id} value={v.id}>
                v{v.version}
              </option>
            ))}
          </select>
        </div>
        <Button
          type="button"
          size="sm"
          className="w-full"
          disabled={!canAdd || catalog.loading}
          onClick={handleAdd}
        >
          <Plus className="mr-1.5 h-3.5 w-3.5" />
          Add pin
        </Button>
        {catalog.error && (
          <p className="text-xs text-destructive" role="alert">
            {catalog.error}
          </p>
        )}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-2">
        {catalog.loading && pinned.pins.length === 0 ? (
          <div className="flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            Loading catalog…
          </div>
        ) : (
          <ul className="space-y-1">
            <li>
              <div
                className={cn(
                  'flex items-start gap-1 rounded-md border px-2 py-2 text-left text-sm transition-colors',
                  focusedPinId === EMPTY_BASELINE_PIN_ID
                    ? 'border-primary bg-primary/10'
                    : 'border-border/60 bg-background hover:bg-muted/50'
                )}
              >
                <button
                  type="button"
                  className="min-w-0 flex-1 text-left"
                  onClick={() => onFocusEmptyBaseline()}
                >
                  <div className="truncate font-medium">∅ Empty baseline</div>
                  <div className="text-xs text-muted-foreground">
                    Discover a state machine from scratch.
                  </div>
                </button>
              </div>
            </li>
            {pinned.pins.length === 0 ? (
              <li>
                <p className="px-2 py-4 text-center text-sm text-muted-foreground">
                  No pins yet. Choose a catalog name and version above, then Add pin.
                </p>
              </li>
            ) : null}
            {pinned.pins.map((p) => {
              const active = p.id === focusedPinId
              return (
                <li key={p.id}>
                  <div
                    className={cn(
                      'flex items-start gap-1 rounded-md border px-2 py-2 text-left text-sm transition-colors',
                      active
                        ? 'border-primary bg-primary/10'
                        : 'border-border/60 bg-background hover:bg-muted/50'
                    )}
                  >
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => onFocusPin(p)}
                    >
                      <div className="truncate font-medium">{p.name}</div>
                      <div className="text-xs text-muted-foreground">v{p.version}</div>
                    </button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                      aria-label={`Remove ${p.name} v${p.version}`}
                      onClick={() => handleRemove(p.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>
        </>
      )}
    </div>
  )
}
