'use client'

import { useState } from 'react'
import type { EntityState } from '@/lib/api'
import { StateBadge, StatusBadge, WorkflowStatusBadge } from '@/components/entities/EntityBadges'

export interface EntityStateOverviewProps {
  entity: EntityState
}

/**
 * Read-only grid of core entity fields (id, machine, state, timestamps) plus optional context JSON.
 * Used on the full detail page and in the entities v2 metrics side panel.
 */
export function EntityStateOverview({ entity }: EntityStateOverviewProps) {
  const [showContext, setShowContext] = useState(false)

  return (
    <>
      <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div>
          <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Entity ID</dt>
          <dd className="text-sm font-mono break-all">{entity.entity_id}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Machine</dt>
          <dd className="text-sm">{entity.machine_name ?? '\u2014'}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Current State</dt>
          <dd className="flex items-center gap-2 flex-wrap">
            <StateBadge state={entity.current_state} />
            <StatusBadge status={entity.status} />
            <WorkflowStatusBadge workflowStatus={entity.workflow_status ?? 'active'} />
          </dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Created</dt>
          <dd className="text-sm text-muted-foreground">
            {entity.created_at ? new Date(entity.created_at).toLocaleString() : '\u2014'}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Updated</dt>
          <dd className="text-sm text-muted-foreground">
            {entity.updated_at ? new Date(entity.updated_at).toLocaleString() : '\u2014'}
          </dd>
        </div>
      </dl>

      {entity.context && Object.keys(entity.context).length > 0 && (
        <div className="mt-4 border-t pt-4">
          <button
            type="button"
            onClick={() => setShowContext(!showContext)}
            className="text-sm font-medium text-primary hover:underline"
          >
            {showContext ? 'Hide' : 'Show'} Context ({Object.keys(entity.context).length} key
            {Object.keys(entity.context).length === 1 ? '' : 's'})
          </button>
          {showContext && (
            <pre className="mt-2 rounded-lg bg-muted p-3 text-xs font-mono overflow-x-auto max-h-[300px]">
              {JSON.stringify(entity.context, null, 2)}
            </pre>
          )}
        </div>
      )}
    </>
  )
}
