'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { renderBasicMarkdown } from './basicMarkdown'
import { X } from 'lucide-react'

export interface StateAnnotationOverlayProps {
  open: boolean
  containerRef: React.RefObject<HTMLElement | null>
  nodeId: string
  machineName: string
  machineVersion: string
  stateName: string
  initialBody: string
  saving: boolean
  deleting: boolean
  onClose: () => void
  onSave: (body: string) => void
  onDelete: () => void
}

export function StateAnnotationOverlay({
  open,
  containerRef,
  nodeId,
  machineName,
  machineVersion,
  stateName,
  initialBody,
  saving,
  deleting,
  onClose,
  onSave,
  onDelete,
}: StateAnnotationOverlayProps) {
  const overlayRef = useRef<HTMLDivElement>(null)
  const [mode, setMode] = useState<'preview' | 'edit'>('preview')
  const [body, setBody] = useState(initialBody)
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null)

  const canDelete = initialBody.trim().length > 0

  useEffect(() => {
    if (!open) return
    setMode('preview')
    setBody(initialBody)
  }, [open, initialBody])

  const computePosition = useCallback(() => {
    const containerEl = containerRef.current
    if (!containerEl) return
    const selectorId = CSS.escape(nodeId)
    const nodeEl =
      document.querySelector(`.react-flow__node[data-id="${selectorId}"]`) ??
      document.querySelector(`[data-id="${selectorId}"]`)
    if (!(nodeEl instanceof HTMLElement)) {
      // Fall back to a safe default so "something" shows up even if anchoring fails.
      setPos({ left: 12, top: 12 })
      return
    }

    const c = containerEl.getBoundingClientRect()
    const r = nodeEl.getBoundingClientRect()

    // Anchor near top-right of the node, with a small offset.
    const left = Math.min(Math.max(r.right - c.left + 8, 8), Math.max(c.width - 360, 8))
    const top = Math.min(Math.max(r.top - c.top, 8), Math.max(c.height - 260, 8))
    setPos({ left, top })
  }, [containerRef, nodeId])

  useEffect(() => {
    if (!open) return
    computePosition()
    const onResizeOrScroll = () => computePosition()
    window.addEventListener('resize', onResizeOrScroll)
    window.addEventListener('scroll', onResizeOrScroll, true)
    return () => {
      window.removeEventListener('resize', onResizeOrScroll)
      window.removeEventListener('scroll', onResizeOrScroll, true)
    }
  }, [open, computePosition])

  useEffect(() => {
    if (!open) return
    const handleMouseDown = (e: MouseEvent) => {
      const target = e.target as Node | null
      if (!target) return
      if (!overlayRef.current?.contains(target)) {
        onClose()
      }
    }
    document.addEventListener('mousedown', handleMouseDown)
    return () => document.removeEventListener('mousedown', handleMouseDown)
  }, [open, onClose])

  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [open, onClose])

  const preview = useMemo(() => renderBasicMarkdown(body), [body])

  if (!open || !pos) return null

  return (
    <div
      ref={overlayRef}
      className="absolute z-30 w-[340px] rounded-lg border bg-background shadow-lg"
      style={{ left: pos.left, top: pos.top }}
      role="dialog"
      aria-label="State note"
      onMouseDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      <header className="flex items-start justify-between gap-2 border-b px-3 py-2">
        <div className="min-w-0">
          <div className="text-xs font-semibold">State note</div>
          <div className="truncate font-mono text-[11px] text-muted-foreground">
            {machineName}@{machineVersion} • {stateName}
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded p-1 text-muted-foreground hover:text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/50"
          aria-label="Close"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </header>

      {mode === 'preview' ? (
        <div
          className="px-3 py-2 text-sm"
          onClick={() => setMode('edit')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') setMode('edit')
          }}
        >
          <div className="text-[11px] font-medium text-muted-foreground mb-2">
            Click to edit
          </div>
          <div className="max-h-[180px] overflow-auto rounded-md border bg-muted/20 px-3 py-2">
            {body.trim().length > 0 ? preview : <span className="text-muted-foreground">No note yet.</span>}
          </div>
        </div>
      ) : (
        <div className="px-3 py-2 space-y-2">
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={8}
            className="w-full resize-y rounded-md border bg-background px-3 py-2 text-sm"
            placeholder="- Preconditions\n- Failure modes\n- Ops checks"
            autoFocus
          />
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {canDelete ? (
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  onClick={onDelete}
                  disabled={deleting || saving}
                >
                  {deleting ? 'Deleting…' : 'Delete'}
                </Button>
              ) : null}
            </div>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setMode('preview')}
                disabled={saving || deleting}
              >
                Preview
              </Button>
              <Button
                type="button"
                size="sm"
                onClick={() => onSave(body)}
                disabled={saving || deleting}
              >
                {saving ? 'Saving…' : 'Save'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
