'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { enqueueApplyData, ApiError } from '@/lib/api'
import type { FSMStateVariable } from '@/lib/types/fsm'
import { Send, CheckCircle2, XCircle } from 'lucide-react'

interface ApplyDataFormProps {
  entityId: string
  defaultMachineName?: string | null
  stateVariables?: FSMStateVariable[]
  onEnqueued?: (eventId: string) => void
}

export default function ApplyDataForm({
  entityId,
  defaultMachineName,
  stateVariables = [],
  onEnqueued,
}: ApplyDataFormProps) {
  const [dataJson, setDataJson] = useState('{}')
  const [sending, setSending] = useState(false)
  const [result, setResult] = useState<{ event_id: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  const fillFromStateVariables = () => {
    const obj: Record<string, unknown> = {}
    for (const sv of stateVariables) {
      obj[sv.key] = sv.default !== undefined && sv.default !== null ? sv.default : null
    }
    setDataJson(JSON.stringify(obj, null, 2))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSending(true)
    setResult(null)
    setError(null)

    let parsed: Record<string, unknown> = {}
    try {
      parsed = JSON.parse(dataJson)
    } catch {
      setError('Invalid JSON in data field')
      setSending(false)
      return
    }

    try {
      const res = await enqueueApplyData(entityId, {
        data: parsed,
        machine_name: defaultMachineName || undefined,
      })
      setResult({ event_id: res.event_id })
      onEnqueued?.(res.event_id)
    } catch (err) {
      setError(err instanceof ApiError ? err.message : err instanceof Error ? err.message : String(err))
    } finally {
      setSending(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Apply Data (Worker)</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <Label htmlFor="apply_data_json" className="text-sm">Data (JSON)</Label>
              {stateVariables.length > 0 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="text-xs text-muted-foreground"
                  onClick={fillFromStateVariables}
                  title="Pre-fill with keys and defaults from state variables"
                >
                  Fill from state variables
                </Button>
              )}
            </div>
            <textarea
              id="apply_data_json"
              rows={6}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
              value={dataJson}
              onChange={(e) => setDataJson(e.target.value)}
            />
          </div>

          <Button type="submit" disabled={sending} className="gap-1.5">
            <Send className="h-4 w-4" />
            {sending ? 'Enqueueing...' : 'Enqueue Apply-Data'}
          </Button>
        </form>

        {result && (
          <div className="mt-4 rounded-lg border border-emerald-300 bg-emerald-50 p-4 dark:border-emerald-700 dark:bg-emerald-950/30">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              <span className="text-sm font-medium">Enqueued</span>
            </div>
            <p className="text-sm">
              Event ID: <code className="text-xs bg-muted px-1 rounded">{result.event_id}</code>
            </p>
          </div>
        )}

        {error && !result && (
          <div className="mt-4 rounded-lg border border-destructive/50 bg-destructive/10 p-3">
            <div className="flex items-center gap-2">
              <XCircle className="h-4 w-4 text-destructive" />
              <p className="text-sm text-destructive">{error}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
