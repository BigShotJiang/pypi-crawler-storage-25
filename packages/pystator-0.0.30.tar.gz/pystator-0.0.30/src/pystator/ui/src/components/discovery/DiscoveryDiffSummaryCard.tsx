'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import type { FSMConfig } from '@/lib/types/fsm'
import { diffFsmConfig } from '@/lib/fsmDiff'

interface DiscoveryDiffSummaryCardProps {
  baselineConfig: FSMConfig | null
  baselineVersion: string | null
  candidateConfig: FSMConfig | null
}

function DiffSection({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(false)
  return (
    <div className="rounded-md border">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-3 py-2 text-left text-sm"
      >
        <span className="font-medium">{title}</span>
        <span className="text-xs text-muted-foreground">{open ? 'Hide' : 'Show'}</span>
      </button>
      {open && <div className="border-t px-3 py-2">{children}</div>}
    </div>
  )
}

export function DiscoveryDiffSummaryCard({
  baselineConfig,
  baselineVersion,
  candidateConfig,
}: DiscoveryDiffSummaryCardProps) {
  const diff = useMemo(() => {
    if (!baselineConfig || !candidateConfig) return null
    return diffFsmConfig(baselineConfig, candidateConfig)
  }, [baselineConfig, candidateConfig])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Diff vs active machine</CardTitle>
        <CardDescription>
          {baselineConfig
            ? `Comparing against Machines catalog v${baselineVersion ?? '—'}`
            : 'No baseline machine found in Machines catalog for this name.'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {!baselineConfig || !candidateConfig || !diff ? (
          <p className="text-sm text-muted-foreground">
            {candidateConfig
              ? 'Create or promote a baseline machine to enable diffs.'
              : 'Select a candidate to enable diffs.'}
          </p>
        ) : (
          <>
            <div className="rounded-md border bg-muted/30 p-3 text-sm text-muted-foreground">
              States: <span className="font-medium text-foreground">+{diff.states.added.length}</span>
              {' / '}
              <span className="font-medium text-foreground">-{diff.states.removed.length}</span>
              {' / '}
              <span className="font-medium text-foreground">~{diff.states.changed.length}</span>
              {' · '}
              Transitions: <span className="font-medium text-foreground">+{diff.transitions.added.length}</span>
              {' / '}
              <span className="font-medium text-foreground">-{diff.transitions.removed.length}</span>
              {' / '}
              <span className="font-medium text-foreground">~{diff.transitions.changed.length}</span>
            </div>

            <DiffSection title={`States added (${diff.states.added.length})`}>
              {diff.states.added.length === 0 ? (
                <p className="text-sm text-muted-foreground">None.</p>
              ) : (
                <ul className="space-y-1 text-sm">
                  {diff.states.added.map((s) => (
                    <li key={s.name} className="font-mono text-xs">{s.name}</li>
                  ))}
                </ul>
              )}
            </DiffSection>

            <DiffSection title={`States removed (${diff.states.removed.length})`}>
              {diff.states.removed.length === 0 ? (
                <p className="text-sm text-muted-foreground">None.</p>
              ) : (
                <ul className="space-y-1 text-sm">
                  {diff.states.removed.map((s) => (
                    <li key={s.name} className="font-mono text-xs">{s.name}</li>
                  ))}
                </ul>
              )}
            </DiffSection>

            <DiffSection title={`Transitions added (${diff.transitions.added.length})`}>
              {diff.transitions.added.length === 0 ? (
                <p className="text-sm text-muted-foreground">None.</p>
              ) : (
                <ul className="space-y-1 text-sm">
                  {diff.transitions.added.map((t, i) => (
                    <li key={`${t.trigger ?? ''}-${i}`} className="font-mono text-xs">
                      {(t.trigger ?? '—')} : {Array.isArray(t.source) ? t.source.join('|') : t.source} → {t.dest}
                    </li>
                  ))}
                </ul>
              )}
            </DiffSection>

            <DiffSection title={`Transitions removed (${diff.transitions.removed.length})`}>
              {diff.transitions.removed.length === 0 ? (
                <p className="text-sm text-muted-foreground">None.</p>
              ) : (
                <ul className="space-y-1 text-sm">
                  {diff.transitions.removed.map((t, i) => (
                    <li key={`${t.trigger ?? ''}-${i}`} className="font-mono text-xs">
                      {(t.trigger ?? '—')} : {Array.isArray(t.source) ? t.source.join('|') : t.source} → {t.dest}
                    </li>
                  ))}
                </ul>
              )}
            </DiffSection>
          </>
        )}
      </CardContent>
    </Card>
  )
}
