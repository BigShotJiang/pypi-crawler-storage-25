'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { FSMTransition } from '@/lib/types/fsm'
import GuardEditor, { type FSMGuard } from '@/components/editors/GuardEditor'
import ActionEditor, { type FSMAction } from '@/components/editors/ActionEditor'
import BuiltinBrowserPanel from '@/components/editors/BuiltinBrowserPanel'
import { normalizeName, validateName } from '@/lib/utils'

function sourceToArray(source: string | string[]): string[] {
  if (Array.isArray(source)) return source
  const s = (source ?? '').trim()
  return s ? [s] : []
}

function normalizeGuards(raw: unknown): FSMGuard[] {
  if (!raw) return []
  if (Array.isArray(raw)) return raw as FSMGuard[]
  return [raw as FSMGuard]
}

function normalizeActions(raw: unknown): FSMAction[] {
  if (!raw) return []
  if (Array.isArray(raw)) return raw as FSMAction[]
  return [raw as FSMAction]
}

function delayToString(after: number | string | undefined): string {
  if (after === undefined || after === null) return ''
  return String(after)
}

function parseDelay(input: string): number | string | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  if (/^[0-9]+[smh]$/.test(trimmed)) return trimmed
  const num = parseInt(trimmed, 10)
  if (!isNaN(num)) return num
  return trimmed
}

export interface TransitionModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  transition: FSMTransition
  stateNames: string[]
  regionNames?: string[]
  onSave: (transition: FSMTransition) => void
  title?: string
  description?: string
}

export function TransitionModal({
  open,
  onOpenChange,
  transition,
  stateNames,
  regionNames = [],
  onSave,
  title = 'Transition',
  description = 'Trigger, source state(s), destination; guards, actions, delay, and region optional.',
}: TransitionModalProps) {
  const [trigger, setTrigger] = useState(transition.trigger ?? '')
  const [source, setSource] = useState<string[]>(() => sourceToArray(transition.source))
  const [dest, setDest] = useState(transition.dest)
  const [guards, setGuards] = useState<FSMGuard[]>(() => normalizeGuards(transition.guards))
  const [actions, setActions] = useState<FSMAction[]>(() => normalizeActions(transition.actions))
  const [delay, setDelay] = useState(delayToString(transition.after))
  const [region, setRegion] = useState(transition.region ?? '')

  useEffect(() => {
    if (open) {
      setTrigger(transition.trigger ?? '')
      setSource(sourceToArray(transition.source))
      setDest(transition.dest)
      setGuards(normalizeGuards(transition.guards))
      setActions(normalizeActions(transition.actions))
      setDelay(delayToString(transition.after))
      setRegion(transition.region ?? '')
    }
  }, [open, transition])

  const normalizedTrigger = useMemo(() => normalizeName(trigger), [trigger])
  const triggerValidation = useMemo(() => {
    const trimmed = trigger.trim()
    if (!trimmed) return { valid: true, error: '' }
    if (!normalizedTrigger) return { valid: false, error: 'Trigger produces no valid characters' }
    try {
      validateName(normalizedTrigger)
      return { valid: true, error: '' }
    } catch (e) {
      return { valid: false, error: e instanceof Error ? e.message : 'Invalid trigger' }
    }
  }, [trigger, normalizedTrigger])
  const showTriggerHint = trigger.trim() !== '' && normalizedTrigger !== '' && normalizedTrigger !== trigger.trim().toLowerCase()

  const uniqueStateNames = useMemo(() => [...new Set(stateNames)], [stateNames])
  const uniqueRegionNames = useMemo(() => [...new Set(regionNames)], [regionNames])

  const handleInsertGuard = useCallback(
    (name: string) => setGuards((prev) => [...prev, name]),
    [],
  )
  const handleInsertAction = useCallback(
    (name: string) => setActions((prev) => [...prev, name]),
    [],
  )

  const handleSave = () => {
    if (source.length === 0 || !dest) return
    if (!triggerValidation.valid) return
    const hasTrigger = trigger?.trim()
    const hasDelay = delay?.trim()
    if (!hasTrigger && !hasDelay) return
    onSave({
      trigger: normalizedTrigger || undefined,
      source: source.length === 1 ? source[0] : source,
      dest,
      guards: guards.length > 0 ? guards : undefined,
      actions: actions.length > 0 ? actions : undefined,
      after: parseDelay(delay),
      region: region.trim() || undefined,
    })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" showClose>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="trans-trigger">Trigger</Label>
              <Input
                id="trans-trigger"
                className="h-9"
                placeholder="e.g. submit"
                value={trigger ?? ''}
                onChange={(e) => setTrigger(e.target.value)}
              />
              {showTriggerHint && (
                <p className="text-xs text-muted-foreground">
                  Will be saved as: <span className="font-mono font-medium text-foreground">{normalizedTrigger}</span>
                </p>
              )}
              {triggerValidation.error && (
                <p className="text-xs text-destructive">{triggerValidation.error}</p>
              )}
              <p className="text-xs text-muted-foreground">
                Only lowercase letters, numbers, and underscores allowed.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="trans-source">Source (hold Ctrl/Cmd to select multiple)</Label>
              <select
                id="trans-source"
                multiple
                className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                value={source}
                onChange={(e) => setSource([...e.target.selectedOptions].map((o) => o.value))}
                disabled={uniqueStateNames.length === 0}
              >
                {uniqueStateNames.length === 0 ? (
                  <option value="" disabled>Add a state first</option>
                ) : (
                  uniqueStateNames.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="trans-dest">Destination</Label>
              <select
                id="trans-dest"
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                value={dest}
                onChange={(e) => setDest(e.target.value)}
                disabled={uniqueStateNames.length === 0}
              >
                {uniqueStateNames.length === 0 ? (
                  <option value="">Add a state first</option>
                ) : (
                  uniqueStateNames.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))
                )}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="trans-region">Region (for parallel states)</Label>
              <select
                id="trans-region"
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                value={region}
                onChange={(e) => setRegion(e.target.value)}
              >
                <option value="">None</option>
                {uniqueRegionNames.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Guards</Label>
            <GuardEditor guards={guards} onChange={setGuards} />
          </div>
          <div className="space-y-2">
            <Label>Actions</Label>
            <ActionEditor actions={actions} onChange={setActions} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="trans-delay">Delay (after) - ms or "5s"/"5m"/"1h"</Label>
            <Input
              id="trans-delay"
              className="h-9"
              placeholder="e.g. 5000 or 5s"
              value={delay}
              onChange={(e) => setDelay(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Delayed transitions fire automatically after the specified time
            </p>
          </div>
          <BuiltinBrowserPanel
            onInsertGuard={handleInsertGuard}
            onInsertAction={handleInsertAction}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={(!trigger.trim() && !delay.trim()) || !triggerValidation.valid || source.length === 0 || !dest}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
