"use client"

import { useCallback, useState } from "react"

interface ContextPanelProps {
  context: Record<string, unknown>
}

export default function ContextPanel({ context }: ContextPanelProps) {
  const [copied, setCopied] = useState(false)

  const entries = Object.entries(context).filter(
    ([k]) => !k.startsWith("_")
  )

  const handleCopy = useCallback(() => {
    const json = JSON.stringify(context, null, 2)
    navigator.clipboard.writeText(json).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    })
  }, [context])

  if (entries.length === 0) {
    return (
      <div className="rounded-md border bg-muted/20 p-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Context</span>
        </div>
        <p className="text-xs text-muted-foreground italic">No context data</p>
      </div>
    )
  }

  return (
    <div className="rounded-md border bg-muted/20 p-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Context</span>
        <button
          onClick={handleCopy}
          className="text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          {copied ? "Copied!" : "Copy JSON"}
        </button>
      </div>
      <div className="space-y-1 max-h-48 overflow-y-auto">
        {entries.map(([key, value]) => (
          <div key={key} className="flex items-baseline gap-2 text-xs font-mono">
            <span className="text-muted-foreground shrink-0">{key}:</span>
            <span className="text-foreground truncate" title={JSON.stringify(value)}>
              {typeof value === "object" ? JSON.stringify(value) : String(value)}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
