'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import LoadingSpinner from '@/components/LoadingSpinner'
import {
  getEntityMetrics,
  getApiErrorMessage,
  type EntityMetricsResponse,
  type ErrorPatternItem,
  type DwellByStateItem,
  type FleetComparison,
  type VelocityPoint,
  type DurationPercentiles,
} from '@/lib/api'
import {
  Activity,
  AlertTriangle,
  TrendingUp,
  BarChart3,
  RefreshCw,
  Repeat2,
} from 'lucide-react'

interface EntityMetricsPanelProps {
  entityId: string
  refreshToken?: number
}

function formatMs(ms: number): string {
  if (ms < 1000) return `${Math.round(ms)}ms`
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
  return `${(ms / 60000).toFixed(1)}min`
}

function formatRelativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
  return `${Math.floor(diff / 86400000)}d ago`
}

function healthColorClasses(status: 'healthy' | 'warning' | 'critical'): string {
  switch (status) {
    case 'healthy':
      return 'text-emerald-500 border-emerald-500'
    case 'warning':
      return 'text-amber-500 border-amber-500'
    case 'critical':
      return 'text-red-500 border-red-500'
  }
}

function HealthBadge({
  score,
  status,
  stalenessLabel,
  failureRate,
}: {
  score: number
  status: 'healthy' | 'warning' | 'critical'
  stalenessLabel: string
  failureRate: number
}) {
  const colors = healthColorClasses(status)
  return (
    <div className="flex items-center gap-4">
      <div
        className={`w-16 h-16 rounded-full border-4 flex items-center justify-center ${colors}`}
      >
        <span className="text-xl font-bold">{score}</span>
      </div>
      <div className="space-y-1">
        <p className="text-sm font-medium capitalize">{status}</p>
        <p className="text-xs text-muted-foreground">{stalenessLabel}</p>
        <p className="text-xs text-muted-foreground">
          Failure rate:{' '}
          <span className="font-medium text-foreground">
            {(failureRate * 100).toFixed(1)}%
          </span>
        </p>
      </div>
    </div>
  )
}

function StuckBanner({
  stuckState,
  currentDwellMs,
  avgDwellMs,
}: {
  stuckState: string | null
  currentDwellMs: number | null
  avgDwellMs: number | null
}) {
  return (
    <div className="rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/20 p-3">
      <div className="flex items-start gap-2">
        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
        <div className="text-sm">
          <p className="font-medium text-amber-800 dark:text-amber-300">
            Potentially stuck in{' '}
            <code className="rounded bg-amber-100 dark:bg-amber-900/40 px-1 text-xs">
              {stuckState}
            </code>
          </p>
          {currentDwellMs != null && avgDwellMs != null && (
            <p className="text-xs text-amber-700 dark:text-amber-400 mt-1">
              Current dwell: {formatMs(currentDwellMs)} (avg: {formatMs(avgDwellMs)})
            </p>
          )}
        </div>
      </div>
    </div>
  )
}

function ErrorBreakdown({ patterns }: { patterns: ErrorPatternItem[] }) {
  const items = patterns.slice(0, 5)
  return (
    <div>
      <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
        <AlertTriangle className="h-3.5 w-3.5" />
        Error Breakdown
      </h4>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b text-muted-foreground">
              <th className="text-left py-1.5 pr-2 font-medium">Pattern</th>
              <th className="text-right py-1.5 px-2 font-medium">Count</th>
              <th className="text-right py-1.5 pl-2 font-medium">Last</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => (
              <tr key={idx} className="border-b border-border/50">
                <td className="py-1.5 pr-2">
                  <span className="text-foreground">
                    {item.error_type ?? 'unknown'}
                  </span>{' '}
                  <span className="text-muted-foreground">on</span>{' '}
                  <code className="rounded bg-muted px-1 text-[10px]">{item.trigger}</code>{' '}
                  <span className="text-muted-foreground">from</span>{' '}
                  <code className="rounded bg-muted px-1 text-[10px]">{item.source_state}</code>
                </td>
                <td className="text-right py-1.5 px-2">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-destructive/10 text-destructive text-[10px] font-medium">
                    {item.count}
                  </span>
                </td>
                <td className="text-right py-1.5 pl-2 text-muted-foreground">
                  {formatRelativeTime(item.last_occurred)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function LatencyBars({ percentiles }: { percentiles: DurationPercentiles }) {
  const entries: { label: string; value: number | null }[] = [
    { label: 'p50', value: percentiles.p50 },
    { label: 'p75', value: percentiles.p75 },
    { label: 'p95', value: percentiles.p95 },
    { label: 'p99', value: percentiles.p99 },
  ]

  const maxVal = Math.max(
    ...entries.map((e) => e.value ?? 0).filter((v) => v > 0),
    1
  )

  return (
    <div className="space-y-1.5">
      {entries.map((entry) => {
        const pct = entry.value != null && maxVal > 0
          ? (entry.value / maxVal) * 100
          : 0
        return (
          <div key={entry.label} className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground w-8 text-right font-mono">
              {entry.label}
            </span>
            <div className="flex-1 h-4 bg-muted rounded overflow-hidden">
              <div
                className="h-full bg-primary/60 rounded transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className="text-xs text-foreground w-16 text-right font-mono">
              {entry.value != null ? formatMs(entry.value) : '--'}
            </span>
          </div>
        )
      })}
    </div>
  )
}

function DwellTable({ items }: { items: DwellByStateItem[] }) {
  if (items.length === 0) {
    return <p className="text-xs text-muted-foreground">No dwell data available.</p>
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b text-muted-foreground">
            <th className="text-left py-1.5 pr-2 font-medium">State</th>
            <th className="text-right py-1.5 px-2 font-medium">Avg</th>
            <th className="text-right py-1.5 px-2 font-medium">Min</th>
            <th className="text-right py-1.5 px-2 font-medium">Max</th>
            <th className="text-right py-1.5 pl-2 font-medium">Visits</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.state} className="border-b border-border/50">
              <td className="py-1.5 pr-2">
                <code className="rounded bg-muted px-1 text-[10px]">{item.state}</code>
              </td>
              <td className="text-right py-1.5 px-2 font-mono">{formatMs(item.avg_ms)}</td>
              <td className="text-right py-1.5 px-2 font-mono">{formatMs(item.min_ms)}</td>
              <td className="text-right py-1.5 px-2 font-mono">{formatMs(item.max_ms)}</td>
              <td className="text-right py-1.5 pl-2">{item.visit_count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function BehavioralPatterns({
  stateRevisits,
  hasCycles,
  fleetComparison,
}: {
  stateRevisits: Record<string, number>
  hasCycles: boolean
  fleetComparison: FleetComparison | null
}) {
  const revisitEntries = Object.entries(stateRevisits).filter(([, count]) => count > 1)

  return (
    <div className="space-y-3">
      {/* State revisits */}
      {revisitEntries.length > 0 && (
        <div>
          <h5 className="text-xs font-medium text-muted-foreground mb-1.5">
            State Revisits
          </h5>
          <div className="flex flex-wrap gap-1.5">
            {revisitEntries.map(([state, count]) => (
              <span
                key={state}
                className="inline-flex items-center gap-1 rounded border border-border px-2 py-0.5 text-xs"
              >
                <code className="text-[10px]">{state}</code>
                <span className="text-muted-foreground">&times;{count}</span>
                {hasCycles && (
                  <Repeat2 className="h-3 w-3 text-amber-500" />
                )}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Fleet comparison */}
      {fleetComparison && (
        <div>
          <h5 className="text-xs font-medium text-muted-foreground mb-1.5">
            Fleet Comparison
          </h5>
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Failure rate</span>
              <span className="flex items-center gap-2">
                <span
                  className={
                    fleetComparison.entity_failure_rate <= fleetComparison.fleet_failure_rate
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-red-600 dark:text-red-400'
                  }
                >
                  {(fleetComparison.entity_failure_rate * 100).toFixed(1)}%
                </span>
                <span className="text-muted-foreground">vs</span>
                <span>{(fleetComparison.fleet_failure_rate * 100).toFixed(1)}%</span>
              </span>
            </div>
            {fleetComparison.entity_avg_latency_ms != null &&
              fleetComparison.fleet_avg_latency_ms != null && (
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Avg latency</span>
                  <span className="flex items-center gap-2">
                    <span
                      className={
                        fleetComparison.entity_avg_latency_ms <=
                        fleetComparison.fleet_avg_latency_ms
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-red-600 dark:text-red-400'
                      }
                    >
                      {formatMs(fleetComparison.entity_avg_latency_ms)}
                    </span>
                    <span className="text-muted-foreground">vs</span>
                    <span>{formatMs(fleetComparison.fleet_avg_latency_ms)}</span>
                  </span>
                </div>
              )}
            {fleetComparison.latency_percentile_rank != null && (
              <p className="text-muted-foreground">
                Faster than{' '}
                <span className="font-medium text-foreground">
                  {(fleetComparison.latency_percentile_rank * 100).toFixed(0)}%
                </span>{' '}
                of entities
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function VelocitySparkline({ points }: { points: VelocityPoint[] }) {
  if (points.length < 2) {
    return <p className="text-xs text-muted-foreground">Insufficient velocity data.</p>
  }

  const maxDuration = Math.max(...points.map((p) => p.duration_ms), 1)
  const svgWidth = 300
  const svgHeight = 60

  const coords = points.map((p, i) => {
    const x = (i / (points.length - 1)) * svgWidth
    const y = svgHeight - (p.duration_ms / maxDuration) * svgHeight
    return `${x},${y}`
  })

  const polylinePoints = coords.join(' ')
  const areaPoints = `0,${svgHeight} ${polylinePoints} ${svgWidth},${svgHeight}`

  return (
    <svg
      viewBox={`0 0 ${svgWidth} ${svgHeight}`}
      preserveAspectRatio="none"
      className="w-full h-16"
      role="img"
      aria-label="Transition velocity sparkline"
    >
      <polygon
        points={areaPoints}
        className="fill-emerald-500/10"
      />
      <polyline
        points={polylinePoints}
        fill="none"
        className="stroke-emerald-500"
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export default function EntityMetricsPanel({
  entityId,
  refreshToken = 0,
}: EntityMetricsPanelProps) {
  const [data, setData] = useState<EntityMetricsResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchMetrics = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getEntityMetrics(entityId)
      setData(res)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load entity metrics'))
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    fetchMetrics()
  }, [fetchMetrics, refreshToken])

  if (loading && !data) {
    return (
      <Card>
        <CardContent className="py-8">
          <LoadingSpinner />
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card>
        <CardContent className="py-4">
          <p className="text-destructive text-sm">{error}</p>
        </CardContent>
      </Card>
    )
  }

  if (!data) {
    return null
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <Activity className="h-4 w-4" />
          Entity Metrics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Section 1: Health Badge + Staleness */}
        <HealthBadge
          score={data.health_score}
          status={data.health_status}
          stalenessLabel={data.staleness_label}
          failureRate={data.recent_failure_rate}
        />

        {/* Section 2: Stuck Detection Banner */}
        {data.is_potentially_stuck && (
          <StuckBanner
            stuckState={data.stuck_state}
            currentDwellMs={data.stuck_current_dwell_ms}
            avgDwellMs={data.stuck_avg_dwell_ms}
          />
        )}

        {/* Section 3: Error Breakdown */}
        {data.error_patterns.length > 0 && (
          <ErrorBreakdown patterns={data.error_patterns} />
        )}

        {/* Section 4: Performance */}
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <BarChart3 className="h-3.5 w-3.5" />
            Performance
          </h4>
          <div className="space-y-3">
            <div>
              <p className="text-[11px] text-muted-foreground mb-1.5">
                Latency Percentiles
              </p>
              <LatencyBars percentiles={data.latency_percentiles} />
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground mb-1.5">
                Dwell by State
              </p>
              <DwellTable items={data.dwell_by_state} />
            </div>
          </div>
        </div>

        {/* Section 5: Behavioral Patterns */}
        {(Object.keys(data.state_revisits).length > 0 || data.fleet_comparison) && (
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5" />
              Behavioral Patterns
            </h4>
            <BehavioralPatterns
              stateRevisits={data.state_revisits}
              hasCycles={data.has_cycles}
              fleetComparison={data.fleet_comparison}
            />
          </div>
        )}

        {/* Section 6: Velocity Sparkline */}
        {data.velocity_points.length >= 2 && (
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <RefreshCw className="h-3.5 w-3.5" />
              Transition Velocity
            </h4>
            <VelocitySparkline points={data.velocity_points} />
          </div>
        )}
      </CardContent>
    </Card>
  )
}
