'use client'

import { useCallback, useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { getBuiltinCatalog } from '@/lib/api'
import type { BuiltinCatalog, CatalogEntry, CatalogEffect, CatalogOperator } from '@/lib/api'
import { ChevronDown, ChevronRight, BookOpen, Plus } from 'lucide-react'

interface BuiltinBrowserPanelProps {
  onInsertGuard?: (name: string) => void
  onInsertAction?: (name: string) => void
}

type TabKey = 'guards' | 'actions' | 'effects'

export default function BuiltinBrowserPanel({
  onInsertGuard,
  onInsertAction,
}: BuiltinBrowserPanelProps) {
  const [open, setOpen] = useState(false)
  const [catalog, setCatalog] = useState<BuiltinCatalog | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<TabKey>('guards')

  const fetchCatalog = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await getBuiltinCatalog()
      setCatalog(data)
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (open && !catalog && !loading) {
      fetchCatalog()
    }
  }, [open, catalog, loading, fetchCatalog])

  const tabs: { key: TabKey; label: string }[] = [
    { key: 'guards', label: 'Guards' },
    { key: 'actions', label: 'Actions' },
    { key: 'effects', label: 'Effects & Operators' },
  ]

  return (
    <div className="rounded-lg border bg-card">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2 px-4 py-2.5 text-sm font-medium hover:bg-muted/50 transition-colors"
      >
        {open ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        )}
        <BookOpen className="h-4 w-4" />
        Browse Built-ins
      </button>

      {open && (
        <div className="border-t px-4 pb-4 pt-3 space-y-3">
          {/* Tabs */}
          <div className="flex gap-1 border-b">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveTab(tab.key)}
                className={`px-3 py-1.5 text-xs font-medium border-b-2 transition-colors ${
                  activeTab === tab.key
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content */}
          {loading && (
            <p className="text-sm text-muted-foreground py-4 text-center">Loading catalog...</p>
          )}
          {error && (
            <p className="text-sm text-destructive py-2">Failed to load catalog: {error}</p>
          )}

          {catalog && !loading && (
            <div className="max-h-72 overflow-y-auto space-y-1">
              {activeTab === 'guards' &&
                catalog.guards.map((item) => (
                  <EntryRow key={item.name} entry={item} onInsert={onInsertGuard} />
                ))}

              {activeTab === 'actions' &&
                catalog.actions.map((item) => (
                  <EntryRow key={item.name} entry={item} onInsert={onInsertAction} />
                ))}

              {activeTab === 'effects' && (
                <>
                  {catalog.effects.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider pt-1">
                        Effects
                      </p>
                      {catalog.effects.map((eff) => (
                        <EffectRow key={eff.name} effect={eff} />
                      ))}
                    </div>
                  )}
                  {catalog.check_operators.length > 0 && (
                    <div className="space-y-1 pt-2">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">
                        Check Operators
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {catalog.check_operators.map((op) => (
                          <span
                            key={op.name}
                            className="rounded bg-muted px-2 py-0.5 text-xs font-mono"
                          >
                            {op.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function EntryRow({
  entry,
  onInsert,
}: {
  entry: CatalogEntry
  onInsert?: (name: string) => void
}) {
  return (
    <div className="flex items-start justify-between gap-2 rounded px-2 py-1.5 hover:bg-muted/40">
      <div className="min-w-0">
        <p className="text-sm font-semibold truncate">{entry.name}</p>
        <p className="text-xs text-muted-foreground line-clamp-2">{entry.description}</p>
        {entry.params.length > 0 && (
          <p className="text-xs text-muted-foreground mt-0.5">
            Params: {entry.params.map((p) => p.name).join(', ')}
          </p>
        )}
      </div>
      {onInsert && (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onInsert(entry.name)}
          className="h-7 shrink-0 gap-1 text-xs"
        >
          <Plus className="h-3 w-3" />
          Insert
        </Button>
      )}
    </div>
  )
}

function EffectRow({ effect }: { effect: CatalogEffect }) {
  return (
    <div className="rounded px-2 py-1.5 hover:bg-muted/40">
      <p className="text-sm font-semibold">{effect.name}</p>
      <p className="text-xs text-muted-foreground">{effect.description}</p>
      {effect.syntax && (
        <code className="text-xs bg-muted px-1 rounded mt-0.5 inline-block">{effect.syntax}</code>
      )}
    </div>
  )
}
