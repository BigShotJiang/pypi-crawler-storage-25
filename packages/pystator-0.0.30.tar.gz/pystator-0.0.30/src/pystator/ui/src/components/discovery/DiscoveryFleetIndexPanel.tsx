'use client'

import { useCallback, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { buildDiscoveryCandidate, getApiErrorMessage } from '@/lib/api'
import type { FleetRowView, UseDiscoveryFleetIndexResult } from '@/hooks/useDiscoveryFleetIndex'
import { ChevronLeft, ChevronRight, Hammer, Loader2, RefreshCw } from 'lucide-react'

const SORT_OPTIONS: { value: string; label: string }[] = [
  { value: 'machine_name', label: 'Name' },
  { value: 'last_observation_at', label: 'Last observation' },
  { value: 'observation_count', label: 'Observations' },
  { value: 'candidate_count', label: 'Candidates' },
  { value: 'drift_rate_recent', label: 'Drift rate' },
  { value: 'shadow_diff_count_recent', label: 'Shadow diffs' },
]

function AttentionBadges({ row }: { row: FleetRowView }) {
  const { attention } = row
  const pills: { key: string; label: string; className: string; title: string }[] = []
  if (attention.drift) {
    pills.push({
      key: 'drift',
      label: 'Drift',
      className: 'bg-amber-500/15 text-amber-800 dark:text-amber-200 border border-amber-500/40',
      title: `Shadow drift in latest ${row.shadow_diff_count_recent} diffs: ${(row.drift_rate_recent * 100).toFixed(0)}% differ (threshold: ≥15% with ≥3 samples).`,
    })
  }
  if (attention.stale) {
    pills.push({
      key: 'stale',
      label: 'Stale',
      className: 'bg-slate-500/15 text-slate-700 dark:text-slate-300 border border-slate-500/30',
      title: row.last_observation_at
        ? 'No observation in the last 7 days.'
        : 'No observations recorded for this machine.',
    })
  }
  if (attention.missingCatalog) {
    pills.push({
      key: 'nocat',
      label: 'No catalog',
      className: 'bg-violet-500/15 text-violet-800 dark:text-violet-200 border border-violet-500/40',
      title: 'No machine with this name exists in the Machines catalog (baseline may be missing).',
    })
  }
  if (attention.versionMismatch) {
    pills.push({
      key: 'ver',
      label: 'Ver ≠ cat',
      className: 'bg-sky-500/15 text-sky-900 dark:text-sky-100 border border-sky-500/40',
      title: `Latest candidate version (${row.latest_candidate_version ?? '—'}) does not match catalog version (${row.catalogVersion ?? '—'}).`,
    })
  }
  if (pills.length === 0) return null
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {pills.map((p) => (
        <span
          key={p.key}
          title={p.title}
          className={`inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium ${p.className}`}
        >
          {p.label}
        </span>
      ))}
    </div>
  )
}

export interface DiscoveryFleetIndexPanelProps {
  fleet: UseDiscoveryFleetIndexResult
  workspaceMachineName: string
  onOpenMachine: (name: string) => void | Promise<void>
  /** `sidebarRail`: full-height rail body (no Card); `pageCard`: standalone card layout. */
  variant?: 'pageCard' | 'sidebarRail'
}

async function mapPool<T, R>(
  items: T[],
  concurrency: number,
  fn: (item: T) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length)
  let i = 0
  async function worker() {
    while (i < items.length) {
      const idx = i++
      out[idx] = await fn(items[idx])
    }
  }
  const workers = Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
  await Promise.all(workers)
  return out
}

export function DiscoveryFleetIndexPanel({
  fleet,
  workspaceMachineName,
  onOpenMachine,
  variant = 'pageCard',
}: DiscoveryFleetIndexPanelProps) {
  const [bulkOpen, setBulkOpen] = useState(false)
  const [bulkRunning, setBulkRunning] = useState(false)
  const [bulkError, setBulkError] = useState<string | null>(null)
  const [bulkOk, setBulkOk] = useState(0)

  const runBulkBuild = useCallback(async () => {
    const names = [...fleet.selectedMachineNames]
    if (names.length === 0) return
    setBulkRunning(true)
    setBulkError(null)
    setBulkOk(0)
    try {
      let ok = 0
      await mapPool(names, 3, async (machine_name) => {
        try {
          await buildDiscoveryCandidate({ machine_name })
          ok += 1
          setBulkOk(ok)
        } catch (e) {
          throw new Error(getApiErrorMessage(e, `Build failed for ${machine_name}`))
        }
      })
      await fleet.refresh()
      setBulkOpen(false)
      fleet.clearSelection()
    } catch (e) {
      setBulkError(getApiErrorMessage(e, 'Bulk build failed'))
    } finally {
      setBulkRunning(false)
    }
  }, [fleet])

  const maxOffset = Math.max(0, fleet.total - fleet.limit)
  const pageStart = fleet.total === 0 ? 0 : fleet.offset + 1
  const pageEnd = Math.min(fleet.offset + fleet.rows.length, fleet.total)

  const tableScrollClass =
    variant === 'sidebarRail'
      ? 'flex-1 min-h-0 overflow-auto rounded-md border min-h-[120px]'
      : 'flex-1 overflow-auto rounded-md border min-h-[200px] max-h-[55vh]'

  const controls = (
    <>
        <div className="flex flex-wrap gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8"
            disabled={fleet.loading}
            onClick={() => void fleet.refresh()}
          >
            {fleet.loading ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <RefreshCw className="h-3.5 w-3.5" />
            )}
            <span className="ml-1.5">Refresh</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8"
            disabled={fleet.selectedMachineNames.size === 0}
            onClick={() => setBulkOpen(true)}
          >
            <Hammer className="h-3.5 w-3.5" />
            <span className="ml-1.5">Build selected ({fleet.selectedMachineNames.size})</span>
          </Button>
          {fleet.selectedMachineNames.size > 0 && (
            <Button type="button" variant="ghost" size="sm" className="h-8" onClick={fleet.clearSelection}>
              Clear selection
            </Button>
          )}
        </div>

        {fleet.error && (
          <p className="text-sm text-destructive" role="alert">
            {fleet.error}
          </p>
        )}

        <div className="space-y-1">
          <Label htmlFor="fleet-search" className="text-xs">
            Search name
          </Label>
          <Input
            id="fleet-search"
            value={fleet.searchInput}
            onChange={(e) => fleet.setSearchInput(e.target.value)}
            placeholder="Substring…"
            className="h-8 text-sm"
          />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label className="text-xs">Sort</Label>
            <select
              className="flex h-8 w-full rounded-md border border-input bg-background px-2 text-xs"
              value={fleet.sort}
              onChange={(e) => fleet.setSort(e.target.value)}
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Order</Label>
            <select
              className="flex h-8 w-full rounded-md border border-input bg-background px-2 text-xs"
              value={fleet.order}
              onChange={(e) => fleet.setOrder(e.target.value as 'asc' | 'desc')}
            >
              <option value="asc">Ascending</option>
              <option value="desc">Descending</option>
            </select>
          </div>
        </div>

        <div className={tableScrollClass}>
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-muted/80 backdrop-blur-sm z-10">
              <tr className="border-b text-left">
                <th className="p-2 w-8" aria-label="Select" />
                <th className="p-2">Machine</th>
                <th className="p-2 text-right">Obs</th>
                <th className="p-2 text-right">Drift</th>
              </tr>
            </thead>
            <tbody>
              {fleet.rows.map((row) => (
                <FleetRow
                  key={row.machine_name}
                  row={row}
                  selected={workspaceMachineName.trim() === row.machine_name}
                  checked={fleet.selectedMachineNames.has(row.machine_name)}
                  onToggleCheck={() => fleet.toggleSelected(row.machine_name)}
                  onOpen={() => void onOpenMachine(row.machine_name)}
                />
              ))}
              {fleet.rows.length === 0 && !fleet.loading && (
                <tr>
                  <td colSpan={4} className="p-4 text-muted-foreground text-center">
                    No machines match.
                  </td>
                </tr>
              )}
              {fleet.loading && fleet.rows.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-4 text-center text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin inline" />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>
            {fleet.total === 0 ? '0' : `${pageStart}–${pageEnd}`} of {fleet.total}
          </span>
          <div className="flex gap-1">
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-7 w-7"
              disabled={fleet.offset <= 0 || fleet.loading}
              onClick={() => fleet.setOffset(Math.max(0, fleet.offset - fleet.limit))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-7 w-7"
              disabled={fleet.offset >= maxOffset || fleet.loading || fleet.total === 0}
              onClick={() => fleet.setOffset(Math.min(maxOffset, fleet.offset + fleet.limit))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
    </>
  )

  return (
    <>
      {variant === 'pageCard' ? (
        <Card className="flex w-full shrink-0 flex-col min-h-[320px] lg:max-w-md xl:max-w-lg">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Fleet</CardTitle>
            <CardDescription>
              Machines with discovery data. Shadow metrics use the latest 200 diffs per machine. Click a
              row to open it in the workspace.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex min-h-0 flex-1 flex-col space-y-3">{controls}</CardContent>
        </Card>
      ) : (
        <div className="flex h-full min-h-0 flex-col px-2 pb-2">
          <div className="flex min-h-0 flex-1 flex-col space-y-3 pt-2">{controls}</div>
        </div>
      )}

      <Dialog open={bulkOpen} onOpenChange={setBulkOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Build candidates for selected machines?</DialogTitle>
            <DialogDescription>
              This runs the discovery candidate builder for {fleet.selectedMachineNames.size} machine(s),
              with at most 3 concurrent requests. Existing candidate versions are unchanged; new versions
              may be created.
            </DialogDescription>
          </DialogHeader>
          {bulkError && <p className="text-sm text-destructive">{bulkError}</p>}
          {bulkRunning && (
            <p className="text-sm text-muted-foreground">
              Building… {bulkOk} / {fleet.selectedMachineNames.size}
            </p>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="outline" onClick={() => setBulkOpen(false)} disabled={bulkRunning}>
              Cancel
            </Button>
            <Button
              type="button"
              onClick={() => void runBulkBuild()}
              disabled={bulkRunning || fleet.selectedMachineNames.size === 0}
            >
              {bulkRunning ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Confirm build'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

function FleetRow({
  row,
  selected,
  checked,
  onToggleCheck,
  onOpen,
}: {
  row: FleetRowView
  selected: boolean
  checked: boolean
  onToggleCheck: () => void
  onOpen: () => void
}) {
  return (
    <tr
      className={`border-b border-border/60 cursor-pointer hover:bg-muted/50 ${
        selected ? 'bg-primary/10' : ''
      }`}
      onClick={onOpen}
    >
      <td className="p-2 align-top" onClick={(e) => e.stopPropagation()}>
        <input
          type="checkbox"
          checked={checked}
          onChange={onToggleCheck}
          className="rounded border-input"
          aria-label={`Select ${row.machine_name}`}
        />
      </td>
      <td className="p-2 align-top">
        <div className="font-medium text-foreground break-all">{row.machine_name}</div>
        <AttentionBadges row={row} />
      </td>
      <td className="p-2 align-top text-right tabular-nums">{row.observation_count}</td>
      <td className="p-2 align-top text-right tabular-nums">
        {(row.drift_rate_recent * 100).toFixed(0)}%
      </td>
    </tr>
  )
}
