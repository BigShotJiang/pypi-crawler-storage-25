'use client'

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Loader2 } from 'lucide-react'

interface PromoteCandidateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  machineName: string
  version: string | null
  loading: boolean
  onConfirm: () => void
  /** When true, show catalog baseline comparison (fleet / three-column flow). */
  showCatalogImpact?: boolean
  /** Short line describing catalog vs candidate delta; null means no catalog baseline. */
  impactSummary?: string | null
  /** e.g. "Machines catalog · v1.0.0" */
  impactBaselineLabel?: string | null
  impactLoading?: boolean
}

export function PromoteCandidateDialog({
  open,
  onOpenChange,
  machineName,
  version,
  loading,
  onConfirm,
  showCatalogImpact = false,
  impactSummary,
  impactBaselineLabel,
  impactLoading,
}: PromoteCandidateDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" showClose>
        <DialogHeader>
          <DialogTitle>Promote candidate to machine</DialogTitle>
          <DialogDescription>
            This validates the inferred config and saves it to the Machines catalog as{' '}
            <span className="font-medium text-foreground">
              {machineName || '—'} v{version || '—'}
            </span>
            . If that name and version already exist, the stored config is replaced.
          </DialogDescription>
        </DialogHeader>
        {showCatalogImpact && (
          <div className="rounded-md border border-border bg-muted/30 px-3 py-2 text-sm">
            <p className="text-xs font-medium text-muted-foreground">Impact vs catalog</p>
            {impactLoading ? (
              <p className="mt-1 text-muted-foreground">Loading baseline…</p>
            ) : impactSummary ? (
              <>
                {impactBaselineLabel ? (
                  <p className="mt-0.5 text-xs text-muted-foreground">{impactBaselineLabel}</p>
                ) : null}
                <p className="mt-1 text-foreground">{impactSummary}</p>
              </>
            ) : (
              <p className="mt-1 text-muted-foreground">
                No matching machine in the catalog — promotion will create or replace the catalog entry
                for this name.
              </p>
            )}
          </div>
        )}
        <DialogFooter className="gap-2 sm:gap-0">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button type="button" onClick={onConfirm} disabled={loading || !version}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Promoting…
              </>
            ) : (
              'Promote'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
