'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { renderBasicMarkdown } from './basicMarkdown'

export interface StateAnnotationDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  machineName: string
  machineVersion: string
  stateName: string
  initialBody: string
  saving: boolean
  deleting: boolean
  onSave: (body: string) => void
  onDelete: () => void
}

export function StateAnnotationDialog({
  open,
  onOpenChange,
  machineName,
  machineVersion,
  stateName,
  initialBody,
  saving,
  deleting,
  onSave,
  onDelete,
}: StateAnnotationDialogProps) {
  const [body, setBody] = useState(initialBody)
  const [mounted, setMounted] = useState(false)

  useEffect(() => setMounted(true), [])

  useEffect(() => {
    if (!open) return
    setBody(initialBody)
  }, [open, initialBody])

  useEffect(() => {
    if (!open) return
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onOpenChange(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onOpenChange])

  const close = useCallback(() => onOpenChange(false), [onOpenChange])

  const canDelete = initialBody.trim().length > 0
  const preview = useMemo(() => renderBasicMarkdown(body), [body])

  if (!open || !mounted || typeof document === 'undefined') return null

  return createPortal(
    <>
      {/* Backdrop: clicking it closes the note */}
      <div
        className="fixed inset-0 z-50 bg-black/60"
        onPointerDown={close}
        aria-hidden
      />

      {/* Panel */}
      <div
        role="dialog"
        aria-modal
        className="fixed left-[50%] top-[50%] z-50 w-full max-w-2xl translate-x-[-50%] translate-y-[-50%] rounded-lg border bg-background p-6 shadow-lg"
        onPointerDown={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h2 className="text-lg font-semibold leading-none tracking-tight">State note</h2>
            <p className="mt-1.5 text-sm text-muted-foreground">
              <span className="font-mono text-xs">
                {machineName}@{machineVersion} &bull; {stateName}
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={close}
            className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body: editor + preview */}
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted-foreground">Edit (basic markdown)</div>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={12}
              className="w-full resize-y rounded-md border bg-background px-3 py-2 text-sm"
              placeholder="- Preconditions&#10;- Failure modes&#10;- Ops checks"
            />
          </div>
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted-foreground">Preview</div>
            <div className="h-[300px] overflow-auto rounded-md border bg-muted/20 px-3 py-2 text-sm">
              {preview}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 gap-2">
          {canDelete ? (
            <Button
              type="button"
              variant="destructive"
              onClick={onDelete}
              disabled={deleting || saving}
            >
              {deleting ? 'Deleting\u2026' : 'Delete note'}
            </Button>
          ) : null}
          <Button type="button" variant="outline" onClick={close} disabled={saving || deleting}>
            Close
          </Button>
          <Button type="button" onClick={() => onSave(body)} disabled={saving || deleting}>
            {saving ? 'Saving\u2026' : 'Save'}
          </Button>
        </div>
      </div>
    </>,
    document.body
  )
}
