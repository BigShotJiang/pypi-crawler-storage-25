'use client'

import { Button } from '@/components/ui/button'
import { DiscoveryCandidatesTable } from '@/components/discovery/DiscoveryCandidatesTable'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { useDiscoveryBaselineMachine } from '@/hooks/useDiscoveryBaselineMachine'
import { diffFsmConfig, summarizeFsmDiffImpact } from '@/lib/fsmDiff'
import type { FSMConfig } from '@/lib/types/fsm'
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react'
import { useLayoutEffect, useMemo, useRef, useState } from 'react'
import { PromoteCandidateDialog } from '@/components/discovery/PromoteCandidateDialog'
import { cn } from '@/lib/utils'
import type { TriplePanelLayoutApi } from '@/components/layout/ResizableTriplePanelLayout'
import { useDiscoveryConfig } from '@/hooks/useDiscoveryConfig'

function railInitialLetter(label: string): string {
  const t = label.trim()
  if (!t) return '?'
  return t.charAt(0).toUpperCase()
}

export interface DiscoveryCandidatesColumnProps {
  api: TriplePanelLayoutApi
  workspace: UseDiscoveryWorkspaceResult
  focusedPinId: string | null
  /** Catalog row id when a pin is focused — refines baseline lookup for promote impact. */
  baselineCatalogMachineId?: string | null
}

export function DiscoveryCandidatesColumn({
  api,
  workspace: d,
  focusedPinId,
  baselineCatalogMachineId = null,
}: DiscoveryCandidatesColumnProps) {
  const isCollapsed = api.isPanelCollapsed
  const [promoteOpen, setPromoteOpen] = useState(false)
  const [promoteTarget, setPromoteTarget] = useState<string | null>(null)
  void focusedPinId
  const { config: discoveryConfig } = useDiscoveryConfig()

  const baseline = useDiscoveryBaselineMachine(d.machineName, {
    catalogMachineId: baselineCatalogMachineId,
  })

  const promoteImpact = useMemo(() => {
    if (!promoteOpen || !promoteTarget) {
      return { loading: false, summary: null as string | null, label: null as string | null }
    }
    const detailMismatch = d.detail?.version !== promoteTarget
    if (baseline.loading || d.loadingDetail || detailMismatch) {
      return { loading: true, summary: null as string | null, label: null as string | null }
    }
    if (!baseline.baselineConfig) {
      return { loading: false, summary: null as string | null, label: null as string | null }
    }
    const cfg = d.detail?.config as FSMConfig | undefined
    if (!cfg) {
      return { loading: true, summary: null as string | null, label: null as string | null }
    }
    const diff = diffFsmConfig(baseline.baselineConfig, cfg)
    return {
      loading: false,
      summary: summarizeFsmDiffImpact(diff),
      label: baseline.baselineVersion
        ? `Machines catalog · ${baseline.baselineVersion}`
        : 'Machines catalog',
    }
  }, [
    promoteOpen,
    promoteTarget,
    baseline.loading,
    baseline.baselineConfig,
    baseline.baselineVersion,
    d.loadingDetail,
    d.detail,
  ])

  const hasFocus = d.machineName.trim().length > 0

  /** Natural width of the New candidate label (measured off-screen) for compress-to-icon behavior. */
  const fullLabelWidthRef = useRef<HTMLDivElement>(null)
  const actionsRowRef = useRef<HTMLDivElement>(null)
  const [minWidthForFullActions, setMinWidthForFullActions] = useState(0)
  const [compressActions, setCompressActions] = useState(false)

  useLayoutEffect(() => {
    let cancelled = false
    const measure = () => {
      const el = fullLabelWidthRef.current
      if (!el || cancelled) return
      const w = el.scrollWidth
      if (w > 0) setMinWidthForFullActions(w)
    }
    measure()
    const id = requestAnimationFrame(measure)
    return () => {
      cancelled = true
      cancelAnimationFrame(id)
    }
  }, [])

  useLayoutEffect(() => {
    const el = actionsRowRef.current
    if (!el || isCollapsed) return
    const threshold =
      minWidthForFullActions > 0 ? minWidthForFullActions + 6 : 200
    const update = () => {
      setCompressActions(el.getBoundingClientRect().width < threshold)
    }
    update()
    const ro = new ResizeObserver(() => update())
    ro.observe(el)
    return () => ro.disconnect()
  }, [isCollapsed, minWidthForFullActions])

  const sortedWorkspaces = useMemo(() => {
    const next = [...d.drafts]
    next.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    return next
  }, [d.drafts])

  const sortedCandidatesCollapsed = useMemo(() => {
    const next = [...d.builtCandidates]
    next.sort((a, b) => {
      const at = new Date(a.created_at).getTime()
      const bt = new Date(b.created_at).getTime()
      return bt - at
    })
    return next
  }, [d.builtCandidates])

  return (
    <div className="flex h-full min-h-0 flex-col bg-background">
      {isCollapsed ? (
        <div className="flex min-h-0 flex-1 flex-col bg-background">
          <div className="flex h-12 min-h-12 shrink-0 items-center justify-center border-b border-border/50 bg-muted/30 px-4 py-0">
            <button
              type="button"
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
              aria-label="Expand panel"
              onClick={() => api.onExpandRequested()}
            >
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
          <div className="flex shrink-0 justify-center border-b border-border/50 px-1 py-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-8 w-8 shrink-0"
              title="New draft workspace"
              aria-label="New candidate"
              disabled={!hasFocus || d.loadingList}
              onClick={() => void d.createDraft()}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex min-h-0 flex-1 flex-col items-center gap-2 overflow-y-auto px-1 py-2">
            {!hasFocus ? (
              <p className="max-w-[4.5rem] text-center text-[10px] leading-tight text-muted-foreground">
                Pick a baseline (left), then create a candidate.
              </p>
            ) : (
              <>
                {sortedWorkspaces.map((ws, draftIdx) => {
                  const draftNum = draftIdx + 1
                  const label = ws.title?.trim() || `Draft ${draftNum}`
                  const active = !d.selectedVersion && d.activeDraftId === ws.id
                  return (
                    <Button
                      key={`ws-${ws.id}`}
                      type="button"
                      variant={active ? 'default' : 'outline'}
                      size="icon"
                      className="h-8 w-8 shrink-0 rounded-full text-xs font-semibold tabular-nums"
                      title={`Draft #${draftNum} · ${ws.id}`}
                      aria-label={`Select draft workspace #${draftNum}`}
                      aria-pressed={active}
                      onClick={() => d.selectDraft(ws.id)}
                    >
                      {draftNum}
                    </Button>
                  )
                })}
                {sortedCandidatesCollapsed.map((c) => {
                  const active = d.selectedVersion === c.version
                  const seq = c.candidate_sequence
                  const initial =
                    typeof seq === 'number' && seq > 0
                      ? String(seq)
                      : railInitialLetter(c.version)
                  return (
                    <Button
                      key={`cand-${c.version}`}
                      type="button"
                      variant={active ? 'default' : 'outline'}
                      size="icon"
                      className="h-8 w-8 shrink-0 rounded-full border-dashed text-xs font-semibold"
                      title={`Built candidate #${seq ?? '—'} · ${c.version}`}
                      aria-label={`Select built candidate #${seq ?? c.version}`}
                      aria-pressed={active}
                      onClick={() => d.selectVersion(c.version)}
                    >
                      {initial}
                    </Button>
                  )
                })}
                {sortedWorkspaces.length === 0 && sortedCandidatesCollapsed.length === 0 ? (
                  <p className="max-w-[4.5rem] text-center text-[10px] leading-tight text-muted-foreground">
                    {d.loadingList ? 'Loading…' : 'No drafts or builds yet.'}
                  </p>
                ) : null}
              </>
            )}
          </div>
        </div>
      ) : (
        <>
      <div
        className={cn(
          'flex h-12 min-h-12 shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-0',
          'justify-between'
        )}
      >
        <div className="relative flex min-w-0 flex-1 items-center justify-between gap-2">
          {/* Measure intrinsic width of full-label toolbar (same classes as expanded buttons). */}
          <div
            className="pointer-events-none absolute -left-[10000px] top-0 flex gap-1 opacity-0"
            aria-hidden
          >
            <div ref={fullLabelWidthRef} className="flex gap-1">
              <Button type="button" size="sm" variant="outline" className="h-8 shrink-0" tabIndex={-1}>
                <Plus className="mr-1.5 h-3.5 w-3.5 shrink-0" />
                <span className="whitespace-nowrap">New candidate</span>
              </Button>
            </div>
          </div>
          <div
            ref={actionsRowRef}
            className="flex min-h-0 min-w-0 flex-1 flex-nowrap items-center gap-1"
          >
            <Button
              type="button"
              size="sm"
              variant="outline"
              title="New draft workspace"
              className={cn('shrink-0', compressActions ? 'h-8 w-8 px-0' : 'h-8')}
              disabled={!hasFocus || d.loadingList}
              onClick={() => void d.createDraft()}
            >
              <Plus className={cn('h-3.5 w-3.5 shrink-0', !compressActions && 'mr-1.5')} />
              {!compressActions && <span className="whitespace-nowrap">New candidate</span>}
            </Button>
          </div>
          <button
            type="button"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
            aria-label="Collapse panel"
            onClick={() => api.onCollapseRequested()}
          >
            <ChevronLeft className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-hidden">
        {!hasFocus ? (
          <p className="p-4 text-sm text-muted-foreground">
            Pin a discovery machine from the left, then use the right panel to choose entity scope and
            preview or build.
          </p>
        ) : (
          <div className="flex h-full min-h-0 flex-col">
            <div className="min-h-0 flex-1 overflow-hidden">
              <DiscoveryCandidatesTable
                embedded
                compactEmbedded
                drafts={d.drafts}
                activeDraftId={d.activeDraftId}
                onSelectDraft={d.selectDraft}
                onDeleteDraft={(id) => void d.deleteDraft(id)}
                builtCandidates={d.builtCandidates}
                selectedVersion={d.selectedVersion}
                loadingList={d.loadingList}
                promoting={d.promoting}
                driftAlertThreshold={discoveryConfig?.drift_alert_threshold}
                driftSevereThreshold={discoveryConfig?.drift_severe_threshold}
                driftMinSample={discoveryConfig?.drift_min_sample}
                lowSampleThreshold={discoveryConfig?.low_sample_threshold}
                onSelectVersion={d.selectVersion}
                onPromoteRequest={(version) => {
                  setPromoteTarget(version)
                  setPromoteOpen(true)
                }}
              />
            </div>
          </div>
        )}
      </div>
        </>
      )}

      <PromoteCandidateDialog
        open={promoteOpen}
        onOpenChange={(open) => {
          setPromoteOpen(open)
          if (!open) setPromoteTarget(null)
        }}
        machineName={d.machineName.trim()}
        version={promoteTarget}
        loading={d.promoting}
        showCatalogImpact
        impactLoading={promoteImpact.loading}
        impactSummary={promoteImpact.summary}
        impactBaselineLabel={promoteImpact.label}
        onConfirm={async () => {
          if (!promoteTarget) return
          try {
            await d.promote(promoteTarget)
            setPromoteOpen(false)
            setPromoteTarget(null)
          } catch {
            /* surfaced in workspace */
          }
        }}
      />
    </div>
  )
}
