'use client'

import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import type { ObservabilityFilters } from './types'

interface ObservabilityFilterBarProps {
  draftFilters: ObservabilityFilters
  onDraftChange: (next: ObservabilityFilters) => void
  onApply: () => void
  onClear: () => void
}

export function ObservabilityFilterBar({
  draftFilters,
  onDraftChange,
  onApply,
  onClear,
}: ObservabilityFilterBarProps) {
  return (
    <div className="mt-4 flex flex-wrap items-end gap-3 rounded-lg border bg-muted/30 p-3">
      <div className="flex flex-col gap-1">
        <Label className="text-xs text-muted-foreground">Machine</Label>
        <input
          type="text"
          placeholder="e.g. order_management"
          className="rounded-md border border-input bg-background px-2 py-1.5 text-sm w-[190px]"
          value={draftFilters.machineName}
          onChange={(e) => onDraftChange({ ...draftFilters, machineName: e.target.value })}
        />
      </div>

      <div className="flex flex-col gap-1">
        <Label className="text-xs text-muted-foreground">Entity ID</Label>
        <input
          type="text"
          placeholder="e.g. order-123"
          className="rounded-md border border-input bg-background px-2 py-1.5 text-sm w-[180px]"
          value={draftFilters.entityId}
          onChange={(e) => onDraftChange({ ...draftFilters, entityId: e.target.value })}
        />
      </div>

      <div className="flex flex-col gap-1">
        <Label className="text-xs text-muted-foreground">Window</Label>
        <select
          className="rounded-md border border-input bg-background px-2 py-1.5 text-sm min-w-[130px]"
          value={String(draftFilters.windowHours)}
          onChange={(e) => onDraftChange({ ...draftFilters, windowHours: Number(e.target.value) })}
        >
          <option value="1">Last 1h</option>
          <option value="6">Last 6h</option>
          <option value="24">Last 24h</option>
          <option value="72">Last 72h</option>
          <option value="168">Last 7d</option>
        </select>
      </div>

      <Button variant="outline" size="sm" onClick={onApply}>Apply</Button>
      <Button variant="ghost" size="sm" onClick={onClear}>Clear</Button>
    </div>
  )
}
