'use client'

interface BarDatum {
  label: string
  value: number
  color?: string
}

interface BarChartProps {
  data: BarDatum[]
  height?: number
  showLabels?: boolean
  className?: string
}

const DEFAULT_COLOR = 'hsl(var(--primary))'
const PADDING_TOP = 24
const PADDING_BOTTOM_NO_LABELS = 8
const PADDING_BOTTOM_LABELS = 32
const PADDING_X = 4
const BAR_GAP = 4

export function BarChart({ data, height = 200, showLabels = true, className }: BarChartProps) {
  if (data.length === 0) {
    return (
      <div className={className}>
        <p className="text-xs text-muted-foreground text-center py-6">No data</p>
      </div>
    )
  }

  const paddingBottom = showLabels ? PADDING_BOTTOM_LABELS : PADDING_BOTTOM_NO_LABELS
  const viewBoxWidth = 400
  const viewBoxHeight = height

  const maxValue = Math.max(...data.map((d) => d.value), 1)

  const chartWidth = viewBoxWidth - PADDING_X * 2
  const chartHeight = viewBoxHeight - PADDING_TOP - paddingBottom

  const barSlotWidth = chartWidth / data.length
  const barWidth = Math.max(barSlotWidth - BAR_GAP, 2)

  return (
    <div className={className}>
      <svg
        viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`}
        preserveAspectRatio="xMidYMid meet"
        width="100%"
        height={height}
        role="img"
        aria-label="Bar chart"
      >
        {data.map((d, idx) => {
          const barHeight = (d.value / maxValue) * chartHeight
          const x = PADDING_X + idx * barSlotWidth + (barSlotWidth - barWidth) / 2
          const y = PADDING_TOP + chartHeight - barHeight
          const fill = d.color ?? DEFAULT_COLOR

          return (
            <g key={`${d.label}-${idx}`}>
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={Math.max(barHeight, 1)}
                rx={2}
                fill={fill}
              />
              {/* Value text above bar */}
              <text
                x={x + barWidth / 2}
                y={y - 4}
                textAnchor="middle"
                className="fill-foreground"
                fontSize={10}
                fontWeight={500}
              >
                {d.value}
              </text>
              {/* Label below bar */}
              {showLabels && (
                <text
                  x={x + barWidth / 2}
                  y={viewBoxHeight - 4}
                  textAnchor="middle"
                  className="fill-muted-foreground"
                  fontSize={8}
                >
                  {d.label.length > 8 ? `${d.label.slice(0, 7)}…` : d.label}
                </text>
              )}
            </g>
          )
        })}
      </svg>
    </div>
  )
}
