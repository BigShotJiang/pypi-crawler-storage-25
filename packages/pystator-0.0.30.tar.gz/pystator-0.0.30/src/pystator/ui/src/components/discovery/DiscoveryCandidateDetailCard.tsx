'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import type { DiscoveryBuiltCandidateResponse } from '@/lib/api'
import { Loader2 } from 'lucide-react'
import type { FSMConfig } from '@/lib/types/fsm'
import { FsmFlowDiagram } from '@/components/fsm-flow'
import { DiscoveryCandidateEdgesTable } from '@/components/discovery/DiscoveryCandidateEdgesTable'
import { Input } from '@/components/ui/input'

function JsonPreview({ value }: { value: unknown }) {
  return (
    <pre className="max-h-64 overflow-auto whitespace-pre-wrap break-words rounded-md border bg-muted/50 p-3 text-xs">
      {JSON.stringify(value, null, 2)}
    </pre>
  )
}

interface DiscoveryCandidateDetailCardProps {
  selectedVersion: string | null
  loadingDetail: boolean
  detail: DiscoveryBuiltCandidateResponse | null
  onSaveEditedCandidate?: (
    config: FSMConfig,
    targetMachineName: string,
    targetVersion?: string
  ) => Promise<void>
}

type CandidateTab = 'diagram' | 'edges' | 'table' | 'raw'

function coerceFsmConfig(value: Record<string, unknown>): FSMConfig {
  const cfg = value as unknown as FSMConfig
  return {
    ...cfg,
    states: Array.isArray(cfg.states) ? cfg.states : [],
    transitions: Array.isArray(cfg.transitions) ? cfg.transitions : [],
  }
}

export function DiscoveryCandidateDetailCard({
  selectedVersion,
  loadingDetail,
  detail,
  onSaveEditedCandidate,
}: DiscoveryCandidateDetailCardProps) {
  const [tab, setTab] = useState<CandidateTab>('diagram')
  const [highlightTransition, setHighlightTransition] = useState<{ source: string; target: string; trigger: string } | null>(null)
  const [draftConfig, setDraftConfig] = useState<FSMConfig | null>(null)
  const [targetMachineName, setTargetMachineName] = useState('')
  const [targetVersion, setTargetVersion] = useState('')
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)

  useEffect(() => {
    if (!detail) {
      setDraftConfig(null)
      return
    }
    const cfg = coerceFsmConfig(detail.config)
    setDraftConfig(cfg)
    setTargetMachineName(
      String((cfg.meta?.machine_name as string | undefined) ?? detail.machine_name ?? '')
    )
    setTargetVersion(
      String((cfg.meta?.version as string | undefined) ?? detail.version ?? '')
    )
  }, [detail])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Candidate detail</CardTitle>
        <CardDescription>
          {selectedVersion
            ? detail
              ? `Candidate #${detail.candidate_sequence} · version ${selectedVersion}`
              : `Version ${selectedVersion}`
            : 'Select a candidate from the table.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loadingDetail ? (
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        ) : detail ? (
          <div className="space-y-3">
            <div className="rounded-md border bg-muted/30 p-3 text-sm text-muted-foreground">
              Inferred edges: <span className="font-medium text-foreground">{detail.edges?.length ?? 0}</span>
              {' · '}
              Status: <span className="font-medium text-foreground">{detail.status}</span>
            </div>

            <div className="flex rounded-lg border border-border/70 bg-background/50 p-0.5" role="tablist" aria-label="Candidate view">
              <button
                type="button"
                role="tab"
                aria-selected={tab === 'diagram'}
                onClick={() => setTab('diagram')}
                className={`inline-flex items-center rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  tab === 'diagram' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Diagram
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={tab === 'edges'}
                onClick={() => setTab('edges')}
                className={`inline-flex items-center rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  tab === 'edges' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Edges
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={tab === 'raw'}
                onClick={() => setTab('raw')}
                className={`inline-flex items-center rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  tab === 'raw' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Raw
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={tab === 'table'}
                onClick={() => setTab('table')}
                className={`inline-flex items-center rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  tab === 'table' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Table edit
              </button>
            </div>

            {tab === 'diagram' ? (
              <div className="h-[420px]">
                <FsmFlowDiagram
                  config={draftConfig ?? coerceFsmConfig(detail.config)}
                  minHeight="100%"
                  showGuards
                  showActions={false}
                  highlightTransition={highlightTransition}
                  opsMetrics={{ enabled: false, metricsByState: {} }}
                />
              </div>
            ) : tab === 'edges' ? (
              <DiscoveryCandidateEdgesTable
                edges={detail.edges ?? []}
                onSelectEdge={(edge) => {
                  setTab('diagram')
                  setHighlightTransition({
                    source: edge.source_state,
                    target: edge.destination_state,
                    trigger: '',
                  })
                }}
              />
            ) : tab === 'table' ? (
              <div className="space-y-3">
                <p className="text-xs text-muted-foreground">
                  Edit states and transitions directly. Diagram tab reflects the draft.
                </p>
                <div className="rounded border p-2">
                  <p className="mb-1 text-xs font-medium">States</p>
                  {(draftConfig?.states ?? []).map((s, idx) => (
                    <div key={`${s.name}-${idx}`} className="mb-1 flex items-center gap-2">
                      <Input
                        value={s.name}
                        onChange={(e) => {
                          const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                          const states = [...(next.states ?? [])]
                          states[idx] = { ...states[idx], name: e.target.value }
                          next.states = states
                          setDraftConfig(next)
                        }}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                          next.states = (next.states ?? []).filter((_, i) => i !== idx)
                          setDraftConfig(next)
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                      next.states = [...(next.states ?? []), { name: 'new_state', type: 'stable' }]
                      setDraftConfig(next)
                    }}
                  >
                    Add state
                  </Button>
                </div>
                <div className="rounded border p-2">
                  <p className="mb-1 text-xs font-medium">Transitions</p>
                  {(draftConfig?.transitions ?? []).map((t, idx) => (
                    <div key={`${t.source}-${t.dest}-${idx}`} className="mb-1 grid grid-cols-3 gap-2">
                      <Input
                        value={Array.isArray(t.source) ? t.source.join(',') : t.source}
                        onChange={(e) => {
                          const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                          const transitions = [...(next.transitions ?? [])]
                          transitions[idx] = { ...transitions[idx], source: e.target.value }
                          next.transitions = transitions
                          setDraftConfig(next)
                        }}
                      />
                      <Input
                        value={t.dest}
                        onChange={(e) => {
                          const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                          const transitions = [...(next.transitions ?? [])]
                          transitions[idx] = { ...transitions[idx], dest: e.target.value }
                          next.transitions = transitions
                          setDraftConfig(next)
                        }}
                      />
                      <div className="flex gap-2">
                        <Input
                          value={t.trigger ?? ''}
                          onChange={(e) => {
                            const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                            const transitions = [...(next.transitions ?? [])]
                            transitions[idx] = { ...transitions[idx], trigger: e.target.value }
                            next.transitions = transitions
                            setDraftConfig(next)
                          }}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                            next.transitions = (next.transitions ?? []).filter((_, i) => i !== idx)
                            setDraftConfig(next)
                          }}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const next = { ...(draftConfig ?? coerceFsmConfig(detail.config)) }
                      next.transitions = [
                        ...(next.transitions ?? []),
                        { source: 'new_state', dest: 'new_state', trigger: 'to_new_state' },
                      ]
                      setDraftConfig(next)
                    }}
                  >
                    Add transition
                  </Button>
                </div>
                <div className="rounded border p-2">
                  <p className="mb-2 text-xs font-medium">Save edited candidate</p>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    <Input
                      value={targetMachineName}
                      onChange={(e) => setTargetMachineName(e.target.value)}
                      placeholder="Target machine name"
                    />
                    <Input
                      value={targetVersion}
                      onChange={(e) => setTargetVersion(e.target.value)}
                      placeholder="Target version (optional)"
                    />
                  </div>
                  {saveError ? <p className="mt-2 text-xs text-red-600">{saveError}</p> : null}
                  <Button
                    type="button"
                    className="mt-2"
                    disabled={!onSaveEditedCandidate || !draftConfig || saving}
                    onClick={async () => {
                      if (!onSaveEditedCandidate || !draftConfig) return
                      setSaving(true)
                      setSaveError(null)
                      try {
                        await onSaveEditedCandidate(
                          draftConfig,
                          targetMachineName,
                          targetVersion || undefined
                        )
                      } catch (e) {
                        setSaveError(e instanceof Error ? e.message : 'Save failed')
                      } finally {
                        setSaving(false)
                      }
                    }}
                  >
                    {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Save as candidate
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <Button type="button" variant="outline" size="sm" onClick={() => navigator.clipboard?.writeText(JSON.stringify(detail.config, null, 2))}>
                  Copy JSON
                </Button>
                <JsonPreview value={draftConfig ?? detail.config} />
              </>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No candidate selected.</p>
        )}
      </CardContent>
    </Card>
  )
}
