'use client'

/**
 * Three horizontally resizable columns (react-resizable-panels).
 * Separator styling matches ResizableWorkspaceLayout (global CSS for [data-separator]).
 */

import { type ReactNode, useCallback, useRef, useState } from 'react'
import { Group, Panel, Separator, type PanelImperativeHandle } from 'react-resizable-panels'
import { cn } from '@/lib/utils'

function pct(n: number): string {
  return String(n)
}

const DEFAULT_SIZES = [18, 26, 56] as const
const DEFAULT_MIN_SIZES = [12, 12, 22] as const
const DEFAULT_COLLAPSED_SIZE = 64
const DEFAULT_COLLAPSE_THRESHOLD = 70
const DEFAULT_COMPACT_THRESHOLD = 220

export type TriplePanelDisplayMode = 'expanded' | 'compact' | 'collapsed'

export interface TriplePanelLayoutApi {
  isPanelCollapsed: boolean
  panelDisplayMode: TriplePanelDisplayMode
  onCollapseRequested: () => void
  onExpandRequested: () => void
}

export interface ResizableTriplePanelLayoutProps {
  /** Prefix for panel group id. */
  groupId: string
  left: ReactNode | ((api: TriplePanelLayoutApi) => ReactNode)
  middle: ReactNode | ((api: TriplePanelLayoutApi) => ReactNode)
  right: ReactNode
  /** Default sizes as percents [left, middle, right], must sum to 100. */
  defaultSizes?: readonly [number, number, number]
  /** Min sizes as percents for each panel. */
  minSizes?: readonly [number, number, number]
  height?: string | 'fill'
  className?: string
  style?: React.CSSProperties
  separatorClassName?: string
  leftClassName?: string
  middleClassName?: string
  rightClassName?: string
  collapsedSize?: number
  collapseThresholdPx?: number
  compactThresholdPx?: number
}

export function ResizableTriplePanelLayout({
  groupId,
  left,
  middle,
  right,
  defaultSizes = DEFAULT_SIZES,
  minSizes = DEFAULT_MIN_SIZES,
  height = 'calc(100vh - 4rem)',
  className,
  style,
  separatorClassName,
  leftClassName,
  middleClassName,
  rightClassName,
  collapsedSize = DEFAULT_COLLAPSED_SIZE,
  collapseThresholdPx = DEFAULT_COLLAPSE_THRESHOLD,
  compactThresholdPx = DEFAULT_COMPACT_THRESHOLD,
}: ResizableTriplePanelLayoutProps) {
  const leftPanelRef = useRef<PanelImperativeHandle | null>(null)
  const middlePanelRef = useRef<PanelImperativeHandle | null>(null)
  const [leftMode, setLeftMode] = useState<TriplePanelDisplayMode>('expanded')
  const [middleMode, setMiddleMode] = useState<TriplePanelDisplayMode>('expanded')

  const isFill = height === 'fill'
  const rootBaseClassName = `flex h-full bg-background ${isFill ? 'flex-1 min-h-0' : ''}`
  const rootClassName = [rootBaseClassName, className].filter(Boolean).join(' ')
  const rootStyle: React.CSSProperties =
    isFill ? (style ?? {}) : { height, overflow: 'hidden', ...(style ?? {}) }

  const separatorClass = [
    'w-1.5 shrink-0 bg-border transition-colors',
    separatorClassName,
  ].filter(Boolean).join(' ')

  const wrap = (extra: string | undefined) =>
    cn('relative flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden', extra)

  const leftApi: TriplePanelLayoutApi = {
    isPanelCollapsed: leftMode === 'collapsed',
    panelDisplayMode: leftMode,
    onCollapseRequested: () => {
      leftPanelRef.current?.collapse()
      setLeftMode('collapsed')
    },
    onExpandRequested: () => {
      leftPanelRef.current?.expand()
      setLeftMode('expanded')
    },
  }

  const middleApi: TriplePanelLayoutApi = {
    isPanelCollapsed: middleMode === 'collapsed',
    panelDisplayMode: middleMode,
    onCollapseRequested: () => {
      middlePanelRef.current?.collapse()
      setMiddleMode('collapsed')
    },
    onExpandRequested: () => {
      middlePanelRef.current?.expand()
      setMiddleMode('expanded')
    },
  }

  const renderPanel = useCallback((node: ReactNode | ((api: TriplePanelLayoutApi) => ReactNode), api: TriplePanelLayoutApi) => {
    if (typeof node === 'function') {
      return node(api)
    }
    return node
  }, [])

  return (
    <div className={rootClassName} style={rootStyle}>
      <Group
        id={`${groupId}-triple-group`}
        orientation="horizontal"
        className="h-full min-h-0 min-w-0 w-full flex-1"
      >
        <Panel
          id={`${groupId}-left`}
          panelRef={leftPanelRef}
          defaultSize={pct(defaultSizes[0])}
          minSize={pct(minSizes[0])}
          collapsible
          collapsedSize={collapsedSize}
          className="flex min-w-0 flex-col"
          onResize={(size) => {
            const px = size.inPixels
            if (px <= collapseThresholdPx) {
              setLeftMode('collapsed')
            } else if (px <= compactThresholdPx) {
              setLeftMode('compact')
            } else {
              setLeftMode('expanded')
            }
          }}
        >
          <div className={wrap(leftClassName)}>{renderPanel(left, leftApi)}</div>
        </Panel>
        <Separator className={separatorClass} />
        <Panel
          id={`${groupId}-middle`}
          panelRef={middlePanelRef}
          defaultSize={pct(defaultSizes[1])}
          minSize={pct(minSizes[1])}
          collapsible
          collapsedSize={collapsedSize}
          className="flex min-w-0 flex-col"
          onResize={(size) => {
            const px = size.inPixels
            if (px <= collapseThresholdPx) {
              setMiddleMode('collapsed')
            } else if (px <= compactThresholdPx) {
              setMiddleMode('compact')
            } else {
              setMiddleMode('expanded')
            }
          }}
        >
          <div className={wrap(middleClassName)}>{renderPanel(middle, middleApi)}</div>
        </Panel>
        <Separator className={separatorClass} />
        <Panel
          id={`${groupId}-right`}
          defaultSize={pct(defaultSizes[2])}
          minSize={pct(minSizes[2])}
          className="flex min-w-0 flex-col"
        >
          <div className={wrap(rightClassName)}>{right}</div>
        </Panel>
      </Group>
    </div>
  )
}
