'use client'

import type { FSMState, FSMTransition, FSMGuard, FSMAction, FSMActionRef } from '@/lib/types/fsm'

export function parseSource(source: string | string[]): string[] {
  if (Array.isArray(source)) return source
  return source.split(',').map((s) => s.trim()).filter(Boolean)
}

export function sourceToString(source: string | string[]): string {
  if (Array.isArray(source)) return source.join(', ')
  return source
}

function actionRefToLabel(ref: FSMActionRef): string {
  return typeof ref === 'string' ? ref : 'name' in ref ? ref.name : JSON.stringify(ref)
}

function arrToLabels(arr: FSMActionRef | FSMActionRef[] | undefined): string[] {
  if (!arr) return []
  const list = Array.isArray(arr) ? arr : [arr]
  return list.map(actionRefToLabel)
}

function formatGuard(guard: FSMGuard): string {
  if (typeof guard === 'string') return guard
  if (guard && typeof guard === 'object') {
    if ('expr' in guard && typeof (guard as { expr: string }).expr === 'string')
      return `expr: ${(guard as { expr: string }).expr}`
    if ('check' in guard && guard.check && typeof guard.check === 'object') {
      const c = guard.check as { field?: string; op?: string; value?: unknown; values?: unknown[] }
      const field = c.field ?? '?'
      const op = c.op ?? '?'
      if (c.values != null) return `check: ${field} ${op} [...]`
      return `check: ${field} ${op} ${String(c.value ?? '')}`
    }
  }
  return '[guard]'
}

function formatAction(action: FSMAction): string {
  if (typeof action === 'string') return action
  if (action && typeof action === 'object') {
    if ('name' in action && typeof (action as { name: string }).name === 'string') {
      const a = action as { name: string; params?: Record<string, unknown> }
      return a.name
    }
    if ('set' in action && action.set != null) return 'set(...)'
    if ('timestamp' in action && action.timestamp != null) return `timestamp(${String(action.timestamp)})`
    if ('increment' in action && action.increment != null) return `increment(${String(action.increment)})`
    if ('decrement' in action && action.decrement != null) return `decrement(${String(action.decrement)})`
    if ('append' in action && action.append != null) {
      const a = action.append as { field?: string; value?: unknown }
      return a?.field != null ? `append(${a.field}, ...)` : 'append(...)'
    }
    if ('clear' in action && action.clear != null) return `clear(${String(action.clear)})`
  }
  return '[action]'
}

function formatDelay(delay: number | string): string {
  if (typeof delay === 'string') return delay
  if (delay >= 3600000) return `${delay / 3600000}h`
  if (delay >= 60000) return `${delay / 60000}m`
  if (delay >= 1000) return `${delay / 1000}s`
  return `${delay}ms`
}

function guardsToLabels(guards: FSMGuard | FSMGuard[] | undefined): string[] {
  if (!guards) return []
  const arr = Array.isArray(guards) ? guards : [guards]
  return arr.map(formatGuard)
}

function actionsToLabels(actions: FSMAction | FSMAction[] | undefined): string[] {
  if (!actions) return []
  const arr = Array.isArray(actions) ? actions : [actions]
  return arr.map(formatAction)
}

export function TransitionDetails({ t }: { t: FSMTransition }) {
  const g = guardsToLabels(t.guards)
  const a = actionsToLabels(t.actions)
  const hasGuards = g.length > 0
  const hasActions = a.length > 0
  const hasDesc = !!t.description?.trim()
  const hasDelay = t.after !== undefined && t.after !== null
  const hasRegion = !!t.region

  if (!hasGuards && !hasActions && !hasDesc && !hasDelay && !hasRegion) return null

  return (
    <div className="mt-1.5 space-y-1 text-xs">
      {hasGuards && (
        <div>
          <span className="font-medium text-foreground/80">Guards:</span>{' '}
          <span className="flex flex-wrap gap-1 inline">
            {g.map((x, i) => (
              <span key={i} className="inline-flex items-center px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-200">
                [ {x} ]
              </span>
            ))}
          </span>
        </div>
      )}
      {hasActions && (
        <div>
          <span className="font-medium text-foreground/80">Actions:</span>{' '}
          <span className="flex flex-wrap gap-1 inline">
            {a.map((x, i) => (
              <span key={i} className="inline-flex items-center px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200">
                {x}
              </span>
            ))}
          </span>
        </div>
      )}
      {hasDelay && (
        <div>
          <span className="font-medium text-foreground/80">Delay:</span>{' '}
          <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-200">
            ⏱ {formatDelay(t.after!)}
          </span>
        </div>
      )}
      {hasRegion && (
        <div>
          <span className="font-medium text-foreground/80">Region:</span>{' '}
          <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-200">
            @{t.region}
          </span>
        </div>
      )}
      {hasDesc && (
        <div>
          <span className="font-medium text-foreground/80">Description:</span> {t.description}
        </div>
      )}
    </div>
  )
}

function getContextKeys(metadata: Record<string, unknown> | undefined): string[] {
  const raw = metadata?.context_keys
  if (!Array.isArray(raw)) return []
  return raw.filter((x): x is string => typeof x === 'string')
}

export function StateBadges({ s }: { s: FSMState }) {
  const enter = arrToLabels(s.on_enter)
  const exit = arrToLabels(s.on_exit)
  const timeout = s.timeout
  const hasParent = !!s.parent
  const hasInitialChild = !!s.initial_child
  const isParallel = s.type === 'parallel'
  const hasRegions = s.regions && s.regions.length > 0
  const contextKeys = getContextKeys(s.metadata)
  const hasContextKeys = contextKeys.length > 0

  if (enter.length === 0 && exit.length === 0 && !timeout && !hasParent && !hasInitialChild && !hasRegions && !hasContextKeys) return null

  return (
    <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-xs text-muted-foreground">
      {/* Hierarchy info */}
      {hasParent && (
        <span>
          <span className="font-medium text-foreground/80">parent:</span>{' '}
          <span className="inline-flex items-center px-1 py-0.5 rounded bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
            ↳ {s.parent}
          </span>
        </span>
      )}
      {hasInitialChild && (
        <span>
          <span className="font-medium text-foreground/80">initial:</span>{' '}
          <span className="inline-flex items-center px-1 py-0.5 rounded bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
            → {s.initial_child}
          </span>
        </span>
      )}

      {/* Parallel state regions */}
      {isParallel && hasRegions && (
        <span>
          <span className="font-medium text-foreground/80">regions:</span>{' '}
          <span className="inline-flex flex-wrap gap-1">
            {s.regions!.map((r) => (
              <span key={r.name} className="inline-flex items-center px-1 py-0.5 rounded bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/30 dark:text-fuchsia-300">
                ⊞ {r.name}:{r.initial}
              </span>
            ))}
          </span>
        </span>
      )}

      {/* Actions */}
      {enter.length > 0 && (
        <span><span className="font-medium text-foreground/80">on_enter:</span> {enter.join(', ')}</span>
      )}
      {exit.length > 0 && (
        <span><span className="font-medium text-foreground/80">on_exit:</span> {exit.join(', ')}</span>
      )}

      {/* Timeout */}
      {timeout && (
        <span><span className="font-medium text-foreground/80">timeout:</span> {timeout.seconds}s → {timeout.destination}</span>
      )}

      {/* State variables (reference metadata) */}
      {hasContextKeys && (
        <span>
          <span className="font-medium text-foreground/80">State variables:</span>{' '}
          <span className="inline-flex flex-wrap gap-1">
            {contextKeys.map((key) => (
              <span
                key={key}
                className="inline-flex items-center px-1 py-0.5 rounded bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300"
              >
                {key}
              </span>
            ))}
          </span>
        </span>
      )}
    </div>
  )
}
