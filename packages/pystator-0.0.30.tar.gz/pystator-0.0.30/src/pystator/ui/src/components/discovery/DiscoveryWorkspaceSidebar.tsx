'use client'

import { ChevronLeft, ChevronRight } from 'lucide-react'
import { DiscoveryFleetIndexPanel } from '@/components/discovery/DiscoveryFleetIndexPanel'
import type { SidebarLayoutApi } from '@/components/layout'
import type { UseDiscoveryFleetIndexResult } from '@/hooks/useDiscoveryFleetIndex'
import { cn } from '@/lib/utils'

export interface DiscoveryWorkspaceSidebarProps {
  api: SidebarLayoutApi
  fleet: UseDiscoveryFleetIndexResult
  workspaceMachineName: string
  onOpenMachine: (name: string) => void | Promise<void>
}

/**
 * Left rail for `/discovery/`: fleet index plus collapse control.
 * Used with {@link ResizableWorkspaceLayout} (resizable drag handle, same defaults as Workspace).
 */
export function DiscoveryWorkspaceSidebar({
  api,
  fleet,
  workspaceMachineName,
  onOpenMachine,
}: DiscoveryWorkspaceSidebarProps) {
  const { isPanelCollapsed, sidebarDisplayMode, onCollapseRequested, onExpandRequested } = api
  const isCompact = sidebarDisplayMode === 'compact'
  const showLabels = !isPanelCollapsed && !isCompact

  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <div
        className={cn(
          'flex shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-3',
          isPanelCollapsed ? 'justify-center' : 'justify-between'
        )}
      >
        {showLabels && (
          <span className="truncate px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Fleet
          </span>
        )}
        <button
          type="button"
          onClick={() => {
            if (isPanelCollapsed) {
              onExpandRequested()
            } else {
              onCollapseRequested()
            }
          }}
          className="shrink-0 rounded-md p-1.5 transition-colors hover:bg-muted"
          aria-label={isPanelCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isPanelCollapsed ? (
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronLeft className="h-4 w-4 text-muted-foreground" />
          )}
        </button>
      </div>

      <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
        {!isPanelCollapsed && (
          <DiscoveryFleetIndexPanel
            variant="sidebarRail"
            fleet={fleet}
            workspaceMachineName={workspaceMachineName}
            onOpenMachine={onOpenMachine}
          />
        )}
      </div>
    </div>
  )
}
