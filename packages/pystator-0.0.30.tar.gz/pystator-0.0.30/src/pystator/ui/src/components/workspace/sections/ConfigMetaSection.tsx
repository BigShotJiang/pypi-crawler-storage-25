'use client'

import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import type { FSMConfig } from '@/lib/types/fsm'
import type { ValidationResult } from '@/stores/workspace'
import { CheckCircle2, XCircle } from 'lucide-react'

export interface ConfigMetaSectionProps {
  config: FSMConfig
  validationResult: ValidationResult | null
  error: Error | null
  validating: boolean
  setMeta: (field: 'machine_name' | 'version', value: string) => void
  updateConfig: (updater: (c: FSMConfig) => FSMConfig) => void
  runValidate: () => void
}

export function ConfigMetaSection({
  config,
  validationResult,
  error,
  validating,
  setMeta,
  updateConfig,
  runValidate,
}: ConfigMetaSectionProps) {
  return (
    <div className="space-y-3">
      {error && <ErrorDisplay error={error} className="mt-1" />}
      <div className="grid grid-cols-1 gap-2">
        <div className="space-y-1">
          <div className="flex flex-row items-center justify-between gap-2">
            <Label className="text-xs">Machine name</Label>
            {validationResult && (
              <span
                className={`inline-flex items-center gap-1 shrink-0 text-xs font-medium ${
                  validationResult.valid ? 'text-emerald-600' : 'text-destructive'
                }`}
                title={validationResult.valid ? 'Config is valid' : validationResult.errors.join('; ')}
              >
                {validationResult.valid ? (
                  <><CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" /> Valid</>
                ) : (
                  <><XCircle className="h-3 w-3" /> Invalid</>
                )}
              </span>
            )}
          </div>
          <Input
            className="h-8 text-sm"
            value={config.meta?.machine_name ?? ''}
            onChange={(e) => setMeta('machine_name', e.target.value)}
            placeholder="my_fsm"
          />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Version</Label>
          <Input
            className="h-8 text-sm"
            value={config.meta?.version ?? ''}
            onChange={(e) => setMeta('version', e.target.value)}
            placeholder="1.0.0"
          />
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="meta_strict_mode"
            checked={config.meta?.strict_mode ?? false}
            onChange={(e) =>
              updateConfig((c) => ({
                ...c,
                meta: { ...c.meta, strict_mode: e.target.checked },
              }))
            }
            className="rounded border-input"
          />
          <Label htmlFor="meta_strict_mode" className="text-xs font-normal cursor-pointer">Strict mode</Label>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="meta_validate_context"
            checked={config.meta?.validate_context ?? false}
            onChange={(e) =>
              updateConfig((c) => ({
                ...c,
                meta: { ...c.meta, validate_context: e.target.checked },
              }))
            }
            className="rounded border-input"
          />
          <Label htmlFor="meta_validate_context" className="text-xs font-normal cursor-pointer" title="When enabled, context is validated against state_variables (required keys, types) before each transition.">
            Validate context
          </Label>
        </div>
      </div>
      {validationResult && !validationResult.valid && validationResult.errors.length > 0 && (
        <ul className="list-disc list-inside text-xs text-destructive mt-1 space-y-0.5">
          {validationResult.errors.map((err, i) => (
            <li key={i}>{err}</li>
          ))}
        </ul>
      )}
      <Button size="sm" className="w-full" onClick={runValidate} disabled={validating}>
        {validating ? 'Validating...' : 'Validate'}
      </Button>
    </div>
  )
}
