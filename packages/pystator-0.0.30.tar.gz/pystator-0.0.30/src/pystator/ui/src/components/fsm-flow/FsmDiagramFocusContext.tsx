'use client'

/**
 * Single place for "what the user emphasized" on the FSM React Flow diagram:
 * a clicked edge label, or a clicked node (all incident edge labels lift).
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'

export interface FsmDiagramFocusValue {
  focusedEdgeId: string | null
  focusedEdgeSourceId: string | null
  focusedEdgeTargetId: string | null
  focusedNodeId: string | null
  requestFocusEdgeLabel: (edgeId: string, endpoints?: { sourceId: string; targetId: string }) => void
  requestFocusNode: (nodeId: string) => void
  clearFocus: () => void
}

const FsmDiagramFocusContext = createContext<FsmDiagramFocusValue | null>(null)

export interface FsmDiagramFocusProviderProps {
  children: ReactNode
  /** When this identity changes, all focus is cleared (e.g. rebuilt edge list). */
  resetSignal?: unknown
}

export function FsmDiagramFocusProvider({ children, resetSignal }: FsmDiagramFocusProviderProps) {
  const [focusedEdgeId, setFocusedEdgeId] = useState<string | null>(null)
  const [focusedEdgeSourceId, setFocusedEdgeSourceId] = useState<string | null>(null)
  const [focusedEdgeTargetId, setFocusedEdgeTargetId] = useState<string | null>(null)
  const [focusedNodeId, setFocusedNodeId] = useState<string | null>(null)

  useEffect(() => {
    setFocusedEdgeId(null)
    setFocusedEdgeSourceId(null)
    setFocusedEdgeTargetId(null)
    setFocusedNodeId(null)
  }, [resetSignal])

  const requestFocusEdgeLabel = useCallback((edgeId: string, endpoints?: { sourceId: string; targetId: string }) => {
    setFocusedNodeId(null)
    setFocusedEdgeId(edgeId)
    setFocusedEdgeSourceId(endpoints?.sourceId ?? null)
    setFocusedEdgeTargetId(endpoints?.targetId ?? null)
  }, [])

  const requestFocusNode = useCallback((nodeId: string) => {
    setFocusedEdgeId(null)
    setFocusedEdgeSourceId(null)
    setFocusedEdgeTargetId(null)
    setFocusedNodeId(nodeId)
  }, [])

  const clearFocus = useCallback(() => {
    setFocusedEdgeId(null)
    setFocusedEdgeSourceId(null)
    setFocusedEdgeTargetId(null)
    setFocusedNodeId(null)
  }, [])

  const value = useMemo<FsmDiagramFocusValue>(
    () => ({
      focusedEdgeId,
      focusedEdgeSourceId,
      focusedEdgeTargetId,
      focusedNodeId,
      requestFocusEdgeLabel,
      requestFocusNode,
      clearFocus,
    }),
    [focusedEdgeId, focusedEdgeSourceId, focusedEdgeTargetId, focusedNodeId, requestFocusEdgeLabel, requestFocusNode, clearFocus]
  )

  return <FsmDiagramFocusContext.Provider value={value}>{children}</FsmDiagramFocusContext.Provider>
}

/** Safe without a provider: no lift, no-ops. */
export function useFsmDiagramFocus(): FsmDiagramFocusValue {
  const ctx = useContext(FsmDiagramFocusContext)
  if (ctx) return ctx
  return {
    focusedEdgeId: null,
    focusedEdgeSourceId: null,
    focusedEdgeTargetId: null,
    focusedNodeId: null,
    requestFocusEdgeLabel: () => {},
    requestFocusNode: () => {},
    clearFocus: () => {},
  }
}
