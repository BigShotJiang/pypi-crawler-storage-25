'use client'

import { useMemo } from 'react'
import DataTable, { type Column } from './DataTable'
import type { FSMActionDefinition, FSMGuardDefinition } from '@/lib/types/fsm'

interface ActionGuardTableProps {
  actions: FSMActionDefinition[]
  guards: FSMGuardDefinition[]
  onActionsChange: (actions: FSMActionDefinition[]) => void
  onGuardsChange: (guards: FSMGuardDefinition[]) => void
}

export default function ActionGuardTable({
  actions,
  guards,
  onActionsChange,
  onGuardsChange,
}: ActionGuardTableProps) {
  const actionColumns: Column<FSMActionDefinition>[] = useMemo(
    () => [
      {
        key: 'name',
        header: 'Name',
        width: '180px',
        accessor: (r) => r.name,
        editor: 'text',
        onChange: (r, v) => ({ ...r, name: String(v) }),
        required: true,
      },
      {
        key: 'description',
        header: 'Description',
        accessor: (r) => r.description ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, description: String(v) || undefined }),
      },
      {
        key: 'parameters',
        header: 'Parameters',
        accessor: (r) => r.parameters ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, parameters: String(v) || undefined }),
      },
    ],
    [],
  )

  const guardColumns: Column<FSMGuardDefinition>[] = useMemo(
    () => [
      {
        key: 'name',
        header: 'Name',
        width: '180px',
        accessor: (r) => r.name,
        editor: 'text',
        onChange: (r, v) => ({ ...r, name: String(v) }),
        required: true,
      },
      {
        key: 'description',
        header: 'Description',
        accessor: (r) => r.description ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, description: String(v) || undefined }),
      },
      {
        key: 'expression',
        header: 'Expression',
        accessor: (r) => r.expression ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, expression: String(v) || undefined }),
      },
    ],
    [],
  )

  return (
    <div className="space-y-8">
      <section>
        <h3 className="text-sm font-semibold mb-3">Action definitions</h3>
        <DataTable<FSMActionDefinition>
          columns={actionColumns}
          rows={actions}
          onRowsChange={onActionsChange}
          rowKey={(r) => r.name || `action-${actions.indexOf(r)}`}
          onAddRow={() => ({ name: `action_${actions.length + 1}` })}
          emptyMessage="No actions defined."
          addLabel="Add action"
        />
      </section>
      <section>
        <h3 className="text-sm font-semibold mb-3">Guard definitions</h3>
        <DataTable<FSMGuardDefinition>
          columns={guardColumns}
          rows={guards}
          onRowsChange={onGuardsChange}
          rowKey={(r) => r.name || `guard-${guards.indexOf(r)}`}
          onAddRow={() => ({ name: `guard_${guards.length + 1}` })}
          emptyMessage="No guards defined."
          addLabel="Add guard"
        />
      </section>
    </div>
  )
}
