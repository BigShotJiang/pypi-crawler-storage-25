'use client'

import { useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import type { InferredEdgeApiItem } from '@/lib/api'

type SortKey = 'confidence_desc' | 'support_desc' | 'entities_desc'

interface DiscoveryCandidateEdgesTableProps {
  edges: InferredEdgeApiItem[]
  onSelectEdge?: (edge: InferredEdgeApiItem) => void
}

export function DiscoveryCandidateEdgesTable({ edges, onSelectEdge }: DiscoveryCandidateEdgesTableProps) {
  const [minConfidence, setMinConfidence] = useState(0.5)
  const [sortBy, setSortBy] = useState<SortKey>('confidence_desc')

  const filtered = useMemo(() => {
    const next = edges.filter((e) => (e.confidence ?? 0) >= minConfidence)
    next.sort((a, b) => {
      if (sortBy === 'support_desc') return (b.count ?? 0) - (a.count ?? 0)
      if (sortBy === 'entities_desc') return (b.unique_entities ?? 0) - (a.unique_entities ?? 0)
      return (b.confidence ?? 0) - (a.confidence ?? 0)
    })
    return next
  }, [edges, minConfidence, sortBy])

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <label htmlFor="edge-min-confidence" className="text-xs text-muted-foreground">
            Min confidence
          </label>
          <input
            id="edge-min-confidence"
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={minConfidence}
            onChange={(e) => setMinConfidence(parseFloat(e.target.value))}
          />
          <span className="text-xs font-mono text-muted-foreground">{minConfidence.toFixed(2)}</span>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="edge-sort" className="text-xs text-muted-foreground">
            Sort
          </label>
          <select
            id="edge-sort"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortKey)}
            className="rounded-md border border-input bg-background px-2 py-1 text-xs"
          >
            <option value="confidence_desc">Confidence</option>
            <option value="support_desc">Support (count)</option>
            <option value="entities_desc">Unique entities</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground">No edges meet the current confidence threshold.</p>
      ) : (
        <div className="max-h-72 overflow-auto rounded-md border text-sm">
          <table className="w-full">
            <thead className="sticky top-0 bg-muted/80 backdrop-blur text-left text-xs">
              <tr className="border-b">
                <th className="p-2 font-medium">Source → Dest</th>
                <th className="p-2 font-medium">Count</th>
                <th className="p-2 font-medium">Entities</th>
                <th className="p-2 font-medium">Confidence</th>
                <th className="p-2 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((e, idx) => (
                <tr key={`${e.source_state}-${e.destination_state}-${idx}`} className="border-b hover:bg-muted/50">
                  <td className="p-2 font-mono text-xs">{e.source_state} → {e.destination_state}</td>
                  <td className="p-2 font-mono text-xs">{e.count}</td>
                  <td className="p-2 font-mono text-xs">{e.unique_entities}</td>
                  <td className="p-2 font-mono text-xs">{(e.confidence ?? 0).toFixed(2)}</td>
                  <td className="p-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => onSelectEdge?.(e)}
                    >
                      Highlight
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
