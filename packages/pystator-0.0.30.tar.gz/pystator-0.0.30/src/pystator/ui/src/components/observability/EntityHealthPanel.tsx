'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  getEntityHealth,
  getApiErrorMessage,
  type EntityHealthResponse,
} from '@/lib/api'
import { AlertTriangle } from 'lucide-react'

const STATE_COLORS = [
  'bg-blue-500',
  'bg-emerald-500',
  'bg-amber-500',
  'bg-purple-500',
  'bg-rose-500',
  'bg-cyan-500',
  'bg-orange-500',
  'bg-indigo-500',
  'bg-teal-500',
  'bg-pink-500',
]

interface EntityHealthPanelProps {
  windowHours: number
  machineName?: string
  onEntityClick: (entityId: string) => void
}

export function EntityHealthPanel({ windowHours, machineName, onEntityClick }: EntityHealthPanelProps) {
  const [data, setData] = useState<EntityHealthResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getEntityHealth({
        window_hours: windowHours,
        machine_name: machineName || undefined,
      })
      setData(res)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load entity health'))
    } finally {
      setLoading(false)
    }
  }, [windowHours, machineName])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  if (loading && !data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Entity Health</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground py-8 text-center">Loading entity health data...</p>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Entity Health</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-destructive py-4 text-center">{error}</p>
        </CardContent>
      </Card>
    )
  }

  if (!data) return null

  const { status_distribution, state_distribution, machine_distribution, top_failing_entities, terminal_rate, total_entities } = data
  const terminalPct = (terminal_rate * 100).toFixed(1)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Entity Health</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Status counts */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-lg border p-3 text-center">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span className="text-xs text-muted-foreground uppercase tracking-wider">Active</span>
            </div>
            <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
              {status_distribution.active}
            </p>
          </div>
          <div className="rounded-lg border p-3 text-center">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <span className="h-2 w-2 rounded-full bg-amber-500" />
              <span className="text-xs text-muted-foreground uppercase tracking-wider">Archived</span>
            </div>
            <p className="text-lg font-semibold text-amber-600 dark:text-amber-400">
              {status_distribution.archived}
            </p>
          </div>
          <div className="rounded-lg border p-3 text-center">
            <div className="flex items-center justify-center gap-1.5 mb-1">
              <span className="h-2 w-2 rounded-full bg-red-500" />
              <span className="text-xs text-muted-foreground uppercase tracking-wider">Deleted</span>
            </div>
            <p className="text-lg font-semibold text-red-600 dark:text-red-400">
              {status_distribution.deleted}
            </p>
          </div>
        </div>

        {/* State distribution bar */}
        {state_distribution.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
              State Distribution
            </p>
            <div className="flex h-4 rounded-full overflow-hidden bg-muted">
              {state_distribution.map((item, idx) => (
                <div
                  key={item.state}
                  className={`${STATE_COLORS[idx % STATE_COLORS.length]} transition-all`}
                  style={{ width: `${Math.max(item.percentage, 1)}%` }}
                  title={`${item.state}: ${item.count} (${item.percentage.toFixed(1)}%)`}
                />
              ))}
            </div>
            <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
              {state_distribution.map((item, idx) => (
                <span key={item.state} className="flex items-center gap-1 text-xs text-muted-foreground">
                  <span className={`h-2 w-2 rounded-full ${STATE_COLORS[idx % STATE_COLORS.length]}`} />
                  {item.state} ({item.count})
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Machine breakdown */}
        {machine_distribution.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
              Machines
            </p>
            <div className="space-y-1">
              {machine_distribution.map((item) => (
                <div
                  key={item.machine_name}
                  className="flex items-center justify-between text-sm px-2 py-1 rounded hover:bg-muted/30"
                >
                  <span className="font-mono text-xs">{item.machine_name}</span>
                  <span className="text-muted-foreground text-xs">{item.count}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Terminal rate */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Terminal Rate</p>
            <p className="text-xs font-medium text-foreground">{terminalPct}%</p>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: `${Math.min(terminal_rate * 100, 100)}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">{total_entities} total entities</p>
        </div>

        {/* Top failing entities */}
        {top_failing_entities.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <AlertTriangle className="h-3.5 w-3.5" />
              Top Failing Entities
            </p>
            <div className="rounded-md border overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left px-3 py-1.5 text-xs font-medium text-muted-foreground">Entity ID</th>
                    <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Failures</th>
                    <th className="text-right px-3 py-1.5 text-xs font-medium text-muted-foreground">Last Failure</th>
                  </tr>
                </thead>
                <tbody>
                  {top_failing_entities.map((item) => (
                    <tr key={item.entity_id} className="border-b last:border-0 hover:bg-muted/20">
                      <td className="px-3 py-1.5">
                        <button
                          type="button"
                          className="text-primary hover:underline font-mono text-xs"
                          onClick={() => onEntityClick(item.entity_id)}
                        >
                          {item.entity_id}
                        </button>
                      </td>
                      <td className="text-right px-3 py-1.5 text-xs font-medium text-destructive">
                        {item.failure_count}
                      </td>
                      <td className="text-right px-3 py-1.5 text-xs text-muted-foreground">
                        {new Date(item.last_failure_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
