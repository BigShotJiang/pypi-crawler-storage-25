'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import type { EntityState } from '@/lib/api'
import { BarChart3, ChevronDown, ChevronUp } from 'lucide-react'

interface EntityOverviewPanelProps {
  entities: EntityState[]
  total: number
  /** When true, the collapsible overview starts open. */
  defaultExpanded?: boolean
}

interface StatusCounts {
  active: number
  archived: number
  deleted: number
}

interface WorkflowCounts {
  active: number
  complete: number
  failed: number
}

interface StateDistribution {
  state: string
  count: number
  percentage: number
  color: string
}

interface MachineBreakdown {
  machine: string
  count: number
}

const STATE_COLORS = [
  'bg-blue-500',
  'bg-emerald-500',
  'bg-amber-500',
  'bg-purple-500',
  'bg-rose-500',
  'bg-cyan-500',
  'bg-orange-500',
  'bg-indigo-500',
  'bg-teal-500',
  'bg-pink-500',
]

export default function EntityOverviewPanel({
  entities,
  total,
  defaultExpanded = false,
}: EntityOverviewPanelProps) {
  const [expanded, setExpanded] = useState(defaultExpanded)

  const statusCounts = useMemo<StatusCounts>(() => {
    const counts: StatusCounts = { active: 0, archived: 0, deleted: 0 }
    for (const ent of entities) {
      if (ent.status === 'active') counts.active++
      else if (ent.status === 'archived') counts.archived++
      else if (ent.status === 'deleted') counts.deleted++
    }
    return counts
  }, [entities])

  const workflowCounts = useMemo<WorkflowCounts>(() => {
    const counts: WorkflowCounts = { active: 0, complete: 0, failed: 0 }
    for (const ent of entities) {
      const ws = ent.workflow_status ?? 'active'
      if (ws === 'complete') counts.complete++
      else if (ws === 'failed') counts.failed++
      else counts.active++
    }
    return counts
  }, [entities])

  const stateDistribution = useMemo<StateDistribution[]>(() => {
    const map = new Map<string, number>()
    for (const ent of entities) {
      map.set(ent.current_state, (map.get(ent.current_state) ?? 0) + 1)
    }
    const totalCount = entities.length || 1
    return Array.from(map.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([state, count], idx) => ({
        state,
        count,
        percentage: (count / totalCount) * 100,
        color: STATE_COLORS[idx % STATE_COLORS.length],
      }))
  }, [entities])

  const machineBreakdown = useMemo<MachineBreakdown[]>(() => {
    const map = new Map<string, number>()
    for (const ent of entities) {
      const name = ent.machine_name ?? 'unknown'
      map.set(name, (map.get(name) ?? 0) + 1)
    }
    return Array.from(map.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([machine, count]) => ({ machine, count }))
  }, [entities])

  return (
    <Card>
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center justify-between px-4 py-3 text-sm font-medium hover:bg-muted/30 transition-colors rounded-t-lg"
      >
        <span className="flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-muted-foreground" />
          Overview
          <span className="text-muted-foreground font-normal">({total} total)</span>
        </span>
        {expanded ? (
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        )}
      </button>

      {expanded && (
        <CardContent className="pt-0 pb-4 space-y-4">
          {/* Status counts */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Active</span>
              </div>
              <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
                {statusCounts.active}
              </p>
            </div>
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-amber-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Archived</span>
              </div>
              <p className="text-lg font-semibold text-amber-600 dark:text-amber-400">
                {statusCounts.archived}
              </p>
            </div>
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-red-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Deleted</span>
              </div>
              <p className="text-lg font-semibold text-red-600 dark:text-red-400">
                {statusCounts.deleted}
              </p>
            </div>
          </div>

          <p className="text-xs text-muted-foreground uppercase tracking-wider">Workflow (FSM)</p>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-sky-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">In progress</span>
              </div>
              <p className="text-lg font-semibold text-sky-600 dark:text-sky-400">
                {workflowCounts.active}
              </p>
            </div>
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Complete</span>
              </div>
              <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
                {workflowCounts.complete}
              </p>
            </div>
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-red-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Failed</span>
              </div>
              <p className="text-lg font-semibold text-red-600 dark:text-red-400">
                {workflowCounts.failed}
              </p>
            </div>
          </div>

          {/* State distribution bar */}
          {stateDistribution.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
                State Distribution
              </p>
              <div className="flex h-4 rounded-full overflow-hidden bg-muted">
                {stateDistribution.map((item) => (
                  <div
                    key={item.state}
                    className={`${item.color} transition-all`}
                    style={{ width: `${Math.max(item.percentage, 1)}%` }}
                    title={`${item.state}: ${item.count} (${item.percentage.toFixed(1)}%)`}
                  />
                ))}
              </div>
              <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
                {stateDistribution.map((item) => (
                  <span key={item.state} className="flex items-center gap-1 text-xs text-muted-foreground">
                    <span className={`h-2 w-2 rounded-full ${item.color}`} />
                    {item.state} ({item.count})
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Machine breakdown */}
          {machineBreakdown.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
                Machines
              </p>
              <div className="space-y-1">
                {machineBreakdown.map((item) => (
                  <div
                    key={item.machine}
                    className="flex items-center justify-between text-sm px-2 py-1 rounded hover:bg-muted/30"
                  >
                    <span className="font-mono text-xs">{item.machine}</span>
                    <span className="text-muted-foreground text-xs">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  )
}
