'use client'

import { useState } from 'react'
import { X, CheckCircle2, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { createMachine, validateConfig } from '@/lib/api'
import { parseFsmConfig, type ConfigFormat } from '@/lib/fsmConfigParse'
import { readFileAsText, formatFromFilename, isAllowedFsmConfigFile } from '@/lib/fsmFileImport'

interface MachineUploadModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export default function MachineUploadModal({
  isOpen,
  onClose,
  onSuccess,
}: MachineUploadModalProps) {
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [progress, setProgress] = useState('')

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return

    if (!isAllowedFsmConfigFile(file.name)) {
      setError('Please upload a YAML or JSON file (.yaml, .yml, or .json)')
      return
    }

    try {
      setUploading(true)
      setError(null)
      setSuccess(false)
      setProgress('Reading file...')

      const raw = await readFileAsText(file)
      setProgress('Parsing...')
      const format = formatFromFilename(file.name) as ConfigFormat
      const parsed = parseFsmConfig(raw, format)

      if ('error' in parsed) {
        setError(parsed.error)
        return
      }

      setProgress('Validating...')
      await validateConfig(parsed.config)

      setProgress('Creating machine...')
      await createMachine(parsed.config)

      setProgress('Complete!')
      setSuccess(true)
      setTimeout(() => {
        onSuccess()
        handleClose()
      }, 1200)
    } catch (err) {
      const ex = err as { message?: string; response?: { detail?: string } }
      const msg =
        typeof (ex.response as { detail?: string })?.detail === 'string'
          ? (ex.response as { detail: string }).detail
          : ex.message ?? 'Upload failed'
      setError(msg)
    } finally {
      setUploading(false)
    }
  }

  const handleClose = () => {
    setError(null)
    setSuccess(false)
    setProgress('')
    onClose()
  }

  if (!isOpen) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
      onClick={handleClose}
    >
      <div
        className="bg-background rounded-lg shadow-lg max-w-md w-full mx-4 p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Upload FSM config</h2>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2 p-3 bg-destructive/10 border border-destructive/50 rounded-md">
            <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-4 flex items-start gap-2 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md">
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-green-800 dark:text-green-200">Machine created from file.</p>
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">
              Select FSM config file (YAML or JSON)
            </label>
            <input
              type="file"
              accept=".yaml,.yml,.json"
              onChange={handleFileChange}
              disabled={uploading}
              className="block w-full text-sm text-muted-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-primary file:text-primary-foreground file:text-sm file:font-medium hover:file:bg-primary/90"
            />
          </div>
          {progress && (
            <p className="text-sm text-muted-foreground">{progress}</p>
          )}
        </div>

        <div className="mt-4 flex justify-end">
          <Button variant="outline" onClick={handleClose} disabled={uploading}>
            Close
          </Button>
        </div>
      </div>
    </div>
  )
}
