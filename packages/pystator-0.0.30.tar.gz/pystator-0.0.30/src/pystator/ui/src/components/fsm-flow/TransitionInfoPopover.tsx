'use client'

import { Copy, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

function InfoRow({
  label,
  value,
  onCopy,
}: {
  label: string
  value: string
  onCopy: (text: string, label: string) => void
}) {
  return (
    <div className="space-y-1 rounded-md border bg-background px-3 py-2">
      <div className="flex items-center justify-between gap-2">
        <div className="text-xs font-semibold text-muted-foreground">{label}</div>
        <button
          type="button"
          className="inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"
          onClick={() => onCopy(value, label.toLowerCase())}
          aria-label={`Copy ${label}`}
          title={`Copy ${label}`}
        >
          <Copy className="h-3 w-3" />
          Copy
        </button>
      </div>
      <div className="font-mono text-xs whitespace-pre-wrap break-words">{value}</div>
    </div>
  )
}

export function TransitionInfoPopover({
  title,
  subtitle,
  trigger,
  guards,
  actions,
  delay,
  region,
  timeout,
  onClose,
  onCopy,
}: {
  title: string
  subtitle: string
  trigger?: string | null
  guards?: string | null
  actions?: string | null
  delay?: string | null
  region?: string | null
  timeout?: string | null
  onClose: () => void
  onCopy: (text: string, label: string) => void
}) {
  const hasMeta =
    (delay != null && delay !== '') ||
    (region != null && region !== '') ||
    (timeout != null && timeout !== '')

  return (
    <div className="w-[420px] max-w-[calc(100vw-48px)] rounded-lg border bg-background shadow-lg">
      <div className="flex items-start justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold">{title}</div>
          <div className="mt-1 font-mono text-[10px] text-muted-foreground truncate">{subtitle}</div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          aria-label="Close"
          title="Close"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-2 p-4">
        {trigger ? <InfoRow label="Trigger" value={trigger} onCopy={onCopy} /> : null}
        {guards ? <InfoRow label="Guards" value={guards} onCopy={onCopy} /> : null}
        {actions ? <InfoRow label="Actions" value={actions} onCopy={onCopy} /> : null}

        {hasMeta ? (
          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            {delay ? <span>Delay: {delay}</span> : null}
            {region ? <span>Region: {region}</span> : null}
            {timeout ? <span>Timeout: {timeout}</span> : null}
          </div>
        ) : null}
      </div>

      <div className="flex justify-end border-t px-4 py-3">
        <Button type="button" onClick={onClose}>
          Done
        </Button>
      </div>
    </div>
  )
}
