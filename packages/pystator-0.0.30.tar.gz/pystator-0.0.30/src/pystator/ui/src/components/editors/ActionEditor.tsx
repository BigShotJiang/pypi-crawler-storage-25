'use client'

import { useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Plus } from 'lucide-react'

// Re-export FSMActionRef as FSMAction from shared types
import type { FSMActionRef } from '@/lib/types/fsm'
export type FSMAction = FSMActionRef

type ActionKind = 'named' | 'effect'
type EffectType = 'set' | 'timestamp' | 'increment' | 'decrement' | 'append' | 'clear'
const EFFECT_TYPES: EffectType[] = ['set', 'timestamp', 'increment', 'decrement', 'append', 'clear']

interface ActionEditorProps {
  actions: FSMAction[]
  onChange: (actions: FSMAction[]) => void
  actionDefinitions?: { name: string; description?: string; parameters?: string }[]
}

function classifyAction(a: FSMAction): { kind: ActionKind; effectType?: EffectType } {
  if (typeof a === 'string' || 'name' in a) return { kind: 'named' }
  for (const t of EFFECT_TYPES) if (t in a) return { kind: 'effect', effectType: t }
  return { kind: 'named' }
}

function getNamedValue(a: FSMAction): string {
  if (typeof a === 'string') return a
  return 'name' in a ? a.name : ''
}

function getEffectField(a: FSMAction, type: EffectType): string {
  if (type === 'append') return (a as { append: { field: string } }).append?.field ?? ''
  return String((a as Record<string, unknown>)[type] ?? '')
}

function getSetPair(a: FSMAction): [string, string] {
  if (typeof a === 'object' && a !== null && 'set' in a) {
    const entries = Object.entries((a as { set: Record<string, unknown> }).set)
    if (entries.length > 0) return [entries[0][0], String(entries[0][1])]
  }
  return ['', '']
}

function getAppendValue(a: FSMAction): string {
  if (typeof a === 'object' && a !== null && 'append' in a) {
    return String((a as { append: { field: string; value: unknown } }).append.value ?? '')
  }
  return ''
}

function buildDefault(kind: ActionKind, effectType: EffectType): FSMAction {
  if (kind === 'named') return ''
  const map: Record<EffectType, FSMAction> = {
    set: { set: { '': '' } },
    timestamp: { timestamp: '' },
    increment: { increment: '' },
    decrement: { decrement: '' },
    append: { append: { field: '', value: '' } },
    clear: { clear: '' },
  }
  return map[effectType]
}

const SINGLE_FIELD_EFFECTS: EffectType[] = ['timestamp', 'increment', 'decrement', 'clear']

export default function ActionEditor({ actions, onChange, actionDefinitions }: ActionEditorProps) {
  const update = useCallback(
    (idx: number, next: FSMAction) => { const c = [...actions]; c[idx] = next; onChange(c) },
    [actions, onChange],
  )
  const remove = useCallback(
    (idx: number) => onChange(actions.filter((_, i) => i !== idx)),
    [actions, onChange],
  )
  const add = useCallback(() => onChange([...actions, '']), [actions, onChange])

  return (
    <div className="space-y-2">
      {actions.map((action, idx) => {
        const { kind, effectType = 'set' } = classifyAction(action)
        const borderColor = kind === 'named' ? 'border-l-violet-500' : 'border-l-emerald-500'
        return (
          <div key={idx} className={`flex items-start gap-2 rounded-md border p-2 border-l-4 ${borderColor}`}>
            <select
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              value={kind}
              onChange={(e) => update(idx, buildDefault(e.target.value as ActionKind, 'set'))}
            >
              <option value="named">Named</option>
              <option value="effect">Effect</option>
            </select>

            <div className="flex flex-1 items-center gap-2">
              {kind === 'named' ? (
                <>
                  <Input
                    className="h-9 flex-1"
                    placeholder="action name"
                    list="action-suggestions"
                    value={getNamedValue(action)}
                    onChange={(e) => update(idx, e.target.value || '')}
                  />
                  {actionDefinitions && actionDefinitions.length > 0 && (
                    <datalist id="action-suggestions">
                      {actionDefinitions.map((d) => <option key={d.name} value={d.name} />)}
                    </datalist>
                  )}
                </>
              ) : (
                <>
                  <select
                    className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                    value={effectType}
                    onChange={(e) => update(idx, buildDefault('effect', e.target.value as EffectType))}
                  >
                    {EFFECT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                  {effectType === 'set' && (
                    <>
                      <Input
                        className="h-9 w-28" placeholder="key"
                        value={getSetPair(action)[0]}
                        onChange={(e) => update(idx, { set: { [e.target.value]: getSetPair(action)[1] } })}
                      />
                      <Input
                        className="h-9 flex-1" placeholder="value"
                        value={getSetPair(action)[1]}
                        onChange={(e) => update(idx, { set: { [getSetPair(action)[0]]: e.target.value } })}
                      />
                    </>
                  )}
                  {SINGLE_FIELD_EFFECTS.includes(effectType) && (
                    <Input
                      className="h-9 flex-1" placeholder="field name"
                      value={getEffectField(action, effectType)}
                      onChange={(e) => update(idx, { [effectType]: e.target.value } as unknown as FSMAction)}
                    />
                  )}
                  {effectType === 'append' && (
                    <>
                      <Input
                        className="h-9 w-28" placeholder="field"
                        value={getEffectField(action, 'append')}
                        onChange={(e) => update(idx, { append: { field: e.target.value, value: getAppendValue(action) } })}
                      />
                      <Input
                        className="h-9 flex-1" placeholder="value"
                        value={getAppendValue(action)}
                        onChange={(e) => update(idx, { append: { field: getEffectField(action, 'append'), value: e.target.value } })}
                      />
                    </>
                  )}
                </>
              )}
            </div>

            <button
              type="button"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
              onClick={() => remove(idx)}
              aria-label="Remove action"
            >
              X
            </button>
          </div>
        )
      })}
      <Button type="button" variant="outline" size="sm" onClick={add} className="gap-1">
        <Plus className="h-3.5 w-3.5" />
        Add action
      </Button>
    </div>
  )
}
