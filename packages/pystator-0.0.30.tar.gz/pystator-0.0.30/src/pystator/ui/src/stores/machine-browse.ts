/**
 * Client-only store for the machine browse folder tree.
 * Builds a virtual folder tree from machine names (split on `/`).
 */

import { create } from 'zustand'
import type { MachineBrowseTreeNode } from '@/lib/types/machine-browse'

export interface MachineBrowseItem {
  name: string
  namespace?: string | null
}

function _normalizeNamespace(raw: string): string {
  const trimmed = raw.trim()
  if (!trimmed) return ''
  // Collapse repeated slashes and strip leading/trailing slashes.
  const collapsed = trimmed.replace(/\/+/g, '/')
  const withoutEdges = collapsed.replace(/^\/+|\/+$/g, '')
  return withoutEdges
}

function _namespaceParts(ns: string | null | undefined): string[] {
  const normalized = ns ? _normalizeNamespace(ns) : ''
  if (!normalized) return []
  return normalized.split('/').filter((p) => p.trim().length > 0)
}

function _folderIdFromParts(parts: string[]): string {
  return `folder:${parts.join('/')}`
}

interface MachineBrowseStore {
  expandedIds: Set<string>
  selectedMachineName: string | null

  buildTree: (machines: MachineBrowseItem[]) => MachineBrowseTreeNode[]
  toggleExpand: (nodeId: string) => void
  selectMachine: (name: string | null) => void
}

export const useMachineBrowseStore = create<MachineBrowseStore>((set, get) => ({
  expandedIds: new Set<string>(),
  selectedMachineName: null,

  buildTree: (machines) => {
    const sorted = [...machines]
      .map((m) => ({
        name: m.name.trim(),
        namespace: m.namespace ? _normalizeNamespace(m.namespace) : '',
      }))
      .filter((m) => Boolean(m.name))
      .sort((a, b) => {
        const ap = a.namespace ? `${a.namespace}/${a.name}` : a.name
        const bp = b.namespace ? `${b.namespace}/${b.name}` : b.name
        return ap.localeCompare(bp)
      })

    type Node = MachineBrowseTreeNode & { childrenMap?: Map<string, Node> }
    const root: Node = {
      id: 'root',
      name: '',
      kind: 'folder',
      folder_type: 'machine',
      children: [],
      childrenMap: new Map(),
    }

    const ensureFolder = (parent: Node, label: string, pathParts: string[]): Node => {
      const id = _folderIdFromParts(pathParts)
      const existing = parent.childrenMap?.get(id)
      if (existing) return existing
      const next: Node = {
        id,
        name: label,
        kind: 'folder',
        folder_type: 'machine',
        children: [],
        childrenMap: new Map(),
      }
      parent.childrenMap?.set(id, next)
      parent.children?.push(next)
      return next
    }

    const seenDisplayPaths = new Set<string>()
    for (const m of sorted) {
      const parts = _namespaceParts(m.namespace)
      let cursor = root
      for (let i = 0; i < parts.length; i++) {
        const pathParts = parts.slice(0, i + 1)
        cursor = ensureFolder(cursor, parts[i], pathParts)
      }
      const displayPath = m.namespace ? `${m.namespace}/${m.name}` : m.name
      if (seenDisplayPaths.has(displayPath)) continue
      seenDisplayPaths.add(displayPath)
      const item: Node = {
        id: `item:${displayPath}`,
        name: m.name,
        kind: 'item',
        folder_type: 'machine',
        item_id: m.name,
        item_label: displayPath,
      }
      cursor.children?.push(item)
    }

    const sortChildren = (node: Node) => {
      node.children?.sort((a, b) => {
        if (a.kind !== b.kind) return a.kind === 'folder' ? -1 : 1
        return a.name.localeCompare(b.name)
      })
      for (const child of node.children ?? []) {
        if (child.kind === 'folder') sortChildren(child as Node)
      }
      delete node.childrenMap
    }
    sortChildren(root)

    return root.children ?? []
  },

  toggleExpand: (nodeId) => {
    set((s) => {
      const next = new Set(s.expandedIds)
      if (next.has(nodeId)) next.delete(nodeId)
      else next.add(nodeId)
      return { expandedIds: next }
    })
  },

  selectMachine: (name) => set({ selectedMachineName: name }),
}))
