/**
 * Zustand store for the entity list page.
 * Manages entities, filters, sorting, cursor-based pagination, selection, and auto-refresh.
 */

import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import { listEntities } from '@/lib/api'
import type { EntityState } from '@/lib/api'

type EntityStatus = 'active' | 'archived' | 'deleted' | 'all'
type SortField = 'entity_id' | 'current_state' | 'machine_name' | 'updated_at' | 'created_at'
type SortOrder = 'asc' | 'desc'
type AutoRefreshInterval = 0 | 5000 | 10000 | 30000 | 60000

interface EntityListState {
  // Data
  entities: EntityState[]
  total: number
  loading: boolean
  error: string | null

  // Filters
  filterMachine: string
  filterState: string
  filterStatus: EntityStatus
  filterIsTerminal: boolean | null
  searchText: string

  // Sort
  sortBy: SortField
  sortOrder: SortOrder

  // Pagination (cursor-based)
  pageSize: number
  cursorStack: string[]
  currentCursor: string | null
  nextCursor: string | null

  // Selection
  selectedIds: Set<string>

  // Auto-refresh
  autoRefreshInterval: AutoRefreshInterval
  autoRefreshPaused: boolean

  // Actions
  fetchEntities: () => Promise<void>
  goNextPage: () => void
  goPrevPage: () => void
  goFirstPage: () => void
  setFilterMachine: (value: string) => void
  setFilterState: (value: string) => void
  setFilterStatus: (value: EntityStatus) => void
  setFilterIsTerminal: (value: boolean | null) => void
  setSearchText: (value: string) => void
  setSortBy: (field: SortField) => void
  setSortOrder: (order: SortOrder) => void
  toggleSort: (field: SortField) => void
  setAutoRefreshInterval: (interval: AutoRefreshInterval) => void
  setAutoRefreshPaused: (paused: boolean) => void
  toggleSelect: (id: string) => void
  toggleSelectAll: () => void
  clearSelection: () => void
}

export const useEntityListStore = create<EntityListState>()(
  devtools(
    (set, get) => ({
      // Data
      entities: [],
      total: 0,
      loading: false,
      error: null,

      // Filters
      filterMachine: '',
      filterState: '',
      filterStatus: 'active',
      filterIsTerminal: null,
      searchText: '',

      // Sort
      sortBy: 'updated_at',
      sortOrder: 'desc',

      // Pagination
      pageSize: 25,
      cursorStack: [],
      currentCursor: null,
      nextCursor: null,

      // Selection
      selectedIds: new Set<string>(),

      // Auto-refresh
      autoRefreshInterval: 0,
      autoRefreshPaused: false,

      fetchEntities: async () => {
        const state = get()
        set({ loading: true, error: null })
        try {
          const params: Record<string, string | number | boolean | undefined> = {
            page_size: state.pageSize,
            sort_by: state.sortBy,
            sort_order: state.sortOrder,
          }

          if (state.currentCursor) {
            params.cursor = state.currentCursor
          }
          if (state.filterMachine) {
            params.machine_name = state.filterMachine
          }
          if (state.filterState.trim()) {
            params.state = state.filterState.trim()
          }
          if (state.filterStatus !== 'all') {
            params.status = state.filterStatus
          } else {
            params.include_archived = true
            params.include_deleted = true
          }
          if (state.filterIsTerminal !== null) {
            params.is_terminal = state.filterIsTerminal
          }

          const res = await listEntities(params as Parameters<typeof listEntities>[0])
          set({
            entities: res.entities,
            total: res.total,
            nextCursor: res.next_cursor,
            loading: false,
          })
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e)
          set({ error: msg, loading: false })
        }
      },

      goNextPage: () => {
        const { nextCursor, currentCursor } = get()
        if (!nextCursor) return
        set((s) => ({
          cursorStack: currentCursor
            ? [...s.cursorStack, currentCursor]
            : s.cursorStack,
          currentCursor: nextCursor,
        }))
        get().fetchEntities()
      },

      goPrevPage: () => {
        const { cursorStack } = get()
        if (cursorStack.length === 0) return
        const newStack = [...cursorStack]
        const prevCursor = newStack.pop() ?? null
        set({
          cursorStack: newStack,
          currentCursor: prevCursor,
        })
        get().fetchEntities()
      },

      goFirstPage: () => {
        set({
          cursorStack: [],
          currentCursor: null,
        })
        get().fetchEntities()
      },

      setFilterMachine: (value) => {
        set({
          filterMachine: value,
          cursorStack: [],
          currentCursor: null,
          selectedIds: new Set<string>(),
        })
        get().fetchEntities()
      },

      setFilterState: (value) => {
        set({
          filterState: value,
          cursorStack: [],
          currentCursor: null,
          selectedIds: new Set<string>(),
        })
        get().fetchEntities()
      },

      setFilterStatus: (value) => {
        set({
          filterStatus: value,
          cursorStack: [],
          currentCursor: null,
          selectedIds: new Set<string>(),
        })
        get().fetchEntities()
      },

      setFilterIsTerminal: (value) => {
        set({
          filterIsTerminal: value,
          cursorStack: [],
          currentCursor: null,
          selectedIds: new Set<string>(),
        })
        get().fetchEntities()
      },

      setSearchText: (value) => {
        set({ searchText: value })
      },

      setSortBy: (field) => {
        set({
          sortBy: field,
          cursorStack: [],
          currentCursor: null,
        })
        get().fetchEntities()
      },

      setSortOrder: (order) => {
        set({
          sortOrder: order,
          cursorStack: [],
          currentCursor: null,
        })
        get().fetchEntities()
      },

      toggleSort: (field) => {
        const { sortBy, sortOrder } = get()
        if (sortBy === field) {
          set({
            sortOrder: sortOrder === 'asc' ? 'desc' : 'asc',
            cursorStack: [],
            currentCursor: null,
          })
        } else {
          set({
            sortBy: field,
            sortOrder: 'asc',
            cursorStack: [],
            currentCursor: null,
          })
        }
        get().fetchEntities()
      },

      setAutoRefreshInterval: (interval) => {
        set({ autoRefreshInterval: interval })
      },

      setAutoRefreshPaused: (paused) => {
        set({ autoRefreshPaused: paused })
      },

      toggleSelect: (id) => {
        set((s) => {
          const next = new Set(s.selectedIds)
          if (next.has(id)) {
            next.delete(id)
          } else {
            next.add(id)
          }
          return { selectedIds: next }
        })
      },

      toggleSelectAll: () => {
        set((s) => {
          const allIds = s.entities.map((e) => e.entity_id)
          const allSelected = allIds.length > 0 && allIds.every((id) => s.selectedIds.has(id))
          if (allSelected) {
            return { selectedIds: new Set<string>() }
          }
          return { selectedIds: new Set(allIds) }
        })
      },

      clearSelection: () => {
        set({ selectedIds: new Set<string>() })
      },
    }),
    { name: 'entity-list' },
  ),
)
