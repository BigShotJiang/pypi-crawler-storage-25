import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import { ApiError, authMeWithTimeout, loginWithTimeout } from '@/lib/api'
import type { AuthMeResponse } from '@/lib/api'
import { clearAccessToken, setAccessToken } from '@/lib/auth-storage'
import { AUTH_CHECK_TIMEOUT_MS, LOGIN_REQUEST_TIMEOUT_MS, ROUTES } from '@/lib/constants'

export interface AuthState {
  user: AuthMeResponse | null
  loading: boolean
  apiUnavailable: boolean
  checkAuth: () => Promise<void>
  login: (username: string, password: string) => Promise<string>
  logout: () => void
  clearUser: () => void
}

export const useAuthStore = create<AuthState>()(
  devtools(
    (set) => ({
      user: null,
      loading: true,
      apiUnavailable: false,

      checkAuth: async () => {
        try {
          const me = await authMeWithTimeout(AUTH_CHECK_TIMEOUT_MS)
          set({ user: me, apiUnavailable: false })
        } catch (err) {
          if (err instanceof ApiError && err.status === 401) {
            set({ user: null, apiUnavailable: false })
          } else {
            set({ user: null, apiUnavailable: true })
          }
        } finally {
          set({ loading: false })
        }
      },

      login: async (username, password) => {
        const res = await loginWithTimeout(username, password, LOGIN_REQUEST_TIMEOUT_MS)
        setAccessToken(res.access_token)
        set({ user: { username, auth_disabled: false }, apiUnavailable: false })
        const returnUrl =
          typeof window !== 'undefined'
            ? sessionStorage.getItem('pystator_return_url')
            : null
        sessionStorage.removeItem('pystator_return_url')
        return returnUrl || ROUTES.HOME
      },

      logout: () => {
        clearAccessToken()
        set({ user: null, apiUnavailable: false })
      },

      clearUser: () => set({ user: null }),
    }),
    { name: 'auth' },
  ),
)

export const selectUser = (s: AuthState) => s.user
export const selectLoading = (s: AuthState) => s.loading
export const selectApiUnavailable = (s: AuthState) => s.apiUnavailable
export const selectIsAuthenticated = (s: AuthState) => !!s.user
export const selectAuthDisabled = (s: AuthState) => s.user?.auth_disabled === true
export const selectLogin = (s: AuthState) => s.login
export const selectLogout = (s: AuthState) => s.logout
export const selectCheckAuth = (s: AuthState) => s.checkAuth
