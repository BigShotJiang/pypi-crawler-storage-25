import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

/**
 * Proxy for PyStator UI
 * Since we use localStorage for auth, we handle auth checks client-side
 * This proxy is mainly for future server-side auth if needed
 */
export function proxy(request: NextRequest) {
  // Allow all requests to proceed
  // Client-side components will check localStorage and redirect if needed
  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
