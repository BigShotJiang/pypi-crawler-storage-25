'use client'

import { useCallback, useEffect, useState } from 'react'
import {
  getApiErrorMessage,
  listDiscoveryMachines,
  listMachines,
  type DiscoveryFleetMachineItem,
} from '@/lib/api'

/** Client-side attention flags (merged with catalog via listMachines). */
export type FleetRowAttention = {
  /** Elevated drift in recent shadow window (≥15% differs, ≥3 samples). */
  drift: boolean
  /** No observation in the last 7 days (or never observed). */
  stale: boolean
  /** No Machines catalog row for this name. */
  missingCatalog: boolean
  /** Catalog version differs from latest discovery candidate version. */
  versionMismatch: boolean
}

export interface FleetRowView extends DiscoveryFleetMachineItem {
  catalogVersion: string | null
  catalogId: string | null
  attention: FleetRowAttention
}

const STALE_MS = 7 * 24 * 60 * 60 * 1000

function mergeCatalogAndAttention(
  items: DiscoveryFleetMachineItem[],
  catalogNames: Map<string, { id: string; version: string }>
): FleetRowView[] {
  const now = Date.now()
  return items.map((item) => {
    const cat = catalogNames.get(item.machine_name)
    const lastObs = item.last_observation_at
      ? new Date(item.last_observation_at).getTime()
      : null
    const stale = lastObs === null || now - lastObs > STALE_MS
    const missingCatalog = !cat
    const candVer = item.latest_candidate_version
    const versionMismatch = Boolean(
      cat && candVer && cat.version !== candVer
    )
    const drift =
      item.drift_rate_recent >= 0.15 && item.shadow_diff_count_recent >= 3
    return {
      ...item,
      catalogVersion: cat?.version ?? null,
      catalogId: cat?.id ?? null,
      attention: {
        drift,
        stale,
        missingCatalog,
        versionMismatch,
      },
    }
  })
}

export interface UseDiscoveryFleetIndexResult {
  rows: FleetRowView[]
  total: number
  limit: number
  offset: number
  setLimit: (n: number) => void
  setOffset: (n: number) => void
  searchInput: string
  setSearchInput: (v: string) => void
  sort: string
  setSort: (v: string) => void
  order: 'asc' | 'desc'
  setOrder: (v: 'asc' | 'desc') => void
  loading: boolean
  error: string | null
  refresh: () => Promise<void>
  selectedMachineNames: Set<string>
  toggleSelected: (name: string) => void
  clearSelection: () => void
}

export function useDiscoveryFleetIndex(): UseDiscoveryFleetIndexResult {
  const [rows, setRows] = useState<FleetRowView[]>([])
  const [total, setTotal] = useState(0)
  const [limit, setLimit] = useState(50)
  const [offset, setOffset] = useState(0)
  const [searchInput, setSearchInput] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [sort, setSort] = useState('machine_name')
  const [order, setOrder] = useState<'asc' | 'desc'>('asc')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedMachineNames, setSelectedMachineNames] = useState<Set<string>>(
    () => new Set()
  )

  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebouncedSearch(searchInput.trim())
    }, 300)
    return () => window.clearTimeout(t)
  }, [searchInput])

  useEffect(() => {
    setOffset(0)
  }, [debouncedSearch, sort, order, limit])

  const fetchFleet = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [fleetRes, machinesRes] = await Promise.all([
        listDiscoveryMachines({
          query: debouncedSearch || undefined,
          sort,
          order,
          limit,
          offset,
        }),
        listMachines(),
      ])
      const catalogNames = new Map(
        machinesRes.machines.map((m) => [m.name, { id: m.id, version: m.version }])
      )
      setRows(mergeCatalogAndAttention(fleetRes.items, catalogNames))
      setTotal(fleetRes.total)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load discovery fleet'))
      setRows([])
      setTotal(0)
    } finally {
      setLoading(false)
    }
  }, [debouncedSearch, sort, order, limit, offset])

  useEffect(() => {
    void fetchFleet()
  }, [fetchFleet])

  const toggleSelected = useCallback((name: string) => {
    setSelectedMachineNames((prev) => {
      const next = new Set(prev)
      if (next.has(name)) next.delete(name)
      else next.add(name)
      return next
    })
  }, [])

  const clearSelection = useCallback(() => setSelectedMachineNames(new Set()), [])

  // Drop selection of rows that disappeared (e.g. after filter)
  useEffect(() => {
    const names = new Set(rows.map((r) => r.machine_name))
    setSelectedMachineNames((prev) => {
      let changed = false
      const next = new Set<string>()
      for (const n of prev) {
        if (names.has(n)) next.add(n)
        else changed = true
      }
      return changed ? next : prev
    })
  }, [rows])

  return {
    rows,
    total,
    limit,
    offset,
    setLimit,
    setOffset,
    searchInput,
    setSearchInput,
    sort,
    setSort,
    order,
    setOrder,
    loading,
    error,
    refresh: fetchFleet,
    selectedMachineNames,
    toggleSelected,
    clearSelection,
  }
}
