'use client'

import { useState, useCallback, useEffect } from 'react'
import type { FSMConfig } from '@/lib/types/fsm'
import { parseFsmConfig, stringifyFsmConfig, type ConfigFormat } from '@/lib/fsmConfigParse'

const DEFAULT_JSON = `{
  "meta": { "machine_name": "order", "version": "1.0" },
  "states": [
    { "name": "pending", "type": "initial" },
    { "name": "processing", "type": "stable" },
    { "name": "done", "type": "terminal" }
  ],
  "transitions": [
    { "trigger": "start", "source": "pending", "dest": "processing" },
    { "trigger": "complete", "source": "processing", "dest": "done" }
  ]
}`

export interface UseFsmConfigParseOptions {
  initialFormat?: ConfigFormat
  initialRaw?: string
}

export interface UseFsmConfigParseReturn {
  format: ConfigFormat
  raw: string
  setRaw: (value: string) => void
  config: FSMConfig | null
  parseError: string | null
  setFormat: (format: ConfigFormat) => void
  switchFormat: (newFormat: ConfigFormat) => void
  /** Re-parse current raw with current format (e.g. after user edit) */
  reparse: () => void
}

export function useFsmConfigParse(
  options: UseFsmConfigParseOptions = {}
): UseFsmConfigParseReturn {
  const {
    initialFormat = 'json',
    initialRaw = DEFAULT_JSON,
  } = options

  const [format, setFormatState] = useState<ConfigFormat>(initialFormat)
  const [raw, setRaw] = useState(initialRaw)
  const [config, setConfig] = useState<FSMConfig | null>(null)
  const [parseError, setParseError] = useState<string | null>(null)

  const reparse = useCallback(() => {
    setParseError(null)
    const result = parseFsmConfig(raw, format)
    if ('error' in result) {
      setParseError(result.error)
      setConfig(null)
    } else {
      setConfig(result.config)
    }
  }, [raw, format])

  useEffect(() => {
    reparse()
  }, [reparse])

  const switchFormat = useCallback((newFormat: ConfigFormat) => {
    if (newFormat === format) return
    setParseError(null)
    let current: FSMConfig
    if (config) {
      current = config
    } else {
      const result = parseFsmConfig(raw, format)
      if ('error' in result) {
        current = { meta: { machine_name: '', version: '1.0' }, states: [], transitions: [] }
      } else {
        current = result.config
      }
    }
    setRaw(stringifyFsmConfig(current, newFormat))
    setFormatState(newFormat)
  }, [format, config, raw])

  return {
    format,
    raw,
    setRaw,
    config,
    parseError,
    setFormat: setFormatState,
    switchFormat,
    reparse,
  }
}
