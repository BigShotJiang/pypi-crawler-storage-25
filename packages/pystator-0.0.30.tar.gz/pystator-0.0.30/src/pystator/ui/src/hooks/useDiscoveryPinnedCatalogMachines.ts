'use client'

import { useCallback, useEffect, useState } from 'react'
import type { MachineListItem } from '@/lib/api'

const STORAGE_KEY = 'pystator_discovery_catalog_pins'

function loadPins(): MachineListItem[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as unknown
    if (!Array.isArray(parsed)) return []
    const out: MachineListItem[] = []
    for (const row of parsed) {
      if (!row || typeof row !== 'object') continue
      const o = row as Record<string, unknown>
      const id =
        typeof o.id === 'string' ? o.id : typeof o.id === 'number' ? String(o.id) : ''
      const name = typeof o.name === 'string' ? o.name : ''
      const version =
        typeof o.version === 'string'
          ? o.version
          : typeof o.version === 'number'
            ? String(o.version)
            : ''
      if (!id || !name || !version) continue
      out.push({
        id,
        name,
        version,
        description: typeof o.description === 'string' ? o.description : null,
        created_at: typeof o.created_at === 'string' ? o.created_at : null,
        updated_at: typeof o.updated_at === 'string' ? o.updated_at : null,
      })
    }
    return dedupeById(out)
  } catch {
    return []
  }
}

function dedupeById(pins: MachineListItem[]): MachineListItem[] {
  const seen = new Set<string>()
  const out: MachineListItem[] = []
  for (const p of pins) {
    const key = String(p.id)
    if (seen.has(key)) continue
    seen.add(key)
    out.push(p)
  }
  return out
}

function savePins(pins: MachineListItem[]) {
  if (typeof window === 'undefined') return
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(pins))
}

export interface UseDiscoveryPinnedCatalogMachinesResult {
  pins: MachineListItem[]
  addPin: (item: MachineListItem) => void
  removePin: (id: string) => void
}

export function useDiscoveryPinnedCatalogMachines(): UseDiscoveryPinnedCatalogMachinesResult {
  // Hydrate from localStorage during state initialization to avoid
  // mount-effect races in React Strict Mode that can overwrite stored pins.
  const [pins, setPins] = useState<MachineListItem[]>(() => loadPins())

  useEffect(() => {
    savePins(pins)
  }, [pins])

  const addPin = useCallback((item: MachineListItem) => {
    setPins((prev) => {
      const normalized: MachineListItem = {
        ...item,
        id: String(item.id),
        name: String(item.name),
        version: String(item.version),
      }
      if (prev.some((p) => String(p.id) === normalized.id)) return prev
      return dedupeById([...prev, normalized])
    })
  }, [])

  const removePin = useCallback((id: string) => {
    const key = String(id)
    setPins((prev) => prev.filter((p) => String(p.id) !== key))
  }, [])

  return { pins, addPin, removePin }
}
