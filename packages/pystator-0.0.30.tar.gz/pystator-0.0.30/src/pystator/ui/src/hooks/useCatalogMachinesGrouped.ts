'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { getApiErrorMessage, listMachines } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'

function parseSemver(v: string): [number, number, number] | null {
  const m = /^v?(\d+)\.(\d+)\.(\d+)/.exec(v.trim())
  if (!m) return null
  return [Number(m[1]), Number(m[2]), Number(m[3])]
}

function compareVersions(a: string, b: string): number {
  const pa = parseSemver(a)
  const pb = parseSemver(b)
  if (pa && pb) {
    if (pa[0] !== pb[0]) return pa[0] - pb[0]
    if (pa[1] !== pb[1]) return pa[1] - pb[1]
    if (pa[2] !== pb[2]) return pa[2] - pb[2]
    return 0
  }
  return a.localeCompare(b)
}

export interface UseCatalogMachinesGroupedResult {
  machines: MachineListItem[]
  /** All catalog names sorted. */
  uniqueNames: string[]
  /** Versions for a name, newest first. */
  versionsForName: (name: string) => MachineListItem[]
  byName: Map<string, MachineListItem[]>
  loading: boolean
  error: string | null
  refresh: () => Promise<void>
}

export function useCatalogMachinesGrouped(): UseCatalogMachinesGroupedResult {
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await listMachines()
      setMachines(res.machines ?? [])
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load machines'))
      setMachines([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const byName = useMemo(() => {
    const m = new Map<string, MachineListItem[]>()
    for (const item of machines) {
      const list = m.get(item.name) ?? []
      list.push(item)
      m.set(item.name, list)
    }
    for (const [, list] of m) {
      list.sort((a, b) => compareVersions(b.version, a.version))
    }
    return m
  }, [machines])

  const uniqueNames = useMemo(() => {
    return [...byName.keys()].sort((a, b) => a.localeCompare(b))
  }, [byName])

  const versionsForName = useCallback(
    (name: string) => byName.get(name) ?? [],
    [byName]
  )

  return {
    machines,
    uniqueNames,
    versionsForName,
    byName,
    loading,
    error,
    refresh: load,
  }
}
