'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { getObservabilityStateMetrics } from '@/lib/api'
import type { ObservabilityStateMetricsResponse, StateOpsMetricsItem } from '@/lib/api'

export type UseStateOpsMetricsOptions = {
  enabled: boolean
  machineName: string
  windowHours?: number
  pollMs?: number
}

export type StateOpsMetricsByState = Record<string, StateOpsMetricsItem>

export function useStateOpsMetrics({
  enabled,
  machineName,
  windowHours = 24,
  pollMs = 15_000,
}: UseStateOpsMetricsOptions) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const [data, setData] = useState<ObservabilityStateMetricsResponse | null>(null)

  const fetchOnce = useCallback(async () => {
    if (!enabled) return
    if (!machineName || machineName.trim().length === 0) return
    setLoading(true)
    setError(null)
    try {
      const res = await getObservabilityStateMetrics({
        machine_name: machineName,
        window_hours: windowHours,
      })
      setData(res)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [enabled, machineName, windowHours])

  useEffect(() => {
    if (!enabled) {
      setData(null)
      setError(null)
      setLoading(false)
      return
    }
    void fetchOnce()
  }, [enabled, fetchOnce])

  useEffect(() => {
    if (!enabled) return
    if (!machineName || machineName.trim().length === 0) return
    const id = window.setInterval(() => {
      fetchOnce().catch(() => {})
    }, pollMs)
    return () => window.clearInterval(id)
  }, [enabled, machineName, pollMs, fetchOnce])

  const metricsByState = useMemo<StateOpsMetricsByState>(() => {
    const items = data?.items ?? []
    const out: StateOpsMetricsByState = {}
    for (const it of items) out[it.state_name] = it
    return out
  }, [data])

  return { loading, error, data, metricsByState, refresh: fetchOnce }
}
