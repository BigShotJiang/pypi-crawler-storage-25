'use client'

import { useState, useEffect, useCallback } from 'react'
import { listMachines, getMachine } from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'

export interface UseMachineConfigByNameResult {
  config: FSMConfig | null
  loading: boolean
  error: Error | null
  refetch: () => void
}

/**
 * Resolve machine config by machine name (e.g. from entity.machine_name).
 * Lists machines, finds by name, then fetches full machine for config.
 * Use for entity detail diagram and any view that needs config by name.
 */
export function useMachineConfigByName(machineName: string | null): UseMachineConfigByNameResult {
  const [config, setConfig] = useState<FSMConfig | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  const fetchConfig = useCallback(async () => {
    if (!machineName || machineName.trim() === '') {
      setConfig(null)
      setError(null)
      return
    }
    setLoading(true)
    setError(null)
    try {
      const listRes = await listMachines()
      const match = listRes.machines.find((m) => m.name === machineName)
      if (!match) {
        setConfig(null)
        setError(new Error(`Machine not found: ${machineName}`))
        return
      }
      const machine = await getMachine(match.id)
      setConfig(machine.config)
    } catch (err) {
      setConfig(null)
      setError(err instanceof Error ? err : new Error(String(err)))
    } finally {
      setLoading(false)
    }
  }, [machineName])

  useEffect(() => {
    fetchConfig()
  }, [fetchConfig])

  return { config, loading, error, refetch: fetchConfig }
}
