'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { getMachine, listMachines } from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'

export interface DiscoveryBaselineMachineResult {
  baselineConfig: FSMConfig | null
  baselineVersion: string | null
  loading: boolean
  error: string | null
}

export interface UseDiscoveryBaselineMachineOptions {
  /** When set, baseline is this exact catalog row (`getMachine(id)`), not latest-by-name. */
  catalogMachineId?: string | null
}

function parseSemver(v: string): [number, number, number] | null {
  const m = /^v?(\d+)\.(\d+)\.(\d+)/.exec(v.trim())
  if (!m) return null
  return [Number(m[1]), Number(m[2]), Number(m[3])]
}

function compareVersions(a: string, b: string): number {
  const pa = parseSemver(a)
  const pb = parseSemver(b)
  if (pa && pb) {
    if (pa[0] !== pb[0]) return pa[0] - pb[0]
    if (pa[1] !== pb[1]) return pa[1] - pb[1]
    if (pa[2] !== pb[2]) return pa[2] - pb[2]
    return 0
  }
  return a.localeCompare(b)
}

type CacheEntry = { config: FSMConfig; version: string }

function cacheKey(name: string, catalogMachineId: string | null | undefined): string {
  if (catalogMachineId) return `id:${catalogMachineId}`
  return `name:${name}`
}

export function useDiscoveryBaselineMachine(
  machineName: string,
  options?: UseDiscoveryBaselineMachineOptions
): DiscoveryBaselineMachineResult {
  const catalogMachineId = options?.catalogMachineId ?? null
  const name = useMemo(() => machineName.trim(), [machineName])
  const cacheRef = useRef<Map<string, CacheEntry>>(new Map())
  const [baselineConfig, setBaselineConfig] = useState<FSMConfig | null>(null)
  const [baselineVersion, setBaselineVersion] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false

    async function run() {
      if (!name) {
        setBaselineConfig(null)
        setBaselineVersion(null)
        setLoading(false)
        setError(null)
        return
      }

      const key = cacheKey(name, catalogMachineId)
      const cached = cacheRef.current.get(key)
      if (cached) {
        setBaselineConfig(cached.config)
        setBaselineVersion(cached.version)
        setLoading(false)
        setError(null)
        return
      }

      setLoading(true)
      setError(null)
      try {
        if (catalogMachineId) {
          const full = await getMachine(catalogMachineId)
          const config = full.config as FSMConfig
          if (!cancelled) {
            cacheRef.current.set(key, { config, version: full.version })
            setBaselineConfig(config)
            setBaselineVersion(full.version)
          }
          return
        }

        const list = await listMachines()
        const matches = (list.machines ?? []).filter((m) => m.name === name)
        if (matches.length === 0) {
          if (!cancelled) {
            setBaselineConfig(null)
            setBaselineVersion(null)
          }
          return
        }

        const latest = matches.reduce((best, cur) =>
          compareVersions(best.version, cur.version) >= 0 ? best : cur
        )
        const full = await getMachine(latest.id)
        const config = full.config as FSMConfig
        if (!cancelled) {
          cacheRef.current.set(key, { config, version: full.version })
          setBaselineConfig(config)
          setBaselineVersion(full.version)
        }
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Failed to load baseline machine')
          setBaselineConfig(null)
          setBaselineVersion(null)
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    void run()
    return () => {
      cancelled = true
    }
  }, [name, catalogMachineId])

  return { baselineConfig, baselineVersion, loading, error }
}
