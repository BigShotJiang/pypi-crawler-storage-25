# PyStator UI

Next.js UI for building and visualizing FSMs. Install with `pip install pystator[ui]`.

## Build

```bash
cd src/pystator/ui && npm install && npm run build
# Or from repo root: python -m pystator.ui.build
```

## Dev

```bash
npm run dev
# Or: python -m pystator.ui.dev
```

## Serve (after build)

```bash
python -m pystator.ui.server
# Requires API running at http://localhost:8000 (or set PYSTATOR_API_URL)
```

## Pages

- **Home** – Overview and entry point to the UI
- **Workspace** – Configure FSMs, browse machines, edit state/transition config, test process runs, and save
- **Machines** – Manage machine records
- **Entities** – Run and inspect entity state transitions
- **Observability** – Transition and worker-event monitoring views
- **Table Editor** – Spreadsheet-style FSM editing
- **Templates** – Starter FSM templates and downloads
- **Documentation** – API reference with inline test panels
- **Settings** – API URL and DB settings
- **Login** – Authentication entry route

## Structure

- **`src/app/`** – Next.js App Router pages (one component per route)
- **`src/components/`** – Reusable UI: `layout` (PageContainer), `common` (PageHeader), `ui` (shadcn), `workspace`, `fsm-flow`, `modals`, `sidebar`, `documentation`, `settings`
- **`src/stores/`** – Zustand stores for workspace, auth, app-config, and toast state
- **`src/hooks/`** – useFsmConfigParse, useWorkspaceSave, useApiHealth, useDatabaseConfig
- **`src/lib/`** – API client, FSM types, fsmConfigParse, fsmToReactFlow, settings, templates, constants, utils
- **`src/data/`** – API method definitions for Documentation

## Data flow (high level)

- Route components in `src/app/` orchestrate feature screens.
- Shared state lives in `src/stores/` and is read/written via selectors.
- API calls are centralized in `src/lib/api.ts`.
- FSM parsing/layout helpers live in `src/lib/` and are consumed by workspace/fsm-flow components.
