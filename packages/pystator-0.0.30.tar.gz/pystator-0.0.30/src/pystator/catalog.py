"""Catalog of built-in guards, actions, and effects for API/UI discovery.

Introspects the builtins module to generate metadata that the UI can
display in the built-in browser panel.
"""

from __future__ import annotations

import inspect
from typing import Any

# Single source of truth for check operators (defined in _types.py)
from pystator._types import CHECK_OPS
from pystator.builtins import (
    _BUILTIN_ACTIONS,
    _BUILTIN_GUARDS,
)

# ---------------------------------------------------------------------------
# Effect types (from effects.py)
# ---------------------------------------------------------------------------

_EFFECT_CATALOG: list[dict[str, Any]] = [
    {
        "name": "set",
        "description": "Set one or more context keys.",
        "syntax": '{ set: { key: "value" } }',
    },
    {
        "name": "timestamp",
        "description": "Set a field to the current UTC ISO timestamp.",
        "syntax": "{ timestamp: field_name }",
    },
    {
        "name": "increment",
        "description": "Add 1 to a numeric context field (default 0).",
        "syntax": "{ increment: field_name }",
    },
    {
        "name": "decrement",
        "description": "Subtract 1 from a numeric context field (default 0).",
        "syntax": "{ decrement: field_name }",
    },
    {
        "name": "append",
        "description": "Append a value to a list context field.",
        "syntax": '{ append: { field: "list_key", value: "item" } }',
    },
    {
        "name": "clear",
        "description": "Remove a key from the context.",
        "syntax": "{ clear: field_name }",
    },
    {
        "name": "compute",
        "description": "Evaluate expressions and set results as context keys.",
        "syntax": '{ compute: { total: "price * qty" } }',
    },
]

_HTTP_ACTION_CATALOG: dict[str, Any] = {
    "name": "http",
    "description": "Fire an HTTP request defined in YAML with {{ }} template substitution.",
    "syntax": '{ http: { url: "https://...", method: "POST", body: { ... } } }',
    "params": [
        "url",
        "method",
        "headers",
        "body",
        "timeout",
        "retry",
        "on_success",
        "on_error",
    ],
}


def _extract_params(func: Any) -> list[dict[str, str]]:
    """Extract keyword-only parameters from a function signature."""
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return []
    params: list[dict[str, str]] = []
    for name, param in sig.parameters.items():
        if name == "ctx" or name == "kwargs":
            continue
        if param.kind in (
            inspect.Parameter.KEYWORD_ONLY,
            inspect.Parameter.VAR_KEYWORD,
        ):
            entry: dict[str, str] = {"name": name}
            if param.default is not inspect.Parameter.empty:
                entry["default"] = str(param.default)
            if param.annotation is not inspect.Parameter.empty:
                entry["type"] = str(param.annotation)
            params.append(entry)
    return params


def _docstring_summary(func: Any) -> str:
    """Extract first line of a function's docstring."""
    doc = getattr(func, "__doc__", None)
    if not doc:
        return ""
    return doc.strip().split("\n")[0]


def get_builtin_catalog() -> dict[str, Any]:
    """Generate the full catalog of built-in guards, actions, effects, and operators.

    Returns:
        Dict with keys: ``guards``, ``actions``, ``effects``, ``check_operators``.
    """
    guards = []
    for name, func in _BUILTIN_GUARDS.items():
        guards.append(
            {
                "name": name,
                "description": _docstring_summary(func),
                "params": _extract_params(func),
            }
        )

    actions = []
    for name, func in _BUILTIN_ACTIONS.items():
        actions.append(
            {
                "name": name,
                "description": _docstring_summary(func),
                "params": _extract_params(func),
            }
        )

    operators = [{"name": op} for op in sorted(CHECK_OPS)]

    return {
        "guards": guards,
        "actions": actions,
        "effects": _EFFECT_CATALOG,
        "check_operators": operators,
        "http_action": _HTTP_ACTION_CATALOG,
    }
