"""Shared expression evaluation and template rendering for PyStator.

Provides a safe expression engine (via ``simpleeval``) used by:
- Guard inline expressions (``expr: "fill_qty >= order_qty"``)
- Computed effects (``compute: {total: "price * qty"}``)
- HTTP action template rendering (``{{ order_id }}``)
"""

from __future__ import annotations

import re
from typing import Any

from simpleeval import SimpleEval

# Safe builtins exposed to expressions.
_EXPR_BUILTINS: dict[str, Any] = {
    "len": len,
    "min": min,
    "max": max,
    "abs": abs,
    "sum": sum,
    "round": round,
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "any": any,
    "all": all,
}

_TEMPLATE_RE = re.compile(r"\{\{\s*(.+?)\s*\}\}")


def evaluate_expr(expr: str, namespace: dict[str, Any]) -> Any:
    """Evaluate an expression with *namespace* as variables.

    Uses ``simpleeval`` for safe sandboxed evaluation. Returns the raw
    result (any type).

    Args:
        expr: Expression string (e.g. ``"price * qty"``).
        namespace: Variable mapping (typically the FSM context dict).

    Returns:
        The evaluated result.

    Raises:
        Exception: On syntax errors or undefined names.
    """
    evaluator = SimpleEval(names=namespace)
    for name, func in _EXPR_BUILTINS.items():
        evaluator.functions[name] = func
    return evaluator.eval(expr)


def evaluate_bool_expr(expr: str, namespace: dict[str, Any]) -> bool:
    """Evaluate an expression and coerce to bool.

    Convenience wrapper for guard expressions that must return True/False.

    Args:
        expr: Boolean expression string.
        namespace: Variable mapping.

    Returns:
        True if the expression evaluates to a truthy value.
    """
    return bool(evaluate_expr(expr, namespace))


def render_template(template: str, namespace: dict[str, Any]) -> str:
    """Replace ``{{ expr }}`` patterns with evaluated results.

    Each ``{{ ... }}`` block is evaluated as an expression against
    *namespace*. Simple variable references (``{{ order_id }}``) and
    computed expressions (``{{ price * qty }}``) are both supported.

    Args:
        template: String containing ``{{ expr }}`` patterns.
        namespace: Variable mapping for expression evaluation.

    Returns:
        The rendered string with all patterns replaced.
    """

    def _replace(match: re.Match[str]) -> str:
        expr = match.group(1)
        try:
            return str(evaluate_expr(expr, namespace))
        except Exception:
            return match.group(0)  # Leave unresolved on error

    return _TEMPLATE_RE.sub(_replace, template)


def render_template_value(value: Any, namespace: dict[str, Any]) -> Any:
    """Recursively render templates in a value (str, dict, or list).

    Strings are rendered via :func:`render_template`. Dicts and lists
    are traversed recursively. Other types are returned unchanged.

    Args:
        value: The value to render (string, dict, list, or scalar).
        namespace: Variable mapping for expression evaluation.

    Returns:
        The rendered value.
    """
    if isinstance(value, str):
        return render_template(value, namespace)
    if isinstance(value, dict):
        return {k: render_template_value(v, namespace) for k, v in value.items()}
    if isinstance(value, list):
        return [render_template_value(item, namespace) for item in value]
    return value
