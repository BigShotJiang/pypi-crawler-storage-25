"""
FSM template routes.

FSM templates (starter YAML configs) live under pystator/data/templates/fsm/.
List and serve by filename (e.g. blank.yaml, order_management.yaml).
"""

from __future__ import annotations

import io
import logging
import zipfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import PlainTextResponse, Response

logger = logging.getLogger(__name__)

router = APIRouter()


def _find_fsm_template_dir() -> Path:
    """
    Find FSM template directory.

    Templates are bundled inside the package at ``pystator/data/templates/fsm/``.
    Resolution order:
      1. Package-relative (works for pip install *and* editable installs)
      2. Project-root ``data/templates/fsm/`` (legacy / dev fallback)
      3. CWD ``data/templates/fsm/``
    """
    try:
        import pystator

        pkg_dir = Path(pystator.__file__).resolve().parent
        # Inside the installed package: src/pystator/data/templates/fsm
        pkg_fsm_dir = pkg_dir / "data" / "templates" / "fsm"
        if pkg_fsm_dir.exists() and any(pkg_fsm_dir.glob("*.yaml")):
            return pkg_fsm_dir

        # Fallback: project root data/templates/fsm (editable install)
        project_root = pkg_dir.parent.parent
        root_fsm_dir = project_root / "data" / "templates" / "fsm"
        if root_fsm_dir.exists() and any(root_fsm_dir.glob("*.yaml")):
            return root_fsm_dir
    except (ImportError, AttributeError):
        pass

    # Last resort: CWD
    cwd_fsm_dir = Path.cwd() / "data" / "templates" / "fsm"
    if cwd_fsm_dir.exists() and any(cwd_fsm_dir.glob("*.yaml")):
        return cwd_fsm_dir

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="FSM template directory not found",
    )


def _list_fsm_templates() -> list[str]:
    """Return sorted list of FSM template filenames (.yaml/.yml)."""
    fsm_dir = _find_fsm_template_dir()
    names = []
    for f in fsm_dir.iterdir():
        if f.is_file() and f.suffix.lower() in (".yaml", ".yml"):
            names.append(f.name)
    return sorted(names)


def _get_fsm_template_path(filename: str) -> Path:
    """Get path to an FSM template file; filename must be in allowlist."""
    safe_name = Path(filename).name
    if safe_name != filename or ".." in filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid filename",
        )
    allowed = _list_fsm_templates()
    if safe_name not in allowed:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"FSM template not found: {filename}. Available: {allowed[:10]}{'...' if len(allowed) > 10 else ''}",
        )
    return _find_fsm_template_dir() / safe_name


@router.get(
    "/templates/fsm/zip",
    summary="Download FSM templates ZIP",
    description="Download a ZIP archive containing all FSM template files (e.g. blank.yaml, order_management.yaml).",
    response_description="ZIP archive containing template files",
    tags=["Templates"],
)
async def download_fsm_templates_zip() -> Response:
    """Return all FSM templates as a single ZIP file."""
    try:
        fsm_dir = _find_fsm_template_dir()
        names = _list_fsm_templates()
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for name in names:
                template_path = fsm_dir / name
                zip_file.write(template_path, arcname=name)
        zip_buffer.seek(0)
        zip_content = zip_buffer.read()
        zip_buffer.close()
        return Response(
            content=zip_content,
            media_type="application/zip",
            headers={
                "Content-Disposition": 'attachment; filename="fsm_templates.zip"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error creating FSM templates ZIP: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create FSM templates ZIP",
        )


@router.get(
    "/templates/fsm",
    summary="List FSM template filenames",
    description="Return a list of available FSM template filenames (e.g. blank.yaml, order_management.yaml). Use GET /templates/fsm/{filename} to get one.",
    response_description="JSON object with templates array",
    tags=["Templates"],
)
async def list_fsm_templates():
    """List available FSM template filenames."""
    try:
        names = _list_fsm_templates()
        return {"templates": names}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error listing FSM templates: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list FSM templates: {str(e)}",
        )


@router.get(
    "/templates/fsm/{filename:path}",
    summary="Get FSM template content",
    description="Return a single FSM template as YAML text by filename (e.g. blank.yaml, order_management.yaml).",
    response_class=PlainTextResponse,
    tags=["Templates"],
)
async def get_fsm_template(filename: str):
    """Return one FSM template file content as YAML text."""
    try:
        template_path = _get_fsm_template_path(filename)
        content = template_path.read_text(encoding="utf-8")
        return PlainTextResponse(content=content, media_type="application/x-yaml")
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error serving FSM template %s: %s", filename, e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve FSM template: {str(e)}",
        )
