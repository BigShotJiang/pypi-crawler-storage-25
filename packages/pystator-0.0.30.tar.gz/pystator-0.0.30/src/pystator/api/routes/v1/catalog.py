"""Catalog API route for built-in guards, actions, effects, and operators.

Serves metadata about pystator's built-in capabilities so the UI
can display them in a browser panel with descriptions and parameter schemas.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from pystator.catalog import get_builtin_catalog

router = APIRouter(prefix="/catalog")


@router.get(
    "/builtins",
    summary="List built-in guards, actions, effects, and check operators",
    description="Returns metadata for all built-in capabilities with descriptions "
    "and parameter schemas. Used by the UI's built-in browser panel.",
)
async def list_builtins() -> dict[str, Any]:
    """Return the full built-in catalog."""
    return get_builtin_catalog()
