"""Route handlers for observability dashboards.

Provides fleet-level operational visibility over entity transitions and
worker queue activity.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from pystator.api.dependencies.database import get_db_session
from pystator.api.models.responses import (
    EntityHealthResponse,
    ObservabilityStateMetricsResponse,
    ObservabilitySummaryResponse,
    ObservabilityTransitionItem,
    ObservabilityTransitionsResponse,
    ObservabilityWorkerEventItem,
    ObservabilityWorkerEventsResponse,
    StateOpsAgeBuckets,
    StateOpsErrorTopItem,
    StateOpsMetricsItem,
    TransitionAnalyticsResponse,
)
from pystator.api.services.analytics_service import (
    compute_entity_health,
    compute_transition_analytics,
)
from pystator.api.services.state_metrics_service import compute_state_metrics
from pystator.db.models import (
    EntityStateModel,
    TransitionHistoryModel,
    WorkerEventModel,
)

router = APIRouter(prefix="/observability")


def _window_start(hours: int) -> datetime:
    """Return UTC window start timestamp for a trailing-hour window."""
    return datetime.now(UTC) - timedelta(hours=hours)


def _compute_p95(values: list[int]) -> int | None:
    """Compute p95 using nearest-rank method for a list of integer values."""
    if not values:
        return None
    sorted_values = sorted(values)
    rank = max(1, (95 * len(sorted_values) + 99) // 100)
    return sorted_values[min(rank - 1, len(sorted_values) - 1)]


@router.get(
    "/summary",
    response_model=ObservabilitySummaryResponse,
    summary="Get observability summary",
    description="Return high-level runtime KPIs for transitions and worker events.",
)
async def get_observability_summary(
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours for transition metrics",
    ),
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    entity_id: str | None = Query(default=None, description="Filter by entity id"),
) -> ObservabilitySummaryResponse:
    """Return dashboard summary metrics for the selected scope."""
    end_time = datetime.now(UTC)
    start_time = _window_start(window_hours)

    transitions_query = session.query(TransitionHistoryModel).filter(
        TransitionHistoryModel.created_at >= start_time,
        TransitionHistoryModel.created_at <= end_time,
    )
    if machine_name:
        transitions_query = transitions_query.filter(
            TransitionHistoryModel.machine_name == machine_name
        )
    if entity_id:
        transitions_query = transitions_query.filter(
            TransitionHistoryModel.entity_id == entity_id
        )

    transitions_total = transitions_query.count()
    transitions_failed = transitions_query.filter(
        TransitionHistoryModel.success.is_(False)
    ).count()

    duration_rows = transitions_query.with_entities(
        TransitionHistoryModel.duration_ms
    ).all()
    durations = [
        int(row[0])
        for row in duration_rows
        if row[0] is not None and isinstance(row[0], int)
    ]

    entities_query = session.query(EntityStateModel)
    if machine_name:
        entities_query = entities_query.filter(
            EntityStateModel.machine_name == machine_name
        )
    if entity_id:
        entities_query = entities_query.filter(EntityStateModel.entity_id == entity_id)
    active_entities = entities_query.count()

    worker_query = session.query(WorkerEventModel)
    if machine_name:
        worker_query = worker_query.filter(
            WorkerEventModel.machine_name == machine_name
        )
    if entity_id:
        worker_query = worker_query.filter(WorkerEventModel.entity_id == entity_id)

    worker_pending = worker_query.filter(WorkerEventModel.status == "pending").count()
    worker_claimed = worker_query.filter(WorkerEventModel.status == "claimed").count()
    worker_failed = worker_query.filter(WorkerEventModel.status == "failed").count()
    worker_dead_letter = worker_query.filter(
        WorkerEventModel.status == "dead_letter"
    ).count()

    failure_rate = (
        (transitions_failed / transitions_total) if transitions_total else 0.0
    )

    return ObservabilitySummaryResponse(
        window_start=start_time,
        window_end=end_time,
        active_entities=active_entities,
        transitions_total=transitions_total,
        transitions_failed=transitions_failed,
        transition_failure_rate=failure_rate,
        p95_transition_duration_ms=_compute_p95(durations),
        worker_pending=worker_pending,
        worker_claimed=worker_claimed,
        worker_failed=worker_failed,
        worker_dead_letter=worker_dead_letter,
    )


@router.get(
    "/transitions",
    response_model=ObservabilityTransitionsResponse,
    summary="List transition events",
    description="Return paginated transition history across entities with filters.",
)
async def list_observability_transitions(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    entity_id: str | None = Query(default=None, description="Filter by entity id"),
    status: Literal["all", "success", "failed"] = Query(
        default="all", description="Filter by transition outcome"
    ),
    start_at: datetime | None = Query(
        default=None, description="Filter transitions at or after this UTC datetime"
    ),
    end_at: datetime | None = Query(
        default=None, description="Filter transitions at or before this UTC datetime"
    ),
    limit: int = Query(default=50, ge=1, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> ObservabilityTransitionsResponse:
    """Return paginated transition history with optional filters."""
    query = session.query(TransitionHistoryModel)

    if machine_name:
        query = query.filter(TransitionHistoryModel.machine_name == machine_name)
    if entity_id:
        query = query.filter(TransitionHistoryModel.entity_id == entity_id)
    if status == "success":
        query = query.filter(TransitionHistoryModel.success.is_(True))
    elif status == "failed":
        query = query.filter(TransitionHistoryModel.success.is_(False))
    if start_at is not None:
        query = query.filter(TransitionHistoryModel.created_at >= start_at)
    if end_at is not None:
        query = query.filter(TransitionHistoryModel.created_at <= end_at)

    total = query.count()
    rows = (
        query.order_by(TransitionHistoryModel.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return ObservabilityTransitionsResponse(
        items=[
            ObservabilityTransitionItem(
                id=str(row.id),
                entity_id=row.entity_id,
                machine_name=row.machine_name,
                source_state=row.source_state,
                target_state=row.target_state,
                trigger=row.trigger,
                success=row.success,
                error_message=row.error_message,
                actions_executed=row.actions_executed,
                duration_ms=row.duration_ms,
                created_at=row.created_at,
            )
            for row in rows
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/worker-events",
    response_model=ObservabilityWorkerEventsResponse,
    summary="List worker queue events",
    description="Return paginated worker event queue rows with filters.",
)
async def list_observability_worker_events(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    entity_id: str | None = Query(default=None, description="Filter by entity id"),
    status: Literal[
        "all", "pending", "claimed", "completed", "failed", "dead_letter"
    ] = Query(default="all", description="Filter by worker event status"),
    start_at: datetime | None = Query(
        default=None,
        description="Filter events created at or after this UTC datetime",
    ),
    end_at: datetime | None = Query(
        default=None,
        description="Filter events created at or before this UTC datetime",
    ),
    limit: int = Query(default=50, ge=1, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> ObservabilityWorkerEventsResponse:
    """Return paginated worker events with optional filters."""
    query = session.query(WorkerEventModel)

    if machine_name:
        query = query.filter(WorkerEventModel.machine_name == machine_name)
    if entity_id:
        query = query.filter(WorkerEventModel.entity_id == entity_id)
    if status != "all":
        query = query.filter(WorkerEventModel.status == status)
    if start_at is not None:
        query = query.filter(WorkerEventModel.created_at >= start_at)
    if end_at is not None:
        query = query.filter(WorkerEventModel.created_at <= end_at)

    total = query.count()
    rows = (
        query.order_by(WorkerEventModel.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return ObservabilityWorkerEventsResponse(
        items=[
            ObservabilityWorkerEventItem(
                id=str(row.id),
                machine_name=row.machine_name,
                entity_id=row.entity_id,
                trigger=row.trigger,
                status=row.status,
                attempt=row.attempt,
                max_attempts=row.max_attempts,
                error_message=row.error_message,
                fires_at=row.fires_at,
                claimed_by=row.claimed_by,
                claimed_at=row.claimed_at,
                created_at=row.created_at,
                completed_at=row.completed_at,
                result_json=row.result_json,
                transition_history_id=(
                    str(row.transition_history_id)
                    if row.transition_history_id is not None
                    else None
                ),
            )
            for row in rows
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/state-metrics",
    response_model=ObservabilityStateMetricsResponse,
    summary="Get per-state operational metrics",
    description=(
        "Return minimal per-state metrics for augmenting the state diagram (counts, age, failures)."
    ),
)
async def get_observability_state_metrics(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str = Query(..., description="Machine name (required)"),
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours for failure metrics",
    ),
) -> ObservabilityStateMetricsResponse:
    window, metrics_by_state = compute_state_metrics(
        session=session,
        machine_name=machine_name,
        window_hours=window_hours,
    )

    items: list[StateOpsMetricsItem] = []
    for state_name, m in metrics_by_state.items():
        age_b = m.get("age_buckets") or {}
        top = m.get("top_error")
        items.append(
            StateOpsMetricsItem(
                state_name=state_name,
                entity_count=int(m.get("entity_count") or 0),
                age_p95_seconds=m.get("age_p95_seconds"),
                age_oldest_seconds=m.get("age_oldest_seconds"),
                age_buckets=StateOpsAgeBuckets(
                    le_5m=int(age_b.get("le_5m") or 0),
                    le_30m=int(age_b.get("le_30m") or 0),
                    gt_30m=int(age_b.get("gt_30m") or 0),
                ),
                failed_transition_count=int(m.get("failed_transition_count") or 0),
                top_error=StateOpsErrorTopItem(**top)
                if isinstance(top, dict)
                else None,
            )
        )

    return ObservabilityStateMetricsResponse(
        machine_name=machine_name,
        window_start=window.start,
        window_end=window.end,
        items=items,
    )


@router.get(
    "/entity-health",
    response_model=EntityHealthResponse,
    summary="Get entity health analytics",
    description="Return entity-centric health metrics including state/status distribution.",
)
async def get_entity_health(
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window for failure metrics",
    ),
    machine_name: str | None = Query(default=None, description="Filter by machine"),
) -> EntityHealthResponse:
    """Return entity health analytics."""
    data = compute_entity_health(session, window_hours, machine_name)
    return EntityHealthResponse(**data)


@router.get(
    "/transition-analytics",
    response_model=TransitionAnalyticsResponse,
    summary="Get transition analytics",
    description="Return time-series and aggregate transition analytics.",
)
async def get_transition_analytics(
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours",
    ),
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    bucket_count: int = Query(
        default=12,
        ge=2,
        le=48,
        description="Number of time buckets",
    ),
) -> TransitionAnalyticsResponse:
    """Return transition analytics with time bucketing."""
    data = compute_transition_analytics(
        session, window_hours, machine_name, bucket_count
    )
    return TransitionAnalyticsResponse(**data)
