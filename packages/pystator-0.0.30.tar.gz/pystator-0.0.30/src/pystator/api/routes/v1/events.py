"""SSE endpoint for real-time config change notifications."""

from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from pystator.events import ChangeBus

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get(
    "/events/stream",
    summary="Stream config change events (SSE)",
    description=(
        "Server-Sent Events stream for real-time config change notifications."
    ),
)
async def event_stream(
    request: Request,
    topic: str = "*",
) -> StreamingResponse:
    """Stream config change events via Server-Sent Events.

    Args:
        request: The incoming HTTP request.
        topic: Comma-separated topics to subscribe to.
    """
    bus: ChangeBus = request.app.state.change_bus

    topics = [t.strip() for t in topic.split(",") if t.strip()]
    if not topics:
        topics = ["*"]
    queues = [bus.subscribe(t) for t in topics]

    async def _generate():
        try:
            while True:
                if await request.is_disconnected():
                    break
                for q in queues:
                    try:
                        event = q.get_nowait()
                        if event is None:
                            return
                        data = json.dumps(
                            {
                                "topic": event.topic,
                                "action": event.action,
                                "resource_id": event.resource_id,
                                "revision": event.revision,
                                "actor": event.actor,
                                "timestamp": event.timestamp,
                            }
                        )
                        yield f"data: {data}\n\n"
                    except asyncio.QueueEmpty:
                        pass
                await asyncio.sleep(0.5)
        finally:
            for q in queues:
                for t in topics:
                    bus.unsubscribe(q, t)

    return StreamingResponse(
        _generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
