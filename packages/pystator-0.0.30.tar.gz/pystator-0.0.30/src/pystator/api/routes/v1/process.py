"""Route handlers for FSM process (transition) operations."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status

from pystator.api.dependencies import get_fsm_service
from pystator.api.models.requests import ProcessRequest
from pystator.api.models.responses import ProcessResponse
from pystator.api.services.discovery_service import DiscoveryService
from pystator.api.services.fsm_service import FSMService
from pystator.config import is_discovery_shadow_enabled

router = APIRouter()


@router.post(
    "/process",
    response_model=ProcessResponse,
    status_code=status.HTTP_200_OK,
    summary="Process FSM event",
    description="Build machine from config and compute transition for one event. "
    "Returns HTTP 200 with success true or false; failed transitions use the structured "
    "`error` field (not 4xx). 400 if the request cannot be processed (e.g. invalid config). "
    "Guards are pass-through.",
    responses={
        200: {"description": "Transition computed (check success and error fields)"},
        400: {"description": "Request could not be processed (e.g. invalid config)"},
        422: {"description": "Validation error"},
    },
)
async def process_event(
    request: ProcessRequest,
    service: Annotated[FSMService, Depends(get_fsm_service)],
) -> ProcessResponse:
    """
    Process one FSM event.

    Accepts full FSM config, current state, trigger, and optional context.
    Returns success/failure, structured error when applicable, target state,
    and actions to execute. The API does not persist state or execute actions;
    the client does that.
    """
    try:
        result = service.process(
            config=request.config,
            current_state=request.current_state,
            trigger=request.trigger,
            context=request.context,
        )
        if is_discovery_shadow_enabled():
            machine_name = str(
                request.config.get("meta", {}).get("machine_name", "default")
            )
            diff = DiscoveryService().run_shadow_compare(
                machine_name=machine_name,
                active_config=request.config,
                source_state=request.current_state,
                trigger=request.trigger,
                context=request.context,
            )
            if diff is not None:
                metadata = dict(result.get("metadata") or {})
                metadata["shadow_diff"] = {
                    "differs": diff.differs,
                    "reason": diff.reason,
                    "candidate_success": diff.candidate_success,
                    "candidate_target_state": diff.candidate_target_state,
                    "candidate_version": diff.metadata.get("candidate_version"),
                }
                result["metadata"] = metadata
        return ProcessResponse(**result)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
