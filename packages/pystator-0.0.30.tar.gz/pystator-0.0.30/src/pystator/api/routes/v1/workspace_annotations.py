"""Workspace annotations (state-anchored notes)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session
from pystator.api.models.responses import WorkspaceAnnotationsListResponse
from pystator.db.models.annotation import WorkspaceAnnotationModel

router = APIRouter(prefix="/annotations")


@router.get(
    "",
    response_model=WorkspaceAnnotationsListResponse,
    status_code=status.HTTP_200_OK,
    summary="List annotations for a machine version",
)
async def list_annotations(
    machine_name: str = Query(..., description="Machine name"),
    machine_version: str = Query(..., description="Machine version"),
    session: Session = Depends(get_db_session),
) -> WorkspaceAnnotationsListResponse:
    rows = (
        session.query(WorkspaceAnnotationModel)
        .filter(
            WorkspaceAnnotationModel.machine_name == machine_name,
            WorkspaceAnnotationModel.machine_version == machine_version,
        )
        .order_by(WorkspaceAnnotationModel.state_name.asc())
        .all()
    )
    return WorkspaceAnnotationsListResponse(
        machine_name=machine_name,
        machine_version=machine_version,
        items=[
            {
                "state_name": r.state_name,
                "body_markdown": r.body_markdown or "",
                "updated_at": r.updated_at,
            }
            for r in rows
        ],
    )


@router.put(
    "/{machine_name}/{machine_version}/{state_name}",
    status_code=status.HTTP_200_OK,
    summary="Upsert one state annotation (idempotent)",
)
async def upsert_annotation(
    machine_name: str,
    machine_version: str,
    state_name: str,
    body: dict,
    session: Session = Depends(get_db_session),
) -> dict:
    body_markdown = str(body.get("body_markdown") or "")
    row = (
        session.query(WorkspaceAnnotationModel)
        .filter(
            WorkspaceAnnotationModel.machine_name == machine_name,
            WorkspaceAnnotationModel.machine_version == machine_version,
            WorkspaceAnnotationModel.state_name == state_name,
        )
        .first()
    )
    if row is None:
        row = WorkspaceAnnotationModel(
            machine_name=machine_name,
            machine_version=machine_version,
            state_name=state_name,
            body_markdown=body_markdown,
        )
        session.add(row)
    else:
        row.body_markdown = body_markdown
    session.commit()
    return {"ok": True}


@router.delete(
    "/{machine_name}/{machine_version}/{state_name}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete one state annotation",
)
async def delete_annotation(
    machine_name: str,
    machine_version: str,
    state_name: str,
    session: Session = Depends(get_db_session),
) -> None:
    deleted = (
        session.query(WorkspaceAnnotationModel)
        .filter(
            WorkspaceAnnotationModel.machine_name == machine_name,
            WorkspaceAnnotationModel.machine_version == machine_version,
            WorkspaceAnnotationModel.state_name == state_name,
        )
        .delete(synchronize_session="fetch")
    )
    session.commit()
    if deleted == 0:
        raise HTTPException(status_code=404, detail="annotation not found")


@router.post(
    "/{machine_name}/{machine_version}/rename",
    status_code=status.HTTP_200_OK,
    summary="Move an annotation from old state name to new state name",
)
async def rename_annotation(
    machine_name: str,
    machine_version: str,
    body: dict,
    session: Session = Depends(get_db_session),
) -> dict:
    old_state_name = str(body.get("old_state_name") or "")
    new_state_name = str(body.get("new_state_name") or "")
    if not old_state_name or not new_state_name:
        raise HTTPException(
            status_code=400, detail="old_state_name and new_state_name required"
        )

    row = (
        session.query(WorkspaceAnnotationModel)
        .filter(
            WorkspaceAnnotationModel.machine_name == machine_name,
            WorkspaceAnnotationModel.machine_version == machine_version,
            WorkspaceAnnotationModel.state_name == old_state_name,
        )
        .first()
    )
    if row is None:
        return {"ok": True, "moved": False}

    existing_target = (
        session.query(WorkspaceAnnotationModel)
        .filter(
            WorkspaceAnnotationModel.machine_name == machine_name,
            WorkspaceAnnotationModel.machine_version == machine_version,
            WorkspaceAnnotationModel.state_name == new_state_name,
        )
        .first()
    )
    if existing_target is not None:
        session.delete(row)
    else:
        row.state_name = new_state_name
    session.commit()
    return {"ok": True, "moved": True}
