"""Route handlers for entity state management (full-service mode).

Unlike /process which is stateless compute-only, these endpoints
manage entity state in the database via SQLAlchemy-backed state stores.

Full service workflow:
1. Load state from DB (entity_states table)
2. Load machine config from DB or request
3. Process event (compute transition)
4. Persist new state to DB
5. Record transition history
6. Return result with actions to execute
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from pystator.api.dependencies.database import get_db_session
from pystator.api.models.requests import (
    ApplyDataRequest,
    CreateEntityRequest,
    DryRunRequest,
    ImportEntityRequest,
    PatchLabelsRequest,
    ProcessEntityEventRequest,
    UpdateLabelsRequest,
)
from pystator.api.models.responses import (
    ApplyDataEnqueueResponse,
    AvailableTriggersResponse,
    CreateEntityResponse,
    DryRunResponse,
    EntityLabelsResponse,
    EntityListResponse,
    EntityMetricsResponse,
    EntitySnapshotResponse,
    EntityStateResponse,
    EntityTimelineResponse,
    FsmOutcomeError,
    HistoryPurgeResponse,
    HistoryStatsResponse,
    ImportEntityResponse,
    ProcessEntityEventResponse,
    TimelineStep,
    TransitionHistoryResponse,
    TransitionHistorySnapshotItem,
    TriggerInfo,
)
from pystator.api.services.analytics_service import compute_entity_timeline
from pystator.api.services.entity_metrics_service import compute_entity_metrics
from pystator.api.services.entity_service import (
    EntityAlreadyExistsError,
    EntityNotActiveError,
    EntityNotFoundError,
    EntityQueryFilters,
    MachineNotFoundError,
    NoInitialStateForMachineError,
    archive_entity,
    create_entity_at_initial,
    delete_entity_label,
    encode_cursor,
    export_entity_snapshot,
    get_active_entity,
    get_entity_labels,
    get_history_stats,
    import_entity_from_snapshot,
    load_machine_config,
    merge_entity_labels,
    purge_entity,
    purge_history_before,
    query_entities,
    restore_entity,
    set_entity_labels,
    soft_delete_entity,
)
from pystator.api.services.entity_service import (
    process_entity_event as process_entity_event_service,
)
from pystator.api.services.fsm_service import FSMService, build_machine_from_config
from pystator.api.services.transition_outcome import action_names_from_payload
from pystator.db.models import EntityStateModel, EventLogModel, TransitionHistoryModel
from pystator.db.models.machine import MachineModel
from pystator.shared.entity_id_validator import validate_entity_id
from pystator.workflow_status import WORKFLOW_STATUS_ACTIVE, WORKFLOW_VALID_STATUSES

router = APIRouter(prefix="/entities")


# ============================================================
# Helper Functions
# ============================================================


def _validated_entity_id(entity_id: str) -> str:
    """Validate and return entity_id from path parameter, or raise 422."""
    try:
        return validate_entity_id(entity_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from None


def _get_machine_config(
    session: Session,
    machine_name: str,
    machine_version: str | None = None,
) -> dict[str, Any]:
    """Load machine config from database, raising HTTPException on failure."""
    try:
        return load_machine_config(session, machine_name, machine_version)
    except MachineNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from None


def _entity_state_response(entity: EntityStateModel) -> EntityStateResponse:
    """Build an EntityStateResponse from a DB model."""
    return EntityStateResponse(
        entity_id=entity.entity_id,
        current_state=entity.current_state,
        machine_name=entity.machine_name,
        machine_version=getattr(entity, "machine_version", None),
        context=entity.context_json or {},
        status=entity.status or "active",
        workflow_status=entity.workflow_status or WORKFLOW_STATUS_ACTIVE,
        is_terminal=entity.is_terminal,
        labels=entity.labels_json or {},
        updated_at=entity.updated_at,
        created_at=entity.created_at,
        archived_at=entity.archived_at,
        deleted_at=entity.deleted_at,
    )


# ============================================================
# Route Handlers — Core CRUD
# ============================================================


@router.get(
    "/{entity_id}/state",
    response_model=EntityStateResponse,
    summary="Get entity state",
    description="Get the current state for an entity from the database.",
    responses={
        200: {"description": "Entity state returned"},
        404: {"description": "Entity not found"},
    },
)
async def get_entity_state(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityStateResponse:
    """Get current state for an entity."""
    entity_id = _validated_entity_id(entity_id)

    entity = (
        session.query(EntityStateModel)
        .filter(
            EntityStateModel.entity_id == entity_id,
            EntityStateModel.status == "active",
        )
        .first()
    )

    if not entity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        )

    return _entity_state_response(entity)


@router.post(
    "/{entity_id}/create",
    response_model=CreateEntityResponse,
    summary="Create entity at initial state",
    description=(
        "Create a new entity row at the machine's initial state without processing "
        "an FSM event. Records a transition history row with trigger __entity_created__. "
        "Returns 409 if the entity already exists."
    ),
    responses={
        200: {"description": "Entity created"},
        400: {"description": "Machine has no initial state"},
        404: {"description": "Machine not found"},
        409: {"description": "Entity already exists"},
    },
)
async def create_entity(
    entity_id: str,
    request: CreateEntityRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> CreateEntityResponse:
    """Persist entity at initial state (no FSM transition)."""
    entity_id = _validated_entity_id(entity_id)

    start_time = time.time()
    machine_config = _get_machine_config(
        session, request.machine_name, request.machine_version
    )
    duration_ms = int((time.time() - start_time) * 1000)

    try:
        entity, history = create_entity_at_initial(
            session,
            entity_id=entity_id,
            machine_name=request.machine_name,
            machine_config=machine_config,
            context=request.context,
            duration_ms=duration_ms,
        )
    except EntityAlreadyExistsError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Entity already exists: {entity_id}",
        ) from None
    except NoInitialStateForMachineError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Machine {request.machine_name} has no initial state",
        ) from None

    session.commit()

    return CreateEntityResponse(
        entity_id=entity.entity_id,
        current_state=entity.current_state,
        machine_name=entity.machine_name,
        context=entity.context_json or {},
        updated_at=entity.updated_at,
        created_at=entity.created_at,
        transition_id=str(history.id),
    )


@router.post(
    "/{entity_id}/events",
    response_model=ProcessEntityEventResponse,
    summary="Process event for entity",
    description=(
        "Full-service event processing: load state from DB, process event, "
        "persist new state, record history, return result. "
        "If entity doesn't exist, creates it with the machine's initial state."
    ),
    responses={
        200: {"description": "Event processed successfully"},
        400: {"description": "Invalid request or transition"},
        404: {"description": "Machine not found"},
    },
)
async def process_entity_event(
    entity_id: str,
    request: ProcessEntityEventRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> ProcessEntityEventResponse:
    """Process an event for an entity with full state persistence."""
    entity_id = _validated_entity_id(entity_id)

    try:
        result = process_entity_event_service(
            session,
            entity_id=entity_id,
            trigger=request.trigger,
            machine_name=request.machine_name,
            machine_version=request.machine_version,
            context=request.context,
        )
    except MachineNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from None
    except NoInitialStateForMachineError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Machine {exc.machine_name} has no initial state",
        ) from None
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from None

    session.commit()

    return ProcessEntityEventResponse(
        success=result.success,
        entity_id=result.entity_id,
        source_state=result.source_state,
        target_state=result.target_state,
        trigger=result.trigger,
        actions=result.actions,
        error_detail=FsmOutcomeError.model_validate(result.error_payload)
        if result.error_payload
        else None,
        error=result.error_message,
        shadow_diff=result.shadow_diff,
        transition_id=result.transition_id,
    )


@router.post(
    "/{entity_id}/apply-data",
    response_model=ApplyDataEnqueueResponse,
    summary="Enqueue triggerless apply-data update",
    description=(
        "Enqueue a triggerless context/state-variable update for worker processing. "
        "The worker will merge the data into entity context and evaluate post-transition "
        "routing (auto-transitions + when-route) via Orchestrator.apply_data."
    ),
    responses={
        200: {"description": "Apply-data event enqueued"},
        404: {"description": "Entity not found"},
        409: {"description": "Entity not active"},
    },
)
async def enqueue_apply_data(
    entity_id: str,
    request: ApplyDataRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> ApplyDataEnqueueResponse:
    """Enqueue an apply-data update for worker processing (does not process inline)."""
    entity_id = _validated_entity_id(entity_id)

    # Enforce semantics: entity must exist (and be active) to apply data.
    try:
        entity = get_active_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None
    except EntityNotActiveError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from None

    machine_name = (request.machine_name or entity.machine_name or "").strip()
    if not machine_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Entity has no machine_name; cannot route apply-data event",
        )

    # Parse fires_at (ISO) if provided. Keep this endpoint lean; validation can be expanded later.
    fires_at_dt: datetime | None = None
    if request.fires_at:
        try:
            fires_at_dt = datetime.fromisoformat(request.fires_at)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid fires_at timestamp: {request.fires_at!r}",
            ) from exc

    from pystator.worker import submit_apply_data

    event_id = await submit_apply_data(
        machine_name=machine_name,
        entity_id=entity_id,
        data=request.data,
        fires_at=fires_at_dt,
        idempotency_key=request.idempotency_key,
        max_attempts=request.max_attempts or 5,
    )

    return ApplyDataEnqueueResponse(
        entity_id=entity_id,
        machine_name=machine_name,
        event_id=event_id,
    )


@router.get(
    "/{entity_id}/timeline",
    response_model=EntityTimelineResponse,
    summary="Get entity journey timeline",
    description="Return the full state progression timeline for an entity.",
    responses={
        200: {"description": "Timeline returned"},
        404: {"description": "Entity not found"},
    },
)
async def get_entity_timeline(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityTimelineResponse:
    """Get the entity's full state journey as a timeline."""
    entity_id = _validated_entity_id(entity_id)

    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    if not entity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        )

    data = compute_entity_timeline(session, entity_id)

    return EntityTimelineResponse(
        entity_id=data["entity_id"],
        machine_name=data["machine_name"],
        current_state=data["current_state"],
        steps=[TimelineStep(**step) for step in data["steps"]],
        total_dwell_ms=data["total_dwell_ms"],
        states_visited=data["states_visited"],
    )


@router.get(
    "/{entity_id}/history",
    response_model=list[TransitionHistoryResponse],
    summary="Get entity transition history",
    description="Get the transition history for an entity.",
    responses={200: {"description": "Transition history returned"}},
)
async def get_entity_history(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    limit: int = Query(default=50, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> list[TransitionHistoryResponse]:
    """Get transition history for an entity."""
    entity_id = _validated_entity_id(entity_id)

    history = (
        session.query(TransitionHistoryModel)
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .order_by(TransitionHistoryModel.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return [
        TransitionHistoryResponse(
            id=str(h.id),
            entity_id=h.entity_id,
            source_state=h.source_state,
            target_state=h.target_state,
            trigger=h.trigger,
            success=h.success,
            error_message=h.error_message,
            actions_executed=h.actions_executed,
            created_at=h.created_at,
            duration_ms=h.duration_ms,
        )
        for h in history
    ]


@router.delete(
    "/{entity_id}",
    response_model=EntityStateResponse,
    summary="Soft-delete entity state",
    description="Soft-delete an entity (sets status to deleted, preserves record).",
    responses={
        200: {"description": "Entity soft-deleted"},
        404: {"description": "Entity not found"},
    },
)
async def delete_entity(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityStateResponse:
    """Soft-delete an entity's state record."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = soft_delete_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None

    session.commit()
    return _entity_state_response(entity)


@router.get(
    "",
    response_model=EntityListResponse,
    summary="List entities",
    description="List entities with filtering, sorting, and cursor pagination.",
    responses={200: {"description": "Entity list returned"}},
)
async def list_entities(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    state: str | None = Query(default=None, description="Filter by current state"),
    is_terminal: bool | None = Query(default=None, description="Filter by terminal"),
    workflow_status: str | None = Query(
        default=None,
        description="Filter by workflow outcome (active, complete, failed)",
    ),
    entity_status: str | None = Query(
        default=None, alias="status", description="Filter by lifecycle status"
    ),
    include_archived: bool = Query(default=False, description="Include archived"),
    include_deleted: bool = Query(default=False, description="Include deleted"),
    created_after: datetime | None = Query(default=None, description="Created after"),
    created_before: datetime | None = Query(default=None, description="Created before"),
    updated_after: datetime | None = Query(default=None, description="Updated after"),
    updated_before: datetime | None = Query(default=None, description="Updated before"),
    labels: str | None = Query(
        default=None, description="Label filter as key=val,key2=val2"
    ),
    sort_by: str = Query(default="created_at", description="Sort field"),
    sort_order: str = Query(default="desc", description="Sort order: asc or desc"),
    limit: int = Query(default=50, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
    cursor: str | None = Query(default=None, description="Pagination cursor"),
    page_size: int | None = Query(default=None, le=200, description="Cursor page size"),
) -> EntityListResponse:
    """List entities with optional filtering, sorting, and cursor pagination."""
    if workflow_status is not None and workflow_status not in WORKFLOW_VALID_STATUSES:
        raise HTTPException(
            status_code=422,
            detail=(
                f"Invalid workflow_status: {workflow_status!r}; "
                f"expected one of {sorted(WORKFLOW_VALID_STATUSES)}"
            ),
        )

    parsed_labels: dict[str, str] | None = None
    if labels:
        parsed_labels = {}
        for pair in labels.split(","):
            if "=" in pair:
                k, v = pair.split("=", 1)
                parsed_labels[k.strip()] = v.strip()

    filters = EntityQueryFilters(
        machine_name=machine_name,
        state=state,
        is_terminal=is_terminal,
        workflow_status=workflow_status,
        status=entity_status or "active",
        include_archived=include_archived,
        include_deleted=include_deleted,
        created_after=created_after,
        created_before=created_before,
        updated_after=updated_after,
        updated_before=updated_before,
        labels=parsed_labels,
        sort_by=sort_by,
        sort_order=sort_order,
        limit=limit,
        offset=offset,
        cursor=cursor,
        page_size=page_size,
    )

    effective_limit = page_size or limit
    entities, total = query_entities(session, filters)

    next_cursor: str | None = None
    if len(entities) > effective_limit:
        entities = entities[:effective_limit]
        last = entities[-1]
        next_cursor = encode_cursor(last.entity_id, last.created_at)

    return EntityListResponse(
        entities=[_entity_state_response(e) for e in entities],
        total=total,
        limit=effective_limit,
        offset=offset,
        next_cursor=next_cursor,
    )


# ============================================================
# Route Handlers — Lifecycle (archive / restore / purge)
# ============================================================


@router.post(
    "/{entity_id}/archive",
    response_model=EntityStateResponse,
    summary="Archive entity",
    description="Set entity status to archived.",
    responses={
        200: {"description": "Entity archived"},
        404: {"description": "Entity not found"},
        409: {"description": "Entity already deleted"},
    },
)
async def archive_entity_route(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityStateResponse:
    """Archive an entity (set status to archived)."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = archive_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None
    except EntityNotActiveError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Entity {entity_id} is deleted and cannot be archived",
        ) from None

    session.commit()
    return _entity_state_response(entity)


@router.post(
    "/{entity_id}/restore",
    response_model=EntityStateResponse,
    summary="Restore entity",
    description="Restore an archived or deleted entity to active status.",
    responses={
        200: {"description": "Entity restored"},
        404: {"description": "Entity not found"},
    },
)
async def restore_entity_route(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityStateResponse:
    """Restore an entity to active status."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = restore_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None

    session.commit()
    return _entity_state_response(entity)


@router.delete(
    "/{entity_id}/purge",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Purge entity",
    description="Permanently delete entity and all its data.",
    responses={
        204: {"description": "Entity purged"},
        404: {"description": "Entity not found"},
    },
)
async def purge_entity_route(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> None:
    """Hard-delete an entity from the database."""
    entity_id = _validated_entity_id(entity_id)

    try:
        purge_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None

    session.commit()


# ============================================================
# Route Handlers — Labels
# ============================================================


@router.get(
    "/{entity_id}/labels",
    response_model=EntityLabelsResponse,
    summary="Get entity labels",
    responses={200: {"description": "Labels returned"}},
)
async def get_labels(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityLabelsResponse:
    """Get all labels for an entity."""
    entity_id = _validated_entity_id(entity_id)

    try:
        labels = get_entity_labels(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None

    return EntityLabelsResponse(entity_id=entity_id, labels=labels)


@router.put(
    "/{entity_id}/labels",
    response_model=EntityLabelsResponse,
    summary="Replace entity labels",
    responses={200: {"description": "Labels replaced"}},
)
async def replace_labels(
    entity_id: str,
    request: UpdateLabelsRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityLabelsResponse:
    """Replace all labels on an entity."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = set_entity_labels(session, entity_id, request.labels)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from None

    session.commit()
    return EntityLabelsResponse(entity_id=entity_id, labels=entity.labels_json or {})


@router.patch(
    "/{entity_id}/labels",
    response_model=EntityLabelsResponse,
    summary="Merge entity labels",
    responses={200: {"description": "Labels merged"}},
)
async def merge_labels(
    entity_id: str,
    request: PatchLabelsRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityLabelsResponse:
    """Merge labels into existing labels without removing unmentioned keys."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = merge_entity_labels(session, entity_id, request.labels)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from None

    session.commit()
    return EntityLabelsResponse(entity_id=entity_id, labels=entity.labels_json or {})


@router.delete(
    "/{entity_id}/labels/{key}",
    response_model=EntityLabelsResponse,
    summary="Delete a single label",
    responses={200: {"description": "Label deleted"}},
)
async def delete_label(
    entity_id: str,
    key: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityLabelsResponse:
    """Delete a single label by key."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = delete_entity_label(session, entity_id, key)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None

    session.commit()
    return EntityLabelsResponse(entity_id=entity_id, labels=entity.labels_json or {})


# ============================================================
# Route Handlers — Triggers / Dry-run
# ============================================================


@router.get(
    "/{entity_id}/available-triggers",
    response_model=AvailableTriggersResponse,
    summary="Get available triggers",
    description="List triggers available from the entity's current state.",
    responses={200: {"description": "Available triggers returned"}},
)
async def get_available_triggers(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> AvailableTriggersResponse:
    """Get triggers available from the entity's current state."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = get_active_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None
    except EntityNotActiveError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from None

    config = _get_machine_config(session, entity.machine_name)
    machine = build_machine_from_config(config)
    transitions = machine.get_available_transitions(entity.current_state)

    triggers = [
        TriggerInfo(
            trigger=t.trigger,
            target_state=t.dest,
            has_guard=bool(t.guards),
            guard_description=t.description or None,
        )
        for t in transitions
    ]

    return AvailableTriggersResponse(
        entity_id=entity_id,
        current_state=entity.current_state,
        triggers=triggers,
    )


@router.post(
    "/{entity_id}/dry-run",
    response_model=DryRunResponse,
    summary="Dry-run transition",
    description="Evaluate a transition without persisting any changes.",
    responses={200: {"description": "Dry-run result returned"}},
)
async def dry_run(
    entity_id: str,
    request: DryRunRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> DryRunResponse:
    """Evaluate a transition without persisting changes."""
    entity_id = _validated_entity_id(entity_id)

    try:
        entity = get_active_entity(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None
    except EntityNotActiveError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from None

    config = _get_machine_config(session, entity.machine_name)
    service = FSMService()
    result = service.process(
        config=config,
        current_state=entity.current_state,
        trigger=request.trigger,
        context=request.context,
    )

    actions = action_names_from_payload(result.get("actions_to_execute", []))

    return DryRunResponse(
        would_succeed=result.get("success", False),
        entity_id=entity_id,
        source_state=entity.current_state,
        target_state=result.get("target_state") if result.get("success") else None,
        trigger=request.trigger,
        actions_that_would_execute=actions,
        error_detail=result.get("error_message"),
    )


# ============================================================
# Route Handlers — Metrics
# ============================================================


@router.get(
    "/{entity_id}/metrics",
    response_model=EntityMetricsResponse,
    summary="Get entity metrics",
    description="Comprehensive per-entity health, error, performance, and behavioral metrics.",
    responses={
        200: {"description": "Entity metrics returned"},
        404: {"description": "Entity not found"},
    },
)
async def get_entity_metrics(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24, ge=1, le=168, description="Trailing window for fleet comparison"
    ),
) -> EntityMetricsResponse:
    """Get comprehensive metrics for a single entity."""
    entity_id = _validated_entity_id(entity_id)

    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    if not entity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        )

    data = compute_entity_metrics(session, entity_id, window_hours)
    return EntityMetricsResponse(**data)


# ============================================================
# Route Handlers — History stats / purge
# ============================================================


@router.get(
    "/{entity_id}/history/stats",
    response_model=HistoryStatsResponse,
    summary="Get history statistics",
    responses={200: {"description": "History stats returned"}},
)
async def get_history_statistics(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> HistoryStatsResponse:
    """Get aggregated history statistics for an entity."""
    entity_id = _validated_entity_id(entity_id)

    stats = get_history_stats(session, entity_id)
    return HistoryStatsResponse(
        entity_id=entity_id,
        total_transitions=stats["total_transitions"],
        first_at=stats["first_at"],
        last_at=stats["last_at"],
        success_count=stats["success_count"],
        failure_count=stats["failure_count"],
    )


@router.delete(
    "/{entity_id}/history",
    response_model=HistoryPurgeResponse,
    summary="Purge old history",
    description="Delete transition history records older than the given timestamp.",
    responses={200: {"description": "History purged"}},
)
async def purge_history(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    before: datetime = Query(..., description="Delete records before this timestamp"),
) -> HistoryPurgeResponse:
    """Delete transition history records older than *before*."""
    entity_id = _validated_entity_id(entity_id)

    deleted, remaining = purge_history_before(session, entity_id, before)
    session.commit()

    return HistoryPurgeResponse(
        entity_id=entity_id,
        deleted_count=deleted,
        remaining_count=remaining,
    )


# ============================================================
# Route Handlers — Snapshot / Import
# ============================================================


@router.get(
    "/{entity_id}/snapshot",
    response_model=EntitySnapshotResponse,
    summary="Export entity snapshot",
    description="Export full entity state and history as a snapshot.",
    responses={200: {"description": "Snapshot returned"}},
)
async def get_entity_snapshot(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntitySnapshotResponse:
    """Export full entity snapshot including state and history."""
    entity_id = _validated_entity_id(entity_id)

    try:
        snapshot = export_entity_snapshot(session, entity_id)
    except EntityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        ) from None

    history_items = [
        TransitionHistorySnapshotItem(
            source_state=h["source_state"],
            target_state=h.get("target_state"),
            trigger=h["trigger"],
            success=h["success"],
            error_message=h.get("error_message"),
            actions_executed=h.get("actions_executed"),
            created_at=h["created_at"],
            duration_ms=h.get("duration_ms"),
        )
        for h in snapshot.get("history", [])
    ]

    return EntitySnapshotResponse(
        entity_id=snapshot["entity_id"],
        machine_name=snapshot.get("machine_name"),
        current_state=snapshot["current_state"],
        context=snapshot.get("context", {}),
        status=snapshot.get("status", "active"),
        labels=snapshot.get("labels", {}),
        history=history_items,
        exported_at=snapshot["exported_at"],
    )


@router.post(
    "/import",
    response_model=ImportEntityResponse,
    summary="Import entity from snapshot",
    description="Import an entity and its history from a snapshot payload.",
    responses={
        200: {"description": "Entity imported"},
        409: {"description": "Entity already exists"},
    },
)
async def import_entity(
    request: ImportEntityRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> ImportEntityResponse:
    """Import an entity from a snapshot payload."""
    snapshot = {
        "entity_id": request.entity_id,
        "machine_name": request.machine_name,
        "current_state": request.current_state,
        "context": request.context,
        "status": request.status,
        "labels": request.labels,
        "history": request.history,
    }

    try:
        entity, history_count = import_entity_from_snapshot(
            session, snapshot, overwrite=request.overwrite
        )
    except EntityAlreadyExistsError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Entity already exists: {request.entity_id}",
        ) from None

    session.commit()

    return ImportEntityResponse(
        entity_id=entity.entity_id,
        history_count=history_count,
        success=True,
    )


# ============================================================
# Route Handlers — Event Log & Replay
# ============================================================


@router.get(
    "/{entity_id}/events",
    summary="Get event log",
    description="Paginated append-only event log for an entity.",
    responses={404: {"description": "Entity not found"}},
)
async def get_entity_events(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> dict[str, Any]:
    """Return paginated event log entries for an entity."""
    entity_id = _validated_entity_id(entity_id)
    rows = (
        session.query(EventLogModel)
        .filter(EventLogModel.entity_id == entity_id)
        .order_by(EventLogModel.sequence.asc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    total = (
        session.query(EventLogModel)
        .filter(EventLogModel.entity_id == entity_id)
        .count()
    )
    return {
        "events": [
            {
                "id": str(r.id),
                "entity_id": r.entity_id,
                "machine_name": r.machine_name,
                "sequence": r.sequence,
                "trigger": r.trigger,
                "payload": r.payload_json,
                "event_id": r.event_id,
                "source": r.source,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in rows
        ],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@router.post(
    "/{entity_id}/replay",
    summary="Replay entity from event log",
    description="Replay all persisted events to reconstruct entity state history.",
    responses={
        200: {"description": "Replay results"},
        404: {"description": "Entity not found or no events"},
    },
)
async def replay_entity(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    up_to_sequence: int | None = Query(None, ge=1),
) -> dict[str, Any]:
    """Replay entity from event log, returning state at each step."""
    entity_id = _validated_entity_id(entity_id)

    # Load entity to get machine config
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )
    if entity is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        )

    config = _get_machine_config(session, entity.machine_name, entity.machine_version)
    machine = build_machine_from_config(config)

    # Load events
    query = (
        session.query(EventLogModel)
        .filter(EventLogModel.entity_id == entity_id)
        .order_by(EventLogModel.sequence.asc())
    )
    if up_to_sequence is not None:
        query = query.filter(EventLogModel.sequence <= up_to_sequence)
    events = query.all()

    if not events:
        return {"steps": [], "total_events": 0}

    # Replay events through a fresh instance
    instance = machine.create(entity_id=entity_id)
    steps: list[dict[str, Any]] = []
    for evt in events:
        payload = evt.payload_json or {}
        try:
            result = instance.send(evt.trigger, **payload)
            steps.append(
                {
                    "sequence": evt.sequence,
                    "trigger": evt.trigger,
                    "source_state": result.source_state,
                    "target_state": result.target_state,
                    "success": result.success,
                    "current_state": instance.current_state,
                }
            )
        except Exception as exc:
            steps.append(
                {
                    "sequence": evt.sequence,
                    "trigger": evt.trigger,
                    "source_state": instance.current_state,
                    "target_state": None,
                    "success": False,
                    "error": str(exc),
                    "current_state": instance.current_state,
                }
            )

    return {
        "steps": steps,
        "total_events": len(events),
        "final_state": instance.current_state,
    }


# ============================================================
# Route Handlers — Workflow Versioning & Migration
# ============================================================


@router.post(
    "/{entity_id}/migrate",
    response_model=EntityStateResponse,
    summary="Migrate entity to a new machine version",
    description="Update the entity to use a different machine version. "
    "Validates that the current state exists in the target definition.",
    responses={
        200: {"description": "Entity migrated"},
        400: {"description": "Incompatible state"},
        404: {"description": "Entity or machine not found"},
    },
)
async def migrate_entity(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str = Query(..., description="Target machine name"),
    machine_version: str = Query(..., description="Target machine version"),
) -> EntityStateResponse:
    """Migrate an entity to a new machine version."""
    entity_id = _validated_entity_id(entity_id)
    entity = get_active_entity(session, entity_id)

    # Load target machine config
    target_config = _get_machine_config(session, machine_name, machine_version)
    target_machine = build_machine_from_config(target_config)

    # Validate compatibility: entity's current state must exist in target
    target_states = {s.name for s in target_machine.states}
    if entity.current_state not in target_states:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Entity's current state '{entity.current_state}' does not exist "
                f"in machine '{machine_name}' version '{machine_version}'. "
                f"Available states: {sorted(target_states)}"
            ),
        )

    # Load target machine DB row for machine_id
    target_row = (
        session.query(MachineModel)
        .filter(
            MachineModel.name == machine_name,
            MachineModel.version == machine_version,
        )
        .first()
    )

    # Update entity
    entity.machine_name = machine_name
    entity.machine_version = machine_version
    if target_row:
        entity.machine_id = target_row.id

    # Record migration in transition history
    history_row = TransitionHistoryModel(
        entity_id=entity_id,
        machine_name=machine_name,
        source_state=entity.current_state,
        target_state=entity.current_state,
        trigger="__migrate",
        success=True,
        context_snapshot={
            "previous_machine_version": getattr(entity, "machine_version", None),
            "new_machine_version": machine_version,
        },
    )
    session.add(history_row)
    session.commit()
    session.refresh(entity)

    return _entity_state_response(entity)
