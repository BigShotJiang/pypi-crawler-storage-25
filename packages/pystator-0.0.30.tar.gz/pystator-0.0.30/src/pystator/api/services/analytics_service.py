"""Analytics query functions for observability dashboards."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from pystator.db.models import EntityStateModel, TransitionHistoryModel

logger = logging.getLogger(__name__)


def _compute_percentiles(
    values: list[int],
    percentiles: list[int],
) -> dict[str, int | None]:
    """Compute percentiles using nearest-rank method.

    Args:
        values: Unsorted list of integer values.
        percentiles: Target percentiles (e.g. [50, 75, 95, 99]).

    Returns:
        Dict mapping "pN" to value, e.g. {"p50": 12, "p95": 100}.
    """
    if not values:
        return {f"p{p}": None for p in percentiles}

    sorted_vals = sorted(values)
    result: dict[str, int | None] = {}
    for pct in percentiles:
        rank = max(1, (pct * len(sorted_vals) + 99) // 100)
        idx = min(rank - 1, len(sorted_vals) - 1)
        result[f"p{pct}"] = sorted_vals[idx]
    return result


def _bucket_transitions(
    rows: list[tuple[datetime, bool]],
    bucket_count: int,
    window_start: datetime,
    window_end: datetime,
) -> list[dict[str, Any]]:
    """Distribute transitions into equal-width time buckets.

    Args:
        rows: List of (created_at, success) tuples.
        bucket_count: Number of buckets to create.
        window_start: Start of the time window.
        window_end: End of the time window.

    Returns:
        List of dicts with bucket_start, bucket_end, total, failed, failure_rate.
    """
    total_seconds = max((window_end - window_start).total_seconds(), 1)
    bucket_width = total_seconds / bucket_count

    buckets: list[dict[str, Any]] = []
    for idx in range(bucket_count):
        start = window_start + timedelta(seconds=idx * bucket_width)
        end = window_start + timedelta(seconds=(idx + 1) * bucket_width)
        buckets.append(
            {
                "bucket_start": start.isoformat(),
                "bucket_end": end.isoformat(),
                "total": 0,
                "failed": 0,
                "failure_rate": 0.0,
            }
        )

    for created_at, success in rows:
        # Normalize to offset-aware for SQLite compatibility
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=UTC)
        ws = window_start if window_start.tzinfo else window_start.replace(tzinfo=UTC)
        offset_s = (created_at - ws).total_seconds()
        bucket_idx = int(offset_s / bucket_width)
        bucket_idx = min(bucket_idx, bucket_count - 1)
        bucket_idx = max(bucket_idx, 0)
        buckets[bucket_idx]["total"] += 1
        if not success:
            buckets[bucket_idx]["failed"] += 1

    for bucket in buckets:
        if bucket["total"] > 0:
            bucket["failure_rate"] = round(bucket["failed"] / bucket["total"], 4)

    return buckets


def compute_entity_health(
    session: Session,
    window_hours: int,
    machine_name: str | None,
) -> dict[str, Any]:
    """Compute entity-centric health analytics.

    Args:
        session: Database session.
        window_hours: Trailing window for failure metrics.
        machine_name: Optional machine filter.

    Returns:
        Dict with state_distribution, status_distribution, machine_distribution,
        top_failing_entities, terminal_rate, total_entities.
    """
    entity_query = session.query(EntityStateModel)
    if machine_name:
        entity_query = entity_query.filter(
            EntityStateModel.machine_name == machine_name
        )

    total_entities = entity_query.count()

    # State distribution
    state_rows = (
        entity_query.with_entities(
            EntityStateModel.current_state,
            func.count(EntityStateModel.id),
        )
        .group_by(EntityStateModel.current_state)
        .all()
    )
    state_distribution = [
        {
            "state": row[0] or "unknown",
            "count": row[1],
            "percentage": round(row[1] / max(total_entities, 1) * 100, 1),
        }
        for row in state_rows
    ]
    state_distribution.sort(key=lambda item: item["count"], reverse=True)

    # Status distribution
    status_rows = (
        entity_query.with_entities(
            EntityStateModel.status,
            func.count(EntityStateModel.id),
        )
        .group_by(EntityStateModel.status)
        .all()
    )
    status_map = {row[0]: row[1] for row in status_rows}
    status_distribution = {
        "active": status_map.get("active", 0),
        "archived": status_map.get("archived", 0),
        "deleted": status_map.get("deleted", 0),
    }

    # Machine distribution
    machine_rows = (
        entity_query.with_entities(
            EntityStateModel.machine_name,
            func.count(EntityStateModel.id),
        )
        .group_by(EntityStateModel.machine_name)
        .all()
    )
    machine_distribution = [
        {"machine_name": row[0] or "unknown", "count": row[1]} for row in machine_rows
    ]
    machine_distribution.sort(key=lambda item: item["count"], reverse=True)

    # Top failing entities in window
    window_start = datetime.now(UTC) - timedelta(hours=window_hours)
    fail_query = session.query(
        TransitionHistoryModel.entity_id,
        func.count(TransitionHistoryModel.id).label("fail_count"),
        func.max(TransitionHistoryModel.created_at).label("last_at"),
    ).filter(
        TransitionHistoryModel.success.is_(False),
        TransitionHistoryModel.created_at >= window_start,
    )
    if machine_name:
        fail_query = fail_query.filter(
            TransitionHistoryModel.machine_name == machine_name
        )
    fail_rows = (
        fail_query.group_by(TransitionHistoryModel.entity_id)
        .order_by(func.count(TransitionHistoryModel.id).desc())
        .limit(10)
        .all()
    )
    top_failing_entities = [
        {
            "entity_id": row[0],
            "failure_count": row[1],
            "last_failure_at": row[2].isoformat() if row[2] else "",
        }
        for row in fail_rows
    ]

    # Terminal rate
    terminal_count = entity_query.filter(EntityStateModel.is_terminal.is_(True)).count()
    terminal_rate = round(terminal_count / max(total_entities, 1) * 100, 1)

    return {
        "state_distribution": state_distribution,
        "status_distribution": status_distribution,
        "machine_distribution": machine_distribution,
        "top_failing_entities": top_failing_entities,
        "terminal_rate": terminal_rate,
        "total_entities": total_entities,
    }


def compute_transition_analytics(
    session: Session,
    window_hours: int,
    machine_name: str | None,
    bucket_count: int,
) -> dict[str, Any]:
    """Compute transition analytics with time bucketing.

    Args:
        session: Database session.
        window_hours: Trailing window size in hours.
        machine_name: Optional machine filter.
        bucket_count: Number of time buckets.

    Returns:
        Dict with time_buckets, duration_percentiles, top_failing_triggers,
        top_failing_states, volume_trend.
    """
    window_end = datetime.now(UTC)
    window_start = window_end - timedelta(hours=window_hours)

    query = session.query(TransitionHistoryModel).filter(
        TransitionHistoryModel.created_at >= window_start,
        TransitionHistoryModel.created_at <= window_end,
    )
    if machine_name:
        query = query.filter(TransitionHistoryModel.machine_name == machine_name)

    # Fetch relevant columns
    rows = query.with_entities(
        TransitionHistoryModel.created_at,
        TransitionHistoryModel.success,
        TransitionHistoryModel.duration_ms,
        TransitionHistoryModel.trigger,
        TransitionHistoryModel.source_state,
    ).all()

    # Time buckets
    time_rows = [(row[0], row[1]) for row in rows if row[0] is not None]
    time_buckets = _bucket_transitions(
        time_rows, bucket_count, window_start, window_end
    )

    # Volume trend (just total per bucket)
    volume_trend = [
        {"bucket_start": bucket["bucket_start"], "count": bucket["total"]}
        for bucket in time_buckets
    ]

    # Duration percentiles
    durations = [
        int(row[2]) for row in rows if row[2] is not None and isinstance(row[2], int)
    ]
    duration_percentiles = _compute_percentiles(durations, [50, 75, 95, 99])

    # Top failing triggers
    trigger_stats: dict[str, dict[str, int]] = {}
    for row in rows:
        trigger = row[3] or "unknown"
        if trigger not in trigger_stats:
            trigger_stats[trigger] = {"total": 0, "failed": 0}
        trigger_stats[trigger]["total"] += 1
        if not row[1]:
            trigger_stats[trigger]["failed"] += 1

    top_failing_triggers = sorted(
        [
            {
                "trigger": trigger,
                "total": stats["total"],
                "failed": stats["failed"],
                "failure_rate": round(stats["failed"] / max(stats["total"], 1), 4),
            }
            for trigger, stats in trigger_stats.items()
            if stats["failed"] > 0
        ],
        key=lambda item: item["failed"],
        reverse=True,
    )[:10]

    # Top failing states
    state_stats: dict[str, dict[str, int]] = {}
    for row in rows:
        state = row[4] or "unknown"
        if state not in state_stats:
            state_stats[state] = {"total": 0, "failed": 0}
        state_stats[state]["total"] += 1
        if not row[1]:
            state_stats[state]["failed"] += 1

    top_failing_states = sorted(
        [
            {
                "state": state,
                "total": stats["total"],
                "failed": stats["failed"],
                "failure_rate": round(stats["failed"] / max(stats["total"], 1), 4),
            }
            for state, stats in state_stats.items()
            if stats["failed"] > 0
        ],
        key=lambda item: item["failed"],
        reverse=True,
    )[:10]

    return {
        "time_buckets": time_buckets,
        "duration_percentiles": duration_percentiles,
        "top_failing_triggers": top_failing_triggers,
        "top_failing_states": top_failing_states,
        "volume_trend": volume_trend,
    }


def compute_entity_timeline(
    session: Session,
    entity_id: str,
) -> dict[str, Any]:
    """Compute entity journey timeline with dwell times.

    Args:
        session: Database session.
        entity_id: Entity identifier.

    Returns:
        Dict with entity_id, machine_name, current_state, steps,
        total_dwell_ms, states_visited.
    """
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )

    history = (
        session.query(TransitionHistoryModel)
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .order_by(TransitionHistoryModel.created_at.asc())
        .all()
    )

    steps: list[dict[str, Any]] = []
    visited_states: set[str] = set()

    for idx, row in enumerate(history):
        target = row.target_state or row.source_state
        visited_states.add(target)

        entered_at = row.created_at
        entered_iso = entered_at.isoformat() if entered_at else ""

        # Look at next transition to compute dwell and exit trigger
        exited_at = None
        dwell_ms = None
        trigger_out = None
        if idx + 1 < len(history):
            next_row = history[idx + 1]
            exited_at = next_row.created_at
            trigger_out = next_row.trigger
            if entered_at and exited_at:
                dwell_ms = int((exited_at - entered_at).total_seconds() * 1000)

        steps.append(
            {
                "state": target,
                "entered_at": entered_iso,
                "exited_at": exited_at.isoformat() if exited_at else None,
                "dwell_ms": dwell_ms,
                "trigger_in": row.trigger,
                "trigger_out": trigger_out,
                "success": row.success,
            }
        )

    total_dwell_ms = sum(
        step["dwell_ms"] for step in steps if step["dwell_ms"] is not None
    )

    return {
        "entity_id": entity_id,
        "machine_name": entity.machine_name if entity else None,
        "current_state": entity.current_state if entity else "",
        "steps": steps,
        "total_dwell_ms": total_dwell_ms,
        "states_visited": len(visited_states),
    }


__all__ = [
    "compute_entity_health",
    "compute_entity_timeline",
    "compute_transition_analytics",
]
