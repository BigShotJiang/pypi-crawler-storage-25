"""Per-state operational metrics for ops monitoring.

This module computes lightweight metrics for each state of a machine, intended
to augment the state diagram without turning it into a full dashboard.

Key design goals:
- Deterministic, testable logic in one place (no route-level one-offs)
- Cross-database compatibility (SQLite + Postgres): do heavy grouping in SQL,
  but compute percentiles in Python for portability.
- Minimal output with conditional rendering handled in the UI.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session

from pystator.db.models import EntityStateModel, TransitionHistoryModel


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _window_start(hours: int, now: datetime) -> datetime:
    return now - timedelta(hours=hours)


def _compute_p95(values: list[int]) -> int | None:
    """Compute p95 using nearest-rank method for a list of integer values."""
    if not values:
        return None
    sorted_values = sorted(values)
    rank = max(1, (95 * len(sorted_values) + 99) // 100)
    return sorted_values[min(rank - 1, len(sorted_values) - 1)]


@dataclass(frozen=True)
class StateMetricsWindow:
    start: datetime
    end: datetime


def compute_state_metrics(
    session: Session,
    machine_name: str,
    window_hours: int = 24,
    age_bucket_edges_minutes: tuple[int, int] = (5, 30),
) -> tuple[StateMetricsWindow, dict[str, dict]]:
    """Compute per-state metrics for a machine.

    Returns:
        (window, metrics_by_state_name) where metrics_by_state_name maps to a dict
        matching StateOpsMetricsItem fields (minus state_name).
    """
    now = _utc_now()
    start = _window_start(window_hours, now)
    window = StateMetricsWindow(start=start, end=now)

    # Only consider active entities for ops load/age. Archived/deleted are not "in flight".
    active_entities_q = (
        session.query(EntityStateModel.entity_id, EntityStateModel.current_state)
        .filter(EntityStateModel.machine_name == machine_name)
        .filter(EntityStateModel.status == "active")
    )

    # --- Count by state (SQL) ---
    counts_rows = (
        session.query(
            EntityStateModel.current_state, func.count(EntityStateModel.entity_id)
        )
        .filter(EntityStateModel.machine_name == machine_name)
        .filter(EntityStateModel.status == "active")
        .group_by(EntityStateModel.current_state)
        .all()
    )
    counts_by_state: dict[str, int] = {
        str(s): int(c) for s, c in counts_rows if s is not None
    }

    # --- Age by state (Python for portability) ---
    # Compute last transition timestamp per entity (within machine). If no history, fall back to entity updated_at/created_at.
    last_ts_rows = (
        session.query(
            TransitionHistoryModel.entity_id,
            func.max(TransitionHistoryModel.created_at),
        )
        .filter(TransitionHistoryModel.machine_name == machine_name)
        .group_by(TransitionHistoryModel.entity_id)
        .all()
    )
    last_ts_by_entity: dict[str, datetime] = {
        str(eid): ts for eid, ts in last_ts_rows if eid is not None and ts is not None
    }

    entity_state_rows = active_entities_q.with_entities(
        EntityStateModel.entity_id,
        EntityStateModel.current_state,
        EntityStateModel.updated_at,
        EntityStateModel.created_at,
    ).all()

    ages_by_state: dict[str, list[int]] = defaultdict(list)
    edge1_m, edge2_m = age_bucket_edges_minutes
    edge1_s = int(edge1_m * 60)
    edge2_s = int(edge2_m * 60)
    buckets_by_state: dict[str, dict[str, int]] = defaultdict(
        lambda: {"le_5m": 0, "le_30m": 0, "gt_30m": 0}
    )

    for eid, state, updated_at, created_at in entity_state_rows:
        if eid is None or state is None:
            continue
        eid_s = str(eid)
        state_s = str(state)
        ts = last_ts_by_entity.get(eid_s) or updated_at or created_at
        if ts is None:
            continue
        # created_at/updated_at may be naive in some sqlite configurations; treat as UTC.
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=UTC)
        age_s = int(max(0, (now - ts).total_seconds()))
        ages_by_state[state_s].append(age_s)
        if age_s <= edge1_s:
            buckets_by_state[state_s]["le_5m"] += 1
        elif age_s <= edge2_s:
            buckets_by_state[state_s]["le_30m"] += 1
        else:
            buckets_by_state[state_s]["gt_30m"] += 1

    age_p95_by_state = {s: _compute_p95(vals) for s, vals in ages_by_state.items()}
    age_oldest_by_state = {
        s: (max(vals) if vals else None) for s, vals in ages_by_state.items()
    }

    # --- Error heat (either side) ---
    failed_rows = (
        session.query(
            TransitionHistoryModel.source_state,
            TransitionHistoryModel.target_state,
            TransitionHistoryModel.error_type,
            TransitionHistoryModel.error_message,
        )
        .filter(TransitionHistoryModel.machine_name == machine_name)
        .filter(TransitionHistoryModel.created_at >= start)
        .filter(TransitionHistoryModel.created_at <= now)
        .filter(TransitionHistoryModel.success.is_(False))
        .all()
    )

    failed_count_by_state: dict[str, int] = defaultdict(int)
    error_sig_counts_by_state: dict[str, Counter[tuple[str | None, str | None]]] = (
        defaultdict(Counter)
    )

    for src, dst, et, em in failed_rows:
        touched: set[str] = set()
        if src:
            touched.add(str(src))
        if dst:
            touched.add(str(dst))
        if not touched:
            continue
        sig = (str(et) if et is not None else None, str(em) if em is not None else None)
        for s in touched:
            failed_count_by_state[s] += 1
            error_sig_counts_by_state[s][sig] += 1

    top_error_by_state: dict[str, dict | None] = {}
    for s, counter in error_sig_counts_by_state.items():
        if not counter:
            top_error_by_state[s] = None
            continue
        (et, em), cnt = counter.most_common(1)[0]
        top_error_by_state[s] = {
            "error_type": et,
            "error_message": em,
            "count": int(cnt),
        }

    # --- Assemble ---
    all_states = (
        set(counts_by_state.keys())
        | set(ages_by_state.keys())
        | set(failed_count_by_state.keys())
    )
    metrics_by_state: dict[str, dict] = {}
    for s in sorted(all_states):
        metrics_by_state[s] = {
            "entity_count": int(counts_by_state.get(s, 0)),
            "age_p95_seconds": age_p95_by_state.get(s),
            "age_oldest_seconds": age_oldest_by_state.get(s),
            "age_buckets": buckets_by_state.get(
                s, {"le_5m": 0, "le_30m": 0, "gt_30m": 0}
            ),
            "failed_transition_count": int(failed_count_by_state.get(s, 0)),
            "top_error": top_error_by_state.get(s),
        }

    return window, metrics_by_state
