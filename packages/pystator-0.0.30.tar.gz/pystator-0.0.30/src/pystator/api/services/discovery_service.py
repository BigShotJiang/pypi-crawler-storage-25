"""Service facade for inferred FSM discovery APIs."""

from __future__ import annotations

from datetime import UTC, datetime
from threading import Lock
from typing import Any, Literal

from pystator.config import (
    get_discovery_backend,
    get_discovery_database_url,
    get_discovery_min_confidence,
    get_discovery_min_edge_count,
)
from pystator.discovery import InferenceEngine, InferenceThresholds, ObservedStateEvent
from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    ShadowDiff,
)
from pystator.discovery.stores import create_discovery_store

_ENGINE_LOCK = Lock()
_ENGINE: InferenceEngine | None = None
_STORE: Any = None


def get_discovery_engine() -> InferenceEngine:
    global _ENGINE, _STORE
    if _ENGINE is not None:
        return _ENGINE
    with _ENGINE_LOCK:
        if _ENGINE is not None:
            return _ENGINE
        backend = get_discovery_backend()
        db_url = get_discovery_database_url()
        store = create_discovery_store(
            backend,
            connection_string=db_url,
            options={"database_name": "pystator"},
        )
        connect = getattr(store, "connect", None)
        if callable(connect):
            connect()
        thresholds = InferenceThresholds(
            min_edge_count=get_discovery_min_edge_count(),
            min_confidence=get_discovery_min_confidence(),
        )
        _ENGINE = InferenceEngine(
            observation_store=store,
            inference_store=store,
            built_candidate_store=store,
            shadow_store=store,
            thresholds=thresholds,
        )
        _STORE = store
        return _ENGINE


class DiscoveryService:
    def __init__(self, engine: InferenceEngine | None = None) -> None:
        self._engine = engine or get_discovery_engine()

    def record_observation(
        self,
        *,
        machine_name: str,
        entity_id: str,
        state: str,
        observed_at: datetime | None,
        source: str,
        source_event_id: str | None,
        ingest_seq: int,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        event = ObservedStateEvent(
            entity_id=entity_id,
            machine_name=machine_name,
            state=state,
            observed_at=observed_at or datetime.utcnow(),
            source=source,
            source_event_id=source_event_id,
            ingest_seq=ingest_seq,
            metadata=dict(metadata or {}),
        )
        return self._engine.record_observation(machine_name, event)

    def build_candidate(
        self,
        machine_name: str,
        version: str | None = None,
        *,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        edge_selection: list[tuple[str, str]] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        draft_id: str | None = None,
    ) -> dict[str, Any]:
        candidate = self._engine.build_candidate(
            machine_name,
            version=version,
            mode=mode,
            entity_ids=entity_ids,
            edge_selection=edge_selection,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
            draft_id=draft_id,
        )
        edges_snapshot = candidate.metadata.get("inferred_edges_snapshot")
        edges = edges_snapshot if isinstance(edges_snapshot, list) else []
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": edges,
        }

    def preview_candidate_inputs(
        self,
        machine_name: str,
        *,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
    ) -> dict[str, Any]:
        payload = self._engine.preview_inference(
            machine_name,
            mode=mode,
            entity_ids=entity_ids,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
        )
        return {
            "machine_name": payload["machine_name"],
            "mode": payload["mode"],
            "entity_ids_used": payload["entity_ids_used"],
            "observation_count": payload["observation_count"],
            "edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["edges"]
            ],
            "selected_edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["selected_edges"]
            ],
        }

    def list_entity_ids(self, machine_name: str) -> list[str]:
        store = self._engine._observations  # noqa: SLF001
        list_ids = getattr(store, "list_entity_ids", None)
        if callable(list_ids):
            return [str(x) for x in list_ids(machine_name)]
        observations = self._engine._observations.list_observations(machine_name)  # noqa: SLF001
        return sorted({x.entity_id for x in observations if x.entity_id})

    def delete_entity_observations(self, machine_name: str, entity_id: str) -> int:
        store = self._engine._observations  # noqa: SLF001
        deleter = getattr(store, "delete_observations_for_entity", None)
        if callable(deleter):
            return int(deleter(machine_name, entity_id))
        observations = self._engine._observations.list_observations(machine_name)  # noqa: SLF001
        return sum(1 for x in observations if x.entity_id == entity_id)

    def save_candidate_config(
        self,
        *,
        source_machine_name: str,
        target_machine_name: str,
        target_version: str | None,
        config: dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        version = target_version
        if not version:
            latest = self._engine.get_latest_built_candidate(target_machine_name)
            if latest is None:
                version = "0.1.0"
            else:
                parts = str(latest.version).split(".")
                if len(parts) == 3 and all(part.isdigit() for part in parts):
                    major, minor, patch = (int(p) for p in parts)
                    version = f"{major}.{minor}.{patch + 1}"
                else:
                    version = "0.1.0"
        candidate = BuiltDiscoveryCandidate(
            machine_name=target_machine_name,
            version=version,
            status="candidate",
            config=dict(config),
            metadata={
                "build_mode": "manual_config",
                "source_machine_name": source_machine_name,
                **(metadata or {}),
            },
        )
        saved = self._engine.save_built_candidate(candidate)
        return {
            "machine_name": saved.machine_name,
            "version": saved.version,
            "candidate_sequence": saved.candidate_sequence,
            "status": saved.status,
            "config": saved.config,
            "metadata": saved.metadata,
            "edges": [],
        }

    def update_candidate_status(
        self, *, machine_name: str, version: str, status: str
    ) -> BuiltDiscoveryCandidate:
        existing = self._engine.get_built_candidate(machine_name, version)
        if existing is None:
            raise ValueError(
                f"Candidate not found for machine={machine_name!r} version={version!r}"
            )
        updated = BuiltDiscoveryCandidate(
            machine_name=existing.machine_name,
            version=existing.version,
            status=status,
            config=dict(existing.config),
            created_at=existing.created_at,
            metadata=dict(existing.metadata),
            candidate_sequence=existing.candidate_sequence,
        )
        return self._engine.save_built_candidate(updated)

    def get_latest_candidate(self, machine_name: str) -> dict[str, Any] | None:
        candidate = self._engine.get_latest_built_candidate(machine_name)
        if candidate is None:
            return None
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
        }

    def list_candidate_summaries(self, machine_name: str) -> list[dict[str, Any]]:
        """Lightweight rows for candidate version listing (no full config)."""
        candidates = self._engine.list_built_candidates(machine_name)
        candidates = [c for c in candidates if str(c.status).lower() == "candidate"]
        candidates = sorted(
            candidates,
            key=lambda c: c.created_at,
            reverse=True,
        )
        shadow_rows = self._engine.list_shadow_diffs(machine_name, limit=5000)
        by_version: dict[str, list[ShadowDiff]] = {}
        for diff in shadow_rows:
            version = str((diff.metadata or {}).get("candidate_version") or "").strip()
            if not version:
                continue
            bucket = by_version.setdefault(version, [])
            # Keep only the most recent 200 rows per version.
            if len(bucket) < 200:
                bucket.append(diff)
        out: list[dict[str, Any]] = []
        for c in candidates:
            meta = c.metadata if isinstance(c.metadata, dict) else {}
            version_rows = by_version.get(str(c.version), [])
            shadow_total = len(version_rows)
            differs_n = sum(1 for r in version_rows if r.differs)
            out.append(
                {
                    "machine_name": c.machine_name,
                    "version": c.version,
                    "candidate_sequence": c.candidate_sequence,
                    "status": c.status,
                    "created_at": c.created_at,
                    "metadata": meta,
                    "observation_count_at_build": int(
                        meta.get("observation_count") or 0
                    ),
                    "shadow_diff_count_recent": shadow_total,
                    "drift_rate_recent": (
                        float(differs_n / shadow_total) if shadow_total else 0.0
                    ),
                    "build_mode": (
                        str(meta.get("build_mode"))
                        if meta.get("build_mode") is not None
                        else None
                    ),
                }
            )
        return out

    def get_candidate_version(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        """Return the stored built candidate domain object, if any."""
        return self._engine.get_built_candidate(machine_name, version)

    def get_candidate_detail(
        self, machine_name: str, version: str
    ) -> dict[str, Any] | None:
        """Full candidate payload including edge diagnostics (same shape as build)."""
        candidate = self._engine.get_built_candidate(machine_name, version)
        if candidate is None:
            return None
        edges_snapshot = candidate.metadata.get("inferred_edges_snapshot")
        edges = edges_snapshot if isinstance(edges_snapshot, list) else []
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": edges,
        }

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[dict[str, Any]]:
        diffs = self._engine.list_shadow_diffs(machine_name, limit=limit)
        return [
            {
                "machine_name": d.machine_name,
                "source_state": d.source_state,
                "trigger": d.trigger,
                "active_success": d.active_success,
                "active_target_state": d.active_target_state,
                "candidate_success": d.candidate_success,
                "candidate_target_state": d.candidate_target_state,
                "differs": d.differs,
                "reason": d.reason,
                "metadata": d.metadata,
            }
            for d in diffs
        ]

    def run_shadow_compare(
        self,
        *,
        machine_name: str,
        active_config: dict[str, Any],
        source_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> ShadowDiff | None:
        return self._engine.run_shadow_compare(
            machine_name=machine_name,
            active_config=active_config,
            source_state=source_state,
            trigger=trigger,
            context=context,
        )

    def list_fleet_summaries(
        self,
        *,
        query: str | None = None,
        sort: str = "machine_name",
        order: str = "asc",
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Paginated fleet index rows from the discovery store (SQL or in-memory).

        ``sort`` must be one of: machine_name, last_observation_at, observation_count,
        candidate_count, drift_rate_recent, shadow_diff_count_recent.
        ``order`` is ``asc`` or ``desc``.
        """
        store = self._engine._observations  # noqa: SLF001 — single shared store instance
        rows: list[dict[str, Any]]
        if hasattr(store, "list_fleet_summaries"):
            rows = store.list_fleet_summaries()  # type: ignore[union-attr]
        else:
            rows = []

        qnorm = (query or "").strip().lower()
        if qnorm:
            rows = [r for r in rows if qnorm in str(r.get("machine_name", "")).lower()]

        sort_keys = {
            "machine_name",
            "last_observation_at",
            "observation_count",
            "candidate_count",
            "drift_rate_recent",
            "shadow_diff_count_recent",
        }
        key = sort if sort in sort_keys else "machine_name"
        reverse = str(order).lower() == "desc"
        min_dt = datetime.min.replace(tzinfo=UTC)

        def sort_value(row: dict[str, Any]) -> Any:
            if key == "machine_name":
                return row.get("machine_name") or ""
            v = row.get(key)
            if key == "last_observation_at" and v is None:
                return min_dt
            if isinstance(v, datetime):
                return v
            if v is None:
                return 0
            return v

        rows = sorted(rows, key=sort_value, reverse=reverse)
        total = len(rows)
        page = rows[offset : offset + max(0, limit)]
        # JSON-serializable datetimes as ISO strings for route layer
        serializable: list[dict[str, Any]] = []
        for r in page:
            item = dict(r)
            loa = item.get("last_observation_at")
            if isinstance(loa, datetime):
                item["last_observation_at"] = loa
            lcca = item.get("latest_candidate_created_at")
            if isinstance(lcca, datetime):
                item["latest_candidate_created_at"] = lcca
            serializable.append(item)
        return {
            "items": serializable,
            "total": total,
            "limit": limit,
            "offset": offset,
        }

    @staticmethod
    def draft_to_dict(d: DiscoveryDraft) -> dict[str, Any]:
        return {
            "id": d.id,
            "machine_name": d.machine_name,
            "title": d.title,
            "selected_entity_ids": list(d.selected_entity_ids),
            "mode": d.mode,
            "min_edge_count": d.min_edge_count,
            "min_confidence": d.min_confidence,
            "manual_edge_selection": [
                {"source_state": a, "destination_state": b}
                for (a, b) in d.manual_edge_selection
            ],
            "created_at": d.created_at,
            "updated_at": d.updated_at,
            "last_built_version": d.last_built_version,
        }

    def list_drafts_dicts(self, machine_name: str) -> list[dict[str, Any]]:
        return [self.draft_to_dict(d) for d in self._engine.list_drafts(machine_name)]

    def create_draft(
        self, machine_name: str, title: str | None = None
    ) -> dict[str, Any]:
        d = self._engine.create_draft(machine_name, title=title)
        return self.draft_to_dict(d)

    def patch_draft(
        self,
        machine_name: str,
        draft_id: str,
        patch: dict[str, Any],
    ) -> dict[str, Any]:
        d = self._engine.get_draft(draft_id)
        if d is None or d.machine_name != machine_name:
            raise ValueError("draft not found")
        kwargs: dict[str, Any] = {}
        if "title" in patch:
            kwargs["title"] = patch["title"]
        if "selected_entity_ids" in patch:
            kwargs["selected_entity_ids"] = list(patch["selected_entity_ids"] or [])
        if "mode" in patch:
            kwargs["mode"] = patch["mode"]
        if "min_edge_count" in patch:
            kwargs["min_edge_count"] = patch["min_edge_count"]
        if "min_confidence" in patch:
            kwargs["min_confidence"] = patch["min_confidence"]
        if "manual_edge_selection" in patch:
            raw = patch["manual_edge_selection"] or []
            pairs: list[tuple[str, str]] = []
            for item in raw:
                if isinstance(item, dict):
                    s = item.get("source_state", "")
                    dest = item.get("destination_state", "")
                    if s and dest:
                        pairs.append((str(s), str(dest)))
            kwargs["manual_edge_selection"] = pairs
        updated = self._engine.update_draft(draft_id, **kwargs)
        return self.draft_to_dict(updated)

    def delete_draft(self, machine_name: str, draft_id: str) -> bool:
        d = self._engine.get_draft(draft_id)
        if d is None or d.machine_name != machine_name:
            return False
        return self._engine.delete_draft(draft_id)

    def preview_draft(self, machine_name: str, draft_id: str) -> dict[str, Any]:
        d = self._engine.get_draft(draft_id)
        if d is None or d.machine_name != machine_name:
            raise ValueError("draft not found")
        payload = self._engine.preview_draft(draft_id)
        return {
            "machine_name": payload["machine_name"],
            "mode": payload["mode"],
            "entity_ids_used": payload["entity_ids_used"],
            "observation_count": payload["observation_count"],
            "edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["edges"]
            ],
            "selected_edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["selected_edges"]
            ],
        }

    def build_draft(self, machine_name: str, draft_id: str) -> dict[str, Any]:
        d = self._engine.get_draft(draft_id)
        if d is None or d.machine_name != machine_name:
            raise ValueError("draft not found")
        candidate = self._engine.build_from_draft(draft_id)
        edges_snapshot = candidate.metadata.get("inferred_edges_snapshot")
        edges = edges_snapshot if isinstance(edges_snapshot, list) else []
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": edges,
        }
