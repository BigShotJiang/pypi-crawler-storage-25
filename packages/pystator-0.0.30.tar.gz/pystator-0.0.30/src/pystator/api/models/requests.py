"""Request models for PyStator API.

Centralizes all request body models used across API routes.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


class LoginRequest(BaseModel):
    """Request body for authentication."""

    username: str = Field(..., description="Username")
    password: str = Field(..., description="Password")


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


class DatabaseTestRequest(BaseModel):
    """Request body for testing database connection."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")


class DiscoveryDatabaseTestRequest(BaseModel):
    """Request body for testing discovery database connection."""

    backend: str = Field(..., description="Discovery backend type")
    connection_string: str | None = Field(
        None, description="Backend connection string if required"
    )


class DlqTestRequest(BaseModel):
    """Request body for testing DLQ database connection."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")
    table_name: str | None = Field(None, description="DLQ table name")


class DlqStatsRequest(BaseModel):
    """Request body for DLQ statistics."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")
    table_name: str | None = Field(None, description="DLQ table name")


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


class ProcessEntityEventRequest(BaseModel):
    """Request body for processing an event for an entity."""

    trigger: str = Field(..., description="Event trigger name")
    context: dict[str, Any] = Field(
        default_factory=dict, description="Optional context for guards/actions"
    )
    machine_name: str | None = Field(
        None, description="Machine name (required if entity doesn't exist yet)"
    )
    machine_version: str | None = Field(
        None, description="Machine version (defaults to latest)"
    )


class CreateEntityRequest(BaseModel):
    """Request body for creating an entity at the machine's initial state."""

    machine_name: str = Field(..., description="Machine name (stored definition)")
    machine_version: str | None = Field(
        None, description="Machine version (defaults to latest)"
    )
    context: dict[str, Any] = Field(
        default_factory=dict, description="Optional persisted entity context"
    )


class DryRunRequest(BaseModel):
    """Request body for a dry-run transition evaluation."""

    trigger: str = Field(..., description="Event trigger name")
    context: dict[str, Any] = Field(
        default_factory=dict, description="Context for guards/actions"
    )


class ApplyDataRequest(BaseModel):
    """Request body for enqueueing a triggerless apply-data update for an entity."""

    data: dict[str, Any] = Field(
        default_factory=dict,
        description="Data to merge into entity context (typically state variables)",
    )
    machine_name: str | None = Field(
        None,
        description=(
            "Optional machine name override for routing. "
            "When omitted, uses the entity's stored machine_name."
        ),
    )
    fires_at: str | None = Field(
        None,
        description="Optional ISO timestamp for delayed eligibility (defaults to now)",
    )
    idempotency_key: str | None = Field(None, description="Optional deduplication key")
    max_attempts: int | None = Field(
        None, ge=1, le=100, description="Optional per-event max attempts override"
    )


class UpdateLabelsRequest(BaseModel):
    """Request body for replacing all labels on an entity."""

    labels: dict[str, str] = Field(..., description="Key-value labels to set")


class PatchLabelsRequest(BaseModel):
    """Request body for merging labels on an entity."""

    labels: dict[str, str] = Field(..., description="Key-value labels to merge")


class BulkCreateEntityItem(BaseModel):
    """Single item in a bulk create request."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str = Field(..., description="Machine name")
    machine_version: str | None = Field(None, description="Machine version")
    context: dict[str, Any] = Field(default_factory=dict, description="Entity context")


class BulkCreateEntitiesRequest(BaseModel):
    """Request body for bulk entity creation."""

    items: list[BulkCreateEntityItem] = Field(
        ..., description="Entities to create", max_length=100
    )


class BulkProcessEventsRequest(BaseModel):
    """Request body for bulk event processing."""

    trigger: str = Field(..., description="Event trigger name")
    entity_ids: list[str] = Field(
        ..., description="Entity IDs to process", max_length=100
    )
    context: dict[str, Any] = Field(default_factory=dict, description="Shared context")
    machine_name: str | None = Field(None, description="Machine name override")


class ImportEntityRequest(BaseModel):
    """Request body for importing an entity from snapshot."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    current_state: str = Field(..., description="Current state")
    context: dict[str, Any] = Field(default_factory=dict, description="Context")
    status: str = Field("active", description="Lifecycle status")
    labels: dict[str, str] = Field(default_factory=dict, description="Labels")
    history: list[dict[str, Any]] = Field(
        default_factory=list, description="History records"
    )
    overwrite: bool = Field(False, description="Overwrite if entity already exists")


class DiscoveryObserveRequest(BaseModel):
    """Request body for recording a discovered state observation."""

    machine_name: str = Field(..., description="Machine name")
    entity_id: str = Field(..., description="Observed entity identifier")
    state: str = Field(..., description="Observed state")
    observed_at: str | None = Field(
        None, description="ISO timestamp for observation time (defaults to now)"
    )
    source: str = Field("api", description="Observation source")
    source_event_id: str | None = Field(
        None, description="Optional source event id for idempotency"
    )
    ingest_seq: int = Field(0, description="Optional ingest sequence")
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Optional additional metadata"
    )


class DiscoveryBuildCandidateRequest(BaseModel):
    """Request body for building an inferred candidate machine."""

    machine_name: str = Field(..., description="Machine name")
    version: str | None = Field(
        None, description="Optional candidate version (auto-generated when omitted)"
    )
    mode: Literal["inference", "manual"] = Field(
        "inference",
        description="Build mode: threshold inference or manual edge selection",
    )
    entity_ids: list[str] = Field(
        default_factory=list,
        description=(
            "Optional entity-id subset used for inference. Empty means all entities "
            "for this machine."
        ),
    )
    edge_selection: list[dict[str, str]] = Field(
        default_factory=list,
        description=(
            "Manual mode edge selection as source/destination pairs. Selected pairs "
            "bypass threshold filtering."
        ),
    )
    min_edge_count: int | None = Field(
        None, description="Optional per-build override for min edge count"
    )
    min_confidence: float | None = Field(
        None, description="Optional per-build override for min confidence"
    )


class DiscoveryPreviewRequest(BaseModel):
    """Request body for previewing inferred edges without saving a candidate."""

    machine_name: str = Field(..., description="Machine name")
    mode: Literal["inference", "manual"] = Field(
        "inference",
        description="Preview mode",
    )
    entity_ids: list[str] = Field(
        default_factory=list,
        description="Optional entity-id subset; empty means all entities",
    )
    min_edge_count: int | None = Field(
        None, description="Optional per-preview override for min edge count"
    )
    min_confidence: float | None = Field(
        None, description="Optional per-preview override for min confidence"
    )


class DiscoveryDraftCreateRequest(BaseModel):
    """Create an empty discovery draft (draft candidate scope)."""

    title: str | None = Field(None, description="Optional display title")


class DiscoveryDraftMachineCreateRequest(BaseModel):
    """Create a new draft discovery machine namespace.

    A draft discovery machine is a synthetic machine_name (e.g. ``draft::<uuid>``)
    used to scope observations and inferred candidates without requiring an
    existing saved machine.
    """

    title: str | None = Field(None, description="Optional display title")


class DiscoveryDraftPatchRequest(BaseModel):
    """Patch draft fields; omitted keys are left unchanged."""

    title: str | None = Field(None, description="Display title")
    selected_entity_ids: list[str] | None = Field(
        None, description="Replace entity-id selection (empty list clears)"
    )
    mode: Literal["inference", "manual"] | None = Field(None)
    min_edge_count: int | None = Field(None, ge=1)
    min_confidence: float | None = Field(None, ge=0.0, le=1.0)
    manual_edge_selection: list[dict[str, str]] | None = Field(
        None,
        description="Manual mode edges as source_state/destination_state",
    )


class DiscoverySaveCandidateRequest(BaseModel):
    """Request body for saving an edited candidate config."""

    source_machine_name: str = Field(..., description="Discovery machine source name")
    target_machine_name: str = Field(
        ..., description="Machine name to save candidate under"
    )
    target_version: str | None = Field(
        None, description="Version to save under (auto-generated when omitted)"
    )
    config: dict[str, Any] = Field(..., description="Candidate FSM config")
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional additional metadata merged into candidate metadata",
    )


# ---------------------------------------------------------------------------
# FSM config operations
# ---------------------------------------------------------------------------


class ProcessRequest(BaseModel):
    """Request body for processing an FSM event."""

    config: dict[str, Any] = Field(
        ...,
        description="FSM configuration (meta, states, transitions, optional error_policy)",
    )
    current_state: str = Field(
        ...,
        description="Current state name of the entity",
    )
    trigger: str = Field(
        ...,
        description="Event trigger name",
    )
    context: dict[str, Any] | None = Field(
        default=None,
        description="Runtime context for guards (e.g. fill_qty, order_qty)",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "config": {
                    "meta": {"machine_name": "order", "version": "1.0"},
                    "states": [
                        {"name": "OPEN", "type": "initial"},
                        {"name": "FILLED", "type": "terminal"},
                    ],
                    "transitions": [
                        {"trigger": "fill", "source": "OPEN", "dest": "FILLED"},
                    ],
                },
                "current_state": "OPEN",
                "trigger": "fill",
                "context": {"fill_qty": 100, "order_qty": 100},
            }
        }
    }


class MachineCreateRequest(BaseModel):
    """Request body for creating/storing an FSM machine in the database."""

    config: dict[str, Any] = Field(
        ...,
        description="Full FSM configuration (meta, states, transitions, error_policy)",
    )


class MachineUpdateRequest(BaseModel):
    """Request body for updating an FSM machine."""

    config: dict[str, Any] = Field(
        ...,
        description="Full FSM configuration to replace existing",
    )
    expected_revision: int | None = Field(
        None,
        description=(
            "Expected current revision for optimistic "
            "concurrency. Returns 409 on mismatch."
        ),
    )


class ValidateRequest(BaseModel):
    """Request body for validating FSM config."""

    config: dict[str, Any] = Field(
        ...,
        description="FSM configuration to validate",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "config": {
                    "meta": {"machine_name": "order", "version": "1.0"},
                    "states": [
                        {"name": "OPEN", "type": "initial"},
                        {"name": "FILLED", "type": "terminal"},
                    ],
                    "transitions": [
                        {"trigger": "fill", "source": "OPEN", "dest": "FILLED"},
                    ],
                },
            }
        }
    }
