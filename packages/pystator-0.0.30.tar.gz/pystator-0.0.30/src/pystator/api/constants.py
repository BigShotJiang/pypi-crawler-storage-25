"""API-wide constants (sentinels, conventions).

Workflow outcome strings (``workflow_status`` on entities) live in
``pystator.workflow_status`` — import them from there, not from this module.
"""

from __future__ import annotations

# Recorded in transition_history when an entity row is created at initial state
# via POST /entities/{id}/create (not a real FSM trigger).
ENTITY_CREATED_TRIGGER = "__entity_created__"

# Entity lifecycle statuses
ENTITY_STATUS_ACTIVE = "active"
ENTITY_STATUS_ARCHIVED = "archived"
ENTITY_STATUS_DELETED = "deleted"
ENTITY_VALID_STATUSES = frozenset(
    {ENTITY_STATUS_ACTIVE, ENTITY_STATUS_ARCHIVED, ENTITY_STATUS_DELETED}
)
