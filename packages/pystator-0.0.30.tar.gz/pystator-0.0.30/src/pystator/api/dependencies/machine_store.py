"""FastAPI dependency for machine store injection.

Follows PyCharter's api/dependencies/store.py pattern: singleton
MachineStoreClient auto-detected from PYSTATOR_DATABASE_URL.
"""

from __future__ import annotations

from fastapi import HTTPException, status

from pystator.machine_store import MachineStoreClient, SQLAlchemyMachineStore

_store_instance: MachineStoreClient | None = None


def get_machine_store() -> MachineStoreClient:
    """FastAPI dependency — singleton MachineStoreClient.

    Auto-detects backend from the pystator database URL.
    Defaults to SQLAlchemyMachineStore.
    """
    global _store_instance

    if _store_instance is None:
        from pystator.config.database import get_database_url
        from pystator.db.config import get_db_url

        db_url = get_database_url() or get_db_url(None, required=False)

        if not db_url:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="No database URL configured for machine store",
            )

        if SQLAlchemyMachineStore is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="SQLAlchemy is required for the machine store",
            )

        store = SQLAlchemyMachineStore(db_url)
        try:
            store.connect()
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to initialize machine store: {e}",
            ) from e

        _store_instance = store

    return _store_instance
