"""API dependency injection."""

from __future__ import annotations

from pystator.api.dependencies.core import get_fsm_service
from pystator.api.dependencies.database import get_db_session
from pystator.api.dependencies.machine_store import get_machine_store

__all__ = ["get_fsm_service", "get_db_session", "get_machine_store"]
