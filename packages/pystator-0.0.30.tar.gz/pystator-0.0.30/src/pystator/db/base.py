"""
Base SQLAlchemy configuration.

Mirrors PyCharter's db/base.py for consistent behavior across SQLite and PostgreSQL.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session as SASession
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()


def get_engine(connection_string: str) -> Engine:
    """
    Create SQLAlchemy engine from connection string.

    For SQLite, configures the engine to handle schema references properly.
    SQLite doesn't support schemas, so we ensure schema prefixes are ignored.
    """
    if connection_string.startswith("sqlite://"):
        # timeout: seconds to wait on SQLITE_BUSY (worker + notebook sharing one file).
        engine = create_engine(
            connection_string,
            echo=False,
            connect_args=(
                {"check_same_thread": False, "timeout": 30.0}
                if connection_string != "sqlite:///:memory:"
                else {}
            ),
        )

        @event.listens_for(engine, "connect")
        def set_sqlite_pragma(dbapi_conn, connection_record) -> None:  # type: ignore[no-untyped-def]
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

        @event.listens_for(engine, "before_cursor_execute", retval=True)
        def receive_before_cursor_execute(  # type: ignore[no-untyped-def]
            conn, cursor, statement, parameters, context, executemany
        ) -> tuple[str, Any]:
            if connection_string.startswith("sqlite://"):
                statement = statement.replace('"pystator".', "").replace(
                    "pystator.", ""
                )
            return statement, parameters

        return engine
    return create_engine(connection_string, echo=False)


def get_session(connection_string: str) -> SASession:
    """Create SQLAlchemy session from connection string."""
    engine = get_engine(connection_string)
    Session = sessionmaker(bind=engine)
    return Session()


def get_schema_prefix(connection_string: str) -> str:
    """Return schema prefix for raw SQL: empty for SQLite, 'pystator.' for PostgreSQL.

    Use when building raw SQL so the same code works for both dialects.
    """
    return "" if connection_string.startswith("sqlite://") else "pystator."
