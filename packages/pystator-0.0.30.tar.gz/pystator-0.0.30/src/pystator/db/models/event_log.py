"""
SQLAlchemy model for the append-only event log.

Stores raw events (inputs) as the source of truth for each entity,
enabling replay and event-sourcing patterns. Unlike transition_history
(which records outcomes), the event_log captures what was requested.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import JSON, Column, DateTime, Index, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(UTC)


class EventLogModel(Base):
    """Append-only event log for replay and event sourcing.

    Each row records a single event sent to an entity. Events are ordered
    by ``sequence`` (monotonically increasing per entity) and are never
    modified after insertion.
    """

    __tablename__ = "event_log"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Entity identifier
    entity_id = Column(String(255), nullable=False)

    # Machine name (denormalized for filtering)
    machine_name = Column(String(255), nullable=True)

    # Monotonic sequence number per entity (1, 2, 3, ...)
    sequence = Column(Integer, nullable=False)

    # Event trigger name
    trigger = Column(String(255), nullable=False)

    # Raw event payload (the input, not the outcome)
    payload_json = Column(JSON, nullable=True)

    # Original Event.event_id (UUID string for idempotency)
    event_id = Column(String(64), nullable=True)

    # Event source ("api", "user", "system", etc.)
    source = Column(String(255), nullable=True)

    # Append timestamp
    created_at = Column(DateTime(timezone=True), default=_utc_now)

    __table_args__ = (
        UniqueConstraint("entity_id", "sequence", name="uq_event_log_entity_sequence"),
        Index("ix_event_log_entity_id", "entity_id"),
        Index("ix_event_log_created_at", "created_at"),
        {"schema": "pystator"},
    )
