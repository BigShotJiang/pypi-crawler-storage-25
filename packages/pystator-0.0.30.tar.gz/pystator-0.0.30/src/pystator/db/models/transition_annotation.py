"""
SQLAlchemy model for workspace transition annotations.

Robust MVP: one note per transition per (machine_name, machine_version).
Transitions are anchored by a deterministic transition_key derived from
transition source(s), trigger, and destination.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(UTC)


class WorkspaceTransitionAnnotationModel(Base):
    __tablename__ = "workspace_transition_annotations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    machine_name = Column(String(255), nullable=False, index=True)
    machine_version = Column(String(50), nullable=False, index=True)
    transition_key = Column(String(512), nullable=False, index=True)

    body_markdown = Column(Text, nullable=False, default="")

    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "machine_name",
            "machine_version",
            "transition_key",
            name="uq_workspace_transition_annotations_machine_version_key",
        ),
        {"schema": "pystator"},
    )
