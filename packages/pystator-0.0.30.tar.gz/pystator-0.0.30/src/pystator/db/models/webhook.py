"""
SQLAlchemy model for webhook subscriptions.

Webhooks receive HTTP POST notifications when matching events occur
(transition failures, dead letter creation, dwell time exceeded).
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import JSON, Boolean, Column, DateTime, Index, String
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(UTC)


class WebhookModel(Base):
    """Webhook subscription for event notifications.

    Each row defines a webhook endpoint that receives HTTP POST payloads
    when one of its subscribed event types fires.

    Supported event types:
        - ``transition_failed``: A transition attempt failed.
        - ``dead_letter_created``: An event was sent to the dead letter queue.
        - ``dwell_time_exceeded``: An entity exceeded its dwell time threshold.
    """

    __tablename__ = "webhooks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Human-readable name
    name = Column(String(255), nullable=False)

    # Target URL for HTTP POST
    url = Column(String(2048), nullable=False)

    # List of event type strings to subscribe to
    events_json = Column(JSON, nullable=False)

    # Custom HTTP headers (e.g., auth tokens)
    headers_json = Column(JSON, nullable=True)

    # Whether this webhook is active
    enabled = Column(Boolean, nullable=False, default=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)

    __table_args__ = (
        Index("ix_webhooks_enabled", "enabled"),
        {"schema": "pystator"},
    )
