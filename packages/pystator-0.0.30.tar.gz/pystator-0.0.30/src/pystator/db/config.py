"""
Database URL resolution, migrations path, and Alembic configuration.

Mirrors pycharter's db/config.py: used by db/cli.py, API, worker, and store
when a database URL is needed (with optional default to SQLite).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from pystator.config import get_database_url, set_database_url
from pystator.db.paths import get_migrations_dir

if TYPE_CHECKING:
    from alembic.config import Config

try:
    from alembic.config import Config as _Config

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False
    _Config = None  # type: ignore[misc, assignment]

# Default SQLite path (single source of truth for "no config" case)
_DEFAULT_DB_FILENAME = "pystator.db"


def _default_db_path() -> Path:
    """Return the default SQLite database path (cwd / pystator.db)."""
    return Path.cwd() / _DEFAULT_DB_FILENAME


def _default_db_url() -> str:
    """Return the default SQLite database URL."""
    return f"sqlite:///{_default_db_path()}"


def require_alembic() -> None:
    """Raise ImportError if Alembic is not available."""
    if not ALEMBIC_AVAILABLE:
        raise ImportError(
            "alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )


def get_db_url(database_url: str | None = None, required: bool = True) -> str:
    """Resolve database URL from argument, config, or env.

    Defaults to sqlite:///<cwd>/pystator.db if unset. When a connection string
    is provided (explicit arg, PYSTATOR_DATABASE_URL, or config file), it is
    used as-is.

    Args:
        database_url: Optional explicit URL (e.g. from CLI arg).
        required: If True and no URL was configured, print an info message
            about using the default SQLite database.

    Returns:
        Resolved database URL (defaults to sqlite:///<cwd>/pystator.db if unset).
    """
    db_url = database_url or get_database_url()
    if not db_url:
        db_url = _default_db_url()
        if required:
            print(f"ℹ Using default SQLite database: {db_url}")
    return db_url


def is_default_db_url(url: str) -> bool:
    """Return True if url is the current default SQLite database URL.

    Used by the API to log a warning only when the default is in use.
    """
    if not url or not url.startswith("sqlite://"):
        return False
    # Compare normalized path: sqlite:///path/to/pystator.db
    path_part = url[10:] if url.startswith("sqlite:///") else url
    try:
        return Path(path_part).resolve() == _default_db_path().resolve()
    except (OSError, RuntimeError):
        return False


def get_alembic_config(database_url: str | None = None) -> Config:
    """Build Alembic Config with script_location and sqlalchemy.url set.

    Uses get_db_url(required=False) so the default path is defined in one place.
    """
    require_alembic()
    config = _Config()
    config.set_main_option("script_location", str(get_migrations_dir()))
    config.set_main_option("prepend_sys_path", ".")
    config.set_main_option("version_path_separator", "os")
    config.set_main_option(
        "file_template",
        "%%(year)d%%(month).2d%%(day).2d%%(hour).2d%%(minute).2d%%(second).2d_%%(rev)s_%%(slug)s",
    )
    db_url = get_db_url(database_url, required=False)
    config.set_main_option("sqlalchemy.url", db_url)
    set_database_url(db_url)
    return config  # type: ignore[return-value]


def detect_db_type(database_url: str) -> str:
    """Return database type from connection string.

    Returns:
        One of ``"postgresql"``, ``"sqlite"``, ``"mongodb"``, ``"redis"``.
        Defaults to ``"sqlite"`` for unrecognised schemes.
    """
    if database_url.startswith(("postgresql://", "postgres://")):
        return "postgresql"
    if database_url.startswith(("mongodb://", "mongodb+srv://")):
        return "mongodb"
    if database_url.startswith(("redis://", "rediss://")):
        return "redis"
    if database_url.startswith("sqlite://"):
        return "sqlite"
    return "sqlite"


# Re-export so callers can import from pystator.db.config only
__all__ = [
    "get_db_url",
    "get_alembic_config",
    "get_migrations_dir",
    "detect_db_type",
    "require_alembic",
    "is_default_db_url",
]
