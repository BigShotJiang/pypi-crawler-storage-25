"""Add workflow_status to entity_states; backfill from machine configs.

Revision ID: 20260402120000
Revises: 20260401120000
Create Date: 2026-04-02
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import sqlalchemy as sa
from alembic import op

revision: str = "20260402120000"
down_revision: str | None = "20260401120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    columns = {
        c["name"] for c in inspector.get_columns("entity_states", schema=schema_name)
    }
    indexes = {
        i["name"] for i in inspector.get_indexes("entity_states", schema=schema_name)
    }

    # Idempotent guards: handles partially-applied migrations (common in SQLite)
    if "workflow_status" not in columns:
        op.add_column(
            "entity_states",
            sa.Column("workflow_status", sa.String(20), nullable=True),
            schema=schema_name,
        )

    if "ix_entity_states_workflow_status" not in indexes:
        op.create_index(
            "ix_entity_states_workflow_status",
            "entity_states",
            ["workflow_status"],
            schema=schema_name,
        )

    # Late imports so migration module loads before app models are needed
    from pystator.api.services.fsm_service import build_machine_from_config
    from pystator.workflow_status import (
        WORKFLOW_STATUS_ACTIVE,
        persistence_flags_for_state,
    )

    # Core reflection avoids schema-qualified ORM table names on SQLite.
    meta = sa.MetaData()
    entity_states = sa.Table(
        "entity_states", meta, autoload_with=connection, schema=schema_name
    )
    machines = sa.Table("machines", meta, autoload_with=connection, schema=schema_name)

    rows = connection.execute(
        sa.select(
            entity_states.c.entity_id,
            entity_states.c.machine_name,
            entity_states.c.current_state,
        )
    ).mappings()

    for row in rows:
        eid = row["entity_id"]
        machine_name = row["machine_name"]
        current_state = row["current_state"]

        if not machine_name:
            connection.execute(
                sa.update(entity_states)
                .where(entity_states.c.entity_id == eid)
                .values(workflow_status=WORKFLOW_STATUS_ACTIVE)
            )
            continue

        machine_cfg = connection.execute(
            sa.select(machines.c.config_json)
            .where(machines.c.name == machine_name)
            .order_by(machines.c.version.desc())
            .limit(1)
        ).scalar_one_or_none()

        if not isinstance(machine_cfg, dict):
            connection.execute(
                sa.update(entity_states)
                .where(entity_states.c.entity_id == eid)
                .values(workflow_status=WORKFLOW_STATUS_ACTIVE)
            )
            continue

        try:
            machine = build_machine_from_config(machine_cfg)
            is_t, ws = persistence_flags_for_state(machine, current_state)
        except Exception:
            is_t, ws = None, WORKFLOW_STATUS_ACTIVE

        values: dict[str, Any] = {"workflow_status": ws}
        if is_t is not None:
            values["is_terminal"] = is_t
        connection.execute(
            sa.update(entity_states)
            .where(entity_states.c.entity_id == eid)
            .values(**values)
        )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_entity_states_workflow_status",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_column("entity_states", "workflow_status", schema=schema_name)
