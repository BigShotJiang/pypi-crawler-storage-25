"""Add webhooks table for alert notifications.

Revision ID: 20260406120000
Revises: 20260405120000
Create Date: 2026-04-06
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260406120000"
down_revision: str | None = "20260405120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    tables = inspector.get_table_names(schema=schema_name)
    if "webhooks" not in tables:
        op.create_table(
            "webhooks",
            sa.Column(
                "id",
                sa.UUID(as_uuid=True),
                primary_key=True,
            ),
            sa.Column("name", sa.String(255), nullable=False),
            sa.Column("url", sa.String(2048), nullable=False),
            sa.Column("events_json", sa.JSON(), nullable=False),
            sa.Column("headers_json", sa.JSON(), nullable=True),
            sa.Column(
                "enabled",
                sa.Boolean(),
                nullable=False,
                server_default=sa.text("1"),
            ),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=True,
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(timezone=True),
                nullable=True,
            ),
            schema=schema_name,
        )
        op.create_index(
            "ix_webhooks_enabled",
            "webhooks",
            ["enabled"],
            schema=schema_name,
        )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index("ix_webhooks_enabled", table_name="webhooks", schema=schema_name)
    op.drop_table("webhooks", schema=schema_name)
