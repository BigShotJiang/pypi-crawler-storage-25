"""Add revision column to machines (optimistic concurrency).

Revision ID: 20260403120000
Revises: 20260402120000
Create Date: 2026-04-03
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260403120000"
down_revision: str | None = "20260402120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    columns = {c["name"] for c in inspector.get_columns("machines", schema=schema_name)}
    if "revision" not in columns:
        op.add_column(
            "machines",
            sa.Column(
                "revision",
                sa.Integer(),
                nullable=False,
                server_default=sa.text("1"),
            ),
            schema=schema_name,
        )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_column("machines", "revision", schema=schema_name)
