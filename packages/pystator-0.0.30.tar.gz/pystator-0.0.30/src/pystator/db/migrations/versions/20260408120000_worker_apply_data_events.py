"""Add worker_apply_data_events durable queue table.

Revision ID: 20260408120000
Revises: 20260407120000
Create Date: 2026-04-08
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSON, UUID

revision: str = "20260408120000"
down_revision: str | None = "20260407120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()

    op.create_table(
        "worker_apply_data_events",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("machine_name", sa.String(255), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("data_json", JSON(), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column(
            "fires_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("claimed_by", sa.String(255), nullable=True),
        sa.Column("claimed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attempt", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="5"),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("idempotency_key", sa.String(255), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("result_json", JSON(), nullable=True),
        sa.Column("transition_history_id", UUID(as_uuid=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "idempotency_key", name="uq_worker_apply_data_events_idempotency_key"
        ),
        schema=schema_name,
    )

    op.create_index(
        "ix_worker_apply_data_events_poll",
        "worker_apply_data_events",
        ["status", "fires_at"],
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_apply_data_events_entity_id",
        "worker_apply_data_events",
        ["entity_id"],
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_apply_data_events_machine_name",
        "worker_apply_data_events",
        ["machine_name"],
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_apply_data_events_transition_history_id",
        "worker_apply_data_events",
        ["transition_history_id"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_worker_apply_data_events_transition_history_id",
        table_name="worker_apply_data_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_apply_data_events_machine_name",
        table_name="worker_apply_data_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_apply_data_events_entity_id",
        table_name="worker_apply_data_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_apply_data_events_poll",
        table_name="worker_apply_data_events",
        schema=schema_name,
    )
    op.drop_table("worker_apply_data_events", schema=schema_name)
