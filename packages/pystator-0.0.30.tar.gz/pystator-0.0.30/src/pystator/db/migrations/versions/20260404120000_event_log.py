"""Add event_log table for append-only event sourcing.

Revision ID: 20260404120000
Revises: 20260403120000
Create Date: 2026-04-04
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260404120000"
down_revision: str | None = "20260403120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    tables = inspector.get_table_names(schema=schema_name)
    if "event_log" not in tables:
        op.create_table(
            "event_log",
            sa.Column(
                "id",
                sa.UUID(as_uuid=True),
                primary_key=True,
            ),
            sa.Column("entity_id", sa.String(255), nullable=False),
            sa.Column("machine_name", sa.String(255), nullable=True),
            sa.Column("sequence", sa.Integer(), nullable=False),
            sa.Column("trigger", sa.String(255), nullable=False),
            sa.Column("payload_json", sa.JSON(), nullable=True),
            sa.Column("event_id", sa.String(64), nullable=True),
            sa.Column("source", sa.String(255), nullable=True),
            sa.Column(
                "created_at",
                sa.DateTime(timezone=True),
                nullable=True,
            ),
            sa.UniqueConstraint(
                "entity_id",
                "sequence",
                name="uq_event_log_entity_sequence",
            ),
            schema=schema_name,
        )
        op.create_index(
            "ix_event_log_entity_id",
            "event_log",
            ["entity_id"],
            schema=schema_name,
        )
        op.create_index(
            "ix_event_log_created_at",
            "event_log",
            ["created_at"],
            schema=schema_name,
        )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index("ix_event_log_created_at", table_name="event_log", schema=schema_name)
    op.drop_index("ix_event_log_entity_id", table_name="event_log", schema=schema_name)
    op.drop_table("event_log", schema=schema_name)
