"""Rename DLQ table to dead_letter_queue.

Revision ID: 20260407120000
Revises: 20260406120000
Create Date: 2026-04-07
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text

revision: str = "20260407120000"
down_revision: str | None = "20260406120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

OLD_NAME = "pystator_dead_letter_queue"
NEW_NAME = "dead_letter_queue"

_UNIFIED_REQUIRED_COLUMNS = {
    "record_id",
    "source_name",
    "reason",
    "error_message",
    "error_type",
    "stage",
    "payload",
    "metadata",
    "attempt",
    "max_attempts",
    "status",
    "retry_count",
    "created_at",
    "updated_at",
    "expires_at",
}


def _dlq_schema(dialect: str) -> str | None:
    return "public" if dialect == "postgresql" else None


def upgrade() -> None:
    bind = op.get_bind()
    dialect = bind.dialect.name
    schema_name = _dlq_schema(dialect)
    inspector = sa.inspect(bind)
    tables = set(inspector.get_table_names(schema=schema_name))

    if OLD_NAME in tables and NEW_NAME not in tables:
        op.rename_table(OLD_NAME, NEW_NAME, schema=schema_name)
        return

    if OLD_NAME in tables and NEW_NAME in tables:
        old_cols = {
            c["name"] for c in inspector.get_columns(OLD_NAME, schema=schema_name)
        }
        new_cols = {
            c["name"] for c in inspector.get_columns(NEW_NAME, schema=schema_name)
        }

        if not _UNIFIED_REQUIRED_COLUMNS.issubset(old_cols):
            return
        if not _UNIFIED_REQUIRED_COLUMNS.issubset(new_cols):
            return

        shared = [c for c in sorted(old_cols) if c in new_cols]
        if not _UNIFIED_REQUIRED_COLUMNS.issubset(set(shared)):
            return

        if schema_name:
            old_q = f'"{schema_name}"."{OLD_NAME}"'
            new_q = f'"{schema_name}"."{NEW_NAME}"'
        else:
            old_q = f'"{OLD_NAME}"'
            new_q = f'"{NEW_NAME}"'

        cols_csv = ", ".join(f'"{c}"' for c in shared)

        if dialect == "postgresql":
            bind.execute(
                text(
                    f"INSERT INTO {new_q} ({cols_csv}) "
                    f"SELECT {cols_csv} FROM {old_q} "
                    "ON CONFLICT (record_id) DO NOTHING"
                )
            )
        else:
            bind.execute(
                text(
                    f"INSERT OR IGNORE INTO {new_q} ({cols_csv}) "
                    f"SELECT {cols_csv} FROM {old_q}"
                )
            )

        op.drop_table(OLD_NAME, schema=schema_name)


def downgrade() -> None:
    bind = op.get_bind()
    dialect = bind.dialect.name
    schema_name = _dlq_schema(dialect)
    inspector = sa.inspect(bind)
    tables = set(inspector.get_table_names(schema=schema_name))

    if NEW_NAME in tables and OLD_NAME not in tables:
        op.rename_table(NEW_NAME, OLD_NAME, schema=schema_name)
