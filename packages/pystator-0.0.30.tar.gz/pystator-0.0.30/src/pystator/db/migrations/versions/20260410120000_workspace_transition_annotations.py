"""Add workspace transition annotations table.

Revision ID: 20260410120000
Revises: 20260409120000
Create Date: 2026-04-10
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision: str = "20260410120000"
down_revision: str | None = "20260409120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.create_table(
        "workspace_transition_annotations",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("machine_name", sa.String(length=255), nullable=False),
        sa.Column("machine_version", sa.String(length=50), nullable=False),
        sa.Column("transition_key", sa.String(length=512), nullable=False),
        sa.Column("body_markdown", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_by", sa.String(length=255), nullable=True),
        sa.Column("updated_by", sa.String(length=255), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "machine_name",
            "machine_version",
            "transition_key",
            name="uq_workspace_transition_annotations_machine_version_key",
        ),
        sa.Index("ix_workspace_transition_annotations_machine_name", "machine_name"),
        sa.Index(
            "ix_workspace_transition_annotations_machine_version",
            "machine_version",
        ),
        sa.Index(
            "ix_workspace_transition_annotations_transition_key",
            "transition_key",
        ),
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_table("workspace_transition_annotations", schema=schema_name)
