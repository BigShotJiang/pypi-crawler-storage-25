"""Add machine_version column to entity_states.

Revision ID: 20260405120000
Revises: 20260404120000
Create Date: 2026-04-05
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260405120000"
down_revision: str | None = "20260404120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    columns = {
        c["name"] for c in inspector.get_columns("entity_states", schema=schema_name)
    }
    if "machine_version" not in columns:
        op.add_column(
            "entity_states",
            sa.Column("machine_version", sa.String(50), nullable=True),
            schema=schema_name,
        )
        op.create_index(
            "ix_entity_states_machine_version",
            "entity_states",
            ["machine_version"],
            schema=schema_name,
        )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_entity_states_machine_version",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_column("entity_states", "machine_version", schema=schema_name)
