"""Reference guards and actions for core trading FSMs.

Provides stub/reference implementations for portfolio, optimization,
order, and intraday trading state machines. Override individual guards
or actions in your own registries for real policy and side effects.

Trading machine configs are bundled at ``contrib/trading/data/trading_machines.yaml``.

Usage::

    from pystator.contrib.trading import get_core_guard_registry, get_core_action_registry

    machine = StateMachine.from_yaml("my_trading_fsm.yaml")
    machine.bind_guards(get_core_guard_registry())
    machine.bind_actions(get_core_action_registry())
"""

from __future__ import annotations

from .guards import (
    acceptable_turnover,
    all_orders_filled_or_cancelled,
    auto_approval_enabled,
    can_retry,
    can_safely_cancel,
    cooldown_elapsed,
    daily_pnl_below_threshold,
    daily_pnl_critical,
    daily_pnl_improved,
    daily_pnl_recovered,
    data_quality_sufficient,
    drift_exceeds_threshold,
    has_buying_power,
    has_no_fills,
    has_partial_fills,
    is_cancellable,
    is_full_fill,
    is_market_hours,
    is_partial_fill,
    is_within_trading_hours,
    order_list_empty,
    passes_risk_constraints,
    requires_approval,
    retry_optimization_allowed,
    risk_actually_cleared,
    risk_allows_entry,
)
from .registry import get_core_action_registry, get_core_guard_registry

__all__ = [
    "get_core_guard_registry",
    "get_core_action_registry",
    "acceptable_turnover",
    "all_orders_filled_or_cancelled",
    "auto_approval_enabled",
    "can_retry",
    "can_safely_cancel",
    "cooldown_elapsed",
    "daily_pnl_below_threshold",
    "daily_pnl_critical",
    "daily_pnl_improved",
    "daily_pnl_recovered",
    "data_quality_sufficient",
    "drift_exceeds_threshold",
    "has_buying_power",
    "has_no_fills",
    "has_partial_fills",
    "is_cancellable",
    "is_full_fill",
    "is_market_hours",
    "is_partial_fill",
    "is_within_trading_hours",
    "order_list_empty",
    "passes_risk_constraints",
    "requires_approval",
    "retry_optimization_allowed",
    "risk_actually_cleared",
    "risk_allows_entry",
]
