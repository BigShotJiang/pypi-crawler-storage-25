"""Observability — hooks, linting, and visualization.

Re-exports instrumentation and developer tooling:

- ``TransitionHook`` and built-in hooks (logging, metrics, dwell time)
- ``lint`` — static analysis for unreachable states, dead ends, etc.
- ``to_mermaid``, ``to_dot`` — diagram generation
"""

from __future__ import annotations

from pystator.hooks import (
    DwellTimeTracker,
    LoggingHook,
    MetricsCollector,
    StructuredLoggingHook,
    TransitionHook,
    TransitionMetrics,
    TransitionObserver,
)
from pystator.lint import LintSeverity, LintWarning, lint
from pystator.visualization import (
    get_statistics,
    to_dot,
    to_mermaid,
    to_mermaid_flowchart,
    to_scxml,
)

__all__ = [
    # Hooks
    "TransitionHook",
    "LoggingHook",
    "MetricsCollector",
    "StructuredLoggingHook",
    "DwellTimeTracker",
    "TransitionMetrics",
    "TransitionObserver",
    # Lint
    "lint",
    "LintSeverity",
    "LintWarning",
    # Visualization
    "to_mermaid",
    "to_mermaid_flowchart",
    "to_dot",
    "to_scxml",
    "get_statistics",
]
