"""EntitySession -- stateful per-entity FSM wrapper.

Provides a developer-friendly object that tracks current state,
context, and exposes trigger methods and state-check properties
auto-generated from the config.

Example:
    >>> machine = StateMachine.from_yaml("order_fsm.yaml")
    >>> order = machine.create(context={"order_id": "123"})
    >>>
    >>> order.current_state      # 'pending'
    >>> order.is_pending         # True
    >>> order.send("confirm")    # TransitionResult(success=True, ...)
    >>> order.current_state      # 'confirmed'
    >>> order.is_confirmed       # True
    >>> order.allowed_triggers   # ['ship', 'cancel']
"""

from __future__ import annotations

import asyncio
import re
import threading
import uuid
from dataclasses import dataclass

# Type hint only -- avoid circular import at runtime
from typing import TYPE_CHECKING, Any

from pystator._types import DestinationCheckResult, TransitionResult
from pystator.event import Event
from pystator.workflow_status import compute_workflow_status

if TYPE_CHECKING:
    from pystator.machine import StateMachine

# Characters to replace when converting state names to Python identifiers
_NON_ALNUM_RE = re.compile(r"[^a-zA-Z0-9]+")


def _to_python_id(name: str) -> str:
    """Convert a state/trigger name to a valid Python identifier.

    E.g. ``"PENDING_NEW"`` -> ``"pending_new"``,
         ``"order.submitted"`` -> ``"order_submitted"``.
    """
    return _NON_ALNUM_RE.sub("_", name).strip("_").lower()


class EntitySession:
    """Stateful wrapper around a :class:`StateMachine`.

    Tracks the current state and context for a single entity
    (e.g., one order, one user session). Provides:

    - ``send(trigger, **payload)`` / ``asend(trigger, **payload)``
    - Auto-generated trigger methods (e.g., ``order.confirm()``)
    - Auto-generated ``is_<state>`` properties (e.g., ``order.is_pending``)
    - ``current_state``, ``context``, ``is_final``, ``workflow_status``, ``allowed_triggers``
    - ``snapshot()`` for serializing the instance state (includes ``workflow_status``).
    """

    # Maximum number of deferred event replays per state change (prevents loops)
    _MAX_DEFERRED_REPLAY = 50

    def __init__(
        self,
        machine: StateMachine,
        *,
        entity_id: str | None = None,
        context: dict[str, Any] | None = None,
        initial_state: str | None = None,
        defer_unhandled: bool = False,
    ) -> None:
        """Initialize a stateful entity session.

        Args:
            machine: The StateMachine definition to use.
            entity_id: Optional unique identifier (auto-generated UUID if omitted).
            context: Optional initial context dict.
            initial_state: Override the initial state (defaults to machine's initial).
            defer_unhandled: If True, queue unmatched events for later replay.
        """
        if entity_id is not None:
            from pystator.shared.entity_id_validator import validate_entity_id

            self._entity_id = validate_entity_id(entity_id)
        else:
            self._entity_id = str(uuid.uuid4())
        self._machine = machine
        self._context = dict(context or {})
        self._current_state = initial_state or machine.get_initial_state().name
        self._history: list[TransitionResult] = []
        self._lock = threading.Lock()
        self._async_lock: asyncio.Lock | None = None
        self._defer_unhandled = defer_unhandled
        self._deferred_events: list[tuple[str, dict[str, Any]]] = []

        # Dynamically generate trigger methods and is_* properties
        self._bind_trigger_methods()
        self._bind_state_properties()

    # ------------------------------------------------------------------
    # Dynamic binding
    # ------------------------------------------------------------------

    def _bind_trigger_methods(self) -> None:
        """Create ``self.<trigger_name>(**payload)`` methods from config triggers.

        Each generated method calls ``self.send(trigger, **payload)``.
        """
        for trigger_name in self._machine.trigger_names:
            # Skip synthetic triggers (prefixed with _)
            if trigger_name.startswith("_"):
                continue
            py_name = _to_python_id(trigger_name)
            if hasattr(self, py_name):
                continue  # Don't override existing attributes
            # Create the closure with trigger_name captured
            self._create_trigger_method(py_name, trigger_name)

    def _create_trigger_method(self, py_name: str, trigger_name: str) -> None:
        """Bind a single trigger method."""

        def trigger_method(**payload: Any) -> TransitionResult:
            return self.send(trigger_name, **payload)

        trigger_method.__name__ = py_name
        trigger_method.__doc__ = (
            f"Send '{trigger_name}' event. Auto-generated from config."
        )
        setattr(self, py_name, trigger_method)

    def _bind_state_properties(self) -> None:
        """Create ``self.is_<state_name>`` read-only attributes from config states.

        These are simple boolean checks, not true descriptors, to keep
        things lightweight. They are re-evaluated on access via __getattr__.
        """
        # Store the set of valid is_* names so __getattr__ can resolve them
        self._is_state_names: dict[str, str] = {}
        for state_name in self._machine.state_names:
            py_name = f"is_{_to_python_id(state_name)}"
            self._is_state_names[py_name] = state_name

    def __getattr__(self, name: str) -> Any:
        """Resolve dynamic ``is_<state>`` properties by comparing current state."""
        # Avoid infinite recursion during __init__
        if name == "_is_state_names":
            raise AttributeError(name)
        is_names = self.__dict__.get("_is_state_names", {})
        if name in is_names:
            return self._current_state == is_names[name]
        raise AttributeError(
            f"'{type(self).__name__}' object has no attribute '{name}'"
        )

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def send(self, trigger: str, **payload: Any) -> TransitionResult:
        """Send an event to the machine and apply the transition.

        Thread-safe: uses an internal lock to serialize access.

        When ``defer_unhandled=True`` was set, events that don't match any
        transition are queued and replayed after the next successful state
        change.

        Args:
            trigger: Event trigger name.
            **payload: Event payload data (merged into context for guards/actions).

        Returns:
            TransitionResult describing the outcome.
        """
        with self._lock:
            return self._send_unlocked(trigger, payload)

    def _send_unlocked(self, trigger: str, payload: dict[str, Any]) -> TransitionResult:
        """Internal send without locking (called from send and replay)."""
        event = Event(trigger=trigger, payload=payload) if payload else trigger
        ctx = {**self._context, **payload}

        result = self._machine.process(self._current_state, event, ctx)

        if result.success and result.target_state:
            self._machine._engine.apply_history(result)
            self._current_state = result.target_state
            self._history.append(result)

            # Fire registered callbacks
            self._machine._fire_callbacks(result, ctx)

            # Evaluate auto transitions and when-routes from the new state
            post_results = self._machine._engine.evaluate_post_transition(
                self._current_state, ctx
            )
            for post_result in post_results:
                if post_result.success and post_result.target_state:
                    self._machine._engine.apply_history(post_result)
                    self._current_state = post_result.target_state
                    self._history.append(post_result)
                    self._machine._fire_callbacks(post_result, ctx)

            # Replay deferred events after state change
            if self._defer_unhandled and self._deferred_events:
                self._replay_deferred()
        elif not result.success and self._defer_unhandled:
            # Queue the event for later replay
            self._deferred_events.append((trigger, dict(payload)))

        return result

    def _replay_deferred(self) -> None:
        """Replay deferred events FIFO after a state change."""
        for _ in range(self._MAX_DEFERRED_REPLAY):
            if not self._deferred_events:
                break
            queued = list(self._deferred_events)
            self._deferred_events.clear()
            for trigger, payload in queued:
                result = self._send_unlocked(trigger, payload)
                if not result.success and self._defer_unhandled:
                    # Already re-queued by _send_unlocked
                    pass

    async def asend(self, trigger: str, **payload: Any) -> TransitionResult:
        """Async version of :meth:`send` (supports async guards).

        Async-safe: uses an internal asyncio.Lock to serialize access.
        """
        if self._async_lock is None:
            self._async_lock = asyncio.Lock()

        async with self._async_lock:
            return await self._asend_unlocked(trigger, payload)

    async def _asend_unlocked(
        self, trigger: str, payload: dict[str, Any]
    ) -> TransitionResult:
        """Internal async send without locking."""
        event = Event(trigger=trigger, payload=payload) if payload else trigger
        ctx = {**self._context, **payload}

        result = await self._machine.aprocess(self._current_state, event, ctx)

        if result.success and result.target_state:
            self._machine._engine.apply_history(result)
            self._current_state = result.target_state
            self._history.append(result)

            # Fire registered callbacks (async path)
            await self._machine._afire_callbacks(result, ctx)

            post_results = await self._machine._engine.async_evaluate_post_transition(
                self._current_state, ctx
            )
            for post_result in post_results:
                if post_result.success and post_result.target_state:
                    self._machine._engine.apply_history(post_result)
                    self._current_state = post_result.target_state
                    self._history.append(post_result)
                    await self._machine._afire_callbacks(post_result, ctx)

            # Replay deferred events after state change
            if self._defer_unhandled and self._deferred_events:
                await self._async_replay_deferred()
        elif not result.success and self._defer_unhandled:
            self._deferred_events.append((trigger, dict(payload)))

        return result

    async def _async_replay_deferred(self) -> None:
        """Async replay deferred events FIFO after a state change."""
        for _ in range(self._MAX_DEFERRED_REPLAY):
            if not self._deferred_events:
                break
            queued = list(self._deferred_events)
            self._deferred_events.clear()
            for trigger, payload in queued:
                await self._asend_unlocked(trigger, payload)

    # ------------------------------------------------------------------
    # Data-driven when-route evaluation
    # ------------------------------------------------------------------

    def apply_data(self, **data: Any) -> list[TransitionResult]:
        """Update context and evaluate when-route transitions.

        Merges *data* into the session context, then runs the post-transition
        evaluation chain (auto-transitions + when-routes). No trigger is
        required -- the destination states' ``when`` clauses determine which
        transition (if any) fires.

        Requires ``classification.auto_route: true`` in the machine meta.

        Returns:
            List of transition results that fired (may be empty).
        """
        with self._lock:
            return self._apply_data_unlocked(data)

    def _apply_data_unlocked(self, data: dict[str, Any]) -> list[TransitionResult]:
        self._context.update(data)
        ctx = dict(self._context)
        results = self._machine._engine.evaluate_post_transition(
            self._current_state, ctx
        )
        for r in results:
            if r.success and r.target_state:
                self._machine._engine.apply_history(r)
                self._current_state = r.target_state
                self._history.append(r)
                self._machine._fire_callbacks(r, ctx)
        return results

    async def aapply_data(self, **data: Any) -> list[TransitionResult]:
        """Async version of :meth:`apply_data`."""
        if self._async_lock is None:
            self._async_lock = asyncio.Lock()

        async with self._async_lock:
            self._context.update(data)
            ctx = dict(self._context)
            results = await self._machine._engine.async_evaluate_post_transition(
                self._current_state, ctx
            )
            for r in results:
                if r.success and r.target_state:
                    self._machine._engine.apply_history(r)
                    self._current_state = r.target_state
                    self._history.append(r)
                    await self._machine._afire_callbacks(r, ctx)
            return results

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------

    @property
    def entity_id(self) -> str:
        """Unique identifier for this entity session."""
        return self._entity_id

    @property
    def current_state(self) -> str:
        """Current state name."""
        return self._current_state

    @property
    def context(self) -> dict[str, Any]:
        """Current context (mutable reference)."""
        return self._context

    @context.setter
    def context(self, value: dict[str, Any]) -> None:
        self._context = value

    @property
    def is_final(self) -> bool:
        """True if current state is terminal."""
        return self._machine.is_terminal(self._current_state)

    @property
    def workflow_status(self) -> str:
        """FSM workflow outcome: ``active``, ``complete``, or ``failed``.

        Derived from the current state's type (``TERMINAL`` → complete,
        ``ERROR`` → failed, else active). Same semantics as persisted
        ``workflow_status`` on entity store rows.
        """
        return compute_workflow_status(self._machine, self._current_state)

    @property
    def allowed_triggers(self) -> list[str]:
        """Trigger names available from the current state."""
        return self._machine.get_available_triggers(self._current_state)

    @property
    def allowed_transitions(self) -> list[Any]:
        """Transition definitions available from the current state."""
        return self._machine.get_available_transitions(self._current_state)

    def evaluate_destination(
        self,
        destination_state: str,
        context_overrides: dict[str, Any] | None = None,
    ) -> DestinationCheckResult:
        """Check if *destination_state* is reachable from :attr:`current_state`.

        Merges ``context_overrides`` into :attr:`context` for the check (session
        context is not mutated). Same semantics as
        :meth:`StateMachine.evaluate_destination`.
        """
        ctx = dict(self._context)
        if context_overrides:
            ctx.update(context_overrides)
        return self._machine.evaluate_destination(
            self._current_state,
            destination_state,
            ctx,
        )

    def can_transition_to(
        self,
        destination_state: str,
        context_overrides: dict[str, Any] | None = None,
    ) -> bool:
        """True if *destination_state* is reachable from the current state now."""
        return self.evaluate_destination(destination_state, context_overrides).allowed

    @property
    def history(self) -> list[TransitionResult]:
        """List of all transition results applied to this instance."""
        return list(self._history)

    @property
    def deferred_events(self) -> list[tuple[str, dict[str, Any]]]:
        """Pending deferred events (trigger, payload) not yet applied."""
        return list(self._deferred_events)

    def clear_deferred(self) -> None:
        """Discard all deferred events."""
        self._deferred_events.clear()

    # ------------------------------------------------------------------
    # Snapshot / restore
    # ------------------------------------------------------------------

    def snapshot(self) -> dict[str, Any]:
        """Serialize instance state for persistence.

        Returns:
            Dict with current_state, context, and deferred events (serializable).
        """
        snap: dict[str, Any] = {
            "entity_id": self._entity_id,
            "current_state": self._current_state,
            "context": dict(self._context),
            "machine_name": self._machine.name,
            "machine_version": self._machine.version,
            "is_terminal": self._machine.is_terminal(self._current_state),
            "workflow_status": compute_workflow_status(
                self._machine, self._current_state
            ),
        }
        if self._deferred_events:
            snap["deferred_events"] = [
                {"trigger": t, "payload": p} for t, p in self._deferred_events
            ]
        return snap

    @classmethod
    def from_snapshot(
        cls,
        machine: StateMachine,
        snapshot: dict[str, Any],
    ) -> EntitySession:
        """Restore an instance from a snapshot.

        Args:
            machine: The StateMachine definition.
            snapshot: Dict from :meth:`snapshot`.

        Returns:
            Restored EntitySession.
        """
        instance = cls(
            machine=machine,
            entity_id=snapshot.get("entity_id"),
            context=snapshot.get("context"),
            initial_state=snapshot.get("current_state"),
            defer_unhandled=bool(snapshot.get("deferred_events")),
        )
        for ev in snapshot.get("deferred_events", []):
            instance._deferred_events.append((ev["trigger"], ev.get("payload", {})))
        return instance

    def record(self) -> EventRecorder:
        """Return an EventRecorder that wraps this instance for replay support."""
        return EventRecorder(self)

    def __repr__(self) -> str:
        return (
            f"EntitySession(id={self._entity_id!r}, "
            f"machine={self._machine.name!r}, "
            f"state={self._current_state!r})"
        )


# ---------------------------------------------------------------------------
# EventRecorder
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class RecordedEvent:
    """A single recorded event with timestamp."""

    trigger: str
    payload: dict[str, Any]
    timestamp: float  # time.monotonic() value

    def to_dict(self) -> dict[str, Any]:
        return {
            "trigger": self.trigger,
            "payload": self.payload,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RecordedEvent:
        return cls(
            trigger=data["trigger"],
            payload=data.get("payload", {}),
            timestamp=data.get("timestamp", 0.0),
        )


class EventRecorder:
    """Records events sent to an EntitySession for later replay.

    Example::

        order = machine.create()
        recorder = order.record()
        recorder.send("confirm", valid=True)
        recorder.send("ship")

        # Replay on a fresh instance
        replayed = recorder.replay(machine)
        assert replayed.current_state == order.current_state
    """

    def __init__(self, instance: EntitySession) -> None:
        self._instance = instance
        self._events: list[RecordedEvent] = []
        self._initial_context: dict[str, Any] = dict(instance.context)
        self._initial_state: str = instance.current_state

    def send(self, trigger: str, **payload: Any) -> TransitionResult:
        """Send an event (delegates to instance) and record it."""
        import time

        self._events.append(
            RecordedEvent(
                trigger=trigger,
                payload=dict(payload),
                timestamp=time.monotonic(),
            )
        )
        return self._instance.send(trigger, **payload)

    @property
    def events(self) -> list[RecordedEvent]:
        """All recorded events."""
        return list(self._events)

    @property
    def instance(self) -> EntitySession:
        """The wrapped EntitySession."""
        return self._instance

    def replay(self, machine: StateMachine) -> EntitySession:
        """Create a fresh instance and replay all recorded events."""
        new_instance = machine.create(
            context=dict(self._initial_context),
            initial_state=self._initial_state,
        )
        for event in self._events:
            new_instance.send(event.trigger, **event.payload)
        return new_instance

    def to_dict(self) -> dict[str, Any]:
        """Serialize the recording for storage."""
        return {
            "initial_state": self._initial_state,
            "initial_context": self._initial_context,
            "events": [e.to_dict() for e in self._events],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any], machine: StateMachine) -> EventRecorder:
        """Deserialize a recording and attach to a fresh instance."""
        instance = machine.create(
            context=data.get("initial_context", {}),
            initial_state=data.get("initial_state"),
        )
        recorder = cls(instance)
        recorder._events = [RecordedEvent.from_dict(e) for e in data.get("events", [])]
        return recorder
