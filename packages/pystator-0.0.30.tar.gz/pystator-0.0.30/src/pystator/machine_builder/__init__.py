"""Machine Builder — construct runtime StateMachines from definitions or stores.

Produces StateMachine instances from MachineDefinition objects (parsed configs)
or directly from a MachineStoreClient, with optional guard/action binding.
"""

from __future__ import annotations

from pystator.machine_builder.builder import (
    MachineNotFoundError,
    build_machine,
    build_machine_from_store,
)

__all__ = [
    "MachineNotFoundError",
    "build_machine",
    "build_machine_from_store",
]
