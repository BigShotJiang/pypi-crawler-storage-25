"""Machine Builder — construct runtime StateMachines from definitions or stores.

Consolidates logic previously scattered across:
- api/services/fsm_service.py (build_machine_from_config with pass-through guards)
- worker/registry.py (_register — from_dict + bind guards/actions)
- api/services/entity_service.py (load_machine_config + FSMService.process)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pystator.machine_parser.types import MachineDefinition

if TYPE_CHECKING:
    from pystator.actions import ActionRegistry
    from pystator.guards import GuardRegistry
    from pystator.machine import StateMachine
    from pystator.machine_store.client import MachineStoreClient


class MachineNotFoundError(Exception):
    """Raised when a machine definition cannot be found in the store."""

    def __init__(self, name: str, version: str | None = None) -> None:
        self.name = name
        self.version = version
        detail = f"Machine '{name}'"
        if version:
            detail += f" version '{version}'"
        detail += " not found in store"
        super().__init__(detail)


def build_machine(
    definition: MachineDefinition,
    *,
    guards: GuardRegistry | None = None,
    actions: ActionRegistry | None = None,
) -> StateMachine:
    """Build a runtime StateMachine from a MachineDefinition.

    Optionally binds guard and action registries so the machine is
    ready for event processing.

    Args:
        definition: A parsed MachineDefinition.
        guards: Optional guard registry to bind.
        actions: Optional action registry to bind.

    Returns:
        A fully configured StateMachine instance.
    """
    from pystator.machine import StateMachine

    machine = StateMachine.from_dict(definition.config)
    if guards is not None:
        machine.bind_guards(guards)
    if actions is not None:
        machine.bind_actions(actions)
    return machine


def build_machine_from_store(
    store: MachineStoreClient,
    name: str,
    version: str | None = None,
    *,
    guards: GuardRegistry | None = None,
    actions: ActionRegistry | None = None,
) -> StateMachine:
    """Load a machine definition from a store and build a StateMachine.

    Args:
        store: A connected MachineStoreClient.
        name: Machine name to look up.
        version: Specific version, or None for latest.
        guards: Optional guard registry to bind.
        actions: Optional action registry to bind.

    Returns:
        A fully configured StateMachine instance.

    Raises:
        MachineNotFoundError: If the machine is not in the store.
    """
    definition = store.get(name, version)
    if definition is None:
        raise MachineNotFoundError(name, version)
    return build_machine(definition, guards=guards, actions=actions)
