# Context and Sinks API

## TransitionContext

::: pystator.context.TransitionContext
    options:
      show_root_heading: true
      heading_level: 3

## Sinks

::: pystator.sinks.EventSink
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.sinks.MetricSink
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.sinks.LoggingEventSink
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.sinks.LoggingMetricSink
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.sinks.configure_event_sink
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.sinks.configure_metric_sink
    options:
      show_root_heading: true
      heading_level: 3

## Import

```python
from pystator.context import TransitionContext

from pystator.sinks import (
    EventSink,
    MetricSink,
    LoggingEventSink,
    LoggingMetricSink,
    configure_event_sink,
    configure_metric_sink,
)
```

## Context key reference

| Key | Set by | Description |
|-----|--------|-------------|
| `_event` | Engine | `Event` object for the current transition |
| `_entity_id` | Orchestrator | Entity ID being processed |
| `_action_params` | ActionExecutor | Parameters from YAML `params:` for the current action |

All other keys are user-defined and come from the entity's persistent context or the event payload.

## See also

- [Context guide](../guides/context.md)
- [Orchestrator](orchestrator.md) — `context_validator` parameter
- [Hooks and Metrics](hooks.md)
