# Errors

Exception hierarchy for FSM configuration and runtime errors.

::: pystator.errors.FSMError

::: pystator.errors.ConfigurationError
::: pystator.errors.InvalidTransitionError
::: pystator.errors.GuardRejectedError
::: pystator.errors.UndefinedStateError
::: pystator.errors.UndefinedTriggerError
::: pystator.errors.GuardNotFoundError
::: pystator.errors.ActionNotFoundError
::: pystator.errors.TimeoutExpiredError
::: pystator.errors.TerminalStateError
::: pystator.errors.StaleVersionError
