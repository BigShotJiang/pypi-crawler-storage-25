# Worker (Python API)

Long-running **event consumer** that claims rows from `worker_events`, runs the **Orchestrator**, and updates **entity state**. Operational guide: [Worker](../guides/worker.md).

## Types and entrypoints

::: pystator.worker.runner.Worker

::: pystator.worker.config.WorkerConfig

::: pystator.worker.submit_event

::: pystator.worker.submit_event_sync

## Related models

::: pystator.worker.models.WorkerEvent

::: pystator.worker.models.ClaimedEvent

::: pystator.worker.models.EventStatus

## Imports

```python
from pystator.worker import Worker, WorkerConfig, submit_event, submit_event_sync
```

Install: `pip install pystator[worker]` (database URL required at runtime).
