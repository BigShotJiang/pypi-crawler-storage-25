# Actions

Register and execute actions (on_enter, on_exit, transition actions).

::: pystator.actions.ActionRegistry

::: pystator.actions.ActionExecutor
