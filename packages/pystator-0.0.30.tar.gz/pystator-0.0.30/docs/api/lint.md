# Linting API

Static analysis of state machine definitions — detect unreachable states, dead ends, nondeterminism, and missing guard/action registrations.

See [Linting guide](../guides/linting.md) for the full guide with CI integration examples.

## Functions

::: pystator.lint.lint
    options:
      show_root_heading: true
      heading_level: 3

## Data classes and enumerations

::: pystator.lint.LintSeverity
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.lint.LintWarning
    options:
      show_root_heading: true
      heading_level: 3

## Lint check codes

| Code | Severity | Description |
|------|---------|-------------|
| `unreachable_state` | WARNING | State cannot be reached from the initial state |
| `dead_end` | WARNING | Non-terminal state with no outbound transitions |
| `dead_transition` | WARNING | Transition shadowed by a higher-priority transition |
| `nondeterministic` | WARNING | Multiple unguarded transitions with the same trigger |
| `missing_guard` | WARNING | Guard name referenced but not registered |
| `missing_action` | WARNING | Action name referenced but not registered |

## Import

```python
from pystator.lint import lint, LintWarning, LintSeverity

# Or from the top-level package
from pystator import lint, LintWarning
```

## See also

- [Linting guide](../guides/linting.md)
- [Visualization](visualization.md) — generate diagrams
