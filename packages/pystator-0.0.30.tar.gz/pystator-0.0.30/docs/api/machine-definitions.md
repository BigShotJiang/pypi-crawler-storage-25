# Machine definitions (parser, store, builder)

Use this pipeline when you want a **canonical `MachineDefinition`** (parse once, validate, store in DB) and **build a `StateMachine`** only when needed. For a single YAML file in a script, `StateMachine.from_yaml()` is usually enough.

See the [Package structure guide](../guides/package-structure.md#machine-definition-layers) for when to use each layer.

## Types and parsing

::: pystator.machine_parser.types.MachineDefinition

::: pystator.machine_parser.parser.parse_machine

::: pystator.machine_parser.parser.parse_machine_file

## Building runtime machines

::: pystator.machine_builder.builder.build_machine

::: pystator.machine_builder.builder.build_machine_from_store

::: pystator.machine_builder.builder.MachineNotFoundError

## Definition stores

::: pystator.machine_store.client.MachineStoreClient

::: pystator.machine_store.in_memory.InMemoryMachineStore

::: pystator.machine_store._sqlalchemy.SQLAlchemyMachineStore

`SQLAlchemyMachineStore` requires SQLAlchemy (included with `pystator[api]` or `pystator[worker]`). It is also exported as `from pystator.machine_store import SQLAlchemyMachineStore` when dependencies are present.

## Imports

```python
from pystator.machine_parser import MachineDefinition, parse_machine, parse_machine_file
from pystator.machine_builder import build_machine, build_machine_from_store, MachineNotFoundError
from pystator.machine_store import MachineStoreClient, InMemoryMachineStore
# Optional, when SQLAlchemy is installed:
from pystator.machine_store import SQLAlchemyMachineStore
```

The same symbols are available from the top-level `pystator` package (`from pystator import ...`).
