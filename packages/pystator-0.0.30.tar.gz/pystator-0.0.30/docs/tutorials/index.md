# Tutorials

Step-by-step guides to build workflows and use the API and UI.

## Available tutorials

| Tutorial | Description | Duration |
|----------|-------------|----------|
| [Order workflow](order-workflow.md) | Build an order lifecycle FSM with guards and actions, run it in Python. | ~25 min |
| [API and UI](api-and-ui.md) | Run the REST API and web UI; validate configs, run process, manage machines. | ~15 min |

## Learning path

1. **Order workflow** — Get comfortable with states, transitions, guards, and actions in code.
2. **API and UI** — Use the same concepts over HTTP and in the visual builder.

## Prerequisites

- Python 3.11+
- `pip install pystator` (and `pystator[api]` for the API/UI tutorial)
- [Quick start](../getting-started/quickstart.md) done (optional but helpful)

## Tutorial format

Each tutorial includes:

1. **Overview** — What you’ll build or do
2. **Steps** — Numbered instructions with copy-paste code
3. **What’s next** — Links to deeper docs or other tutorials

## Getting help

- [Concepts](../guides/concepts.md) — States, transitions, guards, actions
- [API reference](../api.md) — Full API summary
- [Examples](../examples.md) — Runnable example list
- [GitHub Issues](https://github.com/optophi/pystator/issues)
