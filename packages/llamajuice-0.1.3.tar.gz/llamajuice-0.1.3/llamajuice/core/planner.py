"""VRAM budget planner — figure out what fits and how to manage it.

Given a GPU and a list of models, calculates:
  - What fits simultaneously
  - What needs to be loaded on-demand
  - Recommended keep_alive for each model
  - Headroom for KV cache and overhead
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


class LoadStrategy(Enum):
    PINNED = "pinned"        # keep_alive: -1, always in VRAM
    WARM = "warm"            # keep_alive: 10-30m, stays loaded during active use
    ON_DEMAND = "on-demand"  # keep_alive: 60-90s, loaded when needed, dropped after


@dataclass
class ModelSlot:
    name: str
    size_gb: float
    role: str              # "primary", "router", "stt", "tts", "embedding"
    strategy: LoadStrategy = LoadStrategy.PINNED
    keep_alive: str = "-1"  # Ollama keep_alive value
    priority: int = 0       # higher = more important to keep loaded

    @property
    def keep_alive_seconds(self) -> int:
        if self.keep_alive == "-1":
            return -1
        if self.keep_alive.endswith("m"):
            return int(self.keep_alive[:-1]) * 60
        if self.keep_alive.endswith("s"):
            return int(self.keep_alive[:-1])
        return int(self.keep_alive)


@dataclass
class VRAMPlan:
    gpu_name: str
    vram_total_gb: float
    slots: list[ModelSlot] = field(default_factory=list)
    overhead_gb: float = 0.5  # KV cache, CUDA context, etc.

    @property
    def pinned_gb(self) -> float:
        return sum(s.size_gb for s in self.slots if s.strategy == LoadStrategy.PINNED)

    @property
    def warm_gb(self) -> float:
        return sum(s.size_gb for s in self.slots if s.strategy == LoadStrategy.WARM)

    @property
    def on_demand_gb(self) -> float:
        return sum(s.size_gb for s in self.slots if s.strategy == LoadStrategy.ON_DEMAND)

    @property
    def peak_gb(self) -> float:
        """Worst-case VRAM: all models loaded simultaneously."""
        return sum(s.size_gb for s in self.slots) + self.overhead_gb

    @property
    def typical_gb(self) -> float:
        """Typical VRAM: pinned + overhead. On-demand models come and go."""
        return self.pinned_gb + self.overhead_gb

    @property
    def headroom_gb(self) -> float:
        return round(self.vram_total_gb - self.typical_gb, 1)

    @property
    def fits(self) -> bool:
        """Can at least the pinned models fit?"""
        return self.typical_gb <= self.vram_total_gb

    @property
    def peak_fits(self) -> bool:
        """Can ALL models fit simultaneously?"""
        return self.peak_gb <= self.vram_total_gb

    def to_dict(self) -> dict:
        return {
            "gpu": self.gpu_name,
            "vram_total_gb": self.vram_total_gb,
            "overhead_gb": self.overhead_gb,
            "slots": [
                {
                    "name": s.name,
                    "size_gb": s.size_gb,
                    "role": s.role,
                    "strategy": s.strategy.value,
                    "keep_alive": s.keep_alive,
                }
                for s in self.slots
            ],
            "pinned_gb": round(self.pinned_gb, 1),
            "typical_gb": round(self.typical_gb, 1),
            "peak_gb": round(self.peak_gb, 1),
            "headroom_gb": self.headroom_gb,
            "fits": self.fits,
            "peak_fits": self.peak_fits,
        }


# Known model sizes (approximate, Q4_K_M quant, for when we can't query Ollama)
KNOWN_SIZES: dict[str, float] = {
    "qwen2.5:7b": 4.4,
    "qwen2.5:1.5b": 0.9,
    "qwen2.5:0.5b": 0.4,
    "qwen2.5-coder:7b": 4.4,
    "qwen3:8b": 5.0,
    "qwen3.5:9b": 5.2,
    "llama3.1:8b": 4.9,
    "gemma3:4b": 3.1,
    "gemma4:e4b": 3.9,
    "mistral:7b": 4.4,
    "phi3:mini": 2.2,
    "granite3.1:8b": 4.6,
    "deepseek-r1:8b": 4.9,
    "whisper-medium": 1.5,
    "whisper-large-v3": 3.0,
    "whisper-distil-large-v3": 1.5,
    "nomic-embed-text": 0.3,
}

# Rough Q4_K_M sizes by parameter count — used as last resort
_PARAM_SIZE_GB: dict[str, float] = {
    "0.5b": 0.4, "1b": 0.6, "1.5b": 0.9, "2b": 1.3,
    "3b": 1.8, "4b": 2.5, "7b": 4.5, "8b": 5.0,
    "9b": 5.5, "13b": 7.5, "14b": 8.5, "27b": 16.0, "70b": 40.0,
}

# Role-based strategy defaults
ROLE_DEFAULTS: dict[str, tuple[LoadStrategy, str, int]] = {
    "primary":   (LoadStrategy.PINNED, "-1", 10),
    "router":    (LoadStrategy.PINNED, "-1", 9),
    "stt":       (LoadStrategy.ON_DEMAND, "90s", 5),
    "tts":       (LoadStrategy.ON_DEMAND, "90s", 4),
    "embedding": (LoadStrategy.PINNED, "-1", 3),  # CPU-only, no VRAM
}


def _estimate_from_params(name: str) -> float:
    """Estimate model size from parameter count in the name (e.g. '7b' -> 4.5 GB)."""
    match = re.search(r'(\d+\.?\d*b)\b', name.lower())
    if match:
        param_key = match.group(1)
        if param_key in _PARAM_SIZE_GB:
            return _PARAM_SIZE_GB[param_key]
    return 0.0


def _get_model_size(name: str) -> float:
    """Look up model size. Tries multiple strategies before giving up."""
    # 1. Try Ollama API with fuzzy matching
    try:
        import httpx
        resp = httpx.get("http://localhost:11434/api/tags", timeout=3)
        if resp.status_code == 200:
            for m in resp.json().get("models", []):
                m_name = m.get("name", "")
                # Exact match
                if m_name == name:
                    return round(m["size"] / (1024**3), 1)
                # Match without :latest tag (Ollama appends this)
                if m_name == f"{name}:latest":
                    return round(m["size"] / (1024**3), 1)
                # Input is prefix of stored name (e.g. "qwen2.5:7b" matches "qwen2.5:7b:latest")
                if m_name.startswith(f"{name}:"):
                    return round(m["size"] / (1024**3), 1)
    except Exception:
        pass

    # 2. Check known sizes dict
    key = name.lower().strip()
    if key in KNOWN_SIZES:
        return KNOWN_SIZES[key]

    # 3. Estimate from parameter count in the name
    estimate = _estimate_from_params(name)
    if estimate > 0:
        return estimate

    # 4. Truly unknown
    return 0.0


def plan_vram(
    models: list[tuple[str, str]],  # list of (model_name, role)
    vram_total_gb: float | None = None,
    gpu_name: str | None = None,
) -> VRAMPlan:
    """Create a VRAM budget plan for the given models.

    Args:
        models: list of (model_name, role) tuples.
                Roles: "primary", "router", "stt", "tts", "embedding"
        vram_total_gb: GPU VRAM in GB. Auto-detected if None.
        gpu_name: GPU name. Auto-detected if None.
    """
    if vram_total_gb is None or gpu_name is None:
        from llamajuice.core.gpu import detect_gpu
        gpu = detect_gpu()
        vram_total_gb = vram_total_gb or gpu.vram_total_gb
        gpu_name = gpu_name or gpu.name

    plan = VRAMPlan(gpu_name=gpu_name, vram_total_gb=vram_total_gb)

    # Build slots with default strategies
    for name, role in models:
        size = _get_model_size(name)
        strategy, keep_alive, priority = ROLE_DEFAULTS.get(
            role, (LoadStrategy.WARM, "10m", 1)
        )
        plan.slots.append(ModelSlot(
            name=name,
            size_gb=size,
            role=role,
            strategy=strategy,
            keep_alive=keep_alive,
            priority=priority,
        ))

    # If pinned models don't fit, demote lowest-priority pinned to warm
    while not plan.fits and any(
        s.strategy == LoadStrategy.PINNED for s in plan.slots
    ):
        # Find lowest-priority pinned model
        pinned = [s for s in plan.slots if s.strategy == LoadStrategy.PINNED]
        pinned.sort(key=lambda s: s.priority)
        demote = pinned[0]
        demote.strategy = LoadStrategy.ON_DEMAND
        demote.keep_alive = "90s"

    return plan
