# RapidBalancer

RapidBalancer is a lightweight and powerful Python load balancer designed for the BetterRapidHost ecosystem.

It provides:

- ⚖️ Smart load balancing
- 🌐 Reverse proxy system
- 📊 Real-time dashboard
- 👥 Client tracking
- 🔥 Request monitoring
- 📡 Traffic analytics
- 🔄 Automatic failover
- 🧠 Sticky sessions
- ⚡ High performance routing
- 🖥️ Live node monitoring

with extremely simple syntax.

---

# ✨ Features

- ⚖️ Smart balancing algorithm
- 🔄 Automatic node failover
- 📡 Reverse proxy support
- 👥 Client analytics
- 📊 Real-time dashboard
- 📈 Live statistics API
- 🔥 Request inspector
- 🧠 Sticky sessions
- 🚀 Multi-node support
- 🔒 Optional SSL support
- ⚡ Performance mode
- 💀 Extreme mode
- 🌐 LAN and WAN ready
- 📁 BetterRapidHost integration

---

# 📦 Installation

Install using pip:

```bash
pip install RapidBalancer
```

---

# 🚀 Quick Start

## Basic Load Balancer

```python
from RapidBalancer import RapidBalancer

RapidBalancer.add(
    "127.0.0.1:5000",
    "127.0.0.1:5001",
    "127.0.0.1:5002",
    "127.0.0.1:5003"
)

RapidBalancer.run(
    host="0.0.0.0",
    port=8080
)
```

---

# 🌐 Access

## Main Website

```text
http://IP:8080
```

---

## Dashboard

```text
http://IP:8080/balancer_panel
```

---

## Stats API

```text
http://IP:8080/balancer_stats
```

---

# 🧠 Smart Balancing

RapidBalancer automatically chooses the best node based on:

- latency
- active connections
- traffic usage

No manual configuration required.

---

# 🔄 Automatic Failover

If a node goes offline:

```text
NODE 5001 DOWN
```

RapidBalancer automatically removes it from rotation.

Clients continue accessing the application normally.

---

# 👥 Client Tracking

RapidBalancer automatically tracks:

- IP address
- request count
- traffic usage
- visited routes
- user-agent
- connection time

---

# 📊 Dashboard

Built-in realtime dashboard includes:

- online nodes
- online clients
- total traffic
- requests
- latency
- CPU usage
- RAM usage
- node statistics
- client analytics

---

# 📡 Reverse Proxy

RapidBalancer acts as a reverse proxy.

Example architecture:

```text
Client
   ↓
RapidBalancer :8080
   ↓
RapidHost :5000
RapidHost :5001
RapidHost :5002
RapidHost :5003
```

---

# 🔥 BetterRapidHost Integration

## RapidHost Example

```python
from BetterRapidHost import RapidHost

RapidHost.hostIP("127.0.0.1")

RapidHost.hostPort(5000)

RapidHost.hostSite("index.html")
```

## RapidBalancer Example

```python
from RapidBalancer import RapidBalancer

RapidBalancer.add(
    "127.0.0.1:5000"
)

RapidBalancer.run(
    host="0.0.0.0",
    port=8080
)
```

Clients access only:

```text
http://IP:8080
```

Backend nodes remain hidden and protected.

---

# ⚡ Performance Mode

```python
RapidBalancer.PerformanceMode()
```

Optimizations:

- lower latency
- faster refresh rate
- higher request limit

---

# 💀 Extreme Mode

```python
RapidBalancer.ExtremeMode()
```

Extreme optimizations:

- ultra low timeout
- ultra fast health checks
- massive request limit
- aggressive balancing

---

# 📈 Statistics

## Global Stats

```python
RapidBalancer.stats()
```

Example:

```python
{
    "global": {
        "requests": 15281,
        "traffic": 9283812,
        "errors": 2
    }
}
```

---

# 🔍 Node Management

## Add Nodes

```python
RapidBalancer.add(
    "127.0.0.1:5000",
    "127.0.0.1:5001"
)
```

---

## Remove Node

```python
RapidBalancer.RemoveNode(
    "127.0.0.1",
    5000
)
```

---

## Disable Node

```python
RapidBalancer.DisableNode(
    "127.0.0.1",
    5000
)
```

---

## Enable Node

```python
RapidBalancer.EnableNode(
    "127.0.0.1",
    5000
)
```

---

# 🔒 SSL Support

```python
RapidBalancer.enableSSL(
    "cert.pem",
    "key.pem"
)
```

---

# 🔥 Request Inspector

Get request logs:

```python
RapidBalancer.Requests()
```

---

# 🖥️ System Monitor

```python
RapidBalancer.CPUUsage()

RapidBalancer.RAMUsage()
```

---

# 📁 Recommended Architecture

```text
Internet
   ↓
RapidBalancer
   ↓
RapidHost Cluster
```

---

# ⚡ Philosophy

RapidBalancer focuses on:

- simplicity
- realtime monitoring
- scalability
- performance
- minimal syntax
- powerful infrastructure tools

---

# 📜 License

MIT License

---

# 👨‍💻 Author

Leonardo Nery