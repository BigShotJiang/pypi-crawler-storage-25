# Agent Server

一个基于 Google ADK (Agent Development Kit) 和 FastAPI 构建的智能体服务服务器，用于运行和管理 AI 代理。

## 项目概述

`agent-server` 提供了多种接口方式来与 AI 代理进行交互，包括 HTTP API、AGUI 接口和命令行界面。

## 核心功能

### 1. ADK Server

基于 FastAPI 的 HTTP API 服务器，使用 Google ADK 的 Runner 来执行代理。

- **功能**: 提供标准的 HTTP API 接口
- **会话管理**: 支持会话创建和管理
- **安全**: 包含用户白名单中间件
- **启动命令**: `agent-server-adk`

配置文件参数说明：
AGENTS_PATH=/Users/fubo/develop/apps/agent-os # 智能体配置的上一级文件夹
SESSION_SERVICE_URI=sqlite+aiosqlite:///./sessions.db # Session服务的链接
MEMORY_SERVICE_URI=milvus+http: # Memory服务的链接（backend支持内存【空字符串】、Milvus【milvus】）
EMBEDDING_BASE_URL="http://localhost:8000/v1" # embedding服务的base url
EMBEDDING_API_KEY="sk-XXX" # embedding服务的API-KEY
EMBEDDING_MODEL="" # embedding模型名称
USER_SERVICE_URI= # 用户服务的URI
TRACE_SERVICE_URI=test@http://101.42.12.55:20500 # 智能体trace服务的URI
HOST=0.0.0.0  # 服务IP
PORT=8000  # 服务端口
ASYNC_CHAT_MAX_CONCURRENCY=4  # 异步提交最大job的数量
ASYNC_CHAT_MAX_TASK_EVENTS=2000 # 异步提交最大的event数量

### 2. AGUI Server

提供 AGUI (Agent Graphical User Interface) 接口，用于图形化交互。

- **主要端点**:
  - `POST /agui/api/v1/chat/completions` - 聊天完成接口
  - `GET /agui/api/v1/reload` - 热重载代理配置
  - `GET /agui/api/v1/health` - 健康检查
- **启动命令**: `agent-server-agui`

### 3. CMD Server

命令行交互界面，使用 `rich` 库实现彩色输出和 Markdown 渲染。

- **功能**:
  - 任务提交和执行
  - 会话管理（列出、删除）
  - 实时输出代理响应
  - 支持工具调用和函数响应展示
- **启动命令**: `agent-server-cmd`

## 技术架构

### 依赖
- **Google ADK**: Agent Development Kit，用于代理运行
- **FastAPI**: Web 框架，提供 HTTP API
- **Uvicorn**: ASGI 服务器
- **Rich**: 命令行美化输出
- **Python Dotenv**: 环境变量管理

### 工具类 (utils.py)

- **Utils.Service**: 提供 session 和 memory 服务的创建
  - `memory_service()`: 创建记忆服务
  - `session_service()`: 创建会话服务
- **Utils.Agent**: 负责代理的加载和运行器创建
  - `load_adk_agents()`: 从指定路径加载代理配置
  - `create_adk_agent_agui_runner()`: 创建 AGUI 运行器
  - `create_adk_agent_adk_runner()`: 创建 ADK 运行器

## 配置说明

配置文件：`.server.env`

```bash
# 代理配置路径
AGENTS_PATH=/Users/fubo/develop/apps/agent-os/agents

# 会话服务数据库 URI（留空使用内存服务）
SESSION_SERVICE_URI=

# 记忆服务 URI（留空使用内存服务）
MEMORY_SERVICE_URI=

# 用户服务 URI
USER_SERVICE_URI=

# 追踪服务 URI
TRACE_SERVICE_URI=

# 服务器监听地址
HOST=0.0.0.0

# 服务器端口
PORT=8000
```

## 安装与使用

### 安装依赖

```bash
pip install -e .
```

### 启动服务

```bash
# 启动 AGUI 服务器
agent-server-agui

# 启动命令行界面
agent-server-cmd

# 启动 ADK 服务器
agent-server-adk
```

## 项目结构

```
agent-server/
├── src/
│   └── agent_server/
│       ├── __init__.py
│       ├── adk_server.py      # ADK HTTP 服务器
│       ├── agui_server.py     # AGUI 服务器
│       ├── cmd_server.py      # 命令行服务器
│       ├── utils.py           # 工具类
│       └── .server.env        # 配置文件
├── tests/
├── pyproject.toml
├── Dockerfile
└── README.md
```

## 开发信息

- **版本**: 0.0.1
- **作者**: fubo <fb_linux@163.com>
- **许可证**: MIT
- **Python 版本**: >= 3.10

## 依赖项

- `agent-base>=0.1.2`
- `fastapi`
- `uvicorn`
- `rich`
- `python-dotenv`
- `google-adk`

## 测试

```bash
pip install -e ".[test]"
pytest
```
