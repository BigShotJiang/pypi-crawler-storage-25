import uuid
import json
import asyncio
from dataclasses import dataclass, field
from typing import Optional, Dict, List
import logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

from rich.console import Console
from rich.markdown import Markdown

from google.adk.sessions import BaseSessionService
from google.genai import types

from agent_server.utils import Utils, ServerConfig, ChatRequest
from agent_server.agent_runner import AgentRunner


@dataclass
class JobRecord:
    job_id: str
    session_id: str
    prompt: str
    task: Optional[asyncio.Task] = None
    done: bool = False
    error: Optional[str] = None
    buffer: List[str] = field(default_factory=list)


class AgentCMDRunner:
    def __init__(self) -> None:
        self.user_id = "cmd-user"
        self.console = Console()
        server_config: ServerConfig = Utils.load_envs(".server.env")
        self.runner: AgentRunner = AgentRunner(
            agents_path=server_config.agents_path,
            session_service_uri=server_config.session_service_uri,
            memory_service_uri=server_config.memory_service_uri
        )
        self.runner.adk_runner.auto_create_session = True
        self.session_service: BaseSessionService = self.runner.session_service

        self.jobs: Dict[str, JobRecord] = {}
        self.foreground_job_id: Optional[str] = None

    @staticmethod
    def print_banner():
        banner = r"""
         █████╗  ██████╗ ███████╗███╗   ██╗████████╗    ██████╗ ███████╗
        ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝   ██╔═══██╗██╔════╝
        ███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║      ██║   ██║███████╗
        ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║      ██║   ██║╚════██║
        ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║      ╚██████╔╝███████║
        ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝       ╚═════╝ ╚══════╝
        """
        print(banner)

    def render_output(self, text: str):
        self.console.print(Markdown(text), justify="left")

    def format_part(self, part: types.Part) -> Optional[str]:
        if part.text is not None and part.text != "" and part.thought is True:
            return f"===\n* **分析**\n{part.text}"

        if part.text is not None and part.text != "" and (part.thought is None or part.thought is False):
            return f"===\n* **答案**\n{part.text}"

        if part.function_call is not None:
            try:
                params_json = json.dumps(part.function_call.args, indent=2, ensure_ascii=False)
            except Exception:
                params_json = str(part.function_call.args)

            return (
                f"===\n* **工具调用**\n"
                f"- 工具名：{part.function_call.name}\n"
                f"- 工具参数：\n```python\n{params_json}\n```"
            )

        if part.function_response is not None:
            try:
                response_json = json.dumps(part.function_response.response, indent=2, ensure_ascii=False)
            except Exception:
                response_json = str(part.function_response.response)

            return (
                f"===\n* **工具调用返回结果**\n"
                f"- 工具名：{part.function_response.name}\n"
                f"- 工具返回结果：\n```json\n{response_json}\n```"
            )

        return None

    def _emit_to_job(self, job: JobRecord, text: str):
        job.buffer.append(text)

        # 只有当前前台任务才实时显示
        if self.foreground_job_id == job.job_id:
            self.render_output(text)

    async def submit_job(self, input_text: str) -> str:
        job_id = uuid.uuid4().hex[:8]
        session_id = uuid.uuid4().hex

        job = JobRecord(
            job_id=job_id,
            session_id=session_id,
            prompt=input_text,
        )
        self.jobs[job_id] = job

        job.task = asyncio.create_task(self._run_job(job))
        return job_id

    async def _run_job(self, job: JobRecord):
        try:
            async for chunk in self.runner.run(
                    user_id=self.user_id,
                    request=ChatRequest(
                        type="adk", session_id=job.session_id, message=job.prompt
                    ),
                    use_adk_sse=False
            ):
                for part in chunk.content.parts:
                    rendered = self.format_part(part)
                    if rendered:
                        self._emit_to_job(job, rendered)

            job.done = True
            if self.foreground_job_id == job.job_id:
                self.render_output(f"===\n* **任务完成**\n- job_id：`{job.job_id}`")
        except asyncio.CancelledError:
            job.done = True
            job.error = "cancelled"
            raise
        except Exception as e:
            job.done = True
            job.error = str(e)
            err_text = f"===\n* **任务异常**\n- job_id：`{job.job_id}`\n- 错误：```text\n{type(e).__name__}: {e}\n```"
            self._emit_to_job(job, err_text)

    async def _list_sessions_raw(self):
        resp = await self.session_service.list_sessions(
            app_name=self.runner.app_name,
            user_id=self.user_id,
        )
        if hasattr(resp, "sessions"):
            return resp.sessions
        return resp or []

    async def show_sessions(self):
        sessions = await self._list_sessions_raw()

        if not sessions:
            self.render_output("当前没有 session。")
            return

        lines = ["===\n* **Session 列表**"]
        for s in sessions:
            sid = getattr(s, "session_id", None) or getattr(s, "id", None) or str(s)
            uid = getattr(s, "user_id", self.user_id)
            app = getattr(s, "app_name", self.app_name)
            lines.append(f"- session_id=`{sid}` | user=`{uid}` | app=`{app}`")
        self.render_output("\n".join(lines))

    async def delete_session(self, session_id: str):
        # 如果该 session 对应的 job 还在运行，先取消任务并从内存中移除
        for job_id, job in list(self.jobs.items()):
            if job.session_id == session_id:
                if job.task and not job.task.done():
                    job.task.cancel()
                if self.foreground_job_id == job_id:
                    self.foreground_job_id = None
                self.jobs.pop(job_id, None)
                break

        await self.session_service.delete_session(
            app_name=self.runner.app_name,
            user_id=self.user_id,
            session_id=session_id,
        )

        self.render_output(f"===\n* **已删除 Session**\n- session_id：`{session_id}`")

    async def delete_job(self, job_id: str):
        job = self.jobs.get(job_id)
        if not job:
            self.render_output(f"===\n* **错误**\n未找到 job：`{job_id}`")
            return

        if job.task and not job.task.done():
            job.task.cancel()

        await self.session_service.delete_session(
            app_name=self.runner.app_name,
            user_id=self.user_id,
            session_id=job.session_id,
        )

        if self.foreground_job_id == job_id:
            self.foreground_job_id = None

        self.jobs.pop(job_id, None)
        self.render_output(
            f"===\n* **已删除 Job 对应 Session**\n- job_id：`{job_id}`\n- session_id：`{job.session_id}`"
        )

    async def cancel_job(self, job_id: str):
        job = self.jobs.get(job_id)
        if not job:
            self.render_output(f"===\n* **错误**\n未找到 job：`{job_id}`")
            return

        if job.task and not job.task.done():
            job.task.cancel()
            self.render_output(f"===\n* **已取消任务**\n- job_id：`{job_id}`")
        else:
            self.render_output(f"===\n* **任务已结束**\n- job_id：`{job_id}`")

    def show_jobs(self):
        if not self.jobs:
            self.render_output("当前没有任务。")
            return

        lines = ["===\n* **任务列表**"]
        for jid, job in self.jobs.items():
            status = "done" if job.done else "running"
            if job.error == "cancelled":
                status = "cancelled"
            elif job.error:
                status = "error"
            fg = " ← 前台" if self.foreground_job_id == jid else ""
            lines.append(
                f"- `{jid}` | `{status}` | session=`{job.session_id}`{fg}"
            )
        self.render_output("\n".join(lines))

    async def bring_to_foreground(self, job_id: str):
        job = self.jobs.get(job_id)
        if not job:
            self.render_output(f"===\n* **错误**\n未找到 job：`{job_id}`")
            return

        self.foreground_job_id = job_id
        self.render_output(f"===\n* **切换前台**\n- 当前前台 job：`{job_id}`")

        # 重放历史输出
        if job.buffer:
            self.render_output(f"===\n* **历史输出重放**\n- job：`{job_id}`")
            for item in job.buffer:
                self.render_output(item)

    def send_to_background(self):
        self.foreground_job_id = None
        self.render_output("===\n* **已切回后台模式**")


async def run_main():
    agent_cmd_runner = AgentCMDRunner()
    agent_cmd_runner.print_banner()
    agent_cmd_runner.render_output(
        "输入自然语言即提交一个任务；\n"
        "`/jobs` 查看任务；`/sessions` 查看 session；\n"
        "`/fg <job_id>` 切前台；`/bg` 回后台；\n"
        "`/del <session_id>` 删除 session；`/deljob <job_id>` 删除 job 对应 session；\n"
        "`/cancel <job_id>` 取消任务；`exit` `bye` `quit` 退出。"
    )

    while True:
        try:
            # 不阻塞事件循环：后台任务可以继续并发跑
            input_text = await asyncio.to_thread(input, "\n> ")
            input_text = input_text.strip()

            if not input_text:
                continue

            if input_text.lower() in {"bye", "exit", "quit"}:
                break

            if input_text == "/jobs":
                agent_cmd_runner.show_jobs()
                continue

            if input_text == "/sessions":
                await agent_cmd_runner.show_sessions()
                continue

            if input_text.startswith("/fg "):
                job_id = input_text.split(maxsplit=1)[1].strip()
                await agent_cmd_runner.bring_to_foreground(job_id)
                continue

            if input_text == "/bg":
                agent_cmd_runner.send_to_background()
                continue

            if input_text.startswith("/deljob "):
                job_id = input_text.split(maxsplit=1)[1].strip()
                await agent_cmd_runner.delete_job(job_id)
                continue

            if input_text.startswith("/del "):
                session_id = input_text.split(maxsplit=1)[1].strip()
                await agent_cmd_runner.delete_session(session_id)
                continue

            if input_text.startswith("/cancel "):
                job_id = input_text.split(maxsplit=1)[1].strip()
                await agent_cmd_runner.cancel_job(job_id)
                continue

            job_id = await agent_cmd_runner.submit_job(input_text)
            await agent_cmd_runner.bring_to_foreground(job_id)
            agent_cmd_runner.render_output(f"===\n* **已提交任务**\n- job_id：`{job_id}`")
        except (EOFError, KeyboardInterrupt):
            print("\n已退出。")
            break


def main():
    asyncio.run(run_main())


if __name__ == "__main__":
    main()
