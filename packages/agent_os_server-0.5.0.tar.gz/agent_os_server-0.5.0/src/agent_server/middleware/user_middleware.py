import logging
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from fastapi import Request

from agent_server.utils import ServerConfig, Utils
from agent_server.services import Service


class UserMiddleware(BaseHTTPMiddleware):
    server_config: ServerConfig = Utils.load_envs(".server.env")
    service = Service.user_service(db_url=server_config.user_service_uri)

    async def dispatch(self, request: Request, call_next):
        # 1. 可选：定义路由白名单，用于跳过验证的端点
        # 例如，一个公开的 /health 端点，无需用户验证
        if request.url.path in [
            "/api/v1/health",
            "/docs", "/openapi.json"
        ]:
            return await call_next(request)

        # 2. 提取并验证用户ID
        user_id = request.headers.get("X-User-Id")
        if not user_id:
            logging.warning(f"Access Denied: You SHOULD provide X-User-Id first. from {request.client.host}")
            return Response("Unauthorized: Missing user identity identifier", status_code=401)

        if not UserMiddleware.service.verify(user_id):
            logging.warning(
                f"Access Denied: There is no user named '{user_id}' in whitelist. From {request.client.host}"
            )
            return Response(f"Access Denied: User '{user_id}' have no permission", status_code=403)

        # 3. 用户在白名单内，记录日志并继续处理请求
        logging.info(f"User '{user_id}' has passed verification in whitelist")
        return await call_next(request)
