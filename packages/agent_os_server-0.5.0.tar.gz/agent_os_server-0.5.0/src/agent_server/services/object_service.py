import logging
import io
import os
from typing import List
from pydantic import BaseModel
from datetime import timedelta
import mimetypes
from urllib.parse import urlparse, unquote
from fastapi import UploadFile

from minio import Minio
from minio.error import S3Error


class ObjectURI(BaseModel):
    database_type: str
    backend_type: str
    access_key: str
    secret_key: str
    endpoint: str
    bucket: str


class ObjectService(object):
    def __init__(self, uri: str, url_expires=3600):
        # URI格式 minio+minio://ak:sk@endpoint/bucket
        self.url_expires = url_expires
        self.object_uri = self.parse_uri(uri=uri)
        self.minio_client = Minio(
            endpoint=self.object_uri.endpoint,
            access_key=self.object_uri.access_key,
            secret_key=self.object_uri.secret_key,
            secure=False,
        )
        self.allow_mime_types = {
            'image/jpeg', 'image/png', 'image/gif',
            'image/webp', 'image/svg+xml', 'image/bmp',
            'image/x-icon', 'image/avif'
        }
        self._ensure_bucket_exists()

    @staticmethod
    def parse_uri(uri: str) -> ObjectURI | None:
        parsed = urlparse(uri)

        # scheme: minio+minio
        if "+" not in parsed.scheme:
            raise ValueError("URI scheme 格式错误，应类似 minio+minio://...")

        database_type, backend_type = parsed.scheme.split("+", 1)

        access_key = unquote(parsed.username or "")
        secret_key = unquote(parsed.password or "")

        host = parsed.hostname or ""
        port = parsed.port

        endpoint = f"{host}:{port}" if port else host

        # path: /agent-os
        bucket = parsed.path.lstrip("/")

        return ObjectURI(
            database_type=database_type,
            backend_type=backend_type,
            access_key=access_key,
            secret_key=secret_key,
            endpoint=endpoint,
            bucket=bucket,
        )

    def _ensure_bucket_exists(self):
        """确保存储桶存在，不存在则创建"""
        bucket_name = self.object_uri.bucket
        try:
            if not self.minio_client.bucket_exists(bucket_name):
                self.minio_client.make_bucket(bucket_name)
                logging.info("Bucket '%s' created successfully", bucket_name)
            else:
                logging.info("Bucket '%s' already exists", bucket_name)
        except S3Error as e:
            logging.error("Failed to ensure bucket exists: %s", e)
            raise

    def upload_file(self, file: UploadFile, user_token: str) -> dict:
        """
        上传文件到 MinIO

        :param file: 上传的文件
        :param user_token: 用户 token
        :return: 文件信息
        """
        bucket_name = self.object_uri.bucket
        original_filename = file.filename

        # 构建对象路径: {user_token}/{original_filename}
        object_name = f"{user_token}/{original_filename}"

        # 检测 MIME 类型
        content_type = file.content_type or mimetypes.guess_type(original_filename)[0] or "application/octet-stream"
        if content_type not in self.allow_mime_types:
            raise ValueError(f"Error mine {content_type}")

        try:
            # 读取文件内容（兼容 file.file 是 bytes 或文件对象的情况）
            if isinstance(file.file, bytes):
                file_content = file.file
            else:
                file_content = file.file.read()
            file_size = len(file_content)

            # 上传到 MinIO（put_object 需要文件对象，使用 io.BytesIO 包装 bytes）
            self.minio_client.put_object(
                bucket_name=bucket_name,
                object_name=object_name,
                data=io.BytesIO(file_content),
                length=file_size,
                content_type=content_type,
            )

            # 生成预签名下载 URL
            download_url = self.minio_client.presigned_get_object(
                bucket_name=bucket_name,
                object_name=object_name,
                expires=timedelta(seconds=self.url_expires),
            )

            logging.info("File uploaded successfully: %s", object_name)

            return {
                "file_id": object_name,
                "file_name": original_filename,
                "mime_type": content_type,
                "size": file_size,
                "download_url": download_url,
            }

        except S3Error as e:
            logging.error("Failed to upload file: %s", e)
            raise Exception(f"Upload failed: {str(e)}")

    def delete_file(self, file_name: str, user_token: str) -> bool:
        """
        删除 MinIO 中的文件

        :param file_name: 文件名
        :param user_token: 用户 token
        :return: 是否删除成功
        """
        bucket_name = self.object_uri.bucket
        object_name = f"{user_token}/{file_name}"

        try:
            self.minio_client.remove_object(bucket_name, object_name)
            logging.info("File deleted successfully: %s", object_name)
            return True
        except S3Error as e:
            logging.error("Failed to delete file: %s", e)
            raise Exception(f"Delete failed: {str(e)}")

    def list_files(self, user_token: str) -> List[dict]:
        """
        列出用户的所有文件

        :param user_token: 用户 token
        :return: 文件列表
        """
        bucket_name = self.object_uri.bucket
        prefix = f"{user_token}/"
        file_list = []

        try:
            objects = self.minio_client.list_objects(
                bucket_name=bucket_name,
                prefix=prefix,
                recursive=False,
            )

            for obj in objects:
                # 获取文件统计信息
                stat = self.minio_client.stat_object(bucket_name, obj.object_name)

                # 生成预签名下载 URL
                download_url = self.minio_client.presigned_get_object(
                    bucket_name=bucket_name,
                    object_name=obj.object_name,
                    expires=timedelta(seconds=self.url_expires),
                )

                file_list.append({
                    "file_id": obj.object_name,
                    "file_name": os.path.basename(obj.object_name),
                    "mime_type": stat.content_type,
                    "size": stat.size,
                    "download_url": download_url,
                })

            logging.info("Listed %d files for user: %s", len(file_list), user_token)
            return file_list

        except S3Error as e:
            logging.error("Failed to list files: %s", e)
            raise Exception(f"List files failed: {str(e)}")

    def get_file_info(self, file_name: str, user_token: str) -> dict:
        """
        获取文件信息

        :param file_name: 文件名
        :param user_token: 用户 token
        :return: 文件信息
        """
        bucket_name = self.object_uri.bucket
        object_name = f"{user_token}/{file_name}"

        try:
            stat = self.minio_client.stat_object(bucket_name, object_name)

            download_url = self.minio_client.presigned_get_object(
                bucket_name=bucket_name,
                object_name=object_name,
                expires=timedelta(seconds=self.url_expires),
            )

            return {
                "file_id": object_name,
                "file_name": file_name,
                "mime_type": stat.content_type,
                "size": stat.size,
                "download_url": download_url,
            }

        except S3Error as e:
            logging.error("Failed to get file info: %s", e)
            raise Exception(f"Get file info failed: {str(e)}")
