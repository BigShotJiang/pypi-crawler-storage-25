class UserService(object):
    def __init__(self, uri: str):
        self.uri = uri
        self.allow_users = {"alice", "bob"}

    def verify(self, user: str) -> bool:
        return user in self.allow_users

    def create_user(self, user: str, password: str) -> bool:
        pass