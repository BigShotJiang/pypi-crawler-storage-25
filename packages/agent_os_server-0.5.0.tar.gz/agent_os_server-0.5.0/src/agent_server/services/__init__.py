from google.adk.memory import InMemoryMemoryService, BaseMemoryService
from google.adk.sessions import DatabaseSessionService, InMemorySessionService, BaseSessionService
from google.adk.sessions import Session
import mlflow

from agent_server.services.object_service import ObjectService
from agent_server.services.user_service import UserService


class Service:
    @staticmethod
    def memory_service(db_uri: str) -> BaseMemoryService | None:
        """
        Memory服务
        """
        if db_uri is None:
            return None

        if db_uri == "":
            return InMemoryMemoryService()

        return InMemoryMemoryService()

    @staticmethod
    def object_service(db_url: str) -> ObjectService | None:
        if db_url is None or db_url == "":
            return None

        return ObjectService(uri=db_url)

    @staticmethod
    def user_service(db_url: str) -> UserService | None:
        return UserService(db_url)

    @staticmethod
    def session_service(db_url: str) -> BaseSessionService | None:
        """Session服务"""
        if db_url is None:
            return None

        if db_url == "":
            return InMemorySessionService()
        service = DatabaseSessionService(db_url=db_url)
        service.db_engine.sync_engine.pool._pre_ping = False
        return service

    @staticmethod
    def trace_service(trace_uri: str) -> bool:
        if (trace_uri is not None or trace_uri != "") and "@" in trace_uri:

            trace_elems = trace_uri.split("@")
            mlflow.set_tracking_uri(trace_elems[1])
            mlflow.set_experiment(trace_elems[0])
            mlflow.openai.autolog()
            return True

        return False

    @staticmethod
    async def ensure_session(
            session_service: BaseSessionService,
            app_name: str, user_id: str,
            session_id: str | None = None
    ) -> Session:
        if session_id:
            session = await session_service.get_session(
                app_name=app_name, user_id=user_id, session_id=session_id
            )
            if session:
                return session

            return await session_service.create_session(
                app_name=app_name, user_id=user_id, session_id=session_id,
                state={},
            )

        return await session_service.create_session(
            app_name=app_name, user_id=user_id, state={},
        )
