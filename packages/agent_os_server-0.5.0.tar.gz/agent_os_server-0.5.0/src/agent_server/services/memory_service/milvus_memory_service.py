# milvus_memory_service.py
from __future__ import annotations

import asyncio
import datetime as dt
import hashlib
import json
from typing import Any, Callable, Mapping, Sequence

from google.adk.sessions import Session
from pymilvus import DataType, MilvusClient
from google.genai import types
from google.adk.memory.base_memory_service import BaseMemoryService, SearchMemoryResponse
from google.adk.memory.memory_entry import MemoryEntry


class MilvusMemoryService(BaseMemoryService):
    def __init__(
            self, *,
            uri: str, token: str | None, collection_name: str, dim: int,
            embed_fn: Callable[[str], Sequence[float]], top_k: int = 5,
    ) -> None:
        self.client = MilvusClient(uri=uri, token=token)
        self.collection_name = collection_name
        self.dim = dim
        self.embed_fn = embed_fn
        self.top_k = top_k

        self._ensure_collection()

    @staticmethod
    def _flatten_text(obj: Any) -> str:
        """
        尽量把 ADK 的 event/content/session 结构压成纯文本。
        这里故意写得宽松一些，方便适配不同版本的 ADK 对象。
        """
        if obj is None:
            return ""
        if isinstance(obj, str):
            return obj.strip()
        if isinstance(obj, dict):
            parts = []
            for v in obj.values():
                t = MilvusMemoryService._flatten_text(v)
                if t:
                    parts.append(t)
            return "\n".join(parts).strip()
        if isinstance(obj, (list, tuple)):
            parts = []
            for item in obj:
                t = MilvusMemoryService._flatten_text(item)
                if t:
                    parts.append(t)
            return "\n".join(parts).strip()

        # 常见对象：content.parts / text / role / name / content
        for attr in ("text", "content", "parts"):
            if hasattr(obj, attr):
                val = getattr(obj, attr)
                t = MilvusMemoryService._flatten_text(val)
                if t:
                    return t

        return str(obj).strip()

    def _ensure_collection(self) -> None:
        if self.collection_name in self.client.list_collections():
            return

        schema = MilvusClient.create_schema(
            auto_id=False,
            enable_dynamic_field=False,
        )
        schema.add_field("id", DataType.VARCHAR, is_primary=True, max_length=128)
        schema.add_field("app_name", DataType.VARCHAR, max_length=128)
        schema.add_field("user_id", DataType.VARCHAR, max_length=128)
        schema.add_field("session_id", DataType.VARCHAR, max_length=128)
        schema.add_field("memory_type", DataType.VARCHAR, max_length=32)
        schema.add_field("content", DataType.VARCHAR, max_length=65535)
        schema.add_field("author", DataType.VARCHAR, max_length=128)
        schema.add_field("timestamp", DataType.VARCHAR, max_length=64)
        schema.add_field("custom_metadata", DataType.VARCHAR, max_length=65535)
        schema.add_field("vector", DataType.FLOAT_VECTOR, dim=self.dim)

        index_params = self.client.prepare_index_params()
        index_params.add_index(
            field_name="vector",
            index_type="AUTOINDEX",
            metric_type="COSINE",
        )

        # 标量字段如果你后面要高频过滤，也可以继续加索引；
        # 这里先保持最小可用。
        self.client.create_collection(
            collection_name=self.collection_name,
            schema=schema,
            index_params=index_params,
        )

    @staticmethod
    def _make_id(
            app_name: str, user_id: str, session_id: str, memory_type: str, content: str, extra: str = ""
    ) -> str:

        raw = f"{app_name}|{user_id}|{session_id}|{memory_type}|{content}|{extra}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

    async def _embed(self, text: str) -> list[float]:
        vec = await asyncio.to_thread(self.embed_fn, text)
        vec = list(vec)
        if len(vec) != self.dim:
            raise ValueError(f"embedding dim mismatch: got {len(vec)}, expect {self.dim}")
        return vec

    @staticmethod
    def _session_to_text_items(session: Any) -> list[dict[str, Any]]:
        """
        你可以按自己的 session/event 结构改这里。
        目标是把一段会话拆成若干条可检索记忆。
        """
        items: list[dict[str, Any]] = []

        session_id = getattr(session, "id", None) or getattr(session, "session_id", "") or ""
        app_name = getattr(session, "app_name", "") or ""
        user_id = getattr(session, "user_id", "") or ""
        events = getattr(session, "events", []) or []

        for idx, ev in enumerate(events):
            text = MilvusMemoryService._flatten_text(ev)
            if not text:
                continue

            author = getattr(ev, "author", "") or ""
            timestamp = getattr(ev, "timestamp", "") or ""
            custom_metadata = getattr(ev, "custom_metadata", None) or {}

            items.append(
                {
                    "id": MilvusMemoryService._make_id(
                        app_name, user_id, session_id, "event", text, str(idx)
                    ),
                    "app_name": app_name,
                    "user_id": user_id,
                    "session_id": session_id,
                    "memory_type": "event",
                    "content": text,
                    "author": author,
                    "timestamp": str(timestamp),
                    "custom_metadata": json.dumps(custom_metadata, ensure_ascii=False),
                }
            )

        return items

    async def add_session_to_memory(self, session: Session) -> None:
        rows = MilvusMemoryService._session_to_text_items(session)
        if not rows:
            return

        for row in rows:
            row["vector"] = await self._embed(row["content"])

        # 用 upsert 做幂等写入；同一 session 重复 ingest 时不会无限重复。
        await asyncio.to_thread(
            self.client.upsert,
            collection_name=self.collection_name,
            data=rows,
        )

    # async def add_events_to_memory(
    #         self, *, app_name: str, user_id: str, events: Sequence[Event], session_id: str | None = None,
    #         custom_metadata: Mapping[str, object] | None = None,
    # ) -> None:
    #     pass

    async def add_memory(self, *, app_name: str, user_id: str, memories: Sequence[MemoryEntry],
            custom_metadata: Mapping[str, object] | None = None,
    ) -> None:
        rows = []
        for idx, memory in enumerate(memories):
            content = MilvusMemoryService._flatten_text(getattr(memory, "content", memory))
            if not content:
                continue

            author = getattr(memory, "author", "") or ""
            timestamp = getattr(memory, "timestamp", "") or ""
            merged_metadata = dict(custom_metadata or {})
            mem_metadata = getattr(memory, "custom_metadata", None) or {}
            if isinstance(mem_metadata, Mapping):
                merged_metadata.update(mem_metadata)

            rows.append(
                {
                    "id": MilvusMemoryService._make_id(
                        app_name, user_id, "", "memory", content, str(idx)
                    ),
                    "app_name": app_name,
                    "user_id": user_id,
                    "session_id": "",
                    "memory_type": "manual",
                    "content": content,
                    "author": author,
                    "timestamp": str(timestamp),
                    "custom_metadata": json.dumps(merged_metadata, ensure_ascii=False),
                    "vector": await self._embed(content),
                }
            )

        if not rows:
            return

        await asyncio.to_thread(
            self.client.upsert,
            collection_name=self.collection_name,
            data=rows,
        )

    async def search_memory(self, *, app_name: str, user_id: str, query: str) -> SearchMemoryResponse:
        query_vec = await self._embed(query)

        # Milvus 支持按标量字段过滤后再做 ANN 搜索。
        # 这里用 app_name / user_id 做租户隔离，避免不同用户互相串记忆。
        expr = f'app_name == "{app_name}" and user_id == "{user_id}"'

        res = await asyncio.to_thread(
            self.client.search,
            collection_name=self.collection_name,
            anns_field="vector",
            data=[query_vec],
            limit=self.top_k,
            filter=expr,
            output_fields=[
                "id",
                "app_name",
                "user_id",
                "session_id",
                "memory_type",
                "content",
                "author",
                "timestamp",
                "custom_metadata",
            ],
            search_params={"metric_type": "COSINE"},
        )

        memories: list[MemoryEntry] = []
        for hits in res:
            for hit in hits:
                entity = hit.get("entity", hit) if isinstance(hit, dict) else hit
                content = entity.get("content", "") if isinstance(entity, dict) else str(entity)

                memories.append(
                    MemoryEntry(
                        content=types.Content(role="", parts=[types.Part(text=content)]),
                        author=entity.get("author", "") if isinstance(entity, dict) else "",
                        timestamp=entity.get("timestamp", "") if isinstance(entity, dict) else "",
                        custom_metadata={
                            "id": entity.get("id", "") if isinstance(entity, dict) else "",
                            "app_name": app_name,
                            "user_id": user_id,
                            "session_id": entity.get("session_id", "") if isinstance(entity, dict) else "",
                            "memory_type": entity.get("memory_type", "") if isinstance(entity, dict) else "",
                        },
                    )
                )

        return SearchMemoryResponse(memories=memories)
