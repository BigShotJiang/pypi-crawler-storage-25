from pydantic import BaseModel, Field
from typing import Any, List
from dotenv import dotenv_values


class ServerConfig(BaseModel):
    # 智能体配置文件夹
    agents_path: str

    # session服务URI
    session_service_uri: str

    # memory服务URI
    memory_service_uri: str

    # 用户服务URI
    user_service_uri: str

    # object服务URI
    object_service_uri: str

    # trace service URI
    trace_service_uri: str

    # host
    host: str

    # port
    port: int

    # 异步 chat 任务最大并发数；不同 session 可并发，同一个 user + session 默认串行。
    async_chat_max_concurrency: int = 4

    # 每个异步任务最多在内存中保留多少条输出事件，避免长任务无限占用内存。
    async_chat_max_task_events: int = 2000


class RequestContent(BaseModel):
    data: Any = ""
    mine_type: str = ""

class ChatRequest(BaseModel):
    type: str = "adk"
    session_id: str
    message: str
    attachments: List[RequestContent] = []


class AsyncChatRequest(BaseModel):
    type: str = "adk"
    # 必须传已有 session_id；异步任务接口不会自动创建 session。
    session_id: str
    message: str
    attachments: List[RequestContent] = []


class AsyncChatTaskEventQuery(BaseModel):
    after_index: int = Field(default=0, ge=0)
    limit: int = Field(default=100, ge=1, le=1000)


class Utils:
    @staticmethod
    def safe_jsonable(value):
        if value is None:
            return None

        if hasattr(value, "model_dump"):
            try:
                return value.model_dump(mode="json")
            except Exception:
                pass

        if hasattr(value, "dict"):
            try:
                return value.dict()
            except Exception:
                pass

        if isinstance(value, (str, int, float, bool, list, dict)):
            return value

        return str(value)

    @staticmethod
    def load_envs(env_file: str) -> ServerConfig | None:
        config = dotenv_values(env_file)
        return ServerConfig(
            agents_path=config.get("AGENTS_PATH", ""),
            session_service_uri=config.get("SESSION_SERVICE_URI", ""),
            memory_service_uri=config.get("MEMORY_SERVICE_URI", ""),
            user_service_uri=config.get("USER_SERVICE_URI", ""),
            object_service_uri=config.get("OBJECT_SERVICE_URI", ""),
            trace_service_uri=config.get("TRACE_SERVICE_URI", ""),
            host=config.get("HOST", "0.0.0.0"),
            port=int(config.get("PORT", "8000")),
            async_chat_max_concurrency=int(config.get("ASYNC_CHAT_MAX_CONCURRENCY", "4")),
            async_chat_max_task_events=int(config.get("ASYNC_CHAT_MAX_TASK_EVENTS", "2000")),
        )
