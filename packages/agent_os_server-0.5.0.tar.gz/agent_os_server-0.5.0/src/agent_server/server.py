import asyncio
import json
import sys
import uuid
from datetime import datetime, timezone
import uvicorn
import logging
from fastapi.responses import StreamingResponse
from fastapi import FastAPI, Request, Response, Query, UploadFile, File, Header

from agent_server.utils import Utils, ServerConfig, ChatRequest, AsyncChatRequest
from agent_server.services import Service
from agent_server.agent_runner import AgentRunner
from agent_server.middleware.user_middleware import UserMiddleware


class Application:
    server_config: ServerConfig = Utils.load_envs(".server.env")
    if Service.trace_service(server_config.trace_service_uri):
        logging.info(f"Mlflow trace is ready {server_config.trace_service_uri}")

    runner = AgentRunner(
        agents_path=server_config.agents_path,
        session_service_uri=server_config.session_service_uri,
        memory_service_uri=server_config.memory_service_uri,
        object_service_uri=server_config.object_service_uri
    )

    api = FastAPI(title=f"{runner.agent_name} Server")
    # api.add_middleware(UserWhitelistMiddleware)
    api.add_middleware(UserMiddleware)

    # 新增异步任务能力：每次请求只提交一个任务，但任务在后台执行。
    # 注意：这是进程内任务表，服务重启后任务记录会丢失；如果需要跨进程/重启保留，可再接 Redis/MySQL。
    _async_chat_tasks: dict[str, dict] = {}
    _async_chat_task_handles: dict[str, asyncio.Task] = {}
    _async_chat_tasks_guard = asyncio.Lock()
    _async_chat_semaphore = asyncio.Semaphore(server_config.async_chat_max_concurrency)

    # 同一个 user + session 的 run 默认串行，避免并发写同一个 session 导致状态/事件顺序错乱。
    # 不同 session 的任务会按 ASYNC_CHAT_MAX_CONCURRENCY 并发执行。
    _session_run_locks: dict[tuple[str, str], asyncio.Lock] = {}
    _session_run_locks_guard = asyncio.Lock()

    @staticmethod
    def _utc_now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    async def _get_session_run_lock(user_id: str, session_id: str) -> asyncio.Lock:
        lock_key = (user_id, session_id)
        async with Application._session_run_locks_guard:
            lock = Application._session_run_locks.get(lock_key)
            if lock is None:
                lock = asyncio.Lock()
                Application._session_run_locks[lock_key] = lock
            return lock

    @staticmethod
    def _task_public_meta(record: dict) -> dict:
        return {
            "task_id": record["task_id"],
            "user_id": record["user_id"],
            "session_id": record["session_id"],
            "status": record["status"],
            "type": record["type"],
            "created_at": record["created_at"],
            "updated_at": record["updated_at"],
            "started_at": record.get("started_at"),
            "finished_at": record.get("finished_at"),
            "event_count": record.get("event_count", 0),
            "dropped_event_count": record.get("dropped_event_count", 0),
            "error": record.get("error"),
        }

    @staticmethod
    async def _get_owned_task_record(task_id: str, user_id: str) -> dict | None:
        async with Application._async_chat_tasks_guard:
            record = Application._async_chat_tasks.get(task_id)
            if record is None or record.get("user_id") != user_id:
                return None
            return record

    @staticmethod
    async def _update_async_chat_task(task_id: str, **updates):
        async with Application._async_chat_tasks_guard:
            record = Application._async_chat_tasks.get(task_id)
            if record is None:
                return
            record.update(updates)
            record["updated_at"] = Application._utc_now()

    @staticmethod
    async def _append_async_chat_task_event(task_id: str, event):
        safe_event = Utils.safe_jsonable(event)
        async with Application._async_chat_tasks_guard:
            record = Application._async_chat_tasks.get(task_id)
            if record is None:
                return

            event_index = record.get("event_count", 0)
            record.setdefault("events", []).append({
                "index": event_index,
                "created_at": Application._utc_now(),
                "data": safe_event,
            })
            record["event_count"] = event_index + 1

            max_events = max(1, Application.server_config.async_chat_max_task_events)
            overflow = len(record["events"]) - max_events
            if overflow > 0:
                del record["events"][:overflow]
                record["dropped_event_count"] = record.get("dropped_event_count", 0) + overflow

            record["updated_at"] = Application._utc_now()

    @staticmethod
    async def _run_async_chat_task(task_id: str, user_id: str, chat_request: ChatRequest):
        try:
            await Application._update_async_chat_task(task_id, status="queued")
            async with Application._async_chat_semaphore:
                await Application._update_async_chat_task(
                    task_id,
                    status="running",
                    started_at=Application._utc_now(),
                )

                session_lock = await Application._get_session_run_lock(user_id, chat_request.session_id)
                async with session_lock:
                    async for event in Application.runner.run(user_id=user_id, request=chat_request):
                        await Application._append_async_chat_task_event(task_id, event)

            await Application._update_async_chat_task(
                task_id,
                status="completed",
                finished_at=Application._utc_now(),
            )
        except asyncio.CancelledError:
            await Application._update_async_chat_task(
                task_id,
                status="cancelled",
                finished_at=Application._utc_now(),
            )
            raise
        except Exception as e:
            logging.exception(f"async chat task failed task_id={task_id} session_id={chat_request.session_id}: {e}")
            await Application._update_async_chat_task(
                task_id,
                status="failed",
                finished_at=Application._utc_now(),
                error=f"{type(e).__name__}: {e}",
            )

    @staticmethod
    @api.get("/api/v1/reload", tags=["API"])
    async def reload():
        try:
            Application.runner = AgentRunner(
                agents_path=Application.server_config.agents_path,
                session_service_uri=Application.server_config.session_service_uri,
                memory_service_uri=Application.server_config.memory_service_uri
            )
        except Exception:
            logging.error("Failed to load agents")
            return {"code": 10000, "message": "Failed to load agents", "data": ""}

        return {"code": 0, "message": "", "data": "OK"}

    @staticmethod
    @api.get("/api/v1/session/create", tags=["API Session"])
    async def create_session(request: Request):
        try:
            user_id = request.headers.get("X-User-Id")
            session = await Service.ensure_session(
                session_service=Application.runner.session_service,
                app_name=Application.runner.app_name,
                user_id=user_id, session_id=None
            )
            return {"code": 0, "message": "", "data": {"user_id": user_id, "session_id": session.id}}

        except Exception as e:
            logging.exception(f"create_session failed {e}")
            return {"code": 10001, "message": "create_session failed", "data": ""}

    @staticmethod
    @api.get("/api/v1/health", tags=["API"])
    async def health_check():
        return {"code": 0, "message": "", "data": "OK"}

    @staticmethod
    @api.post("/api/v1/chat/completions", tags=["API Sync Chat"])
    async def chat_completion(request: Request):
        """"""
        user_id = request.headers.get("X-User-Id")
        data = ChatRequest.model_validate_json(await request.body())

        async def event_generator():
            async for event in Application.runner.run(user_id=user_id, request=data):
                yield json.dumps(Utils.safe_jsonable(event), ensure_ascii=False) + "\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    @staticmethod
    @api.post("/api/v1/chat/completions/task/create", tags=["API Async Chat"])
    async def create_async_chat_completion_task(request: Request):
        """
        新增路由：一次只提交一个 chat/completions 任务，服务端后台异步执行。

        这个接口不会自动创建 session，必须传已有 session_id。
        如果 session 不存在，直接返回 Session not found。
        原 /api/v1/chat/completions 路由不变。
        """
        user_id = request.headers.get("X-User-Id")
        try:
            data = AsyncChatRequest.model_validate_json(await request.body())

            session = await Application.runner.session_service.get_session(
                app_name=Application.runner.app_name,
                user_id=user_id,
                session_id=data.session_id,
            )
            if not session:
                return {"code": 10002, "message": "Session not found", "data": ""}

            chat_request = ChatRequest(
                type=data.type,
                session_id=data.session_id,
                message=data.message,
            )

            task_id = uuid.uuid4().hex
            now = Application._utc_now()
            record = {
                "task_id": task_id,
                "user_id": user_id,
                "session_id": data.session_id,
                "type": data.type,
                "message": data.message,
                "status": "pending",
                "created_at": now,
                "updated_at": now,
                "started_at": None,
                "finished_at": None,
                "event_count": 0,
                "dropped_event_count": 0,
                "error": None,
                "events": [],
            }

            async with Application._async_chat_tasks_guard:
                Application._async_chat_tasks[task_id] = record
                Application._async_chat_task_handles[task_id] = asyncio.create_task(
                    Application._run_async_chat_task(task_id, user_id, chat_request)
                )

            return {
                "code": 0,
                "message": "",
                "data": {
                    "task_id": task_id,
                    "session_id": data.session_id,
                    "status": "pending",
                },
            }

        except Exception as e:
            logging.exception(f"create async chat task failed {e}")
            return {"code": 10004, "message": "create async chat task failed", "data": ""}

    @staticmethod
    @api.get("/api/v1/chat/completions/task/list", tags=["API Async Chat"])
    async def list_async_chat_completion_tasks(
            request: Request,
            limit: int = Query(default=50, ge=1, le=500),
            status: str | None = Query(default=None),
    ):
        """
        新增路由：查看当前用户在本服务进程内的异步任务概览。

        返回任务总数、各状态数量，以及任务 ID/运行状态等摘要。
        注意：任务表是进程内内存数据；服务重启、多 worker、多实例时不会共享。
        """
        user_id = request.headers.get("X-User-Id")
        async with Application._async_chat_tasks_guard:
            owned_records = [
                record
                for record in Application._async_chat_tasks.values()
                if record.get("user_id") == user_id
            ]

            status_counts = {}
            for record in owned_records:
                record_status = record.get("status", "unknown")
                status_counts[record_status] = status_counts.get(record_status, 0) + 1

            filtered_records = [
                Application._task_public_meta(record)
                for record in owned_records
                if status is None or record.get("status") == status
            ]

        filtered_records.sort(key=lambda item: item["created_at"], reverse=True)
        tasks = filtered_records[:limit]
        return {
            "code": 0,
            "message": "",
            "data": {
                "total": len(owned_records),
                "filtered_total": len(filtered_records),
                "returned_count": len(tasks),
                "status_counts": status_counts,
                "tasks": tasks,
            },
        }

    @staticmethod
    @api.get("/api/v1/chat/completions/task/info", tags=["API Async Chat"])
    async def get_async_chat_completion_task(request: Request, task_id: str):
        """新增路由：查看单个异步任务状态，不返回完整事件列表。"""
        user_id = request.headers.get("X-User-Id")
        record = await Application._get_owned_task_record(task_id, user_id)
        if record is None:
            return {"code": 10005, "message": "task not found", "data": ""}

        return {"code": 0, "message": "", "data": Application._task_public_meta(record)}

    @staticmethod
    @api.get("/api/v1/chat/completions/task/events", tags=["API Async Chat"])
    async def get_async_chat_completion_task_events(
            request: Request,
            task_id: str,
            after_index: int = Query(default=0, ge=0),
            limit: int = Query(default=100, ge=1, le=1000),
    ):
        """
        新增路由：按任务维度增量读取后台任务输出。

        这里读取的是异步任务执行过程中收集到的输出，不修改、不读取原 session event 接口。
        客户端首次传 after_index=0；之后把返回的 next_after_index 带回来继续轮询。
        """
        user_id = request.headers.get("X-User-Id")
        record = await Application._get_owned_task_record(task_id, user_id)
        if record is None:
            return {"code": 10005, "message": "task not found", "data": ""}

        async with Application._async_chat_tasks_guard:
            current = Application._async_chat_tasks.get(task_id)
            if current is None or current.get("user_id") != user_id:
                return {"code": 10005, "message": "task not found", "data": ""}

            available_events = list(current.get("events", []))
            first_available_index = available_events[0]["index"] if available_events else current.get("event_count", 0)
            sliced_events = [event for event in available_events if event.get("index", -1) >= after_index][:limit]
            if sliced_events:
                next_after_index = sliced_events[-1]["index"] + 1
            else:
                next_after_index = after_index

            has_more = any(event.get("index", -1) >= next_after_index for event in available_events)
            missed_event_count = max(0, first_available_index - after_index)
            data = {
                "task_id": task_id,
                "session_id": current["session_id"],
                "status": current["status"],
                "events": sliced_events,
                "next_after_index": next_after_index,
                "has_more": has_more,
                "event_count": current.get("event_count", 0),
                "first_available_index": first_available_index,
                "dropped_event_count": current.get("dropped_event_count", 0),
                "missed_event_count": missed_event_count,
                "error": current.get("error"),
            }

        return {"code": 0, "message": "", "data": data}

    @staticmethod
    @api.delete("/api/v1/chat/completions/task/delete", tags=["API Async Chat"])
    async def delete_async_chat_completion_task(request: Request, task_id: str):
        """
        新增路由：删除当前用户的异步任务记录。

        - 如果任务还在 pending/queued/running/cancelling，会先 cancel 后删除。
        - 删除后，该 task 的状态和内存事件输出都会被移除，再查询会返回 task not found。
        - 这个删除只影响新增异步任务内存表，不删除 session，也不删除 session events。
        """
        user_id = request.headers.get("X-User-Id")
        async with Application._async_chat_tasks_guard:
            record = Application._async_chat_tasks.get(task_id)
            if record is None or record.get("user_id") != user_id:
                return {"code": 10005, "message": "task not found", "data": ""}

            previous_status = record.get("status")
            handle = Application._async_chat_task_handles.pop(task_id, None)
            Application._async_chat_tasks.pop(task_id, None)

            if handle is not None and not handle.done():
                handle.cancel()

        return {
            "code": 0,
            "message": "",
            "data": {
                "task_id": task_id,
                "deleted": True,
                "previous_status": previous_status,
            },
        }

    @staticmethod
    @api.post("/api/v1/file/upload", tags=["Files"])
    async def upload(file: UploadFile = File(...), request: Request = None):
        """
        文件上传接口<br/>
        :param file: 上传的文件<br/>
        :param request: 完整的请求信息<br/>
        :return: 文件信息（包含 mime_type 和 download_url）<br/>
        """
        logging.info(
            "Got request from Request-Source-Ip: %s",
            request.url.hostname if request else "unknown"
        )
        user_id = request.headers.get("X-User-Id")

        # 检查用户 token
        if not user_id:
            return {
                "code": 30001,
                "message": "User token is required",
                "data": {},
            }

        try:
            return {
                "code": 0,
                "message": "Upload successful",
                "data": Application.runner.object_service.upload_file(file, user_id),
            }
        except ValueError as e:
            logging.error("Unsupported MIME")
            return {
                "code": 30007,
                "message": "Unsupported MIME",
                "data": {},
            }
        except Exception as e:
            logging.error("Upload failed: %s", str(e))
            return {
                "code": 30003,
                "message": "Upload failed",
                "data": {},
            }

    @staticmethod
    @api.delete("/api/v1/file/delete", tags=["Files"])
    async def delete(file_name: str = Query(..., description="要删除的文件名"), request: Request = None):
        """
        文件删除接口<br/>
        :param file_name: 文件名<br/>
        :param request: 完整的请求信息<br/>
        :return: 删除结果<br/>
        """
        logging.info("Got request from Request-Source-Ip: %s",request.url.hostname if request else "unknown")
        user_id = request.headers.get("X-User-Id")

        # 检查用户 token
        if not user_id:
            return {
                "code": 30001,
                "message": "User token is required",
                "data": {},
            }

        try:
            return {
                "code": 0,
                "message": "Delete successful",
                "data": Application.runner.object_service.delete_file(file_name=file_name, user_token=user_id),
            }
        except Exception as e:
            logging.error("Delete failed: %s", str(e))
            return {
                "code": 30004,
                "message": "Delete failed",
                "data": {},
            }

    @staticmethod
    @api.get("/api/v1/file/list", tags=["Files"])
    async def list_files(request: Request = None):
        """
        列出用户文件接口<br/>
        :param request: 完整的请求信息<br/>
        :return: 文件列表<br/>
        """
        logging.info("Got request from Request-Source-Ip: %s",request.url.hostname if request else "unknown")
        user_id = request.headers.get("X-User-Id")

        # 检查用户 token
        if not user_id:
            return {
                "code": 30001,
                "message": "User token is required",
                "data": {},
            }

        try:
            return {
                "code": 0,
                "message": "Delete successful",
                "data": Application.runner.object_service.list_files(user_token=user_id),
            }
        except Exception as e:
            logging.error("List files failed: %s", str(e))
            return {
                "code": 30000,
                "message": "File service error",
                "data": {},
            }

    @staticmethod
    @api.get("/api/v1/file/info", tags=["Files"])
    async def get_file_info(file_name: str = Query(..., description="文件名"), request: Request = None):
        """
        获取文件信息接口<br/>
        :param file_name: 文件名<br/>
        :param request: 完整的请求信息<br/>
        :return: 文件信息（包含 mime_type 和 download_url）<br/>
        """
        logging.info("Got request from Request-Source-Ip: %s",request.url.hostname if request else "unknown")
        user_id = request.headers.get("X-User-Id")

        # 检查用户 token
        if not user_id:
            return {
                "code": 30001,
                "message": "User token is required",
                "data": {},
            }

        try:
            return {
                "code": 0,
                "message": "Get file info successful",
                "data": Application.runner.object_service.get_file_info(file_name=file_name, user_token=user_id),
            }
        except Exception as e:
            logging.error("Get file info failed: %s", str(e))
            return {
                "code": 30002,
                "message": "File not found",
                "data": {},
            }


def main():
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
        stream=sys.stderr
    )
    uvicorn.run(Application.api, host=Application.server_config.host, port=Application.server_config.port)


if __name__ == '__main__':
    main()
