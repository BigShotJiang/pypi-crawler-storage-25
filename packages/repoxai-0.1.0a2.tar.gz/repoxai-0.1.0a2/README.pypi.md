# Repox
[![GitHub Repo](https://img.shields.io/badge/GitHub-kmandana%2FRepoX-24292F?logo=github)](https://github.com/kmandana/RepoX)
[![Release](https://img.shields.io/github/v/release/kmandana/RepoX?label=Release)](https://github.com/kmandana/RepoX/releases)

The repo index that makes coding agents smart.

Repox scans any codebase and builds a persistent intelligence profile - 13 extraction dimensions covering everything from tech stack and architecture to auth flows, state machines, and security posture. Instead of starting from zero, your coding agent gets institutional knowledge so generated code fits the project like a senior wrote it.

## Installation

**With [uv](https://docs.astral.sh/uv/) (recommended):**

```bash
uv tool install repoxai
```

**With pip:**

```bash
pip install repoxai
```

Requires Python 3.12+.

## Quick Start

```bash
# Set up LLM (needed for scan + context)
export ANTHROPIC_API_KEY=sk-...   # or OPENAI_API_KEY or GEMINI_API_KEY

# Scan a repo
repox scan /path/to/repo

# View full profile (no LLM needed)
repox show

# Get a task-specific advisory brief
repox context "Fix the login bug in auth.py" --target-files src/auth.py
```

## What It Extracts

| # | Dimension | What it captures |
|---|-----------|-----------------|
| 1 | Tech Stack | Language, framework, package manager, test runner, dependencies |
| 2 | Architecture | Pattern detection (layered, DDD, MVC, hexagonal, flat, etc.) |
| 3 | Symbols | Full AST symbol graph - functions, classes, methods, constants |
| 4 | Dependencies | Import graph, call graph, PageRank-based file importance |
| 5 | API Surface | HTTP endpoints, MCP tools, Celery tasks, WebSocket events |
| 6 | Data Models | ORM entities, Pydantic models, Prisma schemas, field definitions |
| 7 | Design Patterns | Factory, Builder, Observer, Repository, Middleware, Strategy |
| 8 | Infrastructure | Docker services, env vars, deployment targets, external integrations |
| 9 | Conventions | Naming, error handling, async patterns, import style, type hints |
| 10 | Test Patterns | Framework, file naming, fixtures, mocking, assertion style |
| 11 | Hotspots | Churn-complexity analysis, temporal coupling, knowledge islands |
| 12 | Custom Rules | Team conventions from CLAUDE.md, .cursorrules, AGENTS.md, etc. |
| 13 | Behavioral | Auth flows, state machines, middleware chains, background jobs, API contracts |

Plus **LLM Interpretation** (architecture insights, convention synthesis) and **Security Posture** (auth defaults, input validation, SQL safety, CORS, secret management).

## Agent Integration

Add to your agent's rules file (CLAUDE.md, .cursorrules, AGENTS.md):

```
Before starting any task, run `repox show` to understand the codebase structure, conventions, and patterns. Use this context to write code that fits the project.
```

## Links

- Full documentation: https://github.com/kmandana/RepoX
- Issues: https://github.com/kmandana/RepoX/issues
- Releases: https://github.com/kmandana/RepoX/releases
