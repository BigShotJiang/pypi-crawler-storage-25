"""Tests for the main scanner orchestration."""

from pathlib import Path

from repox.models import ArchPattern
from repox.persistence import load_profile_json
from repox.scanner import collect_source_files, scan


class TestCollectSourceFiles:
    def test_finds_python_files(self, layered_repo: Path):
        files = collect_source_files(layered_repo)
        file_names = [f.name for f in files]
        assert "pyproject.toml" in file_names

    def test_finds_config_files(self, python_repo: Path):
        files = collect_source_files(python_repo)
        file_names = [f.name for f in files]
        assert "pyproject.toml" in file_names

    def test_skips_venv(self, tmp_path: Path):
        venv = tmp_path / ".venv" / "lib"
        venv.mkdir(parents=True)
        (venv / "stuff.py").touch()
        (tmp_path / "main.py").touch()

        files = collect_source_files(tmp_path)
        assert all(".venv" not in str(f) for f in files)

    def test_skips_node_modules(self, tmp_path: Path):
        nm = tmp_path / "node_modules" / "express"
        nm.mkdir(parents=True)
        (nm / "index.js").touch()
        (tmp_path / "app.js").touch()

        files = collect_source_files(tmp_path)
        assert all("node_modules" not in f.relative_to(tmp_path).parts for f in files)


class TestScan:
    def test_full_scan_python(self, python_repo: Path):
        profile = scan(python_repo, force=True)
        assert profile.repo_name == python_repo.name
        assert profile.tech_stack.primary_language == "Python"
        assert profile.tech_stack.framework == "FastAPI"

    def test_saves_profile_files(self, python_repo: Path):
        scan(python_repo, force=True)
        repox_dir = python_repo / ".repox"
        assert repox_dir.is_dir()
        assert (repox_dir / "profile.json").exists()
        assert (repox_dir / "profile.md").exists()
        assert (repox_dir / "hashes.json").exists()

    def test_incremental_scan(self, python_repo: Path):
        # First scan
        profile1 = scan(python_repo)
        ts1 = profile1.last_scanned

        # Second scan without changes — should be fast and return existing
        profile2 = scan(python_repo)
        assert profile2.tech_stack.primary_language == "Python"

    def test_force_scan_ignores_cache(self, python_repo: Path):
        scan(python_repo)
        profile = scan(python_repo, force=True)
        assert profile.tech_stack.primary_language == "Python"

    def test_scan_with_architecture(self, layered_repo: Path):
        profile = scan(layered_repo, force=True)
        assert profile.architecture.pattern == ArchPattern.LAYERED

    def test_scan_with_custom_rules(self, rules_repo: Path):
        profile = scan(rules_repo, force=True)
        assert len(profile.custom_rules.rules) > 0

    def test_profile_persisted_and_loadable(self, python_repo: Path):
        scan(python_repo, force=True)
        loaded = load_profile_json(python_repo)
        assert loaded is not None
        assert loaded.tech_stack.primary_language == "Python"
