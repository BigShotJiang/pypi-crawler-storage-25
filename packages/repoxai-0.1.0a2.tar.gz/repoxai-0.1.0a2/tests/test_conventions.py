"""Tests for coding conventions + test patterns extraction."""

from __future__ import annotations

from pathlib import Path

from repox.extractors.conventions import extract_conventions, extract_test_patterns
from repox.extractors.symbols import extract_symbols


class TestNamingConventions:
    def test_detects_snake_case(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("""\
def get_user(): pass
def create_order(): pass
def process_payment(): pass
def validate_input(): pass
""")
        sym = extract_symbols(tmp_path, [tmp_path / "app.py"])
        conv = extract_conventions(tmp_path, [tmp_path / "app.py"], sym)

        naming = [c for c in conv.conventions if c.category == "naming" and "snake_case" in c.rule]
        assert len(naming) == 1
        assert naming[0].confidence >= 0.9

    def test_detects_pascal_case_classes(self, tmp_path: Path):
        (tmp_path / "models.py").write_text("""\
class UserProfile: pass
class OrderItem: pass
class PaymentService: pass
""")
        sym = extract_symbols(tmp_path, [tmp_path / "models.py"])
        conv = extract_conventions(tmp_path, [tmp_path / "models.py"], sym)

        pascal = [c for c in conv.conventions if c.category == "naming" and "PascalCase" in c.rule]
        assert len(pascal) == 1

    def test_detects_upper_case_constants(self, tmp_path: Path):
        (tmp_path / "config.py").write_text("""\
MAX_RETRIES = 3
TIMEOUT = 30
API_KEY = "secret"
""")
        sym = extract_symbols(tmp_path, [tmp_path / "config.py"])
        conv = extract_conventions(tmp_path, [tmp_path / "config.py"], sym)

        upper = [c for c in conv.conventions if c.category == "naming" and "UPPER" in c.rule]
        assert len(upper) == 1


class TestTypeHintConventions:
    def test_detects_high_type_coverage(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("""\
def get_user(user_id: int) -> str: pass
def create_order(items: list) -> dict: pass
def process(data: bytes) -> None: pass
""")
        sym = extract_symbols(tmp_path, [tmp_path / "app.py"])
        conv = extract_conventions(tmp_path, [tmp_path / "app.py"], sym)

        type_conv = [c for c in conv.conventions if c.category == "types"]
        assert len(type_conv) == 1
        assert type_conv[0].confidence >= 0.9


class TestAsyncConventions:
    def test_detects_async_heavy(self, tmp_path: Path):
        (tmp_path / "service.py").write_text("""\
async def fetch(): pass
async def save(): pass
async def process(): pass
def helper(): pass
""")
        sym = extract_symbols(tmp_path, [tmp_path / "service.py"])
        conv = extract_conventions(tmp_path, [tmp_path / "service.py"], sym)

        async_conv = [c for c in conv.conventions if c.category == "async"]
        assert len(async_conv) >= 1
        assert any("async" in c.rule.lower() for c in async_conv)


class TestDocstringConventions:
    def test_detects_documentation_level(self, tmp_path: Path):
        (tmp_path / "app.py").write_text('''\
def well_documented():
    """This function is well documented."""
    pass

def also_documented():
    """Another documented function."""
    pass

def no_docs():
    pass
''')
        sym = extract_symbols(tmp_path, [tmp_path / "app.py"])
        conv = extract_conventions(tmp_path, [tmp_path / "app.py"], sym)

        doc_conv = [c for c in conv.conventions if c.category == "documentation"]
        assert len(doc_conv) == 1


class TestImportConventions:
    def test_detects_future_annotations(self, tmp_path: Path):
        for i in range(5):
            (tmp_path / f"mod{i}.py").write_text("from __future__ import annotations\n\ndef func(): pass\n")
        files = [tmp_path / f"mod{i}.py" for i in range(5)]
        sym = extract_symbols(tmp_path, files)
        conv = extract_conventions(tmp_path, files, sym)

        import_conv = [c for c in conv.conventions if c.category == "imports"]
        assert len(import_conv) == 1
        assert "__future__" in import_conv[0].rule


class TestTestPatterns:
    def test_detects_pytest(self, tmp_path: Path):
        tests_dir = tmp_path / "tests"
        tests_dir.mkdir()
        (tests_dir / "test_app.py").write_text("""\
import pytest

@pytest.fixture
def client():
    return TestClient()

def test_create_user(client):
    assert client.post("/users").status_code == 200

def test_delete_user(client):
    assert client.delete("/users/1").status_code == 204
""")
        files = [tests_dir / "test_app.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_test_patterns(tmp_path, files, sym)

        assert patterns.framework == "pytest"
        assert patterns.test_file_count == 1
        assert patterns.test_count >= 2
        assert patterns.file_pattern == "test_*.py"
        assert patterns.fixture_approach == "pytest fixtures"
        assert patterns.assertion_style == "assert"

    def test_detects_test_naming(self, tmp_path: Path):
        (tmp_path / "test_users.py").write_text("""\
def test_create_user_success(): pass
def test_create_user_invalid_email(): pass
def test_delete_user_not_found(): pass
""")
        files = [tmp_path / "test_users.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_test_patterns(tmp_path, files, sym)

        assert patterns.naming_convention == "test_{method}_{scenario}"

    def test_empty_repo(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("def main(): pass")
        files = [tmp_path / "app.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_test_patterns(tmp_path, files, sym)

        assert patterns.test_file_count == 0
        assert patterns.framework is None
