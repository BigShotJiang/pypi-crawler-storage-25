"""Tests for JSON/MD persistence layer."""

from pathlib import Path

from repox.models import (
    ArchitectureMap,
    ArchPattern,
    CustomRule,
    CustomRules,
    Dependency,
    DirectoryLabel,
    RepoProfile,
    RuleSource,
    TechStack,
)
from repox.persistence import (
    compute_file_hash,
    get_changed_files,
    load_hashes,
    load_profile_json,
    save_hashes,
    save_profile_json,
    save_profile_md,
)


class TestProfilePersistence:
    def test_save_and_load_json(self, tmp_path: Path):
        profile = RepoProfile(
            repo_path=str(tmp_path),
            repo_name="test",
            tech_stack=TechStack(
                primary_language="Python",
                language_version="3.12",
                framework="FastAPI",
                dependencies=[Dependency(name="fastapi", version=">=0.100")],
            ),
        )

        save_profile_json(profile, tmp_path)
        loaded = load_profile_json(tmp_path)

        assert loaded is not None
        assert loaded.repo_name == "test"
        assert loaded.tech_stack.primary_language == "Python"
        assert loaded.tech_stack.framework == "FastAPI"
        assert len(loaded.tech_stack.dependencies) == 1

    def test_load_nonexistent(self, tmp_path: Path):
        assert load_profile_json(tmp_path) is None

    def test_save_creates_repox_dir(self, tmp_path: Path):
        profile = RepoProfile(repo_path=str(tmp_path), repo_name="test")
        save_profile_json(profile, tmp_path)
        assert (tmp_path / ".repox").is_dir()
        assert (tmp_path / ".repox" / "profile.json").exists()

    def test_save_profile_md(self, tmp_path: Path):
        profile = RepoProfile(
            repo_path=str(tmp_path),
            repo_name="my-project",
            tech_stack=TechStack(
                primary_language="Python",
                language_version="3.12",
                framework="FastAPI",
                test_runner="pytest",
                test_command="pytest tests",
                linter="ruff",
                package_manager="uv",
            ),
            architecture=ArchitectureMap(
                pattern=ArchPattern.LAYERED,
                confidence=0.85,
                directory_labels=[
                    DirectoryLabel(path="src/routes", label="api", description="API handlers"),
                    DirectoryLabel(path="src/services", label="service"),
                ],
            ),
            custom_rules=CustomRules(
                rules=[CustomRule(
                    source=RuleSource.CLAUDE_MD,
                    content="Always use type hints",
                    file_path="CLAUDE.md",
                )],
                sources_found=["CLAUDE.md"],
            ),
        )

        save_profile_md(profile, tmp_path)
        md_path = tmp_path / ".repox" / "profile.md"
        assert md_path.exists()

        content = md_path.read_text()
        assert "my-project" in content
        assert "Python" in content
        assert "FastAPI" in content
        assert "pytest" in content
        assert "LAYERED" in content.upper() or "layered" in content
        assert "CLAUDE.md" in content


class TestHashing:
    def test_compute_hash(self, tmp_path: Path):
        f = tmp_path / "test.py"
        f.write_text("print('hello')")
        h1 = compute_file_hash(f)
        assert isinstance(h1, str)
        assert len(h1) == 64  # SHA-256 hex

    def test_hash_changes_with_content(self, tmp_path: Path):
        f = tmp_path / "test.py"
        f.write_text("print('hello')")
        h1 = compute_file_hash(f)

        f.write_text("print('world')")
        h2 = compute_file_hash(f)

        assert h1 != h2

    def test_hash_same_for_same_content(self, tmp_path: Path):
        f = tmp_path / "test.py"
        f.write_text("print('hello')")
        h1 = compute_file_hash(f)
        h2 = compute_file_hash(f)
        assert h1 == h2

    def test_save_and_load_hashes(self, tmp_path: Path):
        hashes = {"src/main.py": "abc123", "src/utils.py": "def456"}
        save_hashes(hashes, tmp_path)
        loaded = load_hashes(tmp_path)
        assert loaded == hashes

    def test_load_hashes_empty(self, tmp_path: Path):
        assert load_hashes(tmp_path) == {}


class TestChangedFiles:
    def test_all_new_files(self, tmp_path: Path):
        f1 = tmp_path / "a.py"
        f2 = tmp_path / "b.py"
        f1.write_text("a")
        f2.write_text("b")

        changed, new_hashes = get_changed_files(tmp_path, [f1, f2], {})
        assert len(changed) == 2
        assert len(new_hashes) == 2

    def test_no_changes(self, tmp_path: Path):
        f1 = tmp_path / "a.py"
        f1.write_text("a")

        _, old_hashes = get_changed_files(tmp_path, [f1], {})
        changed, _ = get_changed_files(tmp_path, [f1], old_hashes)
        assert len(changed) == 0

    def test_one_file_changed(self, tmp_path: Path):
        f1 = tmp_path / "a.py"
        f2 = tmp_path / "b.py"
        f1.write_text("a")
        f2.write_text("b")

        _, old_hashes = get_changed_files(tmp_path, [f1, f2], {})

        # Modify one file
        f1.write_text("a_modified")
        changed, _ = get_changed_files(tmp_path, [f1, f2], old_hashes)
        assert len(changed) == 1
        assert changed[0] == f1
