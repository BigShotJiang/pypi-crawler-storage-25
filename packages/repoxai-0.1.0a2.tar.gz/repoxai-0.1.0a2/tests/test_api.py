"""Tests for the public Python API."""

from __future__ import annotations

from pathlib import Path

import repox
from repox.api import generate_context, get_context_for_files, get_profile, scan


class TestScanAPI:
    def test_scan_returns_profile(self, tmp_path: Path):
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "example"
requires-python = ">=3.12"
dependencies = ["fastapi"]
""")
        (tmp_path / "main.py").write_text("x = 1\n")

        profile = scan(tmp_path)

        assert profile.repo_name == tmp_path.name
        assert profile.tech_stack.primary_language == "Python"

    def test_scan_accepts_string_path(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1\n")
        profile = scan(str(tmp_path))
        assert profile is not None

    def test_scan_force(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1\n")
        profile = scan(tmp_path, force=True)
        assert profile is not None


class TestGetProfileAPI:
    def test_returns_none_without_scan(self, tmp_path: Path):
        result = get_profile(tmp_path)
        assert result is None

    def test_returns_profile_after_scan(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1\n")
        scan(tmp_path)

        result = get_profile(tmp_path)
        assert result is not None
        assert result.repo_name == tmp_path.name


class TestGenerateContextAPI:
    def test_generates_context(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("def hello(): pass\n")
        scan(tmp_path)

        result = generate_context(
            tmp_path,
            task="Fix bug in hello function",
            task_type="bug_fix",
        )

        assert "Fix bug" in result
        assert len(result) > 50

    def test_auto_scans_if_no_profile(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1\n")

        result = generate_context(tmp_path, task="Do something")
        assert len(result) > 0

    def test_saves_context_md(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1\n")

        generate_context(tmp_path, task="Test task", save=True)

        assert (tmp_path / ".repox" / "context.md").exists()

    def test_no_save_option(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1\n")

        generate_context(tmp_path, task="Test task", save=False)

        assert not (tmp_path / ".repox" / "context.md").exists()


class TestGetContextForFilesAPI:
    def test_generates_for_files(self, tmp_path: Path):
        (tmp_path / "auth.py").write_text("def login(): pass\n")
        scan(tmp_path)

        result = get_context_for_files(tmp_path, files=["auth.py"])

        assert "auth.py" in result


class TestTopLevelExports:
    def test_scan_exported(self):
        assert hasattr(repox, "scan")

    def test_get_profile_exported(self):
        assert hasattr(repox, "get_profile")

    def test_generate_context_exported(self):
        assert hasattr(repox, "generate_context")

    def test_serve_exported(self):
        assert hasattr(repox, "serve")

    def test_record_learning_exported(self):
        assert hasattr(repox, "record_learning")

    def test_get_active_rules_exported(self):
        assert hasattr(repox, "get_active_rules")
