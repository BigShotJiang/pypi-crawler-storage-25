"""Tests for the CLI entry point."""

from pathlib import Path

from click.testing import CliRunner

from repox.cli import main


class TestCLIScan:
    def test_scan_command(self, python_repo: Path):
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(python_repo)])
        assert result.exit_code == 0
        assert "Scanning" in result.output
        assert "Python" in result.output
        assert "FastAPI" in result.output

    def test_scan_force(self, python_repo: Path):
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(python_repo), "--force"])
        assert result.exit_code == 0

    def test_scan_json_output(self, python_repo: Path):
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(python_repo), "--json-output"])
        assert result.exit_code == 0
        assert '"primary_language"' in result.output

    def test_scan_layered(self, layered_repo: Path):
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(layered_repo)])
        assert result.exit_code == 0
        assert "layered" in result.output.lower()


class TestCLIProfile:
    def test_profile_without_scan(self, tmp_path: Path):
        runner = CliRunner()
        result = runner.invoke(main, ["profile", str(tmp_path)])
        assert result.exit_code != 0
        assert "No profile found" in result.output

    def test_profile_after_scan(self, python_repo: Path):
        runner = CliRunner()
        runner.invoke(main, ["scan", str(python_repo)])
        result = runner.invoke(main, ["profile", str(python_repo)])
        assert result.exit_code == 0
        assert '"primary_language"' in result.output


class TestCLIShow:
    def test_show_without_scan(self, tmp_path: Path):
        runner = CliRunner()
        result = runner.invoke(main, ["show", str(tmp_path)])
        assert result.exit_code != 0
        assert "No profile found" in result.output

    def test_show_after_scan(self, python_repo: Path):
        runner = CliRunner()
        runner.invoke(main, ["scan", str(python_repo)])
        result = runner.invoke(main, ["show", str(python_repo)])
        assert result.exit_code == 0
        assert "Python" in result.output


class TestCLIVersion:
    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output
