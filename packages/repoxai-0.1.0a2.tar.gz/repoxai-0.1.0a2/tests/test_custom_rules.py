"""Tests for custom rules extraction."""

from pathlib import Path

from repox.extractors.custom_rules import extract_custom_rules
from repox.models import RuleSource


class TestCustomRulesExtraction:
    def test_finds_all_rule_files(self, rules_repo: Path):
        rules = extract_custom_rules(rules_repo)
        assert len(rules.rules) == 4
        assert len(rules.sources_found) == 4

    def test_finds_claude_md(self, rules_repo: Path):
        rules = extract_custom_rules(rules_repo)
        claude_rules = [r for r in rules.rules if r.source == RuleSource.CLAUDE_MD]
        assert len(claude_rules) == 1
        assert "type hints" in claude_rules[0].content

    def test_finds_agents_md(self, rules_repo: Path):
        rules = extract_custom_rules(rules_repo)
        agent_rules = [r for r in rules.rules if r.source == RuleSource.AGENTS_MD]
        assert len(agent_rules) == 1
        assert "Repository pattern" in agent_rules[0].content

    def test_finds_cursorrules(self, rules_repo: Path):
        rules = extract_custom_rules(rules_repo)
        cursor_rules = [r for r in rules.rules if r.source == RuleSource.CURSORRULES]
        assert len(cursor_rules) == 1
        assert "TypeScript" in cursor_rules[0].content

    def test_parses_patchmate_yaml(self, rules_repo: Path):
        rules = extract_custom_rules(rules_repo)
        pm_rules = [r for r in rules.rules if r.source == RuleSource.PATCHMATE_YAML]
        assert len(pm_rules) == 1
        content = pm_rules[0].content
        # Should have parsed structure
        assert "tests before committing" in content
        assert "snake_case" in content
        assert "migrations/" in content

    def test_sources_found(self, rules_repo: Path):
        rules = extract_custom_rules(rules_repo)
        assert "CLAUDE.md" in rules.sources_found
        assert "AGENTS.md" in rules.sources_found
        assert ".cursorrules" in rules.sources_found
        assert "patchmate.yaml" in rules.sources_found


class TestSingleRuleFile:
    def test_only_claude_md(self, tmp_path: Path):
        (tmp_path / "CLAUDE.md").write_text("Use pytest for testing.")
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 1
        assert rules.rules[0].source == RuleSource.CLAUDE_MD

    def test_only_agents_md(self, tmp_path: Path):
        (tmp_path / "AGENTS.md").write_text("Follow TDD.")
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 1
        assert rules.rules[0].source == RuleSource.AGENTS_MD

    def test_copilot_instructions(self, tmp_path: Path):
        gh = tmp_path / ".github"
        gh.mkdir()
        (gh / "copilot-instructions.md").write_text("Use async/await.")
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 1
        assert rules.rules[0].source == RuleSource.COPILOT_INSTRUCTIONS


class TestEdgeCases:
    def test_empty_repo(self, tmp_path: Path):
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 0
        assert len(rules.sources_found) == 0

    def test_empty_rule_file(self, tmp_path: Path):
        (tmp_path / "CLAUDE.md").write_text("")
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 0

    def test_whitespace_only_file(self, tmp_path: Path):
        (tmp_path / "CLAUDE.md").write_text("   \n\n  ")
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 0

    def test_invalid_yaml(self, tmp_path: Path):
        (tmp_path / "patchmate.yaml").write_text(": invalid: yaml: [")
        rules = extract_custom_rules(tmp_path)
        # Should still capture the raw content
        assert len(rules.rules) == 1

    def test_patchmate_yaml_plain_string(self, tmp_path: Path):
        (tmp_path / "patchmate.yaml").write_text("just a plain string of rules")
        rules = extract_custom_rules(tmp_path)
        assert len(rules.rules) == 1
        assert rules.rules[0].content == "just a plain string of rules"
