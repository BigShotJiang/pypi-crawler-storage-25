"""Tests for MCP server — single get_context tool."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from repox.models import (
    APISurface,
    ArchitectureMap,
    ArchPattern,
    CodingConventions,
    Convention,
    CustomRule,
    CustomRules,
    DataEntity,
    DataModelMap,
    DependencyGraph,
    DesignPatterns,
    DetectedPattern,
    DirectoryLabel,
    Endpoint,
    FieldDef,
    FileOwnership,
    Hotspot,
    HotspotAnalysis,
    ImportEdge,
    InfraTopology,
    KnowledgeMap,
    ModuleBusFactor,
    RepoProfile,
    RuleSource,
    Service,
    EnvVar,
    Symbol,
    SymbolGraph,
    SymbolKind,
    SymbolRank,
    CallEdge,
    TechStack,
    TestPatterns,
)
from repox import server


def _make_profile() -> RepoProfile:
    return RepoProfile(
        repo_path="/test",
        repo_name="test-repo",
        last_scanned=datetime.now(),
        tech_stack=TechStack(
            primary_language="Python",
            framework="FastAPI",
            test_runner="pytest",
        ),
        architecture=ArchitectureMap(
            pattern=ArchPattern.LAYERED,
            confidence=0.85,
            entry_points=["src/main.py"],
            directory_labels=[DirectoryLabel(path="src/api", label="api")],
        ),
        symbols=SymbolGraph(
            symbols=[
                Symbol(name="get_user", kind=SymbolKind.FUNCTION, file_path="src/api.py",
                       line_start=10, line_end=20, is_async=True, parent_scope="UserRouter"),
            ],
            languages_parsed=["python"],
            files_parsed=5,
        ),
        dependencies=DependencyGraph(
            import_edges=[
                ImportEdge(source_file="src/api.py", target_file="src/service.py", imported_names=["UserService"]),
            ],
            call_edges=[
                CallEdge(caller="get_user", callee="UserService.get", file_path="src/api.py", line=15),
            ],
            symbol_ranks=[
                SymbolRank(symbol="src/service.py", file_path="src/service.py", pagerank=0.15),
            ],
        ),
        api_surface=APISurface(
            framework="FastAPI",
            endpoints=[
                Endpoint(method="GET", path="/users/{id}", handler="get_user",
                         file_path="src/api.py", line=10),
            ],
        ),
        data_models=DataModelMap(entities=[
            DataEntity(name="User", file_path="src/models.py", orm="SQLAlchemy",
                       fields=[FieldDef(name="id", type="int", primary_key=True)]),
        ]),
        design_patterns=DesignPatterns(patterns=[
            DetectedPattern(pattern="Repository", category="structural",
                            file_path="src/repo.py", participants=["UserRepo"], confidence=0.85),
        ]),
        infrastructure=InfraTopology(
            services=[Service(name="web", image="python:3.12", ports=["8000"])],
            env_vars=[EnvVar(name="DATABASE_URL", source="code")],
            external_integrations=["AWS"],
            deployment_targets=["Docker"],
        ),
        conventions=CodingConventions(conventions=[
            Convention(category="naming", rule="snake_case", confidence=0.95),
        ]),
        test_patterns=TestPatterns(
            framework="pytest", test_count=50, test_file_count=10,
        ),
        hotspots=HotspotAnalysis(hotspots=[
            Hotspot(file_path="src/core.py", change_frequency=30, churn=500, complexity=200, score=60.0),
        ]),
        knowledge_map=KnowledgeMap(
            file_ownerships=[
                FileOwnership(file_path="src/core.py", primary_author="Alice",
                              contribution_pct=98.0, is_knowledge_island=True),
            ],
            bus_factors=[
                ModuleBusFactor(module="src", bus_factor=2, contributors=["Alice", "Bob"]),
            ],
        ),
        custom_rules=CustomRules(
            rules=[CustomRule(source=RuleSource.CLAUDE_MD, content="Use type hints", file_path="CLAUDE.md")],
            sources_found=["CLAUDE.md"],
        ),
    )


class TestGetContext:
    def setup_method(self):
        server._profile = _make_profile()
        server._repo_path = Path("/test")

    def test_no_args_returns_full_profile(self, tmp_path: Path):
        """get_context() with no args returns the full profile.md."""
        # Create a fake profile.md
        repox_dir = tmp_path / ".repox"
        repox_dir.mkdir()
        profile_md = repox_dir / "profile.md"
        profile_md.write_text("# Full Profile\nAll 13 dimensions here.")

        server._repo_path = tmp_path
        result = server.get_context()

        assert "Full Profile" in result
        assert "13 dimensions" in result

    def test_with_task_returns_context_brief(self):
        """get_context(task=...) returns a context brief (template fallback)."""
        result = server.get_context(task="Fix the login bug")

        # Template fallback should include task and profile data
        assert "Fix the login bug" in result
        assert "Python" in result

    def test_with_task_and_target_files(self):
        """get_context with target_files filters dependencies."""
        result = server.get_context(
            task="Refactor API layer",
            target_files=["src/api.py"],
        )

        assert "Refactor API layer" in result
        assert "src/api.py" in result

    def test_no_profile_raises(self):
        """get_context raises when no profile is loaded."""
        server._profile = None
        try:
            server.get_context(task="anything")
            assert False, "Should have raised"
        except RuntimeError as e:
            assert "No profile loaded" in str(e)

    def test_task_brief_includes_conventions(self):
        """Task-aware brief includes conventions from the profile."""
        result = server.get_context(task="Add new endpoint")
        assert "snake_case" in result

    def test_task_brief_includes_architecture(self):
        """Task-aware brief includes architecture info."""
        result = server.get_context(task="Add new module")
        assert "layered" in result.lower()
