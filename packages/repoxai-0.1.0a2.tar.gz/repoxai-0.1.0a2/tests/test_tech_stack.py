"""Tests for tech stack fingerprint extraction."""

import json
from pathlib import Path

from repox.extractors.tech_stack import extract_tech_stack


class TestPythonDetection:
    def test_pyproject_basic(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.primary_language == "Python"
        assert ts.language_version == "3.11"
        assert ts.package_manager == "uv"
        assert "pyproject.toml" in ts.config_files_parsed

    def test_pyproject_framework(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.framework == "FastAPI"

    def test_pyproject_orm(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.orm == "SQLAlchemy"

    def test_pyproject_test_runner(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.test_runner == "pytest"
        assert ts.test_command == "pytest tests"

    def test_pyproject_linter(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.linter == "ruff"

    def test_pyproject_dependencies(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        dep_names = [d.name for d in ts.dependencies]
        assert "fastapi" in dep_names
        assert "sqlalchemy" in dep_names

    def test_pyproject_dev_dependencies(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        dev_names = [d.name for d in ts.dev_dependencies]
        assert "pytest" in dev_names
        assert "ruff" in dev_names

    def test_pyproject_cloud(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.cloud_provider == "AWS"

    def test_pyproject_database(self, python_repo: Path):
        ts = extract_tech_stack(python_repo)
        assert ts.database == "PostgreSQL"

    def test_poetry_detection(self, tmp_path: Path):
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "test"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = ["django>=4.0"]

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
""")
        ts = extract_tech_stack(tmp_path)
        assert ts.package_manager == "poetry"
        assert ts.framework == "Django"


class TestNodeDetection:
    def test_package_json_basic(self, node_repo: Path):
        ts = extract_tech_stack(node_repo)
        assert ts.primary_language == "TypeScript"
        assert ts.language_version == "20"
        assert ts.package_manager == "pnpm"

    def test_package_json_framework(self, node_repo: Path):
        ts = extract_tech_stack(node_repo)
        assert ts.framework == "Next.js"

    def test_package_json_orm(self, node_repo: Path):
        ts = extract_tech_stack(node_repo)
        assert ts.orm == "Prisma"

    def test_package_json_test_runner(self, node_repo: Path):
        ts = extract_tech_stack(node_repo)
        assert ts.test_runner == "vitest"
        assert ts.test_command == "vitest run"

    def test_package_json_linter(self, node_repo: Path):
        ts = extract_tech_stack(node_repo)
        assert ts.linter == "eslint"
        assert ts.formatter == "prettier"

    def test_javascript_detection(self, tmp_path: Path):
        """Without TypeScript dep, should detect as JavaScript."""
        (tmp_path / "package.json").write_text(json.dumps({
            "name": "jsapp",
            "dependencies": {"express": "^4.0.0"},
        }))
        ts = extract_tech_stack(tmp_path)
        assert ts.primary_language == "JavaScript"
        assert ts.framework == "Express"


class TestGoDetection:
    def test_go_mod(self, go_repo: Path):
        ts = extract_tech_stack(go_repo)
        assert ts.primary_language == "Go"
        assert ts.language_version == "1.22"
        assert ts.package_manager == "go mod"
        assert ts.framework == "Gin"
        assert ts.orm == "GORM"
        assert ts.test_runner == "go test"


class TestRustDetection:
    def test_cargo_toml(self, rust_repo: Path):
        ts = extract_tech_stack(rust_repo)
        assert ts.primary_language == "Rust"
        assert ts.language_version == "2021"
        assert ts.package_manager == "cargo"
        assert ts.framework == "Axum"
        assert ts.orm == "SQLx"
        assert ts.test_runner == "cargo test"


class TestCIDetection:
    def test_github_actions(self, tmp_path: Path):
        gh = tmp_path / ".github" / "workflows"
        gh.mkdir(parents=True)
        (gh / "ci.yml").write_text("name: CI")
        ts = extract_tech_stack(tmp_path)
        assert ts.ci_system == "GitHub Actions"

    def test_gitlab_ci(self, tmp_path: Path):
        (tmp_path / ".gitlab-ci.yml").write_text("stages: [test]")
        ts = extract_tech_stack(tmp_path)
        assert ts.ci_system == "GitLab CI"


class TestContainerDetection:
    def test_dockerfile(self, tmp_path: Path):
        (tmp_path / "Dockerfile").write_text("FROM python:3.12")
        ts = extract_tech_stack(tmp_path)
        assert ts.containerization == "Docker"

    def test_compose(self, tmp_path: Path):
        (tmp_path / "docker-compose.yml").write_text("version: '3'")
        ts = extract_tech_stack(tmp_path)
        assert ts.containerization == "Docker Compose"

    def test_k8s(self, tmp_path: Path):
        (tmp_path / "k8s").mkdir()
        ts = extract_tech_stack(tmp_path)
        assert ts.containerization == "Kubernetes"


class TestEmptyRepo:
    def test_no_config_files(self, tmp_path: Path):
        ts = extract_tech_stack(tmp_path)
        assert ts.primary_language is None
        assert ts.framework is None
        assert ts.dependencies == []
