"""Tests for infrastructure topology extraction."""

from __future__ import annotations

from pathlib import Path

from repox.extractors.infrastructure import extract_infrastructure


class TestDockerfile:
    def test_basic_dockerfile(self, tmp_path: Path):
        (tmp_path / "Dockerfile").write_text("""\
FROM python:3.12-slim
WORKDIR /app
COPY . .
EXPOSE 8000
EXPOSE 8080
CMD ["uvicorn", "main:app"]
""")
        infra = extract_infrastructure(tmp_path, [])
        assert len(infra.services) == 1
        assert infra.services[0].name == "app"
        assert infra.services[0].image == "python:3.12-slim"
        assert "8000" in infra.services[0].ports
        assert "8080" in infra.services[0].ports
        assert "Docker" in infra.deployment_targets


class TestDockerCompose:
    def test_compose_services(self, tmp_path: Path):
        (tmp_path / "docker-compose.yml").write_text("""\
version: '3.8'
services:
  web:
    build: .
    ports:
      - "8000:8000"
    depends_on:
      - db
      - redis
    environment:
      - DATABASE_URL=postgres://localhost/mydb
      - REDIS_URL=redis://redis:6379
  db:
    image: postgres:15
    ports:
      - "5432:5432"
    environment:
      POSTGRES_DB: mydb
      POSTGRES_PASSWORD: secret
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
""")
        infra = extract_infrastructure(tmp_path, [])
        assert len(infra.services) == 3
        assert "Docker Compose" in infra.deployment_targets

        web = next(s for s in infra.services if s.name == "web")
        assert "db" in web.depends_on
        assert "redis" in web.depends_on

        db = next(s for s in infra.services if s.name == "db")
        assert db.image == "postgres:15"

        # Env vars should be extracted
        env_names = {ev.name for ev in infra.env_vars}
        assert "DATABASE_URL" in env_names
        assert "REDIS_URL" in env_names


class TestKubernetes:
    def test_k8s_deployment(self, tmp_path: Path):
        k8s_dir = tmp_path / "k8s"
        k8s_dir.mkdir()
        (k8s_dir / "deployment.yaml").write_text("""\
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-server
spec:
  replicas: 3
  template:
    spec:
      containers:
        - name: api
          image: myapp:latest
""")
        infra = extract_infrastructure(tmp_path, [])
        assert "Kubernetes" in infra.deployment_targets
        assert any(s.name == "api-server" for s in infra.services)


class TestTerraform:
    def test_terraform_aws(self, tmp_path: Path):
        (tmp_path / "main.tf").write_text("""\
resource "aws_ecs_service" "api" {
  name = "api-service"
}

resource "aws_rds_instance" "db" {
  engine = "postgres"
}
""")
        infra = extract_infrastructure(tmp_path, [])
        assert "Terraform" in infra.deployment_targets
        assert "AWS" in infra.deployment_targets


class TestEnvVars:
    def test_env_example(self, tmp_path: Path):
        (tmp_path / ".env.example").write_text("""\
# Database
DATABASE_URL=postgres://localhost/mydb
REDIS_URL=redis://localhost:6379

# API Keys
STRIPE_SECRET_KEY=sk_test_xxx
SENTRY_DSN=https://xxx@sentry.io/123
""")
        infra = extract_infrastructure(tmp_path, [])
        env_names = {ev.name for ev in infra.env_vars}
        assert "DATABASE_URL" in env_names
        assert "STRIPE_SECRET_KEY" in env_names
        assert "SENTRY_DSN" in env_names

    def test_python_env_vars(self, tmp_path: Path):
        (tmp_path / "config.py").write_text("""\
import os

DATABASE_URL = os.environ.get("DATABASE_URL")
SECRET_KEY = os.getenv("SECRET_KEY")
DEBUG = os.environ["DEBUG_MODE"]
""")
        infra = extract_infrastructure(tmp_path, [tmp_path / "config.py"])
        env_names = {ev.name for ev in infra.env_vars}
        assert "DATABASE_URL" in env_names
        assert "SECRET_KEY" in env_names

    def test_js_env_vars(self, tmp_path: Path):
        (tmp_path / "config.ts").write_text("""\
const dbUrl = process.env.DATABASE_URL;
const apiKey = process.env["API_KEY"];
""")
        infra = extract_infrastructure(tmp_path, [tmp_path / "config.ts"])
        env_names = {ev.name for ev in infra.env_vars}
        assert "DATABASE_URL" in env_names
        assert "API_KEY" in env_names


class TestExternalIntegrations:
    def test_detects_from_imports(self, tmp_path: Path):
        (tmp_path / "services.py").write_text("""\
import boto3
import stripe
from sentry_sdk import init
""")
        infra = extract_infrastructure(tmp_path, [tmp_path / "services.py"])
        assert "AWS" in infra.external_integrations
        assert "Stripe" in infra.external_integrations
        assert "Sentry" in infra.external_integrations

    def test_detects_from_env_var_names(self, tmp_path: Path):
        (tmp_path / ".env.example").write_text("""\
STRIPE_SECRET_KEY=xxx
SLACK_WEBHOOK_URL=xxx
DATADOG_API_KEY=xxx
""")
        infra = extract_infrastructure(tmp_path, [])
        assert "Stripe" in infra.external_integrations
        assert "Slack" in infra.external_integrations
        assert "Datadog" in infra.external_integrations


class TestEmptyRepo:
    def test_no_infrastructure(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1")
        infra = extract_infrastructure(tmp_path, [tmp_path / "main.py"])
        assert len(infra.services) == 0
        assert len(infra.deployment_targets) == 0
