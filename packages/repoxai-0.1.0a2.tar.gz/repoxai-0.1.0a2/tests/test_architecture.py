"""Tests for architecture map extraction."""

from pathlib import Path

from repox.extractors.architecture import extract_architecture
from repox.models import ArchPattern


class TestLayeredArchitecture:
    def test_detects_layered(self, layered_repo: Path):
        arch = extract_architecture(layered_repo)
        assert arch.pattern == ArchPattern.LAYERED
        assert arch.confidence >= 0.70

    def test_labels_directories(self, layered_repo: Path):
        arch = extract_architecture(layered_repo)
        labels = {dl.label for dl in arch.directory_labels}
        assert "api" in labels
        assert "service" in labels
        assert "data" in labels

    def test_layering_rules(self, layered_repo: Path):
        arch = extract_architecture(layered_repo)
        # Should have rules about api -> service -> data
        assert len(arch.layering_rules) > 0

        # Find the api -> data rule (should be disallowed)
        for rule in arch.layering_rules:
            if "routes" in rule.source and "models" in rule.target:
                assert rule.allowed is False

    def test_entry_points(self, layered_repo: Path):
        arch = extract_architecture(layered_repo)
        assert any("main.py" in ep for ep in arch.entry_points)

    def test_module_boundaries(self, layered_repo: Path):
        arch = extract_architecture(layered_repo)
        assert len(arch.module_boundaries) > 0


class TestDDDArchitecture:
    def test_detects_ddd(self, ddd_repo: Path):
        arch = extract_architecture(ddd_repo)
        assert arch.pattern == ArchPattern.DOMAIN_DRIVEN
        assert arch.confidence >= 0.70


class TestMVCArchitecture:
    def test_detects_mvc(self, mvc_repo: Path):
        arch = extract_architecture(mvc_repo)
        assert arch.pattern == ArchPattern.MVC
        assert arch.confidence >= 0.85


class TestHexagonalArchitecture:
    def test_detects_hexagonal(self, hexagonal_repo: Path):
        arch = extract_architecture(hexagonal_repo)
        assert arch.pattern == ArchPattern.HEXAGONAL
        assert arch.confidence >= 0.80

    def test_hexagonal_layering(self, hexagonal_repo: Path):
        arch = extract_architecture(hexagonal_repo)
        # Core should not import adapters
        for rule in arch.layering_rules:
            if "core" in rule.source and "adapters" in rule.target:
                assert rule.allowed is False


class TestFlatArchitecture:
    def test_detects_flat(self, tmp_path: Path):
        # Just a few files, no meaningful subdirs
        (tmp_path / "main.py").touch()
        (tmp_path / "utils.py").touch()
        arch = extract_architecture(tmp_path)
        assert arch.pattern in (ArchPattern.FLAT, ArchPattern.UNKNOWN)


class TestEmptyRepo:
    def test_empty_repo(self, tmp_path: Path):
        arch = extract_architecture(tmp_path)
        assert arch.pattern == ArchPattern.UNKNOWN or arch.pattern == ArchPattern.FLAT
