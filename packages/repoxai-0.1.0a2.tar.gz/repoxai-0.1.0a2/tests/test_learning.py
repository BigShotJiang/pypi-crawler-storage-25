"""Tests for historical learning engine."""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

from repox.learning import (
    contradict_learning,
    decay_stale_rules,
    get_active_rules,
    record_learning,
)
from repox.models import RepoProfile
from repox.persistence import load_profile_json, save_profile_json


def _init_profile(tmp_path: Path) -> None:
    """Create a minimal profile for learning tests."""
    profile = RepoProfile(repo_path=str(tmp_path), repo_name="test")
    save_profile_json(profile, tmp_path)


class TestRecordLearning:
    def test_creates_new_rule(self, tmp_path: Path):
        _init_profile(tmp_path)

        rule = record_learning(
            tmp_path,
            rule="Use tenacity for retries",
            category="error_handling",
            source="interaction",
            context="PR #42",
        )

        assert rule.rule == "Use tenacity for retries"
        assert rule.category == "error_handling"
        assert rule.confidence == 0.5
        assert rule.reinforcement_count == 0
        assert rule.context == "PR #42"

    def test_reinforces_existing_rule(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Use type hints", category="typing")
        rule = record_learning(tmp_path, rule="Use type hints", category="typing")

        assert rule.reinforcement_count == 1
        assert rule.confidence == 0.6  # 0.5 + 0.1

    def test_multiple_reinforcements(self, tmp_path: Path):
        _init_profile(tmp_path)

        for _ in range(5):
            rule = record_learning(tmp_path, rule="Snake case", category="naming")

        assert rule.reinforcement_count == 4
        assert abs(rule.confidence - 0.9) < 0.01  # 0.5 + 4*0.1

    def test_confidence_caps_at_one(self, tmp_path: Path):
        _init_profile(tmp_path)

        for _ in range(20):
            rule = record_learning(tmp_path, rule="Test rule", category="testing")

        assert rule.confidence <= 1.0

    def test_increments_total_interactions(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Rule A", category="a")
        record_learning(tmp_path, rule="Rule B", category="b")
        record_learning(tmp_path, rule="Rule A", category="a")  # reinforce

        profile = load_profile_json(tmp_path)
        assert profile.learning.total_interactions == 3

    def test_persists_to_disk(self, tmp_path: Path):
        _init_profile(tmp_path)
        record_learning(tmp_path, rule="Persisted rule", category="general")

        profile = load_profile_json(tmp_path)
        assert len(profile.learning.learned_rules) == 1
        assert profile.learning.learned_rules[0].rule == "Persisted rule"

    def test_case_insensitive_matching(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Use Type Hints", category="typing")
        rule = record_learning(tmp_path, rule="use type hints", category="typing")

        assert rule.reinforcement_count == 1  # matched existing

    def test_different_category_creates_new(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Be consistent", category="naming")
        record_learning(tmp_path, rule="Be consistent", category="testing")

        profile = load_profile_json(tmp_path)
        assert len(profile.learning.learned_rules) == 2

    def test_with_examples(self, tmp_path: Path):
        _init_profile(tmp_path)

        rule = record_learning(
            tmp_path, rule="Use factories",
            category="testing",
            examples=["UserFactory.create()", "OrderFactory.build()"],
        )

        assert len(rule.examples) == 2

    def test_no_profile_raises(self, tmp_path: Path):
        import pytest
        with pytest.raises(FileNotFoundError):
            record_learning(tmp_path, rule="test", category="test")


class TestContradictLearning:
    def test_reduces_confidence(self, tmp_path: Path):
        _init_profile(tmp_path)
        record_learning(tmp_path, rule="Always mock DB", category="testing")

        result = contradict_learning(tmp_path, rule="Always mock DB", category="testing")
        assert result is True

        profile = load_profile_json(tmp_path)
        rule = profile.learning.learned_rules[0]
        assert rule.confidence == 0.3  # 0.5 - 0.2
        assert rule.contradiction_count == 1

    def test_removes_at_zero_confidence(self, tmp_path: Path):
        _init_profile(tmp_path)
        record_learning(tmp_path, rule="Bad rule", category="general")

        contradict_learning(tmp_path, rule="Bad rule", category="general")  # 0.3
        contradict_learning(tmp_path, rule="Bad rule", category="general")  # 0.1
        contradict_learning(tmp_path, rule="Bad rule", category="general")  # 0 → removed

        profile = load_profile_json(tmp_path)
        assert len(profile.learning.learned_rules) == 0

    def test_not_found_returns_false(self, tmp_path: Path):
        _init_profile(tmp_path)
        result = contradict_learning(tmp_path, rule="nonexistent", category="x")
        assert result is False


class TestGetActiveRules:
    def test_filters_by_confidence(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Strong rule", category="a")
        # Reinforce to boost confidence
        record_learning(tmp_path, rule="Strong rule", category="a")
        record_learning(tmp_path, rule="Strong rule", category="a")

        record_learning(tmp_path, rule="Weak rule", category="b")
        # Contradict to lower confidence
        contradict_learning(tmp_path, rule="Weak rule", category="b")

        rules = get_active_rules(tmp_path, min_confidence=0.5)
        assert len(rules) == 1
        assert rules[0].rule == "Strong rule"

    def test_filters_by_category(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Naming rule", category="naming")
        record_learning(tmp_path, rule="Test rule", category="testing")

        rules = get_active_rules(tmp_path, min_confidence=0.0, category="naming")
        assert len(rules) == 1
        assert rules[0].category == "naming"

    def test_sorted_by_confidence(self, tmp_path: Path):
        _init_profile(tmp_path)

        record_learning(tmp_path, rule="Low conf", category="a")
        record_learning(tmp_path, rule="High conf", category="b")
        record_learning(tmp_path, rule="High conf", category="b")  # reinforce

        rules = get_active_rules(tmp_path, min_confidence=0.0)
        assert rules[0].rule == "High conf"

    def test_empty_repo(self, tmp_path: Path):
        rules = get_active_rules(tmp_path)
        assert rules == []


class TestDecayStaleRules:
    def test_decays_old_rules(self, tmp_path: Path):
        _init_profile(tmp_path)
        record_learning(tmp_path, rule="Old rule", category="general")

        # Manually set last_reinforced to 8 months ago
        profile = load_profile_json(tmp_path)
        profile.learning.learned_rules[0].last_reinforced = datetime.now() - timedelta(days=250)
        save_profile_json(profile, tmp_path)

        count = decay_stale_rules(tmp_path, stale_months=6)
        assert count == 1

        profile = load_profile_json(tmp_path)
        assert profile.learning.learned_rules[0].confidence == 0.35  # 0.5 - 0.15

    def test_removes_fully_decayed(self, tmp_path: Path):
        _init_profile(tmp_path)
        record_learning(tmp_path, rule="Will decay", category="general")

        profile = load_profile_json(tmp_path)
        profile.learning.learned_rules[0].last_reinforced = datetime.now() - timedelta(days=400)
        profile.learning.learned_rules[0].confidence = 0.1  # already low
        save_profile_json(profile, tmp_path)

        decay_stale_rules(tmp_path, stale_months=6, decay_amount=0.15)

        profile = load_profile_json(tmp_path)
        assert len(profile.learning.learned_rules) == 0

    def test_does_not_decay_recent_rules(self, tmp_path: Path):
        _init_profile(tmp_path)
        record_learning(tmp_path, rule="Fresh rule", category="general")

        count = decay_stale_rules(tmp_path, stale_months=6)
        assert count == 0

    def test_no_profile_returns_zero(self, tmp_path: Path):
        count = decay_stale_rules(tmp_path)
        assert count == 0
