"""Tests for design pattern detection."""

from __future__ import annotations

from pathlib import Path

from repox.extractors.design_patterns import extract_design_patterns
from repox.extractors.symbols import extract_symbols


class TestNamingConventionDetection:
    def test_detects_factory_by_name(self, tmp_path: Path):
        (tmp_path / "user_factory.py").write_text('''\
class UserFactory:
    def create(self, **kwargs):
        pass
''')
        files = [tmp_path / "user_factory.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        factory_patterns = [p for p in patterns.patterns if p.pattern == "Factory"]
        assert len(factory_patterns) >= 1

    def test_detects_repository_by_name(self, tmp_path: Path):
        (tmp_path / "user_repository.py").write_text('''\
class UserRepository:
    def get(self, id): pass
    def create(self, data): pass
    def update(self, id, data): pass
    def delete(self, id): pass
''')
        files = [tmp_path / "user_repository.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        repo_patterns = [p for p in patterns.patterns if p.pattern == "Repository"]
        assert len(repo_patterns) >= 1

    def test_detects_service_by_name(self, tmp_path: Path):
        (tmp_path / "payment_service.py").write_text('''\
class PaymentService:
    def process(self): pass
''')
        files = [tmp_path / "payment_service.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        service_patterns = [p for p in patterns.patterns if p.pattern == "Service Layer"]
        assert len(service_patterns) >= 1


class TestSingletonDetection:
    def test_detects_singleton_get_instance(self, tmp_path: Path):
        (tmp_path / "config.py").write_text('''\
class Config:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
''')
        files = [tmp_path / "config.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        singleton = [p for p in patterns.patterns if p.pattern == "Singleton"]
        assert len(singleton) >= 1


class TestFactoryDetection:
    def test_detects_factory_methods(self, tmp_path: Path):
        (tmp_path / "factory.py").write_text('''\
class ConnectionFactory:
    def create_connection(self, type):
        pass

    def build_pool(self):
        pass
''')
        files = [tmp_path / "factory.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        factory = [p for p in patterns.patterns if p.pattern == "Factory"]
        assert len(factory) >= 1

    def test_detects_standalone_factory_function(self, tmp_path: Path):
        (tmp_path / "helpers.py").write_text('''\
def create_database_engine(config):
    pass

def build_http_client(base_url):
    pass
''')
        files = [tmp_path / "helpers.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        factory = [p for p in patterns.patterns if p.pattern == "Factory"]
        assert len(factory) >= 1


class TestBuilderDetection:
    def test_detects_builder(self, tmp_path: Path):
        (tmp_path / "query.py").write_text('''\
class QueryBuilder:
    def with_filter(self, f):
        return self

    def with_sort(self, s):
        return self

    def with_limit(self, n):
        return self

    def build(self):
        return Query()
''')
        files = [tmp_path / "query.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        builder = [p for p in patterns.patterns if p.pattern == "Builder"]
        assert len(builder) >= 1


class TestRepositoryDetection:
    def test_detects_repository_by_methods(self, tmp_path: Path):
        (tmp_path / "store.py").write_text('''\
class DataStore:
    def get(self, id): pass
    def find_all(self): pass
    def create(self, entity): pass
    def update(self, id, data): pass
    def delete(self, id): pass
    def save(self, entity): pass
''')
        files = [tmp_path / "store.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        repo = [p for p in patterns.patterns if p.pattern == "Repository"]
        assert len(repo) >= 1


class TestObserverDetection:
    def test_detects_observer(self, tmp_path: Path):
        (tmp_path / "events.py").write_text('''\
class EventBus:
    def __init__(self):
        self.listeners = []

    def subscribe(self, listener):
        self.listeners.append(listener)

    def emit(self, event):
        for listener in self.listeners:
            listener(event)
''')
        files = [tmp_path / "events.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        observer = [p for p in patterns.patterns if p.pattern == "Observer"]
        assert len(observer) >= 1
        assert observer[0].confidence >= 0.8


class TestStrategyDetection:
    def test_detects_strategy(self, tmp_path: Path):
        (tmp_path / "auth.py").write_text('''\
from abc import ABC

class AuthStrategy(ABC):
    def authenticate(self, request):
        pass

class JWTAuth(AuthStrategy):
    def authenticate(self, request):
        pass

class APIKeyAuth(AuthStrategy):
    def authenticate(self, request):
        pass
''')
        files = [tmp_path / "auth.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        strategy = [p for p in patterns.patterns if p.pattern == "Strategy"]
        assert len(strategy) >= 1
        assert "AuthStrategy" in strategy[0].participants


class TestMiddlewareDetection:
    def test_detects_middleware(self, tmp_path: Path):
        (tmp_path / "middleware.py").write_text('''\
async def logging_middleware(request, call_next):
    response = await call_next(request)
    return response

async def auth_middleware(request, call_next):
    if not request.headers.get("Authorization"):
        raise HTTPException(401)
    return await call_next(request)
''')
        files = [tmp_path / "middleware.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)

        mw = [p for p in patterns.patterns if p.pattern == "Middleware"]
        assert len(mw) >= 1


class TestEmptyRepo:
    def test_no_patterns(self, tmp_path: Path):
        (tmp_path / "utils.py").write_text("x = 1")
        files = [tmp_path / "utils.py"]
        sym = extract_symbols(tmp_path, files)
        patterns = extract_design_patterns(tmp_path, files, sym)
        # Might still detect file naming patterns, but no structural ones
        assert isinstance(patterns.patterns, list)
