"""Tests for dependency graph + PageRank extraction."""

from __future__ import annotations

from pathlib import Path

from repox.extractors.dependencies import extract_dependencies
from repox.extractors.symbols import extract_symbols


class TestPythonImports:
    def test_absolute_imports(self, tmp_path: Path):
        src = tmp_path / "src" / "myapp"
        src.mkdir(parents=True)
        (src / "__init__.py").touch()
        (src / "models.py").write_text("class User: pass")
        (src / "services.py").write_text("""\
from myapp.models import User

def get_user():
    return User()
""")
        files = [src / "models.py", src / "services.py", src / "__init__.py"]
        sym = extract_symbols(tmp_path, files)
        dep = extract_dependencies(tmp_path, files, sym)

        import_targets = [e.target_file for e in dep.import_edges]
        assert any("models.py" in t for t in import_targets)

    def test_relative_imports(self, tmp_path: Path):
        pkg = tmp_path / "pkg"
        pkg.mkdir()
        (pkg / "__init__.py").touch()
        (pkg / "a.py").write_text("X = 1")
        (pkg / "b.py").write_text("from . import a\nfrom .a import X\n")

        files = [pkg / "__init__.py", pkg / "a.py", pkg / "b.py"]
        sym = extract_symbols(tmp_path, files)
        dep = extract_dependencies(tmp_path, files, sym)

        assert len(dep.import_edges) >= 1

    def test_call_edges(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("""\
def helper():
    pass

def main():
    helper()
    print("done")
""")
        files = [tmp_path / "app.py"]
        sym = extract_symbols(tmp_path, files)
        dep = extract_dependencies(tmp_path, files, sym)

        callees = [e.callee for e in dep.call_edges]
        assert "helper" in callees


class TestPageRank:
    def test_pagerank_ranks_central_files(self, tmp_path: Path):
        """The most-imported file should have the highest PageRank."""
        pkg = tmp_path / "pkg"
        pkg.mkdir()
        (pkg / "__init__.py").touch()
        (pkg / "models.py").write_text("class Base: pass\nclass User(Base): pass")
        (pkg / "services.py").write_text("from .models import User\ndef get(): return User()")
        (pkg / "routes.py").write_text("from .models import User\nfrom .services import get\ndef api(): return get()")

        files = [pkg / "__init__.py", pkg / "models.py", pkg / "services.py", pkg / "routes.py"]
        sym = extract_symbols(tmp_path, files)
        dep = extract_dependencies(tmp_path, files, sym)

        if dep.symbol_ranks:
            # models.py should rank highest (imported by both services and routes)
            top = dep.symbol_ranks[0]
            assert "models.py" in top.symbol

    def test_empty_graph(self, tmp_path: Path):
        (tmp_path / "standalone.py").write_text("x = 1")
        files = [tmp_path / "standalone.py"]
        sym = extract_symbols(tmp_path, files)
        dep = extract_dependencies(tmp_path, files, sym)

        # No imports = no graph = no ranks
        assert len(dep.import_edges) == 0


class TestJSImports:
    def test_relative_imports(self, tmp_path: Path):
        (tmp_path / "utils.js").write_text("export function add(a, b) { return a + b; }")
        (tmp_path / "app.js").write_text("import { add } from './utils';\nconsole.log(add(1, 2));\n")

        files = [tmp_path / "utils.js", tmp_path / "app.js"]
        sym = extract_symbols(tmp_path, files)
        dep = extract_dependencies(tmp_path, files, sym)

        assert len(dep.import_edges) >= 1
        edge = dep.import_edges[0]
        assert "utils.js" in edge.target_file
        assert "add" in edge.imported_names
