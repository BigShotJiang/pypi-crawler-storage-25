"""Shared test fixtures for Repox tests."""

from __future__ import annotations

import json
from pathlib import Path

import pytest


@pytest.fixture
def tmp_repo(tmp_path: Path) -> Path:
    """Create a minimal repo directory for testing."""
    return tmp_path


@pytest.fixture
def python_repo(tmp_path: Path) -> Path:
    """Create a Python project with pyproject.toml."""
    (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "myapp"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "fastapi>=0.100",
    "sqlalchemy>=2.0",
    "psycopg2>=2.9",
    "boto3>=1.28",
]

[build-system]
requires = ["uv_build>=0.9.5"]
build-backend = "uv_build"

[dependency-groups]
dev = [
    "pytest>=8.0",
    "ruff>=0.4",
]

[tool.pytest.ini_options]
testpaths = ["tests"]

[tool.ruff]
line-length = 120

[tool.ruff.lint]
select = ["E", "F", "I"]
""")
    return tmp_path


@pytest.fixture
def node_repo(tmp_path: Path) -> Path:
    """Create a Node.js/TypeScript project with package.json."""
    (tmp_path / "package.json").write_text(json.dumps({
        "name": "myapp",
        "version": "1.0.0",
        "engines": {"node": ">=20"},
        "packageManager": "pnpm@9.0.0",
        "scripts": {
            "test": "vitest run",
            "dev": "next dev",
        },
        "dependencies": {
            "next": "^14.0.0",
            "react": "^18.0.0",
            "@prisma/client": "^5.0.0",
        },
        "devDependencies": {
            "typescript": "^5.0.0",
            "vitest": "^1.0.0",
            "eslint": "^8.0.0",
            "prettier": "^3.0.0",
        },
    }, indent=2))
    (tmp_path / ".eslintrc.json").write_text("{}")
    (tmp_path / ".prettierrc").write_text("{}")
    return tmp_path


@pytest.fixture
def go_repo(tmp_path: Path) -> Path:
    """Create a Go project with go.mod."""
    (tmp_path / "go.mod").write_text("""\
module github.com/example/myapp

go 1.22

require (
    github.com/gin-gonic/gin v1.9.1
    gorm.io/gorm v1.25.5
)
""")
    return tmp_path


@pytest.fixture
def rust_repo(tmp_path: Path) -> Path:
    """Create a Rust project with Cargo.toml."""
    (tmp_path / "Cargo.toml").write_text("""\
[package]
name = "myapp"
version = "0.1.0"
edition = "2021"

[dependencies]
axum = "0.7"
sqlx = { version = "0.7", features = ["postgres"] }
tokio = { version = "1", features = ["full"] }
""")
    return tmp_path


@pytest.fixture
def layered_repo(tmp_path: Path) -> Path:
    """Create a layered architecture project."""
    src = tmp_path / "src"
    for d in ["routes", "services", "models", "middleware", "utils"]:
        (src / d).mkdir(parents=True)
        (src / d / "__init__.py").touch()

    (tmp_path / "src" / "main.py").touch()
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "__init__.py").touch()

    (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "layered-app"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = ["fastapi"]

[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"
""")
    return tmp_path


@pytest.fixture
def ddd_repo(tmp_path: Path) -> Path:
    """Create a domain-driven design project with feature folders."""
    src = tmp_path / "src"
    for domain in ["users", "orders", "payments"]:
        d = src / domain
        d.mkdir(parents=True)
        (d / "routes.py").touch()
        (d / "services.py").touch()
        (d / "models.py").touch()

    (src / "main.py").touch()
    return tmp_path


@pytest.fixture
def mvc_repo(tmp_path: Path) -> Path:
    """Create an MVC project."""
    src = tmp_path / "src"
    for d in ["models", "views", "controllers"]:
        (src / d).mkdir(parents=True)
        (src / d / "__init__.py").touch()
    return tmp_path


@pytest.fixture
def hexagonal_repo(tmp_path: Path) -> Path:
    """Create a hexagonal architecture project."""
    src = tmp_path / "src"
    for d in ["core", "adapters", "ports"]:
        (src / d).mkdir(parents=True)
        (src / d / "__init__.py").touch()
    return tmp_path


@pytest.fixture
def rules_repo(tmp_path: Path) -> Path:
    """Create a repo with various rule files."""
    (tmp_path / "CLAUDE.md").write_text("""\
# Project Rules

- Always use type hints
- Use ruff for linting
- Never modify the auth middleware directly
""")

    (tmp_path / "AGENTS.md").write_text("""\
# Agent Instructions

When adding endpoints, always add tests.
Use the Repository pattern for data access.
""")

    (tmp_path / ".cursorrules").write_text("""\
Use TypeScript strict mode.
Prefer functional components.
""")

    (tmp_path / "patchmate.yaml").write_text("""\
rules:
  - Always run tests before committing
  - Use conventional commits
conventions:
  naming: snake_case
  error_handling: custom exceptions
restrictions:
  no_modify:
    - migrations/
    - alembic/
  require_review:
    - src/auth/
""")

    return tmp_path
