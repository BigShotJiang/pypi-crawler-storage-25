"""Tests for context generation engine."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from repox.context import TaskContext, generate_context, save_context
from repox.models import (
    ArchitectureMap,
    ArchPattern,
    CodingConventions,
    Convention,
    CustomRule,
    CustomRules,
    DataEntity,
    DataModelMap,
    DependencyGraph,
    DesignPatterns,
    DetectedPattern,
    DirectoryLabel,
    Endpoint,
    APISurface,
    FieldDef,
    Hotspot,
    HotspotAnalysis,
    InfraTopology,
    KnowledgeMap,
    RepoProfile,
    RuleSource,
    Service,
    SymbolGraph,
    SymbolRank,
    TechStack,
    TestPatterns,
)


def _make_profile(**overrides) -> RepoProfile:
    defaults = dict(
        repo_path="/test/repo",
        repo_name="test-repo",
        last_scanned=datetime.now(),
        tech_stack=TechStack(primary_language="Python", framework="FastAPI"),
        architecture=ArchitectureMap(
            pattern=ArchPattern.LAYERED,
            confidence=0.85,
            directory_labels=[DirectoryLabel(path="src/api", label="api")],
        ),
        conventions=CodingConventions(conventions=[
            Convention(category="naming", rule="snake_case for functions", confidence=0.95, examples=["get_user"]),
        ]),
        custom_rules=CustomRules(
            rules=[CustomRule(source=RuleSource.CLAUDE_MD, content="Always use type hints", file_path="CLAUDE.md")],
            sources_found=["CLAUDE.md"],
        ),
    )
    defaults.update(overrides)
    return RepoProfile(**defaults)


class TestTemplateRendering:
    def test_basic_context_generation(self):
        profile = _make_profile()
        task = TaskContext(description="Fix login bug", task_type="bug_fix")

        # Without LLM, should fall back to template
        result = generate_context(profile, task)

        assert "Fix login bug" in result
        assert "Python" in result
        assert "test-repo" in result

    def test_includes_custom_rules(self):
        profile = _make_profile()
        task = TaskContext(description="Add feature")

        result = generate_context(profile, task)
        assert "Always use type hints" in result

    def test_includes_architecture(self):
        profile = _make_profile()
        task = TaskContext(description="Add endpoint")

        result = generate_context(profile, task)
        assert "layered" in result.lower()

    def test_includes_conventions(self):
        profile = _make_profile()
        task = TaskContext(description="Write code")

        result = generate_context(profile, task)
        assert "snake_case" in result

    def test_includes_hotspots(self):
        profile = _make_profile(
            hotspots=HotspotAnalysis(hotspots=[
                Hotspot(file_path="src/core.py", change_frequency=50, churn=1200, complexity=300, score=150.0),
            ]),
        )
        task = TaskContext(description="Refactor core")

        result = generate_context(profile, task)
        assert "src/core.py" in result

    def test_includes_design_patterns(self):
        profile = _make_profile(
            design_patterns=DesignPatterns(patterns=[
                DetectedPattern(pattern="Repository", category="structural",
                                file_path="src/repo.py", participants=["UserRepo"]),
            ]),
        )
        task = TaskContext(description="Add data access")

        result = generate_context(profile, task)
        assert "Repository" in result

    def test_includes_api_surface(self):
        profile = _make_profile(
            api_surface=APISurface(
                framework="FastAPI",
                endpoints=[Endpoint(method="GET", path="/users", handler="list_users",
                                    file_path="api.py", line=10)],
            ),
        )
        task = TaskContext(description="Add endpoint")

        result = generate_context(profile, task)
        assert "/users" in result

    def test_includes_infrastructure(self):
        profile = _make_profile(
            infrastructure=InfraTopology(
                services=[Service(name="web", image="python:3.12")],
                deployment_targets=["Docker"],
            ),
        )
        task = TaskContext(description="Deploy")

        result = generate_context(profile, task)
        assert "web" in result

    def test_target_files_shown(self):
        profile = _make_profile()
        task = TaskContext(description="Fix bug", target_files=["src/auth.py"])

        result = generate_context(profile, task)
        assert "src/auth.py" in result

    def test_token_budgeting(self):
        profile = _make_profile()
        task = TaskContext(description="Quick fix")

        result = generate_context(profile, task, max_tokens=100)
        # Should still produce output, just truncated
        assert len(result) > 0


class TestAdvisoryPrompt:
    """Tests for the LLM advisory prompt structure."""

    def test_llm_synthesize_prompt_includes_confidence_instructions(self):
        """The LLM prompt should instruct advisory tone and confidence tags."""
        from unittest.mock import patch, MagicMock
        from repox.context import _llm_synthesize, _build_sections

        profile = _make_profile(
            hotspots=HotspotAnalysis(hotspots=[
                Hotspot(file_path="src/core.py", change_frequency=50, churn=1200, complexity=300, score=150.0),
            ]),
        )
        task = TaskContext(description="Fix auth bug", task_type="bug_fix", target_files=["src/auth.py"])
        sections = _build_sections(profile, task)

        captured_args = {}

        def mock_complete(prompt, system=None, model=None):
            captured_args["prompt"] = prompt
            captured_args["system"] = system
            return "## Recommendation (high confidence)\nDo the thing."

        with patch("repox.llm.complete", mock_complete):
            result = _llm_synthesize(profile, task, sections)

        # Verify advisory tone in system prompt
        assert "advising, not instructing" in captured_args["system"]
        assert "high confidence" in captured_args["system"]
        assert "medium confidence" in captured_args["system"]
        assert "low confidence" in captured_args["system"]

        # Verify structured sections in prompt
        assert "Recommendation" in captured_args["prompt"]
        assert "Risks & Side Effects" in captured_args["prompt"]
        assert "Testing Strategy" in captured_args["prompt"]
        assert "Conventions to Follow" in captured_args["prompt"]

    def test_llm_synthesize_returns_llm_output(self):
        """_llm_synthesize returns the LLM's response directly."""
        from unittest.mock import patch
        from repox.context import _llm_synthesize, _build_sections

        profile = _make_profile()
        task = TaskContext(description="Add feature")
        sections = _build_sections(profile, task)

        expected = "## Recommendation (high confidence)\nUse the existing pattern."

        with patch("repox.llm.complete", return_value=expected):
            result = _llm_synthesize(profile, task, sections)

        assert result == expected


class TestContextPersistence:
    def test_save_context(self, tmp_path: Path):
        context = "# Context Brief\nThis is a test."
        out = save_context(context, tmp_path)

        assert out.exists()
        assert out.name == "context.md"
        assert out.read_text() == context
