"""Tests for data model map extraction."""

from __future__ import annotations

from pathlib import Path

from repox.extractors.data_models import extract_data_models


class TestSQLAlchemyExtraction:
    def test_basic_model(self, tmp_path: Path):
        (tmp_path / "models.py").write_text('''\
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import DeclarativeBase, relationship

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False, unique=True)
    email = Column(String, nullable=False, index=True)
    active = Column(Boolean, default=True)
    posts = relationship("Post", back_populates="author")

class Post(Base):
    __tablename__ = "posts"
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    author_id = Column(Integer, ForeignKey("users.id"))
    author = relationship("User", back_populates="posts")
''')
        models = extract_data_models(tmp_path, [tmp_path / "models.py"])
        assert len(models.entities) == 2

        user = next(e for e in models.entities if e.name == "User")
        assert user.orm == "SQLAlchemy"
        assert len(user.fields) >= 4

        id_field = next(f for f in user.fields if f.name == "id")
        assert id_field.primary_key is True

        name_field = next(f for f in user.fields if f.name == "name")
        assert name_field.nullable is False
        assert name_field.unique is True

        email_field = next(f for f in user.fields if f.name == "email")
        assert email_field.indexed is True

        assert len(user.relationships) == 1
        assert user.relationships[0].target_model == "Post"
        assert user.relationships[0].back_populates == "author"

        post = next(e for e in models.entities if e.name == "Post")
        fk_field = next(f for f in post.fields if f.name == "author_id")
        assert fk_field.foreign_key == "users.id"

    def test_mapped_column_style(self, tmp_path: Path):
        (tmp_path / "models.py").write_text('''\
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

class Base(DeclarativeBase):
    pass

class Item(Base):
    name = mapped_column(String, nullable=False)
    price = mapped_column(Float)
    quantity = mapped_column(Integer, nullable=False)
''')
        models = extract_data_models(tmp_path, [tmp_path / "models.py"])
        item = next((e for e in models.entities if e.name == "Item"), None)
        assert item is not None
        assert any(f.name == "price" for f in item.fields)


class TestDjangoExtraction:
    def test_django_model(self, tmp_path: Path):
        (tmp_path / "models.py").write_text('''\
from django.db import models

class Article(models.Model):
    title = models.CharField(max_length=200)
    body = models.TextField(null=True)
    published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey("User", on_delete=models.CASCADE, related_name="articles")
    tags = models.ManyToManyField("Tag", related_name="articles")
''')
        models_result = extract_data_models(tmp_path, [tmp_path / "models.py"])
        assert len(models_result.entities) == 1

        article = models_result.entities[0]
        assert article.name == "Article"
        assert article.orm == "Django ORM"

        title = next(f for f in article.fields if f.name == "title")
        assert title.type == "string"

        body = next(f for f in article.fields if f.name == "body")
        assert body.nullable is True

        # Relationships
        assert len(article.relationships) == 2
        fk_rel = next(r for r in article.relationships if r.name == "author")
        assert fk_rel.target_model == "User"
        assert fk_rel.kind == "many-to-one"
        assert fk_rel.back_populates == "articles"

        m2m_rel = next(r for r in article.relationships if r.name == "tags")
        assert m2m_rel.kind == "many-to-many"


class TestPydanticExtraction:
    def test_pydantic_model(self, tmp_path: Path):
        (tmp_path / "schemas.py").write_text('''\
from pydantic import BaseModel

class UserCreate(BaseModel):
    name: str
    email: str
    age: int | None = None
    role: str = "user"
''')
        models = extract_data_models(tmp_path, [tmp_path / "schemas.py"])
        assert len(models.entities) == 1

        user = models.entities[0]
        assert user.name == "UserCreate"
        assert user.orm == "Pydantic"

        name_f = next(f for f in user.fields if f.name == "name")
        assert name_f.type == "str"

        age_f = next(f for f in user.fields if f.name == "age")
        assert age_f.nullable is True
        assert age_f.default == "None"

        role_f = next(f for f in user.fields if f.name == "role")
        assert role_f.default == '"user"'


class TestPrismaExtraction:
    def test_prisma_schema(self, tmp_path: Path):
        (tmp_path / "schema.prisma").write_text('''\
model User {
  id        Int      @id @default(autoincrement())
  email     String   @unique
  name      String?
  posts     Post[]
  createdAt DateTime @default(now())
}

model Post {
  id       Int    @id @default(autoincrement())
  title    String
  content  String?
  author   User   @relation(fields: [authorId], references: [id])
  authorId Int
}
''')
        models = extract_data_models(tmp_path, [tmp_path / "schema.prisma"])
        assert len(models.entities) == 2

        user = next(e for e in models.entities if e.name == "User")
        assert user.orm == "Prisma"

        id_field = next(f for f in user.fields if f.name == "id")
        assert id_field.primary_key is True

        email_field = next(f for f in user.fields if f.name == "email")
        assert email_field.unique is True

        post = next(e for e in models.entities if e.name == "Post")
        assert any(r.target_model == "User" for r in post.relationships)


class TestEmptyRepo:
    def test_no_models(self, tmp_path: Path):
        (tmp_path / "utils.py").write_text("def helper(): pass")
        models = extract_data_models(tmp_path, [tmp_path / "utils.py"])
        assert len(models.entities) == 0

    def test_non_model_class(self, tmp_path: Path):
        (tmp_path / "service.py").write_text('''\
class UserService:
    def get_user(self, id):
        pass
''')
        models = extract_data_models(tmp_path, [tmp_path / "service.py"])
        assert len(models.entities) == 0
