"""Tests for the LLM integration layer."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from repox.cli import main
from repox.llm import LLMConfigError, complete, get_model


# Keys we need to ensure are cleared during auto-detect tests.
_API_KEYS = ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "REPOX_MODEL")


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Remove all LLM-related env vars so tests start from a clean state."""
    for key in _API_KEYS:
        monkeypatch.delenv(key, raising=False)


class TestGetModel:
    def test_cli_override_takes_priority(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("REPOX_MODEL", "openai/gpt-5.3")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        assert get_model(cli_override="custom/model") == "custom/model"

    def test_env_var_override(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("REPOX_MODEL", "openai/gpt-5.3")
        assert get_model() == "openai/gpt-5.3"

    def test_config_file_override(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        config = tmp_path / "config.toml"
        config.write_text('[llm]\nmodel = "gemini/gemini-2.5-flash"\n')
        monkeypatch.setattr("repox.llm._CONFIG_PATH", config)
        assert get_model() == "gemini/gemini-2.5-flash"

    def test_auto_detect_anthropic(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        assert get_model() == "anthropic/claude-opus-4-6"

    def test_auto_detect_openai(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        assert get_model() == "openai/gpt-5.3"

    def test_auto_detect_gemini(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("GEMINI_API_KEY", "key-test")
        assert get_model() == "gemini/gemini-2.5-flash"

    def test_auto_detect_priority_anthropic_first(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant")
        monkeypatch.setenv("OPENAI_API_KEY", "sk-oai")
        assert get_model() == "anthropic/claude-opus-4-6"

    def test_no_key_raises(self) -> None:
        with pytest.raises(LLMConfigError, match="No LLM API key found"):
            get_model()

    def test_priority_cli_over_env_over_config_over_detect(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config = tmp_path / "config.toml"
        config.write_text('[llm]\nmodel = "config/model"\n')
        monkeypatch.setattr("repox.llm._CONFIG_PATH", config)
        monkeypatch.setenv("REPOX_MODEL", "env/model")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")

        # CLI wins over all
        assert get_model(cli_override="cli/model") == "cli/model"
        # Without CLI, env wins
        assert get_model() == "env/model"
        # Without env, config wins
        monkeypatch.delenv("REPOX_MODEL")
        assert get_model() == "config/model"
        # Without config, auto-detect wins
        monkeypatch.setattr("repox.llm._CONFIG_PATH", tmp_path / "nonexistent.toml")
        assert get_model() == "anthropic/claude-opus-4-6"


def _mock_response(content: str = "mocked response") -> SimpleNamespace:
    """Build a fake litellm response object."""
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content=content))]
    )


class TestComplete:
    @patch("repox.llm.litellm.completion")
    def test_complete_basic(self, mock_completion, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        mock_completion.return_value = _mock_response("hello back")

        result = complete("hello")

        assert result == "hello back"
        mock_completion.assert_called_once()
        call_kwargs = mock_completion.call_args
        assert call_kwargs.kwargs["model"] == "anthropic/claude-opus-4-6"
        assert call_kwargs.kwargs["messages"] == [{"role": "user", "content": "hello"}]

    @patch("repox.llm.litellm.completion")
    def test_complete_with_system(self, mock_completion, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        mock_completion.return_value = _mock_response()

        complete("hello", system="be helpful")

        messages = mock_completion.call_args.kwargs["messages"]
        assert messages == [
            {"role": "system", "content": "be helpful"},
            {"role": "user", "content": "hello"},
        ]

    @patch("repox.llm.litellm.completion")
    def test_complete_with_model_override(self, mock_completion) -> None:
        mock_completion.return_value = _mock_response()

        complete("hello", model="custom/model")

        assert mock_completion.call_args.kwargs["model"] == "custom/model"


class TestCLIModelFlag:
    def test_model_flag_appears_in_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "--model" in result.output

    def test_existing_commands_still_work(self, python_repo: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["scan", str(python_repo)])
        assert result.exit_code == 0
