"""Tests for hotspot analysis and knowledge map extraction."""

from __future__ import annotations

import subprocess
from pathlib import Path

from repox.extractors.hotspots import extract_hotspots, extract_knowledge_map


def _init_git_repo(tmp_path: Path) -> None:
    """Initialize a git repo with some history."""
    subprocess.run(["git", "init"], cwd=str(tmp_path), capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(tmp_path), capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test Author"], cwd=str(tmp_path), capture_output=True)


def _commit(tmp_path: Path, message: str) -> None:
    subprocess.run(["git", "add", "-A"], cwd=str(tmp_path), capture_output=True)
    subprocess.run(["git", "commit", "-m", message, "--allow-empty"], cwd=str(tmp_path), capture_output=True)


class TestHotspotAnalysis:
    def test_detects_frequently_changed_files(self, tmp_path: Path):
        _init_git_repo(tmp_path)

        # Create files and make multiple commits
        hot_file = tmp_path / "hot.py"
        cold_file = tmp_path / "cold.py"

        cold_file.write_text("x = 1\n")
        _commit(tmp_path, "initial cold")

        for i in range(5):
            hot_file.write_text(f"x = {i}\n" * 10)
            _commit(tmp_path, f"update hot {i}")

        files = [hot_file, cold_file]
        result = extract_hotspots(tmp_path, files)

        assert len(result.hotspots) >= 1
        # hot.py should rank higher than cold.py
        hot_paths = [h.file_path for h in result.hotspots]
        assert "hot.py" in hot_paths
        hot_entry = next(h for h in result.hotspots if h.file_path == "hot.py")
        assert hot_entry.change_frequency >= 4

    def test_temporal_coupling(self, tmp_path: Path):
        _init_git_repo(tmp_path)

        file_a = tmp_path / "service.py"
        file_b = tmp_path / "repository.py"
        file_c = tmp_path / "unrelated.py"

        # Always change a and b together
        for i in range(5):
            file_a.write_text(f"# v{i}\nclass Service: pass\n")
            file_b.write_text(f"# v{i}\nclass Repo: pass\n")
            _commit(tmp_path, f"update service + repo {i}")

        # Change c independently
        file_c.write_text("x = 1\n")
        _commit(tmp_path, "unrelated change")

        files = [file_a, file_b, file_c]
        result = extract_hotspots(tmp_path, files)

        # service.py and repository.py should be temporally coupled
        if result.temporal_couplings:
            pair_files = {(tc.file_a, tc.file_b) for tc in result.temporal_couplings}
            assert ("repository.py", "service.py") in pair_files or ("service.py", "repository.py") in pair_files

    def test_empty_git_repo(self, tmp_path: Path):
        _init_git_repo(tmp_path)
        _commit(tmp_path, "initial")

        result = extract_hotspots(tmp_path, [])
        assert len(result.hotspots) == 0
        assert result.analysis_period_months == 12

    def test_non_git_repo(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1")
        result = extract_hotspots(tmp_path, [tmp_path / "main.py"])
        assert len(result.hotspots) == 0


class TestKnowledgeMap:
    def test_detects_file_ownership(self, tmp_path: Path):
        _init_git_repo(tmp_path)

        file_a = tmp_path / "main.py"
        file_a.write_text("x = 1\n")
        _commit(tmp_path, "initial")

        for i in range(3):
            file_a.write_text(f"x = {i}\n")
            _commit(tmp_path, f"update {i}")

        result = extract_knowledge_map(tmp_path, [file_a])
        assert len(result.file_ownerships) >= 1
        ownership = result.file_ownerships[0]
        assert ownership.primary_author == "Test Author"
        assert ownership.contribution_pct == 100.0

    def test_knowledge_island_detection(self, tmp_path: Path):
        _init_git_repo(tmp_path)

        file_a = tmp_path / "solo.py"
        for i in range(5):
            file_a.write_text(f"x = {i}\n")
            _commit(tmp_path, f"solo update {i}")

        result = extract_knowledge_map(tmp_path, [file_a])
        assert len(result.file_ownerships) >= 1
        solo = next(o for o in result.file_ownerships if o.file_path == "solo.py")
        assert solo.is_knowledge_island is True

    def test_bus_factor(self, tmp_path: Path):
        _init_git_repo(tmp_path)

        (tmp_path / "src").mkdir()
        file_a = tmp_path / "src" / "main.py"
        file_a.write_text("x = 1\n")
        _commit(tmp_path, "initial")

        result = extract_knowledge_map(tmp_path, [file_a])
        assert len(result.bus_factors) >= 1
        src_bf = next((b for b in result.bus_factors if b.module == "src"), None)
        assert src_bf is not None
        assert src_bf.bus_factor >= 1

    def test_non_git_repo(self, tmp_path: Path):
        (tmp_path / "main.py").write_text("x = 1")
        result = extract_knowledge_map(tmp_path, [tmp_path / "main.py"])
        assert len(result.file_ownerships) == 0
