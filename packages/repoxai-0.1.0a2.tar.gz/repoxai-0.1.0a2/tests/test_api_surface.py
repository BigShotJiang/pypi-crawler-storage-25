"""Tests for API surface map extraction."""

from __future__ import annotations

import json
from pathlib import Path

from repox.extractors.api_surface import extract_api_surface


class TestFastAPIExtraction:
    def test_basic_routes(self, tmp_path: Path):
        (tmp_path / "main.py").write_text('''\
from fastapi import FastAPI

app = FastAPI()

@app.get("/users")
async def list_users():
    return []

@app.post("/users")
async def create_user(user: UserCreate) -> User:
    return User()

@app.get("/users/{user_id}")
async def get_user(user_id: int):
    return {}

@app.delete("/users/{user_id}")
async def delete_user(user_id: int):
    pass
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "main.py"])
        assert len(surface.endpoints) == 4
        assert surface.framework == "FastAPI"

        methods = {ep.method for ep in surface.endpoints}
        assert "GET" in methods
        assert "POST" in methods
        assert "DELETE" in methods

        paths = {ep.path for ep in surface.endpoints}
        assert "/users" in paths
        assert "/users/{user_id}" in paths

    def test_router_routes(self, tmp_path: Path):
        (tmp_path / "routes.py").write_text('''\
from fastapi import APIRouter

router = APIRouter()

@router.get("/items")
async def list_items():
    return []

@router.put("/items/{id}")
async def update_item(id: int):
    pass
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "routes.py"])
        assert len(surface.endpoints) == 2
        assert surface.endpoints[0].handler == "list_items"
        assert surface.endpoints[1].method == "PUT"


class TestFlaskExtraction:
    def test_flask_routes(self, tmp_path: Path):
        (tmp_path / "app.py").write_text('''\
from flask import Flask

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health():
    return "ok"

@app.route("/submit", methods=["POST"])
def submit():
    pass
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "app.py"])
        assert len(surface.endpoints) == 2
        assert surface.framework == "Flask"

        health = next(ep for ep in surface.endpoints if ep.path == "/health")
        assert health.method == "GET"


class TestExpressExtraction:
    def test_express_routes(self, tmp_path: Path):
        (tmp_path / "server.js").write_text('''\
const express = require('express');
const app = express();

app.get('/api/users', getUsers);
app.post('/api/users', createUser);
app.put('/api/users/:id', updateUser);
app.delete('/api/users/:id', deleteUser);
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "server.js"])
        assert len(surface.endpoints) == 4
        assert surface.framework == "Express"

        methods = {ep.method for ep in surface.endpoints}
        assert methods == {"GET", "POST", "PUT", "DELETE"}

    def test_router_routes(self, tmp_path: Path):
        (tmp_path / "routes.ts").write_text('''\
import { Router } from 'express';
const router = Router();

router.get('/items', listItems);
router.post('/items', createItem);
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "routes.ts"])
        assert len(surface.endpoints) == 2


class TestDjangoExtraction:
    def test_django_urls(self, tmp_path: Path):
        (tmp_path / "urls.py").write_text('''\
from django.urls import path
from . import views

urlpatterns = [
    path("users/", views.user_list, name="user-list"),
    path("users/<int:pk>/", views.user_detail, name="user-detail"),
    path("orders/", views.order_list, name="order-list"),
]
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "urls.py"])
        assert len(surface.endpoints) == 3
        assert surface.framework == "Django"

        paths = {ep.path for ep in surface.endpoints}
        assert "/users" in paths
        assert "/users/<int:pk>" in paths


class TestNextJSExtraction:
    def test_nextjs_app_router(self, tmp_path: Path):
        api_dir = tmp_path / "app" / "api" / "users"
        api_dir.mkdir(parents=True)
        (api_dir / "route.ts").write_text('''\
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
    return NextResponse.json([]);
}

export async function POST(request: Request) {
    return NextResponse.json({});
}
''')
        surface = extract_api_surface(tmp_path, [api_dir / "route.ts"])
        assert len(surface.endpoints) == 2

        methods = {ep.method for ep in surface.endpoints}
        assert "GET" in methods
        assert "POST" in methods


class TestCeleryTasks:
    def test_celery_task_detection(self, tmp_path: Path):
        (tmp_path / "tasks.py").write_text('''\
from celery import shared_task

@shared_task
def send_email(to, subject, body):
    pass

@shared_task(bind=True, max_retries=3)
def process_order(self, order_id):
    pass
''')
        surface = extract_api_surface(tmp_path, [tmp_path / "tasks.py"])
        assert len(surface.endpoints) == 2
        assert all(ep.method == "TASK" for ep in surface.endpoints)
        names = {ep.handler for ep in surface.endpoints}
        assert "send_email" in names
        assert "process_order" in names


class TestOpenAPISpec:
    def test_openapi_json(self, tmp_path: Path):
        spec = {
            "openapi": "3.0.0",
            "paths": {
                "/pets": {
                    "get": {"operationId": "listPets", "summary": "List all pets"},
                    "post": {"operationId": "createPet"},
                },
                "/pets/{petId}": {
                    "get": {"operationId": "showPetById"},
                },
            },
        }
        (tmp_path / "openapi.json").write_text(json.dumps(spec))
        surface = extract_api_surface(tmp_path, [])
        assert len(surface.endpoints) == 3
        assert surface.framework == "OpenAPI"


class TestEmptyRepo:
    def test_no_endpoints(self, tmp_path: Path):
        (tmp_path / "utils.py").write_text("def helper(): pass")
        surface = extract_api_surface(tmp_path, [tmp_path / "utils.py"])
        assert len(surface.endpoints) == 0
        assert surface.framework is None
