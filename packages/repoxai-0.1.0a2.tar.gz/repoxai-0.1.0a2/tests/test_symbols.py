"""Tests for symbol graph extraction (tree-sitter AST)."""

from __future__ import annotations

from pathlib import Path

from repox.extractors.symbols import extract_symbols
from repox.models import SymbolKind


class TestPythonExtraction:
    def test_extracts_functions(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("""\
def hello(name: str) -> str:
    \"\"\"Greet someone.\"\"\"
    return f"Hello {name}"

def _private_helper():
    pass
""")
        graph = extract_symbols(tmp_path, [tmp_path / "app.py"])
        funcs = [s for s in graph.symbols if s.kind == SymbolKind.FUNCTION]
        assert len(funcs) == 2

        hello = next(s for s in funcs if s.name == "hello")
        assert hello.return_type == "str"
        assert hello.docstring == "Greet someone."
        assert hello.visibility == "public"
        assert len(hello.parameters) == 1
        assert hello.parameters[0].name == "name"
        assert hello.parameters[0].type_annotation == "str"

        helper = next(s for s in funcs if s.name == "_private_helper")
        assert helper.visibility == "protected"

    def test_extracts_classes(self, tmp_path: Path):
        (tmp_path / "models.py").write_text("""\
class BaseModel:
    pass

class User(BaseModel):
    \"\"\"A user entity.\"\"\"
    def __init__(self, name: str):
        self.name = name

    async def save(self) -> None:
        pass
""")
        graph = extract_symbols(tmp_path, [tmp_path / "models.py"])

        classes = [s for s in graph.symbols if s.kind == SymbolKind.CLASS]
        assert len(classes) == 2

        user = next(s for s in classes if s.name == "User")
        assert "BaseModel" in user.base_classes
        assert user.docstring == "A user entity."

        methods = [s for s in graph.symbols if s.kind == SymbolKind.METHOD]
        assert len(methods) == 2

        save = next(s for s in methods if s.name == "save")
        assert save.parent_scope == "User"
        assert save.return_type == "None"

    def test_extracts_decorators(self, tmp_path: Path):
        (tmp_path / "routes.py").write_text("""\
class Router:
    @staticmethod
    def validate():
        pass

    @property
    def name(self):
        return self._name
""")
        graph = extract_symbols(tmp_path, [tmp_path / "routes.py"])
        validate = next((s for s in graph.symbols if s.name == "validate"), None)
        assert validate is not None
        assert validate.is_static is True
        assert "staticmethod" in validate.decorators

    def test_extracts_constants(self, tmp_path: Path):
        (tmp_path / "config.py").write_text("""\
TIMEOUT = 30
MAX_RETRIES = 3
some_var = "not a constant"
""")
        graph = extract_symbols(tmp_path, [tmp_path / "config.py"])
        consts = [s for s in graph.symbols if s.kind == SymbolKind.CONSTANT]
        names = [c.name for c in consts]
        assert "TIMEOUT" in names
        assert "MAX_RETRIES" in names
        assert "some_var" not in names

    def test_extracts_async_functions(self, tmp_path: Path):
        (tmp_path / "service.py").write_text("""\
async def fetch_data(url: str) -> dict:
    pass

def sync_func():
    pass
""")
        graph = extract_symbols(tmp_path, [tmp_path / "service.py"])
        fetch = next(s for s in graph.symbols if s.name == "fetch_data")
        assert fetch.is_async is True

        sync = next(s for s in graph.symbols if s.name == "sync_func")
        assert sync.is_async is False

    def test_files_parsed_count(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("def foo(): pass")
        (tmp_path / "b.py").write_text("def bar(): pass")
        graph = extract_symbols(tmp_path, [tmp_path / "a.py", tmp_path / "b.py"])
        assert graph.files_parsed == 2
        assert "python" in graph.languages_parsed

    def test_default_parameters(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("""\
def create_user(name: str, active: bool = True, role: str = "user"):
    pass
""")
        graph = extract_symbols(tmp_path, [tmp_path / "app.py"])
        func = graph.symbols[0]
        assert len(func.parameters) == 3
        assert func.parameters[0].name == "name"
        assert func.parameters[1].name == "active"
        assert func.parameters[1].default == "True"
        assert func.parameters[2].default == '"user"'


class TestJavaScriptExtraction:
    def test_extracts_functions(self, tmp_path: Path):
        (tmp_path / "app.js").write_text("""\
function greet(name) {
    return `Hello ${name}`;
}

async function fetchData(url) {
    return await fetch(url);
}
""")
        graph = extract_symbols(tmp_path, [tmp_path / "app.js"])
        funcs = [s for s in graph.symbols if s.kind == SymbolKind.FUNCTION]
        assert len(funcs) == 2

        greet = next(s for s in funcs if s.name == "greet")
        assert greet.is_async is False

        fetch_fn = next(s for s in funcs if s.name == "fetchData")
        assert fetch_fn.is_async is True

    def test_extracts_classes(self, tmp_path: Path):
        (tmp_path / "models.js").write_text("""\
class Animal {
    constructor(name) {
        this.name = name;
    }

    speak() {
        return `${this.name} makes a sound`;
    }

    static create(name) {
        return new Animal(name);
    }
}

class Dog extends Animal {
    speak() {
        return `${this.name} barks`;
    }
}
""")
        graph = extract_symbols(tmp_path, [tmp_path / "models.js"])
        classes = [s for s in graph.symbols if s.kind == SymbolKind.CLASS]
        assert len(classes) == 2

        dog = next(s for s in classes if s.name == "Dog")
        assert "Animal" in dog.base_classes

        methods = [s for s in graph.symbols if s.kind == SymbolKind.METHOD]
        assert any(m.name == "speak" for m in methods)

        create = next(s for s in methods if s.name == "create")
        assert create.is_static is True

    def test_extracts_arrow_functions(self, tmp_path: Path):
        (tmp_path / "utils.js").write_text("""\
const add = (a, b) => a + b;
const fetchUser = async (id) => {
    return await db.get(id);
};
const MAX_SIZE = 100;
""")
        graph = extract_symbols(tmp_path, [tmp_path / "utils.js"])
        funcs = [s for s in graph.symbols if s.kind == SymbolKind.FUNCTION]
        assert any(f.name == "add" for f in funcs)
        assert any(f.name == "fetchUser" for f in funcs)

        fetch_user = next(s for s in funcs if s.name == "fetchUser")
        assert fetch_user.is_async is True


class TestTypeScriptExtraction:
    def test_extracts_interfaces(self, tmp_path: Path):
        (tmp_path / "types.ts").write_text("""\
interface User {
    id: number;
    name: string;
}

interface Admin extends User {
    permissions: string[];
}

type UserId = number;

enum Role {
    Admin,
    User,
    Guest
}
""")
        graph = extract_symbols(tmp_path, [tmp_path / "types.ts"])
        interfaces = [s for s in graph.symbols if s.kind == SymbolKind.INTERFACE]
        assert len(interfaces) == 2

        admin = next(s for s in interfaces if s.name == "Admin")
        assert "User" in admin.base_classes

        types = [s for s in graph.symbols if s.kind == SymbolKind.TYPE]
        assert any(t.name == "UserId" for t in types)

        enums = [s for s in graph.symbols if s.kind == SymbolKind.ENUM]
        assert any(e.name == "Role" for e in enums)


class TestGoExtraction:
    def test_extracts_functions_and_structs(self, tmp_path: Path):
        (tmp_path / "main.go").write_text("""\
package main

type User struct {
    Name string
    Age  int
}

type Repository interface {
    FindByID(id int) (*User, error)
}

func NewUser(name string) *User {
    return &User{Name: name}
}

func (u *User) Greet() string {
    return "Hello, " + u.Name
}

func privateHelper() {}
""")
        graph = extract_symbols(tmp_path, [tmp_path / "main.go"])

        classes = [s for s in graph.symbols if s.kind == SymbolKind.CLASS]
        assert any(c.name == "User" for c in classes)

        interfaces = [s for s in graph.symbols if s.kind == SymbolKind.INTERFACE]
        assert any(i.name == "Repository" for i in interfaces)

        funcs = [s for s in graph.symbols if s.kind == SymbolKind.FUNCTION]
        assert any(f.name == "NewUser" for f in funcs)
        new_user = next(f for f in funcs if f.name == "NewUser")
        assert new_user.visibility == "public"

        methods = [s for s in graph.symbols if s.kind == SymbolKind.METHOD]
        assert any(m.name == "Greet" for m in methods)
        greet = next(m for m in methods if m.name == "Greet")
        assert greet.parent_scope == "User"

        private = next(f for f in funcs if f.name == "privateHelper")
        assert private.visibility == "private"


class TestRustExtraction:
    def test_extracts_structs_and_impls(self, tmp_path: Path):
        (tmp_path / "lib.rs").write_text("""\
pub struct Config {
    pub host: String,
    port: u16,
}

pub enum Status {
    Active,
    Inactive,
}

pub trait Service {
    fn start(&self);
}

impl Config {
    pub fn new(host: String, port: u16) -> Self {
        Config { host, port }
    }

    fn validate(&self) -> bool {
        !self.host.is_empty()
    }
}

pub async fn serve(config: Config) {
    todo!()
}
""")
        graph = extract_symbols(tmp_path, [tmp_path / "lib.rs"])

        classes = [s for s in graph.symbols if s.kind == SymbolKind.CLASS]
        assert any(c.name == "Config" for c in classes)

        enums = [s for s in graph.symbols if s.kind == SymbolKind.ENUM]
        assert any(e.name == "Status" for e in enums)

        traits = [s for s in graph.symbols if s.kind == SymbolKind.INTERFACE]
        assert any(t.name == "Service" for t in traits)

        methods = [s for s in graph.symbols if s.kind == SymbolKind.METHOD]
        new_fn = next(m for m in methods if m.name == "new")
        assert new_fn.parent_scope == "Config"
        assert new_fn.visibility == "public"

        validate = next(m for m in methods if m.name == "validate")
        assert validate.visibility == "private"

        funcs = [s for s in graph.symbols if s.kind == SymbolKind.FUNCTION]
        serve = next(f for f in funcs if f.name == "serve")
        assert serve.is_async is True
        assert serve.visibility == "public"


class TestMultiLanguage:
    def test_mixed_repo(self, tmp_path: Path):
        (tmp_path / "app.py").write_text("def main(): pass")
        (tmp_path / "utils.js").write_text("function helper() {}")
        (tmp_path / "types.ts").write_text("interface Config { port: number; }")

        files = [tmp_path / "app.py", tmp_path / "utils.js", tmp_path / "types.ts"]
        graph = extract_symbols(tmp_path, files)

        assert graph.files_parsed == 3
        assert "python" in graph.languages_parsed
        assert "javascript" in graph.languages_parsed
        assert "typescript" in graph.languages_parsed

    def test_skips_unsupported_files(self, tmp_path: Path):
        (tmp_path / "readme.md").write_text("# Hello")
        (tmp_path / "data.csv").write_text("a,b,c")
        graph = extract_symbols(tmp_path, [tmp_path / "readme.md", tmp_path / "data.csv"])
        assert graph.files_parsed == 0
        assert len(graph.symbols) == 0


class TestEmptyFiles:
    def test_empty_file(self, tmp_path: Path):
        (tmp_path / "empty.py").write_text("")
        graph = extract_symbols(tmp_path, [tmp_path / "empty.py"])
        assert graph.files_parsed == 1
        assert len(graph.symbols) == 0
