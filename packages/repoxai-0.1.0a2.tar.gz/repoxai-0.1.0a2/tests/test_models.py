"""Tests for the RepoProfile data models."""

from datetime import datetime

from repox.models import (
    ArchitectureMap,
    ArchPattern,
    CodingConventions,
    CustomRules,
    Dependency,
    DirectoryLabel,
    RepoProfile,
    Symbol,
    SymbolKind,
    TechStack,
)


class TestTechStack:
    def test_defaults(self):
        ts = TechStack()
        assert ts.primary_language is None
        assert ts.dependencies == []
        assert ts.config_files_parsed == []

    def test_with_values(self):
        ts = TechStack(
            primary_language="Python",
            language_version="3.12",
            framework="FastAPI",
            dependencies=[Dependency(name="fastapi", version=">=0.100")],
        )
        assert ts.primary_language == "Python"
        assert ts.framework == "FastAPI"
        assert len(ts.dependencies) == 1
        assert ts.dependencies[0].name == "fastapi"


class TestArchitectureMap:
    def test_defaults(self):
        arch = ArchitectureMap()
        assert arch.pattern == ArchPattern.UNKNOWN
        assert arch.confidence == 0.0

    def test_with_labels(self):
        arch = ArchitectureMap(
            pattern=ArchPattern.LAYERED,
            confidence=0.85,
            directory_labels=[
                DirectoryLabel(path="src/routes", label="api", description="API handlers"),
                DirectoryLabel(path="src/services", label="service"),
            ],
        )
        assert arch.pattern == ArchPattern.LAYERED
        assert len(arch.directory_labels) == 2


class TestSymbol:
    def test_function_symbol(self):
        sym = Symbol(
            name="get_user",
            kind=SymbolKind.FUNCTION,
            file_path="src/services/user.py",
            line_start=10,
            line_end=25,
            is_async=True,
            return_type="User",
        )
        assert sym.name == "get_user"
        assert sym.kind == SymbolKind.FUNCTION
        assert sym.is_async is True
        assert sym.exported is True  # default


class TestRepoProfile:
    def test_defaults(self):
        profile = RepoProfile(repo_path="/tmp/test", repo_name="test")
        assert profile.repo_name == "test"
        assert isinstance(profile.tech_stack, TechStack)
        assert isinstance(profile.architecture, ArchitectureMap)
        assert isinstance(profile.custom_rules, CustomRules)
        assert isinstance(profile.last_scanned, datetime)

    def test_serialization_roundtrip(self):
        profile = RepoProfile(
            repo_path="/tmp/test",
            repo_name="test",
            tech_stack=TechStack(
                primary_language="Python",
                framework="FastAPI",
            ),
            architecture=ArchitectureMap(
                pattern=ArchPattern.LAYERED,
                confidence=0.85,
            ),
        )

        json_str = profile.model_dump_json()
        loaded = RepoProfile.model_validate_json(json_str)

        assert loaded.repo_name == "test"
        assert loaded.tech_stack.primary_language == "Python"
        assert loaded.tech_stack.framework == "FastAPI"
        assert loaded.architecture.pattern == ArchPattern.LAYERED
        assert loaded.architecture.confidence == 0.85
