# Release Process

## Setup (One-time)

### Configure PyPI Trusted Publishing

This project uses PyPI's [Trusted Publishing](https://docs.pypi.org/trusted-publishers/) for secure, token-free publishing from GitHub Actions.

1. **Create a PyPI account** if you don't have one: https://pypi.org/account/register/

2. **Add GitHub as a Trusted Publisher:**
   - Go to https://pypi.org/manage/account/publishing/
   - Click "Add a new pending publisher"
   - Fill in:
     - **PyPI Project Name:** `repoxai`
     - **Owner:** `kmandana`
     - **Repository:** `RepoX`
     - **Workflow name:** `publish.yml`
     - **Environment name:** `pypi`
   - Click "Add"

3. **Create the `pypi` environment in GitHub:**
   - Go to https://github.com/kmandana/RepoX/settings/environments
   - Create environment named `pypi`

4. **Done!** No API tokens needed. GitHub Actions will authenticate using OIDC.

## Making a Release

We use `bump-my-version` to automate version bumping, committing, and tagging.

### Quick Release

```bash
# Bump pre-release (0.1.0a1 -> 0.1.0a2)
bump-my-version bump build
git push && git push --tags

# Bump to stable (0.1.0a1 -> 0.1.0)
bump-my-version bump release
git push && git push --tags

# Bump patch version (0.1.0 -> 0.1.1)
bump-my-version bump patch
git push && git push --tags

# Bump minor version (0.1.0 -> 0.2.0)
bump-my-version bump minor
git push && git push --tags

# Bump major version (0.1.0 -> 1.0.0)
bump-my-version bump major
git push && git push --tags
```

### What `bump-my-version` Does

When you run `bump-my-version bump`:
1. Updates version in `pyproject.toml`
2. Updates version in `src/repox/__init__.py`
3. Creates git commit: `chore: bump version X.Y.Z -> A.B.C`
4. Creates git tag: `vA.B.C`
5. You manually push (for safety)

### GitHub Actions Does the Rest

On tag push, the workflow automatically:
1. Builds the package
2. Publishes to PyPI
3. Creates a GitHub Release
4. Signs artifacts with Sigstore

### Verify

- PyPI: https://pypi.org/project/repoxai/
- GitHub Releases: https://github.com/kmandana/RepoX/releases

## Version Numbering

We follow [PEP 440](https://peps.python.org/pep-0440/):

- **Pre-releases:** `X.Y.ZaN` (alpha), `X.Y.ZbN` (beta), `X.Y.ZrcN` (release candidate)
- **Stable releases:** `X.Y.Z`

Install pre-releases with:
```bash
pip install --pre repoxai
```

## Testing Before Release

```bash
uv build
cd /tmp && python -m venv test-env && source test-env/bin/activate
pip install /path/to/RepoX/dist/repoxai-*.whl
repox --help
```
