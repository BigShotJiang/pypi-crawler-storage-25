"""Public API — the clean interface for any tool to use Repox.

Usage:
    from repox import scan, generate_context, get_profile, serve

    # Scan a repo (incremental by default)
    profile = scan("/path/to/repo")

    # Generate task-aware context brief
    context = generate_context(
        "/path/to/repo",
        task="Fix the login bug in auth.py",
        task_type="bug_fix",
        target_files=["src/auth.py"],
    )

    # Load existing profile without re-scanning
    profile = get_profile("/path/to/repo")

    # Start MCP server
    serve("/path/to/repo")
"""

from __future__ import annotations

from pathlib import Path

from repox.models import RepoProfile


def scan(
    repo_path: str | Path = ".",
    *,
    force: bool = False,
) -> RepoProfile:
    """Scan a repository and build/update the codebase profile.

    Incremental by default — only re-processes changed files.
    Use force=True to rescan everything.

    Args:
        repo_path: Path to the git repository root. Defaults to cwd.
        force: If True, ignore cached hashes and rescan all files.

    Returns:
        Complete RepoProfile with all 13 dimensions.
    """
    from repox.scanner import scan as _scan

    return _scan(Path(repo_path).resolve(), force=force)


def get_profile(repo_path: str | Path = ".") -> RepoProfile | None:
    """Load an existing profile without scanning.

    Returns None if no profile exists (run scan() first).
    """
    from repox.persistence import load_profile_json

    return load_profile_json(Path(repo_path).resolve())


def generate_context(
    repo_path: str | Path = ".",
    *,
    task: str,
    task_type: str = "general",
    target_files: list[str] | None = None,
    model: str | None = None,
    max_tokens: int = 4000,
    save: bool = True,
) -> str:
    """Generate a task-aware context brief from the repo profile.

    If no profile exists, runs a scan first. Uses LLM when available,
    falls back to structured template.

    Args:
        repo_path: Path to the git repository root.
        task: Description of what the coding agent is about to do.
        task_type: One of "bug_fix", "new_feature", "refactor", "general".
        target_files: Specific files the task will touch.
        model: LLM model override (e.g. "anthropic/claude-sonnet-4-20250514").
        max_tokens: Token budget for the context brief.
        save: If True, writes .repox/context.md alongside returning the string.

    Returns:
        Markdown context brief as a string.
    """
    from repox.context import TaskContext, generate_context as _gen, save_context
    from repox.persistence import load_profile_json

    path = Path(repo_path).resolve()
    profile = load_profile_json(path)

    if profile is None:
        profile = scan(path)

    task_ctx = TaskContext(
        description=task,
        task_type=task_type,
        target_files=target_files or [],
    )

    brief = _gen(profile, task_ctx, model=model, max_tokens=max_tokens)

    if save:
        save_context(brief, path)

    return brief


def serve(repo_path: str | Path = ".") -> None:
    """Start the MCP server, exposing Repox intelligence as tools.

    Any MCP-compatible agent (Claude Code, Cursor, etc.) can connect:

        {
            "mcpServers": {
                "repox": {
                    "command": "repox",
                    "args": ["serve"]
                }
            }
        }
    """
    from repox.server import run_server

    run_server(Path(repo_path).resolve())


def get_context_for_files(
    repo_path: str | Path = ".",
    *,
    files: list[str],
    model: str | None = None,
) -> str:
    """Quick helper — generate context focused on specific files.

    Useful for pre-commit hooks, CI pipelines, or IDE integrations.
    """
    return generate_context(
        repo_path,
        task=f"Working on: {', '.join(files)}",
        task_type="general",
        target_files=files,
        model=model,
    )
