"""Context generation engine — LLM-synthesized task-aware briefs."""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field

from repox.models import RepoProfile
from repox.persistence import get_repox_dir


class TaskContext(BaseModel):
    """Describes the task the coding agent is about to perform."""

    description: str
    task_type: str = "general"  # bug_fix, new_feature, refactor, general
    target_files: list[str] = Field(default_factory=list)


CONTEXT_MD = "context.md"

# Token budget priorities (descending). We include sections in order until budget is reached.
SECTION_PRIORITY = [
    "custom_rules",
    "architecture",
    "conventions",
    "dependencies",
    "hotspots",
    "design_patterns",
    "data_models",
    "api_surface",
    "test_patterns",
    "infrastructure",
    "knowledge_map",
]


def generate_context(
    profile: RepoProfile,
    task: TaskContext,
    *,
    model: str | None = None,
    max_tokens: int = 4000,
) -> str:
    """Generate a task-aware context brief from the profile.

    If an LLM is available, produces a synthesized brief.
    Otherwise, falls back to a structured template.
    """
    # Build structured sections from profile
    sections = _build_sections(profile, task)

    # Try LLM synthesis
    try:
        return _llm_synthesize(profile, task, sections, model=model)
    except Exception:
        # Fallback to template
        return _template_render(profile, task, sections, max_tokens=max_tokens)


def save_context(context: str, repo_path: Path) -> Path:
    """Write context.md to .repox/ directory."""
    repox_dir = get_repox_dir(repo_path)
    repox_dir.mkdir(exist_ok=True)
    out = repox_dir / CONTEXT_MD
    out.write_text(context)
    return out


def _build_sections(profile: RepoProfile, task: TaskContext) -> dict[str, str]:
    """Build structured text sections from profile data, filtered by task relevance."""
    sections: dict[str, str] = {}

    # Custom rules — always include (highest priority)
    if profile.custom_rules.rules:
        rules_text = []
        for rule in profile.custom_rules.rules:
            content = rule.content[:500] if len(rule.content) > 500 else rule.content
            rules_text.append(f"**{rule.source.value}:**\n{content}")
        sections["custom_rules"] = "\n\n".join(rules_text)

    # Architecture
    arch = profile.architecture
    if arch.pattern.value != "unknown":
        lines = [f"Pattern: {arch.pattern.value} (confidence: {arch.confidence:.0%})"]
        if arch.entry_points:
            lines.append(f"Entry points: {', '.join(arch.entry_points)}")
        if arch.directory_labels:
            for dl in arch.directory_labels[:10]:
                desc = f" — {dl.description}" if dl.description else ""
                lines.append(f"  {dl.path} → {dl.label}{desc}")
        if arch.layering_rules:
            lines.append("Layering rules:")
            for r in arch.layering_rules:
                arrow = "→" if r.allowed else "✗→"
                lines.append(f"  {r.source} {arrow} {r.target}")
        sections["architecture"] = "\n".join(lines)

    # Conventions
    if profile.conventions.conventions:
        conv_lines = []
        for c in profile.conventions.conventions[:15]:
            examples = f" (e.g., {', '.join(c.examples[:2])})" if c.examples else ""
            conv_lines.append(f"- {c.category}: {c.rule}{examples}")
        sections["conventions"] = "\n".join(conv_lines)

    # Dependencies — relevant files for task
    if task.target_files and profile.dependencies.import_edges:
        relevant_edges = []
        for edge in profile.dependencies.import_edges:
            if any(t in edge.source_file or t in edge.target_file for t in task.target_files):
                relevant_edges.append(f"{edge.source_file} → {edge.target_file}")
        if relevant_edges:
            sections["dependencies"] = "\n".join(relevant_edges[:20])

    if not task.target_files and profile.dependencies.symbol_ranks:
        top_files = [f"{r.symbol} (PageRank: {r.pagerank:.4f})" for r in profile.dependencies.symbol_ranks[:10]]
        sections["dependencies"] = "Key files by centrality:\n" + "\n".join(top_files)

    # Hotspots
    if profile.hotspots.hotspots:
        hot_lines = [f"- {h.file_path} (freq={h.change_frequency}, churn={h.churn}, score={h.score})"
                     for h in profile.hotspots.hotspots[:10]]
        sections["hotspots"] = "\n".join(hot_lines)

    # Design patterns
    if profile.design_patterns.patterns:
        by_pattern: dict[str, list[str]] = {}
        for p in profile.design_patterns.patterns:
            loc = p.participants[0] if p.participants else p.file_path
            by_pattern.setdefault(p.pattern, []).append(loc)
        pat_lines = [f"- {name}: {', '.join(locs[:3])}" for name, locs in sorted(by_pattern.items())]
        sections["design_patterns"] = "\n".join(pat_lines)

    # Data models
    if profile.data_models.entities:
        dm_lines = []
        for e in profile.data_models.entities[:10]:
            fields = ", ".join(f.name for f in e.fields[:5])
            orm_tag = f" ({e.orm})" if e.orm else ""
            dm_lines.append(f"- {e.name}{orm_tag}: {fields}")
        sections["data_models"] = "\n".join(dm_lines)

    # API surface
    if profile.api_surface.endpoints:
        api_lines = []
        for ep in profile.api_surface.endpoints[:15]:
            api_lines.append(f"- {ep.method} {ep.path} → {ep.handler}")
        fw = f" ({profile.api_surface.framework})" if profile.api_surface.framework else ""
        sections["api_surface"] = f"Framework{fw}:\n" + "\n".join(api_lines)

    # Test patterns
    tp = profile.test_patterns
    if tp.framework:
        tp_lines = [f"Framework: {tp.framework}"]
        if tp.file_pattern:
            tp_lines.append(f"File pattern: {tp.file_pattern}")
        if tp.naming_convention:
            tp_lines.append(f"Naming: {tp.naming_convention}")
        if tp.fixture_approach:
            tp_lines.append(f"Fixtures: {tp.fixture_approach}")
        if tp.mock_library:
            tp_lines.append(f"Mocking: {tp.mock_library}")
        sections["test_patterns"] = "\n".join(tp_lines)

    # Infrastructure
    if profile.infrastructure.services:
        infra_lines = [f"- {s.name}" + (f" ({s.image})" if s.image else "")
                       for s in profile.infrastructure.services[:10]]
        if profile.infrastructure.deployment_targets:
            infra_lines.append(f"Targets: {', '.join(profile.infrastructure.deployment_targets)}")
        sections["infrastructure"] = "\n".join(infra_lines)

    # Knowledge map
    if profile.knowledge_map.file_ownerships:
        islands = [o for o in profile.knowledge_map.file_ownerships if o.is_knowledge_island]
        if islands:
            km_lines = [f"- {o.file_path} ({o.primary_author}, {o.contribution_pct}% — knowledge island)"
                        for o in islands[:10]]
            sections["knowledge_map"] = "Knowledge islands:\n" + "\n".join(km_lines)

    return sections


def _llm_synthesize(
    profile: RepoProfile,
    task: TaskContext,
    sections: dict[str, str],
    *,
    model: str | None = None,
) -> str:
    """Use LLM to produce a structured advisory brief with confidence tags."""
    from repox.llm import complete

    # Build the prompt with structured data
    profile_data = ""
    for key in SECTION_PRIORITY:
        if key in sections:
            header = key.replace("_", " ").title()
            profile_data += f"\n## {header}\n{sections[key]}\n"

    system = (
        "You are a senior developer producing an advisory brief for a coding agent. "
        "You are advising, not instructing — the agent's own LLM may be more capable "
        "than you. Frame everything as recommendations, not commands.\n\n"
        "For each section you include, tag it with a confidence level:\n"
        "- (high confidence) — derived from concrete data in the profile\n"
        "- (medium confidence — verify these) — inferred from patterns, agent should check\n"
        "- (low confidence — assess independently) — speculative, agent should decide\n\n"
        "Only include sections that are relevant to the task. Skip sections that add no value. "
        "Keep the total brief under 2000 tokens. Use markdown."
    )

    prompt = f"""Task: {task.description}
Task type: {task.task_type}
{f"Target files: {', '.join(task.target_files)}" if task.target_files else ""}

Repository: {profile.repo_name}
Tech: {profile.tech_stack.primary_language or 'Unknown'}{f' / {profile.tech_stack.framework}' if profile.tech_stack.framework else ''}

{profile_data}

Write a structured advisory brief using ONLY the sections relevant to this task.
Available sections (include only if useful):

## Recommendation (confidence)
What to do and the recommended high-level approach.

## Files to Change (confidence)
Which files to modify and why.

## Dependencies Affected (confidence)
What imports or depends on the target files. What might break.

## Risks & Side Effects (confidence)
Hotspots, knowledge islands, side effects, things that could go wrong.

## Testing Strategy (confidence)
How to test the changes, matching existing project patterns.

## Conventions to Follow (confidence)
Project-specific rules and patterns the changes should follow.
"""

    return complete(prompt, system=system, model=model)


def _template_render(
    profile: RepoProfile,
    task: TaskContext,
    sections: dict[str, str],
    *,
    max_tokens: int = 4000,
) -> str:
    """Fallback template rendering when LLM is unavailable."""
    lines = [
        f"# Context Brief: {profile.repo_name}",
        f"**Task:** {task.description}",
        f"**Type:** {task.task_type}",
        "",
    ]

    if task.target_files:
        lines.append(f"**Target files:** {', '.join(task.target_files)}")
        lines.append("")

    ts = profile.tech_stack
    lines.append(f"**Tech:** {ts.primary_language or 'Unknown'}"
                 f"{f' / {ts.framework}' if ts.framework else ''}"
                 f"{f' / {ts.orm}' if ts.orm else ''}")
    lines.append("")

    # Add sections in priority order, tracking rough token count (4 chars ≈ 1 token)
    char_budget = max_tokens * 4
    char_count = sum(len(l) for l in lines)

    for key in SECTION_PRIORITY:
        if key not in sections:
            continue
        header = key.replace("_", " ").title()
        section_text = f"## {header}\n{sections[key]}\n"
        section_chars = len(section_text)

        if char_count + section_chars > char_budget:
            break

        lines.append(section_text)
        char_count += section_chars

    return "\n".join(lines) + "\n"
