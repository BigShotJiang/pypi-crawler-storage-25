"""Historical learning — compound intelligence from interactions.

Records rules learned from agent interactions, PR outcomes, and review
patterns. Rules gain confidence through reinforcement and decay when
not reinforced or when contradicted.

Usage:
    from repox.learning import record_learning, get_active_rules, decay_stale_rules

    # Record a learned convention
    record_learning(
        repo_path="/path/to/repo",
        rule="Use tenacity for retries instead of manual loops",
        category="error_handling",
        source="interaction",
        context="PR #42 review comment",
    )

    # Get high-confidence learned rules
    rules = get_active_rules("/path/to/repo", min_confidence=0.6)

    # Run periodic decay (e.g. in CI)
    decay_stale_rules("/path/to/repo", stale_months=6)
"""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

from repox.models import HistoricalLearning, LearnedRule, LearnedRuleSource
from repox.persistence import load_profile_json, save_profile_json


def record_learning(
    repo_path: str | Path,
    *,
    rule: str,
    category: str,
    source: str = "interaction",
    context: str | None = None,
    examples: list[str] | None = None,
) -> LearnedRule:
    """Record a new learned rule or reinforce an existing one.

    If a rule with similar content already exists, reinforces it
    instead of creating a duplicate.

    Args:
        repo_path: Path to the repository.
        rule: The rule text (e.g. "Use tenacity for retries").
        category: Category (naming, error_handling, testing, etc.).
        source: One of: interaction, pr_outcome, review_pattern, fix_pattern.
        context: Optional context about where this was learned.
        examples: Optional code examples.

    Returns:
        The created or updated LearnedRule.
    """
    path = Path(repo_path).resolve()
    profile = load_profile_json(path)
    if profile is None:
        raise FileNotFoundError(f"No profile at {path}. Run `repox scan` first.")

    learning = profile.learning
    source_enum = LearnedRuleSource(source)

    # Check for existing similar rule
    existing = _find_similar_rule(learning.learned_rules, rule, category)

    if existing:
        # Reinforce
        existing.reinforcement_count += 1
        existing.confidence = min(1.0, existing.confidence + 0.1)
        existing.last_reinforced = datetime.now()
        if examples:
            existing.examples.extend(examples)
            existing.examples = existing.examples[:10]  # cap examples
        learned = existing
    else:
        # Create new
        learned = LearnedRule(
            rule=rule,
            category=category,
            source=source_enum,
            confidence=0.5,
            context=context,
            examples=examples or [],
        )
        learning.learned_rules.append(learned)

    learning.total_interactions += 1
    save_profile_json(profile, path)
    return learned


def contradict_learning(
    repo_path: str | Path,
    *,
    rule: str,
    category: str,
) -> bool:
    """Record that a learned rule was contradicted.

    Reduces confidence. If confidence drops to 0, removes the rule.

    Returns:
        True if the rule was found and updated, False if not found.
    """
    path = Path(repo_path).resolve()
    profile = load_profile_json(path)
    if profile is None:
        return False

    existing = _find_similar_rule(profile.learning.learned_rules, rule, category)
    if not existing:
        return False

    existing.contradiction_count += 1
    existing.confidence = max(0.0, existing.confidence - 0.2)

    # Remove if confidence is zero
    if existing.confidence <= 0:
        profile.learning.learned_rules.remove(existing)

    save_profile_json(profile, path)
    return True


def get_active_rules(
    repo_path: str | Path,
    *,
    min_confidence: float = 0.4,
    category: str | None = None,
) -> list[LearnedRule]:
    """Get learned rules above a confidence threshold.

    Args:
        repo_path: Path to the repository.
        min_confidence: Minimum confidence to include (0.0-1.0).
        category: Optional category filter.

    Returns:
        List of active learned rules, sorted by confidence descending.
    """
    path = Path(repo_path).resolve()
    profile = load_profile_json(path)
    if profile is None:
        return []

    rules = profile.learning.learned_rules
    filtered = [r for r in rules if r.confidence >= min_confidence]
    if category:
        filtered = [r for r in filtered if r.category == category]

    return sorted(filtered, key=lambda r: r.confidence, reverse=True)


def decay_stale_rules(
    repo_path: str | Path,
    *,
    stale_months: int = 6,
    decay_amount: float = 0.15,
) -> int:
    """Reduce confidence of rules not reinforced recently.

    Call periodically (e.g. monthly in CI) to keep learned rules fresh.

    Args:
        repo_path: Path to the repository.
        stale_months: Rules not reinforced in this many months get decayed.
        decay_amount: How much to reduce confidence per decay cycle.

    Returns:
        Number of rules decayed.
    """
    path = Path(repo_path).resolve()
    profile = load_profile_json(path)
    if profile is None:
        return 0

    cutoff = datetime.now() - timedelta(days=stale_months * 30)
    decayed = 0

    for rule in list(profile.learning.learned_rules):
        if rule.last_reinforced < cutoff:
            rule.confidence = max(0.0, rule.confidence - decay_amount)
            decayed += 1
            if rule.confidence <= 0:
                profile.learning.learned_rules.remove(rule)

    if decayed:
        save_profile_json(profile, path)

    return decayed


def _find_similar_rule(
    rules: list[LearnedRule], rule_text: str, category: str
) -> LearnedRule | None:
    """Find an existing rule with similar content in the same category."""
    rule_lower = rule_text.lower().strip()
    for r in rules:
        if r.category == category and r.rule.lower().strip() == rule_lower:
            return r
    return None
