"""LLM integration layer — one model, every provider, via litellm."""

from __future__ import annotations

import os
import tomllib
from pathlib import Path

import litellm

# Priority-ordered: first key found wins.
_PROVIDER_MAP: list[tuple[str, str]] = [
    ("ANTHROPIC_API_KEY", "anthropic/claude-opus-4-6"),
    ("OPENAI_API_KEY", "openai/gpt-5.3"),
    ("GEMINI_API_KEY", "gemini/gemini-2.5-flash"),
]

_CONFIG_PATH = Path.home() / ".repox" / "config.toml"


class LLMConfigError(Exception):
    """Raised when no LLM model can be resolved."""


def _load_config_model() -> str | None:
    """Read model from ~/.repox/config.toml [llm] section if it exists."""
    if not _CONFIG_PATH.exists():
        return None
    with open(_CONFIG_PATH, "rb") as f:
        data = tomllib.load(f)
    return data.get("llm", {}).get("model")


def _detect_from_env() -> str:
    """Auto-detect best model from available API keys."""
    for env_var, model_string in _PROVIDER_MAP:
        if os.environ.get(env_var):
            return model_string
    raise LLMConfigError(
        "No LLM API key found. Set one of: "
        + ", ".join(k for k, _ in _PROVIDER_MAP)
        + "\nOr set REPOX_MODEL / --model to specify a model directly."
    )


def get_model(cli_override: str | None = None) -> str:
    """Resolve which model to use.

    Priority: cli_override > REPOX_MODEL env var > ~/.repox/config.toml > auto-detect.
    """
    if cli_override:
        return cli_override

    env_model = os.environ.get("REPOX_MODEL")
    if env_model:
        return env_model

    config_model = _load_config_model()
    if config_model:
        return config_model

    return _detect_from_env()


def complete(
    prompt: str,
    *,
    system: str | None = None,
    model: str | None = None,
) -> str:
    """Call the LLM and return the response text.

    Args:
        prompt: The user/main prompt.
        system: Optional system prompt.
        model: Optional model override (from CLI). If None, auto-detects.

    Returns:
        The assistant's response as a plain string.
    """
    resolved_model = get_model(cli_override=model)

    messages: list[dict[str, str]] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    response = litellm.completion(model=resolved_model, messages=messages)
    return response.choices[0].message.content
