"""Main scanner — orchestrates extraction and builds the RepoProfile."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from repox.extractors import is_test_file
from repox.extractors.api_surface import extract_api_surface
from repox.extractors.architecture import extract_architecture
from repox.extractors.conventions import extract_conventions, extract_test_patterns
from repox.extractors.custom_rules import extract_custom_rules
from repox.extractors.data_models import extract_data_models
from repox.extractors.dependencies import extract_dependencies
from repox.extractors.design_patterns import extract_design_patterns
from repox.extractors.hotspots import extract_hotspots, extract_knowledge_map
from repox.extractors.infrastructure import extract_infrastructure
from repox.extractors.symbols import extract_symbols
from repox.extractors.tech_stack import extract_tech_stack
from repox.models import RepoProfile
from repox.persistence import (
    get_changed_files,
    load_hashes,
    load_profile_json,
    save_hashes,
    save_profile_json,
    save_profile_md,
)

# Source file extensions we care about
SOURCE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs",
    ".java", ".kt", ".cs", ".rb", ".php", ".swift",
    ".c", ".cpp", ".h", ".hpp",
}

# Config file names we always want to track
CONFIG_FILES = {
    "pyproject.toml", "package.json", "go.mod", "Cargo.toml",
    "pom.xml", "build.gradle", "Gemfile", "composer.json",
    "docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml",
    "Dockerfile", "Makefile",
    "patchmate.yaml", "AGENTS.md", "CLAUDE.md", ".cursorrules",
    "schema.prisma", "openapi.json", "openapi.yaml", "swagger.json", "swagger.yaml",
}

SKIP_DIRS = {
    ".git", ".repox", ".venv", "venv", "env", ".env",
    "node_modules", "__pycache__", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", ".tox", "dist", "build", "target", ".next",
    ".nuxt", "coverage", ".coverage", "htmlcov", ".claude",
}


def collect_source_files(repo_path: Path) -> list[Path]:
    """Collect all source and config files in the repo."""
    files: list[Path] = []

    for item in _walk(repo_path):
        if item.is_file():
            if item.suffix in SOURCE_EXTENSIONS or item.name in CONFIG_FILES:
                files.append(item)

    return sorted(files)


def _walk(root: Path):
    """Walk directory tree, skipping ignored directories."""
    try:
        entries = sorted(root.iterdir(), key=lambda p: p.name)
    except PermissionError:
        return

    for entry in entries:
        if entry.is_dir():
            if entry.name not in SKIP_DIRS and not entry.name.startswith("."):
                yield from _walk(entry)
        else:
            yield entry



def scan(repo_path: Path, force: bool = False) -> RepoProfile:
    """Run a full or incremental scan and return the updated profile.

    Args:
        repo_path: Path to the git repository root.
        force: If True, re-scan everything regardless of hashes.

    Returns:
        Updated RepoProfile.
    """
    repo_path = repo_path.resolve()

    # Load existing profile for incremental updates
    existing_profile = None if force else load_profile_json(repo_path)

    # Hash-based change detection
    source_files = collect_source_files(repo_path)
    old_hashes = {} if force else load_hashes(repo_path)
    changed_files, new_hashes = get_changed_files(repo_path, source_files, old_hashes)

    is_incremental = existing_profile is not None and not force
    need_rescan = not is_incremental or len(changed_files) > 0

    if is_incremental and not need_rescan:
        # Nothing changed — return existing profile with updated timestamp
        existing_profile.last_scanned = datetime.now()
        save_profile_json(existing_profile, repo_path)
        return existing_profile

    profile = RepoProfile(
        repo_path=str(repo_path),
        repo_name=repo_path.name,
        last_scanned=datetime.now(),
    )

    # Separate production files from test files
    prod_files = [f for f in source_files if not is_test_file(f, repo_path)]

    # Dimension 1: Tech stack
    profile.tech_stack = extract_tech_stack(repo_path)

    # Dimension 2: Architecture map
    profile.architecture = extract_architecture(repo_path)

    # Dimension 3: Symbol graph (tree-sitter AST) — all files for completeness
    profile.symbols = extract_symbols(repo_path, source_files)

    # Dimension 4: Dependency graph + PageRank — all files (tests import prod)
    profile.dependencies = extract_dependencies(repo_path, source_files, profile.symbols)

    # Dimension 5: API surface map — production only (avoid test fixtures)
    profile.api_surface = extract_api_surface(repo_path, prod_files)

    # Dimension 6: Data model map — production only
    profile.data_models = extract_data_models(repo_path, prod_files)

    # Dimension 7: Design patterns — production only (avoid test class name matches)
    profile.design_patterns = extract_design_patterns(repo_path, prod_files, profile.symbols)

    # Dimensions 9+10: Coding conventions + test patterns
    profile.conventions = extract_conventions(repo_path, source_files, profile.symbols)
    profile.test_patterns = extract_test_patterns(repo_path, source_files, profile.symbols)

    # Dimension 8: Infrastructure topology
    profile.infrastructure = extract_infrastructure(repo_path, source_files)

    # Dimensions 11+12: Hotspot analysis + knowledge map (git history)
    profile.hotspots = extract_hotspots(repo_path, source_files)
    profile.knowledge_map = extract_knowledge_map(repo_path, source_files)

    # Behavioral intelligence (WebSocket events, auth, state machines, middleware, jobs, contracts)
    from repox.extractors.behavioral import extract_behavioral
    profile.behavioral = extract_behavioral(repo_path, prod_files, profile.symbols, profile.api_surface)

    # Security posture
    from repox.extractors.security import extract_security_posture
    profile.security = extract_security_posture(
        repo_path, prod_files, profile.api_surface, profile.behavioral, profile.symbols
    )

    # Dimension 13: Custom rules
    profile.custom_rules = extract_custom_rules(repo_path)

    # Layer 2: LLM interpretation (enriches architecture, conventions, patterns)
    try:
        from repox.extractors.llm_interpret import llm_interpret
        llm_interpret(profile)
    except Exception:
        pass  # LLM unavailable — static results still valid

    # Persist
    save_profile_json(profile, repo_path)
    save_profile_md(profile, repo_path)
    save_hashes(new_hashes, repo_path)

    return profile
