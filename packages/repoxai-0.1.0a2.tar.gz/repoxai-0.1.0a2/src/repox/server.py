"""MCP server — expose Repox intelligence as a single context tool."""

from __future__ import annotations

import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from repox.models import RepoProfile
from repox.persistence import load_profile_json, get_repox_dir, PROFILE_MD

mcp = FastMCP("repox", instructions="Repox — codebase intelligence for coding agents")

# Global profile state
_profile: RepoProfile | None = None
_repo_path: Path | None = None


def _get_profile() -> RepoProfile:
    """Get the loaded profile or raise."""
    if _profile is None:
        raise RuntimeError("No profile loaded. Run `repox scan` first.")
    return _profile


def load_profile(repo_path: str | Path) -> None:
    """Load a profile from disk into memory."""
    global _profile, _repo_path
    _repo_path = Path(repo_path)
    _profile = load_profile_json(_repo_path)
    if _profile is None:
        raise FileNotFoundError(f"No profile found at {repo_path}/.repox/profile.json — run `repox scan` first.")


def _get_full_profile() -> str:
    """Return the full profile.md content."""
    if _repo_path is None:
        raise RuntimeError("No profile loaded. Run `repox scan` first.")
    md_path = get_repox_dir(_repo_path) / PROFILE_MD
    if not md_path.exists():
        raise FileNotFoundError("No profile.md found. Run `repox scan` first.")
    return md_path.read_text()


@mcp.tool()
def get_context(
    task: str | None = None,
    target_files: list[str] | None = None,
) -> str:
    """Get codebase intelligence for a coding task.

    Without arguments, returns the full codebase profile — all 13 extraction
    dimensions at full detail. The calling agent's LLM interprets what's relevant.

    With a task description (and optional target files), returns an LLM-generated
    advisory brief with confidence-tagged recommendations covering what to change,
    how, risks, testing strategy, and conventions to follow. Falls back to the
    full profile if no LLM is configured.
    """
    profile = _get_profile()

    if task:
        # Try LLM advisory brief
        from repox.context import TaskContext, generate_context
        task_ctx = TaskContext(
            description=task,
            task_type="general",
            target_files=target_files or [],
        )
        return generate_context(profile, task_ctx)

    # No task — return full profile
    return _get_full_profile()


def run_server(repo_path: Path) -> None:
    """Start the MCP server for the given repo."""
    load_profile(repo_path)
    mcp.run()
