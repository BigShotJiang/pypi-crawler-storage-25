"""CLI entry point — repox scan / profile / context / serve / learn."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from repox import __version__


@click.group()
@click.version_option(__version__, prog_name="repox")
@click.option("--model", default=None, help="LLM model override (e.g. 'anthropic/claude-opus-4-6').")
@click.pass_context
def main(ctx: click.Context, model: str | None) -> None:
    """Repox — The repo index that makes coding agents smart."""
    ctx.ensure_object(dict)
    ctx.obj["model"] = model


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True))
@click.option("--force", is_flag=True, help="Force full rescan, ignoring cached hashes.")
@click.option("--json-output", "json_out", is_flag=True, help="Output profile as JSON to stdout.")
def scan(path: str, force: bool, json_out: bool) -> None:
    """Scan a repository and build/update the codebase profile."""
    from repox.scanner import scan as do_scan

    repo_path = Path(path)
    click.echo(f"Scanning {repo_path.name}...")

    profile = do_scan(repo_path, force=force)

    # Summary
    ts = profile.tech_stack
    arch = profile.architecture

    click.echo(f"\n  Repo:         {profile.repo_name}")
    if ts.primary_language:
        lang = ts.primary_language
        if ts.language_version:
            lang += f" {ts.language_version}"
        click.echo(f"  Language:     {lang}")
    if ts.framework:
        click.echo(f"  Framework:    {ts.framework}")
    if ts.package_manager:
        click.echo(f"  Pkg manager:  {ts.package_manager}")
    if ts.test_runner:
        click.echo(f"  Test runner:  {ts.test_runner}")
    if arch.pattern.value != "unknown":
        click.echo(f"  Architecture: {arch.pattern.value} ({arch.confidence:.0%})")
    if profile.custom_rules.sources_found:
        click.echo(f"  Custom rules: {', '.join(profile.custom_rules.sources_found)}")

    sym = profile.symbols
    dep = profile.dependencies
    if sym.files_parsed:
        click.echo(f"  Symbols:      {len(sym.symbols)} across {sym.files_parsed} files ({', '.join(sym.languages_parsed)})")
    if dep.import_edges:
        click.echo(f"  Imports:      {len(dep.import_edges)} edges")
    if dep.symbol_ranks:
        top = dep.symbol_ranks[0]
        click.echo(f"  Top file:     {top.symbol} (PageRank: {top.pagerank:.4f})")
    if profile.conventions.conventions:
        click.echo(f"  Conventions:  {len(profile.conventions.conventions)} detected")
    if profile.test_patterns.test_count:
        click.echo(f"  Tests:        {profile.test_patterns.test_count} in {profile.test_patterns.test_file_count} files ({profile.test_patterns.framework or 'unknown'})")

    api = profile.api_surface
    if api.endpoints:
        click.echo(f"  Endpoints:    {len(api.endpoints)} ({api.framework or 'unknown'})")
    dm = profile.data_models
    if dm.entities:
        click.echo(f"  Data models:  {len(dm.entities)} entities")
    dp = profile.design_patterns
    if dp.patterns:
        unique_patterns = {p.pattern for p in dp.patterns}
        click.echo(f"  Patterns:     {len(dp.patterns)} detections ({', '.join(sorted(unique_patterns)[:5])})")

    infra = profile.infrastructure
    if infra.services:
        click.echo(f"  Services:     {len(infra.services)} ({', '.join(s.name for s in infra.services[:5])})")
    if infra.deployment_targets:
        click.echo(f"  Deploy:       {', '.join(infra.deployment_targets)}")
    hot = profile.hotspots
    if hot.hotspots:
        top_hot = hot.hotspots[0]
        click.echo(f"  Top hotspot:  {top_hot.file_path} (score: {top_hot.score})")
    km = profile.knowledge_map
    islands = [o for o in km.file_ownerships if o.is_knowledge_island]
    if islands:
        click.echo(f"  K. islands:   {len(islands)} files with single-author risk")

    learn = profile.learning
    if learn.learned_rules:
        active = [r for r in learn.learned_rules if r.confidence >= 0.4]
        click.echo(f"  Learned:      {len(active)} active rules ({learn.total_interactions} interactions)")

    deps_count = len(ts.dependencies)
    dev_count = len(ts.dev_dependencies)
    click.echo(f"  Dependencies: {deps_count} prod, {dev_count} dev")
    click.echo(f"  Config files: {len(ts.config_files_parsed)} parsed")

    click.echo(f"\n  Saved to .repox/profile.json + profile.md")

    if json_out:
        click.echo("\n" + profile.model_dump_json(indent=2))


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True))
def profile(path: str) -> None:
    """Show the current repo profile (from last scan)."""
    from repox.persistence import load_profile_json

    repo_path = Path(path)
    prof = load_profile_json(repo_path)

    if not prof:
        click.echo("No profile found. Run `repox scan` first.", err=True)
        sys.exit(1)

    click.echo(prof.model_dump_json(indent=2))


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True))
def show(path: str) -> None:
    """Show the human-readable profile summary."""
    from repox.persistence import get_repox_dir, PROFILE_MD

    repo_path = Path(path)
    md_path = get_repox_dir(repo_path) / PROFILE_MD

    if not md_path.exists():
        click.echo("No profile found. Run `repox scan` first.", err=True)
        sys.exit(1)

    click.echo(md_path.read_text())


@main.command()
@click.argument("task_description")
@click.option("--path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True),
              help="Path to the repository.")
@click.option("--task-type", default="general",
              type=click.Choice(["bug_fix", "new_feature", "refactor", "general"]),
              help="Type of task for context prioritization.")
@click.option("--target-files", default=None,
              help="Comma-separated list of files the task will touch.")
@click.option("--no-save", is_flag=True, help="Don't save context.md, just print.")
@click.pass_context
def context(ctx: click.Context, task_description: str, path: str, task_type: str,
            target_files: str | None, no_save: bool) -> None:
    """Generate a task-aware context brief.

    Examples:

        repox context "Fix the login bug in auth.py"

        repox context "Add user search endpoint" --task-type new_feature

        repox context "Refactor payment module" --target-files src/payments.py,src/billing.py
    """
    from repox.context import TaskContext, generate_context, save_context
    from repox.persistence import load_profile_json

    repo_path = Path(path)
    prof = load_profile_json(repo_path)

    if not prof:
        click.echo("No profile found. Scanning first...", err=True)
        from repox.scanner import scan as do_scan
        prof = do_scan(repo_path)

    target_list = [f.strip() for f in target_files.split(",")] if target_files else []
    task = TaskContext(
        description=task_description,
        task_type=task_type,
        target_files=target_list,
    )

    model = ctx.obj.get("model")
    brief = generate_context(prof, task, model=model)
    click.echo(brief)

    if not no_save:
        out = save_context(brief, repo_path)
        click.echo(f"\n  Saved to {out}", err=True)


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True))
def serve(path: str) -> None:
    """Start the MCP server, exposing Repox intelligence as tools.

    Connect from any MCP-compatible agent:

    \b
        {
            "mcpServers": {
                "repox": {
                    "command": "repox",
                    "args": ["serve"]
                }
            }
        }
    """
    from repox.server import run_server

    repo_path = Path(path)
    click.echo(f"Starting Repox MCP server for {repo_path.name}...", err=True)
    run_server(repo_path)


@main.command()
@click.argument("rule")
@click.option("--path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True),
              help="Path to the repository.")
@click.option("--category", default="general", help="Rule category (naming, error_handling, testing, etc.).")
@click.option("--source", default="interaction",
              type=click.Choice(["interaction", "pr_outcome", "review_pattern", "fix_pattern"]),
              help="How this rule was learned.")
@click.option("--context", "ctx_str", default=None, help="Context about where this was learned.")
def learn(rule: str, path: str, category: str, source: str, ctx_str: str | None) -> None:
    """Record a learned convention or pattern.

    Examples:

        repox learn "Use tenacity for retries" --category error_handling

        repox learn "Always add type hints to public functions" --category typing

        repox learn "Use factories for test data" --category testing --source review_pattern
    """
    from repox.learning import record_learning

    repo_path = Path(path)
    learned = record_learning(
        repo_path,
        rule=rule,
        category=category,
        source=source,
        context=ctx_str,
    )

    if learned.reinforcement_count > 0:
        click.echo(f"  Reinforced (x{learned.reinforcement_count + 1}, confidence: {learned.confidence:.0%}): {rule}")
    else:
        click.echo(f"  Learned (confidence: {learned.confidence:.0%}): {rule}")


@main.command("learned")
@click.option("--path", default=".", type=click.Path(exists=True, file_okay=False, resolve_path=True),
              help="Path to the repository.")
@click.option("--min-confidence", default=0.4, type=float, help="Minimum confidence threshold.")
@click.option("--category", default=None, help="Filter by category.")
def show_learned(path: str, min_confidence: float, category: str | None) -> None:
    """Show active learned rules."""
    from repox.learning import get_active_rules

    repo_path = Path(path)
    rules = get_active_rules(repo_path, min_confidence=min_confidence, category=category)

    if not rules:
        click.echo("No learned rules yet. Use `repox learn` to teach Repox.")
        return

    for r in rules:
        status = f"[{r.confidence:.0%}]"
        reinforced = f" (x{r.reinforcement_count + 1})" if r.reinforcement_count > 0 else ""
        click.echo(f"  {status} {r.category}: {r.rule}{reinforced}")


if __name__ == "__main__":
    main()
