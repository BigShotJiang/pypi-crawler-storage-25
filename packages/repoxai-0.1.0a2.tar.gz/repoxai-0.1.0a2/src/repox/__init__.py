"""Repox - The repo index that makes coding agents smart."""

__version__ = "0.1.0a2"

from repox.api import generate_context, get_context_for_files, get_profile, scan, serve
from repox.learning import contradict_learning, decay_stale_rules, get_active_rules, record_learning

__all__ = [
    "scan",
    "get_profile",
    "generate_context",
    "get_context_for_files",
    "serve",
    "record_learning",
    "contradict_learning",
    "get_active_rules",
    "decay_stale_rules",
]
