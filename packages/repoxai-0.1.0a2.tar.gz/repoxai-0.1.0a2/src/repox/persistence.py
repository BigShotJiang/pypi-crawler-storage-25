"""JSON + Markdown persistence for RepoProfile."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

from repox.models import RepoProfile

REPOX_DIR = ".repox"
PROFILE_JSON = "profile.json"
PROFILE_MD = "profile.md"
HASHES_JSON = "hashes.json"


def get_repox_dir(repo_path: Path) -> Path:
    return repo_path / REPOX_DIR


def save_profile_json(profile: RepoProfile, repo_path: Path) -> Path:
    """Write profile.json with all structured data."""
    repox_dir = get_repox_dir(repo_path)
    repox_dir.mkdir(exist_ok=True)
    out = repox_dir / PROFILE_JSON
    out.write_text(profile.model_dump_json(indent=2))
    return out


def load_profile_json(repo_path: Path) -> RepoProfile | None:
    """Load profile.json if it exists."""
    path = get_repox_dir(repo_path) / PROFILE_JSON
    if not path.exists():
        return None
    return RepoProfile.model_validate_json(path.read_text())


def save_profile_md(profile: RepoProfile, repo_path: Path) -> Path:
    """Write a human-readable profile.md summary."""
    repox_dir = get_repox_dir(repo_path)
    repox_dir.mkdir(exist_ok=True)
    out = repox_dir / PROFILE_MD
    out.write_text(_render_profile_md(profile))
    return out


def _render_profile_md(profile: RepoProfile) -> str:
    lines: list[str] = []
    lines.append(f"# Repox Profile: {profile.repo_name}")
    lines.append(f"*Last scanned: {profile.last_scanned.isoformat()}*\n")

    # Tech Stack
    ts = profile.tech_stack
    if ts.primary_language:
        lines.append("## Tech Stack")
        if ts.primary_language:
            lang = ts.primary_language
            if ts.language_version:
                lang += f" {ts.language_version}"
            lines.append(f"- **Language:** {lang}")
        if ts.framework:
            lines.append(f"- **Framework:** {ts.framework}")
        if ts.orm:
            lines.append(f"- **ORM:** {ts.orm}")
        if ts.test_runner:
            lines.append(f"- **Test runner:** {ts.test_runner}")
        if ts.test_command:
            lines.append(f"- **Test command:** `{ts.test_command}`")
        if ts.linter:
            lines.append(f"- **Linter:** {ts.linter}")
        if ts.formatter:
            lines.append(f"- **Formatter:** {ts.formatter}")
        if ts.package_manager:
            lines.append(f"- **Package manager:** {ts.package_manager}")
        if ts.ci_system:
            lines.append(f"- **CI:** {ts.ci_system}")
        if ts.containerization:
            lines.append(f"- **Containerization:** {ts.containerization}")
        if ts.database:
            lines.append(f"- **Database:** {ts.database}")
        if ts.dependencies:
            lines.append(f"- **Dependencies:** {len(ts.dependencies)}")
        lines.append("")

    # Architecture
    arch = profile.architecture
    if arch.pattern.value != "unknown":
        lines.append("## Architecture")
        lines.append(f"- **Pattern:** {arch.pattern.value} (confidence: {arch.confidence:.0%})")
        if arch.entry_points:
            lines.append(f"- **Entry points:** {', '.join(arch.entry_points)}")
        if arch.directory_labels:
            lines.append("- **Directory roles:**")
            for dl in arch.directory_labels:
                desc = f" — {dl.description}" if dl.description else ""
                lines.append(f"  - `{dl.path}` → {dl.label}{desc}")
        if arch.layering_rules:
            lines.append("- **Layering rules:**")
            for rule in arch.layering_rules:
                arrow = "→" if rule.allowed else "✗→"
                lines.append(f"  - `{rule.source}` {arrow} `{rule.target}`")
        lines.append("")

    # Symbol Graph
    sym = profile.symbols
    if sym.symbols:
        lines.append("## Symbol Graph")
        lines.append(f"- **Files parsed:** {sym.files_parsed}")
        lines.append(f"- **Total symbols:** {len(sym.symbols)}")
        lines.append(f"- **Languages:** {', '.join(sym.languages_parsed)}")
        # Count by kind
        from collections import Counter
        kind_counts = Counter(s.kind.value for s in sym.symbols)
        for kind, count in kind_counts.most_common():
            lines.append(f"  - {kind}: {count}")
        lines.append("")

    # Key Function Signatures (public, non-test)
    if sym.symbols:
        pub_funcs = [
            s for s in sym.symbols
            if s.kind.value in ("function", "method")
            and s.visibility == "public"
            and not s.file_path.startswith("tests/")
            and not s.file_path.startswith("test_")
            and not s.name.startswith("test_")
        ]
        if pub_funcs:
            lines.append("## Key Functions")
            # Group by file
            by_file: dict[str, list] = {}
            for s in pub_funcs:
                by_file.setdefault(s.file_path, []).append(s)
            for fp, funcs in sorted(by_file.items()):
                lines.append(f"\n### `{fp}`")
                for s in funcs[:15]:
                    params = ", ".join(
                        f"{p.name}: {p.type_annotation}" if p.type_annotation else p.name
                        for p in s.parameters
                        if p.name != "self"
                    )
                    ret = f" → {s.return_type}" if s.return_type else ""
                    async_prefix = "async " if s.is_async else ""
                    scope = f"{s.parent_scope}." if s.parent_scope else ""
                    lines.append(f"- `{async_prefix}{scope}{s.name}({params}){ret}`")
                if len(funcs) > 15:
                    lines.append(f"- *... and {len(funcs) - 15} more*")
            lines.append("")

    # Dependency Graph / PageRank
    dep = profile.dependencies
    if dep.symbol_ranks:
        lines.append("## Key Files (by PageRank)")
        for rank in dep.symbol_ranks[:10]:
            lines.append(f"- `{rank.symbol}` — {rank.pagerank:.4f}")
        lines.append("")

    # Call Graph Cross-Reference (top callers/callees)
    if dep.call_edges:
        from collections import defaultdict
        callers_of: dict[str, list[str]] = defaultdict(list)
        callees_of: dict[str, list[str]] = defaultdict(list)
        for edge in dep.call_edges:
            callers_of[edge.callee].append(edge.caller)
            callees_of[edge.caller].append(edge.callee)

        # Filter to project-internal function calls only (skip stdlib/builtins)
        STDLIB_NOISE = {
            "len", "str", "int", "float", "bool", "list", "dict", "set", "tuple",
            "print", "isinstance", "type", "super", "range", "enumerate", "zip",
            "map", "filter", "sorted", "reversed", "max", "min", "sum", "any", "all",
            "open", "hasattr", "getattr", "setattr", "repr", "format", "round", "abs",
        }
        all_funcs = set(callers_of.keys()) | set(callees_of.keys())
        # Filter to production functions, exclude stdlib noise
        all_funcs = {f for f in all_funcs
                     if not f.startswith("test_")
                     and f not in STDLIB_NOISE
                     and "." in f or "/" in f or f[0].isupper()}
        scored = [(f, len(callers_of.get(f, [])) + len(callees_of.get(f, []))) for f in all_funcs]
        scored.sort(key=lambda x: x[1], reverse=True)

        if scored:
            lines.append("## Call Graph")
            for func_name, _ in scored[:15]:
                callers = [c for c in callers_of.get(func_name, []) if c not in STDLIB_NOISE]
                callees = [c for c in callees_of.get(func_name, []) if c not in STDLIB_NOISE]
                if not callers and not callees:
                    continue
                parts = [f"`{func_name}`"]
                if callees:
                    parts.append(f"calls: {', '.join(f'`{c}`' for c in callees[:5])}")
                if callers:
                    parts.append(f"called by: {', '.join(f'`{c}`' for c in callers[:5])}")
                lines.append(f"- {' — '.join(parts)}")
            lines.append("")

    # API Surface
    api = profile.api_surface
    if api.endpoints:
        lines.append("## API Surface")
        if api.framework:
            lines.append(f"*Framework: {api.framework}*\n")
        for ep in api.endpoints[:20]:
            auth = " (auth)" if ep.auth_required else ""
            lines.append(f"- **{ep.method}** `{ep.path}` → `{ep.handler}`{auth}")
        if len(api.endpoints) > 20:
            lines.append(f"- *... and {len(api.endpoints) - 20} more*")
        lines.append("")

    # Data Models
    dm = profile.data_models
    if dm.entities:
        lines.append("## Data Models")
        for entity in dm.entities:
            orm_tag = f" ({entity.orm})" if entity.orm else ""
            lines.append(f"### {entity.name}{orm_tag}")
            for field in entity.fields[:15]:
                constraints = []
                if field.primary_key:
                    constraints.append("PK")
                if field.unique:
                    constraints.append("unique")
                if field.foreign_key:
                    constraints.append(f"FK→{field.foreign_key}")
                if not field.nullable:
                    constraints.append("required")
                tag = f" [{', '.join(constraints)}]" if constraints else ""
                lines.append(f"- `{field.name}`: {field.type}{tag}")
            for rel in entity.relationships:
                lines.append(f"- `{rel.name}` → {rel.target_model} ({rel.kind})")
            lines.append("")

    # Design Patterns
    dp = profile.design_patterns
    if dp.patterns:
        lines.append("## Design Patterns")
        # Group by pattern name
        by_pattern: dict[str, list] = {}
        for p in dp.patterns:
            by_pattern.setdefault(p.pattern, []).append(p)
        for name, detections in sorted(by_pattern.items()):
            locations = ", ".join(d.participants[0] if d.participants else d.file_path for d in detections[:3])
            lines.append(f"- **{name}** ({detections[0].category}): {locations}")
        lines.append("")

    # Coding Conventions
    conv = profile.conventions
    if conv.conventions:
        lines.append("## Coding Conventions")
        for c in conv.conventions:
            examples = ""
            if c.examples:
                examples = f" (e.g., {', '.join(c.examples[:2])})"
            lines.append(f"- **{c.category}:** {c.rule}{examples}")
        lines.append("")

    # Test Patterns
    tp = profile.test_patterns
    if tp.framework:
        lines.append("## Test Patterns")
        lines.append(f"- **Framework:** {tp.framework}")
        if tp.file_pattern:
            lines.append(f"- **File pattern:** `{tp.file_pattern}`")
        if tp.naming_convention:
            lines.append(f"- **Naming:** `{tp.naming_convention}`")
        if tp.fixture_approach:
            lines.append(f"- **Fixtures:** {tp.fixture_approach}")
        if tp.mock_library:
            lines.append(f"- **Mocking:** {tp.mock_library}")
        if tp.assertion_style:
            lines.append(f"- **Assertions:** {tp.assertion_style}")
        lines.append(f"- **Tests:** {tp.test_count} in {tp.test_file_count} files")
        lines.append("")

    # Infrastructure Topology
    infra = profile.infrastructure
    if infra.services:
        lines.append("## Infrastructure")
        for svc in infra.services:
            img = f" ({svc.image})" if svc.image else ""
            ports = f" ports: {', '.join(svc.ports)}" if svc.ports else ""
            lines.append(f"- **{svc.name}**{img}{ports}")
            if svc.depends_on:
                lines.append(f"  - depends on: {', '.join(svc.depends_on)}")
        if infra.deployment_targets:
            lines.append(f"- **Deployment:** {', '.join(infra.deployment_targets)}")
        if infra.external_integrations:
            lines.append(f"- **External:** {', '.join(infra.external_integrations)}")
        if infra.env_vars:
            lines.append(f"- **Env vars:** {len(infra.env_vars)} tracked")
        lines.append("")

    # Hotspot Analysis
    hot = profile.hotspots
    if hot.hotspots:
        lines.append("## Hotspots (by churn × complexity)")
        for h in hot.hotspots[:10]:
            lines.append(f"- `{h.file_path}` — score: {h.score}, freq: {h.change_frequency}, churn: {h.churn}")
        if hot.temporal_couplings:
            lines.append("\n**Temporal couplings:**")
            for tc in hot.temporal_couplings[:5]:
                lines.append(f"- `{tc.file_a}` ↔ `{tc.file_b}` ({tc.co_change_count} co-changes, {tc.confidence:.0%})")
        lines.append("")

    # Knowledge Map
    km = profile.knowledge_map
    if km.file_ownerships:
        islands = [o for o in km.file_ownerships if o.is_knowledge_island]
        if islands:
            lines.append("## Knowledge Islands")
            for o in islands[:10]:
                lines.append(f"- `{o.file_path}` — {o.primary_author} ({o.contribution_pct:.0f}%)")
            lines.append("")
        if km.bus_factors:
            lines.append("## Bus Factor")
            for b in km.bus_factors:
                lines.append(f"- `{b.module}` — bus factor: {b.bus_factor} ({', '.join(b.contributors)})")
            lines.append("")

    # Behavioral Intelligence
    beh = profile.behavioral
    has_behavioral = (beh.auth_flows or beh.state_machines or beh.middleware_chain
                      or beh.api_contracts or beh.background_jobs)
    if has_behavioral:
        lines.append("## Behavioral Intelligence")

        if beh.auth_flows:
            lines.append("\n### Auth Flows")
            for af in beh.auth_flows:
                provider = f" ({af.provider})" if af.provider else ""
                lines.append(f"- **{af.method}**{provider}: `{af.guard_function}` in `{af.guard_file}`")
                if af.protected_routes:
                    lines.append(f"  - Protects: {', '.join(f'`{r}`' for r in af.protected_routes[:8])}")

        if beh.state_machines:
            lines.append("\n### Entity Lifecycles")
            for sm in beh.state_machines:
                states = " → ".join(sm.states) if sm.states else "unknown"
                lines.append(f"- **{sm.entity}** (`{sm.file_path}`): {states}")

        if beh.middleware_chain:
            lines.append("\n### Middleware Chain")
            for mw in beh.middleware_chain:
                purpose = f" — {mw.purpose}" if mw.purpose else ""
                lines.append(f"- `{mw.name}`{purpose} (`{mw.file_path}`)")

        if beh.background_jobs:
            lines.append("\n### Background Jobs")
            for job in beh.background_jobs:
                lines.append(f"- {job}")

        if beh.api_contracts:
            lines.append("\n### API Contracts (Frontend → Backend)")
            for c in beh.api_contracts[:20]:
                backend = f" → `{c.backend_handler}`" if c.backend_handler else ""
                lines.append(f"- `{c.consumer_function}` ({c.consumer_file}): **{c.method}** `{c.path}`{backend}")
            if len(beh.api_contracts) > 20:
                lines.append(f"- *... and {len(beh.api_contracts) - 20} more*")

        lines.append("")

    # Security Posture
    sec = profile.security
    has_security = (sec.auth_required_by_default or sec.input_validation or sec.sql_safety
                    or sec.cors_origins or sec.secret_management or sec.sensitive_fields
                    or sec.rate_limiting or sec.security_notes)
    if has_security:
        lines.append("## Security Posture")
        if sec.auth_required_by_default:
            lines.append("- **Auth:** Required by default on all routes")
        if sec.unprotected_routes:
            lines.append(f"- **Intentionally public:** {', '.join(f'`{r}`' for r in sec.unprotected_routes[:5])}")
        if sec.input_validation:
            lines.append(f"- **Input validation:** {sec.input_validation}")
        if sec.sql_safety:
            lines.append(f"- **SQL safety:** {sec.sql_safety}")
        if sec.cors_origins:
            origins = ", ".join(sec.cors_origins[:5])
            lines.append(f"- **CORS origins:** {origins}" + (" (ALLOW ALL)" if sec.cors_allow_all else ""))
        if sec.secret_management:
            lines.append(f"- **Secrets:** {sec.secret_management}")
        if sec.rate_limiting:
            lines.append(f"- **Rate limiting:** {sec.rate_limiting}")
        if sec.sensitive_fields:
            lines.append(f"- **PII fields:** {', '.join(f'`{f}`' for f in sec.sensitive_fields[:10])}")
        if sec.security_notes:
            lines.append("\n**Agent rules:**")
            for note in sec.security_notes:
                lines.append(f"- {note}")
        lines.append("")

    # Custom Rules
    cr = profile.custom_rules
    if cr.rules:
        lines.append("## Custom Rules")
        lines.append(f"*Sources: {', '.join(cr.sources_found)}*\n")
        for rule in cr.rules:
            content = rule.content
            if len(content) > 200:
                content = content[:200] + "..."
            lines.append(f"### {rule.source.value}")
            lines.append(content)
            lines.append("")

    return "\n".join(lines) + "\n"


# ── File Hashing for Incremental Scans ───────────────────────────────────────


def compute_file_hash(file_path: Path) -> str:
    return hashlib.sha256(file_path.read_bytes()).hexdigest()


def load_hashes(repo_path: Path) -> dict[str, str]:
    """Load file hashes from previous scan."""
    path = get_repox_dir(repo_path) / HASHES_JSON
    if not path.exists():
        return {}
    return json.loads(path.read_text())


def save_hashes(hashes: dict[str, str], repo_path: Path) -> Path:
    repox_dir = get_repox_dir(repo_path)
    repox_dir.mkdir(exist_ok=True)
    out = repox_dir / HASHES_JSON
    out.write_text(json.dumps(hashes, indent=2))
    return out


def get_changed_files(
    repo_path: Path, source_files: list[Path], old_hashes: dict[str, str]
) -> tuple[list[Path], dict[str, str]]:
    """Compare current file hashes against stored hashes. Returns (changed_files, new_hashes)."""
    new_hashes: dict[str, str] = {}
    changed: list[Path] = []

    for fp in source_files:
        rel = str(fp.relative_to(repo_path))
        h = compute_file_hash(fp)
        new_hashes[rel] = h
        if old_hashes.get(rel) != h:
            changed.append(fp)

    return changed, new_hashes
