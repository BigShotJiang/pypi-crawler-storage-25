"""Pydantic data models for all 13 dimensions of codebase intelligence."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path

from pydantic import BaseModel, Field


# ── Dimension 1: Tech Stack Fingerprint ──────────────────────────────────────


class Dependency(BaseModel):
    name: str
    version: str | None = None
    dev: bool = False


class TechStack(BaseModel):
    """Auto-detected technology stack from config files."""

    primary_language: str | None = None
    language_version: str | None = None
    framework: str | None = None
    orm: str | None = None
    test_runner: str | None = None
    test_command: str | None = None
    linter: str | None = None
    formatter: str | None = None
    package_manager: str | None = None
    ci_system: str | None = None
    containerization: str | None = None
    cloud_provider: str | None = None
    database: str | None = None
    dependencies: list[Dependency] = Field(default_factory=list)
    dev_dependencies: list[Dependency] = Field(default_factory=list)
    config_files_parsed: list[str] = Field(default_factory=list)


# ── Dimension 2: Architecture Map ────────────────────────────────────────────


class ArchPattern(str, Enum):
    LAYERED = "layered"
    DOMAIN_DRIVEN = "domain-driven"
    MVC = "mvc"
    HEXAGONAL = "hexagonal"
    FLAT = "flat"
    MONOLITH_MODULES = "monolith-modules"
    UNKNOWN = "unknown"


class DirectoryLabel(BaseModel):
    path: str
    label: str
    description: str | None = None


class LayeringRule(BaseModel):
    source: str
    target: str
    allowed: bool = True


class ArchitectureMap(BaseModel):
    """Detected architectural pattern and directory semantics."""

    pattern: ArchPattern = ArchPattern.UNKNOWN
    confidence: float = 0.0
    directory_labels: list[DirectoryLabel] = Field(default_factory=list)
    layering_rules: list[LayeringRule] = Field(default_factory=list)
    entry_points: list[str] = Field(default_factory=list)
    module_boundaries: list[str] = Field(default_factory=list)


# ── Dimension 3: Symbol Graph ────────────────────────────────────────────────


class SymbolKind(str, Enum):
    FUNCTION = "function"
    CLASS = "class"
    METHOD = "method"
    TYPE = "type"
    CONSTANT = "constant"
    VARIABLE = "variable"
    ENUM = "enum"
    INTERFACE = "interface"
    PROPERTY = "property"


class Parameter(BaseModel):
    name: str
    type_annotation: str | None = None
    default: str | None = None


class Symbol(BaseModel):
    name: str
    kind: SymbolKind
    file_path: str
    line_start: int
    line_end: int
    parameters: list[Parameter] = Field(default_factory=list)
    return_type: str | None = None
    decorators: list[str] = Field(default_factory=list)
    docstring: str | None = None
    visibility: str = "public"
    is_async: bool = False
    is_static: bool = False
    parent_scope: str | None = None
    base_classes: list[str] = Field(default_factory=list)
    exported: bool = True


class SymbolGraph(BaseModel):
    """All code symbols extracted via tree-sitter AST parsing."""

    symbols: list[Symbol] = Field(default_factory=list)
    languages_parsed: list[str] = Field(default_factory=list)
    files_parsed: int = 0


# ── Dimension 4: Dependency Graph ────────────────────────────────────────────


class ImportEdge(BaseModel):
    source_file: str
    target_file: str
    imported_names: list[str] = Field(default_factory=list)


class CallEdge(BaseModel):
    caller: str
    callee: str
    file_path: str
    line: int


class SymbolRank(BaseModel):
    symbol: str
    file_path: str
    pagerank: float


class DependencyGraph(BaseModel):
    """Import graph, call graph, and PageRank rankings."""

    import_edges: list[ImportEdge] = Field(default_factory=list)
    call_edges: list[CallEdge] = Field(default_factory=list)
    symbol_ranks: list[SymbolRank] = Field(default_factory=list)


# ── Dimension 5: API Surface ────────────────────────────────────────────────


class Endpoint(BaseModel):
    method: str
    path: str
    handler: str
    file_path: str
    line: int
    request_schema: str | None = None
    response_schema: str | None = None
    auth_required: bool | None = None
    middleware: list[str] = Field(default_factory=list)


class APISurface(BaseModel):
    """All HTTP endpoints, WebSocket handlers, gRPC services, async workers."""

    endpoints: list[Endpoint] = Field(default_factory=list)
    framework: str | None = None


# ── Dimension 6: Data Model Map ─────────────────────────────────────────────


class FieldDef(BaseModel):
    name: str
    type: str
    nullable: bool = False
    unique: bool = False
    indexed: bool = False
    primary_key: bool = False
    foreign_key: str | None = None
    default: str | None = None


class Relationship(BaseModel):
    name: str
    target_model: str
    kind: str  # one-to-many, many-to-many, one-to-one
    back_populates: str | None = None


class DataEntity(BaseModel):
    name: str
    file_path: str
    fields: list[FieldDef] = Field(default_factory=list)
    relationships: list[Relationship] = Field(default_factory=list)
    orm: str | None = None


class DataModelMap(BaseModel):
    """Database entities, fields, relationships, and validation schemas."""

    entities: list[DataEntity] = Field(default_factory=list)


# ── Dimension 7: Design Patterns ────────────────────────────────────────────


class DetectedPattern(BaseModel):
    pattern: str
    category: str  # creational, structural, behavioral, architectural
    file_path: str
    participants: list[str] = Field(default_factory=list)
    confidence: float = 0.0


class DesignPatterns(BaseModel):
    """GoF and architectural patterns detected in the codebase."""

    patterns: list[DetectedPattern] = Field(default_factory=list)


# ── Dimension 8: Infrastructure Topology ─────────────────────────────────────


class Service(BaseModel):
    name: str
    image: str | None = None
    ports: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    environment: list[str] = Field(default_factory=list)


class EnvVar(BaseModel):
    name: str
    source: str  # code, .env.example, docker-compose, etc.
    description: str | None = None


class InfraTopology(BaseModel):
    """Docker services, K8s resources, env vars, external integrations."""

    services: list[Service] = Field(default_factory=list)
    env_vars: list[EnvVar] = Field(default_factory=list)
    external_integrations: list[str] = Field(default_factory=list)
    deployment_targets: list[str] = Field(default_factory=list)


# ── Dimension 9: Coding Conventions ──────────────────────────────────────────


class Convention(BaseModel):
    category: str  # naming, error_handling, logging, imports, types, etc.
    rule: str
    confidence: float = 0.0
    examples: list[str] = Field(default_factory=list)


class CodingConventions(BaseModel):
    """Detected coding style and patterns from statistical analysis."""

    conventions: list[Convention] = Field(default_factory=list)


# ── Dimension 10: Test Patterns ──────────────────────────────────────────────


class TestPatterns(BaseModel):
    """Test framework, naming, fixtures, mocking patterns."""

    __test__ = False

    framework: str | None = None
    file_pattern: str | None = None  # e.g., "*_test.py", "*.test.ts"
    naming_convention: str | None = None  # e.g., "test_{method}_{scenario}"
    fixture_approach: str | None = None
    mock_library: str | None = None
    assertion_style: str | None = None
    test_count: int = 0
    test_file_count: int = 0


# ── Dimension 11: Hotspot Analysis ───────────────────────────────────────────


class Hotspot(BaseModel):
    file_path: str
    change_frequency: int
    churn: int  # lines added + deleted
    complexity: float
    score: float  # change_frequency * complexity


class TemporalCoupling(BaseModel):
    file_a: str
    file_b: str
    co_change_count: int
    confidence: float


class HotspotAnalysis(BaseModel):
    """Files ranked by churn x complexity from git history."""

    hotspots: list[Hotspot] = Field(default_factory=list)
    temporal_couplings: list[TemporalCoupling] = Field(default_factory=list)
    analysis_period_months: int = 12


# ── Dimension 12: Knowledge Map ──────────────────────────────────────────────


class FileOwnership(BaseModel):
    file_path: str
    primary_author: str
    contribution_pct: float
    is_knowledge_island: bool = False  # >95% single author


class ModuleBusFactor(BaseModel):
    module: str
    bus_factor: int
    contributors: list[str] = Field(default_factory=list)


class KnowledgeMap(BaseModel):
    """Code ownership, bus factor, knowledge islands from git history."""

    file_ownerships: list[FileOwnership] = Field(default_factory=list)
    bus_factors: list[ModuleBusFactor] = Field(default_factory=list)


# ── Dimension 13: Custom Rules ───────────────────────────────────────────────


class RuleSource(str, Enum):
    PATCHMATE_YAML = "patchmate.yaml"
    AGENTS_MD = "AGENTS.md"
    CLAUDE_MD = "CLAUDE.md"
    CURSORRULES = ".cursorrules"
    COPILOT_INSTRUCTIONS = ".github/copilot-instructions.md"


class CustomRule(BaseModel):
    source: RuleSource
    content: str
    file_path: str


class CustomRules(BaseModel):
    """Team-provided rules from config files — highest priority context."""

    rules: list[CustomRule] = Field(default_factory=list)
    sources_found: list[str] = Field(default_factory=list)


# ── Behavioral Intelligence ─────────────────────────────────────────────────


class AuthFlow(BaseModel):
    """Detected authentication/authorization pattern."""

    method: str  # jwt, session, api_key, oauth, webhook
    provider: str | None = None  # clerk, auth0, firebase, custom
    guard_function: str | None = None  # get_current_user, require_auth
    guard_file: str | None = None
    protected_routes: list[str] = Field(default_factory=list)  # route files that use the guard


class StateMachine(BaseModel):
    """Detected entity lifecycle / state machine."""

    entity: str  # Screening, Order, etc.
    states: list[str] = Field(default_factory=list)
    file_path: str = ""
    field_name: str = "state"  # the field that holds the state


class MiddlewareEntry(BaseModel):
    """A middleware in the chain."""

    name: str
    file_path: str
    purpose: str | None = None  # logging, auth, cors, etc.


class APIContract(BaseModel):
    """Cross-project API contract — frontend consumer → backend endpoint."""

    consumer_file: str  # frontend/lib/hooks/useScreenings.ts
    consumer_function: str  # useCreateScreening
    method: str  # POST
    path: str  # /screenings
    backend_handler: str | None = None  # create_screening


class BehavioralIntelligence(BaseModel):
    """Behavioral patterns extracted from the codebase."""

    auth_flows: list[AuthFlow] = Field(default_factory=list)
    state_machines: list[StateMachine] = Field(default_factory=list)
    middleware_chain: list[MiddlewareEntry] = Field(default_factory=list)
    api_contracts: list[APIContract] = Field(default_factory=list)
    background_jobs: list[str] = Field(default_factory=list)  # simple list of job descriptions


# ── Security Posture ────────────────────────────────────────────────────────


class SecurityPosture(BaseModel):
    """Security patterns the codebase follows — agents must maintain these."""

    auth_required_by_default: bool = False
    unprotected_routes: list[str] = Field(default_factory=list)  # intentionally public
    input_validation: str | None = None  # "Pydantic", "Zod", "Joi", "manual", None
    sql_safety: str | None = None  # "ORM-only", "parameterized raw SQL", "mixed"
    cors_origins: list[str] = Field(default_factory=list)
    cors_allow_all: bool = False
    secret_management: str | None = None  # "env vars via Settings", "dotenv", "vault"
    sensitive_fields: list[str] = Field(default_factory=list)  # PII field names
    rate_limiting: str | None = None  # "slowapi", "express-rate-limit", None
    security_notes: list[str] = Field(default_factory=list)  # actionable rules for agents


# ── Historical Learning ─────────────────────────────────────────────────────


class LearnedRuleSource(str, Enum):
    INTERACTION = "interaction"  # from agent feedback / PR comments
    PR_OUTCOME = "pr_outcome"  # from merge/close patterns
    REVIEW_PATTERN = "review_pattern"  # from code review feedback
    FIX_PATTERN = "fix_pattern"  # from successful error fixes


class LearnedRule(BaseModel):
    """A rule learned from interactions — evolves over time."""

    rule: str
    category: str  # naming, error_handling, testing, etc.
    source: LearnedRuleSource
    confidence: float = 0.5
    reinforcement_count: int = 0  # how many times this was confirmed
    contradiction_count: int = 0  # how many times this was contradicted
    first_seen: datetime = Field(default_factory=datetime.now)
    last_reinforced: datetime = Field(default_factory=datetime.now)
    examples: list[str] = Field(default_factory=list)
    context: str | None = None  # where/when this was learned


class HistoricalLearning(BaseModel):
    """Compound intelligence from interactions — grows over time."""

    learned_rules: list[LearnedRule] = Field(default_factory=list)
    total_interactions: int = 0
    total_prs_analyzed: int = 0


# ── Top-level RepoProfile ───────────────────────────────────────────────────


class RepoProfile(BaseModel):
    """Complete codebase intelligence profile — all 13 dimensions."""

    repo_path: str
    repo_name: str
    last_scanned: datetime = Field(default_factory=datetime.now)
    version: str = "0.1.0"

    # Structural (from code)
    tech_stack: TechStack = Field(default_factory=TechStack)
    architecture: ArchitectureMap = Field(default_factory=ArchitectureMap)
    symbols: SymbolGraph = Field(default_factory=SymbolGraph)
    dependencies: DependencyGraph = Field(default_factory=DependencyGraph)
    api_surface: APISurface = Field(default_factory=APISurface)
    data_models: DataModelMap = Field(default_factory=DataModelMap)
    design_patterns: DesignPatterns = Field(default_factory=DesignPatterns)
    infrastructure: InfraTopology = Field(default_factory=InfraTopology)

    # Convention (patterns from code)
    conventions: CodingConventions = Field(default_factory=CodingConventions)
    test_patterns: TestPatterns = Field(default_factory=TestPatterns)

    # Temporal (from git)
    hotspots: HotspotAnalysis = Field(default_factory=HotspotAnalysis)
    knowledge_map: KnowledgeMap = Field(default_factory=KnowledgeMap)

    # Explicit (from team)
    custom_rules: CustomRules = Field(default_factory=CustomRules)

    # Behavioral (patterns from code + structure)
    behavioral: BehavioralIntelligence = Field(default_factory=BehavioralIntelligence)

    # Security posture
    security: SecurityPosture = Field(default_factory=SecurityPosture)

    # Learned (from interactions)
    learning: HistoricalLearning = Field(default_factory=HistoricalLearning)
