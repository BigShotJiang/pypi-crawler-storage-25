"""Dim 8: Infrastructure topology — Docker, K8s, Terraform, env vars."""

from __future__ import annotations

import json
import re
from pathlib import Path

import yaml

from repox.models import EnvVar, InfraTopology, Service

# Known infrastructure file patterns
DOCKER_COMPOSE_NAMES = {
    "docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml",
}
K8S_KINDS = {"Deployment", "Service", "ConfigMap", "Secret", "Ingress", "StatefulSet", "DaemonSet"}
KNOWN_SERVICES = {
    "postgres": "PostgreSQL", "postgresql": "PostgreSQL", "mysql": "MySQL",
    "redis": "Redis", "mongo": "MongoDB", "mongodb": "MongoDB",
    "rabbitmq": "RabbitMQ", "kafka": "Kafka", "elasticsearch": "Elasticsearch",
    "nginx": "Nginx", "traefik": "Traefik", "memcached": "Memcached",
    "minio": "MinIO", "localstack": "LocalStack",
}
EXTERNAL_SERVICE_IMPORTS = {
    "boto3": "AWS", "botocore": "AWS",
    "stripe": "Stripe",
    "twilio": "Twilio",
    "sendgrid": "SendGrid",
    "sentry_sdk": "Sentry",
    "google.cloud": "GCP",
    "azure": "Azure",
    "redis": "Redis",
    "celery": "Celery",
    "pika": "RabbitMQ",
    "kafka": "Kafka",
    "pymongo": "MongoDB",
    "psycopg2": "PostgreSQL", "asyncpg": "PostgreSQL",
    "mysql": "MySQL",
}
EXTERNAL_SERVICE_ENVVARS = {
    "STRIPE": "Stripe", "TWILIO": "Twilio", "SENDGRID": "SendGrid",
    "SENTRY": "Sentry", "AWS": "AWS", "GOOGLE": "GCP", "AZURE": "Azure",
    "REDIS": "Redis", "MONGO": "MongoDB", "POSTGRES": "PostgreSQL",
    "MYSQL": "MySQL", "RABBITMQ": "RabbitMQ", "KAFKA": "Kafka",
    "SLACK": "Slack", "GITHUB": "GitHub", "DATADOG": "Datadog",
    "NEWRELIC": "New Relic",
}


def extract_infrastructure(repo_path: Path, source_files: list[Path]) -> InfraTopology:
    """Extract infrastructure topology from config files and source code."""
    services: list[Service] = []
    env_vars: list[EnvVar] = []
    external_integrations: set[str] = set()
    deployment_targets: set[str] = set()

    # Parse Docker files
    _parse_dockerfile(repo_path, services, deployment_targets)
    _parse_docker_compose(repo_path, services, env_vars, deployment_targets)

    # Parse K8s manifests
    _parse_k8s_manifests(repo_path, services, deployment_targets)

    # Parse Terraform
    _parse_terraform(repo_path, deployment_targets)

    # Parse .env.example
    _parse_env_example(repo_path, env_vars)

    # Scan source for env var usage and external service imports
    _scan_source_env_vars(source_files, env_vars)
    _scan_external_integrations(source_files, external_integrations)

    # Detect external services from env var names
    seen_env_names = {ev.name for ev in env_vars}
    for ev_name in seen_env_names:
        for prefix, svc in EXTERNAL_SERVICE_ENVVARS.items():
            if prefix in ev_name.upper():
                external_integrations.add(svc)

    return InfraTopology(
        services=services,
        env_vars=_dedup_env_vars(env_vars),
        external_integrations=sorted(external_integrations),
        deployment_targets=sorted(deployment_targets),
    )


def _parse_dockerfile(repo_path: Path, services: list[Service], targets: set[str]) -> None:
    """Parse Dockerfile for base image, ports, entrypoint."""
    dockerfile = repo_path / "Dockerfile"
    if not dockerfile.exists():
        return

    targets.add("Docker")
    text = dockerfile.read_text(errors="replace")
    image = None
    ports: list[str] = []

    for line in text.splitlines():
        line = line.strip()
        if line.upper().startswith("FROM "):
            parts = line.split()
            if len(parts) >= 2:
                image = parts[1].split(" AS ")[0] if " AS " in parts[1].upper() else parts[1]
        elif line.upper().startswith("EXPOSE "):
            ports.extend(line.split()[1:])

    services.append(Service(
        name="app",
        image=image,
        ports=ports,
    ))


def _parse_docker_compose(
    repo_path: Path, services: list[Service], env_vars: list[EnvVar], targets: set[str]
) -> None:
    """Parse docker-compose.yml for services, ports, env vars."""
    compose_file = None
    for name in DOCKER_COMPOSE_NAMES:
        candidate = repo_path / name
        if candidate.exists():
            compose_file = candidate
            break

    if not compose_file:
        return

    targets.add("Docker Compose")

    try:
        data = yaml.safe_load(compose_file.read_text(errors="replace"))
    except Exception:
        return

    if not isinstance(data, dict):
        return

    svc_map = data.get("services", {})
    if not isinstance(svc_map, dict):
        return

    for svc_name, svc_config in svc_map.items():
        if not isinstance(svc_config, dict):
            continue

        image = svc_config.get("image", "")
        ports = []
        for p in svc_config.get("ports", []):
            ports.append(str(p))

        depends = svc_config.get("depends_on", [])
        if isinstance(depends, dict):
            depends = list(depends.keys())

        env_list = svc_config.get("environment", [])
        svc_env: list[str] = []
        if isinstance(env_list, list):
            for item in env_list:
                name = str(item).split("=")[0]
                svc_env.append(name)
                env_vars.append(EnvVar(name=name, source="docker-compose"))
        elif isinstance(env_list, dict):
            for key in env_list:
                svc_env.append(key)
                env_vars.append(EnvVar(name=key, source="docker-compose"))

        services.append(Service(
            name=svc_name,
            image=image or None,
            ports=ports,
            depends_on=depends if isinstance(depends, list) else [],
            environment=svc_env,
        ))

        # Detect known services from image name
        if image:
            image_lower = image.lower().split(":")[0].split("/")[-1]
            for key, svc_label in KNOWN_SERVICES.items():
                if key in image_lower:
                    break


def _parse_k8s_manifests(repo_path: Path, services: list[Service], targets: set[str]) -> None:
    """Parse Kubernetes YAML manifests."""
    k8s_dirs = [repo_path / "k8s", repo_path / "kubernetes", repo_path / "deploy",
                repo_path / "manifests", repo_path / "helm"]
    k8s_files: list[Path] = []

    for d in k8s_dirs:
        if d.is_dir():
            for f in d.rglob("*.yaml"):
                k8s_files.append(f)
            for f in d.rglob("*.yml"):
                k8s_files.append(f)

    if not k8s_files:
        return

    targets.add("Kubernetes")

    for fpath in k8s_files:
        try:
            for doc in yaml.safe_load_all(fpath.read_text(errors="replace")):
                if not isinstance(doc, dict):
                    continue
                kind = doc.get("kind", "")
                if kind not in K8S_KINDS:
                    continue
                metadata = doc.get("metadata", {})
                name = metadata.get("name", "unknown") if isinstance(metadata, dict) else "unknown"
                if kind == "Deployment" or kind == "StatefulSet":
                    services.append(Service(name=name))
        except Exception:
            continue

    # Check for Helm
    if (repo_path / "helm").is_dir() or any((d / "Chart.yaml").exists() for d in k8s_dirs if d.is_dir()):
        targets.add("Helm")


def _parse_terraform(repo_path: Path, targets: set[str]) -> None:
    """Detect Terraform usage and cloud provider."""
    tf_files = list(repo_path.rglob("*.tf"))
    # Limit depth to avoid scanning deeply nested directories
    tf_files = [f for f in tf_files if len(f.relative_to(repo_path).parts) <= 4]

    if not tf_files:
        return

    targets.add("Terraform")

    for tf in tf_files[:20]:  # limit
        try:
            text = tf.read_text(errors="replace")
        except Exception:
            continue
        if "aws_" in text:
            targets.add("AWS")
        if "google_" in text:
            targets.add("GCP")
        if "azurerm_" in text:
            targets.add("Azure")


def _parse_env_example(repo_path: Path, env_vars: list[EnvVar]) -> None:
    """Parse .env.example for documented env vars."""
    for name in [".env.example", ".env.sample", ".env.template"]:
        path = repo_path / name
        if path.exists():
            try:
                for line in path.read_text(errors="replace").splitlines():
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        var_name = line.split("=")[0].strip()
                        env_vars.append(EnvVar(name=var_name, source=name))
            except Exception:
                pass


def _scan_source_env_vars(source_files: list[Path], env_vars: list[EnvVar]) -> None:
    """Scan source code for os.environ / process.env usage."""
    patterns = [
        # Python: os.environ.get("VAR"), os.getenv("VAR"), os.environ["VAR"]
        re.compile(r'os\.(?:environ\.get|getenv|environ\[)\s*\(\s*["\']([A-Z_][A-Z0-9_]*)["\']'),
        re.compile(r'os\.environ\[\s*["\']([A-Z_][A-Z0-9_]*)["\']'),
        # JS/TS: process.env.VAR, process.env["VAR"]
        re.compile(r'process\.env\.([A-Z_][A-Z0-9_]*)'),
        re.compile(r'process\.env\[\s*["\']([A-Z_][A-Z0-9_]*)["\']'),
        # Go: os.Getenv("VAR")
        re.compile(r'os\.Getenv\(\s*"([A-Z_][A-Z0-9_]*)"'),
    ]

    seen: set[str] = set()
    for fp in source_files:
        if fp.suffix not in {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs"}:
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue
        for pat in patterns:
            for match in pat.finditer(text):
                var_name = match.group(1)
                if var_name not in seen:
                    seen.add(var_name)
                    env_vars.append(EnvVar(name=var_name, source="code"))


def _scan_external_integrations(source_files: list[Path], integrations: set[str]) -> None:
    """Detect external service integrations from imports."""
    py_import_re = re.compile(r'^\s*(?:from|import)\s+([\w.]+)', re.MULTILINE)
    js_import_re = re.compile(r'(?:require\(["\']|from\s+["\'])([\w@/.-]+)')

    for fp in source_files:
        if fp.suffix not in {".py", ".js", ".ts", ".jsx", ".tsx"}:
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        if fp.suffix == ".py":
            for m in py_import_re.finditer(text):
                module = m.group(1)
                for prefix, svc in EXTERNAL_SERVICE_IMPORTS.items():
                    if module == prefix or module.startswith(prefix + "."):
                        integrations.add(svc)
        else:
            for m in js_import_re.finditer(text):
                module = m.group(1)
                for prefix, svc in EXTERNAL_SERVICE_IMPORTS.items():
                    if module == prefix or module.startswith(prefix + "/"):
                        integrations.add(svc)


def _dedup_env_vars(env_vars: list[EnvVar]) -> list[EnvVar]:
    """Deduplicate env vars, preferring the most specific source."""
    priority = {".env.example": 0, ".env.sample": 0, ".env.template": 0,
                "docker-compose": 1, "code": 2}
    seen: dict[str, EnvVar] = {}
    for ev in env_vars:
        if ev.name not in seen or priority.get(ev.source, 99) < priority.get(seen[ev.name].source, 99):
            seen[ev.name] = ev
    return sorted(seen.values(), key=lambda e: e.name)
