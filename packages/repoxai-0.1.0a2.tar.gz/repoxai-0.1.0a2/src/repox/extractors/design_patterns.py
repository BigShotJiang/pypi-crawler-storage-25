"""Dimension 7: Design pattern detection — GoF + architectural patterns."""

from __future__ import annotations

import re
from pathlib import Path

from repox.models import (
    DetectedPattern,
    DesignPatterns,
    Symbol,
    SymbolGraph,
    SymbolKind,
)

# ── Main extraction ──────────────────────────────────────────────────────────


def extract_design_patterns(
    repo_path: Path,
    source_files: list[Path],
    symbol_graph: SymbolGraph,
) -> DesignPatterns:
    """Detect design patterns via naming conventions and AST heuristics."""
    patterns: list[DetectedPattern] = []

    # Build lookup indices
    classes = [s for s in symbol_graph.symbols if s.kind == SymbolKind.CLASS]
    methods_by_class: dict[str, list[Symbol]] = {}
    for s in symbol_graph.symbols:
        if s.kind == SymbolKind.METHOD and s.parent_scope:
            methods_by_class.setdefault(s.parent_scope, []).append(s)

    funcs = [s for s in symbol_graph.symbols if s.kind == SymbolKind.FUNCTION]

    # Run each detection strategy
    patterns.extend(_detect_by_naming(classes, funcs, source_files, repo_path))
    patterns.extend(_detect_singleton(classes, methods_by_class))
    patterns.extend(_detect_factory(classes, methods_by_class, funcs))
    patterns.extend(_detect_builder(classes, methods_by_class))
    patterns.extend(_detect_repository(classes, methods_by_class))
    patterns.extend(_detect_observer(classes, methods_by_class))
    patterns.extend(_detect_strategy(classes, methods_by_class))
    patterns.extend(_detect_middleware(funcs, source_files, repo_path))
    patterns.extend(_detect_decorator_pattern(funcs))
    patterns.extend(_detect_di(classes, methods_by_class))

    # Deduplicate (same class + same pattern)
    seen: set[tuple[str, str]] = set()
    unique: list[DetectedPattern] = []
    for p in patterns:
        key = (p.file_path, p.pattern)
        if key not in seen:
            seen.add(key)
            unique.append(p)

    return DesignPatterns(patterns=unique)


# ── Naming convention detection (fast, high precision) ────────────────────────


_NAMING_PATTERNS: list[tuple[str, str, str]] = [
    (r"(?i)factory", "Factory", "creational"),
    (r"(?i)repository", "Repository", "architectural"),
    (r"(?i)adapter", "Adapter", "structural"),
    (r"(?i)facade", "Facade", "structural"),
    (r"(?i)observer", "Observer", "behavioral"),
    (r"(?i)strategy", "Strategy", "behavioral"),
    (r"(?i)command", "Command", "behavioral"),
    (r"(?i)builder", "Builder", "creational"),
    (r"(?i)proxy", "Proxy", "structural"),
    (r"(?i)decorator", "Decorator", "structural"),
    (r"(?i)middleware", "Middleware", "architectural"),
    (r"(?i)handler", "Handler", "behavioral"),
    (r"(?i)service", "Service Layer", "architectural"),
]


def _detect_by_naming(
    classes: list[Symbol],
    funcs: list[Symbol],
    source_files: list[Path],
    repo_path: Path,
) -> list[DetectedPattern]:
    """Detect patterns from class and file naming conventions."""
    patterns: list[DetectedPattern] = []

    # Class name matching
    for cls in classes:
        for regex, pattern_name, category in _NAMING_PATTERNS:
            if re.search(regex, cls.name):
                # Avoid "Service Layer" for every class named XService unless it's meaningful
                if pattern_name == "Service Layer" and not cls.name.endswith("Service"):
                    continue
                if pattern_name == "Handler" and not cls.name.endswith("Handler"):
                    continue

                patterns.append(DetectedPattern(
                    pattern=pattern_name,
                    category=category,
                    file_path=cls.file_path,
                    participants=[cls.name],
                    confidence=0.75,
                ))

    # File name matching
    for fp in source_files:
        name = fp.stem.lower()
        for regex, pattern_name, category in _NAMING_PATTERNS:
            if re.search(regex, name):
                rel = str(fp.relative_to(repo_path))
                patterns.append(DetectedPattern(
                    pattern=pattern_name,
                    category=category,
                    file_path=rel,
                    participants=[fp.stem],
                    confidence=0.60,
                ))

    return patterns


# ── Singleton detection ──────────────────────────────────────────────────────


def _detect_singleton(
    classes: list[Symbol], methods_by_class: dict[str, list[Symbol]]
) -> list[DetectedPattern]:
    """Detect Singleton pattern: private constructor + getInstance/instance caching."""
    patterns: list[DetectedPattern] = []

    for cls in classes:
        methods = methods_by_class.get(cls.name, [])
        method_names = {m.name for m in methods}

        # Python __new__ with instance check, or class with _instance attribute
        has_new = "__new__" in method_names
        has_get_instance = any(
            n in method_names for n in ("get_instance", "getInstance", "instance")
        )
        has_private_init = any(
            m.name == "__init__" and m.visibility in ("private", "protected")
            for m in methods
        )

        if has_new or has_get_instance or has_private_init:
            patterns.append(DetectedPattern(
                pattern="Singleton",
                category="creational",
                file_path=cls.file_path,
                participants=[cls.name],
                confidence=0.80 if has_get_instance else 0.60,
            ))

    return patterns


# ── Factory detection ────────────────────────────────────────────────────────


def _detect_factory(
    classes: list[Symbol],
    methods_by_class: dict[str, list[Symbol]],
    funcs: list[Symbol],
) -> list[DetectedPattern]:
    """Detect Factory pattern: create/build methods returning different types."""
    patterns: list[DetectedPattern] = []

    for cls in classes:
        methods = methods_by_class.get(cls.name, [])
        factory_methods = [
            m for m in methods
            if m.name in ("create", "build", "make", "from_dict", "from_json", "from_config")
            or m.name.startswith("create_") or m.name.startswith("build_")
        ]
        if factory_methods:
            patterns.append(DetectedPattern(
                pattern="Factory",
                category="creational",
                file_path=cls.file_path,
                participants=[cls.name] + [m.name for m in factory_methods],
                confidence=0.70,
            ))

    # Standalone factory functions
    for func in funcs:
        if (func.name.startswith("create_") or func.name.startswith("build_")
                or func.name.startswith("make_")):
            patterns.append(DetectedPattern(
                pattern="Factory",
                category="creational",
                file_path=func.file_path,
                participants=[func.name],
                confidence=0.65,
            ))

    return patterns


# ── Builder detection ────────────────────────────────────────────────────────


def _detect_builder(
    classes: list[Symbol], methods_by_class: dict[str, list[Symbol]]
) -> list[DetectedPattern]:
    """Detect Builder pattern: method chaining with build() method."""
    patterns: list[DetectedPattern] = []

    for cls in classes:
        methods = methods_by_class.get(cls.name, [])
        method_names = {m.name for m in methods}

        has_build = "build" in method_names
        # Methods returning self (chaining) — check for with_* or set_* methods
        chaining_methods = [
            m for m in methods
            if m.name.startswith("with_") or m.name.startswith("set_")
        ]

        if has_build and len(chaining_methods) >= 2:
            patterns.append(DetectedPattern(
                pattern="Builder",
                category="creational",
                file_path=cls.file_path,
                participants=[cls.name, "build"] + [m.name for m in chaining_methods[:3]],
                confidence=0.85,
            ))

    return patterns


# ── Repository detection ─────────────────────────────────────────────────────


_REPO_METHODS = {"get", "find", "create", "update", "delete", "save", "list", "all",
                 "find_by_id", "find_all", "get_by_id", "get_all", "find_one"}


def _detect_repository(
    classes: list[Symbol], methods_by_class: dict[str, list[Symbol]]
) -> list[DetectedPattern]:
    """Detect Repository pattern: CRUD method set wrapping data access."""
    patterns: list[DetectedPattern] = []

    for cls in classes:
        methods = methods_by_class.get(cls.name, [])
        method_names = {m.name.lower() for m in methods}

        matches = method_names & _REPO_METHODS
        if len(matches) >= 3:
            patterns.append(DetectedPattern(
                pattern="Repository",
                category="architectural",
                file_path=cls.file_path,
                participants=[cls.name] + sorted(matches)[:4],
                confidence=0.80,
            ))

    return patterns


# ── Observer/Event Emitter detection ─────────────────────────────────────────


def _detect_observer(
    classes: list[Symbol], methods_by_class: dict[str, list[Symbol]]
) -> list[DetectedPattern]:
    """Detect Observer pattern: subscribe/on + emit/notify methods."""
    patterns: list[DetectedPattern] = []

    subscribe_names = {"subscribe", "on", "add_listener", "register", "attach", "add_observer"}
    emit_names = {"emit", "notify", "publish", "dispatch", "trigger", "fire"}

    for cls in classes:
        methods = methods_by_class.get(cls.name, [])
        method_names = {m.name for m in methods}

        has_subscribe = bool(method_names & subscribe_names)
        has_emit = bool(method_names & emit_names)

        if has_subscribe and has_emit:
            patterns.append(DetectedPattern(
                pattern="Observer",
                category="behavioral",
                file_path=cls.file_path,
                participants=[cls.name],
                confidence=0.85,
            ))

    return patterns


# ── Strategy detection ───────────────────────────────────────────────────────


def _detect_strategy(
    classes: list[Symbol], methods_by_class: dict[str, list[Symbol]]
) -> list[DetectedPattern]:
    """Detect Strategy pattern: interface with multiple implementations injected via constructor."""
    patterns: list[DetectedPattern] = []

    # Find interfaces/protocols/ABCs that have multiple implementations
    interface_names: set[str] = set()
    for cls in classes:
        if cls.kind in (SymbolKind.CLASS, SymbolKind.INTERFACE):
            if any(b in ("ABC", "Protocol", "Interface", "abc.ABC") for b in cls.base_classes):
                interface_names.add(cls.name)

    # Find classes implementing those interfaces
    for iface in interface_names:
        implementors = [c for c in classes if iface in c.base_classes]
        if len(implementors) >= 2:
            patterns.append(DetectedPattern(
                pattern="Strategy",
                category="behavioral",
                file_path=implementors[0].file_path,
                participants=[iface] + [c.name for c in implementors[:3]],
                confidence=0.80,
            ))

    return patterns


# ── Middleware detection ─────────────────────────────────────────────────────


def _detect_middleware(
    funcs: list[Symbol], source_files: list[Path], repo_path: Path
) -> list[DetectedPattern]:
    """Detect Middleware pattern: functions with next() chain pattern."""
    patterns: list[DetectedPattern] = []

    for func in funcs:
        params = [p.name for p in func.parameters]
        # Express-style (req, res, next) or ASGI-style (request, call_next)
        if "next" in params or "call_next" in params or "next_handler" in params:
            patterns.append(DetectedPattern(
                pattern="Middleware",
                category="architectural",
                file_path=func.file_path,
                participants=[func.name],
                confidence=0.75,
            ))

    return patterns


# ── Decorator pattern detection ──────────────────────────────────────────────


def _detect_decorator_pattern(funcs: list[Symbol]) -> list[DetectedPattern]:
    """Detect Decorator pattern: functions wrapping functions (Python decorators that are user-defined)."""
    patterns: list[DetectedPattern] = []

    for func in funcs:
        # Heuristic: function that takes a function parameter and returns a function
        param_names = {p.name for p in func.parameters}
        param_types = {p.type_annotation for p in func.parameters if p.type_annotation}

        is_decorator_like = (
            ("func" in param_names or "fn" in param_names or "f" in param_names
             or "Callable" in str(param_types))
            and func.return_type and "Callable" in str(func.return_type)
        )

        if is_decorator_like:
            patterns.append(DetectedPattern(
                pattern="Decorator",
                category="structural",
                file_path=func.file_path,
                participants=[func.name],
                confidence=0.70,
            ))

    return patterns


# ── Dependency Injection detection ───────────────────────────────────────────


def _detect_di(
    classes: list[Symbol], methods_by_class: dict[str, list[Symbol]]
) -> list[DetectedPattern]:
    """Detect Dependency Injection: constructor accepts abstract type parameters."""
    patterns: list[DetectedPattern] = []

    # Build set of known abstract/interface names
    abstract_names: set[str] = set()
    for cls in classes:
        if any(b in ("ABC", "Protocol", "Interface", "abc.ABC") for b in cls.base_classes):
            abstract_names.add(cls.name)

    for cls in classes:
        methods = methods_by_class.get(cls.name, [])
        init_methods = [m for m in methods if m.name in ("__init__", "constructor")]

        for init in init_methods:
            abstract_params = [
                p for p in init.parameters
                if p.type_annotation and p.type_annotation in abstract_names
            ]
            if abstract_params:
                patterns.append(DetectedPattern(
                    pattern="Dependency Injection",
                    category="architectural",
                    file_path=cls.file_path,
                    participants=[cls.name] + [p.type_annotation for p in abstract_params],
                    confidence=0.85,
                ))

    return patterns
