"""Dimension 3: Symbol graph — tree-sitter multi-language AST extraction."""

from __future__ import annotations

from pathlib import Path

import tree_sitter_language_pack as tslp
from tree_sitter import Node

from repox.models import Parameter, Symbol, SymbolGraph, SymbolKind

# Map file extensions to tree-sitter language names
EXTENSION_TO_LANGUAGE: dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".rb": "ruby",
    ".php": "php",
}


def extract_symbols(repo_path: Path, source_files: list[Path]) -> SymbolGraph:
    """Extract all code symbols from source files using tree-sitter."""
    graph = SymbolGraph()
    languages_seen: set[str] = set()

    for file_path in source_files:
        lang = EXTENSION_TO_LANGUAGE.get(file_path.suffix)
        if not lang:
            continue

        try:
            parser = tslp.get_parser(lang)
        except Exception:
            continue

        try:
            code = file_path.read_bytes()
        except (OSError, UnicodeDecodeError):
            continue

        rel_path = str(file_path.relative_to(repo_path))
        tree = parser.parse(code)

        extractor = _LANGUAGE_EXTRACTORS.get(lang, _extract_generic)
        symbols = extractor(tree.root_node, rel_path, code)
        graph.symbols.extend(symbols)
        languages_seen.add(lang)
        graph.files_parsed += 1

    graph.languages_parsed = sorted(languages_seen)
    return graph


# ── Python Extraction ────────────────────────────────────────────────────────


def _extract_python(root: Node, file_path: str, code: bytes) -> list[Symbol]:
    """Extract symbols from a Python AST."""
    symbols: list[Symbol] = []
    _walk_python(root, file_path, code, symbols, parent_scope=None)
    return symbols


def _walk_python(
    node: Node, file_path: str, code: bytes, symbols: list[Symbol], parent_scope: str | None
) -> None:
    for child in node.children:
        if child.type == "class_definition":
            sym = _extract_python_class(child, file_path, code, parent_scope)
            if sym:
                symbols.append(sym)
                # Extract methods inside the class
                body = _find_child(child, "block")
                if body:
                    _walk_python(body, file_path, code, symbols, parent_scope=sym.name)

        elif child.type == "function_definition":
            sym = _extract_python_function(child, file_path, code, parent_scope)
            if sym:
                symbols.append(sym)

        elif child.type == "decorated_definition":
            # Unwrap the decorated definition
            decorators = _get_python_decorators(child)
            inner = _find_child(child, "function_definition") or _find_child(child, "class_definition")
            if inner and inner.type == "function_definition":
                sym = _extract_python_function(inner, file_path, code, parent_scope)
                if sym:
                    sym.decorators = decorators
                    if "staticmethod" in decorators:
                        sym.is_static = True
                    if parent_scope:
                        sym.kind = SymbolKind.METHOD
                    symbols.append(sym)
            elif inner and inner.type == "class_definition":
                sym = _extract_python_class(inner, file_path, code, parent_scope)
                if sym:
                    sym.decorators = decorators
                    symbols.append(sym)
                    body = _find_child(inner, "block")
                    if body:
                        _walk_python(body, file_path, code, symbols, parent_scope=sym.name)

        elif child.type == "expression_statement":
            # Module-level assignments (constants)
            assign = _find_child(child, "assignment")
            if assign and parent_scope is None:
                sym = _extract_python_assignment(assign, file_path, code)
                if sym:
                    symbols.append(sym)

        elif child.type == "assignment" and parent_scope is None:
            sym = _extract_python_assignment(child, file_path, code)
            if sym:
                symbols.append(sym)


def _extract_python_class(node: Node, file_path: str, code: bytes, parent_scope: str | None) -> Symbol | None:
    name_node = _find_child(node, "identifier")
    if not name_node:
        return None

    name = name_node.text.decode()

    # Base classes
    bases: list[str] = []
    arg_list = _find_child(node, "argument_list")
    if arg_list:
        for arg in arg_list.children:
            if arg.type == "identifier":
                bases.append(arg.text.decode())
            elif arg.type == "attribute":
                bases.append(arg.text.decode())

    # Docstring
    docstring = _get_python_docstring(node)

    return Symbol(
        name=name,
        kind=SymbolKind.CLASS,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
        base_classes=bases,
        docstring=docstring,
        parent_scope=parent_scope,
    )


def _extract_python_function(
    node: Node, file_path: str, code: bytes, parent_scope: str | None
) -> Symbol | None:
    name_node = _find_child(node, "identifier")
    if not name_node:
        return None

    name = name_node.text.decode()

    # Determine kind
    kind = SymbolKind.METHOD if parent_scope else SymbolKind.FUNCTION

    # Parameters
    params = _get_python_parameters(node)

    # Return type
    return_type = None
    rt_node = _find_child(node, "type")
    if rt_node:
        return_type = rt_node.text.decode()

    # Async
    is_async = any(c.type == "async" for c in node.parent.children) if node.parent else False
    # Also check if function_definition text starts with "async"
    if not is_async:
        is_async = node.parent is not None and node.parent.type == "function_definition"
        if not is_async:
            # Check in the node's own prefix
            prev = node.prev_sibling
            is_async = prev is not None and prev.type == "async"

    # Simpler async check — look at full text
    func_text_start = code[node.start_byte:min(node.start_byte + 20, node.end_byte)].decode(errors="replace")
    if not is_async:
        is_async = "async " in code[max(0, node.start_byte - 10):node.start_byte + 10].decode(errors="replace")

    # Docstring
    docstring = _get_python_docstring(node)

    # Visibility
    visibility = "private" if name.startswith("_") else "public"
    if name.startswith("__") and not name.endswith("__"):
        visibility = "private"
    elif name.startswith("_"):
        visibility = "protected"

    return Symbol(
        name=name,
        kind=kind,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
        parameters=params,
        return_type=return_type,
        docstring=docstring,
        visibility=visibility,
        is_async=is_async,
        parent_scope=parent_scope,
    )


def _get_python_parameters(func_node: Node) -> list[Parameter]:
    """Extract parameters from a Python function definition."""
    params: list[Parameter] = []
    param_node = _find_child(func_node, "parameters")
    if not param_node:
        return params

    for child in param_node.children:
        if child.type == "identifier":
            name = child.text.decode()
            if name != "self" and name != "cls":
                params.append(Parameter(name=name))

        elif child.type == "typed_parameter":
            name_n = _find_child(child, "identifier")
            type_n = _find_child(child, "type")
            name = name_n.text.decode() if name_n else ""
            type_ann = type_n.text.decode() if type_n else None
            if name and name != "self" and name != "cls":
                params.append(Parameter(name=name, type_annotation=type_ann))

        elif child.type == "typed_default_parameter":
            name_n = _find_child(child, "identifier")
            type_n = _find_child(child, "type")
            name = name_n.text.decode() if name_n else ""
            type_ann = type_n.text.decode() if type_n else None
            # Default value is the last non-type, non-name, non-= child
            default = None
            for c in reversed(child.children):
                if c.type not in ("identifier", "type", "=", ":"):
                    default = c.text.decode()
                    break
            if name and name != "self" and name != "cls":
                params.append(Parameter(name=name, type_annotation=type_ann, default=default))

        elif child.type == "default_parameter":
            name_n = _find_child(child, "identifier")
            name = name_n.text.decode() if name_n else ""
            default = None
            for c in reversed(child.children):
                if c.type not in ("identifier", "="):
                    default = c.text.decode()
                    break
            if name and name != "self" and name != "cls":
                params.append(Parameter(name=name, default=default))

    return params


def _get_python_decorators(decorated_node: Node) -> list[str]:
    """Extract decorator names from a decorated_definition."""
    decorators: list[str] = []
    for child in decorated_node.children:
        if child.type == "decorator":
            # Get the decorator expression (skip @)
            for c in child.children:
                if c.type in ("identifier", "attribute", "call"):
                    text = c.text.decode()
                    # For calls like @app.get("/path"), just get the name part
                    if "(" in text:
                        text = text[:text.index("(")]
                    decorators.append(text)
                    break
    return decorators


def _get_python_docstring(node: Node) -> str | None:
    """Extract docstring from a class or function definition."""
    body = _find_child(node, "block")
    if not body or not body.children:
        return None

    # Look for the first string node in the block — could be:
    # 1. expression_statement > string (older tree-sitter)
    # 2. string directly in block (newer tree-sitter)
    for child in body.children:
        if child.type == "expression_statement":
            string_node = _find_child(child, "string") or _find_child(child, "concatenated_string")
            if string_node:
                return _extract_string_content(string_node)
            break
        elif child.type == "string":
            return _extract_string_content(child)
        elif child.type not in (":", "newline", "indent", "NEWLINE", "INDENT", "comment"):
            break

    return None


def _extract_string_content(string_node: Node) -> str | None:
    """Extract the text content from a string node, stripping quotes."""
    # Try to find string_content child (newer tree-sitter with string_start/content/end)
    for child in string_node.children:
        if child.type == "string_content":
            return child.text.decode().strip()

    # Fallback: strip quotes from full text
    text = string_node.text.decode()
    for q in ('"""', "'''"):
        if text.startswith(q) and text.endswith(q):
            return text[3:-3].strip()
    for q in ('"', "'"):
        if text.startswith(q) and text.endswith(q):
            return text[1:-1].strip()

    return text


def _extract_python_assignment(node: Node, file_path: str, code: bytes) -> Symbol | None:
    """Extract a module-level constant/variable assignment."""
    # Only extract UPPER_CASE or type-annotated assignments
    left = node.children[0] if node.children else None
    if not left or left.type != "identifier":
        return None

    name = left.text.decode()
    # Only capture ALL_CAPS constants at module level
    if not name.isupper() and not name.startswith("__"):
        return None

    return Symbol(
        name=name,
        kind=SymbolKind.CONSTANT,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
    )


# ── JavaScript/TypeScript Extraction ─────────────────────────────────────────


def _extract_js_ts(root: Node, file_path: str, code: bytes) -> list[Symbol]:
    """Extract symbols from JavaScript/TypeScript AST."""
    symbols: list[Symbol] = []
    _walk_js_ts(root, file_path, code, symbols, parent_scope=None)
    return symbols


def _walk_js_ts(
    node: Node, file_path: str, code: bytes, symbols: list[Symbol], parent_scope: str | None
) -> None:
    for child in node.children:
        if child.type in ("function_declaration", "generator_function_declaration"):
            sym = _extract_js_function(child, file_path, code, parent_scope)
            if sym:
                symbols.append(sym)

        elif child.type == "class_declaration":
            sym = _extract_js_class(child, file_path, code, parent_scope)
            if sym:
                symbols.append(sym)
                body = _find_child(child, "class_body")
                if body:
                    _walk_js_ts(body, file_path, code, symbols, parent_scope=sym.name)

        elif child.type == "method_definition":
            sym = _extract_js_method(child, file_path, code, parent_scope)
            if sym:
                symbols.append(sym)

        elif child.type in ("export_statement", "export_default_declaration"):
            _walk_js_ts(child, file_path, code, symbols, parent_scope)

        elif child.type == "lexical_declaration":
            # const/let declarations — check for arrow functions or constants
            for decl in child.children:
                if decl.type == "variable_declarator":
                    sym = _extract_js_variable(decl, child, file_path, code, parent_scope)
                    if sym:
                        symbols.append(sym)

        elif child.type == "interface_declaration":
            sym = _extract_js_interface(child, file_path, code)
            if sym:
                symbols.append(sym)

        elif child.type == "type_alias_declaration":
            name_node = _find_child(child, "type_identifier") or _find_child(child, "identifier")
            if name_node:
                symbols.append(Symbol(
                    name=name_node.text.decode(),
                    kind=SymbolKind.TYPE,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                ))

        elif child.type == "enum_declaration":
            name_node = _find_child(child, "identifier")
            if name_node:
                symbols.append(Symbol(
                    name=name_node.text.decode(),
                    kind=SymbolKind.ENUM,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                ))


def _extract_js_function(node: Node, file_path: str, code: bytes, parent_scope: str | None) -> Symbol | None:
    name_node = _find_child(node, "identifier")
    if not name_node:
        return None

    is_async = any(c.type == "async" for c in node.children)
    params = _get_js_parameters(node)
    return_type = _get_js_return_type(node)

    return Symbol(
        name=name_node.text.decode(),
        kind=SymbolKind.FUNCTION,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
        parameters=params,
        return_type=return_type,
        is_async=is_async,
        parent_scope=parent_scope,
        exported=_is_exported(node),
    )


def _extract_js_class(node: Node, file_path: str, code: bytes, parent_scope: str | None) -> Symbol | None:
    name_node = _find_child(node, "type_identifier") or _find_child(node, "identifier")
    if not name_node:
        return None

    bases: list[str] = []
    heritage = _find_child(node, "class_heritage")
    if heritage:
        for c in heritage.children:
            if c.type in ("identifier", "type_identifier"):
                bases.append(c.text.decode())

    return Symbol(
        name=name_node.text.decode(),
        kind=SymbolKind.CLASS,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
        base_classes=bases,
        parent_scope=parent_scope,
        exported=_is_exported(node),
    )


def _extract_js_method(node: Node, file_path: str, code: bytes, parent_scope: str | None) -> Symbol | None:
    name_node = _find_child(node, "property_identifier") or _find_child(node, "identifier")
    if not name_node:
        return None

    is_async = any(c.type == "async" for c in node.children)
    is_static = any(c.type == "static" for c in node.children)
    params = _get_js_parameters(node)
    return_type = _get_js_return_type(node)

    name = name_node.text.decode()
    visibility = "private" if name.startswith("#") or name.startswith("_") else "public"

    return Symbol(
        name=name,
        kind=SymbolKind.METHOD,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
        parameters=params,
        return_type=return_type,
        is_async=is_async,
        is_static=is_static,
        visibility=visibility,
        parent_scope=parent_scope,
    )


def _extract_js_variable(
    decl_node: Node, parent: Node, file_path: str, code: bytes, parent_scope: str | None
) -> Symbol | None:
    """Extract a const/let variable — detect arrow functions vs constants."""
    name_node = _find_child(decl_node, "identifier")
    if not name_node:
        return None

    name = name_node.text.decode()
    value = None
    for child in decl_node.children:
        if child.type == "arrow_function":
            value = child
            break

    if value and value.type == "arrow_function":
        is_async = any(c.type == "async" for c in value.children)
        params = _get_js_parameters(value)
        return_type = _get_js_return_type(value)
        return Symbol(
            name=name,
            kind=SymbolKind.FUNCTION,
            file_path=file_path,
            line_start=parent.start_point[0] + 1,
            line_end=parent.end_point[0] + 1,
            parameters=params,
            return_type=return_type,
            is_async=is_async,
            parent_scope=parent_scope,
            exported=_is_exported(parent),
        )
    elif name.isupper() or name[0].isupper():
        # UPPER_CASE constants or PascalCase types
        return Symbol(
            name=name,
            kind=SymbolKind.CONSTANT,
            file_path=file_path,
            line_start=parent.start_point[0] + 1,
            line_end=parent.end_point[0] + 1,
            parent_scope=parent_scope,
            exported=_is_exported(parent),
        )

    return None


def _extract_js_interface(node: Node, file_path: str, code: bytes) -> Symbol | None:
    name_node = _find_child(node, "type_identifier") or _find_child(node, "identifier")
    if not name_node:
        return None

    bases: list[str] = []
    extends = _find_child(node, "extends_type_clause")
    if extends:
        for c in extends.children:
            if c.type in ("type_identifier", "identifier"):
                bases.append(c.text.decode())

    return Symbol(
        name=name_node.text.decode(),
        kind=SymbolKind.INTERFACE,
        file_path=file_path,
        line_start=node.start_point[0] + 1,
        line_end=node.end_point[0] + 1,
        base_classes=bases,
        exported=_is_exported(node),
    )


def _get_js_parameters(node: Node) -> list[Parameter]:
    """Extract parameters from JS/TS function/method/arrow."""
    params: list[Parameter] = []
    fp = _find_child(node, "formal_parameters")
    if not fp:
        return params

    for child in fp.children:
        if child.type == "identifier":
            params.append(Parameter(name=child.text.decode()))
        elif child.type in ("required_parameter", "optional_parameter"):
            name_n = None
            type_n = None
            for c in child.children:
                if c.type == "identifier":
                    name_n = c
                elif c.type == "type_annotation":
                    type_n = c
            if name_n:
                type_ann = type_n.text.decode().lstrip(": ") if type_n else None
                params.append(Parameter(name=name_n.text.decode(), type_annotation=type_ann))

    return params


def _get_js_return_type(node: Node) -> str | None:
    """Get return type annotation from a JS/TS function."""
    for child in node.children:
        if child.type == "type_annotation":
            return child.text.decode().lstrip(": ")
    return None


def _is_exported(node: Node) -> bool:
    """Check if a node is inside an export statement."""
    parent = node.parent
    while parent:
        if parent.type in ("export_statement", "export_default_declaration"):
            return True
        parent = parent.parent
    return False


# ── Go Extraction ────────────────────────────────────────────────────────────


def _extract_go(root: Node, file_path: str, code: bytes) -> list[Symbol]:
    """Extract symbols from Go AST."""
    symbols: list[Symbol] = []

    for child in root.children:
        if child.type == "function_declaration":
            name_node = _find_child(child, "identifier")
            if name_node:
                name = name_node.text.decode()
                symbols.append(Symbol(
                    name=name,
                    kind=SymbolKind.FUNCTION,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                    visibility="public" if name[0].isupper() else "private",
                ))

        elif child.type == "method_declaration":
            name_node = _find_child(child, "field_identifier")
            if name_node:
                name = name_node.text.decode()
                # Try to get receiver type
                receiver = _find_child(child, "parameter_list")
                parent_scope = None
                if receiver:
                    for c in receiver.children:
                        if c.type == "parameter_declaration":
                            type_id = _find_child(c, "type_identifier") or _find_child(c, "pointer_type")
                            if type_id:
                                parent_scope = type_id.text.decode().lstrip("*")
                                break

                symbols.append(Symbol(
                    name=name,
                    kind=SymbolKind.METHOD,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                    visibility="public" if name[0].isupper() else "private",
                    parent_scope=parent_scope,
                ))

        elif child.type == "type_declaration":
            for spec in child.children:
                if spec.type == "type_spec":
                    name_node = _find_child(spec, "type_identifier")
                    if name_node:
                        name = name_node.text.decode()
                        # Determine if struct or interface
                        kind = SymbolKind.TYPE
                        if _find_child(spec, "struct_type"):
                            kind = SymbolKind.CLASS  # struct as class analog
                        elif _find_child(spec, "interface_type"):
                            kind = SymbolKind.INTERFACE

                        symbols.append(Symbol(
                            name=name,
                            kind=kind,
                            file_path=file_path,
                            line_start=spec.start_point[0] + 1,
                            line_end=spec.end_point[0] + 1,
                            visibility="public" if name[0].isupper() else "private",
                        ))

    return symbols


# ── Rust Extraction ──────────────────────────────────────────────────────────


def _extract_rust(root: Node, file_path: str, code: bytes) -> list[Symbol]:
    """Extract symbols from Rust AST."""
    symbols: list[Symbol] = []
    _walk_rust(root, file_path, code, symbols, parent_scope=None)
    return symbols


def _walk_rust(
    node: Node, file_path: str, code: bytes, symbols: list[Symbol], parent_scope: str | None
) -> None:
    for child in node.children:
        if child.type == "function_item":
            name_node = _find_child(child, "identifier")
            if name_node:
                name = name_node.text.decode()
                is_pub = any(c.type == "visibility_modifier" for c in child.children)
                is_async = any(
                    c.type == "async" or
                    (c.type == "function_modifiers" and any(gc.type == "async" for gc in c.children))
                    for c in child.children
                )
                symbols.append(Symbol(
                    name=name,
                    kind=SymbolKind.METHOD if parent_scope else SymbolKind.FUNCTION,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                    visibility="public" if is_pub else "private",
                    is_async=is_async,
                    parent_scope=parent_scope,
                ))

        elif child.type == "struct_item":
            name_node = _find_child(child, "type_identifier")
            if name_node:
                name = name_node.text.decode()
                is_pub = any(c.type == "visibility_modifier" for c in child.children)
                symbols.append(Symbol(
                    name=name,
                    kind=SymbolKind.CLASS,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                    visibility="public" if is_pub else "private",
                ))

        elif child.type == "enum_item":
            name_node = _find_child(child, "type_identifier")
            if name_node:
                name = name_node.text.decode()
                symbols.append(Symbol(
                    name=name,
                    kind=SymbolKind.ENUM,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                ))

        elif child.type == "trait_item":
            name_node = _find_child(child, "type_identifier")
            if name_node:
                name = name_node.text.decode()
                symbols.append(Symbol(
                    name=name,
                    kind=SymbolKind.INTERFACE,
                    file_path=file_path,
                    line_start=child.start_point[0] + 1,
                    line_end=child.end_point[0] + 1,
                ))

        elif child.type == "impl_item":
            # Get the type being implemented
            type_node = _find_child(child, "type_identifier")
            scope = type_node.text.decode() if type_node else None
            body = _find_child(child, "declaration_list")
            if body and scope:
                _walk_rust(body, file_path, code, symbols, parent_scope=scope)


# ── Generic Extraction (fallback) ────────────────────────────────────────────


def _extract_generic(root: Node, file_path: str, code: bytes) -> list[Symbol]:
    """Fallback extractor for languages without specific support."""
    symbols: list[Symbol] = []

    def walk(node: Node, parent_scope: str | None = None) -> None:
        for child in node.children:
            if "function" in child.type and "definition" in child.type or "declaration" in child.type:
                name_node = _find_child(child, "identifier") or _find_child(child, "property_identifier")
                if name_node:
                    symbols.append(Symbol(
                        name=name_node.text.decode(),
                        kind=SymbolKind.FUNCTION,
                        file_path=file_path,
                        line_start=child.start_point[0] + 1,
                        line_end=child.end_point[0] + 1,
                        parent_scope=parent_scope,
                    ))
            elif "class" in child.type and "definition" in child.type or "declaration" in child.type:
                name_node = _find_child(child, "identifier")
                if name_node:
                    name = name_node.text.decode()
                    symbols.append(Symbol(
                        name=name,
                        kind=SymbolKind.CLASS,
                        file_path=file_path,
                        line_start=child.start_point[0] + 1,
                        line_end=child.end_point[0] + 1,
                        parent_scope=parent_scope,
                    ))
                    walk(child, parent_scope=name)
            else:
                walk(child, parent_scope)

    walk(root)
    return symbols


# ── Shared helpers ───────────────────────────────────────────────────────────


def _find_child(node: Node, type_name: str) -> Node | None:
    """Find the first direct child of the given type."""
    for child in node.children:
        if child.type == type_name:
            return child
    return None


# ── Language extractor registry ──────────────────────────────────────────────

_LANGUAGE_EXTRACTORS = {
    "python": _extract_python,
    "javascript": _extract_js_ts,
    "typescript": _extract_js_ts,
    "tsx": _extract_js_ts,
    "go": _extract_go,
    "rust": _extract_rust,
}
