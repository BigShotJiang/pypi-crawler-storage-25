"""Dimension 13: Custom rules — parse AGENTS.md / patchmate.yaml / .cursorrules."""

from __future__ import annotations

from pathlib import Path

import yaml

from repox.models import CustomRule, CustomRules, RuleSource

# Files to check in priority order
RULE_FILES: list[tuple[str, RuleSource]] = [
    ("patchmate.yaml", RuleSource.PATCHMATE_YAML),
    ("AGENTS.md", RuleSource.AGENTS_MD),
    ("CLAUDE.md", RuleSource.CLAUDE_MD),
    (".cursorrules", RuleSource.CURSORRULES),
    (".github/copilot-instructions.md", RuleSource.COPILOT_INSTRUCTIONS),
]


def extract_custom_rules(repo_path: Path) -> CustomRules:
    """Read and parse team-provided rule files from the repo."""
    result = CustomRules()

    for filename, source in RULE_FILES:
        file_path = repo_path / filename
        if file_path.exists():
            content = _read_rule_file(file_path, source)
            if content:
                result.rules.append(CustomRule(
                    source=source,
                    content=content,
                    file_path=str(file_path.relative_to(repo_path)),
                ))
                result.sources_found.append(filename)

    return result


def _read_rule_file(file_path: Path, source: RuleSource) -> str | None:
    """Read and optionally parse a rule file. Returns content as string."""
    try:
        text = file_path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        return None

    if not text:
        return None

    if source == RuleSource.PATCHMATE_YAML:
        return _parse_patchmate_yaml(text)

    # Markdown and plain text files are returned as-is
    return text


def _parse_patchmate_yaml(text: str) -> str | None:
    """Parse patchmate.yaml and convert to readable rules string."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError:
        return text  # Fall back to raw content on parse failure

    if not isinstance(data, dict):
        return text

    lines: list[str] = []

    # Extract rules section
    rules = data.get("rules", [])
    if isinstance(rules, list):
        for rule in rules:
            if isinstance(rule, str):
                lines.append(f"- {rule}")
            elif isinstance(rule, dict):
                for key, val in rule.items():
                    lines.append(f"- **{key}:** {val}")

    # Extract conventions
    conventions = data.get("conventions", {})
    if isinstance(conventions, dict):
        for key, val in conventions.items():
            if isinstance(val, list):
                lines.append(f"- **{key}:** {', '.join(str(v) for v in val)}")
            else:
                lines.append(f"- **{key}:** {val}")

    # Extract restrictions
    restrictions = data.get("restrictions", {})
    if isinstance(restrictions, dict):
        no_modify = restrictions.get("no_modify", [])
        if no_modify:
            lines.append(f"- **Do not modify:** {', '.join(no_modify)}")

        require_review = restrictions.get("require_review", [])
        if require_review:
            lines.append(f"- **Require review:** {', '.join(require_review)}")

    # If we parsed structured content, return it; otherwise return raw
    if lines:
        return "\n".join(lines)

    return text
