"""Dims 11+12: Hotspot analysis + knowledge map from git history."""

from __future__ import annotations

import subprocess
from collections import Counter, defaultdict
from pathlib import Path

from repox.models import (
    FileOwnership,
    Hotspot,
    HotspotAnalysis,
    KnowledgeMap,
    ModuleBusFactor,
    TemporalCoupling,
)


def extract_hotspots(repo_path: Path, source_files: list[Path]) -> HotspotAnalysis:
    """Mine git history for hotspot analysis — change frequency, churn, temporal coupling."""
    if not _is_git_repo(repo_path):
        return HotspotAnalysis()

    source_rels = {str(f.relative_to(repo_path)) for f in source_files}

    # Get change frequency per file (last 12 months)
    change_freq = _get_change_frequency(repo_path, months=12)
    # Get churn per file (lines added + deleted)
    churn_map = _get_churn(repo_path, months=12)
    # Get line counts as complexity proxy
    line_counts = _get_line_counts(source_files, repo_path)

    hotspots: list[Hotspot] = []
    for rel_path in source_rels:
        freq = change_freq.get(rel_path, 0)
        churn = churn_map.get(rel_path, 0)
        complexity = line_counts.get(rel_path, 0)

        if freq == 0:
            continue

        score = freq * (complexity / 100.0) if complexity > 0 else freq
        hotspots.append(Hotspot(
            file_path=rel_path,
            change_frequency=freq,
            churn=churn,
            complexity=float(complexity),
            score=round(score, 2),
        ))

    hotspots.sort(key=lambda h: h.score, reverse=True)

    # Temporal coupling
    couplings = _get_temporal_coupling(repo_path, months=12, source_rels=source_rels)

    return HotspotAnalysis(
        hotspots=hotspots[:50],  # top 50
        temporal_couplings=couplings[:30],  # top 30
        analysis_period_months=12,
    )


def extract_knowledge_map(repo_path: Path, source_files: list[Path]) -> KnowledgeMap:
    """Mine git history for code ownership and knowledge distribution."""
    if not _is_git_repo(repo_path):
        return KnowledgeMap()

    source_rels = {str(f.relative_to(repo_path)) for f in source_files}

    # Get author contributions per file
    file_authors = _get_file_authors(repo_path, source_rels)

    ownerships: list[FileOwnership] = []
    for rel_path, authors in file_authors.items():
        if not authors:
            continue
        total = sum(authors.values())
        top_author, top_count = authors.most_common(1)[0]
        pct = (top_count / total) * 100 if total > 0 else 0
        is_island = pct > 95 and total >= 3  # at least 3 commits to be meaningful

        ownerships.append(FileOwnership(
            file_path=rel_path,
            primary_author=top_author,
            contribution_pct=round(pct, 1),
            is_knowledge_island=is_island,
        ))

    ownerships.sort(key=lambda o: o.contribution_pct, reverse=True)

    # Bus factor per top-level module
    bus_factors = _compute_bus_factors(file_authors)

    return KnowledgeMap(
        file_ownerships=ownerships[:100],  # top 100
        bus_factors=bus_factors,
    )


def _is_git_repo(repo_path: Path) -> bool:
    return (repo_path / ".git").exists()


def _run_git(repo_path: Path, args: list[str], timeout: int = 30) -> str:
    """Run a git command and return stdout."""
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return ""


def _get_change_frequency(repo_path: Path, months: int = 12) -> dict[str, int]:
    """Count commits per file in the last N months."""
    output = _run_git(repo_path, [
        "log", f"--since={months} months ago", "--name-only", "--format=",
    ])
    freq: Counter[str] = Counter()
    for line in output.splitlines():
        line = line.strip()
        if line:
            freq[line] += 1
    return dict(freq)


def _get_churn(repo_path: Path, months: int = 12) -> dict[str, int]:
    """Get lines added + deleted per file."""
    output = _run_git(repo_path, [
        "log", f"--since={months} months ago", "--numstat", "--format=",
    ])
    churn: Counter[str] = Counter()
    for line in output.splitlines():
        parts = line.split("\t")
        if len(parts) == 3:
            added, deleted, path = parts
            try:
                churn[path] += int(added) + int(deleted)
            except ValueError:
                pass  # binary files show "-"
    return dict(churn)


def _get_line_counts(source_files: list[Path], repo_path: Path) -> dict[str, int]:
    """Count lines of code per file as a complexity proxy."""
    counts: dict[str, int] = {}
    for fp in source_files:
        try:
            text = fp.read_text(errors="replace")
            rel = str(fp.relative_to(repo_path))
            # Count non-blank, non-comment lines (approximation)
            lines = [l for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
            counts[rel] = len(lines)
        except Exception:
            pass
    return counts


def _get_temporal_coupling(
    repo_path: Path, months: int = 12, source_rels: set[str] | None = None
) -> list[TemporalCoupling]:
    """Find files that frequently change together."""
    output = _run_git(repo_path, [
        "log", f"--since={months} months ago", "--name-only", "--format=COMMIT_SEP",
    ])

    co_changes: Counter[tuple[str, str]] = Counter()
    file_commits: Counter[str] = Counter()
    total_commits = 0

    current_files: list[str] = []
    for line in output.splitlines():
        line = line.strip()
        if line == "COMMIT_SEP":
            if current_files:
                total_commits += 1
                # Record co-changes for files in same commit
                filtered = [f for f in current_files if source_rels is None or f in source_rels]
                for f in filtered:
                    file_commits[f] += 1
                for i in range(len(filtered)):
                    for j in range(i + 1, len(filtered)):
                        pair = tuple(sorted([filtered[i], filtered[j]]))
                        co_changes[pair] += 1
            current_files = []
        elif line:
            current_files.append(line)

    # Process last commit
    if current_files:
        total_commits += 1
        filtered = [f for f in current_files if source_rels is None or f in source_rels]
        for f in filtered:
            file_commits[f] += 1
        for i in range(len(filtered)):
            for j in range(i + 1, len(filtered)):
                pair = tuple(sorted([filtered[i], filtered[j]]))
                co_changes[pair] += 1

    couplings: list[TemporalCoupling] = []
    for (fa, fb), count in co_changes.most_common(100):
        if count < 2:
            break
        # Confidence = co-changes / min(commits of either file)
        min_commits = min(file_commits[fa], file_commits[fb])
        confidence = count / min_commits if min_commits > 0 else 0
        if confidence >= 0.3:  # at least 30% co-change rate
            couplings.append(TemporalCoupling(
                file_a=fa,
                file_b=fb,
                co_change_count=count,
                confidence=round(confidence, 2),
            ))

    return couplings


def _get_file_authors(repo_path: Path, source_rels: set[str]) -> dict[str, Counter[str]]:
    """Get author commit counts per file."""
    output = _run_git(repo_path, [
        "log", "--format=AUTHOR:%an", "--name-only",
    ])

    file_authors: dict[str, Counter[str]] = defaultdict(Counter)
    current_author: str | None = None

    for line in output.splitlines():
        line = line.strip()
        if line.startswith("AUTHOR:"):
            current_author = line[7:]
        elif line and current_author and line in source_rels:
            file_authors[line][current_author] += 1

    return dict(file_authors)


def _compute_bus_factors(file_authors: dict[str, Counter[str]]) -> list[ModuleBusFactor]:
    """Compute bus factor per top-level directory."""
    module_authors: dict[str, Counter[str]] = defaultdict(Counter)

    for rel_path, authors in file_authors.items():
        parts = rel_path.split("/")
        module = parts[0] if len(parts) > 1 else "(root)"
        for author, count in authors.items():
            module_authors[module][author] += count

    bus_factors: list[ModuleBusFactor] = []
    for module, authors in sorted(module_authors.items()):
        total = sum(authors.values())
        # Contributors with >10% contribution
        significant = [a for a, c in authors.items() if (c / total) > 0.10]
        bus_factors.append(ModuleBusFactor(
            module=module,
            bus_factor=len(significant),
            contributors=sorted(significant),
        ))

    return bus_factors
