"""Dimension 2: Architecture map — detect patterns + layering rules."""

from __future__ import annotations

from pathlib import Path

from repox.models import (
    ArchitectureMap,
    ArchPattern,
    DirectoryLabel,
    LayeringRule,
)

# ── Known directory role patterns ────────────────────────────────────────────

DIRECTORY_ROLES: dict[str, tuple[str, str]] = {
    # API layer
    "routes": ("api", "API route handlers"),
    "routers": ("api", "API route handlers"),
    "controllers": ("api", "Request controllers"),
    "handlers": ("api", "Request handlers"),
    "views": ("api", "View functions / templates"),
    "endpoints": ("api", "API endpoints"),
    "api": ("api", "API layer"),
    # Business logic
    "services": ("service", "Business logic / service layer"),
    "core": ("service", "Core business logic"),
    "domain": ("service", "Domain logic"),
    "usecases": ("service", "Application use cases"),
    "use_cases": ("service", "Application use cases"),
    # Data layer
    "models": ("data", "Data models / ORM entities"),
    "entities": ("data", "Domain entities"),
    "repositories": ("data", "Data access / repository pattern"),
    "repos": ("data", "Data access / repository pattern"),
    "db": ("data", "Database layer"),
    "database": ("data", "Database layer"),
    "schemas": ("data", "Data schemas / validation"),
    "dao": ("data", "Data access objects"),
    # Infrastructure
    "middleware": ("infra", "Middleware layer"),
    "adapters": ("infra", "External adapters (hexagonal)"),
    "ports": ("infra", "Port interfaces (hexagonal)"),
    "infrastructure": ("infra", "Infrastructure layer"),
    "integrations": ("infra", "Third-party integrations"),
    "clients": ("infra", "External service clients"),
    "external": ("infra", "External dependencies"),
    # Support
    "utils": ("support", "Utility functions"),
    "helpers": ("support", "Helper functions"),
    "lib": ("support", "Shared library code"),
    "common": ("support", "Shared/common code"),
    "shared": ("support", "Shared code across modules"),
    # Config
    "config": ("config", "Configuration"),
    "settings": ("config", "Settings / configuration"),
    # Testing
    "tests": ("test", "Test suite"),
    "test": ("test", "Test suite"),
    "__tests__": ("test", "Test suite"),
    "spec": ("test", "Test specifications"),
    "specs": ("test", "Test specifications"),
    # Static / frontend
    "static": ("static", "Static assets"),
    "public": ("static", "Public assets"),
    "assets": ("static", "Asset files"),
    "templates": ("template", "Template files"),
    "components": ("ui", "UI components"),
    "pages": ("ui", "Page components / routes"),
    "app": ("ui", "Application entry / pages"),
    # Tasks / workers
    "tasks": ("worker", "Background tasks / workers"),
    "workers": ("worker", "Background workers"),
    "jobs": ("worker", "Background jobs"),
    "celery": ("worker", "Celery task definitions"),
    # Migrations
    "migrations": ("migration", "Database migrations"),
    "alembic": ("migration", "Alembic migrations"),
}

# ── Entry point patterns ─────────────────────────────────────────────────────

ENTRY_POINT_FILES = [
    "main.py",
    "app.py",
    "server.py",
    "wsgi.py",
    "asgi.py",
    "manage.py",
    "index.ts",
    "index.js",
    "server.ts",
    "server.js",
    "app.ts",
    "app.js",
    "main.ts",
    "main.js",
    "main.go",
    "cmd/main.go",
    "main.rs",
    "src/main.rs",
    "src/lib.rs",
]


def extract_architecture(repo_path: Path) -> ArchitectureMap:
    """Analyze directory structure to detect architectural pattern and layering."""
    arch = ArchitectureMap()

    # Collect top-level source directories
    src_root = _find_source_root(repo_path)
    if not src_root:
        return arch

    dirs = _get_meaningful_dirs(src_root, repo_path)

    # Label directories
    arch.directory_labels = _label_directories(dirs, repo_path)

    # Detect pattern
    roles = {dl.label for dl in arch.directory_labels}
    dir_names = {d.name for d in dirs}

    arch.pattern, arch.confidence = _detect_pattern(roles, dir_names, dirs, repo_path)

    # Detect layering rules based on pattern
    arch.layering_rules = _infer_layering_rules(arch.pattern, arch.directory_labels)

    # Detect entry points
    arch.entry_points = _find_entry_points(repo_path)

    # Detect module boundaries
    arch.module_boundaries = _find_module_boundaries(dirs, repo_path)

    return arch


def _find_source_root(repo_path: Path) -> Path | None:
    """Find the main source directory (src/, lib/, app/, or repo root)."""
    candidates = ["src", "lib", "app", "pkg"]
    for c in candidates:
        p = repo_path / c
        if p.is_dir():
            # Check if it has actual source files or subdirs
            children = [x for x in p.iterdir() if not x.name.startswith(".")]
            if children:
                return p
    # Fall back to repo root
    return repo_path


def _get_meaningful_dirs(src_root: Path, repo_path: Path) -> list[Path]:
    """Get directories that likely contain meaningful source code."""
    skip = {
        ".git", ".repox", ".venv", "venv", "env", ".env",
        "node_modules", "__pycache__", ".mypy_cache", ".pytest_cache",
        ".ruff_cache", ".tox", "dist", "build", "target", ".next",
        ".nuxt", "coverage", ".coverage", "htmlcov", "egg-info",
        ".claude",
    }

    dirs: list[Path] = []
    try:
        for item in src_root.iterdir():
            if item.is_dir() and item.name not in skip and not item.name.startswith("."):
                dirs.append(item)
    except PermissionError:
        pass
    return sorted(dirs, key=lambda p: p.name)


def _label_directories(dirs: list[Path], repo_path: Path) -> list[DirectoryLabel]:
    """Assign semantic labels to directories based on known patterns."""
    labels: list[DirectoryLabel] = []
    for d in dirs:
        name = d.name.lower()
        if name in DIRECTORY_ROLES:
            role, desc = DIRECTORY_ROLES[name]
            labels.append(DirectoryLabel(
                path=str(d.relative_to(repo_path)),
                label=role,
                description=desc,
            ))
    return labels


def _detect_pattern(
    roles: set[str],
    dir_names: set[str],
    dirs: list[Path],
    repo_path: Path,
) -> tuple[ArchPattern, float]:
    """Detect the architectural pattern based on directory roles."""

    # Hexagonal / ports-adapters
    if "adapters" in dir_names and ("ports" in dir_names or "core" in dir_names):
        return ArchPattern.HEXAGONAL, 0.85

    # MVC
    has_mvc = {"models", "views", "controllers"}
    if dir_names & has_mvc == has_mvc:
        return ArchPattern.MVC, 0.90

    # Classic layered (routes/controllers + services + models/repositories)
    has_api = roles & {"api"}
    has_service = roles & {"service"}
    has_data = roles & {"data"}
    if has_api and has_service and has_data:
        return ArchPattern.LAYERED, 0.85
    if has_api and has_data:
        return ArchPattern.LAYERED, 0.70

    # Domain-driven (feature folders with own routes+services+models)
    if _detect_feature_folders(dirs):
        return ArchPattern.DOMAIN_DRIVEN, 0.80

    # Monolith with modules (multiple top-level dirs with mixed concerns)
    if len(dirs) >= 5 and has_service:
        return ArchPattern.MONOLITH_MODULES, 0.60

    # Flat (few directories, everything at top level)
    if len(dirs) <= 2:
        return ArchPattern.FLAT, 0.70

    return ArchPattern.UNKNOWN, 0.0


def _detect_feature_folders(dirs: list[Path]) -> bool:
    """Check if dirs look like domain-driven feature folders (e.g., users/, orders/, payments/)."""
    feature_like = 0
    for d in dirs:
        # A feature folder typically has its own models/routes/services inside
        children = {c.name.lower() for c in d.iterdir() if c.is_dir() or c.is_file()}
        has_internal_structure = bool(
            children & {"models", "routes", "services", "views", "schemas",
                        "models.py", "routes.py", "services.py", "views.py", "schemas.py"}
        )
        if has_internal_structure:
            feature_like += 1

    return feature_like >= 2


def _infer_layering_rules(pattern: ArchPattern, labels: list[DirectoryLabel]) -> list[LayeringRule]:
    """Infer allowed import directions based on pattern."""
    rules: list[LayeringRule] = []

    if pattern == ArchPattern.LAYERED:
        # Standard layered: api → service → data, no skipping layers
        layer_order = ["api", "service", "data"]
        api_dirs = [dl.path for dl in labels if dl.label == "api"]
        svc_dirs = [dl.path for dl in labels if dl.label == "service"]
        data_dirs = [dl.path for dl in labels if dl.label == "data"]

        for api in api_dirs:
            for svc in svc_dirs:
                rules.append(LayeringRule(source=api, target=svc, allowed=True))
            for data in data_dirs:
                rules.append(LayeringRule(source=api, target=data, allowed=False))
        for svc in svc_dirs:
            for data in data_dirs:
                rules.append(LayeringRule(source=svc, target=data, allowed=True))
            for api in api_dirs:
                rules.append(LayeringRule(source=svc, target=api, allowed=False))

    elif pattern == ArchPattern.HEXAGONAL:
        # Core should not depend on adapters
        core_dirs = [dl.path for dl in labels if dl.label == "service"]
        adapter_dirs = [dl.path for dl in labels if dl.label == "infra"]
        for core in core_dirs:
            for adapter in adapter_dirs:
                rules.append(LayeringRule(source=core, target=adapter, allowed=False))

    return rules


def _find_entry_points(repo_path: Path) -> list[str]:
    """Find likely application entry points."""
    found: list[str] = []
    for pattern in ENTRY_POINT_FILES:
        # Check in repo root and src/
        for base in [repo_path, repo_path / "src"]:
            p = base / pattern
            if p.exists():
                found.append(str(p.relative_to(repo_path)))
    return found


def _find_module_boundaries(dirs: list[Path], repo_path: Path) -> list[str]:
    """Identify directories that form logical module boundaries."""
    boundaries: list[str] = []
    for d in dirs:
        # A module boundary is a directory with its own __init__.py (Python)
        # or index.ts/js (Node) or that contains multiple subdirectories
        init_py = d / "__init__.py"
        index_files = [d / "index.ts", d / "index.js", d / "index.tsx", d / "mod.rs"]

        if init_py.exists() or any(f.exists() for f in index_files):
            boundaries.append(str(d.relative_to(repo_path)))
        elif sum(1 for c in d.iterdir() if c.is_dir()) >= 2:
            boundaries.append(str(d.relative_to(repo_path)))

    return boundaries
