"""Dimension 4: Dependency graph + PageRank ranking."""

from __future__ import annotations

import re
from pathlib import Path

import tree_sitter_language_pack as tslp
from tree_sitter import Node

from repox.models import (
    CallEdge,
    DependencyGraph,
    ImportEdge,
    SymbolGraph,
    SymbolRank,
)

# ── Import graph extraction ──────────────────────────────────────────────────


def extract_dependencies(
    repo_path: Path, source_files: list[Path], symbol_graph: SymbolGraph
) -> DependencyGraph:
    """Build import graph, call graph, and compute PageRank."""
    graph = DependencyGraph()

    for file_path in source_files:
        try:
            code = file_path.read_bytes()
        except (OSError, UnicodeDecodeError):
            continue

        rel_path = str(file_path.relative_to(repo_path))
        suffix = file_path.suffix

        if suffix == ".py":
            imports = _extract_python_imports(code, rel_path, repo_path, file_path)
            calls = _extract_python_calls(code, rel_path)
            graph.import_edges.extend(imports)
            graph.call_edges.extend(calls)
        elif suffix in (".js", ".ts", ".jsx", ".tsx"):
            imports = _extract_js_imports(code, rel_path, repo_path, file_path)
            graph.import_edges.extend(imports)

    # Build symbol index for PageRank
    symbol_index = _build_symbol_index(symbol_graph)

    # Compute PageRank
    graph.symbol_ranks = _compute_pagerank(graph, symbol_index)

    return graph


# ── Python imports ───────────────────────────────────────────────────────────


def _extract_python_imports(
    code: bytes, source_file: str, repo_path: Path, file_path: Path
) -> list[ImportEdge]:
    """Extract import statements from Python code using tree-sitter."""
    edges: list[ImportEdge] = []

    try:
        parser = tslp.get_parser("python")
    except Exception:
        return edges

    tree = parser.parse(code)

    for node in tree.root_node.children:
        if node.type == "import_statement":
            # import foo, import foo.bar
            edge = _resolve_python_import(node, source_file, repo_path, file_path)
            if edge:
                edges.append(edge)

        elif node.type == "import_from_statement":
            # from foo import bar, from . import baz
            edge = _resolve_python_from_import(node, source_file, repo_path, file_path)
            if edge:
                edges.append(edge)

    return edges


def _resolve_python_import(
    node: Node, source_file: str, repo_path: Path, file_path: Path
) -> ImportEdge | None:
    """Resolve 'import X' to a file path."""
    module_node = node.child_by_field_name("name")
    if not module_node:
        # Try first dotted_name or identifier child
        for child in node.children:
            if child.type in ("dotted_name", "identifier"):
                module_node = child
                break

    if not module_node:
        return None

    module_path = module_node.text.decode()
    resolved = _resolve_python_module(module_path, repo_path, file_path)
    if resolved:
        return ImportEdge(
            source_file=source_file,
            target_file=resolved,
            imported_names=[module_path.split(".")[-1]],
        )
    return None


def _resolve_python_from_import(
    node: Node, source_file: str, repo_path: Path, file_path: Path
) -> ImportEdge | None:
    """Resolve 'from X import Y' to a file path."""
    module_text = ""
    imported_names: list[str] = []

    # Get module name (after 'from', before 'import')
    found_from = False
    found_import = False
    for child in node.children:
        if child.type == "from":
            found_from = True
        elif child.type == "import":
            found_import = True
        elif found_from and not found_import:
            if child.type in ("dotted_name", "identifier", "relative_import"):
                module_text = child.text.decode()
        elif found_import:
            if child.type in ("dotted_name", "identifier"):
                imported_names.append(child.text.decode())
            elif child.type == "aliased_import":
                name_node = child.children[0] if child.children else None
                if name_node:
                    imported_names.append(name_node.text.decode())

    if not module_text:
        return None

    resolved = _resolve_python_module(module_text, repo_path, file_path)
    if resolved:
        return ImportEdge(
            source_file=source_file,
            target_file=resolved,
            imported_names=imported_names,
        )
    return None


def _resolve_python_module(module_path: str, repo_path: Path, file_path: Path) -> str | None:
    """Resolve a Python module path to a relative file path."""
    # Handle relative imports (leading dots)
    dots = 0
    clean_path = module_path
    while clean_path.startswith("."):
        dots += 1
        clean_path = clean_path[1:]

    if dots > 0:
        # Relative import
        base = file_path.parent
        for _ in range(dots - 1):
            base = base.parent
        parts = clean_path.split(".") if clean_path else []
    else:
        # Absolute import — try from repo root and common source dirs
        parts = module_path.split(".")
        base = None
        for candidate_root in [repo_path, repo_path / "src"]:
            test_path = candidate_root
            for part in parts:
                test_path = test_path / part
            if (test_path.with_suffix(".py")).exists() or (test_path / "__init__.py").exists():
                base = candidate_root
                break

        if base is None:
            return None  # External package

    # Build the path
    target = base
    for part in parts:
        target = target / part

    # Check if it's a file or package
    if target.with_suffix(".py").exists():
        return str(target.with_suffix(".py").relative_to(repo_path))
    elif (target / "__init__.py").exists():
        return str((target / "__init__.py").relative_to(repo_path))

    return None


# ── JS/TS imports ────────────────────────────────────────────────────────────


def _extract_js_imports(
    code: bytes, source_file: str, repo_path: Path, file_path: Path
) -> list[ImportEdge]:
    """Extract import/require statements from JS/TS code."""
    edges: list[ImportEdge] = []

    # Use regex for speed — import/require patterns are well-defined
    text = code.decode(errors="replace")

    # ES imports: import { X, Y } from './path'
    for m in re.finditer(
        r"""import\s+(?:\{([^}]+)\}|(\w+))\s+from\s+['"](\.\.?/[^'"]+)['"]""",
        text,
    ):
        named = m.group(1)
        default = m.group(2)
        path = m.group(3)

        names: list[str] = []
        if named:
            names = [n.strip().split(" as ")[0].strip() for n in named.split(",")]
        if default:
            names.append(default)

        resolved = _resolve_js_module(path, repo_path, file_path)
        if resolved:
            edges.append(ImportEdge(
                source_file=source_file,
                target_file=resolved,
                imported_names=names,
            ))

    # Default + named: import X, { Y } from './path'
    for m in re.finditer(
        r"""import\s+(\w+)\s*,\s*\{([^}]+)\}\s+from\s+['"](\.\.?/[^'"]+)['"]""",
        text,
    ):
        default = m.group(1)
        named = m.group(2)
        path = m.group(3)
        names = [default] + [n.strip().split(" as ")[0].strip() for n in named.split(",")]
        resolved = _resolve_js_module(path, repo_path, file_path)
        if resolved:
            edges.append(ImportEdge(
                source_file=source_file,
                target_file=resolved,
                imported_names=names,
            ))

    return edges


def _resolve_js_module(import_path: str, repo_path: Path, file_path: Path) -> str | None:
    """Resolve a relative JS/TS import to a file path."""
    if not import_path.startswith("."):
        return None  # External package

    base = file_path.parent
    target = (base / import_path).resolve()

    # Try with various extensions
    extensions = [".ts", ".tsx", ".js", ".jsx"]
    for ext in extensions:
        candidate = target.with_suffix(ext)
        if candidate.exists():
            try:
                return str(candidate.relative_to(repo_path))
            except ValueError:
                return None

    # Try as directory with index file
    if target.is_dir():
        for ext in extensions:
            index = target / f"index{ext}"
            if index.exists():
                try:
                    return str(index.relative_to(repo_path))
                except ValueError:
                    return None

    return None


# ── Python call extraction ───────────────────────────────────────────────────


def _extract_python_calls(code: bytes, source_file: str) -> list[CallEdge]:
    """Extract function/method calls from Python code."""
    edges: list[CallEdge] = []

    try:
        parser = tslp.get_parser("python")
    except Exception:
        return edges

    tree = parser.parse(code)
    _walk_calls(tree.root_node, source_file, edges)
    return edges


def _walk_calls(node: Node, source_file: str, edges: list[CallEdge]) -> None:
    """Walk AST and collect call expressions."""
    if node.type == "call":
        func_node = node.children[0] if node.children else None
        if func_node:
            callee = func_node.text.decode()
            # Filter out built-in calls and very short names
            if callee and not callee.startswith("(") and len(callee) > 1:
                # For method calls like self.db.fetch(), extract the meaningful part
                parts = callee.split(".")
                # Get the function being called (last part)
                func_name = parts[-1]
                # Construct a meaningful callee identifier
                if len(parts) > 1 and parts[0] == "self":
                    callee = ".".join(parts[1:])

                edges.append(CallEdge(
                    caller=source_file,  # We'll refine this in future milestones
                    callee=callee,
                    file_path=source_file,
                    line=node.start_point[0] + 1,
                ))

    for child in node.children:
        _walk_calls(child, source_file, edges)


# ── PageRank ─────────────────────────────────────────────────────────────────


def _build_symbol_index(symbol_graph: SymbolGraph) -> dict[str, str]:
    """Build name→file_path index from the symbol graph."""
    index: dict[str, str] = {}
    for sym in symbol_graph.symbols:
        key = f"{sym.parent_scope}.{sym.name}" if sym.parent_scope else sym.name
        index[key] = sym.file_path
    return index


def _compute_pagerank(
    graph: DependencyGraph,
    symbol_index: dict[str, str],
    damping: float = 0.85,
    iterations: int = 30,
) -> list[SymbolRank]:
    """Compute PageRank over the dependency graph.

    Uses import edges and call edges to build an adjacency matrix,
    then runs iterative PageRank.
    """
    # Build graph nodes from all files mentioned in edges
    nodes: set[str] = set()
    adjacency: dict[str, set[str]] = {}

    for edge in graph.import_edges:
        nodes.add(edge.source_file)
        nodes.add(edge.target_file)
        adjacency.setdefault(edge.source_file, set()).add(edge.target_file)

    for edge in graph.call_edges:
        callee_file = symbol_index.get(edge.callee)
        if callee_file:
            nodes.add(edge.file_path)
            nodes.add(callee_file)
            adjacency.setdefault(edge.file_path, set()).add(callee_file)

    if not nodes:
        return []

    n = len(nodes)
    node_list = sorted(nodes)
    node_idx = {name: i for i, name in enumerate(node_list)}

    # Initialize scores
    scores = [1.0 / n] * n

    # Iterative PageRank
    for _ in range(iterations):
        new_scores = [(1.0 - damping) / n] * n

        for source, targets in adjacency.items():
            if not targets:
                continue
            src_idx = node_idx.get(source)
            if src_idx is None:
                continue
            share = scores[src_idx] / len(targets)
            for target in targets:
                tgt_idx = node_idx.get(target)
                if tgt_idx is not None:
                    new_scores[tgt_idx] += damping * share

        scores = new_scores

    # Convert to SymbolRank objects, sorted by score descending
    ranks = []
    for i, node_name in enumerate(node_list):
        ranks.append(SymbolRank(
            symbol=node_name,
            file_path=node_name,
            pagerank=round(scores[i], 6),
        ))

    ranks.sort(key=lambda r: r.pagerank, reverse=True)
    return ranks
