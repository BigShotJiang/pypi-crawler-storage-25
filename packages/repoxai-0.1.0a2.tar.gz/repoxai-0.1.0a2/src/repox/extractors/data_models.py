"""Dimension 6: Data model map — ORM entities, fields, relationships, schemas."""

from __future__ import annotations

import re
from pathlib import Path

import tree_sitter_language_pack as tslp
from tree_sitter import Node

from repox.models import DataEntity, DataModelMap, FieldDef, Relationship

# ── Main extraction ──────────────────────────────────────────────────────────


def extract_data_models(repo_path: Path, source_files: list[Path]) -> DataModelMap:
    """Extract all database entities, fields, relationships, and schemas."""
    model_map = DataModelMap()

    for file_path in source_files:
        rel_path = str(file_path.relative_to(repo_path))

        if file_path.suffix == ".py":
            entities = _extract_python_models(file_path, rel_path)
            model_map.entities.extend(entities)

        elif file_path.name == "schema.prisma":
            entities = _extract_prisma_models(file_path, rel_path)
            model_map.entities.extend(entities)

    return model_map


# ── Python ORM extraction ────────────────────────────────────────────────────

# SQLAlchemy base class patterns
_SQLALCHEMY_BASES = {"Base", "DeclarativeBase", "MappedAsDataclass"}
# Django model bases
_DJANGO_BASES = {"Model", "models.Model"}
# Pydantic bases
_PYDANTIC_BASES = {"BaseModel", "BaseSettings"}

# SQLAlchemy column type mapping
_SA_TYPE_MAP = {
    "String": "string", "Text": "string", "Unicode": "string",
    "Integer": "integer", "BigInteger": "integer", "SmallInteger": "integer",
    "Float": "float", "Numeric": "float", "Decimal": "float",
    "Boolean": "boolean", "Bool": "boolean",
    "DateTime": "datetime", "Date": "date", "Time": "time",
    "JSON": "json", "JSONB": "json",
    "LargeBinary": "binary", "BLOB": "binary",
    "UUID": "uuid", "Uuid": "uuid",
    "Enum": "enum",
    "ARRAY": "array",
}

# Django field type mapping
_DJANGO_TYPE_MAP = {
    "CharField": "string", "TextField": "string", "SlugField": "string",
    "EmailField": "string", "URLField": "string", "FilePathField": "string",
    "IntegerField": "integer", "BigIntegerField": "integer",
    "SmallIntegerField": "integer", "PositiveIntegerField": "integer",
    "FloatField": "float", "DecimalField": "float",
    "BooleanField": "boolean", "NullBooleanField": "boolean",
    "DateTimeField": "datetime", "DateField": "date", "TimeField": "time",
    "JSONField": "json",
    "BinaryField": "binary", "FileField": "binary", "ImageField": "binary",
    "UUIDField": "uuid",
    "AutoField": "integer", "BigAutoField": "integer",
    "ForeignKey": "foreign_key",
    "OneToOneField": "one_to_one",
    "ManyToManyField": "many_to_many",
}


def _extract_python_models(file_path: Path, rel_path: str) -> list[DataEntity]:
    """Extract ORM models and Pydantic schemas from Python files."""
    try:
        code = file_path.read_bytes()
    except (OSError, UnicodeDecodeError):
        return []

    try:
        parser = tslp.get_parser("python")
    except Exception:
        return []

    tree = parser.parse(code)
    entities: list[DataEntity] = []

    for child in tree.root_node.children:
        # Handle both plain class and decorated class
        class_node = None
        if child.type == "class_definition":
            class_node = child
        elif child.type == "decorated_definition":
            for c in child.children:
                if c.type == "class_definition":
                    class_node = c
                    break

        if not class_node:
            continue

        entity = _parse_python_class_as_model(class_node, rel_path, code)
        if entity:
            entities.append(entity)

    return entities


def _parse_python_class_as_model(node: Node, file_path: str, code: bytes) -> DataEntity | None:
    """Parse a Python class to see if it's an ORM model or Pydantic schema."""
    # Get class name
    name = None
    for child in node.children:
        if child.type == "identifier":
            name = child.text.decode()
            break

    if not name:
        return None

    # Get base classes
    bases: list[str] = []
    arg_list = None
    for child in node.children:
        if child.type == "argument_list":
            arg_list = child
            break

    if arg_list:
        for child in arg_list.children:
            if child.type in ("identifier", "attribute"):
                bases.append(child.text.decode())

    # Determine ORM type
    orm = _detect_orm_type(bases)
    if not orm:
        return None

    # Get class body
    body = None
    for child in node.children:
        if child.type == "block":
            body = child
            break

    if not body:
        return None

    # Extract fields and relationships based on ORM type
    fields: list[FieldDef] = []
    relationships: list[Relationship] = []

    if orm == "SQLAlchemy":
        _extract_sqlalchemy_fields(body, code, fields, relationships)
    elif orm == "Django ORM":
        _extract_django_fields(body, code, fields, relationships)
    elif orm == "Pydantic":
        _extract_pydantic_fields(body, code, fields)

    if not fields and not relationships:
        return None

    return DataEntity(
        name=name,
        file_path=file_path,
        fields=fields,
        relationships=relationships,
        orm=orm,
    )


def _detect_orm_type(bases: list[str]) -> str | None:
    """Detect which ORM a class belongs to from its base classes."""
    for base in bases:
        clean = base.split(".")[-1]
        if clean in _SQLALCHEMY_BASES:
            return "SQLAlchemy"
        if clean in _DJANGO_BASES or base in _DJANGO_BASES:
            return "Django ORM"
        if clean in _PYDANTIC_BASES:
            return "Pydantic"
    return None


# ── SQLAlchemy ───────────────────────────────────────────────────────────────


def _extract_sqlalchemy_fields(
    body: Node, code: bytes, fields: list[FieldDef], relationships: list[Relationship]
) -> None:
    """Extract fields from SQLAlchemy model body."""
    for child in body.children:
        if child.type in ("expression_statement", "assignment"):
            assign = child if child.type == "assignment" else None
            if child.type == "expression_statement":
                for c in child.children:
                    if c.type == "assignment":
                        assign = c
                        break
            if not assign:
                continue

            text = assign.text.decode()

            # Column() or mapped_column()
            if "Column(" in text or "mapped_column(" in text:
                field = _parse_sa_column(text)
                if field:
                    fields.append(field)

            # relationship()
            elif "relationship(" in text:
                rel = _parse_sa_relationship(text)
                if rel:
                    relationships.append(rel)

        elif child.type == "type_alias_statement":
            # SQLAlchemy 2.0 Mapped[] style
            text = child.text.decode()
            if "Mapped[" in text:
                field = _parse_sa_mapped(text)
                if field:
                    fields.append(field)


def _parse_sa_column(text: str) -> FieldDef | None:
    """Parse a SQLAlchemy Column() or mapped_column() definition."""
    # name = Column(Type, ...)
    m = re.match(r'(\w+)\s*[:=]', text)
    if not m:
        return None
    name = m.group(1)

    # Extract column type
    type_m = re.search(r'(?:Column|mapped_column)\s*\(\s*(\w+)', text)
    col_type = "unknown"
    if type_m:
        raw_type = type_m.group(1)
        col_type = _SA_TYPE_MAP.get(raw_type, raw_type.lower())

    nullable = "nullable=True" in text or "nullable" not in text
    if "nullable=False" in text:
        nullable = False

    unique = "unique=True" in text
    indexed = "index=True" in text
    primary_key = "primary_key=True" in text

    # Foreign key
    fk = None
    fk_m = re.search(r'ForeignKey\s*\(\s*["\']([^"\']+)["\']', text)
    if fk_m:
        fk = fk_m.group(1)

    return FieldDef(
        name=name,
        type=col_type,
        nullable=nullable,
        unique=unique,
        indexed=indexed,
        primary_key=primary_key,
        foreign_key=fk,
    )


def _parse_sa_mapped(text: str) -> FieldDef | None:
    """Parse SQLAlchemy 2.0 Mapped[] annotation."""
    m = re.match(r'(\w+)\s*:\s*Mapped\[([^\]]+)\]', text)
    if not m:
        return None
    name = m.group(1)
    type_str = m.group(2).strip()

    nullable = "None" in type_str or "Optional" in type_str
    col_type = type_str.replace("Optional[", "").replace("]", "").replace(" | None", "").strip()

    return FieldDef(
        name=name,
        type=col_type.lower(),
        nullable=nullable,
    )


def _parse_sa_relationship(text: str) -> Relationship | None:
    """Parse a SQLAlchemy relationship() definition."""
    m = re.match(r'(\w+)\s*[:=]', text)
    if not m:
        return None
    name = m.group(1)

    # Target model
    target_m = re.search(r'relationship\s*\(\s*["\']?(\w+)["\']?', text)
    if not target_m:
        return None
    target = target_m.group(1)

    # back_populates
    bp = None
    bp_m = re.search(r'back_populates\s*=\s*["\'](\w+)["\']', text)
    if bp_m:
        bp = bp_m.group(1)

    # Determine kind
    kind = "one-to-many"
    if "uselist=False" in text:
        kind = "one-to-one"
    elif "secondary" in text:
        kind = "many-to-many"

    return Relationship(
        name=name,
        target_model=target,
        kind=kind,
        back_populates=bp,
    )


# ── Django ORM ───────────────────────────────────────────────────────────────


def _extract_django_fields(
    body: Node, code: bytes, fields: list[FieldDef], relationships: list[Relationship]
) -> None:
    """Extract fields from a Django model body."""
    for child in body.children:
        assign = None
        if child.type == "assignment":
            assign = child
        elif child.type == "expression_statement":
            for c in child.children:
                if c.type == "assignment":
                    assign = c
                    break

        if not assign:
            continue

        text = assign.text.decode()

        # Match field pattern: name = models.FieldType(...) or FieldType(...)
        m = re.match(r'(\w+)\s*=\s*(?:models\.)?(\w+)\s*\(', text)
        if not m:
            continue

        field_name = m.group(1)
        field_type_name = m.group(2)

        mapped_type = _DJANGO_TYPE_MAP.get(field_type_name)
        if not mapped_type:
            continue

        # Handle relationship fields
        if mapped_type in ("foreign_key", "one_to_one", "many_to_many"):
            target_m = re.search(r'\(\s*["\']?(\w+)["\']?', text[m.end() - 1:])
            target = target_m.group(1) if target_m else "unknown"

            related_name = None
            rn_m = re.search(r'related_name\s*=\s*["\'](\w+)["\']', text)
            if rn_m:
                related_name = rn_m.group(1)

            kind_map = {"foreign_key": "many-to-one", "one_to_one": "one-to-one", "many_to_many": "many-to-many"}
            relationships.append(Relationship(
                name=field_name,
                target_model=target,
                kind=kind_map[mapped_type],
                back_populates=related_name,
            ))

            # Also add as a field
            fields.append(FieldDef(
                name=field_name,
                type=mapped_type,
                foreign_key=f"{target}.id" if mapped_type == "foreign_key" else None,
            ))
        else:
            nullable = "null=True" in text
            unique = "unique=True" in text
            primary_key = "primary_key=True" in text

            fields.append(FieldDef(
                name=field_name,
                type=mapped_type,
                nullable=nullable,
                unique=unique,
                primary_key=primary_key,
            ))


# ── Pydantic ─────────────────────────────────────────────────────────────────


def _extract_pydantic_fields(body: Node, code: bytes, fields: list[FieldDef]) -> None:
    """Extract fields from a Pydantic BaseModel body."""
    for child in body.children:
        # Look for type-annotated assignments: name: str, name: int = 5
        if child.type == "expression_statement":
            inner = child.children[0] if child.children else None
            if not inner:
                continue
        else:
            inner = child

        text = inner.text.decode().strip()

        # Skip class methods and nested classes
        if text.startswith("def ") or text.startswith("class ") or text.startswith("@"):
            continue

        # Match: field_name: FieldType or field_name: FieldType = default
        m = re.match(r'(\w+)\s*:\s*(.+?)(?:\s*=\s*(.+))?$', text)
        if not m:
            continue

        name = m.group(1)
        type_str = m.group(2).strip()
        default = m.group(3)

        # Skip private and dunder
        if name.startswith("_"):
            continue

        # Skip Config class indicator
        if name == "model_config":
            continue

        nullable = "None" in type_str or "Optional" in type_str
        clean_type = type_str.replace("Optional[", "").rstrip("]").replace(" | None", "").strip()

        fields.append(FieldDef(
            name=name,
            type=clean_type.lower() if clean_type[0].islower() else clean_type,
            nullable=nullable,
            default=default.strip() if default else None,
        ))


# ── Prisma ───────────────────────────────────────────────────────────────────


def _extract_prisma_models(file_path: Path, rel_path: str) -> list[DataEntity]:
    """Parse schema.prisma file for model definitions."""
    try:
        text = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []

    entities: list[DataEntity] = []

    # Match model blocks: model Name { ... }
    for m in re.finditer(r'model\s+(\w+)\s*\{([^}]+)\}', text):
        model_name = m.group(1)
        body = m.group(2)

        fields: list[FieldDef] = []
        relationships: list[Relationship] = []

        for line in body.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("//") or line.startswith("@@"):
                continue

            field = _parse_prisma_field(line, model_name)
            if field:
                if field.foreign_key:
                    relationships.append(Relationship(
                        name=field.name,
                        target_model=field.type,
                        kind="many-to-one" if "[]" not in line else "one-to-many",
                    ))
                fields.append(field)

        if fields:
            entities.append(DataEntity(
                name=model_name,
                file_path=rel_path,
                fields=fields,
                relationships=relationships,
                orm="Prisma",
            ))

    return entities


def _parse_prisma_field(line: str, model_name: str) -> FieldDef | None:
    """Parse a single Prisma field line."""
    # name Type @attributes
    m = re.match(r'(\w+)\s+(\w+)(\[\])?\s*(.*)', line)
    if not m:
        return None

    name = m.group(1)
    type_str = m.group(2)
    is_array = m.group(3) is not None
    attrs = m.group(4)

    # Map Prisma types
    prisma_type_map = {
        "String": "string", "Int": "integer", "Float": "float",
        "Boolean": "boolean", "DateTime": "datetime", "Json": "json",
        "BigInt": "integer", "Decimal": "float", "Bytes": "binary",
    }

    mapped_type = prisma_type_map.get(type_str, type_str)

    nullable = "?" in line
    unique = "@unique" in attrs
    primary_key = "@id" in attrs
    is_relation = "@relation" in attrs or (type_str[0].isupper() and type_str not in prisma_type_map)
    fk = type_str if is_relation else None

    return FieldDef(
        name=name,
        type=mapped_type if not is_array else f"{mapped_type}[]",
        nullable=nullable,
        unique=unique,
        primary_key=primary_key,
        foreign_key=fk,
    )
