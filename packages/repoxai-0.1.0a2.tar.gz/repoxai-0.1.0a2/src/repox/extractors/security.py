"""Security posture extraction — what agents must maintain to not degrade security."""

from __future__ import annotations

import re
from pathlib import Path

from repox.models import APISurface, BehavioralIntelligence, SecurityPosture, SymbolGraph


def extract_security_posture(
    repo_path: Path,
    source_files: list[Path],
    api_surface: APISurface,
    behavioral: BehavioralIntelligence,
    symbols: SymbolGraph,
) -> SecurityPosture:
    """Extract security posture from the codebase."""
    posture = SecurityPosture()

    # 1. Auth posture — which routes are unprotected
    _analyze_auth_posture(posture, api_surface, behavioral, source_files, repo_path)

    # 2. Input validation pattern
    _analyze_input_validation(posture, source_files, repo_path)

    # 3. SQL safety
    _analyze_sql_safety(posture, source_files, repo_path)

    # 4. CORS policy
    _analyze_cors(posture, source_files, repo_path)

    # 5. Secret management
    _analyze_secret_management(posture, source_files, repo_path)

    # 6. Sensitive data fields (PII)
    _analyze_sensitive_fields(posture, symbols)

    # 7. Rate limiting
    _analyze_rate_limiting(posture, source_files, repo_path)

    # Generate actionable security notes for agents
    _generate_security_notes(posture)

    return posture


def _analyze_auth_posture(
    posture: SecurityPosture,
    api_surface: APISurface,
    behavioral: BehavioralIntelligence,
    source_files: list[Path],
    repo_path: Path,
) -> None:
    """Determine auth posture and find intentionally unprotected routes."""
    if not behavioral.auth_flows:
        return

    protected_files = set()
    for flow in behavioral.auth_flows:
        protected_files.update(flow.protected_routes)

    # Check if most route files are protected
    route_files = {
        str(f.relative_to(repo_path)) for f in source_files
        if any(kw in str(f) for kw in ("route", "api", "endpoint", "controller"))
        and f.suffix in (".py", ".ts", ".js")
    }

    if route_files and len(protected_files & route_files) / max(len(route_files), 1) > 0.5:
        posture.auth_required_by_default = True

    # Find unprotected route files (have endpoints but no auth guard)
    for ep in api_surface.endpoints:
        if ep.method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
            if ep.file_path not in protected_files:
                route_desc = f"{ep.method} {ep.path} ({ep.handler})"
                if route_desc not in posture.unprotected_routes:
                    posture.unprotected_routes.append(route_desc)

    # Known intentionally-public patterns
    public_patterns = {"health", "webhook", "public", "status", "ping", "version", "openapi", "docs", "favicon"}
    intentional: list[str] = []
    suspicious: list[str] = []

    for route in posture.unprotected_routes:
        if any(p in route.lower() for p in public_patterns):
            intentional.append(route)
        else:
            suspicious.append(route)

    posture.unprotected_routes = intentional  # only keep intentional ones
    if suspicious:
        posture.security_notes.append(
            f"Routes without auth guard (verify intentional): {', '.join(suspicious[:5])}"
        )


def _analyze_input_validation(
    posture: SecurityPosture, source_files: list[Path], repo_path: Path
) -> None:
    """Detect input validation patterns."""
    pydantic_count = 0
    zod_count = 0
    joi_count = 0
    manual_count = 0

    for fp in source_files:
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        if fp.suffix == ".py":
            if "BaseModel" in text and ("class " in text):
                pydantic_count += 1
            if re.search(r'request\.\w+\[', text) or "request.form" in text:
                manual_count += 1

        elif fp.suffix in (".ts", ".js", ".tsx"):
            if "z.object" in text or "z.string" in text or "from 'zod'" in text:
                zod_count += 1
            if "Joi." in text or "from 'joi'" in text:
                joi_count += 1

    if pydantic_count > 0:
        posture.input_validation = "Pydantic"
    elif zod_count > 0:
        posture.input_validation = "Zod"
    elif joi_count > 0:
        posture.input_validation = "Joi"
    elif manual_count > 0:
        posture.input_validation = "manual"


def _analyze_sql_safety(
    posture: SecurityPosture, source_files: list[Path], repo_path: Path
) -> None:
    """Detect SQL safety patterns — ORM vs raw SQL."""
    orm_usage = 0
    raw_sql = 0
    parameterized_raw = 0

    for fp in source_files:
        if fp.suffix != ".py":
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        # ORM patterns
        if "session.query" in text or "session.execute" in text or "db.query" in text:
            orm_usage += 1
        if ".filter(" in text or ".filter_by(" in text:
            orm_usage += 1

        # Raw SQL detection (not ORM session.execute)
        raw_patterns = [
            r'cursor\.execute\s*\(',
            r'connection\.execute\s*\(\s*f["\']',  # raw connection with f-string
            r'\.raw\s*\(',  # Django raw()
            r'\.executescript\s*\(',
        ]
        for pat in raw_patterns:
            if re.search(pat, text):
                raw_sql += 1
                # Check if parameterized
                if re.search(r'execute\s*\([^,]+,\s*[\[\(]', text):
                    parameterized_raw += 1

        # f-string in raw SQL (dangerous) — only flag if SQL keywords present in the f-string
        for m in re.finditer(r'(?:cursor\.execute|\.execute)\s*\(\s*f["\']([^"\']{0,200})', text):
            snippet = m.group(1).upper()
            if any(kw in snippet for kw in ("SELECT ", "INSERT ", "UPDATE ", "DELETE ", "DROP ", "ALTER ")):
                posture.security_notes.append(
                    f"f-string SQL detected in {str(fp.relative_to(repo_path))} — SQL injection risk"
                )
                break

    if orm_usage > 0 and raw_sql == 0:
        posture.sql_safety = "ORM-only"
    elif orm_usage > 0 and raw_sql > 0:
        posture.sql_safety = "mixed (ORM + raw SQL)"
    elif raw_sql > 0 and parameterized_raw == raw_sql:
        posture.sql_safety = "parameterized raw SQL"
    elif raw_sql > 0:
        posture.sql_safety = "raw SQL (review for injection risks)"


def _analyze_cors(
    posture: SecurityPosture, source_files: list[Path], repo_path: Path
) -> None:
    """Detect CORS configuration."""
    for fp in source_files:
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        # FastAPI/Starlette CORS
        if "CORSMiddleware" in text:
            # Extract origins
            origins_match = re.search(
                r'allow_origins\s*=\s*[\[\(](.*?)[\]\)]',
                text, re.DOTALL,
            )
            if origins_match:
                origins = re.findall(r'["\']([^"\']+)["\']', origins_match.group(1))
                posture.cors_origins = origins
                if "*" in origins:
                    posture.cors_allow_all = True

            # Check allow_credentials with allow_all
            if "allow_credentials=True" in text and posture.cors_allow_all:
                posture.security_notes.append(
                    "CORS allows all origins with credentials — security risk"
                )

        # Express cors()
        if "cors(" in text and fp.suffix in (".js", ".ts"):
            origin_match = re.search(r'origin\s*:\s*["\']([^"\']+)["\']', text)
            if origin_match:
                posture.cors_origins.append(origin_match.group(1))
            if "origin: true" in text or "origin: '*'" in text:
                posture.cors_allow_all = True

        # Next.js headers in next.config.js
        if fp.name in ("next.config.js", "next.config.mjs", "next.config.ts"):
            if "Access-Control-Allow-Origin" in text:
                origin_match = re.search(r"Access-Control-Allow-Origin['\"],\s*value:\s*['\"]([^'\"]+)", text)
                if origin_match:
                    posture.cors_origins.append(origin_match.group(1))


def _analyze_secret_management(
    posture: SecurityPosture, source_files: list[Path], repo_path: Path
) -> None:
    """Detect how secrets are managed."""
    patterns_found: dict[str, int] = {}

    for fp in source_files:
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))

        # Settings/config class with env vars
        if "BaseSettings" in text or "pydantic_settings" in text:
            patterns_found["Pydantic Settings (env vars)"] = patterns_found.get("Pydantic Settings (env vars)", 0) + 1
        if "os.environ" in text or "os.getenv" in text:
            patterns_found["os.environ / os.getenv"] = patterns_found.get("os.environ / os.getenv", 0) + 1
        if "process.env" in text:
            patterns_found["process.env"] = patterns_found.get("process.env", 0) + 1
        if "dotenv" in text or "load_dotenv" in text:
            patterns_found["dotenv"] = patterns_found.get("dotenv", 0) + 1
        if "vault" in text.lower() and ("hvac" in text or "Vault" in text):
            patterns_found["HashiCorp Vault"] = patterns_found.get("HashiCorp Vault", 0) + 1
        if "aws_secretsmanager" in text or "SecretsManager" in text:
            patterns_found["AWS Secrets Manager"] = patterns_found.get("AWS Secrets Manager", 0) + 1

        # Check for hardcoded secrets (suspicious patterns)
        hardcoded = re.findall(
            r'(?:password|secret|api_key|token|credentials)\s*=\s*["\'][^"\']{8,}["\']',
            text, re.IGNORECASE,
        )
        # Filter out obvious non-secrets (test files, variable names)
        if hardcoded and "test" not in rel.lower() and "mock" not in rel.lower():
            posture.security_notes.append(
                f"Possible hardcoded secrets in {rel} — verify these are not real credentials"
            )

    if patterns_found:
        posture.secret_management = max(patterns_found, key=patterns_found.get)


def _analyze_sensitive_fields(posture: SecurityPosture, symbols: SymbolGraph) -> None:
    """Detect PII/sensitive fields from data models."""
    pii_keywords = {
        "email", "phone", "phone_number", "ssn", "social_security",
        "password", "password_hash", "secret", "token", "api_key",
        "credit_card", "card_number", "cvv", "address", "date_of_birth",
        "dob", "national_id", "passport", "driver_license", "ip_address",
        "avatar_url", "first_name", "last_name", "full_name",
    }

    seen: set[str] = set()
    for s in symbols.symbols:
        if s.kind.value in ("property", "variable", "constant"):
            name_lower = s.name.lower()
            if name_lower in pii_keywords and name_lower not in seen:
                seen.add(name_lower)
                posture.sensitive_fields.append(s.name)

    # Also check from class attributes that look like PII
    for s in symbols.symbols:
        if s.kind.value == "class" and s.file_path and "model" in s.file_path.lower():
            # This is likely a data model — check for PII field names
            pass  # Fields are already captured above via properties

    posture.sensitive_fields = sorted(set(posture.sensitive_fields))


def _analyze_rate_limiting(
    posture: SecurityPosture, source_files: list[Path], repo_path: Path
) -> None:
    """Detect rate limiting setup."""
    for fp in source_files:
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        # Python
        if "slowapi" in text or "SlowAPI" in text:
            posture.rate_limiting = "SlowAPI"
        elif "flask_limiter" in text or "Limiter" in text:
            posture.rate_limiting = "Flask-Limiter"
        elif "throttle" in text.lower() and "class" in text:
            posture.rate_limiting = "custom throttling"

        # JS/TS
        if "express-rate-limit" in text or "rateLimit" in text:
            posture.rate_limiting = "express-rate-limit"
        if "bottleneck" in text:
            posture.rate_limiting = "Bottleneck"

        if posture.rate_limiting:
            break


def _generate_security_notes(posture: SecurityPosture) -> None:
    """Generate actionable security notes for coding agents."""
    notes = posture.security_notes  # already has some from above

    if posture.auth_required_by_default:
        notes.insert(0, "Auth is required by default — add auth guard to every new route")

    if posture.input_validation:
        notes.append(f"All inputs must be validated via {posture.input_validation} — never accept raw dicts/objects")

    if posture.sql_safety == "ORM-only":
        notes.append("SQL: ORM-only — do not use raw SQL queries")
    elif posture.sql_safety and "raw" in posture.sql_safety:
        notes.append("SQL: Raw SQL exists — always use parameterized queries, never f-strings")

    if posture.cors_allow_all:
        notes.append("CORS allows all origins — do not add credentials support without restricting origins")

    if posture.secret_management:
        notes.append(f"Secrets: loaded via {posture.secret_management} — never hardcode credentials")

    if posture.sensitive_fields:
        fields = ", ".join(posture.sensitive_fields[:10])
        notes.append(f"PII fields ({fields}) — do not log, expose in list APIs, or include in error messages")

    if not posture.rate_limiting:
        notes.append("No rate limiting detected — consider adding to public/auth endpoints")

    # Deduplicate
    posture.security_notes = list(dict.fromkeys(notes))
