"""Dims 9+10: Coding conventions + test patterns via statistical AST analysis."""

from __future__ import annotations

import re
from pathlib import Path

from repox.extractors import is_test_file
from repox.models import (
    CodingConventions,
    Convention,
    SymbolGraph,
    SymbolKind,
    TestPatterns,
)


# ── Coding Conventions (Dim 9) ───────────────────────────────────────────────


def extract_conventions(
    repo_path: Path,
    source_files: list[Path],
    symbol_graph: SymbolGraph,
) -> CodingConventions:
    """Extract coding conventions via statistical analysis of the symbol graph."""
    conventions: list[Convention] = []

    # Naming conventions
    naming = _analyze_naming(symbol_graph)
    conventions.extend(naming)

    # Type hint coverage (Python)
    type_hint_conv = _analyze_type_hints(symbol_graph)
    if type_hint_conv:
        conventions.append(type_hint_conv)

    # Async patterns
    async_conv = _analyze_async_patterns(symbol_graph)
    if async_conv:
        conventions.append(async_conv)

    # Docstring coverage
    doc_conv = _analyze_docstrings(symbol_graph)
    if doc_conv:
        conventions.append(doc_conv)

    # Visibility patterns
    vis_conv = _analyze_visibility(symbol_graph)
    if vis_conv:
        conventions.append(vis_conv)

    # Import patterns from source files
    import_convs = _analyze_import_patterns(source_files)
    conventions.extend(import_convs)

    # Error handling patterns
    error_convs = _analyze_error_handling(source_files)
    conventions.extend(error_convs)

    # Async boundaries per module
    async_boundary = _analyze_async_boundaries(symbol_graph)
    if async_boundary:
        conventions.append(async_boundary)

    return CodingConventions(conventions=conventions)


def _analyze_naming(graph: SymbolGraph) -> list[Convention]:
    """Detect naming conventions from symbol names."""
    conventions: list[Convention] = []

    # Classify function/method names
    funcs = [s for s in graph.symbols if s.kind in (SymbolKind.FUNCTION, SymbolKind.METHOD)]
    if funcs:
        snake = sum(1 for f in funcs if _is_snake_case(f.name))
        camel = sum(1 for f in funcs if _is_camel_case(f.name))
        total = len(funcs)

        if total > 0:
            dominant = "snake_case" if snake >= camel else "camelCase"
            pct = max(snake, camel) / total
            if pct > 0.5:
                conventions.append(Convention(
                    category="naming",
                    rule=f"Functions/methods use {dominant}",
                    confidence=round(pct, 2),
                    examples=[f.name for f in funcs if (
                        _is_snake_case(f.name) if dominant == "snake_case" else _is_camel_case(f.name)
                    )][:3],
                ))

    # Classify class names
    classes = [s for s in graph.symbols if s.kind == SymbolKind.CLASS]
    if classes:
        pascal = sum(1 for c in classes if _is_pascal_case(c.name))
        total = len(classes)
        if total > 0 and pascal / total > 0.5:
            conventions.append(Convention(
                category="naming",
                rule="Classes use PascalCase",
                confidence=round(pascal / total, 2),
                examples=[c.name for c in classes if _is_pascal_case(c.name)][:3],
            ))

    # Classify constants
    consts = [s for s in graph.symbols if s.kind == SymbolKind.CONSTANT]
    if consts:
        upper = sum(1 for c in consts if c.name.isupper())
        total = len(consts)
        if total > 0 and upper / total > 0.5:
            conventions.append(Convention(
                category="naming",
                rule="Constants use UPPER_SNAKE_CASE",
                confidence=round(upper / total, 2),
                examples=[c.name for c in consts if c.name.isupper()][:3],
            ))

    return conventions


def _analyze_type_hints(graph: SymbolGraph) -> Convention | None:
    """Analyze type hint coverage for functions/methods."""
    funcs = [s for s in graph.symbols if s.kind in (SymbolKind.FUNCTION, SymbolKind.METHOD)]
    if not funcs:
        return None

    with_return_type = sum(1 for f in funcs if f.return_type is not None)
    total = len(funcs)
    pct = with_return_type / total

    if pct > 0.7:
        rule = f"Return type annotations used ({pct:.0%} coverage)"
    elif pct > 0.3:
        rule = f"Partial return type annotations ({pct:.0%} coverage)"
    else:
        rule = f"Minimal type annotations ({pct:.0%} coverage)"

    return Convention(
        category="types",
        rule=rule,
        confidence=round(pct, 2),
    )


def _analyze_async_patterns(graph: SymbolGraph) -> Convention | None:
    """Detect async usage patterns."""
    funcs = [s for s in graph.symbols if s.kind in (SymbolKind.FUNCTION, SymbolKind.METHOD)]
    if not funcs:
        return None

    async_count = sum(1 for f in funcs if f.is_async)
    total = len(funcs)
    pct = async_count / total

    if async_count == 0:
        return None

    if pct > 0.5:
        rule = f"Heavily async codebase ({pct:.0%} of functions are async)"
    else:
        rule = f"Mixed sync/async ({async_count} async out of {total} functions)"

    return Convention(
        category="async",
        rule=rule,
        confidence=round(pct, 2),
        examples=[f.name for f in funcs if f.is_async][:3],
    )


def _analyze_docstrings(graph: SymbolGraph) -> Convention | None:
    """Analyze docstring coverage."""
    public_symbols = [
        s for s in graph.symbols
        if s.kind in (SymbolKind.FUNCTION, SymbolKind.METHOD, SymbolKind.CLASS)
        and s.visibility == "public"
    ]
    if not public_symbols:
        return None

    with_docs = sum(1 for s in public_symbols if s.docstring)
    total = len(public_symbols)
    pct = with_docs / total

    if pct > 0.7:
        rule = f"Well-documented ({pct:.0%} of public symbols have docstrings)"
    elif pct > 0.3:
        rule = f"Partially documented ({pct:.0%} of public symbols have docstrings)"
    else:
        rule = f"Minimal documentation ({pct:.0%} docstring coverage)"

    return Convention(
        category="documentation",
        rule=rule,
        confidence=round(pct, 2),
    )


def _analyze_visibility(graph: SymbolGraph) -> Convention | None:
    """Analyze visibility/encapsulation patterns."""
    funcs = [s for s in graph.symbols if s.kind in (SymbolKind.FUNCTION, SymbolKind.METHOD)]
    if not funcs:
        return None

    private = sum(1 for f in funcs if f.visibility in ("private", "protected"))
    total = len(funcs)
    pct = private / total

    if pct > 0.3:
        return Convention(
            category="encapsulation",
            rule=f"Active use of private/protected visibility ({pct:.0%} of functions)",
            confidence=round(pct, 2),
        )
    return None


def _analyze_import_patterns(source_files: list[Path]) -> list[Convention]:
    """Analyze import ordering and style from Python files."""
    conventions: list[Convention] = []

    # Check for __future__ imports at top (Python)
    future_count = 0
    py_files = [f for f in source_files if f.suffix == ".py"]
    for fp in py_files[:50]:  # Sample up to 50 files
        try:
            text = fp.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        lines = text.split("\n")
        for line in lines[:5]:  # Check first 5 lines
            if line.strip().startswith("from __future__"):
                future_count += 1
                break

    if py_files and future_count / max(len(py_files[:50]), 1) > 0.5:
        conventions.append(Convention(
            category="imports",
            rule="Uses from __future__ import annotations",
            confidence=round(future_count / len(py_files[:50]), 2),
        ))

    return conventions


# ── Test Patterns (Dim 10) ───────────────────────────────────────────────────


def extract_test_patterns(
    repo_path: Path,
    source_files: list[Path],
    symbol_graph: SymbolGraph,
) -> TestPatterns:
    """Detect test framework, naming, fixtures, mocking patterns."""
    patterns = TestPatterns()

    test_files = [f for f in source_files if is_test_file(f, repo_path)]
    patterns.test_file_count = len(test_files)

    if not test_files:
        return patterns

    # Detect file pattern
    patterns.file_pattern = _detect_test_file_pattern(test_files, repo_path)

    # Count test functions from symbol graph
    test_symbols = [
        s for s in symbol_graph.symbols
        if s.kind in (SymbolKind.FUNCTION, SymbolKind.METHOD)
        and (s.name.startswith("test_") or s.name.startswith("test"))
    ]
    patterns.test_count = len(test_symbols)

    # Detect framework and patterns from test file contents
    _detect_test_framework_and_patterns(test_files, patterns)

    # Detect naming convention from test symbols
    if test_symbols:
        patterns.naming_convention = _detect_test_naming(test_symbols)

    return patterns



def _detect_test_file_pattern(test_files: list[Path], repo_path: Path) -> str:
    """Detect the test file naming pattern."""
    patterns: dict[str, int] = {}
    for f in test_files:
        name = f.name
        if name.startswith("test_") and name.endswith(".py"):
            patterns["test_*.py"] = patterns.get("test_*.py", 0) + 1
        elif name.endswith("_test.py"):
            patterns["*_test.py"] = patterns.get("*_test.py", 0) + 1
        elif name.endswith(".test.ts") or name.endswith(".test.tsx"):
            patterns["*.test.ts"] = patterns.get("*.test.ts", 0) + 1
        elif name.endswith(".test.js") or name.endswith(".test.jsx"):
            patterns["*.test.js"] = patterns.get("*.test.js", 0) + 1
        elif name.endswith(".spec.ts"):
            patterns["*.spec.ts"] = patterns.get("*.spec.ts", 0) + 1
        elif name.endswith("_test.go"):
            patterns["*_test.go"] = patterns.get("*_test.go", 0) + 1

    if patterns:
        return max(patterns, key=patterns.get)
    return "unknown"


def _detect_test_framework_and_patterns(test_files: list[Path], patterns: TestPatterns) -> None:
    """Detect framework, fixture approach, mock library from test file contents."""
    framework_signals: dict[str, int] = {}
    mock_signals: dict[str, int] = {}
    fixture_signals: dict[str, int] = {}
    assertion_signals: dict[str, int] = {}

    for fp in test_files[:30]:  # Sample up to 30 test files
        try:
            text = fp.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        # Framework detection
        if "import pytest" in text or "from pytest" in text or "@pytest" in text:
            framework_signals["pytest"] = framework_signals.get("pytest", 0) + 1
        if "from unittest" in text or "import unittest" in text:
            framework_signals["unittest"] = framework_signals.get("unittest", 0) + 1
        if "from vitest" in text or "import { describe" in text or "import { it" in text:
            framework_signals["vitest"] = framework_signals.get("vitest", 0) + 1
        if "from jest" in text or "describe(" in text and fp.suffix in (".js", ".ts", ".jsx", ".tsx"):
            framework_signals["jest"] = framework_signals.get("jest", 0) + 1

        # Mock detection
        if "unittest.mock" in text or "from unittest.mock" in text or "mock.patch" in text:
            mock_signals["unittest.mock"] = mock_signals.get("unittest.mock", 0) + 1
        if "pytest-mock" in text or "mocker" in text:
            mock_signals["pytest-mock"] = mock_signals.get("pytest-mock", 0) + 1
        if "jest.mock" in text or "jest.fn" in text:
            mock_signals["jest.mock"] = mock_signals.get("jest.mock", 0) + 1
        if "vi.mock" in text or "vi.fn" in text:
            mock_signals["vi.mock"] = mock_signals.get("vi.mock", 0) + 1

        # Fixture detection
        if "@pytest.fixture" in text:
            fixture_signals["pytest fixtures"] = fixture_signals.get("pytest fixtures", 0) + 1
        if "factory_boy" in text or "class.*Factory" in text:
            fixture_signals["factory_boy"] = fixture_signals.get("factory_boy", 0) + 1
        if "setUp" in text or "tearDown" in text:
            fixture_signals["setUp/tearDown"] = fixture_signals.get("setUp/tearDown", 0) + 1
        if "beforeEach" in text or "afterEach" in text:
            fixture_signals["beforeEach/afterEach"] = fixture_signals.get("beforeEach/afterEach", 0) + 1

        # Assertion style
        if "assert " in text and fp.suffix == ".py":
            assertion_signals["assert"] = assertion_signals.get("assert", 0) + 1
        if "self.assert" in text:
            assertion_signals["self.assert*"] = assertion_signals.get("self.assert*", 0) + 1
        if "expect(" in text:
            assertion_signals["expect()"] = assertion_signals.get("expect()", 0) + 1

    if framework_signals:
        patterns.framework = max(framework_signals, key=framework_signals.get)
    if mock_signals:
        patterns.mock_library = max(mock_signals, key=mock_signals.get)
    if fixture_signals:
        patterns.fixture_approach = max(fixture_signals, key=fixture_signals.get)
    if assertion_signals:
        patterns.assertion_style = max(assertion_signals, key=assertion_signals.get)


def _detect_test_naming(test_symbols: list) -> str:
    """Detect test naming convention."""
    # test_method_scenario vs test_scenario vs testMethodScenario
    snake_with_context = 0
    plain_test = 0

    for s in test_symbols:
        name = s.name
        if name.startswith("test_") and name.count("_") >= 2:
            snake_with_context += 1
        elif name.startswith("test_"):
            plain_test += 1

    if snake_with_context > plain_test:
        return "test_{method}_{scenario}"
    elif plain_test > 0:
        return "test_{description}"
    return "test_*"


# ── Naming helpers ───────────────────────────────────────────────────────────


def _analyze_error_handling(source_files: list[Path]) -> list[Convention]:
    """Detect error handling patterns from source files."""
    conventions: list[Convention] = []
    try_count = 0
    custom_exceptions: list[str] = []
    error_patterns: dict[str, int] = {}

    py_files = [f for f in source_files if f.suffix == ".py"
                and not f.name.startswith("test_") and "tests/" not in str(f)]
    for fp in py_files[:50]:
        try:
            text = fp.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        try_count += text.count("\n    try:")
        try_count += text.count("\ntry:")

        # Custom exception classes
        for m in re.finditer(r'class\s+(\w*(?:Error|Exception)\w*)\s*\(', text):
            custom_exceptions.append(m.group(1))

        # Error return patterns
        if 'raise HTTPException' in text or 'raise Http404' in text:
            error_patterns["HTTP exceptions"] = error_patterns.get("HTTP exceptions", 0) + 1
        if 'return {"error"' in text or "return json.dumps" in text:
            error_patterns["JSON error responses"] = error_patterns.get("JSON error responses", 0) + 1
        if 'logging.error' in text or 'logger.error' in text or 'log.error' in text:
            error_patterns["structured logging"] = error_patterns.get("structured logging", 0) + 1

    if try_count > 0:
        conventions.append(Convention(
            category="error_handling",
            rule=f"Uses try/except blocks ({try_count} instances across production code)",
            confidence=0.8,
        ))

    if custom_exceptions:
        unique_exceptions = sorted(set(custom_exceptions))[:5]
        conventions.append(Convention(
            category="error_handling",
            rule=f"Defines custom exceptions: {', '.join(unique_exceptions)}",
            confidence=0.9,
            examples=unique_exceptions,
        ))

    for pattern, count in error_patterns.items():
        if count >= 1:
            conventions.append(Convention(
                category="error_handling",
                rule=f"Uses {pattern} for error reporting",
                confidence=0.7,
            ))

    return conventions


def _analyze_async_boundaries(graph: SymbolGraph) -> Convention | None:
    """Detect async/sync boundaries per module."""
    from collections import defaultdict

    module_async: dict[str, dict[str, int]] = defaultdict(lambda: {"async": 0, "sync": 0})

    for s in graph.symbols:
        if s.kind.value not in ("function", "method"):
            continue
        if s.file_path.startswith("tests/") or s.name.startswith("test_"):
            continue
        module = s.file_path
        if s.is_async:
            module_async[module]["async"] += 1
        else:
            module_async[module]["sync"] += 1

    if not module_async:
        return None

    boundaries: list[str] = []
    for module, counts in sorted(module_async.items()):
        total = counts["async"] + counts["sync"]
        if total == 0:
            continue
        if counts["async"] == total:
            boundaries.append(f"{module}: all async")
        elif counts["sync"] == total:
            boundaries.append(f"{module}: all sync")
        elif counts["async"] > 0:
            boundaries.append(f"{module}: {counts['async']} async, {counts['sync']} sync")

    if not boundaries:
        return None

    return Convention(
        category="async",
        rule="Async boundaries: " + "; ".join(boundaries[:8]),
        confidence=0.9,
        examples=boundaries[:8],
    )


def _is_snake_case(name: str) -> bool:
    """Check if name is snake_case (includes _private and __dunder__)."""
    clean = name.strip("_")
    if not clean:
        return True
    return clean == clean.lower() and "_" in name or clean.islower()


def _is_camel_case(name: str) -> bool:
    """Check if name is camelCase."""
    if not name or name[0].isupper() or "_" in name:
        return False
    return name != name.lower() and any(c.isupper() for c in name)


def _is_pascal_case(name: str) -> bool:
    """Check if name is PascalCase."""
    if not name or not name[0].isupper():
        return False
    return "_" not in name
