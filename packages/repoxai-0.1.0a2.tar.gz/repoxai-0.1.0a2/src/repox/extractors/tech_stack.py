"""Dimension 1: Tech stack fingerprint — auto-detect from config files."""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from repox.models import Dependency, TechStack

# ── Known framework indicators ───────────────────────────────────────────────

PYTHON_FRAMEWORKS = {
    "fastapi": "FastAPI",
    "django": "Django",
    "flask": "Flask",
    "starlette": "Starlette",
    "tornado": "Tornado",
    "sanic": "Sanic",
    "litestar": "Litestar",
    "mcp": "MCP",
}

PYTHON_ORMS = {
    "sqlalchemy": "SQLAlchemy",
    "django": "Django ORM",
    "tortoise-orm": "Tortoise ORM",
    "peewee": "Peewee",
    "sqlmodel": "SQLModel",
    "prisma": "Prisma",
}

PYTHON_TEST_RUNNERS = {
    "pytest": "pytest",
    "unittest": "unittest",
    "nose2": "nose2",
}

PYTHON_LINTERS = {
    "ruff": "ruff",
    "flake8": "flake8",
    "pylint": "pylint",
    "mypy": "mypy",
    "pyright": "pyright",
}

PYTHON_FORMATTERS = {
    "black": "black",
    "ruff": "ruff",
    "autopep8": "autopep8",
    "yapf": "yapf",
}

NODE_FRAMEWORKS = {
    "express": "Express",
    "next": "Next.js",
    "nuxt": "Nuxt",
    "fastify": "Fastify",
    "koa": "Koa",
    "nestjs": "NestJS",
    "@nestjs/core": "NestJS",
    "hono": "Hono",
}

NODE_ORMS = {
    "prisma": "Prisma",
    "@prisma/client": "Prisma",
    "typeorm": "TypeORM",
    "sequelize": "Sequelize",
    "drizzle-orm": "Drizzle",
    "mongoose": "Mongoose",
    "knex": "Knex",
}

NODE_TEST_RUNNERS = {
    "vitest": "vitest",
    "jest": "jest",
    "mocha": "mocha",
    "ava": "ava",
}

CLOUD_INDICATORS = {
    "boto3": "AWS",
    "aws-sdk": "AWS",
    "@aws-sdk": "AWS",
    "google-cloud": "GCP",
    "@google-cloud": "GCP",
    "azure": "Azure",
    "@azure": "Azure",
}

DATABASE_INDICATORS = {
    "psycopg2": "PostgreSQL",
    "psycopg": "PostgreSQL",
    "asyncpg": "PostgreSQL",
    "pg": "PostgreSQL",
    "mysql-connector": "MySQL",
    "pymysql": "MySQL",
    "mysql2": "MySQL",
    "pymongo": "MongoDB",
    "mongodb": "MongoDB",
    "mongoose": "MongoDB",
    "redis": "Redis",
    "aioredis": "Redis",
    "ioredis": "Redis",
    "sqlite3": "SQLite",
    "better-sqlite3": "SQLite",
}


def extract_tech_stack(repo_path: Path) -> TechStack:
    """Auto-detect the complete tech stack from config files."""
    ts = TechStack()

    # Try each config parser — check root and common monorepo subdirs
    search_dirs = [repo_path]
    for sub in ("backend", "server", "api", "frontend", "web", "mobile", "app"):
        candidate = repo_path / sub
        if candidate.is_dir():
            search_dirs.append(candidate)

    for d in search_dirs:
        pyproject = d / "pyproject.toml"
        if pyproject.exists():
            _parse_pyproject(pyproject, ts)

        package_json = d / "package.json"
        if package_json.exists():
            _parse_package_json(package_json, ts)

        go_mod = d / "go.mod"
        if go_mod.exists():
            _parse_go_mod(go_mod, ts)

        cargo_toml = d / "Cargo.toml"
        if cargo_toml.exists():
            _parse_cargo_toml(cargo_toml, ts)

    setup_cfg = repo_path / "setup.cfg"
    if setup_cfg.exists():
        ts.config_files_parsed.append("setup.cfg")

    # CI detection
    _detect_ci(repo_path, ts)

    # Container detection
    _detect_containers(repo_path, ts)

    # Linter config detection
    _detect_linter_configs(repo_path, ts)

    return ts


# ── pyproject.toml ───────────────────────────────────────────────────────────

def _parse_pyproject(path: Path, ts: TechStack) -> None:
    """Parse pyproject.toml for Python project metadata."""
    # Use tomllib (stdlib in 3.11+)
    import tomllib

    ts.config_files_parsed.append("pyproject.toml")
    text = path.read_bytes()
    try:
        data = tomllib.loads(text.decode())
    except Exception:
        return

    project = data.get("project", {})

    # Language
    if not ts.primary_language:
        ts.primary_language = "Python"

    # Python version
    requires = project.get("requires-python", "")
    if requires:
        m = re.search(r"(\d+\.\d+)", requires)
        if m:
            ts.language_version = m.group(1)

    # Package manager
    build_system = data.get("build-system", {})
    build_requires = build_system.get("requires", [])
    build_backend = build_system.get("build-backend", "")

    if "uv_build" in build_backend or any("uv" in r for r in build_requires):
        ts.package_manager = "uv"
    elif "poetry" in build_backend or any("poetry" in r for r in build_requires):
        ts.package_manager = "poetry"
    elif "flit" in build_backend:
        ts.package_manager = "flit"
    elif "hatchling" in build_backend:
        ts.package_manager = "hatch"
    elif "setuptools" in build_backend or any("setuptools" in r for r in build_requires):
        ts.package_manager = "pip"

    # Dependencies
    deps = project.get("dependencies", [])
    for dep_str in deps:
        dep = _parse_pep508(dep_str)
        if dep:
            ts.dependencies.append(dep)

    # Dev dependencies (from dependency-groups or optional-dependencies)
    dep_groups = data.get("dependency-groups", {})
    for group_name, group_deps in dep_groups.items():
        for dep_str in group_deps:
            if isinstance(dep_str, str):
                dep = _parse_pep508(dep_str)
                if dep:
                    dep.dev = True
                    ts.dev_dependencies.append(dep)

    optional_deps = project.get("optional-dependencies", {})
    for group_name, group_deps in optional_deps.items():
        for dep_str in group_deps:
            dep = _parse_pep508(dep_str)
            if dep:
                dep.dev = True
                ts.dev_dependencies.append(dep)

    # Detect framework, ORM, test runner from deps
    all_dep_names = [d.name.lower() for d in ts.dependencies + ts.dev_dependencies]
    _detect_from_deps(all_dep_names, ts, ecosystem="python")

    # Test config from pyproject
    tool = data.get("tool", {})
    if "pytest" in tool:
        ts.test_runner = ts.test_runner or "pytest"
        pytest_conf = tool["pytest"].get("ini_options", {})
        if "testpaths" in pytest_conf:
            ts.test_command = f"pytest {' '.join(pytest_conf['testpaths'])}"
        else:
            ts.test_command = ts.test_command or "pytest"

    # Linter/formatter from tool config
    if "ruff" in tool:
        ruff_conf = tool["ruff"]
        if ruff_conf.get("lint"):
            ts.linter = ts.linter or "ruff"
        if ruff_conf.get("format"):
            ts.formatter = ts.formatter or "ruff"
        # If just [tool.ruff] exists, it's at least a linter
        ts.linter = ts.linter or "ruff"

    if "black" in tool:
        ts.formatter = ts.formatter or "black"

    if "mypy" in tool:
        ts.linter = ts.linter or "mypy"


def _parse_pep508(dep_str: str) -> Dependency | None:
    """Parse a PEP 508 dependency string like 'requests>=2.0,<3'."""
    m = re.match(r"^([a-zA-Z0-9_.-]+)\s*(.*)", dep_str.strip())
    if not m:
        return None
    name = m.group(1)
    version = m.group(2).strip() or None
    return Dependency(name=name, version=version)


# ── package.json ─────────────────────────────────────────────────────────────

def _parse_package_json(path: Path, ts: TechStack) -> None:
    """Parse package.json for Node.js project metadata."""
    import json

    ts.config_files_parsed.append("package.json")
    try:
        data = json.loads(path.read_text())
    except Exception:
        return

    # Language
    if not ts.primary_language:
        # Check for TypeScript
        dev_deps = data.get("devDependencies", {})
        all_deps = {**data.get("dependencies", {}), **dev_deps}
        if "typescript" in all_deps:
            ts.primary_language = "TypeScript"
        else:
            ts.primary_language = "JavaScript"

    # Node version
    engines = data.get("engines", {})
    if "node" in engines:
        m = re.search(r"(\d+)", engines["node"])
        if m:
            ts.language_version = m.group(1)

    # Package manager
    pm = data.get("packageManager", "")
    if "pnpm" in pm:
        ts.package_manager = ts.package_manager or "pnpm"
    elif "yarn" in pm:
        ts.package_manager = ts.package_manager or "yarn"
    elif "bun" in pm:
        ts.package_manager = ts.package_manager or "bun"
    else:
        ts.package_manager = ts.package_manager or "npm"

    # Dependencies
    for name, version in data.get("dependencies", {}).items():
        ts.dependencies.append(Dependency(name=name, version=version))
    for name, version in data.get("devDependencies", {}).items():
        ts.dev_dependencies.append(Dependency(name=name, version=version, dev=True))

    all_dep_names = [d.name.lower() for d in ts.dependencies + ts.dev_dependencies]
    _detect_from_deps(all_dep_names, ts, ecosystem="node")

    # Test command from scripts
    scripts = data.get("scripts", {})
    test_script = scripts.get("test", "")
    if test_script and test_script != "echo \"Error: no test specified\" && exit 1":
        ts.test_command = ts.test_command or test_script


# ── go.mod ───────────────────────────────────────────────────────────────────

def _parse_go_mod(path: Path, ts: TechStack) -> None:
    ts.config_files_parsed.append("go.mod")
    text = path.read_text()

    ts.primary_language = ts.primary_language or "Go"
    ts.package_manager = ts.package_manager or "go mod"
    ts.test_runner = ts.test_runner or "go test"
    ts.test_command = ts.test_command or "go test ./..."

    # Go version
    m = re.search(r"^go\s+(\d+\.\d+)", text, re.MULTILINE)
    if m:
        ts.language_version = ts.language_version or m.group(1)

    # Deps
    for m in re.finditer(r"^\s+(\S+)\s+(v\S+)", text, re.MULTILINE):
        ts.dependencies.append(Dependency(name=m.group(1), version=m.group(2)))

    # Framework detection
    dep_names = [d.name for d in ts.dependencies]
    for name in dep_names:
        if "gin-gonic" in name:
            ts.framework = ts.framework or "Gin"
        elif "labstack/echo" in name:
            ts.framework = ts.framework or "Echo"
        elif "gofiber" in name:
            ts.framework = ts.framework or "Fiber"
        elif "gorilla/mux" in name:
            ts.framework = ts.framework or "Gorilla Mux"

    # ORM detection
    for name in dep_names:
        if "gorm.io" in name:
            ts.orm = ts.orm or "GORM"
        elif "ent" in name:
            ts.orm = ts.orm or "Ent"


# ── Cargo.toml ───────────────────────────────────────────────────────────────

def _parse_cargo_toml(path: Path, ts: TechStack) -> None:
    import tomllib

    ts.config_files_parsed.append("Cargo.toml")
    try:
        data = tomllib.loads(path.read_bytes().decode())
    except Exception:
        return

    ts.primary_language = ts.primary_language or "Rust"
    ts.package_manager = ts.package_manager or "cargo"
    ts.test_runner = ts.test_runner or "cargo test"
    ts.test_command = ts.test_command or "cargo test"

    # Rust edition as version proxy
    package = data.get("package", {})
    edition = package.get("edition")
    if edition:
        ts.language_version = ts.language_version or str(edition)

    # Deps
    for name, ver in data.get("dependencies", {}).items():
        if isinstance(ver, str):
            ts.dependencies.append(Dependency(name=name, version=ver))
        elif isinstance(ver, dict):
            ts.dependencies.append(Dependency(name=name, version=ver.get("version")))

    # Framework detection
    dep_names = [d.name for d in ts.dependencies]
    if "actix-web" in dep_names:
        ts.framework = ts.framework or "Actix Web"
    elif "axum" in dep_names:
        ts.framework = ts.framework or "Axum"
    elif "rocket" in dep_names:
        ts.framework = ts.framework or "Rocket"
    elif "warp" in dep_names:
        ts.framework = ts.framework or "Warp"

    # ORM
    if "diesel" in dep_names:
        ts.orm = ts.orm or "Diesel"
    elif "sea-orm" in dep_names:
        ts.orm = ts.orm or "SeaORM"
    elif "sqlx" in dep_names:
        ts.orm = ts.orm or "SQLx"


# ── Cross-ecosystem detection helpers ────────────────────────────────────────

def _detect_from_deps(dep_names: list[str], ts: TechStack, ecosystem: str) -> None:
    """Detect framework, ORM, test runner, cloud, DB from dependency names."""
    if ecosystem == "python":
        frameworks, orms, test_runners = PYTHON_FRAMEWORKS, PYTHON_ORMS, PYTHON_TEST_RUNNERS
    else:
        frameworks, orms, test_runners = NODE_FRAMEWORKS, NODE_ORMS, NODE_TEST_RUNNERS

    for dep in dep_names:
        if not ts.framework and dep in frameworks:
            ts.framework = frameworks[dep]
        if not ts.orm and dep in orms:
            ts.orm = orms[dep]
        if not ts.test_runner and dep in test_runners:
            ts.test_runner = test_runners[dep]

        # Cloud
        for indicator, cloud in CLOUD_INDICATORS.items():
            if dep.startswith(indicator):
                ts.cloud_provider = ts.cloud_provider or cloud
                break

        # Database
        for indicator, db in DATABASE_INDICATORS.items():
            if dep.startswith(indicator):
                ts.database = ts.database or db
                break


def _detect_ci(repo_path: Path, ts: TechStack) -> None:
    """Detect CI system from config files."""
    gh_workflows = repo_path / ".github" / "workflows"
    if gh_workflows.is_dir() and any(gh_workflows.iterdir()):
        ts.ci_system = ts.ci_system or "GitHub Actions"
        ts.config_files_parsed.append(".github/workflows/")

    gitlab_ci = repo_path / ".gitlab-ci.yml"
    if gitlab_ci.exists():
        ts.ci_system = ts.ci_system or "GitLab CI"
        ts.config_files_parsed.append(".gitlab-ci.yml")

    circleci = repo_path / ".circleci" / "config.yml"
    if circleci.exists():
        ts.ci_system = ts.ci_system or "CircleCI"
        ts.config_files_parsed.append(".circleci/config.yml")

    jenkinsfile = repo_path / "Jenkinsfile"
    if jenkinsfile.exists():
        ts.ci_system = ts.ci_system or "Jenkins"
        ts.config_files_parsed.append("Jenkinsfile")


def _detect_containers(repo_path: Path, ts: TechStack) -> None:
    """Detect containerization from Docker/K8s files."""
    dockerfile = repo_path / "Dockerfile"
    compose = repo_path / "docker-compose.yml"
    compose_alt = repo_path / "docker-compose.yaml"
    compose_alt2 = repo_path / "compose.yml"
    compose_alt3 = repo_path / "compose.yaml"

    if dockerfile.exists():
        ts.containerization = ts.containerization or "Docker"
        ts.config_files_parsed.append("Dockerfile")

    for f in [compose, compose_alt, compose_alt2, compose_alt3]:
        if f.exists():
            ts.containerization = ts.containerization or "Docker Compose"
            ts.config_files_parsed.append(f.name)
            break

    k8s = repo_path / "k8s"
    if k8s.is_dir():
        ts.containerization = ts.containerization or "Kubernetes"
        ts.config_files_parsed.append("k8s/")


def _detect_linter_configs(repo_path: Path, ts: TechStack) -> None:
    """Detect linters/formatters from standalone config files."""
    linter_files = {
        "ruff.toml": ("ruff", None),
        ".ruff.toml": ("ruff", None),
        ".eslintrc": (None, None),
        ".eslintrc.js": (None, None),
        ".eslintrc.json": (None, None),
        "eslint.config.js": (None, None),
        "eslint.config.mjs": (None, None),
        ".prettierrc": (None, "prettier"),
        ".prettierrc.js": (None, "prettier"),
        "prettier.config.js": (None, "prettier"),
        "biome.json": ("biome", "biome"),
    }

    for filename, (linter, formatter) in linter_files.items():
        if (repo_path / filename).exists():
            ts.config_files_parsed.append(filename)
            if linter:
                ts.linter = ts.linter or linter
            if formatter:
                ts.formatter = ts.formatter or formatter

    # eslint detection from config files (set separately since multiple patterns)
    eslint_files = [".eslintrc", ".eslintrc.js", ".eslintrc.json", "eslint.config.js", "eslint.config.mjs"]
    for f in eslint_files:
        if (repo_path / f).exists():
            ts.linter = ts.linter or "eslint"
            break
