"""Dimension 5: API surface map — endpoint + route extraction."""

from __future__ import annotations

import json
import re
from pathlib import Path

import tree_sitter_language_pack as tslp
from tree_sitter import Node

from repox.models import APISurface, Endpoint

# ── Main extraction ──────────────────────────────────────────────────────────


def extract_api_surface(repo_path: Path, source_files: list[Path]) -> APISurface:
    """Extract all HTTP endpoints, async workers, and API definitions."""
    surface = APISurface()

    for file_path in source_files:
        rel_path = str(file_path.relative_to(repo_path))

        if file_path.suffix == ".py":
            try:
                code = file_path.read_bytes()
            except (OSError, UnicodeDecodeError):
                continue
            endpoints = _extract_python_endpoints(file_path, rel_path, code)
            surface.endpoints.extend(endpoints)
            if endpoints and not surface.framework:
                surface.framework = _detect_python_framework(code)

        elif file_path.suffix in (".js", ".ts", ".jsx", ".tsx"):
            try:
                text = file_path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            endpoints = _extract_js_endpoints(text, rel_path, repo_path)
            surface.endpoints.extend(endpoints)
            if endpoints and not surface.framework:
                surface.framework = _detect_js_framework(text)

    # Check for OpenAPI spec
    openapi_endpoints = _parse_openapi(repo_path)
    if openapi_endpoints and not surface.endpoints:
        surface.endpoints = openapi_endpoints
        surface.framework = surface.framework or "OpenAPI"

    return surface


# ── Python endpoint extraction ───────────────────────────────────────────────

# FastAPI/Flask/Starlette decorator patterns
_PYTHON_HTTP_METHODS = {"get", "post", "put", "delete", "patch", "head", "options"}


def _extract_python_endpoints(file_path: Path, rel_path: str, code: bytes) -> list[Endpoint]:
    """Extract endpoints from Python files using tree-sitter AST."""
    try:
        parser = tslp.get_parser("python")
    except Exception:
        return []

    tree = parser.parse(code)
    endpoints: list[Endpoint] = []

    # Walk all decorated definitions looking for route decorators
    _walk_python_routes(tree.root_node, rel_path, code, endpoints)

    # Also check for Django url patterns
    endpoints.extend(_extract_django_urls(tree.root_node, rel_path, code))

    # Check for Celery tasks
    endpoints.extend(_extract_celery_tasks(tree.root_node, rel_path, code))

    # Check for MCP tools
    endpoints.extend(_extract_mcp_tools(tree.root_node, rel_path, code))

    return endpoints


def _walk_python_routes(node: Node, file_path: str, code: bytes, endpoints: list[Endpoint]) -> None:
    """Walk AST looking for route/endpoint decorators."""
    for child in node.children:
        if child.type == "decorated_definition":
            endpoint = _parse_python_route_decorator(child, file_path, code)
            if endpoint:
                endpoints.append(endpoint)

        elif child.type in ("class_definition", "block"):
            _walk_python_routes(child, file_path, code, endpoints)


def _parse_python_route_decorator(node: Node, file_path: str, code: bytes) -> Endpoint | None:
    """Parse a decorated function for FastAPI/Flask route decorators."""
    decorators: list[Node] = []
    func_node = None

    for child in node.children:
        if child.type == "decorator":
            decorators.append(child)
        elif child.type == "function_definition":
            func_node = child

    if not func_node or not decorators:
        return None

    # Get function name
    func_name = None
    for child in func_node.children:
        if child.type == "identifier":
            func_name = child.text.decode()
            break

    if not func_name:
        return None

    # Check each decorator for route patterns
    for dec in decorators:
        dec_text = dec.text.decode()

        # FastAPI/Flask patterns: @app.get("/path"), @router.post("/path")
        m = re.match(
            r'@\w+\.(' + '|'.join(_PYTHON_HTTP_METHODS) + r')\s*\(\s*["\']([^"\']+)["\']',
            dec_text,
        )
        if m:
            method = m.group(1).upper()
            path = m.group(2)

            # Try to extract response model from type hints
            return_type = _get_python_return_type(func_node)

            return Endpoint(
                method=method,
                path=path,
                handler=func_name,
                file_path=file_path,
                line=func_node.start_point[0] + 1,
                response_schema=return_type,
            )

        # @app.route("/path", methods=["GET", "POST"])
        m = re.match(
            r'@\w+\.route\s*\(\s*["\']([^"\']+)["\']',
            dec_text,
        )
        if m:
            path = m.group(1)
            methods_match = re.search(r'methods\s*=\s*\[([^\]]+)\]', dec_text)
            method = "GET"
            if methods_match:
                methods_text = methods_match.group(1)
                first = re.search(r'["\'](\w+)["\']', methods_text)
                if first:
                    method = first.group(1).upper()

            return Endpoint(
                method=method,
                path=path,
                handler=func_name,
                file_path=file_path,
                line=func_node.start_point[0] + 1,
            )

        # @api_view(["GET"]) — DRF
        m = re.match(r'@api_view\s*\(\s*\[([^\]]+)\]', dec_text)
        if m:
            methods_text = m.group(1)
            first = re.search(r'["\'](\w+)["\']', methods_text)
            method = first.group(1).upper() if first else "GET"
            return Endpoint(
                method=method,
                path=f"/{func_name}",  # DRF path comes from urls.py
                handler=func_name,
                file_path=file_path,
                line=func_node.start_point[0] + 1,
            )

    return None


def _get_python_return_type(func_node: Node) -> str | None:
    """Extract return type annotation from a Python function."""
    for child in func_node.children:
        if child.type == "type":
            return child.text.decode()
    return None


def _extract_django_urls(root: Node, file_path: str, code: bytes) -> list[Endpoint]:
    """Extract Django URL patterns from urls.py."""
    if not file_path.endswith("urls.py"):
        return []

    endpoints: list[Endpoint] = []
    text = code.decode(errors="replace")

    # path("route/", view_func, name="name")
    for m in re.finditer(
        r'path\s*\(\s*["\']([^"\']*)["\']'
        r'\s*,\s*'
        r'(\w[\w.]*)',
        text,
    ):
        path = "/" + m.group(1).strip("/")
        handler = m.group(2)
        line = text[:m.start()].count("\n") + 1
        endpoints.append(Endpoint(
            method="GET",  # Django paths handle multiple methods
            path=path,
            handler=handler,
            file_path=file_path,
            line=line,
        ))

    return endpoints


def _extract_celery_tasks(root: Node, file_path: str, code: bytes) -> list[Endpoint]:
    """Extract Celery task definitions."""
    endpoints: list[Endpoint] = []
    text = code.decode(errors="replace")

    for m in re.finditer(r'@(?:shared_task|app\.task|celery\.task)(?:\([^)]*\))?\s*\ndef\s+(\w+)', text):
        func_name = m.group(1)
        line = text[:m.start()].count("\n") + 1
        endpoints.append(Endpoint(
            method="TASK",
            path=f"celery:{func_name}",
            handler=func_name,
            file_path=file_path,
            line=line,
        ))

    return endpoints


def _extract_mcp_tools(root: Node, file_path: str, code: bytes) -> list[Endpoint]:
    """Extract MCP tool definitions (@mcp.tool() / @server.tool())."""
    endpoints: list[Endpoint] = []
    text = code.decode(errors="replace")

    for m in re.finditer(
        r'^@(?:\w+\.)?tool\s*\([^)]*\)\s*\n'
        r'(?:async\s+)?def\s+(\w+)',
        text,
        re.MULTILINE,
    ):
        func_name = m.group(1)
        line = text[:m.start()].count("\n") + 1

        # Extract docstring for description
        func_start = m.end()
        doc_match = re.search(r'"""(.*?)"""', text[func_start:func_start + 500], re.DOTALL)
        desc = doc_match.group(1).strip().split("\n")[0] if doc_match else None

        endpoints.append(Endpoint(
            method="TOOL",
            path=f"mcp:{func_name}",
            handler=func_name,
            file_path=file_path,
            line=line,
            request_schema=desc,
        ))

    return endpoints


def _detect_python_framework(code: bytes) -> str | None:
    """Detect which Python framework from file content."""
    text = code.decode(errors="replace")
    if "FastMCP" in text or "mcp.server" in text or "@mcp.tool" in text:
        return "MCP"
    if "fastapi" in text.lower() or "APIRouter" in text:
        return "FastAPI"
    if "flask" in text.lower() or "Flask(" in text:
        return "Flask"
    if "django" in text.lower():
        return "Django"
    if "starlette" in text.lower():
        return "Starlette"
    return None


# ── JavaScript/TypeScript endpoint extraction ────────────────────────────────


def _extract_js_endpoints(text: str, rel_path: str, repo_path: Path) -> list[Endpoint]:
    """Extract endpoints from JS/TS files using regex patterns."""
    endpoints: list[Endpoint] = []

    # Express patterns: app.get("/path", handler), router.post("/path", handler)
    for m in re.finditer(
        r'(?:app|router|server)\s*\.\s*(' + '|'.join(_PYTHON_HTTP_METHODS) + r')\s*\(\s*["\']([^"\']+)["\']',
        text,
    ):
        method = m.group(1).upper()
        path = m.group(2)
        line = text[:m.start()].count("\n") + 1

        # Try to find handler name
        handler = _extract_js_handler_name(text, m.end())

        endpoints.append(Endpoint(
            method=method,
            path=path,
            handler=handler or "anonymous",
            file_path=rel_path,
            line=line,
        ))

    # Next.js API routes (app/api/*/route.ts pattern)
    if _is_nextjs_route(rel_path):
        for method in _PYTHON_HTTP_METHODS:
            pattern = rf'export\s+(?:async\s+)?function\s+{method.upper()}\s*\('
            m = re.search(pattern, text)
            if m:
                path = _nextjs_path_from_file(rel_path)
                line = text[:m.start()].count("\n") + 1
                endpoints.append(Endpoint(
                    method=method.upper(),
                    path=path,
                    handler=method.upper(),
                    file_path=rel_path,
                    line=line,
                ))

    return endpoints


def _extract_js_handler_name(text: str, pos: int) -> str | None:
    """Try to extract the handler function name after a route definition."""
    after = text[pos:pos + 100]
    # Look for named function: , handlerName) or , functionName)
    m = re.search(r',\s*(\w+)\s*\)', after)
    if m:
        return m.group(1)
    return None


def _is_nextjs_route(rel_path: str) -> bool:
    """Check if file is a Next.js API route."""
    return ("/api/" in rel_path and rel_path.endswith(("route.ts", "route.js"))) or \
           rel_path.startswith("pages/api/")


def _nextjs_path_from_file(rel_path: str) -> str:
    """Convert Next.js file path to API path."""
    # app/api/users/[id]/route.ts -> /api/users/:id
    path = rel_path
    # Remove file name
    path = re.sub(r'/route\.(ts|js)$', '', path)
    path = re.sub(r'\.(ts|js)$', '', path)
    # Remove app/ or pages/ prefix
    path = re.sub(r'^(?:app|pages)/', '/', path)
    # Convert [param] to :param
    path = re.sub(r'\[(\w+)\]', r':\1', path)
    if not path.startswith("/"):
        path = "/" + path
    return path


def _detect_js_framework(text: str) -> str | None:
    if "express" in text.lower() or "require('express')" in text or "from 'express'" in text:
        return "Express"
    if "next" in text.lower() and "NextResponse" in text:
        return "Next.js"
    if "fastify" in text.lower():
        return "Fastify"
    if "koa" in text.lower():
        return "Koa"
    return None


# ── OpenAPI spec parsing ─────────────────────────────────────────────────────


def _parse_openapi(repo_path: Path) -> list[Endpoint]:
    """Parse OpenAPI/Swagger spec if present."""
    candidates = [
        "openapi.json", "openapi.yaml", "openapi.yml",
        "swagger.json", "swagger.yaml", "swagger.yml",
    ]

    for name in candidates:
        endpoints = _parse_openapi_file(repo_path / name)
        if endpoints:
            return endpoints

    return []


def _parse_openapi_file(spec_path: Path) -> list[Endpoint]:
    """Parse an OpenAPI JSON/YAML file."""
    try:
        text = spec_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return []

    data = None
    if spec_path.suffix == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
    else:
        try:
            import yaml
            data = yaml.safe_load(text)
        except Exception:
            return []

    if not data or "paths" not in data:
        return []

    endpoints: list[Endpoint] = []
    for path, methods in data["paths"].items():
        if not isinstance(methods, dict):
            continue
        for method, details in methods.items():
            if method.lower() not in _PYTHON_HTTP_METHODS:
                continue
            handler = ""
            if isinstance(details, dict):
                handler = details.get("operationId", details.get("summary", ""))
            endpoints.append(Endpoint(
                method=method.upper(),
                path=path,
                handler=handler or "unknown",
                file_path=spec_path.name,
                line=0,
            ))

    return endpoints
