"""Repox extraction engines for each intelligence dimension."""

from __future__ import annotations

from pathlib import Path


def is_test_file(file_path: Path, repo_path: Path | None = None) -> bool:
    """Check if a file is a test file (not production code).

    Works with or without repo_path. When repo_path is provided, checks
    all path components for test directories.
    """
    name = file_path.name

    # File-level patterns
    if name.startswith("test_") or name == "conftest.py":
        return True
    if name.endswith(("_test.py", "_test.go", ".test.ts", ".test.js",
                      ".test.tsx", ".test.jsx", ".spec.ts", ".spec.js")):
        return True

    # Directory-level: tests/, test/, __tests__/, spec/
    test_dirs = {"tests", "test", "__tests__", "spec"}
    if repo_path:
        parts = file_path.relative_to(repo_path).parts
    else:
        parts = file_path.parts
    return any(p in test_dirs for p in parts)
