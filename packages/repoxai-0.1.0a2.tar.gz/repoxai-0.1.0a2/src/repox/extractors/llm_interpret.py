"""Layer 2: LLM interpretation of static extraction data.

Runs after all static extractors. Takes raw profile data and uses LLM
to produce institutional knowledge — architecture insights, convention
guides, and richer pattern detection.

This is what separates "data dump" from "a senior developer's understanding."
"""

from __future__ import annotations

import json
from pathlib import Path

from repox.models import (
    ArchitectureMap,
    ArchPattern,
    CodingConventions,
    Convention,
    DesignPatterns,
    DetectedPattern,
    DirectoryLabel,
    RepoProfile,
)


def llm_interpret(profile: RepoProfile, *, model: str | None = None) -> None:
    """Enhance profile with LLM interpretation. Mutates profile in place.

    Runs three focused LLM calls:
    1. Architecture interpretation — patterns, module roles, layering
    2. Convention synthesis — actionable rules from statistical data
    3. Pattern enrichment — patterns that AST heuristics missed
    """
    try:
        from repox.llm import complete
    except Exception:
        return

    # Build a compact summary of the codebase for the LLM
    summary = _build_codebase_summary(profile)

    # 1. Architecture interpretation
    _interpret_architecture(profile, summary, model=model)

    # 2. Convention synthesis
    _interpret_conventions(profile, summary, model=model)

    # 3. Pattern enrichment
    _interpret_patterns(profile, summary, model=model)


def _extract_json(response: str) -> dict:
    """Extract JSON from an LLM response, handling markdown code blocks."""
    text = response
    if "```" in text:
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    return json.loads(text.strip())


def _build_codebase_summary(profile: RepoProfile) -> str:
    """Build a compact text summary of static extraction data for LLM."""
    lines = []
    ts = profile.tech_stack
    lines.append(f"Project: {profile.repo_name}")
    lines.append(f"Language: {ts.primary_language} {ts.language_version or ''}")
    if ts.framework:
        lines.append(f"Framework: {ts.framework}")
    if ts.dependencies:
        lines.append(f"Dependencies: {', '.join(d.name for d in ts.dependencies)}")

    # File structure from symbols
    files: dict[str, list[str]] = {}
    for s in profile.symbols.symbols:
        fp = s.file_path
        files.setdefault(fp, []).append(f"{s.kind.value} {s.name}")

    lines.append("\nFile structure:")
    for fp, symbols in sorted(files.items()):
        lines.append(f"  {fp}: {', '.join(symbols[:15])}")
        if len(symbols) > 15:
            lines.append(f"    ... and {len(symbols) - 15} more")

    # Import graph
    if profile.dependencies.import_edges:
        lines.append("\nImport graph:")
        for edge in profile.dependencies.import_edges:
            lines.append(f"  {edge.source_file} → {edge.target_file}")

    # Existing conventions (statistical)
    if profile.conventions.conventions:
        lines.append("\nStatistical conventions:")
        for c in profile.conventions.conventions:
            lines.append(f"  {c.category}: {c.rule}")

    # API surface
    if profile.api_surface.endpoints:
        lines.append(f"\nAPI ({profile.api_surface.framework}):")
        for ep in profile.api_surface.endpoints[:10]:
            lines.append(f"  {ep.method} {ep.path} → {ep.handler}")

    # Existing patterns
    if profile.design_patterns.patterns:
        lines.append("\nDetected patterns:")
        for p in profile.design_patterns.patterns:
            lines.append(f"  {p.pattern}: {p.participants} in {p.file_path}")

    # Hotspots
    if profile.hotspots.hotspots:
        lines.append("\nTop hotspots:")
        for h in profile.hotspots.hotspots[:5]:
            lines.append(f"  {h.file_path} (freq={h.change_frequency}, churn={h.churn})")

    # Custom rules
    if profile.custom_rules.rules:
        lines.append("\nTeam rules:")
        for r in profile.custom_rules.rules:
            lines.append(f"  [{r.source.value}]: {r.content[:200]}")

    return "\n".join(lines)


def _interpret_architecture(profile: RepoProfile, summary: str, *, model: str | None = None) -> None:
    """LLM interprets architecture from the static data."""
    from repox.llm import complete

    prompt = f"""Analyze this codebase and describe its architecture.

{summary}

Respond in this exact JSON format (no markdown, just JSON):
{{
  "pattern": "one of: layered, domain-driven, mvc, hexagonal, flat, monolith-modules, microservices, mcp-server, cli-tool, library, unknown",
  "confidence": 0.0-1.0,
  "description": "One sentence describing the architecture",
  "module_roles": [
    {{"path": "file_or_dir", "role": "what this module does in 5-10 words"}}
  ],
  "key_insight": "The most important thing a new developer should know about how this code is organized"
}}"""

    try:
        response = complete(prompt, model=model)
        data = _extract_json(response)

        # Update architecture if LLM found something better
        arch = profile.architecture
        llm_pattern = data.get("pattern", "unknown")

        # Map LLM pattern to our enum, keeping new ones as labels
        pattern_map = {
            "layered": ArchPattern.LAYERED,
            "domain-driven": ArchPattern.DOMAIN_DRIVEN,
            "mvc": ArchPattern.MVC,
            "hexagonal": ArchPattern.HEXAGONAL,
            "flat": ArchPattern.FLAT,
            "monolith-modules": ArchPattern.MONOLITH_MODULES,
        }

        if llm_pattern in pattern_map:
            if arch.pattern == ArchPattern.UNKNOWN or data.get("confidence", 0) > arch.confidence:
                arch.pattern = pattern_map[llm_pattern]
                arch.confidence = data.get("confidence", 0.7)
        elif llm_pattern != "unknown" and arch.pattern == ArchPattern.UNKNOWN:
            # Use FLAT as closest match but store the real description
            arch.pattern = ArchPattern.FLAT
            arch.confidence = data.get("confidence", 0.7)

        # Add module roles as directory labels
        # Store key insight as description on the first label only
        key_insight = data.get("key_insight")
        first_role = True
        for role in data.get("module_roles", []):
            path = role.get("path", "")
            desc = role.get("role", "")
            if path and desc:
                if not any(dl.path == path for dl in arch.directory_labels):
                    arch.directory_labels.append(DirectoryLabel(
                        path=path, label=desc,
                        description=key_insight if first_role else None,
                    ))
                    first_role = False

    except Exception:
        pass  # LLM failure shouldn't break the scan


def _interpret_conventions(profile: RepoProfile, summary: str, *, model: str | None = None) -> None:
    """LLM synthesizes actionable conventions from statistical data."""
    from repox.llm import complete

    prompt = f"""Based on this codebase analysis, identify the coding conventions a new developer must follow.
Go beyond statistics — identify the patterns that make code "fit" this project.

{summary}

Respond in this exact JSON format (no markdown, just JSON):
{{
  "conventions": [
    {{
      "category": "naming|error_handling|async|imports|architecture|testing|other",
      "rule": "Actionable rule in imperative form",
      "examples": ["example1", "example2"]
    }}
  ]
}}

Focus on:
- Conventions that are NOT obvious from language defaults
- Patterns specific to THIS project (not generic Python/JS advice)
- Rules that would prevent a new developer from writing code that doesn't fit
- Architecture-level conventions (where to put new code, how modules interact)

Limit to 10 most important conventions."""

    try:
        response = complete(prompt, model=model)
        data = _extract_json(response)

        # Add LLM conventions — tagged so they can be distinguished
        existing_rules = {c.rule.lower() for c in profile.conventions.conventions}
        for conv in data.get("conventions", []):
            rule = conv.get("rule", "")
            if rule and rule.lower() not in existing_rules:
                profile.conventions.conventions.append(Convention(
                    category=conv.get("category", "other"),
                    rule=rule,
                    confidence=0.7,  # LLM-derived
                    examples=conv.get("examples", []),
                ))

    except Exception:
        pass


def _interpret_patterns(profile: RepoProfile, summary: str, *, model: str | None = None) -> None:
    """LLM identifies design patterns that AST heuristics missed."""
    from repox.llm import complete

    prompt = f"""Identify design patterns used in this codebase that go beyond simple naming detection.

{summary}

Respond in this exact JSON format (no markdown, just JSON):
{{
  "patterns": [
    {{
      "pattern": "pattern name",
      "category": "creational|structural|behavioral|architectural",
      "file_path": "where it's used",
      "participants": ["class or function names involved"],
      "evidence": "Why you think this pattern is present (one sentence)"
    }}
  ]
}}

Look for:
- Facade, Adapter, Mediator, Pipeline patterns
- Dependency injection, configuration patterns
- Error handling strategies
- Module interaction patterns
Only include patterns you're confident about. Max 8 patterns."""

    try:
        response = complete(prompt, model=model)
        data = _extract_json(response)

        existing = {(p.pattern, p.file_path) for p in profile.design_patterns.patterns}
        for pat in data.get("patterns", []):
            name = pat.get("pattern", "")
            fp = pat.get("file_path", "")
            if name and (name, fp) not in existing:
                profile.design_patterns.patterns.append(DetectedPattern(
                    pattern=name,
                    category=pat.get("category", "architectural"),
                    file_path=fp,
                    participants=pat.get("participants", []),
                    confidence=0.7,  # LLM-derived
                ))

    except Exception:
        pass
