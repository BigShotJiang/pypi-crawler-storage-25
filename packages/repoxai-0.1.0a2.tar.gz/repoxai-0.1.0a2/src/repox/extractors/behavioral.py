"""Behavioral intelligence — WebSocket events, auth flows, state machines, middleware, jobs, API contracts."""

from __future__ import annotations

import re
from pathlib import Path

from repox.models import (
    APIContract,
    APISurface,
    AuthFlow,
    BehavioralIntelligence,
    Endpoint,
    MiddlewareEntry,
    StateMachine,
    SymbolGraph,
)


def extract_behavioral(
    repo_path: Path,
    source_files: list[Path],
    symbols: SymbolGraph,
    api_surface: APISurface,
) -> BehavioralIntelligence:
    """Extract behavioral patterns from the codebase."""
    result = BehavioralIntelligence()

    # 1. WebSocket/Socket.IO events → add to API surface
    _extract_websocket_events(repo_path, source_files, api_surface)

    # 2. Background jobs
    result.background_jobs = _extract_background_jobs(repo_path, source_files)

    # 3. Auth flows
    result.auth_flows = _extract_auth_flows(repo_path, source_files, symbols)

    # 4. State machines
    result.state_machines = _extract_state_machines(repo_path, source_files)

    # 5. Middleware chain
    result.middleware_chain = _extract_middleware_chain(repo_path, source_files)

    # 6. Cross-project API contracts
    result.api_contracts = _extract_api_contracts(repo_path, source_files, api_surface)

    return result


# ── 1. WebSocket/Socket.IO Event Detection ──────────────────────────────────


def _extract_websocket_events(
    repo_path: Path, source_files: list[Path], api_surface: APISurface
) -> None:
    """Detect Socket.IO and WebSocket event handlers, add to API surface."""
    seen: set[tuple[str, str]] = {(e.path, e.file_path) for e in api_surface.endpoints}

    def _add_ws(event: str, handler: str, file_path: str, line: int) -> None:
        path = f"ws:{event}"
        key = (path, file_path)
        if key not in seen:
            seen.add(key)
            api_surface.endpoints.append(Endpoint(
                method="WS", path=path, handler=handler,
                file_path=file_path, line=line,
            ))

    for fp in source_files:
        if fp.suffix not in (".py", ".js", ".ts", ".tsx"):
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))

        # Python Socket.IO: @sio.on("event"), @sio.event, sio.on("event", handler)
        for m in re.finditer(
            r'@\w+\.(?:on|event)\s*\(\s*["\'](\w+)["\']',
            text,
        ):
            event = m.group(1)
            func_match = re.search(r'(?:async\s+)?def\s+(\w+)', text[m.end():m.end() + 200])
            handler = func_match.group(1) if func_match else event
            line = text[:m.start()].count("\n") + 1
            _add_ws(event, handler, rel, line)

        # Python: async def connect/disconnect (common socketio pattern)
        if "socketio" in text.lower() or "sio" in text:
            for m in re.finditer(r'async\s+def\s+(connect|disconnect)\s*\(', text):
                handler = m.group(1)
                line = text[:m.start()].count("\n") + 1
                _add_ws(handler, handler, rel, line)

        # JS/TS: socket.on("event", handler), io.on("event")
        for m in re.finditer(
            r'(?:socket|io|sio)\s*\.on\s*\(\s*["\'](\w+)["\']',
            text,
        ):
            event = m.group(1)
            line = text[:m.start()].count("\n") + 1
            _add_ws(event, event, rel, line)

    if any(e.method == "WS" for e in api_surface.endpoints) and not api_surface.framework:
        api_surface.framework = "Socket.IO"


# ── 2. Background Job Detection ─────────────────────────────────────────────


def _extract_background_jobs(repo_path: Path, source_files: list[Path]) -> list[str]:
    """Detect scheduled/background jobs from source code."""
    jobs: list[str] = []

    for fp in source_files:
        if fp.suffix != ".py":
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))

        # APScheduler: scheduler.add_job(func, 'interval', ...)
        for m in re.finditer(r'\.add_job\s*\(\s*(\w[\w.]*)', text):
            jobs.append(f"APScheduler: {m.group(1)} ({rel})")

        # Celery: @shared_task, @app.task (already in API surface, but add to jobs list too)
        for m in re.finditer(r'@(?:shared_task|app\.task|celery\.task)\s*.*?\ndef\s+(\w+)', text, re.DOTALL):
            jobs.append(f"Celery: {m.group(1)} ({rel})")

        # Python cron-like: schedule.every(), BackgroundScheduler
        for m in re.finditer(r'schedule\.every\(\)\.\w+\.do\s*\(\s*(\w+)', text):
            jobs.append(f"Schedule: {m.group(1)} ({rel})")

        # Generic background patterns: async functions with "cleanup", "archive", "sync" in name
        for m in re.finditer(r'async\s+def\s+((?:cleanup|archive|sync|expire|purge|migrate|process)_\w+)', text):
            jobs.append(f"Background: {m.group(1)} ({rel})")

    # JS/TS: Bull/BullMQ, node-cron
    for fp in source_files:
        if fp.suffix not in (".js", ".ts"):
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))

        # Bull: new Queue("name"), queue.process(handler)
        for m in re.finditer(r'new\s+(?:Queue|Worker)\s*\(\s*["\'](\w+)["\']', text):
            jobs.append(f"Bull: {m.group(1)} ({rel})")

        # node-cron: cron.schedule("* * * * *", handler)
        for m in re.finditer(r'cron\.schedule\s*\(\s*["\']([^"\']+)["\']', text):
            jobs.append(f"Cron: {m.group(1)} ({rel})")

    return list(dict.fromkeys(jobs))  # deduplicate preserving order


# ── 3. Auth Flow Detection ──────────────────────────────────────────────────


def _extract_auth_flows(
    repo_path: Path, source_files: list[Path], symbols: SymbolGraph
) -> list[AuthFlow]:
    """Detect authentication patterns and what they protect."""
    auth_guards: list[tuple[str, str, str]] = []  # (func_name, file_path, method)
    # Cache file contents for the second pass (protected route detection)
    file_texts: dict[str, str] = {}  # rel_path → text

    for fp in source_files:
        if fp.suffix != ".py":
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))
        file_texts[rel] = text

        # FastAPI Depends patterns: Depends(get_current_user), Depends(require_auth)
        for m in re.finditer(r'Depends\s*\(\s*(\w+)', text):
            func = m.group(1)
            if any(kw in func.lower() for kw in ("auth", "user", "current", "token", "verify")):
                auth_guards.append((func, rel, "dependency_injection"))

        # JWT patterns
        if "jwt" in text.lower() or "jose" in text.lower():
            if "jwt.decode" in text or "jwt.get_unverified" in text:
                auth_guards.append(("JWT verification", rel, "jwt"))

        # Clerk
        if "clerk" in text.lower():
            auth_guards.append(("Clerk", rel, "clerk"))

        # Firebase Auth
        if "firebase_admin" in text and "auth.verify" in text:
            auth_guards.append(("Firebase Auth", rel, "firebase"))

        # Passport.js (JS/TS)
        if "passport" in text.lower() and fp.suffix in (".js", ".ts"):
            auth_guards.append(("Passport", rel, "passport"))

    if not auth_guards:
        return []

    # Find which route files use the guard (reuse cached text)
    guard_funcs = {g[0] for g in auth_guards}
    protected_routes: list[str] = []
    for rel, text in file_texts.items():
        if any(guard in text for guard in guard_funcs):
            if "route" in rel.lower() or "api" in rel.lower() or "endpoint" in rel.lower():
                protected_routes.append(rel)

    # Detect provider
    provider = None
    for _, _, method in auth_guards:
        if method == "clerk":
            provider = "Clerk"
        elif method == "firebase":
            provider = "Firebase"
        elif method == "passport":
            provider = "Passport"

    primary_guard = auth_guards[0]
    return [AuthFlow(
        method=primary_guard[2],
        provider=provider,
        guard_function=primary_guard[0],
        guard_file=primary_guard[1],
        protected_routes=protected_routes,
    )]


# ── 4. State Machine Detection ───────────────────────────────────────────────


def _extract_state_machines(repo_path: Path, source_files: list[Path]) -> list[StateMachine]:
    """Detect entity lifecycles from state/status enums and fields."""
    machines: list[StateMachine] = []

    for fp in source_files:
        if fp.suffix != ".py":
            continue
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))

        # Python string enums / constants that look like states
        # Pattern: STATES = ["waiting", "active", "completed"]
        for m in re.finditer(
            r'(?:STATES?|STATUS(?:ES)?|LIFECYCLE|TERMINAL_STATES?|VALID_STATES?)\s*=\s*[\[\{(](.*?)[\]\})]',
            text, re.DOTALL,
        ):
            states = re.findall(r'["\'](\w+)["\']', m.group(1))
            if len(states) >= 2:
                # Try to find entity name from class above or filename
                entity = _guess_entity_name(text, m.start(), fp)
                machines.append(StateMachine(
                    entity=entity,
                    states=states,
                    file_path=rel,
                ))

        # Enum class with state-like values
        for m in re.finditer(
            r'class\s+(\w*(?:State|Status)\w*)\s*\(.*?Enum.*?\):\s*\n((?:\s+\w+\s*=.*\n)+)',
            text,
        ):
            enum_name = m.group(1)
            values = re.findall(r'(\w+)\s*=\s*["\'](\w+)["\']', m.group(2))
            if values:
                states = [v[1] for v in values]
                entity = enum_name.replace("State", "").replace("Status", "") or _guess_entity_name(text, m.start(), fp)
                machines.append(StateMachine(
                    entity=entity,
                    states=states,
                    file_path=rel,
                    field_name="state",
                ))

        # state = Column(String, default="waiting") pattern
        for m in re.finditer(
            r'(\w+)\s*=\s*(?:Column|mapped_column)\s*\(.*?default\s*=\s*["\'](\w+)["\']',
            text,
        ):
            field = m.group(1)
            if field in ("state", "status"):
                default = m.group(2)
                entity = _guess_entity_name(text, m.start(), fp)
                # Check if there are state constants nearby
                if entity and not any(sm.entity == entity for sm in machines):
                    machines.append(StateMachine(
                        entity=entity,
                        states=[default],
                        file_path=rel,
                        field_name=field,
                    ))

    return machines


def _guess_entity_name(text: str, pos: int, fp: Path) -> str:
    """Guess entity name from nearest class definition or filename."""
    before = text[:pos]
    class_matches = list(re.finditer(r'class\s+(\w+)', before))
    if class_matches:
        return class_matches[-1].group(1)
    return fp.stem.replace("_", " ").title().replace(" ", "")


# ── 5. Middleware Chain Extraction ───────────────────────────────────────────


def _extract_middleware_chain(repo_path: Path, source_files: list[Path]) -> list[MiddlewareEntry]:
    """Detect middleware chain from web framework setup."""
    chain: list[MiddlewareEntry] = []

    for fp in source_files:
        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        rel = str(fp.relative_to(repo_path))

        # FastAPI/Starlette: app.add_middleware(CORSMiddleware, ...) or @app.middleware
        for m in re.finditer(r'\.add_middleware\s*\(\s*(\w+)', text):
            name = m.group(1)
            purpose = _guess_middleware_purpose(name)
            chain.append(MiddlewareEntry(name=name, file_path=rel, purpose=purpose))

        # Custom middleware classes: class FooMiddleware
        for m in re.finditer(r'class\s+(\w*Middleware\w*)\s*[:(]', text):
            name = m.group(1)
            purpose = _guess_middleware_purpose(name)
            if not any(mw.name == name for mw in chain):
                chain.append(MiddlewareEntry(name=name, file_path=rel, purpose=purpose))

        # Express: app.use(cors()), app.use(helmet()), app.use(morgan())
        for m in re.finditer(r'app\.use\s*\(\s*(\w+)\s*\(', text):
            name = m.group(1)
            purpose = _guess_middleware_purpose(name)
            chain.append(MiddlewareEntry(name=name, file_path=rel, purpose=purpose))

        # Next.js middleware.ts
        if fp.name == "middleware.ts" or fp.name == "middleware.js":
            chain.append(MiddlewareEntry(
                name="Next.js middleware",
                file_path=rel,
                purpose="request interception",
            ))

    return chain


def _guess_middleware_purpose(name: str) -> str:
    """Guess the purpose of middleware from its name."""
    lower = name.lower()
    if "cors" in lower:
        return "CORS"
    if "auth" in lower:
        return "authentication"
    if "log" in lower or "request" in lower:
        return "request logging"
    if "rate" in lower or "throttle" in lower:
        return "rate limiting"
    if "error" in lower or "exception" in lower:
        return "error handling"
    if "session" in lower:
        return "session management"
    if "helmet" in lower or "security" in lower:
        return "security headers"
    if "compress" in lower:
        return "response compression"
    if "json" in lower or "body" in lower or "parse" in lower:
        return "body parsing"
    if "static" in lower:
        return "static files"
    if "morgan" in lower:
        return "HTTP logging"
    return "middleware"


# ── 6. Cross-Project API Contract Mapping ────────────────────────────────────


def _extract_api_contracts(
    repo_path: Path, source_files: list[Path], api_surface: APISurface
) -> list[APIContract]:
    """Map frontend/mobile API calls to backend endpoints."""
    contracts: list[APIContract] = []

    # Build lookup of known backend endpoints
    backend_endpoints: dict[str, str] = {}  # "POST /users" → handler
    for ep in api_surface.endpoints:
        if ep.method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
            key = f"{ep.method} {ep.path}"
            backend_endpoints[key] = ep.handler

    # Scan frontend/mobile files for API calls
    for fp in source_files:
        if fp.suffix not in (".ts", ".tsx", ".js", ".jsx"):
            continue

        rel = str(fp.relative_to(repo_path))
        # Only look in frontend/mobile dirs
        if not any(d in rel for d in ("frontend/", "mobile/", "web/", "client/", "app/")):
            continue
        # Skip node_modules (shouldn't be here but safety check)
        if "node_modules" in rel:
            continue

        try:
            text = fp.read_text(errors="replace")
        except Exception:
            continue

        # Pattern: fetch("/api/path"), axios.get("/path"), api.post("/path")
        # Also: useMutation(... "/screenings" ...), useQuery(... "/users" ...)
        for m in re.finditer(
            r'(?:fetch|axios|api|client|httpClient)\s*\.\s*(get|post|put|patch|delete)\s*\(\s*["\'/`]([^"\'`]+)["\'/`]',
            text, re.IGNORECASE,
        ):
            method = m.group(1).upper()
            path = m.group(2)
            # Clean template literals
            path = re.sub(r'\$\{[^}]+\}', ':param', path)
            line = text[:m.start()].count("\n") + 1

            # Find enclosing function
            func = _find_enclosing_function(text, m.start())

            contracts.append(APIContract(
                consumer_file=rel,
                consumer_function=func or "anonymous",
                method=method,
                path=path,
                backend_handler=backend_endpoints.get(f"{method} {path}"),
            ))

        # Fetch with string URL: fetch(`/api/screenings/${code}`)
        for m in re.finditer(
            r'fetch\s*\(\s*[`"\']([^`"\']+)[`"\']',
            text,
        ):
            url = m.group(1)
            if url.startswith("/api") or url.startswith("http"):
                path = re.sub(r'\$\{[^}]+\}', ':param', url)
                path = re.sub(r'https?://[^/]+', '', path)
                func = _find_enclosing_function(text, m.start())
                contracts.append(APIContract(
                    consumer_file=rel,
                    consumer_function=func or "anonymous",
                    method="GET",  # default, can't always tell
                    path=path,
                ))

    # Deduplicate
    seen: set[str] = set()
    deduped: list[APIContract] = []
    for c in contracts:
        key = f"{c.consumer_file}:{c.method}:{c.path}"
        if key not in seen:
            seen.add(key)
            deduped.append(c)

    return deduped


def _find_enclosing_function(text: str, pos: int) -> str | None:
    """Find the nearest function/const definition before pos."""
    before = text[:pos]
    # JS/TS: function name(), const name = , export function name
    matches = list(re.finditer(
        r'(?:export\s+)?(?:async\s+)?(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=)',
        before,
    ))
    if matches:
        m = matches[-1]
        return m.group(1) or m.group(2)
    return None
