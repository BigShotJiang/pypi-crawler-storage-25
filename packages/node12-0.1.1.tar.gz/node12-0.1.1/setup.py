from setuptools import setup, find_packages

setup(
    name="node12",
    version="0.1.1",
    packages=find_packages(),
    description="Simple AIWD exam prep web templates packaged for Python.",
    author="Your Name",
    author_email="your.email@example.com",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
