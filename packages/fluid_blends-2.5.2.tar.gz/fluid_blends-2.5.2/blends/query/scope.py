from blends.models import (
    NId,
    SyntaxGraph,
)


def _is_self_ref(graph: SyntaxGraph, def_nid: NId, lookup_nid: NId) -> bool:
    nodes = graph.nodes
    return (
        nodes[def_nid].get("value_id") == lookup_nid
        or nodes[def_nid].get("variable_id") == lookup_nid
    )


def _is_valid_def(graph: SyntaxGraph, def_nid: NId, lookup_nid: NId) -> bool:
    return not _is_self_ref(graph, def_nid, lookup_nid) and int(def_nid) < int(lookup_nid)


def _dedup_by_subpath(graph: SyntaxGraph, definitions: list[NId]) -> list[NId]:
    seen_subpaths: set[NId | None] = set()
    result: list[NId] = []
    for def_nid in definitions:
        subpath = graph.subpath_index.get(def_nid)
        if subpath not in seen_subpaths:
            seen_subpaths.add(subpath)
            result.append(def_nid)
    return result


def _find_defs_in_scope(
    graph: SyntaxGraph, symbol: str, scope: NId, lookup_nid: NId
) -> list[NId] | None:
    symbol_defs = graph.symbol_index.get(symbol, {})
    if def_nids := symbol_defs.get(scope):
        valid_defs = [def_nid for def_nid in def_nids if _is_valid_def(graph, def_nid, lookup_nid)]
        if valid_defs:
            return _dedup_by_subpath(graph, valid_defs)

    for compound_key, scope_defs in graph.symbol_index.items():
        if (
            "," in compound_key
            and symbol in compound_key.split(",")
            and (def_nids := scope_defs.get(scope))
        ):
            valid_defs = [
                def_nid for def_nid in def_nids if _is_valid_def(graph, def_nid, lookup_nid)
            ]
            if valid_defs:
                return _dedup_by_subpath(graph, valid_defs)

    return None


def get_all_scope_definitions(graph: SyntaxGraph, lookup_nid: NId) -> list[NId]:
    symbol = graph.nodes[lookup_nid].get("symbol")
    current_scope: NId | None = graph.nodes[lookup_nid].get("symbol_scope")
    if not symbol or current_scope is None:
        return []
    while current_scope is not None:
        if definitions := _find_defs_in_scope(graph, symbol, current_scope, lookup_nid):
            return definitions
        current_scope = graph.scope_parent.get(current_scope)
    return []
