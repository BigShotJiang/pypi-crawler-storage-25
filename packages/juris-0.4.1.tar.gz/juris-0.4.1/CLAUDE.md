# CLAUDE.md

## Project Summary

**juris** is a CLI tool that collects and normalizes Swedish legal documents from 8 official sources into a unified, git-friendly format (JSON + Markdown). It supports 21 document types across Swedish and EU law, with incremental collection, async I/O, rate limiting, and PDF text extraction.

## Project Structure

```
src/juris/
├── cli.py              # Click CLI (collect, collect-type, collect-all, update, report, search, validate, status, stats, logs, man, --help-agent)
├── pipeline.py         # Reusable collection pipeline (collect_from_source, ProgressCallback)
├── models.py           # Pydantic models (Document, SearchResult, DocType, Source, Attachment)
├── report.py           # Collection coverage reports (generate, save, load, diff; .reports/ directory)
├── logging.py          # Collection run logging (JSONL per-document log + text file log)
├── search.py           # Document search (local + provider-based, search_local, search_all)
├── storage.py          # Dual-format file storage (JSON + Markdown with YAML frontmatter)
├── index.py            # Remote document index (update, save, load; .index/ directory)
├── state.py            # Incremental collection state tracking (.state/ directory)
├── utils.py            # Shared utilities (rate limiting, text extraction, ID building)
├── pdf.py              # PDF text extraction via pymupdf
└── collectors/         # Source-specific async collectors (auto-discovered)
    ├── __init__.py     # Auto-discovery + backward-compatible re-exports
    ├── base.py         # BaseCollector ABC, registry, __init_subclass__ auto-registration
    ├── riksdagen.py    # Riksdagen JSON API
    ├── regeringen.py   # Regeringen.se web scraper
    ├── domstol.py      # Court decisions REST API
    ├── jo_jk.py        # JO/JK ombudsman decisions
    ├── lagrummet.py    # Agency regulations (AFS, HSLF-FS)
    ├── eurlex.py       # EUR-Lex SPARQL
    ├── curia.py        # CJEU SPARQL
    ├── hudoc.py        # ECtHR JSON API
    └── _cellar.py      # EU CELLAR metadata helper
tests/
├── conftest.py         # Pytest fixtures and helpers
├── test_e2e.py         # End-to-end tests (@e2e marker, hits live APIs)
├── test_parsers.py     # Parser validation tests
├── test_registry.py    # Collector auto-discovery and registry tests
├── test_retry.py       # Retry logic tests
├── test_search.py      # Search functionality tests
├── test_validate.py    # Document validation tests
├── test_logging.py     # Collection logging tests
├── test_report.py      # Report generation, persistence, diff, and CLI tests
├── test_help_agent.py  # --help-agent flag tests
├── test_debug_agent.py # --debug-agent flag tests
├── test_index.py       # Remote index and update command tests
├── test_man.py         # Man command CLI tests
└── test_storage.py     # Storage roundtrip fidelity tests
docs/
├── overview.md         # Project overview and use cases
├── architecture.md     # System architecture and data flow
├── collectors.md       # Collector framework and auto-discovery
├── document-model.md   # Document model, enums, and validation
├── storage-format.md   # Storage format, directory layout, and state
├── data-sources.md     # Data source reference (all 8 sources)
└── parsing-rules.md    # Parsing pipeline documentation
man/                    # Manual pages (.md Markdown files) for CLI commands
Makefile                # Dev commands (install, lint, typecheck, test)
scripts/
├── release.sh          # Semantic version bump + tag creation
├── update-version.sh   # Updates version in pyproject.toml
└── generate-changelog.sh # Changelog generation from conventional commits
website/                # GitHub Pages website (React + Vite + Tailwind)
├── scripts/
│   └── extract-data.ts # Extracts data from Python source → sourceData.ts
├── src/
│   ├── components/     # React components (Navbar, Hero, Terminal, ManPages, Documentation, etc.)
│   └── data/
│       └── sourceData.ts # AUTO-GENERATED from Python source
├── package.json
└── vite.config.ts
.github/workflows/
├── ci.yml              # Lint, typecheck, test on push/PR to main
├── release.yml         # Build + publish to PyPI on tag push
├── version-bump.yml    # Manual workflow_dispatch to bump version
├── deploy-website.yml  # Build + deploy GitHub Pages website
└── e2e-*.yml           # Per-document-type E2E test workflows
```

## Tech Stack

- **Python 3.11+** with async/await
- **httpx** — async HTTP client
- **pydantic** — data validation and models
- **beautifulsoup4 + lxml** — HTML/XML parsing
- **click** — CLI framework
- **pymupdf** — PDF text extraction
- **pyyaml** — YAML frontmatter

## Development

```bash
make install                   # Create .venv and install with dev dependencies
make lint                      # Lint + format check (matches CI)
make format                    # Auto-format code
make typecheck                 # Type check (strict mode)
make test                      # Run unit tests
make test-e2e                  # Run e2e tests (live APIs, slow)
```

Or manually:

```bash
python3 -m venv .venv
.venv/bin/pip install -e ".[dev]"
.venv/bin/python -m ruff check src/
.venv/bin/python -m ruff format --check src/
.venv/bin/mypy src/
.venv/bin/pytest tests/ --ignore=tests/test_e2e.py
```

### Working in a worktree

Git worktrees (paths containing `/worktrees/`) share no `.venv` — they only have the source tree. Use the main repo's venv with `PYTHONPATH=src` so tools pick up the worktree's modified source instead of the installed package:

```bash
# From the worktree directory:
REPO=/Users/niclas/Source/personal/juris
VENV=$REPO/.venv/bin

PYTHONPATH=src $VENV/python -m pytest tests/ --ignore=tests/test_e2e.py   # test
PYTHONPATH=src $VENV/python -m ruff check src/                            # lint
PYTHONPATH=src $VENV/python -m ruff format --check src/                   # format check
PYTHONPATH=src $VENV/python -m mypy src/                                  # typecheck
```

**Do not** run `make` targets from a worktree — they reference `.venv/bin/python` which doesn't exist there.

- Line length: 100
- Ruff rules: E, F, I, W
- MyPy: strict mode, Python 3.11+
- pytest-asyncio with `asyncio_mode = auto`

## Commit and PR Conventions

- Use **conventional commits** for all commit messages (e.g., `feat:`, `fix:`, `refactor:`, `docs:`, `test:`)
- PR titles follow conventional commit style as well

## Adding a New Collector

Collectors are auto-discovered via `BaseCollector.__init_subclass__`. To add one:

1. Add the source name to the `Source` enum in `models.py`
2. Create `src/juris/collectors/mysource.py`:
   ```python
   class MyCollector(BaseCollector):
       source = Source.MY_SOURCE
       supported_doc_types = [DocType.SOME_TYPE]
       preferred_for = [DocType.SOME_TYPE]  # optional — wins when multiple providers exist

       async def collect(self, doc_type, *, session=None, since=None, until=None,
                         limit=None, skip_content=False) -> AsyncIterator[Document]: ...
       async def get_document(self, source_id: str) -> Document | None: ...
   ```
3. No changes needed in `cli.py`, `__init__.py`, or any registry file.

## Releasing

Releases are automated via GitHub Actions:

1. **Via GitHub UI**: Run the "Version Bump" workflow (`version-bump.yml`). The bump type can be left empty to auto-detect from conventional commits, or explicitly set to patch/minor/major. This creates a git tag which triggers the release pipeline.
2. **Via CLI**: Run `./scripts/release.sh [patch|minor|major]` from the main branch. Without an argument, the bump type is inferred from conventional commits.

The release pipeline (`release.yml`) then:
- Updates the version in `pyproject.toml`
- Generates changelog from conventional commits
- Publishes the package to PyPI
- Creates a GitHub Release with release notes

**Required configuration**:
- **PyPI OIDC trusted publisher** must be configured on PyPI for the `pypi-registry` GitHub environment (workflow: `release.yml`, job: `publish-pypi`). No API token needed.
- `RELEASE_TOKEN` — a GitHub Personal Access Token (PAT) with `contents: write` and `workflows` permissions, configured as a repository secret. Required for pushing tags that trigger release workflows and for pushing to protected branches.

## Important Notes

- When the project structure changes (new files, directories, or significant reorganization), update this CLAUDE.md file to reflect the changes.
- Output format: documents are stored as `data/{doc_type}/{session}/{id}.{json|md}`
- Collection state is tracked in `.state/{source}_{doc_type}.json`
- Coverage reports are stored in `.reports/{timestamp}.json` with an index at `.reports/index.json`
- Remote document indexes are stored in `.index/{source}_{doc_type}.json`
