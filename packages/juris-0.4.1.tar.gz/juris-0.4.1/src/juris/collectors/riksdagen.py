"""Riksdagen API collector (data.riksdagen.se)."""

from __future__ import annotations

import logging
import re
from collections.abc import AsyncIterator
from datetime import UTC, date, datetime
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import httpx

from juris.collectors.base import BaseCollector
from juris.models import Attachment, DocType, Document, Source
from juris.utils import build_doc_id, html_to_text

logger = logging.getLogger(__name__)

BASE_URL = "https://data.riksdagen.se"

# Maximum results the Riksdagen API will paginate through (~500 pages × 20).
# Beyond this the API simply stops returning @nasta_sida links.
_PAGINATION_LIMIT = 10_000

# Swedish Riksdag standing committees — maps prefix to full Swedish name
_COMMITTEE_MAP: dict[str, str] = {
    "AU": "Arbetsmarknadsutskottet",
    "CU": "Civilutskottet",
    "FiU": "Finansutskottet",
    "FöU": "Försvarsutskottet",
    "JuU": "Justitieutskottet",
    "KU": "Konstitutionsutskottet",
    "KrU": "Kulturutskottet",
    "MJU": "Miljö- och jordbruksutskottet",
    "NU": "Näringsutskottet",
    "SfU": "Socialförsäkringsutskottet",
    "SkU": "Skatteutskottet",
    "SoU": "Socialutskottet",
    "TU": "Trafikutskottet",
    "UbU": "Utbildningsutskottet",
    "UU": "Utrikesutskottet",
}


def _extract_committee(designation: str) -> str | None:
    """Extract committee name from a BET designation like 'JuU15'."""
    m = re.match(r"^([A-ZÅÄÖ][a-zåäö]*[A-Z][a-zåäö]?)", designation)
    if m:
        return _COMMITTEE_MAP.get(m.group(1))
    return None


# Map our DocType to Riksdagen's doktyp parameter
_DOCTYPE_MAP: dict[DocType, str] = {
    DocType.PROP: "prop",
    DocType.SOU: "sou",
    DocType.MOT: "mot",
    DocType.BET: "bet",
    DocType.DIR: "dir",
    DocType.SKR: "skr",
    DocType.SFS: "sfs",
}

# Doc types where the API requires a subtyp filter.
# SKR documents are now stored under doktyp=prop with subtyp=skr;
# adding subtyp=prop for PROP prevents SKR items leaking into PROP results.
_SUBTYPE_MAP: dict[DocType, str] = {
    DocType.SKR: "skr",
    DocType.PROP: "prop",
}


class RiksdagenCollector(BaseCollector):
    """Collects documents from the Riksdagen open data API."""

    source = Source.RIKSDAGEN
    supported_doc_types = list(_DOCTYPE_MAP.keys())
    preferred_for = [DocType.PROP, DocType.SOU, DocType.DIR, DocType.SKR]

    def __init__(self, rate_limit: float = 0.5) -> None:
        super().__init__(rate_limit=rate_limit, base_url=BASE_URL)
        self._last_fetch_error: str | None = None

    async def _fetch_json(self, url: str) -> dict[str, Any] | None:
        """Fetch a URL and return parsed JSON, or None on error."""
        try:
            resp = await self._fetch_with_retry("GET", url)
            result: dict[str, Any] = resp.json()
            return result
        except httpx.HTTPStatusError as e:
            self._last_fetch_error = f"HTTP {e.response.status_code}"
            logger.warning("Failed to fetch %s: HTTP %d", url, e.response.status_code)
            return None
        except httpx.HTTPError as e:
            detail = f"{type(e).__name__}: {e}" if str(e) else type(e).__name__
            self._last_fetch_error = detail
            logger.warning("Failed to fetch %s: %s", url, detail)
            return None
        except ValueError as e:
            self._last_fetch_error = f"JSON parse error: {e}"
            logger.warning("Failed to parse JSON from %s: %s", url, e)
            return None

    async def _fetch_document_html(self, dok_id: str) -> str | None:
        """Fetch the full HTML content for a document."""
        data = await self._fetch_json(f"{BASE_URL}/dokument/{dok_id}.json")
        if not data:
            return None
        doc_data = data.get("dokumentstatus", {}).get("dokument", {})
        html: str | None = doc_data.get("html")
        return html

    @staticmethod
    def _extract_page(url: str) -> int | None:
        """Extract the current page number from a Riksdagen API URL.

        The API uses ``p`` as the actual pagination parameter (increments per page),
        while ``sida`` remains fixed at the starting page. For the initial URL
        (which has ``sida`` but no ``p``), we fall back to ``sida``.
        """
        params = parse_qs(urlparse(url).query)
        # Prefer ``p`` — this is the real pagination cursor in @nasta_sida URLs
        p = params.get("p")
        if p:
            try:
                return int(p[0])
            except (ValueError, IndexError):
                pass
        # Fall back to ``sida`` for the initial request URL
        sida = params.get("sida")
        if sida:
            try:
                return int(sida[0])
            except (ValueError, IndexError):
                pass
        return None

    @staticmethod
    def _url_with_page(url: str, page: int) -> str | None:
        """Return a copy of *url* with the ``p`` query parameter set to *page*."""
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        if "p" not in params:
            return None
        params["p"] = [str(page)]
        return urlunparse(parsed._replace(query=urlencode(params, doseq=True)))

    async def _verify_pagination_end(
        self, failed_url: str, prev_url: str | None, count: int
    ) -> None:
        """Check adjacent pages to determine if a fetch failure is the natural end.

        After a page fetch fails during pagination, this method re-fetches the
        previous page (to confirm connectivity) and tries the next page (to
        confirm it also fails).  The results are logged so the user can see
        whether this is the normal end of results or a possible ban/rate-limit.
        """
        parsed = urlparse(failed_url)
        params = parse_qs(parsed.query)
        page_strs = params.get("p")
        if not page_strs:
            # No pagination parameter — can't verify
            return
        current_page = int(page_strs[0])

        logger.info("Verifying end of results (failed at page %d)…", current_page)

        # Check previous page
        check_prev = prev_url or self._url_with_page(failed_url, current_page - 1)
        prev_ok = False
        if check_prev and current_page > 1:
            prev_data = await self._fetch_json(check_prev)
            prev_ok = bool(prev_data and prev_data.get("dokumentlista", {}).get("dokument"))

        # Check next page
        next_url = self._url_with_page(failed_url, current_page + 1)
        next_ok = False
        if next_url:
            next_data = await self._fetch_json(next_url)
            next_ok = bool(next_data and next_data.get("dokumentlista", {}).get("dokument"))

        if prev_ok and not next_ok:
            logger.info(
                "Confirmed end of results at page %d (%d documents). "
                "Previous page OK, next page also has no results.",
                current_page,
                count,
            )
        elif not prev_ok:
            logger.warning(
                "Possible rate limit or block: previous page (page %d) also failed. "
                "Results may be incomplete (%d documents collected from %d pages).",
                current_page - 1,
                count,
                current_page - 1,
            )
        else:
            # prev_ok and next_ok — the failed page is an isolated gap
            logger.warning(
                "Unexpected gap at page %d (previous and next pages both OK). "
                "%d documents collected — results may have gaps.",
                current_page,
                count,
            )

    def _parse_document(
        self,
        item: dict[str, Any],
        full_html: str | None = None,
        *,
        expected_doc_type: DocType | None = None,
    ) -> Document:
        """Convert a Riksdagen API document item to our Document model."""
        dok_id = item["dok_id"]

        if expected_doc_type is not None:
            doc_type = expected_doc_type
        else:
            # Reverse lookup DocType from Riksdagen's type string
            doc_type_str = item.get("doktyp", "").lower()
            doc_type = DocType.PROP  # default
            for dt, rk_type in _DOCTYPE_MAP.items():
                if rk_type == doc_type_str:
                    doc_type = dt
                    break

        designation = item.get("beteckning", item.get("nummer", ""))
        session = item.get("rm") or None

        # SFS beteckning is "YYYY:NNN" — split into year (session) and number
        if doc_type == DocType.SFS:
            m = re.match(r"^(\d{4}):(.+)$", designation)
            if m:
                session = m.group(1)
                designation = m.group(2)

        doc_id = build_doc_id(doc_type, designation, session)

        # Parse date — format is "YYYY-MM-DD" or "YYYY-MM-DD HH:MM:SS"
        date_str = item.get("datum", "")
        doc_date = date.fromisoformat(date_str[:10]) if date_str else date.today()

        # Text extraction
        text = None
        html = full_html
        if html:
            text = html_to_text(html)

        # Attachments
        attachments: list[Attachment] = []
        filbilaga = item.get("filbilaga")
        if filbilaga and isinstance(filbilaga, dict):
            fils = filbilaga.get("fil", [])
            if isinstance(fils, dict):
                fils = [fils]
            for fil in fils:
                if isinstance(fil, dict) and fil.get("url"):
                    attachments.append(
                        Attachment(
                            filename=fil.get("namn", ""),
                            url=fil["url"],
                            mime_type=fil.get("typ"),
                            size_bytes=int(fil["storlek"]) if fil.get("storlek") else None,
                        )
                    )

        # Build a summary from undertitel or first substantial text paragraph
        summary = item.get("undertitel") or None
        if not summary and text:
            for paragraph in re.split(r"\n{2,}", text):
                stripped = paragraph.strip()
                # Skip short lines (headings, metadata) and the title itself
                if len(stripped) > 60 and stripped != item.get("titel", ""):
                    summary = stripped[:500]
                    break

        # Extract committee name for committee reports (betänkanden)
        committee = _extract_committee(designation) if doc_type == DocType.BET else None

        return Document(
            doc_id=doc_id,
            doc_type=doc_type,
            designation=designation,
            session=session,
            title=item.get("titel", ""),
            summary=summary,
            text=text,
            html=html,
            date=doc_date,
            department=item.get("organ") or None,
            committee=committee,
            source=Source.RIKSDAGEN,
            source_id=dok_id,
            source_url=f"{BASE_URL}/dokument/{dok_id}",
            fetched_at=datetime.now(tz=UTC),
            attachments=attachments,
        )

    async def _probe_total(self, doc_type: DocType) -> int | None:
        """Fetch the API-reported total document count for *doc_type*."""
        rk_type = _DOCTYPE_MAP[doc_type]
        if doc_type == DocType.SKR:
            rk_type = "prop"
        params: dict[str, str] = {
            "doktyp": rk_type,
            "utformat": "json",
            "antal": "1",
            "sida": "1",
        }
        if doc_type in _SUBTYPE_MAP:
            params["subtyp"] = _SUBTYPE_MAP[doc_type]
        url = f"{BASE_URL}/dokumentlista/?" + urlencode(params)
        data = await self._fetch_json(url)
        if not data:
            return None
        traffar = data.get("dokumentlista", {}).get("@traffar")
        if traffar:
            try:
                return int(traffar)
            except (ValueError, TypeError):
                pass
        return None

    async def is_available(self) -> bool:
        """Probe the Riksdagen API with a single tiny request.

        ``data.riksdagen.se`` is known to occasionally accept TLS connections
        but reset the response mid-stream (``ReadError``).  When that happens
        every collect call hangs through retries — this fast probe lets the
        caller skip the source instead.
        """
        url = f"{BASE_URL}/dokumentlista/?doktyp=prop&utformat=json&antal=1&sida=1&subtyp=prop"
        try:
            client = await self._get_client()
            resp = await client.get(url, timeout=10.0)
        except (httpx.HTTPError, OSError):
            return False
        return resp.status_code == 200

    async def collect(
        self,
        doc_type: DocType,
        *,
        session: str | None = None,
        since: date | None = None,
        until: date | None = None,
        limit: int | None = None,
        skip_content: bool = False,
        offset: int = 0,
    ) -> AsyncIterator[Document]:
        """Yield documents from the Riksdagen API.

        When the total number of documents exceeds the API's pagination limit
        (~10 000) and no date/session filters are applied, automatically splits
        the query by calendar year to retrieve all results.
        """
        if doc_type not in _DOCTYPE_MAP:
            raise ValueError(f"Unsupported doc type for Riksdagen: {doc_type}")

        # Only consider year splitting when no filters narrow the query
        if session is None and since is None and until is None and offset == 0 and limit is None:
            total = await self._probe_total(doc_type)
            if total is not None and total > _PAGINATION_LIMIT:
                self.total_available = total
                logger.info(
                    "%s: %d documents exceeds pagination limit — splitting by year",
                    doc_type.value,
                    total,
                )
                count = 0
                current_year = date.today().year
                consecutive_empty = 0

                for year in range(current_year, 1900, -1):
                    year_since = date(year, 1, 1)
                    year_until = date(year, 12, 31)
                    year_limit = (limit - count) if limit else None
                    year_count = 0

                    async for doc in self._collect_pages(
                        doc_type,
                        since=year_since,
                        until=year_until,
                        limit=year_limit,
                        skip_content=skip_content,
                    ):
                        yield doc
                        count += 1
                        year_count += 1
                        if limit and count >= limit:
                            self.total_available = total
                            return

                    if year_count > 0:
                        consecutive_empty = 0
                        logger.debug("%s year %d: %d documents", doc_type.value, year, year_count)
                    else:
                        consecutive_empty += 1
                        if consecutive_empty >= 10:
                            logger.debug(
                                "%s: %d consecutive empty years — stopping at %d",
                                doc_type.value,
                                consecutive_empty,
                                year,
                            )
                            break

                self.total_available = total
                return

        # Delegate to page-based collection
        async for doc in self._collect_pages(
            doc_type,
            session=session,
            since=since,
            until=until,
            limit=limit,
            skip_content=skip_content,
            offset=offset,
        ):
            yield doc

    async def _collect_pages(
        self,
        doc_type: DocType,
        *,
        session: str | None = None,
        since: date | None = None,
        until: date | None = None,
        limit: int | None = None,
        skip_content: bool = False,
        offset: int = 0,
    ) -> AsyncIterator[Document]:
        """Yield documents using page-based pagination."""
        if doc_type not in _DOCTYPE_MAP:
            raise ValueError(f"Unsupported doc type for Riksdagen: {doc_type}")

        rk_type = _DOCTYPE_MAP[doc_type]
        # SKR is now filed under doktyp=prop&subtyp=skr in the Riksdagen API
        if doc_type == DocType.SKR:
            rk_type = "prop"
        page_size = 20
        count = 0
        items_to_skip = offset % page_size

        # Build initial URL
        start_sida = offset // page_size + 1
        params: dict[str, str] = {
            "doktyp": rk_type,
            "utformat": "json",
            "antal": str(page_size),
            "sida": str(start_sida),
            "sort": "datum",
            "sortorder": "desc",
        }
        if doc_type in _SUBTYPE_MAP:
            params["subtyp"] = _SUBTYPE_MAP[doc_type]
        if session:
            if doc_type == DocType.SFS:
                # SFS uses year, not riksmöte — map to date range
                params["from"] = f"{session}-01-01"
                params["tom"] = f"{session}-12-31"
            else:
                params["rm"] = session
        if since:
            params["from"] = since.isoformat()
        if until:
            params["tom"] = until.isoformat()

        url = f"{BASE_URL}/dokumentlista/?" + "&".join(f"{k}={v}" for k, v in params.items())
        prev_url: str | None = None
        first_page = True  # True until we follow the first @nasta_sida link

        while url:
            data = await self._fetch_json(url)
            if not data:
                if count > 0:
                    await self._verify_pagination_end(url, prev_url, count)
                else:
                    logger.warning(
                        "Failed to fetch initial page: %s",
                        self._last_fetch_error or "unknown error",
                    )
                break

            doc_list = data.get("dokumentlista", {})

            # Capture API-reported total on first page
            if self.total_available is None:
                traffar = doc_list.get("@traffar")
                if traffar:
                    try:
                        self.total_available = int(traffar)
                    except (ValueError, TypeError):
                        pass

            documents = doc_list.get("dokument", [])

            if not documents:
                break

            # Handle single document (API returns dict instead of list)
            if isinstance(documents, dict):
                documents = [documents]

            for item in documents:
                if limit and count >= limit:
                    return

                # Skip items on the first page when resuming from offset
                if items_to_skip > 0:
                    items_to_skip -= 1
                    continue

                dok_id = item.get("dok_id", "")
                logger.debug("Fetching %s: %s", dok_id, item.get("titel", "")[:60])

                # Fetch full HTML content (skip when only metadata is wanted)
                html = None if skip_content else await self._fetch_document_html(dok_id)
                doc = self._parse_document(item, full_html=html, expected_doc_type=doc_type)
                yield doc
                count += 1

            # Follow pagination — detect API cycling bug where @nasta_sida
            # points to the same or earlier page, creating an infinite loop.
            next_url = doc_list.get("@nasta_sida")
            if next_url and (not limit or count < limit):
                # Skip loop detection on the first page transition when resuming
                # with sida > 1: the initial URL uses ``sida`` for page numbering
                # while @nasta_sida uses ``p``, so comparing them cross-scheme
                # falsely triggers loop detection (e.g. sida=31 vs p=2).
                if first_page and start_sida > 1:
                    first_page = False
                else:
                    current_page = self._extract_page(url)
                    next_page = self._extract_page(next_url)
                    if (
                        current_page is not None
                        and next_page is not None
                        and next_page <= current_page
                    ):
                        logger.info(
                            "Pagination loop detected: page %d -> %d. Stopping after %d documents.",
                            current_page,
                            next_page,
                            count,
                        )
                        break
                prev_url = url
                url = next_url
            else:
                break

    async def get_document(self, source_id: str) -> Document | None:
        """Fetch a single document by its Riksdagen dok_id."""
        data = await self._fetch_json(f"{BASE_URL}/dokumentstatus/{source_id}.json")
        if not data:
            return None

        doc_data = data.get("dokumentstatus", {}).get("dokument", {})
        if not doc_data:
            return None

        html = doc_data.get("html")
        return self._parse_document(doc_data, full_html=html)
