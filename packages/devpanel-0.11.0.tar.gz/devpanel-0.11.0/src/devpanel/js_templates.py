"""Shared JS template constants for selector resolution and element queries.

Used by cdp_remote.py (ADB/CDP path) and safari.py (safarictl HTTP path).
Each constant is a raw JS expression with %%PARAM%% placeholders that callers
substitute via str.replace() before evaluation.
"""

# Resolves text= selectors. Filters by visibility, deduplicates wrappers,
# sorts by smallest bbox. %%TEXT%% = JSON-stringified search text.
RESOLVE_TEXT_JS = r"""
(function(){
  var t=%%TEXT%%;
  var candidates=[].slice.call(document.querySelectorAll('*')).filter(function(el){
    if(!el.offsetParent&&el.tagName!=='BODY')return false;
    var r=el.getBoundingClientRect();
    if(r.width===0||r.height===0)return false;
    return (el.textContent||'').trim()===t||
      el.getAttribute('aria-label')===t||
      el.getAttribute('value')===t;
  });
  var leaves=candidates.filter(function(el){
    return!candidates.some(function(c){return c!==el&&el.contains(c);});
  });
  leaves.sort(function(a,b){
    var ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
    return ra.width*ra.height-rb.width*rb.height;
  });
  return leaves[0]||null;
})()
"""

# Resolves label= selectors. Finds <label> by text, then its associated input,
# falling back to [aria-label]. %%LABEL%% = JSON-stringified label text.
RESOLVE_LABEL_JS = r"""
(function(){
  var lbl=%%LABEL%%;
  var labels=document.querySelectorAll('label');
  for(var i=0;i<labels.length;i++){
    if((labels[i].textContent||'').trim()===lbl){
      var el=document.getElementById(labels[i].htmlFor)||labels[i].control;
      if(el)return el;
    }
  }
  return document.querySelector('[aria-label='+JSON.stringify(lbl)+']');
})()
"""

# Resolves role= selectors using JS-side implicit role mapping (no AX tree).
# Matches both explicit [role] attributes and semantic HTML tags.
# %%ROLE%% = JSON-stringified role, %%NAME%% = JSON-stringified name or null.
RESOLVE_ROLE_JS = r"""
(function(){
  var role=%%ROLE%%,name=%%NAME%%;
  var IR={A:'link',BUTTON:'button',INPUT:'textbox',TEXTAREA:'textbox',
    SELECT:'combobox',DETAILS:'group',SUMMARY:'button',DIALOG:'dialog',MENU:'menu'};
  var INPUT_R={checkbox:'checkbox',radio:'radio',range:'slider',
    search:'searchbox',submit:'button',reset:'button',image:'button',file:'button'};
  var LAND={MAIN:'main',NAV:'navigation',HEADER:'banner',FOOTER:'contentinfo',
    ASIDE:'complementary',SECTION:'section',ARTICLE:'article',FORM:'form'};
  function gr(el){
    var e=el.getAttribute('role');if(e)return e;var t=el.tagName;
    if(LAND[t])return LAND[t];if(t==='INPUT')return INPUT_R[el.type]||'textbox';
    if(IR[t])return IR[t];if(t.match(/^H[1-6]$/))return'heading';
    if(t==='IMG')return'img';return'';
  }
  var els=[].slice.call(document.querySelectorAll('*')).filter(function(el){return gr(el)===role;});
  if(name)els=els.filter(function(el){return(el.textContent||'').trim()===name||el.getAttribute('aria-label')===name;});
  return els[0]||null;
})()
"""

# Gets element bounding rect for screenshot clipping.
# %%SELECTOR%% = JSON-stringified CSS selector.
ELEMENT_BBOX_JS = r"""
(function(){
  var el=document.querySelector(%%SELECTOR%%);
  if(!el)return null;
  var r=el.getBoundingClientRect();
  return {x:r.x, y:r.y, width:r.width, height:r.height};
})()
"""
