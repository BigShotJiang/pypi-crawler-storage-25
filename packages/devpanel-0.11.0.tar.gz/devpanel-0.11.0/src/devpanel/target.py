"""Target backend adapter — unifies Safari/CDP/panel dispatch in MCP tools.

Three implementations mirror the extension-side Target interface (target.ts):
  SafariBackend  — iOS device via safarictl HTTP API
  CdpBackend     — ADB phone via daemon CDP WebSocket
  PanelBackend   — Chrome tab via panel commands.ts dispatcher
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from devpanel.ax_tree import format_ax_tree
from devpanel.cdp_remote import (
    adb_screenshot,
    cdp_resolve_selector,
    cdp_screenshot,
    cdp_settle_and_tree,
)
from devpanel.safari import (
    safari_click,
    safari_console,
    safari_eval,
    safari_network,
    safari_screenshot,
    safari_settle_and_tree,
    safari_tree,
    safari_type,
    safari_viewport,
)

if TYPE_CHECKING:
    from devpanel.session import PtySession


# ---------------------------------------------------------------------------
# Result types and exceptions
# ---------------------------------------------------------------------------


@dataclass
class MutationResult:
    """Normalized result from click/type — tree + optional network delta."""

    url: str
    tree: str
    node_count: int
    settle_ms: int
    network: list[dict] | None = None


class NotSupported(Exception):
    """Target does not support this operation."""


class ElementNotFound(Exception):
    """Selector resolved to no element."""


class TargetError(Exception):
    """Generic target-side error."""


def _mutation_from_settle(r: dict) -> MutationResult:
    return MutationResult(
        url=r["url"],
        tree=r["tree"],
        node_count=r["nodeCount"],
        settle_ms=r["settleMs"],
    )


# ---------------------------------------------------------------------------
# Safari backend
# ---------------------------------------------------------------------------

_SAFARI_HEADER = (
    "DevPanel: controlling an iOS Safari page via safarictl USB bridge.\n\n"
    "This is a real iPhone — touch targets are small, layouts are mobile. "
    "viewport() is read-only and includes iOS-specific data: safe area insets "
    "(notch, home indicator) and keyboard state (visualViewport). "
    "tree() returns a DOM structure with ARIA attributes (no accessibility tree in WebKit). "
    "click/type use JavaScript workarounds (no Input domain in WebKit). "
    "js() IS available — evaluates directly on the iOS device. "
    "issues and watch tools are not available.\n\n"
)


class SafariBackend:
    type = "safari"
    instructions_header = _SAFARI_HEADER

    def __init__(self, pty: PtySession) -> None:
        self._pty = pty

    @property
    def _url(self) -> str:
        return self._pty.safari_url

    async def tree(self, depth: int = 4) -> tuple[str, int]:
        text, count = await safari_tree(self._url, depth)
        return text or "(empty tree)", count

    async def screenshot(self, selector: str | None = None) -> tuple[str, str | None]:
        data = await safari_screenshot(self._url)
        return data, "iOS Safari screenshot via Page.snapshotPage"

    async def device_screenshot(self) -> tuple[str, str]:
        data = await safari_screenshot(self._url)
        return data, "iOS device screenshot via Page.snapshotPage"

    async def click(self, selector: str) -> MutationResult:
        try:
            await safari_click(self._url, selector)
        except ValueError:
            raise ElementNotFound(selector) from None
        return _mutation_from_settle(await safari_settle_and_tree(self._url))

    async def type_text(
        self, selector: str, text: str, press_enter: bool = False
    ) -> MutationResult:
        try:
            await safari_type(self._url, selector, text, press_enter)
        except ValueError:
            raise ElementNotFound(selector) from None
        return _mutation_from_settle(await safari_settle_and_tree(self._url))

    async def navigate(self, url: str | None = None, action: str | None = None) -> str:
        if url:
            await safari_eval(self._url, f"location.href = {json.dumps(url)}")
            note = f"Navigating to {url}"
        elif action == "reload":
            await safari_eval(self._url, "location.reload()")
            note = "Reloading page"
        elif action == "back":
            await safari_eval(self._url, "history.back()")
            note = "Going back"
        elif action == "forward":
            await safari_eval(self._url, "history.forward()")
            note = "Going forward"
        else:
            raise ValueError("Provide url or action (reload/back/forward)")
        return f"{note}\nWait briefly then call tree to see the updated page."

    async def network(self, filters: dict) -> list[dict]:
        entries = await safari_network(self._url)
        for key in ("url", "method"):
            val = filters.get(key, "")
            if val:
                entries = [
                    e for e in entries if val.lower() in str(e.get(key, "")).lower()
                ]
        return entries

    async def console(self, filters: dict) -> list[dict]:
        entries = await safari_console(self._url)
        normalized: list[dict] = []
        for entry in entries:
            msg = entry.get("message", entry) if isinstance(entry, dict) else entry
            if isinstance(msg, dict):
                normalized.append(
                    {
                        "level": msg.get("level", msg.get("type", "log")),
                        "text": msg.get("text", ""),
                        "url": msg.get("url", ""),
                    }
                )
            else:
                normalized.append({"level": "log", "text": str(msg)})
        return normalized

    async def issues(self) -> list[dict]:
        raise NotSupported("Not available on iOS Safari (no Audits domain in WebKit)")

    async def viewport(self, args: dict) -> str:
        if args:
            raise NotSupported(
                "Viewport emulation is not supported on iOS devices (read-only)"
            )
        vp = await safari_viewport(self._url)
        self._pty.safari_viewport = vp
        w = vp.get("w", "?")
        h = vp.get("screenH", vp.get("layoutH", "?"))
        dpr = vp.get("dpr", "?")
        parts = [f"{w}x{h} dpr={dpr} (iOS physical device)"]
        if vp.get("safeTop") or vp.get("safeBottom"):
            parts.append(
                f"safe area: top={vp.get('safeTop', 0)} bottom={vp.get('safeBottom', 0)}"
            )
        kb = vp.get("keyboardH", 0)
        if kb > 0:
            parts.append(f"keyboard: {kb}px")
        if vp.get("scrollY"):
            parts.append(f"scrollY={vp['scrollY']}")
        if vp.get("contentH"):
            parts.append(f"contentH={vp['contentH']}")
        return "Viewport (iOS):\n" + "\n".join(parts)

    async def viewport_line(self) -> str:
        try:
            vp = await safari_viewport(self._url)
            self._pty.safari_viewport = vp
            line = (
                f"{vp.get('w', '?')}x{vp.get('screenH', vp.get('layoutH', '?'))}"
                f" @{vp.get('dpr', '?')}x (iOS)"
            )
            if vp.get("safeTop") or vp.get("safeBottom"):
                line += f" safe:{vp.get('safeTop', 0)}+{vp.get('safeBottom', 0)}"
            kb = vp.get("keyboardH", 0)
            if kb > 0:
                line += f" keyboard:{kb}px"
            return f"viewport: {line}"
        except Exception:
            return ""


# ---------------------------------------------------------------------------
# CDP backend (ADB remote)
# ---------------------------------------------------------------------------

_CDP_HEADER = (
    "DevPanel: controlling a PHYSICAL MOBILE DEVICE via ADB remote debugging.\n\n"
    "This is a real phone — touch targets are small, layouts are mobile. "
    "viewport() is read-only (no emulation on physical devices). "
    "js(), network, console, and watch tools are NOT available on remote targets. "
    "Use device_screenshot to capture the full physical screen (includes on-screen "
    "keyboard, status bar). Use screenshot for browser-viewport-only captures.\n\n"
)


class CdpBackend:
    type = "cdp"
    instructions_header = _CDP_HEADER

    def __init__(self, pty: PtySession) -> None:
        self._pty = pty

    async def tree(self, depth: int = 4) -> tuple[str, int]:
        fetch_depth = max(depth + 4, 12)
        await self._pty.cdp_command("Accessibility.enable")
        try:
            result = await self._pty.cdp_command(
                "Accessibility.getFullAXTree",
                {"depth": fetch_depth},
                timeout=10.0,
            )
        finally:
            await self._pty.cdp_command("Accessibility.disable")
        nodes = result.get("result", {}).get("nodes", [])
        return format_ax_tree(nodes, depth)

    async def screenshot(self, selector: str | None = None) -> tuple[str, str | None]:
        data = await cdp_screenshot(self._pty, selector)
        return (
            data,
            "CDP screenshot — browser viewport only, "
            "on-screen keyboard not visible even if open",
        )

    async def device_screenshot(self) -> tuple[str, str]:
        from devpanel.session import adb_state

        if not adb_state:
            raise TargetError("No ADB device — run `devpanel adb` first")
        data = await adb_screenshot(adb_state["serial"])
        return (
            data,
            "ADB screencap — full physical screen including "
            "OS chrome and on-screen keyboard",
        )

    async def click(self, selector: str) -> MutationResult:
        bbox = await cdp_resolve_selector(self._pty, selector)
        if not bbox:
            raise ElementNotFound(selector)
        cx, cy = bbox["cx"], bbox["cy"]
        self._pty._cdp_mutating = True
        try:
            await self._pty.cdp_command(
                "Input.dispatchMouseEvent",
                {
                    "type": "mousePressed",
                    "x": cx,
                    "y": cy,
                    "button": "left",
                    "clickCount": 1,
                },
            )
            await self._pty.cdp_command(
                "Input.dispatchMouseEvent",
                {
                    "type": "mouseReleased",
                    "x": cx,
                    "y": cy,
                    "button": "left",
                    "clickCount": 1,
                },
            )
        finally:
            self._pty._cdp_mutating = False
        return _mutation_from_settle(await cdp_settle_and_tree(self._pty))

    async def type_text(
        self, selector: str, text: str, press_enter: bool = False
    ) -> MutationResult:
        bbox = await cdp_resolve_selector(self._pty, selector)
        if not bbox:
            raise ElementNotFound(selector)
        self._pty._cdp_mutating = True
        try:
            await self._pty.cdp_command(
                "Runtime.callFunctionOn",
                {
                    "objectId": bbox["objectId"],
                    "functionDeclaration": "function(){this.focus();if(this.select)this.select();}",
                    "returnByValue": True,
                },
            )
            for ch in text:
                await self._pty.cdp_command(
                    "Input.dispatchKeyEvent",
                    {"type": "keyDown", "text": ch, "unmodifiedText": ch},
                )
                await self._pty.cdp_command(
                    "Input.dispatchKeyEvent",
                    {"type": "keyUp", "text": ch, "unmodifiedText": ch},
                )
            if press_enter:
                await self._pty.cdp_command(
                    "Input.dispatchKeyEvent",
                    {"type": "keyDown", "key": "Return", "code": "Enter"},
                )
                await self._pty.cdp_command(
                    "Input.dispatchKeyEvent",
                    {"type": "keyUp", "key": "Return", "code": "Enter"},
                )
        finally:
            self._pty._cdp_mutating = False
        return _mutation_from_settle(await cdp_settle_and_tree(self._pty))

    async def navigate(self, url: str | None = None, action: str | None = None) -> str:
        if url:
            await self._pty.cdp_command("Page.navigate", {"url": url}, timeout=10.0)
            note = f"Navigating to {url}"
        elif action == "reload":
            await self._pty.cdp_command("Page.reload", {}, timeout=10.0)
            note = "Reloading page"
        elif action == "back":
            await self._pty.cdp_command(
                "Runtime.evaluate",
                {"expression": "history.back()", "returnByValue": True},
                timeout=5.0,
            )
            note = "Going back"
        elif action == "forward":
            await self._pty.cdp_command(
                "Runtime.evaluate",
                {"expression": "history.forward()", "returnByValue": True},
                timeout=5.0,
            )
            note = "Going forward"
        else:
            raise ValueError("Provide url or action (reload/back/forward)")
        return (
            f"{note}\nWait for the channel notification before calling tree/click/type."
        )

    async def network(self, filters: dict) -> list[dict]:
        raise NotSupported("Not available on ADB remote targets")

    async def console(self, filters: dict) -> list[dict]:
        raise NotSupported("Not available on ADB remote targets")

    async def issues(self) -> list[dict]:
        from devpanel.session import SELECTOR_BUILDER_JS

        try:
            await self._pty.cdp_command("Audits.checkFormsIssues", timeout=3.0)
            await asyncio.sleep(0.3)
        except Exception:
            pass

        issues = list(self._pty.issues_buffer)
        for issue in issues:
            details = issue.get("details")
            if not details or not isinstance(details, dict):
                continue
            node_id = details.get("violatingNodeId")
            if not node_id:
                continue
            try:
                resolve_r = await self._pty.cdp_command(
                    "DOM.resolveNode",
                    {"backendNodeId": node_id},
                    timeout=3.0,
                )
                oid = resolve_r.get("result", {}).get("object", {}).get("objectId")
                if oid:
                    call_r = await self._pty.cdp_command(
                        "Runtime.callFunctionOn",
                        {
                            "objectId": oid,
                            "functionDeclaration": (
                                f"function(){{ return {SELECTOR_BUILDER_JS.strip()}; }}"
                            ),
                            "returnByValue": True,
                        },
                        timeout=3.0,
                    )
                    selector = call_r.get("result", {}).get("result", {}).get("value")
                    if selector:
                        issue["selector"] = selector
            except Exception:
                pass
        return issues

    async def viewport(self, args: dict) -> str:
        if args:
            raise NotSupported(
                "Viewport emulation is not supported on physical devices (read-only)"
            )
        result = await self._pty.cdp_command(
            "Runtime.evaluate",
            {
                "expression": (
                    "(function(){"
                    "var vv=window.visualViewport||{};"
                    "return {"
                    "  width:window.innerWidth,"
                    "  height:window.innerHeight,"
                    "  dpr:window.devicePixelRatio,"
                    "  touch:navigator.maxTouchPoints>0,"
                    "  orientation:screen.orientation?screen.orientation.type:'unknown',"
                    "  visualHeight:vv.height||null,"
                    "  keyboardVisible:vv.height!=null && vv.height<window.innerHeight"
                    "};"
                    "})()"
                ),
                "returnByValue": True,
            },
            timeout=5.0,
        )
        vp = result.get("result", {}).get("result", {}).get("value") or {}
        w = vp.get("width", "?")
        h = vp.get("height", "?")
        dpr = vp.get("dpr", "?")
        touch = vp.get("touch", False)
        orientation = vp.get("orientation", "unknown")
        kb = vp.get("keyboardVisible", False)
        label = (
            f"{w}x{h} dpr={dpr} touch={'yes' if touch else 'no'} "
            f"orientation={orientation}" + (" keyboard=visible" if kb else "")
        )
        return f"Viewport (physical device): {label}"

    async def viewport_line(self) -> str:
        try:
            result = await self._pty.cdp_command(
                "Runtime.evaluate",
                {
                    "expression": (
                        "(function(){"
                        "var vv=window.visualViewport||{};"
                        "return window.innerWidth+'x'+window.innerHeight"
                        "  +' dpr='+window.devicePixelRatio"
                        "  +' touch='+(navigator.maxTouchPoints>0?'yes':'no')"
                        "  +(vv.height!=null&&vv.height<window.innerHeight?"
                        "' keyboard=visible':'');"
                        "})()"
                    ),
                    "returnByValue": True,
                },
                timeout=2.0,
            )
            label = result.get("result", {}).get("result", {}).get("value", "")
            return f"viewport (physical): {label}" if label else ""
        except Exception:
            return ""


# ---------------------------------------------------------------------------
# Panel backend (local Chrome tab)
# ---------------------------------------------------------------------------

_PANEL_HEADER = (
    "DevPanel: browser context injection for the inspected Chrome tab.\n\n"
    "Viewport state is included in context/drain output. Use viewport() to resize "
    "for responsive testing. Do NOT try to resize the browser window manually.\n\n"
)


class PanelBackend:
    type = "panel"
    instructions_header = _PANEL_HEADER

    def __init__(self, pty: PtySession) -> None:
        self._pty = pty

    async def _cmd(self, cmd: str, timeout: float = 10.0, **params: Any) -> dict:
        """Send command to panel, return result dict. Raises TargetError on error."""
        resp = await self._pty.send_command(cmd, timeout=timeout, **params)
        if "error" in resp:
            raise TargetError(resp["error"])
        return resp.get("result", {})

    async def tree(self, depth: int = 4) -> tuple[str, int]:
        r = await self._cmd("tree", timeout=10.0, depth=depth)
        return r.get("text", ""), 0

    async def screenshot(self, selector: str | None = None) -> tuple[str, str | None]:
        params: dict[str, Any] = {}
        if selector:
            params["selector"] = selector
        r = await self._cmd("screenshot", timeout=10.0, **params)
        return r.get("data", ""), None

    async def device_screenshot(self) -> tuple[str, str]:
        raise NotSupported("Not supported on local targets")

    async def click(self, selector: str) -> MutationResult:
        r = await self._cmd("click", timeout=15.0, selector=selector)
        return MutationResult(
            url=r.get("url", "?"),
            tree=r.get("tree", ""),
            node_count=r.get("nodeCount", 0),
            settle_ms=r.get("settleMs", 0),
            network=r.get("network"),
        )

    async def type_text(
        self, selector: str, text: str, press_enter: bool = False
    ) -> MutationResult:
        params: dict[str, Any] = {"selector": selector, "text": text}
        if press_enter:
            params["press_enter"] = True
        r = await self._cmd("type", timeout=15.0, **params)
        return MutationResult(
            url=r.get("url", "?"),
            tree=r.get("tree", ""),
            node_count=r.get("nodeCount", 0),
            settle_ms=r.get("settleMs", 0),
            network=r.get("network"),
        )

    async def navigate(self, url: str | None = None, action: str | None = None) -> str:
        params: dict[str, Any] = {}
        if url:
            params["url"] = url
        if action:
            params["action"] = action
        r = await self._cmd("navigate", timeout=10.0, **params)
        return f"Navigating to {r.get('url', '?')}\n{r.get('note', '')}"

    async def network(self, filters: dict) -> list[dict]:
        params: dict[str, Any] = {}
        for key in ("url", "method", "status", "since"):
            if key in filters:
                params[key] = filters[key]
        r = await self._cmd("network", timeout=10.0, **params)
        return r.get("entries", [])

    async def console(self, filters: dict) -> list[dict]:
        params: dict[str, Any] = {}
        if "since" in filters:
            params["since"] = filters["since"]
        if "level" in filters:
            params["level"] = filters["level"]
        r = await self._cmd("console", timeout=5.0, **params)
        return r.get("entries", [])

    async def issues(self) -> list[dict]:
        r = await self._cmd("issues", timeout=5.0)
        return r.get("issues", [])

    async def viewport(self, args: dict) -> str:
        r = await self._cmd("viewport", timeout=5.0, **args)
        return f"Viewport: {r.get('label', '?')}"

    async def viewport_line(self) -> str:
        try:
            r = await self._cmd("viewport", timeout=2.0)
            label = r.get("label", "")
            return f"viewport: {label}" if label else ""
        except Exception:
            return ""


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_backend(
    pty: PtySession,
) -> SafariBackend | CdpBackend | PanelBackend | None:
    """Get the appropriate backend for the session's active target."""
    if pty.safari_url:
        return SafariBackend(pty)
    if pty.cdp_ws:
        return CdpBackend(pty)
    if pty.clients:
        return PanelBackend(pty)
    return None
