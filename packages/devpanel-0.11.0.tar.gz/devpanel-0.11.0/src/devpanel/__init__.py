"""DevPanel CLI entry point."""

from __future__ import annotations

import asyncio
import json
import socket
import subprocess
import sys
import urllib.request


def main() -> None:
    args = sys.argv[1:]

    # Native messaging mode: Chrome invokes as `devpanel chrome-extension://ID/`
    if args and args[0].startswith("chrome-extension://"):
        from devpanel.nativemsg import serve

        serve()
        return

    cmd = args[0] if args else "start"

    if cmd == "start":
        port = 0
        for i, a in enumerate(args[1:], 1):
            if a == "--port" and i + 1 < len(args):
                port = int(args[i + 1])
        _run_server(port)

    elif cmd == "install":
        ext_id = None
        dev = False
        user_data_dir = None
        for i, a in enumerate(args[1:], 1):
            if a.startswith("--extension-id="):
                ext_id = a.split("=", 1)[1]
            elif a == "--extension-id" and i + 1 < len(args):
                ext_id = args[i + 1]
            elif a.startswith("--user-data-dir="):
                user_data_dir = a.split("=", 1)[1]
            elif a == "--user-data-dir" and i + 1 < len(args):
                user_data_dir = args[i + 1]
            elif a == "--dev":
                dev = True
        from devpanel.install import install

        install(ext_id, dev=dev, user_data_dir=user_data_dir)

    elif cmd == "adb":
        sys.exit(_cmd_adb(args[1:]))

    elif cmd == "restart":
        sys.exit(_cmd_restart())

    elif cmd == "status":
        sys.exit(_cmd_status())

    else:
        print(
            "Usage: devpanel [start|install|restart|status|adb]\n"
            "\n"
            "  start                              Start daemon (random port)\n"
            "  start --port PORT                  Start daemon on fixed port\n"
            "  install --extension-id=ID          Register NMH manifest (production)\n"
            "  install --extension-id=ID --dev    Register NMH manifest (dev, repld)\n"
            "  install --user-data-dir=PATH       Also write manifest to custom profile\n"
            "  restart                            Kill running daemon\n"
            "  status                             Show daemon health\n"
            "  adb                                Forward ADB CDP port + open chrome://inspect\n"
            "  adb list                           List phone tabs via ADB\n"
            "  adb --device SERIAL                Use specific ADB device\n"
            "  adb --port PORT                    Use specific forwarding port",
            file=sys.stderr,
        )
        sys.exit(1)


def _cmd_restart() -> int:
    """Kill the running daemon and remove the lock. Next NMH spawn brings up fresh code."""
    from devpanel.nativemsg import LOCK_FILE, _kill_pid, _read_lock

    lock = _read_lock()
    if not lock:
        if LOCK_FILE.exists():
            LOCK_FILE.unlink(missing_ok=True)
            print("Removed stale lock (daemon was not running)")
            return 0
        print("No daemon running")
        return 0

    pid = lock.get("pid", 0)
    port = lock.get("port", "?")
    if _kill_pid(pid):
        LOCK_FILE.unlink(missing_ok=True)
        print(f"Killed daemon pid={pid} port={port}")
        return 0
    print(f"Failed to kill daemon pid={pid}", file=sys.stderr)
    return 1


def _cmd_status() -> int:
    """Print daemon health from /controls. Exit 1 if not running."""
    from devpanel.nativemsg import LOCK_FILE, _read_lock

    if not LOCK_FILE.exists():
        print("not running (no lock file)")
        return 1
    lock = _read_lock()
    if not lock:
        print("not running (stale lock — pid not alive)")
        return 1
    port = lock.get("port")
    pid = lock.get("pid")
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/controls", timeout=2
        ) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        print(f"unreachable: {e}", file=sys.stderr)
        return 1

    print(f"devpanel daemon  pid={pid}  port={port}")
    print(f"  version       {data.get('version') or '(unknown)'}")
    print(f"  uptime        {data.get('uptime', 0)}s")
    print(f"  spill_dir     {data.get('spill_dir', '?')}")
    print(f"  repld_socket  {data.get('repld_socket') or '(none)'}")
    adb = data.get("adb")
    if adb:
        print(
            f"  adb           serial={adb.get('serial', '?')}  cdp_port={adb.get('cdp_port', '?')}"
        )
    safari = data.get("safari")
    if safari:
        print(f"  safari        url={safari.get('url', '?')}")
    sessions = data.get("sessions", {})
    print(f"  sessions      {len(sessions)}")
    for sid, s in sessions.items():
        cdp_flag = "  cdp=yes" if s.get("cdp_connected") else ""
        print(
            f"    {sid[:8]}  pty_pid={s.get('pty_pid')}  clients={s.get('clients', 0)}  "
            f"stack={s.get('stack_size', 0)}  mcp={s.get('mcp_sessions', 0)}  "
            f"async={s.get('async_tasks', 0)}  watch={s.get('watchers', 0)}{cdp_flag}"
        )
    return 0


async def _list_cdp_pages(cdp_port: int) -> list[dict]:
    """List page targets via browser-level CDP WebSocket (Android-compatible)."""
    import aiohttp

    async with aiohttp.ClientSession() as http:
        ws = await http.ws_connect(f"ws://127.0.0.1:{cdp_port}/devtools/browser")
        await ws.send_json({"id": 1, "method": "Target.getTargets", "params": {}})
        resp = await asyncio.wait_for(ws.receive_json(), timeout=5.0)
        await ws.close()
    targets = resp.get("result", {}).get("targetInfos", [])
    return [t for t in targets if t.get("type") == "page"]


def _adb_devices() -> list[str]:
    """Return list of connected ADB device serials."""
    try:
        out = subprocess.check_output(["adb", "devices"], text=True, timeout=5)
    except (
        FileNotFoundError,
        subprocess.CalledProcessError,
        subprocess.TimeoutExpired,
    ):
        return []
    lines = out.strip().splitlines()[1:]  # skip "List of devices attached"
    serials = []
    for line in lines:
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            serials.append(parts[0])
    return serials


def _free_port() -> int:
    """Find a free TCP port."""
    with socket.socket() as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def _cmd_adb(args: list[str]) -> int:
    """Handle `devpanel adb [list] [--device SERIAL] [--port PORT]`."""
    subcmd = "setup"
    serial: str | None = None
    port: int = 0  # 0 = find free

    i = 0
    while i < len(args):
        a = args[i]
        if a == "list":
            subcmd = "list"
        elif a == "--device" and i + 1 < len(args):
            serial = args[i + 1]
            i += 1
        elif a.startswith("--device="):
            serial = a.split("=", 1)[1]
        elif a == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
            i += 1
        elif a.startswith("--port="):
            port = int(a.split("=", 1)[1])
        i += 1

    from devpanel.nativemsg import _read_lock

    if subcmd == "list":
        # Read daemon lock → find CDP port → list tabs
        lock = _read_lock()
        if not lock:
            print("No daemon running — start daemon first", file=sys.stderr)
            return 1
        daemon_port = lock["port"]
        try:
            with urllib.request.urlopen(
                f"http://127.0.0.1:{daemon_port}/controls", timeout=2
            ) as resp:
                data = json.loads(resp.read())
        except Exception:
            print("Daemon unreachable", file=sys.stderr)
            return 1
        adb_info = data.get("adb")
        if not adb_info:
            print("No ADB port configured — run `devpanel adb` first", file=sys.stderr)
            return 1
        cdp_port = adb_info["cdp_port"]
        # Use browser WS + Target.getTargets (Android Chrome doesn't expose pages via /json)
        try:
            page_targets = asyncio.run(_list_cdp_pages(cdp_port))
        except Exception as e:
            print(
                f"Could not list targets on CDP port {cdp_port}: {e}", file=sys.stderr
            )
            return 1
        if not page_targets:
            print("No page targets found")
            return 0
        print(f"{'ID':<12}  {'Title':<40}  URL")
        print("-" * 80)
        for t in page_targets:
            tid = t.get("targetId", t.get("id", ""))[:10]
            title = (t.get("title") or "")[:38]
            url = t.get("url", "")[:60]
            print(f"{tid:<12}  {title:<40}  {url}")
        return 0

    # setup mode
    devices = _adb_devices()
    if not devices:
        print(
            "No ADB devices found. Connect a device and enable USB debugging.",
            file=sys.stderr,
        )
        return 1

    if not serial:
        if len(devices) == 1:
            serial = devices[0]
        else:
            print("Multiple ADB devices connected:")
            for i, d in enumerate(devices):
                print(f"  {i + 1}. {d}")
            try:
                choice = input(f"Select device [1-{len(devices)}]: ").strip()
                idx = int(choice) - 1
                if idx < 0 or idx >= len(devices):
                    raise ValueError
                serial = devices[idx]
            except (ValueError, KeyboardInterrupt, EOFError):
                print("Cancelled", file=sys.stderr)
                return 1

    # Ensure daemon is running (spawn if needed)
    from devpanel.nativemsg import _ensure_daemon

    try:
        daemon_info = _ensure_daemon()
        daemon_port = daemon_info["port"]
    except Exception as e:
        print(f"Failed to start daemon: {e}", file=sys.stderr)
        return 1

    # Reuse existing ADB forward port if daemon already has one
    if port == 0:
        try:
            with urllib.request.urlopen(
                f"http://127.0.0.1:{daemon_port}/controls", timeout=2
            ) as resp:
                controls = json.loads(resp.read())
            adb_info = controls.get("adb")
            if adb_info and adb_info.get("cdp_port"):
                old_port = adb_info["cdp_port"]
                old_serial = adb_info.get("serial", "")
                if old_serial == serial:
                    port = old_port
                else:
                    subprocess.run(
                        ["adb", "forward", "--remove", f"tcp:{old_port}"],
                        capture_output=True,
                        timeout=5,
                    )
        except Exception:
            pass
    if port == 0:
        port = _free_port()

    # Clean up stale forwards for this device before creating a new one
    try:
        fwd_list = subprocess.check_output(
            ["adb", "-s", serial, "forward", "--list"], text=True, timeout=5
        )
        for line in fwd_list.strip().splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[2] == "localabstract:chrome_devtools_remote":
                old_fwd = parts[1]  # e.g. "tcp:46695"
                if old_fwd != f"tcp:{port}":
                    subprocess.run(
                        ["adb", "-s", serial, "forward", "--remove", old_fwd],
                        capture_output=True,
                        timeout=5,
                    )
    except Exception:
        pass  # Best-effort cleanup

    # ADB forward
    try:
        result = subprocess.run(
            [
                "adb",
                "-s",
                serial,
                "forward",
                f"tcp:{port}",
                "localabstract:chrome_devtools_remote",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            print(f"adb forward failed: {result.stderr.strip()}", file=sys.stderr)
            return 1
    except FileNotFoundError:
        print("adb not found — install Android SDK Platform Tools", file=sys.stderr)
        return 1
    except subprocess.TimeoutExpired:
        print("adb forward timed out", file=sys.stderr)
        return 1

    print(f"Forwarded tcp:{port} → {serial} chrome_devtools_remote")

    try:
        payload = json.dumps({"cdp_port": port, "serial": serial}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{daemon_port}/adb",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=3)
        print(f"Daemon notified (port {daemon_port})")
    except Exception as e:
        print(f"Warning: could not notify daemon: {e}", file=sys.stderr)

    print("Open chrome://inspect/#devices in Chrome to see the device")
    return 0


def _run_server(port: int) -> None:
    async def _main() -> None:
        from devpanel.server import run

        actual_port = await run(port)
        if sys.stdout.isatty():
            print(f"devpanel daemon listening on http://127.0.0.1:{actual_port}")
            print(f"  WebSocket PTY: ws://127.0.0.1:{actual_port}/ws")
            print(f"  MCP:           http://127.0.0.1:{actual_port}/mcp")
            print(f"  Controls:      http://127.0.0.1:{actual_port}/controls")
            print(f"  Stack:         http://127.0.0.1:{actual_port}/stack")
        # Block forever
        await asyncio.Event().wait()

    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass
