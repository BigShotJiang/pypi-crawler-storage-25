"""Safari (iOS) target helpers — thin async wrappers around safarictl HTTP API.

Pure HTTP calls, no WebSocket or event stream. safarictl handles the WebKit
Inspector Protocol session and USB tunnel via pymobiledevice3.
"""

import asyncio
import json
import re
from typing import Any

import aiohttp

from devpanel.js_templates import RESOLVE_LABEL_JS, RESOLVE_ROLE_JS, RESOLVE_TEXT_JS

_http: aiohttp.ClientSession | None = None


async def _get_http() -> aiohttp.ClientSession:
    global _http
    if _http is None or _http.closed:
        _http = aiohttp.ClientSession()
    return _http


async def close_http() -> None:
    """Close the shared HTTP session. Call on daemon shutdown."""
    global _http
    if _http and not _http.closed:
        await _http.close()
    _http = None


async def _checked_json(resp: aiohttp.ClientResponse) -> Any:
    """Parse JSON response, raising on HTTP errors."""
    if resp.status >= 400:
        body = await resp.text()
        raise RuntimeError(f"safarictl {resp.status}: {body[:200]}")
    return await resp.json()


async def safari_eval(url: str, expression: str) -> object:
    """POST /eval — Runtime.evaluate on iOS device."""
    http = await _get_http()
    resp = await http.post(f"{url}/eval", json={"expression": expression})
    data = await _checked_json(resp)
    return data.get("result")


async def safari_screenshot(url: str) -> str:
    """GET /screenshot — Page.snapshotPage from device. Returns base64 PNG."""
    http = await _get_http()
    resp = await http.get(f"{url}/screenshot")
    data = await _checked_json(resp)
    # data["dataURL"] is "data:image/png;base64,..."
    return data["dataURL"].split(",", 1)[1]


async def safari_viewport(url: str) -> dict:
    """GET /viewport — iOS viewport with safe areas, keyboard state."""
    http = await _get_http()
    resp = await http.get(f"{url}/viewport")
    return await _checked_json(resp)


async def safari_reload(url: str) -> dict:
    """POST /reload — re-dump HTML from iOS device, return new viewport JSON."""
    http = await _get_http()
    resp = await http.post(f"{url}/reload")
    return await _checked_json(resp)


async def safari_console(url: str) -> list:
    """GET /console — drain console event buffer."""
    http = await _get_http()
    resp = await http.get(f"{url}/console")
    return await _checked_json(resp)


async def safari_network(url: str) -> list:
    """GET /network — drain network event buffer."""
    http = await _get_http()
    resp = await http.get(f"{url}/network")
    return await _checked_json(resp)


# ---------------------------------------------------------------------------
# DOM tree walker JS — evaluated on device via POST /eval.
# Produces indented text matching the AX tree style:
#   role 'name' = "value" [states]
# ---------------------------------------------------------------------------

DOM_TREE_WALKER_JS = r"""
(function(maxDepth) {
  var SKIP_TAGS = {SCRIPT:1, STYLE:1, NOSCRIPT:1, TEMPLATE:1, SVG:1};
  var INTERACTIVE = {
    A:'link', BUTTON:'button', INPUT:'textbox', TEXTAREA:'textbox',
    SELECT:'combobox', DETAILS:'group', SUMMARY:'button',
    DIALOG:'dialog', MENU:'menu'
  };
  var INPUT_ROLES = {
    checkbox:'checkbox', radio:'radio', range:'slider',
    search:'searchbox', submit:'button', reset:'button',
    image:'button', file:'button'
  };
  var LANDMARK_TAGS = {
    MAIN:'main', NAV:'navigation', HEADER:'banner', FOOTER:'contentinfo',
    ASIDE:'complementary', SECTION:'section', ARTICLE:'article', FORM:'form'
  };

  function getRole(el) {
    var explicit = el.getAttribute('role');
    if (explicit) return explicit;
    var tag = el.tagName;
    if (LANDMARK_TAGS[tag]) return LANDMARK_TAGS[tag];
    if (tag === 'INPUT') return INPUT_ROLES[el.type] || 'textbox';
    if (INTERACTIVE[tag]) return INTERACTIVE[tag];
    if (tag.match(/^H[1-6]$/)) return 'heading';
    if (tag === 'IMG') return 'img';
    if (tag === 'TABLE') return 'table';
    if (tag === 'TR') return 'row';
    if (tag === 'TH') return 'columnheader';
    if (tag === 'TD') return 'cell';
    if (tag === 'UL' || tag === 'OL') return 'list';
    if (tag === 'LI') return 'listitem';
    return '';
  }

  function getName(el) {
    return el.getAttribute('aria-label')
      || el.getAttribute('alt')
      || el.getAttribute('title')
      || el.getAttribute('placeholder')
      || '';
  }

  function getTextContent(el) {
    // Direct text only (no child element text)
    var text = '';
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === 3) text += el.childNodes[i].textContent;
    }
    return text.trim();
  }

  var lines = [];
  function walk(el, depth) {
    if (depth > maxDepth) return 0;
    if (el.nodeType !== 1) return 0;
    var tag = el.tagName;
    if (SKIP_TAGS[tag]) return 0;
    if (el.hidden || el.getAttribute('aria-hidden') === 'true') return 0;

    var role = getRole(el);
    var name = getName(el);
    var indent = '';
    for (var i = 0; i < depth; i++) indent += '  ';

    // Skip non-semantic wrappers — recurse into children at same depth
    if (!role) {
      var count = 0;
      for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
        count += walk(c, depth);
      }
      return count;
    }

    var line = indent + role;

    // Name: prefer aria-label, fall back to direct text for interactive/heading
    var label = name;
    if (!label && (INTERACTIVE[tag] || role === 'heading' || role === 'link' || role === 'button')) {
      label = getTextContent(el);
    }
    if (label) {
      label = label.length > 50 ? label.substring(0, 47) + '...' : label;
      line += " '" + label + "'";
    }

    // Value for inputs
    if (el.value !== undefined && el.value !== '' && (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT')) {
      var v = String(el.value);
      v = v.length > 30 ? v.substring(0, 27) + '...' : v;
      line += ' = "' + v + '"';
    }

    // States
    var states = [];
    if (document.activeElement === el) states.push('focused');
    if (el.required) states.push('required');
    if (el.disabled) states.push('disabled');
    if (el.checked) states.push('checked');
    if (el.getAttribute('aria-selected') === 'true') states.push('selected');
    if (el.getAttribute('aria-expanded') === 'true') states.push('expanded');
    if (el.getAttribute('aria-expanded') === 'false') states.push('collapsed');
    if (states.length) line += ' [' + states.join(', ') + ']';

    lines.push(line);
    var count = 1;
    for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
      count += walk(c, depth + 1);
    }
    return count;
  }

  var count = walk(document.body, 0);
  return JSON.stringify({tree: lines.join('\n'), nodeCount: count});
})(%%DEPTH%%)
"""


# ---------------------------------------------------------------------------
# Selector resolution — shared JS for click/type.
# Resolves text=, role=, label=, CSS selectors to an element.
# ---------------------------------------------------------------------------


def _build_resolve_js(selector: str) -> str:
    """Build JS expression that resolves a selector to an element or null."""
    if selector.startswith("text="):
        return RESOLVE_TEXT_JS.replace("%%TEXT%%", json.dumps(selector[5:]))
    if selector.startswith("role="):
        role_part = selector[5:]
        m = re.match(r'^(\w+)(?:\[name="([^"]+)"\])?$', role_part)
        role = json.dumps(m.group(1) if m else role_part)
        name = json.dumps(m.group(2)) if m and m.group(2) else "null"
        return RESOLVE_ROLE_JS.replace("%%ROLE%%", role).replace("%%NAME%%", name)
    if selector.startswith("label="):
        return RESOLVE_LABEL_JS.replace("%%LABEL%%", json.dumps(selector[6:]))
    return f"document.querySelector({json.dumps(selector)})"


# ---------------------------------------------------------------------------
# Compound operations — compose HTTP helpers into tool-level actions.
# ---------------------------------------------------------------------------


CLICK_JS = r"""
(function(){
  var el=%%RESOLVE%%;
  if(!el)return 'not found';
  el.click();return 'clicked';
})()
"""

TYPE_JS = r"""
(function(){
  var el=%%RESOLVE%%;
  if(!el)return 'not found';
  el.focus();
  if(el.select)el.select();
  el.value=%%TEXT%%;
  el.dispatchEvent(new Event('input',{bubbles:true}));
  el.dispatchEvent(new Event('change',{bubbles:true}));
  %%ENTER%%
  return 'typed';
})()
"""

ENTER_JS = (
    "el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true}));"
    "el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true}));"
)


async def safari_click(url: str, selector: str) -> None:
    """Resolve selector and click the element on the iOS device.

    Raises ValueError if element not found.
    """
    js = CLICK_JS.replace("%%RESOLVE%%", _build_resolve_js(selector))
    result = await safari_eval(url, js)
    if result == "not found":
        raise ValueError(f"Element not found: {selector}")


async def safari_type(
    url: str, selector: str, text: str, press_enter: bool = False
) -> None:
    """Resolve selector, focus element, set value, dispatch events.

    Raises ValueError if element not found.
    """
    js = (
        TYPE_JS.replace("%%RESOLVE%%", _build_resolve_js(selector))
        .replace("%%TEXT%%", json.dumps(text))
        .replace("%%ENTER%%", ENTER_JS if press_enter else "")
    )
    result = await safari_eval(url, js)
    if result == "not found":
        raise ValueError(f"Element not found: {selector}")


async def safari_tree(url: str, depth: int = 4) -> tuple[str, int]:
    """Capture DOM tree from iOS device. Returns (tree_text, node_count)."""
    js = DOM_TREE_WALKER_JS.replace("%%DEPTH%%", str(depth))
    raw = await safari_eval(url, js)
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    if isinstance(parsed, dict):
        return parsed.get("tree", ""), parsed.get("nodeCount", 0)
    return "", 0


async def safari_settle_and_tree(url: str, depth: int = 4) -> dict:
    """After a mutation on iOS, wait briefly, re-dump, then capture tree + URL."""
    await asyncio.sleep(0.5)
    try:
        await safari_reload(url)
    except Exception:
        pass
    try:
        current_url = await safari_eval(url, "location.href")
    except Exception:
        current_url = "?"
    try:
        tree_text, node_count = await safari_tree(url, depth)
    except Exception:
        tree_text, node_count = "", 0
    return {
        "url": current_url,
        "tree": tree_text,
        "nodeCount": node_count,
        "settleMs": 500,
    }
