"""CDP/ADB remote target helpers.

Async functions for interacting with physical devices via the daemon's
direct CDP WebSocket (ADB-forwarded). Used by mcp.py tool implementations.
"""

import asyncio
import base64
import json
import re
from typing import Any

from devpanel.ax_tree import format_ax_tree
from devpanel.js_templates import ELEMENT_BBOX_JS, RESOLVE_LABEL_JS, RESOLVE_TEXT_JS
from devpanel.session import PtySession


async def adb_screenshot(serial: str) -> str:
    """Capture full device screen via ADB screencap. Returns base64 PNG.

    Includes on-screen keyboard, status bar, navigation bar — everything
    visible on the physical display.
    """
    proc = await asyncio.create_subprocess_exec(
        "adb",
        "-s",
        serial,
        "exec-out",
        "screencap",
        "-p",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10.0)
    if proc.returncode != 0:
        raise RuntimeError(f"adb screencap failed: {stderr.decode().strip()}")
    if not stdout:
        raise RuntimeError("adb screencap returned no data")
    return base64.b64encode(stdout).decode()


async def cdp_screenshot(pty: PtySession, selector: str | None = None) -> str:
    """Capture a screenshot via the daemon CDP WebSocket. Returns base64 PNG.

    Raises RuntimeError on failure, asyncio.TimeoutError on timeout.
    Used by both MCP tool and panel HTTP endpoint.
    """
    cdp_params: dict[str, Any] = {"format": "png", "fromSurface": True}
    if selector:
        try:
            js = ELEMENT_BBOX_JS.replace("%%SELECTOR%%", json.dumps(selector))
            eval_result = await pty.cdp_command(
                "Runtime.evaluate",
                {"expression": js, "returnByValue": True},
                timeout=5.0,
            )
            bbox = eval_result.get("result", {}).get("result", {}).get("value")
            if bbox and bbox.get("width", 0) > 0 and bbox.get("height", 0) > 0:
                cdp_params["clip"] = {
                    "x": bbox["x"],
                    "y": bbox["y"],
                    "width": bbox["width"],
                    "height": bbox["height"],
                    "scale": 1,
                }
                cdp_params["captureBeyondViewport"] = True
        except Exception:
            pass  # Fall through to full-viewport screenshot
    result = await pty.cdp_command("Page.captureScreenshot", cdp_params, timeout=10.0)
    data = result.get("result", {}).get("data", "")
    if not data:
        raise RuntimeError("Screenshot returned no data")
    return data


async def cdp_resolve_selector(pty: PtySession, selector: str) -> dict | None:
    """Resolve a selector (CSS / text= / role= / label=) to a bbox + objectId via CDP.

    Returns dict with keys: objectId, cx, cy, width, height — or None on failure.
    """
    object_id: str | None = None

    if selector.startswith("role="):
        # Use Accessibility.queryAXTree to match both implicit and explicit roles.
        role_part = selector[5:]
        m = re.match(r'^(\w+)(?:\[name="([^"]+)"\])?$', role_part)
        role = m.group(1) if m else role_part
        name = m.group(2) if m else None
        try:
            await pty.cdp_command("Accessibility.enable")
            doc_r = await pty.cdp_command("DOM.getDocument", timeout=5.0)
            backend_id = doc_r.get("result", {}).get("root", {}).get("backendNodeId")
            ax_params: dict[str, Any] = {
                "backendNodeId": backend_id,
                "role": role,
            }
            if name:
                ax_params["accessibleName"] = name
            ax_r = await pty.cdp_command(
                "Accessibility.queryAXTree", ax_params, timeout=5.0
            )
            await pty.cdp_command("Accessibility.disable")
        except Exception:
            return None
        nodes = ax_r.get("result", {}).get("nodes", [])
        matched = next(
            (n for n in nodes if not n.get("ignored") and n.get("backendDOMNodeId")),
            None,
        )
        if not matched:
            return None
        resolve_r = await pty.cdp_command(
            "DOM.resolveNode",
            {"backendNodeId": matched["backendDOMNodeId"]},
            timeout=5.0,
        )
        object_id = resolve_r.get("result", {}).get("object", {}).get("objectId")
    else:
        # text=, label=, CSS — resolve via Runtime.evaluate
        if selector.startswith("text="):
            js = RESOLVE_TEXT_JS.replace("%%TEXT%%", json.dumps(selector[5:]))
        elif selector.startswith("label="):
            js = RESOLVE_LABEL_JS.replace("%%LABEL%%", json.dumps(selector[6:]))
        else:
            js = f"document.querySelector({json.dumps(selector)})"

        eval_r = await pty.cdp_command(
            "Runtime.evaluate",
            {"expression": js, "returnByValue": False},
            timeout=5.0,
        )
        object_id = eval_r.get("result", {}).get("result", {}).get("objectId")

    if not object_id:
        return None

    # Get bounding rect
    bbox_r = await pty.cdp_command(
        "Runtime.callFunctionOn",
        {
            "objectId": object_id,
            "functionDeclaration": (
                "function(){var r=this.getBoundingClientRect();"
                "return {x:r.x,y:r.y,width:r.width,height:r.height,"
                "cx:r.x+r.width/2,cy:r.y+r.height/2};}"
            ),
            "returnByValue": True,
        },
        timeout=5.0,
    )
    bbox = bbox_r.get("result", {}).get("result", {}).get("value")
    if not bbox:
        return None
    return {"objectId": object_id, **bbox}


async def cdp_settle_and_tree(pty: PtySession, max_depth: int = 4) -> dict:
    """After a mutation, wait briefly then capture tree + current URL."""
    await asyncio.sleep(0.5)
    try:
        url_r = await pty.cdp_command(
            "Runtime.evaluate",
            {"expression": "location.href", "returnByValue": True},
            timeout=3.0,
        )
        url = url_r.get("result", {}).get("result", {}).get("value", "?")
    except Exception:
        url = "?"

    try:
        await pty.cdp_command("Accessibility.enable")
        tree_r = await pty.cdp_command(
            "Accessibility.getFullAXTree", {"depth": max_depth + 4}, timeout=8.0
        )
        await pty.cdp_command("Accessibility.disable")
        nodes = tree_r.get("result", {}).get("nodes", [])
        tree_text, node_count = format_ax_tree(nodes, max_depth)
    except Exception:
        tree_text, node_count = "", 0

    return {"url": url, "tree": tree_text, "nodeCount": node_count, "settleMs": 500}
