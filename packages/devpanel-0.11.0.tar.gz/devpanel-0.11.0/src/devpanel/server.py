"""DevPanel daemon: aiohttp server with per-tab PTY sessions + HTTP context stack."""

from __future__ import annotations

import atexit
import asyncio
import json
import os
import re
import time
from pathlib import Path
from typing import Any

import aiohttp
from aiohttp import web, WSMsgType

import devpanel.session as _sess
from devpanel.session import (
    PtySession,
    McpSession,
    SPILL_DIR,
    LOCK_FILE,
    SPILL_MAX_AGE,
    IDLE_TIMEOUT,
    MAX_SESSIONS,
    MCP_IDLE_TIMEOUT,
    MCP_SWEEP_INTERVAL,
    SELECTOR_BUILDER_JS,
    INSPECT_HIGHLIGHT_CONFIG,
    spill_item,
    item_summary,
    format_for_channel,
    format_for_agent,
    pick_active_mcp,
)
from devpanel.mcp import (
    dispatch as mcp_dispatch,
    _get_viewport_line as get_viewport_line,
)


# --- Lifecycle ---


def _startup_cleanup() -> None:
    """Clean up stale state from a previous daemon that didn't exit cleanly."""
    if LOCK_FILE.exists():
        try:
            lock = json.loads(LOCK_FILE.read_text())
            pid = lock.get("pid")
            if pid and _pid_alive(pid):
                return  # Another daemon is running, don't clean up
        except (json.JSONDecodeError, OSError):
            pass
        LOCK_FILE.unlink(missing_ok=True)

    # Clean old spill files
    if SPILL_DIR.exists():
        now = time.time()
        for f in SPILL_DIR.iterdir():
            if f.name == "daemon.lock":
                continue
            try:
                if now - f.stat().st_mtime > SPILL_MAX_AGE:
                    f.unlink()
            except OSError:
                pass


def _write_lock(port: int) -> None:
    """Write lock file with current PID and port."""
    SPILL_DIR.mkdir(parents=True, exist_ok=True)
    LOCK_FILE.write_text(
        json.dumps(
            {
                "pid": os.getpid(),
                "port": port,
                "started_at": time.time(),
            }
        )
    )


def _remove_lock() -> None:
    """Remove lock file (best-effort)."""
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


# --- Session registry ---

_sessions: dict[str, PtySession] = {}
_sessions_lock = asyncio.Lock()
_daemon_idle_handle: asyncio.TimerHandle | None = None


def _check_daemon_idle() -> None:
    """Start/cancel daemon idle timer based on session count."""
    global _daemon_idle_handle
    if _sessions:
        if _daemon_idle_handle:
            _daemon_idle_handle.cancel()
            _daemon_idle_handle = None
        return
    if _daemon_idle_handle:
        return  # already ticking

    def _idle_exit():
        _remove_lock()
        os._exit(0)

    loop = asyncio.get_running_loop()
    _daemon_idle_handle = loop.call_later(IDLE_TIMEOUT, _idle_exit)


def _sweep_mcp() -> None:
    """Reap MCP sessions with no POST/GET activity in MCP_IDLE_TIMEOUT.

    Re-arms itself every MCP_SWEEP_INTERVAL seconds. Closes idle sessions via
    queue sentinel; the SSE loop exits cleanly.
    """
    now = time.monotonic()
    for pty_session in _sessions.values():
        for sid, mcp in list(pty_session.mcp_sessions.items()):
            if now - mcp.last_active > MCP_IDLE_TIMEOUT:
                mcp.close()
                pty_session.mcp_sessions.pop(sid, None)
    loop = asyncio.get_running_loop()
    loop.call_later(MCP_SWEEP_INTERVAL, _sweep_mcp)


# --- HTTP handlers: context stack ---


async def handle_stack_push(request: web.Request) -> web.Response:
    """Stage a context item. Always stores — never pushes to channel.

    Channel delivery is explicit via POST /stack/flush.
    """
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    body = await request.json()
    item = spill_item(body)
    async with session.stack_lock:
        session._stack_seq += 1
        item["_seq"] = session._stack_seq
        session.stack.append(item)
    summary = item_summary(item)
    await session.broadcast(
        {"type": "stack-updated", "size": len(session.stack), "summary": summary}
    )
    return web.json_response({"ok": True, "size": len(session.stack)})


async def handle_stack(request: web.Request) -> web.Response:
    """Drain or peek the delivery queue.

    GET /stack?session=X            → drain: return all pending items, clear queue.
                                       Hook fallback for non-channel MCP clients.
    GET /stack?session=X&peek=true  → peek for UI; returns queue contents as JSON.
    """
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        # Return empty for unknown sessions (hook might fire after session ends)
        if request.query.get("peek") == "true":
            return web.json_response([])
        return web.Response(text="", content_type="text/plain")

    session = _sessions[session_id]
    peek = request.query.get("peek") == "true"
    async with session.stack_lock:
        items = list(session.stack)
        if not peek:
            session.stack.clear()

    if peek:
        return web.json_response(items)

    if items:
        await session.broadcast({"type": "stack-updated", "size": 0})

    # Prepend viewport state for agent context
    parts: list[str] = []
    vp = await get_viewport_line(session)
    if vp:
        parts.append(vp)
    agent_text = format_for_agent(items)
    if agent_text:
        parts.append(agent_text)
    return web.Response(text="\n\n".join(parts), content_type="text/plain")


async def handle_stack_flush(request: web.Request) -> web.Response:
    """Flush staged items as a single batch channel notification."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    async with session.stack_lock:
        items = list(session.stack)
        if not items:
            return web.json_response({"ok": True, "flushed": 0})
        session.stack.clear()
    mcp = pick_active_mcp(session)
    if mcp:
        lines = [format_for_channel(i) for i in items]
        if len(lines) == 1:
            mcp.push_channel(lines[0])
        else:
            mcp.push_channel(
                f"Browser context ({len(lines)} items):\n"
                + "\n".join(f"• {line}" for line in lines)
            )
    await session.broadcast({"type": "stack-updated", "size": 0})
    return web.json_response({"ok": True, "flushed": len(items)})


# --- Spill file serving ---


async def handle_spill_serve(request: web.Request) -> web.StreamResponse:
    """GET /spill/{name} — serve a spill file by basename.
    Panel uses this to load screenshot previews; chrome-extension origin
    can't read /run/user/... paths directly."""
    name = request.match_info["name"]
    if not re.fullmatch(r"[a-z_]+-[0-9a-f]{8}\.(png|json|html)", name):
        return web.Response(status=400, text="Invalid filename")
    path = SPILL_DIR / name
    if not path.exists():
        return web.Response(status=404)
    return web.FileResponse(path)


# --- ADB remote target support ---


async def handle_inspect_start(request: web.Request) -> web.Response:
    """POST /inspect/start?session=X — start remote element picker.

    Sends Overlay.setInspectMode via daemon CDP WebSocket.
    Waits up to 60 s for the user to click an element.
    Returns {selector, url} on success.
    """
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    if not session.cdp_ws:
        return web.json_response(
            {"error": "No CDP WebSocket — not a remote target"}, status=409
        )

    loop = asyncio.get_running_loop()
    fut: asyncio.Future[dict] = loop.create_future()
    session._inspect_future = fut

    try:
        await session.cdp_command("DOM.enable")
        await session.cdp_command("Overlay.enable")
        await session.cdp_command(
            "Overlay.setInspectMode",
            {
                "mode": "searchForNode",
                "highlightConfig": INSPECT_HIGHLIGHT_CONFIG,
            },
        )

        # Wait for user click (Overlay.inspectNodeRequested event)
        params = await asyncio.wait_for(fut, timeout=60.0)
        backend_node_id = params.get("backendNodeId")

        # Disable overlay
        await session.cdp_command(
            "Overlay.setInspectMode", {"mode": "none", "highlightConfig": {}}
        )

        # Resolve backendNodeId → objectId
        resolve_r = await session.cdp_command(
            "DOM.resolveNode", {"backendNodeId": backend_node_id}
        )
        object_id = resolve_r.get("result", {}).get("object", {}).get("objectId")
        if not object_id:
            return web.json_response(
                {"error": "Could not resolve node to objectId"}, status=500
            )

        # Build selector + capture url
        call_r = await session.cdp_command(
            "Runtime.callFunctionOn",
            {
                "objectId": object_id,
                "functionDeclaration": f"function() {{ return {{ selector: {SELECTOR_BUILDER_JS.strip()}, url: location.href }}; }}",
                "returnByValue": True,
            },
        )
        value = call_r.get("result", {}).get("result", {}).get("value")
        if not value:
            return web.json_response({"error": "Could not build selector"}, status=500)

        await session.cdp_command("Overlay.disable")
        await session.cdp_command("DOM.disable")

        return web.json_response(
            {
                "ok": True,
                "selector": value.get("selector", ""),
                "url": value.get("url", ""),
            }
        )

    except asyncio.TimeoutError:
        return web.json_response({"error": "Inspect timed out (60s)"}, status=408)
    except asyncio.CancelledError:
        return web.json_response({"error": "Inspect cancelled"}, status=409)
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)
    finally:
        session._inspect_future = None
        # Best-effort cleanup
        try:
            if session.cdp_ws:
                await session.cdp_command(
                    "Overlay.setInspectMode", {"mode": "none", "highlightConfig": {}}
                )
        except Exception:
            pass


async def handle_inspect_stop(request: web.Request) -> web.Response:
    """POST /inspect/stop?session=X — cancel an in-progress remote element picker."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    if session._inspect_future and not session._inspect_future.done():
        session._inspect_future.cancel()
    try:
        if session.cdp_ws:
            await session.cdp_command(
                "Overlay.setInspectMode", {"mode": "none", "highlightConfig": {}}
            )
    except Exception:
        pass
    return web.json_response({"ok": True})


async def handle_adb_setup(request: web.Request) -> web.Response:
    """POST /adb — CLI tells daemon which CDP port ADB is forwarded on."""
    body = await request.json()
    cdp_port = body.get("cdp_port")
    serial = body.get("serial", "")
    if not isinstance(cdp_port, int) or cdp_port <= 0:
        return web.json_response({"error": "cdp_port required"}, status=400)
    _sess.adb_state = {"cdp_port": cdp_port, "serial": serial}
    return web.json_response({"ok": True, "cdp_port": cdp_port, "serial": serial})


async def handle_safari_setup(request: web.Request) -> web.Response:
    """POST /safari — register safarictl API URL for iOS target."""
    body = await request.json()
    url = (body.get("url") or "").rstrip("/")
    if not url:
        return web.json_response({"error": "url required"}, status=400)
    # Probe: verify safarictl is running
    try:
        async with aiohttp.ClientSession() as http:
            resp = await http.get(
                f"{url}/viewport", timeout=aiohttp.ClientTimeout(total=5)
            )
            vp = await resp.json()
    except Exception as e:
        return web.json_response(
            {"error": f"Cannot reach safarictl at {url}: {e}"}, status=502
        )
    _sess.safari_state = {"url": url}
    # Attach to any existing sessions
    for session in _sessions.values():
        session.safari_url = url
        session.safari_viewport = vp
    return web.json_response({"ok": True, "url": url, "viewport": vp})


async def _probe_and_attach_cdp(
    session: PtySession, cdp_port: int, url: str = ""
) -> dict:
    """Discover targets via browser-level CDP and attach to a page.

    Android Chrome doesn't expose page targets via /json — we must connect to
    the browser WebSocket and use Target.getTargets() + Target.attachToTarget()
    with flatten=true for a multiplexed session.

    Returns {"ok": True, "target": ..., "ws_url": ...} on success.
    Raises RuntimeError on failure.
    """
    browser_ws_url = f"ws://127.0.0.1:{cdp_port}/devtools/browser"

    # Connect to browser-level WebSocket and discover targets
    try:
        http = aiohttp.ClientSession()
        browser_ws = await http.ws_connect(browser_ws_url)
    except Exception as e:
        await http.close()
        raise RuntimeError(f"Failed to connect to browser WS on port {cdp_port}: {e}")

    try:
        await browser_ws.send_json(
            {"id": 1, "method": "Target.getTargets", "params": {}}
        )
        resp = await asyncio.wait_for(browser_ws.receive_json(), timeout=5.0)
        targets: list[dict] = resp.get("result", {}).get("targetInfos", [])
        pages = [t for t in targets if t.get("type") == "page"]

        # Match by URL
        match: dict | None = None
        for target in pages:
            target_url = target.get("url", "")
            if target_url == url or (url and target_url.startswith(url.rstrip("/"))):
                match = target
                break
        # Fallback: first non-about page
        if not match:
            for target in pages:
                if not target.get("url", "").startswith("about:"):
                    match = target
                    break
        if not match:
            raise RuntimeError(
                f"No page targets found for {url!r} among {len(pages)} pages"
            )

        # Attach to the target with flatten=true for multiplexed session
        await browser_ws.send_json(
            {
                "id": 2,
                "method": "Target.attachToTarget",
                "params": {"targetId": match["targetId"], "flatten": True},
            }
        )
        # Chrome sends Target.attachedToTarget event first (params.sessionId),
        # then the response (result.sessionId). Read until we get a sessionId.
        target_session_id: str | None = None
        for _ in range(5):
            msg = await asyncio.wait_for(browser_ws.receive_json(), timeout=5.0)
            sid = msg.get("result", {}).get("sessionId") or msg.get("params", {}).get(
                "sessionId"
            )
            if sid:
                target_session_id = sid
                break
        if not target_session_id:
            raise RuntimeError("Target.attachToTarget returned no sessionId")

    except RuntimeError:
        await browser_ws.close()
        await http.close()
        raise
    except Exception as e:
        await browser_ws.close()
        await http.close()
        raise RuntimeError(f"CDP target discovery failed: {e}")

    # Hand the browser WS to the session — it now owns the connection
    # (don't close http/browser_ws here — session takes ownership directly)
    await session.detach_cdp()
    session._cdp_http_session = http
    session.cdp_ws = browser_ws
    session.cdp_url = browser_ws_url
    session._cdp_session_id = target_session_id
    session._cdp_reader_task = asyncio.create_task(session._cdp_read_loop())

    await session.cdp_command("Page.enable")
    await session.cdp_command("Runtime.enable")
    await session.cdp_command("Audits.enable")
    return {
        "ok": True,
        "target": match.get("title", ""),
        "ws_url": browser_ws_url,
    }


async def _auto_attach_cdp(session: PtySession, cdp_port: int) -> None:
    """Background task: auto-attach CDP when WS session is created for a remote target."""
    try:
        await _probe_and_attach_cdp(session, cdp_port)
    except Exception:
        pass  # Best-effort — panel can retry via POST /remote


async def handle_remote_attach(request: web.Request) -> web.Response:
    """POST /remote — panel reports that the inspected window is a remote target.

    Body: {"url": "https://...", "session_id": "..."}
    Daemon probes localhost:{cdp_port}/json, finds the matching page,
    and attaches a CDP WebSocket to the PtySession.
    """
    if not _sess.adb_state:
        return web.json_response(
            {"error": "No ADB port configured — run `devpanel adb` first"}, status=409
        )
    body = await request.json()
    url = body.get("url", "")
    session_id = body.get("session_id")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    try:
        result = await _probe_and_attach_cdp(
            _sessions[session_id], _sess.adb_state["cdp_port"], url
        )
    except RuntimeError as e:
        return web.json_response({"error": str(e)}, status=502)
    return web.json_response(result)


async def handle_screenshot(request: web.Request) -> web.Response:
    """POST /screenshot?session=X — capture screenshot via daemon CDP or ADB.

    Optional JSON body: {"selector": "...", "device": true}.
    device=true uses ADB screencap (full device screen).
    Returns {"ok": true, "data": "<base64 PNG>"}.
    """
    from devpanel.mcp import cdp_screenshot, adb_screenshot

    try:
        body = await request.json()
    except Exception:
        body = {}

    if body.get("device"):
        if not _sess.adb_state:
            return web.json_response(
                {"error": "No ADB device — run `devpanel adb` first"}, status=409
            )
        try:
            data = await adb_screenshot(_sess.adb_state["serial"])
        except asyncio.TimeoutError:
            return web.json_response({"error": "ADB screencap timed out"}, status=504)
        except RuntimeError as e:
            return web.json_response({"error": str(e)}, status=500)
        return web.json_response({"ok": True, "data": data})

    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    if not session.cdp_ws:
        return web.json_response(
            {"error": "No CDP WebSocket — not a remote target"}, status=409
        )
    try:
        data = await cdp_screenshot(session, body.get("selector"))
    except asyncio.TimeoutError:
        return web.json_response({"error": "Screenshot timed out"}, status=504)
    except RuntimeError as e:
        return web.json_response({"error": str(e)}, status=500)
    return web.json_response({"ok": True, "data": data})


# --- Controls (dev endpoint) ---

_start_time = time.time()


def _package_version() -> str:
    """Read the installed devpanel package version. Empty string on failure
    (e.g. running from a source tree without metadata)."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("devpanel")
    except (ImportError, PackageNotFoundError):
        return ""


async def handle_controls(request: web.Request) -> web.Response:
    sessions_info = {}
    for sid, s in _sessions.items():
        sessions_info[sid] = {
            "pty_pid": s.process.pid if s.process else None,
            "pty_alive": s.alive,
            "clients": len(s.clients),
            "stack_size": len(s.stack),
            "mcp_sessions": len(s.mcp_sessions),
            "async_tasks": len(s.async_tasks),
            "watchers": len(s.watchers),
            "cdp_connected": s.cdp_ws is not None,
            "cdp_url": s.cdp_url,
            "safari_url": s.safari_url,
        }
    repld_socket = os.environ.get("REPLD_SOCKET") or str(
        Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "devpanel" / "repld.sock"
    )
    info: dict[str, Any] = {
        "port": request.app.get("port"),
        "version": _package_version(),
        "sessions": sessions_info,
        "session_count": len(_sessions),
        "uptime": round(time.time() - _start_time, 1),
        "spill_dir": str(SPILL_DIR),
        "repld_socket": repld_socket if Path(repld_socket).exists() else None,
    }
    if _sess.adb_state:
        info["adb"] = {
            "serial": _sess.adb_state["serial"],
            "cdp_port": _sess.adb_state["cdp_port"],
        }
    if _sess.safari_state:
        info["safari"] = {"url": _sess.safari_state["url"]}
    return web.json_response(info)


# --- PTY WebSocket (session routing) ---


async def handle_ws(request: web.Request) -> web.WebSocketResponse:
    tab = request.query.get("tab")
    if not tab:
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        await ws.send_bytes(b"\x1b[31mMissing ?tab= parameter\x1b[0m\r\n")
        await ws.close()
        return ws

    port = request.app["port"]

    cwd = request.query.get("cwd")
    remote = request.query.get("remote") == "1"

    async with _sessions_lock:
        session = _sessions.get(tab)
        if not session:
            # Evict oldest sessions if at capacity
            while len(_sessions) >= MAX_SESSIONS:
                oldest_id = next(iter(_sessions))
                oldest = _sessions.pop(oldest_id)
                await oldest.shutdown()
            session = PtySession(tab)
            session._on_exit = lambda sid: (
                _sessions.pop(sid, None),
                _check_daemon_idle(),
            )
            _sessions[tab] = session
            await session.start(port, cwd=cwd)
            _check_daemon_idle()
            # Auto-attach CDP for remote (ADB) targets
            if remote and _sess.adb_state and not session.cdp_ws:
                asyncio.create_task(
                    _auto_attach_cdp(session, _sess.adb_state["cdp_port"])
                )
            # Auto-attach Safari (iOS) target
            if _sess.safari_state and not session.safari_url:
                session.safari_url = _sess.safari_state["url"]

    if not session.alive:
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        await ws.send_bytes(b"\x1b[31mPTY process has exited.\x1b[0m\r\n")
        await ws.close()
        return ws

    ws = web.WebSocketResponse()
    await ws.prepare(request)
    await session.attach(ws)

    try:
        async for msg in ws:
            if msg.type == WSMsgType.BINARY:
                session.write(msg.data)
            elif msg.type == WSMsgType.TEXT:
                try:
                    ctrl: dict[str, Any] = json.loads(msg.data)
                    if "cmd" not in ctrl and "id" in ctrl:
                        # Command response from panel
                        rid = ctrl["id"]
                        future = session.pending_commands.pop(rid, None)
                        if future and not future.done():
                            future.set_result(ctrl)
                    elif ctrl.get("type") == "resize":
                        session.resize(int(ctrl["cols"]), int(ctrl["rows"]))
                except (json.JSONDecodeError, KeyError):
                    pass
            elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                break
    except Exception:
        pass
    finally:
        session.detach(ws)

    return ws


# --- MCP Streamable HTTP ---


async def handle_channel_push(request: web.Request) -> web.Response:
    """POST /channel — push a channel notification to the active MCP session."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404)
    pty = _sessions[session_id]
    body = await request.json()
    content = body.get("content", "")
    mcp = pick_active_mcp(pty)
    if mcp:
        mcp.push_channel(content)
    return web.json_response({"ok": True})


async def handle_mcp_post(request: web.Request) -> web.Response:
    """POST /mcp — JSON-RPC request → JSON response."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404, text="unknown session")
    pty = _sessions[session_id]

    body = await request.json()
    mcp_sid = request.headers.get("Mcp-Session-Id")

    # Route to existing MCP session or create on initialize
    if mcp_sid and mcp_sid in pty.mcp_sessions:
        mcp = pty.mcp_sessions[mcp_sid]
    elif body.get("method") == "initialize":
        mcp = McpSession()
        pty.mcp_sessions[mcp.session_id] = mcp
    else:
        return web.Response(status=400, text="missing or invalid Mcp-Session-Id")

    mcp.touch()
    result = await mcp_dispatch(body, mcp, pty)

    if result is None:
        return web.Response(status=202)

    resp = web.json_response(result)
    if body.get("method") == "initialize":
        resp.headers["Mcp-Session-Id"] = mcp.session_id
    return resp


async def handle_mcp_sse(request: web.Request) -> web.StreamResponse:
    """GET /mcp — SSE stream for server-pushed channel notifications."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404, text="unknown session")
    pty = _sessions[session_id]

    mcp_sid = request.headers.get("Mcp-Session-Id")
    if not mcp_sid or mcp_sid not in pty.mcp_sessions:
        return web.Response(status=400, text="missing or invalid Mcp-Session-Id")
    mcp = pty.mcp_sessions[mcp_sid]
    mcp.touch()

    resp = web.StreamResponse(
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )
    await resp.prepare(request)

    try:
        while True:
            msg = await mcp.queue.get()
            if msg is None:
                break
            data = json.dumps(msg)
            try:
                await resp.write(f"event: message\ndata: {data}\n\n".encode())
            except (ConnectionResetError, ConnectionError):
                # TCP died mid-flush — re-enqueue so the next reconnecting
                # GET picks it up. Sentinel never reaches here (handled above).
                mcp.queue.put_nowait(msg)
                break
    except asyncio.CancelledError:
        pass

    return resp


async def handle_mcp_delete(request: web.Request) -> web.Response:
    """DELETE /mcp — terminate MCP session."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404)
    pty = _sessions[session_id]

    mcp_sid = request.headers.get("Mcp-Session-Id")
    if mcp_sid and mcp_sid in pty.mcp_sessions:
        mcp = pty.mcp_sessions.pop(mcp_sid)
        mcp.close()
    # Broadcast mcp-status: active only if there are remaining initialized sessions
    active = any(m.initialized for m in pty.mcp_sessions.values())
    asyncio.create_task(pty.broadcast({"type": "mcp-status", "active": active}))
    return web.Response(status=204)


# --- CORS middleware ---


@web.middleware
async def cors_middleware(request: web.Request, handler: Any) -> web.StreamResponse:
    if request.method == "OPTIONS":
        resp = web.Response()
    else:
        resp = await handler(request)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Mcp-Session-Id"
    resp.headers["Access-Control-Expose-Headers"] = "Mcp-Session-Id"
    return resp


async def handle_directories(request: web.Request) -> web.Response:
    """GET /directories — return hostname→path mappings from config.
    PUT /directories — update mappings."""
    from devpanel.install import read_config, _config_dir

    if request.method == "PUT":
        body = await request.json()
        config_file = _config_dir() / "config.json"
        config = read_config()
        config["directories"] = body
        _config_dir().mkdir(parents=True, exist_ok=True)
        config_file.write_text(json.dumps(config, indent=2))
        return web.json_response(body)

    config = read_config()
    return web.json_response(config.get("directories", {}))


# --- App factory ---


async def _on_cleanup(_app: web.Application) -> None:
    from devpanel.safari import close_http

    await close_http()


def create_app() -> web.Application:
    app = web.Application(middlewares=[cors_middleware])
    app.on_cleanup.append(_on_cleanup)
    app.router.add_get("/ws", handle_ws)
    app.router.add_post("/stack", handle_stack_push)
    app.router.add_post("/stack/flush", handle_stack_flush)
    app.router.add_get("/stack", handle_stack)
    app.router.add_post("/channel", handle_channel_push)
    app.router.add_post("/mcp", handle_mcp_post)
    app.router.add_get("/mcp", handle_mcp_sse)
    app.router.add_delete("/mcp", handle_mcp_delete)
    app.router.add_get("/controls", handle_controls)
    app.router.add_get("/directories", handle_directories)
    app.router.add_put("/directories", handle_directories)
    app.router.add_get("/spill/{name}", handle_spill_serve)
    app.router.add_post("/screenshot", handle_screenshot)
    app.router.add_post("/adb", handle_adb_setup)
    app.router.add_post("/safari", handle_safari_setup)
    app.router.add_post("/remote", handle_remote_attach)
    app.router.add_post("/inspect/start", handle_inspect_start)
    app.router.add_post("/inspect/stop", handle_inspect_stop)
    return app


async def run(port: int = 0) -> int:
    """Start the server. Sessions created on-demand via /ws. Returns actual port."""
    _startup_cleanup()

    app = create_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    actual_port = site._server.sockets[0].getsockname()[1]  # type: ignore[union-attr]
    app["port"] = actual_port

    _write_lock(actual_port)
    atexit.register(_remove_lock)
    _check_daemon_idle()  # start idle timer (no sessions yet)
    asyncio.get_running_loop().call_later(MCP_SWEEP_INTERVAL, _sweep_mcp)

    return actual_port
