"""Accessibility tree formatting for DevPanel.

Pure functions — no deps on session, server, or mcp modules.
Formats CDP Accessibility.getFullAXTree output into agent-readable text.
"""

from __future__ import annotations

_SKIP_ROLES = frozenset(
    {
        "none",
        "presentation",
        "generic",
        "group",
        "InlineTextBox",
        "LineBreak",
        "StaticText",
        "paragraph",
        "list",
        "listitem",
        "ignoredNode",
        "SvgRoot",
        "RootWebArea",  # emitted by formatTree recursion — skip the root itself
    }
)

_LANDMARK_ROLES = frozenset(
    {
        "main",
        "navigation",
        "header",
        "footer",
        "aside",
        "section",
        "form",
        "dialog",
        "alert",
        "alertdialog",
        "region",
        "complementary",
        "banner",
        "contentinfo",
        "search",
        "article",
        "table",
        "row",
        "rowgroup",
        "columnheader",
        "rowheader",
        "cell",
        "grid",
        "gridcell",
        "tree",
        "treeitem",
        "tablist",
        "tabpanel",
        "menu",
        "menubar",
        "toolbar",
        "status",
        "progressbar",
    }
)

_INTERACTIVE_ROLES = frozenset(
    {
        "button",
        "link",
        "textbox",
        "searchbox",
        "combobox",
        "listbox",
        "option",
        "checkbox",
        "radio",
        "switch",
        "slider",
        "spinbutton",
        "scrollbar",
        "tab",
        "menuitem",
        "menuitemcheckbox",
        "menuitemradio",
        "img",
    }
)


def _get_props(node: dict) -> dict:
    p = {}
    for prop in node.get("properties") or []:
        p[prop["name"]] = prop.get("value", {}).get("value")
    return p


def _count_interactive(by_id: dict, node_id: str, depth: int = 0) -> dict:
    if depth > 20:
        return {"fields": 0, "buttons": 0, "links": 0}
    node = by_id.get(node_id)
    if not node:
        return {"fields": 0, "buttons": 0, "links": 0}
    role = (node.get("role") or {}).get("value", "")
    counts = {"fields": 0, "buttons": 0, "links": 0}
    field_roles = {
        "textbox",
        "searchbox",
        "combobox",
        "spinbutton",
        "slider",
        "checkbox",
        "radio",
        "switch",
    }
    if role in field_roles:
        counts["fields"] += 1
    if role == "button":
        counts["buttons"] += 1
    if role == "link":
        counts["links"] += 1
    for cid in node.get("childIds") or []:
        c = _count_interactive(by_id, cid, depth + 1)
        counts["fields"] += c["fields"]
        counts["buttons"] += c["buttons"]
        counts["links"] += c["links"]
    return counts


def _summarize(counts: dict) -> str:
    parts = []
    if counts["fields"]:
        parts.append(f"{counts['fields']} fields")
    if counts["buttons"]:
        parts.append(f"{counts['buttons']} buttons")
    if counts["links"]:
        parts.append(f"{counts['links']} links")
    return f" ({', '.join(parts)})" if parts else ""


def _format_node(
    by_id: dict, node_id: str, depth: int, max_depth: int, out: list[str]
) -> int:
    if depth > max_depth:
        return 0
    node = by_id.get(node_id)
    if not node:
        return 0

    role = (node.get("role") or {}).get("value", "")
    name = (node.get("name") or {}).get("value", "")
    indent = "  " * depth

    if role in _SKIP_ROLES:
        count = 0
        for cid in node.get("childIds") or []:
            count += _format_node(by_id, cid, depth, max_depth, out)
        return count

    if role in _LANDMARK_ROLES or role == "heading":
        trunc = name[:47] + "..." if len(name) > 50 else name
        props = _get_props(node)
        line = f"{indent}{role}"
        if trunc:
            line += f" '{trunc}'"
        states = []
        if props.get("modal"):
            states.append("modal")
        if props.get("expanded") is True:
            states.append("expanded")
        if props.get("disabled") is True:
            states.append("disabled")
        if states:
            line += f" [{', '.join(states)}]"
        if depth >= max_depth - 1:
            line += _summarize(_count_interactive(by_id, node_id))
        out.append(line)
        count = 1
        if depth < max_depth - 1:
            for cid in node.get("childIds") or []:
                count += _format_node(by_id, cid, depth + 1, max_depth, out)
        return count

    if role in _INTERACTIVE_ROLES:
        trunc = name[:47] + "..." if len(name) > 50 else name
        props = _get_props(node)
        line = f"{indent}{role}"
        if trunc:
            line += f" '{trunc}'"
        val = (node.get("value") or {}).get("value")
        if val is not None:
            v = str(val)
            line += f' = "{v[:27] + "..." if len(v) > 30 else v}"'
        states = []
        if props.get("focused"):
            states.append("focused")
        if props.get("required"):
            states.append("required")
        if props.get("disabled") is True:
            states.append("disabled")
        if props.get("checked") is True:
            states.append("checked")
        if props.get("selected") is True:
            states.append("selected")
        if props.get("expanded") is True:
            states.append("expanded")
        if states:
            line += f" [{', '.join(states)}]"
        out.append(line)
        return 1

    count = 0
    for cid in node.get("childIds") or []:
        count += _format_node(by_id, cid, depth, max_depth, out)
    return count


def format_ax_tree(nodes: list[dict], max_depth: int = 4) -> tuple[str, int]:
    """Format a list of AX nodes (from Accessibility.getFullAXTree) into readable text."""
    if not nodes:
        return "(empty tree)", 0
    by_id = {n["nodeId"]: n for n in nodes}
    all_child_ids: set[str] = set()
    for n in nodes:
        all_child_ids.update(n.get("childIds") or [])
    roots = [n for n in nodes if n["nodeId"] not in all_child_ids]
    root_id = roots[0]["nodeId"] if roots else nodes[0]["nodeId"]
    # Start one level in to skip RootWebArea itself
    root = by_id.get(root_id)
    start_ids = root.get("childIds") or [root_id] if root else [root_id]
    lines: list[str] = []
    count = 0
    for sid in start_ids:
        count += _format_node(by_id, sid, 0, max_depth, lines)
    return "\n".join(lines), count
