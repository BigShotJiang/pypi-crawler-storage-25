"""Hand-rolled MCP JSON-RPC dispatcher for DevPanel.

Streamable HTTP transport: POST /mcp for requests, GET /mcp for SSE notifications.
No SDK dependency — minimal JSON-RPC over aiohttp.
"""

from __future__ import annotations

import asyncio
import base64
import json
from collections.abc import Awaitable, Callable
from typing import Any

from devpanel.safari import safari_eval
from devpanel.session import (
    AsyncTask,
    McpSession,
    PtySession,
    format_for_agent,
    spill,
    spill_large_text,
)
from devpanel.target import (
    ElementNotFound,
    MutationResult,
    NotSupported,
    PanelBackend,
    TargetError,
    get_backend,
)


PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "devpanel"
SERVER_VERSION = "0.10.1"

TOOLS = [
    {
        "name": "context",
        "description": "Get current browser context (selected elements, network captures, screenshots). Does not clear the stack.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "drain",
        "description": "Drain browser context stack. Returns formatted text and clears the stack.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "js",
        "description": (
            "Evaluate JavaScript in the inspected tab. For data extraction, DOM queries, and automation scripts. "
            "Do NOT use js() to click or type — use the click/type tools with selectors from tree instead. "
            "Returns the result as text. Use var (not let/const) for variables that persist across calls. "
            "_ is the last result, _1/_2/etc for numbered history. "
            "sendChannel(msg) is available in evals to push channel notifications. "
            "defer=true returns immediately with {task_id}; result arrives via channel. "
            "every=N runs code every N seconds; js.cancel(task_id) stops it."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "JavaScript to evaluate in the page",
                },
                "defer": {
                    "type": "boolean",
                    "description": "Run asynchronously; returns task_id immediately, result via channel",
                },
                "every": {
                    "type": "number",
                    "description": "Run every N seconds (>= 1); returns task_id, results via channel",
                },
            },
            "required": ["code"],
        },
    },
    {
        "name": "js.cancel",
        "description": "Cancel a deferred or recurring js task by id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task id returned by js(defer=true) or js(every=N)",
                },
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "screenshot",
        "description": (
            "Capture a screenshot of the inspected tab. "
            "With no args: viewport. With selector: just that element, even if "
            "off-screen (no scrolling, no page mutation). "
            "Returns a base64 PNG. Selectors: CSS, text=, role=, label=."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "selector": {
                    "type": "string",
                    "description": "Element selector to clip to (CSS / text= / role= / label=).",
                },
            },
        },
    },
    {
        "name": "device_screenshot",
        "description": (
            "Capture the full physical device screen via ADB. Includes on-screen keyboard, "
            "status bar, navigation bar — everything visible on the display. "
            "Only available on ADB remote targets. Use when you need to see keyboard state "
            "or non-browser UI. Returns a base64 PNG."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "network",
        "description": (
            "Get recent network requests from the inspected tab. "
            "Returns the last 20 HAR entries by default. "
            "Optional filters: url (substring or glob), method (GET/POST/etc), "
            "status (exact int or range like '4xx'/'5xx'), since (epoch ms)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL substring or glob pattern (e.g. */api/*)",
                },
                "method": {
                    "type": "string",
                    "description": "HTTP method filter (GET, POST, etc)",
                },
                "status": {
                    "type": ["string", "integer"],
                    "description": "Exact status code (e.g. 404) or range (e.g. '4xx')",
                },
                "since": {
                    "type": "number",
                    "description": "Filter by startedDateTime (epoch ms)",
                },
            },
        },
    },
    {
        "name": "issues",
        "description": (
            "Browser-detected page issues: deprecations, breaking changes, form accessibility, "
            "CSP violations. Runs checkFormsIssues() then returns buffered Audits.issueAdded events. "
            "Issues accumulate from page load — call anytime to see current state."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "console",
        "description": (
            "Recent console messages from the inspected page (log/warn/error + exceptions + "
            "browser-level entries like network errors). Errors are also auto-pushed as channel notifications."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "since": {
                    "type": "number",
                    "description": "Filter by timestamp (epoch ms)",
                },
                "level": {
                    "type": "string",
                    "enum": ["debug", "info", "log", "warning", "error"],
                    "description": "Minimum severity level",
                },
            },
        },
    },
    {
        "name": "watch",
        "description": (
            "Watch network requests matching a URL pattern. "
            "Each matching request pushes a channel notification. Returns {watch_id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url_pattern": {
                    "type": "string",
                    "description": "Substring or glob pattern to match against request URLs (e.g. '/api/' or '*/api/*')",
                },
            },
            "required": ["url_pattern"],
        },
    },
    {
        "name": "watch.cancel",
        "description": "Stop a network watcher by id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "watch_id": {
                    "type": "string",
                    "description": "Watch id returned by watch()",
                },
            },
            "required": ["watch_id"],
        },
    },
    {
        "name": "tree",
        "description": (
            "Get the page's accessibility tree. ALWAYS call tree before click/type to discover selectors. "
            "Overview format: landmarks structure the page, interactive elements show values and states "
            "(focused, required, disabled, checked, selected). Collapsed regions show child counts. "
            "Use depth to expand deeper. Use role/name from tree output as selectors for click/type."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "depth": {
                    "type": "integer",
                    "description": "Max display depth (default 4). Increase to expand collapsed regions.",
                }
            },
        },
    },
    {
        "name": "click",
        "description": (
            "Click an element. Call tree first to find the selector. "
            "Settles after network quiet, returns accessibility tree + network delta. "
            'Preferred selectors (from tree output): text=Submit, role=button[name="OK"], label=Email. '
            "CSS selectors (#id, .class) as fallback only."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "Element selector"}
            },
            "required": ["selector"],
        },
    },
    {
        "name": "type",
        "description": (
            "Type text into a field, REPLACING any existing content. Call tree first to find the selector. "
            "The element is focused, its content selected, then text is typed (overwriting the selection). "
            "To append, read the field's current value from tree output and type the concatenation. "
            "Settles after network quiet, returns tree + network delta. "
            'Preferred selectors: role=textbox[name="Email"], label=Email. CSS as fallback.'
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "Element to type into"},
                "text": {
                    "type": "string",
                    "description": "Text to type (replaces existing field content)",
                },
                "press_enter": {
                    "type": "boolean",
                    "description": "Press Enter after typing",
                },
            },
            "required": ["selector", "text"],
        },
    },
    {
        "name": "navigate",
        "description": (
            "Navigate to a URL, or reload/go back/forward. "
            "Returns immediately — page loads asynchronously. "
            "Wait for the channel notification before calling tree, click, or type."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to navigate to"},
                "action": {
                    "type": "string",
                    "enum": ["reload", "back", "forward"],
                    "description": "Navigation action (alternative to url)",
                },
            },
        },
    },
    {
        "name": "viewport",
        "description": (
            "Get or set the browser viewport. No params = get current state. "
            "Set width/height to emulate a device. Use mobile=true for touch + DPR 2. "
            "Use clear=true to reset to real window size. "
            "On physical devices (ADB remote targets), read-only — emulation args are rejected."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "width": {
                    "type": "integer",
                    "description": "Viewport width in CSS pixels",
                },
                "height": {
                    "type": "integer",
                    "description": "Viewport height (0 = auto)",
                },
                "mobile": {
                    "type": "boolean",
                    "description": "Enable mobile emulation (touch, DPR 2)",
                },
                "clear": {
                    "type": "boolean",
                    "description": "Clear emulation, restore real window size",
                },
            },
        },
    },
]


def _result(rid: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def _error(rid: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}


def _resp_error(rid: Any, resp: dict) -> dict | None:
    """Return MCP tool error result if resp contains an error, else None."""
    if "error" in resp:
        return _result(
            rid,
            {
                "content": [{"type": "text", "text": f"Error: {resp['error']}"}],
                "isError": True,
            },
        )
    return None


def _require_panel(rid: Any, pty: PtySession) -> dict | None:
    """Guard: return error if no panel is connected, else None."""
    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")
    return None


_BASE_INSTRUCTIONS = (
    "Interaction workflow: tree → click/type. ALWAYS call tree first to discover "
    "selectors. Use role= or text= selectors from tree output (not CSS, not js DOM queries). "
    "Do NOT use js() to click or type — use the click/type tools.\n\n"
    "Navigate is async — returns immediately. Wait for the channel notification "
    '("Page loaded — ready for interaction") before calling tree/click/type.\n\n'
    "Channel notifications arrive as <channel> blocks — page navigations, console errors, "
    "async task results. These are informational; respond in chat, no tool call needed.\n\n"
    "Tools: tree (page structure), click/type (interact), navigate, viewport, "
    "screenshot, network, console, js (data extraction), watch (network monitor), "
    "context (peek stack), drain (clear stack)."
)


def _build_instructions(pty: PtySession) -> str:
    """Build MCP instructions, adapting for local vs remote (ADB) targets."""
    backend = get_backend(pty)
    header = (
        backend.instructions_header if backend else PanelBackend.instructions_header
    )
    return header + _BASE_INSTRUCTIONS


async def dispatch(req: dict, session: McpSession, pty: PtySession) -> dict | None:
    """Dispatch a JSON-RPC request. Returns response dict or None for notifications."""
    method = req.get("method")
    rid = req.get("id")

    match method:
        case "initialize":
            return _result(
                rid,
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
                    "capabilities": {
                        "tools": {},
                        "experimental": {"claude/channel": {}},
                    },
                    "instructions": _build_instructions(pty),
                },
            )

        case "notifications/initialized":
            session.set_initialized()
            asyncio.create_task(pty.broadcast({"type": "mcp-status", "active": True}))
            return None

        case "tools/list":
            return _result(rid, {"tools": TOOLS})

        case "tools/call":
            return await _tools_call(rid, req.get("params", {}), session, pty)

        case "ping":
            return _result(rid, {})

        case _ if rid is None:
            return None  # unknown notification, ignore

        case _:
            return _error(rid, -32601, f"method not found: {method}")


async def _tools_call(rid: Any, params: dict, mcp: McpSession, pty: PtySession) -> dict:
    name = params.get("name")
    args = params.get("arguments", {})
    match name:
        case "context":
            return await _tool_context(rid, pty)
        case "drain":
            return await _tool_drain(rid, pty)
        case "js":
            return await _tool_js(rid, args, mcp, pty)
        case "js.cancel":
            return await _tool_js_cancel(rid, args, pty)
        case "screenshot":
            return await _tool_screenshot(rid, args, pty)
        case "device_screenshot":
            return await _tool_device_screenshot(rid, pty)
        case "network":
            return await _tool_network(rid, args, pty)
        case "console":
            return await _tool_console(rid, args, pty)
        case "issues":
            return await _tool_issues(rid, pty)
        case "tree":
            return await _tool_tree(rid, args, pty)
        case "click":
            return await _tool_click(rid, args, pty)
        case "type":
            return await _tool_type(rid, args, pty)
        case "navigate":
            return await _tool_navigate(rid, args, pty)
        case "watch":
            return await _tool_watch(rid, args, pty)
        case "watch.cancel":
            return await _tool_watch_cancel(rid, args, pty)
        case "viewport":
            return await _tool_viewport(rid, args, pty)
        case _:
            return _error(rid, -32602, f"unknown tool: {name}")


async def _get_viewport_line(pty: PtySession) -> str:
    """Quick viewport summary via target backend. Returns one-line string or empty."""
    backend = get_backend(pty)
    if backend is None:
        return ""
    return await backend.viewport_line()


async def _tool_context(rid: Any, pty: PtySession) -> dict:
    async with pty.stack_lock:
        items = list(pty.stack)
    parts: list[str] = []
    vp = await _get_viewport_line(pty)
    if vp:
        parts.append(vp)
    agent_text = format_for_agent(items)
    if agent_text:
        parts.append(agent_text)
    text = "\n\n".join(parts) if parts else "No browser context available."
    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_drain(rid: Any, pty: PtySession) -> dict:
    async with pty.stack_lock:
        items = list(pty.stack)
        pty.stack.clear()
    if items:
        await pty.broadcast({"type": "stack-updated", "size": 0})
    parts: list[str] = []
    vp = await _get_viewport_line(pty)
    if vp:
        parts.append(vp)
    agent_text = format_for_agent(items)
    if agent_text:
        parts.append(agent_text)
    text = "\n\n".join(parts) if parts else "Stack is empty."
    return _result(rid, {"content": [{"type": "text", "text": text}]})


def _format_eval_result(resp: dict, prefix: str = "") -> str:
    """Format an eval response into display text (with optional prefix for async tasks)."""
    value = resp.get("result", {}).get("value")
    text = json.dumps(value, indent=2) if value is not None else "undefined"
    text = spill_large_text(text, "eval_result")
    if prefix:
        text = f"{prefix} {text}"
    return text


async def _eval_panel(pty: PtySession, code: str) -> str:
    """Eval via panel command dispatcher. Returns formatted text."""
    resp = await pty.send_command("eval", timeout=30.0, code=pty.wrap_eval(code))
    if "error" in resp:
        raise RuntimeError(resp["error"])
    return _format_eval_result(resp)


async def _eval_safari(pty: PtySession, code: str) -> str:
    """Eval via safarictl HTTP API. Returns formatted text."""
    result = await safari_eval(pty.safari_url, code)
    text = json.dumps(result, indent=2) if result is not None else "undefined"
    return spill_large_text(text, "eval_result")


async def _defer_task(
    task_id: str,
    code: str,
    eval_fn: Callable[[PtySession, str], Awaitable[str]],
    mcp: McpSession,
    pty: PtySession,
) -> None:
    try:
        text = await eval_fn(pty, code)
        mcp.push_channel(f"[{task_id}] {text}")
    except asyncio.CancelledError:
        pass
    except Exception as e:
        mcp.push_channel(f"[{task_id}] Error: {e}")
    finally:
        async with pty.async_tasks_lock:
            pty.async_tasks.pop(task_id, None)


async def _every_task(
    task_id: str,
    code: str,
    interval: int,
    eval_fn: Callable[[PtySession, str], Awaitable[str]],
    mcp: McpSession,
    pty: PtySession,
) -> None:
    try:
        while True:
            await asyncio.sleep(interval)
            try:
                text = await eval_fn(pty, code)
            except Exception as e:
                text = f"Error: {e}"
            mcp.push_channel(f"[{task_id}] {text}")
    except asyncio.CancelledError:
        pass
    finally:
        async with pty.async_tasks_lock:
            pty.async_tasks.pop(task_id, None)


async def _tool_js(rid: Any, args: dict, mcp: McpSession, pty: PtySession) -> dict:
    code = args.get("code", "")
    defer = args.get("defer", False)
    every = args.get("every")

    # Pick eval backend
    eval_fn: Callable[[PtySession, str], Awaitable[str]] | None = None
    if pty.safari_url:
        eval_fn = _eval_safari
    elif not pty.clients:
        return _require_panel(rid, pty)

    # Async modes — spawn background task
    if defer or (every is not None and every > 0):
        fn = eval_fn or _eval_panel
        task_id = await pty.alloc_task_id()
        if every is not None and every > 0:
            interval = max(1, int(every))
            at = asyncio.create_task(_every_task(task_id, code, interval, fn, mcp, pty))
            kind = "every"
        else:
            at = asyncio.create_task(_defer_task(task_id, code, fn, mcp, pty))
            kind = "defer"
        async with pty.async_tasks_lock:
            pty.async_tasks[task_id] = AsyncTask(
                task_id=task_id,
                kind=kind,
                code=code,
                interval=int(every) if every is not None else None,
                task=at,
            )
        return _result(
            rid, {"content": [{"type": "text", "text": f"Started {task_id}"}]}
        )

    # Synchronous eval
    value: Any = None
    if eval_fn:
        # Safari path — eval returns parsed JSON value
        try:
            result = await safari_eval(pty.safari_url, code)
            value = result
            text = json.dumps(result, indent=2) if result is not None else "undefined"
            text = spill_large_text(text, "eval_result")
        except Exception as e:
            return _result(
                rid,
                {"content": [{"type": "text", "text": f"Error: {e}"}], "isError": True},
            )
    else:
        # Panel path
        is_async = args.get("async", False) or "await " in code
        wrapped = pty.wrap_eval(code)
        cmd_params: dict[str, Any] = {"code": wrapped}
        if is_async:
            cmd_params["async"] = True
        try:
            resp = await pty.send_command("eval", timeout=5.0, **cmd_params)
        except asyncio.TimeoutError:
            return _error(rid, -32000, "Eval timed out (5s)")
        if err := _resp_error(rid, resp):
            return err
        value = resp.get("result", {}).get("value")  # type: ignore[union-attr]
        text = json.dumps(value, indent=2) if value is not None else "undefined"

    # History — store raw value so wrap_eval injects valid JS literals
    if len(text) <= 1000:
        pty.eval_history.append(value)
    else:
        pty.eval_history.append("[large result]")
    pty.eval_history = pty.eval_history[-20:]

    text = spill_large_text(text, "eval_result")
    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_js_cancel(rid: Any, args: dict, pty: PtySession) -> dict:
    task_id = args.get("task_id", "")
    async with pty.async_tasks_lock:
        at = pty.async_tasks.pop(task_id, None)
    if at is None:
        return _result(
            rid,
            {
                "content": [{"type": "text", "text": f"No such task: {task_id}"}],
                "isError": True,
            },
        )
    at.task.cancel()
    return _result(rid, {"content": [{"type": "text", "text": f"Cancelled {task_id}"}]})


def _screenshot_result(rid: Any, data: str, label: str | None) -> dict:
    """Build MCP screenshot result with optional text label."""
    spill(base64.b64decode(data), "screenshot", "png")
    content: list[dict] = []
    if label:
        content.append({"type": "text", "text": f"[{label}]"})
    content.append({"type": "image", "data": data, "mimeType": "image/png"})
    return _result(rid, {"content": content})


async def _tool_device_screenshot(rid: Any, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        data, label = await backend.device_screenshot()
    except NotSupported as e:
        return _result(
            rid, {"content": [{"type": "text", "text": str(e)}], "isError": True}
        )
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Device screenshot timed out")
    except (TargetError, RuntimeError) as e:
        return _error(rid, -32000, str(e))
    return _screenshot_result(rid, data, label)


async def _tool_screenshot(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        data, label = await backend.screenshot(args.get("selector"))
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Screenshot timed out")
    except (TargetError, RuntimeError) as e:
        return _error(rid, -32000, str(e))
    return _screenshot_result(rid, data, label)


async def _tool_network(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        entries = await backend.network(args)
    except NotSupported as e:
        return _result(
            rid, {"content": [{"type": "text", "text": str(e)}], "isError": True}
        )
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Network capture timed out")
    except Exception as e:
        return _error(rid, -32000, f"Network fetch failed: {e}")
    if not entries:
        return _result(
            rid, {"content": [{"type": "text", "text": "No network entries."}]}
        )
    text = json.dumps(entries, indent=2)
    text = f"{len(entries)} entries\n\n{spill_large_text(text, 'network')}"
    return _result(rid, {"content": [{"type": "text", "text": text}]})


def _format_console_entry(entry: dict) -> str:
    level = entry.get("level", "log").upper()
    text = entry.get("text", "")
    url = entry.get("url", "")
    stack = entry.get("stackTrace", "")
    parts = [f"[{level}] {text}"]
    if url:
        parts.append(f"  {url}")
    if stack and stack != text:
        # Only first line of stack to avoid very long outputs
        first_line = stack.split("\n")[0] if "\n" in stack else stack
        if first_line and first_line != text:
            parts.append(f"  {first_line}")
    return "\n".join(parts)


async def _tool_console(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        entries = await backend.console(args)
    except NotSupported as e:
        return _result(
            rid, {"content": [{"type": "text", "text": str(e)}], "isError": True}
        )
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Console fetch timed out")
    except Exception as e:
        return _error(rid, -32000, f"Console fetch failed: {e}")
    if not entries:
        return _result(
            rid, {"content": [{"type": "text", "text": "No console entries."}]}
        )
    formatted = "\n".join(_format_console_entry(e) for e in entries)
    formatted = spill_large_text(formatted, "console")
    return _result(rid, {"content": [{"type": "text", "text": formatted}]})


def _format_issue(issue: dict) -> str:
    """Format a single audit issue with full context for agent consumption."""
    severity = issue.get("severity", "info")
    icon = {"breaking": "!!", "warning": "!", "improvement": "*", "info": "-"}.get(
        severity, "-"
    )
    code = issue.get("code", "")
    message = issue.get("message", code)
    source = issue.get("source", "")
    lines = [f"{icon} [{severity}] {code}: {message}"]
    if source:
        lines.append(f"  source: {source}")

    details = issue.get("details")
    if details and isinstance(details, dict):
        detail_type = details.get("_detailType", "")

        if "deprecation" in detail_type.lower():
            dep_type = details.get("type", "")
            if dep_type:
                lines.append(f"  deprecation type: {dep_type}")
            loc = details.get("sourceCodeLocation", {})
            if loc.get("url"):
                lines.append(f"  location: {loc['url']}:{loc.get('lineNumber', '?')}")

        elif "generic" in detail_type.lower():
            error_type = details.get("errorType", "")
            if error_type and error_type != message:
                lines.append(f"  error type: {error_type}")
            node_id = details.get("violatingNodeId")
            selector = issue.get("selector")
            if selector:
                lines.append(f"  element: {selector}")
            elif node_id:
                lines.append(f"  violating node (backendNodeId): {node_id}")
            attr = details.get("violatingNodeAttribute")
            if attr:
                lines.append(f"  violating attribute: {attr}")

        elif "contentSecurityPolicy" in detail_type:
            lines.append(f"  directive: {details.get('violatedDirective', '?')}")
            blocked = details.get("blockedURL")
            if blocked:
                lines.append(f"  blocked URL: {blocked}")
            if details.get("isReportOnly"):
                lines.append("  (report-only)")

        elif "cookie" in detail_type.lower():
            cookie = details.get("cookie", {})
            if cookie.get("name"):
                lines.append(f"  cookie: {cookie['name']}")
            reasons = details.get("cookieWarningReasons") or details.get(
                "cookieExclusionReasons"
            )
            if reasons:
                lines.append(f"  reasons: {', '.join(reasons)}")

        # Catch-all: if we have an affectedFrame or request, show it
        frame = details.get("affectedFrame", {})
        if frame.get("frameId"):
            lines.append(f"  frame: {frame.get('frameId', '?')}")
        req = details.get("request", {})
        if req.get("url"):
            lines.append(f"  request: {req['url']}")

    return "\n".join(lines)


async def _tool_issues(rid: Any, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        issues = await backend.issues()
    except NotSupported as e:
        return _result(
            rid, {"content": [{"type": "text", "text": str(e)}], "isError": True}
        )
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Issues fetch timed out")
    except Exception as e:
        return _error(rid, -32000, f"Issues fetch failed: {e}")
    if not issues:
        return _result(
            rid, {"content": [{"type": "text", "text": "No issues detected."}]}
        )
    formatted = "\n".join(_format_issue(i) for i in issues)
    return _result(rid, {"content": [{"type": "text", "text": formatted}]})


async def _tool_watch(rid: Any, args: dict, pty: PtySession) -> dict:
    if pty.safari_url:
        return _result(
            rid,
            {
                "content": [
                    {
                        "type": "text",
                        "text": "Not available on iOS targets (safarictl uses poll-based network API).",
                    }
                ],
                "isError": True,
            },
        )

    if err := _require_panel(rid, pty):
        return err

    url_pattern = args.get("url_pattern", "")
    watch_id = await pty.alloc_watch_id()
    pty.watchers[watch_id] = url_pattern

    try:
        await pty.send_command(
            "register_watcher", timeout=5.0, wid=watch_id, pattern=url_pattern
        )
    except asyncio.TimeoutError:
        pty.watchers.pop(watch_id, None)
        return _error(rid, -32000, "Watcher registration timed out")

    return _result(
        rid, {"content": [{"type": "text", "text": f"watch_id: {watch_id}"}]}
    )


async def _tool_watch_cancel(rid: Any, args: dict, pty: PtySession) -> dict:
    watch_id = args.get("watch_id", "")
    pty.watchers.pop(watch_id, None)

    if not pty.clients:
        return _result(
            rid,
            {"content": [{"type": "text", "text": f"Cancelled {watch_id} (no panel)"}]},
        )

    try:
        await pty.send_command("unregister_watcher", timeout=5.0, wid=watch_id)
    except asyncio.TimeoutError:
        pass  # Best-effort unregister

    return _result(
        rid, {"content": [{"type": "text", "text": f"Cancelled {watch_id}"}]}
    )


def _format_mutation(rid: Any, r: MutationResult) -> dict:
    """Format a MutationResult (tree + optional network delta) as MCP tool result."""
    parts = [f"url: {r.url} (settled in {r.settle_ms}ms)\n"]
    if r.tree:
        parts.append(f"tree ({r.node_count} nodes):")
        parts.append(r.tree)
        if r.network:
            parts.append("")
    if r.network:
        parts.append(f"network ({len(r.network)} requests):")
        for entry in r.network:
            parts.append(
                f"  {entry.get('method', '?')} {entry.get('status', '?')} "
                f"{entry.get('url', '?')} {entry.get('time', '?')}ms {entry.get('size', '?')}"
            )
    return _result(rid, {"content": [{"type": "text", "text": "\n".join(parts)}]})


async def _tool_tree(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        text, _ = await backend.tree(int(args.get("depth", 4)))
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Tree capture timed out")
    except Exception as e:
        return _error(rid, -32000, f"Tree capture failed: {e}")
    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_click(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    selector = args.get("selector", "")
    try:
        result = await backend.click(selector)
    except ElementNotFound:
        return _error(rid, -32000, f"Element not found: {selector}")
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Click timed out")
    except Exception as e:
        return _error(rid, -32000, f"Click failed: {e}")
    return _format_mutation(rid, result)


async def _tool_type(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    selector = args.get("selector", "")
    try:
        result = await backend.type_text(
            selector, args.get("text", ""), args.get("press_enter", False)
        )
    except ElementNotFound:
        return _error(rid, -32000, f"Element not found: {selector}")
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Type timed out")
    except Exception as e:
        return _error(rid, -32000, f"Type failed: {e}")
    return _format_mutation(rid, result)


async def _tool_navigate(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        text = await backend.navigate(args.get("url"), args.get("action"))
    except ValueError as e:
        return _error(rid, -32602, str(e))
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Navigate timed out")
    except Exception as e:
        return _error(rid, -32000, f"Navigate failed: {e}")
    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_viewport(rid: Any, args: dict, pty: PtySession) -> dict:
    backend = get_backend(pty)
    if backend is None:
        return _error(
            rid, -32000, "No target connected — open DevTools or register a device"
        )
    try:
        text = await backend.viewport(args)
    except NotSupported as e:
        return _error(rid, -32000, str(e))
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Viewport command timed out")
    except Exception as e:
        return _error(rid, -32000, f"Viewport failed: {e}")
    return _result(rid, {"content": [{"type": "text", "text": text}]})
