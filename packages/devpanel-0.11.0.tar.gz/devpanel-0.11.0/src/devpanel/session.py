"""Core session classes and shared utilities for DevPanel.

This module owns PtySession, McpSession, and all shared state that both
server.py (HTTP) and mcp.py (tools) need. Neither server nor mcp imports
from the other — both import downward from here.
"""

from __future__ import annotations

import asyncio
import base64
import collections
import fcntl
import json
import os
import pty
import signal
import struct
import termios
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import aiohttp
from aiohttp import web, WSMsgType


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BUFFER_SIZE = 64 * 1024
SCROLLBACK_SIZE = 100 * 1024  # 100 KB ring buffer
IDLE_TIMEOUT = 30 * 60  # 30 minutes (daemon exits when no sessions)
MAX_SESSIONS = 10  # cap live sessions; oldest evicted on overflow
MCP_IDLE_TIMEOUT = 5 * 60  # 5 minutes: reap MCP sessions with no POST/GET activity
MCP_SWEEP_INTERVAL = 60  # 60 seconds between sweep ticks
SPILL_DIR = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "devpanel"
LOCK_FILE = SPILL_DIR / "daemon.lock"
SPILL_MAX_AGE = 3600  # 1 hour

# Populated by server.py handle_adb_setup (POST /adb from CLI).
adb_state: dict[str, Any] | None = None

# Populated by server.py handle_safari_setup (POST /safari from CLI).
safari_state: dict[str, Any] | None = None

SELECTOR_BUILDER_JS = r"""
(function(el) {
  if (el.id) return '#' + CSS.escape(el.id);
  var s = el.tagName.toLowerCase();
  if (el.className && typeof el.className === 'string') {
    s += '.' + el.className.trim().split(/\s+/).slice(0,2).map(function(c){return CSS.escape(c);}).join('.');
  }
  return s;
})(this)
"""

INSPECT_HIGHLIGHT_CONFIG = {
    "showInfo": True,
    "showStyles": False,
    "contentColor": {"r": 111, "g": 168, "b": 220, "a": 0.66},
    "paddingColor": {"r": 147, "g": 196, "b": 125, "a": 0.55},
    "borderColor": {"r": 255, "g": 229, "b": 153, "a": 0.66},
    "marginColor": {"r": 246, "g": 178, "b": 107, "a": 0.66},
}


# ---------------------------------------------------------------------------
# Spill utilities
# ---------------------------------------------------------------------------


def _ensure_spill_dir() -> None:
    SPILL_DIR.mkdir(parents=True, exist_ok=True)


def spill(data: str | bytes, label: str, ext: str) -> str:
    """Write data to a spill file, return the path."""
    _ensure_spill_dir()
    tid = uuid.uuid4().hex[:8]
    path = SPILL_DIR / f"{label}-{tid}.{ext}"
    if isinstance(data, bytes):
        path.write_bytes(data)
    else:
        path.write_text(data)
    return str(path)


def spill_large_text(text: str, label: str, ext: str = "json") -> str:
    """If text > 4KB, spill to file and return preview + path. Otherwise return as-is."""
    if len(text) <= 4000:
        return text
    path = spill(text, label, ext)
    preview = text[:2000] + "\n\n… truncated …\n\n" + text[-500:]
    return f"{preview}\n\nFull result → {path}"


# ---------------------------------------------------------------------------
# AsyncTask
# ---------------------------------------------------------------------------


@dataclass
class AsyncTask:
    task_id: str
    kind: str  # "defer" | "every"
    code: str
    interval: int | None
    task: asyncio.Task[None]


# ---------------------------------------------------------------------------
# McpSession
# ---------------------------------------------------------------------------


class McpSession:
    """Per-MCP-client state. Queues channel notifications until initialized."""

    def __init__(self) -> None:
        self.session_id = uuid.uuid4().hex
        self.initialized = False
        self.pending: list[dict] = []
        self.queue: asyncio.Queue[dict | None] = asyncio.Queue()
        self.last_active = time.monotonic()

    def touch(self) -> None:
        self.last_active = time.monotonic()

    def push_notification(self, notification: dict) -> None:
        """Queue a server notification for delivery via SSE."""
        if not self.initialized:
            self.pending.append(notification)
        else:
            self.queue.put_nowait(notification)

    def push_channel(self, content: str) -> None:
        """Push a claude/channel notification with browser context."""
        self.push_notification(
            {
                "jsonrpc": "2.0",
                "method": "notifications/claude/channel",
                "params": {"content": content},
            }
        )

    def set_initialized(self) -> None:
        """Mark session as initialized, flush pending notifications."""
        self.initialized = True
        self.touch()
        for msg in self.pending:
            self.queue.put_nowait(msg)
        self.pending.clear()

    def close(self) -> None:
        """Signal the SSE loop to stop."""
        self.queue.put_nowait(None)


# ---------------------------------------------------------------------------
# Stack formatters
# ---------------------------------------------------------------------------


def pick_active_mcp(session: PtySession) -> McpSession | None:
    """Pick the most-recently-active MCP session for channel routing.

    Browser events fan to one client; multi-tmux focus follows whoever last
    made an MCP call. Returns None if no MCP sessions exist.
    """
    if not session.mcp_sessions:
        return None
    return max(session.mcp_sessions.values(), key=lambda m: m.last_active)


def item_summary(item: dict[str, Any]) -> str:
    """Short human-readable summary for toast notifications."""
    t = item.get("type", "unknown")
    if t == "element":
        sel = str(item.get("selector", "?"))[:40]
        return f"Pushed `{sel}`"
    if t == "network":
        count = item.get("count", 0)
        return f"Captured {count} requests"
    if t == "screenshot":
        return "Screenshot captured"
    if t == "console":
        count = item.get("count", 0)
        errors = item.get("errors", 0)
        return f"Captured {count} console entries" + (
            f" ({errors} errors)" if errors else ""
        )
    return f"Pushed {t}"


def format_for_channel(item: dict[str, Any]) -> str:
    """Terse one-liner for live channel push."""
    t = item.get("type", "unknown")
    if t == "element":
        sel = item.get("selector", "?")
        url = item.get("url", "")
        note = item.get("note", "")
        parts = [f"Selected {sel}"]
        if url:
            parts.append(f"on {url}")
        if note:
            parts.append(f"— {note}")
        return " ".join(parts)
    if t == "network":
        count = item.get("count", 0)
        errors = item.get("errors", 0)
        path = item.get("spill_path", "")
        text = f"Captured {count} requests"
        if errors:
            text += f", {errors} errors"
        if path:
            text += f" → {path}"
        return text
    if t == "screenshot":
        path = item.get("spill_path", "")
        sel = item.get("selector", "")
        prefix = f"Screenshot of {sel}" if sel else "Screenshot"
        return f"{prefix} → {path}" if path else f"{prefix} captured"
    if t == "console":
        count = item.get("count", 0)
        errors = item.get("errors", 0)
        path = item.get("spill_path", "")
        text = f"{count} console entries"
        if errors:
            text += f", {errors} errors"
        if path:
            text += f" → {path}"
        return text
    return f"Pushed {t}"


def spill_item(body: dict[str, Any]) -> dict[str, Any]:
    """Spill large data (network, screenshot, page HTML) to disk."""
    item_type = body.get("type", "")

    if item_type == "network" and "entries" in body:
        entries = body["entries"]
        path = spill(json.dumps(entries, indent=2), "network", "json")
        errors = [e for e in entries if e.get("status", 200) >= 400]
        return {
            "type": "network",
            "count": len(entries),
            "errors": len(errors),
            "spill_path": path,
        }

    if item_type == "screenshot" and "data" in body:
        png_bytes = base64.b64decode(body["data"])
        path = spill(png_bytes, "screenshot", "png")
        out = {"type": "screenshot", "spill_path": path}
        if body.get("selector"):
            out["selector"] = body["selector"]
        return out

    if item_type == "console" and "entries" in body:
        entries = body["entries"]
        path = spill(json.dumps(entries, indent=2), "console", "json")
        errors = [e for e in entries if e.get("level") in ("error", "warning")]
        return {
            "type": "console",
            "count": len(entries),
            "errors": len(errors),
            "spill_path": path,
        }

    return body


def format_for_agent(items: list[dict[str, Any]]) -> str:
    """Format stack items as readable text for Claude Code."""
    if not items:
        return ""

    sections: dict[str, list[str]] = {}

    for item in items:
        t = item.get("type", "unknown")

        if t == "element":
            lines = sections.setdefault("Selected elements", [])
            selector = item.get("selector", "?")
            url = item.get("url", "")
            note = item.get("note", "")
            parts = [f"- `{selector}`"]
            if url:
                parts.append(f"on {url}")
            if note:
                parts.append(f"— {note}")
            lines.append(" ".join(parts))

        elif t == "network":
            lines = sections.setdefault("Network", [])
            count = item.get("count", 0)
            errors = item.get("errors", 0)
            path = item.get("spill_path", "")
            summary = f"{count} requests"
            if errors:
                summary += f", {errors} errors"
            lines.append(f"- {summary} → {path}")

        elif t == "screenshot":
            lines = sections.setdefault("Screenshots", [])
            path = item.get("spill_path", "")
            lines.append(f"- {path}")

        elif t == "console":
            lines = sections.setdefault("Console", [])
            count = item.get("count", 0)
            errors = item.get("errors", 0)
            path = item.get("spill_path", "")
            summary = f"{count} entries"
            if errors:
                summary += f", {errors} errors/warnings"
            lines.append(f"- {summary} → {path}")

        else:
            lines = sections.setdefault("Other", [])
            lines.append(f"- {json.dumps(item)}")

    parts = ["## Browser Context\n"]
    for heading, lines in sections.items():
        parts.append(f"### {heading}")
        parts.extend(lines)
        parts.append("")

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# PtySession
# ---------------------------------------------------------------------------


def _resize_pty(fd: int, cols: int, rows: int) -> None:
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))


_SEVERITY_MAP = {
    "PageError": "breaking",
    "Breaking": "breaking",
    "Warning": "warning",
    "Information": "improvement",
    "Info": "info",
}


def _parse_cdp_issue(params: dict) -> dict:
    """Parse a CDP Audits.issueAdded event into an issue dict."""
    issue = params.get("issue", {})
    code = issue.get("code", "Unknown")
    severity = _SEVERITY_MAP.get(issue.get("severity", "Information"), "info")
    raw_details = issue.get("details", {})

    # Extract headline message
    message = code
    dep = raw_details.get("deprecationIssueDetails")
    if dep:
        message = dep.get("message") or f"Deprecated: {dep.get('type', code)}"
    gen = raw_details.get("genericIssueDetails")
    if gen:
        message = gen.get("errorMessage") or str(gen.get("errorType", code))
    csp = raw_details.get("contentSecurityPolicyIssueDetails")
    if csp:
        message = f"CSP: {csp.get('violatedDirective', code)}"

    # Extract source location
    source = None
    for val in raw_details.values():
        if isinstance(val, dict):
            loc = val.get("sourceCodeLocation")
            if isinstance(loc, dict) and loc.get("url"):
                ln = loc.get("lineNumber")
                source = f"{loc['url']}{f':{ln}' if ln is not None else ''}"
                break

    # Find the specific detail sub-object
    detail_obj = None
    for k, v in raw_details.items():
        if isinstance(v, dict):
            detail_obj = {**v, "_detailType": k}
            break

    entry: dict = {"code": code, "severity": severity, "message": message}
    if source:
        entry["source"] = source
    if detail_obj:
        entry["details"] = detail_obj
    return entry


class PtySession:
    """Per-tab PTY with scrollback buffer, client fanout, and own context stack."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self.master_fd: int | None = None
        self.process: asyncio.subprocess.Process | None = None
        self.scrollback = bytearray()
        self.clients: set[web.WebSocketResponse] = set()
        self._reader_task: asyncio.Task[None] | None = None
        # Delivery queue. Items removed on flush/drain. Maxlen=50 safety cap.
        self.stack: collections.deque[dict[str, Any]] = collections.deque(maxlen=50)
        self.stack_lock = asyncio.Lock()
        self._stack_seq = 0  # auto-increment for stable ordering
        # MCP sessions (keyed by MCP session ID)
        self.mcp_sessions: dict[str, McpSession] = {}
        # WS command/response protocol
        self.pending_commands: dict[str, asyncio.Future[dict]] = {}
        # JS eval history for _ / _N variables
        self.eval_history: list[Any] = []
        # Async task tracking (defer/every)
        self.async_tasks: dict[str, AsyncTask] = {}
        self.async_tasks_lock = asyncio.Lock()
        self._task_counter = 0
        # Console capture buffer (capped 1000 entries)
        self.console_buffer: collections.deque[dict] = collections.deque(maxlen=1000)
        # Network watchers: id → pattern (also stored panel-side)
        self.watchers: dict[str, str] = {}
        # Audits issues buffer (Audits.issueAdded events, capped like panel ISSUES_BUFFER_MAX)
        self.issues_buffer: collections.deque[dict] = collections.deque(maxlen=200)
        # CDP WebSocket for remote (ADB) targets — None for local tabs
        self.cdp_ws: aiohttp.ClientWebSocketResponse | None = None
        self.cdp_url: str | None = None
        self._cdp_reader_task: asyncio.Task[None] | None = None
        self._cdp_id_counter: int = 0
        self.cdp_pending: dict[int, asyncio.Future[dict]] = {}
        self._cdp_http_session: aiohttp.ClientSession | None = None
        # Target session ID for flattened browser-level CDP connections
        self._cdp_session_id: str | None = None
        # Inspect-mode future: set when inspectNodeRequested fires on remote target
        self._inspect_future: asyncio.Future[dict] | None = None
        # Suppress nav channel push while a tool is driving a mutation
        self._cdp_mutating: bool = False
        # Dedupe nav pushes (same URL = noise)
        self._last_nav_url: str = ""
        # Safari (iOS) target via safarictl HTTP API — None for non-iOS targets
        self.safari_url: str | None = None
        self.safari_viewport: dict | None = None
        # Callback for session removal (set by server.py)
        self._on_exit: Any = None

    async def alloc_task_id(self) -> str:
        async with self.async_tasks_lock:
            self._task_counter += 1
            return f"tsk_{self._task_counter}"

    async def alloc_watch_id(self) -> str:
        async with self.async_tasks_lock:
            self._task_counter += 1
            return f"wch_{self._task_counter}"

    def wrap_eval(self, code: str) -> str:
        """Prepend history variable declarations to eval code."""
        lines: list[str] = []
        if self.eval_history:
            lines.append(f"var _ = {json.dumps(self.eval_history[-1])};")
            for i, r in enumerate(self.eval_history):
                lines.append(f"var _{i + 1} = {json.dumps(r)};")
        lines.append(code)
        return "\n".join(lines)

    async def send_command(
        self, cmd: str, timeout: float = 10.0, **params: Any
    ) -> dict:
        """Send command to panel via WS, await response."""
        rid = uuid.uuid4().hex[:8]
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict] = loop.create_future()
        self.pending_commands[rid] = future
        await self.broadcast({"id": rid, "cmd": cmd, **params})
        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            self.pending_commands.pop(rid, None)
            raise

    async def start(self, port: int, cwd: str | None = None) -> None:
        """Spawn PTY with DEVPANEL_* env vars. User's shell chain handles the rest."""
        master, slave = pty.openpty()
        fcntl.fcntl(
            master, fcntl.F_SETFL, fcntl.fcntl(master, fcntl.F_GETFL) | os.O_NONBLOCK
        )

        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        env["FORCE_COLOR"] = "1"
        env["DEVPANEL_PORT"] = str(port)
        env["DEVPANEL_SESSION"] = self.session_id
        env["DEVPANEL_SPILL_DIR"] = str(SPILL_DIR)
        env["DEVPANEL_REPLD_SOCKET"] = str(SPILL_DIR / "repld.sock")
        # Scrub inherited terminal-multiplexer vars so the spawned shell
        # sees a fresh context (like ghostty/iTerm do implicitly).
        for var in ("TMUX", "TMUX_PANE", "STY"):
            env.pop(var, None)

        shell = os.environ.get("SHELL", "/bin/bash")
        self.process = await asyncio.create_subprocess_exec(
            shell,
            stdin=slave,
            stdout=slave,
            stderr=slave,
            env=env,
            cwd=str(Path(cwd).expanduser())
            if cwd and Path(cwd).expanduser().is_dir()
            else str(Path.home()),
            preexec_fn=os.setsid,
        )
        os.close(slave)
        self.master_fd = master

        _resize_pty(master, 80, 24)

        # Set up async reader from PTY master
        loop = asyncio.get_running_loop()
        reader = asyncio.StreamReader(BUFFER_SIZE)
        protocol = asyncio.StreamReaderProtocol(reader)
        await loop.connect_read_pipe(lambda: protocol, os.fdopen(master, "rb", 0))

        self._reader_task = asyncio.create_task(self._read_loop(reader))

    async def _read_loop(self, reader: asyncio.StreamReader) -> None:
        """Read PTY output, append to scrollback, fan out to WS clients."""
        try:
            while True:
                data = await reader.read(BUFFER_SIZE)
                if not data:
                    break
                # Append to scrollback ring buffer
                self.scrollback.extend(data)
                if len(self.scrollback) > SCROLLBACK_SIZE:
                    self.scrollback = self.scrollback[-SCROLLBACK_SIZE:]
                # Fan out to all connected clients
                closed: set[web.WebSocketResponse] = set()
                for ws in self.clients:
                    try:
                        await ws.send_bytes(data)
                    except Exception:
                        closed.add(ws)
                self.clients -= closed
        except Exception:
            pass

        # PTY exited — notify clients and clean up
        await self._close_clients(b"\r\n\x1b[90m[shell exited]\x1b[0m\r\n")
        if self._on_exit:
            self._on_exit(self.session_id)

    async def _close_clients(self, message: bytes) -> None:
        """Notify WS clients and clear session state."""
        for ws in list(self.clients):
            try:
                await ws.send_bytes(message)
                await ws.close()
            except Exception:
                pass
        self.stack.clear()
        for mcp in self.mcp_sessions.values():
            mcp.close()
        self.mcp_sessions.clear()
        # Cancel all async tasks
        async with self.async_tasks_lock:
            for at in list(self.async_tasks.values()):
                at.task.cancel()
            self.async_tasks.clear()
        # Clear console buffer, issues buffer, and watchers
        self.console_buffer.clear()
        self.issues_buffer.clear()
        self.watchers.clear()
        self.clients.clear()
        # Disconnect remote CDP WebSocket
        await self.detach_cdp()
        # Clear Safari target
        self.detach_safari()

    async def attach(self, ws: web.WebSocketResponse) -> None:
        """Attach a WS client. Replays scrollback."""
        if self.scrollback:
            await ws.send_bytes(bytes(self.scrollback))
        self.clients.add(ws)

    def detach(self, ws: web.WebSocketResponse) -> None:
        """Detach a WS client. Session persists for reconnect."""
        self.clients.discard(ws)

    async def broadcast(self, event: dict[str, Any]) -> None:
        """Send a JSON event to all connected WS clients (text frame)."""
        msg = json.dumps(event)
        closed: set[web.WebSocketResponse] = set()
        for ws in self.clients:
            try:
                await ws.send_str(msg)
            except Exception:
                closed.add(ws)
        self.clients -= closed

    def write(self, data: bytes) -> None:
        """Write to PTY stdin."""
        if self.master_fd is not None:
            os.write(self.master_fd, data)

    def resize(self, cols: int, rows: int) -> None:
        """Resize PTY."""
        if self.master_fd is not None:
            _resize_pty(self.master_fd, cols, rows)

    @property
    def alive(self) -> bool:
        return self.process is not None and self.process.returncode is None

    # --- CDP WebSocket (remote ADB targets) ---

    async def attach_cdp(self, ws_url: str) -> None:
        """Connect a direct CDP WebSocket to a remote (ADB-forwarded) target."""
        await self.detach_cdp()
        self._cdp_http_session = aiohttp.ClientSession()
        self.cdp_ws = await self._cdp_http_session.ws_connect(ws_url)
        self.cdp_url = ws_url
        self._cdp_reader_task = asyncio.create_task(self._cdp_read_loop())

    async def _cdp_read_loop(self) -> None:
        """Read CDP events/responses from the WebSocket and dispatch them."""
        try:
            async for msg in self.cdp_ws:  # type: ignore[union-attr]
                if msg.type == WSMsgType.TEXT:
                    try:
                        data: dict = json.loads(msg.data)
                    except json.JSONDecodeError:
                        continue
                    # For flattened sessions, only process messages for our target
                    sid = data.get("sessionId")
                    if self._cdp_session_id and sid and sid != self._cdp_session_id:
                        continue
                    if "id" in data:
                        # Response to a pending cdp_command call
                        fut = self.cdp_pending.pop(data["id"], None)
                        if fut and not fut.done():
                            fut.set_result(data)
                    else:
                        # Unsolicited event
                        await self._handle_cdp_event(data)
                elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                    break
        except Exception:
            pass
        finally:
            # Resolve any pending futures with a connection-closed error
            for fut in self.cdp_pending.values():
                if not fut.done():
                    fut.set_exception(ConnectionError("CDP WebSocket closed"))
            self.cdp_pending.clear()
            self.cdp_ws = None
            self.cdp_url = None

    async def _handle_cdp_event(self, event: dict) -> None:
        """Dispatch unsolicited CDP events (navigation, console, inspect)."""
        method = event.get("method", "")
        params = event.get("params", {})

        if method == "Page.loadEventFired":
            # Skip when a tool drove this nav (tool result already has the URL)
            if self._cdp_mutating:
                return
            mcp = pick_active_mcp(self)
            if mcp:
                # Use Page.getNavigationHistory — doesn't need an execution
                # context, so it works even during the load transition where
                # Runtime.evaluate("location.href") returns nothing.
                try:
                    r = await self.cdp_command("Page.getNavigationHistory", timeout=3.0)
                    entries = r.get("result", {}).get("entries", [])
                    idx = r.get("result", {}).get("currentIndex", -1)
                    url = entries[idx]["url"] if 0 <= idx < len(entries) else "?"
                except Exception:
                    url = "?"
                # Dedupe: same URL = noise (HMR, sleep/wake, F5)
                if url == self._last_nav_url:
                    return
                self._last_nav_url = url
                mcp.push_channel(f"Page loaded — ready for interaction ({url})")

        elif method == "Runtime.consoleAPICalled":
            # Buffer console entries (mirrors panel-side console capture)
            level = params.get("type", "log")
            args = params.get("args", [])
            text_parts = []
            for arg in args:
                if arg.get("type") == "string":
                    text_parts.append(arg.get("value", ""))
                elif "description" in arg:
                    text_parts.append(arg["description"])
                else:
                    text_parts.append(str(arg.get("value", "")))
            text = " ".join(text_parts)
            ts = params.get("timestamp", 0)
            url = params.get("stackTrace", {}).get("callFrames", [{}])[0].get("url", "")
            entry = {"level": level, "text": text, "timestamp": ts, "url": url}
            self.console_buffer.append(entry)
            # Push errors as channel notifications
            if level in ("error", "warning"):
                mcp = pick_active_mcp(self)
                if mcp:
                    mcp.push_channel(f"[{level.upper()}] {text}")

        elif method == "Audits.issueAdded":
            entry = _parse_cdp_issue(params)
            if not any(
                i.get("code") == entry["code"] and i.get("message") == entry["message"]
                for i in self.issues_buffer
            ):
                self.issues_buffer.append(entry)

        elif method == "Overlay.inspectNodeRequested":
            # User clicked an element during remote inspect mode
            if self._inspect_future and not self._inspect_future.done():
                self._inspect_future.set_result(params)

    async def cdp_command(
        self, method: str, params: dict | None = None, timeout: float = 10.0
    ) -> dict:
        """Send a CDP command via the daemon WebSocket, await its response."""
        if not self.cdp_ws:
            raise RuntimeError("No CDP WebSocket connected")
        self._cdp_id_counter += 1
        rid = self._cdp_id_counter
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[dict] = loop.create_future()
        self.cdp_pending[rid] = fut
        msg: dict[str, Any] = {"id": rid, "method": method, "params": params or {}}
        if self._cdp_session_id:
            msg["sessionId"] = self._cdp_session_id
        await self.cdp_ws.send_json(msg)
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            self.cdp_pending.pop(rid, None)
            raise

    async def detach_cdp(self) -> None:
        """Close the CDP WebSocket and cancel the reader task."""
        if self._cdp_reader_task:
            self._cdp_reader_task.cancel()
            try:
                await self._cdp_reader_task
            except (asyncio.CancelledError, Exception):
                pass
            self._cdp_reader_task = None
        if self.cdp_ws:
            try:
                await self.cdp_ws.close()
            except Exception:
                pass
            self.cdp_ws = None
        if self._cdp_http_session:
            try:
                await self._cdp_http_session.close()
            except Exception:
                pass
            self._cdp_http_session = None
        self.cdp_pending.clear()
        self.cdp_url = None
        self._cdp_session_id = None
        if self._inspect_future and not self._inspect_future.done():
            self._inspect_future.cancel()
        self._inspect_future = None

    def detach_safari(self) -> None:
        """Clear Safari (iOS) target state."""
        self.safari_url = None
        self.safari_viewport = None

    async def shutdown(self) -> None:
        """Terminate this session's PTY."""
        if self.process and self.process.returncode is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGHUP)
            except OSError:
                pass
            try:
                await asyncio.wait_for(self.process.wait(), timeout=5)
            except asyncio.TimeoutError:
                self.process.kill()
        await self._close_clients(b"\r\n\x1b[90m[session ended]\x1b[0m\r\n")
