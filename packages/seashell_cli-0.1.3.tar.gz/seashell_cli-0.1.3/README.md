# Seashell CLI

Command-line tool for querying and managing genomic data on Seashell.

## Install

```bash
pip install seashell-cli
```

## Quick Start

```bash
seashell
```

You'll be prompted for your API key (from your institution admin), username, and password. After login, you're in an interactive shell:

```
seashell> LIST PATIENTS
seashell> FIND VARIANTS WHERE patient=NA12878 AND gene=BRCA1
seashell> EXPORT PATIENT NA12878 FORMAT CRAM
```

## Single Query Mode

```bash
seashell "FIND PATIENTS WHERE gene=BRCA1 AND significance=pathogenic"
seashell "COUNT VARIANTS WHERE patient=NA12878"
seashell --format json "LIST PATIENTS"
```

## Commands

| Command | Description |
|---|---|
| `FIND VARIANTS WHERE ...` | Search variants by gene, significance, patient |
| `FIND PATIENTS WHERE ...` | Find patients matching criteria |
| `COUNT VARIANTS/PATIENTS WHERE ...` | Count matches |
| `LIST PATIENTS` | List all patients |
| `COMPARE p1 VS p2` | Compare two patients |
| `UPLOAD PATIENT id CRAM s3://...` | Upload from CRAM/BAM |
| `UPLOAD PATIENT id FASTQ s3://R1 s3://R2` | Upload from raw FASTQ |
| `EXPORT PATIENT id FORMAT CRAM` | Export as CRAM/BAM |
| `DELETE PATIENT id` | Remove a patient |
| `help` | Show all commands |

## Requirements

- Python 3.8+
- A Seashell API key (contact your institution admin)

## Documentation

https://seashell.bio/docs
