"""Help text for the Seashell CLI."""

HELP_TEXT = """
QUERY COMMANDS
  FIND VARIANTS WHERE ...          Search variants by gene, significance, patient
  FIND PATIENTS WHERE ...          Find patients matching criteria
  COUNT VARIANTS WHERE ...         Count matching variants
  COUNT PATIENTS WHERE ...         Count matching patients
  LIST PATIENTS                    List all patients in your institution
  COMPARE patient1 VS patient2     Compare variants between two patients
  DIFF patient1 VS patient2        Exact variant-level differences
  FIND SIMILAR patient TOP n       Find genetically similar patients
  PCA                              Principal component analysis

UPLOAD
  UPLOAD PATIENT id CRAM s3://path VCF s3://path    Upload from aligned CRAM/BAM
  UPLOAD PATIENT id FASTQ s3://R1 s3://R2           Upload from raw FASTQ
  UPLOAD BATCH s3://manifest.json                   Batch upload from manifest

EXPORT
  EXPORT PATIENT id FORMAT CRAM                     Export as CRAM
  EXPORT PATIENT id FORMAT BAM                      Export as BAM
  EXPORT PATIENT id FORMAT BAM REGION chr17:41M-42M Export a region
  EXPORT PATIENTS WHERE gene=BRCA1 FORMAT CRAM      Export by criteria

ANALYTICS
  COVERAGE patient chr:start-end   Read depth across a region
  QC patient                       Quality control metrics
  PILEUP patient chr:pos-pos       Base-level pileup

MANAGEMENT
  DELETE PATIENT id                Remove a patient (admin only)

FILTERS
  gene=BRCA1                       Gene name
  significance=pathogenic          ClinVar significance
  chromosome=chr17                 Chromosome
  patient=NA12878                  Patient ID
  age>50                           Phenotype filters (age, sex, ancestry)

CLI COMMANDS
  help          Show this message
  status        Connection info and patient count
  logout        Clear saved credentials and log out
  exit          Quit Seashell
""".strip()


# ANSI color codes (work on macOS, Linux, and most Windows terminals)
CYAN = "\033[36m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
WHITE = "\033[97m"
BLUE = "\033[34m"


def welcome_banner():
    """Return the colored welcome banner."""
    lines = []
    lines.append("")
    lines.append(BOLD + WHITE + "  Welcome to Seashell" + RESET)
    lines.append(DIM + "  Genomic data, compressed and queryable." + RESET)
    lines.append("")
    return "\n".join(lines)
