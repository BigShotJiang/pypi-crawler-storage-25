import sys

sys.path.insert(0, "./mca-prototype")
print("Success")
