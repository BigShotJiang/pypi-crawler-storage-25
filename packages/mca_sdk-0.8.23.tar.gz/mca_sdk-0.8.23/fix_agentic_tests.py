filename = "mca-prototype/tests/integration/test_agentic_example.py"
with open(filename, "r") as f:
    content = f.read()

content = content.replace(
    'mock_mca_client.record_goal_completed.assert_called_once_with(\n            goal_id, status="success", tools_used=4, iterations=3, papers_analyzed=2\n        )',
    'mock_mca_client.record_goal_completed.assert_called_once_with(\n            goal_id, status="success"\n        )',
)

content = content.replace(
    "agent = DataAnalyticsAgent(mock_mca_client, simulation_delay=0)",
    "agent = DataAnalyticsAgent(mock_mca_client)",
)

with open(filename, "w") as f:
    f.write(content)
