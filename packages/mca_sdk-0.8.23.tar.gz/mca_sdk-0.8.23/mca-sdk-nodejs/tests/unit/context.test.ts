// Unit tests for withMCAClient context manager
import { withMCAClient } from '../../src/utils/context';
import { MCAClient } from '../../src/core/client';

jest.mock('../../src/core/client');

describe('withMCAClient', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should create client and execute callback', async () => {
    const mockClient = {
      recordPrediction: jest.fn(),
      shutdown: jest.fn().mockResolvedValue(true),
    };

    (MCAClient.create as jest.Mock).mockResolvedValue(mockClient);

    const callback = jest.fn().mockResolvedValue('result');

    const result = await withMCAClient(
      { serviceName: 'test', strictValidation: false },
      callback
    );

    expect(MCAClient.create).toHaveBeenCalledWith({
      serviceName: 'test',
      strictValidation: false,
    });
    expect(callback).toHaveBeenCalledWith(mockClient);
    expect(mockClient.shutdown).toHaveBeenCalled();
    expect(result).toBe('result');
  });

  it('should shutdown client even if callback throws', async () => {
    const mockClient = {
      recordPrediction: jest.fn(),
      shutdown: jest.fn().mockResolvedValue(true),
    };

    (MCAClient.create as jest.Mock).mockResolvedValue(mockClient);

    const callback = jest.fn().mockRejectedValue(new Error('test error'));

    await expect(
      withMCAClient({ serviceName: 'test', strictValidation: false }, callback)
    ).rejects.toThrow('test error');

    expect(mockClient.shutdown).toHaveBeenCalled();
  });

  it('should return callback result', async () => {
    const mockClient = {
      recordPrediction: jest.fn(),
      shutdown: jest.fn().mockResolvedValue(true),
    };

    (MCAClient.create as jest.Mock).mockResolvedValue(mockClient);

    const result = await withMCAClient(
      { serviceName: 'test', strictValidation: false },
      async (client) => {
        await client.recordPrediction({ latency: 0.1 });
        return 42;
      }
    );

    expect(result).toBe(42);
    expect(mockClient.recordPrediction).toHaveBeenCalledWith({ latency: 0.1 });
  });
});
