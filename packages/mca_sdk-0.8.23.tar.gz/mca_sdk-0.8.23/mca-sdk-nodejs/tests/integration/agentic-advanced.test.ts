// Integration tests for advanced agentic workflows
// Tests full workflow: goal → reasoning step → tool → recovery → completion
import { MCAClient } from '../../src/core/client';

describe('Advanced Agentic Workflows (Integration)', () => {
  let client: MCAClient;

  beforeEach(async () => {
    client = await MCAClient.create({
      serviceName: 'test-agentic-integration',
      collectorEndpoint: 'http://localhost:4318',
      strictValidation: false,
      captureInputData: true,
      captureOutputData: true,
    });
  });

  afterEach(async () => {
    if (client) {
      await client.shutdown();
    }
  });

  describe('Full Agentic Workflow', () => {
    it('should execute complete goal → reasoning → tool → completion flow', async () => {
      // Start a goal
      const goalId = client.recordGoalStarted(
        'Process customer query',
        'customer_support'
      );

      // Execute reasoning step
      const plan = await client.reasoningStep(
        'planning',
        async (span) => {
          span.setAttribute('query_complexity', 'medium');
          return { steps: ['analyze', 'respond'] };
        },
        {
          stepDescription: 'Analyze customer query',
          llmModel: 'gpt-4',
        }
      );

      expect(plan.steps).toHaveLength(2);

      // Execute tool within goal context
      const toolResult = await client.trackTool(
        'database_lookup',
        async () => {
          return { customer: 'John Doe', status: 'active' };
        },
        goalId,
        { query_type: 'customer_info' }
      );

      expect(toolResult.customer).toBe('John Doe');

      // Complete goal
      client.recordGoalCompleted(goalId, 'success', {
        resolution: 'query_answered',
      });

      // Should complete without errors
      expect(goalId).toBeTruthy();
    });

    it('should track recovery across retry attempts', async () => {
      const goalId = client.recordGoalStarted('Retry workflow', 'test');

      let attemptCount = 0;

      // First attempt fails
      try {
        await client.trackTool(
          'unreliable_service',
          async () => {
            attemptCount++;
            throw new Error('Service unavailable');
          },
          goalId
        );
      } catch (e) {
        // Expected failure
      }

      // Second attempt succeeds - recovery should be tracked
      const result = await client.trackTool(
        'unreliable_service',
        async () => {
          attemptCount++;
          return 'success';
        },
        goalId
      );

      expect(result).toBe('success');
      expect(attemptCount).toBe(2);

      client.recordGoalCompleted(goalId, 'success');
    });

    it('should handle nested reasoning steps', async () => {
      const goalId = client.recordGoalStarted('Complex analysis', 'research');

      // Outer reasoning step
      const result = await client.reasoningStep(
        'analysis',
        async () => {
          // Inner reasoning step
          const subResult = await client.reasoningStep(
            'data_collection',
            async () => {
              return { data: [1, 2, 3] };
            }
          );

          return { analysis: 'complete', data: subResult.data };
        },
        { stepDescription: 'Main analysis' }
      );

      expect(result.analysis).toBe('complete');
      expect(result.data).toEqual([1, 2, 3]);

      client.recordGoalCompleted(goalId, 'success');
    });

    it('should handle human intervention in workflow', async () => {
      const goalId = client.recordGoalStarted('User interaction', 'support');

      // Simulate workflow that requires human input
      await client.reasoningStep('evaluation', async () => {
        // Determine human input is needed
        return 'needs_clarification';
      });

      // Record human intervention
      client.recordHumanIntervention(
        'User clarification required',
        45.2,
        'clarification',
        Date.now(),
        { intervention_context: 'ambiguous_query' }
      );

      // Continue workflow after intervention
      await client.trackTool(
        'process_clarified_input',
        async () => 'processed',
        goalId
      );

      client.recordGoalCompleted(goalId, 'success');
    });

    it('should handle policy violations in workflow', async () => {
      const goalId = client.recordGoalStarted('Compliance check', 'audit');

      await client.reasoningStep('compliance_check', async () => {
        // Detect policy violation
        client.recordPolicyViolation('unauthorized_data_access');
        return 'violation_detected';
      });

      // Workflow should continue but be marked
      client.recordGoalCompleted(goalId, 'partial', {
        violations: 1,
      });
    });
  });

  describe('Input/Output Capture Integration', () => {
    it('should capture large input data with truncation', async () => {
      const largeInput = {
        features: Array(1000).fill(0).map((_, i) => i),
        metadata: 'x'.repeat(200000), // 200KB string
      };

      // Should not throw despite large payload
      await client.recordPrediction({
        inputData: largeInput,
        latency: 0.5,
      });
    });

    it('should sanitize credentials in captured data', async () => {
      const inputWithCredentials = {
        features: [1, 2, 3],
        config: {
          api_key: 'AKIAIOSFODNN7EXAMPLE',
          bearer_token: 'Bearer abc123xyz456',
        },
      };

      // Should not expose credentials in telemetry
      await client.recordPrediction({
        inputData: inputWithCredentials,
        outputData: { prediction: 0.95 },
        latency: 0.2,
      });
    });

    it('should extract shape information from array inputs', async () => {
      const arrayInput = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
      ];

      await client.recordPrediction({
        inputData: arrayInput,
        outputData: [0.1, 0.8, 0.1],
        latency: 0.15,
      });
    });
  });

  describe('Error Handling Integration', () => {
    it('should handle errors in reasoning steps gracefully', async () => {
      const goalId = client.recordGoalStarted('Error handling', 'test');

      await expect(
        client.reasoningStep('failing_step', async () => {
          throw new Error('Reasoning failed');
        })
      ).rejects.toThrow('Reasoning failed');

      // Goal should still be completable
      client.recordGoalCompleted(goalId, 'failure');
    });

    it('should handle multiple tool failures', async () => {
      const goalId = client.recordGoalStarted('Multi-failure', 'test');

      // Multiple tools fail
      for (let i = 0; i < 3; i++) {
        try {
          await client.trackTool(`tool_${i}`, async () => {
            throw new Error(`Tool ${i} failed`);
          }, goalId);
        } catch (e) {
          // Continue despite failures
        }
      }

      client.recordGoalCompleted(goalId, 'failure');
    });
  });

  describe('Concurrent Operations', () => {
    it('should handle concurrent reasoning steps', async () => {
      const goalId = client.recordGoalStarted('Concurrent ops', 'parallel');

      // Execute multiple reasoning steps in parallel
      const results = await Promise.all([
        client.reasoningStep('step1', async () => 'result1'),
        client.reasoningStep('step2', async () => 'result2'),
        client.reasoningStep('step3', async () => 'result3'),
      ]);

      expect(results).toEqual(['result1', 'result2', 'result3']);

      client.recordGoalCompleted(goalId, 'success');
    });

    it('should handle concurrent tool executions', async () => {
      const goalId = client.recordGoalStarted('Parallel tools', 'test');

      const results = await Promise.all([
        client.trackTool('tool1', async () => 'data1', goalId),
        client.trackTool('tool2', async () => 'data2', goalId),
        client.trackTool('tool3', async () => 'data3', goalId),
      ]);

      expect(results).toEqual(['data1', 'data2', 'data3']);

      client.recordGoalCompleted(goalId, 'success');
    });
  });

  describe('Singleton Access', () => {
    it('should access client via getInstance', async () => {
      const instance = MCAClient.getInstance();
      expect(instance).toBe(client);
    });

    it('should use getInstance in utility functions', async () => {
      // Simulate utility function that needs client access
      const recordMetricViaInstance = async () => {
        const instance = MCAClient.getInstance();
        if (instance) {
          await instance.recordPrediction({ latency: 0.1 });
        }
      };

      await recordMetricViaInstance();
    });
  });
});
