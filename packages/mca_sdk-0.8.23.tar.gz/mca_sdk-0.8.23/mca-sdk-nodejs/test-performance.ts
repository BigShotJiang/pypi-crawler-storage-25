// Performance test for Node.js MCA SDK (NFR1 validation)
import { MCAClient } from './src';

async function testPerformance() {
  console.log('🚀 Starting Node.js MCA SDK Performance Test...\n');

  const client = await MCAClient.create({
    serviceName: 'perf-test',
    modelId: 'mdl-perf',
    modelVersion: '1.0',
    teamName: 'test',
    modelType: 'internal',
    collectorEndpoint: 'http://localhost:4318',
    strictValidation: false,
  });

  console.log('✓ Client initialized\n');

  // Warmup
  console.log('⏳ Warmup: 100 predictions...');
  for (let i = 0; i < 100; i++) {
    await client.recordPrediction({ latency: Math.random() * 0.1 });
  }
  console.log('✓ Warmup complete\n');

  // Main performance test
  const iterations = 1000;
  console.log(`⏳ Performance test: ${iterations} predictions...`);

  const latencies: number[] = [];
  const start = Date.now();

  for (let i = 0; i < iterations; i++) {
    const predStart = Date.now();
    await client.recordPrediction({
      latency: Math.random() * 0.1,
      iteration: i,
    });
    const predEnd = Date.now();
    latencies.push(predEnd - predStart);
  }

  const duration = Date.now() - start;
  const avgLatency = duration / iterations;

  // Calculate percentiles
  latencies.sort((a, b) => a - b);
  const p50 = latencies[Math.floor(iterations * 0.50)];
  const p95 = latencies[Math.floor(iterations * 0.95)];
  const p99 = latencies[Math.floor(iterations * 0.99)];

  console.log('\n📊 Performance Test Results:');
  console.log('═'.repeat(50));
  console.log(`Total predictions:    ${iterations}`);
  console.log(`Total time:           ${duration}ms`);
  console.log(`Average latency:      ${avgLatency.toFixed(2)}ms per prediction`);
  console.log(`Throughput:           ${(iterations / (duration / 1000)).toFixed(0)} predictions/sec`);
  console.log('');
  console.log('Latency Percentiles:');
  console.log(`  p50 (median):       ${p50}ms`);
  console.log(`  p95:                ${p95}ms`);
  console.log(`  p99:                ${p99}ms`);
  console.log('═'.repeat(50));

  // NFR1 validation
  console.log('\n🎯 NFR1 Requirements:');
  console.log(`  Target: <50ms average, <100ms p95`);
  console.log(`  Actual: ${avgLatency.toFixed(2)}ms average, ${p95}ms p95`);

  if (avgLatency < 50 && p95 < 100) {
    console.log('  ✅ PASS: Performance meets NFR1 requirements');
  } else {
    console.log('  ⚠️  WARNING: Performance may not meet NFR1 requirements');
    if (avgLatency >= 50) {
      console.log(`     - Average latency ${avgLatency.toFixed(2)}ms exceeds 50ms target`);
    }
    if (p95 >= 100) {
      console.log(`     - p95 latency ${p95}ms exceeds 100ms target`);
    }
  }

  await client.shutdown();
  console.log('\n✓ Client shutdown complete');
}

testPerformance().catch((error) => {
  console.error('❌ Performance test failed:', error);
  process.exit(1);
});
