// Jest configuration for MCA SDK Node.js
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  roots: ['<rootDir>/tests'],
  testMatch: ['**/*.test.ts'],
  collectCoverageFrom: [
    'src/**/*.ts',
    '!src/**/*.d.ts',
    '!src/types/**',
    '!src/security/_testing.ts',
    '!src/core/providers.ts'
  ],
  coverageThreshold: {
    global: {
      branches: 77,
      functions: 77,
      lines: 82,
      statements: 82
    }
  },
  coverageDirectory: 'coverage',
  coverageReporters: ['json', 'text', 'lcov', 'cobertura'],
  verbose: true,
  testTimeout: 10000
};
