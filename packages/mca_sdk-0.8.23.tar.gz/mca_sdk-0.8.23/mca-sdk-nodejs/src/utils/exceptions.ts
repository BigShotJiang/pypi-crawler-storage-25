// Custom exception types for MCA SDK

export class MCASDKError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'MCASDKError';
    Object.setPrototypeOf(this, MCASDKError.prototype);
  }
}

export class ConfigurationError extends MCASDKError {
  constructor(message: string) {
    super(message);
    this.name = 'ConfigurationError';
    Object.setPrototypeOf(this, ConfigurationError.prototype);
  }
}

export class ValidationError extends MCASDKError {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
    Object.setPrototypeOf(this, ValidationError.prototype);
  }
}

export class RegistryError extends MCASDKError {
  constructor(message: string) {
    super(message);
    this.name = 'RegistryError';
    Object.setPrototypeOf(this, RegistryError.prototype);
  }
}

export class BufferingError extends MCASDKError {
  constructor(message: string) {
    super(message);
    this.name = 'BufferingError';
    Object.setPrototypeOf(this, BufferingError.prototype);
  }
}
