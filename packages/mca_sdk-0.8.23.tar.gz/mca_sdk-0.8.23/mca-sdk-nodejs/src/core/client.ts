// Main MCAClient class for Node.js SDK
import { Meter, Counter, Histogram, Gauge, Attributes, context, trace, Span, SpanStatusCode } from '@opentelemetry/api';
import { Tracer } from '@opentelemetry/api';
import { Logger } from '@opentelemetry/api-logs';
import { MeterProvider } from '@opentelemetry/sdk-metrics';
import { NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
import { LoggerProvider } from '@opentelemetry/sdk-logs';
import { MCAConfig } from '../config/settings';
import {
  MCAClientConfig,
  RecordPredictionOptions,
  MetricAttributes,
  GoalStatus,
  EvaluationOptions
} from '../types';
import {
  setupMeterProvider,
  setupTracerProvider,
  setupLoggerProvider,
  shutdownProviders,
} from './providers';
import { logger as sdkLogger } from '../utils/logger';
import { RegistryClient } from '../registry/client';
import { randomUUID } from 'crypto';
import { extractModelPayload, sanitizeCredentials } from '../utils/serialization';

interface GoalData {
  span: Span;
  startTime: number;
}

interface ToolRetryState {
  firstFailed: boolean;
}

export class MCAClient {
  private static readonly MAX_DYNAMIC_METRICS = 1000; // Prevent unbounded memory growth
  private static _instance: MCAClient | null = null; // Singleton instance

  private config: MCAConfig;
  private meterProvider: MeterProvider;
  private tracerProvider: NodeTracerProvider;
  private loggerProvider: LoggerProvider;
  private _meter: Meter;
  private _tracer: Tracer;
  private _logger: Logger;
  private registryClient?: RegistryClient;
  private predictionCounter: Counter;
  private latencyHistogram: Histogram;
  private thresholds: Record<string, number>;
  private initialized: boolean = false;
  private isShutdown: boolean = false;

  // Agentic AI tracking state
  private activeGoals: Map<string, GoalData> = new Map();
  private toolExecutionState: Map<string, ToolRetryState> = new Map();
  private cleanupInterval?: NodeJS.Timeout;

  // Metric instruments (cached for performance)
  private goalsStartedCounter: Counter;
  private goalsCompletedCounter: Counter;
  private goalsFailedCounter: Counter;
  private goalDurationHistogram: Histogram;
  private toolCallsCounter: Counter;
  private toolLatencyHistogram: Histogram;
  private humanInterventionCounter: Counter;
  private policyViolationsCounter: Counter;
  private reasoningStepsCounter: Counter; // Story 1.19: Reasoning step tracking
  private errorsCounter: Counter;
  private maeHistogram: Histogram;
  private rmseHistogram: Histogram;
  private dynamicCounters: Map<string, Counter> = new Map();
  private dynamicGauges: Map<string, Gauge> = new Map(); // Proper Gauge for absolute values

  private constructor(config: MCAClientConfig) {
    this.config = MCAConfig.create(config);
    this.thresholds = {};

    const providerConfig = {
      serviceName: this.config.serviceName,
      collectorEndpoint: this.config.collectorEndpoint,
      modelId: this.config.modelId,
      modelVersion: this.config.modelVersion,
      teamName: this.config.teamName,
      modelType: this.config.modelType,
      filterSystemMetrics: this.config.filterSystemMetrics,
    };

    this.meterProvider = setupMeterProvider(providerConfig);
    this.tracerProvider = setupTracerProvider(providerConfig);
    this.loggerProvider = setupLoggerProvider(providerConfig);

    this._meter = this.meterProvider.getMeter('mca-sdk');
    this._tracer = this.tracerProvider.getTracer('mca-sdk');
    this._logger = this.loggerProvider.getLogger('mca-sdk');

    // Core prediction metrics
    this.predictionCounter = this._meter.createCounter('model.predictions_total', {
      description: 'Total number of predictions made',
    });

    this.latencyHistogram = this._meter.createHistogram('model.latency_seconds', {
      description: 'Prediction latency in seconds',
      unit: 's',
    });

    this.errorsCounter = this._meter.createCounter('model.errors_total', {
      description: 'Total number of errors',
    });

    // Agentic AI metrics
    this.goalsStartedCounter = this._meter.createCounter('agentic.goals_started_total', {
      description: 'Total number of agent goals started',
    });

    this.goalsCompletedCounter = this._meter.createCounter('agentic.goals_completed_total', {
      description: 'Total number of agent goals completed successfully',
    });

    this.goalsFailedCounter = this._meter.createCounter('agentic.goals_failed_total', {
      description: 'Total number of agent goals that failed',
    });

    this.goalDurationHistogram = this._meter.createHistogram('agentic.goal_duration_seconds', {
      description: 'Duration of agent goals in seconds',
      unit: 's',
    });

    this.toolCallsCounter = this._meter.createCounter('agentic.tool_calls_total', {
      description: 'Total number of tool calls',
    });

    this.toolLatencyHistogram = this._meter.createHistogram('agentic.tool_latency_seconds', {
      description: 'Tool execution latency in seconds',
      unit: 's',
    });

    this.humanInterventionCounter = this._meter.createCounter('agentic.human_interventions_total', {
      description: 'Total number of human interventions',
    });

    this.policyViolationsCounter = this._meter.createCounter('agentic.policy_violations_total', {
      description: 'Total number of policy violations detected',
    });

    // Story 1.19: Reasoning steps tracking
    this.reasoningStepsCounter = this._meter.createCounter('agentic.reasoning_steps_total', {
      description: 'Total number of reasoning steps in agent workflows',
    });

    // Evaluation metrics
    this.maeHistogram = this._meter.createHistogram('model.mae', {
      description: 'Mean Absolute Error',
    });

    this.rmseHistogram = this._meter.createHistogram('model.rmse', {
      description: 'Root Mean Squared Error',
    });

    // Start background cleanup for stale goals
    this.cleanupInterval = setInterval(() => this.cleanupStaleGoals(), 60000);
    this.cleanupInterval.unref(); // Allow Node.js to exit gracefully

    // Set singleton instance (Story 1.22: AC6)
    MCAClient._instance = this;

    sdkLogger.info('MCAClient initialized', {
      serviceName: this.config.serviceName,
      modelId: this.config.modelId,
      collectorEndpoint: this.config.collectorEndpoint,
    });
  }

  static async create(config: MCAClientConfig): Promise<MCAClient> {
    const client = new MCAClient(config);
    await client.initialize();
    return client;
  }

  private async initialize(): Promise<void> {
    if (this.initialized) return;

    if (this.config.registryUrl) {
      this.registryClient = new RegistryClient(
        this.config.registryUrl,
        this.config.registryToken,
        5000,
        this.config.refreshIntervalSecs,
        this.config.refreshIntervalSecs
      );

      try {
        await this.hydrateFromRegistry();
      } catch (error: any) {
        sdkLogger.warn(`Failed to hydrate config from registry: ${error.message}`);
      }
    }

    this.initialized = true;
  }

  private async hydrateFromRegistry(): Promise<void> {
    if (!this.registryClient || !this.config.modelId) return;

    try {
      const modelConfig = await this.registryClient.fetchModelConfig(
        this.config.modelId,
        this.config.modelVersion
      );

      if (modelConfig.thresholds) {
        this.thresholds = modelConfig.thresholds;
      }

      sdkLogger.info('Configuration hydrated from registry', {
        modelId: this.config.modelId,
      });
    } catch (error: any) {
      sdkLogger.warn(`Registry hydration failed: ${error.message}`);
    }
  }

  async recordPrediction(options: RecordPredictionOptions = {}): Promise<void> {
    const { latency, inputData, outputData, ...customAttributes } = options;

    const span = this._tracer.startSpan('record_prediction', {
      attributes: customAttributes,
    });

    try {
      this.predictionCounter.add(1, customAttributes);

      if (latency !== undefined) {
        this.latencyHistogram.record(latency, customAttributes);
      }

      // Story 1.18: Attach input_data if capture enabled (for drift monitoring)
      if (this.config.captureInputData && inputData !== undefined) {
        const sanitizedInput = sanitizeCredentials(inputData);
        const extractedInput = extractModelPayload(
          sanitizedInput,
          this.config.captureMaxSizeBytes
        );

        if (extractedInput.data) {
          span.setAttribute('model.input.data', extractedInput.data);
        }
        if (extractedInput.shape) {
          span.setAttribute('model.input.shape', extractedInput.shape);
        }
        span.setAttribute('model.input.truncated', extractedInput.truncated);
      }

      // Story 1.18: Attach output if capture enabled (for drift monitoring)
      if (this.config.captureOutputData && outputData !== undefined) {
        const sanitizedOutput = sanitizeCredentials(outputData);
        const extractedOutput = extractModelPayload(
          sanitizedOutput,
          this.config.captureMaxSizeBytes
        );

        if (extractedOutput.data) {
          span.setAttribute('model.output.data', extractedOutput.data);
        }
        if (extractedOutput.shape) {
          span.setAttribute('model.output.shape', extractedOutput.shape);
        }
        span.setAttribute('model.output.truncated', extractedOutput.truncated);
      }

      span.setStatus({ code: 1 }); // OK
    } catch (error: any) {
      span.setStatus({ code: 2, message: error.message }); // ERROR
      throw error;
    } finally {
      span.end();
    }
  }

  async recordMetric(
    name: string,
    value: number,
    attributes: MetricAttributes = {}
  ): Promise<void> {
    const counter = this._meter.createCounter(name);
    counter.add(value, attributes);
  }

  /**
   * Force flush all telemetry providers.
   *
   * This method forces all OpenTelemetry providers (metrics, logs, and traces)
   * to flush their internal buffers to the configured exporters immediately.
   * Safe to call mid-lifecycle (e.g., after processing a batch).
   *
   * @param timeoutMs - Maximum time to wait for flush in milliseconds (default: 30000)
   * @returns Promise<boolean> - True if flush was successful without errors
   *
   * @example
   * ```typescript
   * // Flush after processing a batch
   * await processBatch();
   * const success = await client.flush();
   * if (!success) {
   *   console.warn('Flush timed out or failed');
   * }
   * ```
   */
  async flush(timeoutMs: number = 30000): Promise<boolean> {
    if (this.isShutdown) {
      sdkLogger.debug('Client already shut down - ignoring flush()');
      return false;
    }

    const flushPromise = Promise.allSettled([
      this.meterProvider.forceFlush(),
      this.tracerProvider.forceFlush(),
      this.loggerProvider.forceFlush()
    ]);

    let timeoutId: NodeJS.Timeout;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error('Flush timeout')), timeoutMs);
    });

    try {
      const results = await Promise.race([flushPromise, timeoutPromise]) as PromiseSettledResult<void>[];
      const allSucceeded = results.every(r => r.status === 'fulfilled');
      if (!allSucceeded) {
        sdkLogger.debug('Some providers failed to flush');
      }
      return allSucceeded;
    } catch (error: any) {
      sdkLogger.warn(`Flush failed or timed out: ${error.message}`);
      return false;
    } finally {
      clearTimeout(timeoutId!); // Critical: Free the event loop immediately
    }
  }

  /**
   * Start tracking an agent goal.
   *
   * Creates a new goal with a unique ID, starts a parent span, and
   * increments the goals_started counter. The goal must be completed
   * by calling recordGoalCompleted() with the returned goal_id.
   *
   * @param description - Human-readable description of the goal
   * @param type - Category of goal (e.g., "research", "analysis", "general")
   * @param attributes - Additional attributes to attach to the goal span
   * @returns Unique goal_id (UUID string) for tracking and completion
   *
   * @warning HIPAA COMPLIANCE: description is truncated but NOT sanitized for PHI.
   * Users MUST NOT include patient identifiers, SSNs, names, or other PHI
   * in goal descriptions. Use generic descriptions only.
   *
   * @example
   * ```typescript
   * const goalId = client.recordGoalStarted(
   *   'Research diabetes treatments',
   *   'research'
   * );
   * // ... execute goal steps ...
   * client.recordGoalCompleted(goalId, 'success');
   * ```
   */
  recordGoalStarted(
    description: string,
    type: string = 'general',
    attributes?: Attributes
  ): string {
    const descriptionSanitized = description ? description.slice(0, 200) : 'No description';
    const typeSanitized = type ? type.slice(0, 50) : 'general';

    const goalId = randomUUID();
    const startTime = performance.now();

    // Start goal span
    const span = this._tracer.startSpan('agent.goal', {
      attributes: {
        goal_id: goalId,
        goal_type: typeSanitized,
        goal_description: descriptionSanitized,
        ...attributes
      }
    });

    // Store for later completion
    this.activeGoals.set(goalId, { span, startTime });

    // Increment counter
    this.goalsStartedCounter.add(1, { goal_type: typeSanitized });

    sdkLogger.debug(`Goal started: ${goalId} - ${descriptionSanitized.slice(0, 50)}`);

    return goalId;
  }

  /**
   * Complete tracking of an agent goal.
   *
   * Ends the goal span, records duration metrics, and increments the
   * goals_completed counter with the specified status.
   *
   * @param goalId - The goal ID returned from recordGoalStarted()
   * @param status - Completion status: "success", "failure", or "partial" (default: "success")
   * @param attributes - Additional attributes to attach to the goal span
   * @throws Error if goal_id is not found or status is invalid
   *
   * @example
   * ```typescript
   * try {
   *   await executeGoal(goalId);
   *   client.recordGoalCompleted(goalId, 'success');
   * } catch (error) {
   *   client.recordGoalCompleted(goalId, 'failure');
   * }
   * ```
   */
  recordGoalCompleted(
    goalId: string,
    status: GoalStatus = 'success',
    attributes?: Attributes
  ): void {
    const validStatuses: GoalStatus[] = ['success', 'failure', 'partial'];
    if (!validStatuses.includes(status)) {
      throw new Error(
        `Invalid goal status: ${status}. Must be one of: ${validStatuses.join(', ')}`
      );
    }

    const goalData = this.activeGoals.get(goalId);
    if (!goalData) {
      throw new Error(`Goal ID not found: ${goalId}. Did you call recordGoalStarted()?`);
    }

    const { span, startTime } = goalData;
    const duration = (performance.now() - startTime) / 1000; // Convert to seconds

    // Set span attributes
    span.setAttribute('goal_status', status);
    span.setAttribute('goal_completion_time', new Date().toISOString());
    if (attributes) {
      Object.entries(attributes).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          span.setAttribute(key, value);
        }
      });
    }

    // Set span status
    if (status === 'success') {
      span.setStatus({ code: SpanStatusCode.OK });
    } else {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `Goal ${status}` });
    }

    span.end();

    // Record metrics
    if (status === 'success') {
      this.goalsCompletedCounter.add(1, { goal_status: status });
    } else {
      this.goalsFailedCounter.add(1, { goal_status: status });
    }

    this.goalDurationHistogram.record(duration, { goal_status: status });

    // Clean up
    this.activeGoals.delete(goalId);

    // Clean up tool execution state for this goal (exact prefix match to prevent accidental wipes)
    const prefix = `${goalId}:`;
    const keysToDelete: string[] = [];
    for (const key of this.toolExecutionState.keys()) {
      if (key.startsWith(prefix)) {
        keysToDelete.push(key);
      }
    }
    keysToDelete.forEach(key => this.toolExecutionState.delete(key));

    sdkLogger.debug(`Goal completed: ${goalId} - status=${status}, duration=${duration.toFixed(2)}s`);
  }

  /**
   * Track a tool execution with automatic span creation and error handling.
   *
   * Executes the provided async function within a tool span, recording metrics
   * and handling errors appropriately. The span is automatically linked to the
   * parent goal span if goalId is provided.
   *
   * @param toolName - Name of the tool being executed
   * @param fn - Async function to execute
   * @param goalId - Optional goal ID to link this tool execution to
   * @param attributes - Additional attributes to attach to the span
   * @returns Promise resolving to the result of fn()
   * @throws Re-throws any error from fn() after recording it
   *
   * @example
   * ```typescript
   * const result = await client.trackTool(
   *   'search_database',
   *   async () => {
   *     return await database.search(query);
   *   },
   *   goalId,
   *   { query: 'diabetes' }
   * );
   * ```
   */
  async trackTool<T>(
    toolName: string,
    fn: () => Promise<T>,
    goalId?: string,
    attributes?: Attributes
  ): Promise<T> {
    const startTime = performance.now();
    const sanitizedName = toolName.slice(0, 100);

    // Set parent span context if goal exists
    let ctx = context.active();
    if (goalId && this.activeGoals.has(goalId)) {
      const goalData = this.activeGoals.get(goalId)!;
      ctx = trace.setSpan(ctx, goalData.span);
    }

    const span = this._tracer.startSpan(
      `agent.tool.${sanitizedName}`,
      {
        attributes: {
          tool_name: sanitizedName,
          goal_id: goalId,
          ...attributes
        }
      },
      ctx
    );

    // Story 1.19: Check for retry scenario (recovery tracking)
    let isRetryAttempt = false;
    const stateKey = goalId ? `${goalId}:${sanitizedName}` : null;
    if (stateKey && this.toolExecutionState.has(stateKey)) {
      isRetryAttempt = true;
      span.setAttribute('genai.agent.recovery.attempted', true);
    }

    // Execute fn() within context to preserve trace hierarchy
    return context.with(trace.setSpan(ctx, span), async () => {
      try {
        const result = await fn();
        const latency = (performance.now() - startTime) / 1000;

        span.setAttribute('genai.agent.tool.success', true);
        span.setStatus({ code: SpanStatusCode.OK });

        // Story 1.19: Track recovery success if this was a retry
        if (isRetryAttempt && stateKey) {
          span.setAttribute('genai.agent.recovery_success', true);
          // Clear retry state on successful recovery
          this.toolExecutionState.delete(stateKey);
        }

        this.toolCallsCounter.add(1, { tool_name: sanitizedName, status: 'success' });
        this.toolLatencyHistogram.record(latency, { tool_name: sanitizedName });

        return result;
      } catch (error: any) {
        const latency = (performance.now() - startTime) / 1000;

        span.setAttribute('genai.agent.tool.success', false);
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });

        // Story 1.19: Track recovery failure if this was a retry
        if (isRetryAttempt && stateKey) {
          span.setAttribute('genai.agent.recovery_success', false);
        }

        this.toolCallsCounter.add(1, { tool_name: sanitizedName, status: 'error' });
        this.toolLatencyHistogram.record(latency, { tool_name: sanitizedName });

        // Track retry state only if parent goal exists (prevent phantom goal leaks)
        if (goalId && this.activeGoals.has(goalId) && stateKey) {
          this.toolExecutionState.set(stateKey, { firstFailed: true });
        }

        throw error;
      } finally {
        // Guarantee span closure regardless of application or telemetry errors
        span.end();
      }
    });
  }

  /**
   * Record a human intervention event.
   *
   * Tracks when an agent requires human input or intervention, including
   * the reason and wait time. Adds a span event to the currently active span.
   *
   * Story 1.19: Event-mode human intervention (uses span events, not separate spans).
   *
   * @param reason - Reason for human intervention
   * @param waitTime - Time waited for human response in seconds
   * @param type - Type of intervention (default: "input")
   * @param timestamp - Optional epoch timestamp in milliseconds (defaults to Date.now())
   * @param attributes - Additional attributes
   *
   * @example
   * ```typescript
   * client.recordHumanIntervention(
   *   'Ambiguous query requires clarification',
   *   45.2,
   *   'clarification'
   * );
   * ```
   */
  recordHumanIntervention(
    reason: string,
    waitTime: number,
    type: string = 'input',
    timestamp?: number,
    attributes?: Attributes
  ): void {
    const reasonSanitized = reason.slice(0, 200);
    const typeSanitized = type.slice(0, 50);

    // Story 1.19: Validate timestamp is epoch time (not performance.now())
    // Reasonable range: between 2020 and 2100 in milliseconds
    const now = Date.now();
    const minValidTimestamp = 1577836800000; // 2020-01-01
    const maxValidTimestamp = 4102444800000; // 2100-01-01
    let validatedTimestamp = timestamp || now;

    if (timestamp && (timestamp < minValidTimestamp || timestamp > maxValidTimestamp)) {
      sdkLogger.warn(
        `Invalid timestamp ${timestamp} provided to recordHumanIntervention. ` +
        `Expected epoch time in milliseconds. Using current time instead.`
      );
      validatedTimestamp = now;
    }

    // Increment counter
    this.humanInterventionCounter.add(1, {
      reason: reasonSanitized,
      intervention_type: typeSanitized
    });

    // Story 1.19: Add span event to current active span (not a new span)
    const activeSpan = trace.getActiveSpan();
    if (activeSpan) {
      activeSpan.addEvent('human_intervention', {
        reason: reasonSanitized,
        wait_time_seconds: waitTime,
        intervention_type: typeSanitized,
        timestamp: validatedTimestamp,
        ...attributes
      });
    }

    sdkLogger.debug(`Human intervention: ${reasonSanitized} (wait=${waitTime.toFixed(2)}s)`);
  }

  /**
   * Record a policy violation.
   *
   * Tracks when an agent detects or triggers a policy violation.
   * Increments a counter and adds a span event if within an active span.
   *
   * @param policyType - Type of policy that was violated
   *
   * @example
   * ```typescript
   * client.recordPolicyViolation('data_access_unauthorized');
   * ```
   */
  recordPolicyViolation(policyType: string): void {
    const policyTypeSanitized = policyType.slice(0, 50);

    // Increment counter
    this.policyViolationsCounter.add(1, { policy_type: policyTypeSanitized });

    // Add span event if active span exists
    const activeSpan = trace.getActiveSpan();
    if (activeSpan) {
      activeSpan.addEvent('policy_violation', {
        policy_type: policyTypeSanitized,
        severity: 'high'
      });
    }

    sdkLogger.warn(`Policy violation: ${policyTypeSanitized}`);
  }

  /**
   * Track an agent reasoning step with automatic span creation and metrics.
   *
   * Executes the provided async function within a reasoning step span, recording
   * duration and metadata. This allows visibility into planning, evaluation,
   * tool selection, and other cognitive processes in agentic workflows.
   *
   * @param stepType - Type of reasoning step (e.g., "planning", "tool_selection", "evaluation", "synthesis")
   * @param fn - Async function to execute within the reasoning step context
   * @param options - Optional configuration: stepDescription, llmModel, and additional attributes
   * @returns Promise resolving to the result of fn()
   * @throws Re-throws any error from fn() after recording it
   *
   * @example
   * ```typescript
   * const result = await client.reasoningStep(
   *   'planning',
   *   async (span) => {
   *     span.setAttribute('tokens_used', 150);
   *     return await planner.createPlan(query);
   *   },
   *   { stepDescription: 'Analyzing query', llmModel: 'gpt-4' }
   * );
   * ```
   */
  async reasoningStep<T>(
    stepType: string,
    fn: (span: Span) => Promise<T>,
    options: { stepDescription?: string; llmModel?: string; [key: string]: any } = {}
  ): Promise<T> {
    // Sanitize inputs to prevent high-cardinality issues
    const stepTypeSanitized = stepType ? stepType.slice(0, 50) : 'unknown';
    const stepDescriptionSanitized = options.stepDescription
      ? options.stepDescription.slice(0, 200)
      : undefined;
    const llmModelSanitized = options.llmModel ? options.llmModel.slice(0, 50) : undefined;
    const startTime = performance.now();

    // Build span attributes
    const spanAttributes: any = {
      reasoning_step_type: stepTypeSanitized,
      ...options
    };
    // Remove known options from attributes to avoid duplication
    delete spanAttributes.stepDescription;
    delete spanAttributes.llmModel;

    if (stepDescriptionSanitized) {
      spanAttributes.reasoning_step_description = stepDescriptionSanitized;
    }
    if (llmModelSanitized) {
      spanAttributes.llm_model = llmModelSanitized;
    }

    // Create span for reasoning step
    const span = this._tracer.startSpan('agent.reasoning_step', {
      attributes: spanAttributes
    });

    // Execute fn() within context to preserve trace hierarchy
    return context.with(trace.setSpan(context.active(), span), async () => {
      try {
        const result = await fn(span);
        const duration = (performance.now() - startTime) / 1000;

        span.setStatus({ code: SpanStatusCode.OK });
        span.end();

        // Record successful completion
        this.reasoningStepsCounter.add(1, {
          step_type: stepTypeSanitized,
          status: 'success'
        });

        sdkLogger.debug(
          `Reasoning step completed: type=${stepTypeSanitized}, duration=${duration.toFixed(3)}s`
        );

        return result;
      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        span.end();

        // Record failure
        this.reasoningStepsCounter.add(1, {
          step_type: stepTypeSanitized,
          status: 'error'
        });

        throw error;
      }
    });
  }

  /**
   * Get the current singleton MCAClient instance.
   *
   * Returns the currently active client instance if one exists.
   * Useful for auto-instrumentation or decorators where explicit
   * parameter passing is not convenient.
   *
   * @returns The active MCAClient instance, or null if no instance exists
   *
   * @example
   * ```typescript
   * const client = MCAClient.getInstance();
   * if (client) {
   *   await client.recordPrediction({ latency: 0.15 });
   * }
   * ```
   */
  static getInstance(): MCAClient | null {
    return MCAClient._instance;
  }

  /**
   * Record an error with full span and metric tracking.
   *
   * Creates a dedicated error span, records the error via OTel semantic conventions,
   * and updates both predictions_total and errors_total metrics.
   * Handles any thrown value (Error, string, primitive, null) safely.
   *
   * @param error - Error object or any thrown value to record
   * @param latency - Optional prediction latency in seconds
   * @param predictionId - Optional prediction ID (generated if not provided)
   * @param attributes - Additional attributes
   * @returns Sanitized error message
   *
   * @example
   * ```typescript
   * try {
   *   await model.predict(data);
   * } catch (error) {
   *   client.recordError(error, latency, predictionId);
   *   throw error;
   * }
   * ```
   */
  recordError(
    error: unknown,
    latency?: number,
    predictionId?: string,
    attributes?: Attributes
  ): string {
    const normalized = this.normalizeError(error);
    const id = predictionId || randomUUID();
    const errorType = normalized.type.slice(0, 64);
    const errorMessage = this.sanitizeErrorMessage(normalized.message);

    const spanAttrs: Attributes = {
      prediction_id: id,
      error_type: errorType,
      error_message: errorMessage,
      ...attributes
    };
    if (latency !== undefined) {
      spanAttrs.latency = latency;
    }

    const span = this._tracer.startSpan('record_error', {
      attributes: spanAttrs
    });

    // Use OTel semantic conventions with normalized Error object
    span.recordException(normalized.original);
    span.setStatus({ code: SpanStatusCode.ERROR, message: errorMessage });
    span.end();

    // Dual recording
    this.predictionCounter.add(1, { status: 'error', error_type: errorType });
    this.errorsCounter.add(1, { error_type: errorType });

    return errorMessage;
  }

  /**
   * Record model evaluation metrics (MAE, RMSE).
   *
   * @param options - Evaluation options
   * @param options.mae - Mean Absolute Error
   * @param options.rmse - Root Mean Squared Error
   * @param options.dataset - Dataset name (default: "validation")
   * @param options.attributes - Additional attributes
   *
   * @example
   * ```typescript
   * client.recordEvaluation({
   *   mae: 0.15,
   *   rmse: 0.23,
   *   dataset: 'test',
   *   attributes: { model_version: '2.0' }
   * });
   * ```
   */
  recordEvaluation(options: EvaluationOptions): void {
    const dataset = options.dataset || 'validation';
    const attrs = { dataset, ...options.attributes };

    if (options.mae !== undefined) {
      this.maeHistogram.record(options.mae, attrs);
    }

    if (options.rmse !== undefined) {
      this.rmseHistogram.record(options.rmse, attrs);
    }
  }

  /**
   * Record a custom counter metric.
   *
   * Creates and caches a Counter instrument for the given name, then increments it.
   * Instruments are cached with a limit of 1000 to prevent memory leaks from
   * dynamic metric names.
   *
   * @param name - Metric name (avoid including dynamic data like user IDs)
   * @param value - Value to add (default: 1)
   * @param attributes - Metric attributes (use this for dynamic data)
   *
   * @example
   * ```typescript
   * client.recordCounter('custom.cache_hits', 1, { cache_type: 'redis' });
   * ```
   */
  recordCounter(name: string, value: number = 1, attributes?: Attributes): void {
    const counter = this.getOrCreateCounter(name);
    if (counter) {
      counter.add(value, attributes);
    }
  }

  /**
   * Record an absolute gauge value (not cumulative).
   *
   * Uses OpenTelemetry Gauge for proper absolute value semantics.
   * Instruments are cached with a limit of 1000 to prevent memory leaks.
   *
   * @param name - Metric name (avoid including dynamic data)
   * @param value - Absolute gauge value (e.g., current queue size)
   * @param attributes - Metric attributes (use this for dynamic data)
   *
   * @example
   * ```typescript
   * // Record current queue size (absolute value, not cumulative)
   * client.recordGauge('custom.queue_size', 42, { queue: 'processing' });
   * // Later, if queue shrinks to 30, record that absolute value
   * client.recordGauge('custom.queue_size', 30, { queue: 'processing' });
   * ```
   */
  recordGauge(name: string, value: number, attributes?: Attributes): void {
    const gauge = this.getOrCreateGauge(name);
    if (gauge) {
      gauge.record(value, attributes);
    }
  }

  /**
   * Cleanup stale goals older than 1 hour.
   * Called automatically by background cleanup interval.
   */
  private cleanupStaleGoals(): void {
    const now = performance.now();
    const oneHourMs = 60 * 60 * 1000;

    this.activeGoals.forEach((goalData, goalId) => {
      const age = now - goalData.startTime;
      if (age > oneHourMs) {
        sdkLogger.warn(`Cleaning up stale goal: ${goalId} (age=${(age / 1000).toFixed(0)}s)`);
        try {
          this.recordGoalCompleted(goalId, 'failure', { timeout: true });
        } catch (error: any) {
          sdkLogger.error(`Failed to cleanup stale goal ${goalId}: ${error.message}`);
        }
      }
    });
  }

  /**
   * Safely get or create a dynamic counter with memory bounds checking.
   * Returns undefined if the cache limit is reached to prevent OOM.
   */
  private getOrCreateCounter(name: string): Counter | undefined {
    if (this.dynamicCounters.has(name)) {
      return this.dynamicCounters.get(name);
    }

    if (this.dynamicCounters.size >= MCAClient.MAX_DYNAMIC_METRICS) {
      sdkLogger.warn(`Metric cache limit reached (${MCAClient.MAX_DYNAMIC_METRICS}). Dropping new counter: ${name}`);
      return undefined;
    }

    const counter = this._meter.createCounter(name);
    this.dynamicCounters.set(name, counter);
    return counter;
  }

  /**
   * Safely get or create a dynamic gauge with memory bounds checking.
   * Returns undefined if the cache limit is reached to prevent OOM.
   */
  private getOrCreateGauge(name: string): Gauge | undefined {
    if (this.dynamicGauges.has(name)) {
      return this.dynamicGauges.get(name);
    }

    if (this.dynamicGauges.size >= MCAClient.MAX_DYNAMIC_METRICS) {
      sdkLogger.warn(`Metric cache limit reached (${MCAClient.MAX_DYNAMIC_METRICS}). Dropping new gauge: ${name}`);
      return undefined;
    }

    const gauge = this._meter.createGauge(name);
    this.dynamicGauges.set(name, gauge);
    return gauge;
  }

  /**
   * Normalize any thrown value into a consistent error structure.
   * Handles Error objects, strings, and arbitrary thrown values.
   */
  private normalizeError(err: unknown): { message: string; type: string; original: Error } {
    if (err instanceof Error) {
      return {
        message: err.message || 'Unknown error',
        type: err.name || err.constructor?.name || 'Error',
        original: err
      };
    }
    if (typeof err === 'string') {
      return { message: err, type: 'StringError', original: new Error(err) };
    }
    // Handle primitive throws and null/undefined
    const fallbackMessage = err ? String(err) : 'Unknown error';
    return {
      message: fallbackMessage,
      type: 'UnknownError',
      original: new Error(fallbackMessage)
    };
  }

  /**
   * Sanitize error message to remove sensitive information.
   * Handles undefined/null gracefully.
   */
  private sanitizeErrorMessage(message: string | undefined): string {
    if (!message) return 'Unknown error';

    let sanitized = message.slice(0, 200);

    // Mask common credential patterns
    sanitized = sanitized.replace(/api[_-]?key[:\s=]+[\w-]+/gi, 'api_key=***');
    sanitized = sanitized.replace(/token[:\s=]+[\w-]+/gi, 'token=***');
    sanitized = sanitized.replace(/password[:\s=]+[\w-]+/gi, 'password=***');

    return sanitized;
  }

  get meter(): Meter {
    return this._meter;
  }

  get tracer(): Tracer {
    return this._tracer;
  }

  get logger(): Logger {
    return this._logger;
  }

  get thresholdsConfig(): Record<string, number> {
    return { ...this.thresholds };
  }

  async shutdown(timeoutMs: number = 30000): Promise<boolean> {
    if (this.isShutdown) {
      sdkLogger.debug('Client already shut down');
      return true;
    }

    sdkLogger.info('Shutting down MCAClient');

    // Stop background cleanup
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }

    // Close any active goals (snapshot keys to avoid concurrent modification)
    const activeGoalIds = Array.from(this.activeGoals.keys());
    for (const goalId of activeGoalIds) {
      try {
        this.recordGoalCompleted(goalId, 'failure', { shutdown: true });
      } catch (error: any) {
        sdkLogger.error(`Failed to close goal ${goalId} during shutdown: ${error.message}`);
      }
    }

    if (this.registryClient) {
      this.registryClient.stop();
    }

    // Clear singleton instance
    if (MCAClient._instance === this) {
      MCAClient._instance = null;
    }

    this.isShutdown = true;

    return shutdownProviders(
      this.meterProvider,
      this.tracerProvider,
      this.loggerProvider,
      timeoutMs
    );
  }
}
