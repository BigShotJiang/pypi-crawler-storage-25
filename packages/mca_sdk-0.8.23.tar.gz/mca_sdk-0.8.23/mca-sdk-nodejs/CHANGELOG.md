# Changelog

All notable changes to the MCA SDK for Node.js will be documented in this file.

## [0.4.2] - 2026-04-07

### Changed - **BREAKING**
- **Package name:** Reverted from `@mca/sdk` (scoped) back to `mca-sdk` (unscoped) for simpler publishing without requiring npm organization.
- **Installation:** Use `npm install mca-sdk` instead of `npm install @mca/sdk`
- **Imports:** Use `import { MCAClient } from 'mca-sdk'` instead of `from '@mca/sdk'`

### Removed
- Removed `publishConfig.access` field from package.json (not needed for unscoped packages)

## [0.4.1] - 2026-04-07

### Changed - **BREAKING**
- **Package name:** `mca-sdk` → `@mca/sdk` (scoped npm package)
- **Peer dependency added:** `@opentelemetry/api@1.9.0` must be installed by consumers.
- **Node.js support:** Minimum version lowered from 18.x to 16.x, though internal builds target Node 18.
- **Strict Dependency Pinning:** Pinned `@opentelemetry` dependencies to exact versions to avoid breaking changes in the 0.x ecosystem.

### Added
- Repository metadata in package.json (links to GitHub from npm registry).
- Cross-platform build support (rimraf for Windows compatibility).
- Module encapsulation via "exports" field.

### Fixed
- LICENSE file now properly included in npm package.
- Author contact information added to package metadata.
- ESLint configuration properly handles test files.
- Disabled source maps entirely to prevent leaking internal package structure and inflating package size.
- Fixed `js-yaml` type leak by ensuring `@types/js-yaml` stays in `devDependencies` and explicitly typing YAML parsed output.

### Security
- `publishConfig` ensures scoped package publishes as public.

## [0.4.0] - 2026-03-30

### Added - Story 1.22: Feature Parity with Python SDK v0.8.8

#### Agentic AI Enhancements
- **Reasoning Step Tracking**: New `reasoningStep()` async wrapper for tracking agent reasoning steps with automatic span creation and counter metrics
- **Recovery Tracking**: Enhanced `trackTool()` with automatic retry detection and recovery success/failure tracking
- **Event-Mode Human Intervention**: Updated `recordHumanIntervention()` with timestamp validation and proper span event integration

#### Input/Output Data Capture
- **Configuration**: Added `captureInputData`, `captureOutputData`, and `captureMaxSizeBytes` configuration options
- **recordPrediction Enhancement**: Now supports `inputData` and `outputData` parameters for drift monitoring
- **Automatic Serialization**: Input/output data is automatically serialized and attached to spans with shape information
- **Credential Sanitization**: Built-in masking of AWS keys, GCP keys, GitHub tokens, JWT, and Bearer tokens

#### Utilities
- **Serialization Module**: New `src/utils/serialization.ts` with:
  - `serializeForTelemetry()` - Safe JSON serialization with truncation
  - `extractModelPayload()` - Extract data and shape with size limits
  - `sanitizeCredentials()` - Recursive credential masking for security

#### Developer Experience
- **Singleton Access**: New `MCAClient.getInstance()` static method for accessing the active client instance
- **Metric Filtering**: System metrics (`process.*`, `nodejs.*`, `system.*`) are automatically filtered to reduce Cloud Monitoring costs

### Changed
- Bumped version to 0.4.0 to reflect significant feature additions
- Enhanced error handling with better timestamp validation
- Improved TypeScript type definitions for new APIs

### Security
- Added automatic credential sanitization for all input/output data capture
- Respects OpenTelemetry 128KB span attribute limits to prevent exporter crashes

## [0.3.0] - Previous Release

Initial Node.js SDK implementation with core features:
- Basic prediction recording
- Goal and tool tracking
- Error recording
- Custom metrics
- Registry integration
- Configuration management
