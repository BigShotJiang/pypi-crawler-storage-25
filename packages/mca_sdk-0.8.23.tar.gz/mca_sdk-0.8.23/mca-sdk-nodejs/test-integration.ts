// Integration test for Node.js MCA SDK with OTel Collector
import { withMCAClient } from './src';

async function testIntegration() {
  console.log('🚀 Starting Node.js MCA SDK Integration Test...\n');

  await withMCAClient(
    {
      serviceName: 'nodejs-test-model',
      modelId: 'mdl-nodejs-001',
      modelVersion: '1.0.0',
      teamName: 'test-team',
      modelType: 'internal',
      collectorEndpoint: 'http://localhost:4318',
      strictValidation: false,
    },
    async (client) => {
      console.log('✓ MCAClient initialized successfully');

      // Test 1: Record prediction with latency (AC #1)
      await client.recordPrediction({
        latency: 0.123,
        model_version: 'v1.0',
        prediction_id: 'pred-001',
      });
      console.log('✓ Test 1: Recorded prediction with latency (AC #1)');

      // Test 2: Record prediction with custom attributes (AC #2)
      await client.recordPrediction({
        prediction_id: 'pred-002',
        custom_attribute: 'test-value',
        input_size: 100,
        output_size: 1,
      });
      console.log('✓ Test 2: Recorded prediction with custom attributes (AC #2)');

      // Test 3: Record prediction without latency
      await client.recordPrediction({
        prediction_id: 'pred-003',
      });
      console.log('✓ Test 3: Recorded prediction without latency');

      // Test 4: Record custom metric
      await client.recordMetric('custom.test_metric', 42, {
        test_label: 'integration',
        environment: 'workbench',
      });
      console.log('✓ Test 4: Recorded custom metric');

      // Test 5: Multiple concurrent predictions (AC #4)
      console.log('⏳ Test 5: Recording 10 concurrent predictions...');
      const promises = Array.from({ length: 10 }, (_, i) =>
        client.recordPrediction({
          latency: Math.random() * 0.5,
          prediction_id: `pred-batch-${i}`,
        })
      );
      await Promise.all(promises);
      console.log('✓ Test 5: Recorded 10 concurrent predictions (AC #4)');

      console.log('\n⏳ Waiting 10 seconds for metrics to export to collector...');
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  );

  console.log('✓ Client shutdown successfully (AC #3)\n');
  console.log('✅ Integration test completed!\n');
  console.log('Next steps:');
  console.log('1. Check OTel Collector logs: docker-compose logs otel-collector');
  console.log('2. Verify metrics: docker-compose logs otel-collector | grep "model.predictions"');
  console.log('3. Check resource attributes in payload');
}

testIntegration().catch((error) => {
  console.error('❌ Integration test failed:', error);
  process.exit(1);
});
