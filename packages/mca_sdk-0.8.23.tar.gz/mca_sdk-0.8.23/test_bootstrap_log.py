import os

print("Running test...")
print(f"MCA_MODEL_ID={os.environ.get('MCA_MODEL_ID')}")
