// Package mca provides OpenTelemetry instrumentation for ML models.
package mca

import (
	"encoding/json"
	"fmt"
	"reflect"
)

const (
	// MaxSerializedLength is the maximum length for serialized data (1MB OpenTelemetry limit)
	MaxSerializedLength = 1048576
)

// StructToAttributes converts a Go struct to a flat map of attributes suitable for OpenTelemetry.
// Nested structs are flattened using dot notation (e.g., "user.name", "user.age").
// Unexported fields are skipped. Unsupported types (channels, functions, unsafe pointers) return an error.
//
// Example:
//
//	type User struct {
//	    Name string
//	    Age  int
//	    Address struct {
//	        City string
//	        Zip  int
//	    }
//	}
//	user := User{Name: "Alice", Age: 30, Address: struct{City string; Zip int}{City: "NYC", Zip: 10001}}
//	attrs, err := StructToAttributes(user)
//	// attrs = map[string]interface{}{
//	//     "Name": "Alice",
//	//     "Age": 30,
//	//     "Address.City": "NYC",
//	//     "Address.Zip": 10001,
//	// }
func StructToAttributes(v interface{}) (map[string]interface{}, error) {
	result := make(map[string]interface{})
	err := structToAttributesRecursive(reflect.ValueOf(v), "", result, 0)
	return result, err
}

// structToAttributesRecursive recursively processes struct fields with depth limiting.
func structToAttributesRecursive(v reflect.Value, prefix string, result map[string]interface{}, depth int) error {
	// Prevent infinite recursion on deeply nested or circular structures
	const maxDepth = 10
	if depth > maxDepth {
		return fmt.Errorf("maximum nesting depth (%d) exceeded", maxDepth)
	}

	// Dereference pointers
	for v.Kind() == reflect.Ptr {
		if v.IsNil() {
			return nil // Skip nil pointers
		}
		v = v.Elem()
	}

	// Handle non-struct types at top level
	if v.Kind() != reflect.Struct {
		val, err := convertValue(v)
		if err != nil {
			return err
		}
		if prefix != "" {
			result[prefix] = val
		}
		return nil
	}

	// Process struct fields
	t := v.Type()
	for i := 0; i < v.NumField(); i++ {
		field := t.Field(i)
		fieldValue := v.Field(i)

		// Skip unexported fields
		if !field.IsExported() {
			continue
		}

		// Build field name with prefix
		fieldName := field.Name
		if prefix != "" {
			fieldName = prefix + "." + field.Name
		}

		// Handle different field types
		switch fieldValue.Kind() {
		case reflect.Struct:
			// Recursively process nested structs
			if err := structToAttributesRecursive(fieldValue, fieldName, result, depth+1); err != nil {
				return err
			}
		case reflect.Ptr:
			// Dereference pointer and process
			if !fieldValue.IsNil() {
				if err := structToAttributesRecursive(fieldValue, fieldName, result, depth+1); err != nil {
					return err
				}
			}
		case reflect.Slice, reflect.Array:
			// Convert slices/arrays to JSON string representation
			val, err := convertValue(fieldValue)
			if err != nil {
				return fmt.Errorf("field %s: %w", fieldName, err)
			}
			result[fieldName] = val
		case reflect.Map:
			// Convert maps to JSON string representation
			val, err := convertValue(fieldValue)
			if err != nil {
				return fmt.Errorf("field %s: %w", fieldName, err)
			}
			result[fieldName] = val
		case reflect.Chan, reflect.Func, reflect.UnsafePointer:
			return fmt.Errorf("unsupported type %s for field %s", fieldValue.Kind(), fieldName)
		default:
			// Basic types: bool, int, float, string, etc.
			val, err := convertValue(fieldValue)
			if err != nil {
				return fmt.Errorf("field %s: %w", fieldName, err)
			}
			result[fieldName] = val
		}
	}

	return nil
}

// convertValue converts a reflect.Value to a basic Go type suitable for telemetry.
func convertValue(v reflect.Value) (interface{}, error) {
	// Dereference pointers
	for v.Kind() == reflect.Ptr {
		if v.IsNil() {
			return nil, nil
		}
		v = v.Elem()
	}

	switch v.Kind() {
	case reflect.Bool:
		return v.Bool(), nil
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return v.Int(), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return int64(v.Uint()), nil
	case reflect.Float32, reflect.Float64:
		return v.Float(), nil
	case reflect.String:
		return v.String(), nil
	case reflect.Slice, reflect.Array, reflect.Map, reflect.Struct:
		// For complex types, serialize to JSON string
		data, err := json.Marshal(v.Interface())
		if err != nil {
			return nil, fmt.Errorf("failed to marshal to JSON: %w", err)
		}
		return string(data), nil
	case reflect.Chan, reflect.Func, reflect.UnsafePointer:
		return nil, fmt.Errorf("unsupported type: %s", v.Kind())
	default:
		// Fallback to string representation
		return fmt.Sprintf("%v", v.Interface()), nil
	}
}

// SerializeForTelemetry serializes data for telemetry with size truncation.
// Returns the original value for basic types (nil, bool, int, float, string).
// Converts complex types to JSON strings and truncates if exceeds maxLength.
//
// This function is used internally for input/output data capture.
func SerializeForTelemetry(data interface{}, maxLength int) (string, error) {
	if data == nil {
		return "", nil
	}

	// For basic types, convert to string
	switch v := data.(type) {
	case string:
		if len(v) <= maxLength {
			return v, nil
		}
		return truncateString(v, maxLength), nil
	case bool, int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64, float32, float64:
		return fmt.Sprintf("%v", v), nil
	}

	// For complex types, marshal to JSON
	jsonData, err := json.Marshal(data)
	if err != nil {
		return "", fmt.Errorf("failed to serialize data: %w", err)
	}

	jsonStr := string(jsonData)
	if len(jsonStr) <= maxLength {
		return jsonStr, nil
	}

	return truncateString(jsonStr, maxLength), nil
}

// truncateString truncates a string to maxLength with a truncation marker.
func truncateString(s string, maxLength int) string {
	const truncateMarker = "...[truncated]"
	if len(s) <= maxLength {
		return s
	}
	keepLength := maxLength - len(truncateMarker)
	if keepLength <= 0 {
		return truncateMarker
	}
	return s[:keepLength] + truncateMarker
}
