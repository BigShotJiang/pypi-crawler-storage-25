// Package mca provides OpenTelemetry instrumentation for ML models.
package mca

// Prediction represents a model prediction event with telemetry attributes.
type Prediction struct {
	// Latency is the prediction latency in seconds (optional, use nil to omit)
	// Use a pointer to distinguish between 0.0 (valid latency) and not provided
	Latency *float64

	// PredictionID is a unique identifier for correlating traces (optional)
	PredictionID string

	// Attributes are additional key-value pairs to attach to metrics/logs (optional)
	// Maximum 50 attributes allowed, string values truncated to 256 characters
	Attributes map[string]string

	// InputData is the prediction input for drift monitoring (optional)
	// IMPORTANT: Sanitize all PHI/PII BEFORE passing to SDK
	// Data is serialized to JSON and attached to span attributes
	InputData interface{}

	// OutputData is the prediction output for drift monitoring (optional)
	// IMPORTANT: Sanitize all PHI/PII BEFORE passing to SDK
	// Data is serialized to JSON and attached to span attributes
	OutputData interface{}
}
