# Release Notes - MCA SDK v0.8.10

**Release Date:** April 2, 2026  
**Type:** Critical Bug Fix

## Summary

This release fixes a critical bug where the Registry API endpoint change in v0.8.6 caused all model config fetches to fail with 404 errors. The SDK has been reverted to use the working `/api/v1/configs/{model_id}` endpoint.

## Critical Fix

### Registry API Endpoint Reverted

**Problem:**
- v0.8.6 changed the endpoint from `/api/v1/configs/{model_id}` to `/models/{model_id}`
- The new endpoint returns 404 for all registered models
- All three registered test models failed to fetch configs
- Error: `RegistryConfigNotFoundError: Model config not found`

**Solution:**
- Reverted to the working `/api/v1/configs/{model_id}` endpoint
- Testing with v0.8.5 confirmed this endpoint works correctly
- Will re-migrate once Registry team completes data migration to new endpoint

**Impact:**
- ✅ All registered models now fetch successfully
- ✅ `patient-readmission-classifier-v1` works
- ✅ `medical-research-assistant` works
- ✅ `clinical-notes-summarizer-v2` works

## Files Changed

- `mca_sdk/registry/client.py`: Endpoint reverted to `/api/v1/configs/{model_id}`
- `CHANGELOG.md`: Documented fix with version 0.8.10
- `documents/REGISTRY_API_REQUIREMENTS.md`: Updated API contract documentation
- Debug logging added during investigation has been removed

## Upgrade Instructions

### For Users on v0.8.6 - v0.8.9

```bash
pip install --upgrade mca-sdk==0.8.10
```

No code changes required - the SDK will automatically use the correct endpoint.

### Verification

Test that your model config fetches successfully:

```python
from mca_sdk.registry import RegistryClient

registry = RegistryClient(url="https://your-registry-url", use_gcp_auth=True)
config = registry.fetch_model_config("your-model-id")
print(f"✓ Fetched: {config.service_name}")
```

Expected: Should print service name without 404 errors.

## Breaking Changes

None - this is a bug fix that restores v0.8.5 behavior.

## Known Issues

None

## Next Steps

Once the Registry team completes migration to the `/models/` endpoint:
1. SDK will be updated to use the new endpoint
2. Full testing will be performed
3. Release notes will document the re-migration

## Support

If you experience issues with this release:
1. Check that you're using GCP Application Default Credentials
2. Verify connectivity to the registry endpoint
3. Confirm your model is registered in the registry
4. Contact the AI/ML team for support

## Git Tag

```bash
git fetch --tags
git checkout v0.8.10
```

## Package Files

- Wheel: `mca_sdk-0.8.10-py3-none-any.whl`
- Size: 247KB
- Python: 3.10+
