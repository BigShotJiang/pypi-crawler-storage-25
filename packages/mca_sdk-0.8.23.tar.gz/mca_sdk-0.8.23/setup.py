"""Setup configuration for MCA SDK."""

from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="mca-sdk",
    description="Model Collector Agent SDK for OpenTelemetry monitoring",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(include=["mca_sdk", "mca_sdk.*"]),
    package_data={
        "mca_sdk": ["FOR_AI_ASSISTANTS.md"],
        "": ["docker-compose.mock.yml", "config/*.yml"],  # Story 8.4: Include mock collector files
    },
    entry_points={
        "console_scripts": [
            "mca-init=mca_sdk.cli:main",  # Story 8.4: CLI for project scaffolding
            "mca-instrument=mca_sdk.cli.instrument:main",  # Story 8.1: Zero-code instrumentation
            "mca-run=mca_sdk.cli.run:main",  # Story 8.1: Zero-code MCA init
        ],
    },
    python_requires=">=3.10",
    install_requires=[
        "opentelemetry-api>=1.35.0",
        "opentelemetry-sdk>=1.35.0",
        "opentelemetry-exporter-otlp-proto-http>=1.35.0",
        "protobuf>=5.0,<6.0",
        "pyyaml>=6.0",
        "pybreaker>=1.4.1",
        "cryptography>=46.0.5",
        "requests>=2.31.0",
        "wrapt>=1.16.0",
    ],
    extras_require={
        "genai": [
            "litellm>=1.17.0",
        ],
        "vendor": [
            "flask>=3.0.0",
        ],
        "prometheus": [
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
        "gcp-auth": [
            "google-auth>=2.27.0,<3.0.0",
        ],
        "gcp-secrets": [
            "google-cloud-secret-manager>=2.26.0,<3.0.0",
        ],
        "gcp-trace": [
            "google-cloud-trace>=1.11.0,<2.0.0",
            "google-auth>=2.27.0,<3.0.0",
        ],
        "gcp-logging": [
            "google-cloud-logging>=3.13.0,<4.0.0",
        ],
        "gcp": [
            "google-auth>=2.27.0,<3.0.0",
            "google-cloud-secret-manager>=2.26.0,<3.0.0",
            "google-cloud-logging>=3.13.0,<4.0.0",
            "google-cloud-trace>=1.11.0,<2.0.0",
        ],
        "autolog": [
            "scikit-learn==1.7.2",
            "xgboost>=2.0.0",
            "lightgbm>=4.0.0",
            "numpy>=1.24.0",
        ],
        "instrument": [
            "opentelemetry-instrumentation>=0.48b0",
            "opentelemetry-distro>=0.48b0",
            # Note: Users should run `opentelemetry-bootstrap -a install`
            # to install framework-specific instrumentation libraries
        ],
        "test": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-mock>=3.12.0",
            "pytest-asyncio>=0.23.0",
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
        "dev": [
            "black>=24.0.0",
            "mypy>=1.8.0",
            "ruff>=0.1.0",
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-mock>=3.12.0",
            "pytest-asyncio>=0.23.0",
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
        "all": [
            "litellm>=1.17.0",
            "flask>=3.0.0",
            "google-auth>=2.27.0",
            "google-cloud-secret-manager>=2.26.0",
            "google-cloud-logging>=3.13.0,<4.0.0",
            "google-cloud-trace>=1.11.0,<2.0.0",
            "opentelemetry-exporter-prometheus>=0.48b0",
            "scikit-learn==1.7.2",
            "xgboost>=2.0.0",
            "lightgbm>=4.0.0",
            "numpy>=1.24.0",
            "opentelemetry-instrumentation>=0.48b0",
            "opentelemetry-distro>=0.48b0",
        ],
    },
)
