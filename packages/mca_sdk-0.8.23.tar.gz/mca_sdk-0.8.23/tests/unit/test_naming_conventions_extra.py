import pytest
from mca_sdk.validation.naming_conventions import (
    is_valid_metric_name,
    sanitize_metric_name,
)


def test_is_valid_metric_name():
    assert is_valid_metric_name("model.predictions_total") is True
    assert is_valid_metric_name("valid_metric_name") is True
    assert is_valid_metric_name("a" * 256) is True

    # Invalid
    assert is_valid_metric_name(None) is False
    assert is_valid_metric_name("") is False
    assert is_valid_metric_name("ab") is False  # Too short
    assert is_valid_metric_name("a" * 257) is False  # Too long
    assert is_valid_metric_name("invalid-name") is False  # Hyphen
    assert is_valid_metric_name("123_invalid") is False  # Starts with digit
    assert is_valid_metric_name("MetricName") is False  # Uppercase


def test_sanitize_metric_name():
    assert sanitize_metric_name("invalid-name") == "invalid_name"
    assert sanitize_metric_name("123_metric") == "m_123_metric"
    assert sanitize_metric_name("MetricName") == "metricname"
    assert sanitize_metric_name("metric name") == "metric_name"
    assert sanitize_metric_name("ab") == "metric_ab"
    assert sanitize_metric_name("") == "metric_"
    assert len(sanitize_metric_name("a" * 300)) == 256
