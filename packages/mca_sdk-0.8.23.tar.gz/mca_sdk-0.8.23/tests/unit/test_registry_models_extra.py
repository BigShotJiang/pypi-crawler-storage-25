import pytest
from mca_sdk.registry.models import (
    ModelConfig,
    VALID_MODEL_TYPES,
    VALID_MODEL_CATEGORIES,
)


def test_model_config_init_valid():
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="regression",
        model_category="internal",
    )
    assert config.service_name == "test-svc"
    assert config.model_type == "regression"


def test_model_config_legacy_migration_internal():
    # internal type -> category: internal, type: regression
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="internal",
        model_category=None,
    )
    assert config.model_category == "internal"
    assert config.model_type == "regression"


def test_model_config_legacy_migration_vendor():
    # vendor type -> category: vendor, type: regression
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="vendor",
        model_category=None,
    )
    assert config.model_category == "vendor"
    assert config.model_type == "regression"


def test_model_config_legacy_migration_generative():
    # generative type -> category: internal, type: generative
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="generative",
        model_category=None,
    )
    assert config.model_category == "internal"
    assert config.model_type == "generative"


def test_model_config_invalid_type_raises():
    with pytest.raises(ValueError, match="model_type must be one of"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="invalid-type",
            model_category="internal",
        )


def test_model_config_invalid_category_raises():
    with pytest.raises(ValueError, match="model_category must be one of"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="regression",
            model_category="invalid-category",
        )


def test_model_config_missing_category_defaults_to_internal():
    # If a valid type is provided but no category, it raises an error now!
    with pytest.raises(ValueError, match="model_category is required"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="classification",
            model_category=None,
        )
