import pytest


def test_mca_sdk_error_str():
    from mca_sdk.utils.exceptions import MCASDKError

    e = MCASDKError("Some random error")
    assert str(e) == "Some random error"


def test_mca_sdk_error_str_with_token(monkeypatch):
    from mca_sdk.utils.exceptions import MCASDKError

    monkeypatch.setenv("MCA_REGISTRY_TOKEN", "secret-token-12345")
    e = MCASDKError("Error with secret-token-12345 inside")
    # It might use sanitize_token or simple replace, so it should mask it
    assert "secret-token-12345" not in str(e)


def test_validation_error_init():
    from mca_sdk.utils.exceptions import ValidationError

    e = ValidationError(
        "test",
        missing_fields=["a"],
        invalid_fields={"b": "c"},
        model_type="t",
        model_category="c",
    )
    assert e.missing_fields == ["a"]
    assert e.invalid_fields == {"b": "c"}
    assert e.model_type == "t"
    assert e.model_category == "c"


def test_all_exceptions():
    from mca_sdk.utils.exceptions import (
        RegistryConnectionError,
        RegistryAuthError,
        RegistryConfigNotFoundError,
        SecurityError,
        CertificateError,
        CertificateLoadError,
        CertificateValidationError,
        CertificateExpiredError,
        CertificateNotLoadedError,
    )

    assert issubclass(RegistryConnectionError, Exception)
    assert issubclass(RegistryAuthError, Exception)
    assert issubclass(RegistryConfigNotFoundError, Exception)
    assert issubclass(SecurityError, Exception)
    assert issubclass(CertificateError, Exception)
    assert issubclass(CertificateLoadError, Exception)
    assert issubclass(CertificateValidationError, Exception)
    assert issubclass(CertificateExpiredError, Exception)
    assert issubclass(CertificateNotLoadedError, Exception)
