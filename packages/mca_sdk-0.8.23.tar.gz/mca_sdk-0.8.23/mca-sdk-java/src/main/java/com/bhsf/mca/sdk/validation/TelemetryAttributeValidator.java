package com.bhsf.mca.sdk.validation;

import com.bhsf.mca.sdk.exceptions.ValidationException;

import java.util.Map;

/**
 * Runtime validator for telemetry attributes.
 *
 * <p>Provides security validation functions for attribute overflow protection:
 * <ul>
 *   <li>Attribute length limits (1024 chars per value)</li>
 *   <li>Attribute count limits (128 max per span/metric)</li>
 *   <li>Nesting depth limits (5 levels max)</li>
 * </ul>
 *
 * <p>These limits prevent DoS attacks and ensure HIPAA compliance by rejecting
 * oversized attributes that might contain PHI.
 */
public class TelemetryAttributeValidator {

    // Security limits
    public static final int MAX_ATTRIBUTE_LENGTH = 1024;  // Maximum characters per attribute value
    public static final int MAX_ATTRIBUTE_COUNT = 128;    // Maximum attributes per span/metric
    public static final int MAX_KEY_LENGTH = 128;         // Maximum characters per attribute key
    public static final int MAX_NESTING_DEPTH = 5;        // Maximum nesting depth for structured attributes

    /**
     * Validates attribute key and value lengths.
     *
     * @param key Attribute key to validate
     * @param value Attribute value to validate
     * @return true if valid
     * @throws ValidationException if key or value exceeds limits
     */
    public static boolean validateAttributeLength(String key, Object value) {
        // Validate key length
        if (key == null) {
            throw new ValidationException("Attribute key cannot be null");
        }

        if (key.length() > MAX_KEY_LENGTH) {
            String truncatedKey = key.length() > 50 ? key.substring(0, 50) + "..." : key;
            throw new ValidationException(
                "Attribute key exceeds maximum length (" + MAX_KEY_LENGTH + " characters). " +
                "Key: " + truncatedKey
            );
        }

        // Validate value length
        if (value == null) {
            throw new ValidationException("Attribute value for '" + key + "' cannot be null");
        }

        String valueStr = value.toString();
        if (valueStr.length() > MAX_ATTRIBUTE_LENGTH) {
            throw new ValidationException(
                "Attribute value for '" + key + "' exceeds maximum length " +
                "(" + MAX_ATTRIBUTE_LENGTH + " characters). Got " + valueStr.length() + " characters."
            );
        }

        return true;
    }

    /**
     * Validates attribute count per span/metric.
     *
     * @param attributes Dictionary of attributes to validate
     * @return true if valid
     * @throws ValidationException if attribute count exceeds limit
     */
    public static boolean validateAttributeCount(Map<String, ?> attributes) {
        if (attributes == null) {
            return true; // Empty/null attributes are valid
        }

        if (attributes.size() > MAX_ATTRIBUTE_COUNT) {
            throw new ValidationException(
                "Attribute count exceeds maximum (" + MAX_ATTRIBUTE_COUNT + "). " +
                "Got " + attributes.size() + " attributes."
            );
        }

        return true;
    }

    /**
     * Validates attribute structure to prevent deep nesting.
     *
     * @param attributes Attribute structure to validate
     * @return true if valid
     * @throws ValidationException if nesting depth exceeds limit
     */
    public static boolean validateAttributeStructure(Object attributes) {
        return validateAttributeStructure(attributes, 0);
    }

    /**
     * Validates attribute structure to prevent deep nesting (internal recursive method).
     *
     * @param attributes Attribute structure to validate
     * @param depth Current nesting depth
     * @return true if valid
     * @throws ValidationException if nesting depth exceeds limit
     */
    private static boolean validateAttributeStructure(Object attributes, int depth) {
        if (depth > MAX_NESTING_DEPTH) {
            throw new ValidationException(
                "Attribute nesting depth exceeds maximum (" + MAX_NESTING_DEPTH + ")."
            );
        }

        if (attributes instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, ?> map = (Map<String, ?>) attributes;
            for (Object value : map.values()) {
                if (value instanceof Map) {
                    validateAttributeStructure(value, depth + 1);
                }
            }
        }

        return true;
    }

    /**
     * Validates all aspects of a set of attributes.
     *
     * <p>Convenience method that combines:
     * <ul>
     *   <li>Attribute count validation</li>
     *   <li>Attribute length validation for each key-value pair</li>
     *   <li>Attribute structure validation</li>
     * </ul>
     *
     * @param attributes Map of attributes to validate
     * @return true if all validations pass
     * @throws ValidationException if any validation fails
     */
    public static boolean validateAll(Map<String, Object> attributes) {
        if (attributes == null || attributes.isEmpty()) {
            return true;
        }

        // Validate count
        validateAttributeCount(attributes);

        // Validate structure
        validateAttributeStructure(attributes);

        // Validate each key-value pair
        for (Map.Entry<String, Object> entry : attributes.entrySet()) {
            validateAttributeLength(entry.getKey(), entry.getValue());
        }

        return true;
    }
}
