package com.bhsf.mca.sdk.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Multi-source configuration loader for MCAClient.
 *
 * <p>Loads configuration from multiple sources with clear precedence:
 * <pre>
 * builder > registry > environment > file > defaults
 * </pre>
 *
 * <p>This ensures that:
 * <ul>
 *   <li>Explicit builder values always win (developer intent)</li>
 *   <li>Registry provides dynamic runtime updates</li>
 *   <li>Environment variables work for container deployments</li>
 *   <li>Config files support local development</li>
 *   <li>Defaults provide sensible fallbacks</li>
 * </ul>
 *
 * <p>Configuration file locations (checked in order):
 * <ol>
 *   <li>~/.mca_sdk/config.yaml</li>
 *   <li>./mca-config.yaml</li>
 *   <li>./config/mca-config.yaml</li>
 *   <li>./mca-config.properties</li>
 * </ol>
 *
 * <p>Environment variables:
 * <ul>
 *   <li>MCA_SERVICE_NAME</li>
 *   <li>MCA_MODEL_ID</li>
 *   <li>MCA_TEAM_NAME</li>
 *   <li>MCA_MODEL_VERSION</li>
 *   <li>MCA_MODEL_TYPE</li>
 *   <li>MCA_MODEL_CATEGORY</li>
 *   <li>MCA_OTEL_ENDPOINT</li>
 *   <li>MCA_REGISTRY_URL</li>
 *   <li>MCA_REGISTRY_TOKEN</li>
 *   <li>MCA_USE_GCP_AUTH</li>
 *   <li>MCA_CACHE_TTL_SECS</li>
 *   <li>MCA_REFRESH_INTERVAL_SECS</li>
 *   <li>MCA_STRICT_VALIDATION</li>
 *   <li>MCA_GRACEFUL_FALLBACK</li>
 * </ul>
 */
public class ConfigLoader {

    private static final Logger logger = LoggerFactory.getLogger(ConfigLoader.class);

    private static final String[] CONFIG_FILE_PATHS = {
            System.getProperty("user.home") + "/.mca_sdk/config.yaml",
            "./mca-config.yaml",
            "./config/mca-config.yaml",
            "./mca-config.properties"
    };

    /**
     * Load configuration from all sources with precedence.
     *
     * <p>Order: defaults → file → environment → builder
     * (Registry loading happens later in MCAClient.build())
     *
     * @param builder Builder with potentially pre-set values
     * @return Fully loaded MCAConfig
     */
    public static MCAConfig load(MCAConfig.Builder builder) {
        logger.debug("Loading configuration from multiple sources");

        // Start with a new builder to apply defaults first
        MCAConfig.Builder configBuilder = new MCAConfig.Builder();

        // 1. Apply defaults (already set in Builder constructor)

        // 2. Load from file (if exists)
        loadFromFile(configBuilder);

        // 3. Load from environment variables
        loadFromEnvironment(configBuilder);

        // 4. Apply builder values (these override everything)
        applyBuilderValues(configBuilder, builder);

        return configBuilder.build();
    }

    /**
     * Load configuration from file.
     *
     * @param builder Builder to populate
     */
    private static void loadFromFile(MCAConfig.Builder builder) {
        Map<String, Object> fileConfig = findAndLoadConfigFile();

        if (!fileConfig.isEmpty()) {
            applyIfNotNull(val -> builder.serviceName(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "service_name"));
            applyIfNotNull(val -> builder.modelId(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "model_id"));
            applyIfNotNull(val -> builder.teamName(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "team_name"));
            applyIfNotNull(val -> builder.modelVersion(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "model_version"));
            applyIfNotNull(val -> builder.modelType(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "model_type"));
            applyIfNotNull(val -> builder.modelCategory(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "model_category"));
            applyIfNotNull(val -> builder.otelEndpoint(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "otel_endpoint"));
            applyIfNotNull(val -> builder.registryUrl(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "registry_url"));
            applyIfNotNull(val -> builder.registryToken(val, ConfigSource.FILE), YamlConfigParser.getString(fileConfig, "registry_token"));

            Boolean useGcpAuth = YamlConfigParser.getBoolean(fileConfig, "use_gcp_auth", null);
            if (useGcpAuth != null) builder.useGcpAuth(useGcpAuth, ConfigSource.FILE);

            Boolean strictValidation = YamlConfigParser.getBoolean(fileConfig, "strict_validation", null);
            if (strictValidation != null) builder.strictValidation(strictValidation, ConfigSource.FILE);

            Boolean gracefulFallback = YamlConfigParser.getBoolean(fileConfig, "graceful_fallback", null);
            if (gracefulFallback != null) builder.gracefulFallback(gracefulFallback, ConfigSource.FILE);

            Integer cacheTtlSecs = YamlConfigParser.getInt(fileConfig, "cache_ttl_secs", null);
            if (cacheTtlSecs != null) builder.cacheTtlSecs(cacheTtlSecs, ConfigSource.FILE);

            Integer refreshIntervalSecs = YamlConfigParser.getInt(fileConfig, "refresh_interval_secs", null);
            if (refreshIntervalSecs != null) builder.refreshIntervalSecs(refreshIntervalSecs, ConfigSource.FILE);

            Map<String, Object> thresholds = YamlConfigParser.getMap(fileConfig, "thresholds");
            if (!thresholds.isEmpty()) {
                Map<String, Double> thresholdsMap = new HashMap<>();
                thresholds.forEach((key, value) -> {
                    if (value instanceof Number) {
                        thresholdsMap.put(key, ((Number) value).doubleValue());
                    }
                });
                if (!thresholdsMap.isEmpty()) {
                    builder.thresholds(thresholdsMap, ConfigSource.FILE);
                }
            }
        }
    }

    /**
     * Find and load the first available config file.
     *
     * @return Config map, or empty if no file found
     */
    private static Map<String, Object> findAndLoadConfigFile() {
        for (String path : CONFIG_FILE_PATHS) {
            if (path.endsWith(".properties")) {
                Map<String, Object> config = YamlConfigParser.parseProperties(path);
                if (!config.isEmpty()) {
                    logger.info("Loaded configuration from properties file: {}", path);
                    return config;
                }
            } else {
                Map<String, Object> config = YamlConfigParser.parseYaml(path);
                if (!config.isEmpty()) {
                    logger.info("Loaded configuration from YAML file: {}", path);
                    return config;
                }
            }
        }

        logger.debug("No configuration file found");
        return new HashMap<>();
    }

    /**
     * Load configuration from environment variables.
     *
     * @param builder Builder to populate
     */
    private static void loadFromEnvironment(MCAConfig.Builder builder) {
        applyEnvIfPresent(val -> builder.serviceName(val, ConfigSource.ENV), "MCA_SERVICE_NAME");
        applyEnvIfPresent(val -> builder.modelId(val, ConfigSource.ENV), "MCA_MODEL_ID");
        applyEnvIfPresent(val -> builder.teamName(val, ConfigSource.ENV), "MCA_TEAM_NAME");
        applyEnvIfPresent(val -> builder.modelVersion(val, ConfigSource.ENV), "MCA_MODEL_VERSION");
        applyEnvIfPresent(val -> builder.modelType(val, ConfigSource.ENV), "MCA_MODEL_TYPE");
        applyEnvIfPresent(val -> builder.modelCategory(val, ConfigSource.ENV), "MCA_MODEL_CATEGORY");
        applyEnvIfPresent(val -> builder.otelEndpoint(val, ConfigSource.ENV), "MCA_OTEL_ENDPOINT");
        applyEnvIfPresent(val -> builder.registryUrl(val, ConfigSource.ENV), "MCA_REGISTRY_URL");
        applyEnvIfPresent(val -> builder.registryToken(val, ConfigSource.ENV), "MCA_REGISTRY_TOKEN");

        String useGcpAuth = System.getenv("MCA_USE_GCP_AUTH");
        if (useGcpAuth != null) builder.useGcpAuth(Boolean.parseBoolean(useGcpAuth), ConfigSource.ENV);

        String strictValidation = System.getenv("MCA_STRICT_VALIDATION");
        if (strictValidation != null) builder.strictValidation(Boolean.parseBoolean(strictValidation), ConfigSource.ENV);

        String gracefulFallback = System.getenv("MCA_GRACEFUL_FALLBACK");
        if (gracefulFallback != null) builder.gracefulFallback(Boolean.parseBoolean(gracefulFallback), ConfigSource.ENV);

        String cacheTtl = System.getenv("MCA_CACHE_TTL_SECS");
        if (cacheTtl != null) {
            try {
                builder.cacheTtlSecs(Integer.parseInt(cacheTtl), ConfigSource.ENV);
            } catch (NumberFormatException e) {
                logger.warn("Invalid MCA_CACHE_TTL_SECS value: {}", cacheTtl);
            }
        }

        String refreshInterval = System.getenv("MCA_REFRESH_INTERVAL_SECS");
        if (refreshInterval != null) {
            try {
                builder.refreshIntervalSecs(Integer.parseInt(refreshInterval), ConfigSource.ENV);
            } catch (NumberFormatException e) {
                logger.warn("Invalid MCA_REFRESH_INTERVAL_SECS value: {}", refreshInterval);
            }
        }
    }

    /**
     * Apply builder values to config builder (final precedence).
     *
     * @param configBuilder Config builder being populated
     * @param builder       Original builder with user-set values
     */
    private static void applyBuilderValues(MCAConfig.Builder configBuilder, MCAConfig.Builder builder) {
        MCAConfig builderConfig = builder.build();

        if (builderConfig.getSource("serviceName") == ConfigSource.BUILDER) {
            configBuilder.serviceName(builderConfig.getServiceName(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("modelId") == ConfigSource.BUILDER) {
            configBuilder.modelId(builderConfig.getModelId(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("teamName") == ConfigSource.BUILDER) {
            configBuilder.teamName(builderConfig.getTeamName(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("modelVersion") == ConfigSource.BUILDER) {
            configBuilder.modelVersion(builderConfig.getModelVersion(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("modelType") == ConfigSource.BUILDER) {
            configBuilder.modelType(builderConfig.getModelType(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("modelCategory") == ConfigSource.BUILDER) {
            configBuilder.modelCategory(builderConfig.getModelCategory(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("otelEndpoint") == ConfigSource.BUILDER) {
            configBuilder.otelEndpoint(builderConfig.getOtelEndpoint(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("registryUrl") == ConfigSource.BUILDER) {
            configBuilder.registryUrl(builderConfig.getRegistryUrl(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("registryToken") == ConfigSource.BUILDER) {
            configBuilder.registryToken(builderConfig.getRegistryToken(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("useGcpAuth") == ConfigSource.BUILDER) {
            configBuilder.useGcpAuth(builderConfig.isUseGcpAuth(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("strictValidation") == ConfigSource.BUILDER) {
            configBuilder.strictValidation(builderConfig.isStrictValidation(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("gracefulFallback") == ConfigSource.BUILDER) {
            configBuilder.gracefulFallback(builderConfig.isGracefulFallback(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("cacheTtlSecs") == ConfigSource.BUILDER) {
            configBuilder.cacheTtlSecs(builderConfig.getCacheTtlSecs(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("refreshIntervalSecs") == ConfigSource.BUILDER) {
            configBuilder.refreshIntervalSecs(builderConfig.getRefreshIntervalSecs(), ConfigSource.BUILDER);
        }
        if (builderConfig.getSource("thresholds") == ConfigSource.BUILDER) {
            configBuilder.thresholds(builderConfig.getThresholds(), ConfigSource.BUILDER);
        }
    }

    /**
     * Apply value to setter function if value is not null.
     *
     * @param setter Setter function
     * @param value  Value to set
     */
    private static void applyIfNotNull(java.util.function.Consumer<String> setter, String value) {
        if (value != null && !value.trim().isEmpty()) {
            setter.accept(value);
        }
    }

    /**
     * Apply environment variable to setter if present.
     *
     * @param setter Setter function
     * @param envVar Environment variable name
     */
    private static void applyEnvIfPresent(java.util.function.Consumer<String> setter, String envVar) {
        String value = System.getenv(envVar);
        if (value != null && !value.trim().isEmpty()) {
            logger.debug("Applying environment variable: {}", envVar);
            setter.accept(value);
        }
    }
}
