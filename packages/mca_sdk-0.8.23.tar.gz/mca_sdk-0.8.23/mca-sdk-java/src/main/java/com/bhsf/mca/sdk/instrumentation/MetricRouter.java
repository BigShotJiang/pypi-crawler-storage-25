package com.bhsf.mca.sdk.instrumentation;

import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.DoubleCounter;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.metrics.ObservableDoubleGauge;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Routes metric recording to the correct OpenTelemetry instrument type.
 *
 * <p>Supports three instrument types:
 * <ul>
 *   <li><b>COUNTER</b> - Monotonically increasing values (e.g., request count, cache hits)</li>
 *   <li><b>HISTOGRAM</b> - Distribution of values (e.g., latency, accuracy)</li>
 *   <li><b>GAUGE</b> - Current value that can go up or down (e.g., queue size, memory usage)</li>
 * </ul>
 *
 * <p>Instruments are cached for performance (avoids repeated creation overhead).
 * Uses bounded LRU caches (max 1000 instruments per type) to prevent OutOfMemoryError
 * from high-cardinality metric names (e.g., dynamically generated user-specific metrics).
 *
 * <p>Thread-safe for concurrent use.
 *
 * @see com.bhsf.mca.sdk.MCAClient#recordMetric(String, double, String, java.util.Map)
 */
public class MetricRouter {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(MetricRouter.class);

    /**
     * Maximum number of cached instruments per type.
     * Prevents unbounded memory growth from high-cardinality metric names.
     */
    private static final int MAX_CACHE_SIZE = 1000;

    /**
     * Instrument types supported by the router.
     */
    public enum InstrumentType {
        COUNTER,        // DoubleCounter - monotonic increasing (supports fractional values)
        HISTOGRAM,      // DoubleHistogram - distribution
        GAUGE           // ObservableDoubleGauge - absolute current value (not cumulative)
    }

    /**
     * Holder for gauge current value and attributes.
     * Gauges represent absolute values at a point in time.
     */
    private static class GaugeValue {
        final AtomicReference<Double> value = new AtomicReference<>(0.0);
        final AtomicReference<Attributes> attributes = new AtomicReference<>(Attributes.empty());

        void set(double newValue, Attributes newAttributes) {
            value.set(newValue);
            attributes.set(newAttributes);
        }

        double get() {
            return value.get();
        }
    }

    /**
     * Thread-safe bounded LRU cache for instruments.
     * Prevents OutOfMemoryError from high-cardinality metric names.
     *
     * @param <K> Key type (metric name)
     * @param <V> Value type (instrument)
     */
    private static class BoundedLRUCache<K, V> {
        private final Map<K, V> cache;
        private final int maxSize;

        BoundedLRUCache(int maxSize) {
            this.maxSize = maxSize;
            // LinkedHashMap with access-order mode for LRU semantics
            this.cache = Collections.synchronizedMap(new LinkedHashMap<K, V>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                    boolean shouldRemove = size() > maxSize;
                    if (shouldRemove) {
                        log.debug("LRU cache evicting eldest entry: {} (cache size: {})", eldest.getKey(), size());
                    }
                    return shouldRemove;
                }
            });
        }

        V get(K key) {
            return cache.get(key);
        }

        V computeIfAbsent(K key, java.util.function.Function<? super K, ? extends V> mappingFunction) {
            synchronized (cache) {
                V value = cache.get(key);
                if (value == null) {
                    value = mappingFunction.apply(key);
                    if (value != null) {
                        cache.put(key, value);
                    }
                }
                return value;
            }
        }

        int size() {
            return cache.size();
        }

        void clear() {
            cache.clear();
        }
    }

    private final Meter meter;

    // Thread-safe BOUNDED LRU caches for instruments (prevents OOM from high-cardinality metric names)
    private final BoundedLRUCache<String, DoubleCounter> counterCache = new BoundedLRUCache<>(MAX_CACHE_SIZE);
    private final BoundedLRUCache<String, DoubleHistogram> histogramCache = new BoundedLRUCache<>(MAX_CACHE_SIZE);
    private final BoundedLRUCache<String, ObservableDoubleGauge> gaugeCache = new BoundedLRUCache<>(MAX_CACHE_SIZE);
    // Thread-safe storage for current gauge values (gauges represent absolute values, not deltas)
    // Using ConcurrentHashMap here is safe because gauge values are tied to registered gauges (bounded above)
    private final ConcurrentHashMap<String, GaugeValue> gaugeValues = new ConcurrentHashMap<>();

    /**
     * Create a new MetricRouter.
     *
     * @param meter OpenTelemetry Meter for creating instruments
     * @throws IllegalArgumentException if meter is null
     */
    public MetricRouter(Meter meter) {
        if (meter == null) {
            throw new IllegalArgumentException("Meter cannot be null");
        }
        this.meter = meter;
        log.debug("MetricRouter initialized");
    }

    /**
     * Record a metric value with the specified instrument type.
     *
     * @param name Metric name (must be non-null and non-empty)
     * @param value Metric value
     * @param type Instrument type (COUNTER, HISTOGRAM, or GAUGE)
     * @param attributes OpenTelemetry attributes (may be null)
     * @throws IllegalArgumentException if name is null/empty or type is null
     */
    public void recordMetric(String name, double value, InstrumentType type, Attributes attributes) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Metric name cannot be null or empty");
        }
        if (type == null) {
            throw new IllegalArgumentException("Instrument type cannot be null");
        }

        // Use empty attributes if null
        Attributes attrs = (attributes != null) ? attributes : Attributes.empty();

        switch (type) {
            case COUNTER:
                recordCounter(name, value, attrs);
                break;
            case HISTOGRAM:
                recordHistogram(name, value, attrs);
                break;
            case GAUGE:
                recordGauge(name, value, attrs);
                break;
            default:
                throw new IllegalArgumentException("Unknown instrument type: " + type);
        }

        log.debug("Recorded metric: name={}, value={}, type={}", name, value, type);
    }

    /**
     * Record a counter metric.
     * Counters are monotonically increasing (e.g., request count).
     * Supports fractional values (e.g., 1.5 cache hits, 3.14 MB transferred).
     *
     * <p><b>VALIDATION:</b> Negative values are rejected with a warning to prevent
     * OpenTelemetry runtime exceptions (counters must be monotonic).
     */
    private void recordCounter(String name, double value, Attributes attributes) {
        // Validate: counters must be non-negative (monotonic constraint)
        if (value < 0.0) {
            log.warn("Ignoring negative counter value for '{}': {}. Counters must be monotonically increasing.",
                    name, value);
            return;
        }

        DoubleCounter counter = counterCache.computeIfAbsent(name, metricName ->
                meter.counterBuilder(metricName)
                        .ofDoubles()  // Use DoubleCounter for precision (no truncation)
                        .setDescription("Custom counter metric: " + metricName)
                        .build()
        );

        counter.add(value, attributes);
    }

    /**
     * Record a histogram metric.
     * Histograms track distribution of values (e.g., latency, accuracy).
     */
    private void recordHistogram(String name, double value, Attributes attributes) {
        DoubleHistogram histogram = histogramCache.computeIfAbsent(name, metricName ->
                meter.histogramBuilder(metricName)
                        .setDescription("Custom histogram metric: " + metricName)
                        .build()  // Removed hardcoded unit - let backend infer
        );

        histogram.record(value, attributes);
    }

    /**
     * Record a gauge metric (absolute current value).
     * Gauges represent absolute values at a point in time (e.g., queue size=5, then queue size=4).
     *
     * <p><b>SEMANTICS:</b> Unlike UpDownCounter which accumulates deltas (.add()),
     * gauges represent absolute current values (.set()). This implementation properly tracks
     * the current value and exposes it via ObservableDoubleGauge.
     *
     * <p><b>EXAMPLE:</b> Recording queue_size=5, then queue_size=4 will report 5 then 4
     * (NOT 5 then 9 as would happen with incorrect .add() usage).
     */
    private void recordGauge(String name, double value, Attributes attributes) {
        // Get or create the gauge value holder
        GaugeValue gaugeValue = gaugeValues.computeIfAbsent(name, metricName -> new GaugeValue());

        // Set the absolute value (not a delta)
        gaugeValue.set(value, attributes);

        // Create observable gauge if not already created
        gaugeCache.computeIfAbsent(name, metricName ->
                meter.gaugeBuilder(metricName)
                        .setDescription("Custom gauge metric: " + metricName)
                        .buildWithCallback(measurement -> {
                            GaugeValue gv = gaugeValues.get(metricName);
                            if (gv != null) {
                                measurement.record(gv.get(), gv.attributes.get());
                            }
                        })
        );
    }

    /**
     * Get the number of cached instruments.
     * Useful for testing and monitoring.
     *
     * @return Total number of cached instruments across all types
     */
    public int getCachedInstrumentCount() {
        return counterCache.size() + histogramCache.size() + gaugeCache.size();
    }

    /**
     * Clear all cached instruments.
     * Useful for testing. In production, instruments should remain cached for the lifetime
     * of the MetricRouter.
     */
    void clearCache() {
        counterCache.clear();
        histogramCache.clear();
        gaugeCache.clear();
        log.debug("Cleared all instrument caches");
    }
}
