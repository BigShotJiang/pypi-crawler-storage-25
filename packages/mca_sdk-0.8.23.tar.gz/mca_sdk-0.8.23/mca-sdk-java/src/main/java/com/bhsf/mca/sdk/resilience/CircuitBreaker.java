package com.bhsf.mca.sdk.resilience;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Circuit breaker pattern for resilience and fast-fail behavior.
 *
 * <p>Implements the circuit breaker pattern with three states:
 * <ul>
 *   <li><b>CLOSED</b>: Normal operation, requests pass through to underlying operation</li>
 *   <li><b>OPEN</b>: Circuit is "tripped", requests fail immediately (fast-fail)</li>
 *   <li><b>HALF_OPEN</b>: Testing recovery, single request attempts to verify service availability</li>
 * </ul>
 *
 * <p>State Transitions:
 * <ul>
 *   <li>CLOSED → OPEN: After N consecutive failures (configurable, default: 5)</li>
 *   <li>OPEN → HALF_OPEN: After timeout period (configurable, default: 60 seconds)</li>
 *   <li>HALF_OPEN → CLOSED: After successful test request</li>
 *   <li>HALF_OPEN → OPEN: If test request fails</li>
 * </ul>
 *
 * <p>Thread-safe for concurrent use. Uses atomic operations for state management.
 *
 * <p>Example usage:
 * <pre>{@code
 * // Create circuit breaker with retry policy
 * RetryPolicy retry = new RetryPolicy(3, 1.0, 10.0);
 * CircuitBreaker breaker = new CircuitBreaker(retry, 5, 60000);
 *
 * // Execute with circuit breaker protection
 * try {
 *     String result = breaker.execute(() -> callExternalService());
 * } catch (CircuitBreakerOpenException e) {
 *     // Circuit is open, queue for later or use fallback
 *     logger.warn("Circuit breaker is open, using cached data");
 *     return cachedData;
 * }
 * }</pre>
 */
public class CircuitBreaker {
    private static final Logger logger = LoggerFactory.getLogger(CircuitBreaker.class);

    /**
     * Circuit breaker states.
     */
    public enum CircuitState {
        /** Normal operation, requests pass through */
        CLOSED,
        /** Circuit tripped, requests fail immediately */
        OPEN,
        /** Testing recovery, single request allowed */
        HALF_OPEN
    }

    /**
     * Exception thrown when circuit is OPEN.
     */
    public static class CircuitBreakerOpenException extends ResilienceException {
        public CircuitBreakerOpenException(String message) {
            super(message);
        }
    }

    private final RetryPolicy retryPolicy;
    private final int failureThreshold;
    private final long resetTimeoutMs;
    private final String name;

    private final AtomicReference<CircuitState> state;
    private final AtomicInteger failureCount;
    private final AtomicLong lastFailureTime;
    private final AtomicInteger successCount;

    /**
     * Create circuit breaker with default parameters (5 failures, 60s timeout).
     *
     * @param retryPolicy Retry policy for executing operations
     * @throws IllegalArgumentException if retryPolicy is null
     */
    public CircuitBreaker(RetryPolicy retryPolicy) {
        this(retryPolicy, 5, 60000, "default");
    }

    /**
     * Create circuit breaker with custom parameters.
     *
     * @param retryPolicy       Retry policy for executing operations (must not be null)
     * @param failureThreshold  Number of consecutive failures before opening circuit (must be > 0)
     * @param resetTimeoutMs    Cool-down period in milliseconds before entering HALF_OPEN (must be > 0)
     * @param name              Circuit breaker name for logging and monitoring
     * @throws IllegalArgumentException if parameters are invalid
     */
    public CircuitBreaker(RetryPolicy retryPolicy, int failureThreshold, long resetTimeoutMs, String name) {
        if (retryPolicy == null) {
            throw new IllegalArgumentException("retryPolicy cannot be null");
        }
        if (failureThreshold <= 0) {
            throw new IllegalArgumentException("failureThreshold must be positive, got " + failureThreshold);
        }
        if (resetTimeoutMs <= 0) {
            throw new IllegalArgumentException("resetTimeoutMs must be positive, got " + resetTimeoutMs);
        }

        this.retryPolicy = retryPolicy;
        this.failureThreshold = failureThreshold;
        this.resetTimeoutMs = resetTimeoutMs;
        this.name = name;

        this.state = new AtomicReference<>(CircuitState.CLOSED);
        this.failureCount = new AtomicInteger(0);
        this.lastFailureTime = new AtomicLong(0);
        this.successCount = new AtomicInteger(0);

        logger.info(
                "Circuit breaker initialized: {} (failureThreshold={}, resetTimeoutMs={})",
                name, failureThreshold, resetTimeoutMs
        );
    }

    /**
     * Execute operation through circuit breaker with retry policy.
     *
     * <p>Behavior by circuit state:
     * <ul>
     *   <li><b>CLOSED</b>: Normal operation, call retry_policy.executeWithRetry()</li>
     *   <li><b>OPEN</b>: Fast-fail, raise CircuitBreakerOpenException immediately</li>
     *   <li><b>HALF_OPEN</b>: Test mode, single call to check if service recovered</li>
     * </ul>
     *
     * @param operation Operation to execute (typically an external service call)
     * @param <T>       Return type of the operation
     * @return Result of successful operation
     * @throws CircuitBreakerOpenException if circuit is OPEN (fast-fail)
     * @throws Exception                   if operation fails
     */
    public <T> T execute(Callable<T> operation) throws Exception {
        CircuitState currentState = state.get();

        // Check if circuit should transition from OPEN to HALF_OPEN
        if (currentState == CircuitState.OPEN) {
            long timeSinceLastFailure = System.currentTimeMillis() - lastFailureTime.get();
            if (timeSinceLastFailure >= resetTimeoutMs) {
                // Only ONE thread wins the CAS and becomes the test request
                // All other threads fail fast until the test completes
                if (state.compareAndSet(CircuitState.OPEN, CircuitState.HALF_OPEN)) {
                    logger.info("Circuit breaker {} transitioning: OPEN → HALF_OPEN (timeout expired)", name);
                    currentState = CircuitState.HALF_OPEN;
                } else {
                    // Another thread won the race, fail fast while test is in progress
                    logger.debug(
                            "Circuit breaker {} is testing recovery (HALF_OPEN), failing fast",
                            name
                    );
                    throw new CircuitBreakerOpenException(
                            "Circuit breaker " + name + " is testing recovery. Failing fast."
                    );
                }
            } else {
                // Circuit still open, fail fast
                logger.debug(
                        "Circuit breaker {} is OPEN, failing fast ({}ms until retry)",
                        name, resetTimeoutMs - timeSinceLastFailure
                );
                throw new CircuitBreakerOpenException(
                        "Circuit breaker " + name + " is OPEN. Failing fast to prevent cascading failures."
                );
            }
        }

        // Execute operation with retry policy
        try {
            T result = retryPolicy.executeWithRetry(operation);
            onSuccess(currentState);
            return result;
        } catch (Exception e) {
            onFailure(currentState);
            throw e;
        }
    }

    /**
     * Handle successful operation.
     */
    private void onSuccess(CircuitState previousState) {
        successCount.incrementAndGet();

        if (previousState == CircuitState.HALF_OPEN) {
            // Success in HALF_OPEN → transition to CLOSED
            logger.info("Circuit breaker {} transitioning: HALF_OPEN → CLOSED (test request succeeded)", name);
            state.set(CircuitState.CLOSED);
            failureCount.set(0);
        } else if (previousState == CircuitState.CLOSED) {
            // Success in CLOSED → reset failure count
            failureCount.set(0);
        }
    }

    /**
     * Handle failed operation.
     */
    private void onFailure(CircuitState previousState) {
        int currentFailures = failureCount.incrementAndGet();
        lastFailureTime.set(System.currentTimeMillis());

        if (previousState == CircuitState.HALF_OPEN) {
            // Failure in HALF_OPEN → back to OPEN
            logger.warn("Circuit breaker {} transitioning: HALF_OPEN → OPEN (test request failed)", name);
            state.set(CircuitState.OPEN);
            failureCount.set(0); // Reset for next HALF_OPEN attempt
        } else if (previousState == CircuitState.CLOSED) {
            // Check if threshold reached
            if (currentFailures >= failureThreshold) {
                logger.warn(
                        "Circuit breaker {} transitioning: CLOSED → OPEN ({} consecutive failures)",
                        name, currentFailures
                );
                state.set(CircuitState.OPEN);
            } else {
                logger.debug(
                        "Circuit breaker {} failure count: {}/{}",
                        name, currentFailures, failureThreshold
                );
            }
        }
    }

    /**
     * Get current circuit state.
     *
     * @return Current circuit state (CLOSED, OPEN, or HALF_OPEN)
     */
    public CircuitState getState() {
        return state.get();
    }

    /**
     * Get current failure count.
     *
     * @return Number of consecutive failures in CLOSED state
     */
    public int getFailureCount() {
        return failureCount.get();
    }

    /**
     * Get total success count since creation.
     *
     * @return Total number of successful operations
     */
    public int getSuccessCount() {
        return successCount.get();
    }

    /**
     * Get timestamp of last failure.
     *
     * @return Timestamp in milliseconds, or 0 if no failures yet
     */
    public long getLastFailureTime() {
        return lastFailureTime.get();
    }

    /**
     * Get failure threshold.
     *
     * @return Number of failures required to open circuit
     */
    public int getFailureThreshold() {
        return failureThreshold;
    }

    /**
     * Get reset timeout.
     *
     * @return Reset timeout in milliseconds
     */
    public long getResetTimeoutMs() {
        return resetTimeoutMs;
    }

    /**
     * Get circuit breaker name.
     *
     * @return Circuit breaker name
     */
    public String getName() {
        return name;
    }

    /**
     * Manually reset circuit breaker to CLOSED state.
     *
     * <p>This method is primarily for operational use (manual intervention)
     * and testing purposes. Use with caution in production.
     */
    public void reset() {
        CircuitState oldState = state.getAndSet(CircuitState.CLOSED);
        failureCount.set(0);
        lastFailureTime.set(0);

        logger.warn(
                "Circuit breaker {} manually reset: {} → CLOSED",
                name, oldState
        );
    }

    /**
     * Get circuit breaker statistics.
     *
     * @return Statistics object with current metrics
     */
    public CircuitBreakerStats getStats() {
        return new CircuitBreakerStats(
                state.get(),
                failureCount.get(),
                failureThreshold,
                resetTimeoutMs,
                lastFailureTime.get(),
                successCount.get(),
                name
        );
    }

    /**
     * Circuit breaker statistics.
     */
    public static class CircuitBreakerStats {
        private final CircuitState state;
        private final int failureCount;
        private final int failureThreshold;
        private final long resetTimeoutMs;
        private final long lastFailureTime;
        private final int successCount;
        private final String name;

        public CircuitBreakerStats(CircuitState state, int failureCount, int failureThreshold,
                                   long resetTimeoutMs, long lastFailureTime, int successCount, String name) {
            this.state = state;
            this.failureCount = failureCount;
            this.failureThreshold = failureThreshold;
            this.resetTimeoutMs = resetTimeoutMs;
            this.lastFailureTime = lastFailureTime;
            this.successCount = successCount;
            this.name = name;
        }

        public CircuitState getState() { return state; }
        public int getFailureCount() { return failureCount; }
        public int getFailureThreshold() { return failureThreshold; }
        public long getResetTimeoutMs() { return resetTimeoutMs; }
        public long getLastFailureTime() { return lastFailureTime; }
        public int getSuccessCount() { return successCount; }
        public String getName() { return name; }
    }
}
