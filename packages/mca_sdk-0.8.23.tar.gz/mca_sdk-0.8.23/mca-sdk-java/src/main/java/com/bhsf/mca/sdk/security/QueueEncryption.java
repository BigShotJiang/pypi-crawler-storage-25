package com.bhsf.mca.sdk.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.ByteBuffer;
import java.security.SecureRandom;

/**
 * Provides AES-256-GCM encryption for queue data at rest.
 *
 * <p>Uses AES-256-GCM (Galois/Counter Mode) which provides both confidentiality and
 * authenticity. Any tampering with the ciphertext will be detected during decryption.
 *
 * <p>Features:
 * <ul>
 *   <li>AES-256-GCM authenticated encryption</li>
 *   <li>Random 12-byte IV for each encryption (GCM standard)</li>
 *   <li>128-bit authentication tag for tamper detection</li>
 *   <li>Automatic IV prepending to ciphertext</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * // Initialize with secret key
 * SecretKey key = EncryptionManager.loadKeyFromEnvironment();
 * QueueEncryption encryption = new QueueEncryption(key);
 *
 * // Encrypt data
 * byte[] plaintext = "sensitive data".getBytes();
 * byte[] encrypted = encryption.encrypt(plaintext);
 *
 * // Decrypt data
 * byte[] decrypted = encryption.decrypt(encrypted);
 * }</pre>
 */
public class QueueEncryption {
    private static final Logger logger = LoggerFactory.getLogger(QueueEncryption.class);
    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private static final int GCM_IV_LENGTH = 12; // 12 bytes (96 bits) - GCM standard
    private static final int GCM_TAG_LENGTH = 128; // 128 bits (16 bytes)

    private final SecretKey secretKey;
    private final SecureRandom secureRandom;

    /**
     * Constructs encryption instance with the provided secret key.
     *
     * @param secretKey 32-byte AES-256 key
     * @throws SecurityException if key is invalid
     */
    public QueueEncryption(SecretKey secretKey) {
        if (secretKey == null) {
            throw new SecurityException("Secret key cannot be null");
        }

        EncryptionManager.validateKey(secretKey.getEncoded());
        this.secretKey = secretKey;

        // Use non-blocking SecureRandom (backed by /dev/urandom on Linux)
        // getInstanceStrong() can block on low entropy, causing thread starvation
        this.secureRandom = new SecureRandom();
    }

    /**
     * Encrypts data using AES-256-GCM.
     *
     * <p>Generates a random 12-byte IV for each encryption and prepends it to the ciphertext.
     * The IV is needed for decryption and is not secret.
     *
     * <p>Format of returned data: [IV (12 bytes)][ciphertext + auth tag]
     *
     * @param data plaintext data to encrypt
     * @return encrypted data with IV prepended
     * @throws SecurityException if encryption fails
     */
    public byte[] encrypt(byte[] data) {
        if (data == null) {
            throw new SecurityException("Data to encrypt cannot be null");
        }

        try {
            // Generate random IV
            byte[] iv = new byte[GCM_IV_LENGTH];
            secureRandom.nextBytes(iv);

            // Initialize cipher
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec);

            // Encrypt data
            byte[] ciphertext = cipher.doFinal(data);

            // Prepend IV to ciphertext for storage
            ByteBuffer buffer = ByteBuffer.allocate(iv.length + ciphertext.length);
            buffer.put(iv);
            buffer.put(ciphertext);

            return buffer.array();
        } catch (Exception e) {
            throw new SecurityException("Encryption failed", e);
        }
    }

    /**
     * Decrypts data encrypted with {@link #encrypt(byte[])}.
     *
     * <p>Extracts the IV from the first 12 bytes and uses it to decrypt the remaining data.
     * GCM authentication tag validation ensures data integrity - any tampering will cause
     * this method to throw SecurityException.
     *
     * @param encryptedData encrypted data with IV prepended
     * @return decrypted plaintext data
     * @throws SecurityException if decryption fails, data is corrupted, or tampered with
     */
    public byte[] decrypt(byte[] encryptedData) {
        if (encryptedData == null) {
            throw new SecurityException("Encrypted data cannot be null");
        }

        if (encryptedData.length < GCM_IV_LENGTH) {
            throw new SecurityException(
                String.format("Invalid encrypted data: too short. Expected at least %d bytes, got %d",
                    GCM_IV_LENGTH, encryptedData.length)
            );
        }

        try {
            // Extract IV from first 12 bytes
            ByteBuffer buffer = ByteBuffer.wrap(encryptedData);
            byte[] iv = new byte[GCM_IV_LENGTH];
            buffer.get(iv);

            // Extract ciphertext
            byte[] ciphertext = new byte[buffer.remaining()];
            buffer.get(ciphertext);

            // Initialize cipher
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec);

            // Decrypt and verify authentication tag
            return cipher.doFinal(ciphertext);
        } catch (javax.crypto.AEADBadTagException e) {
            // Authentication tag mismatch - data was tampered with
            throw new SecurityException("Decryption failed: authentication tag mismatch. Data may have been tampered with", e);
        } catch (Exception e) {
            throw new SecurityException("Decryption failed", e);
        }
    }
}
