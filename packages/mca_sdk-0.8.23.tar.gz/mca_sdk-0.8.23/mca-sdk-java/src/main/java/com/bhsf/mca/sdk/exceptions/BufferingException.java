package com.bhsf.mca.sdk.exceptions;

/**
 * Exception thrown when buffering operations fail.
 *
 * <p>This exception is raised when telemetry buffering encounters errors that
 * prevent normal operation, such as queue capacity issues or persistence failures.
 *
 * <p>Common scenarios:
 * <ul>
 *   <li>Queue is full and cannot accept new items</li>
 *   <li>Disk persistence failed when overflow occurs</li>
 *   <li>Queue file cannot be read or written</li>
 *   <li>Invalid queue configuration parameters</li>
 *   <li>Queue corruption detected</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * try {
 *     queue.enqueue(telemetryItem);
 * } catch (BufferingException e) {
 *     logger.warn("Failed to buffer telemetry: {}", e.getMessage());
 *     // Send to dead letter queue or drop item
 * }
 * }</pre>
 *
 * @see com.bhsf.mca.sdk.resilience.TelemetryQueue
 * @see com.bhsf.mca.sdk.resilience.DeadLetterQueue
 * @since 0.2.0
 */
public class BufferingException extends MCAException {

    /**
     * Constructs a new BufferingException with the specified detail message.
     *
     * @param message the detail message explaining the buffering failure
     */
    public BufferingException(String message) {
        super(message);
    }

    /**
     * Constructs a new BufferingException with the specified detail message and cause.
     *
     * @param message the detail message explaining the buffering failure
     * @param cause the underlying cause of the buffering failure
     */
    public BufferingException(String message, Throwable cause) {
        super(message, cause);
    }
}
