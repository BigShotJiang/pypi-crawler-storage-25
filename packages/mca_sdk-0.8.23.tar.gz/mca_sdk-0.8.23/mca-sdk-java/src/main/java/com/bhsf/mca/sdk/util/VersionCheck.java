package com.bhsf.mca.sdk.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Version checking utility for MCA SDK.
 *
 * <p>Checks if the running SDK version is outdated and logs warnings.
 * Runs asynchronously to avoid blocking SDK initialization.
 *
 * <p>This class is stateless and thread-safe. All methods are static.
 *
 * <p>Example usage:
 * <pre>{@code
 * // Called automatically during MCAClient initialization
 * VersionCheck.checkVersionAsync("0.2.0");
 *
 * // For testing: synchronous version check
 * VersionInfo info = VersionCheck.checkVersion("0.2.0", Duration.ofSeconds(2));
 * if (info != null && info.isOutdated()) {
 *     System.out.println("Update available: " + info.getLatestVersion());
 * }
 * }</pre>
 *
 * @since 0.2.0
 */
public final class VersionCheck {

    private static final Logger logger = LoggerFactory.getLogger(VersionCheck.class);
    private static final String MAVEN_CENTRAL_API =
            "https://search.maven.org/solrsearch/select?q=g:com.bhsf.mca+AND+a:mca-sdk-java&rows=1&wt=json";
    private static final Duration DEFAULT_TIMEOUT = Duration.ofSeconds(2);
    private static final int OUTDATED_THRESHOLD_DAYS = 30;
    private static final Duration CACHE_DURATION = Duration.ofHours(24);

    // Cache to prevent spamming Maven Central on every MCAClient instantiation
    private static final AtomicReference<Instant> lastCheckTime = new AtomicReference<>(Instant.EPOCH);

    private VersionCheck() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Checks if current SDK version is outdated (async, non-blocking).
     *
     * <p>Fetches the latest version from Maven Central and compares with current version.
     * Logs a warning if the version is &gt;30 days old. Runs in background thread.
     *
     * <p>Rate-limited to once per 24 hours to prevent resource exhaustion.
     *
     * @param currentVersion current SDK version string (e.g., "0.2.0")
     */
    public static void checkVersionAsync(String currentVersion) {
        // Check if we should skip due to recent check (within last 24 hours)
        Instant now = Instant.now();
        Instant lastCheck = lastCheckTime.get();

        if (Duration.between(lastCheck, now).compareTo(CACHE_DURATION) < 0) {
            logger.debug("Skipping version check (last check was {} ago)",
                Duration.between(lastCheck, now));
            return;
        }

        // Update last check time atomically
        if (!lastCheckTime.compareAndSet(lastCheck, now)) {
            // Another thread already started a check
            logger.debug("Version check already in progress");
            return;
        }

        CompletableFuture.runAsync(() -> checkVersion(currentVersion, DEFAULT_TIMEOUT))
                .exceptionally(ex -> {
                    logger.debug("Version check failed: {}", ex.getMessage());
                    return null;
                });
    }

    /**
     * Checks version synchronously (for testing).
     *
     * @param currentVersion current SDK version
     * @param timeout HTTP request timeout
     * @return version info or null if check failed
     */
    static VersionInfo checkVersion(String currentVersion, Duration timeout) {
        try {
            // Enable redirect following (search.maven.org redirects to central.sonatype.com)
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(timeout)
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .build();

            // Add User-Agent header per Sonatype API guidelines
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(MAVEN_CENTRAL_API))
                    .header("User-Agent", "mca-sdk-java/" + currentVersion)
                    .timeout(timeout)
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request,
                    HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                logger.debug("Maven Central API returned status {}", response.statusCode());
                return null;
            }

            return parseVersionInfo(response.body(), currentVersion);

        } catch (Exception e) {
            logger.debug("Version check skipped (network error): {}", e.getMessage());
            return null;
        }
    }

    /**
     * Parses Maven Central API response and checks if version is outdated.
     */
    private static VersionInfo parseVersionInfo(String jsonResponse, String currentVersion) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(jsonResponse);
            JsonNode docs = root.path("response").path("docs");

            if (docs.isEmpty()) {
                logger.debug("No version information available from Maven Central");
                return null;
            }

            JsonNode latestDoc = docs.get(0);
            String latestVersion = latestDoc.path("latestVersion").asText();
            long timestamp = latestDoc.path("timestamp").asLong();

            if (latestVersion.isEmpty() || timestamp == 0) {
                logger.debug("Invalid version data from Maven Central");
                return null;
            }

            Instant releaseTime = Instant.ofEpochMilli(timestamp);
            long ageDays = ChronoUnit.DAYS.between(releaseTime, Instant.now());

            boolean isOutdated = !currentVersion.equals(latestVersion) && ageDays > OUTDATED_THRESHOLD_DAYS;

            if (isOutdated) {
                logger.warn(
                        "MCA SDK version {} is outdated. Latest version is {} (released {} days ago). " +
                        "Update via Maven: <version>{}</version>",
                        currentVersion, latestVersion, ageDays, latestVersion);
            } else {
                logger.debug("MCA SDK version {} is current (latest: {})", currentVersion, latestVersion);
            }

            return new VersionInfo(latestVersion, currentVersion, isOutdated, ageDays);

        } catch (Exception e) {
            logger.debug("Failed to parse version info: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Version information result.
     */
    public static class VersionInfo {
        private final String latestVersion;
        private final String currentVersion;
        private final boolean isOutdated;
        private final long ageDays;

        /**
         * Constructs a VersionInfo object.
         *
         * @param latestVersion latest version available on Maven Central
         * @param currentVersion current SDK version
         * @param isOutdated whether the current version is outdated
         * @param ageDays age of the latest release in days
         */
        public VersionInfo(String latestVersion, String currentVersion, boolean isOutdated, long ageDays) {
            this.latestVersion = latestVersion;
            this.currentVersion = currentVersion;
            this.isOutdated = isOutdated;
            this.ageDays = ageDays;
        }

        /**
         * Gets the latest version available on Maven Central.
         *
         * @return latest version string
         */
        public String getLatestVersion() {
            return latestVersion;
        }

        /**
         * Gets the current SDK version.
         *
         * @return current version string
         */
        public String getCurrentVersion() {
            return currentVersion;
        }

        /**
         * Checks if the current version is outdated.
         *
         * @return true if current version is outdated
         */
        public boolean isOutdated() {
            return isOutdated;
        }

        /**
         * Gets the age of the latest release in days.
         *
         * @return age in days
         */
        public long getAgeDays() {
            return ageDays;
        }
    }
}
