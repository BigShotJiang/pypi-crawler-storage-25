package com.bhsf.mca.sdk.resilience;

import com.bhsf.mca.sdk.exceptions.MCAException;

/**
 * Base exception for resilience-related errors.
 *
 * <p>This exception is thrown when resilience patterns (retry, circuit breaker,
 * queue, dead letter queue) encounter errors that prevent normal operation.
 *
 * <p>Examples include:
 * <ul>
 *   <li>Queue full and cannot accept new items</li>
 *   <li>Circuit breaker is open (fast-fail mode)</li>
 *   <li>Disk persistence failures</li>
 *   <li>Invalid configuration parameters</li>
 * </ul>
 */
public class ResilienceException extends MCAException {

    /**
     * Constructs a resilience exception with the specified message.
     *
     * @param message Detailed error message
     */
    public ResilienceException(String message) {
        super(message);
    }

    /**
     * Constructs a resilience exception with message and cause.
     *
     * @param message Detailed error message
     * @param cause   Root cause exception
     */
    public ResilienceException(String message, Throwable cause) {
        super(message, cause);
    }
}
