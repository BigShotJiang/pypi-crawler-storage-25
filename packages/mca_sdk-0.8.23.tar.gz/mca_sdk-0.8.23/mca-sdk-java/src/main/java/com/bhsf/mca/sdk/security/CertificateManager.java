package com.bhsf.mca.sdk.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;

/**
 * Manages X.509 certificates for mTLS authentication.
 *
 * <p>Provides functionality for:
 * <ul>
 *   <li>Loading and validating client certificates</li>
 *   <li>Loading and validating private keys</li>
 *   <li>Loading and validating CA certificates</li>
 *   <li>Certificate expiration checking with warnings</li>
 *   <li>Hot-reload support for certificate updates</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * CertificateManager manager = new CertificateManager(
 *     "/path/to/client.crt",
 *     "/path/to/client.key",
 *     "/path/to/ca.crt"
 * );
 *
 * // Load and validate all certificates
 * manager.loadAndValidate();
 *
 * // Get loaded certificates
 * X509Certificate clientCert = manager.getClientCertificate();
 * PrivateKey clientKey = manager.getClientKey();
 * X509Certificate caCert = manager.getCACertificate();
 * }</pre>
 */
public class CertificateManager {
    private static final Logger logger = LoggerFactory.getLogger(CertificateManager.class);
    private static final int EXPIRATION_WARNING_DAYS = 30;

    private final String clientCertPath;
    private final String clientKeyPath;
    private final String caCertPath;

    private X509Certificate clientCertificate;
    private PrivateKey clientKey;
    private X509Certificate caCertificate;

    private WatchService watchService;
    private Thread watchThread;
    private volatile boolean watching = false;

    /**
     * Constructs a certificate manager with paths to certificate files.
     *
     * @param clientCertPath path to client certificate (PEM format)
     * @param clientKeyPath path to client private key (PEM format, PKCS8)
     * @param caCertPath path to CA certificate (PEM format)
     */
    public CertificateManager(String clientCertPath, String clientKeyPath, String caCertPath) {
        this.clientCertPath = clientCertPath;
        this.clientKeyPath = clientKeyPath;
        this.caCertPath = caCertPath;
    }

    /**
     * Loads and validates all certificates.
     *
     * <p>This method:
     * <ul>
     *   <li>Loads client certificate, client key, and CA certificate from files</li>
     *   <li>Validates PEM format</li>
     *   <li>Checks certificate expiration</li>
     * </ul>
     *
     * @throws CertificateException if any certificate fails to load or is invalid
     */
    public void loadAndValidate() throws CertificateException {
        logger.info("Loading and validating certificates");

        // Load client certificate
        clientCertificate = loadCertificate(clientCertPath);
        checkExpiration(clientCertificate, clientCertPath);

        // Load client private key
        clientKey = loadPrivateKey(clientKeyPath);

        // Load CA certificate
        caCertificate = loadCertificate(caCertPath);
        checkExpiration(caCertificate, caCertPath);

        logger.info("All certificates loaded and validated successfully");
    }

    /**
     * Loads an X.509 certificate from a PEM file.
     *
     * @param certPath path to certificate file
     * @return loaded X509Certificate
     * @throws CertificateException if certificate cannot be loaded or is invalid
     */
    public X509Certificate loadCertificate(String certPath) throws CertificateException {
        if (certPath == null || certPath.trim().isEmpty()) {
            throw new CertificateException("Certificate path cannot be null or empty");
        }

        Path path = Paths.get(certPath);
        if (!Files.exists(path)) {
            throw new CertificateException(
                String.format("Certificate file not found: %s. Ensure the file exists and path is correct", certPath)
            );
        }

        try (InputStream inputStream = Files.newInputStream(path)) {
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            Certificate cert = certFactory.generateCertificate(inputStream);

            if (!(cert instanceof X509Certificate)) {
                throw new CertificateException(
                    String.format("Certificate is not X.509 format: %s", certPath)
                );
            }

            logger.debug("Successfully loaded certificate from: {}", certPath);
            return (X509Certificate) cert;

        } catch (java.security.cert.CertificateException | IOException e) {
            throw new CertificateException(
                String.format("Failed to load certificate from %s. Must be in valid PEM format. Error: %s",
                    certPath, e.getClass().getSimpleName()), e
            );
        }
    }

    /**
     * Loads a private key from a PEM file (PKCS8 format required).
     *
     * <p>Java natively supports PKCS#8 format only. If you have a PKCS#1 or SEC1 key,
     * convert it first using:
     * <pre>
     * openssl pkcs8 -topk8 -inform PEM -outform PEM -nocrypt -in key.pem -out pkcs8.pem
     * </pre>
     *
     * @param keyPath path to private key file (PKCS8 PEM format)
     * @return loaded PrivateKey
     * @throws CertificateException if key cannot be loaded or is invalid
     */
    public PrivateKey loadPrivateKey(String keyPath) throws CertificateException {
        if (keyPath == null || keyPath.trim().isEmpty()) {
            throw new CertificateException("Private key path cannot be null or empty");
        }

        Path path = Paths.get(keyPath);
        if (!Files.exists(path)) {
            throw new CertificateException(
                String.format("Private key file not found: %s. Ensure the file exists and path is correct", keyPath)
            );
        }

        try {
            String content = Files.readString(path);

            // Check for unsupported PKCS#1 format
            if (content.contains("-----BEGIN RSA PRIVATE KEY-----")) {
                throw new CertificateException(
                    String.format("PKCS#1 format detected in %s. Java requires PKCS#8 format. " +
                        "Convert your key using: " +
                        "openssl pkcs8 -topk8 -inform PEM -outform PEM -nocrypt -in %s -out pkcs8.pem",
                        keyPath, keyPath)
                );
            }

            // Check for unsupported SEC1 EC format
            if (content.contains("-----BEGIN EC PRIVATE KEY-----")) {
                throw new CertificateException(
                    String.format("SEC1 EC format detected in %s. Java requires PKCS#8 format. " +
                        "Convert your key using: " +
                        "openssl pkcs8 -topk8 -inform PEM -outform PEM -nocrypt -in %s -out pkcs8.pem",
                        keyPath, keyPath)
                );
            }

            // Remove PKCS#8 PEM headers/footers and whitespace
            content = content
                .replaceAll("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");

            byte[] keyBytes = Base64.getDecoder().decode(content);

            // Try RSA first, then EC (both use PKCS#8)
            try {
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
                logger.debug("Successfully loaded RSA private key (PKCS#8) from: {}", keyPath);
                return keyFactory.generatePrivate(keySpec);
            } catch (Exception e) {
                // Try EC
                KeyFactory keyFactory = KeyFactory.getInstance("EC");
                PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
                logger.debug("Successfully loaded EC private key (PKCS#8) from: {}", keyPath);
                return keyFactory.generatePrivate(keySpec);
            }

        } catch (CertificateException e) {
            // Re-throw our own exceptions with clear messages
            throw e;
        } catch (Exception e) {
            throw new CertificateException(
                String.format("Failed to load private key from %s. Must be in PKCS#8 PEM format. " +
                    "If you have a PKCS#1 or SEC1 key, convert it first. Error: %s",
                    keyPath, e.getClass().getSimpleName()), e
            );
        }
    }

    /**
     * Checks if a certificate is expired or expiring soon.
     *
     * @param certificate certificate to check
     * @param sourcePath path of the certificate file (for error messages)
     * @throws CertificateException if certificate has expired
     */
    public void checkExpiration(X509Certificate certificate, String sourcePath) throws CertificateException {
        Date notAfter = certificate.getNotAfter();
        Instant expirationDate = notAfter.toInstant();
        Instant now = Instant.now();

        // Check if expired
        if (now.isAfter(expirationDate)) {
            throw new CertificateException(
                String.format("Certificate has expired: %s. Expired on: %s. Please renew the certificate",
                    sourcePath, expirationDate)
            );
        }

        // Warn if expiring soon
        long daysUntilExpiry = ChronoUnit.DAYS.between(now, expirationDate);
        if (daysUntilExpiry <= EXPIRATION_WARNING_DAYS) {
            logger.warn("Certificate expires in {} days ({}). Expiration date: {}. Consider renewing the certificate soon",
                daysUntilExpiry, sourcePath, expirationDate);
        }
    }

    /**
     * Starts hot-reload monitoring of certificate files.
     *
     * <p>Watches the certificate directories for file modifications and automatically
     * reloads certificates when they change. This allows certificate updates without
     * restarting the application.
     *
     * <p>The watch thread runs in the background and can be stopped with {@link #stopHotReload()}.
     *
     * @throws CertificateException if watch service cannot be started
     */
    public synchronized void startHotReload() throws CertificateException {
        if (watching) {
            logger.debug("Hot-reload already active");
            return;
        }

        try {
            watchService = FileSystems.getDefault().newWatchService();

            // Register directories containing certificates
            registerDirectory(clientCertPath);
            registerDirectory(clientKeyPath);
            registerDirectory(caCertPath);

            watching = true;
            watchThread = new Thread(this::watchForChanges, "CertificateHotReload");
            watchThread.setDaemon(true);
            watchThread.start();

            logger.info("Certificate hot-reload started");

        } catch (Exception e) {
            throw new CertificateException("Failed to start certificate hot-reload", e);
        }
    }

    /**
     * Stops hot-reload monitoring.
     */
    public synchronized void stopHotReload() {
        if (!watching) {
            return;
        }

        watching = false;
        if (watchThread != null) {
            watchThread.interrupt();
        }

        if (watchService != null) {
            try {
                watchService.close();
            } catch (IOException e) {
                logger.warn("Error closing watch service", e);
            }
        }

        logger.info("Certificate hot-reload stopped");
    }

    private void registerDirectory(String filePath) throws IOException {
        Path file = Paths.get(filePath).toAbsolutePath();
        Path dir = file.getParent();
        if (dir != null) {
            dir.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
            logger.debug("Watching directory: {}", dir);
        }
    }

    private void watchForChanges() {
        while (watching) {
            try {
                WatchKey key = watchService.take();

                for (WatchEvent<?> event : key.pollEvents()) {
                    WatchEvent.Kind<?> kind = event.kind();

                    if (kind == StandardWatchEventKinds.OVERFLOW) {
                        continue;
                    }

                    @SuppressWarnings("unchecked")
                    WatchEvent<Path> ev = (WatchEvent<Path>) event;
                    Path filename = ev.context();

                    // Check if modified file matches our certificates (using absolute paths)
                    if (isOurCertificate(filename, key)) {
                        logger.info("Certificate file modified: {}. Reloading...", filename);
                        try {
                            Thread.sleep(100); // Brief delay for file write completion
                            loadAndValidate();
                            logger.info("Certificates reloaded successfully");
                        } catch (CertificateException e) {
                            logger.error("Failed to reload certificates", e);
                        } catch (InterruptedException e) {
                            logger.debug("Watch thread interrupted during reload");
                            Thread.currentThread().interrupt(); // Restore interrupt flag
                            break; // Exit the loop safely
                        }
                    }
                }

                key.reset();
            } catch (InterruptedException e) {
                logger.debug("Watch thread interrupted");
                break;
            }
        }
    }

    private boolean isOurCertificate(Path filename, WatchKey key) {
        // Get the directory being watched
        Path dir = (Path) key.watchable();

        // Resolve to absolute path
        Path modifiedFile = dir.resolve(filename).toAbsolutePath();

        // Compare with our certificate absolute paths
        Path clientCertAbs = Paths.get(clientCertPath).toAbsolutePath();
        Path clientKeyAbs = Paths.get(clientKeyPath).toAbsolutePath();
        Path caCertAbs = Paths.get(caCertPath).toAbsolutePath();

        return modifiedFile.equals(clientCertAbs) ||
               modifiedFile.equals(clientKeyAbs) ||
               modifiedFile.equals(caCertAbs);
    }

    // Getters

    /**
     * Gets the loaded client certificate.
     *
     * @return client X509Certificate
     * @throws IllegalStateException if certificates not yet loaded
     */
    public X509Certificate getClientCertificate() {
        if (clientCertificate == null) {
            throw new IllegalStateException("Certificates not loaded. Call loadAndValidate() first");
        }
        return clientCertificate;
    }

    /**
     * Gets the loaded client private key.
     *
     * @return client PrivateKey
     * @throws IllegalStateException if certificates not yet loaded
     */
    public PrivateKey getClientKey() {
        if (clientKey == null) {
            throw new IllegalStateException("Certificates not loaded. Call loadAndValidate() first");
        }
        return clientKey;
    }

    /**
     * Gets the loaded CA certificate.
     *
     * @return CA X509Certificate
     * @throws IllegalStateException if certificates not yet loaded
     */
    public X509Certificate getCACertificate() {
        if (caCertificate == null) {
            throw new IllegalStateException("Certificates not loaded. Call loadAndValidate() first");
        }
        return caCertificate;
    }

    /**
     * Checks if hot-reload is currently active.
     *
     * @return true if hot-reload is running
     */
    public boolean isHotReloadActive() {
        return watching;
    }
}
