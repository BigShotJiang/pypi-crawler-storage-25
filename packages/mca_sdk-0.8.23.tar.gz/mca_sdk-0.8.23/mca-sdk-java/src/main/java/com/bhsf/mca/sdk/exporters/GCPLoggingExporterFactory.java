package com.bhsf.mca.sdk.exporters;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.logs.data.LogRecordData;
import io.opentelemetry.sdk.logs.export.LogRecordExporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

/**
 * Factory for creating GCP Cloud Logging exporter with proper optional dependency handling.
 *
 * <p>This factory exports OpenTelemetry logs to GCP Cloud Logging with:
 * <ul>
 *   <li>Severity level mapping (DEBUG/INFO/WARNING/ERROR/CRITICAL)</li>
 *   <li>Structured JSON payload for rich log data</li>
 *   <li>Log-to-trace correlation (trace/span IDs)</li>
 *   <li>Attributes converted to JSON fields</li>
 *   <li>Resource attributes added with "resource." prefix</li>
 *   <li>Timestamp preservation from telemetry data</li>
 *   <li>Batched writes for efficiency (single RPC per export() call)</li>
 * </ul>
 *
 * <p><strong>Thread Safety:</strong> This exporter is thread-safe with lazy client initialization
 * protected by double-checked locking.
 *
 * <p><strong>Security:</strong> Uses HTTPS/TLS for all communication. No credentials are logged.
 *
 * <p><strong>PHI/PII Handling:</strong> This exporter performs NO PHI/PII masking. Applications
 * MUST sanitize PHI/PII before logging. The SDK cannot determine domain-specific PHI.
 *
 * <p><strong>Implementation Pattern:</strong> This class follows the Factory + Implementation
 * pattern used by {@link com.bhsf.mca.sdk.security.SecretManager}. This factory checks
 * for optional dependency availability and only loads {@link GCPLoggingExporterImpl} if the
 * google-cloud-logging library is present, preventing {@link NoClassDefFoundError} at class load time.
 *
 * <p>Example:
 * <pre>{@code
 * Object credentials = GCPAuthFactory.loadCredentials(null, null);
 * LogRecordExporter exporter = GCPLoggingExporterFactory.create("my-project-123", "mca-sdk-logs", credentials);
 *
 * // Use with LoggerProvider
 * SdkLoggerProvider loggerProvider = SdkLoggerProvider.builder()
 *     .addLogRecordProcessor(BatchLogRecordProcessor.builder(exporter).build())
 *     .build();
 * }</pre>
 */
public class GCPLoggingExporterFactory implements LogRecordExporter {
    private static final Logger log = LoggerFactory.getLogger(GCPLoggingExporterFactory.class);
    private static final boolean GCP_LOGGING_AVAILABLE = checkGcpLoggingAvailability();

    private final LogRecordExporter delegate;

    /**
     * Checks if GCP Cloud Logging library is available at runtime.
     *
     * <p>This check prevents NoClassDefFoundError by verifying the library
     * before attempting to load GCPLoggingExporterImpl.
     *
     * @return true if google-cloud-logging is available, false otherwise
     */
    private static boolean checkGcpLoggingAvailability() {
        try {
            Class.forName("com.google.cloud.logging.Logging");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * Create GCP Cloud Logging exporter with default "global" resource type.
     *
     * @param projectId GCP project ID
     * @param logName Cloud Logging log name (must match ^[a-zA-Z0-9._-]+$)
     * @param credentials Google Cloud credentials (from GCPAuthFactory.loadCredentials)
     * @return GCPLoggingExporterFactory instance
     * @throws ConfigurationException if google-cloud-logging library not available or initialization fails
     */
    public static GCPLoggingExporterFactory create(String projectId, String logName, Object credentials) {
        return new GCPLoggingExporterFactory(projectId, logName, credentials, "global");
    }

    /**
     * Create GCP Cloud Logging exporter with custom resource type.
     *
     * @param projectId GCP project ID
     * @param logName Cloud Logging log name
     * @param credentials Google Cloud credentials
     * @param resourceType GCP monitored resource type (e.g., "global", "k8s_container", "gce_instance")
     * @return GCPLoggingExporterFactory instance
     * @throws ConfigurationException if library unavailable or initialization fails
     */
    public static GCPLoggingExporterFactory create(String projectId, String logName, Object credentials, String resourceType) {
        return new GCPLoggingExporterFactory(projectId, logName, credentials, resourceType);
    }

    /**
     * Private constructor - use create() factory methods.
     *
     * @param projectId GCP project ID
     * @param logName Cloud Logging log name
     * @param credentials Google Cloud credentials (Object type to avoid direct import)
     * @param resourceType GCP monitored resource type
     * @throws ConfigurationException if library unavailable or initialization fails
     */
    private GCPLoggingExporterFactory(String projectId, String logName, Object credentials, String resourceType) {
        if (!GCP_LOGGING_AVAILABLE) {
            throw new ConfigurationException(
                    "google-cloud-logging is not available. " +
                    "This is an optional dependency. " +
                    "Add to your pom.xml:\n" +
                    "<dependency>\n" +
                    "  <groupId>com.google.cloud</groupId>\n" +
                    "  <artifactId>google-cloud-logging</artifactId>\n" +
                    "  <version>3.15.0</version>\n" +
                    "</dependency>"
            );
        }

        try {
            // GCPLoggingExporterImpl will only be loaded if GCP_LOGGING_AVAILABLE is true
            // This provides compile-time type safety with runtime optional dependency support
            this.delegate = GCPLoggingExporterImpl.create(projectId, logName, credentials, resourceType);
            log.info("Initialized GCP Cloud Logging exporter for project: {}, log: {}", projectId, logName);
        } catch (ConfigurationException e) {
            // Re-throw ConfigurationException as-is
            throw e;
        } catch (Exception e) {
            throw new ConfigurationException(
                    "Failed to initialize GCP Cloud Logging exporter: " + e.getMessage(), e);
        }
    }

    @Override
    public CompletableResultCode export(Collection<LogRecordData> logs) {
        return delegate.export(logs);
    }

    @Override
    public CompletableResultCode flush() {
        return delegate.flush();
    }

    @Override
    public CompletableResultCode shutdown() {
        return delegate.shutdown();
    }

    /**
     * Check if GCP Cloud Logging library is available.
     *
     * @return true if library is available, false otherwise
     */
    public static boolean isAvailable() {
        return GCP_LOGGING_AVAILABLE;
    }
}
