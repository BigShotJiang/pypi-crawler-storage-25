package com.bhsf.mca.sdk.security;

/**
 * Exception thrown when certificate loading fails.
 *
 * <p>This checked exception indicates that a certificate file could not be loaded
 * from disk, parsed, or read due to file system issues, format problems, or access restrictions.
 *
 * <p>Common scenarios:
 * <ul>
 *   <li>Certificate file does not exist at the specified path</li>
 *   <li>Insufficient permissions to read certificate file</li>
 *   <li>Certificate file format is invalid (not PEM/DER)</li>
 *   <li>Certificate file is corrupted or truncated</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * try {
 *     X509Certificate cert = CertificateManager.loadCertificate("/path/to/cert.pem");
 * } catch (CertificateLoadException e) {
 *     logger.error("Failed to load certificate: {}", e.getMessage());
 *     throw new SecurityException("Cannot initialize TLS", e);
 * }
 * }</pre>
 *
 * @see CertificateManager
 * @since 0.2.0
 */
public class CertificateLoadException extends CertificateException {

    /**
     * Constructs a new CertificateLoadException with the specified detail message.
     *
     * <p>The message should include the file path to help with troubleshooting.
     *
     * @param message the detail message (typically includes file path and reason)
     */
    public CertificateLoadException(String message) {
        super(message);
    }

    /**
     * Constructs a new CertificateLoadException with the specified detail message and cause.
     *
     * @param message the detail message (typically includes file path and reason)
     * @param cause the underlying cause (e.g., FileNotFoundException, IOException)
     */
    public CertificateLoadException(String message, Throwable cause) {
        super(message, cause);
    }
}
