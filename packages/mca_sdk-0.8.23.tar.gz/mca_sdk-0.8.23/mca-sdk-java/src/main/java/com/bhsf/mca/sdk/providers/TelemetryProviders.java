package com.bhsf.mca.sdk.providers;

import com.bhsf.mca.sdk.config.MCAConfig;
import com.bhsf.mca.sdk.exporters.GCPLoggingExporterFactory;
import com.bhsf.mca.sdk.exporters.GCPTraceExporterFactory;
import com.bhsf.mca.sdk.gcp.GCPAuthFactory;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.common.AttributesBuilder;
import io.opentelemetry.api.logs.Logger;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.exporter.otlp.http.logs.OtlpHttpLogRecordExporter;
import io.opentelemetry.exporter.otlp.http.metrics.OtlpHttpMetricExporter;
import io.opentelemetry.exporter.otlp.http.trace.OtlpHttpSpanExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.logs.SdkLoggerProvider;
import io.opentelemetry.sdk.logs.export.BatchLogRecordProcessor;
import io.opentelemetry.sdk.logs.export.LogRecordExporter;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.export.PeriodicMetricReader;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.BatchSpanProcessor;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import org.slf4j.LoggerFactory;

import java.time.Duration;

/**
 * Manages OpenTelemetry providers (Meter, Logger, Tracer) with proper lifecycle.
 * Thread-safe singleton per MCAClient instance.
 */
public class TelemetryProviders implements AutoCloseable {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(TelemetryProviders.class);

    private final OpenTelemetrySdk openTelemetry;
    private final Meter meter;
    private final Logger logger;
    private final Tracer tracer; // Reserved for future distributed tracing implementation
    private final SdkMeterProvider meterProvider;
    private final SdkLoggerProvider loggerProvider;
    private final SdkTracerProvider tracerProvider;

    // Optional GCP exporters (using interface types for flexibility)
    private SpanExporter gcpTraceExporter;
    private LogRecordExporter gcpLoggingExporter;

    public TelemetryProviders(String serviceName, String modelId, String modelVersion,
                               String teamName, String otelEndpoint) {
        // Build resource attributes
        AttributesBuilder resourceAttrs = Attributes.builder()
                .put("service.name", serviceName);

        if (modelId != null) {
            resourceAttrs.put("model.id", modelId);
        }
        if (modelVersion != null) {
            resourceAttrs.put("model.version", modelVersion);
        }
        if (teamName != null) {
            resourceAttrs.put("team.name", teamName);
        }

        Resource resource = Resource.create(resourceAttrs.build());

        // Sanitize endpoint: remove trailing slashes to prevent double-slash issues
        String sanitizedEndpoint = otelEndpoint.replaceAll("/+$", "");

        // Configure OTLP exporters
        OtlpHttpMetricExporter metricExporter = OtlpHttpMetricExporter.builder()
                .setEndpoint(sanitizedEndpoint + "/v1/metrics")
                .setTimeout(Duration.ofSeconds(10))
                .build();

        OtlpHttpLogRecordExporter logExporter = OtlpHttpLogRecordExporter.builder()
                .setEndpoint(sanitizedEndpoint + "/v1/logs")
                .setTimeout(Duration.ofSeconds(10))
                .build();

        OtlpHttpSpanExporter traceExporter = OtlpHttpSpanExporter.builder()
                .setEndpoint(sanitizedEndpoint + "/v1/traces")
                .setTimeout(Duration.ofSeconds(10))
                .build();

        // Initialize providers with batch processing
        this.meterProvider = SdkMeterProvider.builder()
                .setResource(resource)
                .registerMetricReader(PeriodicMetricReader.builder(metricExporter)
                        .setInterval(Duration.ofSeconds(30))
                        .build())
                .build();

        this.loggerProvider = SdkLoggerProvider.builder()
                .setResource(resource)
                .addLogRecordProcessor(BatchLogRecordProcessor.builder(logExporter)
                        .setScheduleDelay(Duration.ofSeconds(5))
                        .build())
                .build();

        this.tracerProvider = SdkTracerProvider.builder()
                .setResource(resource)
                .addSpanProcessor(BatchSpanProcessor.builder(traceExporter)
                        .setScheduleDelay(Duration.ofSeconds(5))
                        .build())
                .build();

        // Build OpenTelemetry SDK
        this.openTelemetry = OpenTelemetrySdk.builder()
                .setMeterProvider(meterProvider)
                .setLoggerProvider(loggerProvider)
                .setTracerProvider(tracerProvider)
                .build();

        // Get instrumentation instances
        this.meter = openTelemetry.getMeter("com.bhsf.mca.sdk");
        this.logger = openTelemetry.getLogsBridge().get("com.bhsf.mca.sdk");
        this.tracer = openTelemetry.getTracer("com.bhsf.mca.sdk");
    }

    /**
     * Create TelemetryProviders with optional GCP exporters and Prometheus support.
     *
     * @param config MCAConfig with GCP and Prometheus configuration
     */
    public TelemetryProviders(MCAConfig config) {
        // Build resource attributes
        AttributesBuilder resourceAttrs = Attributes.builder()
                .put("service.name", config.getServiceName());

        if (config.getModelId() != null) {
            resourceAttrs.put("model.id", config.getModelId());
        }
        if (config.getModelVersion() != null) {
            resourceAttrs.put("model.version", config.getModelVersion());
        }
        if (config.getTeamName() != null) {
            resourceAttrs.put("team.name", config.getTeamName());
        }

        Resource resource = Resource.create(resourceAttrs.build());

        // Sanitize endpoint
        String sanitizedEndpoint = config.getOtelEndpoint().replaceAll("/+$", "");

        // Configure OTLP exporters
        OtlpHttpMetricExporter otlpMetricExporter = OtlpHttpMetricExporter.builder()
                .setEndpoint(sanitizedEndpoint + "/v1/metrics")
                .setTimeout(Duration.ofSeconds(10))
                .build();

        OtlpHttpLogRecordExporter otlpLogExporter = OtlpHttpLogRecordExporter.builder()
                .setEndpoint(sanitizedEndpoint + "/v1/logs")
                .setTimeout(Duration.ofSeconds(10))
                .build();

        OtlpHttpSpanExporter otlpSpanExporter = OtlpHttpSpanExporter.builder()
                .setEndpoint(sanitizedEndpoint + "/v1/traces")
                .setTimeout(Duration.ofSeconds(10))
                .build();

        // Setup GCP exporters if enabled
        SpanExporter finalSpanExporter = otlpSpanExporter;
        LogRecordExporter finalLogExporter = otlpLogExporter;

        if (config.isGcpTraceEnabled() || config.isGcpLoggingEnabled()) {
            try {
                // Load GCP credentials using factory (returns Object to avoid direct import)
                Object credentials = GCPAuthFactory.loadCredentials(
                        config.getGcpCredentialsPath(),
                        config.getGcpCredentialsJson()
                );

                // Add GCP Trace exporter if enabled
                if (config.isGcpTraceEnabled() && config.getGcpProjectId() != null) {
                    try {
                        this.gcpTraceExporter = GCPTraceExporterFactory.create(
                                config.getGcpProjectId(),
                                credentials
                        );
                        finalSpanExporter = SpanExporter.composite(otlpSpanExporter, gcpTraceExporter);
                        log.info("GCP Trace exporter enabled for project: {}", config.getGcpProjectId());
                    } catch (Exception e) {
                        log.warn("GCP Trace exporter initialization failed, falling back to OTLP only: {}", e.getMessage());
                    }
                }

                // Add GCP Logging exporter if enabled
                if (config.isGcpLoggingEnabled() && config.getGcpProjectId() != null) {
                    try {
                        String logName = config.getGcpLogName() != null ? config.getGcpLogName() : "mca-sdk";
                        this.gcpLoggingExporter = GCPLoggingExporterFactory.create(
                                config.getGcpProjectId(),
                                logName,
                                credentials
                        );
                        finalLogExporter = LogRecordExporter.composite(otlpLogExporter, gcpLoggingExporter);
                        log.info("GCP Logging exporter enabled for project: {}, log: {}", config.getGcpProjectId(), logName);
                    } catch (Exception e) {
                        log.warn("GCP Logging exporter initialization failed, falling back to OTLP only: {}", e.getMessage());
                    }
                }
            } catch (Exception e) {
                log.warn("Failed to load GCP credentials, GCP exporters disabled: {}", e.getMessage());
            }
        }

        // Initialize providers with exporters
        this.meterProvider = SdkMeterProvider.builder()
                .setResource(resource)
                .registerMetricReader(PeriodicMetricReader.builder(otlpMetricExporter)
                        .setInterval(Duration.ofSeconds(30))
                        .build())
                .build();

        this.loggerProvider = SdkLoggerProvider.builder()
                .setResource(resource)
                .addLogRecordProcessor(BatchLogRecordProcessor.builder(finalLogExporter)
                        .setScheduleDelay(Duration.ofSeconds(5))
                        .build())
                .build();

        this.tracerProvider = SdkTracerProvider.builder()
                .setResource(resource)
                .addSpanProcessor(BatchSpanProcessor.builder(finalSpanExporter)
                        .setScheduleDelay(Duration.ofSeconds(5))
                        .build())
                .build();

        // Build OpenTelemetry SDK
        this.openTelemetry = OpenTelemetrySdk.builder()
                .setMeterProvider(meterProvider)
                .setLoggerProvider(loggerProvider)
                .setTracerProvider(tracerProvider)
                .build();

        // Get instrumentation instances
        this.meter = openTelemetry.getMeter("com.bhsf.mca.sdk");
        this.logger = openTelemetry.getLogsBridge().get("com.bhsf.mca.sdk");
        this.tracer = openTelemetry.getTracer("com.bhsf.mca.sdk");
    }

    public Meter getMeter() {
        return meter;
    }

    public Logger getLogger() {
        return logger;
    }

    public Tracer getTracer() {
        return tracer;
    }

    /**
     * Shutdown all providers with timeout.
     * Flushes all pending telemetry before closing.
     * Uses robust error handling to ensure all providers attempt shutdown even if one fails.
     *
     * @param timeoutMillis Maximum time to wait for shutdown in milliseconds
     */
    public void shutdown(long timeoutMillis) {
        long startTime = System.currentTimeMillis();

        // Shutdown in reverse order: tracer, logger, meter
        // Wrap each in try-catch to ensure all providers attempt shutdown
        try {
            tracerProvider.shutdown().join(timeoutMillis, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            log.error("Error shutting down TracerProvider", e);
        }

        long elapsed = System.currentTimeMillis() - startTime;
        long remainingTimeout = Math.max(0, timeoutMillis - elapsed);

        try {
            loggerProvider.shutdown().join(remainingTimeout, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            log.error("Error shutting down LoggerProvider", e);
        }

        elapsed = System.currentTimeMillis() - startTime;
        remainingTimeout = Math.max(0, timeoutMillis - elapsed);

        try {
            meterProvider.shutdown().join(remainingTimeout, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            log.error("Error shutting down MeterProvider", e);
        }

        // Shutdown the root OpenTelemetry SDK instance
        try {
            openTelemetry.close();
        } catch (Exception e) {
            log.error("Error closing OpenTelemetry SDK", e);
        }

        // Shutdown GCP exporters if initialized
        if (gcpTraceExporter != null) {
            try {
                gcpTraceExporter.shutdown();
            } catch (Exception e) {
                log.error("Error shutting down GCP Trace exporter", e);
            }
        }

        if (gcpLoggingExporter != null) {
            try {
                gcpLoggingExporter.shutdown();
            } catch (Exception e) {
                log.error("Error shutting down GCP Logging exporter", e);
            }
        }
    }

    @Override
    public void close() {
        shutdown(30000);
    }
}
