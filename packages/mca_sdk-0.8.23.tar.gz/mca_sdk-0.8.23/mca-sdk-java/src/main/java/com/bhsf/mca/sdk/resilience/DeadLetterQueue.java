package com.bhsf.mca.sdk.resilience;

import com.bhsf.mca.sdk.security.EncryptionManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.SecretKey;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Dead letter queue for failed operations after retry exhaustion.
 *
 * <p>Stores operations that failed all retry attempts for later investigation.
 * Provides bounded storage with automatic eviction of oldest items and
 * optional persistence to disk for post-mortem analysis.
 *
 * <p>Thread Safety: All operations are protected by a ReadWriteLock to ensure
 * safe concurrent access from multiple threads.
 *
 * <p>Example usage:
 * <pre>{@code
 * // Create DLQ with persistence
 * DeadLetterQueue dlq = new DeadLetterQueue(1000, "~/.mca_sdk/dlq.json", null, false);
 *
 * // Enqueue failed item
 * dlq.enqueue("ExportOperation", new IOException("Connection timeout"), 3);
 *
 * // Inspect recent failures
 * List<DLQItem> items = dlq.inspect(10);
 *
 * // Get statistics
 * DLQStats stats = dlq.stats();
 * System.out.println("DLQ size: " + stats.getSize());
 * }</pre>
 *
 * <p>With encryption:
 * <pre>{@code
 * SecretKey key = EncryptionManager.loadKeyFromEnvironment();
 * DeadLetterQueue dlq = new DeadLetterQueue(1000, "~/.mca_sdk/dlq.json", key, true);
 * }</pre>
 */
public class DeadLetterQueue {
    private static final Logger logger = LoggerFactory.getLogger(DeadLetterQueue.class);
    private static final int MAX_ITEM_SIZE_BYTES = 64 * 1024; // 64KB per item
    private static final String DEFAULT_PERSIST_PATH = System.getProperty("user.home") + "/.mca_sdk/dlq.json";

    private final int maxSize;
    private final LinkedList<DLQItem> queue;
    private final ReadWriteLock lock;
    private final String persistPath;
    private final EncryptionManager encryptionManager;
    private final boolean requireEncryption;
    private final ObjectMapper objectMapper;

    // Metrics
    private int itemsEnqueued = 0;
    private int itemsEvicted = 0;
    private int persistSuccessCount = 0;
    private int persistFailureCount = 0;
    private int itemsRecovered = 0;
    private int consecutivePersistFailures = 0;
    private static final int MAX_CONSECUTIVE_FAILURES = 5;

    /**
     * Constructs a dead letter queue with default persistence path.
     *
     * @param maxSize Maximum number of items in DLQ (must be > 0)
     * @throws ResilienceException if maxSize is invalid
     */
    public DeadLetterQueue(int maxSize) {
        this(maxSize, DEFAULT_PERSIST_PATH, null, false);
    }

    /**
     * Constructs a dead letter queue with custom persistence path.
     *
     * @param maxSize     Maximum number of items in DLQ (must be > 0)
     * @param persistPath Path for DLQ persistence (will expand ~/)
     * @param encryptionKey Optional encryption key for data at rest (can be null)
     * @param requireEncryption If true, fail-fast when encryption cannot be initialized
     * @throws ResilienceException if maxSize is invalid or encryption fails
     */
    public DeadLetterQueue(int maxSize, String persistPath, SecretKey encryptionKey, boolean requireEncryption) {
        if (maxSize <= 0) {
            throw new ResilienceException("maxSize must be positive, got " + maxSize);
        }

        this.maxSize = maxSize;
        this.queue = new LinkedList<>();
        this.lock = new ReentrantReadWriteLock();
        this.persistPath = expandPath(persistPath);
        this.requireEncryption = requireEncryption;
        this.objectMapper = new ObjectMapper();

        // Initialize encryption if key provided
        if (encryptionKey != null) {
            try {
                this.encryptionManager = new EncryptionManager(encryptionKey.getEncoded());
                logger.info("DLQ encryption at rest enabled");
            } catch (Exception e) {
                if (requireEncryption) {
                    throw new ResilienceException(
                            "Encryption required but failed to initialize: " + e.getMessage(), e);
                }
                logger.error("Failed to initialize encryption: {}. DLQ will be unencrypted.", e.getMessage());
                this.encryptionManager = null;
            }
        } else {
            if (requireEncryption) {
                throw new ResilienceException(
                        "Encryption required but no key provided. " +
                        "Set encryptionKey parameter.");
            }
            this.encryptionManager = null;
        }

        // Load existing DLQ from disk
        loadFromDisk();

        // Warn about unencrypted storage
        if (encryptionManager == null && !requireEncryption) {
            logger.warn(
                    "⚠️  HIPAA COMPLIANCE WARNING ⚠️\n" +
                    "Dead Letter Queue persistence is enabled WITHOUT encryption at rest.\n" +
                    "DLQ may contain PHI and is stored UNENCRYPTED.\n" +
                    "Unencrypted DLQ file: {}", this.persistPath
            );
        }
    }

    /**
     * Enqueue a failed operation with metadata.
     *
     * <p>Thread-safe operation that adds a failed operation to the DLQ
     * with enriched metadata for investigation. If the DLQ is full, the
     * oldest item is automatically evicted (FIFO).
     *
     * @param item       Description of the failed operation
     * @param error      Exception that caused the failure
     * @param retryCount Number of retry attempts made
     */
    public void enqueue(String item, Exception error, int retryCount) {
        lock.writeLock().lock();
        try {
            boolean wasFull = queue.size() >= maxSize;

            // Truncate large items to prevent memory exhaustion
            String itemStr = item;
            if (itemStr.length() * 2 > MAX_ITEM_SIZE_BYTES) { // Rough size estimate
                int maxChars = MAX_ITEM_SIZE_BYTES / 4; // Conservative char limit
                itemStr = itemStr.substring(0, maxChars) + "... [TRUNCATED]";
                logger.warn(
                        "DLQ item truncated: estimated size exceeds {}KB limit",
                        MAX_ITEM_SIZE_BYTES / 1024
                );
            }

            // Create DLQ item with metadata
            DLQItem dlqItem = new DLQItem(
                    Instant.now().toString(),
                    itemStr,
                    error.getMessage(),
                    error.getClass().getSimpleName(),
                    retryCount
            );

            // Evict oldest if full
            if (wasFull) {
                queue.removeFirst();
                itemsEvicted++;
            }

            // Add new item
            queue.addLast(dlqItem);
            itemsEnqueued++;

            // Persist to disk
            saveToDisk();

            logger.error(
                    "Item moved to DLQ after {} retries. Error: {}",
                    retryCount,
                    error.getClass().getSimpleName()
            );
        } finally {
            lock.writeLock().unlock();
        }
    }

    /**
     * Inspect recent DLQ items.
     *
     * <p>Thread-safe operation that returns the most recent DLQ items
     * for operational visibility and debugging.
     *
     * @param limit Maximum number of items to return (must be > 0)
     * @return List of DLQ items (most recent first)
     * @throws ResilienceException if limit is invalid
     */
    public List<DLQItem> inspect(int limit) {
        if (limit <= 0) {
            throw new ResilienceException("limit must be positive, got " + limit);
        }

        lock.readLock().lock();
        try {
            int actualLimit = Math.min(limit, queue.size());
            List<DLQItem> result = new ArrayList<>(actualLimit);

            // Get most recent items (from end of queue)
            for (int i = queue.size() - actualLimit; i < queue.size(); i++) {
                result.add(queue.get(i));
            }

            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * Get current DLQ size.
     *
     * @return Current number of items in DLQ
     */
    public int size() {
        lock.readLock().lock();
        try {
            return queue.size();
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * Check if DLQ is empty.
     *
     * @return True if DLQ is empty, false otherwise
     */
    public boolean isEmpty() {
        lock.readLock().lock();
        try {
            return queue.isEmpty();
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * Check if DLQ is at maximum capacity.
     *
     * @return True if DLQ is full, false otherwise
     */
    public boolean isFull() {
        lock.readLock().lock();
        try {
            return queue.size() >= maxSize;
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * Clear all items from DLQ.
     *
     * <p>Thread-safe operation that empties the DLQ and persists
     * the cleared state to disk.
     *
     * @return Number of items that were removed
     */
    public int clear() {
        lock.writeLock().lock();
        try {
            int count = queue.size();
            queue.clear();

            // Persist cleared state
            saveToDisk();

            if (count > 0) {
                logger.info("DLQ cleared: {} items removed", count);
            }

            return count;
        } finally {
            lock.writeLock().unlock();
        }
    }

    /**
     * Get DLQ statistics for monitoring.
     *
     * @return Statistics object with DLQ metrics
     */
    public DLQStats stats() {
        lock.readLock().lock();
        try {
            int currentSize = queue.size();
            double utilization = maxSize > 0 ? (currentSize * 100.0 / maxSize) : 0;

            return new DLQStats(
                    currentSize,
                    maxSize,
                    currentSize >= maxSize,
                    currentSize == 0,
                    Math.round(utilization * 100.0) / 100.0,
                    itemsEnqueued,
                    itemsEvicted,
                    persistSuccessCount,
                    persistFailureCount,
                    itemsRecovered,
                    encryptionManager != null
            );
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * Load DLQ from disk on startup.
     */
    private void loadFromDisk() {
        File file = new File(persistPath);
        if (!file.exists()) {
            logger.debug("No existing DLQ file found at {}", persistPath);
            return;
        }

        try {
            byte[] data = Files.readAllBytes(file.toPath());

            // Decrypt if encryption enabled
            if (encryptionManager != null) {
                data = encryptionManager.decrypt(data);
            }

            // Parse JSON
            DLQItem[] items = objectMapper.readValue(data, DLQItem[].class);

            // Restore items (respecting max size limit)
            int startIndex = Math.max(0, items.length - maxSize);
            for (int i = startIndex; i < items.length; i++) {
                queue.add(items[i]);
            }

            itemsRecovered = queue.size();
            logger.info("DLQ loaded from disk: {} items recovered", itemsRecovered);

        } catch (Exception e) {
            logger.error("Failed to load DLQ from disk: {}. Starting with empty DLQ.", e.getClass().getSimpleName());
        }
    }

    /**
     * Persist DLQ to disk using atomic write.
     */
    private void saveToDisk() {
        File parentDir = new File(persistPath).getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            if (!parentDir.mkdirs()) {
                logger.error("Failed to create DLQ directory: {}", parentDir);
                persistFailureCount++;
                return;
            }
        }

        // Take snapshot of current queue
        List<DLQItem> snapshot = new ArrayList<>(queue);

        Path tempFile = null;
        try {
            // Write to temp file
            tempFile = Files.createTempFile(parentDir != null ? parentDir.toPath() : null, ".dlq_", ".tmp");

            byte[] jsonData = objectMapper.writeValueAsBytes(snapshot);

            // Encrypt if enabled
            if (encryptionManager != null) {
                jsonData = encryptionManager.encrypt(jsonData);
            }

            Files.write(tempFile, jsonData);

            // Atomic rename
            Files.move(tempFile, new File(persistPath).toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            tempFile = null; // Rename succeeded

            persistSuccessCount++;
            consecutivePersistFailures = 0;

            logger.debug("DLQ persisted to disk: {} items", snapshot.size());

        } catch (IOException e) {
            persistFailureCount++;
            consecutivePersistFailures++;

            logger.error("Failed to persist DLQ: {}", e.getClass().getSimpleName());

            // Fail-fast after consecutive failures
            if (consecutivePersistFailures >= MAX_CONSECUTIVE_FAILURES) {
                throw new ResilienceException(
                        "DLQ persistence failed " + consecutivePersistFailures + " consecutive times. " +
                        "Last error: " + e.getClass().getSimpleName());
            }
        } finally {
            // Cleanup temp file if write failed
            if (tempFile != null) {
                try {
                    Files.deleteIfExists(tempFile);
                } catch (IOException e) {
                    logger.warn("Failed to cleanup temp file: {}", tempFile);
                }
            }
        }
    }

    /**
     * Expand user home directory in path.
     */
    private String expandPath(String path) {
        if (path.startsWith("~/")) {
            return System.getProperty("user.home") + path.substring(1);
        }
        return path;
    }

    /**
     * DLQ item with metadata.
     */
    public static class DLQItem {
        private String timestamp;
        private String item;
        private String error;
        private String errorType;
        private int retryCount;

        // Default constructor for Jackson
        public DLQItem() {
        }

        public DLQItem(String timestamp, String item, String error, String errorType, int retryCount) {
            this.timestamp = timestamp;
            this.item = item;
            this.error = error;
            this.errorType = errorType;
            this.retryCount = retryCount;
        }

        public String getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(String timestamp) {
            this.timestamp = timestamp;
        }

        public String getItem() {
            return item;
        }

        public void setItem(String item) {
            this.item = item;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public String getErrorType() {
            return errorType;
        }

        public void setErrorType(String errorType) {
            this.errorType = errorType;
        }

        public int getRetryCount() {
            return retryCount;
        }

        public void setRetryCount(int retryCount) {
            this.retryCount = retryCount;
        }
    }

    /**
     * DLQ statistics.
     */
    public static class DLQStats {
        private final int size;
        private final int maxSize;
        private final boolean isFull;
        private final boolean isEmpty;
        private final double utilization;
        private final int itemsEnqueued;
        private final int itemsEvicted;
        private final int persistSuccessCount;
        private final int persistFailureCount;
        private final int itemsRecoveredOnStartup;
        private final boolean encryptionEnabled;

        public DLQStats(int size, int maxSize, boolean isFull, boolean isEmpty, double utilization,
                        int itemsEnqueued, int itemsEvicted, int persistSuccessCount,
                        int persistFailureCount, int itemsRecoveredOnStartup, boolean encryptionEnabled) {
            this.size = size;
            this.maxSize = maxSize;
            this.isFull = isFull;
            this.isEmpty = isEmpty;
            this.utilization = utilization;
            this.itemsEnqueued = itemsEnqueued;
            this.itemsEvicted = itemsEvicted;
            this.persistSuccessCount = persistSuccessCount;
            this.persistFailureCount = persistFailureCount;
            this.itemsRecoveredOnStartup = itemsRecoveredOnStartup;
            this.encryptionEnabled = encryptionEnabled;
        }

        // Getters
        public int getSize() { return size; }
        public int getMaxSize() { return maxSize; }
        public boolean isFull() { return isFull; }
        public boolean isEmpty() { return isEmpty; }
        public double getUtilization() { return utilization; }
        public int getItemsEnqueued() { return itemsEnqueued; }
        public int getItemsEvicted() { return itemsEvicted; }
        public int getPersistSuccessCount() { return persistSuccessCount; }
        public int getPersistFailureCount() { return persistFailureCount; }
        public int getItemsRecoveredOnStartup() { return itemsRecoveredOnStartup; }
        public boolean isEncryptionEnabled() { return encryptionEnabled; }
    }
}
