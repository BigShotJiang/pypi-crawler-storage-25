package com.bhsf.mca.sdk.security;

/**
 * Exception thrown when security operations fail.
 *
 * <p>This exception is used for encryption/decryption failures, certificate validation errors,
 * and other security-related issues.
 */
public class SecurityException extends RuntimeException {

    /**
     * Constructs a new security exception with the specified detail message.
     *
     * @param message the detail message
     */
    public SecurityException(String message) {
        super(message);
    }

    /**
     * Constructs a new security exception with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public SecurityException(String message, Throwable cause) {
        super(message, cause);
    }
}
