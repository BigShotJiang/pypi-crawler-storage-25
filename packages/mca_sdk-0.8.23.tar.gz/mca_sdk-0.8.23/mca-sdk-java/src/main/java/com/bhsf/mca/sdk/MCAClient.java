package com.bhsf.mca.sdk;

import com.bhsf.mca.sdk.config.MCAConfig;
import com.bhsf.mca.sdk.config.ConfigLoader;
import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import com.bhsf.mca.sdk.exceptions.RegistryException;
import com.bhsf.mca.sdk.exceptions.ValidationException;
import com.bhsf.mca.sdk.integrations.AgenticTracking;
import com.bhsf.mca.sdk.integrations.GenAIIntegration;
import com.bhsf.mca.sdk.integrations.TelemetryAttributeUtil;
import com.bhsf.mca.sdk.instrumentation.MetricRouter;
import com.bhsf.mca.sdk.instrumentation.SpanManager;
import com.bhsf.mca.sdk.providers.TelemetryProviders;
import com.bhsf.mca.sdk.registry.RegistryClient;
import com.bhsf.mca.sdk.registry.models.ModelConfig;
import com.bhsf.mca.sdk.util.VersionCheck;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.common.AttributesBuilder;
import io.opentelemetry.api.logs.Logger;
import io.opentelemetry.api.logs.Severity;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Tracer;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MCA SDK Client for instrumenting ML models with OpenTelemetry.
 *
 * <p>Usage example:
 * <pre>{@code
 * try (MCAClient client = new MCAClient.Builder()
 *         .serviceName("readmission-model")
 *         .modelId("mdl-001")
 *         .teamName("clinical-ai")
 *         .build()) {
 *
 *     client.recordPrediction(RecordPredictionRequest.builder()
 *             .latency(0.15)
 *             .attribute("model_version", "2.0")
 *             .build());
 * }
 * }</pre>
 *
 * <p>Thread-safe for concurrent use.
 */
public class MCAClient implements AutoCloseable {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(MCAClient.class);

    /** SDK version for version checking and diagnostics */
    public static final String VERSION = "0.2.0";

    private final MCAConfig config;
    private final TelemetryProviders providers;
    private final Meter meter;
    private final Logger logger;
    private final Tracer tracer;
    private final LongCounter predictionCounter;
    private final DoubleHistogram latencyHistogram;
    private final AtomicBoolean isShutdown;
    private final RegistryClient registryClient;
    private final GenAIIntegration genAIIntegration;
    private final AgenticTracking agenticTracking;
    private final MetricRouter metricRouter;

    /**
     * Private constructor - use Builder to create instances.
     */
    private MCAClient(Builder builder) {
        this.config = builder.config;
        this.registryClient = builder.registryClient;
        this.isShutdown = new AtomicBoolean(false);

        // Initialize telemetry providers with full config (includes GCP and Prometheus support)
        this.providers = new TelemetryProviders(config);

        this.meter = providers.getMeter();
        this.logger = providers.getLogger();
        this.tracer = providers.getTracer();

        // Create metrics
        this.predictionCounter = meter.counterBuilder("model.predictions_total")
                .setDescription("Total number of predictions made by the model")
                .setUnit("1")
                .build();

        this.latencyHistogram = meter.histogramBuilder("model.latency_seconds")
                .setDescription("Prediction latency in seconds")
                .setUnit("s")
                .build();

        // Initialize GenAI and Agentic integrations
        this.genAIIntegration = new GenAIIntegration(meter);
        this.agenticTracking = new AgenticTracking(meter, tracer);

        // Initialize advanced instrumentation
        this.metricRouter = new MetricRouter(meter);

        log.info("MCAClient initialized for service: {}", config.getServiceName());
    }

    /**
     * Record a prediction event with metrics and logs.
     *
     * <p>Creates:
     * <ul>
     *   <li>Counter metric: model.predictions.total</li>
     *   <li>Histogram metric: model.latency.seconds</li>
     *   <li>Structured log with prediction details</li>
     * </ul>
     *
     * @param request RecordPredictionRequest with latency and attributes
     * @throws IllegalStateException if client has been shut down
     */
    public void recordPrediction(RecordPredictionRequest request) {
        if (isShutdown.get()) {
            throw new IllegalStateException("Cannot record prediction: MCAClient has been shut down");
        }

        if (request == null) {
            throw new IllegalArgumentException("RecordPredictionRequest cannot be null");
        }

        // Build attributes for metrics and logs
        AttributesBuilder attrsBuilder = Attributes.builder();
        for (Map.Entry<String, Object> entry : request.getAttributes().entrySet()) {
            addAttribute(attrsBuilder, entry.getKey(), entry.getValue());
        }

        // Add prediction ID only (model.id is already in Resource attributes)
        if (request.getPredictionId() != null) {
            attrsBuilder.put("prediction.id", request.getPredictionId());
        }

        Attributes attributes = attrsBuilder.build();

        // Record counter metric
        predictionCounter.add(1, attributes);

        // Record histogram metric
        latencyHistogram.record(request.getLatency(), attributes);

        // Create structured log
        logger.logRecordBuilder()
                .setSeverity(Severity.INFO)
                .setBody("Prediction recorded")
                .setAllAttributes(attributes)
                .setAttribute(AttributeKey.doubleKey("latency"), request.getLatency())
                .emit();

        log.debug("Recorded prediction: id={}, latency={}s",
                request.getPredictionId(), request.getLatency());
    }

    /**
     * Helper method to add attributes with strict type handling.
     * Only supports String, Long, Integer, Double, Float, and Boolean types.
     * Unsupported types are logged and ignored to prevent PII leaks or useless serialization.
     */
    private void addAttribute(AttributesBuilder builder, String key, Object value) {
        if (value instanceof String) {
            builder.put(key, (String) value);
        } else if (value instanceof Long) {
            builder.put(key, (Long) value);
        } else if (value instanceof Integer) {
            builder.put(key, ((Integer) value).longValue());
        } else if (value instanceof Double) {
            builder.put(key, (Double) value);
        } else if (value instanceof Float) {
            builder.put(key, ((Float) value).doubleValue());
        } else if (value instanceof Boolean) {
            builder.put(key, (Boolean) value);
        } else if (value != null) {
            log.warn("Ignoring unsupported attribute type for key '{}': {} (type: {}). " +
                    "Only String, Long, Integer, Double, Float, and Boolean are supported.",
                    key, value.getClass().getSimpleName(), value.getClass().getName());
        }
    }

    /**
     * Get the GenAI integration for tracking token usage and costs.
     *
     * @return GenAIIntegration instance
     */
    public GenAIIntegration getGenAIIntegration() {
        return genAIIntegration;
    }

    /**
     * Get the Agentic AI integration for tracking goals and tools.
     *
     * @return AgenticTracking instance
     */
    public AgenticTracking getAgenticTracking() {
        return agenticTracking;
    }

    /**
     * Get the OpenTelemetry Tracer for creating custom spans.
     *
     * @return Tracer instance
     */
    public Tracer getTracer() {
        return tracer;
    }

    // Advanced Instrumentation Methods (Story 1.23.6)

    /**
     * Create a trace span with try-with-resources pattern.
     *
     * <p>Java equivalent of Python SDK's trace() context manager.
     * The span is automatically ended when the try block exits.
     *
     * <p>Usage example:
     * <pre>{@code
     * try (var span = client.trace("model.predict")) {
     *     span.setAttribute("input_size", data.size());
     *     // ... prediction logic
     *     span.setAttribute("output", result);
     * }
     * }</pre>
     *
     * @param spanName Name of the span (e.g., "model.predict")
     * @param attributes Initial attributes to attach to the span (may be null)
     * @return SpanManager instance for use with try-with-resources
     * @throws IllegalStateException if client has been shut down
     * @throws IllegalArgumentException if spanName is null or empty
     */
    public SpanManager trace(String spanName, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            throw new IllegalStateException("Cannot create span: MCAClient has been shut down");
        }
        return new SpanManager(tracer, spanName, attributes);
    }

    /**
     * Record a custom metric with explicit instrument type.
     *
     * <p>Supports three instrument types:
     * <ul>
     *   <li>"counter" - Monotonically increasing values (e.g., request count)</li>
     *   <li>"histogram" - Distribution of values (e.g., latency, accuracy)</li>
     *   <li>"gauge" - Current value that can go up or down (e.g., queue size)</li>
     * </ul>
     *
     * @param name Metric name (e.g., "model.cache.hit_rate")
     * @param value Metric value
     * @param instrumentType Type of instrument: "counter", "histogram", or "gauge"
     * @param attributes Additional attributes to attach to the metric (may be null)
     * @throws IllegalStateException if client has been shut down
     * @throws ValidationException if metric name is invalid or instrumentType is invalid
     */
    public void recordMetric(String name, double value, String instrumentType, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            throw new IllegalStateException("Cannot record metric: MCAClient has been shut down");
        }

        // Validate metric name (basic safety checks)
        validateMetricName(name);

        // Parse instrument type
        MetricRouter.InstrumentType type;
        if (instrumentType == null || instrumentType.isEmpty()) {
            type = MetricRouter.InstrumentType.HISTOGRAM; // Default to histogram
        } else {
            switch (instrumentType.toLowerCase()) {
                case "counter":
                    type = MetricRouter.InstrumentType.COUNTER;
                    break;
                case "histogram":
                    type = MetricRouter.InstrumentType.HISTOGRAM;
                    break;
                case "gauge":
                    type = MetricRouter.InstrumentType.GAUGE;
                    break;
                default:
                    // Use ValidationException instead of IllegalArgumentException for consistency
                    throw new ValidationException(
                        "Invalid instrument type: '" + instrumentType + "'. " +
                        "Must be 'counter', 'histogram', or 'gauge'"
                    );
            }
        }

        // Convert attributes to OpenTelemetry Attributes
        Attributes attrs = TelemetryAttributeUtil.buildAttributes(attributes);

        // Delegate to metric router
        metricRouter.recordMetric(name, value, type, attrs);

        log.debug("Recorded custom metric: name={}, value={}, type={}", name, value, instrumentType);
    }

    /**
     * Record a gauge metric (current value that can go up or down).
     *
     * <p>Convenience method for recording gauge metrics without specifying instrument type.
     * Examples: queue size, memory usage, active connections.
     *
     * @param name Metric name
     * @param value Current gauge value
     * @param attributes Additional attributes (may be null)
     * @throws IllegalStateException if client has been shut down
     * @throws ValidationException if metric name is invalid
     */
    public void recordGauge(String name, double value, Map<String, Object> attributes) {
        recordMetric(name, value, "gauge", attributes);
    }

    /**
     * Record a counter metric (monotonically increasing value).
     *
     * <p>Convenience method for recording counter metrics without specifying instrument type.
     * Examples: request count, cache hits, predictions total.
     *
     * @param name Metric name
     * @param value Counter value to add
     * @param attributes Additional attributes (may be null)
     * @throws IllegalStateException if client has been shut down
     * @throws ValidationException if metric name is invalid
     */
    public void recordCounter(String name, double value, Map<String, Object> attributes) {
        recordMetric(name, value, "counter", attributes);
    }

    /**
     * Validate metric name for basic safety.
     *
     * <p>Checks:
     * <ul>
     *   <li>Not null or empty</li>
     *   <li>Length between 1 and 256 characters</li>
     *   <li>No dangerous characters (control chars, special chars)</li>
     *   <li>Starts with letter or underscore (not digit)</li>
     * </ul>
     *
     * @param name Metric name to validate
     * @throws ValidationException if validation fails
     */
    private void validateMetricName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new ValidationException("Metric name cannot be null or empty");
        }

        if (name.length() > 256) {
            throw new ValidationException(
                "Metric name exceeds maximum length of 256 characters: " + name.length()
            );
        }

        // Check for dangerous characters (same as Python SDK)
        String dangerousChars = "\"\\'\\\\/<>[]{}();|&$`";
        for (char c : name.toCharArray()) {
            // Control characters (ASCII 0-31) or dangerous special characters
            if (c < 32 || c > 126 || dangerousChars.indexOf(c) >= 0) {
                throw new ValidationException(
                    "Metric name contains invalid character: '" + c + "' (code: " + (int)c + "). " +
                    "Only alphanumeric, dots, and underscores are allowed."
                );
            }
        }

        // Must start with letter or underscore (not digit)
        char firstChar = name.charAt(0);
        if (Character.isDigit(firstChar)) {
            throw new ValidationException(
                "Metric name must start with a letter or underscore, not a digit: " + name
            );
        }

        // Only allow alphanumeric, dots, and underscores
        for (char c : name.toCharArray()) {
            if (!Character.isLetterOrDigit(c) && c != '.' && c != '_') {
                throw new ValidationException(
                    "Metric name contains invalid character: '" + c + "'. " +
                    "Only alphanumeric, dots, and underscores are allowed."
                );
            }
        }
    }

    /**
     * Shutdown the MCAClient and flush all pending telemetry.
     *
     * <p>This method is idempotent - calling it multiple times is safe.
     * <p>API matches Python SDK: shutdown(timeout_millis=30000)
     *
     * @param timeoutMillis Maximum time to wait for shutdown in milliseconds
     */
    public void shutdown(long timeoutMillis) {
        if (isShutdown.compareAndSet(false, true)) {
            log.info("Shutting down MCAClient for service: {}", config.getServiceName());

            // Shutdown integrations first to prevent new telemetry
            if (genAIIntegration != null) {
                genAIIntegration.shutdown();
            }
            if (agenticTracking != null) {
                agenticTracking.shutdown();
            }

            // Shutdown registry client
            if (registryClient != null) {
                registryClient.shutdown();
            }

            // Shutdown telemetry providers last
            providers.shutdown(timeoutMillis);
            log.info("MCAClient shutdown complete");
        } else {
            log.debug("MCAClient already shut down, ignoring duplicate shutdown call");
        }
    }

    /**
     * AutoCloseable implementation for try-with-resources.
     * Calls shutdown with default 30-second (30000ms) timeout.
     */
    @Override
    public void close() {
        shutdown(30000);
    }

    /**
     * Builder for MCAClient with fluent API.
     */
    public static class Builder {
        private String serviceName;
        private String modelId;
        private String teamName;
        private String modelVersion;
        private String otelEndpoint;
        private String registryUrl;
        private String registryToken;
        private MCAConfig config;
        private RegistryClient registryClient;

        /**
         * Set the service name (required).
         *
         * @param serviceName Name of the service/model
         * @return Builder for chaining
         */
        public Builder serviceName(String serviceName) {
            this.serviceName = serviceName;
            return this;
        }

        /**
         * Set the model ID (optional).
         *
         * @param modelId Unique model identifier
         * @return Builder for chaining
         */
        public Builder modelId(String modelId) {
            this.modelId = modelId;
            return this;
        }

        /**
         * Set the team name (optional).
         *
         * @param teamName Name of the team owning the model
         * @return Builder for chaining
         */
        public Builder teamName(String teamName) {
            this.teamName = teamName;
            return this;
        }

        /**
         * Set the model version (optional, defaults to "1.0.0").
         *
         * @param modelVersion Version of the model
         * @return Builder for chaining
         */
        public Builder modelVersion(String modelVersion) {
            this.modelVersion = modelVersion;
            return this;
        }

        /**
         * Set the OpenTelemetry collector endpoint (optional, defaults to http://localhost:4318).
         *
         * @param otelEndpoint OTLP/HTTP endpoint URL
         * @return Builder for chaining
         */
        public Builder otelEndpoint(String otelEndpoint) {
            this.otelEndpoint = otelEndpoint;
            return this;
        }

        /**
         * Set the registry URL (optional).
         *
         * @param registryUrl URL of the model registry service
         * @return Builder for chaining
         */
        public Builder registryUrl(String registryUrl) {
            this.registryUrl = registryUrl;
            return this;
        }

        /**
         * Set the registry token (optional).
         *
         * @param registryToken Bearer token for registry authentication
         * @return Builder for chaining
         */
        public Builder registryToken(String registryToken) {
            this.registryToken = registryToken;
            return this;
        }

        /**
         * Build the MCAClient instance.
         *
         * <p>Loads configuration from multiple sources with precedence:
         * builder > registry > environment > file > defaults
         *
         * @return Fully initialized MCAClient
         * @throws ConfigurationException if configuration is invalid
         * @throws RegistryException if registry fetch fails (unless gracefulFallback=true)
         */
        public MCAClient build() {
            // Create builder for ConfigLoader with current values
            MCAConfig.Builder configBuilder = new MCAConfig.Builder();
            if (serviceName != null) configBuilder.serviceName(serviceName, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);
            if (modelId != null) configBuilder.modelId(modelId, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);
            if (teamName != null) configBuilder.teamName(teamName, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);
            if (modelVersion != null) configBuilder.modelVersion(modelVersion, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);
            if (otelEndpoint != null) configBuilder.otelEndpoint(otelEndpoint, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);
            if (registryUrl != null) configBuilder.registryUrl(registryUrl, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);
            if (registryToken != null) configBuilder.registryToken(registryToken, com.bhsf.mca.sdk.config.ConfigSource.BUILDER);

            // Load configuration from all sources (defaults → file → env → builder)
            this.config = ConfigLoader.load(configBuilder);

            // Run version check asynchronously (non-blocking)
            VersionCheck.checkVersionAsync(VERSION);

            // Validate required fields
            if (config.getServiceName() == null || config.getServiceName().trim().isEmpty()) {
                throw new ConfigurationException(
                        "serviceName is required. Set via .serviceName(\"your-service\") " +
                        "or environment variable MCA_SERVICE_NAME or config file"
                );
            }

            // Initialize registry client if configured
            if (config.getRegistryUrl() != null) {
                try {
                    log.info("Initializing registry client for URL: {}", config.getRegistryUrl());

                    // Create registry client
                    this.registryClient = RegistryClient.builder()
                            .url(config.getRegistryUrl())
                            .token(config.getRegistryToken())
                            .useGcpAuth(config.isUseGcpAuth())
                            .timeoutSecs(5.0)
                            .cacheTtlSecs(config.getCacheTtlSecs())
                            .meter(null)  // Meter will be created after telemetry providers init
                            .build();

                    // Fetch model config from registry if model ID is set
                    if (config.getModelId() != null) {
                        try {
                            ModelConfig modelConfig = registryClient.fetchModelConfig(
                                    config.getModelId(),
                                    config.getModelVersion()
                            );

                            // Merge registry config into MCAConfig
                            this.config = applyRegistryConfig(config, modelConfig);
                            log.info("Applied registry config for model: {}", config.getModelId());

                        } catch (RegistryException e) {
                            if (config.isGracefulFallback()) {
                                log.warn("Registry unavailable, using local config: {}", e.getMessage());
                            } else {
                                throw e;
                            }
                        }

                        // Start background refresh if configured
                        if (config.getRefreshIntervalSecs() > 0) {
                            registryClient.startBackgroundRefresh(config.getRefreshIntervalSecs());
                        }
                    }

                } catch (Exception e) {
                    if (config.isGracefulFallback()) {
                        log.warn("Failed to initialize registry client, continuing without registry", e);
                        this.registryClient = null;
                    } else {
                        throw e;
                    }
                }
            }

            return new MCAClient(this);
        }

        /**
         * Apply registry configuration to MCAConfig.
         *
         * @param config Current MCAConfig
         * @param modelConfig Registry ModelConfig
         * @return Updated MCAConfig
         */
        private MCAConfig applyRegistryConfig(MCAConfig config, ModelConfig modelConfig) {
            MCAConfig.Builder builder = new MCAConfig.Builder(config);
            
            if (config.getSource("modelVersion") != com.bhsf.mca.sdk.config.ConfigSource.BUILDER && modelConfig.getModelVersion() != null) {
                builder.modelVersion(modelConfig.getModelVersion(), com.bhsf.mca.sdk.config.ConfigSource.REGISTRY);
            }
            if (config.getSource("teamName") != com.bhsf.mca.sdk.config.ConfigSource.BUILDER && modelConfig.getTeamName() != null) {
                builder.teamName(modelConfig.getTeamName(), com.bhsf.mca.sdk.config.ConfigSource.REGISTRY);
            }
            if (config.getSource("modelType") != com.bhsf.mca.sdk.config.ConfigSource.BUILDER && modelConfig.getModelType() != null) {
                builder.modelType(modelConfig.getModelType(), com.bhsf.mca.sdk.config.ConfigSource.REGISTRY);
            }
            if (config.getSource("modelCategory") != com.bhsf.mca.sdk.config.ConfigSource.BUILDER && modelConfig.getModelCategory() != null) {
                builder.modelCategory(modelConfig.getModelCategory(), com.bhsf.mca.sdk.config.ConfigSource.REGISTRY);
            }
            if (config.getSource("thresholds") != com.bhsf.mca.sdk.config.ConfigSource.BUILDER && modelConfig.getThresholds() != null && !modelConfig.getThresholds().isEmpty()) {
                builder.thresholds(modelConfig.getThresholds(), com.bhsf.mca.sdk.config.ConfigSource.REGISTRY);
            }
            
            return builder.build();
        }

    }
}
