package com.bhsf.mca.sdk.registry;

import com.bhsf.mca.sdk.exceptions.RegistryAuthException;
import com.bhsf.mca.sdk.exceptions.RegistryConfigNotFoundException;
import com.bhsf.mca.sdk.exceptions.RegistryConnectionException;
import com.bhsf.mca.sdk.exceptions.RegistryException;
import com.bhsf.mca.sdk.registry.models.CacheEntry;
import com.bhsf.mca.sdk.registry.models.ModelConfig;
import com.bhsf.mca.sdk.resilience.RetryPolicy;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.opentelemetry.api.metrics.Meter;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Client for fetching configurations from the Model Registry.
 *
 * <p>Provides methods to fetch model configurations from a central registry
 * service with automatic retry, caching, and security. Features:
 * <ul>
 *   <li>Automatic retry with exponential backoff</li>
 *   <li>In-memory cache with TTL</li>
 *   <li>HTTPS enforcement for non-localhost endpoints</li>
 *   <li>Bearer token authentication</li>
 *   <li>Request timeout protection</li>
 *   <li>Thread-safe cache operations</li>
 *   <li>Background refresh of tracked models (optional)</li>
 * </ul>
 *
 * <p>Thread-safe for concurrent use. Use {@link Builder} to construct instances.
 *
 * <p>Example:
 * <pre>{@code
 * RegistryClient client = RegistryClient.builder()
 *     .url("https://registry.example.com")
 *     .token("secret-token")
 *     .timeoutSecs(5.0)
 *     .cacheTtlSecs(600)
 *     .build();
 *
 * ModelConfig config = client.fetchModelConfig("mdl-001", "latest");
 *
 * // Start background refresh
 * client.startBackgroundRefresh(300);
 *
 * // Clean shutdown
 * client.shutdown();
 * }</pre>
 */
public class RegistryClient implements AutoCloseable {

    private static final Logger logger = LoggerFactory.getLogger(RegistryClient.class);

    private static final String DEFAULT_VERSION = "latest";
    private static final int DEFAULT_CACHE_TTL_SECS = 600;  // 10 minutes
    private static final double DEFAULT_TIMEOUT_SECS = 5.0;
    private static final int DEFAULT_MAX_RETRIES = 3;
    private static final double DEFAULT_BASE_DELAY = 1.0;
    private static final double DEFAULT_MAX_DELAY = 10.0;

    private final String baseUrl;
    private final String token;
    private final boolean useGcpAuth;
    private final double timeoutSecs;
    private final int cacheTtlSecs;
    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final RetryPolicy retryPolicy;
    private final ConcurrentHashMap<String, CacheEntry<ModelConfig>> cache;
    private final Set<String> trackedModels;
    private final RegistryTelemetry telemetry;
    private ScheduledExecutorService refreshExecutor;

    private RegistryClient(Builder builder) {
        this.baseUrl = builder.url.endsWith("/") ? builder.url.substring(0, builder.url.length() - 1) : builder.url;
        this.token = builder.token;
        this.useGcpAuth = builder.useGcpAuth;
        this.timeoutSecs = builder.timeoutSecs;
        this.cacheTtlSecs = builder.cacheTtlSecs;

        // Validate URL
        validateUrl(this.baseUrl);

        // Validate authentication
        if (token != null && useGcpAuth) {
            throw new RegistryException(
                    "Cannot use both token and use_gcp_auth. Choose either bearer token or GCP authentication."
            );
        }

        if (useGcpAuth) {
            // Check if GCP auth library is available
            try {
                Class.forName("com.google.auth.oauth2.GoogleCredentials");
            } catch (ClassNotFoundException e) {
                throw new IllegalStateException(
                        "GCP authentication requested but google-auth library not available. " +
                        "Add dependency: com.google.auth:google-auth-library-oauth2-http:1.20.0",
                        e
                );
            }
        }

        // Build HTTP client
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout((long) (timeoutSecs * 1000), TimeUnit.MILLISECONDS)
                .readTimeout((long) (timeoutSecs * 1000), TimeUnit.MILLISECONDS)
                .writeTimeout((long) (timeoutSecs * 1000), TimeUnit.MILLISECONDS)
                .build();

        this.objectMapper = new ObjectMapper();
        this.retryPolicy = new RetryPolicy(DEFAULT_MAX_RETRIES, DEFAULT_BASE_DELAY, DEFAULT_MAX_DELAY);
        this.cache = new ConcurrentHashMap<>();
        this.trackedModels = new HashSet<>();
        this.telemetry = new RegistryTelemetry(builder.meter);

        logger.info("RegistryClient initialized with URL: {}", baseUrl);
    }

    /**
     * Validate registry URL for HTTPS enforcement.
     *
     * <p>HTTPS is required for all non-localhost endpoints to prevent
     * man-in-the-middle attacks. Localhost and 127.0.0.1 are exempt
     * for local development.
     *
     * @param url Registry URL to validate
     * @throws RegistryException if HTTP is used for non-localhost endpoint
     */
    private void validateUrl(String url) {
        try {
            URL parsedUrl = new URL(url);
            String protocol = parsedUrl.getProtocol();
            String host = parsedUrl.getHost();

            // HTTP is only allowed for localhost
            if ("http".equals(protocol)) {
                boolean isLocalhost = "localhost".equals(host) ||
                        "127.0.0.1".equals(host) ||
                        "::1".equals(host);

                if (!isLocalhost) {
                    throw new RegistryException(
                            "HTTPS required for non-localhost registry URL: " + url + ". " +
                            "HTTP is only allowed for localhost development."
                    );
                }

                logger.warn("Using HTTP for localhost registry: {}", url);
            }

        } catch (IOException e) {
            throw new RegistryException("Invalid registry URL: " + url, e);
        }
    }

    /**
     * Fetch model configuration from registry.
     *
     * <p>Fetches configuration for the specified model ID and version.
     * Uses cache if available and not expired. Tracks model for background refresh.
     *
     * @param modelId Model identifier
     * @param version Model version (null or "latest" for latest version)
     * @return ModelConfig from registry
     * @throws RegistryException                if fetch fails
     * @throws RegistryConnectionException      if connection fails
     * @throws RegistryAuthException            if authentication fails
     * @throws RegistryConfigNotFoundException  if model not found
     */
    public ModelConfig fetchModelConfig(String modelId, String version) {
        if (modelId == null || modelId.trim().isEmpty()) {
            throw new IllegalArgumentException("modelId cannot be null or empty");
        }

        String effectiveVersion = (version == null || version.trim().isEmpty()) ? DEFAULT_VERSION : version;
        String cacheKey = getCacheKey(modelId, effectiveVersion);

        // Track this model for background refresh
        synchronized (trackedModels) {
            trackedModels.add(modelId + ":" + effectiveVersion);
        }

        // Check cache first
        CacheEntry<ModelConfig> cached = cache.get(cacheKey);
        if (cached != null && cached.isValid()) {
            logger.debug("Cache hit for model: {} version: {}", modelId, effectiveVersion);
            telemetry.recordCacheHit();
            return cached.getValue();
        }

        logger.debug("Cache miss for model: {} version: {}", modelId, effectiveVersion);
        telemetry.recordCacheMiss();

        // Fetch from registry with retry
        try {
            ModelConfig config = retryPolicy.executeWithRetry(() -> fetchWithHttp(modelId, effectiveVersion));

            // Cache the result
            long expiresAt = System.currentTimeMillis() + (cacheTtlSecs * 1000L);
            cache.put(cacheKey, new CacheEntry<>(config, expiresAt));

            logger.info("Fetched model config from registry: {} version: {}", modelId, effectiveVersion);
            return config;

        } catch (RegistryException e) {
            throw e;
        } catch (Exception e) {
            throw new RegistryConnectionException(
                    "Failed to fetch model config: " + modelId + " version: " + effectiveVersion,
                    e
            );
        }
    }

    /**
     * Fetch model configuration via HTTP.
     *
     * @param modelId Model identifier
     * @param version Model version
     * @return ModelConfig from API
     * @throws IOException if HTTP request fails
     */
    private ModelConfig fetchWithHttp(String modelId, String version) throws IOException {
        long startTime = System.currentTimeMillis();

        try {
            String endpoint = baseUrl + "/api/v1/models/" + modelId + "?version=" + version;
            logger.debug("Fetching model config from: {}", endpoint);

            Request.Builder requestBuilder = new Request.Builder().url(endpoint);

            // Add authentication header
            if (token != null) {
                requestBuilder.addHeader("Authorization", "Bearer " + token);
            } else if (useGcpAuth) {
                String gcpToken = getGcpToken();
                requestBuilder.addHeader("Authorization", "Bearer " + gcpToken);
            }

            Request request = requestBuilder.build();

            try (Response response = httpClient.newCall(request).execute()) {
                double latencySeconds = (System.currentTimeMillis() - startTime) / 1000.0;

                if (!response.isSuccessful()) {
                    telemetry.recordError(latencySeconds);
                    handleHttpError(response, modelId, version);
                }

                telemetry.recordSuccess(latencySeconds);

                // Parse response
                String body = response.body().string();
                return parseModelConfig(body);
            }

        } catch (IOException e) {
            double latencySeconds = (System.currentTimeMillis() - startTime) / 1000.0;
            telemetry.recordError(latencySeconds);
            throw e;
        }
    }

    /**
     * Handle HTTP error responses.
     *
     * @param response HTTP response
     * @param modelId  Model identifier
     * @param version  Model version
     * @throws RegistryException based on status code
     */
    private void handleHttpError(Response response, String modelId, String version) throws IOException {
        int statusCode = response.code();
        String body = response.body() != null ? response.body().string() : "";

        if (statusCode == 404) {
            throw new RegistryConfigNotFoundException(
                    "Model config not found: " + modelId + " version: " + version
            );
        } else if (statusCode == 401 || statusCode == 403) {
            // Sanitize token from error message
            String message = "Authentication failed for registry request";
            if (token != null) {
                message += " (token: ***" + token.substring(Math.max(0, token.length() - 4)) + ")";
            }
            throw new RegistryAuthException(message);
        } else {
            throw new RegistryConnectionException(
                    "Registry request failed with status " + statusCode + ": " + body
            );
        }
    }

    /**
     * Parse model configuration from JSON response.
     *
     * @param json JSON string from API
     * @return ModelConfig object
     * @throws IOException if parsing fails
     */
    private ModelConfig parseModelConfig(String json) throws IOException {
        JsonNode root = objectMapper.readTree(json);

        ModelConfig.Builder builder = ModelConfig.builder()
                .serviceName(root.path("service_name").asText())
                .modelId(root.path("model_id").asText())
                .modelVersion(root.path("model_version").asText())
                .teamName(root.path("team_name").asText())
                .modelType(root.path("model_type").asText())
                .modelCategory(root.path("model_category").asText());

        // Optional fields
        if (root.has("registry_id")) {
            builder.registryId(root.get("registry_id").asText());
        }
        if (root.has("deployment_id")) {
            builder.deploymentId(root.get("deployment_id").asText());
        }

        // Parse thresholds
        if (root.has("thresholds")) {
            Map<String, Double> thresholds = new HashMap<>();
            root.get("thresholds").fields().forEachRemaining(entry -> {
                thresholds.put(entry.getKey(), entry.getValue().asDouble());
            });
            builder.thresholds(thresholds);
        }

        // Parse extra_resource
        if (root.has("extra_resource")) {
            Map<String, String> extraResource = new HashMap<>();
            root.get("extra_resource").fields().forEachRemaining(entry -> {
                extraResource.put(entry.getKey(), entry.getValue().asText());
            });
            builder.extraResource(extraResource);
        }

        return builder.build();
    }

    /**
     * Get GCP ID token for authentication.
     *
     * @return GCP ID token
     * @throws IOException if token fetch fails
     */
    private String getGcpToken() throws IOException {
        // Placeholder for GCP authentication
        // In real implementation, use GoogleCredentials to get ID token
        throw new UnsupportedOperationException("GCP authentication not yet implemented");
    }

    /**
     * Generate cache key for model ID and version.
     *
     * @param modelId Model identifier
     * @param version Model version
     * @return Cache key
     */
    private String getCacheKey(String modelId, String version) {
        return "model:" + modelId + ":" + version;
    }

    /**
     * Start background refresh of tracked models.
     *
     * <p>Launches a background thread that periodically refreshes all
     * tracked model configurations. Errors during refresh are logged
     * but do not stop the refresh thread.
     *
     * @param intervalSecs Refresh interval in seconds
     */
    public void startBackgroundRefresh(int intervalSecs) {
        if (intervalSecs <= 0) {
            logger.info("Background refresh disabled (interval <= 0)");
            return;
        }

        if (refreshExecutor != null) {
            logger.warn("Background refresh already started");
            return;
        }

        refreshExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread thread = new Thread(r, "registry-refresh");
            thread.setDaemon(true);
            return thread;
        });

        refreshExecutor.scheduleAtFixedRate(
                this::refreshAllTrackedModels,
                intervalSecs,
                intervalSecs,
                TimeUnit.SECONDS
        );

        logger.info("Started background refresh with interval: {}s", intervalSecs);
    }

    /**
     * Refresh all tracked models.
     *
     * <p>Called by background refresh thread. Errors are logged but do not
     * stop the refresh process for other models.
     */
    private void refreshAllTrackedModels() {
        Set<String> modelsToRefresh;
        synchronized (trackedModels) {
            modelsToRefresh = new HashSet<>(trackedModels);
        }

        logger.debug("Refreshing {} tracked models", modelsToRefresh.size());

        for (String modelKey : modelsToRefresh) {
            try {
                String[] parts = modelKey.split(":", 2);
                if (parts.length == 2) {
                    String modelId = parts[0];
                    String version = parts[1];

                    // Force refresh by removing from cache
                    String cacheKey = getCacheKey(modelId, version);
                    cache.remove(cacheKey);

                    // Fetch fresh config
                    fetchModelConfig(modelId, version);
                    logger.debug("Refreshed model: {} version: {}", modelId, version);
                }
            } catch (Exception e) {
                logger.error("Failed to refresh model: {}", modelKey, e);
                // Continue with other models
            }
        }
    }

    /**
     * Shutdown the registry client and stop background refresh.
     *
     * <p>Idempotent - safe to call multiple times.
     */
    public void shutdown() {
        if (refreshExecutor != null) {
            logger.info("Shutting down background refresh");
            refreshExecutor.shutdown();
            try {
                if (!refreshExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    refreshExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                refreshExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
            refreshExecutor = null;
        }

        httpClient.dispatcher().executorService().shutdown();
        httpClient.connectionPool().evictAll();

        logger.info("RegistryClient shutdown complete");
    }

    /**
     * AutoCloseable implementation.
     */
    @Override
    public void close() {
        shutdown();
    }

    /**
     * Builder for RegistryClient.
     */
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String url;
        private String token;
        private boolean useGcpAuth = false;
        private double timeoutSecs = DEFAULT_TIMEOUT_SECS;
        private int cacheTtlSecs = DEFAULT_CACHE_TTL_SECS;
        private Meter meter;

        public Builder url(String url) {
            this.url = url;
            return this;
        }

        public Builder token(String token) {
            this.token = token;
            return this;
        }

        public Builder useGcpAuth(boolean useGcpAuth) {
            this.useGcpAuth = useGcpAuth;
            return this;
        }

        public Builder timeoutSecs(double timeoutSecs) {
            this.timeoutSecs = timeoutSecs;
            return this;
        }

        public Builder cacheTtlSecs(int cacheTtlSecs) {
            this.cacheTtlSecs = cacheTtlSecs;
            return this;
        }

        public Builder meter(Meter meter) {
            this.meter = meter;
            return this;
        }

        public RegistryClient build() {
            if (url == null || url.trim().isEmpty()) {
                throw new IllegalArgumentException("url is required");
            }
            return new RegistryClient(this);
        }
    }
}
