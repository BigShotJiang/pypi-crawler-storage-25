package com.bhsf.mca.sdk.security;

import com.google.cloud.secretmanager.v1.AccessSecretVersionRequest;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Provider for GCP Secret Manager operations with strongly-typed API access.
 *
 * <p>This class is only loaded when the google-cloud-secretmanager library is available.
 * It provides compile-time type safety while supporting optional dependency patterns.
 *
 * <p><strong>Note:</strong> This class uses direct imports from the GCP SDK. It will only
 * be instantiated if the optional dependency is present at runtime.
 */
class GcpSecretProvider implements AutoCloseable {
    private static final Logger logger = LoggerFactory.getLogger(GcpSecretProvider.class);

    private final SecretManagerServiceClient client;
    private final String projectId;

    /**
     * Creates a new GCP Secret Provider.
     *
     * @param projectId GCP project ID
     * @throws IOException if client creation fails
     */
    GcpSecretProvider(String projectId) throws IOException {
        this.projectId = projectId;
        this.client = SecretManagerServiceClient.create();
        logger.debug("GCP Secret Manager client created for project: {}", projectId);
    }

    /**
     * Package-private constructor for testing with mocked client.
     *
     * @param projectId GCP project ID
     * @param client mocked SecretManagerServiceClient
     */
    GcpSecretProvider(String projectId, SecretManagerServiceClient client) {
        this.projectId = projectId;
        this.client = client;
    }

    /**
     * Fetches a secret from GCP Secret Manager.
     *
     * @param secretName name of the secret to fetch
     * @return secret value as string
     * @throws SecurityException if secret cannot be accessed
     */
    String fetchSecret(String secretName) {
        try {
            // Build secret version name: projects/{project}/secrets/{secret}/versions/latest
            SecretVersionName secretVersionName = SecretVersionName.of(
                projectId,
                secretName,
                "latest"
            );

            // Build request
            AccessSecretVersionRequest request = AccessSecretVersionRequest.newBuilder()
                .setName(secretVersionName.toString())
                .build();

            // Access secret
            AccessSecretVersionResponse response = client.accessSecretVersion(request);

            // Extract secret value
            String secretValue = response.getPayload().getData().toStringUtf8();

            logger.debug("Successfully fetched secret: {} (project: {})", secretName, projectId);
            return secretValue;

        } catch (Exception e) {
            // Use safe error message - don't reveal secret existence or permissions
            String safeMessage = String.format(
                "Failed to access secret from Secret Manager. Secret: %s, Project: %s",
                secretName, projectId
            );

            // Log detailed error internally
            logger.error("Secret access failed - Secret: {}, Project: {}, Error: {}",
                secretName, projectId, e.getClass().getSimpleName());

            throw new SecurityException(safeMessage, e);
        }
    }

    @Override
    public void close() {
        if (client != null) {
            try {
                client.close();
                logger.debug("GCP Secret Manager client closed");
            } catch (Exception e) {
                logger.warn("Failed to close GCP Secret Manager client", e);
            }
        }
    }
}
