package com.bhsf.mca.sdk.registry.models;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Model configuration retrieved from the registry.
 *
 * <p>Contains model metadata, thresholds, and resource attributes
 * for OpenTelemetry instrumentation. Uses two-field taxonomy for
 * model classification (model_category + model_type).
 *
 * <p>Immutable once created. Use Builder to construct instances.
 *
 * <p>Example:
 * <pre>{@code
 * ModelConfig config = ModelConfig.builder()
 *     .serviceName("readmission-model")
 *     .modelId("mdl-001")
 *     .modelVersion("2.0.0")
 *     .teamName("clinical-ai")
 *     .modelCategory("internal")
 *     .modelType("regression")
 *     .threshold("MAE", 12.5)
 *     .threshold("RMSE", 18.3)
 *     .build();
 * }</pre>
 */
public class ModelConfig {

    // Required fields
    private final String serviceName;
    private final String modelId;
    private final String modelVersion;
    private final String teamName;
    private final String modelType;
    private final String modelCategory;

    // Optional identifiers
    private final String registryId;
    private final String deploymentId;

    // Thresholds and metadata
    private final Map<String, Double> thresholds;
    private final Map<String, Object> phiFields;
    private final Map<String, String> extraResource;

    // Time-series specific
    private final String associationIdColumn;

    // Timestamps (for debugging)
    private final String createdAt;
    private final String updatedAt;

    private ModelConfig(Builder builder) {
        // Required fields validation
        if (builder.serviceName == null || builder.serviceName.trim().isEmpty()) {
            throw new IllegalArgumentException("serviceName is required");
        }
        if (builder.modelId == null || builder.modelId.trim().isEmpty()) {
            throw new IllegalArgumentException("modelId is required");
        }
        if (builder.modelVersion == null || builder.modelVersion.trim().isEmpty()) {
            throw new IllegalArgumentException("modelVersion is required");
        }
        if (builder.teamName == null || builder.teamName.trim().isEmpty()) {
            throw new IllegalArgumentException("teamName is required");
        }
        if (builder.modelType == null || builder.modelType.trim().isEmpty()) {
            throw new IllegalArgumentException("modelType is required");
        }
        if (builder.modelCategory == null || builder.modelCategory.trim().isEmpty()) {
            throw new IllegalArgumentException("modelCategory is required");
        }

        this.serviceName = builder.serviceName;
        this.modelId = builder.modelId;
        this.modelVersion = builder.modelVersion;
        this.teamName = builder.teamName;
        this.modelType = builder.modelType;
        this.modelCategory = builder.modelCategory;

        this.registryId = builder.registryId;
        this.deploymentId = builder.deploymentId;

        // Defensive copy of mutable collections
        this.thresholds = Collections.unmodifiableMap(new HashMap<>(builder.thresholds));
        this.phiFields = Collections.unmodifiableMap(new HashMap<>(builder.phiFields));
        this.extraResource = Collections.unmodifiableMap(new HashMap<>(builder.extraResource));

        this.associationIdColumn = builder.associationIdColumn;
        this.createdAt = builder.createdAt;
        this.updatedAt = builder.updatedAt;
    }

    // Getters

    public String getServiceName() {
        return serviceName;
    }

    public String getModelId() {
        return modelId;
    }

    public String getModelVersion() {
        return modelVersion;
    }

    public String getTeamName() {
        return teamName;
    }

    public String getModelType() {
        return modelType;
    }

    public String getModelCategory() {
        return modelCategory;
    }

    public String getRegistryId() {
        return registryId;
    }

    public String getDeploymentId() {
        return deploymentId;
    }

    public Map<String, Double> getThresholds() {
        return thresholds;
    }

    public Map<String, Object> getPhiFields() {
        return phiFields;
    }

    public Map<String, String> getExtraResource() {
        return extraResource;
    }

    public String getAssociationIdColumn() {
        return associationIdColumn;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Create a new builder for ModelConfig.
     *
     * @return Builder instance
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder for ModelConfig with fluent API.
     */
    public static class Builder {
        // Required fields
        private String serviceName;
        private String modelId;
        private String modelVersion;
        private String teamName;
        private String modelType;
        private String modelCategory;

        // Optional fields
        private String registryId;
        private String deploymentId;
        private Map<String, Double> thresholds = new HashMap<>();
        private Map<String, Object> phiFields = new HashMap<>();
        private Map<String, String> extraResource = new HashMap<>();
        private String associationIdColumn;
        private String createdAt;
        private String updatedAt;

        public Builder serviceName(String serviceName) {
            this.serviceName = serviceName;
            return this;
        }

        public Builder modelId(String modelId) {
            this.modelId = modelId;
            return this;
        }

        public Builder modelVersion(String modelVersion) {
            this.modelVersion = modelVersion;
            return this;
        }

        public Builder teamName(String teamName) {
            this.teamName = teamName;
            return this;
        }

        public Builder modelType(String modelType) {
            this.modelType = modelType;
            return this;
        }

        public Builder modelCategory(String modelCategory) {
            this.modelCategory = modelCategory;
            return this;
        }

        public Builder registryId(String registryId) {
            this.registryId = registryId;
            return this;
        }

        public Builder deploymentId(String deploymentId) {
            this.deploymentId = deploymentId;
            return this;
        }

        public Builder thresholds(Map<String, Double> thresholds) {
            if (thresholds != null) {
                this.thresholds = new HashMap<>(thresholds);
            }
            return this;
        }

        public Builder threshold(String key, Double value) {
            this.thresholds.put(key, value);
            return this;
        }

        public Builder phiFields(Map<String, Object> phiFields) {
            if (phiFields != null) {
                this.phiFields = new HashMap<>(phiFields);
            }
            return this;
        }

        public Builder extraResource(Map<String, String> extraResource) {
            if (extraResource != null) {
                this.extraResource = new HashMap<>(extraResource);
            }
            return this;
        }

        public Builder associationIdColumn(String associationIdColumn) {
            this.associationIdColumn = associationIdColumn;
            return this;
        }

        public Builder createdAt(String createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder updatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }

        public ModelConfig build() {
            return new ModelConfig(this);
        }
    }
}
