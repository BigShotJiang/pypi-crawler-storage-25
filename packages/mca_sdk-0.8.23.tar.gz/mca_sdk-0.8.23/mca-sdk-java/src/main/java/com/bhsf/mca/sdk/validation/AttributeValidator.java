package com.bhsf.mca.sdk.validation;

import com.bhsf.mca.sdk.config.MCAConfig;
import com.bhsf.mca.sdk.exceptions.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Validates resource attributes based on model type.
 *
 * <p>Performs validation of configuration attributes ensuring:
 * <ul>
 *   <li>All required attributes for the model type are present</li>
 *   <li>Attribute values are non-null and non-empty</li>
 *   <li>Attribute values don't exceed length limits (1024 chars)</li>
 *   <li>Attribute values match expected format patterns</li>
 * </ul>
 *
 * <p>Supports two modes:
 * <ul>
 *   <li>Strict mode: Throws ValidationException on validation failure</li>
 *   <li>Permissive mode: Returns ValidationResult with errors, logs warnings</li>
 * </ul>
 */
public class AttributeValidator {

    private static final Logger logger = LoggerFactory.getLogger(AttributeValidator.class);

    // Pre-compiled regex pattern for attribute value validation
    private static final Pattern ATTR_VALUE_PATTERN = Pattern.compile("^[a-zA-Z0-9_.-]+$");
    private static final int MAX_ATTRIBUTE_LENGTH = 1024;

    private final MCAConfig config;
    private final boolean strict;
    private final ValidationRules.RuleSet rules;

    /**
     * Creates an AttributeValidator.
     *
     * @param config MCAConfig with model_category, model_type, and attributes
     * @param strict If true, raise exception on validation failure
     */
    public AttributeValidator(MCAConfig config, boolean strict) {
        if (config == null) {
            throw new IllegalArgumentException("config cannot be null");
        }
        this.config = config;
        this.strict = strict;
        this.rules = ValidationRules.getValidationRules(
            config.getModelCategory(),
            config.getModelType()
        );
    }

    /**
     * Validates resource attributes.
     *
     * @return ValidationResult with is_valid, missing_fields, errors
     * @throws ValidationException if strict=true and validation fails
     */
    public ValidationResult validate() {
        List<String> missingFields = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        // Build attribute map from config
        Map<String, String> attributeMap = buildAttributeMap();

        // Check required fields
        for (String field : rules.getRequired()) {
            String value = attributeMap.get(field);

            if (value == null || value.trim().isEmpty()) {
                missingFields.add(field);
                errors.add("Missing required attribute: " + field);
            } else if (!isValidValue(field, value)) {
                // SECURITY: Never include raw value in error message (PHI leakage risk)
                errors.add("Invalid value for " + field);
            }
        }

        // Check optional fields (defense-in-depth validation)
        for (String field : rules.getOptional()) {
            String value = attributeMap.get(field);
            // Only validate if provided (optional fields can be null/missing)
            if (value != null && !value.trim().isEmpty()) {
                if (!isValidValue(field, value)) {
                    errors.add("Invalid value for " + field);
                }
            }
        }

        // Create result
        boolean isValid = errors.isEmpty();
        ValidationResult result = isValid ?
            ValidationResult.success() :
            ValidationResult.failure(missingFields, errors);

        // Log warnings in permissive mode
        if (!isValid && !strict) {
            logger.warn(
                "Validation failed for model_category={}, model_type={}: {}",
                config.getModelCategory(),
                config.getModelType(),
                String.join(", ", errors)
            );
        }

        // Raise exception in strict mode
        if (!isValid && strict) {
            String errorMsg = String.format(
                "Validation failed for model_category=%s, model_type=%s: %s",
                config.getModelCategory(),
                config.getModelType(),
                String.join(", ", errors)
            );
            if (!missingFields.isEmpty()) {
                errorMsg += ". Missing fields: " + String.join(", ", missingFields);
            }
            throw new ValidationException(
                errorMsg,
                missingFields,
                new HashMap<>(),
                config.getModelType(),
                config.getModelCategory()
            );
        }

        return result;
    }

    /**
     * Builds attribute map from MCAConfig.
     *
     * @return Map of attribute names to values
     */
    private Map<String, String> buildAttributeMap() {
        Map<String, String> map = new HashMap<>();

        map.put(ValidationRules.ATTR_SERVICE_NAME, config.getServiceName());
        map.put(ValidationRules.ATTR_MODEL_ID, config.getModelId());
        map.put(ValidationRules.ATTR_MODEL_VERSION, config.getModelVersion());
        map.put(ValidationRules.ATTR_TEAM_NAME, config.getTeamName());

        // LLM provider and model (generative/agentic models)
        // Note: MCAConfig doesn't have llmProvider/llmModel yet, will be added in story 1.23.3
        // For now, these will be null for generative/agentic types

        // Vendor name (vendor models)
        // Note: MCAConfig doesn't have vendorName yet, will be added in story 1.23.3
        // For now, this will be null for vendor types

        // Model type (vendor models only - internal models use taxonomy model_type)
        if ("vendor".equalsIgnoreCase(config.getModelCategory())) {
            map.put(ValidationRules.ATTR_MODEL_TYPE, config.getModelType());
        } else {
            map.put(ValidationRules.ATTR_MODEL_TYPE, config.getModelType());
        }

        // Optional fields
        // Note: deployment.environment not in MCAConfig yet

        return map;
    }

    /**
     * Validates attribute value.
     *
     * @param field Attribute name
     * @param value Attribute value
     * @return true if valid, false otherwise
     */
    private boolean isValidValue(String field, String value) {
        // Must be non-empty string
        if (value == null || value.trim().isEmpty()) {
            return false;
        }

        // Length limit (security - prevent PHI)
        if (value.length() > MAX_ATTRIBUTE_LENGTH) {
            logger.warn("Attribute {} exceeds max length of {} chars", field, MAX_ATTRIBUTE_LENGTH);
            return false;
        }

        // Format validation for critical fields
        // Validates alphanumeric + dash + underscore + dot
        // Prevents invalid characters from reaching OTLP exporters
        if (isCriticalField(field)) {
            if (!ATTR_VALUE_PATTERN.matcher(value).matches()) {
                logger.warn("Attribute {} contains invalid characters", field);
                return false;
            }
        }

        return true;
    }

    /**
     * Checks if field is critical and requires format validation.
     *
     * @param field Attribute name
     * @return true if critical field
     */
    private boolean isCriticalField(String field) {
        return field.equals(ValidationRules.ATTR_MODEL_ID)
            || field.equals(ValidationRules.ATTR_SERVICE_NAME)
            || field.equals(ValidationRules.ATTR_TEAM_NAME)
            || field.equals(ValidationRules.ATTR_LLM_PROVIDER)
            || field.equals(ValidationRules.ATTR_LLM_MODEL)
            || field.equals(ValidationRules.ATTR_VENDOR_NAME)
            || field.equals(ValidationRules.ATTR_MODEL_VERSION)
            || field.equals(ValidationRules.ATTR_SERVICE_VERSION)
            || field.equals(ValidationRules.ATTR_DEPLOYMENT_ENV);
    }
}
