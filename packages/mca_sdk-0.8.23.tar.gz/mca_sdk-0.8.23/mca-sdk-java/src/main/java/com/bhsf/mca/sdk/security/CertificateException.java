package com.bhsf.mca.sdk.security;

/**
 * Exception thrown when certificate operations fail.
 *
 * <p>This includes certificate loading failures, validation errors, expiration issues,
 * and format problems.
 *
 * <p>This is a checked exception to force callers to handle certificate-related errors explicitly.
 */
public class CertificateException extends Exception {

    /**
     * Constructs a new certificate exception with the specified detail message.
     *
     * @param message the detail message
     */
    public CertificateException(String message) {
        super(message);
    }

    /**
     * Constructs a new certificate exception with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public CertificateException(String message, Throwable cause) {
        super(message, cause);
    }
}
