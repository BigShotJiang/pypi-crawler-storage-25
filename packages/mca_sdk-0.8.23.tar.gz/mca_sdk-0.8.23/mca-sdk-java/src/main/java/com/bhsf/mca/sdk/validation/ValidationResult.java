package com.bhsf.mca.sdk.validation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Result of attribute validation.
 *
 * <p>Immutable value object holding validation results including:
 * <ul>
 *   <li>Whether validation passed</li>
 *   <li>List of missing required attributes</li>
 *   <li>List of error messages (including missing fields and invalid values)</li>
 * </ul>
 *
 * <p>Thread-safe due to immutability.
 */
public class ValidationResult {

    private final boolean valid;
    private final List<String> missingFields;
    private final List<String> errors;

    /**
     * Creates a ValidationResult.
     *
     * @param valid Whether validation passed
     * @param missingFields List of missing required field names
     * @param errors List of error messages
     * @throws IllegalArgumentException if valid=true but errors or missingFields are not empty
     */
    public ValidationResult(boolean valid, List<String> missingFields, List<String> errors) {
        // Defensive check: valid=true should have no errors
        if (valid && (!missingFields.isEmpty() || !errors.isEmpty())) {
            throw new IllegalArgumentException(
                "ValidationResult with valid=true cannot have missing fields or errors. " +
                "Got missingFields=" + missingFields + ", errors=" + errors
            );
        }
        this.valid = valid;
        this.missingFields = Collections.unmodifiableList(new ArrayList<>(missingFields));
        this.errors = Collections.unmodifiableList(new ArrayList<>(errors));
    }

    /**
     * Creates a successful validation result with no errors.
     *
     * @return ValidationResult with valid=true
     */
    public static ValidationResult success() {
        return new ValidationResult(true, Collections.emptyList(), Collections.emptyList());
    }

    /**
     * Creates a failed validation result with errors.
     *
     * @param missingFields List of missing field names
     * @param errors List of error messages
     * @return ValidationResult with valid=false
     */
    public static ValidationResult failure(List<String> missingFields, List<String> errors) {
        return new ValidationResult(false, missingFields, errors);
    }

    /**
     * Checks if validation passed.
     *
     * @return true if validation passed, false otherwise
     */
    public boolean isValid() {
        return valid;
    }

    /**
     * Gets the list of missing required fields.
     *
     * @return Unmodifiable list of missing field names
     */
    public List<String> getMissingFields() {
        return missingFields;
    }

    /**
     * Gets the list of error messages.
     *
     * @return Unmodifiable list of error messages
     */
    public List<String> getErrors() {
        return errors;
    }

    @Override
    public String toString() {
        if (valid) {
            return "ValidationResult{valid=true}";
        }
        return "ValidationResult{valid=false, errors=" + errors + ", missingFields=" + missingFields + "}";
    }
}
