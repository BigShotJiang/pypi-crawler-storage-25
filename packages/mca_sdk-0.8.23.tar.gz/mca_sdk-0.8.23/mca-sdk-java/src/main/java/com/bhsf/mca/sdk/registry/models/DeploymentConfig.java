package com.bhsf.mca.sdk.registry.models;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Deployment-specific configuration retrieved from the registry.
 *
 * <p>Contains deployment metadata and resource attribute overrides
 * for runtime-specific configuration. Used to customize OpenTelemetry
 * resource attributes based on deployment environment.
 *
 * <p>Immutable once created. Use Builder to construct instances.
 *
 * <p>Example:
 * <pre>{@code
 * DeploymentConfig config = DeploymentConfig.builder()
 *     .deploymentId("dep-prod-001")
 *     .environment("production")
 *     .region("us-east-1")
 *     .resourceOverride("deployment.zone", "az-1")
 *     .build();
 * }</pre>
 */
public class DeploymentConfig {

    private final String deploymentId;
    private final String environment;
    private final String region;
    private final Map<String, String> resourceOverrides;

    private DeploymentConfig(Builder builder) {
        if (builder.deploymentId == null || builder.deploymentId.trim().isEmpty()) {
            throw new IllegalArgumentException("deploymentId is required");
        }
        if (builder.environment == null || builder.environment.trim().isEmpty()) {
            throw new IllegalArgumentException("environment is required");
        }
        if (builder.region == null || builder.region.trim().isEmpty()) {
            throw new IllegalArgumentException("region is required");
        }

        this.deploymentId = builder.deploymentId;
        this.environment = builder.environment;
        this.region = builder.region;
        this.resourceOverrides = Collections.unmodifiableMap(new HashMap<>(builder.resourceOverrides));
    }

    public String getDeploymentId() {
        return deploymentId;
    }

    public String getEnvironment() {
        return environment;
    }

    public String getRegion() {
        return region;
    }

    public Map<String, String> getResourceOverrides() {
        return resourceOverrides;
    }

    /**
     * Create a new builder for DeploymentConfig.
     *
     * @return Builder instance
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder for DeploymentConfig with fluent API.
     */
    public static class Builder {
        private String deploymentId;
        private String environment;
        private String region;
        private Map<String, String> resourceOverrides = new HashMap<>();

        public Builder deploymentId(String deploymentId) {
            this.deploymentId = deploymentId;
            return this;
        }

        public Builder environment(String environment) {
            this.environment = environment;
            return this;
        }

        public Builder region(String region) {
            this.region = region;
            return this;
        }

        public Builder resourceOverrides(Map<String, String> resourceOverrides) {
            if (resourceOverrides != null) {
                this.resourceOverrides = new HashMap<>(resourceOverrides);
            }
            return this;
        }

        public Builder resourceOverride(String key, String value) {
            this.resourceOverrides.put(key, value);
            return this;
        }

        public DeploymentConfig build() {
            return new DeploymentConfig(this);
        }
    }
}
