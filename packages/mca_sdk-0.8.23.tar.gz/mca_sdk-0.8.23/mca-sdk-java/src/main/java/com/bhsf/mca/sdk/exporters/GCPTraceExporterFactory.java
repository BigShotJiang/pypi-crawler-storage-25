package com.bhsf.mca.sdk.exporters;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Map;

/**
 * Factory for creating GCP Cloud Trace exporter with proper optional dependency handling.
 *
 * <p>This factory exports OpenTelemetry spans to GCP Cloud Trace with full fidelity including:
 * <ul>
 *   <li>Span status mapping (OK, ERROR, UNSET)</li>
 *   <li>Span kind mapping (INTERNAL, SERVER, CLIENT, PRODUCER, CONSUMER)</li>
 *   <li>Span links (max 128 per span)</li>
 *   <li>Span events (max 128 per span)</li>
 *   <li>Resource attribute enrichment</li>
 * </ul>
 *
 * <p><strong>Thread Safety:</strong> This exporter uses a ReentrantLock to serialize export()
 * calls from multiple threads. The TraceServiceClient is thread-safe per Google Cloud
 * library guarantees.
 *
 * <p><strong>GCP Limits:</strong>
 * <ul>
 *   <li>Maximum 200 spans per batch (enforced by splitting)</li>
 *   <li>Maximum 128 links per span (extras dropped with warning)</li>
 *   <li>Maximum 128 events per span (extras dropped with warning)</li>
 *   <li>Display name truncated to 128 chars</li>
 *   <li>Attribute values truncated to 256 chars</li>
 * </ul>
 *
 * <p><strong>Implementation Pattern:</strong> This class follows the Factory + Implementation
 * pattern used by {@link com.bhsf.mca.sdk.security.SecretManager}. This factory checks
 * for optional dependency availability and only loads {@link GCPTraceExporterImpl} if the
 * google-cloud-trace library is present, preventing {@link NoClassDefFoundError} at class load time.
 *
 * <p>Example:
 * <pre>{@code
 * Object credentials = GCPAuthFactory.loadCredentials(null, null);
 * SpanExporter exporter = GCPTraceExporterFactory.create("my-project-123", credentials);
 *
 * // Use with TracerProvider
 * SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
 *     .addSpanProcessor(BatchSpanProcessor.builder(exporter).build())
 *     .build();
 * }</pre>
 */
public class GCPTraceExporterFactory implements SpanExporter {
    private static final Logger log = LoggerFactory.getLogger(GCPTraceExporterFactory.class);
    private static final boolean GCP_TRACE_AVAILABLE = checkGcpTraceAvailability();

    private final SpanExporter delegate;

    /**
     * Checks if GCP Cloud Trace library is available at runtime.
     *
     * <p>This check prevents NoClassDefFoundError by verifying the library
     * before attempting to load GCPTraceExporterImpl.
     *
     * @return true if google-cloud-trace is available, false otherwise
     */
    private static boolean checkGcpTraceAvailability() {
        try {
            Class.forName("com.google.cloud.trace.v2.TraceServiceClient");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * Create GCP Cloud Trace exporter.
     *
     * @param projectId GCP project ID (6-30 chars, lowercase, starts with letter)
     * @param credentials Google Cloud credentials (from GCPAuthFactory.loadCredentials)
     * @return GCPTraceExporterFactory instance
     * @throws ConfigurationException if google-cloud-trace library not available or initialization fails
     */
    public static GCPTraceExporterFactory create(String projectId, Object credentials) {
        return new GCPTraceExporterFactory(projectId, credentials);
    }

    /**
     * Private constructor - use create() factory method.
     *
     * @param projectId GCP project ID
     * @param credentials Google Cloud credentials (Object type to avoid direct import)
     * @throws ConfigurationException if library unavailable or initialization fails
     */
    private GCPTraceExporterFactory(String projectId, Object credentials) {
        if (!GCP_TRACE_AVAILABLE) {
            throw new ConfigurationException(
                    "google-cloud-trace is not available. " +
                    "This is an optional dependency. " +
                    "Add to your pom.xml:\n" +
                    "<dependency>\n" +
                    "  <groupId>com.google.cloud</groupId>\n" +
                    "  <artifactId>google-cloud-trace</artifactId>\n" +
                    "  <version>2.30.0</version>\n" +
                    "</dependency>"
            );
        }

        try {
            // GCPTraceExporterImpl will only be loaded if GCP_TRACE_AVAILABLE is true
            // This provides compile-time type safety with runtime optional dependency support
            this.delegate = GCPTraceExporterImpl.create(projectId, credentials);
            log.info("Initialized GCP Cloud Trace exporter for project: {}", projectId);
        } catch (ConfigurationException e) {
            // Re-throw ConfigurationException as-is
            throw e;
        } catch (Exception e) {
            throw new ConfigurationException(
                    "Failed to initialize GCP Cloud Trace exporter: " + e.getMessage(), e);
        }
    }

    @Override
    public CompletableResultCode export(Collection<SpanData> spans) {
        return delegate.export(spans);
    }

    @Override
    public CompletableResultCode flush() {
        return delegate.flush();
    }

    @Override
    public CompletableResultCode shutdown() {
        return delegate.shutdown();
    }

    /**
     * Get internal metrics for observability.
     *
     * @return Map of metric names to values
     */
    public Map<String, Long> getMetrics() {
        if (delegate instanceof GCPTraceExporterImpl) {
            return ((GCPTraceExporterImpl) delegate).getMetrics();
        }
        throw new IllegalStateException("Delegate is not a GCPTraceExporterImpl instance");
    }

    /**
     * Check if GCP Cloud Trace library is available.
     *
     * @return true if library is available, false otherwise
     */
    public static boolean isAvailable() {
        return GCP_TRACE_AVAILABLE;
    }
}
