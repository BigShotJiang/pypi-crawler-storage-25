package com.bhsf.mca.sdk.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration object for MCAClient.
 *
 * <p>Holds all configuration parameters needed to initialize the SDK.
 * Supports multi-source configuration loading with precedence:
 * builder > registry > environment > file > defaults
 *
 * <p>Immutable once created. Use Builder to construct instances.
 */
public class MCAConfig {
    // Core fields (required)
    private final String serviceName;

    // Model identification (optional)
    private final String modelId;
    private final String teamName;
    private final String modelVersion;
    private final String modelType;
    private final String modelCategory;

    // OpenTelemetry configuration
    private final String otelEndpoint;

    // Registry configuration
    private final String registryUrl;
    private final String registryToken;
    private final boolean useGcpAuth;
    private final int cacheTtlSecs;
    private final int refreshIntervalSecs;

    // GCP Exporter configuration
    private final String gcpProjectId;
    private final boolean gcpTraceEnabled;
    private final boolean gcpLoggingEnabled;
    private final String gcpLogName;
    private final String gcpCredentialsPath;
    private final String gcpCredentialsJson;

    // Prometheus configuration
    private final boolean prometheusEnabled;
    private final int prometheusPort;
    private final String prometheusHost;

    // Thresholds for alerting
    private final Map<String, Double> thresholds;

    // Behavioral flags
    private final boolean strictValidation;
    private final boolean gracefulFallback;

    // Internal tracking
    private final Map<String, ConfigSource> sources;

    private MCAConfig(Builder builder) {
        this.serviceName = builder.serviceName;
        this.modelId = builder.modelId;
        this.teamName = builder.teamName;
        this.modelVersion = builder.modelVersion;
        this.modelType = builder.modelType;
        this.modelCategory = builder.modelCategory;
        this.otelEndpoint = builder.otelEndpoint;
        this.registryUrl = builder.registryUrl;
        this.registryToken = builder.registryToken;
        this.useGcpAuth = builder.useGcpAuth;
        this.cacheTtlSecs = builder.cacheTtlSecs;
        this.refreshIntervalSecs = builder.refreshIntervalSecs;
        this.gcpProjectId = builder.gcpProjectId;
        this.gcpTraceEnabled = builder.gcpTraceEnabled;
        this.gcpLoggingEnabled = builder.gcpLoggingEnabled;
        this.gcpLogName = builder.gcpLogName;
        this.gcpCredentialsPath = builder.gcpCredentialsPath;
        this.gcpCredentialsJson = builder.gcpCredentialsJson;
        this.prometheusEnabled = builder.prometheusEnabled;
        this.prometheusPort = builder.prometheusPort;
        this.prometheusHost = builder.prometheusHost;
        this.thresholds = Collections.unmodifiableMap(new HashMap<>(builder.thresholds));
        this.strictValidation = builder.strictValidation;
        this.gracefulFallback = builder.gracefulFallback;
        this.sources = Collections.unmodifiableMap(new HashMap<>(builder.sources));
    }

    // Getters

    public String getServiceName() {
        return serviceName;
    }

    public String getModelId() {
        return modelId;
    }

    public String getTeamName() {
        return teamName;
    }

    public String getModelVersion() {
        return modelVersion;
    }

    public String getModelType() {
        return modelType;
    }

    public String getModelCategory() {
        return modelCategory;
    }

    public String getOtelEndpoint() {
        return otelEndpoint;
    }

    public String getRegistryUrl() {
        return registryUrl;
    }

    public String getRegistryToken() {
        return registryToken;
    }

    public boolean isUseGcpAuth() {
        return useGcpAuth;
    }

    public int getCacheTtlSecs() {
        return cacheTtlSecs;
    }

    public int getRefreshIntervalSecs() {
        return refreshIntervalSecs;
    }

    public String getGcpProjectId() {
        return gcpProjectId;
    }

    public boolean isGcpTraceEnabled() {
        return gcpTraceEnabled;
    }

    public boolean isGcpLoggingEnabled() {
        return gcpLoggingEnabled;
    }

    public String getGcpLogName() {
        return gcpLogName;
    }

    public String getGcpCredentialsPath() {
        return gcpCredentialsPath;
    }

    public String getGcpCredentialsJson() {
        return gcpCredentialsJson;
    }

    public boolean isPrometheusEnabled() {
        return prometheusEnabled;
    }

    public int getPrometheusPort() {
        return prometheusPort;
    }

    public String getPrometheusHost() {
        return prometheusHost;
    }

    public Map<String, Double> getThresholds() {
        return thresholds;
    }

    public boolean isStrictValidation() {
        return strictValidation;
    }

    public boolean isGracefulFallback() {
        return gracefulFallback;
    }

    public Map<String, ConfigSource> getSources() {
        return sources;
    }

    public ConfigSource getSource(String key) {
        return sources.getOrDefault(key, ConfigSource.DEFAULT);
    }

    /**
     * Builder for MCAConfig with fluent API.
     */
    public static class Builder {
        // Core fields
        private String serviceName;

        // Model identification
        private String modelId;
        private String teamName;
        private String modelVersion = "1.0.0";
        private String modelType;
        private String modelCategory;

        // OpenTelemetry configuration
        private String otelEndpoint = "http://localhost:4318";

        // Registry configuration
        private String registryUrl;
        private String registryToken;
        private boolean useGcpAuth = false;
        private int cacheTtlSecs = 600;  // 10 minutes
        private int refreshIntervalSecs = 600;  // 10 minutes

        // GCP Exporter configuration
        private String gcpProjectId;
        private boolean gcpTraceEnabled = false;
        private boolean gcpLoggingEnabled = false;
        private String gcpLogName = "mca-sdk";
        private String gcpCredentialsPath;
        private String gcpCredentialsJson;

        // Prometheus configuration
        private boolean prometheusEnabled = false;
        private int prometheusPort = 9464;
        private String prometheusHost = "127.0.0.1";

        // Thresholds
        private Map<String, Double> thresholds = new HashMap<>();

        // Behavioral flags
        private boolean strictValidation = false;
        private boolean gracefulFallback = true;

        // Internal tracking
        private Map<String, ConfigSource> sources = new HashMap<>();

        public Builder() {
            // Track defaults
            sources.put("modelVersion", ConfigSource.DEFAULT);
            sources.put("otelEndpoint", ConfigSource.DEFAULT);
            sources.put("useGcpAuth", ConfigSource.DEFAULT);
            sources.put("cacheTtlSecs", ConfigSource.DEFAULT);
            sources.put("refreshIntervalSecs", ConfigSource.DEFAULT);
            sources.put("gcpTraceEnabled", ConfigSource.DEFAULT);
            sources.put("gcpLoggingEnabled", ConfigSource.DEFAULT);
            sources.put("gcpLogName", ConfigSource.DEFAULT);
            sources.put("prometheusEnabled", ConfigSource.DEFAULT);
            sources.put("prometheusPort", ConfigSource.DEFAULT);
            sources.put("prometheusHost", ConfigSource.DEFAULT);
            sources.put("strictValidation", ConfigSource.DEFAULT);
            sources.put("gracefulFallback", ConfigSource.DEFAULT);
        }

        public Builder(MCAConfig config) {
            this.serviceName = config.serviceName;
            this.modelId = config.modelId;
            this.teamName = config.teamName;
            this.modelVersion = config.modelVersion;
            this.modelType = config.modelType;
            this.modelCategory = config.modelCategory;
            this.otelEndpoint = config.otelEndpoint;
            this.registryUrl = config.registryUrl;
            this.registryToken = config.registryToken;
            this.useGcpAuth = config.useGcpAuth;
            this.cacheTtlSecs = config.cacheTtlSecs;
            this.refreshIntervalSecs = config.refreshIntervalSecs;
            this.gcpProjectId = config.gcpProjectId;
            this.gcpTraceEnabled = config.gcpTraceEnabled;
            this.gcpLoggingEnabled = config.gcpLoggingEnabled;
            this.gcpLogName = config.gcpLogName;
            this.gcpCredentialsPath = config.gcpCredentialsPath;
            this.gcpCredentialsJson = config.gcpCredentialsJson;
            this.prometheusEnabled = config.prometheusEnabled;
            this.prometheusPort = config.prometheusPort;
            this.prometheusHost = config.prometheusHost;
            this.thresholds = new HashMap<>(config.thresholds);
            this.strictValidation = config.strictValidation;
            this.gracefulFallback = config.gracefulFallback;
            this.sources = new HashMap<>(config.sources);
        }

        public Builder serviceName(String serviceName) {
            return serviceName(serviceName, ConfigSource.BUILDER);
        }

        public Builder serviceName(String serviceName, ConfigSource source) {
            this.serviceName = serviceName;
            this.sources.put("serviceName", source);
            return this;
        }

        public Builder modelId(String modelId) {
            return modelId(modelId, ConfigSource.BUILDER);
        }

        public Builder modelId(String modelId, ConfigSource source) {
            this.modelId = modelId;
            this.sources.put("modelId", source);
            return this;
        }

        public Builder teamName(String teamName) {
            return teamName(teamName, ConfigSource.BUILDER);
        }

        public Builder teamName(String teamName, ConfigSource source) {
            this.teamName = teamName;
            this.sources.put("teamName", source);
            return this;
        }

        public Builder modelVersion(String modelVersion) {
            return modelVersion(modelVersion, ConfigSource.BUILDER);
        }

        public Builder modelVersion(String modelVersion, ConfigSource source) {
            this.modelVersion = modelVersion;
            this.sources.put("modelVersion", source);
            return this;
        }

        public Builder modelType(String modelType) {
            return modelType(modelType, ConfigSource.BUILDER);
        }

        public Builder modelType(String modelType, ConfigSource source) {
            this.modelType = modelType;
            this.sources.put("modelType", source);
            return this;
        }

        public Builder modelCategory(String modelCategory) {
            return modelCategory(modelCategory, ConfigSource.BUILDER);
        }

        public Builder modelCategory(String modelCategory, ConfigSource source) {
            this.modelCategory = modelCategory;
            this.sources.put("modelCategory", source);
            return this;
        }

        public Builder otelEndpoint(String otelEndpoint) {
            return otelEndpoint(otelEndpoint, ConfigSource.BUILDER);
        }

        public Builder otelEndpoint(String otelEndpoint, ConfigSource source) {
            this.otelEndpoint = otelEndpoint;
            this.sources.put("otelEndpoint", source);
            return this;
        }

        public Builder registryUrl(String registryUrl) {
            return registryUrl(registryUrl, ConfigSource.BUILDER);
        }

        public Builder registryUrl(String registryUrl, ConfigSource source) {
            this.registryUrl = registryUrl;
            this.sources.put("registryUrl", source);
            return this;
        }

        public Builder registryToken(String registryToken) {
            return registryToken(registryToken, ConfigSource.BUILDER);
        }

        public Builder registryToken(String registryToken, ConfigSource source) {
            this.registryToken = registryToken;
            this.sources.put("registryToken", source);
            return this;
        }

        public Builder useGcpAuth(boolean useGcpAuth) {
            return useGcpAuth(useGcpAuth, ConfigSource.BUILDER);
        }

        public Builder useGcpAuth(boolean useGcpAuth, ConfigSource source) {
            this.useGcpAuth = useGcpAuth;
            this.sources.put("useGcpAuth", source);
            return this;
        }

        public Builder cacheTtlSecs(int cacheTtlSecs) {
            return cacheTtlSecs(cacheTtlSecs, ConfigSource.BUILDER);
        }

        public Builder cacheTtlSecs(int cacheTtlSecs, ConfigSource source) {
            this.cacheTtlSecs = cacheTtlSecs;
            this.sources.put("cacheTtlSecs", source);
            return this;
        }

        public Builder refreshIntervalSecs(int refreshIntervalSecs) {
            return refreshIntervalSecs(refreshIntervalSecs, ConfigSource.BUILDER);
        }

        public Builder refreshIntervalSecs(int refreshIntervalSecs, ConfigSource source) {
            this.refreshIntervalSecs = refreshIntervalSecs;
            this.sources.put("refreshIntervalSecs", source);
            return this;
        }

        public Builder gcpProjectId(String gcpProjectId) {
            return gcpProjectId(gcpProjectId, ConfigSource.BUILDER);
        }

        public Builder gcpProjectId(String gcpProjectId, ConfigSource source) {
            this.gcpProjectId = gcpProjectId;
            this.sources.put("gcpProjectId", source);
            return this;
        }

        public Builder gcpTraceEnabled(boolean gcpTraceEnabled) {
            return gcpTraceEnabled(gcpTraceEnabled, ConfigSource.BUILDER);
        }

        public Builder gcpTraceEnabled(boolean gcpTraceEnabled, ConfigSource source) {
            this.gcpTraceEnabled = gcpTraceEnabled;
            this.sources.put("gcpTraceEnabled", source);
            return this;
        }

        public Builder gcpLoggingEnabled(boolean gcpLoggingEnabled) {
            return gcpLoggingEnabled(gcpLoggingEnabled, ConfigSource.BUILDER);
        }

        public Builder gcpLoggingEnabled(boolean gcpLoggingEnabled, ConfigSource source) {
            this.gcpLoggingEnabled = gcpLoggingEnabled;
            this.sources.put("gcpLoggingEnabled", source);
            return this;
        }

        public Builder gcpLogName(String gcpLogName) {
            return gcpLogName(gcpLogName, ConfigSource.BUILDER);
        }

        public Builder gcpLogName(String gcpLogName, ConfigSource source) {
            this.gcpLogName = gcpLogName;
            this.sources.put("gcpLogName", source);
            return this;
        }

        public Builder gcpCredentialsPath(String gcpCredentialsPath) {
            return gcpCredentialsPath(gcpCredentialsPath, ConfigSource.BUILDER);
        }

        public Builder gcpCredentialsPath(String gcpCredentialsPath, ConfigSource source) {
            this.gcpCredentialsPath = gcpCredentialsPath;
            this.sources.put("gcpCredentialsPath", source);
            return this;
        }

        public Builder gcpCredentialsJson(String gcpCredentialsJson) {
            return gcpCredentialsJson(gcpCredentialsJson, ConfigSource.BUILDER);
        }

        public Builder gcpCredentialsJson(String gcpCredentialsJson, ConfigSource source) {
            this.gcpCredentialsJson = gcpCredentialsJson;
            this.sources.put("gcpCredentialsJson", source);
            return this;
        }

        public Builder prometheusEnabled(boolean prometheusEnabled) {
            return prometheusEnabled(prometheusEnabled, ConfigSource.BUILDER);
        }

        public Builder prometheusEnabled(boolean prometheusEnabled, ConfigSource source) {
            this.prometheusEnabled = prometheusEnabled;
            this.sources.put("prometheusEnabled", source);
            return this;
        }

        public Builder prometheusPort(int prometheusPort) {
            return prometheusPort(prometheusPort, ConfigSource.BUILDER);
        }

        public Builder prometheusPort(int prometheusPort, ConfigSource source) {
            this.prometheusPort = prometheusPort;
            this.sources.put("prometheusPort", source);
            return this;
        }

        public Builder prometheusHost(String prometheusHost) {
            return prometheusHost(prometheusHost, ConfigSource.BUILDER);
        }

        public Builder prometheusHost(String prometheusHost, ConfigSource source) {
            this.prometheusHost = prometheusHost;
            this.sources.put("prometheusHost", source);
            return this;
        }

        public Builder thresholds(Map<String, Double> thresholds) {
            return thresholds(thresholds, ConfigSource.BUILDER);
        }

        public Builder thresholds(Map<String, Double> thresholds, ConfigSource source) {
            if (thresholds != null) {
                this.thresholds = new HashMap<>(thresholds);
                this.sources.put("thresholds", source);
            }
            return this;
        }

        public Builder threshold(String key, Double value) {
            this.thresholds.put(key, value);
            this.sources.put("thresholds", ConfigSource.BUILDER);
            return this;
        }

        public Builder strictValidation(boolean strictValidation) {
            return strictValidation(strictValidation, ConfigSource.BUILDER);
        }

        public Builder strictValidation(boolean strictValidation, ConfigSource source) {
            this.strictValidation = strictValidation;
            this.sources.put("strictValidation", source);
            return this;
        }

        public Builder gracefulFallback(boolean gracefulFallback) {
            return gracefulFallback(gracefulFallback, ConfigSource.BUILDER);
        }

        public Builder gracefulFallback(boolean gracefulFallback, ConfigSource source) {
            this.gracefulFallback = gracefulFallback;
            this.sources.put("gracefulFallback", source);
            return this;
        }

        public MCAConfig build() {
            return new MCAConfig(this);
        }
    }
}