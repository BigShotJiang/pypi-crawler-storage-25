package com.bhsf.mca.sdk;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Request object for recording prediction telemetry.
 * Uses Builder pattern for flexible configuration.
 */
public class RecordPredictionRequest {
    private final double latency;
    private final String predictionId;
    private final Map<String, Object> attributes;

    private RecordPredictionRequest(Builder builder) {
        this.latency = builder.latency;
        this.predictionId = builder.predictionId != null ? builder.predictionId : generatePredictionId();
        this.attributes = new HashMap<>(builder.attributes);
    }

    public double getLatency() {
        return latency;
    }

    public String getPredictionId() {
        return predictionId;
    }

    public Map<String, Object> getAttributes() {
        return new HashMap<>(attributes);
    }

    private static String generatePredictionId() {
        return "pred-" + UUID.randomUUID().toString();
    }

    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder for RecordPredictionRequest with fluent API.
     */
    public static class Builder {
        private Double latency; // Use Double object to track if it was set
        private boolean latencySet = false;
        private String predictionId;
        private Map<String, Object> attributes = new HashMap<>();

        /**
         * Set prediction latency in seconds.
         *
         * @param latency Prediction latency (must be non-negative)
         * @return Builder for chaining
         */
        public Builder latency(double latency) {
            if (latency < 0) {
                throw new IllegalArgumentException("Latency must be non-negative, got: " + latency);
            }
            this.latency = latency;
            this.latencySet = true;
            return this;
        }

        /**
         * Set unique prediction identifier.
         *
         * @param predictionId Prediction ID (if null, one will be generated)
         * @return Builder for chaining
         */
        public Builder predictionId(String predictionId) {
            this.predictionId = predictionId;
            return this;
        }

        /**
         * Add a custom attribute to the prediction record.
         *
         * @param key Attribute key
         * @param value Attribute value
         * @return Builder for chaining
         */
        public Builder attribute(String key, Object value) {
            if (key == null || key.trim().isEmpty()) {
                throw new IllegalArgumentException("Attribute key cannot be null or empty");
            }
            this.attributes.put(key, value);
            return this;
        }

        /**
         * Add multiple custom attributes to the prediction record.
         *
         * @param attributes Map of attributes to add
         * @return Builder for chaining
         */
        public Builder attributes(Map<String, Object> attributes) {
            if (attributes != null) {
                this.attributes.putAll(attributes);
            }
            return this;
        }

        /**
         * Build the RecordPredictionRequest.
         *
         * @return Immutable RecordPredictionRequest instance
         * @throws IllegalArgumentException if required fields are not set
         */
        public RecordPredictionRequest build() {
            if (!latencySet || latency == null) {
                throw new IllegalArgumentException(
                        "Latency is required. Call .latency(value) before building."
                );
            }
            return new RecordPredictionRequest(this);
        }
    }
}
