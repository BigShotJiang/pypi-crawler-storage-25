package com.bhsf.mca.sdk.registry;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;
import java.util.concurrent.Callable;

/**
 * Retry policy with exponential backoff and jitter for registry operations.
 *
 * <p>Provides configurable retry logic for handling transient failures
 * when communicating with the registry service. Features:
 * <ul>
 *   <li>Exponential backoff - Delay increases with each retry attempt</li>
 *   <li>Jitter - Random delay variation to prevent thundering herd</li>
 *   <li>Maximum attempt limits - Prevents infinite retry loops</li>
 *   <li>Delay capping - Limits maximum delay between retries</li>
 * </ul>
 *
 * <p>Thread-safe for concurrent use. Can be shared across multiple threads.
 *
 * <p>Example:
 * <pre>{@code
 * RetryPolicy policy = new RetryPolicy(3, 1.0, 10.0);
 * ModelConfig config = policy.executeWithRetry(() ->
 *     performHttpRequest("https://registry/models/mdl-001")
 * );
 * }</pre>
 */
public class RetryPolicy {

    private static final Logger logger = LoggerFactory.getLogger(RetryPolicy.class);

    private final int maxRetries;
    private final double baseDelay;
    private final double maxDelay;
    private final Random random;

    /**
     * Create a retry policy with specified parameters.
     *
     * @param maxRetries Maximum number of retry attempts (must be >= 0)
     * @param baseDelay  Base delay in seconds for first retry (must be > 0)
     * @param maxDelay   Maximum delay in seconds for any retry (must be >= baseDelay)
     * @throws ConfigurationException if parameters are invalid
     */
    public RetryPolicy(int maxRetries, double baseDelay, double maxDelay) {
        if (maxRetries < 0) {
            throw new ConfigurationException("maxRetries must be >= 0, got " + maxRetries);
        }
        if (baseDelay <= 0) {
            throw new ConfigurationException("baseDelay must be > 0, got " + baseDelay);
        }
        if (maxDelay < baseDelay) {
            throw new ConfigurationException(
                    "maxDelay (" + maxDelay + ") must be >= baseDelay (" + baseDelay + ")"
            );
        }

        this.maxRetries = maxRetries;
        this.baseDelay = baseDelay;
        this.maxDelay = maxDelay;
        this.random = new Random();
    }

    /**
     * Execute an operation with retry logic.
     *
     * <p>Attempts to execute the provided operation up to (maxRetries + 1) times.
     * If the operation fails, waits with exponential backoff before retrying.
     * Final exception is propagated to caller after all retries are exhausted.
     *
     * @param operation Operation to execute (may throw exceptions)
     * @param <T>       Return type of the operation
     * @return Result of successful operation
     * @throws Exception If operation fails after all retry attempts
     */
    public <T> T executeWithRetry(Callable<T> operation) throws Exception {
        Exception lastException = null;

        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                // Execute operation
                T result = operation.call();
                if (attempt > 0) {
                    logger.info("Operation succeeded after {} retry attempt(s)", attempt);
                }
                return result;

            } catch (Exception e) {
                lastException = e;

                if (attempt < maxRetries) {
                    // Calculate delay with exponential backoff
                    double delay = calculateDelay(attempt);

                    logger.warn(
                            "Operation failed (attempt {}/{}), retrying in {:.2f}s: {}",
                            attempt + 1,
                            maxRetries + 1,
                            delay,
                            e.getMessage()
                    );

                    // Sleep before retry
                    Thread.sleep((long) (delay * 1000));
                } else {
                    logger.error(
                            "Operation failed after {} attempt(s), no more retries",
                            maxRetries + 1
                    );
                }
            }
        }

        // All attempts exhausted, throw last exception
        throw lastException;
    }

    /**
     * Calculate delay for given attempt with exponential backoff and jitter.
     *
     * <p>Formula:
     * <pre>
     * delay = min(baseDelay * 2^attempt, maxDelay)
     * jittered_delay = delay * (0.5 + random[0, 0.5])
     * </pre>
     *
     * <p>Jitter prevents thundering herd by randomizing delays when many
     * clients retry simultaneously.
     *
     * @param attempt Current attempt number (0-indexed)
     * @return Delay in seconds for this attempt
     */
    public double calculateDelay(int attempt) {
        // Exponential backoff: baseDelay * 2^attempt
        double delay = baseDelay * Math.pow(2, attempt);

        // Cap at max delay
        delay = Math.min(delay, maxDelay);

        // Add jitter: randomize between 50% and 100% of delay
        // This prevents thundering herd when many clients retry simultaneously
        double jitter = 0.5 + (random.nextDouble() * 0.5);
        delay = delay * jitter;

        return delay;
    }

    /**
     * Get maximum number of retry attempts.
     *
     * @return Maximum retries (not including initial attempt)
     */
    public int getMaxRetries() {
        return maxRetries;
    }

    /**
     * Get base delay in seconds.
     *
     * @return Base delay for first retry
     */
    public double getBaseDelay() {
        return baseDelay;
    }

    /**
     * Get maximum delay in seconds.
     *
     * @return Maximum delay for any retry
     */
    public double getMaxDelay() {
        return maxDelay;
    }
}
