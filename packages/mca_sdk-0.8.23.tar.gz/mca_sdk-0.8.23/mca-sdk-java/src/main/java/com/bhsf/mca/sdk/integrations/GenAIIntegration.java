package com.bhsf.mca.sdk.integrations;

import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.common.AttributesBuilder;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * GenAI Integration for tracking token usage, costs, and LLM requests.
 *
 * <p>Provides methods for recording:
 * <ul>
 *   <li>Token usage (prompt, completion, total)</li>
 *   <li>Cost estimation in USD</li>
 *   <li>Request counts and failures</li>
 * </ul>
 *
 * <p>Pre-creates all OpenTelemetry instruments during initialization for optimal performance
 * (avoids repeated instrument creation overhead).
 *
 * <p>Thread-safe for concurrent use.
 *
 * @see com.bhsf.mca.sdk.MCAClient
 */
public class GenAIIntegration {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(GenAIIntegration.class);

    // Pre-created instruments for performance (following Python _instruments_cache pattern)
    private final LongCounter tokensCounter;
    private final DoubleHistogram costHistogram;
    private final LongCounter requestsCounter;
    private final LongCounter failedRequestsCounter;

    // Shutdown state management
    private final AtomicBoolean isShutdown = new AtomicBoolean(false);

    /**
     * Create a new GenAIIntegration instance.
     *
     * @param meter OpenTelemetry Meter for creating metrics
     */
    public GenAIIntegration(Meter meter) {
        if (meter == null) {
            throw new IllegalArgumentException("Meter cannot be null");
        }

        // Pre-create all instruments once for performance
        this.tokensCounter = meter.counterBuilder("genai.tokens_total")
                .setDescription("Total tokens consumed. Use token_type attribute to differentiate prompt/completion.")
                .setUnit("1")
                .build();

        this.costHistogram = meter.histogramBuilder("genai.cost_dollars")
                .setDescription("Estimated cost of GenAI requests")
                .setUnit("usd")
                .build();

        this.requestsCounter = meter.counterBuilder("genai.requests_total")
                .setDescription("Total number of GenAI requests")
                .setUnit("1")
                .build();

        this.failedRequestsCounter = meter.counterBuilder("genai.requests_failed_total")
                .setDescription("Total number of failed GenAI requests")
                .setUnit("1")
                .build();

        log.debug("GenAIIntegration initialized with pre-cached instruments");
    }

    /**
     * Record token usage for an LLM request.
     *
     * <p>Uses long arithmetic to handle large token counts (e.g., multi-million token contexts)
     * without integer overflow.
     *
     * <p>Records three token metrics:
     * <ul>
     *   <li>Total tokens (prompt + completion)</li>
     *   <li>Prompt tokens</li>
     *   <li>Completion tokens</li>
     * </ul>
     *
     * @param promptTokens Number of tokens in the prompt
     * @param completionTokens Number of tokens in the completion
     * @param attributes Additional attributes (e.g., model, provider)
     * @throws IllegalArgumentException if token counts are negative or overflow occurs
     * @throws IllegalStateException if integration has been shut down
     */
    public void recordTokenUsage(long promptTokens, long completionTokens, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            log.warn("Attempted to record token usage after shutdown");
            return;
        }

        if (promptTokens < 0) {
            throw new IllegalArgumentException("promptTokens cannot be negative: " + promptTokens);
        }
        if (completionTokens < 0) {
            throw new IllegalArgumentException("completionTokens cannot be negative: " + completionTokens);
        }

        // Use long arithmetic to prevent overflow
        long totalTokens = promptTokens + completionTokens;

        // Validate total didn't overflow (if both positive, total must be >= either)
        if (totalTokens < promptTokens || totalTokens < completionTokens) {
            throw new IllegalArgumentException(
                "Token sum overflow: prompt=" + promptTokens + ", completion=" + completionTokens);
        }

        // Build base attributes using shared utility (defensive copy + extended types)
        Attributes baseAttrs = TelemetryAttributeUtil.buildAttributes(attributes);

        // Record total tokens
        Attributes totalAttrs = Attributes.builder()
                .putAll(baseAttrs)
                .put("token_type", "total")
                .build();
        tokensCounter.add(totalTokens, totalAttrs);

        // Record prompt tokens
        Attributes promptAttrs = Attributes.builder()
                .putAll(baseAttrs)
                .put("token_type", "prompt")
                .build();
        tokensCounter.add(promptTokens, promptAttrs);

        // Record completion tokens
        Attributes completionAttrs = Attributes.builder()
                .putAll(baseAttrs)
                .put("token_type", "completion")
                .build();
        tokensCounter.add(completionTokens, completionAttrs);

        log.debug("Recorded token usage: prompt={}, completion={}, total={}",
                promptTokens, completionTokens, totalTokens);
    }

    /**
     * Record the estimated cost of a GenAI request.
     *
     * @param costUsd Cost in US dollars
     * @param attributes Additional attributes (e.g., model, provider)
     * @throws IllegalArgumentException if cost is negative
     * @throws IllegalStateException if integration has been shut down
     */
    public void recordCost(double costUsd, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            log.warn("Attempted to record cost after shutdown");
            return;
        }

        if (costUsd < 0) {
            throw new IllegalArgumentException("costUsd cannot be negative: " + costUsd);
        }

        Attributes attrs = TelemetryAttributeUtil.buildAttributes(attributes);
        costHistogram.record(costUsd, attrs);

        log.debug("Recorded cost: ${} USD", costUsd);
    }

    /**
     * Record a GenAI request (success or failure).
     *
     * <p>IMPORTANT: Both successful and failed requests increment the total request counter.
     * Failed requests additionally increment the failed request counter. This ensures:
     * <ul>
     *   <li>requests_total = successful + failed requests</li>
     *   <li>Error rate = failed / total</li>
     * </ul>
     *
     * @param model Model name (e.g., "gpt-4")
     * @param provider Provider name (e.g., "openai")
     * @param status Request status: "success" or "error"
     * @param attributes Additional attributes
     * @throws IllegalArgumentException if status is not "success" or "error"
     * @throws IllegalStateException if integration has been shut down
     */
    public void recordRequest(String model, String provider, String status, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            log.warn("Attempted to record request after shutdown");
            return;
        }

        if (status == null || (!status.equals("success") && !status.equals("error"))) {
            throw new IllegalArgumentException("status must be 'success' or 'error': " + status);
        }

        AttributesBuilder builder = Attributes.builder();

        if (model != null) {
            builder.put("model", model);
        }
        if (provider != null) {
            builder.put("provider", provider);
        }
        builder.put("status", status);

        // Add custom attributes using shared utility (defensive copy + extended types)
        Map<String, Object> safeAttrs = TelemetryAttributeUtil.defensiveCopy(attributes);
        if (safeAttrs != null) {
            for (Map.Entry<String, Object> entry : safeAttrs.entrySet()) {
                TelemetryAttributeUtil.addAttribute(builder, entry.getKey(), entry.getValue());
            }
        }

        Attributes attrs = builder.build();

        // ALWAYS increment total counter (for both success and error)
        requestsCounter.add(1, attrs);

        // Increment failure counter only for errors
        if (status.equals("error")) {
            failedRequestsCounter.add(1, attrs);
            log.debug("Recorded failed request: model={}, provider={}", model, provider);
        } else {
            log.debug("Recorded successful request: model={}, provider={}", model, provider);
        }
    }

    /**
     * Shutdown the GenAIIntegration and prevent further telemetry recording.
     *
     * <p>This method is idempotent - calling it multiple times is safe.
     * After shutdown, all record* methods will log a warning and return immediately.
     */
    public void shutdown() {
        if (isShutdown.compareAndSet(false, true)) {
            log.info("GenAIIntegration shut down");
        }
    }
}
