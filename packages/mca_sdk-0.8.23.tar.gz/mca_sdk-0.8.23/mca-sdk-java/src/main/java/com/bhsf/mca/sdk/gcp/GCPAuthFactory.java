package com.bhsf.mca.sdk.gcp;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;

/**
 * Factory for creating GCP authentication credentials with proper optional dependency handling.
 *
 * <p>This factory provides Application Default Credentials (ADC) and service account key support
 * following a priority order:
 * <ol>
 *   <li>Credentials from file path (credentialsPath parameter)</li>
 *   <li>Credentials from JSON string (credentialsJson parameter)</li>
 *   <li>Application Default Credentials (ADC) fallback</li>
 * </ol>
 *
 * <p>Gracefully handles missing optional dependencies with clear error messages.
 * Thread-safe for concurrent credential loading.
 *
 * <p><strong>Security Note:</strong> Never log credentials or private keys.
 * HIPAA compliance requires secure credential handling.
 *
 * <p><strong>Implementation Pattern:</strong> This class follows the Factory + Implementation
 * pattern used by {@link com.bhsf.mca.sdk.security.SecretManager}. This factory checks
 * for optional dependency availability and only loads {@link GCPAuthImpl} if the GCP
 * auth library is present, preventing {@link NoClassDefFoundError} at class load time.
 *
 * <p>Example:
 * <pre>{@code
 * // Load from file
 * Object creds = GCPAuthFactory.loadCredentials("/path/to/service-account.json", null);
 *
 * // Load from JSON string
 * String json = System.getenv("GCP_CREDENTIALS_JSON");
 * Object creds = GCPAuthFactory.loadCredentials(null, json);
 *
 * // Load from ADC (fallback)
 * Object creds = GCPAuthFactory.loadCredentials(null, null);
 * }</pre>
 */
public class GCPAuthFactory {
    private static final Logger log = LoggerFactory.getLogger(GCPAuthFactory.class);
    private static final boolean GCP_AUTH_AVAILABLE = checkGcpAuthAvailability();

    /**
     * Default OAuth scopes for MCA SDK GCP operations.
     * Includes monitoring, logging, and trace write permissions.
     *
     * <p>This list is immutable to prevent external modification.
     */
    public static final List<String> DEFAULT_SCOPES = Collections.unmodifiableList(
            List.of(
                    "https://www.googleapis.com/auth/monitoring.write",
                    "https://www.googleapis.com/auth/logging.write",
                    "https://www.googleapis.com/auth/trace.append"
            )
    );

    /**
     * Checks if GCP auth library is available at runtime.
     *
     * <p>This check prevents NoClassDefFoundError by verifying the library
     * before attempting to load GCPAuthImpl.
     *
     * @return true if google-auth-library-oauth2-http is available, false otherwise
     */
    private static boolean checkGcpAuthAvailability() {
        try {
            Class.forName("com.google.auth.oauth2.GoogleCredentials");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * Load Google Cloud credentials with default scopes.
     *
     * <p>Priority order:
     * <ol>
     *   <li>credentialsPath (if provided)</li>
     *   <li>credentialsJson (if provided)</li>
     *   <li>Application Default Credentials (ADC)</li>
     * </ol>
     *
     * @param credentialsPath Path to service account JSON file (optional)
     * @param credentialsJson Service account JSON as string (optional)
     * @return GoogleCredentials instance with default scopes (type Object to avoid direct import)
     * @throws ConfigurationException if credentials cannot be loaded or library is unavailable
     */
    public static Object loadCredentials(String credentialsPath, String credentialsJson) {
        return loadCredentials(credentialsPath, credentialsJson, DEFAULT_SCOPES);
    }

    /**
     * Load Google Cloud credentials with custom scopes.
     *
     * <p>Priority order:
     * <ol>
     *   <li>credentialsPath (if provided)</li>
     *   <li>credentialsJson (if provided)</li>
     *   <li>Application Default Credentials (ADC)</li>
     * </ol>
     *
     * @param credentialsPath Path to service account JSON file (optional)
     * @param credentialsJson Service account JSON as string (optional)
     * @param scopes OAuth2 scopes to request
     * @return GoogleCredentials instance with requested scopes (type Object to avoid direct import)
     * @throws ConfigurationException if credentials cannot be loaded or library is unavailable
     */
    public static Object loadCredentials(String credentialsPath, String credentialsJson, List<String> scopes) {
        if (!GCP_AUTH_AVAILABLE) {
            throw new ConfigurationException(
                    "google-auth-library-oauth2-http is not available. " +
                    "This is an optional dependency. " +
                    "Add to your pom.xml:\n" +
                    "<dependency>\n" +
                    "  <groupId>com.google.auth</groupId>\n" +
                    "  <artifactId>google-auth-library-oauth2-http</artifactId>\n" +
                    "  <version>1.11.0</version>\n" +
                    "</dependency>"
            );
        }

        try {
            // GCPAuthImpl will only be loaded if GCP_AUTH_AVAILABLE is true
            // This provides compile-time type safety with runtime optional dependency support
            return GCPAuthImpl.loadCredentials(credentialsPath, credentialsJson, scopes);
        } catch (ConfigurationException e) {
            // Re-throw ConfigurationException as-is
            throw e;
        } catch (Exception e) {
            // Wrap unexpected exceptions
            throw new ConfigurationException("Failed to load GCP credentials: " + e.getMessage(), e);
        }
    }

    /**
     * Validate that credentials have required scopes for GCP operations.
     *
     * <p>Note: This is a best-effort check. Some credential types (e.g., user credentials)
     * may not expose their scopes programmatically. When in doubt, attempt the operation
     * and handle 403 Forbidden errors appropriately.
     *
     * @param credentials GoogleCredentials to validate (passed as Object to avoid direct import)
     * @param requiredScopes Required OAuth2 scopes
     * @return true if credentials have all required scopes (or if scopes cannot be determined)
     * @throws ConfigurationException if GCP auth library is unavailable
     */
    public static boolean validateScopes(Object credentials, List<String> requiredScopes) {
        if (!GCP_AUTH_AVAILABLE) {
            throw new ConfigurationException("GCP auth library not available for scope validation");
        }

        try {
            return GCPAuthImpl.validateScopes(credentials, requiredScopes);
        } catch (Exception e) {
            log.warn("Failed to validate scopes: {}", e.getMessage());
            return true; // Assume valid on validation failure
        }
    }

    /**
     * Check if GCP auth library is available.
     *
     * @return true if library is available, false otherwise
     */
    public static boolean isAvailable() {
        return GCP_AUTH_AVAILABLE;
    }
}
