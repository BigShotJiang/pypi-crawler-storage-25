package com.bhsf.mca.sdk.integrations;

import com.bhsf.mca.sdk.MCAClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for GenAI and Agentic integrations with MCAClient.
 */
public class IntegrationTest {

    private MCAClient client;

    @BeforeEach
    public void setUp() {
        client = new MCAClient.Builder()
                .serviceName("test-integration-service")
                .modelId("test-model")
                .teamName("test-team")
                .build();
    }

    @AfterEach
    public void tearDown() {
        if (client != null) {
            client.close();
        }
    }

    @Test
    public void testGetGenAIIntegration() {
        GenAIIntegration genai = client.getGenAIIntegration();
        assertNotNull(genai, "GenAI integration should not be null");
    }

    @Test
    public void testGetAgenticTracking() {
        AgenticTracking agentic = client.getAgenticTracking();
        assertNotNull(agentic, "Agentic tracking should not be null");
    }

    @Test
    public void testGetTracer() {
        assertNotNull(client.getTracer(), "Tracer should not be null");
    }

    @Test
    public void testGenAIIntegrationTokenUsage() {
        GenAIIntegration genai = client.getGenAIIntegration();
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");
        attrs.put("provider", "openai");

        // Should not throw
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(150, 50, attrs);
        });
    }

    @Test
    public void testGenAIIntegrationCostTracking() {
        GenAIIntegration genai = client.getGenAIIntegration();
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");
        attrs.put("provider", "openai");

        // Should not throw
        assertDoesNotThrow(() -> {
            genai.recordCost(0.002, attrs);
        });
    }

    @Test
    public void testAgenticTrackingGoalLifecycle() {
        AgenticTracking agentic = client.getAgenticTracking();
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("priority", "high");

        String goalId = agentic.recordGoalStarted("Research treatment options", "research", attrs);
        assertNotNull(goalId, "Goal ID should not be null");
        assertEquals(goalId, agentic.getCurrentGoalId(),
                "Current goal ID should match the started goal");

        assertDoesNotThrow(() -> {
            agentic.recordGoalCompleted(goalId, "success", null);
        });

        assertNull(agentic.getCurrentGoalId(),
                "Current goal ID should be cleared after completion");
    }

    @Test
    public void testAgenticTrackingToolExecution() throws Exception {
        AgenticTracking agentic = client.getAgenticTracking();
        String goalId = agentic.recordGoalStarted("Test goal", "test", null);

        Map<String, Object> toolAttrs = new HashMap<>();
        toolAttrs.put("query", "diabetes");

        try (var tool = agentic.trackTool("pubmed_search", goalId, toolAttrs)) {
            assertNotNull(tool, "Tool context should not be null");
            assertNotNull(tool.getSpan(), "Tool span should not be null");

            // Simulate tool execution
            Thread.sleep(10);
            tool.getSpan().setAttribute("results_count", 42);
        }

        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testEndToEndWorkflow() throws Exception {
        // This test demonstrates the full workflow from the story requirements

        // GenAI tracking
        GenAIIntegration genai = client.getGenAIIntegration();
        Map<String, Object> genaiAttrs = new HashMap<>();
        genaiAttrs.put("model", "gpt-4");
        genaiAttrs.put("provider", "openai");

        genai.recordTokenUsage(150, 50, genaiAttrs);
        genai.recordCost(0.002, genaiAttrs);
        genai.recordRequest("gpt-4", "openai", "success", genaiAttrs);

        // Agentic tracking
        AgenticTracking agentic = client.getAgenticTracking();
        Map<String, Object> goalAttrs = new HashMap<>();
        goalAttrs.put("patient_type", "general");

        String goalId = agentic.recordGoalStarted("Analyze patient data", "analysis", goalAttrs);

        // Track multiple tools
        try (var tool1 = agentic.trackTool("data_loader", goalId, Map.of("source", "emr"))) {
            Thread.sleep(10);
            tool1.getSpan().setAttribute("records_loaded", 1000);
        }

        try (var tool2 = agentic.trackTool("risk_analyzer", goalId, Map.of("model", "risk-v2"))) {
            Thread.sleep(10);
            tool2.getSpan().setAttribute("risk_score", 0.75);
        }

        agentic.recordGoalCompleted(goalId, "success", Map.of("duration_ms", 150L));

        // Verify no exceptions were thrown
        assertTrue(true, "End-to-end workflow completed successfully");
    }

    @Test
    public void testMultipleGoalsSequential() {
        AgenticTracking agentic = client.getAgenticTracking();

        String goal1 = agentic.recordGoalStarted("Goal 1", "research", null);
        agentic.recordGoalCompleted(goal1, "success", null);

        String goal2 = agentic.recordGoalStarted("Goal 2", "analysis", null);
        agentic.recordGoalCompleted(goal2, "success", null);

        assertNotEquals(goal1, goal2, "Goal IDs should be unique");
    }

    @Test
    public void testNestedToolCalls() throws Exception {
        AgenticTracking agentic = client.getAgenticTracking();
        String goalId = agentic.recordGoalStarted("Nested tools test", "test", null);

        try (var outerTool = agentic.trackTool("outer_tool", goalId, null)) {
            Thread.sleep(5);

            try (var innerTool = agentic.trackTool("inner_tool", goalId, null)) {
                Thread.sleep(5);
            }

            Thread.sleep(5);
        }

        agentic.recordGoalCompleted(goalId, "success", null);
    }

    @Test
    public void testConcurrentGenAITracking() throws InterruptedException {
        GenAIIntegration genai = client.getGenAIIntegration();
        int threadCount = 5;
        Thread[] threads = new Thread[threadCount];

        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            threads[i] = new Thread(() -> {
                Map<String, Object> attrs = Map.of(
                        "model", "gpt-4",
                        "thread_id", threadId
                );
                genai.recordTokenUsage(100 + threadId, 50 + threadId, attrs);
                genai.recordCost(0.001 * threadId, attrs);
            });
            threads[i].start();
        }

        // Wait for all threads to complete
        for (Thread thread : threads) {
            thread.join();
        }

        // No assertions needed - success means no exceptions were thrown
    }

    @Test
    public void testClientShutdownCleansUpIntegrations() {
        MCAClient testClient = new MCAClient.Builder()
                .serviceName("shutdown-test")
                .build();

        GenAIIntegration genai = testClient.getGenAIIntegration();
        AgenticTracking agentic = testClient.getAgenticTracking();

        assertNotNull(genai);
        assertNotNull(agentic);

        // Should shutdown cleanly
        assertDoesNotThrow(() -> {
            testClient.shutdown(5000);
        });
    }
}
