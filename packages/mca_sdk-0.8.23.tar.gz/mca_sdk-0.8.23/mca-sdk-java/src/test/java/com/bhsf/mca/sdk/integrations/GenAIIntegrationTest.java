package com.bhsf.mca.sdk.integrations;

import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.testing.exporter.InMemoryMetricReader;
import io.opentelemetry.sdk.metrics.data.MetricData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for GenAIIntegration.
 */
public class GenAIIntegrationTest {

    private InMemoryMetricReader metricReader;
    private SdkMeterProvider meterProvider;
    private Meter meter;
    private GenAIIntegration genai;

    @BeforeEach
    public void setUp() {
        // Set up in-memory metric reader for testing
        metricReader = InMemoryMetricReader.create();
        meterProvider = SdkMeterProvider.builder()
                .registerMetricReader(metricReader)
                .build();
        meter = meterProvider.get("test");
        genai = new GenAIIntegration(meter);
    }

    @AfterEach
    public void tearDown() {
        if (meterProvider != null) {
            meterProvider.close();
        }
    }

    @Test
    public void testConstructorWithNullMeter() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new GenAIIntegration(null);
        });
        assertTrue(exception.getMessage().contains("Meter cannot be null"));
    }

    @Test
    public void testRecordTokenUsage() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");
        attrs.put("provider", "openai");

        genai.recordTokenUsage(150, 50, attrs);

        // Verify metrics were recorded
        metricReader.collectAllMetrics().forEach(metric -> {
            if (metric.getName().equals("genai.tokens_total")) {
                assertNotNull(metric, "Token metric should be recorded");
            }
        });
    }

    @Test
    public void testRecordTokenUsageWithNegativePromptTokens() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            genai.recordTokenUsage(-10, 50, attrs);
        });
        assertTrue(exception.getMessage().contains("promptTokens cannot be negative"));
    }

    @Test
    public void testRecordTokenUsageWithNegativeCompletionTokens() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            genai.recordTokenUsage(150, -50, attrs);
        });
        assertTrue(exception.getMessage().contains("completionTokens cannot be negative"));
    }

    @Test
    public void testRecordTokenUsageWithZeroTokens() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");

        // Should not throw - zero is valid
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(0, 0, attrs);
        });
    }

    @Test
    public void testRecordTokenUsageWithNullAttributes() {
        // Should not throw - null attributes are allowed
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(100, 50, null);
        });
    }

    @Test
    public void testRecordTokenUsageWithEmptyAttributes() {
        Map<String, Object> attrs = new HashMap<>();

        // Should not throw - empty attributes are allowed
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(100, 50, attrs);
        });
    }

    @Test
    public void testRecordCost() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");
        attrs.put("provider", "openai");

        genai.recordCost(0.002, attrs);

        // Verify cost metric was recorded
        metricReader.collectAllMetrics().forEach(metric -> {
            if (metric.getName().equals("genai.cost_dollars")) {
                assertNotNull(metric, "Cost metric should be recorded");
            }
        });
    }

    @Test
    public void testRecordCostWithNegativeValue() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            genai.recordCost(-0.002, attrs);
        });
        assertTrue(exception.getMessage().contains("costUsd cannot be negative"));
    }

    @Test
    public void testRecordCostWithZero() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model", "gpt-4");

        // Zero cost is valid
        assertDoesNotThrow(() -> {
            genai.recordCost(0.0, attrs);
        });
    }

    @Test
    public void testRecordRequestSuccess() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("endpoint", "/v1/chat/completions");

        genai.recordRequest("gpt-4", "openai", "success", attrs);

        // Verify request metric was recorded
        metricReader.collectAllMetrics().forEach(metric -> {
            if (metric.getName().equals("genai.requests_total")) {
                assertNotNull(metric, "Request metric should be recorded");
            }
        });
    }

    @Test
    public void testRecordRequestError() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("error_type", "rate_limit");

        genai.recordRequest("gpt-4", "openai", "error", attrs);

        // Verify failed request metric was recorded
        metricReader.collectAllMetrics().forEach(metric -> {
            if (metric.getName().equals("genai.requests_failed_total")) {
                assertNotNull(metric, "Failed request metric should be recorded");
            }
        });
    }

    @Test
    public void testRecordRequestWithInvalidStatus() {
        Map<String, Object> attrs = new HashMap<>();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            genai.recordRequest("gpt-4", "openai", "invalid", attrs);
        });
        assertTrue(exception.getMessage().contains("status must be 'success' or 'error'"));
    }

    @Test
    public void testRecordRequestWithNullStatus() {
        Map<String, Object> attrs = new HashMap<>();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            genai.recordRequest("gpt-4", "openai", null, attrs);
        });
        assertTrue(exception.getMessage().contains("status must be 'success' or 'error'"));
    }

    @Test
    public void testAttributeTypes() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("string_attr", "value");
        attrs.put("long_attr", 123L);
        attrs.put("int_attr", 456);
        attrs.put("double_attr", 78.9);
        attrs.put("float_attr", 10.11f);
        attrs.put("boolean_attr", true);

        // Should handle all supported types without errors
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(100, 50, attrs);
        });
    }

    @Test
    public void testUnsupportedAttributeType() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("list_attr", java.util.Arrays.asList("a", "b", "c"));

        // Should not throw, but should log warning and ignore unsupported type
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(100, 50, attrs);
        });
    }

    @Test
    public void testThreadSafety() throws InterruptedException {
        int threadCount = 10;
        int operationsPerThread = 100;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    Map<String, Object> attrs = new HashMap<>();
                    attrs.put("thread_id", String.valueOf(threadId));
                    attrs.put("model", "gpt-4");

                    for (int j = 0; j < operationsPerThread; j++) {
                        genai.recordTokenUsage(100, 50, attrs);
                        genai.recordCost(0.002, attrs);
                        genai.recordRequest("gpt-4", "openai", "success", attrs);
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        assertTrue(latch.await(10, TimeUnit.SECONDS),
                "All threads should complete within timeout");
        executor.shutdown();

        // Verify metrics were recorded from all threads
        boolean foundTokenMetric = false;
        boolean foundCostMetric = false;
        boolean foundRequestMetric = false;

        for (MetricData metric : metricReader.collectAllMetrics()) {
            if (metric.getName().equals("genai.tokens_total")) {
                foundTokenMetric = true;
            } else if (metric.getName().equals("genai.cost_dollars")) {
                foundCostMetric = true;
            } else if (metric.getName().equals("genai.requests_total")) {
                foundRequestMetric = true;
            }
        }

        assertTrue(foundTokenMetric, "Token metrics should be recorded from concurrent threads");
        assertTrue(foundCostMetric, "Cost metrics should be recorded from concurrent threads");
        assertTrue(foundRequestMetric, "Request metrics should be recorded from concurrent threads");
    }

    @Test
    public void testInstrumentCaching() {
        // Create multiple integrations with the same meter to verify instruments are created properly
        GenAIIntegration genai1 = new GenAIIntegration(meter);
        GenAIIntegration genai2 = new GenAIIntegration(meter);

        Map<String, Object> attrs = Map.of("model", "gpt-4");

        // Both should work without issues
        assertDoesNotThrow(() -> {
            genai1.recordTokenUsage(100, 50, attrs);
            genai2.recordTokenUsage(100, 50, attrs);
        });
    }

    @Test
    public void testLargeTokenCounts() {
        Map<String, Object> attrs = Map.of("model", "gpt-4");

        // Test with large token counts (e.g., 128K context window)
        assertDoesNotThrow(() -> {
            genai.recordTokenUsage(100000, 28000, attrs);
        });
    }

    @Test
    public void testLargeCostValues() {
        Map<String, Object> attrs = Map.of("model", "gpt-4");

        // Test with large cost value
        assertDoesNotThrow(() -> {
            genai.recordCost(99.99, attrs);
        });
    }
}
