package com.bhsf.mca.sdk;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.*;

/**
 * Unit tests for MCAClient and its Builder pattern.
 */
public class MCAClientTest {

    private MCAClient client;

    @AfterEach
    public void tearDown() {
        if (client != null) {
            client.shutdown(5000);
        }
    }

    @Test
    public void testBuilderWithMinimalConfig() {
        // AC 1: Builder pattern initialization
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        assertNotNull(client, "Client should not be null");
    }

    @Test
    public void testBuilderWithFullConfig() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .modelId("mdl-001")
                .teamName("clinical-ai")
                .modelVersion("1.0.0")
                .otelEndpoint("http://localhost:4318")
                .build();

        assertNotNull(client, "Client should not be null");
    }

    @Test
    public void testBuilderValidationFailsWithoutServiceName() {
        // Builder should throw ConfigurationException when serviceName is missing
        Exception exception = assertThrows(ConfigurationException.class, () -> {
            new MCAClient.Builder().build();
        });

        assertTrue(exception.getMessage().contains("serviceName"),
                "Error message should mention serviceName");
    }

    @Test
    public void testBuilderValidationFailsWithEmptyServiceName() {
        Exception exception = assertThrows(ConfigurationException.class, () -> {
            new MCAClient.Builder()
                    .serviceName("")
                    .build();
        });

        assertTrue(exception.getMessage().contains("serviceName"),
                "Error message should mention serviceName");
    }

    @Test
    public void testBuilderValidationFailsWithNullServiceName() {
        Exception exception = assertThrows(ConfigurationException.class, () -> {
            new MCAClient.Builder()
                    .serviceName(null)
                    .build();
        });

        assertTrue(exception.getMessage().contains("serviceName"),
                "Error message should mention serviceName");
    }

    @Test
    public void testBuilderFluentAPI() {
        // Test fluent API returns builder for chaining
        MCAClient.Builder builder = new MCAClient.Builder();

        assertSame(builder, builder.serviceName("test"), "serviceName should return builder");
        assertSame(builder, builder.modelId("test"), "modelId should return builder");
        assertSame(builder, builder.teamName("test"), "teamName should return builder");
    }

    @Test
    public void testShutdownWithTimeout() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        // Should complete without throwing
        assertDoesNotThrow(() -> {
            client.shutdown(5000);
        }, "Shutdown should not throw exception");
    }

    @Test
    public void testMultipleShutdownCallsAreSafe() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        client.shutdown(5000);

        // Second shutdown should be safe (idempotent)
        assertDoesNotThrow(() -> {
            client.shutdown(5000);
        }, "Multiple shutdown calls should be safe");
    }

    @Test
    public void testAutoCloseableInterface() {
        // AC 3: AutoCloseable for try-with-resources
        assertDoesNotThrow(() -> {
            try (MCAClient autoClient = new MCAClient.Builder()
                    .serviceName("test-model")
                    .build()) {
                assertNotNull(autoClient, "Client should not be null in try-with-resources");
            }
        }, "Try-with-resources should work correctly");
    }

    @Test
    public void testThreadSafety() throws InterruptedException {
        // AC 4: Thread safety for concurrent predictions
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        int threadCount = 10;
        int operationsPerThread = 100;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                try {
                    for (int j = 0; j < operationsPerThread; j++) {
                        // This will call recordPrediction once implemented
                        // For now, just test that client can be accessed concurrently
                        assertNotNull(client);
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        assertTrue(latch.await(10, TimeUnit.SECONDS),
                "All threads should complete within timeout");
        executor.shutdown();
    }

    @Test
    public void testDefaultEndpointIsLocalhost() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        // Default endpoint should be localhost:4318
        assertNotNull(client, "Client should be initialized with default endpoint");
    }

    @Test
    public void testCustomEndpoint() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .otelEndpoint("http://custom-collector:4318")
                .build();

        assertNotNull(client, "Client should be initialized with custom endpoint");
    }
}
