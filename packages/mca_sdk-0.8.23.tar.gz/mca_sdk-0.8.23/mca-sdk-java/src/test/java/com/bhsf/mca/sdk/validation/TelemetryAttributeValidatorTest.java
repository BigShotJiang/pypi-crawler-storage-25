package com.bhsf.mca.sdk.validation;

import com.bhsf.mca.sdk.exceptions.ValidationException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

public class TelemetryAttributeValidatorTest {

    // Attribute length tests

    @Test
    public void testValidAttributeLength() {
        assertTrue(TelemetryAttributeValidator.validateAttributeLength("key", "value"));
    }

    @Test
    public void testAttributeValueTooLong_ShouldThrow() {
        String longValue = "a".repeat(1025);  // Over 1024 limit

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAttributeLength("key", longValue);
        });

        assertTrue(ex.getMessage().contains("1024"));
    }

    @Test
    public void testAttributeValueExactlyAtLimit() {
        String maxValue = "a".repeat(1024);  // Exactly at limit

        assertDoesNotThrow(() -> {
            TelemetryAttributeValidator.validateAttributeLength("key", maxValue);
        });
    }

    @Test
    public void testAttributeKeyTooLong_ShouldThrow() {
        String longKey = "k".repeat(129);  // Over 128 limit

        assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAttributeLength(longKey, "value");
        });
    }

    @Test
    public void testAttributeKeyExactlyAtLimit() {
        String maxKey = "k".repeat(128);  // Exactly at limit

        assertDoesNotThrow(() -> {
            TelemetryAttributeValidator.validateAttributeLength(maxKey, "value");
        });
    }

    @Test
    public void testNullKey_ShouldThrow() {
        assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAttributeLength(null, "value");
        });
    }

    @Test
    public void testNullValue_ShouldThrow() {
        assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAttributeLength("key", null);
        });
    }

    @Test
    public void testNumericValue_ShouldConvertToString() {
        assertDoesNotThrow(() -> {
            TelemetryAttributeValidator.validateAttributeLength("key", 12345);
        });
    }

    // Attribute count tests

    @Test
    public void testValidAttributeCount() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("key1", "value1");
        attributes.put("key2", "value2");

        assertTrue(TelemetryAttributeValidator.validateAttributeCount(attributes));
    }

    @Test
    public void testAttributeCountTooHigh_ShouldThrow() {
        Map<String, Object> attributes = new HashMap<>();
        for (int i = 0; i < 129; i++) {  // Over 128 limit
            attributes.put("key" + i, "value" + i);
        }

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAttributeCount(attributes);
        });

        assertTrue(ex.getMessage().contains("128"));
    }

    @Test
    public void testAttributeCountExactlyAtLimit() {
        Map<String, Object> attributes = new HashMap<>();
        for (int i = 0; i < 128; i++) {  // Exactly at limit
            attributes.put("key" + i, "value" + i);
        }

        assertDoesNotThrow(() -> {
            TelemetryAttributeValidator.validateAttributeCount(attributes);
        });
    }

    @Test
    public void testNullAttributes_CountIsValid() {
        assertTrue(TelemetryAttributeValidator.validateAttributeCount(null));
    }

    @Test
    public void testEmptyAttributes_CountIsValid() {
        assertTrue(TelemetryAttributeValidator.validateAttributeCount(new HashMap<>()));
    }

    // Attribute structure (nesting) tests

    @Test
    public void testValidFlatStructure() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("key1", "value1");
        attributes.put("key2", "value2");

        assertTrue(TelemetryAttributeValidator.validateAttributeStructure(attributes));
    }

    @Test
    public void testValidNestedStructure_Level2() {
        Map<String, Object> nested = new HashMap<>();
        nested.put("inner", "value");

        Map<String, Object> attributes = new HashMap<>();
        attributes.put("outer", nested);

        assertDoesNotThrow(() -> {
            TelemetryAttributeValidator.validateAttributeStructure(attributes);
        });
    }

    @Test
    public void testValidNestedStructure_Level5() {
        Map<String, Object> level5 = new HashMap<>();
        level5.put("deepest", "value");

        Map<String, Object> level4 = new HashMap<>();
        level4.put("level5", level5);

        Map<String, Object> level3 = new HashMap<>();
        level3.put("level4", level4);

        Map<String, Object> level2 = new HashMap<>();
        level2.put("level3", level3);

        Map<String, Object> level1 = new HashMap<>();
        level1.put("level2", level2);

        assertDoesNotThrow(() -> {
            TelemetryAttributeValidator.validateAttributeStructure(level1);
        });
    }

    @Test
    public void testNestingTooDeep_ShouldThrow() {
        // Create nesting deeper than 5 levels
        Map<String, Object> level6 = new HashMap<>();
        level6.put("deepest", "value");

        Map<String, Object> level5 = new HashMap<>();
        level5.put("level6", level6);

        Map<String, Object> level4 = new HashMap<>();
        level4.put("level5", level5);

        Map<String, Object> level3 = new HashMap<>();
        level3.put("level4", level4);

        Map<String, Object> level2 = new HashMap<>();
        level2.put("level3", level3);

        Map<String, Object> level1 = new HashMap<>();
        level1.put("level2", level2);

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAttributeStructure(level1);
        });

        assertTrue(ex.getMessage().contains("depth"));
        assertTrue(ex.getMessage().contains("5"));
    }

    @Test
    public void testNonMapStructure_IsValid() {
        // Non-map objects don't have nesting, should be valid
        assertTrue(TelemetryAttributeValidator.validateAttributeStructure("string"));
        assertTrue(TelemetryAttributeValidator.validateAttributeStructure(123));
        assertTrue(TelemetryAttributeValidator.validateAttributeStructure(null));
    }

    // validateAll() tests

    @Test
    public void testValidateAll_ValidAttributes() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("key1", "value1");
        attributes.put("key2", "value2");

        assertTrue(TelemetryAttributeValidator.validateAll(attributes));
    }

    @Test
    public void testValidateAll_TooManyAttributes_ShouldThrow() {
        Map<String, Object> attributes = new HashMap<>();
        for (int i = 0; i < 129; i++) {
            attributes.put("key" + i, "value" + i);
        }

        assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAll(attributes);
        });
    }

    @Test
    public void testValidateAll_AttributeTooLong_ShouldThrow() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("key", "a".repeat(1025));

        assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAll(attributes);
        });
    }

    @Test
    public void testValidateAll_TooDeepNesting_ShouldThrow() {
        // Create too-deep nesting
        Map<String, Object> deep = new HashMap<>();
        Map<String, Object> current = deep;
        for (int i = 0; i < 7; i++) {
            Map<String, Object> next = new HashMap<>();
            current.put("level" + i, next);
            current = next;
        }

        assertThrows(ValidationException.class, () -> {
            TelemetryAttributeValidator.validateAll(deep);
        });
    }

    @Test
    public void testValidateAll_NullAttributes() {
        assertTrue(TelemetryAttributeValidator.validateAll(null));
    }

    @Test
    public void testValidateAll_EmptyAttributes() {
        assertTrue(TelemetryAttributeValidator.validateAll(new HashMap<>()));
    }

    // Constant values tests

    @Test
    public void testConstants() {
        assertEquals(1024, TelemetryAttributeValidator.MAX_ATTRIBUTE_LENGTH);
        assertEquals(128, TelemetryAttributeValidator.MAX_ATTRIBUTE_COUNT);
        assertEquals(128, TelemetryAttributeValidator.MAX_KEY_LENGTH);
        assertEquals(5, TelemetryAttributeValidator.MAX_NESTING_DEPTH);
    }
}
