package com.bhsf.mca.sdk.exceptions;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for BufferingException.
 */
class BufferingExceptionTest {

    @Test
    void testMessageOnlyConstructor() {
        String message = "Queue is full, cannot accept new items";
        BufferingException exception = new BufferingException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testMessageAndCauseConstructor() {
        String message = "Failed to persist queue to disk";
        IOException cause = new IOException("Disk full");
        BufferingException exception = new BufferingException(message, cause);

        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testExtendsMCAException() {
        BufferingException exception = new BufferingException("Test message");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testCredentialSanitization() {
        String gcpKey = "AIzaSyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q";
        BufferingException exception = new BufferingException(
            "Queue persist failed with key " + gcpKey);

        String message = exception.getMessage();
        assertFalse(message.contains(gcpKey), "GCP key should be masked");
        assertTrue(message.contains("AIzaSy"), "GCP prefix should be visible");
    }
}
