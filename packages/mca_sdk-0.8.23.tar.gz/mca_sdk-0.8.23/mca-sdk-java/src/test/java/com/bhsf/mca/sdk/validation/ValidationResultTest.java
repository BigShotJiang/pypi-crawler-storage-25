package com.bhsf.mca.sdk.validation;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;

public class ValidationResultTest {

    @Test
    public void testSuccessfulValidation() {
        ValidationResult result = ValidationResult.success();

        assertTrue(result.isValid());
        assertTrue(result.getMissingFields().isEmpty());
        assertTrue(result.getErrors().isEmpty());
    }

    @Test
    public void testFailedValidationWithErrors() {
        ValidationResult result = ValidationResult.failure(
            Arrays.asList("field1", "field2"),
            Arrays.asList("error1", "error2")
        );

        assertFalse(result.isValid());
        assertEquals(2, result.getMissingFields().size());
        assertEquals(2, result.getErrors().size());
        assertTrue(result.getMissingFields().contains("field1"));
        assertTrue(result.getErrors().contains("error1"));
    }

    @Test
    public void testImmutability() {
        ValidationResult result = ValidationResult.success();

        // Lists should be unmodifiable
        assertThrows(UnsupportedOperationException.class, () -> {
            result.getMissingFields().add("field");
        });

        assertThrows(UnsupportedOperationException.class, () -> {
            result.getErrors().add("error");
        });
    }

    @Test
    public void testDefensiveCheck_ValidTrueWithErrors_ShouldFail() {
        // valid=true with errors should throw IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            new ValidationResult(true, Collections.emptyList(), Arrays.asList("error"));
        });
    }

    @Test
    public void testDefensiveCheck_ValidTrueWithMissingFields_ShouldFail() {
        // valid=true with missing fields should throw IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            new ValidationResult(true, Arrays.asList("field"), Collections.emptyList());
        });
    }

    @Test
    public void testToString_Success() {
        ValidationResult result = ValidationResult.success();
        String str = result.toString();

        assertTrue(str.contains("valid=true"));
    }

    @Test
    public void testToString_Failure() {
        ValidationResult result = ValidationResult.failure(
            Arrays.asList("field1"),
            Arrays.asList("error1")
        );
        String str = result.toString();

        assertTrue(str.contains("valid=false"));
        assertTrue(str.contains("error1"));
        assertTrue(str.contains("field1"));
    }
}
