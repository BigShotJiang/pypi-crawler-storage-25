package com.bhsf.mca.sdk.exceptions;

import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ConfigNotFoundException.
 */
class ConfigNotFoundExceptionTest {

    @Test
    void testMessageOnlyConstructor() {
        String message = "Configuration file config.yaml not found";
        ConfigNotFoundException exception = new ConfigNotFoundException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void testMessageAndCauseConstructor() {
        String message = "Cannot load config from /path/to/config.yaml";
        FileNotFoundException cause = new FileNotFoundException("/path/to/config.yaml");
        ConfigNotFoundException exception = new ConfigNotFoundException(message, cause);

        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testExtendsMCAException() {
        ConfigNotFoundException exception = new ConfigNotFoundException("Test message");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testCredentialSanitization() {
        String awsKey = "AKIAIOSFODNN7EXAMPLE";
        ConfigNotFoundException exception = new ConfigNotFoundException(
            "Config not found for key " + awsKey);

        String message = exception.getMessage();
        assertFalse(message.contains(awsKey), "AWS key should be masked");
        assertTrue(message.contains("AKIA"), "AWS prefix should be visible");
    }
}
