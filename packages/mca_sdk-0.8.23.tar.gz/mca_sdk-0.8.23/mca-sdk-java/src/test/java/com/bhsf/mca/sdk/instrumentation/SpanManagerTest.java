package com.bhsf.mca.sdk.instrumentation;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.testing.exporter.InMemorySpanExporter;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SpanManager.
 */
public class SpanManagerTest {

    private Tracer tracer;
    private InMemorySpanExporter spanExporter;
    private SdkTracerProvider tracerProvider;

    @BeforeEach
    public void setUp() {
        // Create in-memory span exporter for testing
        spanExporter = InMemorySpanExporter.create();
        tracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                .build();

        OpenTelemetrySdk sdk = OpenTelemetrySdk.builder()
                .setTracerProvider(tracerProvider)
                .build();

        tracer = sdk.getTracer("test-tracer");
    }

    @AfterEach
    public void tearDown() {
        if (tracerProvider != null) {
            tracerProvider.close();
        }
        if (spanExporter != null) {
            spanExporter.reset();
        }
    }

    @Test
    public void testSpanCreationAndClose() {
        // Create span manager
        try (SpanManager manager = new SpanManager(tracer, "test.span", null)) {
            assertNotNull(manager.getSpan(), "Span should not be null");
        }

        // Verify span was ended
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size(), "Should have one finished span");
        assertEquals("test.span", spans.get(0).getName(), "Span name should match");
    }

    @Test
    public void testSpanWithAttributes() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("string_attr", "value");
        attributes.put("long_attr", 123L);
        attributes.put("double_attr", 45.67);
        attributes.put("boolean_attr", true);

        try (SpanManager manager = new SpanManager(tracer, "test.span", attributes)) {
            assertNotNull(manager.getSpan());
        }

        // Verify attributes were set
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
        SpanData span = spans.get(0);

        assertEquals("value", span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.stringKey("string_attr")));
        assertEquals(123L, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.longKey("long_attr")));
        assertEquals(45.67, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.doubleKey("double_attr")));
        assertEquals(true, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.booleanKey("boolean_attr")));
    }

    @Test
    public void testSetAttributeFluentAPI() {
        try (SpanManager manager = new SpanManager(tracer, "test.span", null)) {
            // Test fluent API chaining
            SpanManager result = manager.setAttribute("attr1", "value1")
                    .setAttribute("attr2", 100L)
                    .setAttribute("attr3", 3.14);

            assertSame(manager, result, "setAttribute should return same instance for chaining");
        }

        // Verify attributes were set
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
        SpanData span = spans.get(0);

        assertEquals("value1", span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.stringKey("attr1")));
        assertEquals(100L, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.longKey("attr2")));
        assertEquals(3.14, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.doubleKey("attr3")));
    }

    @Test
    public void testNullAttributes() {
        // Should not throw with null attributes
        try (SpanManager manager = new SpanManager(tracer, "test.span", null)) {
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
    }

    @Test
    public void testEmptyAttributes() {
        // Should not throw with empty attributes map
        try (SpanManager manager = new SpanManager(tracer, "test.span", new HashMap<>())) {
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
    }

    @Test
    public void testNullTracerThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new SpanManager(null, "test.span", null);
        });

        assertTrue(exception.getMessage().contains("Tracer"));
    }

    @Test
    public void testNullSpanNameThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new SpanManager(tracer, null, null);
        });

        assertTrue(exception.getMessage().contains("Span name"));
    }

    @Test
    public void testEmptySpanNameThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new SpanManager(tracer, "", null);
        });

        assertTrue(exception.getMessage().contains("Span name"));
    }

    @Test
    public void testUnsupportedAttributeType() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("valid_attr", "value");
        attributes.put("invalid_attr", new Object()); // Unsupported type

        // Should not throw - just log warning and ignore unsupported type
        try (SpanManager manager = new SpanManager(tracer, "test.span", attributes)) {
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
        SpanData span = spans.get(0);

        // Valid attribute should be present
        assertEquals("value", span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.stringKey("valid_attr")));

        // Invalid attribute should not be present
        assertNull(span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.stringKey("invalid_attr")));
    }

    @Test
    public void testSetAttributeWithNullKey() {
        // Should not throw - just log warning and ignore
        try (SpanManager manager = new SpanManager(tracer, "test.span", null)) {
            manager.setAttribute(null, "value");
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
    }

    @Test
    public void testSetAttributeWithNullValue() {
        // Should not throw - just log debug and ignore
        try (SpanManager manager = new SpanManager(tracer, "test.span", null)) {
            manager.setAttribute("key", null);
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
    }

    @Test
    public void testGetSpan() {
        try (SpanManager manager = new SpanManager(tracer, "test.span", null)) {
            Span span = manager.getSpan();
            assertNotNull(span, "getSpan() should return non-null span");
        }
    }

    @Test
    public void testAutoCloseEndsSpan() {
        SpanManager manager = new SpanManager(tracer, "test.span", null);

        // Before close - no finished spans
        assertEquals(0, spanExporter.getFinishedSpanItems().size());

        // Close the span
        manager.close();

        // After close - span should be finished
        assertEquals(1, spanExporter.getFinishedSpanItems().size());
    }

    @Test
    public void testDoubleCloseIsIdempotent() {
        SpanManager manager = new SpanManager(tracer, "test.span", null);

        // Close twice - should not throw
        manager.close();
        manager.close();

        // Should still have only one finished span
        assertEquals(1, spanExporter.getFinishedSpanItems().size());
    }

    @Test
    public void testTypeConversions() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("int_attr", 42); // Integer -> Long
        attributes.put("float_attr", 3.14f); // Float -> Double

        try (SpanManager manager = new SpanManager(tracer, "test.span", attributes)) {
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());
        SpanData span = spans.get(0);

        // Integer should be converted to Long
        assertEquals(42L, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.longKey("int_attr")));

        // Float should be converted to Double
        assertEquals(3.14, span.getAttributes().get(io.opentelemetry.api.common.AttributeKey.doubleKey("float_attr")), 0.01);
    }

    @Test
    public void testConstructorFailureDoesNotLeakContext() {
        // This test verifies that if constructor fails during attribute setting,
        // the scope and span are properly cleaned up to prevent thread context leak

        // Create a map that will cause an exception during iteration
        Map<String, Object> badAttributes = new HashMap<String, Object>() {
            @Override
            public java.util.Set<Map.Entry<String, Object>> entrySet() {
                throw new RuntimeException("Simulated attribute processing failure");
            }
        };

        // Constructor should fail and clean up resources
        assertThrows(RuntimeException.class, () -> {
            new SpanManager(tracer, "test.span", badAttributes);
        });

        // Verify that a subsequent span creation works correctly
        // (would fail if context was leaked)
        try (SpanManager manager = new SpanManager(tracer, "test.after.failure", null)) {
            assertNotNull(manager.getSpan());
        }

        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size(), "Should have only the successful span");
        assertEquals("test.after.failure", spans.get(0).getName());
    }

    @Test
    public void testMultipleCloseCallsAreIdempotent() {
        SpanManager manager = new SpanManager(tracer, "test.span", null);

        // Close multiple times - should not throw or corrupt context
        manager.close();
        manager.close();
        manager.close();

        // Should still have only one finished span
        List<SpanData> spans = spanExporter.getFinishedSpanItems();
        assertEquals(1, spans.size());

        // Verify subsequent span creation still works (context not corrupted)
        try (SpanManager manager2 = new SpanManager(tracer, "test.after.multiclose", null)) {
            assertNotNull(manager2.getSpan());
        }

        spans = spanExporter.getFinishedSpanItems();
        assertEquals(2, spans.size());
    }
}
