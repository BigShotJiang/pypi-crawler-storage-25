package com.bhsf.mca.sdk.resilience;

import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CircuitBreaker.
 */
public class CircuitBreakerTest {

    @Test
    public void testInitialState() {
        RetryPolicy retry = new RetryPolicy(3, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 5, 60000, "test");

        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
        assertEquals(0, breaker.getFailureCount());
        assertEquals(0, breaker.getSuccessCount());
    }

    @Test
    public void testSuccessfulOperationKeepsCircuitClosed() throws Exception {
        RetryPolicy retry = new RetryPolicy(3, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 5, 60000, "test");

        String result = breaker.execute(() -> "success");

        assertEquals("success", result);
        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
        assertEquals(0, breaker.getFailureCount());
        assertEquals(1, breaker.getSuccessCount());
    }

    @Test
    public void testCircuitOpensAfterThresholdFailures() {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0); // No retries
        CircuitBreaker breaker = new CircuitBreaker(retry, 3, 60000, "test");

        // Fail 3 times
        for (int i = 0; i < 3; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
                fail("Should have thrown exception");
            } catch (Exception e) {
                // Expected
            }
        }

        // Circuit should be OPEN
        assertEquals(CircuitBreaker.CircuitState.OPEN, breaker.getState());
    }

    @Test
    public void testCircuitOpenFastFails() {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 2, 60000, "test");

        // Trip circuit with 2 failures
        for (int i = 0; i < 2; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
            } catch (Exception e) {
                // Expected
            }
        }

        assertEquals(CircuitBreaker.CircuitState.OPEN, breaker.getState());

        // Next call should fail fast without executing operation
        AtomicInteger executeCount = new AtomicInteger(0);
        assertThrows(CircuitBreaker.CircuitBreakerOpenException.class, () -> {
            breaker.execute(() -> {
                executeCount.incrementAndGet();
                return "success";
            });
        });

        // Operation should not have been executed
        assertEquals(0, executeCount.get());
    }

    @Test
    public void testCircuitTransitionsToHalfOpenAfterTimeout() throws Exception {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 2, 100, "test"); // 100ms timeout

        // Trip circuit
        for (int i = 0; i < 2; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
            } catch (Exception e) {
                // Expected
            }
        }

        assertEquals(CircuitBreaker.CircuitState.OPEN, breaker.getState());

        // Wait for timeout
        Thread.sleep(150);

        // Next call should transition to HALF_OPEN and execute
        AtomicInteger executeCount = new AtomicInteger(0);
        String result = breaker.execute(() -> {
            executeCount.incrementAndGet();
            return "success";
        });

        assertEquals("success", result);
        assertEquals(1, executeCount.get());
        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
    }

    @Test
    public void testHalfOpenSuccessTransitionsToClosed() throws Exception {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 2, 100, "test");

        // Trip circuit
        for (int i = 0; i < 2; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
            } catch (Exception e) {
                // Expected
            }
        }

        // Wait for timeout
        Thread.sleep(150);

        // Successful call in HALF_OPEN → CLOSED
        breaker.execute(() -> "success");

        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
        assertEquals(0, breaker.getFailureCount());
    }

    @Test
    public void testHalfOpenFailureTransitionsBackToOpen() throws Exception {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 2, 100, "test");

        // Trip circuit
        for (int i = 0; i < 2; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
            } catch (Exception e) {
                // Expected
            }
        }

        // Wait for timeout
        Thread.sleep(150);

        // Failed call in HALF_OPEN → back to OPEN
        try {
            breaker.execute(() -> {
                throw new RuntimeException("Still failing");
            });
        } catch (Exception e) {
            // Expected
        }

        assertEquals(CircuitBreaker.CircuitState.OPEN, breaker.getState());
    }

    @Test
    public void testManualReset() {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 2, 60000, "test");

        // Trip circuit
        for (int i = 0; i < 2; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
            } catch (Exception e) {
                // Expected
            }
        }

        assertEquals(CircuitBreaker.CircuitState.OPEN, breaker.getState());

        // Manual reset
        breaker.reset();

        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
        assertEquals(0, breaker.getFailureCount());
    }

    @Test
    public void testGetStats() {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 5, 30000, "test-breaker");

        CircuitBreaker.CircuitBreakerStats stats = breaker.getStats();

        assertEquals(CircuitBreaker.CircuitState.CLOSED, stats.getState());
        assertEquals(0, stats.getFailureCount());
        assertEquals(5, stats.getFailureThreshold());
        assertEquals(30000, stats.getResetTimeoutMs());
        assertEquals(0, stats.getSuccessCount());
        assertEquals("test-breaker", stats.getName());
    }

    @Test
    public void testInvalidConfigurationThrowsException() {
        RetryPolicy retry = new RetryPolicy(3, 0.1, 1.0);

        // null retry policy
        assertThrows(IllegalArgumentException.class, () -> {
            new CircuitBreaker(null, 5, 60000, "test");
        });

        // failureThreshold <= 0
        assertThrows(IllegalArgumentException.class, () -> {
            new CircuitBreaker(retry, 0, 60000, "test");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new CircuitBreaker(retry, -1, 60000, "test");
        });

        // resetTimeoutMs <= 0
        assertThrows(IllegalArgumentException.class, () -> {
            new CircuitBreaker(retry, 5, 0, "test");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new CircuitBreaker(retry, 5, -1, "test");
        });
    }

    @Test
    public void testGetters() {
        RetryPolicy retry = new RetryPolicy(3, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 7, 45000, "my-breaker");

        assertEquals(7, breaker.getFailureThreshold());
        assertEquals(45000, breaker.getResetTimeoutMs());
        assertEquals("my-breaker", breaker.getName());
    }

    @Test
    public void testSuccessResetsFailureCount() throws Exception {
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 5, 60000, "test");

        // Fail once
        try {
            breaker.execute(() -> {
                throw new RuntimeException("Failure");
            });
        } catch (Exception e) {
            // Expected
        }

        assertEquals(1, breaker.getFailureCount());

        // Success should reset failure count
        breaker.execute(() -> "success");

        assertEquals(0, breaker.getFailureCount());
        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
    }

    @Test
    public void testThunderingHerdPrevention() throws Exception {
        // Test the fix for thundering herd during OPEN → HALF_OPEN transition
        RetryPolicy retry = new RetryPolicy(0, 0.1, 1.0);
        CircuitBreaker breaker = new CircuitBreaker(retry, 2, 100, "test");

        // Trip circuit
        for (int i = 0; i < 2; i++) {
            try {
                breaker.execute(() -> {
                    throw new RuntimeException("Failure");
                });
            } catch (Exception e) {
                // Expected
            }
        }

        assertEquals(CircuitBreaker.CircuitState.OPEN, breaker.getState());

        // Wait for timeout
        Thread.sleep(150);

        // Simulate multiple threads racing to test the circuit
        int numThreads = 10;
        java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(numThreads);
        java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(numThreads);
        java.util.concurrent.atomic.AtomicInteger testExecutions = new java.util.concurrent.atomic.AtomicInteger(0);
        java.util.concurrent.atomic.AtomicInteger fastFailures = new java.util.concurrent.atomic.AtomicInteger(0);

        for (int i = 0; i < numThreads; i++) {
            executor.submit(() -> {
                try {
                    breaker.execute(() -> {
                        testExecutions.incrementAndGet();
                        return "success";
                    });
                } catch (CircuitBreaker.CircuitBreakerOpenException e) {
                    // Other threads should fast-fail while test is in progress
                    fastFailures.incrementAndGet();
                } catch (Exception e) {
                    // Unexpected
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(5, java.util.concurrent.TimeUnit.SECONDS);
        executor.shutdown();

        // CRITICAL: Only ONE thread should have executed the test request
        // All others should have fast-failed with CircuitBreakerOpenException
        assertEquals(1, testExecutions.get(),
                "Only one thread should execute the HALF_OPEN test request");
        assertEquals(numThreads - 1, fastFailures.get(),
                "Other threads should fast-fail during HALF_OPEN test");

        // Circuit should be CLOSED after successful test
        assertEquals(CircuitBreaker.CircuitState.CLOSED, breaker.getState());
    }
}
