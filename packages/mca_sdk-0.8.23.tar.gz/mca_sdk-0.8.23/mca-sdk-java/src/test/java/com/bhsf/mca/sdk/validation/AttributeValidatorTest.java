package com.bhsf.mca.sdk.validation;

import com.bhsf.mca.sdk.config.MCAConfig;
import com.bhsf.mca.sdk.exceptions.ValidationException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AttributeValidatorTest {

    @Test
    public void testValidInternalRegressionModel_StrictMode() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("test-service")
            .modelId("mdl-001")
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);
        ValidationResult result = validator.validate();

        assertTrue(result.isValid());
        assertTrue(result.getErrors().isEmpty());
    }

    @Test
    public void testMissingRequiredAttribute_StrictMode_ShouldThrow() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("test-service")
            // Missing modelId
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            validator.validate();
        });

        assertTrue(ex.getMessage().contains("model.id"));
        assertTrue(ex.getMissingFields().contains("model.id"));
    }

    @Test
    public void testMissingRequiredAttribute_PermissiveMode_ReturnsResult() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("test-service")
            // Missing modelId
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, false);
        ValidationResult result = validator.validate();

        assertFalse(result.isValid());
        assertTrue(result.getMissingFields().contains("model.id"));
        assertTrue(result.getErrors().size() > 0);
    }

    @Test
    public void testEmptyAttribute_ShouldFail() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("")  // Empty string
            .modelId("mdl-001")
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);

        assertThrows(ValidationException.class, () -> {
            validator.validate();
        });
    }

    @Test
    public void testAttributeTooLong_ShouldFail() {
        // Create a string longer than 1024 characters
        String longString = "a".repeat(1025);

        MCAConfig config = new MCAConfig.Builder()
            .serviceName(longString)
            .modelId("mdl-001")
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);

        assertThrows(ValidationException.class, () -> {
            validator.validate();
        });
    }

    @Test
    public void testInvalidCharacters_ShouldFail() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("service@invalid")  // @ is not allowed
            .modelId("mdl-001")
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);

        assertThrows(ValidationException.class, () -> {
            validator.validate();
        });
    }

    @Test
    public void testValidCharacters_AlphanumericAndSpecial() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("test-service_123.v1")  // Valid chars: alphanumeric, dash, underscore, dot
            .modelId("mdl-001")
            .modelVersion("1.0.0")
            .teamName("ml-team")
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);
        ValidationResult result = validator.validate();

        assertTrue(result.isValid());
    }

    @Test
    public void testVendorModel_StrictMode() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("vendor-service")
            .teamName("integration-team")
            // Note: vendorName not yet in MCAConfig, will be added in story 1.23.3
            .modelCategory("vendor")
            .modelType("classification")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);

        // Should throw because vendor.name is missing (not yet in MCAConfig)
        assertThrows(ValidationException.class, () -> {
            validator.validate();
        });
    }

    @Test
    public void testNullConfig_ShouldThrow() {
        assertThrows(IllegalArgumentException.class, () -> {
            new AttributeValidator(null, true);
        });
    }

    @Test
    public void testInvalidTaxonomy_ShouldThrow() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("test-service")
            .modelCategory("invalid")
            .modelType("regression")
            .build();

        assertThrows(IllegalArgumentException.class, () -> {
            new AttributeValidator(config, true);
        });
    }

    @Test
    public void testMultipleMissingFields_ErrorMessage() {
        MCAConfig config = new MCAConfig.Builder()
            .serviceName("test-service")
            // Missing modelId, modelVersion, teamName
            .modelCategory("internal")
            .modelType("regression")
            .build();

        AttributeValidator validator = new AttributeValidator(config, true);

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            validator.validate();
        });

        // Should list all missing fields
        assertTrue(ex.getMissingFields().size() >= 2);
        assertTrue(ex.getMessage().contains("model.id"));
    }
}
