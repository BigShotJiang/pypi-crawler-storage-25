package com.bhsf.mca.sdk.security;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.cert.X509Certificate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for CertificateManager.
 */
public class CertificateManagerTest {

    // Sample self-signed certificate for testing (PEM format)
    private static final String TEST_CERT_PEM =
        "-----BEGIN CERTIFICATE-----\n" +
        "MIICljCCAX4CCQCKmI7cFNnCBDANBgkqhkiG9w0BAQsFADANMQswCQYDVQQGEwJV\n" +
        "UzAeFw0yNDAzMzEwMDAwMDBaFw0yNTAzMzEwMDAwMDBaMA0xCzAJBgNVBAYTAlVT\n" +
        "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu1SU1LfVLPHCozMxH2Mo\n" +
        "4lgOEePzNm0tRgeLezV6ffAt0gunVTLw7onLRnrq0/IzW7yWR7QkrmBL7jTKEn5u\n" +
        "+qKhbwKfBstIs+bMY2Zkp18gnTxKLxoS2tFczGkPLPgizskuemMghRniWaoLcyeh\n" +
        "kd3qqGElvW/VDL5AaWTg0nLVkjRo9z+40RQzuVaE8AkAFmxZzow3x+VJYKdjykkJ\n" +
        "0iT9wCS0DRTXu269V264Vf/3jvredZiKRkgwlL9xNAwxXFg0x/XFw005UWVRIkdg\n" +
        "cKWTjpBP2dPwVZ4WWC+9aGVd+Gyn1o0CLelf4rEjGoXbAAEgAqeGUxrcIlbjXfbc\n" +
        "mwIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCw6bCVLH7y9XmPoWG91cVU0Kh9wZRu\n" +
        "xAoRgLKkAILVMUvg8mqLlpL3HfDDlPY4JVCPVVIx2CfNXdCPQ5lkTZ4gC/TkExfh\n" +
        "FpGxhUpJLKVYX8T8HvYA0kCVqhXxZ8SyG8rLGQjGdECQ+Ug3wLcj3vH6rV0zlzCo\n" +
        "wMVB1cAEXJ3gLKB5FgZbOBxF8HdULLFqRJcHjNLm3G2xP4i3nLCCvLmwVGYd8wgA\n" +
        "C+DGxYvVT+WXKGq7hK5LnkQQNtW8YJGc8xLFzBNWb1sZVWKBLFVGsVV2KKhH9SZk\n" +
        "fMbkH4OVH3FkWFg+0ZHcHmXQ6aqBp3blFPNEHKdUhKQE9MEkJnj7xBUA\n" +
        "-----END CERTIFICATE-----";

    // Sample RSA private key for testing (PEM format, PKCS8)
    private static final String TEST_KEY_PEM =
        "-----BEGIN PRIVATE KEY-----\n" +
        "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC7VJTUt9Us8cKj\n" +
        "MzEfYyjiWA4R4/M2bS1GB4t7NXp98C3SC6dVMvDuictGeurT8jNbvJZHtCSuYEvu\n" +
        "NMoSfm76oqFvAp8Gy0iz5sxjZmSnXyCdPEovGhLa0VzMaQ8s+CLOyS56YyCFGeJZ\n" +
        "qgtzJ6GR3eqoYSW9b9UMvkBpZODSctWSNGj3P7jRFDO5VoTwCQAWbFnOjDfH5Ulg\n" +
        "p2PKSQnSJP3AJLQNFNe7br1XbrhV//eO+t51mIpGSDCUv3E0DDFcWDTH9cXDTTlR\n" +
        "ZVEiR2BwpZOOkE/Z0/BVnhZYL71oZV34bKfWjQIt6V/isSMahdEAAQACp4ZTGtwi\n" +
        "VuNd9tybAgMBAAECggEBAKIBixFvJKAZd0RxHU8g3KXRCXxBYJfCQK2XYWkRyuW+\n" +
        "hKjDhNkF9tPcXAWjZpN0RCpU3pVgFvLSEoX3bPqx9qSJEUWJpHR3CqYvTt0D5RfR\n" +
        "jnMw2BbzJPYzLMaLDvLgQKW9EiKLDLJQJhDqQ3Kd6vXhFKFqsXELfpWJNMZn3Lqp\n" +
        "FcXVwDxEnfRJtMBfpWbhCYjDiSHGVXE1FxQeM0i7J3LgfJZpJ6RqmXK9vfCLJvFb\n" +
        "hF6rYAXPU8F6JEGVhJ3KRfJBQmvJQ3FhJQQh3NxLGEQrGCkSvVHQCMDvQOZDXsj7\n" +
        "cVhNJ3CPlQqmQMQ8pFqrGMb3vLRxCMk0GjSLdA9qz0ECgYEA7S6wCE/2F0pTGCNm\n" +
        "W/1YXScvBn+n5oJMG2PYQ7dXQGhHI4dR9i0YU2Qb4RqvNZVgKAhBzGDPXhLzN4Qj\n" +
        "EoLqLDCE3hLfC8q6eU8p3RG8FqNVXpWmYKJLCXXBZGqYJZvLGYQ6nF8xQWCPNNb2\n" +
        "eB3hCVPKQqGNu+jM8cQnFSsCgYEAysZhFqLvLMJz4LCLsG0BEw5MsVNdFJLPnQgP\n" +
        "hCQGdZ3VQfJXy+QXYqNDVE0L0EpVZfJBB3hB7CUPQBFpLjKUVCmYiLTfQqAqNnq3\n" +
        "x7HqNYqW8P7fHkfFhQMXJcTCQXbM3kOQPqBXFvmMEqJfKCGXJhKXVkMnR8VL0LNb\n" +
        "1aG5gCECgYAMB8VQdlhZDJYFM8cFxL0Q3PNf3jNQF0jqr1YPjKKqQXCe8P0JZGdF\n" +
        "XR5PjLhkVHqpUJKF7tQMCLb2bO4EVhJKq8tGKxNXhKOEQQ0NQqxPVQmQ0VKFjVhN\n" +
        "5F1BZCPCVhHcW3xJQmQJKqYqNhLqLpGHxQGpQjBfHWNLQcXLqQKBgB7nGmhLB3gJ\n" +
        "xKqQqJMXGQ9YPXLGRJvUTLfJYQDKQGJGYQF3F9qCPJDQHqLGPFJKMQqLqjLqCPQH\n" +
        "hQMaJGKHKqYPqLCqLaHKhQqKQKBgHQmPQK3q+HBJCQqMQ3PBqQJQKBJqQPQKHKqL\n" +
        "QPQKBqQJQKBqQPQKHQKBgH3QPLqQKB3QP\n" +
        "-----END PRIVATE KEY-----";

    @Test
    public void testConstructor() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        assertNotNull(manager);
    }

    @Test
    public void testLoadCertificate_FileNotFound() {
        CertificateManager manager = new CertificateManager(
            "/nonexistent/client.crt",
            "/nonexistent/client.key",
            "/nonexistent/ca.crt"
        );

        CertificateException exception = assertThrows(
            CertificateException.class,
            () -> manager.loadCertificate("/nonexistent/cert.crt")
        );
        assertTrue(exception.getMessage().contains("not found"));
    }

    @Test
    public void testLoadCertificate_NullPath() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        CertificateException exception = assertThrows(
            CertificateException.class,
            () -> manager.loadCertificate(null)
        );
        assertTrue(exception.getMessage().contains("cannot be null"));
    }

    @Test
    public void testLoadCertificate_EmptyPath() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        CertificateException exception = assertThrows(
            CertificateException.class,
            () -> manager.loadCertificate("")
        );
        assertTrue(exception.getMessage().contains("cannot be null or empty"));
    }

    @Test
    public void testLoadCertificate_ValidPEM(@TempDir Path tempDir) throws IOException, CertificateException {
        // Create temporary certificate file
        Path certFile = tempDir.resolve("test.crt");
        Files.writeString(certFile, TEST_CERT_PEM);

        CertificateManager manager = new CertificateManager(
            certFile.toString(),
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        X509Certificate cert = manager.loadCertificate(certFile.toString());

        assertNotNull(cert);
        assertEquals("X.509", cert.getType());
    }

    @Test
    public void testLoadCertificate_InvalidPEM(@TempDir Path tempDir) throws IOException {
        // Create temporary file with invalid content
        Path certFile = tempDir.resolve("invalid.crt");
        Files.writeString(certFile, "This is not a valid certificate");

        CertificateManager manager = new CertificateManager(
            certFile.toString(),
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        CertificateException exception = assertThrows(
            CertificateException.class,
            () -> manager.loadCertificate(certFile.toString())
        );
        assertTrue(exception.getMessage().contains("Failed to load certificate"));
    }

    @Test
    public void testLoadPrivateKey_FileNotFound() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/nonexistent/client.key",
            "/path/to/ca.crt"
        );

        CertificateException exception = assertThrows(
            CertificateException.class,
            () -> manager.loadPrivateKey("/nonexistent/key.key")
        );
        assertTrue(exception.getMessage().contains("not found"));
    }

    @Test
    public void testLoadPrivateKey_NullPath() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        CertificateException exception = assertThrows(
            CertificateException.class,
            () -> manager.loadPrivateKey(null)
        );
        assertTrue(exception.getMessage().contains("cannot be null"));
    }

    @Test
    public void testGettersBeforeLoad() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        assertThrows(IllegalStateException.class, manager::getClientCertificate);
        assertThrows(IllegalStateException.class, manager::getClientKey);
        assertThrows(IllegalStateException.class, manager::getCACertificate);
    }

    @Test
    public void testHotReloadNotActiveByDefault() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        assertFalse(manager.isHotReloadActive());
    }

    @Test
    public void testStopHotReloadWhenNotActive() {
        CertificateManager manager = new CertificateManager(
            "/path/to/client.crt",
            "/path/to/client.key",
            "/path/to/ca.crt"
        );

        // Should not throw
        assertDoesNotThrow(manager::stopHotReload);
    }
}
