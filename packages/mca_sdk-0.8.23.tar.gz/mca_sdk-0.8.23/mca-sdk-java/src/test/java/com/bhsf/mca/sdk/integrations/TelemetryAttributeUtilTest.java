package com.bhsf.mca.sdk.integrations;

import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
import io.opentelemetry.sdk.testing.exporter.InMemorySpanExporter;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for TelemetryAttributeUtil.
 */
public class TelemetryAttributeUtilTest {

    @Test
    public void testDefensiveCopyWithNull() {
        Map<String, Object> result = TelemetryAttributeUtil.defensiveCopy(null);
        assertNull(result, "Defensive copy of null should return null");
    }

    @Test
    public void testDefensiveCopyCreatesNewMap() {
        Map<String, Object> original = new HashMap<>();
        original.put("key", "value");

        Map<String, Object> copy = TelemetryAttributeUtil.defensiveCopy(original);

        assertNotNull(copy);
        assertEquals("value", copy.get("key"));

        // Modify original - copy should not be affected
        original.put("key2", "value2");
        assertFalse(copy.containsKey("key2"), "Copy should not reflect changes to original");
    }

    @Test
    public void testDefensiveCopyPreventsConcurrentModificationException() throws InterruptedException {
        Map<String, Object> sharedMap = new HashMap<>();
        sharedMap.put("key1", "value1");
        sharedMap.put("key2", "value2");

        java.util.concurrent.CyclicBarrier barrier = new java.util.concurrent.CyclicBarrier(2);
        CountDownLatch latch = new CountDownLatch(2);
        AtomicBoolean exceptionThrown = new AtomicBoolean(false);

        // Thread 1: Create defensive copy
        Thread t1 = new Thread(() -> {
            try {
                barrier.await(); // Synchronize start
                Map<String, Object> copy = TelemetryAttributeUtil.defensiveCopy(sharedMap);
                // Even if CME occurs during copy, it should be caught and return empty map
                assertNotNull(copy);
            } catch (ConcurrentModificationException e) {
                exceptionThrown.set(true);
            } catch (Exception e) {
                // Ignore barrier exceptions
            } finally {
                latch.countDown();
            }
        });

        // Thread 2: Modify original map
        Thread t2 = new Thread(() -> {
            try {
                barrier.await(); // Synchronize start
                sharedMap.put("key3", "value3");
                sharedMap.remove("key1");
            } catch (Exception e) {
                // Ignore barrier exceptions
            } finally {
                latch.countDown();
            }
        });

        t1.start();
        t2.start();

        assertTrue(latch.await(1, TimeUnit.SECONDS));
        assertFalse(exceptionThrown.get(), "Defensive copy should catch and handle ConcurrentModificationException");
    }

    @Test
    public void testBuildAttributesWithPrimitiveTypes() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("string", "value");
        attrs.put("long", 123L);
        attrs.put("int", 456);
        attrs.put("double", 78.9);
        attrs.put("float", 10.11f);
        attrs.put("boolean", true);

        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        assertEquals("value", result.get(io.opentelemetry.api.common.AttributeKey.stringKey("string")));
        assertEquals(123L, result.get(io.opentelemetry.api.common.AttributeKey.longKey("long")));
        assertEquals(456L, result.get(io.opentelemetry.api.common.AttributeKey.longKey("int")));
        assertEquals(78.9, result.get(io.opentelemetry.api.common.AttributeKey.doubleKey("double")));
        assertEquals(10.11, result.get(io.opentelemetry.api.common.AttributeKey.doubleKey("float")), 0.001);
        assertEquals(true, result.get(io.opentelemetry.api.common.AttributeKey.booleanKey("boolean")));
    }

    @Test
    public void testBuildAttributesWithStringArray() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("tags", new String[]{"tag1", "tag2", "tag3"});

        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        List<String> tags = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("tags"));
        assertNotNull(tags);
        assertEquals(3, tags.size());
        assertTrue(tags.contains("tag1"));
        assertTrue(tags.contains("tag2"));
        assertTrue(tags.contains("tag3"));
    }

    @Test
    public void testBuildAttributesWithStringList() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("roles", Arrays.asList("admin", "user", "guest"));

        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        List<String> roles = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("roles"));
        assertNotNull(roles);
        assertEquals(3, roles.size());
        assertTrue(roles.contains("admin"));
    }

    @Test
    public void testBuildAttributesWithMixedList() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("mixed", Arrays.asList(1, 2, 3));

        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        // Should convert non-String list to String array
        List<String> mixed = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("mixed"));
        assertNotNull(mixed);
        assertEquals(3, mixed.size());
        assertTrue(mixed.contains("1"));
        assertTrue(mixed.contains("2"));
    }

    @Test
    public void testBuildAttributesWithCollection() {
        Map<String, Object> attrs = new HashMap<>();
        Set<String> set = new HashSet<>(Arrays.asList("a", "b", "c"));
        attrs.put("set", set);

        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        List<String> setValues = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("set"));
        assertNotNull(setValues);
        assertEquals(3, setValues.size());
    }

    @Test
    public void testBuildAttributesWithNull() {
        Attributes result = TelemetryAttributeUtil.buildAttributes(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testBuildAttributesWithNullValues() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("null_value", null);
        attrs.put("valid", "value");

        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        assertNull(result.get(io.opentelemetry.api.common.AttributeKey.stringKey("null_value")));
        assertEquals("value", result.get(io.opentelemetry.api.common.AttributeKey.stringKey("valid")));
    }

    @Test
    public void testBuildAttributesWithUnsupportedType() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("object", new Object());
        attrs.put("valid", "value");

        // Should not throw, just log warning and ignore unsupported type
        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        assertEquals("value", result.get(io.opentelemetry.api.common.AttributeKey.stringKey("valid")));
    }

    @Test
    public void testAddSpanAttributeWithPrimitiveTypes() {
        InMemorySpanExporter spanExporter = InMemorySpanExporter.create();
        SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                .build();
        Span span = tracerProvider.get("test").spanBuilder("test").startSpan();

        TelemetryAttributeUtil.addSpanAttribute(span, "string", "value");
        TelemetryAttributeUtil.addSpanAttribute(span, "long", 123L);
        TelemetryAttributeUtil.addSpanAttribute(span, "boolean", true);

        span.end();
        tracerProvider.forceFlush();

        // Verify span was created with attributes
        assertEquals(1, spanExporter.getFinishedSpanItems().size());

        tracerProvider.close();
    }

    @Test
    public void testAddSpanAttributeWithNullSpan() {
        // Should not throw
        assertDoesNotThrow(() -> {
            TelemetryAttributeUtil.addSpanAttribute(null, "key", "value");
        });
    }

    @Test
    public void testAddSpanAttributesWithMap() {
        InMemorySpanExporter spanExporter = InMemorySpanExporter.create();
        SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                .build();
        Span span = tracerProvider.get("test").spanBuilder("test").startSpan();

        Map<String, Object> attrs = new HashMap<>();
        attrs.put("key1", "value1");
        attrs.put("key2", 123L);

        TelemetryAttributeUtil.addSpanAttributes(span, attrs);

        span.end();
        tracerProvider.forceFlush();

        assertEquals(1, spanExporter.getFinishedSpanItems().size());

        tracerProvider.close();
    }

    @Test
    public void testBuildAttributesWithMixedTypeList() {
        Map<String, Object> attrs = new HashMap<>();
        // Mix of String, Integer, Double, Boolean, and null
        attrs.put("mixed", Arrays.asList("string", 123, 45.6, true, null));

        // Should not throw ClassCastException or NPE
        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        List<String> mixed = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("mixed"));
        assertNotNull(mixed);
        assertEquals(5, mixed.size());
        assertTrue(mixed.contains("string"));
        assertTrue(mixed.contains("123"));
        assertTrue(mixed.contains("45.6"));
        assertTrue(mixed.contains("true"));
        assertTrue(mixed.contains("null")); // String::valueOf converts null to "null"
    }

    @Test
    public void testBuildAttributesWithNullElementsInList() {
        Map<String, Object> attrs = new HashMap<>();
        List<String> listWithNulls = new ArrayList<>();
        listWithNulls.add("value1");
        listWithNulls.add(null);
        listWithNulls.add("value2");
        attrs.put("list_with_nulls", listWithNulls);

        // Should not throw NPE - String::valueOf handles null
        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        List<String> list = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("list_with_nulls"));
        assertNotNull(list);
        assertEquals(3, list.size());
        assertEquals("value1", list.get(0));
        assertEquals("null", list.get(1)); // null converted to "null"
        assertEquals("value2", list.get(2));
    }

    @Test
    public void testBuildAttributesWithEmptyList() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("empty_list", Collections.emptyList());

        // Should handle empty list gracefully
        Attributes result = TelemetryAttributeUtil.buildAttributes(attrs);

        assertNotNull(result);
        List<String> list = result.get(io.opentelemetry.api.common.AttributeKey.stringArrayKey("empty_list"));
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testAddSpanAttributeWithMixedTypeList() {
        InMemorySpanExporter spanExporter = InMemorySpanExporter.create();
        SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(spanExporter))
                .build();
        Span span = tracerProvider.get("test").spanBuilder("test").startSpan();

        // Mix of types including null
        TelemetryAttributeUtil.addSpanAttribute(span, "mixed", Arrays.asList("str", 123, null));

        span.end();
        tracerProvider.forceFlush();

        assertEquals(1, spanExporter.getFinishedSpanItems().size());

        tracerProvider.close();
    }

    @Test
    public void testDefensiveCopyReturnsEmptyMapOnCME() {
        // This is a white-box test verifying the behavior when CME is caught
        // In practice, CME during HashMap constructor is rare but possible

        // Create a map that will be concurrently modified
        Map<String, Object> concurrentMap = new java.util.concurrent.ConcurrentHashMap<>();
        concurrentMap.put("key1", "value1");

        // Defensive copy should always return a map (empty on CME)
        Map<String, Object> copy = TelemetryAttributeUtil.defensiveCopy(concurrentMap);
        assertNotNull(copy, "Defensive copy should never return null on CME");
    }

    private static class AtomicBoolean {
        private volatile boolean value;

        public AtomicBoolean(boolean initialValue) {
            this.value = initialValue;
        }

        public void set(boolean newValue) {
            this.value = newValue;
        }

        public boolean get() {
            return value;
        }
    }
}
