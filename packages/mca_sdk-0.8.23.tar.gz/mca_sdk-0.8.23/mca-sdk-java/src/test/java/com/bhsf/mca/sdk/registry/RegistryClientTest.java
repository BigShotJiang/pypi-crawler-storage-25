package com.bhsf.mca.sdk.registry;

import com.bhsf.mca.sdk.exceptions.RegistryAuthException;
import com.bhsf.mca.sdk.exceptions.RegistryConfigNotFoundException;
import com.bhsf.mca.sdk.exceptions.RegistryConnectionException;
import com.bhsf.mca.sdk.exceptions.RegistryException;
import com.bhsf.mca.sdk.registry.models.ModelConfig;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for RegistryClient.
 */
public class RegistryClientTest {

    private MockWebServer mockServer;
    private RegistryClient client;

    @BeforeEach
    public void setUp() throws IOException {
        mockServer = new MockWebServer();
        mockServer.start();
    }

    @AfterEach
    public void tearDown() throws IOException {
        if (client != null) {
            client.shutdown();
        }
        mockServer.shutdown();
    }

    @Test
    public void testFetchModelConfigSuccess() throws InterruptedException {
        String responseJson = "{" +
                "\"service_name\":\"test-service\"," +
                "\"model_id\":\"mdl-001\"," +
                "\"model_version\":\"2.0.0\"," +
                "\"team_name\":\"test-team\"," +
                "\"model_type\":\"regression\"," +
                "\"model_category\":\"internal\"" +
                "}";

        mockServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .setBody(responseJson)
                .addHeader("Content-Type", "application/json"));

        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .build();

        ModelConfig config = client.fetchModelConfig("mdl-001", "latest");

        assertNotNull(config);
        assertEquals("test-service", config.getServiceName());
        assertEquals("mdl-001", config.getModelId());
        assertEquals("2.0.0", config.getModelVersion());
        assertEquals("test-team", config.getTeamName());
        assertEquals("regression", config.getModelType());
        assertEquals("internal", config.getModelCategory());

        // Verify request
        RecordedRequest request = mockServer.takeRequest();
        assertEquals("/api/v1/models/mdl-001?version=latest", request.getPath());
    }

    @Test
    public void testFetchModelConfigWithToken() throws InterruptedException {
        mockServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .setBody("{" +
                        "\"service_name\":\"test-service\"," +
                        "\"model_id\":\"mdl-001\"," +
                        "\"model_version\":\"1.0.0\"," +
                        "\"team_name\":\"test-team\"," +
                        "\"model_type\":\"regression\"," +
                        "\"model_category\":\"internal\"" +
                        "}"));

        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .token("test-token-12345")
                .build();

        client.fetchModelConfig("mdl-001", "latest");

        // Verify authorization header
        RecordedRequest request = mockServer.takeRequest();
        assertEquals("Bearer test-token-12345", request.getHeader("Authorization"));
    }

    @Test
    public void testFetchModelConfigNotFound() {
        mockServer.enqueue(new MockResponse()
                .setResponseCode(404)
                .setBody("Model not found"));

        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .build();

        assertThrows(RegistryConfigNotFoundException.class, () -> {
            client.fetchModelConfig("nonexistent", "latest");
        });
    }

    @Test
    public void testFetchModelConfigUnauthorized() {
        mockServer.enqueue(new MockResponse()
                .setResponseCode(401)
                .setBody("Unauthorized"));

        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .token("invalid-token")
                .build();

        assertThrows(RegistryAuthException.class, () -> {
            client.fetchModelConfig("mdl-001", "latest");
        });
    }

    @Test
    public void testFetchModelConfigServerError() {
        mockServer.enqueue(new MockResponse()
                .setResponseCode(500)
                .setBody("Internal server error"));

        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .build();

        assertThrows(RegistryConnectionException.class, () -> {
            client.fetchModelConfig("mdl-001", "latest");
        });
    }

    @Test
    public void testCacheHit() {
        mockServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .setBody("{" +
                        "\"service_name\":\"test-service\"," +
                        "\"model_id\":\"mdl-001\"," +
                        "\"model_version\":\"1.0.0\"," +
                        "\"team_name\":\"test-team\"," +
                        "\"model_type\":\"regression\"," +
                        "\"model_category\":\"internal\"" +
                        "}"));

        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .cacheTtlSecs(600)
                .build();

        // First fetch - should hit server
        ModelConfig config1 = client.fetchModelConfig("mdl-001", "latest");
        assertNotNull(config1);

        // Second fetch - should hit cache (no server request)
        ModelConfig config2 = client.fetchModelConfig("mdl-001", "latest");
        assertNotNull(config2);

        // Only one request should have been made
        assertEquals(1, mockServer.getRequestCount());
    }

    @Test
    public void testHttpsEnforcementForNonLocalhost() {
        assertThrows(RegistryException.class, () -> {
            RegistryClient.builder()
                    .url("http://registry.example.com")
                    .build();
        });
    }

    @Test
    public void testHttpAllowedForLocalhost() {
        // Should not throw
        client = RegistryClient.builder()
                .url("http://localhost:8080")
                .build();
        assertNotNull(client);
    }

    @Test
    public void testHttpAllowedFor127001() {
        // Should not throw
        client = RegistryClient.builder()
                .url("http://127.0.0.1:8080")
                .build();
        assertNotNull(client);
    }

    @Test
    public void testHttpsAcceptedForRemoteHost() {
        // Should not throw
        client = RegistryClient.builder()
                .url("https://registry.example.com")
                .build();
        assertNotNull(client);
    }

    @Test
    public void testBothTokenAndGcpAuthThrowsException() {
        assertThrows(RegistryException.class, () -> {
            RegistryClient.builder()
                    .url("https://registry.example.com")
                    .token("test-token")
                    .useGcpAuth(true)
                    .build();
        });
    }

    @Test
    public void testNullModelIdThrowsException() {
        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .build();

        assertThrows(IllegalArgumentException.class, () -> {
            client.fetchModelConfig(null, "latest");
        });
    }

    @Test
    public void testEmptyModelIdThrowsException() {
        client = RegistryClient.builder()
                .url(mockServer.url("/").toString())
                .build();

        assertThrows(IllegalArgumentException.class, () -> {
            client.fetchModelConfig("", "latest");
        });
    }

    @Test
    public void testMissingUrlThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            RegistryClient.builder().build();
        });
    }
}
