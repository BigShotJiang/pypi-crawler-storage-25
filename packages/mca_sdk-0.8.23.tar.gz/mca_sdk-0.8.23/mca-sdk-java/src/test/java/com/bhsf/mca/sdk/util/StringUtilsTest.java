package com.bhsf.mca.sdk.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for StringUtils.
 */
class StringUtilsTest {

    // maskCredential(String) Tests

    @Test
    void testMaskCredentialNull() {
        assertEquals("", StringUtils.maskCredential(null));
    }

    @Test
    void testMaskCredentialEmpty() {
        assertEquals("", StringUtils.maskCredential(""));
    }

    @Test
    void testMaskCredentialShort() {
        assertEquals("****", StringUtils.maskCredential("abc"));
        assertEquals("****", StringUtils.maskCredential("1234"));
    }

    @Test
    void testMaskCredentialLong() {
        assertEquals("***2345", StringUtils.maskCredential("my-secret-token-12345"));
        assertEquals("***MPLE", StringUtils.maskCredential("AKIAIOSFODNN7EXAMPLE"));
    }

    // maskCredential(String, String) Tests

    @Test
    void testMaskCredentialInText() {
        String text = "Error: Invalid token my-secret-token-12345 was rejected";
        String credential = "my-secret-token-12345";

        String result = StringUtils.maskCredential(text, credential);

        assertFalse(result.contains(credential));
        assertTrue(result.contains("***2345"));
    }

    @Test
    void testMaskCredentialInTextNull() {
        assertNull(StringUtils.maskCredential(null, "credential"));
        assertEquals("text", StringUtils.maskCredential("text", null));
    }

    // sanitizeCredentials Tests

    @Test
    void testSanitizeCredentialsNull() {
        assertNull(StringUtils.sanitizeCredentials(null));
    }

    @Test
    void testSanitizeAwsKey() {
        String awsKey = "AKIAIOSFODNN7EXAMPLE";
        String text = "Failed to authenticate with AWS key " + awsKey;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains(awsKey));
        assertTrue(result.contains("AKIA"));
        assertTrue(result.contains("***"));
        assertTrue(result.contains("MPLE"));
    }

    @Test
    void testSanitizeAsiaKey() {
        String asiaKey = "ASIAIOSFODNN7EXAMPLE";
        String text = "Temporary AWS key: " + asiaKey;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains(asiaKey));
        assertTrue(result.contains("ASIA"));
        assertTrue(result.contains("***"));
    }

    @Test
    void testSanitizeGcpKey() {
        String gcpKey = "AIzaSyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q";
        String text = "Invalid GCP API key: " + gcpKey;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains(gcpKey));
        assertTrue(result.contains("AIzaSy"));
        assertTrue(result.contains("***"));
        assertTrue(result.contains("P6Q"));
    }

    @Test
    void testSanitizeJwtToken() {
        String jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
        String text = "Token validation failed: " + jwt;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains(jwt));
        assertTrue(result.contains("eyJ"));
        assertTrue(result.contains("***"));
    }

    @Test
    void testSanitizeBearerToken() {
        String bearer = "Bearer abc123token456xyz789012345";
        String text = "Authorization header: " + bearer;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains("abc123token456xyz789012345"));
        assertTrue(result.contains("Bearer"));
        assertTrue(result.contains("***"));
    }

    @Test
    void testSanitizeBearerTokenCaseInsensitive() {
        String bearer = "BEARER abc123token456xyz789012345";
        String text = "Auth failed: " + bearer;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains("abc123token456xyz789012345"));
        assertTrue(result.contains("Bearer") || result.contains("BEARER"));
    }

    @Test
    void testSanitizeMultipleCredentials() {
        String awsKey = "AKIAIOSFODNN7EXAMPLE";
        String gcpKey = "AIzaSyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q";
        String text = "AWS: " + awsKey + ", GCP: " + gcpKey;

        String result = StringUtils.sanitizeCredentials(text);

        assertFalse(result.contains(awsKey));
        assertFalse(result.contains(gcpKey));
        assertTrue(result.contains("AKIA"));
        assertTrue(result.contains("AIzaSy"));
    }

    // containsCredential Tests

    @Test
    void testContainsCredentialNull() {
        assertFalse(StringUtils.containsCredential(null));
    }

    @Test
    void testContainsCredentialAwsKey() {
        assertTrue(StringUtils.containsCredential("Error with AKIAIOSFODNN7EXAMPLE"));
        assertTrue(StringUtils.containsCredential("Temp key ASIAIOSFODNN7EXAMPLE"));
    }

    @Test
    void testContainsCredentialGcpKey() {
        assertTrue(StringUtils.containsCredential(
            "API key AIzaSyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q invalid"));
    }

    @Test
    void testContainsCredentialJwt() {
        assertTrue(StringUtils.containsCredential(
            "Token eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abc123 expired"));
    }

    @Test
    void testContainsCredentialBearer() {
        assertTrue(StringUtils.containsCredential("Bearer abc123token456xyz789012345"));
    }

    @Test
    void testContainsCredentialNone() {
        assertFalse(StringUtils.containsCredential("This is a safe error message"));
        assertFalse(StringUtils.containsCredential("No credentials here"));
    }

    // truncate Tests

    @Test
    void testTruncateNull() {
        assertNull(StringUtils.truncate(null, 10));
    }

    @Test
    void testTruncateShortString() {
        String text = "Short";
        assertEquals(text, StringUtils.truncate(text, 10));
    }

    @Test
    void testTruncateLongString() {
        String text = "This is a very long string that needs truncation";
        String result = StringUtils.truncate(text, 20);

        assertEquals(20, result.length());
        assertTrue(result.endsWith("..."));
        assertFalse(result.contains("truncation"));
    }

    @Test
    void testTruncateExactLength() {
        String text = "Exactly ten";
        assertEquals(text, StringUtils.truncate(text, text.length()));
    }

    @Test
    void testTruncateVeryShortLimit() {
        String result = StringUtils.truncate("Long text", 2);
        assertEquals("...", result);

        result = StringUtils.truncate("Long text", 3);
        assertEquals("...", result);
    }

    @Test
    void testTruncateBoundary() {
        String text = "ABCDEFGHIJ";
        String result = StringUtils.truncate(text, 7);

        assertEquals(7, result.length());
        assertEquals("ABCD...", result);
    }
}
