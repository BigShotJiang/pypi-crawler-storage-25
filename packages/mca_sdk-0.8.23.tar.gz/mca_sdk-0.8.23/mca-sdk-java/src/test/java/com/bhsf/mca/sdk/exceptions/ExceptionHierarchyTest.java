package com.bhsf.mca.sdk.exceptions;

import com.bhsf.mca.sdk.resilience.ResilienceException;
import com.bhsf.mca.sdk.security.CertificateException;
import com.bhsf.mca.sdk.security.CertificateExpiredException;
import com.bhsf.mca.sdk.security.CertificateLoadException;
import com.bhsf.mca.sdk.security.CertificateValidationException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for exception hierarchy.
 *
 * <p>Verifies that all SDK exceptions follow the proper inheritance structure
 * and that catching MCAException catches all runtime SDK exceptions.
 */
class ExceptionHierarchyTest {

    @Test
    void testMCAExceptionExtendsRuntimeException() {
        MCAException exception = new MCAException("Test");
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testConfigurationExceptionExtendsMCAException() {
        ConfigurationException exception = new ConfigurationException("Test");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testConfigNotFoundExceptionExtendsMCAException() {
        ConfigNotFoundException exception = new ConfigNotFoundException("Test");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testBufferingExceptionExtendsMCAException() {
        BufferingException exception = new BufferingException("Test");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testRegistryExceptionExtendsMCAException() {
        RegistryException exception = new RegistryException("Test");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testRegistryConnectionExceptionExtendsRegistryException() {
        RegistryConnectionException exception = new RegistryConnectionException("Test");
        assertTrue(exception instanceof RegistryException);
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testRegistryAuthExceptionExtendsRegistryException() {
        RegistryAuthException exception = new RegistryAuthException("Test");
        assertTrue(exception instanceof RegistryException);
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testRegistryConfigNotFoundExceptionExtendsRegistryException() {
        RegistryConfigNotFoundException exception = new RegistryConfigNotFoundException("Test");
        assertTrue(exception instanceof RegistryException);
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testValidationExceptionExtendsMCAException() {
        ValidationException exception = new ValidationException("Test");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testResilienceExceptionExtendsMCAException() {
        ResilienceException exception = new ResilienceException("Test");
        assertTrue(exception instanceof MCAException);
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testCertificateExceptionIsCheckedException() {
        CertificateException exception = new CertificateException("Test");
        assertTrue(exception instanceof Exception);
        assertFalse(exception instanceof RuntimeException);
        assertFalse(exception instanceof MCAException);
    }

    @Test
    void testCertificateLoadExceptionExtendsCertificateException() {
        CertificateLoadException exception = new CertificateLoadException("Test");
        assertTrue(exception instanceof CertificateException);
        assertTrue(exception instanceof Exception);
        assertFalse(exception instanceof RuntimeException);
    }

    @Test
    void testCertificateValidationExceptionExtendsCertificateException() {
        CertificateValidationException exception = new CertificateValidationException("Test");
        assertTrue(exception instanceof CertificateException);
        assertTrue(exception instanceof Exception);
        assertFalse(exception instanceof RuntimeException);
    }

    @Test
    void testCertificateExpiredExceptionExtendsCertificateException() {
        CertificateExpiredException exception = new CertificateExpiredException("Test");
        assertTrue(exception instanceof CertificateException);
        assertTrue(exception instanceof Exception);
        assertFalse(exception instanceof RuntimeException);
    }

    @Test
    void testCatchingMCAExceptionCatchesAllRuntimeSDKExceptions() {
        // ConfigurationException
        try {
            throw new ConfigurationException("Test");
        } catch (MCAException e) {
            assertEquals("Test", e.getMessage());
        }

        // ConfigNotFoundException
        try {
            throw new ConfigNotFoundException("Test");
        } catch (MCAException e) {
            assertEquals("Test", e.getMessage());
        }

        // BufferingException
        try {
            throw new BufferingException("Test");
        } catch (MCAException e) {
            assertEquals("Test", e.getMessage());
        }

        // RegistryException and subclasses
        try {
            throw new RegistryConnectionException("Test");
        } catch (MCAException e) {
            assertEquals("Test", e.getMessage());
        }

        // ValidationException
        try {
            throw new ValidationException("Test");
        } catch (MCAException e) {
            assertEquals("Test", e.getMessage());
        }

        // ResilienceException
        try {
            throw new ResilienceException("Test");
        } catch (MCAException e) {
            assertEquals("Test", e.getMessage());
        }
    }

    @Test
    void testCertificateExceptionsRequireExplicitHandling() {
        // Certificate exceptions are checked, so they cannot be caught by MCAException
        // This is intentional to force explicit handling of security errors

        assertThrows(Exception.class, () -> {
            throw new CertificateLoadException("Test");
        });
    }

    @Test
    void testExceptionMessagePropagation() {
        String message = "Specific error details";

        assertEquals(message, new MCAException(message).getMessage());
        assertEquals(message, new ConfigurationException(message).getMessage());
        assertEquals(message, new ConfigNotFoundException(message).getMessage());
        assertEquals(message, new BufferingException(message).getMessage());
        assertEquals(message, new RegistryException(message).getMessage());
        assertEquals(message, new ValidationException(message).getMessage());
        assertEquals(message, new ResilienceException(message).getMessage());
        assertEquals(message, new CertificateException(message).getMessage());
        assertEquals(message, new CertificateLoadException(message).getMessage());
        assertEquals(message, new CertificateValidationException(message).getMessage());
        assertEquals(message, new CertificateExpiredException(message).getMessage());
    }
}
