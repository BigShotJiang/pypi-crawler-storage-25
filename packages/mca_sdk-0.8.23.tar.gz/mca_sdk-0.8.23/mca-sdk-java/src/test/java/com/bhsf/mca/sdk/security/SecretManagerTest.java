package com.bhsf.mca.sdk.security;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Tests for SecretManager.
 *
 * <p>Uses Mockito to test GCP Secret Manager integration without requiring
 * actual GCP credentials or network access. The mocked GcpSecretProvider
 * provides full test coverage of the wrapper logic.
 */
public class SecretManagerTest {

    @Test
    public void testConstructor_NullProjectId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new SecretManager(null);
        });
    }

    @Test
    public void testConstructor_EmptyProjectId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new SecretManager("");
        });
    }

    @Test
    public void testConstructor_WhitespaceProjectId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new SecretManager("   ");
        });
    }

    @Test
    public void testConstructor_MissingLibrary() {
        // This test verifies behavior when GCP library is not available
        // The constructor will throw SecurityException with clear message
        try {
            SecretManager manager = new SecretManager("test-project");
            // If we get here, library is available - that's fine
            assertNotNull(manager);
            manager.close();
        } catch (SecurityException e) {
            assertTrue(e.getMessage().contains("GCP Secret Manager library not found") ||
                       e.getMessage().contains("Failed to initialize"));
        }
    }

    @Test
    public void testFetchSecret_WithMock() {
        // Create mock provider
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        when(mockProvider.fetchSecret("test-secret")).thenReturn("secret-value-123");

        // Use package-private constructor for testing
        SecretManager manager = new SecretManager("test-project", mockProvider);

        // Test fetch
        String secret = manager.fetchSecret("test-secret");

        assertEquals("secret-value-123", secret);
        verify(mockProvider, times(1)).fetchSecret("test-secret");
    }

    @Test
    public void testFetchSecret_NullSecretName() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        SecretManager manager = new SecretManager("test-project", mockProvider);

        assertThrows(IllegalArgumentException.class, () -> {
            manager.fetchSecret(null);
        });

        // Verify provider was never called
        verify(mockProvider, never()).fetchSecret(anyString());
    }

    @Test
    public void testFetchSecret_EmptySecretName() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        SecretManager manager = new SecretManager("test-project", mockProvider);

        assertThrows(IllegalArgumentException.class, () -> {
            manager.fetchSecret("");
        });

        verify(mockProvider, never()).fetchSecret(anyString());
    }

    @Test
    public void testFetchSecret_WhitespaceSecretName() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        SecretManager manager = new SecretManager("test-project", mockProvider);

        assertThrows(IllegalArgumentException.class, () -> {
            manager.fetchSecret("   ");
        });

        verify(mockProvider, never()).fetchSecret(anyString());
    }

    @Test
    public void testFetchSecret_ProviderThrowsException() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        when(mockProvider.fetchSecret("missing-secret"))
            .thenThrow(new SecurityException("Failed to access secret from Secret Manager"));

        SecretManager manager = new SecretManager("test-project", mockProvider);

        SecurityException exception = assertThrows(SecurityException.class, () -> {
            manager.fetchSecret("missing-secret");
        });

        assertTrue(exception.getMessage().contains("Failed to access secret"));
        verify(mockProvider, times(1)).fetchSecret("missing-secret");
    }

    @Test
    public void testClose_WithMock() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        SecretManager manager = new SecretManager("test-project", mockProvider);

        // Should not throw
        assertDoesNotThrow(manager::close);

        // Verify close was called on provider
        verify(mockProvider, times(1)).close();
    }

    @Test
    public void testClose_MultipleCallsSafe() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        SecretManager manager = new SecretManager("test-project", mockProvider);

        // Multiple closes should be safe
        assertDoesNotThrow(() -> {
            manager.close();
            manager.close();
        });

        // Verify close was called twice
        verify(mockProvider, times(2)).close();
    }

    @Test
    public void testFetchSecret_MultipleSecrets() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        when(mockProvider.fetchSecret("secret-1")).thenReturn("value-1");
        when(mockProvider.fetchSecret("secret-2")).thenReturn("value-2");
        when(mockProvider.fetchSecret("secret-3")).thenReturn("value-3");

        SecretManager manager = new SecretManager("test-project", mockProvider);

        assertEquals("value-1", manager.fetchSecret("secret-1"));
        assertEquals("value-2", manager.fetchSecret("secret-2"));
        assertEquals("value-3", manager.fetchSecret("secret-3"));

        verify(mockProvider, times(1)).fetchSecret("secret-1");
        verify(mockProvider, times(1)).fetchSecret("secret-2");
        verify(mockProvider, times(1)).fetchSecret("secret-3");
    }

    @Test
    public void testSecurityExceptionMessageIsSafe() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        when(mockProvider.fetchSecret("test-secret"))
            .thenThrow(new SecurityException("Failed to access secret from Secret Manager. Secret: test-secret, Project: test-project"));

        SecretManager manager = new SecretManager("test-project", mockProvider);

        try {
            manager.fetchSecret("test-secret");
            fail("Should have thrown SecurityException");
        } catch (SecurityException e) {
            String message = e.getMessage();

            // Error message should be generic
            assertFalse(message.toLowerCase().contains("password"),
                "Error message should not contain 'password'");

            // Should mention the secret name and project (these are not secret)
            assertTrue(message.contains("test-secret") || message.contains("Failed to access"),
                "Error message should indicate failure");
        }
    }

    @Test
    public void testTryWithResources() {
        GcpSecretProvider mockProvider = Mockito.mock(GcpSecretProvider.class);
        when(mockProvider.fetchSecret("test-secret")).thenReturn("secret-value");

        // Test try-with-resources pattern
        try (SecretManager manager = new SecretManager("test-project", mockProvider)) {
            String secret = manager.fetchSecret("test-secret");
            assertEquals("secret-value", secret);
        }

        // Verify close was called automatically
        verify(mockProvider, times(1)).close();
    }
}
