package com.bhsf.mca.sdk.instrumentation;

import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.data.MetricData;
import io.opentelemetry.sdk.testing.exporter.InMemoryMetricReader;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for MetricRouter.
 */
public class MetricRouterTest {

    private Meter meter;
    private InMemoryMetricReader metricReader;
    private SdkMeterProvider meterProvider;
    private MetricRouter router;

    @BeforeEach
    public void setUp() {
        // Create in-memory metric reader for testing
        metricReader = InMemoryMetricReader.create();
        meterProvider = SdkMeterProvider.builder()
                .registerMetricReader(metricReader)
                .build();

        OpenTelemetrySdk sdk = OpenTelemetrySdk.builder()
                .setMeterProvider(meterProvider)
                .build();

        meter = sdk.getMeter("test-meter");
        router = new MetricRouter(meter);
    }

    @AfterEach
    public void tearDown() {
        if (meterProvider != null) {
            meterProvider.close();
        }
    }

    @Test
    public void testNullMeterThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new MetricRouter(null);
        });

        assertTrue(exception.getMessage().contains("Meter"));
    }

    @Test
    public void testRecordCounter() {
        Attributes attrs = Attributes.builder()
                .put("test_attr", "value")
                .build();

        router.recordMetric("test.counter", 5.0, MetricRouter.InstrumentType.COUNTER, attrs);

        // Force flush
        meterProvider.forceFlush();

        // Verify counter was recorded
        Collection<MetricData> metrics = metricReader.collectAllMetrics();
        assertFalse(metrics.isEmpty(), "Should have recorded metrics");

        boolean foundCounter = false;
        for (MetricData metric : metrics) {
            if (metric.getName().equals("test.counter")) {
                foundCounter = true;
                assertEquals("Custom counter metric: test.counter", metric.getDescription());
                break;
            }
        }
        assertTrue(foundCounter, "Should have found counter metric");
    }

    @Test
    public void testRecordHistogram() {
        Attributes attrs = Attributes.builder()
                .put("test_attr", "value")
                .build();

        router.recordMetric("test.histogram", 42.5, MetricRouter.InstrumentType.HISTOGRAM, attrs);

        // Force flush
        meterProvider.forceFlush();

        // Verify histogram was recorded
        Collection<MetricData> metrics = metricReader.collectAllMetrics();
        assertFalse(metrics.isEmpty(), "Should have recorded metrics");

        boolean foundHistogram = false;
        for (MetricData metric : metrics) {
            if (metric.getName().equals("test.histogram")) {
                foundHistogram = true;
                assertEquals("Custom histogram metric: test.histogram", metric.getDescription());
                break;
            }
        }
        assertTrue(foundHistogram, "Should have found histogram metric");
    }

    @Test
    public void testRecordGauge() {
        Attributes attrs = Attributes.builder()
                .put("test_attr", "value")
                .build();

        router.recordMetric("test.gauge", 100.0, MetricRouter.InstrumentType.GAUGE, attrs);

        // Force flush
        meterProvider.forceFlush();

        // Verify gauge was recorded
        Collection<MetricData> metrics = metricReader.collectAllMetrics();
        assertFalse(metrics.isEmpty(), "Should have recorded metrics");

        boolean foundGauge = false;
        for (MetricData metric : metrics) {
            if (metric.getName().equals("test.gauge")) {
                foundGauge = true;
                assertEquals("Custom gauge metric: test.gauge", metric.getDescription());
                break;
            }
        }
        assertTrue(foundGauge, "Should have found gauge metric");
    }

    @Test
    public void testInstrumentCaching() {
        Attributes attrs = Attributes.empty();

        // Record same metric multiple times
        router.recordMetric("cached.counter", 1.0, MetricRouter.InstrumentType.COUNTER, attrs);
        router.recordMetric("cached.counter", 2.0, MetricRouter.InstrumentType.COUNTER, attrs);
        router.recordMetric("cached.counter", 3.0, MetricRouter.InstrumentType.COUNTER, attrs);

        // Should have 1 cached instrument
        assertEquals(1, router.getCachedInstrumentCount(), "Should cache instrument for reuse");
    }

    @Test
    public void testMultipleInstrumentTypes() {
        Attributes attrs = Attributes.empty();

        router.recordMetric("metric.counter", 1.0, MetricRouter.InstrumentType.COUNTER, attrs);
        router.recordMetric("metric.histogram", 2.0, MetricRouter.InstrumentType.HISTOGRAM, attrs);
        router.recordMetric("metric.gauge", 3.0, MetricRouter.InstrumentType.GAUGE, attrs);

        // Should have 3 cached instruments (one per type)
        assertEquals(3, router.getCachedInstrumentCount());
    }

    @Test
    public void testNullMetricNameThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            router.recordMetric(null, 1.0, MetricRouter.InstrumentType.COUNTER, Attributes.empty());
        });

        assertTrue(exception.getMessage().contains("name"));
    }

    @Test
    public void testEmptyMetricNameThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            router.recordMetric("", 1.0, MetricRouter.InstrumentType.COUNTER, Attributes.empty());
        });

        assertTrue(exception.getMessage().contains("name"));
    }

    @Test
    public void testNullInstrumentTypeThrows() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            router.recordMetric("test.metric", 1.0, null, Attributes.empty());
        });

        assertTrue(exception.getMessage().contains("type"));
    }

    @Test
    public void testNullAttributesUsesEmpty() {
        // Should not throw with null attributes
        router.recordMetric("test.counter", 1.0, MetricRouter.InstrumentType.COUNTER, null);

        meterProvider.forceFlush();

        // Verify metric was recorded
        Collection<MetricData> metrics = metricReader.collectAllMetrics();
        assertFalse(metrics.isEmpty());
    }

    @Test
    public void testThreadSafety() throws InterruptedException {
        int threadCount = 10;
        int iterationsPerThread = 100;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        // Record metrics concurrently from multiple threads
        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    for (int j = 0; j < iterationsPerThread; j++) {
                        router.recordMetric(
                                "concurrent.counter",
                                1.0,
                                MetricRouter.InstrumentType.COUNTER,
                                Attributes.builder().put("thread_id", (long) threadId).build()
                        );
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        // Wait for all threads to complete
        assertTrue(latch.await(10, TimeUnit.SECONDS), "All threads should complete");
        executor.shutdown();
        assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS));

        // Verify instrument was cached (should be 1, not threadCount * iterationsPerThread)
        assertTrue(router.getCachedInstrumentCount() > 0, "Should have cached instruments");
        assertTrue(router.getCachedInstrumentCount() < threadCount * iterationsPerThread,
                "Should reuse cached instruments, not create new ones for each call");
    }

    @Test
    public void testClearCache() {
        Attributes attrs = Attributes.empty();

        // Create some cached instruments
        router.recordMetric("metric1", 1.0, MetricRouter.InstrumentType.COUNTER, attrs);
        router.recordMetric("metric2", 2.0, MetricRouter.InstrumentType.HISTOGRAM, attrs);
        router.recordMetric("metric3", 3.0, MetricRouter.InstrumentType.GAUGE, attrs);

        assertTrue(router.getCachedInstrumentCount() > 0, "Should have cached instruments");

        // Clear cache
        router.clearCache();

        assertEquals(0, router.getCachedInstrumentCount(), "Cache should be empty after clear");
    }

    @Test
    public void testDoubleToLongConversion() {
        // Counter uses long values, so 42.9 should be converted to 42
        router.recordMetric("test.counter", 42.9, MetricRouter.InstrumentType.COUNTER, Attributes.empty());

        meterProvider.forceFlush();

        // Verify counter was recorded (value will be truncated to long)
        Collection<MetricData> metrics = metricReader.collectAllMetrics();
        assertFalse(metrics.isEmpty());
    }

    @Test
    public void testDifferentMetricsSameType() {
        Attributes attrs = Attributes.empty();

        router.recordMetric("counter1", 1.0, MetricRouter.InstrumentType.COUNTER, attrs);
        router.recordMetric("counter2", 2.0, MetricRouter.InstrumentType.COUNTER, attrs);
        router.recordMetric("counter3", 3.0, MetricRouter.InstrumentType.COUNTER, attrs);

        // Should have 3 cached instruments (one per metric name)
        assertEquals(3, router.getCachedInstrumentCount());
    }

    @Test
    public void testInstrumentReuse() {
        Attributes attrs1 = Attributes.builder().put("env", "prod").build();
        Attributes attrs2 = Attributes.builder().put("env", "dev").build();

        // Same metric name with different attributes should reuse instrument
        int initialCount = router.getCachedInstrumentCount();

        router.recordMetric("reused.counter", 1.0, MetricRouter.InstrumentType.COUNTER, attrs1);
        int afterFirst = router.getCachedInstrumentCount();

        router.recordMetric("reused.counter", 2.0, MetricRouter.InstrumentType.COUNTER, attrs2);
        int afterSecond = router.getCachedInstrumentCount();

        assertEquals(afterFirst, afterSecond, "Should reuse same instrument for same metric name");
    }
}
