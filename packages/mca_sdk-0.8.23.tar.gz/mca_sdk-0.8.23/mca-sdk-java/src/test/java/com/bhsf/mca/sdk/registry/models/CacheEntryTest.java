package com.bhsf.mca.sdk.registry.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CacheEntry.
 */
public class CacheEntryTest {

    @Test
    public void testCacheEntryCreation() {
        String value = "test-value";
        long expiresAt = System.currentTimeMillis() + 1000;

        CacheEntry<String> entry = new CacheEntry<>(value, expiresAt);

        assertEquals(value, entry.getValue());
        assertEquals(expiresAt, entry.getExpiresAt());
    }

    @Test
    public void testNullValueThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new CacheEntry<>(null, System.currentTimeMillis());
        });
    }

    @Test
    public void testIsValidWhenNotExpired() {
        CacheEntry<String> entry = new CacheEntry<>("value", System.currentTimeMillis() + 5000);

        assertTrue(entry.isValid());
        assertFalse(entry.isExpired());
    }

    @Test
    public void testIsExpiredWhenPastExpirationTime() {
        CacheEntry<String> entry = new CacheEntry<>("value", System.currentTimeMillis() - 1000);

        assertTrue(entry.isExpired());
        assertFalse(entry.isValid());
    }

    @Test
    public void testExpirationBoundary() throws InterruptedException {
        // Create entry that expires in 100ms
        long expiresAt = System.currentTimeMillis() + 100;
        CacheEntry<String> entry = new CacheEntry<>("value", expiresAt);

        // Should be valid immediately
        assertTrue(entry.isValid());

        // Wait for expiration
        Thread.sleep(150);

        // Should be expired now
        assertTrue(entry.isExpired());
    }
}
