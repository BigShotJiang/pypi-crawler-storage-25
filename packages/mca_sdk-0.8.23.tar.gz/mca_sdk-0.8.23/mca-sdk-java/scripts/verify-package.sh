#!/bin/bash
# Maven Central Package Verification Script
# Validates that the MCA SDK Java package meets Maven Central requirements

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
POM_FILE="$PROJECT_DIR/pom.xml"

echo "========================================="
echo "Maven Central Package Verification"
echo "========================================="
echo ""

# Check if Maven is available
if ! command -v mvn &> /dev/null; then
    echo "❌ ERROR: Maven is not installed or not in PATH"
    echo "   Install Maven 3.6+ to continue"
    exit 1
fi

echo "✅ Maven found: $(mvn --version | head -1)"
echo ""

# Check if POM file exists
if [ ! -f "$POM_FILE" ]; then
    echo "❌ ERROR: pom.xml not found at $POM_FILE"
    exit 1
fi

echo "✅ pom.xml found"
echo ""

# Validate POM syntax
echo "Validating pom.xml syntax..."
if mvn -f "$POM_FILE" validate -q; then
    echo "✅ pom.xml syntax is valid"
else
    echo "❌ ERROR: pom.xml has syntax errors"
    exit 1
fi
echo ""

# Check for required Maven Central metadata
echo "Checking Maven Central required metadata..."

# Check if xmllint is available for proper XML parsing
if command -v xmllint &> /dev/null; then
    echo "  Using xmllint for XML validation"
    XML_PARSER="xmllint"
else
    echo "  ⚠️  xmllint not found, using basic Maven validation"
    XML_PARSER="maven"
fi

check_pom_element() {
    local element=$1
    local xpath="/project/$element"

    if [ "$XML_PARSER" = "xmllint" ]; then
        # Use proper XML XPath evaluation
        local result=$(xmllint --xpath "boolean($xpath)" "$POM_FILE" 2>/dev/null)
        if [ "$result" = "true" ]; then
            echo "  ✅ $element present"
            return 0
        else
            echo "  ❌ $element missing"
            return 1
        fi
    else
        # Fallback: use Maven help plugin to evaluate POM
        local value=$(mvn help:evaluate -Dexpression=project.$element -q -DforceStdout 2>/dev/null)
        if [ -n "$value" ] && [ "$value" != "null" ]; then
            echo "  ✅ $element present"
            return 0
        else
            echo "  ❌ $element missing"
            return 1
        fi
    fi
}

METADATA_VALID=true

check_pom_element "name" || METADATA_VALID=false
check_pom_element "description" || METADATA_VALID=false
check_pom_element "url" || METADATA_VALID=false
check_pom_element "licenses" || METADATA_VALID=false
check_pom_element "developers" || METADATA_VALID=false
check_pom_element "scm" || METADATA_VALID=false

if [ "$METADATA_VALID" = false ]; then
    echo ""
    echo "❌ ERROR: Required Maven Central metadata is missing"
    echo "   See PUBLISHING.md for requirements"
    exit 1
fi

echo ""

# Check for required files
echo "Checking required files..."

check_file() {
    local file=$1
    local path="$PROJECT_DIR/$file"
    if [ -f "$path" ]; then
        echo "  ✅ $file exists"
        return 0
    else
        echo "  ❌ $file missing"
        return 1
    fi
}

FILES_VALID=true

check_file "LICENSE" || FILES_VALID=false
check_file "README.md" || FILES_VALID=false

if [ "$FILES_VALID" = false ]; then
    echo ""
    echo "❌ ERROR: Required files are missing"
    exit 1
fi

echo ""

# Check for Maven plugins
echo "Checking required Maven plugins..."

check_plugin() {
    local plugin=$1

    if [ "$XML_PARSER" = "xmllint" ]; then
        # Use XPath to check plugin exists in release profile or build
        local result=$(xmllint --xpath "boolean(//plugin[artifactId='$plugin'])" "$POM_FILE" 2>/dev/null)
        if [ "$result" = "true" ]; then
            echo "  ✅ $plugin configured"
            return 0
        else
            echo "  ❌ $plugin missing"
            return 1
        fi
    else
        # Fallback: use Maven help plugin
        mvn help:effective-pom -q 2>/dev/null | grep -q "<artifactId>$plugin</artifactId>"
        if [ $? -eq 0 ]; then
            echo "  ✅ $plugin configured"
            return 0
        else
            echo "  ❌ $plugin missing"
            return 1
        fi
    fi
}

PLUGINS_VALID=true

# Check for required plugins (may be in release profile)
echo "Note: Plugins for signing/javadoc/sources should be in 'release' profile"
check_plugin "maven-source-plugin" || PLUGINS_VALID=false
check_plugin "maven-javadoc-plugin" || PLUGINS_VALID=false
check_plugin "maven-gpg-plugin" || PLUGINS_VALID=false
check_plugin "nexus-staging-maven-plugin" || PLUGINS_VALID=false

if [ "$PLUGINS_VALID" = false ]; then
    echo ""
    echo "❌ ERROR: Required Maven plugins are missing"
    exit 1
fi

echo ""

# Check distribution management
echo "Checking distribution management..."

if [ "$XML_PARSER" = "xmllint" ]; then
    has_distmgmt=$(xmllint --xpath "boolean(/project/distributionManagement)" "$POM_FILE" 2>/dev/null)
    has_ossrh=$(xmllint --xpath "boolean(/project/distributionManagement//*[contains(text(),'oss.sonatype.org')])" "$POM_FILE" 2>/dev/null)

    if [ "$has_distmgmt" = "true" ]; then
        echo "  ✅ distributionManagement configured"
        if [ "$has_ossrh" = "true" ]; then
            echo "  ✅ OSSRH repository URLs present"
        else
            echo "  ❌ OSSRH repository URLs missing"
            PLUGINS_VALID=false
        fi
    else
        echo "  ❌ distributionManagement missing"
        PLUGINS_VALID=false
    fi
else
    # Fallback: Maven evaluation
    distmgmt_repo=$(mvn help:evaluate -Dexpression=project.distributionManagement.repository.url -q -DforceStdout 2>/dev/null)
    if [ -n "$distmgmt_repo" ] && [ "$distmgmt_repo" != "null" ]; then
        echo "  ✅ distributionManagement configured"
        if echo "$distmgmt_repo" | grep -q "oss.sonatype.org"; then
            echo "  ✅ OSSRH repository URLs present"
        else
            echo "  ❌ OSSRH repository URLs missing"
            PLUGINS_VALID=false
        fi
    else
        echo "  ❌ distributionManagement missing"
        PLUGINS_VALID=false
    fi
fi

if [ "$PLUGINS_VALID" = false ]; then
    echo ""
    echo "❌ ERROR: Distribution management not properly configured"
    exit 1
fi

echo ""

# Check GPG key availability
echo "Checking GPG setup..."
if command -v gpg &> /dev/null; then
    echo "  ✅ GPG found: $(gpg --version | head -1)"

    if gpg --list-keys | grep -q "@"; then
        echo "  ✅ GPG keys available"
        echo "  📝 Keys:"
        gpg --list-keys | grep -A1 "pub" | head -3
    else
        echo "  ⚠️  No GPG keys found (required for Maven Central)"
        echo "     Run: gpg --gen-key"
    fi
else
    echo "  ⚠️  GPG not found (required for Maven Central)"
    echo "     Install GnuPG to sign artifacts"
fi

echo ""

# Check Maven settings.xml
echo "Checking Maven settings..."
SETTINGS_FILE="$HOME/.m2/settings.xml"
if [ -f "$SETTINGS_FILE" ]; then
    echo "  ✅ settings.xml found"

    if grep -q "<id>ossrh</id>" "$SETTINGS_FILE"; then
        echo "  ✅ OSSRH server configured"
    else
        echo "  ⚠️  OSSRH server not configured in settings.xml"
        echo "     See PUBLISHING.md for setup instructions"
    fi
else
    echo "  ⚠️  settings.xml not found at $SETTINGS_FILE"
    echo "     Create it with OSSRH credentials for deployment"
fi

echo ""
echo "========================================="
echo "Verification Summary"
echo "========================================="

if [ "$METADATA_VALID" = true ] && [ "$FILES_VALID" = true ] && [ "$PLUGINS_VALID" = true ]; then
    echo "✅ Package configuration is valid for Maven Central"
    echo ""
    echo "Next steps:"
    echo "  1. Ensure GPG key is generated and uploaded to keyserver"
    echo "  2. Configure ~/.m2/settings.xml with encrypted OSSRH credentials"
    echo "  3. Run: mvn clean deploy -P release"
    echo "  4. See PUBLISHING.md for full deployment guide"
    echo ""
    echo "Note: Use -P release profile for Maven Central publishing"
    exit 0
else
    echo "❌ Package configuration has issues"
    echo ""
    echo "Fix the errors above before publishing to Maven Central"
    echo "See PUBLISHING.md for requirements"
    exit 1
fi
