#!/bin/bash
# Maven Central Publishing Script
# Orchestrates the full publishing workflow for MCA SDK Java

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "========================================="
echo "MCA SDK Java - Maven Central Publishing"
echo "========================================="
echo ""

# Check if Maven is available
if ! command -v mvn &> /dev/null; then
    echo "❌ ERROR: Maven is not installed"
    exit 1
fi

# Verify package configuration first
echo "Step 1: Verifying package configuration..."
if "$SCRIPT_DIR/verify-package.sh"; then
    echo "✅ Package verification passed"
else
    echo "❌ Package verification failed"
    echo "   Fix errors before publishing"
    exit 1
fi

echo ""

# Extract version from pom.xml
VERSION=$(grep -m1 "<version>" "$PROJECT_DIR/pom.xml" | sed 's/.*<version>\(.*\)<\/version>.*/\1/')
echo "Publishing version: $VERSION"
echo ""

# Confirm with user
read -p "Proceed with publishing version $VERSION to Maven Central? (yes/no): " confirm
if [ "$confirm" != "yes" ]; then
    echo "Publishing cancelled"
    exit 0
fi

echo ""

# Step 2: Run tests (without deploy profile)
echo "Step 2: Running tests..."
cd "$PROJECT_DIR"
mvn clean test

if [ $? -ne 0 ]; then
    echo "❌ Tests failed"
    exit 1
fi

echo "✅ Tests passed"
echo ""

# Step 3: Deploy to OSSRH staging (single command - Maven lifecycle handles all phases)
echo "Step 3: Deploying to OSSRH staging repository..."
echo "⚠️  This will build, sign, and upload artifacts to OSSRH"
echo "   Maven will execute: clean → compile → test → package → verify → deploy"
echo ""
read -p "Continue? (yes/no): " confirm_deploy
if [ "$confirm_deploy" != "yes" ]; then
    echo "Deployment cancelled"
    exit 0
fi

# Single mvn clean deploy command with release profile
# This handles: clean, compile, test, package, sign (via release profile), deploy
mvn clean deploy -P release

if [ $? -ne 0 ]; then
    echo "❌ Deployment failed"
    echo "   Check OSSRH credentials in ~/.m2/settings.xml"
    exit 1
fi

echo "✅ Deployed to OSSRH staging repository"
echo ""

# Note: autoReleaseAfterClose=true in pom.xml means artifacts are automatically released
echo ""
echo "Note: autoReleaseAfterClose is enabled in pom.xml"
echo "      Artifacts will be automatically closed and released to Maven Central"
echo ""
echo "If you need to manually verify or release:"
echo "  1. Go to https://oss.sonatype.org/"
echo "  2. Log in with OSSRH credentials"
echo "  3. Click 'Staging Repositories'"
echo "  4. Find your repository (com.bhsf.mca-*)"
echo "  5. Check 'Activity' tab for validation status"
echo ""
read -p "Press Enter to continue..."

echo ""
echo "========================================="
echo "Publishing Complete!"
echo "========================================="
echo ""
echo "Version $VERSION has been published to Maven Central"
echo ""
echo "Next steps:"
echo "  1. Wait 2-4 hours for sync to Maven Central"
echo "  2. Verify at: https://search.maven.org/"
echo "     Search for: g:com.bhsf.mca a:mca-sdk-java"
echo "  3. Test dependency resolution:"
echo "     cd scripts && ./test-dependency.sh $VERSION"
echo ""
echo "See PUBLISHING.md for more information"
