# Changelog

All notable changes to the MCA SDK for Java will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-04-07

### Added (Updated 2026-04-07 - Post-Adversarial Review)
- **Exception Hierarchy:** Complete exception hierarchy matching Python SDK v0.8.6
  - Added automatic credential sanitization to all SDK exceptions via `MCAException.getMessage()`
  - Added `ConfigNotFoundError` for missing configuration files or keys
  - Added `BufferingException` for queue and buffering operation failures
  - Added specific certificate exceptions:
    - `CertificateLoadException` for certificate loading failures
    - `CertificateValidationException` for certificate validation errors
    - `CertificateExpiredException` for expired or not-yet-valid certificates
- **Utilities:** New `util/` package with essential utilities
  - `StringUtils`: Credential masking, pattern detection, and string truncation
  - `Serialization`: JSON serialization with size limits and OOM protection
  - `VersionCheck`: Automatic SDK version checking against Maven Central
- **Security:** All exception messages now automatically mask AWS keys, GCP keys, JWT tokens, and Bearer tokens
- **Version Checking:** MCAClient now performs asynchronous version check on initialization (non-blocking)

### Changed
- MCAClient now includes `VERSION` constant for diagnostics and version checking
- All exceptions now sanitize credentials in error messages to prevent leakage in logs and traces

### Security
- **CRITICAL:** All exception messages now automatically redact credentials to prevent HIPAA violations
- Added pattern-based detection for AWS access keys, GCP API keys, JWT tokens, and Bearer tokens
- Credential sanitization uses existing `CredentialMasking` utility for consistent behavior

### Fixed
- Ensured all exceptions properly extend `MCAException` (except `CertificateException` family which remains checked)
- Improved error context with specific exception types for different failure scenarios
- **CRITICAL:** Fixed JWT pattern regex to match all valid JWTs regardless of payload format (not just JSON objects)
- **CRITICAL:** Fixed GCP key masking to show only 4 trailing characters (was showing 8, exposing too much)
- **CRITICAL:** Fixed short string masking logic to prevent substring index errors
- **CRITICAL:** Fixed JSON serialization to properly quote strings and primitives (was producing invalid JSON)
- **CRITICAL:** Fixed UTF-8 byte truncation to find valid character boundaries (prevents `\uFFFD` bloat exceeding byte limits)
- **CRITICAL:** Fixed `maxBytes` handling when smaller than truncation marker (now returns empty string instead of violating limit)
- **CRITICAL:** Fixed Maven Central API integration to follow HTTP redirects (was silently failing)
- **CRITICAL:** Added User-Agent header to Maven Central requests (prevents rate limiting/403 errors)
- **CRITICAL:** Added 24-hour caching to version checks (prevents resource exhaustion on repeated client instantiation)
- **CRITICAL:** Renamed `ConfigNotFoundError` to `ConfigNotFoundException` (aligns with Java naming conventions)

## [0.1.0] - 2026-03-28

### Added
- Initial Java SDK release with feature parity to Python SDK
- Configuration and registry integration
- Validation framework
- Security features (mTLS, encryption, secret management)
- Resilience patterns (retry, circuit breaker, buffering)
- GenAI and Agentic AI instrumentation
- Advanced instrumentation features
- GCP exporters (Cloud Monitoring, Cloud Trace, Cloud Logging)

[0.2.0]: https://github.com/bhsf/mca-sdk-java/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/bhsf/mca-sdk-java/releases/tag/v0.1.0
