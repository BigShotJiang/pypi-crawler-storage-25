package examples;

import com.bhsf.mca.sdk.MCAClient;
import com.bhsf.mca.sdk.instrumentation.SpanManager;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Example demonstrating advanced instrumentation features (Story 1.23.6).
 *
 * <p>Showcases:
 * <ul>
 *   <li>Manual tracing with try-with-resources</li>
 *   <li>Custom metric recording (counter, histogram, gauge)</li>
 *   <li>Fluent API for setting span attributes</li>
 * </ul>
 */
public class AdvancedInstrumentationExample {

    public static void main(String[] args) {
        // Initialize MCA Client
        try (MCAClient client = new MCAClient.Builder()
                .serviceName("advanced-instrumentation-demo")
                .modelId("mdl-demo-001")
                .teamName("platform-team")
                .otelEndpoint("http://localhost:4318")
                .build()) {

            System.out.println("=== Advanced Instrumentation Demo ===\n");

            // Demo 1: Manual tracing
            demoManualTracing(client);

            // Demo 2: Custom metrics
            demoCustomMetrics(client);

            // Demo 3: Combined tracing and metrics
            demoCombinedInstrumentation(client);

            System.out.println("\n=== Demo Complete ===");

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Demonstrates manual tracing with try-with-resources pattern.
     */
    private static void demoManualTracing(MCAClient client) {
        System.out.println("1. Manual Tracing Demo");
        System.out.println("-".repeat(50));

        Map<String, Object> attrs = new HashMap<>();
        attrs.put("operation", "data_processing");
        attrs.put("user_id", "user-123");

        try (SpanManager span = client.trace("model.preprocess", attrs)) {
            System.out.println("   - Started span: model.preprocess");

            // Simulate data preprocessing
            simulateWork(100);

            // Add attributes dynamically
            span.setAttribute("records_processed", 1000L)
                    .setAttribute("data_quality", "high")
                    .setAttribute("processing_time_ms", 100L);

            System.out.println("   - Added dynamic attributes to span");
        }

        System.out.println("   - Span automatically ended (try-with-resources)\n");
    }

    /**
     * Demonstrates custom metric recording with different instrument types.
     */
    private static void demoCustomMetrics(MCAClient client) {
        System.out.println("2. Custom Metrics Demo");
        System.out.println("-".repeat(50));

        Random random = new Random();

        // Counter: monotonically increasing
        System.out.println("   - Recording counter metrics...");
        Map<String, Object> counterAttrs = Map.of("cache_type", "redis", "region", "us-east-1");
        client.recordCounter("model.cache_hits", 150.0, counterAttrs);
        client.recordCounter("model.api_requests_total", 500.0, null);

        // Histogram: distribution of values
        System.out.println("   - Recording histogram metrics...");
        Map<String, Object> histoAttrs = Map.of("model_version", "2.0");
        client.recordMetric("model.prediction_confidence", 0.92, "histogram", histoAttrs);
        client.recordMetric("model.data_quality_score", 0.87, "histogram", null);

        // Gauge: current value (can go up or down)
        System.out.println("   - Recording gauge metrics...");
        Map<String, Object> gaugeAttrs = Map.of("queue_name", "predictions");
        client.recordGauge("model.queue_depth", 42.0, gaugeAttrs);
        client.recordGauge("model.memory_usage_mb", 512.0, null);

        System.out.println("   - All metrics recorded successfully\n");
    }

    /**
     * Demonstrates combining tracing and metrics in a realistic scenario.
     */
    private static void demoCombinedInstrumentation(MCAClient client) {
        System.out.println("3. Combined Instrumentation Demo");
        System.out.println("-".repeat(50));

        Map<String, Object> predictionAttrs = new HashMap<>();
        predictionAttrs.put("model_version", "2.0");
        predictionAttrs.put("model_type", "classifier");

        try (SpanManager span = client.trace("model.predict", predictionAttrs)) {
            System.out.println("   - Started prediction span");

            span.setAttribute("input_size", 128L);

            // Simulate prediction
            long startTime = System.currentTimeMillis();
            simulateWork(50);
            long endTime = System.currentTimeMillis();
            double latencySeconds = (endTime - startTime) / 1000.0;

            // Record prediction metrics
            client.recordCounter("model.predictions_total", 1.0, predictionAttrs);
            client.recordMetric("model.prediction_latency_seconds", latencySeconds, "histogram", predictionAttrs);

            // Update span with results
            span.setAttribute("prediction", "positive")
                    .setAttribute("confidence", 0.95)
                    .setAttribute("latency_ms", endTime - startTime);

            System.out.println("   - Recorded prediction metrics within span");
        }

        System.out.println("   - Span ended with complete context\n");
    }

    /**
     * Simulates work by sleeping for specified milliseconds.
     */
    private static void simulateWork(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
