module github.com/baptisthealth/mca-sdk-examples/internal-model-go

go 1.21

require gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go v0.1.0

// DEVELOPMENT ONLY: Replace directive allows testing without publishing to GitLab
// For production use, remove this line and rely on actual module fetching
// replace gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go => ../../mca-sdk-go
replace gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go => ../../mca-sdk-go
