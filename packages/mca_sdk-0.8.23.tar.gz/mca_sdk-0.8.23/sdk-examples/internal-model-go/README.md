# Internal Model Go Example

This example demonstrates using the MCA SDK with an internal ML model in Go.

## Prerequisites

- Go 1.21+
- OTel Collector running at `http://localhost:4318`

## Installation

### Development (from source)

When working from the monorepo:

```bash
cd mca-prototype/sdk-examples/internal-model-go
go run main.go
```

The go.mod includes a `replace` directive for local development.

### Production (from GitLab)

Remove the `replace` directive in go.mod and install from GitLab:

```bash
# Remove the replace line from go.mod
go get gitlab.com/bhsf/ai_ml/model-monitoring/sdk/mca-prototype/mca-sdk-go@mca-prototype/mca-sdk-go/v0.1.0
go build
./internal-model-go
```

**Note:** Requires GitLab authentication for private repository access.

## Running the Example

```bash
# Ensure OTel Collector is running
docker-compose -f ../../docker-compose.yml up -d otel-collector

# Run the example
go run main.go
```

The example will:
1. Initialize the MCA SDK client
2. Record single predictions
3. Record multiple sequential predictions
4. Demonstrate concurrent prediction recording
5. Show context timeout handling

## Output

You should see log output showing:
- SDK initialization
- Prediction recordings
- Telemetry being sent to OTel Collector

Check the OTel Collector logs to see exported metrics and traces.
