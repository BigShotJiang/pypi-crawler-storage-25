"""Standard configuration constants for SDK examples."""

COLLECTOR_HTTP_ENDPOINT = "http://10.164.76.55:4318"
COLLECTOR_GRPC_ENDPOINT = "10.164.76.55:4317"
REGISTRY_URL = "https://emms-registration-api-dev-rlaptra7zq-ue.a.run.app"
DEFAULT_MODEL_ID = "256c8edd-1abe-4ec3-9cc6-18a760be5718"
INTERNAL_MODEL_ID = "7a6fd3b1-3d8c-4768-9100-a8628d1f6237"
AGENTIC_MODEL_ID = "6384b62f-50d2-4de0-adc2-21408a3bc33a"
