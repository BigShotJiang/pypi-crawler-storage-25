from __future__ import annotations
import json
import sqlite3
import threading
import time
from abc import ABC, abstractmethod
from collections import deque
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .observability import Observation, Alert


# ═══════════════════════════════════════════════════════════════════════════
# Abstract base
# ═══════════════════════════════════════════════════════════════════════════

class StorageBackend(ABC):
    """واجهة مجردة لجميع backends
       interface for all backends
    """

    @abstractmethod
    def save_observation(self, obs: "Observation") -> None: ...

    @abstractmethod
    def save_observations_batch(self, observations: List["Observation"]) -> None: ...

    @abstractmethod
    def query_observations(
        self,
        metric_name: Optional[str] = None,
        since: Optional[float] = None,
        until: Optional[float] = None,
        tags_filter: Optional[Dict[str, str]] = None,
        limit: int = 10_000,
    ) -> List["Observation"]: ...

    @abstractmethod
    def save_alert(self, alert: "Alert") -> None: ...

    @abstractmethod
    def query_alerts(
        self,
        since: Optional[float] = None,
        severity: Optional[str] = None,
        limit: int = 1_000,
    ) -> List["Alert"]: ...

    @abstractmethod
    def get_metric_names(self) -> List[str]: ...

    @abstractmethod
    def purge_old_data(
        self,
        metrics_cutoff: float,
        alerts_cutoff: float,
    ) -> None: ...

    @abstractmethod
    def close(self) -> None: ...


# ═══════════════════════════════════════════════════════════════════════════
# Memory backend (سريع جداً، مؤقت)
# ═══════════════════════════════════════════════════════════════════════════

class MemoryBackend(StorageBackend):
    def __init__(self, max_observations: int = 100_000, max_alerts: int = 5_000):
        self._obs: deque = deque(maxlen=max_observations)
        self._alerts: deque = deque(maxlen=max_alerts)
        self._lock = threading.RLock()

    def save_observation(self, obs: "Observation") -> None:
        with self._lock:
            self._obs.append(obs)

    def save_observations_batch(self, observations: List["Observation"]) -> None:
        with self._lock:
            for obs in observations:
                self._obs.append(obs)

    def query_observations(
        self,
        metric_name: Optional[str] = None,
        since: Optional[float] = None,
        until: Optional[float] = None,
        tags_filter: Optional[Dict[str, str]] = None,
        limit: int = 10_000,
    ) -> List["Observation"]:
        with self._lock:
            results = []
            for obs in reversed(self._obs):   # الأحدث أولاً
                if metric_name and obs.metric_name != metric_name:
                    continue
                if since and obs.timestamp < since:
                    continue
                if until and obs.timestamp > until:
                    continue
                if tags_filter and not obs.matches_tags(tags_filter):
                    continue
                results.append(obs)
                if len(results) >= limit:
                    break
            return results

    def save_alert(self, alert: "Alert") -> None:
        with self._lock:
            self._alerts.append(alert)

    def query_alerts(
        self,
        since: Optional[float] = None,
        severity: Optional[str] = None,
        limit: int = 1_000,
    ) -> List["Alert"]:
        with self._lock:
            results = []
            for alert in reversed(self._alerts):
                if since and alert.timestamp < since:
                    continue
                if severity and alert.severity != severity:
                    continue
                results.append(alert)
                if len(results) >= limit:
                    break
            return results

    def get_metric_names(self) -> List[str]:
        with self._lock:
            return list({obs.metric_name for obs in self._obs})

    def purge_old_data(self, metrics_cutoff: float, alerts_cutoff: float) -> None:
        with self._lock:
            self._obs = deque(
                (o for o in self._obs if o.timestamp >= metrics_cutoff),
                maxlen=self._obs.maxlen,
            )
            self._alerts = deque(
                (a for a in self._alerts if a.timestamp >= alerts_cutoff),
                maxlen=self._alerts.maxlen,
            )

    def close(self) -> None:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# SQLite backend (تخزين دائم، مناسب لـ single-node)
# ═══════════════════════════════════════════════════════════════════════════

class SQLiteBackend(StorageBackend):
    """تخزين دائم بـ SQLite مع WAL mode للأداء
       for permanent storage with WAL mode for performance 
    """

    _CREATE_OBS = """
        CREATE TABLE IF NOT EXISTS observations (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT    NOT NULL,
            metric_type TEXT    NOT NULL,
            value       REAL    NOT NULL,
            timestamp   REAL    NOT NULL,
            tags        TEXT    DEFAULT '{}'
        )
    """
    _CREATE_ALERTS = """
        CREATE TABLE IF NOT EXISTS alerts (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp     REAL    NOT NULL,
            metric_name   TEXT    NOT NULL,
            value         REAL    NOT NULL,
            message       TEXT,
            severity      TEXT,
            tags          TEXT    DEFAULT '{}',
            rule_id       TEXT,
            anomaly_score REAL
        )
    """
    _IDX_OBS = """
        CREATE INDEX IF NOT EXISTS idx_obs_name_ts
        ON observations (metric_name, timestamp)
    """
    _IDX_ALERTS = """
        CREATE INDEX IF NOT EXISTS idx_alerts_ts
        ON alerts (timestamp, severity)
    """

    def __init__(self, db_path: str = "obs.db"):
        self._db_path = db_path
        self._local = threading.local()   # connection per thread
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self._db_path, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA cache_size=-64000")   # 64 MB cache
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return self._local.conn

    def _init_db(self) -> None:
        conn = self._conn()
        conn.execute(self._CREATE_OBS)
        conn.execute(self._CREATE_ALERTS)
        conn.execute(self._IDX_OBS)
        conn.execute(self._IDX_ALERTS)
        conn.commit()

    def save_observation(self, obs: "Observation") -> None:
        conn = self._conn()
        conn.execute(
            "INSERT INTO observations (metric_name, metric_type, value, timestamp, tags) VALUES (?,?,?,?,?)",
            (obs.metric_name, obs.metric_type.value, obs.value, obs.timestamp, json.dumps(obs.tags)),
        )
        conn.commit()

    def save_observations_batch(self, observations: List["Observation"]) -> None:
        conn = self._conn()
        conn.executemany(
            "INSERT INTO observations (metric_name, metric_type, value, timestamp, tags) VALUES (?,?,?,?,?)",
            [
                (o.metric_name, o.metric_type.value, o.value, o.timestamp, json.dumps(o.tags))
                for o in observations
            ],
        )
        conn.commit()

    def query_observations(
        self,
        metric_name: Optional[str] = None,
        since: Optional[float] = None,
        until: Optional[float] = None,
        tags_filter: Optional[Dict[str, str]] = None,
        limit: int = 10_000,
    ) -> List["Observation"]:
        from .observability import Observation, MetricType

        clauses, params = [], []
        if metric_name:
            clauses.append("metric_name = ?")
            params.append(metric_name)
        if since:
            clauses.append("timestamp >= ?")
            params.append(since)
        if until:
            clauses.append("timestamp <= ?")
            params.append(until)

        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = f"SELECT * FROM observations {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = self._conn().execute(sql, params).fetchall()
        results = []
        for row in rows:
            obs = Observation(
                metric_name=row["metric_name"],
                metric_type=MetricType(row["metric_type"]),
                value=row["value"],
                timestamp=row["timestamp"],
                tags=json.loads(row["tags"]),
            )
            if tags_filter and not obs.matches_tags(tags_filter):
                continue
            results.append(obs)
        return results

    def save_alert(self, alert: "Alert") -> None:
        conn = self._conn()
        conn.execute(
            "INSERT INTO alerts (timestamp, metric_name, value, message, severity, tags, rule_id, anomaly_score) VALUES (?,?,?,?,?,?,?,?)",
            (
                alert.timestamp, alert.metric_name, alert.value,
                alert.message, alert.severity,
                json.dumps(alert.tags), alert.rule_id,
                alert.anomaly_score,
            ),
        )
        conn.commit()

    def query_alerts(
        self,
        since: Optional[float] = None,
        severity: Optional[str] = None,
        limit: int = 1_000,
    ) -> List["Alert"]:
        from .observability import Alert

        clauses, params = [], []
        if since:
            clauses.append("timestamp >= ?")
            params.append(since)
        if severity:
            clauses.append("severity = ?")
            params.append(severity)

        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = f"SELECT * FROM alerts {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = self._conn().execute(sql, params).fetchall()
        return [
            Alert(
                timestamp=row["timestamp"],
                metric_name=row["metric_name"],
                value=row["value"],
                message=row["message"],
                severity=row["severity"],
                tags=json.loads(row["tags"]),
                rule_id=row["rule_id"] or "",
                anomaly_score=row["anomaly_score"],
            )
            for row in rows
        ]

    def get_metric_names(self) -> List[str]:
        rows = self._conn().execute(
            "SELECT DISTINCT metric_name FROM observations"
        ).fetchall()
        return [r["metric_name"] for r in rows]

    def purge_old_data(self, metrics_cutoff: float, alerts_cutoff: float) -> None:
        conn = self._conn()
        conn.execute("DELETE FROM observations WHERE timestamp < ?", (metrics_cutoff,))
        conn.execute("DELETE FROM alerts WHERE timestamp < ?", (alerts_cutoff,))
        conn.commit()
        # VACUUM مُزال: مكلف جداً على الـ I/O وقد يُحجب الكتابة.
        # يمكن تشغيله يدوياً عبر صيانة دورية إن احتجت.

    def close(self) -> None:
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None


# ═══════════════════════════════════════════════════════════════════════════
# Redis backend (موزّع، مناسب لـ microservices)
# ═══════════════════════════════════════════════════════════════════════════

class RedisBackend(StorageBackend):
    """
    تخزين في Redis باستخدام Sorted Sets (score = timestamp).
    يتطلب: pip install redis
    storage in Redis using Sorted Sets (score = timestamp)
    require:pip install redis
    """

    OBS_KEY = "observations"
    ALERTS_KEY = "alerts"
    NAMES_KEY = "metric_names"

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        key_prefix: str = "obs:",
        ttl_seconds: int = 86400,
        max_observations: int = 100_000,
    ):
        try:
            import redis
        except ImportError:
            raise RuntimeError("please install redis: pip install redis")

        self._redis = redis.from_url(redis_url, decode_responses=True)
        self._prefix = key_prefix
        self._ttl = ttl_seconds
        self._max_obs = max_observations

    def _k(self, key: str) -> str:
        return f"{self._prefix}{key}"

    def save_observation(self, obs: "Observation") -> None:
        data = json.dumps(obs.to_dict())
        pipe = self._redis.pipeline()
        pipe.zadd(self._k(self.OBS_KEY), {data: obs.timestamp})
        pipe.sadd(self._k(self.NAMES_KEY), obs.metric_name)
        pipe.expire(self._k(self.OBS_KEY), self._ttl)
        # الحفاظ على الحجم الأقصى
        pipe.zremrangebyrank(self._k(self.OBS_KEY), 0, -(self._max_obs + 2))
        pipe.execute()

    def save_observations_batch(self, observations: List["Observation"]) -> None:
        pipe = self._redis.pipeline()
        mapping = {json.dumps(o.to_dict()): o.timestamp for o in observations}
        pipe.zadd(self._k(self.OBS_KEY), mapping)
        for o in observations:
            pipe.sadd(self._k(self.NAMES_KEY), o.metric_name)
        pipe.expire(self._k(self.OBS_KEY), self._ttl)
        pipe.zremrangebyrank(self._k(self.OBS_KEY), 0, -(self._max_obs + 2))
        pipe.execute()

    def query_observations(
        self,
        metric_name: Optional[str] = None,
        since: Optional[float] = None,
        until: Optional[float] = None,
        tags_filter: Optional[Dict[str, str]] = None,
        limit: int = 10_000,
    ) -> List["Observation"]:
        from .observability import Observation, MetricType

        min_score = since if since else "-inf"
        max_score = until if until else "+inf"

        raw = self._redis.zrangebyscore(
            self._k(self.OBS_KEY), min_score, max_score,
            start=0, num=limit,
        )
        results = []
        for item in reversed(raw):
            d = json.loads(item)
            obs = Observation(
                metric_name=d["metric_name"],
                metric_type=MetricType(d["metric_type"]),
                value=d["value"],
                timestamp=d["timestamp"],
                tags=d["tags"],
            )
            if metric_name and obs.metric_name != metric_name:
                continue
            if tags_filter and not obs.matches_tags(tags_filter):
                continue
            results.append(obs)
        return results

    def save_alert(self, alert: "Alert") -> None:
        data = json.dumps(alert.to_dict())
        pipe = self._redis.pipeline()
        pipe.zadd(self._k(self.ALERTS_KEY), {data: alert.timestamp})
        pipe.expire(self._k(self.ALERTS_KEY), self._ttl)
        pipe.execute()

    def query_alerts(
        self,
        since: Optional[float] = None,
        severity: Optional[str] = None,
        limit: int = 1_000,
    ) -> List["Alert"]:
        from .observability import Alert

        min_score = since if since else "-inf"
        raw = self._redis.zrangebyscore(
            self._k(self.ALERTS_KEY), min_score, "+inf",
            start=0, num=limit,
        )
        results = []
        for item in reversed(raw):
            d = json.loads(item)
            alert = Alert(**d)
            if severity and alert.severity != severity:
                continue
            results.append(alert)
        return results

    def get_metric_names(self) -> List[str]:
        return list(self._redis.smembers(self._k(self.NAMES_KEY)))

    def purge_old_data(self, metrics_cutoff: float, alerts_cutoff: float) -> None:
        self._redis.zremrangebyscore(self._k(self.OBS_KEY), "-inf", metrics_cutoff)
        self._redis.zremrangebyscore(self._k(self.ALERTS_KEY), "-inf", alerts_cutoff)

    def close(self) -> None:
        self._redis.close()


# ═══════════════════════════════════════════════════════════════════════════
# Factory
# ═══════════════════════════════════════════════════════════════════════════

def create_storage(config: Any) -> StorageBackend:
    """إنشاء backend حسب الإعدادات
       create backend according to configuration
    """
    backend = config.storage.backend.lower()

    if backend == "memory":
        return MemoryBackend(
            max_observations=config.max_stored_metrics,
            max_alerts=config.max_stored_alerts,
        )
    if backend == "sqlite":
        return SQLiteBackend(db_path=config.storage.sqlite_path)
    if backend == "redis":
        return RedisBackend(
            redis_url=config.storage.redis_url,
            key_prefix=config.storage.redis_key_prefix,
            ttl_seconds=config.storage.redis_ttl_seconds,
            max_observations=config.max_stored_metrics,
        )

    raise ValueError(f"Backend not supported: {backend!r}. availably: memory, sqlite, redis")