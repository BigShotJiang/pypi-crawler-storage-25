from __future__ import annotations
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from .config import AnomalyConfig
import numpy as np
config=AnomalyConfig()



# ═══════════════════════════════════════════════════════════════════════════
# نتيجة الكشف
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class AnomalyResult:
    metric_name: str
    value: float
    timestamp: float
    is_anomaly: bool
    score: float                     # كلما زاد، كلما كان الشذوذ أكبر
    algorithm: str
    expected_range: Tuple[float, float]   # (min_normal, max_normal)
    severity: str = "info"            # info | warning | critical
    tags: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "metric_name": self.metric_name,
            "value": self.value,
            "timestamp": self.timestamp,
            "is_anomaly": self.is_anomaly,
            "score": round(self.score, 4),
            "algorithm": self.algorithm,
            "expected_range": list(self.expected_range),
            "severity": self.severity,
            "tags": self.tags,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Detector الأساسي
# ═══════════════════════════════════════════════════════════════════════════

class AnomalyDetector:
    """
    كاشف الشذوذ — يحتفظ بنافذة منزلقة لكل metric ويحدّث النموذج دورياً.\n
    anomaly detections algorithms
    الخوارزميات:
        zscore           — fast and lightweight, suitable for normally distributed data | it's fast and suitable for normally distributed data with outliers
        iqr              — مقاوم للقيم الشاذة الشديدة | it's suitable for skewed data with outliers         
        isolation_forest — يتطلب scikit-learn، الأفضل للأنماط المعقدة | it requires scikit-learn, the best for complex anomalies
    """

    def __init__(
        self,
        algorithm: str = config.algorithm,
        zscore_threshold: float = config.zscore_threshold,
        iqr_multiplier: float = config.iqr_multiplier,
        min_samples: int = config.min_samples,
        window_seconds: float = config.window_seconds,  
        retrain_interval: int = config.retrain_interval_seconds,
    ):
        self.algorithm = algorithm
        self.zscore_threshold = zscore_threshold
        self.iqr_multiplier = iqr_multiplier
        self.min_samples = min_samples
        self.window_seconds = window_seconds
        self.retrain_interval = retrain_interval

        # نافذة منزلقة لكل metric: (timestamp, value)
        self._windows: Dict[str, deque] = defaultdict(lambda: deque(maxlen=10_000))
        # نماذج Isolation Forest لكل metric
        self._models: Dict[str, object] = {}
        self._last_retrain: Dict[str, float] = {}

        self._lock = threading.RLock()

    # ------------------------------------------------------------------ #
    # API عام                                                               #
    # ------------------------------------------------------------------ #

    def update(self, metric_name: str, value: float, timestamp: Optional[float] = None) -> None:
        """إضافة قياس جديد للنافذة\n
            add a new observation to the window 
        """
        ts = timestamp or time.time()
        with self._lock:
            self._windows[metric_name].append((ts, value))

    def detect(
        self,
        metric_name: str,
        value: float,
        timestamp: Optional[float] = None,
        tags: Optional[Dict[str, str]] = None,
    ) -> AnomalyResult:
        """فحص قياس واحد وإرجاع نتيجة الكشف\n
            detect a single observation and return the result of the detection 
        """
        ts = timestamp or time.time()
        self.update(metric_name, value, ts)

        with self._lock:
            samples = self._get_window_values(metric_name, ts)

        if len(samples) < self.min_samples:
            # بيانات غير كافية — لا نحكم
            return AnomalyResult(
                metric_name=metric_name,
                value=value,
                timestamp=ts,
                is_anomaly=False,
                score=0.0,
                algorithm=self.algorithm,
                expected_range=(float("-inf"), float("inf")),
                tags=tags or {},
            )

        if self.algorithm == "zscore":
            return self._zscore_detect(metric_name, value, ts, samples, tags)
        if self.algorithm == "iqr":
            return self._iqr_detect(metric_name, value, ts, samples, tags)
        if self.algorithm == "isolation_forest":
            return self._iforest_detect(metric_name, value, ts, samples, tags)

        raise ValueError(f"not supported: {self.algorithm!r}")

    def get_stats(self, metric_name: str) -> Dict:
        """إحصائيات الـ window الحالي \n
          get states for window
        """
        with self._lock:
            values = self._get_window_values(metric_name)
        if not values:
            return {"metric_name": metric_name, "samples": 0}
        arr = np.array(values)
        return {
            "metric_name": metric_name,
            "samples": len(arr),
            "mean": float(arr.mean()),
            "std": float(arr.std()),
            "min": float(arr.min()),
            "max": float(arr.max()),
            "p25": float(np.percentile(arr, 25)),
            "p75": float(np.percentile(arr, 75)),
        }

    # ------------------------------------------------------------------ #
    # خوارزميات الكشف الداخلية                                              #
    # ------------------------------------------------------------------ #

    def _get_window_values(
        self,
        metric_name: str,
        current_ts: Optional[float] = None,
    ) -> List[float]:
        """القيم في النافذة الزمنية الأخيرة"""
        cutoff = (current_ts or time.time()) - self.window_seconds
        return [v for ts, v in self._windows[metric_name] if ts >= cutoff]

    def _severity_from_score(self, score: float) -> str:
        if score >= 5.0:
            return "critical"
        if score >= 2.0:   # عتبة ثابتة تعمل بشكل معقول لجميع الخوارزميات
            return "warning"
        return "info"

    def _zscore_detect(
        self,
        metric_name: str,
        value: float,
        ts: float,
        samples: List[float],
        tags: Optional[Dict[str, str]],
    ) -> AnomalyResult:
        arr = np.array(samples)
        mean, std = arr.mean(), arr.std()

        if std < 1e-9:   # جميع القيم متطابقة
            score = 0.0 if abs(value - mean) < 1e-9 else float("inf")
        else:
            score = abs((value - mean) / std)

        low = mean - self.zscore_threshold * std
        high = mean + self.zscore_threshold * std
        is_anomaly = score >= self.zscore_threshold

        return AnomalyResult(
            metric_name=metric_name,
            value=value,
            timestamp=ts,
            is_anomaly=is_anomaly,
            score=float(score),
            algorithm="zscore",
            expected_range=(float(low), float(high)),
            severity=self._severity_from_score(score) if is_anomaly else "info",
            tags=tags or {},
        )

    def _iqr_detect(
        self,
        metric_name: str,
        value: float,
        ts: float,
        samples: List[float],
        tags: Optional[Dict[str, str]],
    ) -> AnomalyResult:
        arr = np.array(samples)
        q1, q3 = np.percentile(arr, 25), np.percentile(arr, 75)
        iqr = q3 - q1
        fence = self.iqr_multiplier * iqr

        low = float(q1 - fence)
        high = float(q3 + fence)
        is_anomaly = value < low or value > high

        # النقاط كنسبة خارج الحدود
        if iqr < 1e-9:
            score = 0.0
        else:
            distance = max(low - value, value - high, 0)
            score = distance / (iqr + 1e-9)

        return AnomalyResult(
            metric_name=metric_name,
            value=value,
            timestamp=ts,
            is_anomaly=is_anomaly,
            score=float(score),
            algorithm="iqr",
            expected_range=(low, high),
            severity=self._severity_from_score(score) if is_anomaly else "info",
            tags=tags or {},
        )

    def _iforest_detect(
        self,
        metric_name: str,
        value: float,
        ts: float,
        samples: List[float],
        tags: Optional[Dict[str, str]],
    ) -> AnomalyResult:
        try:
            from sklearn.ensemble import IsolationForest
        except ImportError:
            raise RuntimeError("scikit-learn: pip install scikit-learn")

        now = time.time()
        should_retrain = (
            metric_name not in self._models
            or (now - self._last_retrain.get(metric_name, 0)) >= self.retrain_interval
        )

        if should_retrain:
            arr = np.array(samples).reshape(-1, 1)
            model = IsolationForest(contamination=0.05, random_state=42, n_jobs=-1)
            model.fit(arr)
            with self._lock:
                self._models[metric_name] = model
                self._last_retrain[metric_name] = now

        # قراءة النموذج داخل الـ lock لتجنّب race condition
        with self._lock:
            model = self._models[metric_name]
        raw_score = float(model.score_samples([[value]])[0])
        # score_samples: أكثر سلبية = أكثر شذوذاً. نحوّله لـ [0, ∞]
        score = max(0.0, -raw_score - 0.5) * 10
        is_anomaly = model.predict([[value]])[0] == -1

        # نحسب النطاق الطبيعي بناءً على IQR كتقريب
        arr = np.array(samples)
        low, high = float(np.percentile(arr, 5)), float(np.percentile(arr, 95))

        return AnomalyResult(
            metric_name=metric_name,
            value=value,
            timestamp=ts,
            is_anomaly=is_anomaly,
            score=score,
            algorithm="isolation_forest",
            expected_range=(low, high),
            severity=self._severity_from_score(score) if is_anomaly else "info",
            tags=tags or {},
        )