from __future__ import annotations
import asyncio
import random
import threading
import time
import uuid
from collections import defaultdict, deque
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, Generator, List, Optional
import numpy as np
from .config import ObservabilityConfig


# ═══════════════════════════════════════════════════════════════════════════
# Trace Context — يُمرَّر عبر الخدمات (W3C Trace Context معيار)
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class TraceContext:
    """
        The context of the trace sent in HTTP headers is represented as:
        traceparent: 00-{trace_id}-{span_id}-{flags}
    """
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    sampled: bool = True  # you want to save this trace or not

    @classmethod
    def from_header(cls, traceparent: str) -> "TraceContext":
        """استخراج الـ context من W3C traceparent header
        extract context from W3C traceparent header
        """
        try:
            parts = traceparent.split("-")
            return cls(
                trace_id=parts[1],
                span_id=parts[2],
                sampled=parts[3] == "01",
            )
        except Exception:
            return cls()

    def to_header(self) -> str:
        flag = "01" if self.sampled else "00"
        return f"00-{self.trace_id}-{self.span_id}-{flag}"


# ═══════════════════════════════════════════════════════════════════════════
# TraceEvent
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class TraceEvent:
    event_id: str
    trace_id: str          # يربط جميع spans في نفس الطلب
    event_type: str
    service_name: str
    timestamp: float
    duration: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    parent_id: Optional[str] = None
    status: str = "success"   # success | error | timeout
    error: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "event_id": self.event_id,
            "trace_id": self.trace_id,
            "event_type": self.event_type,
            "service_name": self.service_name,
            "timestamp": self.timestamp,
            "duration": self.duration,
            "metadata": self.metadata,
            "parent_id": self.parent_id,
            "status": self.status,
            "error": self.error,
            "tags": self.tags,
        }

    def to_otlp_span(self) -> Dict:
        """تحويل لصيغة OTLP (OpenTelemetry Protocol) JSON
           convert to OTLP format
        """
        return {
            "traceId": self.trace_id,
            "spanId": self.event_id[:16],
            "parentSpanId": self.parent_id[:16] if self.parent_id else None,
            "name": self.event_type,
            "kind": 1,   # SPAN_KIND_SERVER
            "startTimeUnixNano": int(self.timestamp * 1e9),
            "endTimeUnixNano": int((self.timestamp + (self.duration or 0)) * 1e9),
            "status": {
                "code": 2 if self.status == "error" else 1
            },
            "attributes": [
                {"key": k, "value": {"stringValue": v}}
                for k, v in {**self.tags, "service.name": self.service_name}.items()
            ],
        }


# ═══════════════════════════════════════════════════════════════════════════
# Exporter للـ OTLP (Jaeger / Grafana Tempo / OpenTelemetry Collector)
# ═══════════════════════════════════════════════════════════════════════════

class OTLPExporter:
    """يرسل traces لـ OpenTelemetry Collector عبر HTTP/JSON
       OTLP exporter to OpenTelemetry Collector via HTTP/JSON
    """

    def __init__(self, endpoint: str, service_name: str, service_version: str = "1.0.0"):
        self._endpoint = endpoint.rstrip("/") + "/v1/traces"
        self._service = service_name
        self._version = service_version

    def export(self, events: List[TraceEvent]) -> bool:
        try:
            import urllib.request, json as _json

            payload = {
                "resourceSpans": [{
                    "resource": {
                        "attributes": [
                            {"key": "service.name",    "value": {"stringValue": self._service}},
                            {"key": "service.version", "value": {"stringValue": self._version}},
                        ]
                    },
                    "scopeSpans": [{
                        "spans": [e.to_otlp_span() for e in events]
                    }]
                }]
            }

            data = _json.dumps(payload).encode()
            req = urllib.request.Request(
                self._endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status < 300
        except Exception:
            return False


# ═══════════════════════════════════════════════════════════════════════════
# Tracer الأساسي
# ═══════════════════════════════════════════════════════════════════════════

class Tracer:
    """
    نظام تتبع موزّع:
    - يدعم trace propagation عبر W3C Trace Context
    - يرسل spans لـ OpenTelemetry Collector اختيارياً
    - يعالج stale spans تلقائياً
     
    Distributed Trace Propagation System:
    - Supports trace propagation via W3C Trace Context
    - Optionally sends spans to OpenTelemetry Collector
    - Automatically processes stale spans
    """

    _SKIPPED = ""

    def __init__(self, config: Optional[ObservabilityConfig] = None):
        self.config = config or ObservabilityConfig()
        tc = self.config.tracing

        self._service_name = tc.service_name
        self._sampling_rate = tc.sampling_rate
        self._events: deque = deque(maxlen=tc.max_stored_traces)
        self._active_spans: Dict[str, Dict] = {}
        self._lock = threading.RLock()

        self._stats: Dict[str, Any] = {
            "total_spans": 0,
            "completed_spans": 0,
            "failed_spans": 0,
            "skipped_spans": 0,
            "spans_by_type": defaultdict(int),
        }

        # OTLP export
        self._otlp: Optional[OTLPExporter] = None
        self._stop_event = threading.Event()   # يُستخدم دائماً — سواء OTLP أو cleanup
        self._otlp_buffer: List[TraceEvent] = []

        if tc.opentelemetry_endpoint:
            self._otlp = OTLPExporter(
                endpoint=tc.opentelemetry_endpoint,
                service_name=tc.service_name,
                service_version=tc.service_version,
            )
            self._start_otlp_flush_thread()
        if self.config.enable_auto_cleanup:
            self._start_cleanup_thread()

    # ------------------------------------------------------------------ #
    # API — Sync                                                            #
    # ------------------------------------------------------------------ #

    def start_span(
        self,
        event_type: str,
        parent_id: Optional[str] = None,
        trace_context: Optional[TraceContext] = None,
        tags: Optional[Dict[str, str]] = None,
        **metadata: Any,
    ) -> str:
        """بدء span — يُعيد span_id أو "" عند التخطي
            start a span — returns span_id or "" on skip
        """
        if random.random() > self._sampling_rate:
            with self._lock:
                self._stats["skipped_spans"] += 1
            return self._SKIPPED

        span_id = str(uuid.uuid4())
        trace_id = trace_context.trace_id if trace_context else str(uuid.uuid4().hex)

        with self._lock:
            self._active_spans[span_id] = {
                "start_time": time.time(),
                "event_type": event_type,
                "trace_id": trace_id,
                "metadata": metadata,
                "parent_id": parent_id,
                "tags": tags or {},
            }
            self._stats["total_spans"] += 1
            self._stats["spans_by_type"][event_type] += 1

        return span_id

    def end_span(
        self,
        span_id: str,
        status: str = "success",
        error: Optional[str] = None,
        extra_tags: Optional[Dict[str, str]] = None,
    ) -> Optional[TraceEvent]:
        """إنهاء span وإرجاع الـ TraceEvent
        end a span and return the TraceEvent
        """
        if not span_id:
            return None

        with self._lock:
            data = self._active_spans.pop(span_id, None)
            if data is None:
                return None

            event = TraceEvent(
                event_id=span_id,
                trace_id=data["trace_id"],
                event_type=data["event_type"],
                service_name=self._service_name,
                timestamp=data["start_time"],
                duration=time.time() - data["start_time"],
                metadata=data["metadata"],
                parent_id=data.get("parent_id"),
                status=status,
                error=error,
                tags={**data["tags"], **(extra_tags or {})},
            )

            self._events.append(event)
            self._stats["completed_spans"] += 1
            if status == "error":
                self._stats["failed_spans"] += 1

            if self._otlp:
                self._otlp_buffer.append(event)

        return event

    @contextmanager
    def trace(
        self,
        event_type: str,
        parent_id: Optional[str] = None,
        trace_context: Optional[TraceContext] = None,
        tags: Optional[Dict[str, str]] = None,
        **metadata: Any,
    ) -> Generator[str, None, None]:
        """Context manager للتتبع — sync
           Context manager for trace 
        """
        span_id = self.start_span(event_type, parent_id, trace_context, tags, **metadata)
        status, error = "success", None
        try:
            yield span_id
        except Exception as exc:
            status, error = "error", str(exc)
            raise
        finally:
            self.end_span(span_id, status, error)

    # ------------------------------------------------------------------ #
    # API — Async                                                           #
    # ------------------------------------------------------------------ #

    @asynccontextmanager
    async def atrace(
        self,
        event_type: str,
        parent_id: Optional[str] = None,
        trace_context: Optional[TraceContext] = None,
        tags: Optional[Dict[str, str]] = None,
        **metadata: Any,
    ) -> AsyncGenerator[str, None]:
        """Context manager للتتبع — async
           Context manager for trace 
        """
        loop = asyncio.get_running_loop()
        span_id = await loop.run_in_executor(
            None, lambda: self.start_span(event_type, parent_id, trace_context, tags, **metadata)
        )
        status, error = "success", None
        try:
            yield span_id
        except Exception as exc:
            status, error = "error", str(exc)
            raise
        finally:
            await loop.run_in_executor(None, lambda: self.end_span(span_id, status, error))

    # ------------------------------------------------------------------ #
    # Propagation (للتوزيع عبر services)                                    #
    # ------------------------------------------------------------------ #

    def extract_context(self, headers: Dict[str, str]) -> Optional[TraceContext]:
        """استخراج trace context من HTTP headers
        extract trace context from HTTP headers
        """
        traceparent = headers.get("traceparent") or headers.get("Traceparent")
        if traceparent:
            return TraceContext.from_header(traceparent)
        return None

    def inject_context(self, span_id: str, headers: Dict[str, str]) -> Dict[str, str]:
        """حقن trace context في HTTP headers للإرسال للخدمة التالية
        inject trace context into HTTP headers for the next service
        """
        with self._lock:
            data = self._active_spans.get(span_id)
        if data:
            ctx = TraceContext(trace_id=data["trace_id"], span_id=span_id)
            headers["traceparent"] = ctx.to_header()
        return headers

    # ------------------------------------------------------------------ #
    # الاستعلام                                                             #
    # ------------------------------------------------------------------ #

    def get_events(
        self,
        event_type: Optional[str] = None,
        since: Optional[float] = None,
        status: Optional[str] = None,
        parent_id: Optional[str] = None,
        trace_id: Optional[str] = None,
    ) -> List[TraceEvent]:
        with self._lock:
            events = list(self._events)

        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if since is not None:
            events = [e for e in events if e.timestamp >= since]
        if status:
            events = [e for e in events if e.status == status]
        if parent_id is not None:
            events = [e for e in events if e.parent_id == parent_id]
        if trace_id:
            events = [e for e in events if e.trace_id == trace_id]

        return events

    def get_trace(self, trace_id: str) -> List[TraceEvent]:
        """جميع spans في trace واحد مرتبة زمنياً
          get all spans in a trace sorted by timestamp
        """
        events = self.get_events(trace_id=trace_id)
        return sorted(events, key=lambda e: e.timestamp)

    def get_trace_tree(self, root_span_id: str) -> Dict:
        """شجرة الـ trace — آمن للـ thread
            get trace tree — thread-safe
       
        """
        with self._lock:
            by_id = {e.event_id: e for e in self._events}
            children: Dict[str, List[str]] = defaultdict(list)
            for e in self._events:
                if e.parent_id:
                    children[e.parent_id].append(e.event_id)

        def _build(sid: str) -> Dict:
            ev = by_id.get(sid)
            if not ev:
                return {}
            return {
                "span": ev.to_dict(),
                "children": [_build(c) for c in children.get(sid, [])],
            }

        return _build(root_span_id)

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            completed = [e for e in self._events if e.duration is not None]
            active = len(self._active_spans)
            stats = dict(self._stats)
            by_type = dict(stats["spans_by_type"])

        by_type_stats: Dict[str, Dict] = {}
        durations_map: Dict[str, List[float]] = defaultdict(list)
        for e in completed:
            durations_map[e.event_type].append(e.duration)   # type: ignore[arg-type]

        for et, durs in durations_map.items():
            arr = np.array(durs)
            by_type_stats[et] = {
                "count": len(arr),
                "mean_ms": round(float(arr.mean()) * 1000, 2),
                "p95_ms": round(float(np.percentile(arr, 95)) * 1000, 2),
                "max_ms": round(float(arr.max()) * 1000, 2),
                "error_rate": sum(1 for e in completed if e.event_type == et and e.status == "error") / max(len(arr), 1),
            }

        return {
            "total_spans": stats["total_spans"],
            "completed_spans": stats["completed_spans"],
            "failed_spans": stats["failed_spans"],
            "skipped_spans": stats["skipped_spans"],
            "active_spans": active,
            "error_rate": stats["failed_spans"] / max(stats["completed_spans"], 1),
            "spans_by_type": by_type,
            "duration_stats": by_type_stats,
        }

    # ------------------------------------------------------------------ #
    # التنظيف ودورة الحياة                                                  #
    # ------------------------------------------------------------------ #

    def _evict_stale_spans(self) -> None:
        now = time.time()
        stale_cutoff = now - self.config.tracing.max_traces_age_seconds * 2

        with self._lock:
            stale = [
                sid for sid, data in self._active_spans.items()
                if data["start_time"] < stale_cutoff
            ]
            for sid in stale:
                data = self._active_spans.pop(sid)
                event = TraceEvent(
                    event_id=sid,
                    trace_id=data["trace_id"],
                    event_type=data["event_type"],
                    service_name=self._service_name,
                    timestamp=data["start_time"],
                    duration=now - data["start_time"],
                    metadata=data["metadata"],
                    parent_id=data.get("parent_id"),
                    status="timeout",
                    error="span evicted: exceeded max age",
                    tags=data.get("tags", {}),
                )
                self._events.append(event)
                self._stats["completed_spans"] += 1
                self._stats["failed_spans"] += 1

    def clear_old_traces(self) -> None:
        cutoff = time.time() - self.config.tracing.max_traces_age_seconds
        with self._lock:
            self._events = deque(
                (e for e in self._events if e.timestamp >= cutoff),
                maxlen=self.config.tracing.max_stored_traces,
            )
        self._evict_stale_spans()

    def _start_cleanup_thread(self) -> None:
        def _worker() -> None:
            while not self._stop_event.wait(self.config.cleanup_interval_seconds):
                self.clear_old_traces()

        threading.Thread(target=_worker, daemon=True, name="tracer-cleanup").start()

    def _start_otlp_flush_thread(self) -> None:
        def _worker() -> None:
            while not self._stop_event.wait(5.0):   # flush كل 5 ثوانٍ
                with self._lock:
                    batch, self._otlp_buffer = self._otlp_buffer, []
                if batch and self._otlp:
                    self._otlp.export(batch)

        threading.Thread(target=_worker, daemon=True, name="otlp-flush").start()

    def stop(self) -> None:
        self._stop_event.set()

    def __enter__(self) -> "Tracer":
        return self

    def __exit__(self, *_: Any) -> None:
        self.stop()