from __future__ import annotations
import asyncio
import time
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional
import numpy as np
from .config import ObservabilityConfig
from .storage import StorageBackend, create_storage
from .anomaly import AnomalyDetector


# ═══════════════════════════════════════════════════════════════════════════
# نماذج البيانات
# ═══════════════════════════════════════════════════════════════════════════

class MetricType(Enum):
    COUNTER   = "counter"   # قيمة تتزايد فقط (مثل عدد الطلبات)
    GAUGE     = "gauge"     # قيمة يمكن أن ترتفع وتنخفض (مثل درجة الحرارة)
    HISTOGRAM = "histogram" # توزيع القيم (مثل زمن الاستجابة)
    TIMER     = "timer"     # قياس زمن (مثل زمن تنفيذ وظيفة)


@dataclass
class Observation:
    metric_name: str
    metric_type: MetricType
    value: float
    timestamp: float = field(default_factory=time.time)
    tags: Dict[str, str] = field(default_factory=dict)

    def matches_tags(self, filter_tags: Dict[str, str]) -> bool:
        return all(self.tags.get(k) == v for k, v in filter_tags.items())

    def to_dict(self) -> Dict:
        return {
            "metric_name": self.metric_name,
            "metric_type": self.metric_type.value,
            "value": self.value,
            "timestamp": self.timestamp,
            "tags": self.tags,
        }


@dataclass
class Alert:
    timestamp: float
    metric_name: str
    value: float
    message: str
    severity: str
    tags: Dict[str, str] = field(default_factory=dict)
    rule_id: str = ""
    anomaly_score: Optional[float] = None

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "metric_name": self.metric_name,
            "value": self.value,
            "message": self.message,
            "severity": self.severity,
            "tags": self.tags,
            "rule_id": self.rule_id,
            "anomaly_score": self.anomaly_score,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Rate Limiter (Token Bucket)
# ═══════════════════════════════════════════════════════════════════════════

class TokenBucketRateLimiter:
    """
    Token Bucket algorithm — يسمح بـ burst ثم يُبطئ تدريجياً.
    آمن للـ threads.
    Token Bucket algorithm for thread-safe rate limiting.
    """

    def __init__(self, rate: float, burst: int, per_metric_rate: Optional[int] = None):
        self._rate = rate       # tokens per second (global)
        self._burst = burst     # max tokens (global)
        self._per_metric_rate = float(per_metric_rate or rate)
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

        # حدود لكل metric
        self._per_metric_tokens: Dict[str, float] = defaultdict(lambda: self._per_metric_rate)
        self._per_metric_last: Dict[str, float] = defaultdict(time.monotonic)

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self._burst, self._tokens + elapsed * self._rate)
        self._last_refill = now

    def allow(self, metric_name: Optional[str] = None) -> bool:
        with self._lock:
            self._refill()
            if self._tokens < 1:
                return False
            self._tokens -= 1

            if metric_name:
                now = time.monotonic()
                elapsed = now - self._per_metric_last[metric_name]
                self._per_metric_tokens[metric_name] = min(
                    self._per_metric_rate,
                    self._per_metric_tokens[metric_name] + elapsed * self._per_metric_rate,
                )
                self._per_metric_last[metric_name] = now

                if self._per_metric_tokens[metric_name] < 1:
                    return False
                self._per_metric_tokens[metric_name] -= 1

            return True

    @property
    def available_tokens(self) -> float:
        with self._lock:
            self._refill()
            return self._tokens


# ═══════════════════════════════════════════════════════════════════════════
# قواعد التنبيه
# ═══════════════════════════════════════════════════════════════════════════

class AlertRule:
    def __init__(
        self,
        rule_id: str,
        metric_name: str,
        condition: Callable[[float], bool],
        message: str,
        severity: str = "warning",
        cooldown_seconds: int = 60,
        tags_filter: Optional[Dict[str, str]] = None,
    ):
        self.rule_id = rule_id
        self.metric_name = metric_name
        self.condition = condition
        self.message = message
        self.severity = severity
        self.cooldown_seconds = cooldown_seconds
        self.tags_filter = tags_filter or {}
        self.last_triggered: Optional[float] = None

    def can_trigger(self) -> bool:
        if self.last_triggered is None:
            return True
        return (time.time() - self.last_triggered) >= self.cooldown_seconds

    def should_alert(self, obs: Observation) -> bool:
        if obs.metric_name != self.metric_name:
            return False
        if self.tags_filter and not obs.matches_tags(self.tags_filter):
            return False
        if not self.can_trigger():
            return False
        return self.condition(obs.value)


# ═══════════════════════════════════════════════════════════════════════════
# Async write buffer
# ═══════════════════════════════════════════════════════════════════════════

class AsyncWriteBuffer:
    """
    يجمع القياسات في buffer ويكتبها دفعة واحدة للـ storage
    لتقليل الـ I/O وتحسين الأداء تحت الحمل الشديد.
    
    It gathers measurements in a buffer and writes them all at once to storage
    to reduce I/O and improve performance under heavy load.    
    """

    def __init__(
        self,
        flush_callback: Callable[[List[Observation]], None],
        max_size: int = 1_000,
        flush_interval: float = 0.5,
    ):
        self._callback = flush_callback
        self._max_size = max_size
        self._flush_interval = flush_interval
        self._buffer: List[Observation] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._worker, daemon=True, name="obs-buffer")
        self._thread.start()

    def add(self, obs: Observation) -> None:
        with self._lock:
            self._buffer.append(obs)
            if len(self._buffer) >= self._max_size:
                self._flush_locked()

    def add_batch(self, observations: List[Observation]) -> None:
        with self._lock:
            self._buffer.extend(observations)
            if len(self._buffer) >= self._max_size:
                self._flush_locked()

    def _flush_locked(self) -> None:
        if not self._buffer:
            return
        batch, self._buffer = self._buffer, []
        try:
            self._callback(batch)
        except Exception:
            pass   # لا نريد أن يسقط الـ flush thread بسبب خطأ عابر

    def _worker(self) -> None:
        while not self._stop.wait(self._flush_interval):
            with self._lock:
                self._flush_locked()

    def flush(self) -> None:
        with self._lock:
            self._flush_locked()

    def stop(self) -> None:
        self._stop.set()
        self.flush()


# ═══════════════════════════════════════════════════════════════════════════
# النظام الأساسي
# ═══════════════════════════════════════════════════════════════════════════

class ObservabilitySystem:
    """
    نظام مراقبة إنتاجي — يدعم الحمل الشديد
    observability system that supports anomaly detection.
    """

    def __init__(self, config: Optional[ObservabilityConfig] = None):
        self.config = config or ObservabilityConfig()

        # storage
        self.storage: StorageBackend = create_storage(self.config)

        # rate limiter
        self._limiter: Optional[TokenBucketRateLimiter] = None
        if self.config.rate_limit.enabled:
            self._limiter = TokenBucketRateLimiter(
                rate=self.config.rate_limit.max_records_per_second,
                burst=self.config.rate_limit.burst_size,
                per_metric_rate=self.config.rate_limit.per_metric_limit,
            )

        # write buffer للأداء
        self._buffer = AsyncWriteBuffer(
            flush_callback=self.storage.save_observations_batch,
            max_size=1_000,
            flush_interval=0.5,
        )

        # anomaly detection
        self._anomaly: Optional[AnomalyDetector] = None
        if self.config.anomaly.enabled:
            self._anomaly = AnomalyDetector(
                algorithm=self.config.anomaly.algorithm,
                zscore_threshold=self.config.anomaly.zscore_threshold,
                iqr_multiplier=self.config.anomaly.iqr_multiplier,
                min_samples=self.config.anomaly.min_samples,
                window_seconds=self.config.anomaly.window_seconds,
                retrain_interval=self.config.anomaly.retrain_interval_seconds,
            )

        # alert rules
        self._alert_rules: Dict[str, AlertRule] = {}
        self._rules_lock = threading.RLock()

        # إحصائيات داخلية (عداد فقط، لا يُخزّن في storage)
        self._stats: Dict[str, Any] = {
            "total_recorded": 0,
            "total_dropped": 0,   # بسبب rate limiting
            "total_alerts": 0,
            "total_anomalies": 0,
            "alerts_by_severity": defaultdict(int),
        }
        self._stats_lock = threading.Lock()

        self._stop_event = threading.Event()
        if self.config.enable_auto_cleanup:
            self._start_cleanup_thread()

    # ------------------------------------------------------------------ #
    # تسجيل — Sync                                                          #
    # ------------------------------------------------------------------ #

    def record(
        self,
        metric_name: str,
        value: float,
        metric_type: MetricType = MetricType.GAUGE,
        tags: Optional[Dict[str, str]] = None,
    ) -> bool:
        """
        تسجيل قياس واحد.
        يُعيد True إذا تم القبول أو False إذا رُفض بسبب rate limiting.

        record one metrics value.
        Returns True if accepted or False if rejected due to rate limiting.
        """
        if self._limiter and not self._limiter.allow(metric_name):
            with self._stats_lock:
                self._stats["total_dropped"] += 1
            return False

        obs = Observation(
            metric_name=metric_name,
            metric_type=metric_type,
            value=value,
            timestamp=time.time(),
            tags=tags or {},
        )
        self._buffer.add(obs)

        with self._stats_lock:
            self._stats["total_recorded"] += 1

        self._process_alerts(obs)
        self._process_anomaly(obs)
        return True

    def record_batch(self, observations: List[Observation]) -> int:
        """
        تسجيل دفعة قياسات.
        يُعيد عدد القياسات المقبولة.

        record a batch of observations.
        Returns the number of accepted observations.
        """
        accepted = []
        for obs in observations:
            if self._limiter and not self._limiter.allow(obs.metric_name):
                with self._stats_lock:
                    self._stats["total_dropped"] += 1
                continue
            accepted.append(obs)

        if accepted:
            self._buffer.add_batch(accepted)
            with self._stats_lock:
                self._stats["total_recorded"] += len(accepted)
            for obs in accepted:
                self._process_alerts(obs)
                self._process_anomaly(obs)

        return len(accepted)

    # ------------------------------------------------------------------ #
    # تسجيل — Async                                                         #
    # ------------------------------------------------------------------ #

    async def arecord(
        self,
        metric_name: str,
        value: float,
        metric_type: MetricType = MetricType.GAUGE,
        tags: Optional[Dict[str, str]] = None,
    ) -> bool:
        """نسخة async من record — تُنفَّذ في executor لعدم حجب event loop

           async version for record one metrics value.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, lambda: self.record(metric_name, value, metric_type, tags)
        )

    async def arecord_batch(self, observations: List[Observation]) -> int:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, lambda: self.record_batch(observations))

    # ------------------------------------------------------------------ #
    # قواعد التنبيه                                                         #
    # ------------------------------------------------------------------ #

    def add_alert_rule(
        self,
        rule_id: str,
        metric_name: str,
        condition: Callable[[float], bool],
        message: str,
        severity: str = "warning",
        cooldown_seconds: Optional[int] = None,
        tags_filter: Optional[Dict[str, str]] = None,
    ) -> None:
        rule = AlertRule(
            rule_id=rule_id,
            metric_name=metric_name,
            condition=condition,
            message=message,
            severity=severity,
            cooldown_seconds=cooldown_seconds or self.config.alert_cooldown_seconds,
            tags_filter=tags_filter,
        )
        with self._rules_lock:
            self._alert_rules[rule_id] = rule

    def remove_alert_rule(self, rule_id: str) -> bool:
        with self._rules_lock:
            return self._alert_rules.pop(rule_id, None) is not None

    def _process_alerts(self, obs: Observation) -> None:
        with self._rules_lock:
            rules = list(self._alert_rules.values())

        for rule in rules:
            if rule.should_alert(obs):
                alert = Alert(
                    timestamp=time.time(),
                    metric_name=obs.metric_name,
                    value=obs.value,
                    message=rule.message,
                    severity=rule.severity,
                    tags=obs.tags,
                    rule_id=rule.rule_id,
                )
                self.storage.save_alert(alert)
                rule.last_triggered = time.time()

                with self._stats_lock:
                    self._stats["total_alerts"] += 1
                    self._stats["alerts_by_severity"][rule.severity] += 1

    def _process_anomaly(self, obs: Observation) -> None:
        if not self._anomaly:
            return

        result = self._anomaly.detect(
            metric_name=obs.metric_name,
            value=obs.value,
            timestamp=obs.timestamp,
            tags=obs.tags,
        )

        if result.is_anomaly:
            alert = Alert(
                timestamp=result.timestamp,
                metric_name=result.metric_name,
                value=result.value,
                message=(
                    f"[Anomaly:{result.algorithm.upper()}] "
                    f" Anomaly Detected: {result.value:.4f} "
                    f"( Expected Zone: [{result.expected_range[0]:.4f}, {result.expected_range[1]:.4f}])"
                ),
                severity=result.severity,
                tags=result.tags,
                rule_id=f"anomaly_{result.algorithm}",
                anomaly_score=result.score,
            )
            self.storage.save_alert(alert)

            with self._stats_lock:
                self._stats["total_anomalies"] += 1
                self._stats["alerts_by_severity"][result.severity] += 1

    # ------------------------------------------------------------------ #
    # الاستعلام                                                             #
    # ------------------------------------------------------------------ #

    def get_metrics_summary(
        self,
        metric_name: str,
        window_seconds: Optional[float] = None,
        tags_filter: Optional[Dict[str, str]] = None,
    ) -> Dict:
        window = window_seconds or self.config.window_seconds
        obs = self.storage.query_observations(
            metric_name=metric_name,
            since=time.time() - window,
            tags_filter=tags_filter,
        )

        if not obs:
            return {"metric_name": metric_name, "count": 0, "window_seconds": window}

        values = np.array([o.value for o in obs])
        return {
            "metric_name": metric_name,
            "count": int(len(values)),
            "min": float(values.min()),
            "max": float(values.max()),
            "mean": float(values.mean()),
            "median": float(np.median(values)),
            "std": float(values.std()),
            "p50": float(np.percentile(values, 50)),
            "p90": float(np.percentile(values, 90)),
            "p95": float(np.percentile(values, 95)),
            "p99": float(np.percentile(values, 99)),
            "sum": float(values.sum()),
            "window_seconds": window,
            "first_ts": obs[-1].timestamp,
            "last_ts": obs[0].timestamp,
        }

    def get_active_alerts(
        self,
        max_age_seconds: Optional[float] = None,
        severity: Optional[str] = None,
    ) -> List[Alert]:
        since = time.time() - (max_age_seconds or self.config.max_alerts_age_seconds)
        return self.storage.query_alerts(since=since, severity=severity)

    def get_anomaly_stats(self, metric_name: str) -> Optional[Dict]:
        if not self._anomaly:
            return None
        return self._anomaly.get_stats(metric_name)

    def get_system_stats(self) -> Dict:
        with self._stats_lock:
            stats = dict(self._stats)
            stats["alerts_by_severity"] = dict(stats["alerts_by_severity"])

        stats["unique_metrics"] = len(self.storage.get_metric_names())
        stats["rate_limiter_tokens"] = (
            round(self._limiter.available_tokens, 1) if self._limiter else None
        )
        stats["anomaly_enabled"] = self._anomaly is not None
        stats["storage_backend"] = type(self.storage).__name__
        return stats

    # ------------------------------------------------------------------ #
    # التصدير                                                               #
    # ------------------------------------------------------------------ #

    def export_prometheus(self, window_seconds: float = 60.0) -> str:
        """تصدير كل المقاييس بصيغة Prometheus text format
        export all metrics in Prometheus text format
        """
        PROM_TYPES = {
            MetricType.COUNTER: "counter",
            MetricType.GAUGE: "gauge",
            MetricType.HISTOGRAM: "histogram",
            MetricType.TIMER: "summary",
        }
        since = time.time() - window_seconds
        lines = []

        for name in self.storage.get_metric_names():
            obs_list = self.storage.query_observations(metric_name=name, since=since, limit=10_000)
            if not obs_list:
                continue
            metric_type = obs_list[0].metric_type
            prom_type = PROM_TYPES.get(metric_type, "gauge")
            values = [o.value for o in obs_list]

            lines += [
                f"# HELP {name} Auto-exported from ObservabilitySystem",
                f"# TYPE {name} {prom_type}",
                f'{name}{{service="{self.config.service_name}",env="{self.config.environment}"}} {np.mean(values):.6f}',
                f"{name}_count {len(values)}",
                f"{name}_sum {sum(values):.6f}",
            ]

        return "\n".join(lines)

    def export_dict(self) -> Dict:
        metric_names = self.storage.get_metric_names()
        return {
            "service": self.config.service_name,
            "environment": self.config.environment,
            "timestamp": time.time(),
            "stats": self.get_system_stats(),
            "metrics": {
                name: self.get_metrics_summary(name) for name in metric_names
            },
            "alerts": [a.to_dict() for a in self.get_active_alerts()],
        }

    # ------------------------------------------------------------------ #
    # دورة الحياة                                                           #
    # ------------------------------------------------------------------ #

    def clear_old_data(self) -> None:
        now = time.time()
        self.storage.purge_old_data(
            metrics_cutoff=now - self.config.max_metrics_age_seconds,
            alerts_cutoff=now - self.config.max_alerts_age_seconds,
        )

    def _start_cleanup_thread(self) -> None:
        def _worker() -> None:
            while not self._stop_event.wait(self.config.cleanup_interval_seconds):
                self.clear_old_data()

        t = threading.Thread(target=_worker, daemon=True, name="obs-cleanup")
        t.start()

    def stop(self) -> None:
        """إيقاف آمن لجميع background threads
        
           stop all background threads
        """
        self._stop_event.set()
        self._buffer.stop()
        self.storage.close()

    def __enter__(self) -> "ObservabilitySystem":
        return self

    def __exit__(self, *_: Any) -> None:
        self.stop()