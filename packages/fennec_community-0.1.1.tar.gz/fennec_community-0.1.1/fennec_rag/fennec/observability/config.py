from dataclasses import dataclass, field
from typing import Optional


@dataclass
class StorageConfig:
    backend: str = "memory"          # memory | sqlite | redis
    sqlite_path: str = "obs.db"
    redis_url: str = "redis://localhost:6379/0"
    redis_key_prefix: str = "obs:"
    redis_ttl_seconds: int = 86400   # 24h


@dataclass
class RateLimitConfig:
    enabled: bool = True
    max_records_per_second: int = 10_000
    burst_size: int = 50_000
    per_metric_limit: int = 1_000    # حد لكل metric في الثانية


@dataclass
class AnomalyConfig:
    enabled: bool = True
    algorithm: str = "zscore"        # zscore | iqr | isolation_forest
    zscore_threshold: float = 3.0
    iqr_multiplier: float = 1.5
    min_samples: int = 30            # أقل عدد قياسات لبدء الكشف
    window_seconds: float = 300.0    # نافذة التحليل (5 دقائق)
    retrain_interval_seconds: int = 600


@dataclass
class TracingConfig:
    sampling_rate: float = 1.0
    max_stored_traces: int = 10_000
    max_traces_age_seconds: float = 3600.0
    opentelemetry_endpoint: Optional[str] = None   # e.g. http://jaeger:4317
    service_name: str = "my-service"
    service_version: str = "1.0.0"


@dataclass
class ExporterConfig:
    prometheus_enabled: bool = True
    prometheus_port: int = 9090
    grafana_url: Optional[str] = None
    grafana_api_key: Optional[str] = None
    datadog_api_key: Optional[str] = None
    datadog_site: str = "datadoghq.com"
    export_interval_seconds: int = 15


@dataclass
class ObservabilityConfig:
    # عامّ
    service_name: str = "QuakMind"
    environment: str = "Developer"
    max_stored_metrics: int = 100_000
    max_stored_alerts: int = 5_000
    window_seconds: float = 60.0
    alert_cooldown_seconds: int = 60
    max_metrics_age_seconds: float = 3600.0
    max_alerts_age_seconds: float = 86400.0
    cleanup_interval_seconds: int = 60
    enable_auto_cleanup: bool = True

    # إعدادات فرعية
    storage: StorageConfig = field(default_factory=StorageConfig)
    rate_limit: RateLimitConfig = field(default_factory=RateLimitConfig)
    anomaly: AnomalyConfig = field(default_factory=AnomalyConfig)
    tracing: TracingConfig = field(default_factory=TracingConfig)
    exporter: ExporterConfig = field(default_factory=ExporterConfig)