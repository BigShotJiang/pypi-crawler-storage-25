from __future__ import annotations

import json
import threading
import time
import urllib.request
import urllib.error
from abc import ABC, abstractmethod
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TYPE_CHECKING, Any, Dict, List, Optional
if TYPE_CHECKING:
    from .observability import ObservabilitySystem


# ═══════════════════════════════════════════════════════════════════════════
# Base exporter
# ═══════════════════════════════════════════════════════════════════════════

class BaseExporter(ABC):
    @abstractmethod
    def export(self) -> bool: ...

    @abstractmethod
    def start(self) -> None: ...

    @abstractmethod
    def stop(self) -> None: ...


# ═══════════════════════════════════════════════════════════════════════════
# Prometheus — يشغّل HTTP server يخدم /metrics
# ═══════════════════════════════════════════════════════════════════════════

class PrometheusExporter(BaseExporter):
    """
    يشغّل HTTP server على المنفذ المحدد.
    Prometheus يستطيع الـ scrape من http://host:port/metrics
    Docs: https://prometheus.io/docs/ 
    run a HTTP server to serve /metrics endpoint 
    """

    def __init__(self, obs: "ObservabilitySystem", port: int = 9090):
        self._obs = obs
        self._port = port
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    def export(self) -> bool:
        # Prometheus يـ pull البيانات — لا نحتاج push
        return True

    def _make_handler(self) -> type:
        obs = self._obs

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:   # noqa: N802
                if self.path == "/metrics":
                    content = obs.export_prometheus().encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/plain; version=0.0.4")
                    self.end_headers()
                    self.wfile.write(content)
                elif self.path == "/health":
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"ok")
                else:
                    self.send_response(404)
                    self.end_headers()

            def log_message(self, *_: Any) -> None:
                pass   # تعطيل الـ access log الافتراضي

        return _Handler

    def start(self) -> None:
        handler = self._make_handler()
        self._server = HTTPServer(("0.0.0.0", self._port), handler)
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            daemon=True,
            name="prometheus-exporter",
        )
        self._thread.start()

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()


# ═══════════════════════════════════════════════════════════════════════════
# Grafana — يرسل annotations للتنبيهات
# ═══════════════════════════════════════════════════════════════════════════

class GrafanaExporter(BaseExporter):
    """
    يُرسل annotations لـ Grafana عند حدوث تنبيهات جديدة.
    يتطلب: Grafana URL + API Key بصلاحية Editor أو أعلى.\n

    Sends annotations to Grafana when new alerts occur.
    Requires: Grafana URL + API Key with Editor privileges or higher.
    """

    def __init__(
        self,
        obs: "ObservabilitySystem",
        grafana_url: str,
        api_key: str,
        export_interval: int = 15,
        dashboard_id: Optional[int] = None,
    ):
        self._obs = obs
        self._url = grafana_url.rstrip("/")
        self._key = api_key
        self._interval = export_interval
        self._dashboard_id = dashboard_id
        self._last_export = time.time()
        self._stop = threading.Event()

    def _post(self, path: str, payload: Dict) -> bool:
        try:
            data = json.dumps(payload).encode()
            req = urllib.request.Request(
                f"{self._url}/api/{path}",
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self._key}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status < 300
        except urllib.error.URLError:
            return False

    def export(self) -> bool:
        alerts = self._obs.get_active_alerts(
            max_age_seconds=self._interval * 2
        )
        new_alerts = [a for a in alerts if a.timestamp > self._last_export]

        success = True
        for alert in new_alerts:
            payload: Dict[str, Any] = {
                "time": int(alert.timestamp * 1000),  # milliseconds
                "text": f"<b>[{alert.severity.upper()}]</b> {alert.message}",
                "tags": [alert.severity, alert.metric_name, "observability"],
            }
            if self._dashboard_id:
                payload["dashboardId"] = self._dashboard_id

            if not self._post("annotations", payload):
                success = False

        self._last_export = time.time()
        return success

    def start(self) -> None:
        def _worker() -> None:
            while not self._stop.wait(self._interval):
                self.export()

        threading.Thread(target=_worker, daemon=True, name="grafana-exporter").start()

    def stop(self) -> None:
        self._stop.set()


# ═══════════════════════════════════════════════════════════════════════════
# Datadog — يُرسل metrics وevents
# ═══════════════════════════════════════════════════════════════════════════

class DatadogExporter(BaseExporter):
    """
    يُرسل metrics وevents لـ Datadog.
    يتطلب: DD_API_KEY
    Docs: https://docs.datadoghq.com/api/latest/metrics/
    send metrics and events to Datadog.
    Requires: DD_API_KEY
    """

    METRICS_URL = "https://api.{site}/api/v2/series"
    EVENTS_URL  = "https://api.{site}/api/v1/events"

    def __init__(
        self,
        obs: "ObservabilitySystem",
        api_key: str,
        site: str = "datadoghq.com",
        export_interval: int = 15,
    ):
        self._obs = obs
        self._api_key = api_key
        self._metrics_url = self.METRICS_URL.format(site=site)
        self._events_url = self.EVENTS_URL.format(site=site)
        self._interval = export_interval
        self._last_export = time.time()
        self._stop = threading.Event()

    def _post(self, url: str, payload: Dict) -> bool:
        try:
            data = json.dumps(payload).encode()
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "DD-API-KEY": self._api_key,
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status < 300
        except urllib.error.URLError:
            return False

    def _build_metric_series(self) -> List[Dict]:
        """بناء series بصيغة Datadog v2"""
        service = self._obs.config.service_name
        env = self._obs.config.environment
        now = int(time.time())
        series = []

        for name in self._obs.storage.get_metric_names():
            summary = self._obs.get_metrics_summary(name, window_seconds=self._interval * 2)
            if summary.get("count", 0) == 0:
                continue

            for agg, val in [("mean", summary.get("mean")), ("max", summary.get("max")), ("p95", summary.get("p95"))]:
                if val is None:
                    continue
                series.append({
                    "metric": f"{service}.{name}.{agg}",
                    "type": 3,   # GAUGE
                    "points": [{"timestamp": now, "value": val}],
                    "tags": [f"service:{service}", f"env:{env}"],
                })

        return series

    def export(self) -> bool:
        series = self._build_metric_series()
        metrics_ok = True
        if series:
            metrics_ok = self._post(self._metrics_url, {"series": series})

        # إرسال التنبيهات كـ Datadog Events
        alerts = self._obs.get_active_alerts(max_age_seconds=self._interval * 2)
        new_alerts = [a for a in alerts if a.timestamp > self._last_export]

        events_ok = True
        for alert in new_alerts:
            event_payload = {
                "title": f"[{alert.severity.upper()}] {alert.metric_name}",
                "text": alert.message,
                "alert_type": self._map_severity(alert.severity),
                "tags": [
                    f"service:{self._obs.config.service_name}",
                    f"severity:{alert.severity}",
                    f"metric:{alert.metric_name}",
                ],
            }
            if not self._post(self._events_url, event_payload):
                events_ok = False

        self._last_export = time.time()
        return metrics_ok and events_ok

    @staticmethod
    def _map_severity(severity: str) -> str:
        return {"critical": "error", "warning": "warning"}.get(severity, "info")

    def start(self) -> None:
        def _worker() -> None:
            while not self._stop.wait(self._interval):
                self.export()

        threading.Thread(target=_worker, daemon=True, name="datadog-exporter").start()

    def stop(self) -> None:
        self._stop.set()


# ═══════════════════════════════════════════════════════════════════════════
# ExporterManager — يُدير جميع الـ exporters
# ═══════════════════════════════════════════════════════════════════════════

class ExporterManager:
    """إدارة مركزية لجميع الـ exporters
    export manager for all
    """

    def __init__(self, obs: "ObservabilitySystem"):
        self._obs = obs
        self._exporters: List[BaseExporter] = []
        cfg = obs.config.exporter

        if cfg.prometheus_enabled:
            self._exporters.append(PrometheusExporter(obs, port=cfg.prometheus_port))

        if cfg.grafana_url and cfg.grafana_api_key:
            self._exporters.append(GrafanaExporter(
                obs,
                grafana_url=cfg.grafana_url,
                api_key=cfg.grafana_api_key,
                export_interval=cfg.export_interval_seconds,
            ))

        if cfg.datadog_api_key:
            self._exporters.append(DatadogExporter(
                obs,
                api_key=cfg.datadog_api_key,
                site=cfg.datadog_site,
                export_interval=cfg.export_interval_seconds,
            ))

    def start_all(self) -> None:
        for exp in self._exporters:
            exp.start()

    def stop_all(self) -> None:
        for exp in self._exporters:
            exp.stop()

    def export_all(self) -> Dict[str, bool]:
        return {
            type(exp).__name__: exp.export()
            for exp in self._exporters
        }