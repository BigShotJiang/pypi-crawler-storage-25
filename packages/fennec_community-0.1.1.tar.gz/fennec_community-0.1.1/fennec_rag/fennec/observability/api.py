from __future__ import annotations
import time
from typing import  Dict, List, Optional
from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field
from contextlib import asynccontextmanager
from .config import ObservabilityConfig, StorageConfig, ExporterConfig
from .observability import ObservabilitySystem, MetricType, Observation
from .tracer import Tracer, TraceContext
from .export import ExporterManager


# ═══════════════════════════════════════════════════════════════════════════
# إنشاء النظام
# ═══════════════════════════════════════════════════════════════════════════

config = ObservabilityConfig(
    service_name="api-service",
    environment="production",
    storage=StorageConfig(backend="sqlite", sqlite_path="production.db"),
    exporter=ExporterConfig(
        prometheus_enabled=True,
        prometheus_port=9090,
    ),
)

obs = ObservabilitySystem(config)
tracer = Tracer(config)
exporter_mgr = ExporterManager(obs)


# ── lifespan: يُشغَّل عند بدء التطبيق وإيقافه ──────────────────────────── #
@asynccontextmanager
async def _lifespan(app: FastAPI):
    # startup
    exporter_mgr.start_all()
    yield
    # shutdown
    exporter_mgr.stop_all()
    obs.stop()
    tracer.stop()


# ═══════════════════════════════════════════════════════════════════════════
# إنشاء التطبيق
# ═══════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="Observability API",
    description="observability API — Metrics, Alerts, Traces, Anomaly Detection",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=_lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Dependency للـ tracing التلقائي ───────────────────────────────────── #
def get_trace_context(
    traceparent: Optional[str] = Query(None, description="W3C Trace Context header"),
) -> Optional[TraceContext]:
    if traceparent:
        return TraceContext.from_header(traceparent)
    return None


# ═══════════════════════════════════════════════════════════════════════════
# Pydantic Models
# ═══════════════════════════════════════════════════════════════════════════

class RecordRequest(BaseModel):
    metric_name: str = Field(..., min_length=1, max_length=200)
    value: float
    metric_type: str = Field("gauge", pattern="^(counter|gauge|histogram|timer)$")
    tags: Dict[str, str] = Field(default_factory=dict)


class BatchRecordRequest(BaseModel):
    observations: List[RecordRequest] = Field(..., max_length=1_000)


class AlertRuleRequest(BaseModel):
    rule_id: str
    metric_name: str
    threshold: float
    operator: str = Field(..., pattern="^(gt|lt|gte|lte|eq)$")
    message: str
    severity: str = Field("warning", pattern="^(info|warning|critical)$")
    cooldown_seconds: int = Field(60, ge=0)
    tags_filter: Dict[str, str] = Field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════
# Endpoints — Metrics
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/health", tags=["System"])
def health_check() -> Dict:
    return {"status": "ok", "timestamp": time.time()}


@app.get("/stats", tags=["System"])
def system_stats() -> Dict:
    """إحصائيات النظام الشاملة\n
       states of the system
    """
    return obs.get_system_stats()


@app.post("/metrics/record", tags=["Metrics"])
async def record_metric(
    req: RecordRequest,
    ctx: Optional[TraceContext] = Depends(get_trace_context),
) -> Dict:
    """تسجيل قياس واحد
       record one metrics
    """
    with tracer.trace("record_metric", trace_context=ctx, metric=req.metric_name):
        accepted = await obs.arecord(
            metric_name=req.metric_name,
            value=req.value,
            metric_type=MetricType(req.metric_type),
            tags=req.tags,
        )

    if not accepted:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    return {"accepted": True, "metric_name": req.metric_name}


@app.post("/metrics/batch", tags=["Metrics"])
async def record_batch(
    req: BatchRecordRequest,
    ctx: Optional[TraceContext] = Depends(get_trace_context),
) -> Dict:
    """تسجيل دفعة قياسات
        record batch of metrics    
    """
    observations = [
        Observation(
            metric_name=o.metric_name,
            metric_type=MetricType(o.metric_type),
            value=o.value,
            tags=o.tags,
        )
        for o in req.observations
    ]

    with tracer.trace("record_batch", trace_context=ctx, count=len(observations)):
        accepted = await obs.arecord_batch(observations)

    return {
        "requested": len(observations),
        "accepted": accepted,
        "dropped": len(observations) - accepted,
    }


@app.get("/metrics/{metric_name}", tags=["Metrics"])
def get_metric_summary(
    metric_name: str,
    window_seconds: float = Query(60.0, ge=1, le=86400),
    tags: Optional[str] = Query(None, description="example: env=prod,region=us-east"),
) -> Dict:
    """ملخص إحصائي لمقياس معين
      summary for specific metric
    """
    tags_filter = {}
    if tags:
        try:
            tags_filter = dict(pair.split("=") for pair in tags.split(","))
        except ValueError:
            raise HTTPException(status_code=400, detail="tag format invalid: env=prod,region=us-east")

    summary = obs.get_metrics_summary(metric_name, window_seconds, tags_filter or None)
    if summary.get("count", 0) == 0:
        raise HTTPException(status_code=404, detail=f"no answer for this metrics: {metric_name}")

    return summary


@app.get("/metrics", tags=["Metrics"])
def list_metrics() -> Dict:
    """قائمة بأسماء جميع المقاييس\n
       list of all metrics
    """
    return {"metrics": obs.storage.get_metric_names()}


@app.get("/metrics/{metric_name}/anomaly", tags=["Metrics"])
def get_anomaly_stats(metric_name: str) -> Dict:
    """إحصائيات كشف الشذوذ لمقياس معين\n
       states of anomaly detection for specific metric
    """
    stats = obs.get_anomaly_stats(metric_name)
    if stats is None:
        raise HTTPException(status_code=503, detail="anomaly detector not active")
    return stats


# ═══════════════════════════════════════════════════════════════════════════
# Endpoints — Alerts
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/alerts", tags=["Alerts"])
def get_alerts(
    max_age_seconds: float = Query(3600.0, ge=60),
    severity: Optional[str] = Query(None, pattern="^(info|warning|critical)$"),
) -> Dict:
    """التنبيهات النشطة\n
       get active alert
    """
    alerts = obs.get_active_alerts(max_age_seconds=max_age_seconds, severity=severity)
    return {
        "count": len(alerts),
        "alerts": [a.to_dict() for a in alerts],
    }


@app.post("/alerts/rules", tags=["Alerts"])
def add_alert_rule(req: AlertRuleRequest) -> Dict:
    """إضافة قاعدة تنبيه
      add alert rule
    """
    ops = {
        "gt": lambda v: v > req.threshold,
        "lt": lambda v: v < req.threshold,
        "gte": lambda v: v >= req.threshold,
        "lte": lambda v: v <= req.threshold,
        "eq": lambda v: v == req.threshold,
    }
    obs.add_alert_rule(
        rule_id=req.rule_id,
        metric_name=req.metric_name,
        condition=ops[req.operator],
        message=req.message,
        severity=req.severity,
        cooldown_seconds=req.cooldown_seconds,
        tags_filter=req.tags_filter or None,
    )
    return {"created": True, "rule_id": req.rule_id}


@app.delete("/alerts/rules/{rule_id}", tags=["Alerts"])
def remove_alert_rule(rule_id: str) -> Dict:
    """remove alert rule"""
    removed = obs.remove_alert_rule(rule_id)
    if not removed:
        raise HTTPException(status_code=404, detail=f"rule is not found: {rule_id}")
    return {"deleted": True, "rule_id": rule_id}


# ═══════════════════════════════════════════════════════════════════════════
# Endpoints — Traces
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/traces", tags=["Traces"])
def get_traces(
    event_type: Optional[str] = None,
    since: Optional[float] = None,
    status: Optional[str] = Query(None, pattern="^(success|error|timeout)$"),
    limit: int = Query(100, ge=1, le=1_000),
) -> Dict:
    """الأحداث المسجّلة\n
       get events occurred
    """
    events = tracer.get_events(
        event_type=event_type,
        since=since,
        status=status,
    )
    return {
        "count": len(events[:limit]),
        "events": [e.to_dict() for e in events[:limit]],
    }


@app.get("/traces/{trace_id}", tags=["Traces"])
def get_trace(trace_id: str) -> Dict:
    """جميع spans في trace واحد\n
       get all spans in trace    
    """
    events = tracer.get_trace(trace_id)
    if not events:
        raise HTTPException(status_code=404, detail=f"Trace not active: {trace_id}")
    return {
        "trace_id": trace_id,
        "span_count": len(events),
        "spans": [e.to_dict() for e in events],
    }


@app.get("/traces/stats/summary", tags=["Traces"])
def get_trace_stats() -> Dict:
    """إحصائيات التتبع\n
       states of the trace
    """
    return tracer.get_stats()


# ═══════════════════════════════════════════════════════════════════════════
# Endpoints — Export
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/export/prometheus", tags=["Export"], response_class=PlainTextResponse)
def export_prometheus(window_seconds: float = Query(60.0)) -> str:
    """تصدير بصيغة Prometheus text format\n
       export in prometheus text format
    """
    return obs.export_prometheus(window_seconds=window_seconds)


@app.get("/export/json", tags=["Export"])
def export_json() -> Dict:
    """تصدير شامل بصيغة JSON\n
    export in JSON format
    """
    return obs.export_dict()