from __future__ import annotations
import json
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TYPE_CHECKING, Deque, List, Optional

if TYPE_CHECKING:
    from .observability import ObservabilitySystem

# ── SSE limits ────────────────────────────────────────────────────────────
_MAX_SSE_CLIENTS = 20
_sse_client_count = 0
_sse_lock = threading.Lock()


# ═══════════════════════════════════════════════════════════════════════════
# ConversationLogger  ←  الجديد
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class ConversationTurn:
    """تمثّل دورة محادثة واحدة بين المستخدم ونظام RAG"""
    session_id: str
    query: str
    answer: str
    timestamp: float = field(default_factory=time.time)
    latency_ms: Optional[float] = None          # زمن توليد الإجابة
    sources_count: Optional[int] = None         # عدد المصادر المسترجعة
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "session_id":    self.session_id,
            "query":         self.query,
            "answer":        self.answer,
            "timestamp":     self.timestamp,
            "latency_ms":    self.latency_ms,
            "sources_count": self.sources_count,
            "metadata":      self.metadata,
        }


class ConversationLogger:
    """
    يسجّل محادثات RAG ويجعلها متاحة للـ dashboard في الوقت الفعلي.

    الاستخدام:
        logger = ConversationLogger(max_turns=200)

        # بعد كل استعلام RAG:
        start = time.time()
        answer = rag.generate(query)
        logger.log(
            session_id="user-123",
            query=query,
            answer=answer,
            latency_ms=(time.time() - start) * 1000,
            sources_count=len(retrieved),
        )

    ثم مرّر الـ logger لـ DashboardExporter:
        dash = DashboardExporter(obs, conversation_logger=logger)
    """

    def __init__(self, max_turns: int = 200):
        self._max = max_turns
        self._turns: Deque[ConversationTurn] = deque(maxlen=max_turns)
        self._lock = threading.Lock()
        self._total_logged = 0

    # ── Public API ──────────────────────────────────────────────────────

    def log(
        self,
        session_id: str,
        query: str,
        answer: str,
        latency_ms: Optional[float] = None,
        sources_count: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> None:
        """سجّل دورة محادثة جديدة."""
        turn = ConversationTurn(
            session_id=session_id,
            query=query,
            answer=answer,
            latency_ms=latency_ms,
            sources_count=sources_count,
            metadata=metadata or {},
        )
        with self._lock:
            self._turns.appendleft(turn)   # الأحدث أوّلاً
            self._total_logged += 1

    def get_recent(self, n: int = 50) -> List[dict]:
        """أعِد آخر n دورة كـ list من dicts."""
        with self._lock:
            turns = list(self._turns)[:n]
        return [t.to_dict() for t in turns]

    def get_stats(self) -> dict:
        """إحصائيات سريعة عن المحادثات."""
        with self._lock:
            turns = list(self._turns)

        if not turns:
            return {"total_logged": self._total_logged, "buffered": 0}

        latencies = [t.latency_ms for t in turns if t.latency_ms is not None]
        avg_lat = round(sum(latencies) / len(latencies), 1) if latencies else None

        sessions = {t.session_id for t in turns}

        return {
            "total_logged":    self._total_logged,
            "buffered":        len(turns),
            "unique_sessions": len(sessions),
            "avg_latency_ms":  avg_lat,
        }

    def clear(self) -> None:
        with self._lock:
            self._turns.clear()


# ═══════════════════════════════════════════════════════════════════════════
# HTML Template
# ═══════════════════════════════════════════════════════════════════════════

_HTML = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Observability Dashboard</title>
<style>
  :root {
    --bg: #0d1117; --surface: #161b22; --border: #30363d;
    --text: #e6edf3; --muted: #8b949e;
    --green: #3fb950; --yellow: #d29922; --red: #f85149;
    --blue: #58a6ff; --purple: #bc8cff; --teal: #39d353;
    --font: 'Segoe UI', system-ui, sans-serif;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: var(--font); min-height: 100vh; }

  header {
    background: var(--surface); border-bottom: 1px solid var(--border);
    padding: 14px 28px; display: flex; align-items: center; justify-content: space-between;
  }
  header h1 { font-size: 1.15rem; font-weight: 600; color: var(--blue); }
  #status { display: flex; align-items: center; gap: 8px; font-size: .82rem; color: var(--muted); }
  #dot { width: 8px; height: 8px; border-radius: 50%; background: var(--green);
         box-shadow: 0 0 6px var(--green); animation: pulse 2s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }

  /* ── Tabs ── */
  .tabs { display: flex; gap: 0; border-bottom: 1px solid var(--border);
          background: var(--surface); padding: 0 28px; }
  .tab-btn {
    padding: 12px 20px; font-size: .85rem; font-weight: 500; cursor: pointer;
    background: none; border: none; color: var(--muted);
    border-bottom: 2px solid transparent; transition: all .2s; margin-bottom: -1px;
  }
  .tab-btn:hover { color: var(--text); }
  .tab-btn.active { color: var(--blue); border-bottom-color: var(--blue); }

  .tab-panel { display: none; }
  .tab-panel.active { display: block; }

  main { padding: 24px 28px; display: grid; gap: 20px; }

  /* ── KPI cards ── */
  .kpi-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(155px, 1fr)); gap: 14px; }
  .kpi { background: var(--surface); border: 1px solid var(--border); border-radius: 10px;
         padding: 16px 18px; }
  .kpi .label { font-size: .72rem; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; }
  .kpi .val { font-size: 1.75rem; font-weight: 700; margin-top: 4px; }
  .kpi .sub { font-size: .75rem; color: var(--muted); margin-top: 2px; }

  /* ── Section headers ── */
  .section-title { font-size: .78rem; font-weight: 600; color: var(--muted);
                   text-transform: uppercase; letter-spacing: .08em; margin-bottom: 10px; }

  /* ── Metrics table ── */
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
  table { width: 100%; border-collapse: collapse; font-size: .82rem; }
  thead th { background: #1c2128; padding: 9px 14px; text-align: right; color: var(--muted);
             font-weight: 600; font-size: .72rem; text-transform: uppercase; }
  tbody tr { border-top: 1px solid var(--border); transition: background .15s; }
  tbody tr:hover { background: #1c2128; }
  td { padding: 9px 14px; }
  .metric-name { color: var(--blue); font-weight: 500; }
  .num { font-variant-numeric: tabular-nums; }

  /* ── Alerts ── */
  .alerts-list { display: grid; gap: 8px; }
  .alert-item {
    display: grid; grid-template-columns: auto 1fr auto; align-items: center;
    gap: 12px; padding: 10px 14px; border-radius: 8px; border: 1px solid;
    font-size: .82rem;
  }
  .alert-item.info     { background: #161b2280; border-color: var(--blue);   }
  .alert-item.warning  { background: #2d1f0a80; border-color: var(--yellow); }
  .alert-item.critical { background: #2d0a0a80; border-color: var(--red);    }
  .badge {
    padding: 2px 8px; border-radius: 20px; font-size: .68rem; font-weight: 700;
    text-transform: uppercase;
  }
  .badge.info     { background: var(--blue);   color: #000; }
  .badge.warning  { background: var(--yellow); color: #000; }
  .badge.critical { background: var(--red);    color: #fff; }
  .alert-ts { color: var(--muted); font-size: .72rem; white-space: nowrap; }
  .empty { color: var(--muted); font-size: .82rem; padding: 18px 14px; text-align: center; }

  /* ── Anomaly ── */
  .anomaly-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; }
  .anomaly-card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 14px 16px; }
  .anomaly-card .an-name { font-size: .8rem; color: var(--blue); font-weight: 600; margin-bottom: 8px;
                           white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .an-row { display: flex; justify-content: space-between; font-size: .75rem;
            color: var(--muted); margin-top: 4px; }
  .an-row span:last-child { color: var(--text); font-variant-numeric: tabular-nums; }

  /* ══════════════════════════════════════════════════
     ── Live Chat Section (الجديد) ──
  ══════════════════════════════════════════════════ */
  .chat-kpi-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 14px; margin-bottom: 20px; }

  .chat-feed {
    display: flex; flex-direction: column; gap: 16px;
    max-height: 72vh; overflow-y: auto; padding-right: 4px;
  }
  .chat-feed::-webkit-scrollbar { width: 5px; }
  .chat-feed::-webkit-scrollbar-track { background: transparent; }
  .chat-feed::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

  .turn-card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 12px; padding: 16px 18px;
    animation: slideIn .3s ease;
  }
  @keyframes slideIn { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }

  .turn-header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 12px;
  }
  .session-pill {
    display: inline-flex; align-items: center; gap: 5px;
    background: #1c2128; border: 1px solid var(--border);
    border-radius: 20px; padding: 3px 10px;
    font-size: .72rem; color: var(--muted);
  }
  .session-pill .dot-live { width: 6px; height: 6px; border-radius: 50%;
    background: var(--green); animation: pulse 2s infinite; }
  .turn-meta { display: flex; gap: 12px; font-size: .72rem; color: var(--muted); }
  .turn-meta .lat  { color: var(--yellow); }
  .turn-meta .src  { color: var(--teal); }
  .turn-meta .time { }

  .bubble-row { display: flex; flex-direction: column; gap: 10px; }

  .bubble {
    max-width: 90%; padding: 10px 14px; border-radius: 10px;
    font-size: .85rem; line-height: 1.55; white-space: pre-wrap; word-break: break-word;
  }
  .bubble.user {
    background: #1f2d3d; border: 1px solid #2a4060;
    color: #a8d4f5; align-self: flex-end; border-bottom-left-radius: 3px;
  }
  .bubble.user::before { content: "👤 المستخدم"; display: block;
    font-size: .68rem; color: var(--blue); margin-bottom: 5px; font-weight: 600; }
  .bubble.assistant {
    background: #1a2318; border: 1px solid #2a4030;
    color: #a8d4b0; align-self: flex-start; border-bottom-right-radius: 3px;
  }
  .bubble.assistant::before { content: "🤖 RAG"; display: block;
    font-size: .68rem; color: var(--green); margin-bottom: 5px; font-weight: 600; }

  .no-turns {
    text-align: center; padding: 60px 20px; color: var(--muted);
    border: 1px dashed var(--border); border-radius: 12px;
  }
  .no-turns .icon { font-size: 2.5rem; margin-bottom: 12px; }
  .no-turns p { font-size: .85rem; }

  footer { text-align: center; padding: 20px; color: var(--muted); font-size: .72rem; }
</style>
</head>
<body>

<header>
  <h1>⬡ Observability Dashboard</h1>
  <div id="status"><div id="dot"></div><span id="svc">—</span> &nbsp;|&nbsp; آخر تحديث: <span id="ts">—</span></div>
</header>

<!-- Tabs -->
<div class="tabs">
  <button class="tab-btn active" onclick="switchTab('metrics')">📊 المقاييس</button>
  <button class="tab-btn"        onclick="switchTab('chat')">💬 Live Chat</button>
  <button class="tab-btn"        onclick="switchTab('alerts')">🔔 التنبيهات</button>
  <button class="tab-btn"        onclick="switchTab('anomaly')">🧠 الشذوذ</button>
</div>

<!-- ═══════ Tab: Metrics ═══════ -->
<div id="tab-metrics" class="tab-panel active">
<main>
  <div class="kpi-row" id="kpis">
    <div class="kpi"><div class="label">المقاييس</div><div class="val" id="kpi-metrics">—</div></div>
    <div class="kpi"><div class="label">إجمالي القياسات</div><div class="val" id="kpi-total">—</div></div>
    <div class="kpi"><div class="label">التنبيهات</div><div class="val" id="kpi-alerts">—</div></div>
    <div class="kpi"><div class="label">الشذوذات</div><div class="val" id="kpi-anomalies">—</div></div>
    <div class="kpi"><div class="label">Rate Limiter</div><div class="val" id="kpi-rl">—</div><div class="sub">tokens</div></div>
    <div class="kpi"><div class="label">Storage</div><div class="val" id="kpi-storage" style="font-size:1rem;margin-top:8px">—</div></div>
  </div>

  <div>
    <div class="section-title">📊 المقاييس — آخر 60 ثانية</div>
    <div class="card">
      <table>
        <thead>
          <tr>
            <th>المقياس</th><th>عدد</th><th>متوسط</th><th>min</th><th>max</th>
            <th>p90</th><th>p99</th><th>std</th>
          </tr>
        </thead>
        <tbody id="metrics-body">
          <tr><td colspan="8" class="empty">جارٍ التحميل…</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</main>
</div>

<!-- ═══════ Tab: Live Chat (الجديد) ═══════ -->
<div id="tab-chat" class="tab-panel">
<main>
  <!-- Chat KPIs -->
  <div class="chat-kpi-row">
    <div class="kpi"><div class="label">إجمالي المحادثات</div><div class="val" id="chat-kpi-total">—</div></div>
    <div class="kpi"><div class="label">في الذاكرة</div><div class="val" id="chat-kpi-buffered">—</div></div>
    <div class="kpi"><div class="label">جلسات مختلفة</div><div class="val" id="chat-kpi-sessions">—</div></div>
    <div class="kpi"><div class="label">متوسط الاستجابة</div><div class="val" id="chat-kpi-latency">—</div><div class="sub">ms</div></div>
  </div>

  <div class="section-title">💬 محادثات RAG المباشرة</div>
  <div id="chat-feed" class="chat-feed">
    <div class="no-turns">
      <div class="icon">💬</div>
      <p>لا توجد محادثات بعد — ستظهر هنا فور بدء المستخدمين في الاستعلام</p>
    </div>
  </div>
</main>
</div>

<!-- ═══════ Tab: Alerts ═══════ -->
<div id="tab-alerts" class="tab-panel">
<main>
  <div class="section-title">🔔 التنبيهات النشطة — آخر ساعة</div>
  <div class="alerts-list" id="alerts-list">
    <div class="empty">لا توجد تنبيهات</div>
  </div>
</main>
</div>

<!-- ═══════ Tab: Anomaly ═══════ -->
<div id="tab-anomaly" class="tab-panel">
<main>
  <div class="section-title">🧠 إحصائيات كشف الشذوذ</div>
  <div class="anomaly-grid" id="anomaly-grid">
    <div class="empty">لا توجد بيانات</div>
  </div>
</main>
</div>

<footer>ObservabilitySystem — Live Dashboard &nbsp;|&nbsp; يتحدث كل 3 ثوانٍ عبر SSE</footer>

<script>
// ── Tab switching ────────────────────────────────────────────────────────
function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach((b,i) => {
    const names = ['metrics','chat','alerts','anomaly'];
    b.classList.toggle('active', names[i] === name);
  });
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('active', p.id === 'tab-' + name);
  });
}

// ── Utils ────────────────────────────────────────────────────────────────
const fmt      = (n, d=2) => n == null ? '—' : (+n).toFixed(d);
const fmtTime  = ts => new Date(ts*1000).toLocaleTimeString('ar-EG');
const fmtMs    = ms => ms == null ? '—' : Math.round(ms) + ' ms';
const esc      = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const truncate = (s, n=300) => s.length > n ? s.slice(0, n) + '…' : s;

// ── SSE ──────────────────────────────────────────────────────────────────
const es  = new EventSource('/stream');
const dot = document.getElementById('dot');

es.onmessage = e => { renderAll(JSON.parse(e.data)); };
es.onerror   = () => { dot.style.background = 'var(--red)'; dot.style.boxShadow = '0 0 6px var(--red)'; };
es.onopen    = () => { dot.style.background = 'var(--green)'; dot.style.boxShadow = '0 0 6px var(--green)'; };

// ── Render ───────────────────────────────────────────────────────────────
function renderAll(d) {
  const s = d.stats || {};
  document.getElementById('svc').textContent = d.service + ' [' + d.environment + ']';
  document.getElementById('ts').textContent  = fmtTime(d.timestamp);

  // KPIs
  document.getElementById('kpi-metrics').textContent   = s.unique_metrics ?? '—';
  document.getElementById('kpi-total').textContent     = s.total_recorded  ?? '—';
  document.getElementById('kpi-alerts').textContent    = s.total_alerts    ?? '—';
  document.getElementById('kpi-anomalies').textContent = s.total_anomalies ?? '—';
  document.getElementById('kpi-rl').textContent        = s.rate_limiter_tokens != null ? Math.round(s.rate_limiter_tokens) : '—';
  document.getElementById('kpi-storage').textContent   = s.storage_backend ?? '—';

  // Metrics table
  const tbody   = document.getElementById('metrics-body');
  const entries = Object.entries(d.metrics || {});
  if (!entries.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="empty">لا توجد مقاييس بعد</td></tr>';
  } else {
    tbody.innerHTML = entries.map(([name, m]) => `
      <tr>
        <td class="metric-name">${name}</td>
        <td class="num">${m.count ?? '—'}</td>
        <td class="num">${fmt(m.mean)}</td>
        <td class="num">${fmt(m.min)}</td>
        <td class="num">${fmt(m.max)}</td>
        <td class="num">${fmt(m.p90)}</td>
        <td class="num">${fmt(m.p99)}</td>
        <td class="num">${fmt(m.std)}</td>
      </tr>`).join('');
  }

  // Alerts
  const alertsEl = document.getElementById('alerts-list');
  const alerts   = d.alerts || [];
  if (!alerts.length) {
    alertsEl.innerHTML = '<div class="empty">✅ لا توجد تنبيهات نشطة</div>';
  } else {
    alertsEl.innerHTML = alerts.slice(0,50).map(a => `
      <div class="alert-item ${a.severity}">
        <span class="badge ${a.severity}">${a.severity}</span>
        <span class="alert-msg"><b>${a.metric_name}</b> — ${a.message}</span>
        <span class="alert-ts">${fmtTime(a.timestamp)}</span>
      </div>`).join('');
  }

  // Anomaly
  const anomalyEl = document.getElementById('anomaly-grid');
  const an        = d.anomaly_stats || {};
  const anEntries = Object.entries(an).filter(([,v]) => v && v.samples > 0);
  if (!anEntries.length) {
    anomalyEl.innerHTML = '<div class="empty">لا توجد بيانات شذوذ</div>';
  } else {
    anomalyEl.innerHTML = anEntries.map(([name, v]) => `
      <div class="anomaly-card">
        <div class="an-name" title="${name}">${name}</div>
        <div class="an-row"><span>عينات</span><span>${v.samples}</span></div>
        <div class="an-row"><span>متوسط</span><span>${fmt(v.mean)}</span></div>
        <div class="an-row"><span>std</span><span>${fmt(v.std)}</span></div>
        <div class="an-row"><span>p25</span><span>${fmt(v.p25)}</span></div>
        <div class="an-row"><span>p75</span><span>${fmt(v.p75)}</span></div>
      </div>`).join('');
  }

  // ── Live Chat (الجديد) ────────────────────────────────────────────────
  renderChat(d.conversations || [], d.conversation_stats || {});
}

function renderChat(turns, stats) {
  // KPIs
  document.getElementById('chat-kpi-total').textContent    = stats.total_logged    ?? '—';
  document.getElementById('chat-kpi-buffered').textContent = stats.buffered        ?? '—';
  document.getElementById('chat-kpi-sessions').textContent = stats.unique_sessions ?? '—';
  document.getElementById('chat-kpi-latency').textContent  =
    stats.avg_latency_ms != null ? Math.round(stats.avg_latency_ms) : '—';

  const feed = document.getElementById('chat-feed');
  if (!turns.length) {
    feed.innerHTML = `
      <div class="no-turns">
        <div class="icon">💬</div>
        <p>لا توجد محادثات بعد — ستظهر هنا فور بدء المستخدمين في الاستعلام</p>
      </div>`;
    return;
  }

  feed.innerHTML = turns.map(t => `
    <div class="turn-card">
      <div class="turn-header">
        <span class="session-pill">
          <span class="dot-live"></span>
          ${esc(t.session_id)}
        </span>
        <div class="turn-meta">
          ${t.latency_ms  != null ? `<span class="lat">⚡ ${Math.round(t.latency_ms)} ms</span>` : ''}
          ${t.sources_count != null ? `<span class="src">📄 ${t.sources_count} مصادر</span>` : ''}
          <span class="time">${fmtTime(t.timestamp)}</span>
        </div>
      </div>
      <div class="bubble-row">
        <div class="bubble user">${esc(truncate(t.query, 400))}</div>
        <div class="bubble assistant">${esc(truncate(t.answer, 600))}</div>
      </div>
    </div>`).join('');
}
</script>
</body>
</html>
"""


# ═══════════════════════════════════════════════════════════════════════════
# HTTP Handler
# ═══════════════════════════════════════════════════════════════════════════

def _make_handler(
    obs: "ObservabilitySystem",
    refresh_seconds: int,
    conv_logger: Optional[ConversationLogger],
) -> type:
    html_bytes = _HTML.encode("utf-8")

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path in ("/", "/index.html"):
                self._send(200, "text/html; charset=utf-8", html_bytes)

            elif self.path == "/data":
                payload = _snapshot(obs, conv_logger)
                self._send(200, "application/json", json.dumps(payload).encode())

            elif self.path == "/stream":
                global _sse_client_count
                with _sse_lock:
                    if _sse_client_count >= _MAX_SSE_CLIENTS:
                        self._send(503, "text/plain", b"Too many SSE clients")
                        return
                    _sse_client_count += 1

                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                try:
                    while True:
                        try:
                            payload = json.dumps(_snapshot(obs, conv_logger))
                        except Exception as exc:
                            payload = json.dumps({"error": str(exc), "timestamp": time.time()})
                        self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
                        self.wfile.flush()
                        time.sleep(refresh_seconds)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass
                finally:
                    with _sse_lock:
                        _sse_client_count -= 1

            else:
                self._send(404, "text/plain", b"Not Found")

        def _send(self, code: int, ctype: str, body: bytes) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_) -> None:
            pass

    return _Handler


def _snapshot(
    obs: "ObservabilitySystem",
    conv_logger: Optional[ConversationLogger],
) -> dict:
    """يبني snapshot كامل — يشمل بيانات المحادثات إذا كان conv_logger موجوداً"""
    try:
        metric_names = obs.storage.get_metric_names()
    except Exception:
        metric_names = []

    metrics: dict = {}
    for name in metric_names:
        try:
            metrics[name] = obs.get_metrics_summary(name, window_seconds=60)
        except Exception:
            pass

    try:
        alerts = [a.to_dict() for a in obs.get_active_alerts(max_age_seconds=3600)]
    except Exception:
        alerts = []

    anomaly_stats: dict = {}
    for name in metric_names:
        try:
            stats = obs.get_anomaly_stats(name)
            if stats:
                anomaly_stats[name] = stats
        except Exception:
            pass

    try:
        system_stats = obs.get_system_stats()
    except Exception:
        system_stats = {}

    # ── بيانات المحادثات (الجديد) ──────────────────────────────────────
    conversations: list = []
    conversation_stats: dict = {}
    if conv_logger is not None:
        try:
            conversations     = conv_logger.get_recent(50)
            conversation_stats = conv_logger.get_stats()
        except Exception:
            pass

    return {
        "service":            obs.config.service_name,
        "environment":        obs.config.environment,
        "timestamp":          time.time(),
        "stats":              system_stats,
        "metrics":            metrics,
        "alerts":             alerts,
        "anomaly_stats":      anomaly_stats,
        "conversations":      conversations,       # ← جديد
        "conversation_stats": conversation_stats,  # ← جديد
    }


# ═══════════════════════════════════════════════════════════════════════════
# DashboardExporter
# ═══════════════════════════════════════════════════════════════════════════

class DashboardExporter:
    """
    يشغّل HTTP server يخدم dashboard HTML live.

    المسارات:
        /          — الـ dashboard الكامل (مع تبويب Live Chat)
        /stream    — Server-Sent Events (SSE) تتحدث كل refresh_seconds
        /data      — JSON snapshot فوري

    الاستخدام:
        from observability.dashboard import DashboardExporter, ConversationLogger

        conv_logger = ConversationLogger(max_turns=200)

        dash = DashboardExporter(obs, conversation_logger=conv_logger, port=8888)
        dash.start()

        # بعد كل استعلام RAG:
        start = time.time()
        answer = rag.generate(query)
        conv_logger.log(
            session_id="user-123",
            query=query,
            answer=answer,
            latency_ms=(time.time() - start) * 1000,
            sources_count=3,
        )
    """

    def __init__(
        self,
        obs: "ObservabilitySystem",
        port: int = 8888,
        refresh_seconds: int = 3,
        host: str = "0.0.0.0",
        conversation_logger: Optional[ConversationLogger] = None,
    ):
        self._obs     = obs
        self._port    = port
        self._host    = host
        self._refresh = refresh_seconds
        self._conv    = conversation_logger
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    @property
    def url(self) -> str:
        return f"http://{self._host}:{self._port}"

    @property
    def conversation_logger(self) -> Optional[ConversationLogger]:
        """الوصول المباشر للـ ConversationLogger من الخارج."""
        return self._conv

    def set_conversation_logger(self, logger: ConversationLogger) -> None:
        """تعيين أو استبدال الـ ConversationLogger بعد الإنشاء."""
        self._conv = logger

    def start(self) -> None:
        handler = _make_handler(self._obs, self._refresh, self._conv)
        try:
            self._server = HTTPServer((self._host, self._port), handler)
        except OSError as exc:
            raise RuntimeError(
                f"[Dashboard] فشل التشغيل على المنفذ {self._port}: {exc}\n"
                f"تأكد أن المنفذ غير مستخدم أو غيّر port في DashboardExporter(port=...)."
            ) from exc
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            daemon=True,
            name="obs-dashboard",
        )
        self._thread.start()
        chat_status = "✅ مع Live Chat" if self._conv else "⚠️ بدون Live Chat (مرّر conversation_logger=...)"
        print(f"[Dashboard] Live at {self.url}  (refresh every {self._refresh}s) — {chat_status}")

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()

    def export(self) -> bool:
        return True