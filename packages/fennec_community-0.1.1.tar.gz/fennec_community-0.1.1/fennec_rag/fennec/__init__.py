"""
fennec-rag: A comprehensive RAG framework with Arabic language support.
"""

__version__ = "0.1.1"
__author__ = "yousef khalil"
__license__ = "MIT"
