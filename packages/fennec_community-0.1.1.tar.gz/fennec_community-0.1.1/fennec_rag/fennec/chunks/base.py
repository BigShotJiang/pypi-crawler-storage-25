"""
Main interface for document splitting
الواجهة الرئيسية لتقسيم المستندات
"""
from abc import ABC, abstractmethod
from typing import List, Callable, Optional, Dict
from .doc_model import DocumentChunk, Document


class ChunkingStrategy(ABC):
    """
    Abstract base class for chunking strategies\n
    الفئة الأساسية المجردة لاستراتيجيات التقسيم
    """
    
    @abstractmethod
    def chunk(self, text: str, doc_id: str) -> List[DocumentChunk]:
        """
        Split document into chunks\n
        تقسيم المستند إلى قطع
        
        Args:
            text: Text to split | النص المراد تقسيمه
            doc_id: Document identifier | معرف المستند
            
        Returns:
            List of document chunks | قائمة قطع المستند
        """
        pass


class TextSplitter(ABC):
    """
    Abstract base class for text splitting\n
    الفئة الأساسية المجردة لتقسيم النصوص
    """
    
    def __init__(
        self,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        length_function: Callable[[str], int] = len
    ):
        """
        Initialize text splitter\n
        تهيئة مقسم النصوص
        
        Args:
            chunk_size: Maximum size of each chunk | الحد الأقصى لحجم كل قطعة
            chunk_overlap: Overlap between consecutive chunks | التداخل بين القطع المتتالية
            length_function: Function to calculate text length | دالة لحساب طول النص
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.length_function = length_function
    
    @abstractmethod
    def split_text(self, text: str) -> List[str]:
        """
        Split text into chunks\n
        تقسيم النص إلى قطع
        
        Args:
            text: Text to split | النص المراد تقسيمه
            
        Returns:
            List of text chunks | قائمة قطع النص
        """
        pass
    
    def split_documents(self, documents: List[Document]) -> List[Document]:
        """
        Split multiple documents into chunks\n
        تقسيم مستندات متعددة إلى قطع
        
        Args:
            documents: List of documents to split | قائمة المستندات المراد تقسيمها
            
        Returns:
            List of chunked documents | قائمة المستندات المقسمة
        """
        # Extract texts and metadata from documents | استخراج النصوص والبيانات الوصفية من المستندات
        texts, metadatas = [], []
        for doc in documents:
            texts.append(doc.page_content)
            metadatas.append(doc.metadata)
        return self.create_documents(texts, metadatas)
    
    def create_documents(
        self,
        texts: List[str],
        metadatas: Optional[List[Dict]] = None
    ) -> List[Document]:
        """
        Create chunked documents from texts and metadata\n
        إنشاء مستندات مقسمة من النصوص والبيانات الوصفية
        
        Args:
            texts: List of texts to process | قائمة النصوص للمعالجة
            metadatas: Optional list of metadata dictionaries | قائمة اختيارية من قواميس البيانات الوصفية
            
        Returns:
            List of chunked documents | قائمة المستندات المقسمة
        """
        # Use empty metadata if none provided | استخدام بيانات وصفية فارغة إذا لم يتم توفيرها
        metadatas = metadatas or [{}] * len(texts)
        documents = []
        
        # Process each text | معالجة كل نص
        for i, text in enumerate(texts):
            # Split text into chunks | تقسيم النص إلى قطع
            for chunk in self.split_text(text):
                # Copy metadata to preserve original | نسخ البيانات الوصفية للحفاظ على النسخة الأصلية
                metadata = metadatas[i].copy()
                # Create new document for each chunk | إنشاء مستند جديد لكل قطعة
                documents.append(Document(page_content=chunk, metadata=metadata))
        
        return documents