from typing import List
from .base import TextSplitter
from .chunk_config import ChunkConfig

config = ChunkConfig()



class CharacterTextSplitter(TextSplitter):
    """
    Character-based text splitter
    تقسيم النص بناءً على الأحرف
    """
    
    def __init__(
        self,
        separator: str = "\n\n",
        **kwargs
    ):
        """
        Initialize character text splitter\n
        تهيئة مقسم النص بناءً على الأحرف
        
        Args:
            separator: Separator string to split on | سلسلة الفاصل للتقسيم عليها
            **kwargs: Additional arguments for parent class | معاملات إضافية للفئة الأصلية
        """
        super().__init__(**kwargs)
        self.separator = separator
    
    def split_text(self, text: str) -> List[str]:
        """
        Split text into chunks\n
        تقسيم النص إلى قطع
        
        Args:
            text: Text to split | النص المراد تقسيمه
            
        Returns:
            List of text chunks | قائمة قطع النص
        """
        # Split by separator or individual characters | التقسيم بالفاصل أو الأحرف الفردية
        if self.separator:
            splits = text.split(self.separator)
        else:
            splits = list(text)
        
        return self._merge_splits(splits)
    
    def _merge_splits(self, splits: List[str]) -> List[str]:
        """
        Merge small chunks to reach optimal size\n
        دمج القطع الصغيرة للوصول إلى الحجم الأمثل
        
        Args:
            splits: List of split text pieces | قائمة قطع النص المقسمة
            
        Returns:
            List of merged chunks | قائمة القطع المدمجة
        """
        chunks = []
        current_chunk = []
        current_length = 0
        
        for split in splits:
            split_len = self.length_function(split)
            
            # Check if adding this split exceeds chunk size | التحقق من تجاوز حجم القطعة
            if current_length + split_len > self.chunk_size:
                if current_chunk:
                    chunks.append(self.separator.join(current_chunk))
                    
                    # Keep overlap for context preservation | الاحتفاظ بالتداخل للحفاظ على السياق
                    overlap_size = 0
                    current_chunk = []
                    current_length = 0
                    
                    # Add overlap from previous chunk | إضافة التداخل من القطعة السابقة
                    for prev_split in reversed(chunks[-1].split(self.separator)):
                        if overlap_size + self.length_function(prev_split) <= self.chunk_overlap:
                            current_chunk.insert(0, prev_split)
                            overlap_size += self.length_function(prev_split)
                        else:
                            break
            
            # Add current split to chunk | إضافة القطعة الحالية
            current_chunk.append(split)
            current_length += split_len
        
        # Add remaining chunk | إضافة القطعة المتبقية
        if current_chunk:
            chunks.append(self.separator.join(current_chunk))
        
        return chunks


class RecursiveCharacterTextSplitter(TextSplitter):
    """
    Using multiple techniques to hierarchically divide texts\n
    استخدام تقنيات متعدده لتقسيم النصوص بشكل هرمي
    """
    
    def __init__(
        self,
        separators: List[str] = None,
        **kwargs
    ):
        """
        Initialize recursive character text splitter
        تهيئة مقسم النص التدريجي
        
        Args:
            separators: List of separators to try in order | قائمة الفواصل للمحاولة بالترتيب
            **kwargs: Additional arguments for parent class | معاملات إضافية للفئة الأصلية
        """
        super().__init__(**kwargs)
        # Default separators from most to least specific | الفواصل الافتراضية من الأكثر إلى الأقل تحديداً
        self.separators = separators or ["\n\n", "\n", " ", ""]
    
    def split_text(self, text: str) -> List[str]:
        """
        Split text recursively using multiple separators\n
        تقسيم النص بشكل تدريجي باستخدام فواصل متعددة
        
        Args:
            text: Text to split | النص المراد تقسيمه
            
        Returns:
            List of text chunks | قائمة قطع النص
        """
        final_chunks = []
        separator = self.separators[-1]
        
        # Find the first separator that exists in text | إيجاد أول فاصل موجود في النص
        for sep in self.separators:
            if sep in text:
                separator = sep
                break
        
        # Split by chosen separator | التقسيم بالفاصل المختار
        splits = text.split(separator)
        good_splits = []
        
        for split in splits:
            # If split is small enough, keep it | إذا كانت القطعة صغيرة بما يكفي، احتفظ بها
            if self.length_function(split) < self.chunk_size:
                good_splits.append(split)
            else:
                # Process accumulated good splits | معالجة القطع الجيدة المتراكمة
                if good_splits:
                    merged = self._merge_splits(good_splits, separator)
                    final_chunks.extend(merged)
                    good_splits = []
                
                # Recursively split large chunks | تقسيم القطع الكبيرة بشكل تدريجي
                other_chunks = self.split_text(split)
                final_chunks.extend(other_chunks)
        
        # Process remaining good splits | معالجة القطع الجيدة المتبقية
        if good_splits:
            merged = self._merge_splits(good_splits, separator)
            final_chunks.extend(merged)
        
        return final_chunks
    
    def _merge_splits(self, splits: List[str], separator: str) -> List[str]:
        """
        Merge splits into chunks\n
        دمج القطع في أجزاء
        
        Args:
            splits: List of split pieces | قائمة القطع المقسمة
            separator: Separator used for joining | الفاصل المستخدم للدمج
            
        Returns:
            List of merged chunks | قائمة القطع المدمجة
        """
        chunks = []
        current_chunk = []
        current_length = 0
        
        for split in splits:
            split_len = self.length_function(split)
            
            # Check if adding split exceeds size limit | التحقق من تجاوز حد الحجم
            if current_length + split_len > self.chunk_size and current_chunk:
                chunks.append(separator.join(current_chunk))
                current_chunk = []
                current_length = 0
            
            # Add split to current chunk | إضافة القطعة إلى الجزء الحالي
            current_chunk.append(split)
            current_length += split_len
        
        # Add remaining chunk | إضافة الجزء المتبقي
        if current_chunk:
            chunks.append(separator.join(current_chunk))
        return chunks


class TokenTextSplitter(TextSplitter):
    """
    Token-based text splitter using tiktoken\n
    tiktoken مقسم نص يعتمد على الرموز باستخدام 
    """
    
    def __init__(
        self,
        encoding_name: str = config.model_token,
        **kwargs
    ):
        """
        Initialize token text splitter
        تهيئة مقسم النص بناءً على الرموز
        
        Args:
            encoding_name: Name of tiktoken encoding | اسم ترميز tiktoken
            **kwargs: Additional arguments for parent class | معاملات إضافية للفئة الأصلية
        """
        super().__init__(**kwargs)
        try:
            import tiktoken
            self.tokenizer = tiktoken.get_encoding(encoding_name)
        except ImportError:
            raise ImportError("Please install tiktoken: pip install tiktoken ")
    
    def split_text(self, text: str) -> List[str]:
        """
        Split text based on token count
        تقسيم النص بناءً على عدد الرموز
        
        Args:
            text: Text to split | النص المراد تقسيمه
            
        Returns:
            List of text chunks | قائمة قطع النص
        """
        # Encode text to tokens | ترميز النص إلى رموز
        tokens = self.tokenizer.encode(text)
        chunks = []
        
        # Split tokens into chunks with overlap | تقسيم الرموز إلى قطع مع التداخل
        for i in range(0, len(tokens), self.chunk_size - self.chunk_overlap):
            # Extract chunk tokens | استخراج رموز القطعة
            chunk_tokens = tokens[i:i + self.chunk_size]
            # Decode tokens back to text | فك ترميز الرموز إلى نص
            chunk_text = self.tokenizer.decode(chunk_tokens)
            chunks.append(chunk_text)
        
        return chunks