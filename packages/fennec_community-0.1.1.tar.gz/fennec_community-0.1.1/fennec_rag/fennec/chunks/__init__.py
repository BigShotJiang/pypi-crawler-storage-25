"""
نظام تقسيم النصوص المتقدم
يدعم التقسيم الثابت والدلالي والهجين
"""

from .doc_model import DocumentChunk, Document
from .base import ChunkingStrategy, TextSplitter
from .arabic_chunker import ArabicTextChunker
from .multi_chunker import MultilanguageTextChunker
from .text_splitter import (
    CharacterTextSplitter,
    RecursiveCharacterTextSplitter,
    TokenTextSplitter
)
from .chunk_config import ChunkConfig
__all__ = [
    # النماذج
    'DocumentChunk',
    'Document',
    
    # الاستراتيجيات الأساسية
    'ChunkingStrategy',
    'TextSplitter',
    
    # استراتيجيات التقسيم
    'ArabicTextChunker',
    'MultilanguageTextChunker',
    
    # مقسمات النصوص
    'CharacterTextSplitter',
    'RecursiveCharacterTextSplitter',
    'TokenTextSplitter',
    'ChunkConfig'
]

