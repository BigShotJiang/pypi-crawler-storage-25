"""
نماذج البيانات الأساسية لنظام التقسيم
"""
from dataclasses import dataclass, field
from typing import Optional, Dict
import numpy as np


@dataclass
class DocumentChunk:
    chunk_id: str
    doc_id: str
    text: str
    embedding: Optional[np.ndarray] = None
    metadata: Dict = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.chunk_id or not self.doc_id:
            raise ValueError("chunk_id and doc_id are required")
        if not self.text or not self.text.strip():
            raise ValueError("text is required and cannot be empty")
    
    @property
    def id(self):
        return self.chunk_id


@dataclass
class Document:
    """document text and metadata"""
    page_content: str
    metadata: Dict = field(default_factory=dict)