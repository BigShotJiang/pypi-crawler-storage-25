import re
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from .doc_model import DocumentChunk
from .chunk_config import ChunkConfig
import warnings
import logging

warnings.filterwarnings('ignore')

config = ChunkConfig()

# Lazy imports – loaded only when the class is actually instantiated
def _load_torch_and_transformers():
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForTokenClassification, AutoModel
        return torch, AutoTokenizer, AutoModelForTokenClassification, AutoModel
    except ImportError as e:
        raise ImportError(
            "⚠ Required libraries not found: torch and transformers. Please install them to use MultilanguageTextChunker.\n"
            "pip install torch transformers\n"
            f"   Original error: {e}"
        ) from e


class MultilanguageTextChunker:

    # Sentence delimiters for multiple languages | فواصل الجمل لعدة لغات
    SENTENCE_DELIMITERS = r'[.!?。！？।।॥\n]'
    
    # Language patterns for detection | أنماط اللغات للكشف
    LANGUAGE_PATTERNS = {
        'arabic': re.compile(r'[\u0600-\u06FF]+'),
        'chinese': re.compile(r'[\u4e00-\u9fff]+'),
        'japanese': re.compile(r'[\u3040-\u309f\u30a0-\u30ff]+'),
        'korean': re.compile(r'[\uac00-\ud7af]+'),
        'cyrillic': re.compile(r'[\u0400-\u04FF]+'),
        'devanagari': re.compile(r'[\u0900-\u097F]+'),
        'thai': re.compile(r'[\u0E00-\u0E7F]+'),
        'hebrew': re.compile(r'[\u0590-\u05FF]+'),
    }
    
    # Recommended models for different languages | النماذج الموصى بها للغات المختلفة
    LANGUAGE_MODELS = {
        'multilingual': config.multilingual,  # Default for all languages | افتراضي لجميع اللغات
        'english': config.english,
        'arabic': config.arabic,
        'chinese': config.chinese,
        'french': config.french,
        'german': config.german,
        'spanish': config.spanish,
        'russian': config.russian,
        'japanese': config.japanese,
        'korean': config.korean,
        'portuguese': config.portuguese,
        'italian': config.italian,
        'dutch': config.dutch,
        'polish': config.polish,
        'turkish': config.turkish,
        'vietnamese': config.vietnamese,
        'hindi': config.hindi,
    }
    
    def __init__(
        self, 
        chunk_size: int = config.chunk_size, 
        overlap: int = config.overlap,
        min_chunk_size: int = config.min_chunk_size,
        model_name: Optional[str] = None,
        language: str = 'auto',
        use_semantic_chunking: bool = config.use_semantic_chunking,
        device: Optional[str] = None,
        use_smart_overlap: bool = True,  # NEW: Enable smart overlap
        smart_overlap_threshold: float = 0.7,  # NEW: Similarity threshold
        strict_size_limit: bool = True,  # NEW: Enforce strict size limits
        size_tolerance: float = 0.05,  # NEW: 5% tolerance
    ):
        """
        Initialize multilingual text chunker with Smart Overlap\n
        تهيئة محلل النصوص متعدد اللغات مع التداخل الذكي
        
        Args:
            chunk_size: Maximum chunk size in characters | الحد الأقصى لحجم القطعة بالأحرف
            overlap: Number of overlapping characters between chunks | عدد الأحرف المتداخلة بين القطع
            min_chunk_size: Minimum chunk size | الحد الأدنى لحجم القطعة
            model_name: Hugging Face model name (auto-selected if None) | اسم نموذج Hugging Face
            language: Target language ('auto', 'english', 'arabic', etc.) | اللغة المستهدفة
            use_semantic_chunking: Use intelligent semantic chunking | استخدام التقسيم الدلالي الذكي
            device: Device to use (cpu/cuda) | الجهاز المستخدم
            use_smart_overlap: Enable smart semantic overlap | تفعيل التداخل الذكي الدلالي
            smart_overlap_threshold: Similarity threshold for overlap | عتبة التشابه للتداخل
            strict_size_limit: Enforce strict chunk size limits | فرض حدود صارمة للحجم
            size_tolerance: Tolerance factor for size limits | معامل التسامح لحدود الحجم
        """
        # Validate parameters | التحقق من صحة المعاملات
        if chunk_size <= 0 or overlap < 0:
            raise ValueError("chunk_size must be positive and overlap non-negative ")
        if overlap >= chunk_size:
            raise ValueError("overlap must be less than chunk_size ")
        if min_chunk_size <= 0 or min_chunk_size > chunk_size:
            raise ValueError("Invalid min_chunk_size ")
            
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.min_chunk_size = min_chunk_size
        self.use_semantic_chunking = use_semantic_chunking
        self.language = language.lower()
        self.use_smart_overlap = use_smart_overlap
        self.smart_overlap_threshold = smart_overlap_threshold
        self.strict_size_limit = strict_size_limit
        self.size_tolerance = size_tolerance
        
        # Calculate effective max size | حساب الحد الأقصى الفعلي
        self.effective_max_size = int(self.chunk_size * (1 + self.size_tolerance))
        
        # Lazy-load torch and transformers | تحميل المكتبات الثقيلة عند الحاجة
        torch, AutoTokenizer, AutoModelForTokenClassification, AutoModel = _load_torch_and_transformers()
        self._torch = torch
        self._AutoTokenizer = AutoTokenizer
        self._AutoModelForTokenClassification = AutoModelForTokenClassification
        self._AutoModel = AutoModel
        
        # Determine device | تحديد الجهاز
        if device is None:
            self.device = "cuda" if self._torch.cuda.is_available() else "cpu"
        else:
            self.device = device
        
        # Setup logger | إعداد المسجل
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        # Auto-select model based on language | اختيار النموذج تلقائياً بناءً على اللغة
        if model_name is None:
            if self.language == 'auto':
                model_name = self.LANGUAGE_MODELS['multilingual']
            else:
                model_name = self.LANGUAGE_MODELS.get(
                    self.language, 
                    self.LANGUAGE_MODELS['multilingual']
                )
        
        self.model_name = model_name
        
        # Load model and tokenizer | تحميل النموذج والمحلل اللغوي
        self._initialize_model(model_name)

    def _initialize_model(self, model_name: str):
        """
        Load model and tokenizer | تحميل النموذج والمحلل اللغوي
        """
        try:
            self.tokenizer = self._AutoTokenizer.from_pretrained(model_name)
            if self.use_semantic_chunking:
                # Try AutoModel first (better for embeddings)
                try:
                    self.model = self._AutoModel.from_pretrained(model_name)
                except:
                    # Fallback to token classification model
                    self.model = self._AutoModelForTokenClassification.from_pretrained(model_name)
                
                self.model.to(self.device)
                self.model.eval()
            else:
                self.model = None
            
            self.logger.info(f"✓ Model loaded: {model_name} on {self.device}")
        except Exception as e:
            self.logger.error(f"⚠ Failed to load model: {e} ")
            self.logger.info("Falling back to traditional chunking without model. ")
            self.tokenizer = None
            self.model = None
            self.use_semantic_chunking = False
            self.use_smart_overlap = False

    def detect_language(self, text: str) -> str:
        """
        Detect the primary language of the text\n
        كشف اللغة الأساسية للنص
        
        Args:
            text: Text to analyze | النص للتحليل
            
        Returns:
            Detected language code | رمز اللغة المكتشفة
        """
        text_sample = text[:1000]  # Sample for detection | عينة للكشف
        
        # Count matches for each language pattern | عد التطابقات لكل نمط لغة
        language_scores = {}
        for lang, pattern in self.LANGUAGE_PATTERNS.items():
            matches = len(pattern.findall(text_sample))
            if matches > 0:
                language_scores[lang] = matches
        
        if language_scores:
            detected = max(language_scores, key=language_scores.get)
            self.logger.debug(f"Detected language: {detected} ")
            return detected
        
        # Default to English if no specific pattern found | الافتراضي إلى الإنجليزية
        return 'english'

    def _get_sentence_delimiters(self, language: str) -> str:
        """
        Get appropriate sentence delimiters for the language\n
        الحصول على فواصل الجمل المناسبة للغة
        """
        delimiters = {
            'chinese': r'[。！？\n]',
            'japanese': r'[。！？\n]',
            'thai': r'[.!?।\n]',
            'hindi': r'[।॥.!?\n]',
            'arabic': r'[.!?؟\n]',
        }
        return delimiters.get(language, self.SENTENCE_DELIMITERS)

    def _split_into_sentences_hf(self, text: str) -> List[str]:
        """
        Split text into sentences using Hugging Face model\n
        تقسيم النص إلى جمل باستخدام نموذج Hugging Face
        """
        if not self.tokenizer or not self.use_semantic_chunking:
            return self._split_into_sentences_traditional(text)
        
        try:
            # Tokenize text | ترميز النص
            inputs = self.tokenizer(
                text,
                return_tensors=config.return_tensor,
                truncation=config.truncation,
                max_length=config.max_len,
                padding=config.padding
            ).to(self.device)
            
            # Get embeddings | الحصول على التضمينات
            with self._torch.no_grad():
                outputs = self.model(**inputs)
                # Handle different model outputs
                if hasattr(outputs, 'last_hidden_state'):
                    embeddings = outputs.last_hidden_state
                else:
                    embeddings = outputs.logits
            
            # Extract sentences from embeddings | استخراج الجمل من التضمينات
            sentences = self._extract_sentences_from_embeddings(text, inputs, embeddings)
            
            return sentences if sentences else self._split_into_sentences_traditional(text)
            
        except Exception as e:
            self.logger.warning(f"⚠ Error in intelligent chunking: {e} ")
            return self._split_into_sentences_traditional(text)

    def _extract_sentences_from_embeddings(
        self, 
        text: str, 
        inputs: dict, 
        embeddings: Any
    ) -> List[str]:
        """
        Extract sentences from model embeddings\n
        استخراج الجمل من تضمينات النموذج
        """
        # Convert tokens to words | تحويل الرموز إلى كلمات
        tokens = self.tokenizer.convert_ids_to_tokens(inputs['input_ids'][0])
        
        # Find potential sentence breaks | البحث عن فواصل الجمل المحتملة
        sentences = []
        current_sentence = []
        
        for i, token in enumerate(tokens):
            # Skip special tokens | تخطي الرموز الخاصة
            if token in ['[CLS]', '[PAD]', '[SEP]', '<s>', '</s>', '<pad>', '<unk>']:
                continue
            
            # Handle subword tokens (BERT-style) | معالجة رموز الكلمات الفرعية
            if token.startswith('##'):
                word = token[2:]
            elif token.startswith('▁'):  # SentencePiece style
                word = ' ' + token[1:]
            else:
                word = token if not current_sentence else ' ' + token
            
            current_sentence.append(word)
            
            # Check for sentence boundaries | التحقق من حدود الجمل
            if self._is_sentence_boundary(token, i, embeddings):
                sentence_text = ''.join(current_sentence).strip()
                if sentence_text:
                    sentences.append(sentence_text)
                current_sentence = []
        
        # Add last sentence | إضافة الجملة الأخيرة
        if current_sentence:
            sentence_text = ''.join(current_sentence).strip()
            if sentence_text:
                sentences.append(sentence_text)
        
        # Fallback to traditional if failed | الرجوع إلى التقليدي في حالة الفشل
        if not sentences:
            return self._split_into_sentences_traditional(text)
        
        return self._merge_short_sentences(sentences)

    def _is_sentence_boundary(
        self, 
        token: str, 
        position: int, 
        embeddings: Any
    ) -> bool:
        """
        Determine if position represents sentence end\n\n
        تحديد ما إذا كان الموقع يمثل نهاية جملة
        """
        # Check for punctuation marks | التحقق من علامات الترقيم
        if re.match(self.SENTENCE_DELIMITERS, token):
            return True
        
        # Use embedding changes to determine boundaries | استخدام تغيرات التضمين
        if position > 0 and position < embeddings.shape[1] - 1:
            # Calculate difference between consecutive embeddings
            diff = self._torch.norm(
                embeddings[0, position] - embeddings[0, position + 1]
            ).item()
            # If difference is large, might be sentence boundary
            if diff > 2.5:  # Adjustable threshold
                return True
        
        return False

    def _split_into_sentences_traditional(self, text: str) -> List[str]:
        """
        Split text into sentences using traditional method\n
        تقسيم النص إلى جمل باستخدام الطريقة التقليدية
        """
        # Detect language if auto mode | كشف اللغة إذا كان في الوضع التلقائي
        if self.language == 'auto':
            detected_lang = self.detect_language(text)
            delimiters = self._get_sentence_delimiters(detected_lang)
        else:
            delimiters = self._get_sentence_delimiters(self.language)
        
        # Split based on punctuation | التقسيم بناءً على علامات الترقيم
        sentences = re.split(delimiters, text)
        
        # Clean sentences | تنظيف الجمل
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return self._merge_short_sentences(sentences)

    def _merge_short_sentences(self, sentences: List[str]) -> List[str]:
        """
        Merge very short sentences with the next one\n
        دمج الجمل القصيرة جداً مع التالية
        """
        if not sentences:
            return []
        
        merged = []
        buffer = ""
        min_sentence_length = 30
        
        for sent in sentences:
            if buffer and not buffer.endswith(' '):
                buffer += ' '
            
            if len(buffer) < min_sentence_length and buffer:
                buffer += sent
            else:
                if buffer:
                    merged.append(buffer.strip())
                buffer = sent
        
        if buffer:
            merged.append(buffer.strip())
        
        return merged

    def _calculate_semantic_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate semantic similarity between two texts\n
        حساب التشابه الدلالي بين نصين
        """
        if not self.tokenizer or not self.model:
            return 0.0
        
        try:
            # Convert texts to embeddings | تحويل النصوص إلى تضمينات
            inputs1 = self.tokenizer(
                text1, 
                return_tensors="pt", 
                truncation=True,
                max_length=config.max_len,
                padding=True
            ).to(self.device)
            
            inputs2 = self.tokenizer(
                text2, 
                return_tensors="pt", 
                truncation=True,
                max_length=config.max_len,
                padding=True
            ).to(self.device)
            
            with self._torch.no_grad():
                outputs1 = self.model(**inputs1)
                outputs2 = self.model(**inputs2)
                
                # Handle different model outputs
                if hasattr(outputs1, 'last_hidden_state'):
                    emb1 = outputs1.last_hidden_state.mean(dim=1)
                    emb2 = outputs2.last_hidden_state.mean(dim=1)
                else:
                    emb1 = outputs1.logits.mean(dim=1)
                    emb2 = outputs2.logits.mean(dim=1)
            
            # Calculate cosine similarity | حساب تشابه جيب التمام
            similarity = self._torch.nn.functional.cosine_similarity(emb1, emb2)
            return similarity.item()
            
        except Exception as e:
            self.logger.debug(f"Similarity calculation failed: {e}")
            return 0.0

    def _calculate_overlap_sentences(self, sentences: List[str]) -> int:
        """
        Calculate number of sentences for overlap\n
        حساب عدد الجمل للتداخل
        """
        if not sentences:
            return 0
        
        total_chars = sum(len(s) for s in sentences)
        avg_sentence_length = total_chars / len(sentences)
        
        if avg_sentence_length == 0:
            return 1
        
        overlap_sentences = max(1, int(self.overlap / avg_sentence_length))
        return min(overlap_sentences, len(sentences))

    def _apply_smart_overlap(
        self,
        previous_chunk: List[str],
        current_buffer: List[str]
    ) -> List[str]:
        """
        🧠 SMART OVERLAP: Select overlap sentences based on semantic similarity\n
        تداخل ذكي: اختيار جمل التداخل بناءً على التشابه الدلالي
        """
        # حالة خاصة: لا يوجد تداخل
        if not previous_chunk or self.overlap == 0:
            return []
        
        # حساب عدد جمل التداخل المطلوبة
        overlap_count = self._calculate_overlap_sentences(previous_chunk)
        
        # الحصول على المرشحين من نهاية القطعة السابقة
        candidate_count = min(overlap_count * 2, len(previous_chunk))
        candidates = previous_chunk[-candidate_count:]
        
        # إذا كان التداخل الذكي مُفعّل وهناك محتوى جديد
        if self.use_smart_overlap and self.use_semantic_chunking and current_buffer:
            # الجملة الأولى من القطعة الجديدة للمقارنة
            first_new_sentence = current_buffer[0]
            
            # حساب درجة التشابه لكل جملة مرشحة
            similarities = []
            for candidate in candidates:
                sim = self._calculate_semantic_similarity(candidate, first_new_sentence)
                similarities.append((candidate, sim))
            
            # ترتيب حسب التشابه (الأعلى أولاً)
            similarities.sort(key=lambda x: x[1], reverse=True)
            
            # أخذ الجمل الأكثر ارتباطاً
            overlap_sentences = [s[0] for s in similarities[:overlap_count]]
            
            # معلومات للـ debugging
            if similarities:
                avg_similarity = sum(s[1] for s in similarities[:overlap_count]) / len(similarities[:overlap_count])
                self.logger.debug(f"🔗 Smart Overlap: {len(overlap_sentences)} sentences, avg similarity: {avg_similarity:.2f}")
            
            return overlap_sentences
        
        # Fallback: التداخل التقليدي
        overlap_sentences = previous_chunk[-overlap_count:] if overlap_count > 0 else []
        
        if overlap_sentences:
            self.logger.debug(f"📋 Traditional Overlap: {len(overlap_sentences)} sentences")
        
        return overlap_sentences

    def _split_long_sentence(self, sentence: str) -> List[str]:
        """
        Split a very long sentence into smaller parts
        تقسيم جملة طويلة جداً إلى أجزاء أصغر
        """
        words = sentence.split()
        chunks = []
        current_chunk = []
        current_length = 0
        
        for word in words:
            word_len = len(word) + 1
            
            if current_length + word_len > self.chunk_size and current_chunk:
                chunk_text = " ".join(current_chunk)
                chunks.append(chunk_text)
                self.logger.debug(f"  📏 Split long sentence: {len(chunk_text)} chars")
                current_chunk = []
                current_length = 0
            
            current_chunk.append(word)
            current_length += word_len
        
        if current_chunk:
            chunks.append(" ".join(current_chunk))
        
        return chunks

    def _validate_chunk_size(self, chunk_text: str, chunk_index: int) -> bool:
        """
        Validate that chunk size is within acceptable limits
        التحقق من أن حجم القطعة ضمن الحدود المقبولة
        """
        actual_length = len(chunk_text)
        
        # Check if exceeds strict limit
        if self.strict_size_limit and actual_length > self.effective_max_size:
            self.logger.error(f"❌ ERROR: Chunk {chunk_index} exceeds limit: {actual_length} > {self.effective_max_size}")
            return False
        
        # Warning for exceeding base size but within tolerance
        if actual_length > self.chunk_size:
            excess_percent = ((actual_length - self.chunk_size) / self.chunk_size) * 100
            self.logger.warning(f"⚠️ Chunk {chunk_index} exceeds base size by {excess_percent:.1f}%: {actual_length} vs {self.chunk_size}")
        
        return True

    def chunk(self, text: str, doc_id: str) -> List[DocumentChunk]:
        """
        Split text into intelligent overlapping chunks with SMART OVERLAP\n
        تقسيم النص إلى قطع متداخلة ذكية مع التداخل الذكي
        """
        if not text or not text.strip():
            return []
        
        # Split into sentences using model | تقسيم إلى جمل باستخدام النموذج
        sentences = self._split_into_sentences_hf(text)
        if not sentences:
            return []
        
        self.logger.info(f"📊 Text split into {len(sentences)} sentences ")
        self.logger.info(f"📏 Size limits: base={self.chunk_size}, max={self.effective_max_size}")
        
        if self.use_smart_overlap and self.use_semantic_chunking:
            self.logger.info(f"🧠 Smart Overlap: ENABLED (threshold={self.smart_overlap_threshold})")
        else:
            self.logger.info(f"📋 Smart Overlap: DISABLED (using traditional overlap)")
        
        chunks = []
        current_buffer = []
        current_length = 0
        previous_chunk_sentences = []  # NEW: Track previous chunk for smart overlap
        
        for i, sentence in enumerate(sentences):
            sentence_length = len(sentence)
            
            # Handle sentences longer than chunk_size
            if sentence_length > self.chunk_size:
                self.logger.warning(f"⚠️ Long sentence detected: {sentence_length} chars (limit: {self.chunk_size})")
                
                # Save current buffer first
                if current_buffer:
                    chunk_text = " ".join(current_buffer)
                    if len(chunk_text) >= self.min_chunk_size and self._validate_chunk_size(chunk_text, len(chunks)):
                        chunks.append(self._create_chunk(doc_id, len(chunks), chunk_text, previous_chunk_sentences))
                        previous_chunk_sentences = current_buffer.copy()
                    current_buffer = []
                    current_length = 0
                
                # Split long sentence
                sub_chunks = self._split_long_sentence(sentence)
                for sub_chunk in sub_chunks:
                    if len(sub_chunk) >= self.min_chunk_size and self._validate_chunk_size(sub_chunk, len(chunks)):
                        chunks.append(self._create_chunk(doc_id, len(chunks), sub_chunk, previous_chunk_sentences))
                        previous_chunk_sentences = [sub_chunk]
                continue
            
            # Check if adding this sentence will exceed limit
            will_exceed_base = current_length + sentence_length + 1 > self.chunk_size
            will_exceed_max = current_length + sentence_length + 1 > self.effective_max_size
            
            # If we exceed max size | إذا تجاوزنا الحد الأقصى
            if will_exceed_base and current_buffer:
                # Check semantic similarity for merging
                can_merge_semantically = False
                
                if self.use_semantic_chunking and i < len(sentences) - 1 and not will_exceed_max:
                    similarity = self._calculate_semantic_similarity(
                        current_buffer[-1],
                        sentence
                    )
                    # If similarity is high, continue in same chunk
                    if similarity > self.smart_overlap_threshold:
                        can_merge_semantically = True
                        self.logger.debug(f"  🔗 Semantic merge: similarity={similarity:.2f}")
                
                if not can_merge_semantically:
                    # Create chunk | إنشاء القطعة
                    chunk_text = " ".join(current_buffer)
                    actual_length = len(chunk_text)
                    
                    if actual_length >= self.min_chunk_size and self._validate_chunk_size(chunk_text, len(chunks)):
                        chunks.append(self._create_chunk(doc_id, len(chunks), chunk_text, previous_chunk_sentences))
                        self.logger.info(f"  ✓ Chunk {len(chunks)}: {actual_length}/{self.chunk_size} chars, {len(current_buffer)} sentences")
                    
                    # 🧠 SMART OVERLAP: Apply intelligent overlap selection
                    previous_chunk_sentences = current_buffer.copy()
                    overlap_sentences = self._apply_smart_overlap(
                        previous_chunk=previous_chunk_sentences,
                        current_buffer=[sentence]
                    )
                    
                    current_buffer = overlap_sentences
                    current_length = sum(len(s) + 1 for s in current_buffer)
            
            # Add current sentence | إضافة الجملة الحالية
            current_buffer.append(sentence)
            current_length += sentence_length + 1
        
        # Process remaining sentences | معالجة الجمل المتبقية
        if current_buffer:
            chunk_text = " ".join(current_buffer)
            if len(chunk_text) >= self.min_chunk_size and self._validate_chunk_size(chunk_text, len(chunks)):
                chunks.append(self._create_chunk(doc_id, len(chunks), chunk_text, previous_chunk_sentences))
                self.logger.info(f"  ✓ Chunk {len(chunks)} (last): {len(chunk_text)}/{self.chunk_size} chars")
        
        self.logger.info(f"✅ Total chunks: {len(chunks)} ")
        
        # Final validation summary
        oversized_chunks = sum(1 for c in chunks if len(c.text) > self.chunk_size)
        if oversized_chunks > 0:
            self.logger.warning(f"⚠️ {oversized_chunks} chunks exceed base size (within tolerance)")
        
        return chunks

    def _create_chunk(
        self, 
        doc_id: str, 
        index: int, 
        text: str,
        previous_chunk_sentences: List[str] = None
    ) -> DocumentChunk:
        """
        Create DocumentChunk object with enhanced metadata including Smart Overlap info\n
        إنشاء كائن DocumentChunk مع بيانات وصفية محسنة تتضمن معلومات التداخل الذكي
        """
        # Detect languages in chunk | كشف اللغات في القطعة
        detected_languages = []
        for lang, pattern in self.LANGUAGE_PATTERNS.items():
            if pattern.search(text):
                detected_languages.append(lang)
        
        if not detected_languages:
            detected_languages.append('english')
        
        actual_length = len(text)
        
        # Calculate additional statistics | حساب إحصائيات إضافية
        metadata = {
            'index': index,
            'length': actual_length,
            'languages': detected_languages,
            'word_count': len(text.split()),
            'sentence_count': len(re.split(self.SENTENCE_DELIMITERS, text)),
            'model_used': self.model_name,
            'size_compliance': {
                'within_base_limit': actual_length <= self.chunk_size,
                'within_max_limit': actual_length <= self.effective_max_size,
                'size_ratio': actual_length / self.chunk_size,
                'excess_chars': max(0, actual_length - self.chunk_size)
            }
        }
        
        # Add smart overlap info
        if previous_chunk_sentences and self.use_smart_overlap:
            current_sentences = [s for s in re.split(self.SENTENCE_DELIMITERS, text) if s.strip()]
            overlap_sentences = []
            
            # Find which sentences are overlapping
            for sent in current_sentences:
                if sent in previous_chunk_sentences:
                    overlap_sentences.append(sent)
            
            metadata['smart_overlap'] = {
                'enabled': self.use_smart_overlap,
                'overlap_sentence_count': len(overlap_sentences),
                'overlap_ratio': len(overlap_sentences) / len(current_sentences) if current_sentences else 0,
                'has_overlap': len(overlap_sentences) > 0
            }
        
        # Add embedding if model is available | إضافة التضمين إذا كان النموذج متاحاً
        if self.tokenizer and self.use_semantic_chunking:
            try:
                inputs = self.tokenizer(
                    text,
                    return_tensors=config.return_tensor,
                    truncation=config.truncation,
                    max_length=config.max_len
                ).to(self.device)
                
                with self._torch.no_grad():
                    if self.model:
                        outputs = self.model(**inputs)
                        if hasattr(outputs, 'last_hidden_state'):
                            embedding = outputs.last_hidden_state.mean(dim=1).cpu().numpy()
                        else:
                            embedding = outputs.logits.mean(dim=1).cpu().numpy()
                        metadata['embedding_shape'] = embedding.shape
                        metadata['has_embedding'] = True
            except Exception:
                metadata['has_embedding'] = False
        
        return DocumentChunk(
            chunk_id=f"{doc_id}_chunk_{index}",
            doc_id=doc_id,
            text=text,
            metadata=metadata
        )

    def chunk_text(self, text: str, doc_id: str) -> List[DocumentChunk]:
        """
        Compatibility method for legacy code\n
        طريقة التوافق للكود القديم
        """
        return self.chunk(text, doc_id)

    def get_embeddings_batch(self, texts: List[str]) -> Any:
        """
        Get embeddings for batch of texts\n
        الحصول على تضمينات لمجموعة من النصوص
        """
        if not self.tokenizer or not self.model:
            raise ValueError("Model not available ")
        
        embeddings = []
        
        for text in texts:
            inputs = self.tokenizer(
                text,
                return_tensors=config.return_tensor,
                truncation=config.truncation,
                max_length=config.max_len,
                padding=config.padding
            ).to(self.device)
            
            with self._torch.no_grad():
                outputs = self.model(**inputs)
                if hasattr(outputs, 'last_hidden_state'):
                    emb = outputs.last_hidden_state.mean(dim=1)
                else:
                    emb = outputs.logits.mean(dim=1)
                embeddings.append(emb)
        
        return self._torch.cat(embeddings, dim=0)

    def get_chunking_stats(self, chunks: List[DocumentChunk]) -> dict:
        """
        Get comprehensive statistics about the chunks including smart overlap metrics\n
        الحصول على إحصائيات شاملة عن القطع مع مقاييس التداخل الذكي
        """
        if not chunks:
            return {'total_chunks': 0}
        
        sizes = [len(c.text) for c in chunks]
        oversized = [s for s in sizes if s > self.chunk_size]
        critically_oversized = [s for s in sizes if s > self.effective_max_size]
        
        # Calculate smart overlap metrics
        smart_overlap_stats = {
            'chunks_with_overlap': 0,
            'avg_overlap_ratio': 0.0,
            'total_overlap_sentences': 0
        }
        
        if self.use_smart_overlap:
            overlap_ratios = []
            for chunk in chunks:
                if 'smart_overlap' in chunk.metadata and chunk.metadata['smart_overlap']['has_overlap']:
                    smart_overlap_stats['chunks_with_overlap'] += 1
                    overlap_ratios.append(chunk.metadata['smart_overlap']['overlap_ratio'])
                    smart_overlap_stats['total_overlap_sentences'] += chunk.metadata['smart_overlap']['overlap_sentence_count']
            
            if overlap_ratios:
                smart_overlap_stats['avg_overlap_ratio'] = sum(overlap_ratios) / len(overlap_ratios)
        
        # Detect languages in all chunks
        all_languages = set()
        for chunk in chunks:
            if 'languages' in chunk.metadata:
                all_languages.update(chunk.metadata['languages'])
        
        return {
            'total_chunks': len(chunks),
            'detected_languages': list(all_languages),
            'size_stats': {
                'min': min(sizes),
                'max': max(sizes),
                'avg': sum(sizes) / len(sizes),
                'median': sorted(sizes)[len(sizes) // 2]
            },
            'compliance': {
                'within_base_limit': len(chunks) - len(oversized),
                'exceeds_base_limit': len(oversized),
                'exceeds_max_limit': len(critically_oversized),
                'compliance_rate': ((len(chunks) - len(oversized)) / len(chunks)) * 100
            },
            'limits': {
                'base_limit': self.chunk_size,
                'max_limit': self.effective_max_size,
                'tolerance': f"{self.size_tolerance * 100}%"
            },
            'smart_overlap': smart_overlap_stats,
            'oversized_chunks': [
                {
                    'index': i,
                    'size': len(c.text),
                    'excess': len(c.text) - self.chunk_size,
                    'excess_percent': ((len(c.text) - self.chunk_size) / self.chunk_size) * 100
                }
                for i, c in enumerate(chunks) if len(c.text) > self.chunk_size
            ]
        }

    @classmethod
    def get_supported_languages(cls) -> List[str]:
        """
        Get list of explicitly supported languages\n
        الحصول على قائمة اللغات المدعومة صراحةً
        """
        return list(cls.LANGUAGE_MODELS.keys())

    @classmethod
    def get_recommended_model(cls, language: str) -> str:
        """
        Get recommended model for a specific language\n
        الحصول على النموذج الموصى به للغة معينة
        """
        return cls.LANGUAGE_MODELS.get(
            language.lower(), 
            cls.LANGUAGE_MODELS['multilingual']
        )