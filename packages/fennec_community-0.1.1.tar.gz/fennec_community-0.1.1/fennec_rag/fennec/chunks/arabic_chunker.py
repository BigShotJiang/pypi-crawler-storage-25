import re
import inspect
import warnings
from typing import List, Optional, Tuple, Any
import logging
from .base import ChunkingStrategy
from .doc_model import DocumentChunk
from .chunk_config import ChunkConfig

warnings.filterwarnings('ignore')

config = ChunkConfig()

# Lazy imports – loaded only when the class is actually instantiated
# استيراد كسول – يُحمَّل فقط عند إنشاء الكائن فعلياً
def _load_torch_and_transformers():
    try:
        import torch
        from transformers import AutoTokenizer, AutoModel
        return torch, AutoTokenizer, AutoModel
    except ImportError as e:
        raise ImportError(
            "⚠ Required libraries not found: torch and transformers. Please install them to use ArabicTextChunker.\n"
            "pip install torch transformers\n"
            f"   Original error: {e}"
        ) from e


class ArabicTextChunker(ChunkingStrategy):
    """
    Smart Arabic text chunker with semantic chunking support, STRICT size limits, and Smart Overlap\n
    محلل نصوص عربية ذكي مع دعم التقسيم الدلالي وحدود صارمة للحجم وتداخل ذكي
    """

    # Class constants | ثوابت الكلاس
    SENTENCE_DELIMITERS = r'[.!?؟\n]'
    ARABIC_PATTERN = re.compile(r'[\u0600-\u06FF]+')
    
    # Spacing fix patterns | أنماط إصلاح المسافات
    SPACE_PATTERNS = {
        'after_punct': (r'([.!?؟،,;:])([^\s])', r'\1 \2'),
        'before_paren': (r'([^\s])(\()', r'\1 \2'),
        'after_paren': (r'(\))([^\s.,!?؟])', r'\1 \2'),
        'word_boundary': (r'([\u0600-\u06FF]+)([A-Za-z]+)', r'\1 \2'),
        'reverse_boundary': (r'([A-Za-z]+)([\u0600-\u06FF]+)', r'\1 \2'),
    }

    def __init__(
        self,
        chunk_size: int = config.chunk_size,
        overlap: int = config.overlap,
        min_chunk_size: int = config.min_chunk_size,
        model_name: str = config.model_name,
        use_semantic_chunking: bool = config.use_semantic_chunking,
        device: Optional[str] = None,
        preserve_formatting: bool = config.preserve_formatting,
        fix_spacing: bool = config.fix_spacing,
        strict_size_limit: bool = config.strict_size_limit,
        size_tolerance: float = config.size_tolerance,
        use_smart_overlap: bool = config.use_smart_overlap,
        smart_overlap_threshold: float = config.smart_overlap_threshold,
    ):
        """
        Initialize Arabic text chunker | تهيئة محلل النصوص العربية
        
        Args:
            chunk_size: Maximum chunk size | الحد الأقصى لحجم القطعة
            overlap: Overlap between chunks | التداخل بين القطع
            min_chunk_size: Minimum chunk size | الحد الأدنى لحجم القطعة
            model_name: Hugging Face model name | اسم النموذج من Hugging Face
            use_semantic_chunking: Use semantic chunking | استخدام التقسيم الدلالي
            device: Device to use (cuda/cpu) | الجهاز المستخدم (cuda/cpu)
            preserve_formatting: Preserve original formatting | الحفاظ على التنسيق الأصلي
            fix_spacing: Automatically fix missing spaces | إصلاح المسافات المفقودة تلقائياً
            strict_size_limit: Enforce strict chunk size limits | فرض حدود صارمة لحجم القطعة
            size_tolerance: Tolerance factor for size limits (0.05 = 5%) | معامل التسامح لحدود الحجم
            use_smart_overlap: Enable smart semantic overlap | تفعيل التداخل الذكي الدلالي
            smart_overlap_threshold: Similarity threshold for overlap selection | عتبة التشابه لاختيار التداخل
        """
        self._validate_parameters(chunk_size, overlap, min_chunk_size)
        
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.min_chunk_size = min_chunk_size
        self.use_semantic_chunking = use_semantic_chunking
        self.preserve_formatting = preserve_formatting
        self.fix_spacing = fix_spacing
        self.strict_size_limit = strict_size_limit
        self.size_tolerance = size_tolerance
        self.use_smart_overlap = use_smart_overlap
        self.smart_overlap_threshold = smart_overlap_threshold
        torch, AutoTokenizer, AutoModel = _load_torch_and_transformers()
        self._torch = torch
        self._AutoTokenizer = AutoTokenizer
        self._AutoModel = AutoModel
        self.device = device or ("cuda" if self._torch.cuda.is_available() else "cpu")
        
        # Calculate effective max size | حساب الحد الأقصى الفعلي
        self.effective_max_size = int(self.chunk_size * (1 + self.size_tolerance))
        
        # Setup logger | إعداد المسجل
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        self._initialize_model(model_name)

    @staticmethod
    def _validate_parameters(chunk_size: int, overlap: int, min_chunk_size: int):
        """
        Validate initialization parameters \nالتحقق من صحة المعاملات
        """
        if chunk_size <= 0 or overlap < 0:
            raise ValueError("chunk_size must be positive and overlap non-negative ")
        if overlap >= chunk_size:
            raise ValueError("overlap must be less than chunk_size ")
        if min_chunk_size <= 0 or min_chunk_size > chunk_size:
            raise ValueError("min_chunk_size is invalid ")

    def _initialize_model(self, model_name: str):
        """
        Load model and tokenizer\ntokenizer تحميل النموذج والـ 
        """
        AutoTokenizer = self._AutoTokenizer
        AutoModel     = self._AutoModel
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            if self.use_semantic_chunking:
                self.model = AutoModel.from_pretrained(model_name)
                self.model.to(self.device)
                self.model.eval()
            else:
                self.model = None
            print(f"✓ Model loaded: {model_name} on {self.device} ")
        except Exception as e:
            print(f"⚠ Failed to load model: {e} ")
            print("Traditional chunking will be used ")
            self.tokenizer = None
            self.model = None
            self.use_semantic_chunking = False
            self.use_smart_overlap = False  # Disable smart overlap if model fails

    @classmethod
    def get_available_parameters(cls) -> List[str]:
        """
        Get list of available parameters in the class\n
        الحصول علي القيم المتاحه من البارامترز في الكلاس
        
        Returns:
            List of available parameters
        """
        sig = inspect.signature(cls.__init__)
        params = list(sig.parameters.keys())
        params.remove('self')
        return params

    @classmethod
    def create_safely(cls, **kwargs):
        """
        Create instance safely with filtering unsupported parameters\n
        بشكل امن مع فلتره البارامترز غير مدعومه instance إنشاء 
        """
        available_params = cls.get_available_parameters()
        filtered_kwargs = {k: v for k, v in kwargs.items() if k in available_params}
        
        rejected_params = set(kwargs.keys()) - set(filtered_kwargs.keys())
        if rejected_params:
            print(f"⚠ Unsupported parameters ignored: {rejected_params}")
        
        return cls(**filtered_kwargs)

    # ==================== Text Processing | معالجة النصوص ====================
    
    def _fix_text_spacing(self, text: str) -> str:
        """
        Fix missing spaces in text\n
        إصلاح المسافات المفقودة في النص
        """
        if not self.fix_spacing:
            return text
        
        original_text = text
        
        for pattern_name, (pattern, replacement) in self.SPACE_PATTERNS.items():
            text = re.sub(pattern, replacement, text)
        
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'\s+([.,!?؟،;:])', r'\1', text)
        
        if len(original_text) != len(text):
            diff = abs(len(text) - len(original_text))
            self.logger.debug(f"ℹ Spacing fixed: {diff} characters modified ")
        
        return text.strip()

    def _normalize_text(self, text: str) -> str:
        """
        Normalize Arabic text (unify similar characters)\n
        تطبيع النص العربي (توحيد الأحرف المتشابهة)
        """
        text = re.sub(r'[إأآا]', 'ا', text)
        text = re.sub(r'ة', 'ه', text)
        text = re.sub(r'[\u064B-\u0652]', '', text)
        text = re.sub(r'(.)\1+', r'\1\1', text)
        return text

    # ==================== Sentence Splitting | تقسيم الجمل ====================
    
    def _split_into_sentences_advanced(self, text: str) -> List[Tuple[str, int]]:
        """
        Split text into sentences while preserving original positions
        تقسيم النص إلى جمل مع الحفاظ على المواقع الأصلية
        """
        if self.fix_spacing:
            text = self._fix_text_spacing(text)
        
        sentences = []
        current_pos = 0
        
        for match in re.finditer(self.SENTENCE_DELIMITERS, text):
            end_pos = match.end()
            sentence = text[current_pos:end_pos].strip()
            
            if sentence:
                sentences.append((sentence, current_pos))
            
            current_pos = end_pos
        
        if current_pos < len(text):
            last_sentence = text[current_pos:].strip()
            if last_sentence:
                sentences.append((last_sentence, current_pos))
        
        return sentences

    def _split_into_sentences_traditional(self, text: str) -> List[str]:
        """
        Traditional sentence splitting with spacing fix
        تقسيم تقليدي للجمل مع إصلاح المسافات
        """
        if self.fix_spacing:
            text = self._fix_text_spacing(text)
        
        sentences = re.split(self.SENTENCE_DELIMITERS, text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return self._merge_short_sentences(sentences)

    def _merge_short_sentences(self, sentences: List[str]) -> List[str]:
        """
        Merge very short sentences
        دمج الجمل القصيرة جداً
        """
        if not sentences:
            return []
        
        merged = []
        buffer = ""
        min_sentence_length = config.min_sentences
        
        for sent in sentences:
            if buffer and not buffer.endswith(' '):
                buffer += ' '
            
            if len(buffer) < min_sentence_length and buffer:
                buffer += sent
            else:
                if buffer:
                    merged.append(buffer.strip())
                buffer = sent
        
        if buffer:
            merged.append(buffer.strip())
        
        return merged

    def _split_long_sentence(self, sentence: str) -> List[str]:
        """
        Split a very long sentence into smaller parts
        تقسيم جملة طويلة جداً إلى أجزاء أصغر
        
        Args:
            sentence: Long sentence to split
            
        Returns:
            List of smaller text parts
        """
        words = sentence.split()
        chunks = []
        current_chunk = []
        current_length = 0
        
        for word in words:
            word_len = len(word) + 1
            
            if current_length + word_len > self.chunk_size and current_chunk:
                chunk_text = " ".join(current_chunk)
                chunks.append(chunk_text)
                self.logger.debug(f"  📏 Split long sentence: {len(chunk_text)} chars")
                current_chunk = []
                current_length = 0
            
            current_chunk.append(word)
            current_length += word_len
        
        if current_chunk:
            chunks.append(" ".join(current_chunk))
        
        return chunks

    # ==================== Semantic Similarity | التشابه الدلالي ====================
    
    def _calculate_semantic_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate semantic similarity between two texts
        حساب التشابه الدلالي بين نصين
        """
        if not self.tokenizer or not self.model:
            return 0.0
        
        try:
            if self.fix_spacing:
                text1 = self._fix_text_spacing(text1)
                text2 = self._fix_text_spacing(text2)
            
            inputs1 = self.tokenizer(
                text1, return_tensors="pt", truncation=True, 
                max_length=128, padding=True
            ).to(self.device)
            
            inputs2 = self.tokenizer(
                text2, return_tensors="pt", truncation=True, 
                max_length=128, padding=True
            ).to(self.device)
            
            with self._torch.no_grad():
                emb1 = self.model(**inputs1, output_hidden_states=True).last_hidden_state.mean(dim=1)
                emb2 = self.model(**inputs2, output_hidden_states=True).last_hidden_state.mean(dim=1)
            
            similarity = self._torch.nn.functional.cosine_similarity(emb1, emb2)
            return similarity.item()
            
        except Exception as e:
            self.logger.warning(f"⚠ Error calculating similarity: {e} : {e}")
            return 0.0

    # ==================== Smart Overlap | التداخل الذكي ====================
    
    def _calculate_overlap_sentences(self, sentences: List[str]) -> int:
        """
        Calculate number of sentences for overlap
        حساب عدد الجمل للتداخل
        """
        if not sentences:
            return 0
        
        total_chars = sum(len(s) for s in sentences)
        avg_sentence_length = total_chars / len(sentences)
        
        if avg_sentence_length == 0:
            return 1
        
        overlap_sentences = max(1, int(self.overlap / avg_sentence_length))
        return min(overlap_sentences, len(sentences))

    def _apply_smart_overlap(
        self,
        previous_chunk: List[str],
        current_buffer: List[str]
    ) -> List[str]:
        """
        🧠 SMART OVERLAP: Select overlap sentences based on semantic similarity
        تداخل ذكي: اختيار جمل التداخل بناءً على التشابه الدلالي
        
        Args:
            previous_chunk: Sentences from previous chunk
            current_buffer: Sentences in current buffer (first sentence used for comparison)
            
        Returns:
            List of sentences to use as overlap
        """
        # حالة خاصة: لا يوجد تداخل
        if not previous_chunk or self.overlap == 0:
            return []
        
        # حساب عدد جمل التداخل المطلوبة
        overlap_count = self._calculate_overlap_sentences(previous_chunk)
        
        # الحصول على المرشحين من نهاية القطعة السابقة
        # نأخذ ضعف العدد المطلوب لنختار الأفضل منهم
        candidate_count = min(overlap_count * 2, len(previous_chunk))
        candidates = previous_chunk[-candidate_count:]
        
        # إذا كان التداخل الذكي مُفعّل وهناك محتوى جديد
        if self.use_smart_overlap and self.use_semantic_chunking and current_buffer:
            # الجملة الأولى من القطعة الجديدة للمقارنة
            first_new_sentence = current_buffer[0]
            
            # حساب درجة التشابه لكل جملة مرشحة
            similarities = []
            for candidate in candidates:
                sim = self._calculate_semantic_similarity(candidate, first_new_sentence)
                similarities.append((candidate, sim))
            
            # ترتيب حسب التشابه (الأعلى أولاً)
            similarities.sort(key=lambda x: x[1], reverse=True)
            
            # أخذ الجمل الأكثر ارتباطاً
            overlap_sentences = [s[0] for s in similarities[:overlap_count]]
            
            # معلومات للـ debugging
            if similarities:
                avg_similarity = sum(s[1] for s in similarities[:overlap_count]) / len(similarities[:overlap_count])
                self.logger.debug(f"🔗 Smart Overlap: {len(overlap_sentences)} sentences, avg similarity: {avg_similarity:.2f}")
                
                for sent, sim in similarities[:overlap_count]:
                    preview = sent[:50] + "..." if len(sent) > 50 else sent
                    self.logger.debug(f"  ✓ Similarity: {sim:.2f} - {preview}")
            
            return overlap_sentences
        
        # Fallback: التداخل التقليدي (آخر N جملة)
        overlap_sentences = previous_chunk[-overlap_count:] if overlap_count > 0 else []
        
        if overlap_sentences:
            self.logger.debug(f"📋 Traditional Overlap: {len(overlap_sentences)} sentences (last {overlap_count})")
        
        return overlap_sentences

    # ==================== Quality Validation | التحقق من الجودة ====================
    
    def _validate_chunk_quality(self, chunk_text: str) -> bool:
        """
        Validate chunk quality
        التحقق من جودة القطعة
        """
        if len(chunk_text.strip()) < self.min_chunk_size:
            return False
        
        words = chunk_text.split()
        if len(words) < 3:
            return False
        
        has_content = bool(
            self.ARABIC_PATTERN.search(chunk_text) or 
            re.search(r'[A-Za-z]+', chunk_text)
        )
        
        return has_content

    def _calculate_quality_score(self, text: str) -> float:
        """
        Calculate chunk quality score (0-1)
        حساب درجة جودة القطعة (0-1)
        """
        score = 0.0
        
        if ' ' in text:
            score += 0.25
        
        if self.min_chunk_size <= len(text) <= self.chunk_size:
            score += 0.25
        
        word_count = len(text.split())
        if 10 <= word_count <= 200:
            score += 0.25
        
        if text:
            space_ratio = text.count(' ') / len(text)
            if 0.1 <= space_ratio <= 0.25:
                score += 0.25
        
        return round(score, 2)

    def _validate_chunk_size(self, chunk_text: str, chunk_index: int) -> bool:
        """
        Validate that chunk size is within acceptable limits
        التحقق من أن حجم القطعة ضمن الحدود المقبولة
        
        Args:
            chunk_text: Chunk text to validate
            chunk_index: Index of the chunk
            
        Returns:
            True if within limits, False otherwise
        """
        actual_length = len(chunk_text)
        
        # Check if exceeds strict limit
        if self.strict_size_limit and actual_length > self.effective_max_size:
            self.logger.error(f"❌ ERROR: Chunk {chunk_index} exceeds limit: {actual_length} > {self.effective_max_size} ")
            return False
        
        # Warning for exceeding base size but within tolerance
        if actual_length > self.chunk_size:
            excess_percent = ((actual_length - self.chunk_size) / self.chunk_size) * 100
            self.logger.warning(f"⚠️ Warning: Chunk {chunk_index} exceeds base size by {excess_percent:.1f}%: {actual_length} vs {self.chunk_size}")
        
        return True

    # ==================== Main Chunking | التقسيم الرئيسي ====================
    
    def chunk(self, text: str, doc_id: str) -> List[DocumentChunk]:
        """
        Intelligent text chunking with STRICT size enforcement and SMART OVERLAP\n
        تقسيم النص إلى قطع ذكية مع فرض صارم للحجم وتداخل ذكي
        
        Args:
            text: Text to chunk | النص للتقسيم
            doc_id: Document ID | معرف المستند
            
        Returns:
            List of document chunks | قائمة قطع المستند
        """
        if not text or not text.strip():
            return []
        
        # Fix spacing
        if self.fix_spacing:
            original_length = len(text)
            text = self._fix_text_spacing(text)
            self.logger.info(f"📝 Original text: {original_length} chars → After fix: {len(text)} chars ")
        
        # Split into sentences
        sentences = self._split_into_sentences_traditional(text)
        if not sentences:
            return []
        
        self.logger.info(f"📊 Text split into {len(sentences)} sentences ")
        self.logger.info(f"📏 Size limits: base={self.chunk_size}, max={self.effective_max_size} ")
        
        if self.use_smart_overlap and self.use_semantic_chunking:
            self.logger.info(f"🧠 Smart Overlap: ENABLED (threshold={self.smart_overlap_threshold}) ")
        else:
            self.logger.info(f"📋 Smart Overlap: DISABLED (using traditional overlap) ")
        
        chunks = []
        current_buffer = []
        current_length = 0
        previous_chunk_sentences = []  # NEW: Track previous chunk sentences for smart overlap

        for i, sentence in enumerate(sentences):
            sentence_length = len(sentence)
            
            # Handle sentences longer than chunk_size
            if sentence_length > self.chunk_size:
                self.logger.warning(f"⚠️ Long sentence detected: {sentence_length} chars (limit: {self.chunk_size}) ")
                
                # Save current buffer first
                if current_buffer:
                    chunk_text = " ".join(current_buffer)
                    if self._validate_chunk_quality(chunk_text) and self._validate_chunk_size(chunk_text, len(chunks)):
                        chunks.append(self._create_chunk(doc_id, len(chunks), chunk_text, previous_chunk_sentences))
                        previous_chunk_sentences = current_buffer.copy()  # Update previous chunk
                    current_buffer = []
                    current_length = 0
                
                # Split long sentence
                sub_chunks = self._split_long_sentence(sentence)
                for sub_chunk in sub_chunks:
                    if self._validate_chunk_quality(sub_chunk) and self._validate_chunk_size(sub_chunk, len(chunks)):
                        chunks.append(self._create_chunk(doc_id, len(chunks), sub_chunk, previous_chunk_sentences))
                        previous_chunk_sentences = [sub_chunk]  # Update previous chunk
                continue
            
            # Check if adding this sentence will exceed limit
            will_exceed_base = current_length + sentence_length + 1 > self.chunk_size
            will_exceed_max = current_length + sentence_length + 1 > self.effective_max_size
            
            if will_exceed_base and current_buffer:
                # Check semantic similarity with STRICT size enforcement
                can_merge_semantically = False
                
                if self.use_semantic_chunking and i < len(sentences) - 1 and not will_exceed_max:
                    similarity = self._calculate_semantic_similarity(
                        current_buffer[-1], sentence
                    )
                    # Only merge if similarity is high AND within effective max size
                    if similarity > self.smart_overlap_threshold:
                        can_merge_semantically = True
                        self.logger.debug(f"  🔗 Semantic merge: similarity={similarity:.2f}, size will be {current_length + sentence_length + 1} ")
                
                if not can_merge_semantically:
                    # Create chunk
                    chunk_text = " ".join(current_buffer)
                    
                    # Validate actual length before creating chunk
                    actual_length = len(chunk_text)
                    
                    if self._validate_chunk_quality(chunk_text) and self._validate_chunk_size(chunk_text, len(chunks)):
                        chunks.append(self._create_chunk(doc_id, len(chunks), chunk_text, previous_chunk_sentences))
                        self.logger.info(f"  ✓ Chunk {len(chunks)}: {actual_length}/{self.chunk_size} chars, {len(current_buffer)} sentences ")

                    # 🧠 SMART OVERLAP: Apply intelligent overlap selection
                    previous_chunk_sentences = current_buffer.copy()  # Save before applying overlap
                    overlap_sentences = self._apply_smart_overlap(
                        previous_chunk=previous_chunk_sentences,
                        current_buffer=[sentence]  # Next sentence as context
                    )
                    
                    current_buffer = overlap_sentences
                    current_length = sum(len(s) + 1 for s in current_buffer)

            current_buffer.append(sentence)
            current_length += sentence_length + 1

        # Process remaining sentences
        if current_buffer:
            chunk_text = " ".join(current_buffer)
            if self._validate_chunk_quality(chunk_text) and self._validate_chunk_size(chunk_text, len(chunks)):
                chunks.append(self._create_chunk(doc_id, len(chunks), chunk_text, previous_chunk_sentences))
                self.logger.info(f"  ✓ Chunk {len(chunks)} (last): {len(chunk_text)}/{self.chunk_size} chars ")

        self.logger.info(f"✅ Total chunks: {len(chunks)} ")
        
        # Final validation summary
        oversized_chunks = sum(1 for c in chunks if len(c.text) > self.chunk_size)
        if oversized_chunks > 0:
            self.logger.warning(f"⚠️ {oversized_chunks} chunks exceed base size (within tolerance) ")
        
        return chunks

    def _create_chunk(
        self, 
        doc_id: str, 
        index: int, 
        text: str, 
        previous_chunk_sentences: List[str] = None
    ) -> DocumentChunk:
        """
        Create DocumentChunk object with enhanced metadata including overlap info\n
        يتضمن معلومات التداخل metadata مع DocumentChunk إنشاء كائن 
        
        Args:
            doc_id: Document ID
            index: Chunk index
            text: Chunk text
            previous_chunk_sentences: Sentences from previous chunk (for overlap tracking)
        """
        if self.fix_spacing:
            text = self._fix_text_spacing(text)
        
        is_arabic = bool(self.ARABIC_PATTERN.search(text))
        words = text.split()
        actual_length = len(text)
        
        # Build metadata
        metadata = {
            'index': index,
            'length': actual_length,
            'is_arabic': is_arabic,
            'word_count': len(words),
            'sentence_count': len([s for s in re.split(self.SENTENCE_DELIMITERS, text) if s.strip()]),
            'avg_word_length': sum(len(w) for w in words) / len(words) if words else 0,
            'has_proper_spacing': ' ' in text,
            'quality_score': self._calculate_quality_score(text),
            'size_compliance': {
                'within_base_limit': actual_length <= self.chunk_size,
                'within_max_limit': actual_length <= self.effective_max_size,
                'size_ratio': actual_length / self.chunk_size,
                'excess_chars': max(0, actual_length - self.chunk_size)
            }
        }
        
        # Add smart overlap info
        if previous_chunk_sentences and self.use_smart_overlap:
            current_sentences = [s for s in re.split(self.SENTENCE_DELIMITERS, text) if s.strip()]
            overlap_sentences = []
            
            # Find which sentences are overlapping
            for sent in current_sentences:
                if sent in previous_chunk_sentences:
                    overlap_sentences.append(sent)
            
            metadata['smart_overlap'] = {
                'enabled': self.use_smart_overlap,
                'overlap_sentence_count': len(overlap_sentences),
                'overlap_ratio': len(overlap_sentences) / len(current_sentences) if current_sentences else 0,
                'has_overlap': len(overlap_sentences) > 0
            }

        # Add embedding
        if self.tokenizer and self.use_semantic_chunking:
            try:
                inputs = self.tokenizer(
                    text, return_tensors="pt", truncation=True, 
                    max_length=512, padding=True
                ).to(self.device)
                
                with self._torch.no_grad():
                    outputs = self.model(**inputs, output_hidden_states=True)
                    embedding = outputs.last_hidden_state.mean(dim=1).cpu().numpy()
                    metadata['embedding_shape'] = embedding.shape
                    metadata['has_embedding'] = True
            except Exception as e:
                metadata['has_embedding'] = False
                self.logger.warning(f"⚠ Failed to create embedding: {e}")

        return DocumentChunk(
            chunk_id=f"{doc_id}_chunk_{index}",
            doc_id=doc_id,
            text=text,
            metadata=metadata
        )

    # ==================== Helper Methods | طرق مساعدة ====================
    
    def chunk_text(self, text: str, doc_id: str) -> List[DocumentChunk]:
        """
        Alternative method for compatibility\n
        طريقة بديلة للتوافق
        """
        return self.chunk(text, doc_id)

    def get_embeddings_batch(self, texts: List[str]) -> Any:
        """
        Get embeddings for a batch of texts\n
       لمجموعه من النصوص embeddings الحصول على 
        """
        if not self.tokenizer or not self.model:
            raise ValueError("Model not available ")

        if self.fix_spacing:
            texts = [self._fix_text_spacing(t) for t in texts]

        embeddings = []
        for text in texts:
            inputs = self.tokenizer(
                text, return_tensors="pt", truncation=True, 
                max_length=512, padding=True
            ).to(self.device)
            
            with self._torch.no_grad():
                outputs = self.model(**inputs, output_hidden_states=True)
                emb = outputs.last_hidden_state.mean(dim=1)
                embeddings.append(emb)
        
        return self._torch.cat(embeddings, dim=0)

    def analyze_text_quality(self, text: str) -> dict:
        """
        Analyze text quality and provide detailed report\n
        تحليل جودة النص وتقديم تقرير مفصل
        """
        original_text = text
        fixed_text = self._fix_text_spacing(text) if self.fix_spacing else text
        
        return {
            'original_length': len(original_text),
            'fixed_length': len(fixed_text),
            'spaces_added': fixed_text.count(' ') - original_text.count(' '),
            'has_spacing_issues': len(original_text) != len(fixed_text),
            'word_count_original': len(original_text.split()),
            'word_count_fixed': len(fixed_text.split()),
            'is_arabic': bool(self.ARABIC_PATTERN.search(text)),
            'sentence_count': len(re.split(self.SENTENCE_DELIMITERS, fixed_text)),
            'quality_score': self._calculate_quality_score(fixed_text),
            'preview_original': original_text if len(original_text) > 100 else original_text,
            'preview_fixed': fixed_text if len(fixed_text) > 100 else fixed_text
        }

    def get_chunking_stats(self, chunks: List[DocumentChunk]) -> dict:
        """
        Get comprehensive statistics about the chunks including smart overlap metrics\n
        الحصول على إحصائيات شاملة عن القطع مع مقاييس التداخل الذكي
        
        Args:
            chunks: List of document chunks
            
        Returns:
            Dictionary with statistics
        """
        if not chunks:
            return {'total_chunks': 0}
        
        sizes = [len(c.text) for c in chunks]
        oversized = [s for s in sizes if s > self.chunk_size]
        critically_oversized = [s for s in sizes if s > self.effective_max_size]
        
        # Calculate smart overlap metrics
        smart_overlap_stats = {
            'chunks_with_overlap': 0,
            'avg_overlap_ratio': 0.0,
            'total_overlap_sentences': 0
        }
        
        if self.use_smart_overlap:
            overlap_ratios = []
            for chunk in chunks:
                if 'smart_overlap' in chunk.metadata and chunk.metadata['smart_overlap']['has_overlap']:
                    smart_overlap_stats['chunks_with_overlap'] += 1
                    overlap_ratios.append(chunk.metadata['smart_overlap']['overlap_ratio'])
                    smart_overlap_stats['total_overlap_sentences'] += chunk.metadata['smart_overlap']['overlap_sentence_count']
            
            if overlap_ratios:
                smart_overlap_stats['avg_overlap_ratio'] = sum(overlap_ratios) / len(overlap_ratios)
        
        return {
            'total_chunks': len(chunks),
            'size_stats': {
                'min': min(sizes),
                'max': max(sizes),
                'avg': sum(sizes) / len(sizes),
                'median': sorted(sizes)[len(sizes) // 2]
            },
            'compliance': {
                'within_base_limit': len(chunks) - len(oversized),
                'exceeds_base_limit': len(oversized),
                'exceeds_max_limit': len(critically_oversized),
                'compliance_rate': ((len(chunks) - len(oversized)) / len(chunks)) * 100
            },
            'limits': {
                'base_limit': self.chunk_size,
                'max_limit': self.effective_max_size,
                'tolerance': f"{self.size_tolerance * 100}%"
            },
            'smart_overlap': smart_overlap_stats,
            'oversized_chunks': [
                {
                    'index': i,
                    'size': len(c.text),
                    'excess': len(c.text) - self.chunk_size,
                    'excess_percent': ((len(c.text) - self.chunk_size) / self.chunk_size) * 100
                }
                for i, c in enumerate(chunks) if len(c.text) > self.chunk_size
            ]
        }