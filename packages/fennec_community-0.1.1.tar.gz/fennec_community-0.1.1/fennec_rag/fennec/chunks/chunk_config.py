from dataclasses import dataclass

@dataclass
class ChunkConfig:
    model_name : str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    chunk_size : int = 512
    overlap : int = 128
    min_chunk_size : int = 50
    use_semantic_chunking : bool = False
    preserve_formatting : bool = True
    fix_spacing : bool = True
    strict_size_limit : bool = True
    size_tolerance : float = 0.05
    use_smart_overlap : bool = True
    smart_overlap_threshold : float = 0.7
    


    # models
    arabic : str = "CAMeL-Lab/bert-base-arabic-camelbert-mix"
    multilingual: str = 'xlm-roberta-base' 
    english : str= 'bert-base-uncased'
    arabic : str = 'CAMeL-Lab/bert-base-arabic-camelbert-mix'
    chinese : str = 'bert-base-chinese'
    french : str = 'camembert-base'
    german : str ='bert-base-german-cased'
    spanish : str = 'dccuchile/bert-base-spanish-wwm-uncased'
    russian : str = 'DeepPavlov/rubert-base-cased'
    japanese : str ='cl-tohoku/bert-base-japanese'
    korean : str ='klue/bert-base'
    portuguese : str ='neuralmind/bert-base-portuguese-cased'
    italian : str = 'dbmdz/bert-base-italian-cased'
    dutch : str ='GroNLP/bert-base-dutch-cased'
    polish : str ='dkleczek/bert-base-polish-cased'
    turkish : str ='dbmdz/bert-base-turkish-cased'
    vietnamese : str = 'vinai/phobert-base'
    hindi : str = 'ai4bharat/indic-bert'


    # for semantic 
    max_len : int = 512
    padding : bool = True
    truncation : bool = True
    return_tensor : str ='pt'

    # for merge
    min_sentences : int = 30

    # for tiktoken
    model_token="cl100k_base"




