from .base_llm_interface import BaseLLMInterface
from .openai_interface import OpenAIInterface
from .anthropic_interface import AnthropicInterface
from .ollama_interface import OllamaInterface
from .hugginface_interface import HuggingFaceInterface
from .gemini_interface import GeminiInterface
from .mistral_interface import MistralInterface
from .config_llm import llm_config


# Hallucination Guard Integration
from .hallucination import (
    HallucinationGuard,
    HallucinationCheck,
    HallucinationType,
    ConfidenceLevel,
    GroundingContext,
    ProtectedLLMInterface,
    GuardConfig,
    ProtectedLLMConfig,
    GuardPresets,
    ProtectedLLMPresets,
    DomainConfigs,
    create_protected_llm_for_domain,
)


__hugginface_models__ = [
    'gpt', 'llama', 'mistral', 'falcon', 'bloom', 'opt', 'pythia',
    't5', 'bart', 'mbart', 'pegasus', 'flan', 'bert', 'roberta',
    'albert', 'electra', 'deberta', 'arabert'
]

__llm_providers__ = ["openai", "anthropic", "huggingface", "ollama", "gemini","mistral"]

__all__ = [
    # LLM Interfaces
    "BaseLLMInterface",
    "OpenAIInterface",
    "AnthropicInterface",
    "OllamaInterface",
    "HuggingFaceInterface",
    "GeminiInterface",
    "MistralInterface",
    # Hallucination Guard
    "HallucinationGuard",
    "HallucinationCheck",
    "HallucinationType",
    "ConfidenceLevel",
    "GroundingContext",
    "ProtectedLLMInterface",
    # Config & Presets
    "GuardConfig",
    "ProtectedLLMConfig",
    "GuardPresets",
    "ProtectedLLMPresets",
    "DomainConfigs",
    "create_protected_llm_for_domain",
    "llm_config"
]
