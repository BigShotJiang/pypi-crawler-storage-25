from typing import Optional, Any, AsyncIterator
import asyncio
from abc import ABC, abstractmethod
from .config_llm import llm_config

llm_config_ = llm_config()


class BaseLLMInterface(ABC):
    """Main Interface For All LLM Support\n"""

    def __init__(self, model_name: str, api_key: str, **kwargs):
        self.model_name = model_name
        self.api_key = api_key
        self.kwargs = kwargs

    @abstractmethod
    def generate(
        self,
        prompt: str,
        max_tokens: int = llm_config_.max_token,
        temperature: float = llm_config_.temperature,
        **kwargs,
    ) -> str:
        """generate text"""
        pass

    @abstractmethod
    async def generate_async(
        self,
        prompt: str,
        max_tokens: int = llm_config_.max_token,
        temperature: float = llm_config_.temperature,
        **kwargs,
    ) -> str:
        """generate text as async"""
        pass

    async def astream(
        self,
        prompt: str,
        max_tokens: int = llm_config_.max_token,
        temperature: float = llm_config_.temperature,
        **kwargs,
    ) -> AsyncIterator[str]:
        """
        Stream tokens one by one (async generator).
        Default: generates full response then yields word-by-word.
        Override in subclasses that support native streaming.

        Example:
            async for token in llm.astream("مرحباً"):
                print(token, end="", flush=True)
        """
        response = await self.generate_async(prompt, max_tokens, temperature, **kwargs)
        for word in response.split(" "):
            yield word + " "
            await asyncio.sleep(0)  # yield control to event loop

    # ── Async context manager ────────────────────────────────────────
    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.acleanup()
        return False

    async def acleanup(self):
        """Override in subclasses to release async resources (e.g., aiohttp sessions)"""
        pass

    def validate_connection(
        self,
        test_prompt: str = "test",
        max_tokens: int = 10,
        temperature: float = 0.7,
        async_mode: bool = False,
    ) -> dict:
        """
        Check LLM connection and response.

        Returns:
            dict: {
                "success": bool,
                "reason": str,
                "response": str (if success)
            }
        """
        try:
            if async_mode:
                import asyncio
                response = asyncio.run(
                    self.generate_async(test_prompt, max_tokens=max_tokens, temperature=temperature)
                )
            else:
                response = self.generate(test_prompt, max_tokens=max_tokens, temperature=temperature)

            if response:
                return {"success": True, "reason": "Connection successful", "response": response}
            else:
                return {"success": False, "reason": "Empty response", "response": None}

        except Exception as e:
            return {"success": False, "reason": str(e), "response": None}

    def with_hallucination_guard(
        self,
        auto_retry: bool = True,
        max_retries: int = 3,
        strict_mode: bool = False,
        verbose: bool = True,
        threshold: float = 0.7,
        require_sources: bool = True,
        domain: Optional[str] = None,
    ):
        """
        لف هذه الواجهة بطبقة الحماية من الهلوسة.

        Args:
            auto_retry: إعادة المحاولة تلقائياً عند اكتشاف هلوسة
            max_retries: أقصى عدد للمحاولات
            strict_mode: الوضع الصارم - رفض أي إجابة مشبوهة
            verbose: طباعة التفاصيل
            threshold: حد الثقة المطلوب (0-1)
            require_sources: اشتراط المصادر
            domain: مجال متخصص (medical, legal, financial, educational,
                    customer_service, creative_writing)

        Returns:
            ProtectedLLMInterface: واجهة LLM محمية

        Example:
            >>> llm = OpenAIInterface(model_name="gpt-4", api_key="...")
            >>> protected = llm.with_hallucination_guard(strict_mode=True)
            >>> result = protected.generate("سؤالك هنا")
            >>> print(result["response"])
        """
        from .hallucination import ProtectedLLMInterface, create_protected_llm_for_domain

        if domain:
            return create_protected_llm_for_domain(
                self,
                domain=domain,
            )

        from .hallucination import HallucinationGuard

        guard = HallucinationGuard(
            threshold=threshold,
            require_sources=require_sources,
            fact_check_enabled=True,
            confidence_check_enabled=True,
        )

        return ProtectedLLMInterface(
            llm_interface=self,
            hallucination_guard=guard,
            auto_retry=auto_retry,
            max_retries=max_retries,
            request_sources=require_sources,
            strict_mode=strict_mode,
            verbose=verbose,
        )
