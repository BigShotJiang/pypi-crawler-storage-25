uncertainty_patterns_=[
    r"(ربما|قد|من الممكن|يمكن أن|أعتقد|أظن|على ما أذكر)",
    r"(غالبًا|أغلب الظن|يبدو أن|يُحتمل أن|قد يكون|قد تكون)",
    r"(ليس مؤكداً|غير مؤكد|غير واضح|غير معروف)",
    r"(على حد علمي|فيما أعلم|فيما يبدو)",
    r"(على ما يبدو|على الأغلب|إلى حد ما)",
    r"(من الصعب الجزم|لا يمكن التأكد)",
    r"(ربما يكون السبب|قد يرجع ذلك إلى)",
    r"(لا أستطيع الجزم|لا أستطيع التأكيد)",
    r"(likely|most likely|apparently|seems that|it seems)",
    r"(it is possible that|it might be that)",
    r"(not confirmed|uncertain|unclear)",
    r"(to my knowledge|as far as I know)",
    r"(it appears that|it could be that)",
    r"(hard to say|difficult to determine)",
    r"(I cannot confirm|I cannot be sure)",
    r"(I think|maybe|perhaps|possibly|might|could be|not sure)",
]




overconfidence_patterns_=[
    r"(بالتأكيد|مئة بالمئة|100%|بدون شك|يقيناً|حتماً)",
    r"(قطعًا|لا جدال في ذلك|لا خلاف عليه)",
    r"(لا يوجد أي شك|من المؤكد تمامًا)",
    r"(حقيقة مؤكدة|ثابت علميًا بشكل قاطع)",
    r"(من المستحيل أن يكون غير ذلك)",
    r"(مضمون تمامًا|لا يحتمل الخطأ)",
    r"(حقيقة لا تقبل النقاش)",
    r"(بدون أدنى شك)",
    r"(undoubtedly|without any doubt|beyond doubt)",
    r"(there is no question that)",
    r"(it is a proven fact)",
    r"(absolutely certain|completely certain)",
    r"(guaranteed|100 percent sure)",
    r"(cannot possibly be otherwise)",
    r"(without a shadow of a doubt)",
    r"(definitely|absolutely|certainly|100%|without doubt|guaranteed)",
]

made_up_indicators_=[
    r"(حسب خبرتي الشخصية|من تجربتي)",
    r"(من خلال خبرتي|حسب معرفتي الشخصية)",
    r"(عملت على هذا الموضوع سابقًا)",
    r"(تعاملت مع حالات مشابهة)",
    r"(قمت بدراسة هذا الأمر بنفسي)",
    r"(لاحظت بنفسي أن)",
    r"(شاركت في مشروع يتعلق بـ)",
    r"(based on my experience)",
    r"(I have worked on similar cases)",
    r"(I personally studied this)",
    r"(I have seen many examples)",
    r"(I was involved in)",
    r"(in my professional opinion)",
    r"(in my experience|from what I've seen)",
]