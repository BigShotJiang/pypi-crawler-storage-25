from typing import Optional, Dict, Any
from .hallucination_guard import (
    HallucinationGuard,
    GroundingContext,
    HallucinationCheck
    
)


class ProtectedLLMInterface:
    """
    واجهة محمية للـ LLM
    
    تلتف حول أي LLM interface وتضيف:
    - فحص تلقائي للهلوسة
    - طلب مصادر تلقائي
    - إعادة محاولة تلقائية عند اكتشاف هلوسة
    - تسجيل وتتبع\n
    protected llm interface
    features:
    -hallucination guard
    -request grounding sources
    -auto retry on hallucination
    -logging and tracking
    """
    
    def __init__(
        self,
        llm_interface,
        hallucination_guard: Optional[HallucinationGuard] = None,
        auto_retry: bool = True,
        max_retries: int = 3,
        request_sources: bool = False,  # set True only when grounding_context will be supplied
        strict_mode: bool = False,
        verbose: bool = True,
        temperature_decay: float = 0.1,   # ضيف ده
        min_temperature: float = 0.3,
    ):
        """
        Args:
            llm_interface: واجهة الـ LLM الأساسية
            hallucination_guard: طبقة الحماية (يتم إنشاؤها تلقائياً إذا لم تُحدد)
            auto_retry: إعادة المحاولة تلقائياً عند اكتشاف هلوسة
            max_retries: أقصى عدد لإعادة المحاولة
            request_sources: طلب مصادر في البرومبت
            strict_mode: الوضع الصارم (رفض أي هلوسة)
            verbose: طباعة التفاصيل
        """
        self.llm = llm_interface
        self.guard = hallucination_guard or HallucinationGuard(
            threshold=0.7,
            require_sources=request_sources,
            fact_check_enabled=True,
            confidence_check_enabled=True
        )
        self.auto_retry = auto_retry
        self.max_retries = max_retries
        self.request_sources = request_sources
        self.strict_mode = strict_mode
        self.verbose = verbose
        self.temperature_decay = temperature_decay
        self.min_temperature = min_temperature






        
        # إحصائيات
        self.stats = {
            "total_requests": 0,
            "hallucinations_detected": 0,
            "retries_performed": 0,
            "successful_responses": 0,
            "failed_responses": 0
        }
    
    def generate(
        self,
        prompt: str,
        grounding_context: Optional[GroundingContext] = None,
        max_tokens: int = 500,
        temperature: float = 0.7,
        bypass_guard: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        توليد نص محمي من الهلوسة\n
        generate text free of hallucination
        
        Args:
            prompt: البرومبت الأصلي
            grounding_context: السياق والمصادر
            max_tokens: أقصى عدد tokens
            temperature: درجة الحرارة
            bypass_guard: تجاوز الحماية (للطوارئ فقط)
            **kwargs: معاملات إضافية للـ LLM
            
        Returns:
            Dict يحتوي على:
            - response: الإجابة النهائية
            - check_result: نتيجة فحص الهلوسة
            - retries: عدد المحاولات
            - confidence_level: مستوى الثقة
            - sources_used: المصادر المستخدمة
        """
        self.stats["total_requests"] += 1
        
        # تعديل البرومبت لطلب المصادر
        # Only enhance when a real grounding_context is provided —
        # asking for citations without any sources causes the guard
        # to always score the response as low-confidence.
        enhanced_prompt = (
            self._enhance_prompt(prompt)
            if (self.request_sources and grounding_context is not None)
            else prompt
        )
        
        # المحاولة الأولى
        response = self.llm.generate(
            enhanced_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs
        )
        
        # تجاوز الحماية إذا طُلب ذلك
        if bypass_guard:
            return {
                "response": response,
                "bypassed": True,
                "warning": "Hallucination guard was bypassed"
            }
        
        # فحص الهلوسة
        check_result = self.guard.check_response(
            response=response,
            grounding_context=grounding_context,
            original_query=prompt
        )
        
        retries = 0
        
        # إعادة المحاولة إذا اكتُشفت هلوسة
        while (
            check_result.is_hallucination and
            self.auto_retry and
            retries < self.max_retries
        ):
            retries += 1
            self.stats["retries_performed"] += 1
            
            if self.verbose:
                print(f"⚠️  Hallucination detected (attempt {retries}/{self.max_retries})")
                print(f"   Type: {check_result.hallucination_type.value if check_result.hallucination_type else 'Unknown'}")
                print(f"   Confidence: {check_result.confidence_score:.2%}")
                print(f"   Retrying with stricter constraints...")
            
            # تعديل البرومبت لمحاولة تحسين الإجابة
            retry_prompt = self._create_retry_prompt(
                original_prompt=enhanced_prompt,
                check_result=check_result,
                grounding_context=grounding_context
            )
            
            # تقليل temperature لتقليل الهلوسة
            retry_temp = max(0.3, temperature - (retries * 0.1))
            
            # إعادة المحاولة
            response = self.llm.generate(
                retry_prompt,
                max_tokens=max_tokens,
                temperature=retry_temp,
                **kwargs
            )
            
            # فحص الإجابة الجديدة
            check_result = self.guard.check_response(
                response=response,
                grounding_context=grounding_context,
                original_query=prompt
            )
        
        # تحديث الإحصائيات
        if check_result.is_hallucination:
            self.stats["hallucinations_detected"] += 1
            if self.strict_mode:
                self.stats["failed_responses"] += 1
            else:
                self.stats["successful_responses"] += 1
        else:
            self.stats["successful_responses"] += 1
        
        # في الوضع الصارم، رفض الإجابة إذا كانت هلوسة
        if self.strict_mode and check_result.is_hallucination:
            response = self._generate_rejection_message(check_result)
        
        # طباعة التفاصيل
        if self.verbose:
            self._print_check_summary(check_result, retries)
        
        return {
            "response": response,
            "check_result": check_result,
            "retries": retries,
            "confidence_level": self.guard.get_confidence_level(check_result.confidence_score),
            "confidence_score": check_result.confidence_score,
            "is_hallucination": check_result.is_hallucination,
            "hallucination_type": check_result.hallucination_type.value if check_result.hallucination_type else None,
            "recommendation": check_result.recommendation,
            "sources_used": grounding_context.sources if grounding_context else []
        }
    
    async def generate_async(
        self,
        prompt: str,
        grounding_context: Optional[GroundingContext] = None,
        max_tokens: int = 500,
        temperature: float = 0.7,
        bypass_guard: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """نسخة async من generate"""
        self.stats["total_requests"] += 1
        
        enhanced_prompt = (
            self._enhance_prompt(prompt)
            if (self.request_sources and grounding_context is not None)
            else prompt
        )

        response = await self.llm.generate_async(
            enhanced_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs
        )
        
        if bypass_guard:
            return {
                "response": response,
                "bypassed": True,
                "warning": "Hallucination guard was bypassed"
            }
        
        check_result = self.guard.check_response(
            response=response,
            grounding_context=grounding_context,
            original_query=prompt
        )
        
        retries = 0
        
        while (
            check_result.is_hallucination and
            self.auto_retry and
            retries < self.max_retries
        ):
            retries += 1
            self.stats["retries_performed"] += 1
            
            if self.verbose:
                print(f"⚠️  Hallucination detected (attempt {retries}/{self.max_retries})")
            
            retry_prompt = self._create_retry_prompt(
                original_prompt=enhanced_prompt,
                check_result=check_result,
                grounding_context=grounding_context
            )
            
            retry_temp = max(0.3, temperature - (retries * 0.1))
            
            response = await self.llm.generate_async(
                retry_prompt,
                max_tokens=max_tokens,
                temperature=retry_temp,
                **kwargs
            )
            
            check_result = self.guard.check_response(
                response=response,
                grounding_context=grounding_context,
                original_query=prompt
            )
        
        if check_result.is_hallucination:
            self.stats["hallucinations_detected"] += 1
            if self.strict_mode:
                self.stats["failed_responses"] += 1
            else:
                self.stats["successful_responses"] += 1
        else:
            self.stats["successful_responses"] += 1
        
        if self.strict_mode and check_result.is_hallucination:
            response = self._generate_rejection_message(check_result)
        
        if self.verbose:
            self._print_check_summary(check_result, retries)
        
        return {
            "response": response,
            "check_result": check_result,
            "retries": retries,
            "confidence_level": self.guard.get_confidence_level(check_result.confidence_score),
            "confidence_score": check_result.confidence_score,
            "is_hallucination": check_result.is_hallucination,
            "hallucination_type": check_result.hallucination_type.value if check_result.hallucination_type else None,
            "recommendation": check_result.recommendation,
            "sources_used": grounding_context.sources if grounding_context else []
        }
    
    def _enhance_prompt(self, prompt: str) -> str:
        """تعزيز البرومبت بطلب المصادر
        
        ⚠️  Do NOT ask the LLM to "state uncertainty" here — the hallucination
        guard penalises uncertainty markers (I think / not sure / I cannot
        confirm), so asking the LLM to produce them creates a retry loop.
        """
        enhancement = """

                        INSTRUCTIONS:
                        - Answer based only on verified, factual information.
                        - Be concise and direct. State facts clearly.
                        - Do not invent or fabricate information.
                        - If the question is outside your knowledge, reply: "I don't have reliable information on this."
                        """
        return prompt + enhancement
    
    def _create_retry_prompt(
        self,
        original_prompt: str,
        check_result: HallucinationCheck,
        grounding_context: Optional[GroundingContext]
    ) -> str:
        """إنشاء برومبت معدل للمحاولة مرة أخرى
        
        ⚠️  Do NOT include uncertainty-language instructions — they trigger
        the same guard penalty (I think / not sure / I cannot confirm).
        Focus on asking for factual, direct answers only.
        """
        issue = (
            check_result.hallucination_type.value
            if check_result.hallucination_type else "quality issue"
        )
        problems = "\n".join(
            "- " + e for e in check_result.evidence[:3]
        ) or "- Response did not meet quality threshold"

        feedback = (
            f"The previous answer had a {issue}.\n"
            f"Issues:\n{problems}\n\n"
            f"Please provide a corrected, factual, and direct answer.\n"
            f"Rules:\n"
            f"- State facts clearly and concisely.\n"
            f"- Do not fabricate information.\n"
            f"- Do not add unnecessary qualifiers or disclaimers.\n"
        )

        if grounding_context and grounding_context.sources:
            sources_text = "\n".join(
                "- " + s[:100] for s in grounding_context.sources[:5]
            )
            feedback += f"\nAvailable sources:\n{sources_text}\n"

        return feedback + "\n" + original_prompt
    
    def _generate_rejection_message(self, check_result: HallucinationCheck) -> str:
        """توليد رسالة رفض في الوضع الصارم"""
        return f"""⚠️ Response Quality Check Failed

                        The generated response did not meet quality standards due to:
                        - Type: {check_result.hallucination_type.value if check_result.hallucination_type else 'Unknown'}
                        - Confidence Score: {check_result.confidence_score:.2%}

                        Issues detected:
                        {chr(10).join('• ' + e for e in check_result.evidence)}

                        Recommendation: {check_result.recommendation}

                        Please:
                        1. Provide more specific context
                        2. Include grounding sources
                        3. Rephrase your question for clarity
                        4.the answer must be same query language
                        """
    
    def _print_check_summary(self, check_result: HallucinationCheck, retries: int):
        """طباعة ملخص الفحص"""
        status = "✅ PASS" if not check_result.is_hallucination else "❌ FAIL"
        confidence = self.guard.get_confidence_level(check_result.confidence_score)
        
        print(f"\n{'='*60}")
        print(f"Hallucination Guard Check: {status}")
        print(f"{'='*60}")
        print(f"Confidence Score: {check_result.confidence_score:.2%}")
        print(f"Confidence Level: {confidence.value}")
        
        if check_result.hallucination_type:
            print(f"Issue Type: {check_result.hallucination_type.value}")
        
        if check_result.evidence:
            print(f"\nEvidence:")
            for i, evidence in enumerate(check_result.evidence[:5], 1):
                print(f"  {i}. {evidence}")
        
        if retries > 0:
            print(f"\nRetries: {retries}")
        
        print(f"\nRecommendation: {check_result.recommendation}")
        print(f"{'='*60}\n")
    
    def get_statistics(self) -> Dict[str, Any]:
        """الحصول على الإحصائيات"""
        guard_stats = self.guard.get_statistics()
        
        return {
            "llm_stats": self.stats,
            "guard_stats": guard_stats,
            "hallucination_rate": (
                self.stats["hallucinations_detected"] / self.stats["total_requests"]
                if self.stats["total_requests"] > 0 else 0
            ),
            "success_rate": (
                self.stats["successful_responses"] / self.stats["total_requests"]
                if self.stats["total_requests"] > 0 else 0
            ),
            "avg_retries": (
                self.stats["retries_performed"] / self.stats["total_requests"]
                if self.stats["total_requests"] > 0 else 0
            )
        }
    
    def reset_statistics(self):
        """إعادة تعيين الإحصائيات"""
        self.stats = {
            "total_requests": 0,
            "hallucinations_detected": 0,
            "retries_performed": 0,
            "successful_responses": 0,
            "failed_responses": 0
        }
        self.guard.reset_history()
    
    def configure_guard(
        self,
        threshold: Optional[float] = None,
        require_sources: Optional[bool] = None,
        fact_check_enabled: Optional[bool] = None,
        confidence_check_enabled: Optional[bool] = None
    ):
        """تعديل إعدادات الحماية"""
        if threshold is not None:
            self.guard.threshold = threshold
        if require_sources is not None:
            self.guard.require_sources = require_sources
        if fact_check_enabled is not None:
            self.guard.fact_check_enabled = fact_check_enabled
        if confidence_check_enabled is not None:
            self.guard.confidence_check_enabled = confidence_check_enabled
    
    def set_strict_mode(self, enabled: bool):
        """تفعيل/تعطيل الوضع الصارم\n
          active and unactive strict mode
        """
        self.strict_mode = enabled
    
    def set_verbose(self, enabled: bool):
        """تفعيل/تعطيل الإخراج التفصيلي\n
        active and unactive verbose
        """
        self.verbose = enabled