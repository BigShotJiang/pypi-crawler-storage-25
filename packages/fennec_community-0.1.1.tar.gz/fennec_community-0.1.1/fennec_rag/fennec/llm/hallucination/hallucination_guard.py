"""
Hallucination Guard Layer
==========================
طبقة حماية شاملة للـ LLM من الهلوسة (Hallucination)
تتضمن آليات للكشف والتحقق والتأكد من صحة المخرجات
"""

from typing import Dict, List, Optional, Tuple, Any
import re
from dataclasses import dataclass,field
from enum import Enum
import numpy as np
from datetime import datetime
from .hallucination_pattern import uncertainty_patterns_, overconfidence_patterns_, made_up_indicators_



class HallucinationType(Enum):
    """أنواع الهلوسة المحتملة\n
      types of hallucinations
    """
    FACTUAL_ERROR = "factual_error"  # خطأ في الحقائق
    MADE_UP_INFO = "made_up_info"  # معلومات مختلقة
    CONFLICTING_INFO = "conflicting_info"  # معلومات متناقضة
    UNSUPPORTED_CLAIM = "unsupported_claim"  # ادعاءات غير مدعومة
    CONTEXT_DEVIATION = "context_deviation"  # خروج عن السياق
    OVERCONFIDENCE = "overconfidence"  # ثقة زائدة بدون دليل


class ConfidenceLevel(Enum):
    """مستويات الثقة في الإجابة\n
        confidence level
    """
    VERY_HIGH = "very_high"  # 90-100%
    HIGH = "high"  # 75-89%
    MEDIUM = "medium"  # 50-74%
    LOW = "low"  # 25-49%
    VERY_LOW = "very_low"  # 0-24%


@dataclass
class HallucinationCheck:
    """نتيجة فحص الهلوسة\n
      hallucination check result
    """
    is_hallucination: bool
    confidence_score: float  # 0-1
    hallucination_type: Optional[HallucinationType]
    evidence: List[str]
    recommendation: str
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            "is_hallucination": self.is_hallucination,
            "confidence_score": self.confidence_score,
            "hallucination_type": self.hallucination_type.value if self.hallucination_type else None,
            "evidence": self.evidence,
            "recommendation": self.recommendation,
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class GroundingContext:
    """سياق التأكد من المصداقية\n
      context for grounding
    """
    sources: List[str]  # المصادر المستخدمة
    retrieved_facts: List[str]  # الحقائق المسترجعة
    context_window: str  # نافذة السياق
    metadata: Dict[str, Any] = None


class HallucinationGuard:
    """
    طبقة الحماية من الهلوسة
    
    الميزات:
    - كشف الهلوسة في المخرجات
    - التحقق من الحقائق
    - قياس الثقة
    - التأكد من وجود مصادر\n
    hallucination guard 
    features:
    -hallucination detection
    -check from information
    -check confidence
    -check sources
    """
    
    def __init__(
        self,
        threshold: float = 0.7,
        require_sources: bool = True,
        fact_check_enabled: bool = True,
        confidence_check_enabled: bool = True,
        enable_logging: bool = True
    ):
        """
        Args:
            threshold: حد الثقة المطلوب (0-1)
            require_sources: هل يشترط وجود مصادر
            fact_check_enabled: تفعيل التحقق من الحقائق
            confidence_check_enabled: تفعيل فحص الثقة
            enable_logging: تفعيل السجل
        """
        self.threshold = threshold
        self.require_sources = require_sources
        self.fact_check_enabled = fact_check_enabled
        self.confidence_check_enabled = confidence_check_enabled
        self.enable_logging = enable_logging
        
        # أنماط للكشف عن الهلوسة
        self.uncertainty_patterns = uncertainty_patterns_
          
        self.overconfidence_patterns = overconfidence_patterns_
      
        
        self.made_up_indicators = made_up_indicators_
     
        
        # سجل الفحوصات
        self.check_history: List[HallucinationCheck] = []
    
    def check_response(
        self,
        response: str,
        grounding_context: Optional[GroundingContext] = None,
        original_query: Optional[str] = None
    ) -> HallucinationCheck:
        """
        فحص شامل للإجابة للكشف عن الهلوسة\n
        full check for hallucinations detections
        
        Args:
            response: الإجابة من الـ LLM
            grounding_context: السياق والمصادر
            original_query: السؤال الأصلي
            
        Returns:
            HallucinationCheck: نتيجة الفحص
        """
        checks = []
        evidence = []
        
        # 1. فحص المصادر
        # Only run source check when a grounding_context is actually provided.
        # If no context is given (standalone LLM call), requiring sources would
        # always score 0.0 and falsely flag every response as a hallucination.
        if self.require_sources and grounding_context:
            source_check = self._check_sources(response, grounding_context)
            checks.append(source_check)
            if not source_check[0]:
                evidence.append("No grounding sources found")
        
        # 2. فحص التناقض الداخلي
        contradiction_check = self._check_internal_contradictions(response)
        checks.append(contradiction_check)
        if not contradiction_check[0]:
            evidence.append("Internal contradictions detected")
        
        # 3. فحص مؤشرات الثقة
        if self.confidence_check_enabled:
            confidence_check = self._analyze_confidence_markers(response)
            checks.append(confidence_check)
            evidence.extend(confidence_check[2])
        
        # 4. فحص الحقائق إذا كان متاح
        if self.fact_check_enabled and grounding_context:
            fact_check = self._verify_facts(response, grounding_context)
            checks.append(fact_check)
            if not fact_check[0]:
                evidence.append("Facts not supported by context")
        
        # 5. فحص الخروج عن السياق
        if original_query:
            context_check = self._check_context_relevance(response, original_query)
            checks.append(context_check)
            if not context_check[0]:
                evidence.append("Response deviates from query context")
        
        # حساب النتيجة النهائية
        scores = []
        for passed, score, _ in checks:
            if not passed:
                score *= 0.5  # penalty
            scores.append(score)
        # When no checks apply (e.g. no grounding_context and only
        # source-check was configured), default to a neutral passing score
        # instead of 0.5, so responses aren't unnecessarily flagged.
        final_score = np.mean(scores) if scores else 0.75
        
        # تحديد نوع الهلوسة
        hallucination_type = self._determine_hallucination_type(checks, evidence)
        
        # هل هناك هلوسة؟
        is_hallucination = final_score < self.threshold
        
        # التوصية
        recommendation = self._generate_recommendation(
            is_hallucination, final_score, hallucination_type, evidence
        )
        
        result = HallucinationCheck(
            is_hallucination=is_hallucination,
            confidence_score=final_score,
            hallucination_type=hallucination_type,
            evidence=evidence,
            recommendation=recommendation
        )
        
        if self.enable_logging:
            self.check_history.append(result)
        
        return result
    
    def _check_sources(
        self, response: str, context: GroundingContext
    ) -> Tuple[bool, float, List[str]]:
        """التحقق من وجود مصادر للادعاءات"""
        if not context or not context.sources:
            return (False, 0.0, ["No sources provided"])
        
        # استخراج الادعاءات من الإجابة
        claims = self._extract_claims(response)
        
        # التحقق من كل ادعاء
        supported_claims = 0
        evidence = []
        
        for claim in claims:
            is_supported = self._is_claim_supported(claim, context)
            if is_supported:
                supported_claims += 1
            else:
                evidence.append(f"Unsupported claim: {claim[:50]}...")
        
        if not claims:
            return (True, 0.8, ["No specific claims to verify"])
        
        support_ratio = supported_claims / len(claims)
        return (support_ratio > 0.7, support_ratio, evidence)
    
    def _check_internal_contradictions(
        self, response: str
    ) -> Tuple[bool, float, List[str]]:
        """فحص التناقضات الداخلية في الإجابة"""
        sentences = self._split_into_sentences(response)
        contradictions = []
        
        # فحص بسيط للتناقضات
        for i, sent1 in enumerate(sentences):
            for sent2 in sentences[i+1:]:
                if self._are_contradicting(sent1, sent2):
                    contradictions.append(
                        f"Contradiction between: '{sent1[:30]}...' and '{sent2[:30]}...'"
                    )
        
        no_contradictions = len(contradictions) == 0
        score = 1.0 if no_contradictions else max(0.3, 1.0 - len(contradictions) * 0.2)
        
        return (no_contradictions, score, contradictions)
    
    def _analyze_confidence_markers(
        self, response: str
    ) -> Tuple[bool, float, List[str]]:
        """تحليل مؤشرات الثقة في الإجابة"""
        evidence = []
        
        # البحث عن عبارات عدم اليقين
        uncertainty_count = sum(
            len(re.findall(pattern, response, re.IGNORECASE))
            for pattern in self.uncertainty_patterns
        )
        
        # البحث عن عبارات الثقة الزائدة
        overconfidence_count = sum(
            len(re.findall(pattern, response, re.IGNORECASE))
            for pattern in self.overconfidence_patterns
        )
        
        # البحث عن مؤشرات معلومات مختلقة
        made_up_count = sum(
            len(re.findall(pattern, response, re.IGNORECASE))
            for pattern in self.made_up_indicators
        )
        
        if uncertainty_count > 3:
            evidence.append(f"High uncertainty markers: {uncertainty_count}")
        
        if overconfidence_count > 2:
            evidence.append(f"Overconfidence markers: {overconfidence_count}")
        
        if made_up_count > 0:
            evidence.append(f"Made-up info indicators: {made_up_count}")
        
        # حساب النتيجة
        penalty = (uncertainty_count * 0.05) + (overconfidence_count * 0.1) + (made_up_count * 0.2)
        score = max(0.0, 1.0 - penalty)
        
        is_reliable = score > 0.6
        return (is_reliable, score, evidence)
    
    def _verify_facts(
        self, response: str, context: GroundingContext
    ) -> Tuple[bool, float, List[str]]:
        """التحقق من الحقائق بناءً على السياق"""
        if not context.retrieved_facts:
            return (True, 0.7, ["No facts to verify against"])
        
        # استخراج الحقائق من الإجابة
        response_facts = self._extract_factual_statements(response)
        
        verified = 0
        evidence = []
        
        for fact in response_facts:
            is_verified = any(
                self._facts_match(fact, context_fact)
                for context_fact in context.retrieved_facts
            )
            if is_verified:
                verified += 1
            else:
                evidence.append(f"Unverified fact: {fact[:50]}...")
        
        if not response_facts:
            return (True, 0.8, ["No factual statements to verify"])
        
        verification_ratio = verified / len(response_facts)
        return (verification_ratio > 0.7, verification_ratio, evidence)
    
    def _check_context_relevance(
        self, response: str, query: str
    ) -> Tuple[bool, float, List[str]]:
        """التحقق من ملاءمة الإجابة للسؤال"""
        # استخراج الكلمات المفتاحية من السؤال
        query_keywords = self._extract_keywords(query)
        
        # التحقق من وجود الكلمات المفتاحية في الإجابة
        matches = sum(
            1 for keyword in query_keywords
            if keyword.lower() in response.lower()
        )
        
        if not query_keywords:
            return (True, 0.8, [])
        
        relevance_ratio = matches / len(query_keywords)
        is_relevant = relevance_ratio > 0.3
        
        evidence = [] if is_relevant else ["Response may not be relevant to query"]
        
        return (is_relevant, relevance_ratio, evidence)
    
    def _determine_hallucination_type(
        self, checks: List[Tuple], evidence: List[str]
    ) -> Optional[HallucinationType]:
        """تحديد نوع الهلوسة بناءً على الفحوصات"""
        if not any(not check[0] for check in checks):
            return None
        
        evidence_text = " ".join(evidence).lower()
        
        if "no grounding sources" in evidence_text or "unsupported" in evidence_text:
            return HallucinationType.UNSUPPORTED_CLAIM
        
        if "contradiction" in evidence_text:
            return HallucinationType.CONFLICTING_INFO
        
        if "overconfidence" in evidence_text:
            return HallucinationType.OVERCONFIDENCE
        
        if "made-up" in evidence_text:
            return HallucinationType.MADE_UP_INFO
        
        if "not relevant" in evidence_text:
            return HallucinationType.CONTEXT_DEVIATION
        
        if "unverified fact" in evidence_text:
            return HallucinationType.FACTUAL_ERROR
        
        return HallucinationType.UNSUPPORTED_CLAIM
    
    def _generate_recommendation(
        self,
        is_hallucination: bool,
        score: float,
        hallucination_type: Optional[HallucinationType],
        evidence: List[str]
    ) -> str:
        """توليد توصية بناءً على نتيجة الفحص"""
        if not is_hallucination:
            if score > 0.9:
                return "Response appears highly reliable. Safe to use."
            elif score > 0.75:
                return "Response appears reliable. Minor verification recommended."
            else:
                return "Response is acceptable but consider additional verification."
        
        recommendations = {
            HallucinationType.UNSUPPORTED_CLAIM: 
                "Provide grounding sources. Request citations or evidence.",
            HallucinationType.CONFLICTING_INFO: 
                "Resolve contradictions. Regenerate response with consistent information.",
            HallucinationType.OVERCONFIDENCE: 
                "Request hedged language. Ask for uncertainty markers where appropriate.",
            HallucinationType.MADE_UP_INFO: 
                "Reject response. Request information from verified sources only.",
            HallucinationType.CONTEXT_DEVIATION: 
                "Refocus on original query. Provide more specific context.",
            HallucinationType.FACTUAL_ERROR: 
                "Verify facts against reliable sources. Request corrections.",
        }
        
        base_rec = recommendations.get(
            hallucination_type,
            "Review response carefully. Consider regeneration with stricter constraints."
        )
        
        return f"{base_rec} (Confidence: {score:.2%})"
    
    # Helper methods
    
    def _extract_claims(self, text: str) -> List[str]:
        """استخراج الادعاءات من النص"""
        # تقسيم إلى جمل
        sentences = self._split_into_sentences(text)
        
        # تصفية الجمل التي تحتوي على ادعاءات
        claims = []
        for sent in sentences:
            # استبعاد الأسئلة والجمل القصيرة جداً
            if '?' in sent or len(sent.split()) < 5:
                continue
            claims.append(sent.strip())
        
        return claims
    
    def _is_claim_supported(self, claim: str, context: GroundingContext) -> bool:
        """التحقق من دعم الادعاء بالمصادر"""
        claim_lower = claim.lower()
        
        # البحث في المصادر
        for source in context.sources:
            if any(word in source.lower() for word in claim_lower.split() if len(word) > 4):
                return True
        
        # البحث في السياق
        if context.context_window and any(
            word in context.context_window.lower() 
            for word in claim_lower.split() if len(word) > 4
        ):
            return True
        
        return False
    
    def _split_into_sentences(self, text: str) -> List[str]:
        """تقسيم النص إلى جمل"""
        # نمط بسيط لتقسيم الجمل
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _are_contradicting(self, sent1: str, sent2: str) -> bool:
        """فحص التناقض بين جملتين (مبسط)"""
        # كشف بسيط للنفي المتناقض
        negation_words = ['لا', 'ليس', 'not', 'no', 'never', 'none']
        
        sent1_has_neg = any(word in sent1.lower() for word in negation_words)
        sent2_has_neg = any(word in sent2.lower() for word in negation_words)
        
        # إذا كانت إحداهما منفية والأخرى لا، والكلمات متشابهة
        if sent1_has_neg != sent2_has_neg:
            common_words = set(sent1.lower().split()) & set(sent2.lower().split())
            if len(common_words) > 3:
                return True
        
        return False
    
    def _extract_factual_statements(self, text: str) -> List[str]:
        """استخراج الجمل الحقيقية"""
        sentences = self._split_into_sentences(text)
        
        # تصفية الجمل التي قد تحتوي على حقائق
        factual = []
        for sent in sentences:
            # استبعاد الآراء والتعليقات
            if any(word in sent.lower() for word in ['أعتقد', 'أظن', 'ربما', 'i think', 'maybe']):
                continue
            
            # الاحتفاظ بالجمل التي تحتوي على أرقام أو تواريخ أو حقائق محددة
            if re.search(r'\d+|في عام|\d{4}|%', sent):
                factual.append(sent.strip())
        
        return factual if factual else sentences[:3]  # على الأقل أول 3 جمل
    
    def _facts_match(self, fact1: str, fact2: str) -> bool:
        """مطابقة الحقائق"""
        # استخراج الأرقام والتواريخ
        nums1 = set(re.findall(r'\d+', fact1))
        nums2 = set(re.findall(r'\d+', fact2))
        
        # إذا كانت الأرقام متطابقة
        if nums1 and nums2 and nums1 & nums2:
            return True
        
        # مطابقة الكلمات المفتاحية
        words1 = set(word.lower() for word in fact1.split() if len(word) > 4)
        words2 = set(word.lower() for word in fact2.split() if len(word) > 4)
        
        overlap = len(words1 & words2)
        return overlap > min(len(words1), len(words2)) * 0.5
    
    def _extract_keywords(self, text: str) -> List[str]:
        """استخراج الكلمات المفتاحية"""
        # إزالة الكلمات الشائعة
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'من', 'في', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه', 'ذلك'
        }
        
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = [w for w in words if w not in stop_words and len(w) > 3]
        
        return keywords
    
    def get_confidence_level(self, score: float) -> ConfidenceLevel:
        """تحويل النتيجة إلى مستوى ثقة"""
        if score >= 0.9:
            return ConfidenceLevel.VERY_HIGH
        elif score >= 0.75:
            return ConfidenceLevel.HIGH
        elif score >= 0.5:
            return ConfidenceLevel.MEDIUM
        elif score >= 0.25:
            return ConfidenceLevel.LOW
        else:
            return ConfidenceLevel.VERY_LOW
    
    def get_statistics(self) -> Dict[str, Any]:
        """احصائيات الفحوصات"""
        if not self.check_history:
            return {"message": "No checks performed yet"}
        
        total_checks = len(self.check_history)
        hallucinations = sum(1 for check in self.check_history if check.is_hallucination)
        avg_score = np.mean([check.confidence_score for check in self.check_history])
        
        types_count = {}
        for check in self.check_history:
            if check.hallucination_type:
                type_name = check.hallucination_type.value
                types_count[type_name] = types_count.get(type_name, 0) + 1
        
        return {
            "total_checks": total_checks,
            "hallucinations_detected": hallucinations,
            "hallucination_rate": hallucinations / total_checks,
            "average_confidence_score": avg_score,
            "hallucination_types": types_count,
            "last_check": self.check_history[-1].to_dict() if self.check_history else None
        }
    
    def reset_history(self):
        """مسح السجل"""
        self.check_history = []