"""
Configuration for Hallucination Guard
======================================
إعدادات قابلة للتخصيص لطبقة الحماية من الهلوسة
"""

from dataclasses import dataclass
from typing import List
from .hallucination_pattern import overconfidence_patterns_, uncertainty_patterns_, made_up_indicators_
from dataclasses import asdict




@dataclass
class GuardConfig:
    """إعدادات HallucinationGuard"""
    
    # عتبة الثقة
    threshold: float = 0.7
    
    # هل يشترط وجود مصادر
    require_sources: bool = True
    
    # تفعيل التحقق من الحقائق
    fact_check_enabled: bool = True
    
    # تفعيل فحص الثقة
    confidence_check_enabled: bool = True
    
    # تفعيل السجل
    enable_logging: bool = True
    
    # أنماط كشف عدم اليقين (يمكن التعديل)
    uncertainty_patterns: List[str] = None
    
    # أنماط كشف الثقة الزائدة (يمكن التعديل)
    overconfidence_patterns: List[str] = None
    
    # أنماط كشف المعلومات المختلقة (يمكن التعديل)
    made_up_patterns: List[str] = None
    
    def __post_init__(self):
        """تهيئة الأنماط الافتراضية إذا لم تُحدد"""
        if self.uncertainty_patterns is None:
            self.uncertainty_patterns = uncertainty_patterns_
             
        
        if self.overconfidence_patterns is None:
            self.overconfidence_patterns = overconfidence_patterns_
           
        
        if self.made_up_patterns is None:
            self.made_up_patterns = made_up_indicators_
           
@dataclass
class ProtectedLLMConfig:
    """إعدادات ProtectedLLMInterface
     ProtectedLLMInterface config
    """
    
    # إعادة محاولة تلقائية
    auto_retry: bool = True
    
    # أقصى عدد محاولات
    max_retries: int = 3
    
    # طلب مصادر في البرومبت
    request_sources: bool = True
    
    # الوضع الصارم (رفض الهلوسة)
    strict_mode: bool = False
    
    # عرض التفاصيل
    verbose: bool = True
    
    # تقليل temperature عند إعادة المحاولة
    temperature_decay: float = 0.1
    
    # أقل temperature مسموح
    min_temperature: float = 0.3


# إعدادات مُعرّفة مسبقاً (Presets)

class GuardPresets:
    """إعدادات جاهزة لحالات استخدام مختلفة
       config ready for different use cases
    """
    
    @staticmethod
    def strict() -> GuardConfig:
        """إعدادات صارمة للتطبيقات الحرجة (طبي، قانوني، مالي)
        strict config for critical use cases (legal, medical, financial)
        """
        return GuardConfig(
            threshold=0.9,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
    
    @staticmethod
    def balanced() -> GuardConfig:
        """إعدادات متوازنة للاستخدام العام
        balanced config for general use cases
        """
        return GuardConfig(
            threshold=0.7,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
    
    @staticmethod
    def relaxed() -> GuardConfig:
        """إعدادات مرنة للمحتوى الإبداعي
        flixible config for creative writing
        """
        return GuardConfig(
            threshold=0.5,
            require_sources=False,
            fact_check_enabled=False,
            confidence_check_enabled=True,
            enable_logging=True
        )
    
    @staticmethod
    def minimal() -> GuardConfig:
        """إعدادات أدنى (للاختبار فقط)
        minimal config for testing purposes
        """
        return GuardConfig(
            threshold=0.3,
            require_sources=False,
            fact_check_enabled=False,
            confidence_check_enabled=False,
            enable_logging=False
        )


class ProtectedLLMPresets:
    """إعدادات جاهزة لـ ProtectedLLMInterface
    config ready for ProtectedLLMInterface
    """
    
    @staticmethod
    def production() -> ProtectedLLMConfig:
        """إعدادات للإنتاج
        production config for production use
        """
        return ProtectedLLMConfig(
            auto_retry=True,
            max_retries=3,
            request_sources=True,
            strict_mode=False,
            verbose=False,
            temperature_decay=0.1,
            min_temperature=0.3
        )
    
    @staticmethod
    def development() -> ProtectedLLMConfig:
        """إعدادات للتطوير
        development config for development use
        """
        return ProtectedLLMConfig(
            auto_retry=True,
            max_retries=5,
            request_sources=True,
            strict_mode=False,
            verbose=True,
            temperature_decay=0.1,
            min_temperature=0.3
        )
    
    @staticmethod
    def critical() -> ProtectedLLMConfig:
        """إعدادات للتطبيقات الحرجة
          critical config for critical use cases
        """
        return ProtectedLLMConfig(
            auto_retry=True,
            max_retries=5,
            request_sources=True,
            strict_mode=True,
            verbose=True,
            temperature_decay=0.15,
            min_temperature=0.2
        )
    
    @staticmethod
    def fast() -> ProtectedLLMConfig:
        """إعدادات سريعة (أقل إعادة محاولات)
         fast config with fewer retries
        """
        return ProtectedLLMConfig(
            auto_retry=True,
            max_retries=1,
            request_sources=True,
            strict_mode=False,
            verbose=False,
            temperature_decay=0.1,
            min_temperature=0.3
        )


# إعدادات حسب المجال (Domain-Specific Configs)

class DomainConfigs:
    """إعدادات مخصصة حسب المجال
    specific configs for each domain
    """
    
    @staticmethod
    def medical() -> tuple[GuardConfig, ProtectedLLMConfig]:
        """إعدادات للمجال الطبي
        medical config for medical use cases
        """
        guard = GuardConfig(
            threshold=0.95,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
        
        llm = ProtectedLLMConfig(
            auto_retry=True,
            max_retries=5,
            request_sources=True,
            strict_mode=True,
            verbose=True,
            temperature_decay=0.15,
            min_temperature=0.2
        )
        
        return guard, llm
    
    @staticmethod
    def legal() -> tuple[GuardConfig, ProtectedLLMConfig]:
        """إعدادات للمجال القانوني
        legal config for legal use cases
        """
        guard = GuardConfig(
            threshold=0.9,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
        
        llm = ProtectedLLMConfig(
            auto_retry=True,
            max_retries=5,
            request_sources=True,
            strict_mode=True,
            verbose=True,
            temperature_decay=0.15,
            min_temperature=0.2
        )
        
        return guard, llm
    
    @staticmethod
    def financial() -> tuple[GuardConfig, ProtectedLLMConfig]:
        """إعدادات للمجال المالي
        financial config for financial use cases
        """
        guard = GuardConfig(
            threshold=0.9,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
        
        llm = ProtectedLLMConfig(
            auto_retry=True,
            max_retries=4,
            request_sources=True,
            strict_mode=True,
            verbose=True,
            temperature_decay=0.1,
            min_temperature=0.25
        )
        
        return guard, llm
    
    @staticmethod
    def educational() -> tuple[GuardConfig, ProtectedLLMConfig]:
        """إعدادات للمجال التعليمي
        educational config for educational use cases
        """
        guard = GuardConfig(
            threshold=0.75,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
        
        llm = ProtectedLLMConfig(
            auto_retry=True,
            max_retries=3,
            request_sources=True,
            strict_mode=False,
            verbose=True,
            temperature_decay=0.1,
            min_temperature=0.3
        )
        
        return guard, llm
    
    @staticmethod
    def customer_service() -> tuple[GuardConfig, ProtectedLLMConfig]:
        """إعدادات لخدمة العملاء
        customer service config for customer service use cases
        """
        guard = GuardConfig(
            threshold=0.7,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True
        )
        
        llm = ProtectedLLMConfig(
            auto_retry=True,
            max_retries=2,
            request_sources=True,
            strict_mode=False,
            verbose=False,
            temperature_decay=0.1,
            min_temperature=0.3
        )
        
        return guard, llm
    
    @staticmethod
    def creative_writing() -> tuple[GuardConfig, ProtectedLLMConfig]:
        """إعدادات للكتابة الإبداعية
        creative writing config for creative writing use cases
        """
        guard = GuardConfig(
            threshold=0.5,
            require_sources=False,
            fact_check_enabled=False,
            confidence_check_enabled=True,
            enable_logging=True
        )
        
        llm = ProtectedLLMConfig(
            auto_retry=False,  # لا إعادة محاولة للإبداع
            max_retries=0,
            request_sources=False,
            strict_mode=False,
            verbose=False,
            temperature_decay=0.0,
            min_temperature=0.7
        )
        
        return guard, llm






def filter_kwargs_for_class(cls, data: dict):
    import inspect
    sig = inspect.signature(cls.__init__)
    valid_params = set(sig.parameters.keys())
    valid_params.discard("self")

    return {
        k: v for k, v in data.items()
        if k in valid_params
    }



def create_protected_llm_for_domain(llm_interface, domain: str):
    method = getattr(
        DomainConfigs,
        domain.replace("-", "_").replace(" ", "_"),
        None
    )

    if method is None:
        raise ValueError(
            f"Unknown domain '{domain}'. "
            "Available: medical, legal, financial, research, education, creative_writing"
        )

    guard_config, protected_config = method()

    from .hallucination_guard import HallucinationGuard
    from .protected_llm_interface import ProtectedLLMInterface


    from dataclasses import asdict

    guard_dict = asdict(guard_config)
    guard_kwargs = filter_kwargs_for_class(HallucinationGuard, guard_dict)

    guard = HallucinationGuard(**guard_kwargs)

  # بعد (الحل)
    protected_dict = asdict(protected_config)
    protected_kwargs = filter_kwargs_for_class(ProtectedLLMInterface, protected_dict)

    return ProtectedLLMInterface(
        llm_interface=llm_interface,
        hallucination_guard=guard,
        **protected_kwargs
    )