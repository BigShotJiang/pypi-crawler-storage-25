"""
Hallucination Guard Module
===========================
طبقة الحماية من الهلوسة للـ LLM
"""

from .hallucination_guard import (
    HallucinationGuard,
    HallucinationCheck,
    HallucinationType,
    ConfidenceLevel,
    GroundingContext,
)
from .protected_llm_interface import ProtectedLLMInterface
from .config import (
    GuardConfig,
    ProtectedLLMConfig,
    GuardPresets,
    ProtectedLLMPresets,
    DomainConfigs,
    create_protected_llm_for_domain,
)

__all__ = [
    # Core guard
    "HallucinationGuard",
    "HallucinationCheck",
    "HallucinationType",
    "ConfidenceLevel",
    "GroundingContext",
    # Protected interface
    "ProtectedLLMInterface",
    # Config & presets
    "GuardConfig",
    "ProtectedLLMConfig",
    "GuardPresets",
    "ProtectedLLMPresets",
    "DomainConfigs",
    "create_protected_llm_for_domain",
]
