from .base_llm_interface import BaseLLMInterface
from .config_llm import llm_config
from typing import Optional
import warnings
import asyncio

warnings.filterwarnings("ignore", category=UserWarning)
config = llm_config()


class HuggingFaceInterface(BaseLLMInterface):
    """
    Enhanced HuggingFace interface supporting causal and seq2seq models.\n
    واجهة هاجنج فيس المحسّنة — تدعم النماذج السببية والتسلسل للتسلسل.

    """

    # Model types classification - تصنيف أنواع النماذج
    MODEL_TYPES = {
        'causal_lm': ['gpt', 'llama', 'mistral', 'falcon', 'bloom', 'opt', 'pythia'],
        'seq2seq':   ['t5', 'bart', 'mbart', 'pegasus', 'flan'],
        'masked_lm': ['bert', 'roberta', 'albert', 'electra', 'deberta', 'arabert'],
    }

    def __init__(
        self,
        model_name: str = config.hugginface_model,
        max_input_tokens: int = 1024,
        **kwargs,
    ):
        """
        Initialize HuggingFace Interface - تهيئة واجهة هاجنج فيس

        Args:
            model_name:        اسم النموذج | Model name
            max_input_tokens:  الحد الأقصى لتوكنات الإدخال | Max input context length
            **kwargs:          إعدادات إضافية | Additional settings
        """
        super().__init__(model_name, api_key=None, **kwargs)

        # ✅ Fix 4: explicit parameter instead of hidden kwargs
        self.max_input_tokens = max_input_tokens

        try:
            from transformers import (
                AutoConfig,
                AutoModelForCausalLM,
                AutoModelForSeq2SeqLM,
                AutoTokenizer,
            )
            import torch

            self.torch = torch
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_name, trust_remote_code=True
            )

            # Detect model type via config (more reliable than name matching)
            # اكتشاف نوع النموذج عبر الإعدادات (أكثر موثوقية من مطابقة الاسم)
            model_config = AutoConfig.from_pretrained(model_name, trust_remote_code=True)

            if getattr(model_config, "is_encoder_decoder", False):
                self.model_type = "seq2seq"
            elif model_config.model_type.lower() in [
                "bert", "roberta", "albert", "deberta", "arabert",
                "electra", "camembert", "xlm-roberta",
            ]:
                # ✅ Fix 3: raise a clear error instead of trying to use it as LLM
             raise NotImplementedError(
                                    f"The model '{model_name}' is of type masked_lm (e.g., BERT) "
                                    f"and is designed for fill-mask tasks only, not for free text generation.\n"
                                    f"Use a causal_lm model such as GPT or LLaMA, "
                                    f"or a seq2seq model like T5 or BART instead."
                                )
            else:
                self.model_type = "causal_lm"

            # ✅ Fix 1: correct device_map usage — never call .to() after device_map="auto"
            use_cuda = torch.cuda.is_available()
            self.device = "cuda" if use_cuda else "cpu"

            if use_cuda:
                # With CUDA: use device_map="auto", never call .to() afterwards
                load_kwargs = dict(
                    device_map="auto",
                    trust_remote_code=True,
                    torch_dtype=torch.float16,
                )
            else:
                # Without CUDA: no device_map, load directly to CPU
                load_kwargs = dict(
                    trust_remote_code=True,
                    torch_dtype=torch.float32,
                )

            if self.model_type == "causal_lm":
                self.model = AutoModelForCausalLM.from_pretrained(model_name, **load_kwargs)
            elif self.model_type == "seq2seq":
                self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name, **load_kwargs)

            # ✅ Fix 1: .to(device) only on CPU and only without device_map
            if not use_cuda:
                self.model = self.model.to(self.device)

            # Ensure padding token exists - التأكد من وجود رمز الحشو
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token or "[PAD]"

            print(
                f"✓ Loaded '{model_name}' | type={self.model_type} "
                f"| device={self.device} | max_input={self.max_input_tokens}"
            )

        except NotImplementedError:
            raise
        except ImportError:
            raise ImportError(
                "Install transformers and torch: pip install transformers torch"
            )
        except Exception as exc:
            raise RuntimeError(f"Error loading model '{model_name}': {exc}") from exc

    # ──────────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────────

    def generate(
        self,
        prompt: str,
        max_tokens: int = config.max_token,
        temperature: float = config.temperature,
        **kwargs,
    ) -> str:
        """
        Generate text depending on model type.\n
        توليد النص حسب نوع النموذج.

        Args:
            prompt:      النص المدخل | Input text
            max_tokens:  الحد الأقصى للتوكنات المولّدة | Max new tokens
            temperature: درجة العشوائية — 0 = greedy decoding | Sampling temperature
            **kwargs:    معاملات توليد إضافية | Extra generation params

        Returns:
            النص المولّد | Generated text string
        """
        try:
            if self.model_type == "causal_lm":
                return self._generate_causal(prompt, max_tokens, temperature, **kwargs)
            elif self.model_type == "seq2seq":
                return self._generate_seq2seq(prompt, max_tokens, temperature, **kwargs)
            else:
                return self._generate_causal(prompt, max_tokens, temperature, **kwargs)
        except Exception as exc:
            print(f"⚠ HuggingFace generation error: {exc}")
            return f"Generation error: {exc}"

    async def generate_async(
        self,
        prompt: str,
        max_tokens: int = config.max_token,
        temperature: float = config.temperature,
        **kwargs,
    ) -> str:
        """Async wrapper for generation - غلاف غير متزامن للتوليد"""
        return await asyncio.to_thread(
            self.generate, prompt, max_tokens, temperature, **kwargs
        )

    # ──────────────────────────────────────────────────────────────────
    # Internal helpers — مساعدات داخلية
    # ──────────────────────────────────────────────────────────────────

    def _build_gen_kwargs(self, max_tokens: int, temperature: float, **kwargs) -> dict:
        """
        Build generation kwargs safely.
        ✅ Fix 2: temperature is NOT passed to model.generate when do_sample=False
        بناء معاملات التوليد — temperature لا تُمرَّر عند greedy decoding
        """
        do_sample = temperature > 0

        gen_kwargs = dict(
            max_new_tokens=max_tokens,
            do_sample=do_sample,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
        )

        if do_sample:
            # these params are only meaningful when sampling
            gen_kwargs["temperature"] = temperature
            gen_kwargs["top_p"]       = kwargs.get("top_p", 0.9)
            gen_kwargs["top_k"]       = kwargs.get("top_k", 50)
        else:
            # greedy or beam search
            num_beams = kwargs.get("num_beams", 1)
            if num_beams > 1:
                gen_kwargs["num_beams"] = num_beams

        if "repetition_penalty" in kwargs:
            gen_kwargs["repetition_penalty"] = kwargs["repetition_penalty"]

        return gen_kwargs

    def _tokenize(self, prompt: str) -> dict:
        """
        Tokenize prompt using self.max_input_tokens.
        ✅ Fix 4: uses the class attribute instead of a hidden kwarg default
        """
        return self.tokenizer(
            prompt,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=self.max_input_tokens,
        ).to(self.device)

    # ──────────────────────────────────────────────────────────────────
    # Internal generation methods — طرق التوليد الداخلية
    # ──────────────────────────────────────────────────────────────────

    def _generate_causal(self, prompt: str, max_tokens: int, temperature: float, **kwargs) -> str:
        """
        Generate using causal LM (GPT, LLaMA, Mistral...).\n
        توليد النص باستخدام نموذج اللغة السببي.
        """
        inputs     = self._tokenize(prompt)
        gen_kwargs = self._build_gen_kwargs(max_tokens, temperature, **kwargs)

        with self.torch.no_grad():
            outputs = self.model.generate(**inputs, **gen_kwargs)

        # Extract only newly generated tokens - استخراج التوكنات الجديدة فقط
        input_len     = inputs["input_ids"].shape[-1]
        generated_ids = outputs[0][input_len:]
        response      = self.tokenizer.decode(generated_ids, skip_special_tokens=True).strip()
        return response or "No text generated"

    def _generate_seq2seq(self, prompt: str, max_tokens: int, temperature: float, **kwargs) -> str:
        """
        Generate using seq2seq model (T5, BART, Flan...).\n
        توليد النص باستخدام نموذج التسلسل للتسلسل.
        """
        inputs     = self._tokenize(prompt)
        gen_kwargs = self._build_gen_kwargs(max_tokens, temperature, **kwargs)

        # seq2seq manages its own decoder tokens — remove causal-only keys
        gen_kwargs.pop("pad_token_id", None)
        gen_kwargs.pop("eos_token_id", None)

        with self.torch.no_grad():
            outputs = self.model.generate(**inputs, **gen_kwargs)

        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
        return response or "No text generated"

    # ──────────────────────────────────────────────────────────────────
    # Utilities
    # ──────────────────────────────────────────────────────────────────

    def get_model_info(self) -> dict:
        """
        Get model information - الحصول على معلومات النموذج.

        Returns:
            Dictionary with model details - قاموس يحتوي على تفاصيل النموذج
        """
        return {
            "model_name":           self.model_name,
            "model_type":           self.model_type,
            "device":               self.device,
            "has_cuda":             self.torch.cuda.is_available(),
            "max_input_tokens":     self.max_input_tokens,
            "tokenizer_vocab_size": len(self.tokenizer),
        }