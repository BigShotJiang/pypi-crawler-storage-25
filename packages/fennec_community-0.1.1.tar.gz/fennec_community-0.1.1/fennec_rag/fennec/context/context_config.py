from dataclasses import dataclass
from typing import Callable


@dataclass
class ContextConfig:
    """
    إعدادات بناء السياق\n
    Context building configuration
    """
    max_context_length: int = 2000      # الحد الأقصى لطول السياق | Maximum context length
    include_scores: bool = False        # إضافة درجات التشابه | Include similarity scores
    include_metadata: bool = False      # إضافة البيانات الوصفية | Include metadata
    separator: str = "\n---\n"          # فاصل بين القطع | Separator between chunks
    template: str = "arabic"            # القالب المستخدم | Template to use
                                        # Options: 'arabic', 'english', 'minima 

    # Duplication strategy settings
    prefix_length : int = 100

    # Compression strategy settings
    min_compression_char : int = 50
    LengthCounter = Callable[[str], int]
LengthCounter = Callable[[str], int]
