from typing import List
from .stratgey import BudgetAllocationStrategy

class EqualBudgetAllocation(BudgetAllocationStrategy):
    """Divide the global budget equally among all queries.\n
    بالتساوي query علي جميع ال tokens تقسيم اجمالي 
    """

    def allocate(self, total_budget: int, n_queries: int) -> List[int]:
        if n_queries <= 0:
            return []
        per_query = total_budget // n_queries
        budgets = [per_query] * n_queries
        # Give any remainder to the first query.
        budgets[0] += total_budget - sum(budgets)
        return budgets


class WeightedBudgetAllocation(BudgetAllocationStrategy):
    """Allocate budget proportionally to provided weights.\n
      weights بالاهميه والتي تحددعن طريق قيمه  query علي جميع ال tokens تقسيم اجمالي 
    """

    def __init__(self, weights: List[float]):
        self.weights = weights

    def allocate(self, total_budget: int, n_queries: int) -> List[int]:
        if len(self.weights) != n_queries:
            raise ValueError("weights length must equal n_queries.")
        total_w = sum(self.weights)
        if total_w == 0:
            # If all weights are zero, fall back to equal allocation.
            return EqualBudgetAllocation().allocate(total_budget, n_queries)
        raw = [total_budget * w / total_w for w in self.weights]
        budgets = [max(1, int(b)) for b in raw]
        # Correct rounding drift.
        diff = total_budget - sum(budgets)
        budgets[0] += diff
        return budgets
