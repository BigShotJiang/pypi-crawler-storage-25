
from __future__ import annotations
import hashlib
import logging
from dataclasses import dataclass
from typing import List, Optional, Protocol, Tuple, runtime_checkable
from .allocations import EqualBudgetAllocation
from .context_config import ContextConfig , LengthCounter
from .stratgey import DeduplicationStrategy, RankingStrategy, CompressionStrategy, BudgetAllocationStrategy
config = ContextConfig()
logger = logging.getLogger(__name__)



@runtime_checkable
class ChunkProtocol(Protocol):
    """Formal interface that every chunk object must satisfy."""
    doc_id: str
    text: str
    metadata: Optional[dict]


def validate_chunk(chunk: object) -> None:
    """Raise TypeError with a descriptive message if chunk is malformed."""
    missing = [
        attr for attr in ("doc_id", "text")
        if not hasattr(chunk, attr)
    ]
    if missing:
        raise TypeError(
            f"Chunk is missing required attributes: {missing}. "
            "Chunk must expose 'doc_id: str' and 'text: str'."
        )
    if not isinstance(chunk.text, str):          # type: ignore[union-attr]
        raise TypeError(f"chunk.text must be str, got {type(chunk.text).__name__}.")
    if not isinstance(chunk.doc_id, str):        # type: ignore[union-attr]
        raise TypeError(f"chunk.doc_id must be str, got {type(chunk.doc_id).__name__}.")


# ─────────────────────────────────────────────
#  Template Dataclass
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class ContextTemplate:
    header: str
    chunk_format: str
    chunk_with_score: str
    footer: str


def char_counter(text: str) -> int:
    """Default character-based counter."""
    if text is None:
        return 0
    return len(text)

def make_token_counter(tokenizer) -> LengthCounter:
    """
    Wrap any HuggingFace / tiktoken-style tokenizer into a LengthCounter.

    Usage example:
        import tiktoken
        enc = tiktoken.encoding_for_model("gpt-4")
        counter = make_token_counter(enc)
        manager = ContextManager(config, length_counter=counter)
    """
    def _count(text: str) -> int:
        return len(tokenizer.encode(text))
    return _count




class PrefixDeduplication(DeduplicationStrategy):
    """Original prefix-based deduplication (fast but weak)."""

    def __init__(self, prefix_length= config.prefix_length):
        self.prefix_length = prefix_length

    def deduplicate(self, chunks: List[Tuple]) -> List[Tuple]:
        seen: set[str] = set()
        unique: List[Tuple] = []
        for chunk, score in chunks:
            if self.prefix_length > len(chunk.text): 
                raise ValueError(f"prefix_length {self.prefix_length} exceeds chunk text length {len(chunk.text)}.")
            sig = chunk.text[: self.prefix_length].lower()
            if sig not in seen:
                seen.add(sig)
                unique.append((chunk, score))
        return unique


class HashDeduplication(DeduplicationStrategy):
    """
    Strong SHA-256 hash of the full normalised text.
    Near-duplicate detection: lower-case + whitespace normalisation
    before hashing to catch trivially different copies.
    """

    def deduplicate(self, chunks: List[Tuple]) -> List[Tuple]:
        seen: set[str] = set()
        unique: List[Tuple] = []
        for chunk, score in chunks:
            normalised = " ".join(chunk.text.lower().split())
            sig = hashlib.sha256(normalised.encode()).hexdigest()
            if sig not in seen:
                seen.add(sig)
                unique.append((chunk, score))
        return unique


# ─────────────────────────────────────────────
#  Concrete Ranking Strategy
# ─────────────────────────────────────────────

class ScoreRanking(RankingStrategy):
    """Sort by similarity score, highest first."""

    def rank(self, chunks: List[Tuple], max_chunks: Optional[int]) -> List[Tuple]:
        ranked = sorted(chunks, key=lambda x: x[1], reverse=True)
        return ranked[:max_chunks] if max_chunks is not None else ranked



class GreedyCompression(CompressionStrategy):
    """
    Keep header + footer, greedily fill the middle.
    Guards against negative available space and tiny targets.
    """

    MIN_CONTENT_LENGTH = config.min_compression_char  # chars / tokens – absolute floor

    def compress(self, context: str, target: int,
                 counter: LengthCounter, separator: str) -> str:
        if counter(context) <= target:
            return context

        if target <= 0:
            logger.warning("compress called with target_length=%d; returning empty.", target)
            return ""

        parts = context.split(separator)

        if len(parts) <= 2:
            return self._truncate(context, target, counter)

        header, *middle, footer = parts
        overhead = counter(header) + counter(footer) + 2 * counter(separator)
        available = target - overhead

        if available < self.MIN_CONTENT_LENGTH:
            # Budget too tight to fit even middle content; return truncated header only.
            logger.warning(
                "compress: available space (%d) below minimum (%d). "
                "Returning truncated header.",
                available, self.MIN_CONTENT_LENGTH,
            )
            return self._truncate(header, target, counter)

        compressed_middle: List[str] = []
        used = 0
        for part in middle:
            part_len = counter(part)
            remaining = available - used
            if remaining <= 0:
                break
            if used + part_len <= available:
                compressed_middle.append(part)
                used += part_len
            elif remaining > self.MIN_CONTENT_LENGTH:
                compressed_middle.append(self._truncate(part, remaining, counter))
                break

        result = separator.join([header, *compressed_middle, footer])

        if counter(result) > target:
            result = self._truncate(result, target, counter)

        return result

    @staticmethod
    def _truncate(text: str, max_len: int, counter: LengthCounter) -> str:
        if counter(text) <= max_len:
            return text
        # Binary-search the cut point to work for both char & token counters.
        lo, hi = 0, len(text)
        while lo < hi - 1:
            mid = (lo + hi) // 2
            if counter(text[:mid]) <= max_len - 3:  # -3 for "..."
                lo = mid
            else:
                hi = mid
        truncated = text[:lo]
        last_space = truncated.rfind(" ")
        if last_space > lo * 0.8:
            truncated = truncated[:last_space]
        return truncated + "..."




class ContextManager:
    """
    Orchestrator for building, compressing, and inspecting RAG context.

    Behaviour is fully customisable through injected strategy objects,
    making ContextManager responsible only for coordination.
    """

    TEMPLATES: dict[str, ContextTemplate] = {
        'arabic': ContextTemplate(
            header="المعلومات المسترجعة:",
            chunk_format="[مصدر: {doc_id}] {text}",
            chunk_with_score="[مصدر: {doc_id} | تشابه: {score:.2f}] {text}",
            footer="---",
        ),
        'english': ContextTemplate(
            header="Retrieved Information:",
            chunk_format="[Source: {doc_id}] {text}",
            chunk_with_score="[Source: {doc_id} | Similarity: {score:.2f}] {text}",
            footer="---",
        ),
        'minimal': ContextTemplate(
            header="",
            chunk_format="{text}",
            chunk_with_score="{text}",
            footer="",
        ),
    }

    DEFAULT_TEMPLATE = config.template

    def __init__(
        self,
        config: Optional[ContextConfig] = None,
        *,
        length_counter: Optional[LengthCounter] = None,
        dedup_strategy: Optional[DeduplicationStrategy] = None,
        ranking_strategy: Optional[RankingStrategy] = None,
        compression_strategy: Optional[CompressionStrategy] = None,
        budget_strategy: Optional[BudgetAllocationStrategy] = None,
    ):
        self.config = config or ContextConfig()
        self._counter: LengthCounter = length_counter or char_counter
        self._dedup = dedup_strategy or HashDeduplication()
        self._ranker = ranking_strategy or ScoreRanking()
        self._compressor = compression_strategy or GreedyCompression()
        self._budget_allocator = budget_strategy or EqualBudgetAllocation()
        self._validate_config()

    # ── Config ──────────────────────────────────────────────────────────

    def _validate_config(self) -> None:
        if self.config.max_context_length <= 0:
            raise ValueError("max_context_length must be a positive integer.")
        if self.config.template not in self.TEMPLATES:
            logger.warning(
                "Template '%s' not found; falling back to '%s'.",
                self.config.template, self.DEFAULT_TEMPLATE,
            )
            self.config.template = self.DEFAULT_TEMPLATE

    @property
    def _template(self) -> ContextTemplate:
        return self.TEMPLATES[self.config.template]

    # ── Public API ───────────────────────────────────────────────────────

    def build(
        self,
        query: str,
        chunks: List[Tuple],
        max_chunks: Optional[int] = None,
        *,
        max_length: Optional[int] = None,
    ) -> str:
        """
        Build a formatted context string from retrieved (chunk, score) pairs.

        Args:
            query:      The user query (used for logging).
            chunks:     List of (ChunkProtocol, float) pairs.
            max_chunks: Hard cap on the number of chunks included.
            max_length: Override for max context length (falls back to config).
        """
        budget = max_length or self.config.max_context_length

        if not chunks:
            logger.warning(
                "build | query='%.60s' | chunks=0 | returning empty context.", query
            )
            return self._build_empty_context()

        try:
            for chunk, _ in chunks:
                validate_chunk(chunk)

            original_count = len(chunks)

            deduped = self._dedup.deduplicate(chunks)
            ranked = self._ranker.rank(deduped, max_chunks)

            removed_dupes = original_count - len(deduped)

            logger.debug(
                "build | query='%.60s' | input=%d | after_dedup=%d "
                "| removed_dupes=%d | after_rank=%d",
                query, original_count, len(deduped), removed_dupes, len(ranked),
            )

            context, included = self._assemble(ranked, budget)

            logger.info(
                "build | query='%.60s' | included_chunks=%d | length=%d | budget=%d",
                query, included, self._counter(context), budget,
            )
            return context

        except (TypeError, ValueError) as exc:
            logger.error("build | query='%.60s' | validation error: %s", query, exc)
            return self._build_empty_context()
        except Exception:
            logger.exception("build | query='%.60s' | unexpected error.", query)
            return self._build_empty_context()

    def build_multi_query_context(
        self,
        queries: List[str],
        all_chunks: List[List[Tuple]],
        *,
        global_budget: Optional[int] = None,
    ) -> str:
        """
        Build a combined context for multi-hop RAG.

        If global_budget is set the budget is distributed across queries
        using the injected BudgetAllocationStrategy; the resulting context
        is clamped to global_budget afterwards.
        """
        if len(queries) != len(all_chunks):
            raise ValueError("'queries' and 'all_chunks' must have the same length.")

        n = len(queries)
        budgets: List[Optional[int]] = [None] * n

        if global_budget is not None:
            allocated = self._budget_allocator.allocate(global_budget, n)
            budgets = list(allocated)  # type: ignore[assignment]
            logger.debug(
                "build_multi_query_context | global_budget=%d | per_query=%s",
                global_budget, allocated,
            )

        sections: List[str] = []
        for i, (query, chunks) in enumerate(zip(queries, all_chunks)):
            ctx = self.build(query, chunks, max_length=budgets[i])
            sections.append(f"--- Query {i + 1}: {query} ---\n{ctx}")

        combined = "\n\n".join(sections)

        #   Final clamp to global budget.
        if global_budget is not None and self._counter(combined) > global_budget:
            logger.info(
                "build_multi_query_context | combined length %d > budget %d; compressing.",
                self._counter(combined), global_budget,
            )
            combined = self._compressor.compress(
                combined, global_budget, self._counter, self.config.separator
            )

        return combined

    def compress_context(self, context: str, target_length: int) -> str:
        """
          Compress context with full edge-case handling.
        Delegates to the injected CompressionStrategy.
        """
        if target_length <= 0:
            logger.error(
                "compress_context | target_length=%d is invalid; returning empty.", target_length
            )
            return ""

        before = self._counter(context)
        result = self._compressor.compress(
            context, target_length, self._counter, self.config.separator
        )
        after = self._counter(result)

        #   Structured log.
        logger.info(
            "compress_context | before=%d | after=%d | target=%d | reduced_by=%d",
            before, after, target_length, before - after,
        )

        #   Absolute safety guarantee – should never be needed if strategy is correct.
        if after > target_length:
            logger.error(
                "compress_context | strategy returned length %d > target %d. "
                "Hard-truncating.",
                after, target_length,
            )
            result = result[:target_length]

        return result

    def get_context_stats(self, context: str) -> dict:
        """
          Accurate statistics that exclude header and footer from chunk metrics.
        """
        tmpl = self._template
        parts = context.split(self.config.separator)

        # Strip header / footer if present to get true chunk parts.
        chunk_parts = parts
        if tmpl.header and chunk_parts and chunk_parts[0] == tmpl.header:
            chunk_parts = chunk_parts[1:]
        if tmpl.footer and chunk_parts and chunk_parts[-1] == tmpl.footer:
            chunk_parts = chunk_parts[:-1]

        # Remove empty strings that arise from multiple separators.
        chunk_parts = [p for p in chunk_parts if p.strip()]
        chunk_count = len(chunk_parts)
        chunk_lengths = [self._counter(p) for p in chunk_parts]

        return {
            'total_length':     self._counter(context),
            'word_count':       len(context.split()),
            'chunk_count':      chunk_count,
            'template':         self.config.template,
            'avg_chunk_length': sum(chunk_lengths) // chunk_count if chunk_count else 0,
            'min_chunk_length': min(chunk_lengths) if chunk_lengths else 0,
            'max_chunk_length': max(chunk_lengths) if chunk_lengths else 0,
            'length_unit':      'tokens' if self._counter is not char_counter else 'chars',
        }

    # ── Private helpers ──────────────────────────────────────────────────

    def _assemble(self, ranked_chunks: List[Tuple], budget: int) -> Tuple[str, int]:
        """
      Greedy assembly with a *final* length check.

        Returns (context_string, number_of_included_chunks).
        The returned string is guaranteed to be within budget.
        """
        tmpl = self._template
        sep = self.config.separator
        parts: List[str] = []

        if tmpl.header:
            parts.append(tmpl.header)
        if tmpl.footer:
            footer_placeholder = True
        else:
            footer_placeholder = False

        included = 0
        for i, (chunk, score) in enumerate(ranked_chunks):
            chunk_text = self._format_chunk(chunk, score)

            candidate_parts = parts + [chunk_text]
            if footer_placeholder:
                candidate_parts.append(tmpl.footer)

            #   Measure the *complete* candidate string before accepting.
            candidate = sep.join(candidate_parts)
            if self._counter(candidate) > budget:
                if included == 0:
                    # Must include at least one chunk – compress it to fit.
                    compressed = self._compressor.compress(
                        chunk_text,
                        budget - self._counter(sep.join(
                            ([tmpl.header] if tmpl.header else [])
                            + ([""] if footer_placeholder else [])
                        )),
                        self._counter,
                        sep,
                    )
                    parts.append(compressed)
                    included += 1
                break

            # Accepted – update parts without footer, we add it at the end.
            if footer_placeholder and parts and parts[-1] == tmpl.footer:
                parts.pop()
            parts.append(chunk_text)
            included += 1

        if footer_placeholder:
            parts.append(tmpl.footer)

        context = sep.join(parts)

        #   Final safety clamp.
        if self._counter(context) > budget:
            context = self._compressor.compress(context, budget, self._counter, sep)

        return context, included

    def _format_chunk(self, chunk, score: float) -> str:
        """Format a single chunk using the active template."""
        tmpl = self._template
        fmt = tmpl.chunk_with_score if self.config.include_scores else tmpl.chunk_format

        text = fmt.format(doc_id=chunk.doc_id, text=chunk.text.strip(), score=score)

        if (
            self.config.include_metadata
            and hasattr(chunk, 'metadata')
            and chunk.metadata
        ):
            meta = " | ".join(f"{k}: {v}" for k, v in chunk.metadata.items())
            text = f"{text}\n[{meta}]"

        return text

    def _build_empty_context(self) -> str:
        tmpl = self._template
        msg = (
            "not available"
            if self.config.template == 'arabic'
            else "No information available."
        )
        return self.config.separator.join(filter(None, [tmpl.header, msg, tmpl.footer]))