
from typing import List
from abc import ABC, abstractmethod
from typing import List, Tuple, Optional
from .context_config import ContextConfig as config




class DeduplicationStrategy(ABC):
    """Strategy for removing duplicate chunks."""

    @abstractmethod
    def deduplicate(self, chunks: List[Tuple]) -> List[Tuple]:
        ...


class RankingStrategy(ABC):
    """Strategy for ranking / sorting chunks."""

    @abstractmethod
    def rank(self, chunks: List[Tuple], max_chunks: Optional[int]) -> List[Tuple]:
        ...


class CompressionStrategy(ABC):
    """Strategy for compressing an already-built context string."""

    @abstractmethod
    def compress(self, context: str, target: int,
                 counter: config.LengthCounter, separator: str) -> str:
        ...


class BudgetAllocationStrategy(ABC):
    """Strategy for distributing a global budget across multiple queries."""

    @abstractmethod
    def allocate(self, total_budget: int, n_queries: int) -> List[int]:
        ...
