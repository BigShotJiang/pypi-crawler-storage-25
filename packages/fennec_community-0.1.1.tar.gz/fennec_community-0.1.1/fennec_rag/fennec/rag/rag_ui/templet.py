from .enum import constants


def _print_banner(title: str, port: int) -> None:
    sep = "=" * 55
    print(f"\n{sep}\n  🤖  {title}\n  🌐  http://localhost:{port}\n  ⏹   CTRL+C to stop\n{sep}\n")


def _build_html(title: str, description: str, theme: str) -> str:
    """
    بناء صفحة HTML الكاملة.

    Args:
        title       : عنوان الصفحة
        description : وصف الشاشة الترحيبية
        theme       : "dark" | "light"

    Returns:
        str: HTML كامل
    """
    d = theme == "dark"
    v = {
        "bg_base":      "#0d0f14" if d else "#f4f4f0",
        "bg_sidebar":   "#111318" if d else "#eae9e3",
        "bg_card":      "#181b22" if d else "#ffffff",
        "bg_input":     "#1e2129" if d else "#fafaf8",
        "bg_hover":     "#1e222c" if d else "#e0ded8",
        "bg_active":    "#252a36" if d else "#d5d3cc",
        "border":       "#2a2f3e" if d else "#d8d6cf",
        "border_light": "#1f2330" if d else "#e8e6df",
        "text1":        "#e8eaf2" if d else "#1a1a1a",
        "text2":        "#8b90a4" if d else "#6b6b6b",
        "text3":        "#555a6e" if d else "#a0a0a0",
        "accent_glow":  "rgba(79,142,247,0.15)" if d else "rgba(79,142,247,0.10)",
        "user_bg":      "#1a2540" if d else "#ebf2ff",
        "user_border":  "#2e4a8a" if d else "#b8d0f5",
        "bot_bg":       "#181b22" if d else "#ffffff",
        "shadow":       "0 4px 24px rgba(0,0,0,0.4)" if d else "0 4px 24px rgba(0,0,0,0.08)",
        "shadow_sm":    "0 2px 8px rgba(0,0,0,0.3)" if d else "0 2px 8px rgba(0,0,0,0.06)",
        "is_dark":      "true" if d else "false",
    }

    css = f"""
:root {{
  --bg-base:{v['bg_base']};--bg-sidebar:{v['bg_sidebar']};--bg-card:{v['bg_card']};
  --bg-input:{v['bg_input']};--bg-hover:{v['bg_hover']};--bg-active:{v['bg_active']};
  --border:{v['border']};--border-light:{v['border_light']};
  --text-1:{v['text1']};--text-2:{v['text2']};--text-3:{v['text3']};
  --accent:#4f8ef7;--accent-2:#7c3aed;--accent-glow:{v['accent_glow']};
  --user-bg:{v['user_bg']};--user-border:{v['user_border']};--bot-bg:{v['bot_bg']};
  --success:#22c55e;--warning:#f59e0b;--danger:#ef4444;
  --radius:14px;--radius-sm:8px;--sidebar-w:280px;
  --font-main:'IBM Plex Sans Arabic',sans-serif;--font-mono:'JetBrains Mono',monospace;
  --shadow:{v['shadow']};--shadow-sm:{v['shadow_sm']};--transition:0.18s ease;
}}
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
html,body{{height:100%;font-family:var(--font-main);background:var(--bg-base);color:var(--text-1);font-size:15px;line-height:1.6;-webkit-font-smoothing:antialiased}}
.app{{display:flex;height:100vh;overflow:hidden}}

/* ── Sidebar ── */
.sidebar{{width:var(--sidebar-w);background:var(--bg-sidebar);border-left:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0;transition:transform var(--transition);z-index:10}}
.sidebar-header{{padding:20px 16px 12px;border-bottom:1px solid var(--border)}}
.brand{{display:flex;align-items:center;gap:10px;margin-bottom:12px}}
.brand-icon{{width:36px;height:36px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 0 20px var(--accent-glow)}}
.brand-name{{font-size:15px;font-weight:600;color:var(--text-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}}
.btn-new-chat{{width:100%;padding:10px 14px;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;border:none;border-radius:var(--radius-sm);font-family:var(--font-main);font-size:14px;font-weight:500;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:opacity var(--transition),transform var(--transition)}}
.btn-new-chat:hover{{opacity:.9;transform:translateY(-1px)}}

/* ── Search box ── */
.search-box{{margin:10px 16px 4px;display:flex;align-items:center;gap:7px;background:var(--bg-input);border:1px solid var(--border);border-radius:var(--radius-sm);padding:7px 10px;transition:border-color var(--transition)}}
.search-box:focus-within{{border-color:var(--accent)}}
.search-box input{{flex:1;background:none;border:none;outline:none;font-family:var(--font-main);font-size:13px;color:var(--text-1)}}
.search-box input::placeholder{{color:var(--text-3)}}
.search-icon{{color:var(--text-3);font-size:13px;flex-shrink:0}}

.sidebar-section-label{{padding:10px 16px 5px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--text-3)}}
.sessions-list{{flex:1;overflow-y:auto;padding:4px 8px;scrollbar-width:thin;scrollbar-color:var(--border) transparent}}
.session-item{{padding:10px;border-radius:var(--radius-sm);cursor:pointer;transition:background var(--transition);display:flex;align-items:center;gap:8px;margin-bottom:2px;position:relative}}
.session-item:hover{{background:var(--bg-hover)}}.session-item.active{{background:var(--bg-active)}}
.session-icon{{font-size:14px;flex-shrink:0;color:var(--text-2)}}
.session-info{{flex:1;min-width:0}}
.session-title{{font-size:13px;color:var(--text-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}}
.session-meta{{font-size:11px;color:var(--text-3);margin-top:1px}}
.session-actions{{display:flex;gap:2px;opacity:0;transition:opacity var(--transition);flex-shrink:0}}
.session-item:hover .session-actions{{opacity:1}}
.session-action-btn{{background:none;border:none;color:var(--text-3);cursor:pointer;font-size:13px;padding:3px 5px;border-radius:4px;transition:color var(--transition),background var(--transition)}}
.session-action-btn:hover{{color:var(--text-1);background:var(--bg-hover)}}
.session-action-btn.del:hover{{color:var(--danger)}}
.pin-badge{{font-size:10px;margin-right:2px}}

/* ── Docs section ── */
.docs-section{{border-top:1px solid var(--border);padding:12px 8px}}
.docs-header{{display:flex;align-items:center;justify-content:space-between;padding:0 8px 8px}}
.docs-title{{font-size:12px;font-weight:600;color:var(--text-2);text-transform:uppercase;letter-spacing:.06em}}
.btn-upload-mini{{background:none;border:1px solid var(--border);border-radius:6px;padding:4px 8px;font-size:11px;color:var(--accent);cursor:pointer;transition:background var(--transition),border-color var(--transition);font-family:var(--font-main)}}
.btn-upload-mini:hover{{background:var(--accent-glow);border-color:var(--accent)}}
.docs-list{{max-height:120px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--border) transparent}}
.doc-item{{display:flex;align-items:center;gap:6px;padding:5px 8px;border-radius:6px;font-size:12px;color:var(--text-2);transition:background var(--transition)}}
.doc-item:hover{{background:var(--bg-hover)}}.doc-name{{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}}
.doc-del-btn{{background:none;border:none;color:var(--text-3);cursor:pointer;font-size:13px;padding:2px 4px;border-radius:4px;opacity:0;transition:opacity var(--transition),color var(--transition);flex-shrink:0}}
.doc-item:hover .doc-del-btn{{opacity:1}}.doc-del-btn:hover{{color:var(--danger)}}
.doc-empty{{font-size:12px;color:var(--text-3);text-align:center;padding:8px;font-style:italic}}

/* ── Main area ── */
.main{{flex:1;display:flex;flex-direction:column;overflow:hidden;background:var(--bg-base)}}
.topbar{{padding:14px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;background:var(--bg-base);flex-shrink:0}}
.topbar-title{{font-size:15px;font-weight:600;color:var(--text-1);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}}
.topbar-title:hover{{color:var(--accent)}}
.topbar-actions{{display:flex;gap:8px}}
.btn-icon{{width:34px;height:34px;border-radius:var(--radius-sm);border:1px solid var(--border);background:none;color:var(--text-2);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:15px;transition:background var(--transition),color var(--transition),border-color var(--transition)}}
.btn-icon:hover{{background:var(--bg-hover);color:var(--text-1);border-color:var(--accent)}}
.status-badge{{display:flex;align-items:center;gap:5px;font-size:12px;color:var(--text-3);padding:4px 10px;border-radius:20px;border:1px solid var(--border-light);background:var(--bg-card)}}
.status-dot{{width:6px;height:6px;border-radius:50%;background:var(--success);box-shadow:0 0 6px var(--success);animation:pulse 2s infinite}}
@keyframes pulse{{0%,100%{{opacity:1}}50%{{opacity:.4}}}}

/* ── Messages ── */
.messages-area{{flex:1;overflow-y:auto;padding:28px 0;scrollbar-width:thin;scrollbar-color:var(--border) transparent}}
.welcome{{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center;padding:40px 24px;animation:fadeInUp .5s ease}}
.welcome-icon{{width:72px;height:72px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:20px;box-shadow:0 8px 32px var(--accent-glow);animation:float 3s ease-in-out infinite}}
@keyframes float{{0%,100%{{transform:translateY(0)}}50%{{transform:translateY(-8px)}}}}
.welcome-title{{font-size:26px;font-weight:600;color:var(--text-1);margin-bottom:10px}}
.welcome-desc{{font-size:15px;color:var(--text-2);max-width:420px;line-height:1.7;margin-bottom:32px}}
.suggestions{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;width:100%;max-width:640px}}
.suggestion-card{{padding:14px 16px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;transition:border-color var(--transition),background var(--transition),transform var(--transition);text-align:right}}
.suggestion-card:hover{{border-color:var(--accent);background:var(--bg-hover);transform:translateY(-2px)}}
.suggestion-icon{{font-size:18px;margin-bottom:6px}}.suggestion-text{{font-size:13px;color:var(--text-2);font-weight:500}}
.message-wrapper{{display:flex;padding:6px 24px;gap:12px;animation:fadeInUp .25s ease;max-width:900px;margin:0 auto;width:100%}}
@keyframes fadeInUp{{from{{opacity:0;transform:translateY(10px)}}to{{opacity:1;transform:translateY(0)}}}}
.message-wrapper.user{{flex-direction:row-reverse}}
.avatar{{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;margin-top:2px}}
.avatar.user{{background:linear-gradient(135deg,var(--accent),var(--accent-2));box-shadow:0 2px 10px var(--accent-glow)}}
.avatar.assistant{{background:var(--bg-card);border:1px solid var(--border)}}
.bubble{{max-width:72%;padding:13px 17px;border-radius:var(--radius);line-height:1.7;font-size:14.5px;position:relative;word-break:break-word}}
.bubble.user{{background:var(--user-bg);border:1px solid var(--user-border);color:var(--text-1);border-radius:var(--radius) 4px var(--radius) var(--radius)}}
.bubble.assistant{{background:var(--bot-bg);border:1px solid var(--border);color:var(--text-1);border-radius:4px var(--radius) var(--radius) var(--radius);box-shadow:var(--shadow-sm)}}
.bubble-footer{{display:flex;align-items:center;gap:8px;margin-top:8px;flex-wrap:wrap}}
.latency-badge{{font-size:11px;font-family:var(--font-mono);color:var(--text-3);background:var(--bg-hover);padding:2px 7px;border-radius:4px;border:1px solid var(--border-light)}}
.source-chip{{font-size:11px;color:var(--accent);background:var(--accent-glow);border:1px solid rgba(79,142,247,.2);padding:2px 8px;border-radius:20px;font-weight:500}}
.copy-btn{{background:none;border:none;color:var(--text-3);cursor:pointer;font-size:13px;padding:2px 6px;border-radius:4px;transition:color var(--transition),background var(--transition);margin-right:auto}}
.copy-btn:hover{{color:var(--accent);background:var(--accent-glow)}}

/* ── Rating buttons ── */
.rating-group{{display:flex;gap:4px;align-items:center}}
.rate-btn{{background:none;border:1px solid var(--border-light);border-radius:6px;padding:2px 7px;font-size:13px;cursor:pointer;transition:background var(--transition),border-color var(--transition),transform var(--transition);color:var(--text-3)}}
.rate-btn:hover{{transform:scale(1.15)}}
.rate-btn.active-up{{border-color:var(--success);color:var(--success);background:rgba(34,197,94,.1)}}
.rate-btn.active-down{{border-color:var(--danger);color:var(--danger);background:rgba(239,68,68,.1)}}

/* ── Typing / streaming ── */
.typing-bubble{{background:var(--bot-bg);border:1px solid var(--border);border-radius:4px var(--radius) var(--radius) var(--radius);padding:14px 18px;box-shadow:var(--shadow-sm)}}
.typing-dots{{display:flex;gap:5px;align-items:center;height:16px}}
.typing-dots span{{width:7px;height:7px;background:var(--text-3);border-radius:50%;animation:bounce 1.2s infinite ease-in-out}}
.typing-dots span:nth-child(2){{animation-delay:.2s}}.typing-dots span:nth-child(3){{animation-delay:.4s}}
@keyframes bounce{{0%,80%,100%{{transform:scale(.7);opacity:.5}}40%{{transform:scale(1);opacity:1}}}}
.cursor{{display:inline-block;width:2px;height:1em;background:var(--accent);margin-right:1px;vertical-align:text-bottom;animation:blink .7s step-end infinite}}
@keyframes blink{{0%,100%{{opacity:1}}50%{{opacity:0}}}}

/* ── Stop button ── */
.stop-btn{{display:none;align-items:center;gap:6px;padding:7px 16px;background:var(--bg-card);border:1px solid var(--danger);border-radius:var(--radius-sm);color:var(--danger);font-family:var(--font-main);font-size:13px;cursor:pointer;transition:background var(--transition);margin:0 auto}}
.stop-btn:hover{{background:rgba(239,68,68,.1)}}
.stop-btn.visible{{display:flex}}

/* ── Input area ── */
.input-area{{padding:16px 24px 20px;border-top:1px solid var(--border);background:var(--bg-base);flex-shrink:0}}
.input-wrapper{{max-width:860px;margin:0 auto;display:flex;flex-direction:column;gap:8px}}
.input-box{{display:flex;align-items:flex-end;gap:10px;background:var(--bg-input);border:1.5px solid var(--border);border-radius:var(--radius);padding:10px 14px;transition:border-color var(--transition),box-shadow var(--transition)}}
.input-box:focus-within{{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-glow)}}
#query-input{{flex:1;background:none;border:none;outline:none;color:var(--text-1);font-family:var(--font-main);font-size:14.5px;line-height:1.6;resize:none;max-height:180px;min-height:24px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--border) transparent}}
#query-input::placeholder{{color:var(--text-3)}}
.send-btn{{width:38px;height:38px;border-radius:10px;border:none;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:17px;transition:opacity var(--transition),transform var(--transition);flex-shrink:0;box-shadow:0 2px 12px var(--accent-glow)}}
.send-btn:hover:not(:disabled){{opacity:.88;transform:scale(1.05)}}.send-btn:disabled{{opacity:.35;cursor:not-allowed;transform:none}}
.input-actions{{display:flex;align-items:center;gap:8px;flex-wrap:wrap}}
.attach-btn{{display:flex;align-items:center;gap:5px;padding:6px 12px;background:none;border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-2);font-size:12px;font-family:var(--font-main);cursor:pointer;transition:background var(--transition),border-color var(--transition),color var(--transition)}}
.attach-btn:hover{{background:var(--accent-glow);border-color:var(--accent);color:var(--accent)}}
.char-counter{{font-size:11px;color:var(--text-3);font-family:var(--font-mono);margin-right:auto}}

/* ── Toast ── */
.upload-toast{{position:fixed;bottom:90px;right:50%;transform:translateX(50%);background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:12px 18px;font-size:13px;color:var(--text-1);box-shadow:var(--shadow);z-index:100;display:flex;align-items:center;gap:10px;animation:slideUp .25s ease;max-width:400px}}
@keyframes slideUp{{from{{opacity:0;transform:translateX(50%) translateY(16px)}}to{{opacity:1;transform:translateX(50%) translateY(0)}}}}

/* ── Upload modal ── */
.upload-overlay{{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:200;align-items:center;justify-content:center;backdrop-filter:blur(4px)}}
.upload-overlay.show{{display:flex}}
.upload-modal{{background:var(--bg-card);border:1px solid var(--border);border-radius:20px;padding:32px;width:440px;max-width:90vw;box-shadow:var(--shadow);animation:popIn .2s ease}}
@keyframes popIn{{from{{opacity:0;transform:scale(.93)}}to{{opacity:1;transform:scale(1)}}}}
.modal-title{{font-size:17px;font-weight:600;margin-bottom:6px}}.modal-desc{{font-size:13px;color:var(--text-2);margin-bottom:20px}}
.drop-zone{{border:2px dashed var(--border);border-radius:var(--radius);padding:32px 20px;text-align:center;cursor:pointer;transition:border-color var(--transition),background var(--transition)}}
.drop-zone:hover,.drop-zone.dragover{{border-color:var(--accent);background:var(--accent-glow)}}
.drop-icon{{font-size:36px;margin-bottom:10px}}.drop-text{{font-size:14px;color:var(--text-2);margin-bottom:6px}}.drop-hint{{font-size:12px;color:var(--text-3)}}
.modal-actions{{display:flex;gap:10px;margin-top:20px;justify-content:flex-end}}
.btn-cancel{{padding:9px 18px;background:none;border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-2);font-family:var(--font-main);font-size:13px;cursor:pointer;transition:background var(--transition)}}
.btn-cancel:hover{{background:var(--bg-hover)}}
.btn-confirm{{padding:9px 18px;background:linear-gradient(135deg,var(--accent),var(--accent-2));border:none;border-radius:var(--radius-sm);color:#fff;font-family:var(--font-main);font-size:13px;cursor:pointer;font-weight:500;transition:opacity var(--transition)}}
.btn-confirm:hover{{opacity:.88}}.btn-confirm:disabled{{opacity:.4;cursor:not-allowed}}
.progress-bar-wrap{{height:4px;background:var(--border);border-radius:2px;overflow:hidden;margin-top:14px;display:none}}
.progress-bar{{height:100%;background:var(--accent);border-radius:2px;transition:width .3s ease;width:0%}}

/* ── Rename modal ── */
.rename-overlay{{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:300;align-items:center;justify-content:center;backdrop-filter:blur(4px)}}
.rename-overlay.show{{display:flex}}
.rename-modal{{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:24px;width:380px;max-width:90vw;box-shadow:var(--shadow);animation:popIn .2s ease}}
.rename-modal h3{{font-size:16px;font-weight:600;margin-bottom:14px}}
.rename-modal input{{width:100%;background:var(--bg-input);border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:10px 12px;font-family:var(--font-main);font-size:14px;color:var(--text-1);outline:none;transition:border-color var(--transition)}}
.rename-modal input:focus{{border-color:var(--accent)}}

/* ── Export dropdown ── */
.export-menu{{position:absolute;top:100%;left:0;margin-top:4px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-sm);padding:4px;z-index:50;min-width:130px;box-shadow:var(--shadow-sm);animation:fadeInUp .15s ease;display:none}}
.export-menu.open{{display:block}}
.export-item{{padding:8px 12px;border-radius:6px;font-size:13px;cursor:pointer;color:var(--text-2);transition:background var(--transition),color var(--transition)}}
.export-item:hover{{background:var(--bg-hover);color:var(--text-1)}}
.export-wrap{{position:relative}}

/* ── Markdown in bubbles ── */
.bubble h1,.bubble h2,.bubble h3{{font-weight:600;margin:10px 0 6px;color:var(--text-1)}}
.bubble h1{{font-size:18px}}.bubble h2{{font-size:16px}}.bubble h3{{font-size:14px}}
.bubble ul,.bubble ol{{padding-right:20px;margin:6px 0}}
.bubble li{{margin-bottom:3px}}
.bubble blockquote{{border-right:3px solid var(--accent);padding:6px 12px;margin:8px 0;background:var(--bg-hover);border-radius:0 6px 6px 0;color:var(--text-2)}}
.bubble table{{width:100%;border-collapse:collapse;margin:8px 0;font-size:13px}}
.bubble th,.bubble td{{border:1px solid var(--border);padding:6px 10px;text-align:right}}
.bubble th{{background:var(--bg-hover);font-weight:600}}
.bubble a{{color:var(--accent);text-decoration:none}}.bubble a:hover{{text-decoration:underline}}
pre,code{{font-family:var(--font-mono);font-size:13px;background:var(--bg-sidebar);border:1px solid var(--border);border-radius:6px;padding:2px 6px}}
pre{{padding:12px 14px;overflow-x:auto;margin:8px 0;position:relative}}
pre code{{background:none;border:none;padding:0}}
.code-copy{{position:absolute;top:8px;left:8px;background:var(--bg-hover);border:1px solid var(--border);border-radius:5px;padding:2px 8px;font-size:11px;color:var(--text-3);cursor:pointer;font-family:var(--font-main);transition:color var(--transition)}}
.code-copy:hover{{color:var(--accent)}}

/* ── Mobile ── */
.menu-toggle{{display:none;background:none;border:none;color:var(--text-2);font-size:20px;cursor:pointer;padding:4px 8px}}
@media(max-width:640px){{.sidebar{{position:fixed;top:0;right:0;bottom:0;transform:translateX(100%);z-index:50}}.sidebar.open{{transform:translateX(0)}}.menu-toggle{{display:flex;align-items:center;justify-content:center}}.message-wrapper{{padding:6px 14px}}.bubble{{max-width:86%}}.input-area{{padding:12px 14px 16px}}.topbar{{padding:12px 14px}}}}
::-webkit-scrollbar{{width:5px}}::-webkit-scrollbar-track{{background:transparent}}::-webkit-scrollbar-thumb{{background:var(--border);border-radius:10px}}
"""

    return f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>{title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>{css}</style>
</head>
<body>
<div class="app">
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="brand">
        <div class="brand-icon">🤖</div>
        <span class="brand-name">{title}</span>
      </div>
      <button class="btn-new-chat" onclick="newSession()">✦ &nbsp; محادثة جديدة</button>
    </div>
    <div class="search-box">
      <span class="search-icon">🔍</span>
      <input id="session-search" placeholder="ابحث في المحادثات…" oninput="onSearchInput()" autocomplete="off"/>
    </div>
    <div class="sidebar-section-label">المحادثات</div>
    <div class="sessions-list" id="sessions-list"></div>
    <div class="docs-section">
      <div class="docs-header">
        <span class="docs-title">📎 المستندات</span>
        <button class="btn-upload-mini" onclick="openUpload()">+ رفع ملف</button>
      </div>
      <div class="docs-list" id="sidebar-docs"><div class="doc-empty">لا توجد مستندات</div></div>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
      <span class="topbar-title" id="chat-title" title="انقر مرتين للتعديل" ondblclick="openRename()">محادثة جديدة</span>
      <div class="topbar-actions">
        <div class="status-badge"><div class="status-dot"></div><span>متصل</span></div>
        <button class="btn-icon" title="تبديل الثيم" onclick="toggleTheme()">🌓</button>
        <button class="btn-icon" title="مسح الرسائل" onclick="clearChat()">🗑</button>
        <div class="export-wrap">
          <button class="btn-icon" title="تصدير" onclick="toggleExportMenu()">⬇</button>
          <div class="export-menu" id="export-menu">
            <div class="export-item" onclick="exportChat('txt')">📄 تصدير TXT</div>
            <div class="export-item" onclick="exportChat('json')">📦 تصدير JSON</div>
          </div>
        </div>
      </div>
    </div>

    <div class="messages-area" id="messages-area">
      <div class="welcome" id="welcome-screen">
        <div class="welcome-icon">🤖</div>
        <div class="welcome-title">{title}</div>
        <div class="welcome-desc">{description}</div>
        <div class="suggestions">
          <div class="suggestion-card" onclick="useSuggestion(this)"><div class="suggestion-icon">📋</div><div class="suggestion-text">لخّص المستندات المُضافة</div></div>
          <div class="suggestion-card" onclick="useSuggestion(this)"><div class="suggestion-icon">🔍</div><div class="suggestion-text">ما أهم النقاط في هذه المستندات؟</div></div>
          <div class="suggestion-card" onclick="useSuggestion(this)"><div class="suggestion-icon">💡</div><div class="suggestion-text">اشرح لي بالتفصيل...</div></div>
          <div class="suggestion-card" onclick="useSuggestion(this)"><div class="suggestion-icon">❓</div><div class="suggestion-text">أجب عن سؤالي بناءً على المستندات</div></div>
        </div>
      </div>
    </div>

    <div style="text-align:center;padding:0 0 6px">
      <button class="stop-btn" id="stop-btn" onclick="stopStream()">⏹ إيقاف الإجابة</button>
    </div>

    <div class="input-area">
      <div class="input-wrapper">
        <div class="input-box">
          <textarea id="query-input" placeholder="اكتب سؤالك… (Shift+Enter لسطر جديد)" rows="1"
            oninput="autoResize(this);updateCounter()" onkeydown="handleKey(event)"></textarea>
          <button class="send-btn" id="send-btn" onclick="sendMessage()" title="إرسال">➤</button>
        </div>
        <div class="input-actions">
          <button class="attach-btn" onclick="openUpload()">📎 &nbsp; إرفاق ملف</button>
          <span class="char-counter" id="char-counter">0 / {constants.MAX_QUERY_LENGTH.value}</span>
        </div>
      </div>
    </div>
  </main>
</div>

<!-- Upload Modal -->
<div class="upload-overlay" id="upload-overlay" onclick="closeUploadOnBg(event)">
  <div class="upload-modal">
    <div class="modal-title">📂 رفع مستند</div>
    <div class="modal-desc">أضف ملفاً لقاعدة المعرفة. الأنواع: TXT, PDF, DOCX, XLSX, MD, CSV, JSON, HTML</div>
    <div class="drop-zone" id="drop-zone" onclick="document.getElementById('file-input').click()"
         ondragover="onDragOver(event)" ondragleave="onDragLeave()" ondrop="onDrop(event)">
      <div class="drop-icon">📄</div>
      <div class="drop-text" id="drop-text">اسحب الملف هنا أو انقر للاختيار</div>
      <div class="drop-hint" id="drop-hint">الحجم الأقصى: {constants.MAX_FILE_SIZE_MB.value} ميجا</div>
    </div>
    <input type="file" id="file-input" style="display:none"
           accept=".txt,.pdf,.docx,.xlsx,.md,.csv,.json,.html" onchange="onFileSelect(event)">
    <div class="progress-bar-wrap" id="progress-wrap"><div class="progress-bar" id="progress-bar"></div></div>
    <div class="modal-actions">
      <button class="btn-cancel" onclick="closeUpload()">إلغاء</button>
      <button class="btn-confirm" id="upload-btn" onclick="doUpload()" disabled>رفع الملف</button>
    </div>
  </div>
</div>

<!-- Rename Modal -->
<div class="rename-overlay" id="rename-overlay" onclick="closeRenameOnBg(event)">
  <div class="rename-modal">
    <h3>✏️ إعادة تسمية المحادثة</h3>
    <input id="rename-input" placeholder="اكتب العنوان الجديد…" onkeydown="renameKey(event)" maxlength="60"/>
    <div class="modal-actions" style="margin-top:16px">
      <button class="btn-cancel" onclick="closeRename()">إلغاء</button>
      <button class="btn-confirm" onclick="doRename()">حفظ</button>
    </div>
  </div>
</div>

<script>
const MAX_LEN = {constants.MAX_QUERY_LENGTH.value};
let currentSessionId = null, isStreaming = false, selectedFile = null, currentStreamId = null;
let isDark = {v['is_dark']};

(async () => {{
  await loadSessions();
  if (!currentSessionId) {{
    const s = await apiPost('/api/session/new');
    currentSessionId = s.session_id;
    await loadSessions();
  }}
}})();

// ── Theme ────────────────────────────────────────────────────────────────────
function toggleTheme() {{
  isDark = !isDark;
  const root = document.documentElement;
  const t = isDark ? {{
    '--bg-base':'#0d0f14','--bg-sidebar':'#111318','--bg-card':'#181b22',
    '--bg-input':'#1e2129','--bg-hover':'#1e222c','--bg-active':'#252a36',
    '--border':'#2a2f3e','--border-light':'#1f2330',
    '--text-1':'#e8eaf2','--text-2':'#8b90a4','--text-3':'#555a6e',
    '--accent-glow':'rgba(79,142,247,0.15)',
    '--user-bg':'#1a2540','--user-border':'#2e4a8a','--bot-bg':'#181b22',
    '--shadow':'0 4px 24px rgba(0,0,0,0.4)','--shadow-sm':'0 2px 8px rgba(0,0,0,0.3)',
  }} : {{
    '--bg-base':'#f4f4f0','--bg-sidebar':'#eae9e3','--bg-card':'#ffffff',
    '--bg-input':'#fafaf8','--bg-hover':'#e0ded8','--bg-active':'#d5d3cc',
    '--border':'#d8d6cf','--border-light':'#e8e6df',
    '--text-1':'#1a1a1a','--text-2':'#6b6b6b','--text-3':'#a0a0a0',
    '--accent-glow':'rgba(79,142,247,0.10)',
    '--user-bg':'#ebf2ff','--user-border':'#b8d0f5','--bot-bg':'#ffffff',
    '--shadow':'0 4px 24px rgba(0,0,0,0.08)','--shadow-sm':'0 2px 8px rgba(0,0,0,0.06)',
  }};
  Object.entries(t).forEach(([k,v]) => root.style.setProperty(k, v));
}}

// ── Sessions ─────────────────────────────────────────────────────────────────
async function loadSessions(q='') {{
  const url = q ? `/api/sessions/search?q=${{encodeURIComponent(q)}}` : '/api/sessions';
  const sessions = await apiFetch(url);
  const list = document.getElementById('sessions-list');
  list.innerHTML = '';
  if (!sessions.length) {{
    list.innerHTML = '<div class="doc-empty">لا توجد محادثات</div>';
    return;
  }}
  sessions.forEach(s => {{
    const item = document.createElement('div');
    item.className = 'session-item' + (s.session_id === currentSessionId ? ' active' : '');
    item.dataset.id = s.session_id;
    const pin = s.is_pinned ? '<span class="pin-badge">📌</span>' : '';
    item.innerHTML = `
      <span class="session-icon">💬</span>
      <div class="session-info">
        <div class="session-title">${{pin}}${{escHtml(s.title)}}</div>
        <div class="session-meta">${{relativeTime(s.updated_at)}} · ${{s.message_count}} رسالة</div>
      </div>
      <div class="session-actions">
        <button class="session-action-btn" onclick="togglePin(event,'${{s.session_id}}',${{!s.is_pinned}})" title="${{s.is_pinned?'إلغاء التثبيت':'تثبيت'}}">📌</button>
        <button class="session-action-btn del" onclick="deleteSession(event,'${{s.session_id}}')" title="حذف">✕</button>
      </div>`;
    item.onclick = e => {{ if (!e.target.closest('.session-actions')) switchSession(s.session_id); }};
    list.appendChild(item);
  }});
}}

let searchTimer = null;
function onSearchInput() {{
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadSessions(document.getElementById('session-search').value), 280);
}}

async function newSession() {{
  const s = await apiPost('/api/session/new');
  currentSessionId = s.session_id;
  clearMessages(); showWelcome();
  document.getElementById('chat-title').textContent = 'محادثة جديدة';
  await loadSessions();
}}

async function switchSession(sid) {{
  currentSessionId = sid;
  const session = await apiFetch(`/api/session/${{sid}}`);
  clearMessages(); hideWelcome();
  session.messages.forEach(msg => {{
    if (msg.role === 'user') renderUser(msg.content);
    else if (msg.role === 'assistant') renderAssistant(msg.content, msg.sources, msg.latency_ms, msg.msg_id, msg.rating);
  }});
  document.getElementById('chat-title').textContent = session.title;
  updateSidebarDocs(session.documents);
  await loadSessions();
  scrollToBottom();
}}

async function deleteSession(e, sid) {{
  e.stopPropagation();
  if (!confirm('حذف هذه المحادثة؟')) return;
  await apiFetch(`/api/session/${{sid}}`, 'DELETE');
  if (currentSessionId === sid) {{ await newSession(); return; }}
  await loadSessions();
}}

async function togglePin(e, sid, pin) {{
  e.stopPropagation();
  await apiPost(`/api/session/${{sid}}/pin`, {{ pinned: pin }});
  await loadSessions();
}}

// ── Rename ───────────────────────────────────────────────────────────────────
function openRename() {{
  const inp = document.getElementById('rename-input');
  inp.value = document.getElementById('chat-title').textContent;
  document.getElementById('rename-overlay').classList.add('show');
  setTimeout(() => inp.focus(), 100);
}}
function closeRename() {{ document.getElementById('rename-overlay').classList.remove('show'); }}
function closeRenameOnBg(e) {{ if (e.target === document.getElementById('rename-overlay')) closeRename(); }}
function renameKey(e) {{ if (e.key === 'Enter') doRename(); if (e.key === 'Escape') closeRename(); }}
async function doRename() {{
  const title = document.getElementById('rename-input').value.trim();
  if (!title || !currentSessionId) return;
  await apiPost(`/api/session/${{currentSessionId}}/rename`, {{ title }});
  document.getElementById('chat-title').textContent = title;
  closeRename();
  await loadSessions();
}}

// ── Export ───────────────────────────────────────────────────────────────────
function toggleExportMenu() {{
  document.getElementById('export-menu').classList.toggle('open');
}}
document.addEventListener('click', e => {{
  if (!e.target.closest('.export-wrap'))
    document.getElementById('export-menu').classList.remove('open');
}});
function exportChat(fmt) {{
  if (!currentSessionId) return;
  window.location.href = `/api/session/${{currentSessionId}}/export?format=${{fmt}}`;
  document.getElementById('export-menu').classList.remove('open');
}}

// ── Send / Stream ─────────────────────────────────────────────────────────────
async function sendMessage() {{
  const inp = document.getElementById('query-input');
  const query = inp.value.trim();
  if (!query || isStreaming) return;
  if (query.length > MAX_LEN) {{ showToast('⚠️ الرسالة طويلة جدًا'); return; }}
  if (!currentSessionId) {{ const s = await apiPost('/api/session/new'); currentSessionId = s.session_id; }}
  inp.value = ''; autoResize(inp); updateCounter();
  hideWelcome(); renderUser(query);
  setSending(true);
  showStopBtn(true);
  const tid = 'typing-' + Date.now();
  appendTyping(tid); scrollToBottom();
  try {{ await streamResponse(query, tid); }}
  catch (err) {{ removeTyping(tid); renderAssistant('❌ خطأ: ' + err.message); }}
  setSending(false);
  showStopBtn(false);
  const upd = await apiFetch(`/api/session/${{currentSessionId}}`);
  document.getElementById('chat-title').textContent = upd.title;
  await loadSessions();
}}

async function streamResponse(query, typingId) {{
  isStreaming = true;
  currentStreamId = 'sid-' + Date.now();
  let fullText = '', bubbleEl = null;
  const resp = await fetch('/api/chat/stream', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{ session_id: currentSessionId, query, stream_id: currentStreamId }}),
  }});
  if (!resp.ok) throw new Error('Server error: ' + resp.status);
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  removeTyping(typingId);
  while (true) {{
    const {{ done, value }} = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, {{ stream: true }});
    const lines = buffer.split('\\n');
    buffer = lines.pop();
    for (const line of lines) {{
      if (!line.startsWith('data: ')) continue;
      const payload = JSON.parse(line.slice(6));
      if (!payload.done) {{
        fullText += payload.token;
        if (!bubbleEl) bubbleEl = createStreamingBubble();
        updateStreamingBubble(bubbleEl, fullText);
        scrollToBottom();
      }} else {{
        if (bubbleEl) finalizeStreamingBubble(bubbleEl, fullText, payload.latency_ms, payload.msg_id);
      }}
    }}
  }}
  isStreaming = false;
  currentStreamId = null;
}}

async function stopStream() {{
  if (!currentStreamId) return;
  await apiPost('/api/chat/stop', {{ stream_id: currentStreamId }});
  isStreaming = false;
  currentStreamId = null;
  showStopBtn(false);
  setSending(false);
}}

function showStopBtn(show) {{
  document.getElementById('stop-btn').classList.toggle('visible', show);
}}

// ── Render helpers ────────────────────────────────────────────────────────────
function renderUser(text) {{
  const a = document.getElementById('messages-area');
  const w = document.createElement('div');
  w.className = 'message-wrapper user';
  w.innerHTML = `<div class="avatar user">👤</div><div class="bubble user">${{escHtml(text).replace(/\\n/g,'<br>')}}</div>`;
  a.appendChild(w);
}}

function renderAssistant(text, sources=[], latency_ms=0, msgId='', rating=0) {{
  const a  = document.getElementById('messages-area');
  const w  = document.createElement('div');
  w.className = 'message-wrapper assistant';
  const mid = msgId || ('msg-' + Date.now());
  const sh  = (sources && sources.length) ? sources.map(s => `<span class="source-chip">📄 ${{escHtml(s)}}</span>`).join('') : '';
  const lh  = latency_ms > 0 ? `<span class="latency-badge">${{latency_ms.toFixed(0)}}ms</span>` : '';
  const rg  = buildRatingHtml(mid, rating);
  w.innerHTML = `<div class="avatar assistant">🤖</div>
    <div class="bubble assistant" id="${{mid}}">${{formatMarkdown(text)}}
      <div class="bubble-footer">
        <button class="copy-btn" onclick="copyMsg('${{mid}}')">📋 نسخ</button>
        ${{lh}}${{rg}}${{sh}}
      </div>
    </div>`;
  a.appendChild(w);
  addCodeCopyButtons(w);
  scrollToBottom();
}}

function buildRatingHtml(msgId, rating) {{
  const upCls   = rating === 1  ? ' active-up'   : '';
  const downCls = rating === -1 ? ' active-down'  : '';
  return `<div class="rating-group">
    <button class="rate-btn${{upCls}}" onclick="rateMsg('${{msgId}}',1)" title="إجابة جيدة">👍</button>
    <button class="rate-btn${{downCls}}" onclick="rateMsg('${{msgId}}',-1)" title="إجابة سيئة">👎</button>
  </div>`;
}}

async function rateMsg(msgId, rating) {{
  if (!currentSessionId) return;
  await apiPost(`/api/session/${{currentSessionId}}/rate`, {{ msg_id: msgId, rating }});
  // تحديث مرئي للزرّين
  const bubble = document.getElementById(msgId);
  if (!bubble) return;
  bubble.querySelectorAll('.rate-btn').forEach(btn => {{
    btn.classList.remove('active-up','active-down');
  }});
  const btns = bubble.querySelectorAll('.rate-btn');
  if (rating === 1  && btns[0]) btns[0].classList.add('active-up');
  if (rating === -1 && btns[1]) btns[1].classList.add('active-down');
}}

function createStreamingBubble() {{
  const a = document.getElementById('messages-area');
  const w = document.createElement('div');
  w.className = 'message-wrapper assistant';
  w.id = 'streaming-wrapper';
  const b = document.createElement('div');
  b.className = 'bubble assistant';
  b.id = 'streaming-bubble';
  b.innerHTML = '<span class="cursor"></span>';
  w.innerHTML = '<div class="avatar assistant">🤖</div>';
  w.appendChild(b);
  a.appendChild(w);
  return b;
}}

function updateStreamingBubble(b, t) {{
  b.innerHTML = formatMarkdown(t) + '<span class="cursor"></span>';
}}

function finalizeStreamingBubble(b, t, ms, msgId) {{
  const lh  = ms > 0 ? `<span class="latency-badge">${{ms.toFixed(0)}}ms</span>` : '';
  const mid  = msgId || ('msg-' + Date.now());
  b.id = mid;
  b.innerHTML = `${{formatMarkdown(t)}}
    <div class="bubble-footer">
      <button class="copy-btn" onclick="copyMsg('${{mid}}')">📋 نسخ</button>
      ${{lh}}
      ${{buildRatingHtml(mid, 0)}}
    </div>`;
  addCodeCopyButtons(b);
}}

function addCodeCopyButtons(container) {{
  container.querySelectorAll('pre').forEach(pre => {{
    if (pre.querySelector('.code-copy')) return;
    const btn = document.createElement('button');
    btn.className = 'code-copy';
    btn.textContent = 'نسخ';
    btn.onclick = () => {{
      navigator.clipboard.writeText(pre.querySelector('code')?.innerText || pre.innerText);
      btn.textContent = '✅';
      setTimeout(() => btn.textContent = 'نسخ', 1500);
    }};
    pre.style.position = 'relative';
    pre.appendChild(btn);
  }});
}}

function appendTyping(id) {{
  const a = document.getElementById('messages-area');
  const w = document.createElement('div');
  w.className = 'message-wrapper assistant';
  w.id = id;
  w.innerHTML = '<div class="avatar assistant">🤖</div><div class="typing-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>';
  a.appendChild(w);
}}
function removeTyping(id) {{ const el = document.getElementById(id); if (el) el.remove(); }}

// ── Upload ────────────────────────────────────────────────────────────────────
function openUpload() {{ document.getElementById('upload-overlay').classList.add('show'); }}
function closeUpload() {{
  document.getElementById('upload-overlay').classList.remove('show');
  selectedFile = null;
  document.getElementById('drop-text').textContent = 'اسحب الملف هنا أو انقر للاختيار';
  document.getElementById('drop-hint').textContent = 'الحجم الأقصى: {constants.MAX_FILE_SIZE_MB.value} ميجا';
  document.getElementById('upload-btn').disabled = true;
  document.getElementById('drop-zone').classList.remove('dragover');
  document.getElementById('progress-wrap').style.display = 'none';
  document.getElementById('progress-bar').style.width = '0%';
  document.getElementById('file-input').value = '';
}}
function closeUploadOnBg(e) {{ if (e.target === document.getElementById('upload-overlay')) closeUpload(); }}
function onDragOver(e) {{ e.preventDefault(); document.getElementById('drop-zone').classList.add('dragover'); }}
function onDragLeave() {{ document.getElementById('drop-zone').classList.remove('dragover'); }}
function onDrop(e) {{ e.preventDefault(); document.getElementById('drop-zone').classList.remove('dragover'); if (e.dataTransfer.files[0]) setSelectedFile(e.dataTransfer.files[0]); }}
function onFileSelect(e) {{ if (e.target.files[0]) setSelectedFile(e.target.files[0]); }}
function setSelectedFile(file) {{
  selectedFile = file;
  document.getElementById('drop-text').textContent = '📄 ' + file.name;
  document.getElementById('drop-hint').textContent = 'الحجم: ' + (file.size / 1024).toFixed(1) + ' كيلوبايت';
  document.getElementById('upload-btn').disabled = false;
}}
async function doUpload() {{
  if (!selectedFile) return;
  const btn  = document.getElementById('upload-btn');
  btn.disabled = true; btn.textContent = 'جاري الرفع…';
  const wrap = document.getElementById('progress-wrap');
  const bar  = document.getElementById('progress-bar');
  wrap.style.display = 'block';

  // ── مرحلة 1: رفع الملف (0 → 60%) بسرعة ──────────────────────────────────
  let prog = 0;
  const uploadInterval = setInterval(() => {{
    prog = Math.min(prog + 6, 60);
    bar.style.width = prog + '%';
  }}, 80);

  const fd = new FormData();
  fd.append('file', selectedFile);
  fd.append('session_id', currentSessionId || '');

  let res;
  try {{
    res = await fetch('/api/upload', {{ method: 'POST', body: fd }});
  }} catch (networkErr) {{
    clearInterval(uploadInterval);
    bar.style.width = '100%'; bar.style.background = 'var(--danger)';
    btn.textContent = 'تعذّر الاتصال بالسيرفر';
    setTimeout(closeUpload, 1800);
    return;
  }}

  // ── مرحلة 2: السيرفر استلم الملف — ننتظر المعالجة (60 → 90%) ببطء ──────
  clearInterval(uploadInterval);
  prog = 60;
  bar.style.width = prog + '%';
  btn.textContent = 'جاري المعالجة…';

  // تباطؤ تدريجي — يقترب من 90% لكن لا يصلها تلقائيًا (easing effect)
  const processInterval = setInterval(() => {{
    prog += (90 - prog) * 0.06;
    bar.style.width = prog.toFixed(1) + '%';
  }}, 200);

  let data;
  try {{
    data = await res.json();
  }} catch (parseErr) {{
    clearInterval(processInterval);
    bar.style.width = '100%'; bar.style.background = 'var(--danger)';
    btn.textContent = 'استجابة غير متوقعة من السيرفر';
    setTimeout(closeUpload, 1800);
    return;
  }}

  // ── مرحلة 3: الرد وصل — نُكمل لـ 100% ──────────────────────────────────
  clearInterval(processInterval);
  bar.style.width = '100%';

  // فحص HTTP status + body error معًا
  const isError = !res.ok || data.error || (data.status && data.status.startsWith('❌'));
  if (isError) {{
    bar.style.background = 'var(--danger)';
    btn.textContent = 'فشل الرفع';
    setTimeout(() => {{
      closeUpload();
      showToast('❌ ' + (data.error || data.status || 'حدث خطأ أثناء الرفع'));
    }}, 600);
    return;
  }}

  setTimeout(() => {{
    closeUpload();
    showToast(data.status || '✅ تم رفع الملف');
    if (data.session_id) currentSessionId = data.session_id;
    if (data.documents)  updateSidebarDocs(data.documents);
  }}, 400);
}}

// ── Misc UI ───────────────────────────────────────────────────────────────────
function handleKey(e) {{ if (e.key === 'Enter' && !e.shiftKey) {{ e.preventDefault(); sendMessage(); }} }}
function autoResize(el) {{ el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 180) + 'px'; }}
function updateCounter() {{
  const n = document.getElementById('query-input').value.length;
  const c = document.getElementById('char-counter');
  c.textContent = n + ' / ' + MAX_LEN;
  c.style.color = n > MAX_LEN * .9 ? 'var(--warning)' : 'var(--text-3)';
}}
function setSending(s) {{ document.getElementById('send-btn').disabled = s; document.getElementById('query-input').disabled = s; }}
function scrollToBottom() {{ const a = document.getElementById('messages-area'); a.scrollTop = a.scrollHeight; }}
function clearMessages() {{ document.getElementById('messages-area').querySelectorAll('.message-wrapper').forEach(el => el.remove()); }}
function showWelcome() {{ const w = document.getElementById('welcome-screen'); if (w) w.style.display = 'flex'; }}
function hideWelcome() {{ const w = document.getElementById('welcome-screen'); if (w) w.style.display = 'none'; }}
async function clearChat() {{
  if (!currentSessionId || !confirm('مسح جميع الرسائل؟')) return;
  await apiPost(`/api/session/${{currentSessionId}}/clear`);
  clearMessages(); showWelcome();
  document.getElementById('chat-title').textContent = 'محادثة جديدة';
  await loadSessions();
}}
function copyMsg(id) {{
  const el = document.getElementById(id);
  if (!el) return;
  navigator.clipboard.writeText((el.innerText || '').replace(/^📋 نسخ/,'').trim()).then(() => showToast('✅ تم النسخ'));
}}
function useSuggestion(card) {{
  const inp = document.getElementById('query-input');
  inp.value = card.querySelector('.suggestion-text').textContent;
  autoResize(inp); updateCounter(); inp.focus();
}}
function updateSidebarDocs(docs) {{
  const c = document.getElementById('sidebar-docs');
  if (!docs || !docs.length) {{
    c.innerHTML = '<div class="doc-empty">لا توجد مستندات</div>';
    return;
  }}
  c.innerHTML = docs.map(d => {{
    // دعم الصيغتين: dict {{filename, doc_id}} أو string قديم
    const filename = typeof d === 'string' ? d : d.filename;
    const docId    = typeof d === 'string' ? '' : (d.doc_id || '');
    const delBtn   = docId
      ? `<button class="doc-del-btn" onclick="deleteDocument('${{escHtml(docId)}}','${{escHtml(filename)}}')" title="حذف المستند">🗑</button>`
      : '';
    return `<div class="doc-item">
      <span>📄</span>
      <span class="doc-name" title="${{escHtml(filename)}}">${{escHtml(filename)}}</span>
      ${{delBtn}}
    </div>`;
  }}).join('');
}}

async function deleteDocument(docId, filename) {{
  if (!currentSessionId) return;
  if (!confirm(`حذف "${{filename}}" وإزالة كل بياناته من قاعدة المعرفة؟`)) return;
  const res  = await fetch(`/api/session/${{currentSessionId}}/document/${{encodeURIComponent(docId)}}`, {{ method: 'DELETE' }});
  const data = await res.json();
  if (data.ok) {{
    updateSidebarDocs(data.documents);
    showToast(data.rag_ok ? `✅ تم حذف "${{filename}}" بالكامل` : `⚠️ حُذف من القائمة لكن الـ RAG لا يدعم الحذف الكامل`);
  }} else {{
    showToast('❌ ' + (data.error || 'فشل الحذف'));
  }}
}}
function showToast(msg) {{
  const old = document.querySelector('.upload-toast'); if (old) old.remove();
  const t = document.createElement('div'); t.className = 'upload-toast'; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), {constants.TOAST_DURATION_MS.value});
}}
function toggleSidebar() {{ document.getElementById('sidebar').classList.toggle('open'); }}

// ── Markdown formatter ────────────────────────────────────────────────────────
function formatMarkdown(text) {{
  let t = escHtml(text);
  // code blocks
  t = t.replace(/```([\\s\\S]*?)```/g, (_, code) => `<pre><code>${{code.trim()}}</code></pre>`);
  // inline code
  t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
  // headings
  t = t.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  t = t.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  t = t.replace(/^# (.+)$/gm, '<h1>$1</h1>');
  // bold & italic
  t = t.replace(/\\*\\*([^*]+)\\*\\*/g, '<strong>$1</strong>');
  t = t.replace(/\\*([^*]+)\\*/g, '<em>$1</em>');
  // blockquote
  t = t.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');
  // unordered list
  t = t.replace(/^[-*] (.+)$/gm, '<li>$1</li>');
  t = t.replace(/(<li>.*<\\/li>)/s, '<ul>$1</ul>');
  // ordered list
  t = t.replace(/^\\d+\\. (.+)$/gm, '<li>$1</li>');
  // links
  t = t.replace(/\\[([^\\]]+)\\]\\(([^)]+)\\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  // line breaks
  t = t.replace(/\\n/g, '<br>');
  return t;
}}
function escHtml(str) {{ return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }}
function relativeTime(iso) {{
  const d = (Date.now() - new Date(iso)) / 1000;
  if (d < 60) return 'الآن'; if (d < 3600) return Math.floor(d/60)+'د';
  if (d < 86400) return Math.floor(d/3600)+'س'; return Math.floor(d/86400)+'ي';
}}
async function apiFetch(url, method='GET') {{ return (await fetch(url, {{ method }})).json(); }}
async function apiPost(url, body={{}}) {{ return (await fetch(url, {{ method:'POST', headers:{{'Content-Type':'application/json'}}, body:JSON.stringify(body) }})).json(); }}
</script>
</body>
</html>"""