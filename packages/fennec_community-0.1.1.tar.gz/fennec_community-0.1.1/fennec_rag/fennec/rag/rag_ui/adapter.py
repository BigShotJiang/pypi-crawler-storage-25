from __future__ import annotations

import logging
import re
import time
from typing import Any, Dict, Iterator, List, Optional, Tuple

from .enum import constants

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# RAG types that this adapter knows about (by class name).
# Used only for routing decisions — no hard import dependency.
# ──────────────────────────────────────────────────────────────────────────────
_RAG_CLASS_NAMES = {
    # query(query, context) → AgenticResult(.answer, .retrieved_docs[i].doc_id)
    "AgenticRAG",
    # ask(query, include_sources, use_history) → str
    "ConversationalRAG",
    # query(query, context) → dict(.answer, .sources)
    "DomainSpecificRAG",
    # query(query, context, top_k) → dict(.answer, .sources_used)
    "FederatedRAG",
    # query(query, k, language, include_sources) → str
    "GraphRAG",
    # generate(query, search_method, include_sources) → str
    "HybridSearchRAG",
    # query(question, top_k, ...) → QueryResult(.answer, .clips[i].source_file)
    "MediaRag",
    # query(question, hops, return_intermediate) → str | dict
    "MultiHopRAG",
    # query(query, context) → SelfRAGResult(.answer)
    "SelfRAG",
    # query(query, context) → HyDEResult(.answer)
    "HyDERAG",
    # query(query, context, _depth) → RecursiveRAGResult(.answer)
    "RecursiveRAG",
    # stream(query, context) → Iterator[str]  /  query(query, context) → str
    "StreamingRAG",
    # query(query, include_sources, session_id) → dict(.answer, .sources)
    "RAGWithFeedback",
    # generate(query, ...) → str   ← RAGSystem
}


def _detect_language(text: str) -> str:
    """
    كشف لغة النص بناءً على نطاقات Unicode وكلمات مميّزة.

    Returns:
        رمز اللغة: "ar" | "en" | "fr" | "de" | "es"
    """
    text = text.strip()
    if not text:
        return "en"

    arabic = len(re.findall(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]', text))
    latin  = len(re.findall(r'[a-zA-ZÀ-ÿ]', text))
    total  = arabic + latin or 1

    if arabic / total > 0.25:
        return "ar"

    lower = text.lower()
    scores = {
        "fr": len(re.findall(r'\b(le|la|les|de|du|des|je|tu|il|nous|vous|ils|est|sont|avec|pour|dans)\b', lower)),
        "de": len(re.findall(r'\b(der|die|das|und|ist|ich|sie|wir|nicht|mit|auf|dem|den|ein|eine)\b', lower)),
        "es": len(re.findall(r'\b(el|la|los|las|de|en|que|es|con|por|para|una|uno|como)\b', lower)),
    }
    best = max(scores, key=scores.get)  # type: ignore[arg-type]
    if scores[best] >= 2:
        return best

    return "en"


def _rag_class(rag: Any) -> str:
    """اسم كلاس الـ RAG المُمرَّر."""
    return type(rag).__name__


def _extract_answer_and_sources(result: Any) -> Tuple[str, List[str]]:
    """
    استخراج (answer, sources) من أي نوع نتيجة يُعيده الـ RAG.

    يدعم:
        - str مباشرة
        - dict  → result["answer"] + result.get("sources") أو "sources_used"
        - كائن بـ .answer (AgenticResult / SelfRAGResult / HyDEResult / RecursiveRAGResult / QueryResult)
    """
    # ── حالة str ─────────────────────────────────────────────────────
    if isinstance(result, str):
        return result, []

    # ── حالة dict ────────────────────────────────────────────────────
    if isinstance(result, dict):
        answer  = result.get("answer", str(result))
        sources = (
            result.get("sources")
            or result.get("sources_used")
            or result.get("source_ids")
            or []
        )
        return answer, [str(s) for s in sources]

    # ── كائن بـ .answer ──────────────────────────────────────────────
    if hasattr(result, "answer"):
        answer = result.answer or ""

        # AgenticResult → .retrieved_docs[i].doc_id
        if hasattr(result, "retrieved_docs"):
            sources = [
                getattr(doc, "doc_id", None) or getattr(doc, "id", "unknown")
                for doc in (result.retrieved_docs or [])
            ]
            return answer, sources

        # SelfRAGResult / HyDEResult / RecursiveRAGResult → لا مصادر مباشرة
        return answer, []

    # ── fallback ─────────────────────────────────────────────────────
    return str(result), []


class RAGAdapter:
    """
    واجهة موحّدة للتعامل مع جميع أنواع الـ RAG في المكتبة.
    Unified interface for **all** RAG types in the library.

    أنواع الـ RAG المدعومة:
        AgenticRAG       · ConversationalRAG  · DomainSpecificRAG
        FederatedRAG     · GraphRAG           · HybridSearchRAG
        MediaRag         · MultiHopRAG        · SelfRAG
        HyDERAG          · RecursiveRAG       · StreamingRAG
        RAGWithFeedback  · RAGSystem (generate)

    Args:
        rag             : كائن الـ RAG
        include_sources : تضمين معرّفات المصادر في الإجابة
        language        : رمز اللغة (None = كشف تلقائي)
        retry_attempts  : عدد محاولات إعادة المحاولة عند الفشل
        retry_delay     : التأخير الأساسي بين المحاولات (ثانية)

    Raises:
        TypeError: إذا لم يكن rag يحتوي على أي تابع استعلام معروف
    """

    # تعليمات اللغة المُضافة للاستعلام (prompt injection)
    _LANG_INSTRUCTIONS: Dict[str, str] = {
        "ar": "أجب باللغة العربية.",
        "en": "Answer in English.",
        "fr": "Réponds en français.",
        "de": "Antworte auf Deutsch.",
        "es": "Responde en español.",
    }

    def __init__(
        self,
        rag: Any,
        include_sources: bool = True,
        language: Optional[str] = None,
        retry_attempts: int = constants.RETRY_MAX_ATTEMPTS.value,
        retry_delay: float = constants.RETRY_BASE_DELAY.value,
    ) -> None:
        self.rag             = rag
        self.include_sources = include_sources
        self.language        = language
        self.retry_attempts  = retry_attempts
        self.retry_delay     = retry_delay
        self._cls            = _rag_class(rag)
        # entry_id الأخير من RAGWithFeedback — يُقرأ مرةً واحدة عبر pop_last_entry_id()
        self._last_entry_id: Optional[str] = None
        self._validate()

    # ── Validation ────────────────────────────────────────────────────────────

    def _validate(self) -> None:
        """تحقق أن الـ RAG يحتوي على تابع استعلام يمكن للـ adapter استخدامه."""
        query_methods = ("generate", "query", "ask", "stream")
        if not any(hasattr(self.rag, m) for m in query_methods):
            raise TypeError(
                f"rRAG object must be: ({self._cls})\n"
                f"RAG object must implement one of: {', '.join(query_methods)}."
            )

    # ── Core: ask ─────────────────────────────────────────────────────────────

    def ask(self, query: str) -> Tuple[str, List[str]]:
        """
        إرسال استعلام للـ RAG مع دعم إعادة المحاولة عند الفشل.

        Args:
            query: نص الاستعلام

        Returns:
            Tuple[str, List[str]]: (نص الإجابة, معرّفات المصادر)

        Raises:
            Exception: بعد استنفاد جميع المحاولات
        """
        last_exc: Optional[Exception] = None

        for attempt in range(1, self.retry_attempts + 1):
            try:
                return self._ask_once(query)
            except Exception as exc:
                last_exc = exc
                if attempt < self.retry_attempts:
                    wait = self.retry_delay * (2 ** (attempt - 1))   # exponential back-off
                    logger.warning(
                        "RAG attempt %d/%d failed (%s) — retrying in %.1fs",
                        attempt, self.retry_attempts, exc, wait,
                    )
                    time.sleep(wait)
                else:
                    logger.error("RAG failed after %d attempts: %s", self.retry_attempts, exc)

        raise last_exc  # type: ignore[misc]

    def _ask_once(self, query: str) -> Tuple[str, List[str]]:
        """محاولة واحدة لإرسال الاستعلام — يُوجَّه حسب نوع الـ RAG."""
        detected_lang  = self.language or _detect_language(query)
        instruction    = self._LANG_INSTRUCTIONS.get(detected_lang, "")
        augmented      = f"{instruction}\n\n{query}" if instruction else query
        logger.debug("RAG class=%s | lang=%s | query=%.60s", self._cls, detected_lang, query)

        answer, sources = self._dispatch(augmented, query)

        # نزع قسم المصادر المضمّن في النص إن وُجد
        if self.include_sources and "📚" in answer:
            answer = answer.split("📚")[0].strip()

        return answer, list(dict.fromkeys(sources))[:5]

    # ── Routing ───────────────────────────────────────────────────────────────

    def _dispatch(self, augmented_query: str, raw_query: str) -> Tuple[str, List[str]]:
        """
        يختار تابع الاستعلام المناسب بناءً على نوع كائن الـ RAG.

        الترتيب:
            1. فحص اسم الكلاس للتوجيه المباشر (أدق)
            2. فحص التوابع المتاحة للتوافق العام (fallback)
        """
        cls = self._cls

        # ── ConversationalRAG ─────────────────────────────────────────────────
        if cls == "ConversationalRAG" or (
            hasattr(self.rag, "ask") and not hasattr(self.rag, "query")
        ):
            result = self.rag.ask(
                augmented_query,
                include_sources=self.include_sources,
                use_history=True,
            )
            return _extract_answer_and_sources(result)

        # ── StreamingRAG ──────────────────────────────────────────────────────
        if cls == "StreamingRAG":
            return self._call_streaming(augmented_query)

        # ── FederatedRAG ──────────────────────────────────────────────────────
        if cls == "FederatedRAG":
            result  = self.rag.query(augmented_query)
            answer, _ = _extract_answer_and_sources(result)
            sources = result.get("sources_used", []) if isinstance(result, dict) else []
            return answer, [str(s) for s in sources]

        # ── GraphRAG ──────────────────────────────────────────────────────────
        if cls == "GraphRAG":
            result = self.rag.query(
                augmented_query,
                include_sources=self.include_sources,
            )
            return _extract_answer_and_sources(result)

        # ── HybridSearchRAG ───────────────────────────────────────────────────
        if cls == "HybridSearchRAG":
            result = self.rag.generate(
                augmented_query,
                include_sources=self.include_sources,
            )
            return _extract_answer_and_sources(result)

        # ── MediaRag ──────────────────────────────────────────────────────────
        if cls == "MediaRag":
            result = self.rag.query(raw_query)   # بدون تعليمة اللغة للوسائط
            answer, _ = _extract_answer_and_sources(result)
            sources: List[str] = []
            if hasattr(result, "clips"):
                sources = list(dict.fromkeys(
                    getattr(clip, "source_file", "unknown") for clip in result.clips
                ))
            return answer, sources

        # ── MultiHopRAG ───────────────────────────────────────────────────────
        if cls == "MultiHopRAG":
            result = self.rag.query(augmented_query)
            return _extract_answer_and_sources(result)

        # ── RAGWithFeedback ───────────────────────────────────────────────────
        if cls == "RAGWithFeedback":
            result = self.rag.query(
                augmented_query,
                include_sources=self.include_sources,
            )
            # حفظ entry_id لاستخدامه في التقييم لاحقًا
            if isinstance(result, dict):
                self._last_entry_id = result.get("entry_id")
            return _extract_answer_and_sources(result)

        # ── AgenticRAG / DomainSpecificRAG / SelfRAG / HyDERAG / RecursiveRAG ─
        if cls in ("AgenticRAG", "DomainSpecificRAG", "SelfRAG", "HyDERAG", "RecursiveRAG"):
            result = self.rag.query(augmented_query)
            return _extract_answer_and_sources(result)

        # ── RAGSystem.generate() ─────────────────────────────────────────────
        if hasattr(self.rag, "generate"):
            result = self.rag.generate(augmented_query, include_sources=self.include_sources)
            return _extract_answer_and_sources(result)

        # ── fallback عام: .query() ────────────────────────────────────────────
        if hasattr(self.rag, "query"):
            result = self.rag.query(augmented_query)
            return _extract_answer_and_sources(result)

        raise RuntimeError(
            f"لا يمكن تحديد تابع الاستعلام للـ RAG ({self._cls}).\n"
            f"Cannot determine query method for RAG ({self._cls})."
        )

    # ── Streaming helper ──────────────────────────────────────────────────────

    def _call_streaming(self, query: str) -> Tuple[str, List[str]]:
        """
        يُشغّل StreamingRAG.stream() ويجمع النتيجة كاملةً في نص واحد.
        اللجوء لـ .query() إن لم تتوفر .stream().
        """
        if hasattr(self.rag, "stream"):
            try:
                chunks: List[str] = list(self.rag.stream(query))
                return "".join(chunks), []
            except Exception as exc:
                logger.warning(
                    "StreamingRAG.stream() failed (%s) — falling back to query()", exc
                )

        if hasattr(self.rag, "query"):
            result = self.rag.query(query)
            return _extract_answer_and_sources(result)

        raise RuntimeError("StreamingRAG: لا يوجد تابع stream() أو query() صالح.")

    # ── Streaming generator (for streaming UI) ────────────────────────────────

    def stream(self, query: str) -> Iterator[str]:
        """
        بث الإجابة token-by-token للـ UI.

        - StreamingRAG: يستخدم .stream() مباشرةً
        - بقية الأنواع: يُقسّم الجواب الكامل كلمةً كلمة

        Yields:
            str: جزء من نص الإجابة
        """
        detected_lang  = self.language or _detect_language(query)
        instruction    = self._LANG_INSTRUCTIONS.get(detected_lang, "")
        augmented      = f"{instruction}\n\n{query}" if instruction else query

        if self._cls == "StreamingRAG" and hasattr(self.rag, "stream"):
            try:
                yield from self.rag.stream(augmented)
                return
            except Exception as exc:
                logger.warning(
                    "StreamingRAG.stream() failed during streaming: %s", exc
                )

        # fallback: الحصول على الإجابة كاملةً ثم بثّها كلمةً كلمة
        answer, _ = self._dispatch(augmented, query)
        for word in answer.split(" "):
            yield word + " "
            time.sleep(constants.STREAM_WORD_DELAY.value)

    # ── Ingest ────────────────────────────────────────────────────────────────

    def ingest(self, doc_id: str, text: str) -> None:
        """
        إضافة مستند للـ RAG.

        يجرّب الطرق بالترتيب:
            rag.add_media(text, doc_id=doc_id)  ← MediaRag  (مسار ملف)
            rag.add_document(doc_id, text)       ← AgenticRAG / SelfRAG / HyDERAG / RecursiveRAG / DomainSpecificRAG
            rag.ingest({doc_id: text})           ← RAGSystem
            rag.add_documents({doc_id: text})    ← عام

        Args:
            doc_id: معرّف المستند
            text  : محتوى المستند أو مسار الملف (MediaRag)

        Raises:
            RuntimeError: إذا كان الـ RAG لا يدعم الإضافة
        """
        cls = self._cls

        # ── MediaRag: يأخذ مسار ملف ──────────────────────────────────────────
        if cls == "MediaRag":
            if hasattr(self.rag, "add_media"):
                self.rag.add_media(text, doc_id=doc_id)
                return

        # ── add_document(doc_id, text) ────────────────────────────────────────
        if hasattr(self.rag, "add_document"):
            self.rag.add_document(doc_id, text)
            return

        # ── ingest({doc_id: text}) ────────────────────────────────────────────
        if hasattr(self.rag, "ingest"):
            self.rag.ingest({doc_id: text})
            return

        # ── add_documents({doc_id: text}) ─────────────────────────────────────
        if hasattr(self.rag, "add_documents"):
            self.rag.add_documents({doc_id: text})
            return

        raise RuntimeError(
            f"RAG ({cls}) does not support document ingestion "
            "(add_document / ingest / add_documents / add_media missing)."
        )

    # ── Delete ────────────────────────────────────────────────────────────────

    def delete(self, doc_id: str) -> bool:
        """
        حذف مستند وكل الـ chunks الخاصة به من الـ RAG.

        يجرّب التوابع بهذا الترتيب:
            rag.remove_media(doc_id)       ← MediaRag
            rag.delete(doc_id)
            rag.delete_document(doc_id)
            rag.remove(doc_id)
            rag.remove_document(doc_id)
            rag.delete_documents([doc_id])

        Args:
            doc_id: معرّف المستند المراد حذفه

        Returns:
            True  إذا نجح الحذف
            False إذا كان الـ RAG لا يدعم الحذف أو لم يُوجَد المستند
        """
        methods = [
            ("remove_media",     lambda: self.rag.remove_media(doc_id)),
            ("delete",           lambda: self.rag.delete(doc_id)),
            ("delete_document",  lambda: self.rag.delete_document(doc_id)),
            ("remove",           lambda: self.rag.remove(doc_id)),
            ("remove_document",  lambda: self.rag.remove_document(doc_id)),
            ("delete_documents", lambda: self.rag.delete_documents([doc_id])),
        ]
        for name, fn in methods:
            if hasattr(self.rag, name):
                try:
                    fn()
                    logger.info("Deleted doc '%s' via rag.%s()", doc_id, name)
                    return True
                except Exception as exc:
                    logger.warning("rag.%s('%s') failed: %s", name, doc_id, exc)
                    return False

        logger.warning(
            "RAG (%s) does not support document deletion "
            "(no delete/remove method found).",
            self._cls,
        )
        return False

    # ── Feedback Rating ──────────────────────────────────────────────────────

    def pop_last_entry_id(self) -> Optional[str]:
        """
        يُعيد entry_id الأخير من RAGWithFeedback ويمسحه من الذاكرة.
        Returns and clears the last entry_id from RAGWithFeedback (one-time read).
        يُعيد None إذا لم يكن الـ RAG من نوع RAGWithFeedback أو لم يُنفَّذ استعلام بعد.
        """
        entry_id = self._last_entry_id
        self._last_entry_id = None
        return entry_id

    def rate_feedback(self, entry_id: str, rating: int, comment: Optional[str] = None) -> bool:
        """
        يُرسل تقييم المستخدم لـ RAGWithFeedback.
        Forwards user rating to RAGWithFeedback.rate().

        يُحوِّل تقييم الـ UI (-1/+1) إلى مقياس RAGWithFeedback (1-5):
            UI +1  →  5  (ممتاز | excellent)
            UI -1  →  1  (سيء   | poor)

        Args:
            entry_id : المُعرِّف من result["entry_id"]
            rating   : تقييم الـ UI — يجب أن يكون +1 أو -1
            comment  : تعليق نصي اختياري

        Returns:
            True إذا نجح التقييم، False إذا فشل أو لم يكن الـ RAG من نوع RAGWithFeedback
        """
        if self._cls != "RAGWithFeedback":
            return False
        if not hasattr(self.rag, "rate"):
            logger.warning("RAGWithFeedback object has no rate() method")
            return False

        # تحويل +1/-1 (UI) إلى 5/1 (مقياس RAGWithFeedback)
        fb_rating = 5 if rating >= 1 else 1

        try:
            result = self.rag.rate(entry_id, rating=fb_rating, comment=comment)
            return result is not None
        except Exception as exc:
            logger.warning("rate_feedback() failed: %s", exc)
            return False

    # ── Stats ─────────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        """إحصائيات الـ RAG إن كانت متاحة."""
        if hasattr(self.rag, "get_stats"):
            try:
                return self.rag.get_stats()
            except Exception:
                pass
        if hasattr(self.rag, "stats"):
            try:
                raw = self.rag.stats()
                if isinstance(raw, dict):
                    return raw
            except Exception:
                pass
        return {}

    # ── Repr ──────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"RAGAdapter(rag={self._cls}, "
            f"include_sources={self.include_sources}, "
            f"language={self.language!r})"
        )