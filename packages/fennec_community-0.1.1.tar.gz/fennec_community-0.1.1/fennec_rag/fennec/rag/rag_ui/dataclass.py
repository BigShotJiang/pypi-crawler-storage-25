from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
import uuid
from typing import Any, Dict, List, Optional


@dataclass
class ChatMessage:
    """
    رسالة واحدة داخل جلسة محادثة.
    A single message within a chat session.

    Attributes:
        role       : دور المُرسِل — "user" | "assistant" | "system"
        content    : نص الرسالة
        timestamp  : وقت الإنشاء ISO-8601
        msg_id     : معرّف فريد مختصر (8 أحرف)
        sources    : معرّفات المستندات المصدر
        latency_ms : زمن استجابة الـ RAG بالميلي-ثانية
        rating     : تقييم المستخدم (+1 إيجابي / -1 سلبي / 0 بدون تقييم)
        error      : رسالة خطأ إن وُجد
    """
    role: str
    content: str
    timestamp: str       = field(default_factory=lambda: datetime.now().isoformat())
    msg_id: str          = field(default_factory=lambda: str(uuid.uuid4())[:8])
    sources: List[str]   = field(default_factory=list)
    latency_ms: float    = 0.0
    rating: int          = 0
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """تحويل الرسالة إلى قاموس JSON-serializable."""
        return {
            "role":       self.role,
            "content":    self.content,
            "timestamp":  self.timestamp,
            "msg_id":     self.msg_id,
            "sources":    self.sources,
            "latency_ms": self.latency_ms,
            "rating":     self.rating,
            "error":      self.error,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChatMessage":
        """إنشاء رسالة من قاموس."""
        return cls(
            role=data.get("role", "user"),
            content=data.get("content", ""),
            timestamp=data.get("timestamp", datetime.now().isoformat()),
            msg_id=data.get("msg_id", str(uuid.uuid4())[:8]),
            sources=data.get("sources", []),
            latency_ms=data.get("latency_ms", 0.0),
            rating=data.get("rating", 0),
            error=data.get("error"),
        )


@dataclass
class ChatSession:
    """
    جلسة محادثة كاملة مع سجل رسائلها ومستنداتها.
    chat session with history and documents.


    Attributes:
        session_id  : معرّف فريد (12 حرف)
        title       : عنوان يُولَّد تلقائيًا من أول رسالة
        messages    : قائمة رسائل الجلسة
        created_at  : وقت الإنشاء
        updated_at  : آخر تحديث
        documents   : أسماء الملفات المرفوعة
        is_pinned   : تثبيت الجلسة في أعلى القائمة
    """
    session_id:  str       = field(default_factory=lambda: str(uuid.uuid4())[:12])
    title:       str       = "new chat"
    messages:    List[ChatMessage] = field(default_factory=list)
    created_at:  str       = field(default_factory=lambda: datetime.now().isoformat())
    updated_at:  str       = field(default_factory=lambda: datetime.now().isoformat())
    documents:   List[Dict[str, str]] = field(default_factory=list)  # [{"filename": ..., "doc_id": ...}]
    is_pinned:   bool                 = False

    # ── Mutation ────────────────────────────────────────────────────────────────

    def add(self, role: str, content: str, **kw: Any) -> ChatMessage:
        """
        إضافة رسالة جديدة وتحديث العنوان تلقائيًا.

        Args:
            role    : "user" | "assistant" | "system"
            content : نص الرسالة
            **kw    : حقول إضافية لـ ChatMessage

        Returns:
            ChatMessage المُنشأة
        """
        msg = ChatMessage(role=role, content=content, **kw)
        self.messages.append(msg)
        self.updated_at = datetime.now().isoformat()
        if len(self.messages) == 2:
            first_user = next((m for m in self.messages if m.role == "user"), None)
            if first_user:
                self.title = first_user.content[:45] + (
                    "…" if len(first_user.content) > 45 else ""
                )
        return msg

    def clear(self) -> None:
        """مسح الرسائل مع الاحتفاظ بالمستندات والعنوان."""
        self.messages = []
        self.updated_at = datetime.now().isoformat()

    def rename(self, new_title: str) -> None:
        """تغيير عنوان الجلسة يدويًا."""
        self.title = new_title.strip()[:60] or "new chat"
        self.updated_at = datetime.now().isoformat()

    def remove_document(self, doc_id: str) -> Optional[Dict[str, str]]:
        """
        حذف مستند من قائمة الجلسة بمعرّفه.

        Args:
            doc_id: معرّف المستند

        Returns:
            بيانات المستند المحذوف، أو None إن لم يُوجَد
        """
        for i, doc in enumerate(self.documents):
            if doc.get("doc_id") == doc_id:
                self.updated_at = datetime.now().isoformat()
                return self.documents.pop(i)
        return None

    def rate_message(self, msg_id: str, rating: int) -> bool:
        """
        تقييم رسالة معيّنة.

        Args:
            msg_id : معرّف الرسالة
            rating : +1 | 0 | -1

        Returns:
            True إذا وُجدت الرسالة وتم التقييم
        """
        for msg in self.messages:
            if msg.msg_id == msg_id:
                msg.rating = rating
                return True
        return False

    # ── Properties ──────────────────────────────────────────────────────────────

    @property
    def message_count(self) -> int:
        return len(self.messages)

    @property
    def is_empty(self) -> bool:
        return len(self.messages) == 0

    @property
    def positive_ratings(self) -> int:
        return sum(1 for m in self.messages if m.rating == 1)

    @property
    def negative_ratings(self) -> int:
        return sum(1 for m in self.messages if m.rating == -1)

    # ── Serialisation ────────────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id":       self.session_id,
            "title":            self.title,
            "messages":         [m.to_dict() for m in self.messages],
            "created_at":       self.created_at,
            "updated_at":       self.updated_at,
            "documents":        self.documents,
            "is_pinned":        self.is_pinned,
            "positive_ratings": self.positive_ratings,
            "negative_ratings": self.negative_ratings,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChatSession":
        """استعادة جلسة من قاموس — يدعم الصيغتين القديمة (List[str]) والجديدة (List[Dict])."""
        raw_docs = data.get("documents", [])
        # توافق مع الصيغة القديمة التي كانت تخزّن أسماء الملفات كنصوص
        documents = [
            doc if isinstance(doc, dict) else {"filename": doc, "doc_id": ""}
            for doc in raw_docs
        ]
        session = cls(
            session_id=data.get("session_id", str(uuid.uuid4())[:12]),
            title=data.get("title", "new chat"),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
            documents=documents,
            is_pinned=data.get("is_pinned", False),
        )
        session.messages = [ChatMessage.from_dict(m) for m in data.get("messages", [])]
        return session