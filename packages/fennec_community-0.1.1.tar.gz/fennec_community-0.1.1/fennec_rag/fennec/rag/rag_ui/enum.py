from enum import Enum


class constants(Enum):
    # ── Query limits ──────────────────────────────────────────────────────────
    MAX_QUERY_LENGTH: int        = 4000
    MAX_FILE_SIZE_MB: int        = 50

    # ── Streaming ─────────────────────────────────────────────────────────────
    STREAM_WORD_DELAY: float     = 0.02

    # ── UI / UX ───────────────────────────────────────────────────────────────
    BROWSER_OPEN_DELAY: float    = 1.5
    TOAST_DURATION_MS: int       = 3000

    # ── Session ───────────────────────────────────────────────────────────────
    MAX_SESSIONS: int            = 30
    SESSION_TITLE_MAX_LEN: int   = 45

    # ── Retry ─────────────────────────────────────────────────────────────────
    RETRY_MAX_ATTEMPTS: int      = 3
    RETRY_BASE_DELAY: float      = 0.5