from __future__ import annotations
import logging
from pathlib import Path
from typing import Callable, Dict

logger = logging.getLogger(__name__)


class FileProcessor:
    """
    معالج الملفات — يقرأ ويحوّل الملفات المرفوعة إلى نص.
    Converts uploaded files to plain text.

    الأنواع المدعومة: .txt, .md, .csv, .json, .html, .pdf, .docx, .xlsx
    """

    DEFAULT_EXTENSIONS: frozenset = frozenset(
        {".txt", ".pdf", ".docx", ".md", ".csv", ".json", ".html", ".xlsx"}
    )

    @classmethod
    def read(cls, file_path: str) -> str:
        """
        قراءة ملف وإرجاع محتواه كنص.

        Args:
            file_path: المسار الكامل للملف

        Returns:
            str: محتوى الملف كنص

        Raises:
            ValueError : إذا كان الملف فارغًا تمامًا
            OSError    : إذا تعذّرت القراءة
        """
        suffix = Path(file_path).suffix.lower()
        readers: Dict[str, Callable[[str], str]] = {
            ".pdf":  cls._read_pdf,
            ".docx": cls._read_docx,
            ".xlsx": cls._read_xlsx,
        }
        content = readers.get(suffix, cls._read_text)(file_path)
        return content

    # ── Internal readers ──────────────────────────────────────────────────────

    @staticmethod
    def _read_text(path: str) -> str:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    @staticmethod
    def _read_pdf(path: str) -> str:
        try:
            import pypdf
            reader = pypdf.PdfReader(path)
            pages = [p.extract_text() or "" for p in reader.pages]
            return "\n".join(pages)
        except ImportError:
            logger.warning("pypdf not installed: pip install pypdf")
            return open(path, "rb").read().decode("utf-8", errors="ignore")

    @staticmethod
    def _read_docx(path: str) -> str:
        try:
            import docx
            doc = docx.Document(path)
            parts: list[str] = []
            for para in doc.paragraphs:
                if para.text.strip():
                    parts.append(para.text)
            # تضمين محتوى الجداول
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                    if row_text:
                        parts.append(row_text)
            return "\n".join(parts)
        except ImportError:
            logger.warning("python-docx not installed: pip install python-docx")
            return open(path, "rb").read().decode("utf-8", errors="ignore")

    @staticmethod
    def _read_xlsx(path: str) -> str:
        """
        قراءة ملفات Excel وتحويلها إلى نص جدولي.
        Reads Excel files and converts them to tabular text.
        """
        try:
            import openpyxl
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            parts: list[str] = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                parts.append(f"=== Sheet: {sheet_name} ===")
                for row in ws.iter_rows(values_only=True):
                    row_text = " | ".join(str(cell) for cell in row if cell is not None)
                    if row_text.strip():
                        parts.append(row_text)
            wb.close()
            return "\n".join(parts)
        except ImportError:
            logger.warning("openpyxl not installed: pip install openpyxl")
            return ""

    # ── Utility ───────────────────────────────────────────────────────────────

    @classmethod
    def is_supported(cls, filename: str) -> bool:
        """التحقق من دعم امتداد الملف."""
        return Path(filename).suffix.lower() in cls.DEFAULT_EXTENSIONS

    @classmethod
    def file_info(cls, path: str) -> Dict[str, object]:
        """معلومات الملف: الاسم، الامتداد، الحجم بالبايت."""
        p = Path(path)
        return {
            "name":      p.name,
            "extension": p.suffix.lower(),
            "size_kb":   round(p.stat().st_size / 1024, 2),
            "supported": cls.is_supported(p.name),
        }