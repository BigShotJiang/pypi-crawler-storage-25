from dataclasses import dataclass
from enum import Enum


class AgentAction(Enum):
    """Actions the agent can take at each decision step."""
    RETRIEVE = "retrieve"
    GENERATE = "generate"
    REFINE_QUERY = "refine_query"
    CHECK_SUFFICIENCY = "check_sufficiency"
    STOP = "stop"


class ReasoningDepth(str, Enum):
    SHALLOW = "shallow"
    MEDIUM = "medium"
    DEEP = "deep"

@dataclass
class AgenticConfig:
    """
    Configuration for the Agentic RAG system.

    Attributes:
        max_iterations:           Hard cap on reasoning cycles.
        min_confidence:           Score threshold to accept retrieved docs.
        min_docs_required:        Minimum number of docs before generation.
        enable_query_refinement:  Whether to rewrite weak queries automatically.
        enable_self_correction:   Whether to validate and retry on bad answers.
        enable_sufficiency_check: Whether to ask the LLM if context is enough.
        reasoning_depth:          Controls prompt complexity for LLM calls.
        cache_ttl_seconds:        How long to cache retrieval results (0 = off).
        retry_attempts:           Retries for retrieval / generation calls.
        retry_backoff_base:       Base seconds for exponential backoff.
    """
    max_iterations: int = 5
    min_confidence: float = 0.7
    min_docs_required: int = 2
    enable_query_refinement: bool = True
    enable_self_correction: bool = True
    enable_sufficiency_check: bool = True
    reasoning_depth: ReasoningDepth = ReasoningDepth.MEDIUM
    cache_ttl_seconds: int = 300
    retry_attempts: int = 2
    retry_backoff_base: float = 0.5