from dataclasses import dataclass

@dataclass
class StreamConfig:
    """Fine-grained control over streaming behaviour."""
    chunk_size: int = 10          # words per simulated chunk
    sim_delay: float = 0.04       # seconds between simulated chunks
    max_context_docs: int = 5     # how many retrieved docs to include
    max_doc_chars: int = 500      # truncate each doc to this many chars
    emit_metadata: bool = True    # whether to yield non-CHUNK events
    retrieval_timeout: float = 10.0
    generation_timeout: float = 60.0
    prompt_template: str = (
        
    "You are a precise RAG assistant.\n\n"
    
    "Strict rules:\n"
    "- Use ONLY the provided context.\n"
    "- Do NOT guess.\n"
    "- If missing info, say: 'لا توجد معلومات كافية في السياق'.\n"
    "- The answer MUST be in the SAME language as the question.\n"
    "- NEVER switch language.\n\n"
    
    "Context:\n{context}\n\n"
    "Question: {query}\n\n"
    
    "Final Answer:"
   )

