from enum import Enum

class EventType(str, Enum):
    RETRIEVAL_START  = "retrieval_start"
    RETRIEVAL_DONE   = "retrieval_done"
    GENERATION_START = "generation_start"
    GENERATION_DONE  = "generation_done"
    CHUNK            = "chunk"
    ERROR            = "error"
