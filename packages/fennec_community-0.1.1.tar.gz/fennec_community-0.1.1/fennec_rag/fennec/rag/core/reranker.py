from __future__ import annotations
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple
from .rag_config import RerankMode , RerankerConfig
logger = logging.getLogger(__name__)

# الحد الأقصى لعدد الكلمات المُرسَلة للـ LLM (موحَّد بين اللغتين)
# Max words sent to LLM — unified across languages
_LLM_TEXT_MAX_WORDS: int = 150

# الحد الأقصى للخيوط المتوازية لاستدعاء LLM
# Max parallel threads for LLM calls
_MAX_LLM_WORKERS: int = 6


# ──────────────────────────────────────────────────────────────────────────────
# Reranker
# ──────────────────────────────────────────────────────────────────────────────

class Reranker:
    """
    يُعيد ترتيب قائمة (chunk, score) بحسب الوضع المختار
    Re-ranks a list of (chunk, score) pairs according to the selected mode

    المدخلات | Input:
        query  : نص الاستعلام | Query text
        chunks : List[Tuple[chunk, float]]  – النتائج الأولية | Initial results

    المخرجات | Output:
        List[Tuple[chunk, float]]  – النتائج المُعاد ترتيبها | Re-ranked results
    """

    def __init__(self, config: Optional[RerankerConfig] = None, llm: Any = None):
        """
        Args:
            config: إعدادات مُعيد الترتيب | Reranker configuration
            llm:    نموذج اللغة (مطلوب للوضعين llm وhybrid) |
                    Language model (required for llm / hybrid modes)
        """
        self.config = config or RerankerConfig()
        self.llm    = llm

        if self.config.mode in (RerankMode.LLM, RerankMode.HYBRID) and llm is None:
            logger.warning(
                "LLM not provided — falling back to heuristic mode"
            )
            self.config.mode = RerankMode.HEURISTIC

        logger.info(
            "✅ Reranker ready | mode=%s | top_k=%s | dedup=%s",
            self.config.mode.value,
            self.config.top_k,
            self.config.dedup_enabled,
        )

    # ── Main entry point ──────────────────────────────────────────────────────

    def rerank(
        self,
        query: str,
        chunks: List[Tuple[Any, float]],
    ) -> List[Tuple[Any, float]]:
        """
        إعادة ترتيب النتائج
        Re-rank results

        Args:
            query:  استعلام المستخدم | User query
            chunks: قائمة (قطعة، درجة) | List of (chunk, score)

        Returns:
            النتائج مُعاد ترتيبها | Re-ranked results
        """
        if not chunks:
            return []

        if len(chunks) == 1:
            return chunks

        # ✅ [🟢] فلترة النصوص المكررة قبل أي معالجة
        # Remove near-duplicates before any scoring
        if self.config.dedup_enabled:
            chunks = self._remove_near_duplicates(chunks)

        mode = self.config.mode

        if mode == RerankMode.HEURISTIC:
            ranked = self._rerank_heuristic(query, chunks)
        elif mode == RerankMode.LLM:
            ranked = self._rerank_llm(query, chunks)
        else:  # HYBRID
            ranked = self._rerank_hybrid(query, chunks)

        # تطبيق top_k إذا حُدِّد | Apply top_k if specified
        k = self.config.top_k
        if k is not None:
            ranked = ranked[:k]

        logger.debug(
            "rerank done | mode=%s | in=%d | out=%d | top_score=%.3f",
            mode.value, len(chunks), len(ranked),
            ranked[0][1] if ranked else 0.0,
        )
        return ranked

    # ── Heuristic reranker ────────────────────────────────────────────────────

    def _rerank_heuristic(
        self,
        query: str,
        chunks: List[Tuple[Any, float]],
    ) -> List[Tuple[Any, float]]:
        """
        إعادة ترتيب بالاستدلال البسيط (دون LLM)
        Heuristic re-ranking (no LLM)

        ✅ [🔴] إصلاح: تُستخدم الأوزان الفعلية من effective_weights() بدلاً
        من إعادة ضرب orig_score بوزن llm_score_weight يدويًا.
        Fix: uses effective_weights() so llm weight is correctly folded into
        orig weight instead of being applied twice.
        """
        w            = self.config.effective_weights(RerankMode.HEURISTIC)
        query_terms  = set(re.findall(r"\w+", query.lower()))
        seen_docs:   set[str] = set()
        scored: List[Tuple[Any, float]] = []

        for chunk, orig_score in chunks:
            text   = self._get_text(chunk)
            doc_id = self._get_doc_id(chunk)

            # ── Length bonus ─────────────────────────────────────────────────
            word_count = len(text.split())
            len_bonus  = self._length_bonus(word_count)

            # ── Diversity + term-overlap bonus ───────────────────────────────
            div_bonus   = 0.0 if doc_id in seen_docs else 1.0
            seen_docs.add(doc_id)
            chunk_terms = set(re.findall(r"\w+", text.lower()))
            overlap     = len(query_terms & chunk_terms) / max(len(query_terms), 1)

            # ── Composite score (أوزان فعلية مُصحَّحة) ──────────────────────
            composite = (
                w["orig"] * orig_score
                + w["len"] * len_bonus
                + w["div"] * (div_bonus * 0.5 + overlap * 0.5)
                # w["llm"] == 0.0 في الوضع heuristic
            )
            scored.append((chunk, composite))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    # ── LLM reranker ──────────────────────────────────────────────────────────

    def _rerank_llm(
        self,
        query: str,
        chunks: List[Tuple[Any, float]],
    ) -> List[Tuple[Any, float]]:
        """
        إعادة ترتيب بمساعدة نموذج اللغة (متوازٍ)
        LLM-assisted re-ranking (parallel)

        ✅ [🟡] استدعاء LLM لكل القطع بالتوازي بدلاً من التسلسل
        LLM called for all chunks in parallel instead of sequentially
        """
        w      = self.config.effective_weights(RerankMode.LLM)
        scores = self._batch_llm_scores(query, chunks)
        scored: List[Tuple[Any, float]] = []

        for (chunk, orig_score), llm_score in zip(chunks, scores):
            text      = self._get_text(chunk)
            len_bonus = self._length_bonus(len(text.split()))

            composite = (
                w["orig"] * orig_score
                + w["llm"] * llm_score
                + w["len"] * len_bonus
                # div_weight غير مستخدم في وضع LLM الصافي
            )
            scored.append((chunk, composite))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    # ── Hybrid reranker ───────────────────────────────────────────────────────

    def _rerank_hybrid(
        self,
        query: str,
        chunks: List[Tuple[Any, float]],
    ) -> List[Tuple[Any, float]]:
        """
        مزيج من الاستدلال البسيط وتقييم LLM (متوازٍ)
        Mix of heuristic scoring and LLM evaluation (parallel)

        ✅ [🟡] استدعاء LLM بالتوازي
        LLM calls run in parallel
        """
        w            = self.config.effective_weights(RerankMode.HYBRID)
        query_terms  = set(re.findall(r"\w+", query.lower()))
        seen_docs:   set[str] = set()
        llm_scores   = self._batch_llm_scores(query, chunks)
        scored: List[Tuple[Any, float]] = []

        for (chunk, orig_score), llm_score in zip(chunks, llm_scores):
            text   = self._get_text(chunk)
            doc_id = self._get_doc_id(chunk)

            word_count  = len(text.split())
            len_bonus   = self._length_bonus(word_count)
            div_bonus   = 0.0 if doc_id in seen_docs else 1.0
            seen_docs.add(doc_id)
            chunk_terms = set(re.findall(r"\w+", text.lower()))
            overlap     = len(query_terms & chunk_terms) / max(len(query_terms), 1)

            composite = (
                w["orig"] * orig_score
                + w["llm"] * llm_score
                + w["len"] * len_bonus
                + w["div"] * (div_bonus * 0.5 + overlap * 0.5)
            )
            scored.append((chunk, composite))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored

    # ── Parallel LLM batch scoring ────────────────────────────────────────────

    def _batch_llm_scores(
        self,
        query: str,
        chunks: List[Tuple[Any, float]],
    ) -> List[float]:
        """
        ✅ [🟡] يستدعي LLM لجميع القطع بالتوازي ويُعيد الدرجات بنفس الترتيب.
        Calls LLM for all chunks in parallel and returns scores in the same order.
        """
        results: Dict[int, float] = {}

        with ThreadPoolExecutor(max_workers=_MAX_LLM_WORKERS) as executor:
            future_map = {
                executor.submit(
                    self._llm_relevance_score_cached,
                    query,
                    self._get_text(chunk),
                ): idx
                for idx, (chunk, _) in enumerate(chunks)
            }
            for future in as_completed(future_map):
                idx = future_map[future]
                try:
                    results[idx] = future.result()
                except Exception as exc:
                    logger.warning("LLM scoring failed for chunk %d: %s", idx, exc)
                    results[idx] = 0.5   # neutral fallback

        return [results[i] for i in range(len(chunks))]

    # ── Near-duplicate filter ─────────────────────────────────────────────────

    def _remove_near_duplicates(
        self,
        chunks: List[Tuple[Any, float]],
    ) -> List[Tuple[Any, float]]:
        """
        ✅ [🟢] يحذف القطع التي تتشابه نصيًا مع قطعة سابقة (Jaccard ≥ threshold).
        Removes chunks whose text is near-identical to a previously seen chunk.

        يحتفظ بالقطعة ذات الدرجة الأصلية الأعلى عند وجود تكرار.
        Keeps the chunk with the higher original score when duplicates exist.
        """
        threshold  = self.config.dedup_threshold
        kept:      List[Tuple[Any, float]] = []
        kept_words: List[set] = []

        # ترتيب مبدئي بالدرجة تنازليًا للإبقاء على الأفضل
        sorted_chunks = sorted(chunks, key=lambda x: x[1], reverse=True)

        for chunk, score in sorted_chunks:
            text  = self._get_text(chunk)
            words = set(re.findall(r"\w+", text.lower()))

            is_dup = any(
                self._jaccard(words, seen) >= threshold
                for seen in kept_words
            )

            if not is_dup:
                kept.append((chunk, score))
                kept_words.append(words)

        removed = len(chunks) - len(kept)
        if removed:
            logger.debug("dedup removed %d near-duplicate chunk(s)", removed)

        return kept

    @staticmethod
    def _jaccard(a: set, b: set) -> float:
        """معامل Jaccard بين مجموعتي كلمات | Jaccard similarity between two word sets"""
        if not a or not b:
            return 0.0
        return len(a & b) / len(a | b)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _length_bonus(self, word_count: int) -> float:
        """
        مكافأة الطول الأمثل (0.0 → 1.0)
        Optimal-length bonus (0.0 → 1.0)
        """
        lo = self.config.ideal_min_words
        hi = self.config.ideal_max_words
        if lo <= word_count <= hi:
            return 1.0
        if word_count < lo:
            return max(0.0, word_count / lo)
        return max(0.0, 1.0 - (word_count - hi) / hi)

    def _get_text(self, chunk: Any) -> str:
        """
        استخراج نص القطعة
        Extract chunk text

        ✅ [🔴] fallback آمن: يُعيد "" مع تحذير بدلاً من str(chunk) الضخم
        Safe fallback: returns "" with a warning instead of bulky str(chunk)
        """
        for attr in ("text", "content", "page_content"):
            val = getattr(chunk, attr, None)
            if isinstance(val, str) and val.strip():
                return val
        logger.warning(
            "_get_text: chunk of type '%s' has no recognised text attribute — "
            "returning empty string.",
            type(chunk).__name__,
        )
        return ""

    def _get_doc_id(self, chunk: Any) -> str:
        """استخراج معرف المستند | Extract document ID"""
        return (
            getattr(chunk, "doc_id", None)
            or getattr(chunk, "document_id", None)
            or "unknown"
        )

    @staticmethod
    def _truncate_to_words(text: str, max_words: int) -> str:
        """
        ✅ [🟡] اقتطاع موحَّد بالكلمات (يعمل مع العربية والإنجليزية على حدٍّ سواء)
        Unified word-based truncation (works for both Arabic and English)
        """
        words = text.split()
        if len(words) <= max_words:
            return text
        return " ".join(words[:max_words])

    def _llm_relevance_score(self, query: str, text: str) -> float:
        """
        يسأل LLM عن مدى صلة النص بالاستعلام (0.0 → 1.0)
        Ask LLM about text–query relevance (0.0 → 1.0)

        ✅ [🟡] الاقتطاع موحَّد لكلا اللغتين بـ _truncate_to_words()
        Truncation is now unified for both languages via _truncate_to_words()
        """
        if self.llm is None:
            return 0.5  # neutral fallback

        # ✅ [🟡] اقتطاع متناسق | Consistent truncation
        trimmed_text = self._truncate_to_words(text, _LLM_TEXT_MAX_WORDS)

        lang = self.config.llm_eval_language
        if lang == "ar":
            prompt = (
                f"قيّم مدى صلة النص التالي بالسؤال على مقياس من 0 إلى 10.\n"
                f"أجب برقم فقط بدون أي شرح.\n\n"
                f"السؤال: {query}\n\n"
                f"النص: {trimmed_text}\n\n"
                f"الدرجة:"
            )
        else:
            prompt = (
                f"Rate the relevance of the following text to the question "
                f"on a scale from 0 to 10.\n"
                f"Reply with a number only, no explanation.\n\n"
                f"Question: {query}\n\n"
                f"Text: {trimmed_text}\n\n"
                f"Score:"
            )

        try:
            raw   = self.llm.generate(prompt, max_tokens=5)
            match = re.search(r"\d+(?:\.\d+)?", raw)
            if match:
                score = float(match.group()) / 10.0
                return max(0.0, min(1.0, score))
        except Exception as exc:
            logger.warning("LLM relevance scoring failed: %s", exc)

        return 0.5  # neutral fallback on error

    # ✅ [🟢] تخزين مؤقت لنتائج LLM — يمنع إعادة الاستدعاء لنفس (query, text)
    # LLM result cache — prevents redundant calls for the same (query, text)
    @lru_cache(maxsize=512)
    def _llm_relevance_score_cached(self, query: str, text: str) -> float:
        """
        نسخة مُخزَّنة مؤقتًا من _llm_relevance_score.
        Cached version of _llm_relevance_score.

        ✅ [🟢] يُعيد النتيجة المخزَّنة فورًا إذا سبق حساب (query, text) ذاته
        Returns cached result instantly if the same (query, text) was seen before
        """
        return self._llm_relevance_score(query, text)

    def clear_cache(self) -> None:
        """
        يمسح ذاكرة التخزين المؤقت لـ LLM
        Clear the LLM result cache
        """
        self._llm_relevance_score_cached.cache_clear()
        logger.info("LLM relevance cache cleared.")

    def __repr__(self) -> str:
        return (
            f"Reranker(mode={self.config.mode.value}, "
            f"top_k={self.config.top_k}, "
            f"dedup={self.config.dedup_enabled})"
        )