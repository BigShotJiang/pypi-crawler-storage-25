from typing import Dict, List, Optional, Tuple, Any, Callable, Union
from pathlib import Path
import logging
import time
from dataclasses import dataclass, field
import hashlib
import json
from .base_rag_system import BaseRAGSystem, RAGConfig
from .prompt_router import PromptRouter
from .reranker import Reranker, RerankerConfig, RerankMode

# ── نوع الـ Prompt المخصص | Custom Prompt Type ─────────────────────────────
# يقبل: PromptTemplate (له .format) | دالة (callable) | نص ثابت (str)
# Accepts: PromptTemplate (has .format) | callable | plain string
PromptInput = Union[Any, Callable[[str, str], str], str]

logger = logging.getLogger(__name__)


@dataclass
class LoadedDocument:
    """
    Represents a loaded document with its content and metadata.\n
    يمثل مستنداً محملاً مع محتواه وبياناته الوصفية.
    
    Attributes:
        page_content: The text content of the document | محتوى النص
        metadata: Dictionary of metadata | قاموس البيانات الوصفية
        doc_id: Unique document identifier | معرف المستند الفريد
    """
    page_content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    doc_id: Optional[str] = None

    def __post_init__(self):
        """Auto-generate doc_id if not provided | توليد معرف تلقائي إذا لم يُقدَّم"""
        if not self.doc_id:
            content_hash = hashlib.md5(self.page_content.encode()).hexdigest()[:8]
            self.doc_id = f"doc_{content_hash}_{int(time.time())}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary | تحويل إلى قاموس"""
        return {
            "doc_id": self.doc_id,
            "page_content": self.page_content,
            "metadata": self.metadata
        }

    def __repr__(self) -> str:
        preview = self.page_content[:80].replace('\n', ' ')
        return f"LoadedDocument(doc_id={self.doc_id!r}, preview={preview!r}...)"

class RAGSystem(BaseRAGSystem):
    """
    نظام RAG (التنسيق فقط)
    RAG System (Orchestration only)

    المكونات الخارجية | External dependencies:
    - vector_db        : أي كائن يحتوي على (add, search, remove_by_doc_id, save, load)
                        any object with (add, search, remove_by_doc_id, save, load)
    - chunker          : أي كائن يحتوي على (chunk_text أو chunk)
                        any object with (chunk_text or chunk)
    - llm              : أي كائن يحتوي على (generate)
                        any object with (generate)
    - context_manager  : أي كائن يحتوي على (build)
                        any object with (build)
    """

    def __init__(
        self,
        vector_db: Any,
        llm: Any,
        chunker: Any,
        context_manager: Any,
        config: Optional[RAGConfig] = None,
        prompt: Optional[PromptInput] = None,
    ):
        """
        تهيئة نظام RAG
        Initialize RAG system

        Args:
            vector_db:       قاعدة البيانات المتجهة | Vector database
            llm:             نموذج اللغة | Language model
            chunker:         محلل النصوص | Text chunker
            context_manager: مدير السياق | Context manager
            config:          إعدادات النظام | System configuration
            prompt:          قالب الـ Prompt المخصص أو الافتراضي | Custom or default prompt.
                             يقبل ثلاثة أشكال | Accepts three forms:
                               1) PromptTemplate  — أي كائن له .format(context=..., question=...)
                                                    any object with .format(context=..., question=...)
                               2) Callable        — دالة (context, question) -> str
                                                    function (context, question) -> str
                               3) str             — نص ثابت يحتوي على {context} و {question}
                                                    plain string containing {context} and {question}
                             None = استخدام الـ PromptRouter أو الـ prompt الافتراضي
                             None = use PromptRouter or built-in default prompt
        """
        super().__init__(config)

        # التحقق من المكونات المطلوبة | Validate required components
        if vector_db is None:
            raise ValueError("❌ vector_db must be provided")
        if llm is None:
            raise ValueError("❌ llm must be provided")
        if chunker is None:
            raise ValueError("❌ chunker must be provided")
        if context_manager is None:
            raise ValueError("❌ context_manager must be provided")

        # تعيين المكونات | Assign components
        self.vector_db = vector_db
        self.llm = llm
        self.chunker = chunker
        self.context_manager = context_manager

        # ── Custom Prompt ──────────────────────────────────────────────────
        # يُخزَّن كما هو؛ _resolve_prompt() تُطبّقه وقت الاستعلام
        # Stored as-is; _resolve_prompt() applies it at query time
        self._custom_prompt: Optional[PromptInput] = prompt

        # ── Prompt Router ──────────────────────────────────────────────────
        # يُفعَّل فقط إذا لم يُعطَ prompt مخصص
        # Activated only when no custom prompt is provided
        self.prompt_router = PromptRouter(
            include_few_shot=self.config.include_few_shot
        ) if (self.config.enable_prompt_routing and prompt is None) else None

        # ── Reranker ───────────────────────────────────────────────────────
        if self.config.enable_reranking:
            reranker_config = RerankerConfig(
                mode=RerankMode(self.config.rerank_mode),
                top_k=self.config.rerank_top_k,
                original_score_weight=self.config.rerank_original_weight,
                llm_score_weight=self.config.rerank_llm_weight,
                diversity_weight=self.config.rerank_diversity_weight,
                length_weight=self.config.rerank_length_weight,
            )
            self.reranker = Reranker(config=reranker_config, llm=self.llm)
        else:
            self.reranker = None

        logger.info("✅RAG system initialized"
                    " | reranking=%s | prompt_routing=%s",
                    self.config.enable_reranking,
                    self.config.enable_prompt_routing)

    # ------------------------------------------------------------------
    # إضافة المستندات | Document ingestion
    # ------------------------------------------------------------------

    def add_documents(self, docs: List[LoadedDocument]) -> Dict[str, int]:
        """
        إضافة مستندات للنظام
        Add documents to the system
    
        Args:
            docs: قائمة من LoadedDocument | List of LoadedDocument
    
        Returns:
            قاموس {doc_id: عدد_القطع} | Dictionary {doc_id: number_of_chunks}
        """
        if not docs:
            logger.warning("⚠️ No documents to add")
            return {}
    
        logger.info(f"📄 Starting to add {len(docs)} documents")
    
        results: Dict[str, int] = {}
        all_chunks = []
    
        # معالجة كل مستند | Process each document
        for doc in docs:
            doc_id = doc.doc_id
            text = doc.page_content
    
            if not text or not text.strip():
                logger.warning(f"⚠️ Empty document: {doc_id}")
                results[doc_id] = 0
                continue
            
            try:
                if hasattr(self.chunker, "chunk_text"):
                    chunks = self.chunker.chunk_text(text, doc_id)
                elif hasattr(self.chunker, "chunk"):
                    chunks = self.chunker.chunk(text, doc_id)
                else:
                    raise AttributeError("Chunker must have chunk_text or chunk method")
    
                all_chunks.extend(chunks)
                results[doc_id] = len(chunks)
    
                logger.info(f"✅ {doc_id}: {len(chunks)} chunks")
    
            except Exception as e:
                logger.error(f"❌ Error chunking document {doc_id}: {e}")
                results[doc_id] = 0
    
        # إضافة جميع القطع لقاعدة البيانات | Add all chunks to database
        if all_chunks:
            try:
                self.vector_db.add(all_chunks)
    
                self.stats["total_documents"] += len([v for v in results.values() if v > 0])
                self.stats["total_chunks"] += len(all_chunks)
    
                logger.info(f"✅ Added {len(all_chunks)} chunks total")
    
            except Exception as e:
                logger.error(f"❌ Error adding chunks to database: {e}")
                raise
            
        return results

    # ------------------------------------------------------------------
    # الاسترجاع | Retrieval
    # ------------------------------------------------------------------

    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None
    ) -> List[Tuple[Any, float]]:
        """
        استرجاع القطع ذات الصلة
        Retrieve relevant chunks

        Args:
            query: استعلام المستخدم | User query
            top_k: تجاوز القيمة الافتراضية لـ top_k | Override default top_k

        Returns:
            قائمة من [(قطعة، درجة)] | List of [(chunk, score)]
        """
        if not query or not query.strip():
            logger.warning("⚠️ Empty query")
            return []

        try:
            k = top_k if top_k is not None else self.config.top_k

            # البحث في قاعدة البيانات | Search database
            results = self.vector_db.search(
                query,
                top_k=k,
                score_threshold=self.config.min_score
            )

            logger.info(f"🔍 Retrieved {len(results)} chunks")

            # إعادة الترتيب إذا كانت مفعّلة | Apply reranking if enabled
            if self.reranker and results:
                results = self.reranker.rerank(query=query, chunks=results)
                logger.info("🔄 Reranking applied | top score=%.3f",
                            results[0][1] if results else 0)

            return results

        except Exception as e:
            logger.error(f"❌ Retrieval error: {e}")
            return []

    # ------------------------------------------------------------------
    # التوليد | Generation
    # ------------------------------------------------------------------

    def generate(
        self,
        query: str,
        include_sources: bool = False,
        language: Optional[str] = None,
        **llm_kwargs
    ) -> str:
        """
        توليد إجابة للاستعلام
        Generate answer for query

        Args:
            query:           استعلام المستخدم | User query
            include_sources: تضمين المصادر في الإجابة | Include sources in answer
            language:        'ar' أو 'en' — يُكشف تلقائياً إذا لم يُحدد | auto-detected if None
            **llm_kwargs:    معاملات إضافية لنموذج اللغة | Additional LLM parameters

        Returns:
            الإجابة | Answer text
        """
        self.stats["total_queries"] += 1

        if not query or not query.strip():
            return "⚠️ Please enter a valid query"

        try:
            # استرجاع القطع ذات الصلة (يشمل reranking تلقائياً إذا كان مفعّلاً)
            # Retrieve relevant chunks (includes reranking automatically if enabled)
            retrieved = self.retrieve(query)

            if not retrieved:
                self.stats["failed_queries"] += 1
                return "❌  No relevant information found"

            # بناء السياق | Build context
            context = self.context_manager.build(query, retrieved)

            # بناء الـ prompt عبر _resolve_prompt (مخصص / Router / افتراضي)
            # Build prompt via _resolve_prompt (custom / Router / default)
            prompt = self._resolve_prompt(query, context, language)

            # توليد الإجابة | Generate answer
            answer = self.llm.generate(prompt, **llm_kwargs)

            # إضافة المصادر إذا طُلب ذلك | Add sources if requested
            if include_sources:
                sources = self._format_sources(retrieved)
                answer = f"{answer}\n\n{sources}"

            self.stats["successful_queries"] += 1
            logger.info("✅ Answer generated successfully")
            return answer

        except Exception as e:
            self.stats["failed_queries"] += 1
            logger.error(f"❌ Generation error: {e}")
            return f"❌ Error generating answer: {e}"

    # ------------------------------------------------------------------
    # دوال مساعدة | Helper methods
    # ------------------------------------------------------------------
    def _detect_language_simple(self, text: str) -> str:
        """كشف بسيط للغة (عربي / إنجليزي)"""
        if any('\u0600' <= c <= '\u06FF' for c in text):
            return "ar"
        return "en"

    def _resolve_prompt(self, query: str, context: str, language: Optional[str] = None) -> str:
        """
        بناء نص الـ prompt النهائي بالأولوية التالية:
        Build the final prompt string with this priority:

        1. prompt مخصص أُعطي في __init__   → custom prompt from __init__
        2. PromptRouter (إذا لم يوجد مخصص) → PromptRouter (if no custom)
        3. _build_prompt الافتراضي          → built-in _build_prompt fallback

        Args:
            query:    استعلام المستخدم | User query
            context:  السياق المسترجع  | Retrieved context
            language: 'ar' | 'en' | None (auto)

        Returns:
            نص الـ prompt الجاهز للإرسال لنموذج اللغة
            Ready prompt string for the language model
        """
        # ── 1. prompt مخصص ──────────────────────────────────────────────
        if self._custom_prompt is not None:
            cp = self._custom_prompt

            # 1a. PromptTemplate أو أي كائن له .format
            if hasattr(cp, "format"):
                try:
                    return cp.format(context=context, question=query)
                except (KeyError, TypeError):
                    # fallback: جرّب بدون question (بعض القوالب تستخدم query)
                    return cp.format(context=context, query=query)

            # 1b. Callable (context, question) -> str
            if callable(cp):
                return cp(context, query)

            # 1c. نص ثابت فيه {context} و {question}
            if isinstance(cp, str):
                return cp.format(context=context, question=query)

            logger.warning("⚠️ Unknown prompt type: %s — falling back to default", type(cp))

        # ── 2. PromptRouter ──────────────────────────────────────────────
        if self.prompt_router:
            lang = language or None
            prompt = self.prompt_router.build(query=query, context=context, language=lang)
            detected_lang = self.prompt_router.detect_language(query) if lang is None else lang
            q_type = self.prompt_router.detect_question_type(query, detected_lang)
            logger.info("🧭 Prompt routed | lang=%s | type=%s", detected_lang, q_type.value)
            return prompt

        # ── 3. الافتراضي المدمج ─────────────────────────────────────────
        lang = language or self._detect_language_simple(query)
        return self._build_prompt(query, context, language_pr=lang)

    def set_prompt(self, prompt: Optional[PromptInput]) -> None:
        """
        تغيير أو حذف الـ Prompt المخصص بعد الإنشاء
        Change or remove the custom prompt after initialization

        Args:
            prompt: القالب الجديد (PromptTemplate / callable / str) أو None للعودة للافتراضي
                    New template (PromptTemplate / callable / str) or None to restore default

        Examples:
            # تغيير الـ prompt | Change prompt
            rag.set_prompt(my_template)

            # العودة للـ PromptRouter / الافتراضي | Restore Router / default
            rag.set_prompt(None)
        """
        self._custom_prompt = prompt

        # أعد تفعيل Router إذا أُزيل الـ prompt المخصص
        # Re-enable Router if custom prompt is removed
        if prompt is None and self.config.enable_prompt_routing:
            self.prompt_router = PromptRouter(
                include_few_shot=self.config.include_few_shot
            )
            logger.info("🔄 Custom prompt removed — PromptRouter restored")
        else:
            self.prompt_router = None
            logger.info("✅ Custom prompt set: %s", type(prompt).__name__)

    def _build_prompt(self, query: str, context: str, language_pr: str) -> str:
        """
        بناء الـ prompt لنموذج اللغة (واعي باللغة)
        Build prompt for language model (language-aware)

        Args:
            query: الاستعلام | Query
            context: السياق | Context

        Returns:
            الـ prompt | Prompt text
        """
        # كشف لغة السؤال | Detect question language
        
        if language_pr== 'ar':
            # Prompt بالعربية فقط | Arabic-only prompt
            return f"""أنت مساعد ذكي متخصص في الإجابة على الأسئلة بدقة.
                        استخدم المعلومات التالية للإجابة على السؤال بدقة ووضوح.
                        القواعد المهمة:
                        • أجب بناءً على المعلومات المقدمة فقط
                        • كن دقيقاً ومختصراً
                        .لا تكمل ولا تشرح ولا تستنتج
                        .اذا وجدت الملعومه في المستند اجب بنائا عليها اذا لم تجدها قل لاتوجد معلومات كافيه
                        • إذا لم تجد المعلومات الكافية، قل "لا توجد معلومات كافية للإجابة"
                        • اجب بنفس اللغه القادمه من السوال 
                        ."لمساعدتك Fennec-RAG لو سئلك علي اسمك قلو انا "مساعد شخصي متطور من قبل  
                        المعلومات المتاحة:
                        {context}
                        السؤال: {query}
                        الإجابة:"""
        
        else:
            # Prompt بالإنجليزية فقط | English-only prompt
            return f"""You are an intelligent assistant specialized in answering questions accurately.

                    Use the following information to answer the question accurately and clearly.
                    Important rules:
                    • Answer based only on the provided information
                    • Be accurate and concise
                    • If information is insufficient, say "Insufficient information to answer"
                    • • Answer same query language 
                    . if ask you about your name say "i'm ai assistant for you from Fennec-RAG"
                    Available Information:
                    {context}
                    Question: {query}
                    Answer:"""
        
    def _format_sources(
        self,
        chunks: List[Tuple[Any, float]],
        max_sources: int = 3
    ) -> str:
        """
        تنسيق المصادر للعرض
        Format sources for display

        Args:
            chunks: قائمة القطع مع الدرجات | List of chunks with scores
            max_sources: أقصى عدد مصادر | Maximum number of sources

        Returns:
            المصادر المنسقة | Formatted sources
        """
        seen = set()
        sources = []

        for chunk, score in chunks:
            # الحصول على معرف المستند | Get document ID
            doc_id = getattr(chunk, "doc_id", None) or getattr(chunk, "document_id", "unknown")
            
            if doc_id in seen:
                continue

            seen.add(doc_id)
            sources.append(f"• {doc_id} score: {score:.2f})")

            if len(sources) >= max_sources:
                break

        if sources:
            return "📚 Sources:\n" + "\n".join(sources)
        else:
            return ""

    # ------------------------------------------------------------------
    # الصيانة | Maintenance
    # ------------------------------------------------------------------

    def remove_document(self, doc_id: str) -> int:
        """
        حذف مستند من النظام
        Remove a document from the system

        Args:
            doc_id: معرف المستند | Document ID

        Returns:
            عدد القطع المحذوفة | Number of chunks removed
        """
        try:
            removed = self.vector_db.remove_by_doc_id(doc_id)

            if removed > 0:
                self.stats["total_documents"] -= 1
                self.stats["total_chunks"] -= removed
                logger.info(
                           f"🗑️ Removed {removed} chunks from document {doc_id}")

            return removed

        except Exception as e:
            logger.error(f"❌Remove error: {e}")
            return 0

    def save(self, path: str) -> None:
        """
        حفظ النظام
        Save the system

        Args:
            path: مسار الحفظ | Save path
        """
        try:
            path = Path(path)
            path.mkdir(parents=True, exist_ok=True)

            # حفظ قاعدة البيانات | Save database
            self.vector_db.save(path / "vector_db")

            # حفظ الإحصائيات | Save statistics
            with open(path / "stats.json", "w", encoding="utf-8") as f:
                json.dump(self.stats, f, indent=2, ensure_ascii=False)

            logger.info(f"💾 RAG system saved to: {path}")

        except Exception as e:
            logger.error(f"❌Save error: {e}")
            raise

    @classmethod
    def load(
        cls,
        path: str,
        vector_db: Any,
        llm: Any,
        chunker: Any,
        context_manager: Any,
        config: Optional[RAGConfig] = None
    ) -> "RAGSystem":
        """
        تحميل نظام محفوظ
        Load a saved system

        Args:
            path: مسار التحميل | Load path
            vector_db: قاعدة البيانات المتجهة | Vector database
            llm: نموذج اللغة | Language model
            chunker: محلل النصوص | Text chunker
            context_manager: مدير السياق | Context manager
            config: الإعدادات | Configuration

        Returns:
            النظام المحمل | Loaded system
        """
        try:
            path = Path(path)

            if not path.exists():
                raise FileNotFoundError(f"❌ Path doesn't exist: {path}")

            # تحميل قاعدة البيانات | Load database
            vector_db.load(path / "vector_db")

            # إنشاء النظام | Create system
            system = cls(
                vector_db=vector_db,
                llm=llm,
                chunker=chunker,
                context_manager=context_manager,
                config=config
            )

            # تحميل الإحصائيات | Load statistics
            stats_file = path / "stats.json"
            if stats_file.exists():
                with open(stats_file, "r", encoding="utf-8") as f:
                    system.stats.update(json.load(f))

            logger.info(f"📂 RAG system loaded from: {path}")
            return system

        except Exception as e:
            logger.error(f"❌ Load error: {e}")
            raise

    def get_stats(self) -> Dict[str, Any]:
        """
        الحصول على إحصائيات النظام
        Get system statistics

        Returns:
            قاموس الإحصائيات | Statistics dictionary
        """
        base_stats = super().get_stats()
        
        # إضافة معلومات إضافية | Add additional information
        stats = {
            **base_stats,
            "vector_db_size": getattr(self.vector_db, "size", 0),
            "llm_available": self.llm is not None,
            "chunker_type": type(self.chunker).__name__,
        }

        return stats

    def cleanup(self) -> None:
        """
        تنظيف الموارد
        Clean up resources
        """
        components = [
            ("vector_db", self.vector_db),
            ("llm", self.llm),
            ("chunker", self.chunker),
            ("context_manager", self.context_manager)
        ]

        for name, component in components:
            if hasattr(component, "cleanup"):
                try:
                    component.cleanup()
                    logger.info(f"🧹 Cleaned up {name}")
                except Exception as e:
                    logger.error(f"❌ Error cleaning up {name}: {e}")

        logger.info("🧹 RAG system cleaned up")

    def __enter__(self):
        """دعم context manager | Support context manager"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """تنظيف تلقائي عند الخروج | Automatic cleanup on exit"""
        self.cleanup()
        return False

    # ── Async API (native implementations) ──────────────────────────

    async def aadd_documents(self, docs: Dict[str, str]) -> Dict[str, int]:
        """
        إضافة مستندات بشكل غير متزامن — تعالج chunking وإضافة vectors بالتوازي.
        Async document ingestion — chunks and adds vectors concurrently.
        """
        import asyncio
        if not docs:
            return {}

        results: Dict[str, int] = {}
        all_chunks = []

        # chunk all docs concurrently
        async def _chunk_one(doc_id: str, text: str):
            if not text or not text.strip():
                return doc_id, []
            try:
                fn = (self.chunker.chunk_text if hasattr(self.chunker, "chunk_text")
                      else self.chunker.chunk)
                chunks = await asyncio.to_thread(fn, text, doc_id)
                return doc_id, chunks
            except Exception as e:
                logger.error(f"❌ Error chunking {doc_id}: {e}")
                return doc_id, []

        chunk_results = await asyncio.gather(*[
            _chunk_one(did, txt) for did, txt in docs.items()
        ])

        for doc_id, chunks in chunk_results:
            results[doc_id] = len(chunks)
            all_chunks.extend(chunks)

        if all_chunks:
            # Use async add if vector_db supports it
            if hasattr(self.vector_db, "aadd"):
                await self.vector_db.aadd(all_chunks)
            else:
                await asyncio.to_thread(self.vector_db.add, all_chunks)
            self.stats["total_documents"] += len([v for v in results.values() if v > 0])
            self.stats["total_chunks"] += len(all_chunks)

        return results

    async def aretrieve(self, query: str, top_k=None) -> List[Tuple]:
        """استرجاع القطع بشكل غير متزامن | Async retrieval."""
        import asyncio
        if not query or not query.strip():
            return []
        k = top_k if top_k is not None else self.config.top_k
        # Use async search if available
        if hasattr(self.vector_db, "asearch"):
            results = await self.vector_db.asearch(
                query, top_k=k, score_threshold=self.config.min_score
            )
        else:
            results = await asyncio.to_thread(
                self.vector_db.search, query, top_k=k, score_threshold=self.config.min_score
            )
        if self.reranker and results:
            results = await asyncio.to_thread(self.reranker.rerank, query=query, chunks=results)
        return results

    async def agenerate(self, query: str, include_sources: bool = False,
                    language=None, **llm_kwargs) -> str:
        """توليد إجابة بشكل غير متزامن | Async answer generation."""
        import asyncio
        self.stats["total_queries"] += 1
        if not query or not query.strip():
            return "⚠️ Please enter a valid query"
        try:
            retrieved = await self.aretrieve(query)
            if not retrieved:
                self.stats["failed_queries"] += 1
                return "❌ No relevant information found"

            context = await asyncio.to_thread(self.context_manager.build, query, retrieved)

            prompt = await asyncio.to_thread(
                self._resolve_prompt, query, context, language
            )

            if hasattr(self.llm, "generate_async"):
                answer = await self.llm.generate_async(prompt, **llm_kwargs)
            else:
                answer = await asyncio.to_thread(self.llm.generate, prompt, **llm_kwargs)

            if include_sources:
                sources = self._format_sources(retrieved)
                answer = f"{answer}\n\n{sources}"

            self.stats["successful_queries"] += 1
            return answer

        except Exception as e:
            self.stats["failed_queries"] += 1
            logger.error(f"❌ Async generation error: {e}")
            return f"❌ Error generating answer: {e}"


    async def astream(self, query: str, language=None, **llm_kwargs):
        import asyncio
        import inspect
    
        retrieved = await self.aretrieve(query)
        if not retrieved:
            yield "❌ No relevant information found"
            return
    
        context = await asyncio.to_thread(self.context_manager.build, query, retrieved)

        prompt = await asyncio.to_thread(
            self._resolve_prompt, query, context, language
        )
    
        result = self.llm.astream(prompt, **llm_kwargs)
    
        if inspect.isasyncgen(result):
            async for token in result:
                yield token
        elif inspect.iscoroutine(result):
            actual = await result
            if inspect.isasyncgen(actual):
                async for token in actual:
                    yield token
            elif hasattr(actual, "__aiter__"):
                async for token in actual:
                    yield token
            elif isinstance(actual, str):
                for word in actual.split():
                    yield word + " "
                    await asyncio.sleep(0)
            else:
                yield str(actual)
        elif hasattr(result, "__iter__"):
            for token in result:
                yield str(token)
                await asyncio.sleep(0)
        else:
            yield str(result)
            
    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
        return False

    def __repr__(self) -> str:
        """تمثيل نصي للنظام | String representation"""
        return (
            f"RAGSystem("
            f"docs={self.stats.get('total_documents', 0)}, "
            f"chunks={self.stats.get('total_chunks', 0)}, "
            f"queries={self.stats.get('total_queries', 0)})"
        )