from dataclasses import dataclass, field


@dataclass
class SearchConfig:
    """
    إعدادات البحث الهجين
    Hybrid search configuration
    """
    semantic_weight: float = 0.7       # وزن البحث الدلالي | Semantic search weight
    keyword_weight: float = 0.3        # وزن البحث النصي | Keyword search weight
    min_score: float = 0.3             # الحد الأدنى للدرجة — نتائج دون هذا الحد تُحذف | Minimum score threshold
    top_k: int = 10                    # عدد النتائج | Number of results
    enable_reranking: bool = True      # إعادة الترتيب | Enable reranking
    fusion_method: str = 'weighted_sum'  # طريقة الدمج | Fusion method
                                         # Options: 'weighted_sum', 'rrf', 'max'