
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
from typing import Any, Dict, List, Optional
from .self_improving_rag import LLMCallError, RetrievalError, _call_llm, _retrieve_safe, _deduplicate
from .self_rag_dataclass import HyDEResult

logger = logging.getLogger(__name__)


class HyDERAG:
    """
    HyDE RAG – Hypothetical Document Embeddings.

    Generates *num_hypothetical_docs* synthetic documents that would answer
    the query, retrieves real documents using each synthetic doc as a search
    query, deduplicates, re-ranks, and generates a final answer.

    Hypothetical docs are generated in parallel to reduce latency.

    Example::

        hyde = HyDERAG(rag_system, llm, num_hypothetical_docs=3)
        result = hyde.query("ما هي فوائد الرياضة؟")
        print(result.answer)
    """

    _HYPO_PROMPT = (
        "Write a detailed, factual paragraph that would perfectly answer the question below.\n"
        "Do not reference the question; write as if you are an expert writing a knowledge-base article.\n\n"
        "Question: {query}\n\nParagraph:"
    )

    def __init__(
        self,
        rag_system: Any,
        llm: Any,
        num_hypothetical_docs: int = 3,
        use_original_query: bool = True,
        top_k: int = 5,
        max_final_docs: int = 10,
        llm_retries: int = 2,
        max_workers: int = 4,
    ) -> None:
        if not llm:
            raise ValueError("HyDERAG requires an LLM.")
        self.rag_system = rag_system
        self.llm = llm
        self.num_hypothetical_docs = num_hypothetical_docs
        self.use_original_query = use_original_query
        self.top_k = top_k
        self.max_final_docs = max_final_docs
        self.llm_retries = llm_retries
        self.max_workers = max_workers

    def query(self, query: str, context: Optional[Dict[str, Any]] = None) -> HyDEResult:
        """
        Run the HyDE retrieval pipeline.\n
        تشغيل الاسترجاع

        Returns:
            :class:`HyDEResult` with answer and retrieval statistics.
        """
        logger.info("💭 HyDERAG | query=%r", query[:80])

        # 1. Generate hypothetical docs in parallel
        hypo_docs = self._generate_hypothetical_docs_parallel(query)
        logger.info("  Generated %d hypothetical docs", len(hypo_docs))

        # 2. Retrieve from each hypothetical doc + original query
        search_queries: List[str] = list(hypo_docs)
        if self.use_original_query:
            search_queries.insert(0, query)

        all_retrieved: List[Dict[str, Any]] = []
        for sq in search_queries:
            try:
                all_retrieved.extend(_retrieve_safe(self.rag_system, sq, top_k=self.top_k))
            except RetrievalError as exc:
                logger.warning("  Retrieval skipped for one query: %s", exc)

        # 3. Deduplicate & re-rank
        unique = _deduplicate(all_retrieved)
        ranked = sorted(unique, key=lambda d: d.get("score", 0.0), reverse=True)[: self.max_final_docs]
        logger.info(
            "  Retrieved %d → unique %d → ranked %d",
            len(all_retrieved), len(unique), len(ranked),
        )

        # 4. Generate answer
        answer = self._generate(query, ranked)

        return HyDEResult(
            answer=answer,
            hypothetical_docs=hypo_docs,
            num_retrieved=len(unique),
            num_ranked=len(ranked),
        )

    def add_document(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> Any:
        return self.rag_system.add_document(text, metadata if metadata is not None else {})

    # ── Private Helpers ───────────────────────────────────────────────────

    def _generate_hypothetical_docs_parallel(self, query: str) -> List[str]:
        """Generate all hypothetical docs concurrently."""
        prompt = self._HYPO_PROMPT.format(query=query)

        def _generate_one(_: int) -> Optional[str]:
            try:
                result = _call_llm(self.llm, prompt, retries=self.llm_retries)
                return result if len(result) > 40 else None
            except LLMCallError as exc:
                logger.warning("  Hypothetical doc generation failed: %s", exc)
                return None

        docs: List[str] = []
        with ThreadPoolExecutor(
            max_workers=min(self.max_workers, self.num_hypothetical_docs)
        ) as pool:
            futures = {pool.submit(_generate_one, i): i for i in range(self.num_hypothetical_docs)}
            for future in as_completed(futures):
                result = future.result()
                if result:
                    docs.append(result)

        return docs

    def _generate(self, query: str, docs: List[Dict[str, Any]]) -> str:
        """Build prompt directly from retrieved docs."""
        if not docs:
            return "There is insufficient information."

        context = "\n\n".join(
            d.get("text", "")
            for d in docs[:5]
            if d.get("text")
        )

        prompt = (
            "أنت مساعد ذكي متخصص في الإجابة على الأسئلة بدقة.\n\n"
            "استخدم المعلومات التالية للإجابة على السؤال بدقة ووضوح.\n\n"
            "القواعد المهمة:\n"
            "• أجب بناءً على المعلومات المقدمة فقط\n"
            "• كن دقيقاً ومختصراً\n"
            "• إذا لم تجد المعلومات الكافية، قل \"لا توجد معلومات كافية للإجابة\"\n"
            "• أجب بنفس اللغه الموجوده في السؤال\n\n"
            f"المعلومات المتاحة:\n{context}\n\n"
            f"السؤال: {query}\n"
            "الإجابة:"
        )

        try:
            return _call_llm(self.llm, prompt, retries=self.llm_retries)
        except LLMCallError as exc:
            logger.error("❌ Generation error: %s", exc)
            return "error in generating answer"