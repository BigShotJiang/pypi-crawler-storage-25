from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


@dataclass
class ConversationTurn:
    """
    دورة واحدة من المحادثة\n
    One turn of conversation
    """
    query: str                          # السؤال | Question
    answer: str                         # الإجابة | Answer
    timestamp: datetime                 # الطابع الزمني | Timestamp
    chunks: Optional[List] = None       # القطع المسترجعة | Retrieved chunks
    retrieved_chunks: int = 0           # عدد القطع المسترجعة | Number of retrieved chunks
    
    def __str__(self) -> str:
        """تحويل إلى نص قابل للقراءة | Convert to readable text"""
        return f"Question: {self.query}\nAnswer: {self.answer}"
    
    def to_dict(self) -> dict:
        """تحويل إلى dict للحفظ في JSON | Convert to dict for saving in JSON"""
        return {
            'query': self.query,
            'answer': self.answer,
            'timestamp': self.timestamp.isoformat(),
            'retrieved_chunks': self.retrieved_chunks
            # NOTE: حقل chunks لا يُحفظ لأنه يحتوي على كائنات غير قابلة للتسلسل
            # chunks field is not saved as it contains non-serializable objects
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ConversationTurn':
        """إنشاء من dict عند القراءة من JSON | Create from dict when reading from JSON"""
        return cls(
            query=data['query'],
            answer=data['answer'],
            timestamp=datetime.fromisoformat(data['timestamp']),
            chunks=None,  # لا يُعاد تحميلها من الملف | Not restored from file
            retrieved_chunks=data.get('retrieved_chunks', 0)
        )