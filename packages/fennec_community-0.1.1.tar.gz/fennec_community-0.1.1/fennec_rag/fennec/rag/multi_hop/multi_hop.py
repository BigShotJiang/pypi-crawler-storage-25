import logging
from typing import List, Tuple, Optional, Set, Dict, Any
from .query_decomposer import QueryDecomposer
from .multihop_strategy import HopStrategy
from .multihop_dataclass import HopResult, ReasoningState



logger = logging.getLogger(__name__)

class MultiHopRAG:

    def __init__(self,
                 rag_system,
                 max_hops: int = 3,                  # عدد القفزات المسموح بها | Max allowed hops
                 min_score_threshold: float = 0.3,   # الحد الأدنى لدرجة القطع المقبولة | Minimum acceptable chunk score
                 enable_query_decomposition: bool = True,  # تمكين تحليل السؤال إلى استعلامات فرعية | Enable question decomposition into sub-queries
                 use_stanza_ner: bool = True,            
                 language: str = 'ar',
                 confidence_threshold: float = 0.75):  # لو النظام واثق من الاجابه بنسيه 75 في الميه يعمل early stop ويوفر hops
        if rag_system is None:
            raise ValueError("rag_system is required")

        self.rag = rag_system
        self.max_hops = max_hops
        self.min_score_threshold = min_score_threshold
        self.enable_decomposition = enable_query_decomposition
        self.confidence_threshold = confidence_threshold

        self.decomposer = QueryDecomposer(
            use_stanza=use_stanza_ner,
            language=language
        )

        self.stats = {
            'total_queries': 0,
            'average_hops': 0,
            'decomposed_queries': 0,
            'entities_extracted': 0,
            'early_stops': 0,                           # توقف مبكر لاكتمال الإجابة
            'stanza_enabled': self.decomposer.nlp is not None
        }

        logger.info("✓ Reasoning-Guided Multi-Hop RAG Is Ready")

    # =========================================================================
    # الواجهة الرئيسية | Main Interface
    # =========================================================================

    def query(self, question: str,
              hops: Optional[int] = None,
              return_intermediate: bool = False):
        if not question or not question.strip():
            return "Please enter a valid question"

        self.stats['total_queries'] += 1
        num_hops = hops or self.max_hops

        try:
            # 1. تحليل السؤال إلى متطلبات معرفية
            #    Analyze question into knowledge requirements
            knowledge_requirements = self._analyze_question_requirements(question)

            # 2. تحضير الاستعلامات
            sub_queries = self._prepare_queries(question)

            # 3. تنفيذ القفزات الموجّهة بالتفكير
            hop_results, reasoning_state = self._perform_reasoning_hops(
                question, sub_queries, num_hops, knowledge_requirements
            )

            # 4. تجميع النتائج
            all_chunks = self._aggregate_chunks(hop_results)

            # 5. توليد إجابة مع سلسلة التفكير
            answer = self._generate_reasoned_answer(
                question, all_chunks, hop_results, reasoning_state
            )

            self._update_stats(len(hop_results))

            if return_intermediate:
                return {
                    'answer': answer,
                    'reasoning_chain': reasoning_state.reasoning_chain,
                    'hops': [self._format_hop_result(hr) for hr in hop_results],
                    'knowledge_state': {
                        'known_facts': reasoning_state.known_facts,
                        'missing_info': reasoning_state.missing_info,
                        'confidence': reasoning_state.confidence
                    },
                    'total_chunks': len(all_chunks),
                    'stats': self.get_stats()
                }

            return answer

        except Exception as e:
            logger.error(f"Erro in Reasoning-Guided Query: {e}")
            return f" Error: {str(e)}"

    # =========================================================================
    # تحليل متطلبات السؤال | Question Requirements Analysis
    # =========================================================================

    def _analyze_question_requirements(self, question: str) -> Dict[str, Any]:
        """
        يحلل السؤال لتحديد:
        - نوع السؤال (مقارنة / سببية / وصفية / زمنية)
        - المعلومات المطلوبة لإجابة كاملة
        - استراتيجية البحث المناسبة
        
        Analyzes the question to determine:
        - Question type (comparison / causal / descriptive / temporal)
        - Information needed for complete answer
        - Appropriate search strategy
        """
        question_lower = question.lower()

        # تحديد نوع السؤال | Determine question type
        q_type = self._classify_question_type(question_lower)

        # استخراج المتطلبات المعرفية | Extract knowledge requirements
        requirements = {
            'type': q_type,
            'needs_comparison': any(w in question_lower for w in
                                    ['مقارنة', 'الفرق', 'أفضل', 'compare', 'difference', 'better']),
            'needs_causality': any(w in question_lower for w in
                                   ['لماذا', 'سبب', 'نتيجة', 'why', 'cause', 'because', 'result']),
            'needs_timeline': any(w in question_lower for w in
                                  ['متى', 'تاريخ', 'when', 'date', 'history', 'بعد', 'قبل']),
            'needs_multi_entity': any(w in question_lower for w in
                                      ['و', 'مع', 'كلا', 'and', 'both', 'all']),
            'entities': self.decomposer.extract_entities(question),
            'missing_slots': []   # سيُملأ تدريجياً | Will be filled progressively
        }

        logger.info(f"Question requirements: {q_type}, "
                    f"entities={requirements['entities']}")
        return requirements

    def _classify_question_type(self, question_lower: str) -> str:
        if any(w in question_lower for w in ['مقارنة', 'الفرق', 'compare', 'vs', 'difference']):
            return 'comparison'
        if any(w in question_lower for w in ['لماذا', 'سبب', 'why', 'cause']):
            return 'causal'
        if any(w in question_lower for w in ['متى', 'تاريخ', 'when', 'date']):
            return 'temporal'
        if any(w in question_lower for w in ['كيف', 'how']):
            return 'procedural'
        return 'factual'

    # =========================================================================
    # القفزات الموجّهة بالتفكير | Reasoning-Guided Hops
    # =========================================================================

    def _perform_reasoning_hops(self,
                                 original_question: str,
                                 queries: List[str],
                                 num_hops: int,
                                 requirements: Dict) -> Tuple[List[HopResult], ReasoningState]:
        """
        ينفذ القفزات مع تتبع حالة التفكير في كل خطوة.
        
        الفرق الجوهري: كل قفزة تسأل نفسها:
        "ما الذي أعرفه الآن؟ وما الذي لا أزال بحاجة إليه؟"
        
        Executes hops while tracking reasoning state at each step.
        Each hop asks: "What do I know now? What do I still need?"
        """
        hop_results: List[HopResult] = []
        seen_chunks: Set[str] = set()
        reasoning_state = ReasoningState()
        current_query = queries[0]
        current_strategy = self._select_initial_strategy(requirements)

        for hop in range(num_hops):
            logger.info(f"hope {hop+1}/{num_hops} | "
                        f"Strategy: {current_strategy.value} | Query: {current_query}")

            # البحث | Search
            chunks = self.rag.retrieve(current_query)
            filtered_chunks = self._filter_chunks(chunks, seen_chunks)

            if not filtered_chunks:
                logger.warning(f"No new results in hop {hop+1}")
                break

            # استخراج الكيانات والحقائق | Extract entities and facts
            entities = self._extract_entities_from_chunks(filtered_chunks)
            facts = self._extract_facts_from_chunks(filtered_chunks, original_question)

            # تحديث حالة التفكير | Update reasoning state
            reasoning_step = self._update_reasoning_state(
                reasoning_state, facts, entities,
                current_query, requirements, hop
            )

            # حفظ نتيجة القفزة | Save hop result
            hop_result = HopResult(
                query=current_query,
                chunks=filtered_chunks,
                hop_number=hop + 1,
                extracted_entities=entities,
                strategy=current_strategy,
                reasoning_step=reasoning_step,
                gap_filled=reasoning_state.missing_info[0] if reasoning_state.missing_info else None
            )
            hop_results.append(hop_result)

            # ===== التوقف المبكر الذكي | Smart Early Stopping =====
            # إذا وصلنا لمستوى ثقة كافٍ، نتوقف ولا نكمل القفزات
            if reasoning_state.answer_complete:
                logger.info(
                            f"Answer complete at hop {hop+1} "
                            f"(confidence={reasoning_state.confidence:.2f})")
                self.stats['early_stops'] += 1
                break

            # تحضير القفزة التالية | Prepare next hop
            if hop < num_hops - 1:
                current_query, current_strategy = self._plan_next_hop(
                    original_question, queries, hop,
                    reasoning_state, entities, requirements
                )
                if not current_query:
                    break

        return hop_results, reasoning_state

    def _update_reasoning_state(self,
                                 state: ReasoningState,
                                 facts: List[str],
                                 entities: List[str],
                                 query: str,
                                 requirements: Dict,
                                 hop_num: int) -> str:
        """
        يحدّث ما يعرفه النظام وما لا يزال يبحث عنه.
        Updates what the system knows and what it's still looking for.
        """
        # إضافة الحقائق الجديدة | Add new facts
        for fact in facts:
            if fact not in state.known_facts:
                state.known_facts.append(fact)

        # تقييم الفجوات المعرفية | Evaluate knowledge gaps
        state.missing_info = self._identify_missing_info(
            requirements, state.known_facts, entities
        )

        # حساب الثقة | Calculate confidence
        state.confidence = self._calculate_confidence(
            requirements, state.known_facts, state.missing_info
        )

        # بناء خطوة التفكير | Build reasoning step
        reasoning_step = (
            f"hops {hop_num+1}:  looking for: '{query}'. "
            f"founds {len(facts)} new facts. "
            f" confidence score: {state.confidence:.0%}. "
            f"missing information: {', '.join(state.missing_info[:2]) or ' no thing'}."
        )
        state.reasoning_chain.append(reasoning_step)

        # تحديد اكتمال الإجابة | Determine answer completeness
        state.answer_complete = (
                            (state.confidence >= self.confidence_threshold and len(state.known_facts) > 0)
                            or (len(state.missing_info) == 0 and len(state.known_facts) > 0)
                                )

        logger.debug(reasoning_step)
        return reasoning_step

    # =========================================================================
    # تخطيط القفزة التالية | Next Hop Planning
    # =========================================================================

    def _plan_next_hop(self,
                        original_question: str,
                        queries: List[str],
                        current_hop: int,
                        state: ReasoningState,
                        entities: List[str],
                        requirements: Dict) -> Tuple[Optional[str], HopStrategy]:
        """
        يقرر ما يجب البحث عنه في القفزة التالية بناءً على:
        - ما تم اكتشافه حتى الآن
        - ما لا يزال مفقوداً
        - نوع السؤال الأصلي
        
        Decides what to search for next based on:
        - What has been discovered so far
        - What is still missing
        - Original question type
        """
        # أولاً: استخدم الاستعلامات الفرعية المحددة مسبقاً إن وجدت
        # First: use predefined sub-queries if available
        if current_hop + 1 < len(queries):
            return queries[current_hop + 1], HopStrategy.ENTITY_EXPANSION

        # ثانياً: إذا كانت هناك فجوات معرفية واضحة، ابحث عنها مباشرة
        # Second: if there are clear knowledge gaps, search for them directly
        if state.missing_info:
            gap_query = self._build_gap_filling_query(
                state.missing_info[0], entities, original_question
            )
            logger.info(f"→ Gap-filling hop: {gap_query}")
            return gap_query, HopStrategy.CLARIFICATION

        # ثالثاً: إذا كان السؤال مقارنة وعندنا كيان واحد فقط، ابحث عن الآخر
        # Third: comparison question with only one entity found
        if requirements.get('needs_comparison') and len(state.known_facts) > 0:
            req_entities = requirements.get('entities', [])
            found_entities = self._entities_covered(req_entities, state.known_facts)
            missing_entities = [e for e in req_entities if e not in found_entities]
            if missing_entities:
                comp_query = f"{missing_entities[0]} {original_question}"
                logger.info(f"→ Comparison hop: {comp_query}")
                return comp_query, HopStrategy.RELATION_BRIDGING

        # رابعاً: تعمّق في أهم كيان مكتشف
        # Fourth: dive deeper into most important discovered entity
        if entities:
            bridge_query = self._build_bridge_query(
                original_question, entities, state.known_facts
            )
            logger.info(f"→ Bridge hop: {bridge_query}")
            return bridge_query, HopStrategy.RELATION_BRIDGING

        logger.warning("Cannot plan next hop")
        return None, HopStrategy.ENTITY_EXPANSION

    def _build_gap_filling_query(self, gap: str,
                                  entities: List[str],
                                  original_question: str) -> str:
        """
        يبني استعلاماً مستهدفاً لملء فجوة معرفية محددة.
        Builds a targeted query to fill a specific knowledge gap.
        """
        # دمج الفجوة مع أهم كيان مكتشف
        if entities:
            return f"{entities[0]} {gap}"
        return f"{gap} {original_question}"

    def _build_bridge_query(self, original_question: str,
                             entities: List[str],
                             known_facts: List[str]) -> str:
        """
        يبني استعلام جسر يربط بين ما تعلمناه والسؤال الأصلي.
        Builds a bridging query connecting what we learned to the original question.
        """
        if not entities:
            return original_question

        # استخدم الكيان الأهم مع السؤال الأصلي
        main_entity = entities[0]

        # إذا كان عندنا حقائق، حاول توليد استعلام أكثر تحديداً
        if known_facts:
            # خذ آخر حقيقة مكتشفة كنقطة انطلاق
            last_fact = known_facts[-1]
            # أخذ أول 50 حرف من الحقيقة كسياق
            fact_context = last_fact[:50] if len(last_fact) > 50 else last_fact
            return f"{main_entity} {fact_context}"

        return f"{main_entity} {original_question}"

    # =========================================================================
    # تقييم الحالة المعرفية | Knowledge State Evaluation
    # =========================================================================

    def _extract_facts_from_chunks(self, chunks, question):
       question_entities = self.decomposer.extract_entities(question)
       facts = []

       for chunk, score in chunks[:5]:
           text = self._safe_attr(chunk, 'text', '')
           if not text:
               continue

           sentences = [s.strip() for s in text.replace('،', '.').split('.')
                        if len(s.strip()) > 10]

           for sentence in sentences:
               sentence_lower = sentence.lower()

               is_relevant = (
                   any(entity.lower() in sentence_lower for entity in question_entities)
                   or any(word in sentence_lower for word in question.split())
                   or score > 0.3
               )

               if is_relevant and sentence not in facts:
                   facts.append(sentence)

       return facts[:10]

    def _identify_missing_info(self, requirements: Dict,
                                known_facts: List[str],
                                entities: List[str]) -> List[str]:
        """
        يحدد ما لا يزال مفقوداً بناءً على متطلبات السؤال.
        Identifies what is still missing based on question requirements.
        """
        missing = []
        known_text = ' '.join(known_facts).lower()

        if requirements.get('needs_causality'):
            has_cause = any(w in known_text for w in
                            ['لأن', 'بسبب', 'نتيجة', 'because', 'due to', 'caused'])
            if not has_cause:
                missing.append('causal relationship')

        if requirements.get('needs_timeline'):
            has_date = any(char.isdigit() for char in known_text)
            if not has_date:
                missing.append('specific date or time')

        if requirements.get('needs_comparison'):
            req_entities = requirements.get('entities', [])
            if len(req_entities) >= 2:
                for entity in req_entities:
                    if entity.lower() not in known_text:
                        missing.append(f'info about {entity}')

        return missing

    def _calculate_confidence(self, requirements: Dict,
                               known_facts: List[str],
                               missing_info: List[str]) -> float:
        """
        يحسب مستوى الثقة بأن الإجابة اكتملت.
        Calculates confidence that the answer is complete.
        """
        if not known_facts:
            return 0.0

        # الإصلاح: رُفع الحد من 0.6 إلى 0.85 حتى يمكن تجاوز عتبة الثقة (0.75)
        # Fix: raised ceiling from 0.6 → 0.85 so confidence can exceed the
        # 0.75 threshold and trigger early stopping properly.
        base_confidence = min(len(known_facts) / 5.0, 0.85)
        gap_penalty = len(missing_info) * 0.15
        confidence = max(0.0, base_confidence - gap_penalty)

        # مكافأة إذا لا توجد فجوات | Bonus if no gaps
        if not missing_info and len(known_facts) >= 3:
            confidence = max(confidence, 0.8)

        return min(confidence, 1.0)

    def _entities_covered(self, required: List[str],
                           known_facts: List[str]) -> List[str]:
        known_text = ' '.join(known_facts).lower()
        return [e for e in required if e.lower() in known_text]

    # =========================================================================
    # توليد الإجابة الموجّهة بالتفكير | Reasoned Answer Generation
    # =========================================================================

    def _generate_reasoned_answer(self, question: str,
                                   chunks: List[Tuple],
                                   hop_results: List[HopResult],
                                   reasoning_state: ReasoningState) -> str:
        if not chunks:
            return "I couldn't find enough information"

        if self.rag.llm is None:
            return "Language model not available"

        try:
            context = self._build_reasoned_context(chunks, hop_results, reasoning_state)
            prompt = self._build_reasoned_prompt(question, context, reasoning_state)
            return self.rag.llm.generate(prompt, max_tokens=512)
        except Exception as e:
            logger.error(f"Answer generation error: {e}")
            return f"error in answer generation: {str(e)}"

    def _build_reasoned_context(self, chunks: List[Tuple],
                                 hop_results: List[HopResult],
                                 state: ReasoningState) -> str:
        parts = []

        # سلسلة التفكير | Reasoning chain
        parts.append("=== Reasoning Chain ===")
        for step in state.reasoning_chain:
            parts.append(f"• {step}")

        # الحقائق المكتشفة | Discovered facts
        if state.known_facts:
            parts.append("\n=== Discovered Facts ===")
            for i, fact in enumerate(state.known_facts[:8], 1):
                parts.append(f"{i}. {fact}")

        # المعلومات المفقودة | Missing information
        if state.missing_info:
            parts.append("\n=== Warning: Missing Info ===")
            for gap in state.missing_info:
                parts.append(f"⚠ {gap}")

        # القطع الداعمة | Supporting chunks
        parts.append("\n=== Supporting Sources ===")
        for i, (chunk, score) in enumerate(chunks[:8], 1):
            doc_id = self._safe_attr(chunk, 'doc_id', 'unknown_doc')
            text   = self._safe_attr(chunk, 'text', '')
            parts.append(f"\n[{i}] (score={score:.2f}) {doc_id}:\n{text}")

        return "\n".join(parts)

    @staticmethod
    def _detect_language(text: str) -> str:
        """
        يكتشف لغة النص بناءً على نسبة الحروف العربية.
        Detects text language based on Arabic character ratio.

        Returns:
            'ar' إذا كانت اللغة عربية، 'en' إذا كانت إنجليزية.
            'ar' if Arabic, 'en' if English.
        """
        if not text:
            return 'ar'
        arabic_chars = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
        return 'ar' if arabic_chars / max(len(text), 1) > 0.2 else 'en'

    def _build_reasoned_prompt(self, question: str,
                                context: str,
                                state: ReasoningState) -> str:
        """
        يبني الـ prompt النهائي مع:
        - منع استرجاع معلومات خارج السياق (grounding صارم)
        - الرد بنفس لغة السؤال تلقائياً

        Builds the final prompt with:
        - Strict grounding (no info outside provided context)
        - Auto-reply in the same language as the question
        """
        lang = self._detect_language(question)

        low_confidence = state.confidence < 0.75
        confidence_note = f"{state.confidence:.0%}" if low_confidence else ""

        # ── Arabic prompt ──────────────────────────────────────────────────
        if lang == 'ar':
            confidence_line = (
                f"\n⚠ تنبيه: مستوى الثقة منخفض ({confidence_note})، "
                f"قد تكون المعلومات غير مكتملة."
            ) if low_confidence else ""

            return f"""أنت نظام إجابة على الأسئلة يعمل وفق منهج التفكير متعدد الخطوات.

                    ## السياق المتاح
                    {context}

                    ## السؤال
                    {question}
                    {confidence_line}

                    ## قواعد صارمة يجب اتباعها
                    1. **أجب فقط بناءً على المعلومات الموجودة في السياق أعلاه.**
                    2. **إذا لم تجد المعلومة في السياق، قل صراحةً: "لا تتوفر هذه المعلومة في السياق المقدم."**
                    3. لا تستنتج أو تُكمّل من معرفتك الخاصة — السياق هو المصدر الوحيد.
                    4. اتبع سلسلة التفكير المقدمة وادمج الحقائق المكتشفة بشكل متماسك.
                    5. رتّب إجابتك من العام إلى الخاص.
                    6.لا تذكر أي أسماء أو أمثلة غير موجودة حرفيًا في السياق
                    7. **أجب باللغة العربية.**

                    ## الإجابة"""

        # ── English prompt ─────────────────────────────────────────────────
        else:
            confidence_line = (
                f"\n⚠ Warning: Low confidence ({confidence_note}). "
                f"Information may be incomplete."
            ) if low_confidence else ""

            return f"""You are a question-answering system using multi-step reasoning.

                        ## Available Context
                        {context}

                        ## Question
                        {question}
                        {confidence_line}

                        ## Strict Rules You Must Follow
                        1. **Answer ONLY based on information found in the context above.**
                        2. **If the information is not in the context, explicitly state: "This information is not available in the provided context."**
                        3. Do not infer or complete answers from your own knowledge — the context is the sole source.
                        4. Follow the provided reasoning chain and integrate discovered facts coherently.
                        5. Structure your answer from general to specific.
                        6.Do not mention any names or examples that are not literally present in the context.
                        7. **Reply in English.**

                        ## Answer"""

    # =========================================================================
    # دوال مساعدة | Helper Methods
    # =========================================================================

    @staticmethod
    def _safe_attr(obj, attr: str, default=None):
        """
        قراءة آمنة لخاصية من كائن — يعيد القيمة الافتراضية بدل AttributeError.
        Safe attribute read — returns default instead of raising AttributeError.
        """
        return getattr(obj, attr, default)

    def _select_initial_strategy(self, requirements: Dict) -> HopStrategy:
        if requirements.get('needs_comparison'):
            return HopStrategy.RELATION_BRIDGING
        if requirements.get('needs_causality'):
            return HopStrategy.CLARIFICATION
        return HopStrategy.ENTITY_EXPANSION

    def _prepare_queries(self, question: str) -> List[str]:
        if self.enable_decomposition:
            sub_queries = self.decomposer.decompose(question)
            if len(sub_queries) > 1:
                self.stats['decomposed_queries'] += 1
            return sub_queries
        return [question]

    def _filter_chunks(self, chunks: List[Tuple],
                        seen_chunks: Set[str]) -> List[Tuple]:
        filtered = []
        for item in chunks:
            # دعم صيغة (chunk, score) أو chunk فقط
            # Support both (chunk, score) and bare chunk
            if isinstance(item, tuple) and len(item) == 2:
                chunk, score = item
            else:
                chunk, score = item, 1.0

            chunk_id = self._safe_attr(chunk, 'chunk_id')
            if chunk_id is None:
                logger.warning("chunk missing 'chunk_id' — skipping")
                continue
            if chunk_id in seen_chunks:
                continue
            if score < self.min_score_threshold:
                continue
            filtered.append((chunk, score))
            seen_chunks.add(chunk_id)
        return filtered

    def _extract_entities_from_chunks(self, chunks: List[Tuple]) -> List[str]:
        all_entities = []
        for chunk, _ in chunks[:3]:
            text = self._safe_attr(chunk, 'text', '')
            if not text:
                continue
            entities = self.decomposer.extract_entities(text)
            all_entities.extend(entities)
            self.stats['entities_extracted'] += len(entities)

        seen, unique = set(), []
        for e in all_entities:
            if e not in seen:
                unique.append(e)
                seen.add(e)
        return unique[:5]

    def _aggregate_chunks(self, hop_results: List[HopResult]) -> List[Tuple]:
        all_chunks = []
        for hop_result in hop_results:
            # القفزات الأولى أهم، لكن نعطي وزناً للاستراتيجية أيضاً
            base_weight = 1.0 / hop_result.hop_number
            strategy_bonus = 0.1 if hop_result.strategy == HopStrategy.CLARIFICATION else 0.0
            weight = base_weight + strategy_bonus

            for chunk, score in hop_result.chunks:
                all_chunks.append((chunk, score * weight))

        all_chunks.sort(key=lambda x: x[1], reverse=True)

        unique, seen_ids = [], set()
        for chunk, score in all_chunks:
            chunk_id = self._safe_attr(chunk, 'chunk_id')
            if chunk_id is None:
                continue
            if chunk_id not in seen_ids:
                unique.append((chunk, score))
                seen_ids.add(chunk_id)
        return unique

    def _format_hop_result(self, hop_result: HopResult) -> dict:
        return {
            'hop_number': hop_result.hop_number,
            'query': hop_result.query,
            'strategy': hop_result.strategy.value,
            'reasoning_step': hop_result.reasoning_step,
            'gap_filled': hop_result.gap_filled,
            'chunks_found': len(hop_result.chunks),
            'entities': hop_result.extracted_entities,
            'top_scores': [score for _, score in hop_result.chunks[:3]]
        }

    def _update_stats(self, num_hops: int):
        total = self.stats['total_queries']
        current_avg = self.stats['average_hops']
        self.stats['average_hops'] = (current_avg * (total - 1) + num_hops) / total

    def get_stats(self) -> dict:
        return {
            **self.stats,
            'max_hops': self.max_hops,
            'confidence_threshold': self.confidence_threshold,
            'ner_method': 'Stanza' if self.stats['stanza_enabled'] else 'Regex'
        }
    # ── Async API ────────────────────────────────────────────────────

    async def aquery(self, question: str,
                     max_hops: int = None,
                     return_intermediate: bool = False):
        """
        Async multi-hop query — runs the blocking query in a thread pool.
        استعلام Multi-Hop غير متزامن — يشغّل الاستعلام في thread pool منفصل.

        Args:
            question: السؤال | The question to answer
            max_hops: عدد القفزات (اختياري) | Number of hops (optional)
            return_intermediate: إرجاع النتائج الوسيطة | Return intermediate results
        """
        import asyncio
        return await asyncio.to_thread(
            self.query, question, max_hops, return_intermediate
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False