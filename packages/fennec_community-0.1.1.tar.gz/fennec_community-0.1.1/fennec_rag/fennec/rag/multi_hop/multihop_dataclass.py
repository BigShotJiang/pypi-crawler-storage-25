from dataclasses import dataclass , field
from typing import List , Tuple , Optional
from .multihop_strategy import HopStrategy


@dataclass
class ReasoningState:
    """
    حالة التفكير المتراكمة عبر القفزات
    Accumulated reasoning state across hops
    """
    known_facts: List[str] = field(default_factory=list)       # ما تم اكتشافه
    missing_info: List[str] = field(default_factory=list)      # ما لا يزال مفقوداً
    reasoning_chain: List[str] = field(default_factory=list)   # سلسلة التفكير
    confidence: float = 0.0                                     # مستوى الثقة بالإجابة
    answer_complete: bool = False                               # هل الإجابة اكتملت؟


@dataclass
class HopResult:
    """
    نتيجة قفزة واحدة - موسّعة بمعلومات التفكير
    One hop result - extended with reasoning info
    """
    query: str
    chunks: List[Tuple]
    hop_number: int
    extracted_entities: List[str]
    strategy: HopStrategy = HopStrategy.ENTITY_EXPANSION       # استراتيجية هذه القفزة
    reasoning_step: str = ""                                    # تفكير هذه الخطوة
    gap_filled: Optional[str] = None                           # الفجوة التي ملأتها هذه القفزة

