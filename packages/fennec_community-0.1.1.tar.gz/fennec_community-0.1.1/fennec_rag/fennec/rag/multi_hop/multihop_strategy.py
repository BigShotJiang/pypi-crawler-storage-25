from enum import Enum

class HopStrategy(Enum):
    """
    استراتيجية القفزة | Hop strategy
    """
    ENTITY_EXPANSION   = "entity_expansion"    # توسيع عبر الكيانات
    RELATION_BRIDGING  = "relation_bridging"   # جسر العلاقات
    CLARIFICATION      = "clarification"       # توضيح غامض
    VERIFICATION       = "verification"        # التحقق من معلومة

