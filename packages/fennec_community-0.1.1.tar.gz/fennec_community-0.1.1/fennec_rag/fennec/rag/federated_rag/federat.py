from __future__ import annotations
import asyncio
import concurrent.futures
import inspect
import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Any, AsyncGenerator, Callable, Dict, Generator,
    List, Optional,
)
from .circuitbreaker import CircuitBreaker
from .federat_cache import TTLCache

logger = logging.getLogger(__name__)


class AggregationMethod(str, Enum):
    WEIGHTED  = "weighted"
    VOTING    = "voting"
    RANKING   = "ranking"
    SIMPLE    = "simple"
    MERGE     = "merge"


# ─────────────────────────────────────────────
# StreamChunk
# ─────────────────────────────────────────────

@dataclass
class StreamChunk:
    """
    A single token / text fragment yielded during streaming.

    Attributes
    ----------
    text     : incremental text fragment (empty on done/error sentinels)
    source   : name of the RAG source that produced this chunk
    done     : True on the final chunk for this source
    metadata : optional per-chunk payload (score, latency, weight …)
    error    : non-None when this chunk signals a source failure
    """
    text:     str
    source:   str
    done:     bool                    = False
    metadata: Optional[Dict[str, Any]] = None
    error:    Optional[str]           = None

    def __str__(self) -> str:
        return self.text


# ─────────────────────────────────────────────
# FederatedSource
# ─────────────────────────────────────────────

@dataclass
class FederatedSource:
    """A single RAG backend registered in the federation."""
    name:            str
    rag_system:      Any
    weight:          float = 1.0
    enabled:         bool  = True
    timeout:         float = 10.0
    metadata:        Optional[Dict] = None
    circuit_breaker: CircuitBreaker = field(default_factory=CircuitBreaker)

    _total_queries: int   = field(default=0,   init=False, repr=False)
    _total_errors:  int   = field(default=0,   init=False, repr=False)
    _total_latency: float = field(default=0.0, init=False, repr=False)

    @property
    def stats(self) -> Dict[str, Any]:
        avg = self._total_latency / self._total_queries if self._total_queries else 0
        return {
            "total_queries":  self._total_queries,
            "total_errors":   self._total_errors,
            "avg_latency_ms": round(avg * 1000, 2),
            "error_rate":     round(self._total_errors / max(self._total_queries, 1), 3),
            "circuit_state":  self.circuit_breaker.state.value,
        }

    def record(self, *, error: bool, latency: float) -> None:
        self._total_queries += 1
        self._total_latency += latency
        if error:
            self._total_errors += 1

    # ── streaming capability detection ───────

    def _stream_method(self) -> Optional[Any]:
        """Return the backend's stream method if it exists, else None.
        Priority: astream → stream → generate_stream
        """
        for attr in ("astream", "stream", "generate_stream"):
            m = getattr(self.rag_system, attr, None)
            if callable(m):
                return m
        return None

    def supports_streaming(self) -> bool:
        return self._stream_method() is not None

    def _call_kwargs(self, method, context, top_k) -> Dict:
        """
        Build keyword args based on what the method actually declares.
        Handles: top_k, context, language (extracted from context dict).
        Never passes a param the method doesn't declare — avoids TypeError.
        """
        sig    = inspect.signature(method)
        params = sig.parameters
        kwargs: Dict[str, Any] = {}

        if "top_k" in params:
            kwargs["top_k"] = top_k

        if "context" in params and context is not None:
            kwargs["context"] = context

        # RAGSystem.astream / agenerate accept ``language`` — extract from context dict
        if "language" in params and isinstance(context, dict):
            lang = context.get("language")
            if lang:
                kwargs["language"] = lang

        return kwargs


# ─────────────────────────────────────────────
# FederatedRAG
# ─────────────────────────────────────────────

class FederatedRAG:
    """
    Federated RAG with parallel querying, aggregation, caching,
    circuit-breaking, and **streaming** support.

    Streaming strategies
    --------------------
    WEIGHTED / SIMPLE
        Stream from the highest-weight source that responds successfully.
        Sources are tried in weight order; the first successful one wins.

    RANKING
        Race all sources for ``stream_race_timeout`` seconds, collect
        their first chunk metadata (score), then stream from the source
        with the highest score × weight.

    MERGE
        Stream sources sequentially, highest weight first.
        Each source is prefixed with ``[source_name] ``.

    VOTING
        Needs all full answers to vote — not streamable by nature.
        Falls back to buffered ``query_async`` and emits one chunk.

    Backend requirements
    --------------------
    Streaming works best when the underlying ``rag_system`` exposes a
    ``stream(query, **kwargs)`` or ``astream(query, **kwargs)`` method
    that returns an iterable / async-iterable of str or dict chunks.
    If no stream method is found, the federation falls back to calling
    ``generate()`` and re-emits the answer in small word-level fragments.

    Examples
    --------
    >>> fed = FederatedRAG()
    >>> fed.add_source("docs", rag1, weight=1.5)
    >>> fed.add_source("wiki", rag2, weight=1.0)

    Async streaming:
    >>> async for chunk in fed.astream("What is AI?"):
    ...     print(chunk.text, end="", flush=True)

    Sync streaming:
    >>> for chunk in fed.stream("What is AI?"):
    ...     print(chunk.text, end="", flush=True)

    Buffered (unchanged):
    >>> result = await fed.query_async("What is AI?")
    >>> result = fed.query("What is AI?")
    """

    def __init__(
        self,
        aggregation_method: AggregationMethod | str = AggregationMethod.WEIGHTED,
        min_sources:         int   = 1,
        cache_ttl:           float = 60.0,
        cache_max_size:      int   = 256,
        stream_race_timeout: float = 2.0,
        pre_query_hook:  Optional[Callable[[str, Optional[Dict]], None]] = None,
        post_query_hook: Optional[Callable[[Dict[str, Any]], None]]      = None,
    ):
        self.sources              = {}
        self.aggregation_method   = AggregationMethod(aggregation_method)
        self.min_sources          = min_sources
        self.stream_race_timeout  = stream_race_timeout
        self._cache               = TTLCache(ttl=cache_ttl, max_size=cache_max_size)
        self._pre_hook            = pre_query_hook
        self._post_hook           = post_query_hook

    # ── Source management ────────────────────

    def add_source(
        self,
        name:       str,
        rag_system: Any,
        weight:     float = 1.0,
        timeout:    float = 10.0,
        metadata:   Optional[Dict] = None,
    ) -> "FederatedRAG":
        """Register a new RAG backend. Returns self for chaining."""
        if weight <= 0:
            raise ValueError(f"weight must be positive, got {weight}")
        self.sources[name] = FederatedSource(
            name=name, rag_system=rag_system, weight=weight,
            timeout=timeout, metadata=metadata or {},
        )
        logger.info(f"➕ Source added: '{name}'  weight={weight}  timeout={timeout}s")
        return self

    def remove_source(self, name: str) -> None:
        if name not in self.sources:
            raise KeyError(f"Source '{name}' not found")
        del self.sources[name]
        logger.info(f"➖ Source removed: '{name}'")

    def enable_source(self, name: str, enabled: bool = True) -> None:
        if name not in self.sources:
            raise KeyError(f"Source '{name}' not found")
        self.sources[name].enabled = enabled
        logger.info(f"🔧 Source '{name}' {'enabled' if enabled else 'disabled'}")

    def get_stats(self) -> Dict[str, Dict]:
        return {name: src.stats for name, src in self.sources.items()}

    # ── Buffered public API (unchanged) ──────

    def query(
        self, query: str, context: Optional[Dict] = None, top_k: int = 5
    ) -> Dict[str, Any]:
        """Synchronous buffered query. Safe inside or outside a running loop."""
        try:
            asyncio.get_running_loop()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(
                    asyncio.run, self.query_async(query, context, top_k)
                ).result()
        except RuntimeError:
            return asyncio.run(self.query_async(query, context, top_k))

    async def query_async(
        self, query: str, context: Optional[Dict] = None, top_k: int = 5
    ) -> Dict[str, Any]:
        """Async buffered query — aggregates all sources then returns."""
        cached = self._cache.get(query, context)
        if cached is not None:
            logger.debug("⚡ Cache hit")
            return {**cached, "cached": True}

        if self._pre_hook:
            self._pre_hook(query, context)

        active = self._active_sources()
        if len(active) < self.min_sources:
            return self._error(
                f"Need ≥ {self.min_sources} active source(s), found {len(active)}",
                "insufficient_sources",
            )

        logger.info(f"🌐 Federated query across {len(active)} source(s): {query!r}")
        raw     = await asyncio.gather(*[self._query_source(s, query, context, top_k) for s in active])
        results = [r for r in raw if r is not None]

        if not results:
            return self._error("All sources failed or timed out", "all_sources_failed")

        aggregated = self._aggregate(results, query)
        aggregated.update(
            sources_used=[r["source"] for r in results],
            num_sources=len(results),
            cached=False,
        )
        self._cache.set(query, context, aggregated)
        if self._post_hook:
            self._post_hook(aggregated)
        return aggregated

    # ── Streaming public API ─────────────────

    def stream(
        self,
        query:   str,
        context: Optional[Dict] = None,
        top_k:   int = 5,
    ) -> Generator[StreamChunk, None, None]:
        """
        Synchronous streaming — yields :class:`StreamChunk` objects.

        Works whether or not a loop is already running (e.g. inside Jupyter).

        >>> for chunk in fed.stream("Explain RAG"):
        ...     print(chunk.text, end="", flush=True)
        """
        try:
            asyncio.get_running_loop()
            # Already inside an async context — run the producer in a thread.
            chunks: List[StreamChunk] = []

            async def _collect():
                async for chunk in self.astream(query, context, top_k):
                    chunks.append(chunk)

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                fut = pool.submit(asyncio.run, _collect())
                fut.result()   # block until done
            yield from chunks

        except RuntimeError:
            # No running loop — drive async gen manually.
            loop = asyncio.new_event_loop()
            try:
                agen = self.astream(query, context, top_k)
                while True:
                    try:
                        yield loop.run_until_complete(agen.__anext__())
                    except StopAsyncIteration:
                        break
            finally:
                loop.close()

    async def astream(
        self,
        query:   str,
        context: Optional[Dict] = None,
        top_k:   int = 5,
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Async streaming — yields :class:`StreamChunk` objects as they arrive.

        >>> async for chunk in fed.astream("Explain RAG"):
        ...     print(chunk.text, end="", flush=True)
        """
        if self._pre_hook:
            self._pre_hook(query, context)

        active = self._active_sources()
        if len(active) < self.min_sources:
            yield StreamChunk(
                text=(
                    f"Error: need ≥ {self.min_sources} active source(s), "
                    f"found {len(active)}"
                ),
                source="__federation__",
                done=True,
                error="insufficient_sources",
            )
            return

        method = self.aggregation_method

        if method is AggregationMethod.MERGE:
            async for chunk in self._stream_merge(active, query, context, top_k):
                yield chunk

        elif method is AggregationMethod.VOTING:
            # Voting needs all answers first → buffer, then emit as one chunk.
            result = await self.query_async(query, context, top_k)
            yield StreamChunk(
                text=result.get("answer", ""),
                source=result.get("primary_source", "__federation__"),
                done=True,
                metadata={"aggregation_method": method.value},
            )

        else:
            # WEIGHTED / SIMPLE / RANKING → single winning source
            async for chunk in self._stream_winner(active, query, context, top_k, method):
                yield chunk

    # ── Streaming internals ──────────────────

    async def _stream_winner(
        self,
        active:  List[FederatedSource],
        query:   str,
        context: Optional[Dict],
        top_k:   int,
        method:  AggregationMethod,
    ) -> AsyncGenerator[StreamChunk, None]:
        """Stream from the single winning source."""
        sorted_srcs = sorted(active, key=lambda s: s.weight, reverse=True)

        if method in (AggregationMethod.WEIGHTED, AggregationMethod.SIMPLE):
            # Try sources in weight order; first successful one wins.
            for src in sorted_srcs:
                had_content = False
                async for chunk in self._stream_source(src, query, context, top_k):
                    if not chunk.error:
                        had_content = True
                    yield chunk
                if had_content:
                    return
            yield StreamChunk(
                text="All sources failed or timed out",
                source="__federation__", done=True, error="all_sources_failed",
            )

        else:  # RANKING — race for first chunks, pick best scorer
            queues: Dict[str, asyncio.Queue] = {s.name: asyncio.Queue() for s in sorted_srcs}

            async def _probe(src: FederatedSource):
                async for chunk in self._stream_source(src, query, context, top_k):
                    await queues[src.name].put(chunk)
                    return   # only need the first chunk to score

            tasks = [asyncio.create_task(_probe(s)) for s in sorted_srcs]
            await asyncio.wait(tasks, timeout=self.stream_race_timeout)

            # Cancel any tasks that didn't finish within the race timeout
            for t in tasks:
                t.cancel()
            # Allow cancelled tasks to clean up
            await asyncio.gather(*tasks, return_exceptions=True)

            first_chunks: Dict[str, StreamChunk] = {}
            for src in sorted_srcs:
                try:
                    first_chunks[src.name] = queues[src.name].get_nowait()
                except asyncio.QueueEmpty:
                    pass

            if not first_chunks:
                yield StreamChunk(
                    text="All sources failed or timed out",
                    source="__federation__", done=True, error="all_sources_failed",
                )
                return

            winner_name = max(
                first_chunks,
                key=lambda n: (
                    (first_chunks[n].metadata or {}).get("score", 0.0)
                    * self.sources[n].weight
                ),
            )
            # Emit buffered first chunk then continue streaming.
            yield first_chunks[winner_name]
            async for chunk in self._stream_source(
                self.sources[winner_name], query, context, top_k, skip_first=True
            ):
                yield chunk

    async def _stream_merge(
        self,
        active:  List[FederatedSource],
        query:   str,
        context: Optional[Dict],
        top_k:   int,
    ) -> AsyncGenerator[StreamChunk, None]:
        """Stream sources sequentially, highest weight first."""
        for i, src in enumerate(sorted(active, key=lambda s: s.weight, reverse=True)):
            if i > 0:
                yield StreamChunk(text="\n\n", source="__federation__")
            yield StreamChunk(text=f"[{src.name}] ", source=src.name)

            got_content = False
            async for chunk in self._stream_source(src, query, context, top_k):
                if not chunk.error:
                    got_content = True
                yield chunk

            if not got_content:
                yield StreamChunk(
                    text="(no response)", source=src.name,
                    done=True, error="source_failed",
                )

    async def _stream_source(
        self,
        source:     FederatedSource,
        query:      str,
        context:    Optional[Dict],
        top_k:      int,
        skip_first: bool = False,
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Drive one source's stream method (or fall back to _call_generate).

        Stream method priority:
          RAGSystem.astream → source.stream → source.astream → source.generate_stream
          → buffered _call_generate fallback
        """
        start   = time.monotonic()
        skipped = False

        try:
            rag = source.rag_system

            # ── pick stream method, preferring native astream ────────
            stream_fn = None
            for attr in ("astream", "stream", "generate_stream"):
                m = getattr(rag, attr, None)
                if callable(m):
                    stream_fn = m
                    break

            if stream_fn is not None:
                # ── Native streaming path ────────────────────────────
                #
                # Pattern A — RAGSystem (has retrieve() + astream()):
                #   astream() calls aretrieve() internally with its own
                #   config.top_k, so we CANNOT use it to honour our top_k.
                #   Instead: call retrieve(top_k=top_k) ourselves, then
                #   call agenerate() and stream the result as word-chunks.
                #
                # Pattern B — simple backends (no retrieve()):
                #   Call their stream/astream directly.
                #
                if hasattr(rag, "retrieve") and callable(rag.retrieve):
                    # ── Pattern A ──────────────────────────────────
                    _loop = asyncio.get_running_loop()
                    if hasattr(rag, "aretrieve"):
                        retrieved = await asyncio.wait_for(
                            rag.aretrieve(query, top_k=top_k),
                            timeout=source.timeout,
                        )
                    else:
                        retrieved = await asyncio.wait_for(
                            _loop.run_in_executor(
                                None, lambda: rag.retrieve(query, top_k=top_k)
                            ),
                            timeout=source.timeout,
                        )

                    if not retrieved:
                        yield StreamChunk(
                            text="❌ No relevant information found",
                            source=source.name, done=True,
                        )
                        return

                    score = float(retrieved[0][1]) if retrieved else 0.0

                    # Use agenerate (or generate in thread) and emit word-chunks
                    gen_sig    = inspect.signature(rag.generate)
                    gen_params = gen_sig.parameters
                    gen_kw: Dict[str, Any] = {}
                    if "language" in gen_params and isinstance(context, dict):
                        lang = context.get("language")
                        if lang: gen_kw["language"] = lang

                    if hasattr(rag, "agenerate") and callable(rag.agenerate):
                        answer_raw = await asyncio.wait_for(
                            rag.agenerate(query, **gen_kw), timeout=source.timeout
                        )
                    else:
                        kw_ = gen_kw
                        answer_raw = await asyncio.wait_for(
                            _loop.run_in_executor(
                                None, lambda: rag.generate(query, **kw_)
                            ),
                            timeout=source.timeout,
                        )

                    answer = str(answer_raw) if not isinstance(answer_raw, str) else answer_raw
                    CHUNK_SIZE = 4
                    words = answer.split(" ")
                    for i in range(0, len(words), CHUNK_SIZE):
                        fragment = " ".join(words[i : i + CHUNK_SIZE])
                        if i + CHUNK_SIZE < len(words):
                            fragment += " "
                        if skip_first and not skipped:
                            skipped = True
                            continue
                        yield StreamChunk(
                            text=fragment, source=source.name,
                            metadata={"score": score, "weight": source.weight},
                        )

                    # jump straight to success sentinel
                    latency = time.monotonic() - start
                    source.record(error=False, latency=latency)
                    source.circuit_breaker.record_success()
                    logger.info(f"  ✓ {source.name} stream done ({latency * 1000:.0f} ms)")
                    yield StreamChunk(
                        text="", source=source.name, done=True,
                        metadata={"latency_ms": round(latency * 1000, 2), "weight": source.weight},
                    )
                    return   # skip the generic sentinel below

                else:
                    # ── Pattern B — simple backends with native stream ──
                    sig    = inspect.signature(stream_fn)
                    params = sig.parameters
                    has_varkw = any(
                        p.kind == inspect.Parameter.VAR_KEYWORD
                        for p in params.values()
                    )
                    kwargs: Dict[str, Any] = {}
                    if "top_k"   in params: kwargs["top_k"]   = top_k
                    if "context" in params and context is not None:
                        kwargs["context"] = context
                    if "language" in params and isinstance(context, dict):
                        lang = context.get("language")
                        if lang: kwargs["language"] = lang
                    if has_varkw and source.metadata:
                        kwargs.update({
                            k: v for k, v in source.metadata.items()
                            if k not in kwargs and k != "query"
                        })

                    raw = stream_fn(query, **kwargs)

                # Resolve coroutines (async def astream that returns an agen)
                if inspect.iscoroutine(raw):
                    raw = await raw

                # Wrap sync iterables into async generator
                if not inspect.isasyncgen(raw):
                    async def _wrap(it):
                        loop = asyncio.get_running_loop()
                        for item in await loop.run_in_executor(None, list, it):
                            yield item
                    raw = _wrap(raw)

                deadline = start + source.timeout
                async for raw_chunk in raw:
                    if time.monotonic() > deadline:
                        raise asyncio.TimeoutError

                    # Normalise chunk to (text, score)
                    if isinstance(raw_chunk, str):
                        text, score = raw_chunk, 0.0
                    elif isinstance(raw_chunk, dict):
                        text  = raw_chunk.get("text", raw_chunk.get("answer", ""))
                        score = raw_chunk.get("score", 0.0)
                    else:
                        text, score = str(raw_chunk), 0.0

                    if skip_first and not skipped:
                        skipped = True
                        continue

                    yield StreamChunk(
                        text=text, source=source.name,
                        metadata={"score": score, "weight": source.weight},
                    )

            else:
                # ── Buffered fallback: generate() → word-level chunks ─
                result = await self._call_generate(source, query, context, top_k)
                answer = result.get("answer", "")
                score  = result.get("score", 0.0)

                CHUNK_SIZE = 4   # words per synthetic chunk
                words = answer.split(" ")
                for i in range(0, len(words), CHUNK_SIZE):
                    fragment = " ".join(words[i : i + CHUNK_SIZE])
                    if i + CHUNK_SIZE < len(words):
                        fragment += " "

                    if skip_first and not skipped:
                        skipped = True
                        continue

                    yield StreamChunk(
                        text=fragment, source=source.name,
                        metadata={"score": score, "weight": source.weight},
                    )

            # ── Success sentinel ─────────────────────────────────────
            latency = time.monotonic() - start
            source.record(error=False, latency=latency)
            source.circuit_breaker.record_success()
            logger.info(f"  ✓ {source.name} stream done ({latency * 1000:.0f} ms)")
            yield StreamChunk(
                text="", source=source.name, done=True,
                metadata={"latency_ms": round(latency * 1000, 2), "weight": source.weight},
            )

        except asyncio.TimeoutError:
            latency = time.monotonic() - start
            source.record(error=True, latency=latency)
            source.circuit_breaker.record_failure()
            logger.warning(f"  ⏱ {source.name} stream timed out after {source.timeout}s")
            yield StreamChunk(
                text="", source=source.name, done=True,
                error=f"timeout after {source.timeout}s",
            )

        except Exception as exc:
            latency = time.monotonic() - start
            source.record(error=True, latency=latency)
            source.circuit_breaker.record_failure()
            logger.error(f"  ✗ {source.name} stream error: {exc}")
            yield StreamChunk(
                text="", source=source.name, done=True, error=str(exc),
            )

    # ── Buffered internals ───────────────────

    def _active_sources(self) -> List[FederatedSource]:
        return [s for s in self.sources.values() if s.enabled and s.circuit_breaker.allow()]

    async def _call_generate(
        self,
        source:  FederatedSource,
        query:   str,
        context: Optional[Dict],
        top_k:   int,
    ) -> Dict[str, Any]:
        """
        Call the RAG backend in a signature-aware way, handling two patterns:

        Pattern A — retrieve() + generate() are separate (e.g. RAGSystem):
            Calls ``retrieve(query, top_k=top_k)`` first, then ``generate(query)``.
            This is the only correct way to honour ``top_k`` when the backend
            retrieves internally inside ``generate()``.

        Pattern B — single generate(query, ...) call (simple backends):
            Falls back when the backend has no ``retrieve()`` method.
            Passes only the kwargs the method actually declares
            (``top_k``, ``context``, ``language``) — never positionally.

        Priority for async:
            ``agenerate`` > ``generate`` (coroutine) > ``generate`` (sync in thread)

        Returns a normalised dict with at least ``{"answer": str}``.
        """
        rag  = source.rag_system
        loop = asyncio.get_running_loop()

        # ── Pattern A: separate retrieve() + generate() ───────────────
        # RAGSystem (and any backend that exposes retrieve()) follows this pattern.
        # We call retrieve() ourselves so top_k is actually honoured.
        if hasattr(rag, "retrieve") and callable(rag.retrieve):
            # 1. retrieve
            if hasattr(rag, "aretrieve") and callable(rag.aretrieve):
                retrieved = await asyncio.wait_for(
                    rag.aretrieve(query, top_k=top_k), timeout=source.timeout
                )
            else:
                retrieved = await asyncio.wait_for(
                    loop.run_in_executor(None, lambda: rag.retrieve(query, top_k=top_k)),
                    timeout=source.timeout,
                )

            if not retrieved:
                return {"answer": "❌ No relevant information found", "score": 0.0}

            # 2. extract best score for federation ranking
            score = float(retrieved[0][1]) if retrieved else 0.0

            # 3. generate — pass language from context if declared
            gen_sig    = inspect.signature(rag.generate)
            gen_params = gen_sig.parameters
            gen_kwargs: Dict[str, Any] = {}

            if "language" in gen_params and isinstance(context, dict):
                lang = context.get("language")
                if lang:
                    gen_kwargs["language"] = lang

            if hasattr(rag, "agenerate") and callable(rag.agenerate):
                answer = await asyncio.wait_for(
                    rag.agenerate(query, **gen_kwargs), timeout=source.timeout
                )
            else:
                kw = gen_kwargs
                answer = await asyncio.wait_for(
                    loop.run_in_executor(None, lambda: rag.generate(query, **kw)),
                    timeout=source.timeout,
                )

            if not isinstance(answer, dict):
                answer = {"answer": str(answer)}

            answer.setdefault("score", score)
            return answer

        # ── Pattern B: single generate() / agenerate() call ──────────
        if hasattr(rag, "agenerate") and callable(rag.agenerate):
            fn       = rag.agenerate
            is_async = True
        else:
            fn       = rag.generate
            is_async = inspect.iscoroutinefunction(fn)

        sig        = inspect.signature(fn)
        params     = sig.parameters
        has_kwargs = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
        )

        kwargs: Dict[str, Any] = {}
        if "top_k"   in params:                              kwargs["top_k"]   = top_k
        if "context" in params and context is not None:      kwargs["context"] = context
        if "language" in params and isinstance(context, dict):
            lang = context.get("language")
            if lang:
                kwargs["language"] = lang
        if has_kwargs and source.metadata:
            kwargs.update({
                k: v for k, v in source.metadata.items()
                if k not in kwargs and k != "query"
            })

        kw = kwargs
        if is_async:
            result = await asyncio.wait_for(fn(query, **kw), timeout=source.timeout)
        else:
            result = await asyncio.wait_for(
                loop.run_in_executor(None, lambda: fn(query, **kw)),
                timeout=source.timeout,
            )

        if not isinstance(result, dict):
            result = {"answer": str(result)}
        return result

    async def _query_source(
        self, source: FederatedSource, query: str, context: Optional[Dict], top_k: int = 5,
    ) -> Optional[Dict[str, Any]]:
        start = time.monotonic()
        try:
            result  = await self._call_generate(source, query, context, top_k)
            latency = time.monotonic() - start
            source.record(error=False, latency=latency)
            source.circuit_breaker.record_success()

            result.setdefault("score", 0.0)
            result["source"]     = source.name
            result["weight"]     = source.weight
            result["latency_ms"] = round(latency * 1000, 2)
            logger.info(f"  ✓ {source.name} ({latency * 1000:.0f} ms)")
            return result

        except asyncio.TimeoutError:
            latency = time.monotonic() - start
            source.record(error=True, latency=latency)
            source.circuit_breaker.record_failure()
            logger.warning(f"  ⏱ {source.name} timed out after {source.timeout}s")
            return None

        except Exception as exc:
            latency = time.monotonic() - start
            source.record(error=True, latency=latency)
            source.circuit_breaker.record_failure()
            logger.error(f"  ✗ {source.name}: {exc}")
            return None

    # ── Aggregation strategies (unchanged) ───

    def _aggregate(self, results: List[Dict], query: str) -> Dict[str, Any]:
        m = self.aggregation_method
        if m is AggregationMethod.WEIGHTED: return self._weighted(results)
        if m is AggregationMethod.VOTING:   return self._voting(results)
        if m is AggregationMethod.RANKING:  return self._ranking(results)
        if m is AggregationMethod.MERGE:    return self._merge(results)
        return self._simple(results)

    def _weighted(self, results):
        best = max(results, key=lambda r: (r.get("weight", 1.0), r.get("score", 0.0)))
        return {"answer": best.get("answer", ""), "primary_source": best["source"],
                "all_results": results, "aggregation_method": AggregationMethod.WEIGHTED.value}

    def _voting(self, results):
        vm: Dict[str, List] = defaultdict(list)
        for r in results:
            vm[(r.get("answer") or "")[:60].strip().lower()].append(r)
        wk   = max(vm, key=lambda k: sum(r.get("weight", 1) for r in vm[k]))
        best = max(vm[wk], key=lambda r: r.get("weight", 1.0))
        return {"answer": best.get("answer", ""), "primary_source": best["source"],
                "vote_counts": {k: len(v) for k, v in vm.items()},
                "all_results": results, "aggregation_method": AggregationMethod.VOTING.value}

    def _ranking(self, results):
        ranked = sorted(results,
                        key=lambda r: r.get("score", 0.0) * r.get("weight", 1.0), reverse=True)
        return {"answer": ranked[0].get("answer", ""), "primary_source": ranked[0]["source"],
                "ranked_results": ranked, "aggregation_method": AggregationMethod.RANKING.value}

    def _merge(self, results):
        seen: set = set()
        parts: List[str] = []
        for r in sorted(results, key=lambda x: x.get("weight", 1.0), reverse=True):
            ans = (r.get("answer") or "").strip()
            fp  = ans[:40].lower()
            if ans and fp not in seen:
                seen.add(fp)
                parts.append(f"[{r['source']}] {ans}")
        return {"answer": "\n\n".join(parts), "all_results": results,
                "aggregation_method": AggregationMethod.MERGE.value}

    def _simple(self, results):
        return {"answer": results[0].get("answer", ""), "primary_source": results[0]["source"],
                "all_results": results, "aggregation_method": AggregationMethod.SIMPLE.value}

    @staticmethod
    def _error(msg: str, code: str) -> Dict[str, Any]:
        logger.error(f"FederatedRAG error [{code}]: {msg}")
        return {"answer": msg, "error": code, "sources_used": [], "num_sources": 0}

    # ── Dunder helpers ────────────────────────

    def __repr__(self) -> str:
        return (f"FederatedRAG(sources={list(self.sources)}, "
                f"method={self.aggregation_method.value}, "
                f"min_sources={self.min_sources})")

    def __len__(self) -> int:
        return len(self.sources)

    async def aquery(self, query: str, context=None, top_k: int = 5):
        """Alias for query_async."""
        return await self.query_async(query, context, top_k)

    async def __aenter__(self): return self
    async def __aexit__(self, *_): return False