import time
import hashlib
import threading
from typing import Any, Dict, Optional, Tuple

class TTLCache:
    """Thread-safe in-memory cache with time-to-live."""

    def __init__(self, ttl: float = 60.0, max_size: int = 256):
        self.ttl = ttl
        self.max_size = max_size
        self._store: Dict[str, Tuple[float, Any]] = {}
        self._lock = threading.RLock()  

    @staticmethod
    def _key(query: str, context: Optional[Dict]) -> str:
        raw = f"{query}|{sorted((context or {}).items())}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(self, query: str, context: Optional[Dict]) -> Optional[Any]:
        k = self._key(query, context)
        with self._lock: 
            entry = self._store.get(k)
            if entry and time.monotonic() - entry[0] < self.ttl:
                return entry[1]
            self._store.pop(k, None)
            return None

    def set(self, query: str, context: Optional[Dict], value: Any) -> None:
        k = self._key(query, context)
        with self._lock:  
            if len(self._store) >= self.max_size:
                oldest = min(self._store, key=lambda key: self._store[key][0])
                del self._store[oldest]
            self._store[k] = (time.monotonic(), value)

    def invalidate(self) -> None:
        with self._lock: 
            self._store.clear()