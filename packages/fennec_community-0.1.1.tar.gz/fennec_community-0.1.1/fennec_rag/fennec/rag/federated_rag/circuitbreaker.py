from dataclasses import dataclass, field
from enum import Enum
import logging
import time

logger = logging.getLogger(__name__)


class CircuitState(Enum):
    CLOSED   = "closed"    # normal – requests pass through
    OPEN     = "open"      # failing – requests blocked
    HALF_OPEN = "half_open"


recovery_timeout: float = 30.0  # seconds  (fixed: was annotated as int)
failure_threshold: int = 3


@dataclass
class CircuitBreaker:
    """
    Prevents hammering a repeatedly-failing source.

    Transitions:
        CLOSED  → OPEN      after `failure_threshold` consecutive failures
        OPEN    → HALF_OPEN after `recovery_timeout` seconds
        HALF_OPEN → CLOSED  on success  |  OPEN on failure
    """
    failure_threshold: int = failure_threshold
    recovery_timeout: float = recovery_timeout

    _state: CircuitState = field(default=CircuitState.CLOSED, init=False, repr=False)
    _failures: int = field(default=0, init=False, repr=False)
    _opened_at: float = field(default=0.0, init=False, repr=False)

    def _check_transition(self) -> None:
        """Separated from property to avoid side-effects inside a getter."""
        if self._state is CircuitState.OPEN:
            if time.monotonic() - self._opened_at >= self.recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                logger.debug("Circuit → HALF_OPEN")

    @property
    def state(self) -> CircuitState:
        self._check_transition()
        return self._state

    def allow(self) -> bool:
        self._check_transition()
        return self._state in (CircuitState.CLOSED, CircuitState.HALF_OPEN)

    def record_success(self) -> None:
        self._failures = 0
        self._state = CircuitState.CLOSED

    def record_failure(self) -> None:
        self._failures += 1
        if self._failures >= self.failure_threshold or self._state is CircuitState.HALF_OPEN:
            self._state = CircuitState.OPEN
            self._opened_at = time.monotonic()
            logger.warning(f"Circuit OPENED after {self._failures} failures")