from dataclasses import dataclass
from typing import Optional


@dataclass
class CacheMetrics:
    """
    Track cache performance metrics\n
    تتبع مقاييس أداء ذاكرة التخزين المؤقت
    """
    # L1 cache hits | إصابات المستوى الأول
    l1_hits: int = 0
    # L2 cache hits | إصابات المستوى الثاني
    l2_hits: int = 0
    # L3 cache hits | إصابات المستوى الثالث
    l3_hits: int = 0
    # L1 cache misses | إخفاقات المستوى الأول
    l1_misses: int = 0
    # L2 cache misses | إخفاقات المستوى الثاني
    l2_misses: int = 0
    # L3 cache misses | إخفاقات المستوى الثالث
    l3_misses: int = 0
    # Total set operations | إجمالي عمليات التعيين
    sets: int = 0
    # Total evictions | إجمالي عمليات الإخلاء
    evictions: int = 0
    # Total promotions | إجمالي عمليات الترقية
    promotions: int = 0
    # Total expirations | إجمالي عمليات انتهاء الصلاحية
    expirations: int = 0
    
    def record_get(self, level: int, hit: bool) -> None:
        """
        Record a get operation\n
        تسجيل عملية قراءة
        
        Args:
            level: Cache level (1, 2, or 3) | مستوى التخزين المؤقت (1 أو 2 أو 3)
            hit: Whether the get was a hit or miss | ما إذا كانت العملية إصابة أم إخفاق
        """
        if level == 1:
            if hit:
                self.l1_hits += 1
            else:
                self.l1_misses += 1
        elif level == 2:
            if hit:
                self.l2_hits += 1
            else:
                self.l2_misses += 1
        elif level == 3:
            if hit:
                self.l3_hits += 1
            else:
                self.l3_misses += 1
    
    def record_set(self) -> None:
        """
        Record a set operation\n
        تسجيل عملية تعيين
        """
        self.sets += 1
    
    def record_eviction(self) -> None:
        """
        Record a cache eviction\n
        تسجيل عملية إخلاء من ذاكرة التخزين عندما تمتلئ الذاكره
        """
        self.evictions += 1
    
    def record_promotion(self) -> None:
        """
        Record a promotion between cache levels\n
        تسجيل عملية ترقية بين مستويات التخزين المؤقت
        """
        self.promotions += 1
    
    def record_expiration(self) -> None:
        """
        Record a cache entry expiration\n
        تسجيل عملية انتهاء صلاحية عنصر في ذاكرة التخزين المؤقت
        """
        self.expirations += 1
    
    def get_hit_rate(self, level: Optional[int] = None) -> float:
        """
        Calculate hit rate for specified level or overall\n
        حساب معدل الإصابة للمستوى المحدد أو الإجمالي
        
        Args:
            level: Cache level (1, 2, 3) or None for overall | مستوى التخزين (1، 2، 3) أو None للإجمالي
            
        Returns:
            Hit rate as a float between 0 and 1 | معدل الإصابة كرقم عشري بين 0 و 1
        """
        if level == 1:
            total = self.l1_hits + self.l1_misses
            return self.l1_hits / total if total > 0 else 0.0
        elif level == 2:
            total = self.l2_hits + self.l2_misses
            return self.l2_hits / total if total > 0 else 0.0
        elif level == 3:
            total = self.l3_hits + self.l3_misses
            return self.l3_hits / total if total > 0 else 0.0
        else:
            # Overall hit rate | معدل الإصابة الإجمالي
            total_hits = self.l1_hits + self.l2_hits + self.l3_hits
            total_gets = total_hits + self.l1_misses + self.l2_misses + self.l3_misses
            return total_hits / total_gets if total_gets > 0 else 0.0
    
    def get_stats(self) -> dict:
        """
        Get all statistics as dictionary\n
        الحصول على جميع الإحصائيات كقاموس
        
        Returns:
            Dictionary containing all cache metrics | قاموس يحتوي على جميع مقاييس التخزين المؤقت
        """
        return {
            'l1_hits': self.l1_hits,
            'l2_hits': self.l2_hits,
            'l3_hits': self.l3_hits,
            'total_hits': self.l1_hits + self.l2_hits + self.l3_hits,
            'l1_misses': self.l1_misses,
            'l2_misses': self.l2_misses,
            'l3_misses': self.l3_misses,
            'total_misses': self.l1_misses + self.l2_misses + self.l3_misses,
            'l1_hit_rate': self.get_hit_rate(1),
            'l2_hit_rate': self.get_hit_rate(2),
            'l3_hit_rate': self.get_hit_rate(3),
            'overall_hit_rate': self.get_hit_rate(),
            'sets': self.sets,
            'evictions': self.evictions,
            'promotions': self.promotions,
            'expirations': self.expirations,
         
        }
    
    def reset(self) -> None:
        """
        Reset all metrics to zero\n
        إعادة تعيين جميع المقاييس إلى الصفر
        """
        self.l1_hits = self.l2_hits = self.l3_hits = 0
        self.l1_misses = self.l2_misses = self.l3_misses = 0
        self.sets = self.evictions = self.promotions = self.expirations = 0