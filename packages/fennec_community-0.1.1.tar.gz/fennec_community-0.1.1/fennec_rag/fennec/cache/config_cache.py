# -*- coding: utf-8 -*-
"""
Cache Configuration Module
Provides configuration for multi-level cache system
"""

from dataclasses import dataclass
from typing import Optional
import os


@dataclass
class CacheConfig:
    """
    Configuration for multi-level cache system
    Attributes:
        l1_max_items: Maximum items in L1 cache (in-memory, fastest)
        l2_max_items: Maximum items in L2 cache (in-memory, fast)
        l3_max_items: Maximum items in L3 cache (disk, slower)
        l1_max_size_mb: Maximum size in MB for L1 cache
        l2_max_size_mb: Maximum size in MB for L2 cache
        l3_max_size_mb: Maximum size in MB for L3 cache
        default_ttl: Default time-to-live in seconds (None = no expiration)
        cache_dir: Directory for L3 disk cache
        enable_stats: Enable statistics tracking
        auto_cleanup_interval: Automatic cleanup interval in seconds
    """
    
    # Item limits per level
    l1_max_items: int = 100
    l2_max_items: int = 1000
    l3_max_items: int = 10000
    
    # Size limits per level (in MB)
    l1_max_size_mb: float = 10.0
    l2_max_size_mb: float = 100.0
    l3_max_size_mb: float = 1000.0
    
    # Time-to-live settings
    default_ttl: Optional[float] = None  # seconds
    
    # Storage settings
    cache_dir: str = "./cache_storage"
    
    # Performance settings
    enable_stats: bool = True
    auto_cleanup_interval: int = 3600  # 1 hour
    
    # Access speeds (nanoseconds) - for reference/simulation
    l1_speed_ns: int = 100
    l2_speed_ns: int = 1000
    l3_speed_ns: int = 10000

    l2_to_l1_hits : int = 10

    # size for one cache wiht byte
    size_bytes : int = 1024
    
    def __post_init__(self):
        """Validate configuration after initialization"""
        self._validate()
    
    def _validate(self):
        """Validate configuration parameters"""
        if self.l1_max_items < 1:
            raise ValueError("l1_max_items must be at least 1")
        
        if self.l2_max_items < self.l1_max_items:
            raise ValueError("l2_max_items should be >= l1_max_items")
        
        if self.l3_max_items < self.l2_max_items:
            raise ValueError("l3_max_items should be >= l2_max_items")
        
        if self.l1_max_size_mb <= 0 or self.l2_max_size_mb <= 0 or self.l3_max_size_mb <= 0:
            raise ValueError("Size limits must be positive")
        
        if self.default_ttl is not None and self.default_ttl <= 0:
            raise ValueError("default_ttl must be positive or None")
    
    @classmethod
    def from_env(cls) -> 'CacheConfig':
        """
        Create configuration from environment variables\n
        تمكنك مناخذ متغيرات من خلال env
        
        Environment variables:
            CACHE_L1_MAX_ITEMS: L1 max items
            CACHE_L2_MAX_ITEMS: L2 max items
            CACHE_L3_MAX_ITEMS: L3 max items
            CACHE_DIR: Cache directory path
            CACHE_DEFAULT_TTL: Default TTL in seconds
        """
        return cls(
            l1_max_items=int(os.getenv('CACHE_L1_MAX_ITEMS', 100)),
            l2_max_items=int(os.getenv('CACHE_L2_MAX_ITEMS', 1000)),
            l3_max_items=int(os.getenv('CACHE_L3_MAX_ITEMS', 10000)),
            cache_dir=os.getenv('CACHE_DIR', './cache_storage'),
            default_ttl=float(os.getenv('CACHE_DEFAULT_TTL')) if os.getenv('CACHE_DEFAULT_TTL') else None
        )
    
    def to_dict(self) -> dict:
        """Convert configuration to dictionary\n
         بيرجع الداتا في شكل قاموس
        """
        return {
            'l1_max_items': self.l1_max_items,
            'l2_max_items': self.l2_max_items,
            'l3_max_items': self.l3_max_items,
            'l1_max_size_mb': self.l1_max_size_mb,
            'l2_max_size_mb': self.l2_max_size_mb,
            'l3_max_size_mb': self.l3_max_size_mb,
            'default_ttl': self.default_ttl,
            'cache_dir': self.cache_dir,
        }


