from dataclasses import dataclass, field
import time
from typing import Any, Optional
import pickle
from .config_cache import CacheConfig
config=CacheConfig()


@dataclass
class CacheEntry:
    """
    يمثل عنصر مخزن مؤقتاً مع بيانات وصفية\n
    Represents a cached item with metadata
    """
    key: str                                           # المفتاح | Key
    value: Any                                         # القيمة المخزنة | Cached value
    created_at: float = field(default_factory=time.time)    # وقت الإنشاء | Creation time
    last_access: float = field(default_factory=time.time)   # آخر وصول | Last access time
    hits: int = 0                                      # عدد مرات الوصول | Access count
    ttl: Optional[float] = None                        # مدة الصلاحية بالثواني | Time to live in seconds
    size_bytes: int = 0                                # الحجم بالبايتات | Size in bytes
    
    def __post_init__(self):
        """
        حساب الحجم بعد التهيئة\n
        Calculate size after initialization
        """
        if self.size_bytes == 0:
            self.size_bytes = self._calculate_size()
    
    def _calculate_size(self) -> int:
        """
        تقدير حجم الذاكرة للقيمة المخزنة\n
        Estimate memory size of cached value
        
        Returns:
            الحجم بالبايتات | Size in bytes
        """
        try:
            # محاولة حساب الحجم الفعلي
            # Try to calculate actual size
            return len(pickle.dumps(self.value))
        except Exception:
            # حجم افتراضي إذا فشل الحساب
            # Default size if calculation fails
            return config.size_bytes  # Default 1KB
    
    def increment_hits(self) -> None:
        """
        زيادة عداد الوصول وتحديث وقت الوصول\n
        Increment hit counter and update access time
        """
        self.hits += 1
        self.last_access = time.time()
    
    def is_expired(self) -> bool:
        """
        التحقق من انتهاء صلاحية العنصر بناءً على TTL\n
        Check if entry has expired based on TTL
        
        Returns:
            True إذا انتهت الصلاحية | True if expired
        """
        if self.ttl is None:
            return False
        
        # حساب وقت انتهاء الصلاحية
        # Calculate expiration time
        expiration_time = self.created_at + self.ttl
        return time.time() > expiration_time
    
    def age(self) -> float:
        """
        الحصول على عمر العنصر بالثواني\n
        Get age of entry in seconds
        
        Returns:
            العمر بالثواني | Age in seconds
        """
        return time.time() - self.created_at
    
    def idle_time(self) -> float:
        """
        الحصول على الوقت منذ آخر وصول بالثواني\n
        Get time since last access in seconds
        
        Returns:
            الوقت الخامل بالثواني | Idle time in seconds
        """
        return time.time() - self.last_access
    
    def get_stats(self) -> dict:
        """
        الحصول على إحصائيات العنصر\n
        Get entry statistics
        
        Returns:
            قاموس الإحصائيات | Statistics dictionary
        """
        return {
            'key': self.key,                           # المفتاح | Key
            'hits': self.hits,                         # عدد الوصولات | Hit count
            'age_seconds': self.age(),                 # العمر | Age
            'idle_seconds': self.idle_time(),          # الوقت الخامل | Idle time
            'size_bytes': self.size_bytes,             # الحجم | Size
            'is_expired': self.is_expired(),           # منتهي الصلاحية؟ | Is expired?
            'ttl': self.ttl                            # مدة الصلاحية | TTL
        }
    
    def __repr__(self) -> str:
        """
        تمثيل نصي للعنصر\n
        Text representation of entry
        """
        status = "expired" if self.is_expired() else "valid"
        return (f"CacheEntry(key='{self.key}', hits={self.hits}, "
                f"age={self.age():.1f}s, status={status})")