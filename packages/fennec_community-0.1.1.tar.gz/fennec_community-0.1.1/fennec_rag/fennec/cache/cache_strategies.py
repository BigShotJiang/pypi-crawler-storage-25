
from enum import Enum

class CacheStrategy(Enum):
    """Cache eviction strategies"""
    LRU = "lru"      # Least Recently Used
    LFU = "lfu"      # Least Frequently Used
    FIFO = "fifo"    # First In First Out
    TTL = "ttl"      # Time To Live based
    ADAPTIVE = "adaptive"  # Adaptive strategy
