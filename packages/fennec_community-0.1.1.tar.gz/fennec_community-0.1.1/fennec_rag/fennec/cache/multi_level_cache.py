# -*- coding: utf-8 -*-
"""
Multi-Level Cache System | نظام ذاكرة تخزين مؤقت متعدد المستويات
Implements a 3-level cache hierarchy with automatic promotion and eviction
ينفذ هيكل تخزين مؤقت من 3 مستويات مع ترقية وإخلاء تلقائي
"""

import hashlib
import os
import time
import pickle
import threading
import logging
from collections import OrderedDict, Counter
from typing import Dict, Any, Optional, List
from pathlib import Path
from .cache_strategies import CacheStrategy
from .cache_entry import CacheEntry
from .cache_metrics import CacheMetrics
from .config_cache import CacheConfig

logger = logging.getLogger(__name__)



class MultiLevelCache:
    """
    Multi-level cache system with intelligent promotion and eviction\n
    نظام تخزين مؤقت متعدد المستويات مع ترقية وإخلاء ذكي
    
    Architecture | الهندسة المعمارية:
        L1: Fast in-memory cache (smallest, fastest) | ذاكرة تخزين سريعة (الأصغر والأسرع)
        L2: Medium in-memory cache (medium size, fast) | ذاكرة تخزين متوسطة (حجم متوسط، سريعة)
        L3: Disk-based cache (largest, slower) | ذاكرة تخزين قائمة على القرص (الأكبر، أبطأ)
    
    Features | الميزات:
        - Automatic promotion of hot data | ترقية تلقائية للبيانات الساخنة
        - Configurable eviction strategies (LRU, LFU, FIFO, TTL) | استراتيجيات إخلاء قابلة للتكوين
        - Hash-based key management | إدارة المفاتيح المبنية على التجزئة
        - TTL support | دعم وقت انتهاء الصلاحية
        - Thread-safe operations | عمليات آمنة للخيوط
        - Performance metrics | مقاييس الأداء
        - Size-based and item-based limits | حدود مبنية على الحجم وعدد العناصر
        - Auto cleanup of expired entries | تنظيف تلقائي للعناصر منتهية الصلاحية
    """
    
    def __init__(
        self,
        l1_max_items: Optional[int] = None,
        l2_max_items: Optional[int] = None,
        l3_max_items: Optional[int] = None,
        strategy: CacheStrategy = CacheStrategy.LRU,
        config: Optional[CacheConfig] = None,
        persist_l3: bool = True
    ):
        """
        Initialize multi-level cache\nتهيئة ذاكرة التخزين المؤقت متعددة المستويات
        
        Args:
            l1_max_items: Max items in L1 (overrides config) | الحد الأقصى للعناصر في L1 (يتجاوز الإعدادات)
            l2_max_items: Max items in L2 (overrides config) | الحد الأقصى للعناصر في L2 (يتجاوز الإعدادات)
            l3_max_items: Max items in L3 (overrides config) | الحد الأقصى للعناصر في L3 (يتجاوز الإعدادات)
            strategy: Eviction strategy | استراتيجية الإخلاء
            config: CacheConfig instance | مثيل تكوين ذاكرة التخزين المؤقت
            persist_l3: If True (default), L3 disk files survive after the cache is closed/exited.
                        If False, L3 files are deleted on __exit__ or close().
                        إذا كان True (الافتراضي)، تبقى ملفات L3 على الديسك بعد إغلاق الكاش.
                        إذا كان False، تُحذف ملفات L3 عند الخروج.
        """
        # Use provided config or create default | استخدام الإعدادات المقدمة أو إنشاء الافتراضية
        self.config = config or CacheConfig()
        self.persist_l3 = persist_l3
        
        # Override with provided values | الكتابة فوق القيم المقدمة
        if l1_max_items is not None:
            self.config.l1_max_items = l1_max_items
        if l2_max_items is not None:
            self.config.l2_max_items = l2_max_items
        if l3_max_items is not None:
            self.config.l3_max_items = l3_max_items
        
        self.strategy = strategy
        
        # Cache storage (OrderedDict for efficient LRU) | تخزين ذاكرة التخزين المؤقت (قاموس مرتب لكفاءة LRU)
        self.l1_cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.l2_cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.l3_cache: Dict[str, Dict[str, Any]] = {}  # key -> metadata | مفتاح -> البيانات الوصفية
        
        # Metrics | المقاييس
        self.metrics = CacheMetrics()
        
        # LFU counters | عدادات الأقل استخداماً
        self.l1_frequency: Counter = Counter()
        self.l2_frequency: Counter = Counter()
        
        # Size tracking (in bytes) | تتبع الحجم (بالبايتات)
        self.l1_current_size = 0
        self.l2_current_size = 0
        self.l3_current_size = 0
        
        # Thread safety | الأمان للخيوط
        self.lock = threading.RLock()
        
        # Setup L3 storage | إعداد تخزين L3
        self.cache_dir = Path(self.config.cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Auto cleanup timer | مؤقت التنظيف التلقائي
        self._cleanup_timer: Optional[threading.Timer] = None
        if self.config.auto_cleanup_interval:
            self._schedule_cleanup()
        
        logger.info(f"MultiLevelCache initialized with strategy: {strategy.value}")
        logger.info(f"L1: {self.config.l1_max_items} items ({self.config.l1_max_size_mb}MB), "
                   f"L2: {self.config.l2_max_items} items ({self.config.l2_max_size_mb}MB), "
                   f"L3: {self.config.l3_max_items} items ({self.config.l3_max_size_mb}MB)")
    
    # ==========================================
    # Public API | الواجهة البرمجية العامة
    # ==========================================
    
    def get(self, key: str) -> Optional[Any]:
        """
        Retrieve value from cache\nاسترجاع القيمة من ذاكرة التخزين المؤقت
        
        Args:
            key: Cache key | مفتاح ذاكرة التخزين المؤقت
        
        Returns:
            Cached value or None if not found/expired | القيمة المخزنة أو None إذا لم يتم العثور عليها/منتهية الصلاحية
        """
        with self.lock:
            hashed_key = self._hash_key(key)
            self.metrics.record_get(1, False)  # Will be updated if hit | سيتم التحديث في حالة الإصابة
            
            # Try L1 | محاولة L1
            entry = self.l1_cache.get(hashed_key)
            if entry:
                if self._is_expired(entry):
                    self._remove_entry(hashed_key, level=1)
                    self.metrics.record_expiration()
                    return None
                
                self.metrics.record_get(1, True)
                self._access_entry(entry, level=1)
                return entry.value
            
            # Try L2 | محاولة L2
            entry = self.l2_cache.get(hashed_key)
            if entry:
                if self._is_expired(entry):
                    self._remove_entry(hashed_key, level=2)
                    self.metrics.record_expiration()
                    return None
                
                self.metrics.record_get(2, True)
                self._access_entry(entry, level=2)
                
                # Auto-promote if hot enough | ترقية تلقائية إذا كان ساخناً بما يكفي
                if entry.hits >= self.config.l2_to_l1_hits:
                    self._promote_to_l1(hashed_key, entry)
                
                return entry.value
            
            # Try L3 | محاولة L3
            meta = self.l3_cache.get(hashed_key)
            if meta:
                filepath = meta['path']
                if os.path.exists(filepath):
                    if self._is_l3_expired(meta):
                        self._remove_entry(hashed_key, level=3)
                        self.metrics.record_expiration()
                        return None
                    
                    try:
                        value = self._load_from_disk(filepath)
                        
                        # Create entry and promote | إنشاء عنصر وترقيته
                        entry = CacheEntry(
                            key=hashed_key,
                            value=value,
                            hits=1,
                            ttl=meta.get('ttl')
                        )
                        
                        self.metrics.record_get(3, True)
                        self._promote_to_l2(hashed_key, entry)
                        return value
                        
                    except Exception as e:
                        logger.error(f"Failed to load from L3: {e}")
                        self._remove_entry(hashed_key, level=3)
                else:
                    # File doesn't exist, remove from index | الملف غير موجود، إزالته من الفهرس
                    self._remove_entry(hashed_key, level=3)
            
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> bool:
        """
        Store value in cache \n تخزين القيمة في ذاكرة التخزين المؤقت
        
        Args:
            key: Cache key | مفتاح ذاكرة التخزين المؤقت
            value: Value to cache | القيمة المراد تخزينها مؤقتاً
            ttl: Time-to-live in seconds (None = use default) | وقت البقاء بالثواني (None = استخدام الافتراضي)
        
        Returns:
            True if successful, False otherwise | True إذا نجحت، False خلاف ذلك
        """
        with self.lock:
            try:
                self.metrics.record_set()
                hashed_key = self._hash_key(key)
                
                # Use provided TTL or config default | استخدام TTL المقدم أو الافتراضي من الإعدادات
                effective_ttl = ttl if ttl is not None else self.config.default_ttl
                
                # Remove from all levels first (update operation) | إزالة من جميع المستويات أولاً (عملية تحديث)
                self.delete(key)
                
                # Create entry | إنشاء عنصر
                entry = CacheEntry(
                    key=hashed_key,
                    value=value,
                    ttl=effective_ttl
                )
                
                # Add to L1 | إضافة إلى L1
                self._add_to_l1(hashed_key, entry)
                
                return True
                
            except Exception as e:
                logger.error(f"Failed to set cache entry {key}: {e}")
                return False
    
    def delete(self, key: str) -> bool:
        """
        Delete entry from all cache levels \n حذف العنصر من جميع مستويات ذاكرة التخزين المؤقت
        
        Args:
            key: Cache key | مفتاح ذاكرة التخزين المؤقت
        
        Returns:
            True if entry was found and deleted | True إذا تم العثور على العنصر وحذفه
        """
        with self.lock:
            hashed_key = self._hash_key(key)
            found = False
            
            if hashed_key in self.l1_cache:
                self._remove_entry(hashed_key, level=1)
                found = True
            
            if hashed_key in self.l2_cache:
                self._remove_entry(hashed_key, level=2)
                found = True
            
            if hashed_key in self.l3_cache:
                self._remove_entry(hashed_key, level=3)
                found = True
            
            return found
    
    def exists(self, key: str) -> bool:
        """
        Check if key exists in cache \n التحقق من وجود المفتاح في ذاكرة التخزين المؤقت
        
        Args:
            key: Cache key | مفتاح ذاكرة التخزين المؤقت
        
        Returns:
            True if key exists (and not expired) | True إذا كان المفتاح موجوداً (وغير منتهي الصلاحية)
        """
        with self.lock:
            hashed_key = self._hash_key(key)
            
            # Check L1 | فحص L1
            if hashed_key in self.l1_cache:
                entry = self.l1_cache[hashed_key]
                if not self._is_expired(entry):
                    return True
                self._remove_entry(hashed_key, level=1)
            
            # Check L2 | فحص L2
            if hashed_key in self.l2_cache:
                entry = self.l2_cache[hashed_key]
                if not self._is_expired(entry):
                    return True
                self._remove_entry(hashed_key, level=2)
            
            # Check L3 | فحص L3
            if hashed_key in self.l3_cache:
                meta = self.l3_cache[hashed_key]
                if os.path.exists(meta['path']) and not self._is_l3_expired(meta):
                    return True
                self._remove_entry(hashed_key, level=3)
            
            return False
    
    def clear(self, level: Optional[int] = None) -> None:
        """
        Clear cache(s) \n مسح ذاكرة/ذاكرات التخزين المؤقت
        
        Args:
            level: Cache level to clear (1, 2, 3, or None for all) | مستوى ذاكرة التخزين المؤقت للمسح (1، 2، 3، أو None للكل)
        """
        with self.lock:
            if level is None or level == 1:
                self.l1_cache.clear()
                self.l1_frequency.clear()
                self.l1_current_size = 0
                logger.info("L1 cache cleared")
            
            if level is None or level == 2:
                self.l2_cache.clear()
                self.l2_frequency.clear()
                self.l2_current_size = 0
                logger.info("L2 cache cleared")
            
            if level is None or level == 3:
                # Remove all L3 files | إزالة جميع ملفات L3
                for meta in self.l3_cache.values():
                    filepath = meta['path']
                    try:
                        if os.path.exists(filepath):
                            os.remove(filepath)
                    except Exception as e:
                        logger.error(f"Failed to remove L3 file {filepath}: {e}")
                
                self.l3_cache.clear()
                self.l3_current_size = 0
                logger.info("L3 cache cleared")
            
            if level is None:
                self.metrics.reset()
    
    def cleanup_expired(self) -> int:
        """
        Remove all expired entries \n إزالة جميع العناصر منتهية الصلاحية
        
        Returns:
            Number of entries removed | عدد العناصر المحذوفة
        """
        with self.lock:
            removed = 0
            
            # L1
            expired_l1 = [
                key for key, entry in self.l1_cache.items()
                if self._is_expired(entry)
            ]
            for key in expired_l1:
                self._remove_entry(key, level=1)
                removed += 1
            
            # L2
            expired_l2 = [
                key for key, entry in self.l2_cache.items()
                if self._is_expired(entry)
            ]
            for key in expired_l2:
                self._remove_entry(key, level=2)
                removed += 1
            
            # L3
            expired_l3 = [
                key for key, meta in self.l3_cache.items()
                if self._is_l3_expired(meta)
            ]
            for key in expired_l3:
                self._remove_entry(key, level=3)
                removed += 1
            
            if removed > 0:
                logger.info(f"Cleaned up {removed} expired entries")
                self.metrics.expirations += removed
            
            return removed
    
    def get_stats(self) -> dict:
        """
        Get cache statistics \n الحصول على إحصائيات ذاكرة التخزين المؤقت
        
        Returns:
            Dictionary with statistics | قاموس مع الإحصائيات
        """
        with self.lock:
            stats = self.metrics.get_stats()
            
            stats.update({
                'l1_items': len(self.l1_cache),
                'l1_size_mb': round(self.l1_current_size / (1024 * 1024), 2),
                'l1_max_items': self.config.l1_max_items,
                'l1_max_size_mb': self.config.l1_max_size_mb,
                'l1_utilization': round(len(self.l1_cache) / self.config.l1_max_items * 100, 2),
                
                'l2_items': len(self.l2_cache),
                'l2_size_mb': round(self.l2_current_size / (1024 * 1024), 2),
                'l2_max_items': self.config.l2_max_items,
                'l2_max_size_mb': self.config.l2_max_size_mb,
                'l2_utilization': round(len(self.l2_cache) / self.config.l2_max_items * 100, 2),
                
                'l3_items': len(self.l3_cache),
                'l3_size_mb': round(self.l3_current_size / (1024 * 1024), 2),
                'l3_max_items': self.config.l3_max_items,
                'l3_max_size_mb': self.config.l3_max_size_mb,
                'l3_utilization': round(len(self.l3_cache) / self.config.l3_max_items * 100, 2),
                
                'total_items': len(self.l1_cache) + len(self.l2_cache) + len(self.l3_cache),
                'total_size_mb': round((self.l1_current_size + self.l2_current_size + 
                                       self.l3_current_size) / (1024 * 1024), 2),
                
                'strategy': self.strategy.value,
                
            })
            
            return stats
    
    def get_keys(self, level: Optional[int] = None) -> List[str]:
        """
        Get all keys in cache \n الحصول على جميع المفاتيح في ذاكرة التخزين المؤقت
        
        Args:
            level: Cache level (1, 2, 3, or None for all) | مستوى ذاكرة التخزين المؤقت (1، 2، 3، أو None للكل)
        
        Returns:
            List of hashed keys | قائمة المفاتيح المجزأة
        """
        with self.lock:
            if level == 1:
                return list(self.l1_cache.keys())
            elif level == 2:
                return list(self.l2_cache.keys())
            elif level == 3:
                return list(self.l3_cache.keys())
            else:
                # All levels | جميع المستويات
                keys = set()
                keys.update(self.l1_cache.keys())
                keys.update(self.l2_cache.keys())
                keys.update(self.l3_cache.keys())
                return list(keys)
    
    def get_entry_info(self, key: str) -> Optional[dict]:
        """
        Get detailed information about a cache entry \n الحصول على معلومات مفصلة حول عنصر ذاكرة التخزين المؤقت
        
        Args:
            key: Cache key | مفتاح ذاكرة التخزين المؤقت
        
        Returns:
            Dictionary with entry information or None if not found | قاموس بمعلومات العنصر أو None إذا لم يتم العثور عليه
        """
        with self.lock:
            hashed_key = self._hash_key(key)
            
            # Check L1 | فحص L1
            if hashed_key in self.l1_cache:
                entry = self.l1_cache[hashed_key]
                return {
                    'level': 1,
                    'hits': entry.hits,
                    'age': entry.age(),
                    'idle_time': entry.idle_time(),
                    'size_bytes': entry.size_bytes,
                    'ttl': entry.ttl,
                    'expired': entry.is_expired()
                }
            
            # Check L2 | فحص L2
            if hashed_key in self.l2_cache:
                entry = self.l2_cache[hashed_key]
                return {
                    'level': 2,
                    'hits': entry.hits,
                    'age': entry.age(),
                    'idle_time': entry.idle_time(),
                    'size_bytes': entry.size_bytes,
                    'ttl': entry.ttl,
                    'expired': entry.is_expired()
                }
            
            # Check L3 | فحص L3
            if hashed_key in self.l3_cache:
                meta = self.l3_cache[hashed_key]
                return {
                    'level': 3,
                    'path': meta['path'],
                    'age': time.time() - meta['created_at'],
                    'ttl': meta.get('ttl'),
                    'expired': self._is_l3_expired(meta)
                }
            
            return None
    
    # ==========================================
    # Internal Methods - Promotion & Demotion | الطرق الداخلية - الترقية والتخفيض
    # ==========================================
    
    def _promote_to_l1(self, key: str, entry: CacheEntry) -> None:
        """
        Promote entry from L2 to L1 | ترقية العنصر من L2 إلى L1
        """
        if key in self.l1_cache:
            return
        
        # Remove from L2 | إزالة من L2
        if key in self.l2_cache:
            self._remove_entry(key, level=2)
        
        # Add to L1 | إضافة إلى L1
        self._add_to_l1(key, entry)
        
        self.metrics.record_promotion()
        logger.debug(f"Promoted {key[:8]}... to L1")
    
    def _promote_to_l2(self, key: str, entry: CacheEntry) -> None:
        """
        Promote entry from L3 to L2 | ترقية العنصر من L3 إلى L2
        """
        if key in self.l2_cache:
            return
        
        # Remove from L3 | إزالة من L3
        if key in self.l3_cache:
            self._remove_entry(key, level=3)
        
        # Add to L2 | إضافة إلى L2
        self._add_to_l2(key, entry)
        
        self.metrics.record_promotion()
        logger.debug(f"Promoted {key[:8]}... to L2")
    
    def _demote_to_l2(self, key: str, entry: CacheEntry) -> None:
        """
        Demote entry from L1 to L2 | تخفيض العنصر من L1 إلى L2
        """
        self._remove_entry(key, level=1)
        self._add_to_l2(key, entry)
        logger.debug(f"Demoted {key[:8]}... to L2")
    
    def _demote_to_l3(self, key: str, entry: CacheEntry) -> None:
        """
        Demote entry from L2 to L3 | تخفيض العنصر من L2 إلى L3
        """
        self._remove_entry(key, level=2)
        self._save_to_disk(key, entry)
        logger.debug(f"Demoted {key[:8]}... to L3")
    
    # ==========================================
    # Internal Methods - Adding Entries | الطرق الداخلية - إضافة العناصر
    # ==========================================
    
    def _add_to_l1(self, key: str, entry: CacheEntry) -> None:
        """
        Add entry to L1 cache | إضافة عنصر إلى ذاكرة التخزين المؤقت L1
        """
        # Check if eviction needed (item limit) | التحقق من الحاجة للإخلاء (حد العناصر)
        while len(self.l1_cache) >= self.config.l1_max_items:
            self._evict_from_l1()
        
        # Check if eviction needed (size limit) | التحقق من الحاجة للإخلاء (حد الحجم)
        max_size_bytes = self.config.l1_max_size_mb * 1024 * 1024
        while self.l1_current_size + entry.size_bytes > max_size_bytes and self.l1_cache:
            self._evict_from_l1()
        
        # Add entry | إضافة العنصر
        self.l1_cache[key] = entry
        self.l1_cache.move_to_end(key)
        self.l1_frequency[key] = entry.hits
        self.l1_current_size += entry.size_bytes
    
    def _add_to_l2(self, key: str, entry: CacheEntry) -> None:
        """
        Add entry to L2 cache | إضافة عنصر إلى ذاكرة التخزين المؤقت L2
        """
        # Check if eviction needed (item limit) | التحقق من الحاجة للإخلاء (حد العناصر)
        while len(self.l2_cache) >= self.config.l2_max_items:
            self._evict_from_l2()
        
        # Check if eviction needed (size limit) | التحقق من الحاجة للإخلاء (حد الحجم)
        max_size_bytes = self.config.l2_max_size_mb * 1024 * 1024
        while self.l2_current_size + entry.size_bytes > max_size_bytes and self.l2_cache:
            self._evict_from_l2()
        
        # Add entry | إضافة العنصر
        self.l2_cache[key] = entry
        self.l2_cache.move_to_end(key)
        self.l2_frequency[key] = entry.hits
        self.l2_current_size += entry.size_bytes
    
    # ==========================================
    # Internal Methods - Eviction | الطرق الداخلية - الإخلاء
    # ==========================================
    
    def _evict_from_l1(self) -> None:
        """
        Evict one entry from L1 | إخلاء عنصر واحد من L1
        """
        if not self.l1_cache:
            return
        
        victim_key = self._select_victim(self.l1_cache, self.l1_frequency)
        
        if victim_key:
            entry = self.l1_cache[victim_key]
            self._demote_to_l2(victim_key, entry)
            self.metrics.record_eviction()
    
    def _evict_from_l2(self) -> None:
        """
        Evict one entry from L2 | إخلاء عنصر واحد من L2
        """
        if not self.l2_cache:
            return
        
        victim_key = self._select_victim(self.l2_cache, self.l2_frequency)
        
        if victim_key:
            entry = self.l2_cache[victim_key]
            
            # Check if L3 has space | التحقق من توفر مساحة في L3
            if len(self.l3_cache) >= self.config.l3_max_items:
                self._evict_from_l3()
            
            # Check L3 size limit | التحقق من حد حجم L3
            max_l3_bytes = self.config.l3_max_size_mb * 1024 * 1024
            while self.l3_current_size + entry.size_bytes > max_l3_bytes and self.l3_cache:
                self._evict_from_l3()
            
            self._demote_to_l3(victim_key, entry)
            self.metrics.record_eviction()
    
    def _evict_from_l3(self) -> None:
        """
        Evict one entry from L3 | إخلاء عنصر واحد من L3
        """
        if not self.l3_cache:
            return
        
        # Try to remove expired first | محاولة إزالة المنتهية الصلاحية أولاً
        for key, meta in list(self.l3_cache.items()):
            if self._is_l3_expired(meta):
                self._remove_entry(key, level=3)
                self.metrics.record_eviction()
                return
        
        # Fallback to FIFO (oldest entry) | الرجوع إلى FIFO (العنصر الأقدم)
        oldest_key = next(iter(self.l3_cache))
        self._remove_entry(oldest_key, level=3)
        self.metrics.record_eviction()
    
    def _select_victim(self, cache: OrderedDict, frequency: Counter) -> Optional[str]:
        """
        Select victim for eviction based on strategy | اختيار الضحية للإخلاء بناءً على الاستراتيجية
        
        Args:
            cache: Cache to select from | ذاكرة التخزين المؤقت للاختيار منها
            frequency: Frequency counter for LFU | عداد التكرار لـ LFU
        
        Returns:
            Key to evict or None | المفتاح المراد إخلاؤه أو None
        """
        if not cache:
            return None
        
        if self.strategy == CacheStrategy.LRU:
            # Oldest accessed (first in OrderedDict) | الأقدم وصولاً (الأول في القاموس المرتب)
            return next(iter(cache.keys()))
        
        elif self.strategy == CacheStrategy.LFU:
            # Least frequently used | الأقل استخداماً
            if frequency:
                return frequency.most_common()[-1][0]
            return next(iter(cache.keys()))
        
        elif self.strategy == CacheStrategy.FIFO:
            # Oldest created (first in OrderedDict) | الأقدم إنشاءً (الأول في القاموس المرتب)
            return next(iter(cache.keys()))
        
        elif self.strategy == CacheStrategy.TTL:
            # Find first expired, or oldest if none expired | البحث عن أول منتهي الصلاحية، أو الأقدم إذا لم يكن هناك منتهي الصلاحية
            for key, entry in cache.items():
                if self._is_expired(entry):
                    return key
            return next(iter(cache.keys()))
        
        elif self.strategy == CacheStrategy.ADAPTIVE:
            # Adaptive: Consider both frequency and recency | تكيفي: النظر في التكرار والحداثة معاً
            # Score = (hits / (idle_time + 1)) | النتيجة = (الإصابات / (وقت الخمول + 1))
            # Lower score = better victim | نتيجة أقل = ضحية أفضل
            best_victim = None
            best_score = float('inf')
            
            for key, entry in cache.items():
                idle = entry.idle_time()
                score = entry.hits / (idle + 1)
                if score < best_score:
                    best_score = score
                    best_victim = key
            
            return best_victim or next(iter(cache.keys()))
        
        else:
            # Default to LRU | الافتراضي إلى LRU
            return next(iter(cache.keys()))
    
    # ==========================================
    # Internal Methods - Utilities | الطرق الداخلية - الأدوات المساعدة
    # ==========================================
    
    def _hash_key(self, key: str) -> str:
        """
        Generate SHA-256 hash of key for consistent storage | توليد تجزئة SHA-256 للمفتاح للتخزين المتسق
        
        Args:
            key: Original key | المفتاح الأصلي
        
        Returns:
            Hexadecimal hash string | سلسلة التجزئة السداسية عشرية
        """
        return hashlib.sha256(key.encode('utf-8')).hexdigest()
    
    def _is_l3_expired(self, meta: dict) -> bool:
        """
        Check if L3 entry has expired | التحقق من انتهاء صلاحية عنصر L3
        """
        if meta.get("ttl") is None:
            return False
        return time.time() > meta["created_at"] + meta["ttl"]
    
    def _access_entry(self, entry: CacheEntry, level: int) -> None:
        """
        Update entry metadata on access | تحديث البيانات الوصفية للعنصر عند الوصول
        """
        entry.increment_hits()
        
        # Update frequency counter | تحديث عداد التكرار
        if level == 1:
            self.l1_frequency[entry.key] = entry.hits
            self.l1_cache.move_to_end(entry.key)
        elif level == 2:
            self.l2_frequency[entry.key] = entry.hits
            self.l2_cache.move_to_end(entry.key)
    
    def _remove_entry(self, key: str, level: int) -> None:
        """
        Remove entry from specified level | إزالة العنصر من المستوى المحدد
        """
        if level == 1 and key in self.l1_cache:
            entry = self.l1_cache.pop(key)
            self.l1_frequency.pop(key, None)
            self.l1_current_size -= entry.size_bytes
        
        elif level == 2 and key in self.l2_cache:
            entry = self.l2_cache.pop(key)
            self.l2_frequency.pop(key, None)
            self.l2_current_size -= entry.size_bytes
        
        elif level == 3 and key in self.l3_cache:
            meta = self.l3_cache.pop(key)
            filepath = meta['path']
            try:
                if os.path.exists(filepath):
                    file_size = os.path.getsize(filepath)
                    os.remove(filepath)
                    self.l3_current_size -= file_size
            except Exception as e:
                logger.error(f"Failed to remove L3 file {filepath}: {e}")
    
    def _is_expired(self, entry: CacheEntry) -> bool:
        """
        Check if entry has expired | التحقق من انتهاء صلاحية العنصر
        """
        return entry.is_expired()
    
    def _save_to_disk(self, key: str, entry: CacheEntry) -> None:
        """
        Save entry to disk (L3) | حفظ العنصر على القرص (L3)
        """
        filepath = self.cache_dir / f"{key}.pkl"
        
        try:
            with open(filepath, 'wb') as f:
                pickle.dump(entry.value, f, protocol=pickle.HIGHEST_PROTOCOL)
            
            file_size = os.path.getsize(filepath)
            
            self.l3_cache[key] = {
                "path": str(filepath),
                "created_at": entry.created_at,
                "ttl": entry.ttl,
                "size": file_size
            }
            
            self.l3_current_size += file_size
            
        except Exception as e:
            logger.error(f"Failed to save to disk: {e}")
            if os.path.exists(filepath):
                os.remove(filepath)
    
    def _load_from_disk(self, filepath: str) -> Any:
        """
        Load entry from disk (L3) | تحميل العنصر من القرص (L3)
        """
        with open(filepath, 'rb') as f:
            return pickle.load(f)
    
    def _schedule_cleanup(self) -> None:
        """
        Schedule periodic cleanup of expired entries | جدولة التنظيف الدوري للعناصر منتهية الصلاحية
        """
        def cleanup_task():
            try:
                self.cleanup_expired()
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")
            finally:
                # Reschedule | إعادة الجدولة
                if self.config.auto_cleanup_interval:
                    self._schedule_cleanup()
        
        self._cleanup_timer = threading.Timer(
            self.config.auto_cleanup_interval,
            cleanup_task
        )
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()
    
    def _cancel_cleanup(self) -> None:
        """
        Cancel scheduled cleanup | إلغاء التنظيف المجدول
        """
        if self._cleanup_timer:
            self._cleanup_timer.cancel()
            self._cleanup_timer = None
    
    # ==========================================
    # Batch Operations | العمليات الدفعية
    # ==========================================
    
    def get_many(self, keys: List[str]) -> Dict[str, Any]:
        """
        Get multiple values at once \n الحصول على قيم متعددة دفعة واحدة
        
        Args:
            keys: List of cache keys | قائمة مفاتيح ذاكرة التخزين المؤقت
        
        Returns:
            Dictionary of key-value pairs (only found keys) | قاموس أزواج المفتاح-القيمة (المفاتيح الموجودة فقط)
        """
        result = {}
        for key in keys:
            value = self.get(key)
            if value is not None:
                result[key] = value
        return result
    
    def set_many(self, items: Dict[str, Any], ttl: Optional[float] = None) -> int:
        """
        Set multiple values at once \n تعيين قيم متعددة دفعة واحدة
        
        Args:
            items: Dictionary of key-value pairs to cache | قاموس أزواج المفتاح-القيمة للتخزين المؤقت
            ttl: Time-to-live for all items | وقت البقاء لجميع العناصر
        
        Returns:
            Number of successfully set items | عدد العناصر التي تم تعيينها بنجاح
        """
        count = 0
        for key, value in items.items():
            if self.set(key, value, ttl):
                count += 1
        return count
    
    def delete_many(self, keys: List[str]) -> int:
        """
        Delete multiple keys at once \n حذف مفاتيح متعددة دفعة واحدة
        
        Args:
            keys: List of keys to delete | قائمة المفاتيح المراد حذفها
        
        Returns:
            Number of deleted keys | عدد المفاتيح المحذوفة
        """
        count = 0
        for key in keys:
            if self.delete(key):
                count += 1
        return count
    
    # ==========================================
    # Context Manager Support | دعم مدير السياق
    # ==========================================
    
    def __enter__(self):
        """
        Context manager entry | دخول مدير السياق
        """
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit - cleanup | خروج مدير السياق - التنظيف
        """
        self._cancel_cleanup()
        if self.persist_l3:
            # Clear L1 and L2 only; keep L3 files on disk
            self.clear(level=1)
            self.clear(level=2)
            logger.info("Cache closed: L1 and L2 cleared. L3 persisted on disk.")
        else:
            self.clear()
    
    def __repr__(self) -> str:
        """
        String representation | التمثيل النصي
        """
        return (f"MultiLevelCache(L1={len(self.l1_cache)}/{self.config.l1_max_items}, "
                f"L2={len(self.l2_cache)}/{self.config.l2_max_items}, "
                f"L3={len(self.l3_cache)}/{self.config.l3_max_items}, "
                f"strategy={self.strategy.value}, "
                f"hit_rate={self.metrics.get_hit_rate():.2%})")
    
    def __len__(self) -> int:
        """
        Total number of cached items | العدد الإجمالي للعناصر المخزنة مؤقتاً
        """
        with self.lock:
            return len(self.l1_cache) + len(self.l2_cache) + len(self.l3_cache)
    
    def __contains__(self, key: str) -> bool:
        """
        Support 'in' operator | دعم عامل 'in'
        """
        return self.exists(key)
    # ── Async API ────────────────────────────────────────────────────

    async def aget(self, key: str):
        """Async cache get — كاش غير متزامن"""
        import asyncio
        return await asyncio.to_thread(self.get, key)

    async def aset(self, key: str, value, ttl=None) -> bool:
        """Async cache set — تخزين غير متزامن"""
        import asyncio
        return await asyncio.to_thread(self.set, key, value, ttl)

    async def adelete(self, key: str) -> bool:
        """Async cache delete"""
        import asyncio
        return await asyncio.to_thread(self.delete, key)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False