from collections import defaultdict
from typing import List, Dict, Optional
import threading
import statistics
import time

from .metrics_point import MetricPoint
from .timer_context import TimerContext


class MetricsCollector:
    """Thread-safe metrics collector supporting counters, gauges, histograms, and timers\n
       counters, gauges, histograms كلاس يجمع عمليات القياس المتعدده مثل 
    
    Features:
        - Counters: Monotonically increasing values it's increment only
        - Gauges: Point-in-time measurements it's increment or decrement
        - Histograms: Statistical distribution of values stage all values and calculate statistics
        - Timers: Execution time measurements
        - Thread-safe operations
        - Memory-limited storage
        - Multiple export formats (Prometheus, JSON)
    
    Example:
        collector = MetricsCollector()
        
        # Increment counter
        collector.increment('requests', tags={'endpoint': '/api'})
        
        # Record gauge
        collector.gauge('cpu_usage', 75.5)
        
        # Time operations
        with collector.timer('db_query'):
            # database operation
            pass
    """
    
    def __init__(self, max_metrics: int = 10000):
        """Initialize metrics collector
        
        Args:
            max_metrics: Maximum number of metrics to keep in memory
        """
        self.metrics: List[MetricPoint] = []
        self.counters: Dict[str, float] = defaultdict(float)
        self.gauges: Dict[str, float] = {}
        self.histograms: Dict[str, List[float]] = defaultdict(list)
        self.max_metrics = max_metrics
        self._lock = threading.RLock()
        self._timer_context = TimerContext(self)
        self.all_keys : List[str] = []
    
    # ==================== Counter Operations ====================
    
    def increment(self, name: str, value: float = 1, tags: Optional[Dict] = None):
        """Increment a counter metric
        
        Args:
            name: Counter name
            value: Amount to increment (default: 1)
            tags: Optional categorization tags
        """
        with self._lock:
            key = self._make_key(name, tags)
            self.counters[key] += value
            self.counters[name]+=value
            self._record_metric(name, self.counters[key], tags)
    
    def decrement(self, name: str, value: float = 1, tags: Optional[Dict] = None):
        """Decrement a counter metric
        
        Args:
            name: Counter name
            value: Amount to decrement (default: 1)
            tags: Optional categorization tags
        """
        self.increment(name, -value, tags)
    
    def reset_counter(self, name: str, tags: Optional[Dict] = None):
        """Reset specific counter to zero
        
        Args:
            name: Counter name
            tags: Optional tags to match specific counter
        """
        with self._lock:
            key = self._make_key(name, tags)
            if key in self.counters:
                self.counters[key] = 0
    
    # ==================== Gauge Operations ====================
    
    def gauge(self, name: str, value: float, tags: Optional[Dict] = None):
        """Record a gauge measurement (value that changes over time)
        
        Args:
            name: Gauge name
            value: Current value
            tags: Optional categorization tags
        """
        with self._lock:
            key = self._make_key(name, tags)
            self.gauges[key] = value
            self._record_metric(name, value, tags)
    
    # ==================== Histogram Operations ====================
    
    def histogram(self, name: str, value: float, tags: Optional[Dict] = None):
        """Add value to histogram for statistical analysis
        
        Args:
            name: Histogram name
            value: Value to record
            tags: Optional categorization tags
        """
        with self._lock:
            key = self._make_key(name, tags)
            self.histograms[key].append(value)
            self._record_metric(name, value, tags)
    
    # ==================== Timer Operations ====================
    
    def timer(self, name: str, tags: Optional[Dict] = None):
        """Get timer context manager
        
        Usage:
            with collector.timer('operation'):
                # code to measure
                pass
        
        Args:
            name: Timer name
            tags: Optional categorization tags
            
        Returns:
            Context manager for timing
        """
        return self._timer_context.timer(name, tags)
    
    def measure(self, name: str, tags: Optional[Dict] = None):
        """Get decorator for timing functions
        
        Usage:
            @collector.measure('function_name')
            def my_function():
                pass
        
        Args:
            name: Timer name
            tags: Optional categorization tags
            
        Returns:
            Function decorator
        """
        return self._timer_context.measure(name, tags)
    
    # ==================== Query Operations ====================
    
    def get_metrics_by_name(self, name: str) -> List[MetricPoint]:
        """Retrieve all metrics with specific name
        
        Args:
            name: Metric name to search for
            
        Returns:
            List of matching metric points
        """
        with self._lock:
            return [m for m in self.metrics if m.name == name]
    
    def get_metrics_by_tag(self, tag_key: str, tag_value: str) -> List[MetricPoint]:
        """Retrieve all metrics with specific tag
        
        Args:
            tag_key: Tag key to search
            tag_value: Tag value to match
            
        Returns:
            List of matching metric points
        """
        with self._lock:
            return [m for m in self.metrics 
                   if m.tags.get(tag_key) == tag_value]
    
    def get_summary(self) -> Dict:
        """Get comprehensive summary of all metrics
        
        Returns:
            Dictionary containing:
                - counters: All counter values
                - gauges: All gauge values
                - histograms: Statistical summaries
                - total_metrics: Count of recorded metrics
        """
        with self._lock:
            summary = {
                'counters': dict(self.counters),
                'gauges': dict(self.gauges),
                'histograms': {},
                'total_metrics': len(self.metrics)
            }
            
            # Calculate histogram statistics
            for key, values in self.histograms.items():
                if values:
                    summary['histograms'][key] = self._calculate_stats(values)
            
            return summary
    
    # ==================== Export Operations ====================
    
    def export_prometheus(self) -> str:
        """Export metrics in Prometheus format
        
        Returns:
            Prometheus-formatted metrics string
        """
        with self._lock:
            lines = []
            
            # Export counters
            for name, value in self.counters.items():
                clean_name = self._clean_prometheus_name(name)
                lines.append(f'# TYPE {clean_name} counter')
                lines.append(f'{clean_name} {value}')
            
            # Export gauges
            for name, value in self.gauges.items():
                clean_name = self._clean_prometheus_name(name)
                lines.append(f'# TYPE {clean_name} gauge')
                lines.append(f'{clean_name} {value}')
            
            # Export histograms
            for name, values in self.histograms.items():
                if values:
                    clean_name = self._clean_prometheus_name(name)
                    lines.append(f'# TYPE {clean_name} histogram')
                    stats = self._calculate_stats(values)
                    lines.append(f'{clean_name}_count {stats["count"]}')
                    lines.append(f'{clean_name}_sum {stats["sum"]}')
                    lines.append(f'{clean_name}_avg {stats["mean"]}')
            
            return '\n'.join(lines)
    
    def export_json(self) -> Dict:
        """Export metrics in JSON format
        
        Returns:
            Dictionary containing summary and recent metrics
        """
        with self._lock:
            return {
                'summary': self.get_summary(),
                'recent_metrics': [m.to_dict() for m in self.metrics[-100:]]
            }
    
    # ==================== Management Operations ====================
    
    def clear(self):
        """Clear all metrics and reset all counters"""
        with self._lock:
            self.metrics.clear()
            self.counters.clear()
            self.gauges.clear()
            self.histograms.clear()
    
    # ==================== Internal Helper Methods ====================
    
    def _make_key(self, name: str, tags: Optional[Dict] = None) -> str:
        """Create unique key from name and tags
        
        Args:
            name: Metric name
            tags: Optional tags
            
        Returns:
            Unique key string
        """
        if not tags:
            return name
        tag_str = ','.join(f"{k}={v}" for k, v in sorted(tags.items()))
        return f"{name}{{{tag_str}}}"
    
    def _record_metric(self, name: str, value: float, tags: Optional[Dict] = None):
        """Record metric point with memory management
        
        Args:
            name: Metric name
            value: Metric value
            tags: Optional tags
        """
        metric = MetricPoint(
            name=name,
            value=value,
            timestamp=time.time(),
            tags=tags or {}
        )
        self.metrics.append(metric)
        
        # Enforce memory limit
        if len(self.metrics) > self.max_metrics:
            self.metrics = self.metrics[-self.max_metrics:]
    
    def _calculate_stats(self, values: List[float]) -> Dict:
        """Calculate detailed statistics for values
        
        Args:
            values: List of numeric values
            
        Returns:
            Dictionary with statistical measures
        """
        if not values:
            return {}
        
        sorted_values = sorted(values)
        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'mean': statistics.mean(values),
            'median': statistics.median(values),
            'stdev': statistics.stdev(values) if len(values) > 1 else 0,
            'sum': sum(values),
            'p50': self._percentile(sorted_values, 50),
            'p90': self._percentile(sorted_values, 90),
            'p95': self._percentile(sorted_values, 95),
            'p99': self._percentile(sorted_values, 99)
        }
    
    def _percentile(self, sorted_values: List[float], p: float) -> float:
        """Calculate percentile with linear interpolation
        
        Args:
            sorted_values: Pre-sorted list of values
            p: Percentile (0-100)
            
        Returns:
            Percentile value
        """
        if not sorted_values:
            return 0.0
        
        k = (len(sorted_values) - 1) * p / 100
        f = int(k)
        c = f + 1
        
        if c >= len(sorted_values):
            return sorted_values[-1]
        
        # Linear interpolation
        d0 = sorted_values[f] * (c - k)
        d1 = sorted_values[c] * (k - f)
        return d0 + d1
    
    def _clean_prometheus_name(self, name: str) -> str:
        """Clean metric name for Prometheus format
        
        Args:
            name: Original metric name
            
        Returns:
            Prometheus-compatible name
        """
        return (name.replace('{', '_')
                   .replace('}', '')
                   .replace(',', '_')
                   .replace('=', '_'))
    
    def __repr__(self) -> str:
        return (f"MetricsCollector(metrics={len(self.metrics)}, "
                f"counters={len(self.counters)}, "
                f"gauges={len(self.gauges)})")


# ==================== Global Collector Instance ====================

_global_collector = MetricsCollector()


def get_collector() -> MetricsCollector:
    """Get the global metrics collector instance
    
    Returns:
        Global MetricsCollector instance
    """
    return _global_collector


# ==================== Convenience Functions ====================

def increment(name: str, value: float = 1, tags: Optional[Dict] = None):
    """Increment global counter (convenience function)"""
    _global_collector.increment(name, value, tags)


def gauge(name: str, value: float, tags: Optional[Dict] = None):
    """Record global gauge (convenience function)"""
    _global_collector.gauge(name, value, tags)


def histogram(name: str, value: float, tags: Optional[Dict] = None):
    """Record global histogram value (convenience function)"""
    _global_collector.histogram(name, value, tags)


def timer(name: str, tags: Optional[Dict] = None):
    """Get global timer context (convenience function)"""
    return _global_collector.timer(name, tags)


def measure(name: str, tags: Optional[Dict] = None):
    """Get global measure decorator (convenience function)"""
    return _global_collector.measure(name, tags)