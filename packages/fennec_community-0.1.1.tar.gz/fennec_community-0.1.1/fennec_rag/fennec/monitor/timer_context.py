"""Timer Context Manager and Decorator"""
import time
from contextlib import contextmanager
from typing import Optional, Dict, Callable
from functools import wraps


class TimerContext:
    """Timer utilities for measuring execution time"""
    
    def __init__(self, collector):
        """Initialize timer with a metrics collector
        
        Args:
            collector: MetricsCollector instance to record measurements
        """
        self.collector = collector
    
    @contextmanager
    def timer(self, name: str, tags: Optional[Dict] = None):
        """Context manager for timing code blocks
        
        Usage:
            with timer_context.timer('operation_name'):
                # code to measure
                pass
        
        Args:
            name: Name of the timer metric
            tags: Optional tags for categorization
        """
        start_time = time.time()
        try:
            yield
        finally:
            duration = time.time() - start_time
            self.collector.histogram(name, duration, tags)
    
    def measure(self, name: str, tags: Optional[Dict] = None) -> Callable:
        """Decorator for timing function execution
        
        Usage:
            @timer_context.measure('function_name')
            def my_function():
                pass
        
        Args:
            name: Name of the timer metric
            tags: Optional tags for categorization
            
        Returns:
            Decorated function
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs):
                with self.timer(name, tags):
                    return func(*args, **kwargs)
            return wrapper
        return decorator