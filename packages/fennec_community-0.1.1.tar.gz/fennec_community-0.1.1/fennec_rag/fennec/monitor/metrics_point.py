"""Metric Point Data Structure"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict


@dataclass
class MetricPoint:
    """A single metric measurement point
    
    Attributes:
        name: Metric name
        value: Measured value
        timestamp: Unix timestamp when metric was recorded
        tags: Optional key-value tags for categorization
    """
    name: str
    value: float
    timestamp: float
    tags: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convert metric point to dictionary format
        
        Returns:
            Dictionary containing all metric data including ISO formatted datetime
        """
        return {
            'name': self.name,
            'value': self.value,
            'timestamp': self.timestamp,
            'datetime': datetime.fromtimestamp(self.timestamp).isoformat(),
            'tags': self.tags
        }
    
    def __repr__(self) -> str:
        return f"MetricPoint(name={self.name}, value={self.value}, tags={self.tags})"