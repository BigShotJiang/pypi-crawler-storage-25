from typing import  Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
import time


@dataclass
class RouteMetrics:
    """مقاييس أداء المسار
      metrics for a route.
    
    """
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    total_processing_time: float = 0.0
    average_similarity: float = 0.0
    last_used: Optional[float] = None

    @property
    def success_rate(self) -> float:
        """معدل النجاح
           success rate 
        """
        return (self.successful_calls / self.total_calls * 100) if self.total_calls > 0 else 0.0

    @property
    def average_processing_time(self) -> float:
        """متوسط وقت المعالجة
             average processing time
        """
        return (self.total_processing_time / self.total_calls) if self.total_calls > 0 else 0.0

    def record_call(self, success: bool, similarity: float, processing_time: float):
        """تسجيل استدعاء مع تحديث متوسط التشابه بدقة
            record a call and update the average similarity in real-time.
        """
        self.total_calls += 1
        if success:
            self.successful_calls += 1
        else:
            self.failed_calls += 1

        self.total_processing_time += processing_time

        # تحديث متوسط التشابه بشكل تراكمي
        if similarity > 0.0:
            self.average_similarity = (
                (self.average_similarity * (self.total_calls - 1) + similarity)
                / self.total_calls
            )

        self.last_used = time.time()

    def reset(self):
        """إعادة تعيين المقاييس
            reset the metrics.
        """
        self.total_calls = 0
        self.successful_calls = 0
        self.failed_calls = 0
        self.total_processing_time = 0.0
        self.average_similarity = 0.0
        self.last_used = None

    def to_dict(self) -> Dict[str, Any]:
        """تحويل إلى قاموس
           convert to a dictionary
        """
        return {
            'total_calls': self.total_calls,
            'successful_calls': self.successful_calls,
            'failed_calls': self.failed_calls,
            'success_rate': round(self.success_rate, 2),
            'average_processing_time_ms': round(self.average_processing_time * 1000, 2),
            'average_similarity': round(self.average_similarity, 4),
            'last_used': (
                datetime.fromtimestamp(self.last_used).isoformat()
                if self.last_used else None
            )
        }
