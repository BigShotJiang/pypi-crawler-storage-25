from dataclasses import dataclass


@dataclass
class RouterConfig:
    """إعدادات الموجه الدلالي"""
    model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    similarity_threshold: float = 0.7
    similarity_metric: str = "cosine"   # "cosine" أو "euclidean"
    use_cache: bool = True
    cache_ttl: int = 300                # ثواني (5 دقائق)
    cache_max_size: int = 1000
    enable_logging: bool = True
    log_level: str = "INFO"
    auto_encode_examples: bool = True
    batch_encoding: bool = True
    batch_size: int = 32                # حجم الدفعة عند الترميز
    top_k_alternatives: int = 3 
    