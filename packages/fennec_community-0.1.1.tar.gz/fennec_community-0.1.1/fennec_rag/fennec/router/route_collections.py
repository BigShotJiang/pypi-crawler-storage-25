from typing import Dict, List, Optional, Any
from .route import Route



class RouteCollection:
    """
    مجموعة مسارات مع إمكانيات إدارة متقدمة.
    تدعم الإضافة، الحذف، التحديث، والترتيب حسب الأولوية.
    route collection with ability adv manage
    """

    def __init__(self):
        self._routes: Dict[str, Route] = {}

    # للتوافق مع الكود القديم الذي يصل إلى .routes مباشرة
    @property
    def routes(self) -> Dict[str, Route]:
        return self._routes

    def add(self, route: Route):
        """
        إضافة مسار.
        add a route.

        Raises:
            ValueError: إذا كان المسار موجودًا مسبقًا | if the route already exists
        """
        if route.name in self._routes:
            raise ValueError(f"The route '{route.name}' already exists , use update(route)")
        self._routes[route.name] = route

    def update(self, route: Route):
        """إضافة مسار أو استبداله إذا كان موجودًا
        add or update a route, replacing it if it already exists 
        """
        self._routes[route.name] = route

    def remove(self, name: str) -> bool:
        """
        إزالة مسار.
        remove a route.

        Returns:
            True عند النجاح، False إذا لم يُعثر على المسار | True on success, False otherwise
        """
        if name in self._routes:
            del self._routes[name]
            return True
        return False

    def get(self, name: str) -> Optional[Route]:
        """الحصول على مسار بالاسم أو None
           get a route by name or None if not found 
        """
        return self._routes.get(name)

    def get_enabled(self) -> List[Route]:
        """قائمة بالمسارات المفعّلة فقط
           list of enabled routes only
        """
        return [r for r in self._routes.values() if r.enabled]

    def get_by_priority(self, descending: bool = True) -> List[Route]:
        """قائمة المسارات مرتبة تنازليًا (افتراضي) حسب الأولوية
           list of routes sorted in descending order (default) by priority
         """
        return sorted(self._routes.values(), key=lambda r: r.priority, reverse=descending)

    def enable_all(self):
        """تفعيل جميع المسارات 
           enable all routes
        """
        for route in self._routes.values():
            route.enable()

    def disable_all(self):
        """تعطيل جميع المسارات 
           disable all routes
        """
        for route in self._routes.values():
            route.disable()

    def get_statistics(self) -> Dict[str, Any]:
        """إحصائيات مجمّعة للمجموعة
           statistics for the collection
        """
        total_calls = sum(r.metrics.total_calls for r in self._routes.values())
        total_examples = sum(len(r.examples) for r in self._routes.values())
        count = len(self._routes)

        return {
            'total_routes': count,
            'enabled_routes': len(self.get_enabled()),
            'total_calls': total_calls,
            'total_examples': total_examples,
            'average_examples_per_route': round(total_examples / count, 2) if count else 0
        }

    def __len__(self) -> int:
        return len(self._routes)

    def __iter__(self):
        return iter(self._routes.values())

    def __contains__(self, name: str) -> bool:
        return name in self._routes

    def __repr__(self) -> str:
        return f"RouteCollection({len(self._routes)} routes)"
