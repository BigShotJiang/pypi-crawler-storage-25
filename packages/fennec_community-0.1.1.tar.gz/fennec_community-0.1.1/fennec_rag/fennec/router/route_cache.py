import time
from typing import Any, Dict, Optional, Tuple


class SimpleCache:
    """
    Default Memory For Using Faster\n
    كاش في الذاكرة مع TTL وحجم أقصى
    """

    def __init__(self, ttl: int = 300, max_size: int = 1000):
        self._cache: Dict[str, Tuple[Any, float]] = {}
        self.ttl = ttl
        self.max_size = max_size
        self.hits = 0
        self.misses = 0

    def get(self, key: str) -> Optional[Any]:
        """
        Get Value From Cache By Key\n
        الحصول علي قيمه من الذاكره الافتراضيه باستخدام المفتاح الخاص بالقيمه
        """
        if key in self._cache:
            value, timestamp = self._cache[key]
            if time.time() - timestamp < self.ttl:
                self.hits += 1
                return value
            del self._cache[key]
        self.misses += 1
        return None

    def set(self, key: str, value: Any):
        """"
        Save a New Value In Cache By Key\n
        تسجيل قيمه جديده في الذاكره الافتراضيه باستخدام المفتاح الخاص بيها
        """
        if len(self._cache) >= self.max_size:
            self._evict()
        self._cache[key] = (value, time.time())

    def _evict(self):
        """حذف العناصر المنتهية ثم أقدم 25% إذا لزم"""
        now = time.time()
        expired = [k for k, (_, t) in self._cache.items() if now - t >= self.ttl]
        for k in expired:
            del self._cache[k]

        if len(self._cache) >= self.max_size:
            oldest = sorted(self._cache.items(), key=lambda x: x[1][1])
            for k, _ in oldest[:max(1, len(oldest) // 4)]:
                del self._cache[k]

    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return (self.hits / total * 100) if total else 0.0

    def clear(self):
        self._cache.clear()
        self.hits = 0
        self.misses = 0

    def __len__(self) -> int:
        return len(self._cache)
