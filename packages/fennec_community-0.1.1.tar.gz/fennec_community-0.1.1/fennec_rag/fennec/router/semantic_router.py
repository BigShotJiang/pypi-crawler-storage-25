import hashlib
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Tuple
import numpy as np
from .route import Route
from .route_collections import RouteCollection
from .route_config import RouterConfig
from .route_result import RoutingResult
from .route_cache import SimpleCache
try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None  # type: ignore



# إعداد السجلات
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(name)s: %(message)s')
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# دوال التشابه
# ------------------------------------------------------------------ #

def cosine_similarity(a: List[float], b: List[float]) -> float:
    """حساب تشابه الكوساين بين متجهين — يتجنب القسمة على صفر
    """
    a_arr, b_arr = np.array(a, dtype=np.float32), np.array(b, dtype=np.float32)
    norm_a, norm_b = np.linalg.norm(a_arr), np.linalg.norm(b_arr)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(np.dot(a_arr, b_arr) / (norm_a * norm_b))


def euclidean_distance(a: List[float], b: List[float]) -> float:
    """حساب المسافة الإقليدية بين متجهين"""
    return float(np.linalg.norm(np.array(a, dtype=np.float32) - np.array(b, dtype=np.float32)))



# ------------------------------------------------------------------ #
# الموجه الدلالي الرئيسي
# ------------------------------------------------------------------ #

class SemanticRouter:
    """
    موجه دلالي ذكي يستخدم Sentence Transformers.
    semantic router that uses Sentence Transformers.


    الاستخدام الأساسي:
        router = SemanticRouter()
        router.add_route(my_route)
        result = router.route("استفساري")

    دعم context manager:
        with SemanticRouter() as router:
            ...
    """

    def __init__(
        self,
        config: Optional[RouterConfig] = None,
        model_name: Optional[str] = None,
        similarity_threshold: Optional[float] = None
    ):
        self.config = config or RouterConfig()

        # تجاوز الإعدادات بالمعاملات المباشرة
        if model_name:
            self.config.model_name = model_name
        if similarity_threshold is not None:
            self.config.similarity_threshold = similarity_threshold

        # تحميل النموذج
        logger.info(f"load model: {self.config.model_name}")
        if SentenceTransformer is None:
            raise ImportError(
                "sentence-transformers is required for SemanticRouter. "
                "Install it with: pip install sentence-transformers"
            )
        self.embedding_model = SentenceTransformer(self.config.model_name)

        # المسارات
        self.routes = RouteCollection()

        # الكاش
        self.cache: Optional[SimpleCache] = (
            SimpleCache(ttl=self.config.cache_ttl, max_size=self.config.cache_max_size)
            if self.config.use_cache else None
        )

        # المعالج الاحتياطي
        self.fallback_handler: Optional[Callable] = None

        # الإحصائيات
        self.total_queries = 0
        self.successful_routes = 0
        self.failed_routes = 0
        self.total_processing_time = 0.0

        if self.config.enable_logging:
            logger.setLevel(getattr(logging, self.config.log_level.upper(), logging.INFO))

        logger.info("semantic router initialized")

    # ------------------------------------------------------------------ #
    # دعم context manager
    # ------------------------------------------------------------------ #

    def __enter__(self) -> 'SemanticRouter':
        return self

    def __exit__(self, *args):
        pass  # يمكن إضافة تنظيف مستقبلًا

    def __call__(self, query: str, **kwargs) -> Any:
        """اختصار لـ route() — يتيح استخدام router("استفسار")"""
        return self.route(query, **kwargs)

    # ------------------------------------------------------------------ #
    # التضمينات
    # ------------------------------------------------------------------ #

    def _get_embedding(self, text: str) -> List[float]:
        """حساب تضمين نص واحد"""
        return self.embedding_model.encode(text, convert_to_numpy=True).tolist()

    def _get_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """حساب تضمينات لقائمة نصوص دفعةً واحدة (أسرع)"""
        return self.embedding_model.encode(
            texts,
            convert_to_numpy=True,
            batch_size=self.config.batch_size
        ).tolist()

    def _encode_route(self, route: Route):
        """حساب التضمينات لمسار واحد وتخزينها فيه"""
        if route.examples:
            if self.config.batch_encoding:
                route.embeddings = self._get_embeddings_batch(route.examples)
            else:
                route.embeddings = [self._get_embedding(ex) for ex in route.examples]

    # ------------------------------------------------------------------ #
    # إدارة المسارات
    # ------------------------------------------------------------------ #

    def add_route(self, route: Route):
        """إضافة مسار وحساب تضمينات أمثلته تلقائيًا
            add route and calculate embeddings automatically 
        """
        if not route.examples:
            logger.warning(f"route '{route.name}'without examples can't be added to the router")

        if self.config.auto_encode_examples:
            self._encode_route(route)
            logger.info(f" add route: '{route.name}' with examples: {len(route.examples)} and embeddings:{len(route.embeddings)}")
        else:
            logger.info(f"add route: '{route.name}' without examples")

        self.routes.add(route)

    def re_encode_route(self, name: str) -> bool:
        """
        إعادة حساب تضمينات مسار بعد تحديث أمثلته.
        re-calculate embeddings after updating route.

        Returns:
            True عند النجاح، False إذا لم يُعثر على المسار | True if successful, False otherwise
        """
        route = self.routes.get(name)
        if not route:
            logger.warning(f"router '{name}' not found")
            return False
        self._encode_route(route)
        if self.cache:
            self.cache.clear()  # مسح الكاش لأن التضمينات تغيّرت
        logger.info(f"re-encoded route '{name}'")
        return True

    def remove_route(self, name: str) -> bool:
        """إزالة مسار
           remove route
        """
        result = self.routes.remove(name)
        if result:
            if self.cache:
                self.cache.clear()
            logger.info(f"route removed: '{name}'")
        return result

    def set_fallback(self, handler: Callable):
        """تعيين معالج احتياطي عند عدم وجود مسار مناسب
          set fallback handler when no suitable route is found
        """
        if not callable(handler):
            raise TypeError("handler shoud be callable")
        self.fallback_handler = handler
        logger.info("fallback intialized")

    # ------------------------------------------------------------------ #
    # حساب التشابه واختيار المسار
    # ------------------------------------------------------------------ #

    def _calculate_similarity(self, query_emb: List[float], route: Route) -> float:
        """أعلى تشابه بين الاستعلام وأمثلة المسار
           calculate similarity between query and route examples
        """
        if not route.embeddings:
            return 0.0

        max_sim = 0.0
        for emb in route.embeddings:
            if self.config.similarity_metric == "cosine":
                sim = cosine_similarity(query_emb, emb)
            else:
                sim = 1.0 / (1.0 + euclidean_distance(query_emb, emb))
            if sim > max_sim:
                max_sim = sim

        return max_sim

    def _find_best_route(
        self,
        query_emb: List[float]
    ) -> Tuple[Optional[Route], float, List[Tuple[str, float]]]:
        """إيجاد أفضل مسار مع قائمة بالبدائل
           find best route with list of alternatives
        """
        scores = [
            (route, self._calculate_similarity(query_emb, route))
            for route in self.routes.get_enabled()
        ]
        scores.sort(key=lambda x: x[1], reverse=True)

        if scores and scores[0][1] >= self.config.similarity_threshold:
            best_route, best_score = scores[0]
            alternatives = [
                (r.name, s) for r, s in scores[1:self.config.top_k_alternatives + 1]
            ]
            return best_route, best_score, alternatives

        top_score = scores[0][1] if scores else 0.0
        return None, top_score, []

    @staticmethod
    def _normalize_query(query: str) -> str:
        """تطبيع الاستعلام للكاش (حروف صغيرة + إزالة مسافات زائدة)
        
           normalize query for caching
        """
        return " ".join(query.lower().split())

    @staticmethod
    def _cache_key(query: str) -> str:
        normalized = SemanticRouter._normalize_query(query)
        return f"route:{hashlib.md5(normalized.encode()).hexdigest()}"

    # ------------------------------------------------------------------ #
    # التوجيه
    # ------------------------------------------------------------------ #

    def route(
        self,
        query: str,
        return_result: bool = False,
        **handler_kwargs
    ) -> Any:
        """
        توجيه استعلام إلى أفضل مسار وتنفيذ معالجه.
        semantically route to the best route and execute handler.


        Args:
            query: نص الاستعلام | query text
            return_result: إذا True يُرجع RoutingResult بدلًا من ناتج المعالج | True if return RoutingResult instead of handler result
            **handler_kwargs: معاملات إضافية تُمرَّر للمعالج | additional arguments to the handler


        Returns:
            ناتج المعالج أو RoutingResult حسب return_result | handler result or RoutingResult depending on return_result flag 
        """
        if not query or not query.strip():
            raise ValueError("the query is empty")

        start_time = time.time()
        self.total_queries += 1

        # --- فحص الكاش ---
        if self.cache:
            cache_key = self._cache_key(query)
            cached_name = self.cache.get(cache_key)

            if cached_name:
                cached_route = self.routes.get(cached_name)
                if cached_route and cached_route.enabled:
                    processing_time = time.time() - start_time
                    self.successful_routes += 1
                    cached_response = cached_route.execute(query, similarity=1.0, **handler_kwargs)  # ✅ نفذ دايمًا

                    if return_result:
                        return RoutingResult(
                            route=cached_route,
                            similarity_score=1.0,
                            query=query,
                            processing_time=processing_time,
                            from_cache=True,
                            response=cached_response  # ✅ نحفظ الناتج
                        )

                    return cached_response

        # --- حساب التضمين وإيجاد المسار ---
        query_emb = self._get_embedding(query)
        best_route, best_score, alternatives = self._find_best_route(query_emb)

        processing_time = time.time() - start_time
        self.total_processing_time += processing_time

        # --- تخزين في الكاش ---
        if self.cache and best_route:
            self.cache.set(self._cache_key(query), best_route.name)

        routing_result = RoutingResult(
            route=best_route,
            similarity_score=best_score,
            query=query,
            processing_time=processing_time,
            from_cache=False,
            alternatives=alternatives
        )

        # --- تنفيذ المعالج ---
        if best_route:
            self.successful_routes += 1
            logger.info(
                f"'{query[:40]}' → '{best_route.name}' "
                f"(similarity: {best_score:.3f}, time: {processing_time*1000:.1f}ms)"
            )
            handler_response = best_route.execute(query, similarity=best_score, **handler_kwargs)
            routing_result.response = handler_response  # ✅ نحفظ الناتج في الـ result

            if return_result:
                return routing_result
            return handler_response

        # --- المعالج الاحتياطي ---
        self.failed_routes += 1
        if self.fallback_handler:
            logger.warning(f"no suitable ,will use fallback route: {best_score:.3f})")
            fallback_response = self.fallback_handler(query)
            routing_result.response = fallback_response  # ✅ نحفظ الناتج في الـ result أيضاً

            if return_result:
                return routing_result
            return fallback_response

        no_match_response = {
            "error": "no suitable route found",
            "query": query,
            "highest_similarity": round(best_score, 4),
            "threshold": self.config.similarity_threshold
        }
        routing_result.response = no_match_response
        logger.error(f"no suitable route found for query and fallback route: '{query[:40]}'")

        if return_result:
            return routing_result
        return no_match_response

    def test_route(self, query: str) -> RoutingResult:
        """
        اختبار توجيه استعلام بدون تنفيذ المعالج.
        مفيد للتشخيص والتطوير.
        """
        return self.route(query, return_result=True)

    def batch_route(
        self,
        queries: List[str],
        return_results: bool = False,
        **handler_kwargs
    ) -> List[Any]:
        """
        توجيه قائمة استعلامات دفعةً واحدة بكفاءة. | batch of queries

        Args:
            queries: قائمة الاستعلامات
            return_results: إذا True يُرجع قائمة RoutingResult
            **handler_kwargs: معاملات للمعالجات

        Returns:
            قائمة نتائج المعالجات أو RoutingResult
        """
        return [
            self.route(q, return_result=return_results, **handler_kwargs)
            for q in queries
        ]

    # ------------------------------------------------------------------ #
    # الإحصائيات والأدوات
    # ------------------------------------------------------------------ #

    def list_routes(self) -> List[str]:
        """قائمة أسماء المسارات
           list of route names
        """
        return [r.name for r in self.routes]

    def get_route(self, name: str) -> Optional[Route]:
        """الحصول على مسار بالاسم
           get route by name
        """
        return self.routes.get(name)

    def get_route_stats(self) -> Dict[str, Any]:
        """إحصائيات شاملة للموجه
           statistics about the router 
        """
        stats = {
            'total_queries': self.total_queries,
            'successful_routes': self.successful_routes,
            'failed_routes': self.failed_routes,
            'success_rate': round(
                self.successful_routes / self.total_queries * 100, 2
            ) if self.total_queries else 0.0,
            'average_processing_time_ms': round(
                self.total_processing_time / self.total_queries * 1000, 2
            ) if self.total_queries else 0.0,
            'routes': self.routes.get_statistics(),
            'config': {
                'model': self.config.model_name,
                'similarity_threshold': self.config.similarity_threshold,
                'similarity_metric': self.config.similarity_metric,
            }
        }

        if self.cache:
            stats['cache'] = {
                'hit_rate': round(self.cache.hit_rate, 2),
                'size': len(self.cache),
                'ttl_seconds': self.config.cache_ttl
            }

        return stats


    def reset_statistics(self):
        """إعادة تعيين إحصائيات الموجه والكاش
           reset statistics and cache 
        """
        self.total_queries = 0
        self.successful_routes = 0
        self.failed_routes = 0
        self.total_processing_time = 0.0
        if self.cache:
            self.cache.clear()
        logger.info("reset statistics and cache done.")