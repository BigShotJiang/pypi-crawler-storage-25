from typing import List, Callable, Optional, Dict, Any
from datetime import datetime
import time
from .route_metrics import RouteMetrics


class Route:

    def __init__(
        self,
        name: str,
        description: str,
        handler: Callable,
        examples: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        enabled: bool = True,
        priority: int = 0
    ):
        """
        تهيئة المسار مع التحقق من صحة المدخلات
        initialize route and check from input

        Args:
            name: اسم المسار الفريد (لا يجوز أن يكون فارغًا) | route name (cannot be empty)
            description: وصف المسار ووظيفته                | description of the route and its purpose
            handler: دالة تُنفذ عند استدعاء المسار (يجب أن تكون قابلة للاستدعاء)    | handler to be executed when the route is called (must be callable)
            examples: قائمة جمل مثال للمطابقة الدلالية   | list of example sentences for semantic matching
            metadata: بيانات وصفية إضافية                  | additional metadata
            enabled: هل المسار مفعّل؟ (افتراضي: True)   | is the route enabled? (default: True)
            priority: أولوية المسار — أعلى قيمة = أعلى أولوية (افتراضي: 0)   | route priority — higher value = higher priority (default: 0)

        Raises:
            ValueError: إذا كان الاسم أو الوصف فارغًا | if the name or description is empty
            TypeError: إذا لم يكن handler قابلًا للاستدعاء   | if handler is not callable    
        """
        if not name or not name.strip():
            raise ValueError("Router Name Is Empty")
        if not description or not description.strip():
            raise ValueError("Router Description Is Empty")
        if not callable(handler):
            raise TypeError(f"Must be callable. Got {type(handler).__name__}")

        self.name = name.strip()
        self.description = description.strip()
        self.handler = handler
        self.examples: List[str] = list(dict.fromkeys(examples or []))  # إزالة التكرار مع الحفاظ على الترتيب
        self.metadata: Dict[str, Any] = metadata or {}
        self.enabled = enabled
        self.priority = priority

        # التضمينات (embeddings) — تُحسب لاحقًا بواسطة SemanticRouter
        self.embeddings: List[List[float]] = []

        # المقاييس
        self.metrics = RouteMetrics()

        # الطوابع الزمنية
        self.created_at = time.time()
        self.updated_at = time.time()

    # ------------------------------------------------------------------ #
    # دعم المقارنة والتجزئة
    # ------------------------------------------------------------------ #

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Route):
            return self.name == other.name
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self.name)

    def __str__(self) -> str:
        status = "مفعّل" if self.enabled else "معطّل"
        return (
            f"Route(name='{self.name}', examples={len(self.examples)}, "
            f"priority={self.priority}, status={status})"
        )

    def __repr__(self) -> str:
        return self.__str__()

    # ------------------------------------------------------------------ #
    # إدارة الأمثلة
    # ------------------------------------------------------------------ #

    def add_example(self, example: str):
        """إضافة مثال جديد إن لم يكن موجودًا مسبقًا
            add a new example if it's not already present
        """
        example = example.strip()
        if example  not in self.examples:
            self.examples.append(example)
            self.embeddings = []  # تصفير التضمينات لإعادة الحساب
            self.updated_at = time.time()

    def remove_example(self, example: str) -> bool:
        """
        إزالة مثال. 
        remove an example.


        Returns:
            True إذا تمت الإزالة، False إذا لم يكن المثال موجودًا
            True if the example was removed, False otherwise.
        """
        if example in self.examples:
            self.examples.remove(example)
            self.embeddings = []  # تصفير التضمينات لإعادة الحساب
            self.updated_at = time.time()
            return True
        return False

    def update_example(self, old_example: str, new_example: str) -> bool:
        """
        تحديث مثال موجود.
        update an existing example.


        Returns:
            True إذا نجح التحديث، False إذا لم يُعثر على المثال القديم
            True if the update was successful, False otherwise.
        """
        new_example = new_example.strip()
        if old_example in self.examples and new_example:
            idx = self.examples.index(old_example)
            self.examples[idx] = new_example
            self.embeddings = []
            self.updated_at = time.time()
            return True
        return False

    def get_examples(self, limit: Optional[int] = None) -> List[str]:
        """إرجاع نسخة من قائمة الأمثلة مع دعم التحديد
           return a copy of the list of examples with support for limiting
        """
        return self.examples[:limit] if limit else self.examples.copy()

    # ------------------------------------------------------------------ #
    # إدارة البيانات الوصفية والتفعيل
    # ------------------------------------------------------------------ #

    def add_metadata(self, key: str, value: Any):
        """إضافة أو تحديث بيانات وصفية
           add or update metadata
        """
        self.metadata[key] = value
        self.updated_at = time.time()

    def remove_metadata(self, key: str) -> bool:
        """إزالة بيانات وصفية، تُرجع True عند النجاح
           remove metadata, returning True on success
        """
        if key in self.metadata:
            del self.metadata[key]
            self.updated_at = time.time()
            return True
        return False

    def enable(self):
        """تفعيل المسار
           enable the route
        """
        self.enabled = True
        self.updated_at = time.time()

    def disable(self):
        """تعطيل المسار
           disable the route
        """
        self.enabled = False
        self.updated_at = time.time()

    def clear_embeddings(self):
        """مسح التضمينات المحسوبة (لإعادة الحساب من الموجه)
            clear embedding for re-calculating them 
        """
        self.embeddings = []
        self.updated_at = time.time()

    # ------------------------------------------------------------------ #
    # التنفيذ
    # ------------------------------------------------------------------ #

    def execute(self, query: str, similarity: float = 0.0, **kwargs) -> Any:
        """
        تنفيذ معالج المسار وتسجيل المقاييس.
        execute the handler and record metrics.


        Args:
            query: الاستعلام المُمرَّر للمعالج  | query to be executed by the handler
            similarity: قيمة التشابه (تُمرَّر من الموجه لتسجيل دقيق في المقاييس) | similarity value
            **kwargs: معاملات إضافية للمعالج  | additional arguments to the handler


        Returns:
            ناتج دالة handler  | result of the handler


        Raises:
            RuntimeError: إذا كان المسار معطّلًا | if the route is disabled
        """
        if not self.enabled:
            raise RuntimeError(f"the route '{self.name}' is disabled")

        start_time = time.time()
        success = False

        try:
            result = self.handler(query, **kwargs)
            success = True
            return result
        except Exception:
            success = False
            raise
        finally:
            processing_time = time.time() - start_time
            self.metrics.record_call(success, similarity, processing_time)

    # ------------------------------------------------------------------ #
    # التسلسل والإنتاج
    # ------------------------------------------------------------------ #

    def get_info(self) -> Dict[str, Any]:
        """معلومات شاملة عن المسار
           information about the route
        """
        return {
            'name': self.name,
            'description': self.description,
            'examples_count': len(self.examples),
            'embeddings_ready': len(self.embeddings) > 0,
            'enabled': self.enabled,
            'priority': self.priority,
            'metadata': self.metadata,
            'created_at': datetime.fromtimestamp(self.created_at).isoformat(),
            'updated_at': datetime.fromtimestamp(self.updated_at).isoformat(),
            'metrics': self.metrics.to_dict()
        }

    def to_dict(self) -> Dict[str, Any]:
        """تسلسل المسار إلى قاموس (بدون handler والتضمينات)
        
           serialize the route to a dictionary (without handler and embeddings)
        """
        return {
            'name': self.name,
            'description': self.description,
            'examples': self.examples,
            'metadata': self.metadata,
            'enabled': self.enabled,
            'priority': self.priority,
            'has_embeddings': len(self.embeddings) > 0,
            'metrics': self.metrics.to_dict()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], handler: Callable) -> 'Route':
        """إنشاء مسار من قاموس محفوظ
           create a route from a dictionary
        """
        return cls(
            name=data['name'],
            description=data['description'],
            handler=handler,
            examples=data.get('examples', []),
            metadata=data.get('metadata', {}),
            enabled=data.get('enabled', True),
            priority=data.get('priority', 0)
        )




