from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from .route import Route

@dataclass
class RoutingResult:
    """نتيجة عملية التوجيه
        result of route routing.
    """
    route: Optional[Route]
    similarity_score: float
    query: str
    processing_time: float
    from_cache: bool = False
    alternatives: List[Tuple[str, float]] = field(default_factory=list)
    response: Any = field(default=None)  # ✅ ناتج تنفيذ الـ handler

    @property
    def matched(self) -> bool:
        """هل تطابق الاستعلام مسارًا؟ 
           is the query matched to a route?
        """
        return self.route is not None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'matched': self.matched,
            'route_name': self.route.name if self.route else None,
            'similarity_score': round(self.similarity_score, 4),
            'query': self.query,
            'processing_time_ms': round(self.processing_time * 1000, 2),
            'from_cache': self.from_cache,
            'alternatives': [
                {'route': name, 'score': round(score, 4)}
                for name, score in self.alternatives
            ],
            'response': self.response
        }

    def __str__(self) -> str:
        if self.matched:
            return (
                f"RoutingResult(route='{self.route.name}', "
                f"score={self.similarity_score:.3f}, "
                f"time={self.processing_time*1000:.1f}ms, cache={self.from_cache})"
            )
        return f"RoutingResult(no match, top_score={self.similarity_score:.3f})"