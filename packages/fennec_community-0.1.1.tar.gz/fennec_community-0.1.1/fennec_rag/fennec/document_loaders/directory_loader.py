# -*- coding: utf-8 -*-
"""
Directory Document Loader
محمّل مستندات المجلدات

Recursively loads all supported files from a directory.
يحمّل جميع الملفات المدعومة من مجلد بشكل تكراري.

Example:
    >>> loader = DirectoryLoader("./documents/")
    >>> docs = loader.load()
    >>> print(f"Loaded {len(docs)} documents")
"""

from typing import List, Optional, Dict, Iterator
from pathlib import Path
import fnmatch
import logging
import threading

from .base_loader import BaseDocumentLoader, BaseFileLoader, LoadedDocument
from .config_loader import DirectoryLoaderConfig, EXTENSION_MAP, LoaderType

logger = logging.getLogger(__name__)


class DirectoryLoader(BaseDocumentLoader):
    """
    Load all supported files from a directory.\n
    تحميل جميع الملفات المدعومة من مجلد.

    Features:
        - Recursive directory traversal | اجتياز المجلدات بشكل تكراري
        - Auto-detects file type from extension | اكتشاف نوع الملف تلقائياً
        - Multi-threaded loading | تحميل متعدد الخيوط
        - Progress reporting | الإبلاغ عن التقدم
        - Glob pattern filtering | تصفية بنمط Glob
        - Skip unreadable files | تخطي الملفات غير المقروءة

    Example:
        >>> # Load all supported files
        >>> loader = DirectoryLoader("./data/")
        >>> docs = loader.load()

        >>> # Load only PDFs
        >>> loader = DirectoryLoader("./pdfs/", glob_pattern="**/*.pdf")
        >>> docs = loader.load()

        >>> # Load only txt and md files, excluding hidden folders
        >>> config = DirectoryLoaderConfig(
        ...     glob_pattern="**/*.{txt,md}",
        ...     exclude_patterns=[".*/*"],
        ...     show_progress=True
        ... )
        >>> loader = DirectoryLoader("./docs/", config=config)
        >>> docs = loader.load()
    """

    def __init__(
        self,
        path: str,
        config: Optional[DirectoryLoaderConfig] = None,
        glob_pattern: str = "**/*",
        recursive: bool = True,
        silent_errors: bool = False,
        show_progress: bool = True,
    ):
        """
        Args:
            path: Directory path | مسار المجلد
            config: DirectoryLoaderConfig | إعدادات مجلد
            glob_pattern: File matching pattern | نمط مطابقة الملفات
            recursive: Scan subdirectories | مسح المجلدات الفرعية
            silent_errors: Skip files that fail to load | تخطي الملفات الفاشلة
            show_progress: Print progress | طباعة التقدم
        """
        super().__init__()
        self.directory = Path(path)
        self.config = config or DirectoryLoaderConfig(
            glob_pattern=glob_pattern,
            recursive=recursive,
            silent_errors=silent_errors,
            show_progress=show_progress,
        )
        self._validate_directory()
        self._lock = threading.Lock()

    def _validate_directory(self):
        """Validate directory exists | التحقق من وجود المجلد"""
        if not self.directory.exists():
            raise FileNotFoundError(f"Directory not found: {self.directory}")
        if not self.directory.is_dir():
            raise ValueError(f"Path is not a directory: {self.directory}")

    def load(self) -> List[LoadedDocument]:
        """
        Load all documents from the directory.\n
        تحميل جميع المستندات من المجلد.
        """
        return list(self.lazy_load())

    def lazy_load(self) -> Iterator[LoadedDocument]:
        """
        Lazily load documents from directory.\n
        تحميل مستندات المجلد بشكل كسول.
        """
        files = self._collect_files()
        total = len(files)

        if total == 0:
            logger.warning(f"No supported files found in {self.directory}")
            return

        logger.info(f"Found {total} files to load in {self.directory}")

        if self.config.use_multithreading and total > 1:
            yield from self._load_concurrent(files)
        else:
            yield from self._load_sequential(files, total)

    def _collect_files(self) -> List[Path]:
        """
        Collect all files matching the configured patterns.\n
        جمع كل الملفات المطابقة للأنماط المكونة.
        """
        pattern = self.config.glob_pattern
        if self.config.recursive:
            all_files = list(self.directory.rglob(
                pattern.replace("**/*", "*") if not self.config.recursive else pattern
            ))
        else:
            all_files = list(self.directory.glob(
                pattern.replace("**/*", "*")
            ))

        # Keep only files (not directories) with supported extensions
        supported_exts = set(EXTENSION_MAP.keys())
        files = []
        for f in all_files:
            if not f.is_file():
                continue
            if f.suffix.lower() not in supported_exts:
                continue
            if self._is_excluded(f):
                continue
            files.append(f)

        return sorted(files)

    def _is_excluded(self, file_path: Path) -> bool:
        """Check if file matches exclude patterns | التحقق من تطابق الملف مع أنماط الاستبعاد"""
        rel_path = str(file_path.relative_to(self.directory))
        for pattern in self.config.exclude_patterns:
            if fnmatch.fnmatch(rel_path, pattern):
                return True
            if fnmatch.fnmatch(file_path.name, pattern):
                return True
        return False

    def _load_sequential(self, files: List[Path], total: int) -> Iterator[LoadedDocument]:
        """Load files one by one | تحميل الملفات واحداً تلو الآخر"""
        for i, file_path in enumerate(files):
            if self.config.show_progress:
                print(f"\r  Loading [{i + 1}/{total}]: {file_path.name[:50]:<50}", end="")

            docs = self._load_single_file(file_path)
            yield from docs

        if self.config.show_progress:
            print()  # Newline after progress

    def _load_concurrent(self, files: List[Path]) -> Iterator[LoadedDocument]:
        """Load files concurrently | تحميل الملفات بشكل متزامن"""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        all_docs = []
        total = len(files)
        completed = 0

        with ThreadPoolExecutor(max_workers=self.config.max_concurrency) as executor:
            future_to_file = {
                executor.submit(self._load_single_file, f): f
                for f in files
            }

            for future in as_completed(future_to_file):
                file_path = future_to_file[future]
                try:
                    docs = future.result()
                    with self._lock:
                        all_docs.extend(docs)
                        completed += 1
                        if self.config.show_progress:
                            print(
                                f"\r  Loading [{completed}/{total}]: "
                                f"{file_path.name[:50]:<50}",
                                end=""
                            )
                except Exception as e:
                    logger.error(f"Failed to load {file_path}: {e}")
                    if not self.config.silent_errors:
                        raise

        if self.config.show_progress:
            print()

        yield from all_docs

    def _load_single_file(self, file_path: Path) -> List[LoadedDocument]:
        """
        Load a single file using the appropriate loader.\n
        تحميل ملف واحد باستخدام المحمّل المناسب.
        """
        try:
            loader = self._get_loader_for_file(file_path)
            if loader is None:
                return []
            return loader.load()
        except Exception as e:
            msg = f"Error loading {file_path}: {e}"
            if self.config.silent_errors:
                logger.warning(msg)
                return []
            raise IOError(msg) from e

    def _get_loader_for_file(self, file_path: Path) -> Optional[BaseFileLoader]:
        """
        Get the appropriate loader for a file based on extension.\n
        الحصول على المحمّل المناسب للملف بناءً على الامتداد.
        """
        ext = file_path.suffix.lower()
        loader_type = EXTENSION_MAP.get(ext)

        if loader_type is None:
            return None

        # Import lazily to avoid circular imports
        if loader_type == LoaderType.TEXT:
            from .text_loader import TextLoader
            return TextLoader(str(file_path))

        elif loader_type == LoaderType.MARKDOWN:
            from .text_loader import MarkdownLoader
            return MarkdownLoader(str(file_path))

        elif loader_type == LoaderType.PDF:
            from .pdf_loader import PDFLoader
            return PDFLoader(str(file_path))

        elif loader_type == LoaderType.DOCX:
            from .docx_loader import DocxLoader
            return DocxLoader(str(file_path))

        elif loader_type == LoaderType.CSV:
            from .csv_loader import CSVLoader
            return CSVLoader(str(file_path))

        elif loader_type == LoaderType.EXCEL:
            from .csv_loader import ExcelLoader
            return ExcelLoader(str(file_path))

        elif loader_type == LoaderType.JSON:
            from .json_loader import JSONLoader
            return JSONLoader(str(file_path))

        elif loader_type == LoaderType.JSONL:
            from .json_loader import JSONLinesLoader
            return JSONLinesLoader(str(file_path))

        elif loader_type in (LoaderType.HTML,):
            from .html_loader import HTMLLoader
            return HTMLLoader(str(file_path))

        return None

    def get_stats(self) -> Dict:
        """
        Get statistics about files in the directory.\n
        الحصول على إحصاءات حول الملفات في المجلد.
        """
        files = self._collect_files()
        stats: Dict = {
            "total_files": len(files),
            "by_type": {},
            "total_size_bytes": 0,
        }

        for f in files:
            ext = f.suffix.lower()
            loader_type = EXTENSION_MAP.get(ext, LoaderType.AUTO)
            type_name = loader_type.value

            if type_name not in stats["by_type"]:
                stats["by_type"][type_name] = {"count": 0, "size_bytes": 0}

            stats["by_type"][type_name]["count"] += 1
            size = f.stat().st_size
            stats["by_type"][type_name]["size_bytes"] += size
            stats["total_size_bytes"] += size

        stats["total_size_mb"] = round(stats["total_size_bytes"] / (1024 * 1024), 2)
        return stats
