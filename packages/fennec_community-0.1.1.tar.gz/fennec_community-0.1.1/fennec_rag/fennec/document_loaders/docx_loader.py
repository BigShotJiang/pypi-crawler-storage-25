# -*- coding: utf-8 -*-
"""
Microsoft Word Document Loader (.docx)
محمّل مستندات Microsoft Word

Supports: .docx (and .doc via fallback)
Backend: python-docx

Example:
    >>> loader = DocxLoader("report.docx")
    >>> docs = loader.load()
    >>> print(docs[0].page_content[:200])
"""

from typing import List, Optional
import logging

from .base_loader import BaseFileLoader, LoadedDocument
from .config_loader import DocxLoaderConfig

logger = logging.getLogger(__name__)


class DocxLoader(BaseFileLoader):
    """
    Load Microsoft Word (.docx) documents.\n
    Microsoft Word تحميل مستندات .

    Features:
        - Extracts paragraphs and headings | استخراج الفقرات والعناوين
        - Extracts table content | استخراج محتوى الجداول
        - Extracts headers and footers | استخراج الترويسات والتذييلات
        - Preserves document structure | الحفاظ على هيكل المستند
        - Arabic/RTL text support | دعم النصوص العربية

    Example:
        >>> # Basic usage
        >>> loader = DocxLoader("document.docx")
        >>> docs = loader.load()

        >>> # Custom config
        >>> config = DocxLoaderConfig(include_tables=True, row_separator=" | ")
        >>> loader = DocxLoader("document.docx", config=config)
        >>> docs = loader.load()
    """

    SUPPORTED_EXTENSIONS = [".docx", ".doc"]

    def __init__(
        self,
        file_path: str,
        config: Optional[DocxLoaderConfig] = None,
    ):
        """
        Args:
            file_path: Path to .docx file | مسار ملف docx
            config: DocxLoaderConfig instance | كائن إعدادات Word
        """
        super().__init__(file_path=file_path)
        self.config = config or DocxLoaderConfig()

    def load(self) -> List[LoadedDocument]:
        """
        Load the Word document.
        Word تحميل مستند .
        """
        try:
            from docx import Document as DocxDocument
        except ImportError:
            raise ImportError(
                "python-docx is required for DocxLoader. "
                "Install it with: pip install python-docx"
            )

        # Handle legacy .doc format
        if self.file_path.suffix.lower() == ".doc":
            return self._load_legacy_doc()

        doc = DocxDocument(str(self.file_path))

        parts = []

        # Extract headers | استخراج الترويسات
        if self.config.include_headers:
            for section in doc.sections:
                header_text = self._extract_header_footer(section.header)
                if header_text:
                    parts.append(f"[Header]: {header_text}")

        # Extract paragraphs | استخراج الفقرات
        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            style = para.style.name if para.style else "Normal"
            if "Heading" in style:
                parts.append(f"\n{'#' * self._heading_level(style)} {text}\n")
            else:
                parts.append(text)

        # Extract tables | استخراج الجداول
        if self.config.include_tables:
            for table in doc.tables:
                table_text = self._extract_table(table)
                if table_text:
                    parts.append("\n[Table]:\n" + table_text)

        # Extract footers | استخراج التذييلات
        if self.config.include_footers:
            for section in doc.sections:
                footer_text = self._extract_header_footer(section.footer)
                if footer_text:
                    parts.append(f"[Footer]: {footer_text}")

        full_text = "\n".join(parts).strip()

        # Document-level metadata | بيانات وصفية على مستوى المستند
        core_props = doc.core_properties
        metadata = self._build_file_metadata(
            title=core_props.title or "",
            author=core_props.author or "",
            subject=core_props.subject or "",
            created=str(core_props.created or ""),
            modified=str(core_props.modified or ""),
            paragraph_count=len(doc.paragraphs),
            table_count=len(doc.tables),
        )

        return [LoadedDocument(page_content=full_text, metadata=metadata)]

    def _extract_table(self, table) -> str:
        """
        Extract table content as formatted text.
        استخراج محتوى الجدول كنص منسق.
        """
        rows = []
        for row in table.rows:
            cells = [
                cell.text.strip().replace('\n', ' ')
                for cell in row.cells
            ]
            rows.append(self.config.row_separator.join(cells))
        return self.config.table_separator.join(rows)

    def _extract_header_footer(self, hf) -> str:
        """Extract header or footer text | استخراج نص الترويسة أو التذييل"""
        if hf is None:
            return ""
        texts = [para.text.strip() for para in hf.paragraphs if para.text.strip()]
        return " ".join(texts)

    def _heading_level(self, style_name: str) -> int:
        """Convert heading style name to level | تحويل اسم نمط العنوان إلى مستوى"""
        import re
        match = re.search(r'\d', style_name)
        return int(match.group()) if match else 1

    def _load_legacy_doc(self) -> List[LoadedDocument]:
        """
        Attempt to load legacy .doc file via conversion or pypdf.
        محاولة تحميل ملف .doc القديم عبر التحويل أو pypdf.
        """
        # Try textract first
        try:
            from pypdf import PdfReader

            reader = PdfReader(str(self.file_path))

            text = ""
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"

            metadata = self._build_file_metadata(
                note="Loaded via pypdf"
            )

            return [LoadedDocument(page_content=text.strip(), metadata=metadata)]
        except ImportError:
            pass

        raise ImportError(
            f"Cannot load legacy .doc file {self.file_path.name}. "
            "Options:\n"
            "  1. Convert to .docx first using Microsoft Word or LibreOffice\n"
            "  2. Install PyPDF: pip install PyPdf"
        )
