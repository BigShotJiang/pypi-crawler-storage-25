# -*- coding: utf-8 -*-
"""
Web URL Document Loader
محمّل مستندات عناوين URL الويب

Loads content from web pages and APIs.
يحمّل المحتوى من صفحات الويب وAPIs.

Example:
    >>> loader = WebLoader("https://example.com/article")
    >>> docs = loader.load()
"""

from typing import List, Optional, Dict
import logging
import time
from .base_loader import BaseDocumentLoader, LoadedDocument
from .config_loader import WebLoaderConfig
from .html_loader import HTMLStringLoader, HTMLLoaderConfig

logger = logging.getLogger(__name__)


class WebLoader(BaseDocumentLoader):
    """
    Load content from web URLs.\n
    تحميل المحتوى من عناوين URL للويب.

    Features:
        - Automatic retry on failure | إعادة المحاولة تلقائياً عند الفشل
        - Custom headers (User-Agent, etc.) | رؤوس مخصصة
        - Encoding auto-detection | اكتشاف الترميز تلقائياً
        - HTML parsing with BeautifulSoup | تحليل HTML بـ BeautifulSoup
        - Extracts OG/meta tags as metadata | استخراج وسوم OG/meta

    Example:
        >>> # Single URL
        >>> loader = WebLoader("https://en.wikipedia.org/wiki/Python")
        >>> docs = loader.load()

        >>> # With custom config
        >>> config = WebLoaderConfig(timeout=30, headers={"User-Agent": "MyBot/1.0"})
        >>> loader = WebLoader("https://example.com", config=config)
        >>> docs = loader.load()
    """

    def __init__(
        self,
        url: str,
        config: Optional[WebLoaderConfig] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 10,
    ):
        """
        Args:
            url: Web URL to load | عنوان URL للتحميل
            config: WebLoaderConfig | إعدادات الويب
            headers: HTTP headers | رؤوس HTTP
            timeout: Request timeout in seconds | مهلة الطلب بالثواني
        """
        super().__init__()
        self.url = url.strip()
        self.config = config or WebLoaderConfig(
            headers=headers or {},
            timeout=timeout,
        )

    def load(self) -> List[LoadedDocument]:
        """
        Fetch and load the web page.\n
        جلب وتحميل صفحة الويب.
        """
        html = self._fetch_url()
        html_config = HTMLLoaderConfig(
            tags_to_remove=["script", "style", "nav", "footer", "header", "aside"],
            extract_links=False,
            extract_tables=True,
        )
        loader = HTMLStringLoader(html, source=self.url, config=html_config)
        docs = loader.load()

        # Add URL-specific metadata | إضافة بيانات وصفية خاصة بالـ URL
        for doc in docs:
            doc.metadata["url"] = self.url
            doc.metadata["source"] = self.url

        return docs

    def _fetch_url(self) -> str:
        """
        Fetch URL content with retry logic.\n
        جلب محتوى URL مع منطق إعادة المحاولة.
        """
        try:
            import requests
        except ImportError:
            raise ImportError(
                "requests is required for WebLoader. "
                "Install it with: pip install requests"
            )

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (compatible; DocumentLoader/1.0; "
                "+https://github.com/your-lib)"
            ),
            **self.config.headers,
        }

        last_error = None
        for attempt in range(self.config.max_retries):
            try:
                response = requests.get(
                    self.url,
                    headers=headers,
                    timeout=self.config.timeout,
                    verify=self.config.verify_ssl,
                )
                response.raise_for_status()

                # Detect encoding | اكتشاف الترميز
                if self.config.encoding:
                    response.encoding = self.config.encoding
                else:
                    # Use apparent_encoding for better accuracy
                    response.encoding = response.apparent_encoding or "utf-8"

                return response.text

            except requests.exceptions.RequestException as e:
                last_error = e
                if attempt < self.config.max_retries - 1:
                    wait = self.config.retry_delay * (2 ** attempt)
                    logger.warning(
                        f"Attempt {attempt + 1} failed for {self.url}: {e}. "
                        f"Retrying in {wait:.1f}s..."
                    )
                    time.sleep(wait)

        raise ConnectionError(
            f"Failed to fetch {self.url} after {self.config.max_retries} attempts. "
            f"Last error: {last_error}"
        )


class MultiURLLoader(BaseDocumentLoader):
    """
    Load content from multiple URLs concurrently.\n
    تحميل المحتوى من عناوين URL متعددة بشكل متزامن.

    Features:
        - Concurrent fetching (ThreadPoolExecutor) | جلب متزامن
        - Configurable concurrency | تزامن قابل للتخصيص
        - Graceful error handling | معالجة أخطاء سلسة
        - Optional rate limiting | تحديد معدل اختياري

    Example:
        >>> urls = [
        ...     "https://example.com/article1",
        ...     "https://example.com/article2",
        ...     "https://example.com/article3",
        ... ]
        >>> loader = MultiURLLoader(urls, max_workers=3)
        >>> docs = loader.load()
        >>> print(f"Loaded {len(docs)} documents from {len(urls)} URLs")
    """

    def __init__(
        self,
        urls: List[str],
        config: Optional[WebLoaderConfig] = None,
        max_workers: int = 4,
        delay_between_requests: float = 0.5,
        continue_on_error: bool = True,
    ):
        """
        Args:
            urls: List of URLs to load | قائمة عناوين URL
            config: WebLoaderConfig | إعدادات الويب
            max_workers: Max concurrent threads | الحد الأقصى للخيوط المتزامنة
            delay_between_requests: Seconds between requests | ثواني بين الطلبات
            continue_on_error: Skip URLs that fail | تخطي عناوين URL الفاشلة
        """
        super().__init__()
        self.urls = [url.strip() for url in urls if url.strip()]
        self.config = config or WebLoaderConfig()
        self.max_workers = max_workers
        self.delay = delay_between_requests
        self.continue_on_error = continue_on_error

    def load(self) -> List[LoadedDocument]:
        """
        Load all URLs.
        تحميل كل عناوين URL.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        all_docs = []
        errors = []

        def _load_single(url: str) -> List[LoadedDocument]:
            if self.delay > 0:
                time.sleep(self.delay)
            loader = WebLoader(url=url, config=self.config)
            return loader.load()

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_url = {
                executor.submit(_load_single, url): url
                for url in self.urls
            }

            for future in as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    docs = future.result()
                    all_docs.extend(docs)
                    logger.info(f"✓ Loaded: {url} ({len(docs)} docs)")
                except Exception as e:
                    errors.append((url, str(e)))
                    logger.error(f"✗ Failed: {url} - {e}")
                    if not self.continue_on_error:
                        raise

        if errors:
            logger.warning(
                f"Failed to load {len(errors)}/{len(self.urls)} URLs. "
                f"Failed URLs: {[u for u, _ in errors]}"
            )

        logger.info(
            f"MultiURLLoader: loaded {len(all_docs)} documents "
            f"from {len(self.urls) - len(errors)}/{len(self.urls)} URLs"
        )
        return all_docs
