# -*- coding: utf-8 -*-
"""
Base Document Loader
الفئة الأساسية لتحميل المستندات

Provides the abstract interface that all document loaders must implement.
يوفر الواجهة المجردة التي يجب أن تطبقها جميع محملات المستندات.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Iterator
from pathlib import Path
import logging
import hashlib
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


# ============================================================
# Document Model (compatible with chunks/doc_model.py)
# نموذج المستند (متوافق مع chunks/doc_model.py)
# ============================================================

@dataclass
class LoadedDocument:
    """
    Represents a loaded document with its content and metadata.\n
    يمثل مستنداً محملاً مع محتواه وبياناته الوصفية.
    
    Attributes:
        page_content: The text content of the document | محتوى النص
        metadata: Dictionary of metadata | قاموس البيانات الوصفية
        doc_id: Unique document identifier | معرف المستند الفريد
    """
    page_content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    doc_id: Optional[str] = None

    def __post_init__(self):
        """Auto-generate doc_id if not provided | توليد معرف تلقائي إذا لم يُقدَّم"""
        if not self.doc_id:
            content_hash = hashlib.md5(self.page_content.encode()).hexdigest()[:8]
            self.doc_id = f"doc_{content_hash}_{int(time.time())}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary | تحويل إلى قاموس"""
        return {
            "doc_id": self.doc_id,
            "page_content": self.page_content,
            "metadata": self.metadata
        }

    def __repr__(self) -> str:
        preview = self.page_content[:80].replace('\n', ' ')
        return f"LoadedDocument(doc_id={self.doc_id!r}, preview={preview!r}...)"


# ============================================================
# Abstract Base Loader
# الفئة الأساسية المجردة للمحمّل
# ============================================================

class BaseDocumentLoader(ABC):
    """
    Abstract base class for all document loaders.
    الفئة الأساسية المجردة لجميع محملات المستندات.

    All loaders must implement:
        - load(): Returns list of LoadedDocument
        - lazy_load(): Generator version (memory-efficient)
    """

    def __init__(self, encoding: str = "utf-8", **kwargs):
        """
        Initialize base loader.
        تهيئة المحمّل الأساسي.

        Args:
            encoding: Text encoding to use | ترميز النص المستخدم
        """
        self.encoding = encoding
        self._extra_config = kwargs

    @abstractmethod
    def load(self) -> List[LoadedDocument]:
        """
        Load documents and return as a list.\n
        تحميل المستندات وإرجاعها كقائمة.

        Returns:
            List[LoadedDocument]: List of loaded documents | قائمة المستندات المحملة
        """
        pass

    def lazy_load(self) -> Iterator[LoadedDocument]:
        """
        Lazily load documents one at a time (memory-efficient).\n
        تحميل المستندات بشكل كسول واحداً تلو الآخر (موفر للذاكرة).
        
        Default: calls load() and yields each document.
        Subclasses can override for true streaming.
        """
        for doc in self.load():
            yield doc

    def load_and_split(self, text_splitter=None) -> List[LoadedDocument]:
        """
        Load documents and split them using a text splitter.\n
        تحميل المستندات وتقسيمها باستخدام مقسم النصوص.

        Args:
            text_splitter: A TextSplitter instance from chunks module |
                           مثيل TextSplitter من وحدة chunks

        Returns:
            List[LoadedDocument]: Chunked documents | المستندات المقسمة
        """
        documents = self.load()
        if text_splitter is None:
            return documents
        
        chunked = []
        for doc in documents:
            chunks = text_splitter.split_text(doc.page_content)
            for i, chunk in enumerate(chunks):
                meta = doc.metadata.copy()
                meta["chunk_index"] = i
                meta["total_chunks"] = len(chunks)
                meta["original_doc_id"] = doc.doc_id
                chunked.append(LoadedDocument(
                    page_content=chunk,
                    metadata=meta
                ))
        return chunked

    def _build_metadata(self, source: str, **extra) -> Dict[str, Any]:
        """
        Build standard metadata dict.
        بناء قاموس البيانات الوصفية القياسي.
        """
        metadata = {
            "source": source,
            "loader_type": self.__class__.__name__,
            "loaded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        metadata.update(extra)
        return metadata

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(encoding={self.encoding!r})"


# ============================================================
# File-based Loader Base
# قاعدة المحمّل المستند إلى الملفات
# ============================================================

class BaseFileLoader(BaseDocumentLoader):
    """
    Base class for loaders that read from file paths.\n
    الفئة الأساسية للمحملات التي تقرأ من مسارات الملفات.
    """

    # Subclasses declare their supported extensions
    # الفئات الفرعية تعلن عن امتداداتها المدعومة
    SUPPORTED_EXTENSIONS: List[str] = []

    def __init__(self, file_path: str, encoding: str = "utf-8", **kwargs):
        """
        Args:
            file_path: Path to the file | مسار الملف
            encoding: File encoding | ترميز الملف
        """
        super().__init__(encoding=encoding, **kwargs)
        self.file_path = Path(file_path)
        self._validate_file()

    def _validate_file(self):
        """
        Validate that the file exists and is readable.
        التحقق من وجود الملف وإمكانية قراءته.
        """
        if not self.file_path.exists():
            raise FileNotFoundError(f"File not found: {self.file_path}")
        if not self.file_path.is_file():
            raise ValueError(f"Path is not a file: {self.file_path}")
        
        if self.SUPPORTED_EXTENSIONS:
            ext = self.file_path.suffix.lower()
            if ext not in self.SUPPORTED_EXTENSIONS:
                raise ValueError(
                    f"Unsupported file extension '{ext}'. "
                    f"Supported: {self.SUPPORTED_EXTENSIONS}"
                )

    def _build_file_metadata(self, **extra) -> Dict[str, Any]:
        """Build metadata with file-specific info | بناء بيانات وصفية مع معلومات الملف"""
        stat = self.file_path.stat()
        meta = self._build_metadata(
            source=str(self.file_path.resolve()),
            file_name=self.file_path.name,
            file_type=self.file_path.suffix.lower(),
            file_size_bytes=stat.st_size,
        )
        meta.update(extra)
        return meta

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(file_path={str(self.file_path)!r})"
