# -*- coding: utf-8 -*-
"""
CSV & Excel Document Loaders
محملات مستندات CSV و Excel

Supports: .csv, .tsv, .xlsx, .xls

Example:
    >>> loader = CSVLoader("data.csv", content_columns=["text", "description"])
    >>> docs = loader.load()
"""

import csv
from typing import List, Optional, Dict, Iterator
import logging
from .base_loader import BaseFileLoader, LoadedDocument
from .config_loader import CSVLoaderConfig

logger = logging.getLogger(__name__)


class CSVLoader(BaseFileLoader):
    """
    Load CSV/TSV files with flexible column mapping.\n
    تحميل ملفات CSV/TSV مع تعيين مرن للأعمدة.

    Features:
        - Choose which columns to include as content | اختيار الأعمدة لتكون محتوى
        - Map columns to metadata | تعيين أعمدة كبيانات وصفية
        - Handles Arabic text and special characters | دعم النصوص العربية
        - Each row becomes a Document | كل صف يصبح مستنداً

    Example:
        >>> # Each row → one document with all columns
        >>> loader = CSVLoader("articles.csv")
        >>> docs = loader.load()

        >>> # Use specific columns for content
        >>> loader = CSVLoader(
        ...     "products.csv",
        ...     content_columns=["title", "description"],
        ...     metadata_columns=["id", "category", "price"]
        ... )
        >>> docs = loader.load()
    """

    SUPPORTED_EXTENSIONS = [".csv", ".tsv"]

    def __init__(
        self,
        file_path: str,
        config: Optional[CSVLoaderConfig] = None,
        content_columns: Optional[List[str]] = None,
        metadata_columns: Optional[List[str]] = None,
        source_column: Optional[str] = None,
        encoding: str = "utf-8",
        delimiter: str = ",",
    ):
        """
        Args:
            file_path: Path to CSV file | مسار ملف CSV
            config: CSVLoaderConfig | إعدادات CSV
            content_columns: Columns to use as document content | أعمدة المحتوى
            metadata_columns: Columns to store as metadata | أعمدة البيانات الوصفية
            source_column: Column to use as document source | عمود المصدر
            encoding: File encoding | ترميز الملف
            delimiter: Column delimiter | محدد الأعمدة
        """
        super().__init__(file_path=file_path, encoding=encoding)
        self.config = config or CSVLoaderConfig(
            encoding=encoding,
            delimiter=delimiter,
            content_columns=content_columns,
            metadata_columns=metadata_columns,
            source_column=source_column,
        )
        # Handle TSV
        if self.file_path.suffix.lower() == ".tsv" and delimiter == ",":
            self.config.delimiter = "\t"

    def load(self) -> List[LoadedDocument]:
        """
        Load CSV file, one Document per row.\n
        تحميل ملف CSV، مستند واحد لكل صف.
        """
        return list(self.lazy_load())

    def lazy_load(self) -> Iterator[LoadedDocument]:
        """
        Lazily load CSV rows as Documents.\n
        التحميل الكسول لصفوف CSV كمستندات.
        """
        try:
            with open(
                self.file_path,
                newline="",
                encoding=self.config.encoding,
                errors="replace"
            ) as f:
                # Skip rows if configured | تخطي الصفوف إذا تم تكوينها
                for _ in range(self.config.skip_rows):
                    next(f, None)

                reader = csv.DictReader(
                    f,
                    delimiter=self.config.delimiter,
                    quotechar=self.config.quote_char,
                )

                row_count = 0
                for i, row in enumerate(reader):
                    if self.config.max_rows and i >= self.config.max_rows:
                        break

                    doc = self._row_to_document(row, row_number=i + 1)
                    if doc:
                        yield doc
                        row_count += 1

                logger.debug(f"Loaded {row_count} documents from {self.file_path.name}")

        except UnicodeDecodeError:
            # Retry with latin-1
            logger.warning(f"UTF-8 failed for {self.file_path.name}, trying latin-1")
            self.config.encoding = "latin-1"
            yield from self.lazy_load()

    def _row_to_document(self, row: Dict[str, str], row_number: int) -> Optional[LoadedDocument]:
        """
        Convert a CSV row to a LoadedDocument.
        تحويل صف CSV إلى مستند.
        """
        # Determine content | تحديد المحتوى
        if self.config.content_columns:
            content_parts = []
            for col in self.config.content_columns:
                val = row.get(col, "").strip()
                if val:
                    content_parts.append(f"{col}: {val}")
            content = self.config.row_joiner.join(content_parts)
        else:
            # All columns | كل الأعمدة
            content = self.config.row_joiner.join(
                f"{k}: {v}" for k, v in row.items() if v and v.strip()
            )

        if not content.strip():
            return None

        # Build metadata | بناء البيانات الوصفية
        meta = self._build_file_metadata(row_number=row_number)

        if self.config.metadata_columns:
            for col in self.config.metadata_columns:
                if col in row:
                    meta[col] = row[col]
        else:
            # Store all non-content columns as metadata
            if self.config.content_columns:
                for k, v in row.items():
                    if k not in self.config.content_columns:
                        meta[k] = v

        # Override source if source_column specified | تجاوز المصدر
        if self.config.source_column and self.config.source_column in row:
            meta["source"] = row[self.config.source_column]

        return LoadedDocument(page_content=content, metadata=meta)


class ExcelLoader(BaseFileLoader):
    """
    Load Excel files (.xlsx, .xls).\n
    تحميل ملفات Excel.

    Features:
        - Load specific sheets or all sheets | تحميل أوراق محددة أو كلها
        - Each row → one Document | كل صف → مستند
        - Each sheet → separate batch of Documents | كل ورقة → مجموعة منفصلة
        - Handles merged cells | يتعامل مع الخلايا المدمجة

    Example:
        >>> loader = ExcelLoader("data.xlsx", sheet_name="Sheet1")
        >>> docs = loader.load()

        >>> # Load all sheets
        >>> loader = ExcelLoader("workbook.xlsx", load_all_sheets=True)
        >>> docs = loader.load()
    """

    SUPPORTED_EXTENSIONS = [".xlsx", ".xls", ".xlsm"]

    def __init__(
        self,
        file_path: str,
        sheet_name: Optional[str] = None,
        load_all_sheets: bool = False,
        content_columns: Optional[List[str]] = None,
        metadata_columns: Optional[List[str]] = None,
        skip_rows: int = 0,
        max_rows: Optional[int] = None,
    ):
        """
        Args:
            file_path: Path to Excel file | مسار ملف Excel
            sheet_name: Specific sheet to load (None = first sheet) | اسم الورقة
            load_all_sheets: Load all sheets | تحميل كل الأوراق
            content_columns: Columns to use as content | أعمدة المحتوى
            metadata_columns: Columns to use as metadata | أعمدة البيانات الوصفية
            skip_rows: Rows to skip from start | صفوف للتخطي
            max_rows: Maximum rows to load | الحد الأقصى للصفوف
        """
        super().__init__(file_path=file_path)
        self.sheet_name = sheet_name
        self.load_all_sheets = load_all_sheets
        self.content_columns = content_columns
        self.metadata_columns = metadata_columns
        self.skip_rows = skip_rows
        self.max_rows = max_rows

    def load(self) -> List[LoadedDocument]:
        """
        Load the Excel file.\n
        Excel تحميل ملف .
        """
        try:
            import openpyxl
        except ImportError:
            raise ImportError(
                "openpyxl is required for ExcelLoader. "
                "Install it with: pip install openpyxl"
            )

        wb = openpyxl.load_workbook(str(self.file_path), read_only=True, data_only=True)
        documents = []

        if self.load_all_sheets:
            sheet_names = wb.sheetnames
        elif self.sheet_name:
            sheet_names = [self.sheet_name]
        else:
            sheet_names = [wb.sheetnames[0]]

        for sheet_name in sheet_names:
            ws = wb[sheet_name]
            docs = self._load_sheet(ws, sheet_name)
            documents.extend(docs)

        wb.close()
        return documents

    def _load_sheet(self, ws, sheet_name: str) -> List[LoadedDocument]:
        """Load a single worksheet | تحميل ورقة عمل واحدة"""
        documents = []
        rows = list(ws.iter_rows(values_only=True))

        if not rows:
            return []

        # First row = headers | الصف الأول = العناوين
        headers = [str(h).strip() if h is not None else f"col_{i}"
                   for i, h in enumerate(rows[0])]

        data_rows = rows[1 + self.skip_rows:]
        if self.max_rows:
            data_rows = data_rows[:self.max_rows]

        for row_idx, row in enumerate(data_rows):
            row_dict = {
                headers[i]: str(val).strip() if val is not None else ""
                for i, val in enumerate(row)
                if i < len(headers)
            }

            # Build content
            if self.content_columns:
                parts = [
                    f"{col}: {row_dict.get(col, '')}"
                    for col in self.content_columns
                    if row_dict.get(col, "").strip()
                ]
            else:
                parts = [
                    f"{k}: {v}" for k, v in row_dict.items() if v.strip()
                ]

            content = "\n".join(parts)
            if not content.strip():
                continue

            # Metadata
            meta = self._build_file_metadata(
                sheet_name=sheet_name,
                row_number=row_idx + 2,  # 1-indexed + header
            )
            if self.metadata_columns:
                for col in self.metadata_columns:
                    meta[col] = row_dict.get(col, "")

            documents.append(LoadedDocument(page_content=content, metadata=meta))

        return documents
