"""Data Serialization and Compression Utilities"""

import json
import pickle
import gzip
from typing import Any, Callable, Optional
from .enums import StorageFormat


class SerializationError(Exception):
    """Exception raised when serialization fails"""
    pass


class DeserializationError(Exception):
    """Exception raised when deserialization fails"""
    pass


class DataSerializer:
    """Handles serialization, compression, and encryption of data"""
    
    def __init__(
        self,
        compression_level: int = 6,
        enable_encryption: bool = False,
        encryption_key: Optional[bytes] = None
    ):
        """Initialize data serializer
        
        Args:
            compression_level: Gzip compression level (0-9)
            enable_encryption: Enable data encryption
            encryption_key: Encryption key (required if encryption enabled)
        """
        self.compression_level = compression_level
        self.enable_encryption = enable_encryption
        self.encryption_key = encryption_key
        
        if enable_encryption and not encryption_key:
            raise ValueError("Encryption key is required when encryption is enabled")
    
    def serialize(
        self,
        data: Any,
        format: StorageFormat,
        custom_serializer: Optional[Callable] = None
    ) -> bytes:
        """Serialize data to bytes
        
        Args:
            data: Data to serialize
            format: Storage format
            custom_serializer: Optional custom serialization function
            
        Returns:
            Serialized bytes
            
        Raises:
            SerializationError: If serialization fails
        """
        try:
            # Custom serialization
            if custom_serializer:
                serialized = custom_serializer(data)
                if isinstance(serialized, str):
                    serialized = serialized.encode('utf-8')
                return serialized
            
            # Standard serialization
            if format in (StorageFormat.JSON, StorageFormat.COMPRESSED_JSON):
                serialized = json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2,
                    default=str
                ).encode('utf-8')
            
            elif format in (StorageFormat.PICKLE, StorageFormat.COMPRESSED_PICKLE):
                serialized = pickle.dumps(data)
            
            elif format == StorageFormat.TEXT:
                serialized = str(data).encode('utf-8')
            
            else:
                raise SerializationError(f"Unsupported format: {format}")
            
            # Compression
            if format.is_compressed:
                serialized = self._compress(serialized)
            
            # Encryption
            if self.enable_encryption:
                serialized = self._encrypt(serialized)
            
            return serialized
        
        except Exception as e:
            raise SerializationError(f"Serialization failed: {e}") from e
    
    def deserialize(
        self,
        data: bytes,
        format: StorageFormat,
        custom_deserializer: Optional[Callable] = None
    ) -> Any:
        """Deserialize bytes to data
        
        Args:
            data: Serialized bytes
            format: Storage format
            custom_deserializer: Optional custom deserialization function
            
        Returns:
            Deserialized data
            
        Raises:
            DeserializationError: If deserialization fails
        """
        try:
            # Decryption
            if self.enable_encryption:
                data = self._decrypt(data)
            
            # Decompression
            if format.is_compressed:
                data = self._decompress(data)
            
            # Custom deserialization
            if custom_deserializer:
                return custom_deserializer(data)
            
            # Standard deserialization
            if format in (StorageFormat.JSON, StorageFormat.COMPRESSED_JSON):
                return json.loads(data.decode('utf-8'))
            
            elif format in (StorageFormat.PICKLE, StorageFormat.COMPRESSED_PICKLE):
                return pickle.loads(data)
            
            elif format == StorageFormat.TEXT:
                return data.decode('utf-8')
            
            else:
                raise DeserializationError(f"Unsupported format: {format}")
        
        except Exception as e:
            raise DeserializationError(f"Deserialization failed: {e}") from e
    
    def _compress(self, data: bytes) -> bytes:
        """Compress data using gzip
        
        Args:
            data: Data to compress
            
        Returns:
            Compressed data
        """
        return gzip.compress(data, compresslevel=self.compression_level)
    
    def _decompress(self, data: bytes) -> bytes:
        """Decompress gzip data
        
        Args:
            data: Compressed data
            
        Returns:
            Decompressed data
        """
        return gzip.decompress(data)
    
    def _encrypt(self, data: bytes) -> bytes:
        """Encrypt data using Fernet symmetric encryption
        
        Args:
            data: Data to encrypt
            
        Returns:
            Encrypted data
        """
        if not self.enable_encryption:
            return data
        
        try:
            from cryptography.fernet import Fernet
            
            # Ensure key is bytes
            key = self.encryption_key
            if isinstance(key, str):
                key = key.encode('utf-8')
            
            f = Fernet(key)
            return f.encrypt(data)
        
        except ImportError:
            raise ImportError(
                "cryptography library required for encryption. "
                "Install with: pip install cryptography"
            )
    
    def _decrypt(self, data: bytes) -> bytes:
        """Decrypt data using Fernet symmetric encryption
        
        Args:
            data: Encrypted data
            
        Returns:
            Decrypted data
        """
        if not self.enable_encryption:
            return data
        
        try:
            from cryptography.fernet import Fernet
            
            # Ensure key is bytes
            key = self.encryption_key
            if isinstance(key, str):
                key = key.encode('utf-8')
            
            f = Fernet(key)
            return f.decrypt(data)
        
        except ImportError:
            raise ImportError(
                "cryptography library required for encryption. "
                "Install with: pip install cryptography"
            )


def generate_encryption_key() -> bytes:
    """Generate a new Fernet encryption key
    
    Returns:
        New encryption key as bytes
    """
    try:
        from cryptography.fernet import Fernet
        return Fernet.generate_key()
    except ImportError:
        raise ImportError(
            "cryptography library required. "
            "Install with: pip install cryptography"
        )