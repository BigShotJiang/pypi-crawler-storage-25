"""Advanced Persistence Manager with Comprehensive Features"""

import json
import logging
import threading
from pathlib import Path
from typing import Any, Callable, Optional, Union, List, Dict
from contextlib import contextmanager

from .enums import StorageFormat, CompressionLevel
from .serializers import DataSerializer, SerializationError, DeserializationError
from .metadata import MetadataManager
from .backup import BackupManager
from .cache import LRUCache


class PersistenceManager:
    """Advanced persistence manager for data storage and retrieval
    
    Features:
    - Multiple storage formats (JSON, Pickle, Text)
    - Compression support (gzip)
    - Optional encryption
    - Automatic backups with retention
    - In-memory LRU caching
    - Metadata tracking
    - Thread-safe operations
    - Transaction support
    - Import/Export functionality
    
    Example:
        # Basic usage
        manager = PersistenceManager(storage_path="./data")
        
        # Save data
        manager.save("users", {"john": {"age": 30}})
        
        # Load data
        users = manager.load("users")
        
        # With compression
        manager.save("large_data", data, compress=True)
        
        # With caching
        manager.enable_cache(max_size=100)
    """
    
    def __init__(
        self,
        storage_path: str = "./storage",
        enable_logging: bool = True,
        auto_backup: bool = False,
        backup_count: int = 3,
        compression_level: CompressionLevel = CompressionLevel.BALANCED,
        enable_encryption: bool = False,
        encryption_key: Optional[Union[str, bytes]] = None
    ):
        """Initialize persistence manager
        
        Args:
            storage_path: Directory for storing files
            enable_logging: Enable logging output
            auto_backup: Automatically backup files before overwrite
            backup_count: Number of backups to retain per key
            compression_level: Default compression level
            enable_encryption: Enable data encryption
            encryption_key: Encryption key (required if encryption enabled)
        """
        # Paths
        self.storage_path = Path(storage_path)
        self.backup_path = self.storage_path / "backups"
        
        # Create directories
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Logging
        self.logger = self._setup_logger() if enable_logging else None
        
        # Serializer
        self.serializer = DataSerializer(
            compression_level=compression_level.value,
            enable_encryption=enable_encryption,
            encryption_key=encryption_key
        )
        
        # Metadata
        self.metadata = MetadataManager(self.storage_path, self.logger)
        
        # Backup
        self.backup_manager = None
        if auto_backup:
            self.backup_manager = BackupManager(
                self.backup_path,
                backup_count,
                self.logger
            )
        
        # Cache — disabled by default; call enable_cache() to activate
        self.cache = LRUCache(enabled=False)
        
        # Statistics
        self.stats = {
            'saves': 0,
            'loads': 0,
            'deletes': 0,
            'errors': 0
        }
    
    # ==================== Setup Methods ====================
    
    def _setup_logger(self) -> logging.Logger:
        """Setup logging for the persistence manager
        
        Returns:
            Configured logger instance
        """
        logger = logging.getLogger('PersistenceManager')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _log(self, level: str, message: str):
        """Log a message
        
        Args:
            level: Log level (info, warning, error, debug)
            message: Message to log
        """
        if self.logger:
            getattr(self.logger, level)(message)
    
    # ==================== Cache Management ====================
    
    def enable_cache(self, max_size: int = 100):
        """Enable in-memory caching
        
        Args:
            max_size: Maximum number of items to cache
        """
        self.cache = LRUCache(max_size=max_size, enabled=True)
        self._log('info', f'Cache enabled with max size: {max_size}')
    
    def disable_cache(self):
        """Disable and clear cache"""
        self.cache.disable()
        self._log('info', 'Cache disabled')
    
    # ==================== Core Operations ====================
    
    def save(
        self,
        key: str,
        data: Any,
        format: Union[str, StorageFormat] = StorageFormat.JSON,
        compress: bool = False,
        custom_serializer: Optional[Callable] = None
    ) -> bool:
        """Save data to storage
        
        Args:
            key: Storage key (filename without extension)
            data: Data to save
            format: Storage format
            compress: Force compression (overrides format default)
            custom_serializer: Custom serialization function
            
        Returns:
            True if successful, False otherwise
        """
        # Convert string format to enum
        if isinstance(format, str):
            format = StorageFormat(format)
        
        # Apply compression if requested
        if compress and not format.is_compressed:
            if format == StorageFormat.JSON:
                format = StorageFormat.COMPRESSED_JSON
            elif format == StorageFormat.PICKLE:
                format = StorageFormat.COMPRESSED_PICKLE
        
        with self._lock:
            try:
                file_path = self._get_file_path(key, format)
                
                # Create backup if enabled
                if self.backup_manager and file_path.exists():
                    self.backup_manager.create_backup(file_path, key)
                
                # Serialize data
                serialized_data = self.serializer.serialize(
                    data, format, custom_serializer
                )
                
                # Write to file
                with open(file_path, 'wb') as f:
                    f.write(serialized_data)
                
                # Update metadata
                self.metadata.update(key, format.value, len(serialized_data))
                
                # Update cache
                if self.cache.enabled:
                    self.cache.set(key, data)
                
                # Update statistics
                self.stats['saves'] += 1
                
                self._log('info', f'✅ Saved: {file_path.name} ({len(serialized_data)} bytes)')
                return True
            
            except (SerializationError, Exception) as e:
                self.stats['errors'] += 1
                self._log('error', f'❌ Save error for key "{key}": {e}')
                return False
    
    def load(
        self,
        key: str,
        format: Union[str, StorageFormat] = StorageFormat.JSON,
        decompress: bool = False,
        custom_deserializer: Optional[Callable] = None,
        default: Any = None
    ) -> Any:
        """Load data from storage
        
        Args:
            key: Storage key
            format: Storage format
            decompress: Force decompression (overrides format default)
            custom_deserializer: Custom deserialization function
            default: Default value if key doesn't exist
            
        Returns:
            Loaded data or default value
        """
        # Convert string format to enum
        if isinstance(format, str):
            format = StorageFormat(format)
        
        # Check cache first
        cached_value = self.cache.get(key)
        if cached_value is not None:
            self._log('debug', f'Cache hit for key: {key}')
            return cached_value
        
        with self._lock:
            file_path = self._get_file_path(key, format)
            
            if not file_path.exists():
                self._log('warning', f'⚠️ File not found: {file_path.name}')
                return default
            
            try:
                # Read file
                with open(file_path, 'rb') as f:
                    data = f.read()
                
                # Deserialize data
                result = self.serializer.deserialize(
                    data, format, custom_deserializer
                )
                
                # Update cache
                if self.cache.enabled:
                    self.cache.set(key, result)
                
                # Update statistics
                self.stats['loads'] += 1
                
                self._log('info', f'✅ Loaded: {file_path.name}')
                return result
            
            except (DeserializationError, Exception) as e:
                self.stats['errors'] += 1
                self._log('error', f'❌ Load error for key "{key}": {e}')
                return default
    
    def exists(
        self,
        key: str,
        format: Union[str, StorageFormat] = StorageFormat.JSON
    ) -> bool:
        """Check if a key exists in storage
        
        Args:
            key: Storage key
            format: Storage format
            
        Returns:
            True if exists, False otherwise
        """
        if isinstance(format, str):
            format = StorageFormat(format)
        
        return self._get_file_path(key, format).exists()
    
    def delete(
        self,
        key: str,
        format: Union[str, StorageFormat] = StorageFormat.JSON
    ) -> bool:
        """Delete data from storage
        
        Args:
            key: Storage key
            format: Storage format
            
        Returns:
            True if deleted, False if not found
        """
        if isinstance(format, str):
            format = StorageFormat(format)
        
        with self._lock:
            file_path = self._get_file_path(key, format)
            
            if not file_path.exists():
                self._log('warning', f'File not found for deletion: {file_path.name}')
                return False
            
            try:
                file_path.unlink()
                
                # Remove from cache
                self.cache.remove(key)
                
                # Remove metadata
                self.metadata.remove(key)
                
                # Update statistics
                self.stats['deletes'] += 1
                
                self._log('info', f'🗑️ Deleted: {file_path.name}')
                return True
            
            except Exception as e:
                self.stats['errors'] += 1
                self._log('error', f'Delete error: {e}')
                return False
    
    # ==================== Query Operations ====================
    
    def list_keys(self, pattern: str = "*") -> List[str]:
        """List all stored keys
        
        Args:
            pattern: Glob pattern for filtering
            
        Returns:
            List of storage keys
        """
        keys = set()
        for file in self.storage_path.glob(pattern):
            if file.is_file() and not file.name.startswith('.'):
                keys.add(file.stem)
        return sorted(keys)
    
    def get_metadata(self, key: str) -> Optional[Dict]:
        """Get metadata for a specific key
        
        Args:
            key: Storage key
            
        Returns:
            Metadata dictionary or None
        """
        return self.metadata.get(key)
    
    def get_all_metadata(self) -> Dict:
        """Get all metadata
        
        Returns:
            Dictionary of all metadata
        """
        return self.metadata.get_all()
    
    # ==================== Size Information ====================
    
    def get_size(
        self,
        key: str,
        format: Union[str, StorageFormat] = StorageFormat.JSON
    ) -> int:
        """Get file size in bytes
        
        Args:
            key: Storage key
            format: Storage format
            
        Returns:
            File size in bytes, 0 if not found
        """
        if isinstance(format, str):
            format = StorageFormat(format)
        
        file_path = self._get_file_path(key, format)
        return file_path.stat().st_size if file_path.exists() else 0
    
    def get_total_size(self) -> int:
        """Get total storage size in bytes
        
        Returns:
            Total size of all stored files
        """
        total = 0
        for file in self.storage_path.glob("*"):
            if file.is_file() and not file.name.startswith('.'):
                total += file.stat().st_size
        return total
    
    # ==================== Bulk Operations ====================
    
    def clear_all(self, confirm: bool = False):
        """Delete all stored files
        
        Args:
            confirm: Must be True to confirm deletion
        """
        if not confirm:
            self._log('warning', 'clear_all requires confirm=True')
            return
        
        with self._lock:
            count = 0
            for file in self.storage_path.glob("*"):
                if file.is_file() and not file.name.startswith('.'):
                    file.unlink()
                    count += 1
            
            self.cache.clear()
            self.metadata.clear()
            
            self._log('info', f'🗑️ Cleared all: {count} files deleted')
    
    def export_all(self, export_path: str) -> bool:
        """Export all data to a single JSON file
        
        Args:
            export_path: Path for export file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            all_data = {}
            
            for key in self.list_keys():
                # Try loading with different formats
                for format in StorageFormat:
                    if self.exists(key, format):
                        data = self.load(key, format)
                        if data is not None:
                            all_data[key] = data
                            break
            
            with open(export_path, 'w', encoding='utf-8') as f:
                json.dump(all_data, f, ensure_ascii=False, indent=2, default=str)
            
            self._log('info', f'✅ Exported {len(all_data)} items to: {export_path}')
            return True
        
        except Exception as e:
            self._log('error', f'Export error: {e}')
            return False
    
    def import_all(self, import_path: str) -> bool:
        """Import data from a JSON file
        
        Args:
            import_path: Path to import file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            with open(import_path, 'r', encoding='utf-8') as f:
                all_data = json.load(f)
            
            for key, data in all_data.items():
                self.save(key, data)
            
            self._log('info', f'✅ Imported {len(all_data)} items from: {import_path}')
            return True
        
        except Exception as e:
            self._log('error', f'Import error: {e}')
            return False
    
    # ==================== Statistics ====================
    
    def get_stats(self) -> Dict:
        """Get usage statistics
        
        Returns:
            Dictionary with statistics
        """
        return {
            **self.stats,
            'total_files': len(self.list_keys()),
            'total_size_bytes': self.get_total_size(),
            'cache': self.cache.get_stats()
        }
    
    # ==================== Transaction Support ====================
    
    @contextmanager
    def transaction(self):
        """Context manager for transactional operations
        
        Automatically rolls back changes if an error occurs.
        
        Example:
            with manager.transaction():
                manager.save("key1", data1)
                manager.save("key2", data2)
                # If any error occurs, both saves are rolled back
        """
        snapshot = {}
        keys_modified = []
        
        try:
            # Create snapshot of existing data
            for key in self.list_keys():
                for format in StorageFormat:
                    if self.exists(key, format):
                        snapshot[key] = (format, self.load(key, format))
                        break
            
            yield self
            
        except Exception as e:
            # Rollback on error
            self._log('warning', f'Transaction failed, rolling back: {e}')
            
            # Restore snapshot
            for key, (format, data) in snapshot.items():
                self.save(key, data, format)
            
            raise
    
    # ==================== Helper Methods ====================
    
    def _get_file_path(self, key: str, format: StorageFormat) -> Path:
        """Get file path for a key
        
        Args:
            key: Storage key
            format: Storage format
            
        Returns:
            Full file path
        """
        return self.storage_path / f"{key}.{format.value}"
    
    # ==================== Special Methods ====================
    
    def __len__(self) -> int:
        """Get number of stored files"""
        return len(self.list_keys())
    
    def __repr__(self) -> str:
        stats = self.get_stats()
        return (
            f"PersistenceManager(path='{self.storage_path}', "
            f"files={stats['total_files']}, "
            f"size={stats['total_size_bytes']} bytes)"
        )