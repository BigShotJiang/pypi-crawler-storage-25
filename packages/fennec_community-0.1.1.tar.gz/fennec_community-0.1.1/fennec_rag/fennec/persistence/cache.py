from collections import OrderedDict
from threading import RLock
from typing import Any, Optional


class LRUCache:
    """
    Thread-safe Least Recently Used (LRU) Cache.

    Supports enable/disable toggling so callers can pause caching without
    destroying cached data (disable clears the store, enable reactivates it).

    Args:
        max_size (int): Maximum number of entries to hold in cache.
        enabled  (bool): Whether the cache is active on creation (default True).

    Example:
        cache = LRUCache(max_size=256)
        cache.set("key1", {"data": 42})
        value = cache.get("key1")   # {"data": 42}
        cache.delete("key1")
        cache.remove("key1")        # alias for delete()
        cache.clear()
        cache.disable()
        cache.enable()
        print(cache.get_stats())
    """

    def __init__(self, max_size: int = 128, enabled: bool = True):
        if max_size <= 0:
            raise ValueError("max_size must be a positive integer.")
        self._max_size = max_size
        self._store: OrderedDict = OrderedDict()
        self._lock = RLock()
        # ── FIX 1: enabled flag is now a proper instance attribute ──────────
        self.enabled: bool = enabled

    # ── Enable / Disable ────────────────────────────────────────────────────

    def enable(self) -> None:
        """Activate the cache. Subsequent set/get calls will use the store."""
        with self._lock:
            self.enabled = True

    def disable(self) -> None:
        """Deactivate the cache and clear its contents."""
        with self._lock:
            self.enabled = False
            self._store.clear()

    # ── Public API ──────────────────────────────────────────────────────────

    def get(self, key: str) -> Optional[Any]:
        """
        Return the cached value for *key*, or None if not present.

        Returns None immediately when the cache is disabled.
        """
        if not self.enabled:
            return None
        with self._lock:
            if key not in self._store:
                return None
            # Move to end → mark as most recently used
            self._store.move_to_end(key)
            return self._store[key]

    def set(self, key: str, value: Any) -> None:
        """
        Insert or update *key* in the cache.

        Does nothing when the cache is disabled.
        """
        if not self.enabled:
            return
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                self._store[key] = value
            else:
                if len(self._store) >= self._max_size:
                    # Evict the least recently used entry (first item)
                    self._store.popitem(last=False)
                self._store[key] = value

    def delete(self, key: str) -> bool:
        """Remove *key* from cache. Returns True if the key existed."""
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False

    def remove(self, key: str) -> bool:
        """
        Alias for delete() — provided for API compatibility with
        callers that expect a ``remove`` method.

        Returns True if the key existed and was removed.
        """
        # ── FIX 2: add remove() so manager.py line 344 works ────────────────
        return self.delete(key)

    def clear(self) -> None:
        """Remove all entries from the cache."""
        with self._lock:
            self._store.clear()

    # ── Stats ────────────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        """
        Return basic cache statistics as a plain dict.

        This is the method name expected by PersistenceManager.get_stats().
        The ``stats`` property below is kept for backwards compatibility.

        Returns:
            dict with keys: size, max_size, usage_pct, enabled.
        """
        # ── FIX 3: get_stats() method so manager.py line 520 works ──────────
        with self._lock:
            return {
                "size":      len(self._store),
                "max_size":  self._max_size,
                "usage_pct": round(len(self._store) / self._max_size * 100, 2),
                "enabled":   self.enabled,
            }

    @property
    def stats(self) -> dict:
        """Backwards-compatible property — delegates to get_stats()."""
        return self.get_stats()

    # ── Dunder helpers ───────────────────────────────────────────────────────

    def __contains__(self, key: str) -> bool:
        with self._lock:
            return key in self._store

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)

    @property
    def max_size(self) -> int:
        """Maximum number of entries this cache can hold."""
        return self._max_size

    def __repr__(self) -> str:
        s = self.get_stats()
        return (
            f"LRUCache(size={s['size']}/{s['max_size']}, "
            f"usage={s['usage_pct']}%, "
            f"enabled={s['enabled']})"
        )