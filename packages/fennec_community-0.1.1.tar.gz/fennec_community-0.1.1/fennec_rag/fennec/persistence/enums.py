
from enum import Enum


class StorageFormat(Enum):
    """Supported storage formats for data persistence
    
    Formats:
        JSON: Human-readable JSON format
        PICKLE: Python pickle format (binary)
        COMPRESSED_JSON: Gzip-compressed JSON
        COMPRESSED_PICKLE: Gzip-compressed pickle
        TEXT: Plain text format
    """
    JSON = "json"
    PICKLE = "pickle"
    COMPRESSED_JSON = "json.gz"
    COMPRESSED_PICKLE = "pkl.gz"
    TEXT = "txt"
    
    @property
    def is_compressed(self) -> bool:
        """Check if format is compressed"""
        return self in (self.COMPRESSED_JSON, self.COMPRESSED_PICKLE)
    
    @property
    def is_binary(self) -> bool:
        """Check if format is binary"""
        return self in (self.PICKLE, self.COMPRESSED_PICKLE)
    
    @property
    def is_text_based(self) -> bool:
        """Check if format is text-based"""
        return self in (self.JSON, self.COMPRESSED_JSON, self.TEXT)


class CompressionLevel(Enum):
    """Gzip compression levels
    
    Levels:
        NONE: No compression (0)
        FAST: Fast compression, larger files (1)
        BALANCED: Balanced speed/size (6)
        BEST: Best compression, slower (9)
    """
    NONE = 0
    FAST = 1
    BALANCED = 6
    BEST = 9
    
    @property
    def description(self) -> str:
        """Get compression level description"""
        descriptions = {
            self.NONE: "No compression",
            self.FAST: "Fast compression, larger files",
            self.BALANCED: "Balanced speed and size",
            self.BEST: "Best compression, slower"
        }
        return descriptions[self]