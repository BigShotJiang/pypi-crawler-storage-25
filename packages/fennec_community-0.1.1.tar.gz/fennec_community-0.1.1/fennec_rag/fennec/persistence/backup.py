import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional
import logging


class BackupManager:
    """Manages automatic backups of stored files
    
    Features:
    - Automatic backup creation before overwrites
    - Configurable backup retention count
    - Timestamp-based backup naming
    - Automatic cleanup of old backups
    """
    
    def __init__(
        self,
        backup_path: Path,
        backup_count: int = 3,
        logger: Optional[logging.Logger] = None
    ):
        """Initialize backup manager
        
        Args:
            backup_path: Path where backups will be stored
            backup_count: Number of backups to retain per key
            logger: Optional logger instance
        """
        self.backup_path = backup_path
        self.backup_count = backup_count
        self.logger = logger
        
        # Create backup directory
        self.backup_path.mkdir(parents=True, exist_ok=True)
    
    def create_backup(self, source_file: Path, key: str) -> Optional[Path]:
        """Create a backup of a file
        
        Args:
            source_file: File to backup
            key: Storage key for organizing backups
            
        Returns:
            Path to created backup file or None if source doesn't exist
        """
        if not source_file.exists():
            return None
        
        try:
            # Generate backup filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{key}_{timestamp}{source_file.suffix}"
            backup_file = self.backup_path / backup_name
            
            # Copy file to backup location
            shutil.copy2(source_file, backup_file)
            
            if self.logger:
                self.logger.info(f'Backup created: {backup_file.name}')
            
            # Cleanup old backups
            self._cleanup_old_backups(key, source_file.suffix)
            
            return backup_file
        
        except Exception as e:
            if self.logger:
                self.logger.error(f'Backup creation failed: {e}')
            return None
    
    def _cleanup_old_backups(self, key: str, extension: str):
        """Remove old backups exceeding retention count
        
        Args:
            key: Storage key
            extension: File extension to match
        """
        # Find all backups for this key
        pattern = f"{key}_*{extension}"
        backups = sorted(self.backup_path.glob(pattern))
        
        # Remove oldest backups if exceeding count
        if len(backups) > self.backup_count:
            for backup in backups[:-self.backup_count]:
                try:
                    backup.unlink()
                    if self.logger:
                        self.logger.debug(f'Old backup deleted: {backup.name}')
                except Exception as e:
                    if self.logger:
                        self.logger.error(f'Failed to delete backup: {e}')
    
    def list_backups(self, key: str) -> list[Path]:
        """List all backups for a key
        
        Args:
            key: Storage key
            
        Returns:
            List of backup file paths, sorted by timestamp
        """
        pattern = f"{key}_*"
        return sorted(self.backup_path.glob(pattern))
    
    def restore_backup(self, backup_file: Path, destination: Path) -> bool:
        """Restore a backup file
        
        Args:
            backup_file: Backup file to restore
            destination: Destination path for restored file
            
        Returns:
            True if successful, False otherwise
        """
        if not backup_file.exists():
            if self.logger:
                self.logger.error(f'Backup file not found: {backup_file}')
            return False
        
        try:
            shutil.copy2(backup_file, destination)
            if self.logger:
                self.logger.info(f'Backup restored: {backup_file.name} -> {destination}')
            return True
        except Exception as e:
            if self.logger:
                self.logger.error(f'Restore failed: {e}')
            return False
    
    def get_latest_backup(self, key: str) -> Optional[Path]:
        """Get the most recent backup for a key
        
        Args:
            key: Storage key
            
        Returns:
            Path to latest backup or None if no backups exist
        """
        backups = self.list_backups(key)
        return backups[-1] if backups else None
    
    def clear_backups(self, key: Optional[str] = None):
        """Clear backups
        
        Args:
            key: If provided, clear only backups for this key.
                 If None, clear all backups.
        """
        if key:
            # Clear backups for specific key
            pattern = f"{key}_*"
            backups = self.backup_path.glob(pattern)
        else:
            # Clear all backups
            backups = self.backup_path.glob("*")
        
        count = 0
        for backup in backups:
            if backup.is_file():
                backup.unlink()
                count += 1
        
        if self.logger:
            self.logger.info(f'Cleared {count} backup(s)')