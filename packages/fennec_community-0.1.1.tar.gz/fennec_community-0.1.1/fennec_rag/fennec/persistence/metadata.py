"""Metadata Management for Storage"""

import json
from typing import Dict, Optional
from pathlib import Path
from datetime import datetime
import logging


class MetadataManager:
    """Manages metadata for stored files
    
    Tracks information about stored files including:
    - Storage format
    - File size
    - Creation and modification timestamps
    - Custom metadata fields
    """
    
    def __init__(self, storage_path: Path, logger: Optional[logging.Logger] = None):
        """Initialize metadata manager
        
        Args:
            storage_path: Path where metadata file will be stored
            logger: Optional logger instance
        """
        self.storage_path = storage_path
        self.metadata_file = storage_path / '.metadata.json'
        self.logger = logger
        self._metadata: Dict[str, Dict] = {}
        self._load()
    
    def update(self, key: str, format: str, size: int, **custom_fields):
        """Update metadata for a key
        
        Args:
            key: Storage key
            format: Storage format used
            size: File size in bytes
            **custom_fields: Additional custom metadata fields
        """
        now = datetime.now().isoformat()
        
        if key in self._metadata:
            # Update existing entry
            self._metadata[key].update({
                'format': format,
                'size': size,
                'modified': now,
                **custom_fields
            })
        else:
            # Create new entry
            self._metadata[key] = {
                'format': format,
                'size': size,
                'created': now,
                'modified': now,
                **custom_fields
            }
        
        self._save()
    
    def get(self, key: str) -> Optional[Dict]:
        """Get metadata for a specific key
        
        Args:
            key: Storage key
            
        Returns:
            Metadata dictionary or None if not found
        """
        return self._metadata.get(key)
    
    def get_all(self) -> Dict[str, Dict]:
        """Get all metadata
        
        Returns:
            Dictionary of all metadata
        """
        return self._metadata.copy()
    
    def remove(self, key: str) -> bool:
        """Remove metadata for a key
        
        Args:
            key: Storage key
            
        Returns:
            True if removed, False if not found
        """
        if key in self._metadata:
            del self._metadata[key]
            self._save()
            return True
        return False
    
    def clear(self):
        """Clear all metadata"""
        self._metadata.clear()
        self._save()
    
    def _load(self):
        """Load metadata from file"""
        if not self.metadata_file.exists():
            return
        
        try:
            with open(self.metadata_file, 'r', encoding='utf-8') as f:
                self._metadata = json.load(f)
        except Exception as e:
            if self.logger:
                self.logger.error(f'Failed to load metadata: {e}')
            self._metadata = {}
    
    def _save(self):
        """Save metadata to file"""
        try:
            with open(self.metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self._metadata, f, indent=2, ensure_ascii=False)
        except Exception as e:
            if self.logger:
                self.logger.error(f'Failed to save metadata: {e}')
    
    def __len__(self) -> int:
        return len(self._metadata)
    
    def __contains__(self, key: str) -> bool:
        return key in self._metadata