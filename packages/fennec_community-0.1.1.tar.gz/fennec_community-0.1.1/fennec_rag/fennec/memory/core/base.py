"""
الواجهة الأساسية لأنواع الذاكرة المختلفة
Base interface for different memory types
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, List
from .config import MemoryConfig

config = MemoryConfig()

class BaseMemory(ABC):
    """
    واجهة أساسية لجميع أنواع الذاكرة\n
    Base interface for all memory types
    """
    
    @abstractmethod
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, Any]):
        """
        حفظ السياق في الذاكرة\n
        Save context to memory
        
        Args:
            inputs: مدخلات المستخدم / User inputs
            outputs: مخرجات النظام / System outputs
        """
        pass
    
    @abstractmethod
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحميل متغيرات الذاكرة\n
        Load memory variables
        
        Args:
            inputs: المدخلات الحالية / Current inputs
            
        Returns:
            قاموس يحتوي على بيانات الذاكرة / Dictionary containing memory data
        """
        pass
    
    @abstractmethod
    def clear(self):
        """
        مسح محتويات الذاكرة\n
        Clear memory contents
        """
        pass
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        الحصول على إحصائيات الذاكرة\n
        Get memory statistics
        
        Returns:
            قاموس يحتوي على الإحصائيات / Dictionary containing statistics
        """
        return {
            'type': self.__class__.__name__,
            'size': 0
        }


class BaseRetriever(ABC):
    """
    واجهة أساسية لأنظمة الاسترجاع\n
    Base interface for retrieval systems
    """
    
    @abstractmethod
    def add_documents(self, documents: List[Any]):
        """
        إضافة مستندات\n
        Add documents
        """
        pass
    
    @abstractmethod
    def get_relevant_documents(self, query: str, k: int = 3) -> List[Any]:
        """
        استرجاع مستندات ذات صلة\n
        Retrieve relevant documents
        """
        pass
    # ── Async API ────────────────────────────────────────────────────

    async def asave_context(self, inputs, outputs):
        """Async save context | حفظ سياق غير متزامن"""
        import asyncio
        return await asyncio.to_thread(self.save_context, inputs, outputs)

    async def aload_memory_variables(self, inputs):
        """Async load memory | تحميل ذاكرة غير متزامن"""
        import asyncio
        return await asyncio.to_thread(self.load_memory_variables, inputs)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        self.clear()
        return False
