from dataclasses import dataclass, field
from typing import Dict, Any, List
import time


@dataclass
class ChatMessage:
    """
    يمثل وحدة الذاكرة الأساسية للمحادثة
    Represents the basic memory unit for conversation
    """
    input: str
    output: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        تحويل إلى قاموس\n
        Convert to dictionary
        """
        return {
            'input': self.input,
            'output': self.output,
            'timestamp': self.timestamp,
            'metadata': self.metadata
        }
    
    def to_text(self) -> str:
        """
        تحويل إلى نص\n
        Convert to text
        """
        return f"user: {self.input}\n assistant: {self.output}"


@dataclass
class Entity:
    """
    كيان مستخرج من المحادثة\n
    Entity extracted from conversation
    """
    name: str
    entity_type: str  # person, place, organization, etc.
    contexts: List[str] = field(default_factory=list)
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    
    def add_context(self, context: str):
        """
        إضافة سياق جديد\n
        Add new context
        """
        self.contexts.append(context)
        self.last_seen = time.time()
    
    def get_recent_contexts(self, limit: int = 3) -> List[str]:
        """
        الحصول على أحدث السياقات\n
        Get the most recent contexts
        """
        return self.contexts[-limit:]