
from enum import Enum
from .config import MemoryConfig as memory_config


 



class MemoryType(Enum):
    """
    Types of memory in the system
    
    SHORT_TERM: Temporary memories, limited capacity
    LONG_TERM: Persistent memories, large capacity
    WORKING: Active processing memories
    EPISODIC: Event-based memories with temporal context
    SEMANTIC: Fact-based memories without temporal context
    PROCEDURAL: Skill and procedure memories
    """
    
    SHORT_TERM = "short_term"
    LONG_TERM = "long_term"
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    
    @classmethod
    def from_string(cls, type_str: str) -> 'MemoryType':
        """
        Create MemoryType from string
        
        Args:
            type_str: String representation of memory type
        
        Returns:
            MemoryType instance
        """
        type_map = {
            'short_term': cls.SHORT_TERM,
            'short': cls.SHORT_TERM,
            'st': cls.SHORT_TERM,
            
            'long_term': cls.LONG_TERM,
            'long': cls.LONG_TERM,
            'lt': cls.LONG_TERM,
            
            'working': cls.WORKING,
            'work': cls.WORKING,
            'wm': cls.WORKING,
            
            'episodic': cls.EPISODIC,
            'episode': cls.EPISODIC,
            'ep': cls.EPISODIC,
            
            'semantic': cls.SEMANTIC,
            'sem': cls.SEMANTIC,
            
            'procedural': cls.PROCEDURAL,
            'proc': cls.PROCEDURAL,
        }
        
        return type_map.get(type_str.lower(), cls.SHORT_TERM)
    
    @property
    def description(self) -> str:
        """Get description of memory type"""
        descriptions = {
            self.SHORT_TERM: "Temporary storage with limited capacity",
            self.LONG_TERM: "Persistent storage with large capacity",
            self.WORKING: "Active processing and manipulation",
            self.EPISODIC: "Personal experiences and events",
            self.SEMANTIC: "General facts and knowledge",
            self.PROCEDURAL: "Skills and procedures",
        }
        return descriptions.get(self, "Unknown memory type")
    
    @property
    def default_capacity(self) -> int:
        """Get default capacity for this memory type"""
        capacities = {
            self.SHORT_TERM: memory_config.max_short_term,
            self.LONG_TERM: memory_config.max_long_term,
            self.WORKING: memory_config.max_working,
            self.EPISODIC: memory_config.max_episodic,
            self.SEMANTIC: memory_config.max_semantic,
            self.PROCEDURAL: memory_config.max_procedral,
        }
        return capacities.get(self, 100)
    
    def __str__(self) -> str:
        """String representation"""
        return self.value
    
    def __repr__(self) -> str:
        """Detailed representation"""
        return f"MemoryType.{self.name}"


class MemoryPriority(Enum):
    """Priority levels for memory entries"""
    
    CRITICAL = 1.0
    HIGH = 0.8
    MEDIUM = 0.5
    LOW = 0.3
    MINIMAL = 0.1
    
    @classmethod
    def from_importance(cls, importance: float) -> 'MemoryPriority':
        """Convert importance score to priority"""
        if importance >= 0.9:
            return cls.CRITICAL
        elif importance >= 0.7:
            return cls.HIGH
        elif importance >= 0.5:
            return cls.MEDIUM
        elif importance >= 0.3:
            return cls.LOW
        else:
            return cls.MINIMAL
