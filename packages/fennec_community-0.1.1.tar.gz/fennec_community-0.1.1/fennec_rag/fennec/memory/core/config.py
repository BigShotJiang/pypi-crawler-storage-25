"""
Memory Management Configuration
Provides configuration for the memory system
"""

from dataclasses import dataclass
import os


@dataclass
class MemoryConfig:
    """
    Configuration for memory management system
    
    Attributes:
        max_short_term: Maximum number of short-term memories
        max_long_term: Maximum number of long-term memories
        max_working: Maximum number of working memories
        max_episodic: Maximum number of episodic memories
        
        importance_threshold: Threshold for promoting to long-term
        similarity_threshold: Threshold for memory consolidation
        retrieval_limit: Default limit for memory retrieval
        
        embedding_model: Model name for embeddings
        embedding_batch_size: Batch size for embedding generation
        
        normalize_text: Whether to normalize text (lowercase)
        preserve_case: Whether to preserve original case
        
        enable_persistence: Enable saving to disk
        persistence_path: Path for saving memories
        auto_save_interval: Auto-save interval in seconds
        
        enable_decay: Enable memory decay over time
        decay_rate: Rate of importance decay per day
        min_importance: Minimum importance before removal
    """
    
    # Memory limits
    max_short_term: int = 1000
    max_long_term: int = 1000
    max_working: int = 1000
    max_episodic: int = 1000
    max_semantic : int =1000
    max_procedral: int =1000
    
    # Retrieval settings
    importance_threshold: float = 0.7
    similarity_threshold: float = 0.85
    retrieval_limit: int = 10
    
    # Embedding settings
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_batch_size: int = 32
    embedding_cache_size: int = 1000
    
    # Text processing
    normalize_text: bool = False  # Don't lowercase by default
    preserve_case: bool = True
    remove_duplicates: bool = True
    
    # Persistence
    enable_persistence: bool = True
    persistence_path: str = "./memory_storage"
    auto_save_interval: int = 300  # 5 minutes
    
    return_messages: bool = False
    input_key: str = "input"
    output_key: str = "output"
    memory_key: str = "history"
    max_token_limit: int = 2000
    window_size: int = 5

    # Memory decay
    enable_decay: bool = True
    decay_rate: float = 0.1  # 10% decay per day
    min_importance: float = 0.1
    
    # Performance
    enable_consolidation: bool = True
    consolidation_interval: int = 3600  # 1 hour

    # ForLLM
    max_tokens : int = 2000
    
    # Logging
    log_level: str = "INFO"
    enable_stats: bool = True
    
    def __post_init__(self):
        """Validate configuration"""
        self._validate()
    
    def _validate(self):
        """Validate configuration parameters"""
        if self.max_short_term < 1:
            raise ValueError("max_short_term must be at least 1")
        
        if not 0 <= self.importance_threshold <= 1:
            raise ValueError("importance_threshold must be between 0 and 1")
        
        if not 0 <= self.similarity_threshold <= 1:
            raise ValueError("similarity_threshold must be between 0 and 1")
        
        if self.retrieval_limit < 1:
            raise ValueError("retrieval_limit must be at least 1")
        
        if self.enable_decay and not 0 <= self.decay_rate <= 1:
            raise ValueError("decay_rate must be between 0 and 1")
    
    @classmethod
    def from_env(cls) -> 'MemoryConfig':
        """
        Create configuration from environment variables
        
        Environment variables:
            MEMORY_MAX_SHORT_TERM: Max short-term memories
            MEMORY_MAX_LONG_TERM: Max long-term memories
            MEMORY_EMBEDDING_MODEL: Embedding model name
            MEMORY_PERSISTENCE_PATH: Path for persistence
        """
        return cls(
            max_short_term=int(os.getenv('MEMORY_MAX_SHORT_TERM', 100)),
            max_long_term=int(os.getenv('MEMORY_MAX_LONG_TERM', 1000)),
            embedding_model=os.getenv('MEMORY_EMBEDDING_MODEL', 'all-MiniLM-L6-v2'),
            persistence_path=os.getenv('MEMORY_PERSISTENCE_PATH', './memory_storage'),
            enable_persistence=os.getenv('MEMORY_ENABLE_PERSISTENCE', 'true').lower() == 'true',
        )
    
    def to_dict(self) -> dict:
        """Convert configuration to dictionary"""
        return {
            'max_short_term': self.max_short_term,
            'max_long_term': self.max_long_term,
            'max_working': self.max_working,
            'max_episodic': self.max_episodic,
            'importance_threshold': self.importance_threshold,
            'similarity_threshold': self.similarity_threshold,
            'retrieval_limit': self.retrieval_limit,
            'embedding_model': self.embedding_model,
            'enable_persistence': self.enable_persistence,
            'enable_decay': self.enable_decay,
        }



