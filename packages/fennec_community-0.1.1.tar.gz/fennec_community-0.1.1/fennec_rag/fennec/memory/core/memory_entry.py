from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import time
import hashlib
import json
from .memory_type import MemoryType, MemoryPriority


@dataclass
class MemoryEntry:
    """
    Represents a single memory entry
    
    Attributes:
        content: The actual content/data of the memory
        timestamp: When the memory was created
        memory_type: Type of memory (short/long/working/episodic)
        importance: Importance score (0-1)
        access_count: Number of times accessed
        tags: List of tags for categorization
        metadata: Additional metadata dictionary
        embedding: Vector embedding of the content
        last_access: Timestamp of last access
        decay_factor: Current decay factor
        original_importance: Original importance (before decay)
    """
    
    content: Any
    timestamp: float
    memory_type: MemoryType
    importance: float = 0.5
    access_count: int = 0
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None
    last_access: float = field(default_factory=time.time)
    decay_factor: float = 1.0
    original_importance: Optional[float] = None
    
    def __post_init__(self):
        """Initialize after creation"""
        if self.original_importance is None:
            self.original_importance = self.importance
        
        # Validate importance
        if not 0 <= self.importance <= 1:
            raise ValueError(f"importance must be between 0 and 1, got {self.importance}")
        
        # Generate ID if not in metadata
        if 'id' not in self.metadata:
            self.metadata['id'] = self._generate_id()
    
    def _generate_id(self) -> str:
        """Generate unique ID for this memory"""
        data = f"{self.content}_{self.timestamp}_{self.memory_type.value}"
        return hashlib.md5(data.encode('utf-8')).hexdigest()[:16]
    
    @property
    def id(self) -> str:
        """Get memory ID"""
        return self.metadata.get('id', 'unknown')
    
    @property
    def age_seconds(self) -> float:
        """Get age of memory in seconds"""
        return time.time() - self.timestamp
    
    @property
    def age_days(self) -> float:
        """Get age of memory in days"""
        return self.age_seconds / 86400
    
    @property
    def time_since_access_seconds(self) -> float:
        """Get time since last access in seconds"""
        return time.time() - self.last_access
    
    @property
    def effective_importance(self) -> float:
        """Get importance after applying decay"""
        return self.importance * self.decay_factor
    
    @property
    def priority(self) -> MemoryPriority:
        """Get priority level"""
        return MemoryPriority.from_importance(self.effective_importance)
    
    @property
    def has_embedding(self) -> bool:
        """Check if memory has an embedding"""
        return self.embedding is not None and len(self.embedding) > 0
    
    def access(self) -> None:
        """Record an access to this memory"""
        self.access_count += 1
        self.last_access = time.time()
        
        # Boost importance slightly on access
        boost = 0.05 * (1 - self.importance)  # Smaller boost if already important
        self.importance = min(1.0, self.importance + boost)
    
    def apply_decay(self, decay_rate: float = 0.1) -> None:
        """
        Apply time-based decay to importance
        
        Args:
            decay_rate: Decay rate per day
        """
        days_since_access = self.time_since_access_seconds / 86400
        decay = decay_rate * days_since_access
        
        self.decay_factor = max(0.1, 1.0 - decay)
        self.importance = max(0.1, self.importance * self.decay_factor)
    
    def add_tag(self, tag: str) -> None:
        """Add a tag to this memory"""
        tag = tag.strip().lower()
        if tag and tag not in self.tags:
            self.tags.append(tag)
    
    def add_tags(self, tags: List[str]) -> None:
        """Add multiple tags"""
        for tag in tags:
            self.add_tag(tag)
    
    def has_tag(self, tag: str) -> bool:
        """Check if memory has a specific tag"""
        return tag.lower() in self.tags
    
    def update_metadata(self, key: str, value: Any) -> None:
        """Update a metadata field"""
        self.metadata[key] = value
    
    def merge_metadata(self, metadata: Dict[str, Any]) -> None:
        """Merge new metadata with existing"""
        self.metadata.update(metadata)
    
    def to_dict(self, include_embedding: bool = False) -> Dict[str, Any]:
        """
        Convert memory to dictionary
        
        Args:
            include_embedding: Whether to include embedding vector
        
        Returns:
            Dictionary representation
        """
        result = {
            'id': self.id,
            'content': self.content,
            'timestamp': self.timestamp,
            'memory_type': self.memory_type.value,
            'importance': self.importance,
            'effective_importance': self.effective_importance,
            'access_count': self.access_count,
            'tags': self.tags,
            'metadata': self.metadata,
            'last_access': self.last_access,
            'decay_factor': self.decay_factor,
            'age_seconds': self.age_seconds,
            'priority': self.priority.name,
        }
        
        if include_embedding and self.has_embedding:
            result['embedding'] = self.embedding
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MemoryEntry':
        """
        Create MemoryEntry from dictionary
        
        Args:
            data: Dictionary with memory data
        
        Returns:
            MemoryEntry instance
        """
        # Convert memory_type string to enum
        memory_type = MemoryType.from_string(data.get('memory_type', 'short_term'))
        
        return cls(
            content=data['content'],
            timestamp=data['timestamp'],
            memory_type=memory_type,
            importance=data.get('importance', 0.5),
            access_count=data.get('access_count', 0),
            tags=data.get('tags', []),
            metadata=data.get('metadata', {}),
            embedding=data.get('embedding'),
            last_access=data.get('last_access', time.time()),
            decay_factor=data.get('decay_factor', 1.0),
            original_importance=data.get('original_importance')
        )
    
    def to_json(self, include_embedding: bool = False) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(include_embedding=include_embedding))
    
    @classmethod
    def from_json(cls, json_str: str) -> 'MemoryEntry':
        """Create from JSON string"""
        data = json.loads(json_str)
        return cls.from_dict(data)
    
    def __repr__(self) -> str:
        """String representation"""
        content_preview = str(self.content)[:50]
        if len(str(self.content)) > 50:
            content_preview += "..."
        
        return (f"MemoryEntry(id={self.id}, type={self.memory_type.value}, "
                f"importance={self.importance:.2f}, access_count={self.access_count}, "
                f"content='{content_preview}')")
    
    def __eq__(self, other) -> bool:
        """Check equality based on ID"""
        if not isinstance(other, MemoryEntry):
            return False
        return self.id == other.id
    
    def __hash__(self) -> int:
        """Hash based on ID"""
        return hash(self.id)
    
    def __lt__(self, other) -> bool:
        """Compare based on effective importance"""
        if not isinstance(other, MemoryEntry):
            return NotImplemented
        return self.effective_importance < other.effective_importance