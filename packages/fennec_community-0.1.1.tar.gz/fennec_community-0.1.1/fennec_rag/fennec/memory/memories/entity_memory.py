"""
ذاكرة تتبع الكيانات (Entity Memory)
Entity Tracking Memory
"""

from typing import Dict, Any, List 
import logging
from ..core import BaseMemory, Entity
logger = logging.getLogger(__name__)


class ConversationEntityMemory(BaseMemory):
    """
    ذاكرة تتبع الكيانات - تحفظ معلومات عن الكيانات المذكورة\n
    Entity tracking memory - stores information about mentioned entities
    
    مناسبة للمحادثات التي تتضمن العديد من الأشخاص أو الأماكن أو المنظمات\n
    Suitable for conversations involving many people, places, or organizations
    """
    
    def __init__(
        self,
        llm = None ,
        memory_key: str = "entity_info",
        input_key: str = "input",
        output_key: str = "output",
        lang : str = "en",
        entity_extraction_prompt: str = None
        
    ):
        """
        Args:
            llm: نموذج اللغة لاستخراج الكيانات / Language model for entity extraction
            memory_key: مفتاح معلومات الكيانات / Entity information key
            input_key: مفتاح المدخلات / Input key
            output_key: مفتاح المخرجات / Output key
            entity_extraction_prompt: قالب prompt لاستخراج الكيانات / Prompt template for entity extraction
            lang: اللغة / Language for extract entity
        """
        self.llm = llm
        self.memory_key = memory_key
        self.input_key = input_key
        self.output_key = output_key
        self.lang = lang
        self._nlp = None
        
        self.entity_store: Dict[str, Entity] = {}
        self.chat_memory: List[Dict[str, Any]] = []
        
        # قالب استخراج الكيانات / Entity extraction template
        self.entity_extraction_prompt = (
            entity_extraction_prompt or self._default_extraction_prompt()
        )
    
    def _default_extraction_prompt(self) -> str:
        """
        قالب استخراج الكيانات الافتراضي\n
        Default entity extraction template
        """
        return """استخرج الكيانات المهمة من النص التالي.
                الكيانات يمكن أن تكون: أسماء أشخاص، أماكن، منظمات، منتجات، أو مفاهيم مهمة.
                النص:
                {text}
                الكيانات (قائمة مفصولة بفواصل فقط، بدون شرح):
                extract the important entities from the above text.
                the entities can be: names of people, places, organizations, products, or topics.
                the text {text} the entitites (a list without explainer text)

                """
            
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, Any]):
        """
        حفظ وتحديث الكيانات\n
        Save and update entities
        """
        input_text = inputs.get(self.input_key, "")
        output_text = outputs.get(self.output_key, "")
        combined_text = f"{input_text} {output_text}"
        
        # استخراج الكيانات / Extract entities
        entities = self._extract_entities(combined_text)
        
        # تحديث مخزن الكيانات / Update entity store
        for entity_name in entities:
            if entity_name not in self.entity_store:
                self.entity_store[entity_name] = Entity(
                    name=entity_name,
                    entity_type="unknown"  # يمكن تحسينه لاحقاً / Can be improved later
                )
            
            self.entity_store[entity_name].add_context(combined_text)
        
        # حفظ في الذاكرة / Save to memory
        self.chat_memory.append({
            "input": input_text,
            "output": output_text,
            "entities": entities
        })
        
        logger.debug(f"extracted: {len(entities)} entities: {entities}")
    
    def _extract_entities(self, text: str) -> List[str]:
        try:
            # 🔹 استخدام LLM (أفضل اختيار)
            if self.llm:
                prompt = self.entity_extraction_prompt.format(text=text)
                response = self.llm.generate(prompt, max_tokens=100)

                entities = [
                    e.strip()
                    for e in response.split(',')
                    if e.strip() and len(e.strip()) > 2
                ]
                return entities

            # 🔹 fallback: stanza (بعد التعديل)
            else:
                if self._nlp is None:
                    import stanza
                    self._nlp = stanza.Pipeline(
                        lang=self.lang,
                        processors='tokenize,ner'
                    )

                doc = self._nlp(text)

                # ✅ فلترة أفضل (تجنب الأرقام والـ noise)
                entities = [
                    ent.text.strip()
                    for ent in doc.ents
                    if ent.text.strip().isalpha() or len(ent.text.strip()) > 3
                ]

                return entities

        except Exception as e:
            logger.error(f"Error in extracting entities: {e}")
            return []
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحميل معلومات الكيانات ذات الصلة\n
        Load relevant entity information
        """
        input_text = inputs.get(self.input_key, "")
        
        # استخراج الكيانات من المدخلات الحالية / Extract entities from current input
        current_entities = self._extract_entities(input_text)
        
        # جمع المعلومات ذات الصلة / Gather relevant information
        relevant_info = []
        for entity_name in current_entities:
            if entity_name in self.entity_store:
                entity = self.entity_store[entity_name]
                contexts = entity.get_recent_contexts(limit=3)
                
                if contexts:
                    info = "\n".join(contexts)
                    relevant_info.append(
                        f"معلومات سابقة عن {entity_name}:\n{info}"
                    )
        
        # دمج المعلومات / Merge information
        entity_info = "\n\n".join(relevant_info) if relevant_info else ""
        
        return {self.memory_key: entity_info}
    
    def clear(self):
        """
        مسح الذاكرة\n
        Clear memory
        """
        self.entity_store.clear()
        self.chat_memory.clear()
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        الحصول على إحصائيات الذاكرة\n
        Get memory statistics
        """
        total_contexts = sum(
            len(entity.contexts)
            for entity in self.entity_store.values()
        )
        
        return {
            'type': 'ConversationEntityMemory',
            'entity_count': len(self.entity_store),
            'message_count': len(self.chat_memory),
            'total_contexts': total_contexts
        }
    
    def get_entity_info(self, entity_name: str) -> Dict[str, Any]:
        """
        الحصول على معلومات كيان محدد\n
        Get information about a specific entity
        
        Args:
            entity_name: اسم الكيان / Entity name
            
        Returns:
            معلومات الكيان أو None / Entity information or None
        """
        entity = self.entity_store.get(entity_name)
        if entity:
            return {
                'name': entity.name,
                'type': entity.entity_type,
                'contexts_count': len(entity.contexts),
                'first_seen': entity.first_seen,
                'last_seen': entity.last_seen,
                'recent_contexts': entity.get_recent_contexts()
            }
        return None
    
    def list_entities(self) -> List[str]:
        """
        الحصول على قائمة بجميع الكيانات\n
        Get list of all entities
        """
        return list(self.entity_store.keys())
    async def asave_context(self, inputs, outputs):
        import asyncio
        return await asyncio.to_thread(self.save_context, inputs, outputs)

    async def aload_memory_variables(self, inputs):
        import asyncio
        return await asyncio.to_thread(self.load_memory_variables, inputs)
