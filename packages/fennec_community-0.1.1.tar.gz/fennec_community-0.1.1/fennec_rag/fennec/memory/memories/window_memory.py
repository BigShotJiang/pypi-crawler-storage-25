"""
ذاكرة بنافذة محدودة (Window Memory)
Window Memory with Limited Buffer
"""
from typing import Dict, Any
from collections import deque
from .buffer_memory import ConversationBufferMemory


class ConversationBufferWindowMemory(ConversationBufferMemory):
    """
    ذاكرة بنافذة محدودة - تحفظ آخر K رسالة فقط\n
    Window memory with limited buffer - stores only the last K messages
    
    مناسبة للمحادثات الطويلة حيث نحتاج فقط للسياق الأخير\n
    Suitable for long conversations where we only need recent context
    """
    
    def __init__(self, k: int = 5, **kwargs):
        """
        Args:
            k: عدد الرسائل المحفوظة / Number of messages to keep
            **kwargs: معاملات إضافية للكلاس الأب / Additional parameters for parent class
        """
        super().__init__(**kwargs)
        if k <= 0:
            raise ValueError("k must be a positive integer")
        
        self.k = k
        # استخدام deque مع حد أقصى للحجم / Use deque with maximum size
        self.chat_memory = deque(maxlen=k)
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        الحصول على إحصائيات الذاكرة\n
        Get memory statistics
        """
        stats = super().get_memory_stats()
        stats.update({
            'type': 'ConversationBufferWindowMemory',
            'window_size': self.k,
            'is_full': len(self.chat_memory) >= self.k
        })
        return stats
    
    def get_window_info(self) -> Dict[str, Any]:
        """
        معلومات عن حالة النافذة\n
        Information about window status
        
        Returns:
            معلومات حول النافذة الحالية / Information about current window
        """
        return {
            'current_size': len(self.chat_memory),
            'max_size': self.k,
            'available_slots': self.k - len(self.chat_memory),
            'is_full': len(self.chat_memory) >= self.k
        }
    async def asave_context(self, inputs, outputs):
        import asyncio
        return await asyncio.to_thread(self.save_context, inputs, outputs)

    async def aload_memory_variables(self, inputs):
        import asyncio
        return await asyncio.to_thread(self.load_memory_variables, inputs)
