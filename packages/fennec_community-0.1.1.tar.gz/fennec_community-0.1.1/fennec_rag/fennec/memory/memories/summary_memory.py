"""
ذاكرة مع تلخيص تلقائي (Summary Memory)
Summary Memory with Automatic Summarization
"""

from typing import Dict, Any, List
import logging
from ..core import BaseMemory
from ..core import MemoryConfig as memory_config


logger = logging.getLogger(__name__)


class ConversationSummaryMemory(BaseMemory):
    """
    ذاكرة مع تلخيص تلقائي - تلخص المحادثات القديمة\n
    Memory with automatic summarization - summarizes old conversations
    
    مناسبة للمحادثات الطويلة جداً حيث نحتاج لتقليل حجم السياق\n
    Suitable for very long conversations where we need to reduce context size
    """
    
    def __init__(
        self,
        llm,
        max_token_limit: int = memory_config.max_token_limit,
        memory_key: str = "history",
        input_key: str = "input",
        output_key: str = "output",
        summary_prompt_template: str = None
    ):
        """
        Args:
            llm: نموذج اللغة للتلخيص / Language model for summarization
            max_token_limit: الحد الأقصى للـ tokens قبل التلخيص / Maximum tokens before summarization
            memory_key: مفتاح الذاكرة / Memory key
            input_key: مفتاح المدخلات / Input key
            output_key: مفتاح المخرجات / Output key
            summary_prompt_template: قالب prompt للتلخيص / Prompt template for summarization
        """
        self.llm = llm
        self.max_token_limit = max_token_limit
        self.memory_key = memory_key
        self.input_key = input_key
        self.output_key = output_key
        
        self.chat_memory: List[Dict[str, Any]] = []
        self.summary = ""
        
        # قالب التلخيص الافتراضي / Default summary template
        self.summary_prompt_template = summary_prompt_template or self._default_summary_template()
    
    def _default_summary_template(self) -> str:
        """
        قالب التلخيص الافتراضي\n
        Default summary template
        """
        return """لخص المحادثة التالية بإيجاز، مع التركيز على النقاط الرئيسية:
                    الملخص السابق: {previous_summary}
                    المحادثة الجديدة:
                    {new_conversation}
                    الملخص الشامل:
                    summary the next converatsion wiht focsing on the most important points.
                    {previous_summary} {new_conversation}
                    """
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, Any]):
        """
        حفظ مع تلخيص عند الحاجة\n
        Save with summarization when needed
        """
        message = {
            "input": inputs.get(self.input_key),
            "output": outputs.get(self.output_key)
        }
        self.chat_memory.append(message)
        
        # التحقق من الحجم وتلخيص إذا لزم الأمر / Check size and summarize if needed
        if self._get_token_count() > self.max_token_limit:
            logger.info(f" the token limit has been reached ({self.max_token_limit} tokens)" )
            self._summarize()
    
    def _get_token_count(self) -> int:
        """
        حساب عدد الـ tokens التقريبي
        Calculate approximate token count
        
        Returns:
            عدد الـ tokens المقدر / Estimated token count
        """
        # الملخص / Summary
        summary_tokens = len(self.summary.split())
        
        # الرسائل الحالية / Current messages
        messages_text = "\n".join([
            f"{msg['input']} {msg['output']}"
            for msg in self.chat_memory
        ])
        messages_tokens = len(messages_text.split())
        
        # تقدير تقريبي (كلمة واحدة ≈ 1.3 token) / Rough estimate (1 word ≈ 1.3 tokens)
        return int((summary_tokens + messages_tokens) * 1.3)
    
    def _summarize(self):
        """
        تلخيص المحادثة الحالية\n
        Summarize current conversation
        """
        try:
            # تنسيق المحادثة / Format conversation
            conversation_text = self._format_conversation()
            
            # إنشاء prompt التلخيص / Create summary prompt
            prompt = self.summary_prompt_template.format(
                previous_summary=self.summary or "not found ",
                new_conversation=conversation_text
            )
            
            # توليد الملخص / Generate summary
            new_summary = self.llm.generate(prompt, max_tokens=200)
            
            # تحديث الملخص ومسح الذاكرة / Update summary and clear memory
            self.summary = new_summary.strip()
            self.chat_memory.clear()
            
            logger.info("the summary has been generated successfully")
            
        except Exception as e:
            logger.error(f"error in summarizing the conversation: {e}")
            # في حالة الفشل، نحتفظ بآخر N رسالة فقط / In case of failure, keep only last N messages
            self.chat_memory = self.chat_memory[-5:]
    
    def _format_conversation(self) -> str:
        """
        تنسيق المحادثة للتلخيص
        Format conversation for summarization
        """
        formatted = []
        for msg in self.chat_memory:
            formatted.append(
                f"user: {msg['input']}\nassistant: {msg['output']}"
            )
        return "\n".join(formatted)
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحميل الملخص والرسائل الحديثة\n
        Load summary and recent messages
        """
        # الرسائل الحديثة / Recent messages
        recent_messages = self._format_conversation()
        
        # دمج الملخص مع الرسائل الحديثة / Merge summary with recent messages
        if self.summary and recent_messages:
            full_history = f"{self.summary}\n\n---  the recent conversation---\n{recent_messages}"
        elif self.summary:
            full_history = self.summary
        else:
            full_history = recent_messages
        
        return {self.memory_key: full_history}
    
    def clear(self):
        """
        مسح الذاكرة والملخص\n
        Clear memory and summary
        """
        self.chat_memory.clear()
        self.summary = ""
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        الحصول على إحصائيات الذاكرة\n
        Get memory statistics
        """
        return {
            'type': 'ConversationSummaryMemory',
            'has_summary': bool(self.summary),
            'summary_length': len(self.summary),
            'recent_messages_count': len(self.chat_memory),
            'estimated_tokens': self._get_token_count(),
            'token_limit': self.max_token_limit
        }
    
    def get_summary(self) -> str:
        """
        الحصول على الملخص الحالي\n
        Get current summary
        """
        return self.summary
    
    def force_summarize(self):
        """
        فرض التلخيص حتى لو لم نصل للحد الأقصى\n
        Force summarization even if we haven't reached the limit
        """
        if self.chat_memory:
            self._summarize()
    async def asave_context(self, inputs, outputs):
        import asyncio
        return await asyncio.to_thread(self.save_context, inputs, outputs)

    async def aload_memory_variables(self, inputs):
        import asyncio
        return await asyncio.to_thread(self.load_memory_variables, inputs)
