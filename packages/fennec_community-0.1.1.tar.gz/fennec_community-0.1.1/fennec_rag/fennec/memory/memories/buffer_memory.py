"""
ذاكرة المحادثة الكاملة (Buffer Memory)
Conversation Buffer Memory
"""
from typing import Dict, Any, List
import time
from ..core import BaseMemory


class ConversationBufferMemory(BaseMemory):
    """
    ذاكرة محادثة كاملة - تحفظ كل المحادثة\n
    Complete conversation memory - stores entire conversation
    
    مناسبة للمحادثات القصيرة أو عندما تحتاج للسياق الكامل\n
    Suitable for short conversations or when you need full context
    """
    
    def __init__(
        self,
        return_messages: bool = False,
        input_key: str = "input",
        output_key: str = "output",
        memory_key: str = "history"
    ):
        """
        Args:
            return_messages: إرجاع الرسائل ككائنات أم كنص / Return messages as objects or text
            input_key: مفتاح المدخلات / Input key
            output_key: مفتاح المخرجات / Output key
            memory_key: مفتاح الذاكرة في القاموس المُرجع / Memory key in returned dictionary
        """
        self.chat_memory: List[Dict[str, Any]] = []
        self.return_messages = return_messages
        self.input_key = input_key
        self.output_key = output_key
        self.memory_key = memory_key
    
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, Any]):
        """
        حفظ السياق في الذاكرة\n
        Save context to memory
        """
        message = {
            "input": inputs.get(self.input_key),
            "output": outputs.get(self.output_key),
            "timestamp": time.time()
        }
        self.chat_memory.append(message)
    
    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        تحميل متغيرات الذاكرة\n
        Load memory variables
        """
        if self.return_messages:
            return {self.memory_key: self.chat_memory}
        else:
            # تحويل إلى نص / Convert to text
            text = self._format_messages_as_text()
            return {self.memory_key: text}
    
    def _format_messages_as_text(self) -> str:
        """
        تنسيق الرسائل كنص
        Format messages as text
        """
        formatted = []
        for msg in self.chat_memory:
            formatted.append(
                f"user: {msg['input']}\nassistant: {msg['output']}"
            )
        return "\n".join(formatted)
    
    def clear(self):
        """
        مسح الذاكرة\n
        Clear memory
        """
        self.chat_memory.clear()
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        الحصول على إحصائيات الذاكرة\n
        Get memory statistics
        """
        total_chars = sum(
            len(str(msg['input'])) + len(str(msg['output']))
            for msg in self.chat_memory
        )
        
        return {
            'type': 'ConversationBufferMemory',
            'message_count': len(self.chat_memory),
            'total_characters': total_chars,
            'estimated_tokens': total_chars // 4  # تقدير تقريبي / Rough estimate
        }
    
    def get_messages(self, limit: int = None) -> List[Dict[str, Any]]:
        """
        الحصول على الرسائل\n
        Get messages
        
        Args:
            limit: عدد الرسائل المطلوبة (None للكل) / Number of messages requested (None for all)
        """
        if limit:
            return self.chat_memory[-limit:]
        return self.chat_memory.copy()
    async def asave_context(self, inputs, outputs):
        import asyncio
        return await asyncio.to_thread(self.save_context, inputs, outputs)

    async def aload_memory_variables(self, inputs):
        import asyncio
        return await asyncio.to_thread(self.load_memory_variables, inputs)
