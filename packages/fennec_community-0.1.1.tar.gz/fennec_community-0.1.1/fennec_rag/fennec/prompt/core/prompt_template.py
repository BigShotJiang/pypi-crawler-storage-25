# -*- coding: utf-8 -*-
"""
Prompt Template Module - وحدة قوالب الـ Prompts

قالب متقدم لإنشاء وتنسيق الـ prompts
Advanced template for creating and formatting prompts
"""

from typing import Dict, List, Any, Optional
from string import Formatter
import json
import logging
import os

logger = logging.getLogger(__name__)


class PromptTemplate:
    """
    Advanced prompt template with multiple format support
    
    قالب متقدم للـ prompts مع دعم تنسيقات متعددة
    
    Features:
        - Automatic variable extraction / استخراج تلقائي للمتغيرات
        - Multiple template formats (f-string, jinja2) / تنسيقات متعددة
        - Template validation / التحقق من القالب
        - Partial variable support / دعم المتغيرات الجزئية
        - Template composition / دمج القوالب
    """
    
    SUPPORTED_FORMATS = ['f-string', 'jinja2']
    
    def __init__(
        self,
        template: str,
        input_variables: Optional[List[str]] = None,
        partial_variables: Optional[Dict[str, Any]] = None,
        template_format: str = "f-string",
        validate_template: bool = True
    ):
        """
        Initialize prompt template
        
        Args:
            template: The template string
            input_variables: List of input variables (auto-extracted if None)
            partial_variables: Pre-filled variables
            template_format: Format type ('f-string' or 'jinja2')
            validate_template: Whether to validate on initialization
        """
        if template_format not in self.SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported template format: {template_format}. "
                f"Supported: {self.SUPPORTED_FORMATS}"
            )
        
        self.template = template
        self.template_format = template_format
        self.partial_variables = partial_variables or {}
        
        # Extract variables automatically if not provided
        if input_variables is None:
            self.input_variables = self._extract_variables()
        else:
            self.input_variables = input_variables
        
        if validate_template:
            self._validate()
    
    def _extract_variables(self) -> List[str]:
        """
        Extract variables from template
        
        Returns:
            List of variable names
        """
        if self.template_format == "f-string":
            variables = []
            for _, field_name, _, _ in Formatter().parse(self.template):
                if field_name is not None and field_name:
                    # Handle nested attributes (e.g., {user.name})
                    base_var = field_name.split('.')[0].split('[')[0]
                    if base_var and base_var not in variables:
                        variables.append(base_var)
            return variables
        
        elif self.template_format == "jinja2":
            try:
                import jinja2
                import jinja2.meta
                
                env = jinja2.Environment()
                ast = env.parse(self.template)
                variables = jinja2.meta.find_undeclared_variables(ast)
                return sorted(list(variables))
            except ImportError:
                logger.error("jinja2 not installed")
                return []
        
        return []
    
    def _validate(self) -> None:
        """
        Validate template structure
        
        Raises:
            ValueError: If template is invalid
        """
        missing = set(self.input_variables) - set(self.partial_variables.keys())
        if not missing:
            return
        
        # Try formatting with dummy values
        dummy_vars = {var: "test" for var in missing}
        try:
            self.format(**dummy_vars)
        except KeyError as e:
            raise ValueError(f"Missing variable: {e}")
        except Exception as e:
            logger.warning(f"Template validation warning: {e}")
    
    def format(self, **kwargs) -> str:
        """
        Format the template with provided variables
        
        Args:
            **kwargs: Variables to fill in the template
            
        Returns:
            Formatted prompt string
            
        Raises:
            ValueError: If required variables are missing
        """
        # Merge partial and provided variables
        all_vars = {**self.partial_variables, **kwargs}
        
        # Check for missing variables
        missing = set(self.input_variables) - set(all_vars.keys())
        if missing:
            raise ValueError(
                f"Missing required variables: {missing}. "
                f"Required: {self.input_variables}"
            )
        
        # Format based on template type
        if self.template_format == "f-string":
            try:
                return self.template.format(**all_vars)
            except Exception as e:
                raise ValueError(f"Formatting error: {e}")
        
        elif self.template_format == "jinja2":
            try:
                import jinja2
                jinja_template = jinja2.Template(self.template)
                return jinja_template.render(**all_vars)
            except ImportError:
                raise ValueError("jinja2 not installed. Install with: pip install jinja2")
            except Exception as e:
                raise ValueError(f"Formatting error: {e}")
        
        else:
            raise ValueError(f"Unsupported format: {self.template_format}")
    
    def partial(self, **kwargs) -> 'PromptTemplate':
        """
        Create a partial template with pre-filled variables
        
        Args:
            **kwargs: Variables to pre-fill
            
        Returns:
            New PromptTemplate with partial variables
        """
        new_partial = {**self.partial_variables, **kwargs}
        return PromptTemplate(
            template=self.template,
            input_variables=self.input_variables,
            partial_variables=new_partial,
            template_format=self.template_format,
            validate_template=False
        )
    
    def __add__(self, other) -> 'PromptTemplate':
        """
        Combine two templates
        
        Args:
            other: Another PromptTemplate or string
            
        Returns:
            Combined PromptTemplate
        """
        if isinstance(other, PromptTemplate):
            combined_template = self.template + "\n\n" + other.template
            combined_variables = list(set(self.input_variables + other.input_variables))
            combined_partials = {**self.partial_variables, **other.partial_variables}
            
            return PromptTemplate(
                template=combined_template,
                input_variables=combined_variables,
                partial_variables=combined_partials,
                template_format=self.template_format,
                validate_template=False
            )
        elif isinstance(other, str):
            return PromptTemplate(
                template=self.template + "\n\n" + other,
                input_variables=self.input_variables,
                partial_variables=self.partial_variables,
                template_format=self.template_format,
                validate_template=False
            )
        
        return NotImplemented
    
    def copy(self) -> 'PromptTemplate':
        """Create a copy of the template"""
        return PromptTemplate(
            template=self.template,
            input_variables=self.input_variables.copy(),
            partial_variables=self.partial_variables.copy(),
            template_format=self.template_format,
            validate_template=False
        )
    
    def save(self, filepath: str) -> None:
        """
        Save template to file
        
        Args:
            filepath: Path to save the template
        """
        data = {
            'template': self.template,
            'input_variables': self.input_variables,
            'partial_variables': self.partial_variables,
            'template_format': self.template_format
        }
        if not os.path.exists(os.path.dirname(filepath)):
            logger.warning(f"Path {filepath} not existed , creating one..")
            os.makedirs(os.path.dirname(filepath))
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Template saved to {filepath}")
    
    @classmethod
    def load(cls, filepath: str) -> 'PromptTemplate':
        """
        Load template from file
        
        Args:
            filepath: Path to load the template from
            
        Returns:
            PromptTemplate instance
        """
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return cls(
            template=data['template'],
            input_variables=data.get('input_variables'),
            partial_variables=data.get('partial_variables'),
            template_format=data.get('template_format', 'f-string')
        )
    
    def __repr__(self) -> str:
        """String representation"""
        return (f"PromptTemplate(variables={self.input_variables}, "
                f"partials={list(self.partial_variables.keys())})")