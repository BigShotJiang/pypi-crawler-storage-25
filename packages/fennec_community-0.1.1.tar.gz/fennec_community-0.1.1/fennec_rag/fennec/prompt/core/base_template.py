# -*- coding: utf-8 -*-
"""
Base Template Module
Defines the abstract base class for all template types
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
import logging

logger = logging.getLogger(__name__)


class BaseTemplate(ABC):
    """
    Abstract base class for all prompt templates
    
    الكلاس الأساسي لجميع قوالب الـ prompts
    """
    
    def __init__(
        self,
        input_variables: Optional[List[str]] = None,
        partial_variables: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize base template
        
        Args:
            input_variables: List of required input variables
            partial_variables: Dictionary of pre-filled variables
        """
        self.input_variables = input_variables or []
        self.partial_variables = partial_variables or {}
        
    @abstractmethod
    def format(self, **kwargs) -> str:
        """
        Format the template with provided variables
        
        Args:
            **kwargs: Variables to fill in the template
            
        Returns:
            Formatted string
        """
        pass
    
    @abstractmethod
    def _validate(self) -> None:
        """
        Validate the template structure
        
        Raises:
            ValueError: If template is invalid
        """
        pass
    
    def _check_missing_variables(self, provided_vars: Dict[str, Any]) -> List[str]:
        """
        Check for missing required variables
        
        Args:
            provided_vars: Variables provided by user
            
        Returns:
            List of missing variable names
        """
        all_vars = {**self.partial_variables, **provided_vars}
        required = set(self.input_variables)
        provided = set(all_vars.keys())
        
        return list(required - provided)
    
    def partial(self, **kwargs) -> 'BaseTemplate':
        """
        Create a partial template with pre-filled variables
        
        Args:
            **kwargs: Variables to pre-fill
            
        Returns:
            New template instance with partial variables
        """
        new_partial = {**self.partial_variables, **kwargs}
        # This should be overridden in subclasses
        return self.__class__(
            input_variables=self.input_variables,
            partial_variables=new_partial
        )
    
    def __repr__(self) -> str:
        """String representation"""
        return (f"{self.__class__.__name__}("
                f"input_variables={self.input_variables}, "
                f"partial_variables={list(self.partial_variables.keys())})")
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get template information
        
        Returns:
            Dictionary with template metadata
        """
        return {
            'class': self.__class__.__name__,
            'input_variables': self.input_variables,
            'partial_variables': list(self.partial_variables.keys()),
            'num_inputs': len(self.input_variables),
            'num_partials': len(self.partial_variables)
        }