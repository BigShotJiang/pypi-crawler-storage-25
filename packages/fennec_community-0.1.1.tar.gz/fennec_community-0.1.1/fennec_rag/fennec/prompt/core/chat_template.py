# -*- coding: utf-8 -*-
"""
Chat Prompt Template Module - وحدة قوالب المحادثة

قالب للمحادثات متعددة الرسائل
Template for multi-turn chat conversations
"""

from typing import Dict, List, Any, Optional
from string import Formatter
import logging

logger = logging.getLogger(__name__)


class ChatPromptTemplate:
    """
    Template for multi-turn chat conversations
    
    قالب للمحادثات متعددة الرسائل
    
    Supports:
        - System messages / رسائل النظام
        - User messages / رسائل المستخدم
        - Assistant messages / رسائل المساعد
        - Variable substitution / استبدال المتغيرات
    """
    
    VALID_ROLES = ['system', 'user', 'assistant', 'function']
    
    def __init__(
        self,
        messages: List[Dict[str, str]],
        input_variables: Optional[List[str]] = None,
        partial_variables: Optional[Dict[str, Any]] = None,
        validate_messages: bool = True
    ):
        """
        Initialize chat prompt template
        
        Args:
            messages: List of message dictionaries
            input_variables: List of input variables (auto-extracted if None)
            partial_variables: Pre-filled variables
            validate_messages: Whether to validate message structure
        """
        self.messages = messages
        self.partial_variables = partial_variables or {}
        
        # Extract variables if not provided
        if input_variables is None:
            self.input_variables = self._extract_all_variables()
        else:
            self.input_variables = input_variables
        
        if validate_messages:
            self._validate()
    
    def _extract_all_variables(self) -> List[str]:
        """Extract all variables from all messages"""
        variables = set()
        
        for msg in self.messages:
            content = msg.get("content", "")
            for _, field_name, _, _ in Formatter().parse(content):
                if field_name is not None and field_name:
                    base_var = field_name.split('.')[0].split('[')[0]
                    if base_var:
                        variables.add(base_var)
        
        return sorted(list(variables))
    
    def _validate(self) -> None:
        """Validate message structure"""
        if not self.messages:
            raise ValueError("Messages list cannot be empty")
        
        for i, msg in enumerate(self.messages):
            if "role" not in msg:
                raise ValueError(f"Message {i} missing 'role' field")
            if "content" not in msg:
                raise ValueError(f"Message {i} missing 'content' field")
            
            role = msg["role"]
            if role not in self.VALID_ROLES:
                logger.warning(f"Message {i} has non-standard role: '{role}'")
    
    def format(self, **kwargs) -> List[Dict[str, str]]:
        """
        Format all messages with provided variables
        
        Args:
            **kwargs: Variables to fill in messages
            
        Returns:
            List of formatted message dictionaries
        """
        # Merge partial and provided variables
        all_vars = {**self.partial_variables, **kwargs}
        
        # Check for missing variables
        missing = set(self.input_variables) - set(all_vars.keys())
        if missing:
            raise ValueError(
                f"Missing variables: {missing}. "
                f"Required: {self.input_variables}"
            )
        
        # Format each message
        formatted_messages = []
        for msg in self.messages:
            formatted_msg = {
                "role": msg["role"],
                "content": msg["content"].format(**all_vars)
            }
            
            # Copy optional fields
            for key in ["name", "function_call"]:
                if key in msg:
                    formatted_msg[key] = msg[key]
            
            formatted_messages.append(formatted_msg)
        
        return formatted_messages
    
    def format_as_string(self, **kwargs) -> str:
        """
        Format messages as a single string
        
        Args:
            **kwargs: Variables to fill in
            
        Returns:
            Formatted string with all messages
        """
        messages = self.format(**kwargs)
        
        formatted_parts = []
        for msg in messages:
            role = msg["role"].upper()
            content = msg["content"]
            formatted_parts.append(f"{role}: {content}")
        
        return "\n\n".join(formatted_parts)
    
    def partial(self, **kwargs) -> 'ChatPromptTemplate':
        """Create a partial template with pre-filled variables"""
        new_partial = {**self.partial_variables, **kwargs}
        return ChatPromptTemplate(
            messages=self.messages.copy(),
            input_variables=self.input_variables,
            partial_variables=new_partial,
            validate_messages=False
        )
    
    def add_message(
        self,
        role: str,
        content: str,
        name: Optional[str] = None
    ) -> 'ChatPromptTemplate':
        """Add a message to the template"""
        new_message = {"role": role, "content": content}
        if name:
            new_message["name"] = name
        
        new_messages = self.messages.copy()
        new_messages.append(new_message)
        
        return ChatPromptTemplate(
            messages=new_messages,
            partial_variables=self.partial_variables,
            validate_messages=False
        )
    
    def add_system_message(self, content: str) -> 'ChatPromptTemplate':
        """Add a system message"""
        return self.add_message("system", content)
    
    def add_user_message(self, content: str) -> 'ChatPromptTemplate':
        """Add a user message"""
        return self.add_message("user", content)
    
    def add_assistant_message(self, content: str) -> 'ChatPromptTemplate':
        """Add an assistant message"""
        return self.add_message("assistant", content)
    
    @classmethod
    def from_messages(cls, messages: List[Dict[str, str]]) -> 'ChatPromptTemplate':
        """Create ChatPromptTemplate from messages list"""
        return cls(messages=messages)
    
    @classmethod
    def from_template(cls, template: str, role: str = "user") -> 'ChatPromptTemplate':
        """Create ChatPromptTemplate from a simple template string"""
        messages = [{"role": role, "content": template}]
        return cls(messages=messages)
    
    def __repr__(self) -> str:
        """String representation"""
        return f"ChatPromptTemplate(messages={len(self.messages)}, variables={self.input_variables})"