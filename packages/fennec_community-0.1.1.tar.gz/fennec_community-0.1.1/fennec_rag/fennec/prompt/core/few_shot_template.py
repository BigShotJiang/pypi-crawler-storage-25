# -*- coding: utf-8 -*-
"""
Few-Shot Prompt Template Module - وحدة قوالب Few-Shot

قالب Few-Shot Learning للتعلم من الأمثلة
Template for few-shot learning scenarios
"""

from typing import Dict, List, Any, Optional, Callable
from string import Formatter
import logging

from .prompt_template import PromptTemplate

logger = logging.getLogger(__name__)


class FewShotPromptTemplate:
    """
    Template for few-shot learning prompts
    
    قالب Few-Shot Learning
    
    Features:
        - Custom example formatting / تنسيق مخصص للأمثلة
        - Dynamic example selection / اختيار ديناميكي للأمثلة
        - Maximum examples limit / حد أقصى للأمثلة
    """
    
    def __init__(
        self,
        examples: List[Dict[str, Any]],
        example_prompt: PromptTemplate,
        prefix: str = "",
        suffix: str = "",
        input_variables: Optional[List[str]] = None,
        example_separator: str = "\n\n",
        max_examples: Optional[int] = None,
        example_selector: Optional[Callable] = None
    ):
        """
        Initialize few-shot prompt template
        
        Args:
            examples: List of example dictionaries
            example_prompt: Template for formatting each example
            prefix: Text before examples
            suffix: Text after examples
            input_variables: Variables for suffix
            example_separator: String to separate examples
            max_examples: Maximum number of examples to use
            example_selector: Function to select examples dynamically
        """
        self.examples = examples
        self.example_prompt = example_prompt
        self.prefix = prefix
        self.suffix = suffix
        self.example_separator = example_separator
        self.max_examples = max_examples
        self.example_selector = example_selector
        
        # Extract variables from suffix if not provided
        if input_variables is None:
            self.input_variables = self._extract_suffix_variables()
        else:
            self.input_variables = input_variables
    
    def _extract_suffix_variables(self) -> List[str]:
        """Extract variables from suffix"""
        variables = []
        for _, field_name, _, _ in Formatter().parse(self.suffix):
            if field_name is not None and field_name:
                base_var = field_name.split('.')[0].split('[')[0]
                if base_var and base_var not in variables:
                    variables.append(base_var)
        return variables
    
    def format(self, **kwargs) -> str:
        """
        Format the few-shot prompt
        
        Args:
            **kwargs: Variables for the suffix
            
        Returns:
            Formatted prompt string
        """
        # Check for missing variables
        missing = set(self.input_variables) - set(kwargs.keys())
        if missing:
            raise ValueError(
                f"Missing variables: {missing}. "
                f"Required: {self.input_variables}"
            )
        
        # Select examples
        examples_to_use = self._select_examples(**kwargs)
        
        # Format examples
        formatted_examples = self._format_examples(examples_to_use)
        
        # Format suffix
        formatted_suffix = self.suffix.format(**kwargs) if self.suffix else ""
        
        # Combine all parts
        parts = []
        if self.prefix:
            parts.append(self.prefix)
        if formatted_examples:
            parts.append(formatted_examples)
        if formatted_suffix:
            parts.append(formatted_suffix)
        
        return "\n\n".join(parts)
    
    def _select_examples(self, **kwargs) -> List[Dict[str, Any]]:
        """Select examples to use"""
        if self.example_selector:
            examples = self.example_selector(self.examples, **kwargs)
        else:
            examples = self.examples
        
        # Apply max_examples limit
        if self.max_examples is not None:
            examples = examples[:self.max_examples]
        
        return examples
    
    def _format_examples(self, examples: List[Dict[str, Any]]) -> str:
        """Format all examples"""
        formatted = []
        
        for example in examples:
            try:
                formatted_example = self.example_prompt.format(**example)
                formatted.append(formatted_example)
            except Exception as e:
                logger.error(f"Error formatting example: {e}")
                continue
        
        return self.example_separator.join(formatted)
    
    def add_example(self, example: Dict[str, Any]) -> 'FewShotPromptTemplate':
        """Add an example to the template"""
        new_examples = self.examples.copy()
        new_examples.append(example)
        
        return FewShotPromptTemplate(
            examples=new_examples,
            example_prompt=self.example_prompt,
            prefix=self.prefix,
            suffix=self.suffix,
            input_variables=self.input_variables,
            example_separator=self.example_separator,
            max_examples=self.max_examples,
            example_selector=self.example_selector
        )
    
    def set_max_examples(self, max_examples: int) -> 'FewShotPromptTemplate':
        """Set maximum number of examples"""
        return FewShotPromptTemplate(
            examples=self.examples,
            example_prompt=self.example_prompt,
            prefix=self.prefix,
            suffix=self.suffix,
            input_variables=self.input_variables,
            example_separator=self.example_separator,
            max_examples=max_examples,
            example_selector=self.example_selector
        )
    
    @classmethod
    def from_examples(
        cls,
        examples: List[Dict[str, Any]],
        example_template: str,
        suffix_template: str,
        prefix: str = "",
        **kwargs
    ) -> 'FewShotPromptTemplate':
        """Create FewShotPromptTemplate from examples and templates"""
        example_prompt = PromptTemplate(template=example_template)
        
        return cls(
            examples=examples,
            example_prompt=example_prompt,
            prefix=prefix,
            suffix=suffix_template,
            **kwargs
        )
    
    def __repr__(self) -> str:
        """String representation"""
        return f"FewShotPromptTemplate(examples={len(self.examples)}, variables={self.input_variables})"