# -*- coding: utf-8 -*-
"""
Task Prompts - قوالب المهام

قوالب جاهزة لمهام محددة
Ready-to-use task-specific templates
"""



from ..core.prompt_template import PromptTemplate


class TaskPrompts:
    """
    Collection of task-specific prompt templates
    
    مجموعة من قوالب المهام المحددة
    """
    
    @staticmethod
    def question_answering():
        """
        Question answering template
        قالب الإجابة على الأسئلة
        """
        return PromptTemplate(
            template="""Answer the following question based on the given context.

Context: {context}

Question: {question}

Answer:"""
        )
    
    @staticmethod
    def summarization():
        """
        Text summarization template
        قالب التلخيص
        """
        return PromptTemplate(
            template="""Summarize the following text in {num_sentences} sentences.

Text:
{text}

Summary:"""
        )
    
    @staticmethod
    def translation():
        """
        Translation template
        قالب الترجمة
        """
        return PromptTemplate(
            template="""Translate the following text from {source_lang} to {target_lang}.

Text:
{text}

Translation:"""
        )
    
    @staticmethod
    def classification():
        """
        Text classification template
        قالب التصنيف
        """
        return PromptTemplate(
            template="""Classify the following text into one of these categories: {categories}

Text: {text}

Category:"""
        )
    
    @staticmethod
    def sentiment_analysis():
        """
        Sentiment analysis template
        قالب تحليل المشاعر
        """
        return PromptTemplate(
            template="""Analyze the sentiment of the following text.
Classify it as: Positive, Negative, or Neutral.

Text: {text}

Sentiment:"""
        )
    
    @staticmethod
    def entity_extraction():
        """
        Named entity extraction template
        قالب استخراج الكيانات
        """
        return PromptTemplate(
            template="""Extract all {entity_type} from the following text.

Text: {text}

{entity_type}:"""
        )
    
    @staticmethod
    def code_generation():
        """
        Code generation template
        قالب توليد الكود
        """
        return PromptTemplate(
            template="""Write {language} code to accomplish the following task:

Task: {task}

Requirements:
{requirements}

Code:
```{language}"""
        )
    
    @staticmethod
    def code_review():
        """
        Code review template
        قالب مراجعة الكود
        """
        return PromptTemplate(
            template="""Review the following {language} code and provide feedback.

Code:
```{language}
{code}
```

Review (consider: bugs, performance, best practices, readability):"""
        )
    
    @staticmethod
    def code_explanation():
        """
        Code explanation template
        قالب شرح الكود
        """
        return PromptTemplate(
            template="""Explain what the following {language} code does:

```{language}
{code}
```

Explanation:"""
        )
    
    @staticmethod
    def brainstorming():
        """
        Brainstorming template
        قالب العصف الذهني
        """
        return PromptTemplate(
            template="""Generate {num_ideas} creative ideas for the following:

Topic: {topic}

Context: {context}

Ideas:"""
        )
    
    @staticmethod
    def comparison():
        """
        Comparison template
        قالب المقارنة
        """
        return PromptTemplate(
            template="""Compare and contrast {item1} and {item2}.

Consider:
- Similarities
- Differences
- Pros and Cons
- Use Cases

Comparison:"""
        )
    
    @staticmethod
    def explanation():
        """
        Concept explanation template
        قالب شرح المفاهيم
        """
        return PromptTemplate(
            template="""Explain {concept} in simple terms for {audience}.

Include:
- Definition
- Key Points
- Examples
- Why it matters

Explanation:"""
        )
    
    @staticmethod
    def pros_cons():
        """
        Pros and cons analysis template
        قالب تحليل الإيجابيات والسلبيات
        """
        return PromptTemplate(
            template="""Analyze the pros and cons of {topic}.

Topic: {topic}

Pros (advantages):

Cons (disadvantages):

Conclusion:"""
        )
    
    @staticmethod
    def step_by_step():
        """
        Step-by-step instructions template
        قالب التعليمات خطوة بخطوة
        """
        return PromptTemplate(
            template="""Provide step-by-step instructions for: {task}

Goal: {goal}

Steps:"""
        )
    
    @staticmethod
    def email_writing():
        """
        Email writing template
        قالب كتابة البريد الإلكتروني
        """
        return PromptTemplate(
            template="""Write a {tone} email about {topic}.

To: {recipient}
Subject: {subject}

Email:"""
        )
    
    @staticmethod
    def product_description():
        """
        Product description template
        قالب وصف المنتج
        """
        return PromptTemplate(
            template="""Write a compelling product description for:

Product: {product_name}
Category: {category}
Key Features: {features}
Target Audience: {audience}

Description:"""
        )
    
    @staticmethod
    def blog_post():
        """
        Blog post template
        قالب مقالة المدونة
        """
        return PromptTemplate(
            template="""Write a blog post about {topic}.

Title: {title}
Target Audience: {audience}
Word Count: {word_count} words
Tone: {tone}

Blog Post:"""
        )
    
    @staticmethod
    def social_media_post():
        """
        Social media post template
        قالب منشور وسائل التواصل
        """
        return PromptTemplate(
            template="""Create a {platform} post about {topic}.

Tone: {tone}
Include: {elements}

Post:"""
        )
    
    @staticmethod
    def meeting_notes():
        """
        Meeting notes template
        قالب ملاحظات الاجتماع
        """
        return PromptTemplate(
            template="""Organize the following meeting discussion into structured notes:

Discussion:
{discussion}

Meeting Notes:
- Date & Time:
- Attendees:
- Key Points:
- Decisions:
- Action Items:"""
        )