# -*- coding: utf-8 -*-
"""
Arabic Prompts - القوالب العربية

قوالب خاصة باللغة العربية
Arabic-specific prompt templates
"""

from ..core.chat_template import ChatPromptTemplate
from ..core.prompt_template import PromptTemplate


class ArabicPrompts:
    """
    Collection of Arabic prompt templates
    
    مجموعة من القوالب العربية
    """
    
    @staticmethod
    def arabic_assistant():
        """
        مساعد عربي عام\n
        General Arabic assistant
        """
        return ChatPromptTemplate.from_messages([
            {
                "role": "system",
                "content": "أنت مساعد ذكي ومفيد. تجيب على الأسئلة بطريقة واضحة ومهذبة. "
                          "تلتزم بتقديم معلومات دقيقة ومفيدة باللغة العربية الفصحى."
            }
        ])
    
    @staticmethod
    def arabic_teacher():
        """
        معلم لغة عربية\n
        Arabic language teacher
        """
        return ChatPromptTemplate.from_messages([
            {
                "role": "system",
                "content": "أنت معلم لغة عربية متمكن. تشرح قواعد اللغة العربية والنحو والصرف "
                          "بطريقة واضحة ومبسطة. تقدم أمثلة عملية وتصحح الأخطاء بلطف."
            }
        ])
    
    @staticmethod
    def quran_explainer():
        """
        شارح القرآن الكريم\n
        Quran explanation assistant
        """
        return ChatPromptTemplate.from_messages([
            {
                "role": "system",
                "content": "أنت مساعد متخصص في شرح معاني القرآن الكريم. "
                          "تقدم التفسير بطريقة واضحة مع الاستناد إلى كتب التفسير المعتمدة. "
                          "تحافظ على الأدب والاحترام عند الحديث عن الآيات الكريمة."
            }
        ])
    
    @staticmethod
    def islamic_scholar():
        """
        عالم إسلامي\n
        Islamic scholar assistant
        """
        return ChatPromptTemplate.from_messages([
            {
                "role": "system",
                "content": "أنت عالم إسلامي متخصص. تجيب على الأسئلة الشرعية بناءً على "
                          "القرآن والسنة وأقوال العلماء المعتبرين. تقدم الإجابات بموضوعية "
                          "وتذكر الأدلة والمراجع عند الحاجة."
            }
        ])
    
    @staticmethod
    def arabic_poet():
        """
        شاعر عربي\n
        Arabic poet
        """
        return ChatPromptTemplate.from_messages([
            {
                "role": "system",
                "content": "أنت شاعر عربي مبدع. تكتب الشعر العربي بأنواعه المختلفة "
                          "(العمودي، الحر، النثري). تلتزم بالبحور الشعرية والقافية عند الطلب. "
                          "تستخدم لغة جميلة وصوراً شعرية مؤثرة."
            }
        ])
    
    @staticmethod
    def arabic_news_writer():
        """
        كاتب أخبار عربي\n
        Arabic news writer
        """
        return ChatPromptTemplate.from_messages([
            {
                "role": "system",
                "content": "أنت كاتب أخبار محترف. تكتب الأخبار بأسلوب صحفي واضح وموضوعي. "
                          "تلتزم بالدقة والحيادية في نقل المعلومات. تستخدم عناوين جذابة ومختصرة."
            }
        ])
    
    @staticmethod
    def question_answering_arabic():
        """
        قالب سؤال وجواب بالعربية\n
        Arabic Q&A template
        """
        return PromptTemplate(
            template="""أجب على السؤال التالي بناءً على السياق المعطى.
                        السياق: {سياق}
                        السؤال: {سؤال}
                        الجواب:"""
                                )
    
    @staticmethod
    def summarization_arabic():
        """
        قالب التلخيص بالعربية\n
        Arabic summarization template
        """
        return PromptTemplate(
            template="""لخص النص التالي في {عدد_الجمل} جمل.
                        النص:
                        {نص}
                        الملخص:"""
                                )
    
    @staticmethod
    def translation_to_arabic():
        """
        قالب الترجمة إلى العربية\n
        Translation to Arabic template
        """
        return PromptTemplate(
            template="""ترجم النص التالي من {اللغة_المصدر} إلى العربية الفصحى.
                        النص:
                        {نص}
                        الترجمة:"""
                                )
    
    @staticmethod
    def grammar_check_arabic():
        """
        قالب التدقيق النحوي العربي\n
        Arabic grammar check template
        """
        return PromptTemplate(
            template="""دقق النص التالي نحوياً وإملائياً وصحح الأخطاء.
                            النص:
                            {نص}
                            التصحيحات:"""
                                    )
                                
    @staticmethod
    def formal_letter_arabic():
        """
        قالب الرسالة الرسمية العربية\n
        Arabic formal letter template
        """
        return PromptTemplate(
            template="""اكتب رسالة رسمية عن {موضوع}.
                        المرسل إليه: {المستلم}
                        الغرض: {الغرض}
                        الرسالة:"""
                                )
    
    @staticmethod
    def essay_arabic():
        """
        قالب المقال العربي\n
        Arabic essay template
        """
        return PromptTemplate(
            template="""اكتب مقالاً عن {موضوع}.

                        العنوان: {عنوان}
                        عدد الكلمات: {عدد_الكلمات}
                        الأسلوب: {أسلوب}
                        المقال:"""
                                )
    
    @staticmethod
    def story_arabic():
        """
        قالب القصة العربية\n
        Arabic story template
        """
        return PromptTemplate(
            template="""اكتب قصة {نوع_القصة} عن {موضوع}.
                        الشخصيات: {شخصيات}
                        المكان: {مكان}
                        الطول: {طول}
                        القصة:"""
                                )
    
    @staticmethod
    def social_media_arabic():
        """
        قالب منشور عربي لوسائل التواصل\n
        Arabic social media template
        """
        return PromptTemplate(
            template="""اكتب منشوراً لـ {منصة} عن {موضوع}.

                    الأسلوب: {أسلوب}
                    يتضمن: {عناصر}
                    المنشور:"""
                            )
    
    @staticmethod
    def proverb_explanation():
        """
        قالب شرح الأمثال العربية
        Arabic proverb explanation template
        """
        return PromptTemplate(
            template="""اشرح المثل العربي التالي:
                        المثل: {مثل}
                        الشرح:
                        - المعنى:
                        - القصة:
                        - الاستخدام:
                        - أمثلة:"""
                                )
    
    @staticmethod
    def poetry_analysis():
        """
        قالب تحليل الشعر العربي
        Arabic poetry analysis template
        """
        return PromptTemplate(
            template="""حلل القصيدة التالية:

                    الشاعر: {شاعر}
                    العصر: {عصر}
                    القصيدة:
                    {قصيدة}
                    التحليل:
                    - البحر والقافية:
                    - الموضوع:
                    - الصور الشعرية:
                    - الأساليب البلاغية:
                    - المعنى العام:"""
                            )
    
    @staticmethod
    def quran_tafseer():
        """
        قالب تفسير آية
        Quranic verse interpretation template
        """
        return PromptTemplate(
            template="""فسر الآية الكريمة التالية:

                    الآية: {آية}
                    السورة: {سورة}
                    التفسير:"""
                            )
    
    @staticmethod
    def hadith_explanation():
        """
        قالب شرح الحديث
        Hadith explanation template
        """
        return PromptTemplate(
            template="""اشرح الحديث النبوي الشريف التالي:

                    الحديث: {حديث}
                    الراوي: {راوي}
                    الشرح:
                    - المعنى الإجمالي:
                    - الفوائد:
                    - الدروس المستفادة:"""
                            )