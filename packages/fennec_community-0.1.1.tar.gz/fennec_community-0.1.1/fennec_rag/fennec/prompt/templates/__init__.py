# -*- coding: utf-8 -*-
"""
Pre-built Templates - القوالب الجاهزة

مجموعة من القوالب الجاهزة للاستخدام المباشر
Collection of ready-to-use templates
"""

from .system_prompts import SystemPrompts
from .task_prompts import TaskPrompts
from .arabic_prompts import ArabicPrompts

__all__ = [
    'SystemPrompts',
    'TaskPrompts',
    'ArabicPrompts',
]