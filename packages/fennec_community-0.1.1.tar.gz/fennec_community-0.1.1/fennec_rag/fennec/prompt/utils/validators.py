# -*- coding: utf-8 -*-
"""
Template Validators - مدققات القوالب

التحقق من صحة القوالب والمتغيرات
Validate templates and variables
"""

from typing import List, Optional, Dict, Any
from string import Formatter
import re
import logging

logger = logging.getLogger(__name__)


class TemplateValidator:
    """
    Validate template structures
    
    مدقق بنية القوالب
    
    Features:
        - Template syntax validation
        - Variable name validation
        - Balanced braces check
        - Format string validation
    """
    
    def __init__(self):
        """Initialize template validator"""
        self.errors = []
        self.warnings = []
    
    def validate_template(
        self,
        template: str,
        expected_variables: Optional[List[str]] = None,
        template_format: str = "f-string"
    ) -> bool:
        """
        Validate that template is well-formed
        
        Args:
            template: Template string
            expected_variables: List of expected variable names
            template_format: Template format
            
        Returns:
            True if valid
            
        Raises:
            ValueError: If validation fails
            
        Example:
            >>> validator = TemplateValidator()
            >>> validator.validate_template("Hello {name}", ["name"])
            True
        """
        self.errors = []
        self.warnings = []
        
        # Check balanced braces
        try:
            self.check_balanced_braces(template)
        except ValueError as e:
            self.errors.append(str(e))
            raise
        
        # Validate format string
        if template_format == "f-string":
            try:
                self.validate_format_string(template)
            except ValueError as e:
                self.errors.append(str(e))
                raise
        
        # Check expected variables
        if expected_variables:
            from .variable_extractor import VariableExtractor
            
            extractor = VariableExtractor(template_format)
            actual_variables = set(extractor.extract(template))
            expected_set = set(expected_variables)
            
            # Check for extra variables
            extra = actual_variables - expected_set
            if extra:
                warning = f"Template contains extra variables: {extra}"
                self.warnings.append(warning)
                logger.warning(warning)
            
            # Check for missing variables
            missing = expected_set - actual_variables
            if missing:
                error = f"Template missing expected variables: {missing}"
                self.errors.append(error)
                raise ValueError(error)
        
        return True
    
    def validate_format_string(self, template: str) -> bool:
        """
        Validate that template is a valid format string
        
        Args:
            template: Template string
            
        Returns:
            True if valid
            
        Raises:
            ValueError: If template is invalid
        """
        try:
            # Try parsing the template
            list(Formatter().parse(template))
            return True
        except Exception as e:
            raise ValueError(f"Invalid template format: {e}")
    
    def validate_variable_names(self, variables: List[str]) -> bool:
        """
        Validate that variable names follow naming conventions
        
        Args:
            variables: List of variable names
            
        Returns:
            True if all valid
            
        Raises:
            ValueError: If any variable name is invalid
            
        Example:
            >>> validator = TemplateValidator()
            >>> validator.validate_variable_names(["name", "age"])
            True
            >>> validator.validate_variable_names(["name", "1invalid"])
            ValueError: Invalid variable name: '1invalid'
        """
        # Python variable naming pattern
        pattern = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')
        
        invalid = []
        for var in variables:
            if not pattern.match(var):
                invalid.append(var)
        
        if invalid:
            raise ValueError(
                f"Invalid variable names: {invalid}. "
                f"Must start with letter or underscore, "
                f"followed by letters, numbers, or underscores."
            )
        
        return True
    
    def check_balanced_braces(self, template: str) -> bool:
        """
        Check if braces are balanced in template
        
        Args:
            template: Template string
            
        Returns:
            True if balanced
            
        Raises:
            ValueError: If braces are unbalanced
            
        Example:
            >>> validator = TemplateValidator()
            >>> validator.check_balanced_braces("Hello {name}")
            True
            >>> validator.check_balanced_braces("Hello {name")
            ValueError: Unmatched opening braces
        """
        stack = []
        i = 0
        
        while i < len(template):
            char = template[i]
            
            if char == '{':
                # Check if it's escaped ({{)
                if i + 1 < len(template) and template[i + 1] == '{':
                    i += 2
                    continue
                stack.append(i)
                i += 1
            elif char == '}':
                # Check if it's escaped (}})
                if i + 1 < len(template) and template[i + 1] == '}':
                    i += 2
                    continue
                if not stack:
                    raise ValueError(f"Unmatched closing brace at position {i}")
                stack.pop()
                i += 1
            else:
                i += 1
        
        if stack:
            raise ValueError(f"Unmatched opening braces at positions: {stack}")
        
        return True
    
    def validate_jinja2_template(self, template: str) -> bool:
        """
        Validate Jinja2 template syntax
        
        Args:
            template: Jinja2 template string
            
        Returns:
            True if valid
            
        Raises:
            ValueError: If template is invalid
        """
        try:
            import jinja2
            
            env = jinja2.Environment()
            env.parse(template)
            return True
        
        except ImportError:
            raise ValueError("jinja2 not installed. Install with: pip install jinja2")
        except jinja2.TemplateSyntaxError as e:
            raise ValueError(f"Invalid Jinja2 template: {e}")
    
    def check_security(self, template: str) -> Dict[str, Any]:
        """
        Check template for potential security issues
        
        Args:
            template: Template string
            
        Returns:
            Dictionary with security check results
        """
        issues = []
        
        # Check for code execution patterns
        dangerous_patterns = [
            r'__import__',
            r'eval\s*\(',
            r'exec\s*\(',
            r'compile\s*\(',
            r'open\s*\(',
            r'__.*__',  # Dunder methods
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, template):
                issues.append(f"Potential security issue: {pattern} found in template")
        
        return {
            'is_safe': len(issues) == 0,
            'issues': issues
        }
    
    def get_errors(self) -> List[str]:
        """Get list of validation errors"""
        return self.errors.copy()
    
    def get_warnings(self) -> List[str]:
        """Get list of validation warnings"""
        return self.warnings.copy()
    
    def clear_messages(self):
        """Clear errors and warnings"""
        self.errors = []
        self.warnings = []
    
    @staticmethod
    def is_valid_variable_name(name: str) -> bool:
        """
        Check if a string is a valid variable name
        
        Args:
            name: Variable name to check
            
        Returns:
            True if valid
        """
        pattern = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')
        return bool(pattern.match(name))
    
    @staticmethod
    def suggest_variable_name(name: str) -> str:
        """
        Suggest a valid variable name based on input
        
        Args:
            name: Original name
            
        Returns:
            Suggested valid variable name
            
        Example:
            >>> TemplateValidator.suggest_variable_name("user name")
            'user_name'
            >>> TemplateValidator.suggest_variable_name("1st-item")
            '_1st_item'
        """
        # Replace spaces and dashes with underscores
        suggested = name.replace(' ', '_').replace('-', '_')
        
        # Remove invalid characters
        suggested = re.sub(r'[^a-zA-Z0-9_]', '', suggested)
        
        # Ensure it starts with letter or underscore
        if suggested and suggested[0].isdigit():
            suggested = '_' + suggested
        
        # If empty, return a default
        if not suggested:
            suggested = 'var'
        
        return suggested