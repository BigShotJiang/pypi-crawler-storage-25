# -*- coding: utf-8 -*-
"""
Template Formatters - منسقات القوالب

أدوات لتنسيق ومعالجة القوالب
Tools for formatting and processing templates
"""

from typing import Dict, Any, Optional
import re
import logging

logger = logging.getLogger(__name__)


class TemplateFormatter:
    """
    Format templates with different format types
    
    منسق القوالب بأنواع تنسيق مختلفة
    
    Features:
        - F-string formatting
        - Jinja2 formatting
        - Special character escaping
        - Whitespace handling
        - Text cleaning
    """
    
    def __init__(self, template_format: str = "f-string"):
        """
        Initialize template formatter
        
        Args:
            template_format: Format type ('f-string' or 'jinja2')
        """
        self.template_format = template_format
    
    def format(self, template: str, variables: Dict[str, Any]) -> str:
        """
        Format template with variables
        
        Args:
            template: Template string
            variables: Variables to fill in
            
        Returns:
            Formatted string
            
        Raises:
            ValueError: If formatting fails
            
        Example:
            >>> formatter = TemplateFormatter()
            >>> formatter.format("Hello {name}", {"name": "Ahmad"})
            'Hello Ahmad'
        """
        if self.template_format == "f-string":
            return self._format_fstring(template, variables)
        elif self.template_format == "jinja2":
            return self._format_jinja2(template, variables)
        else:
            raise ValueError(f"Unsupported template format: {self.template_format}")
    
    def _format_fstring(self, template: str, variables: Dict[str, Any]) -> str:
        """
        Format f-string template
        
        Args:
            template: F-string template
            variables: Variables dict
            
        Returns:
            Formatted string
        """
        try:
            return template.format(**variables)
        except KeyError as e:
            raise ValueError(f"Missing variable in template: {e}")
        except Exception as e:
            raise ValueError(f"Error formatting template: {e}")
    
    def _format_jinja2(self, template: str, variables: Dict[str, Any]) -> str:
        """
        Format Jinja2 template
        
        Args:
            template: Jinja2 template
            variables: Variables dict
            
        Returns:
            Formatted string
        """
        try:
            import jinja2
            
            jinja_template = jinja2.Template(template)
            return jinja_template.render(**variables)
        
        except ImportError:
            raise ValueError("jinja2 not installed. Install with: pip install jinja2")
        except jinja2.UndefinedError as e:
            raise ValueError(f"Missing variable in template: {e}")
        except Exception as e:
            raise ValueError(f"Error formatting template: {e}")
    
    @staticmethod
    def escape_special_chars(text: str, format_type: str = "f-string") -> str:
        """
        Escape special characters in text
        
        Args:
            text: Text to escape
            format_type: Format type
            
        Returns:
            Escaped text
            
        Example:
            >>> TemplateFormatter.escape_special_chars("Price: $100")
            'Price: $100'
            >>> TemplateFormatter.escape_special_chars("Use {braces}")
            'Use {{braces}}'
        """
        if format_type == "f-string":
            # Escape curly braces
            return text.replace('{', '{{').replace('}', '}}')
        elif format_type == "jinja2":
            # Jinja2 escaping
            return text.replace('{', '\\{').replace('}', '\\}')
        return text
    
    @staticmethod
    def unescape_special_chars(text: str, format_type: str = "f-string") -> str:
        """
        Unescape special characters
        
        Args:
            text: Text to unescape
            format_type: Format type
            
        Returns:
            Unescaped text
        """
        if format_type == "f-string":
            return text.replace('{{', '{').replace('}}', '}')
        elif format_type == "jinja2":
            return text.replace('\\{', '{').replace('\\}', '}')
        return text
    
    @staticmethod
    def strip_whitespace(text: str, mode: str = "both") -> str:
        """
        Strip whitespace from text
        
        Args:
            text: Text to process
            mode: 'left', 'right', or 'both'
            
        Returns:
            Processed text
            
        Example:
            >>> TemplateFormatter.strip_whitespace("  hello  ", "both")
            'hello'
            >>> TemplateFormatter.strip_whitespace("  hello  ", "left")
            'hello  '
        """
        if mode == "left":
            return text.lstrip()
        elif mode == "right":
            return text.rstrip()
        else:
            return text.strip()
    
    @staticmethod
    def normalize_whitespace(text: str) -> str:
        """
        Normalize whitespace (multiple spaces to single space)
        
        Args:
            text: Text to normalize
            
        Returns:
            Normalized text
            
        Example:
            >>> TemplateFormatter.normalize_whitespace("hello    world")
            'hello world'
        """
        return re.sub(r'\s+', ' ', text).strip()
    
    @staticmethod
    def remove_empty_lines(text: str) -> str:
        """
        Remove empty lines from text
        
        Args:
            text: Text to process
            
        Returns:
            Text without empty lines
        """
        lines = [line for line in text.split('\n') if line.strip()]
        return '\n'.join(lines)
    
    @staticmethod
    def indent_text(text: str, spaces: int = 4) -> str:
        """
        Indent all lines in text
        
        Args:
            text: Text to indent
            spaces: Number of spaces to indent
            
        Returns:
            Indented text
            
        Example:
            >>> TemplateFormatter.indent_text("hello\\nworld", 2)
            '  hello\\n  world'
        """
        indent = ' ' * spaces
        lines = text.split('\n')
        return '\n'.join(indent + line for line in lines)
    
    @staticmethod
    def truncate_text(text: str, max_length: int, suffix: str = "...") -> str:
        """
        Truncate text to maximum length
        
        Args:
            text: Text to truncate
            max_length: Maximum length
            suffix: Suffix to add if truncated
            
        Returns:
            Truncated text
            
        Example:
            >>> TemplateFormatter.truncate_text("Hello world", 8)
            'Hello...'
        """
        if len(text) <= max_length:
            return text
        
        truncate_at = max_length - len(suffix)
        return text[:truncate_at] + suffix
    
    @staticmethod
    def clean_text(text: str) -> str:
        """
        Clean text (normalize whitespace, remove empty lines)
        
        Args:
            text: Text to clean
            
        Returns:
            Cleaned text
        """
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove empty lines
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        return '\n'.join(lines)
    
    @staticmethod
    def wrap_text(text: str, width: int = 80) -> str:
        """
        Wrap text to specified width
        
        Args:
            text: Text to wrap
            width: Maximum line width
            
        Returns:
            Wrapped text
        """
        import textwrap
        return textwrap.fill(text, width=width)
    
    @staticmethod
    def add_prefix(text: str, prefix: str, skip_empty: bool = True) -> str:
        """
        Add prefix to each line
        
        Args:
            text: Text to process
            prefix: Prefix to add
            skip_empty: Whether to skip empty lines
            
        Returns:
            Text with prefixes
            
        Example:
            >>> TemplateFormatter.add_prefix("hello\\nworld", "> ")
            '> hello\\n> world'
        """
        lines = text.split('\n')
        result = []
        
        for line in lines:
            if skip_empty and not line.strip():
                result.append(line)
            else:
                result.append(prefix + line)
        
        return '\n'.join(result)
    
    @staticmethod
    def highlight_variables(template: str, style: str = "**") -> str:
        """
        Highlight variables in template for display
        
        Args:
            template: Template string
            style: Highlight style ("**" for bold, "__" for italic, etc.)
            
        Returns:
            Template with highlighted variables
            
        Example:
            >>> TemplateFormatter.highlight_variables("Hello {name}")
            'Hello **{name}**'
        """
        pattern = r'(\{[^}]+\})'
        return re.sub(pattern, rf'{style}\1{style}', template)
    
    @staticmethod
    def replace_variables(
        template: str,
        replacements: Dict[str, str]
    ) -> str:
        """
        Replace variable names in template
        
        Args:
            template: Template string
            replacements: Dict mapping old names to new names
            
        Returns:
            Template with replaced variable names
            
        Example:
            >>> TemplateFormatter.replace_variables(
            ...     "Hello {name}",
            ...     {"name": "username"}
            ... )
            'Hello {username}'
        """
        result = template
        for old_var, new_var in replacements.items():
            result = result.replace(f'{{{old_var}}}', f'{{{new_var}}}')
        return result