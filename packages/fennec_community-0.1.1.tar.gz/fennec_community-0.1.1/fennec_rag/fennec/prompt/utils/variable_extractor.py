# -*- coding: utf-8 -*-
"""
Variable Extractor - مستخرج المتغيرات

استخراج المتغيرات من قوالب النصوص المختلفة
Extract variables from different template formats
"""

from typing import List, Dict, Any
from string import Formatter
import re
import logging

logger = logging.getLogger(__name__)


class VariableExtractor:
    """
    Extract variables from template strings
    
    مستخرج المتغيرات من قوالب النصوص
    
    Supports:
        - f-string format: {variable}
        - Jinja2 format: {{ variable }}
        - Multiple variables in one template
        - Nested attributes: {user.name}
    """
    
    def __init__(self, template_format: str = "f-string"):
        """
        Initialize variable extractor
        
        Args:
            template_format: Template format ('f-string' or 'jinja2')
        """
        self.template_format = template_format
    
    def extract(self, template: str) -> List[str]:
        """
        Extract all variables from template
        
        Args:
            template: Template string
            
        Returns:
            List of variable names
            
        Example:
            >>> extractor = VariableExtractor()
            >>> extractor.extract("Hello {name}, you are {age} years old")
            ['name', 'age']
        """
        if self.template_format == "f-string":
            return self._extract_fstring(template)
        elif self.template_format == "jinja2":
            return self._extract_jinja2(template)
        else:
            logger.warning(f"Unknown template format: {self.template_format}")
            return []
    
    def _extract_fstring(self, template: str) -> List[str]:
        """
        Extract variables from f-string format template
        
        Args:
            template: F-string template
            
        Returns:
            List of variable names
        """
        variables = []
        
        try:
            for _, field_name, _, _ in Formatter().parse(template):
                if field_name is not None and field_name:
                    # Handle nested attributes (e.g., {user.name})
                    base_var = field_name.split('.')[0].split('[')[0]
                    if base_var and base_var not in variables:
                        variables.append(base_var)
        except Exception as e:
            logger.error(f"Error extracting f-string variables: {e}")
        
        return variables
    
    def _extract_jinja2(self, template: str) -> List[str]:
        """
        Extract variables from Jinja2 template
        
        Args:
            template: Jinja2 template
            
        Returns:
            List of variable names
        """
        try:
            import jinja2
            import jinja2.meta
            
            env = jinja2.Environment()
            ast = env.parse(template)
            variables = jinja2.meta.find_undeclared_variables(ast)
            
            return sorted(list(variables))
        
        except ImportError:
            logger.error("jinja2 not installed. Install with: pip install jinja2")
            return []
        except Exception as e:
            logger.error(f"Error extracting jinja2 variables: {e}")
            return []
    
    def extract_with_positions(self, template: str) -> List[Dict[str, Any]]:
        """
        Extract variables with their positions in the template
        
        Args:
            template: Template string
            
        Returns:
            List of dicts with variable info
            
        Example:
            >>> extractor = VariableExtractor()
            >>> extractor.extract_with_positions("Hello {name}")
            [{'name': 'name', 'start': 6, 'end': 12}]
        """
        variables_info = []
        
        if self.template_format == "f-string":
            pattern = r'\{([^}]+)\}'
            for match in re.finditer(pattern, template):
                var_name = match.group(1).split('.')[0].split('[')[0]
                variables_info.append({
                    'name': var_name,
                    'start': match.start(),
                    'end': match.end(),
                    'full_match': match.group(0)
                })
        
        return variables_info
    
    def get_variable_details(self, template: str) -> List[Dict[str, Any]]:
        """
        Get detailed information about variables
        
        Args:
            template: Template string
            
        Returns:
            List of dictionaries with variable details
            
        Example:
            >>> extractor = VariableExtractor()
            >>> extractor.get_variable_details("Hello {name}")
            [{'name': 'name', 'required': True, 'type': 'any'}]
        """
        variables = self.extract(template)
        details = []
        
        for var in variables:
            detail = {
                'name': var,
                'required': True,
                'type': 'any',
                'description': f'Variable: {var}'
            }
            details.append(detail)
        
        return details
    
    def count_variables(self, template: str) -> int:
        """
        Count number of unique variables
        
        Args:
            template: Template string
            
        Returns:
            Number of unique variables
        """
        return len(self.extract(template))
    
    def has_variables(self, template: str) -> bool:
        """
        Check if template has any variables
        
        Args:
            template: Template string
            
        Returns:
            True if template has variables
        """
        return self.count_variables(template) > 0
    
    def get_variable_types(self, template: str) -> Dict[str, str]:
        """
        Analyze variable types (simple estimation)
        
        Args:
            template: Template string
            
        Returns:
            Dictionary mapping variable names to estimated types
        """
        variables = self.extract(template)
        types = {}
        
        for var in variables:
            # Simple heuristics
            var_lower = var.lower()
            if 'count' in var_lower or 'num' in var_lower or 'id' in var_lower:
                types[var] = 'int'
            elif 'price' in var_lower or 'amount' in var_lower:
                types[var] = 'float'
            elif 'is_' in var_lower or 'has_' in var_lower:
                types[var] = 'bool'
            else:
                types[var] = 'str'
        
        return types
    
    @staticmethod
    def find_unused_variables(
        template: str,
        provided_vars: Dict[str, Any],
        template_format: str = "f-string"
    ) -> List[str]:
        """
        Find variables that are provided but not used in template
        
        Args:
            template: Template string
            provided_vars: Dictionary of provided variables
            template_format: Template format
            
        Returns:
            List of unused variable names
        """
        extractor = VariableExtractor(template_format)
        required = set(extractor.extract(template))
        provided = set(provided_vars.keys())
        
        return list(provided - required)
    
    @staticmethod
    def find_missing_variables(
        template: str,
        provided_vars: Dict[str, Any],
        template_format: str = "f-string"
    ) -> List[str]:
        """
        Find variables that are required but not provided
        
        Args:
            template: Template string
            provided_vars: Dictionary of provided variables
            template_format: Template format
            
        Returns:
            List of missing variable names
        """
        extractor = VariableExtractor(template_format)
        required = set(extractor.extract(template))
        provided = set(provided_vars.keys())
        
        return list(required - provided)