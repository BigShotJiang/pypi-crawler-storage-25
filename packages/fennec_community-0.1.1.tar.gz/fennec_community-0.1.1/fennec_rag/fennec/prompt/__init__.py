"""
وحدة Prompt — إدارة القوالب والتعامل مع مزودي LLM
Prompt module — template management and LLM prompt engineering
"""

# ── Core Templates ────────────────────────────────────────────────────── #
from .core import (
    PromptTemplate,
    ChatPromptTemplate,
    FewShotPromptTemplate,
)

# ── Pre-built Templates ───────────────────────────────────────────────── #
from .templates import (
    SystemPrompts,
    TaskPrompts,
    ArabicPrompts,
)

# ── Utilities ─────────────────────────────────────────────────────────── #
from .utils import (
    VariableExtractor,
    TemplateValidator,
    TemplateFormatter,
)


__all__ = [
    # Core
    "PromptTemplate",
    "ChatPromptTemplate",
    "FewShotPromptTemplate",

    # Pre-built
    "SystemPrompts",
    "TaskPrompts",
    "ArabicPrompts",

    # Utils
    "VariableExtractor",
    "TemplateValidator",
    "TemplateFormatter",
]
