import asyncio
import os
import sys
import importlib.util
import inspect
import time
from typing import Dict, List, Any, Callable, Optional, Set
from collections import defaultdict
from pathlib import Path
import logging
from .plugin import Plugin, PluginError, PluginTimeoutError
from .base import PluginStatus, PluginPriority
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import logging
logger = logging.getLogger(__name__)


class PluginManagerError(Exception):
    """استثناء خاص بمدير الإضافات"""
    pass


class PluginManager:
    """مدير الإضافات  مع إدارة شاملة للدورة الحياة\n
        plugin manager with lifecycle management
    """
    
    def __init__(self, 
                 plugins_dir: str = "plugins", 
                 safe_mode: bool = False,
                 system_version: str = "1.0.0",
                 auto_discover: bool = True):
        """
        Args:
            plugins_dir: المجلد الذي يحتوي على الإضافات | Directory containing plugins
            safe_mode: عند تفعيله، يمكن منع تشغيل إضافات قد تسبب مشاكل | when activate it could disable plugins
            system_version: إصدار النظام للتحقق من التوافق | system version to check compatibility with
            auto_discover: اكتشاف الإضافات تلقائياً عند البدء | automatically discover plugins on startup
        """
        self.plugins: Dict[str, Plugin] = {}
        self.hooks: Dict[str, List[Callable]] = defaultdict(list)
        self.hook_priorities: Dict[str, Dict[Callable, int]] = defaultdict(dict)
        self.plugins_dir = Path(plugins_dir)
        self.safe_mode = safe_mode
        self.system_version = system_version
        
        # تتبع التبعيات
        self.dependency_graph: Dict[str, Set[str]] = defaultdict(set)
        self.reverse_dependencies: Dict[str, Set[str]] = defaultdict(set)
        
        # نظام الأذونات
        self.permissions_granted: Dict[str, Set[str]] = defaultdict(set)
        
        # التحليلات والإحصائيات
        self.analytics = PluginAnalytics()
        
        # Marketplace
        self.marketplace = PluginMarketplace()
        
        # Hot Reload
        self.file_watchers: Dict[str, float] = {}
        self._hot_reload_enabled = False
        self._hot_reload_task: Optional[asyncio.Task] = None
        
        # تتبع الحالة
        self._initialized = False
        self._shutting_down = False
        
        logger.info(f"🔌 plugin is running (system version: {system_version})")
        
        # اكتشاف تلقائي
        if auto_discover:
            asyncio.create_task(self._auto_discover_on_init())
    
    async def _auto_discover_on_init(self):
        """اكتشاف الإضافات تلقائياً عند التهيئة"""
        try:
            discovered = await self.discover_plugins()
            logger.info(f"✅ number of discovered plugins: {len(discovered)} ")
        except Exception as e:
            logger.error(f"❌ error during auto-discovery: {e}")
    
    # ══════════════════════════════════════════════════════════════════════
    # 📦 تسجيل وإدارة الإضافات
    # ══════════════════════════════════════════════════════════════════════
    
    async def register_plugin(self, plugin: Plugin) -> bool:
        """
        تسجيل إضافة مع فحص شامل للتبعيات والأذونات والتوافق \n register plugin with checking dependencies, permissions, and compatibility
        
        Args:
            plugin: الإضافة المراد تسجيلها
            
        Returns:
            True إذا نجح التسجيل، False خلاف ذلك
        """
        try:
            # التحقق من التسجيل المسبق
            if plugin.name in self.plugins:
                logger.warning(f"⚠️ plugin {plugin.name} is already registered")
                return False
            
            # فحص التوافق مع إصدار النظام
            if not plugin.metadata.is_compatible_with(self.system_version):
                logger.error(
                    f"❌ plugin {plugin.name} is not compatible with system version: {self.system_version}"
                )
                return False
            
            # فحص التبعيات
            if not await self._check_dependencies(plugin):
                logger.error(f"❌ erro in dependencies for plugin {plugin.name}")
                return False
            
            # فحص الأذونات
            if not self._check_permissions(plugin):
                logger.error(f"❌ plugin {plugin.name} has missing permissions")
                return False
            
            # تهيئة الإضافة
            plugin.status = PluginStatus.INITIALIZING
            
            try:
                if await plugin.initialize():
                    self.plugins[plugin.name] = plugin
                    plugin.status = PluginStatus.ENABLED
                    plugin.enabled = True
                    plugin.initialized_at = time.time()
                    
                    # تحديث التبعيات
                    self._update_dependency_graph(plugin)
                    
                    # تسجيل في Analytics
                    self.analytics.record_plugin_registration(plugin.name)
                    
                    # تشغيل hooks للتسجيل
                    await self.trigger_hook('plugin_registered', plugin=plugin)
                    
                    logger.info(
                        f"✅ plugin {plugin.name} is registered with version: {plugin.metadata.version}"
                    )
                    return True
                else:
                    plugin.status = PluginStatus.ERROR
                    plugin.error_message = "faild in initializing plugin"
                    logger.error(f"❌ error in initializing plugin {plugin.name}")
                    return False
                    
            except Exception as e:
                plugin.status = PluginStatus.ERROR
                plugin.error_message = str(e)
                logger.error(f"❌ error in initializing plugin {plugin.name}: {e}")
                return False
                
        except Exception as e:
            logger.error(f"❌ error in registering plugin {plugin.name}: {e}")
            return False
    
    async def unregister_plugin(self, name: str, force: bool = False) -> bool:
        """
        إلغاء تسجيل إضافة مع فحص التبعيات العكسية \n unregister plugin with checking reverse dependencies
        
        Args:
            name: اسم الإضافة
            force: إجبار الإلغاء حتى لو كانت هناك تبعيات
            
        Returns:
            True إذا نجح الإلغاء
        """
        if name not in self.plugins:
            logger.warning(f"⚠️ plugin {name} not found")
            return False
        
        # فحص الإضافات التي تعتمد عليها
        if not force and name in self.reverse_dependencies:
            dependents = self.reverse_dependencies[name]
            if dependents:
                dependents_str = ", ".join(dependents)
                logger.error(
                    f"❌ no way to unregister plugin {name} because there are another plugins that depend on it"
                    f"{dependents_str}. using force True to unregister anyway"
                )
                return False
        
        plugin = self.plugins[name]
        
        try:
            # تشغيل hook قبل الإلغاء
            await self.trigger_hook('plugin_unregistering', plugin=plugin)
            
            # تنظيف الإضافة
            await plugin.cleanup()
            
            # إزالة من القاموس
            del self.plugins[name]
            
            # تنظيف التبعيات
            if name in self.dependency_graph:
                del self.dependency_graph[name]
            
            # إزالة من التبعيات العكسية
            for deps in self.reverse_dependencies.values():
                deps.discard(name)
            if name in self.reverse_dependencies:
                del self.reverse_dependencies[name]
            
            # تنظيف الأذونات
            if name in self.permissions_granted:
                del self.permissions_granted[name]
            
            # تشغيل hook بعد الإلغاء
            await self.trigger_hook('plugin_unregistered', plugin_name=name)
            
            logger.info(f"🗑️ plugin: {name} unregistered successfuly")
            return True
            
        except Exception as e:
            logger.error(f"❌ error in unregistering plugin {name}: {e}")
            return False
    
    async def enable_plugin(self, name: str) -> bool:
        """تفعيل إضافة معطلة\n
            activation for disaled plugin
        """
        if name not in self.plugins:
            return False
        
        plugin = self.plugins[name]
        if plugin.enabled:
            logger.info(f"ℹ️ plugin: {name} already enabled")
            return True
        
        # التحقق من التبعيات
        if not await self._check_dependencies(plugin):
            logger.error(f"❌ no way to unregisted plugin {name} because there are another plugins that depend on it")
            return False
        
        plugin.enabled = True
        plugin.status = PluginStatus.ENABLED
        await self.trigger_hook('plugin_enabled', plugin=plugin)
        logger.info(f"✅ plugin {name} is enabled successfully")
        return True
    
    async def disable_plugin(self, name: str) -> bool:
        """تعطيل إضافة\n
            disable plugin for activation
        """
        if name not in self.plugins:
            return False
        
        plugin = self.plugins[name]
        if not plugin.enabled:
            logger.info(f"ℹ️ plugin: {name} already disabled")
            return True
        
        plugin.enabled = False
        plugin.status = PluginStatus.DISABLED
        await self.trigger_hook('plugin_disabled', plugin=plugin)
        logger.info(f"🔒 disabled plugin is successfully: {name}")
        return True
    
    # ══════════════════════════════════════════════════════════════════════
    # 🎣 نظام Hooks
    # ══════════════════════════════════════════════════════════════════════
    
    def add_hook(self, 
                 event: str, 
                 callback: Callable, 
                 priority: int = PluginPriority.NORMAL.value):
        """
        إضافة hook مع أولوية\n
        hook with priority level 
        
        Args:
            event: اسم الحدث
            callback: الدالة المراد تنفيذها
            priority: الأولوية (أعلى قيمة = أولوية أعلى)
        """
        if not callable(callback):
            raise ValueError("must be a callable object")
        
        self.hooks[event].append(callback)
        self.hook_priorities[event][callback] = priority
        
        # ترتيب حسب الأولوية (من الأعلى للأقل)
        self.hooks[event].sort(
            key=lambda cb: self.hook_priorities[event].get(cb, 50),
            reverse=True
        )
        
        logger.debug(f"🎣 hook is added: '{event}' wiht priority: {priority}")
    
    def remove_hook(self, event: str, callback: Callable) -> bool:
        """إزالة hook\n
            remove hook
        """
        if event in self.hooks and callback in self.hooks[event]:
            self.hooks[event].remove(callback)
            if callback in self.hook_priorities[event]:
                del self.hook_priorities[event][callback]
            logger.debug(f"🗑️ hook is removed: '{event}'")
            return True
        return False
    
    async def trigger_hook(self, event: str, **kwargs) -> List[Any]:
        """
        تفعيل hooks مع جمع النتائج وإدارة الأخطاء \n
        trigger hooks with collecting results and handling errors
        
        Args:
            event: اسم الحدث
            **kwargs: معاملات الحدث
            
        Returns:
            قائمة بنتائج تنفيذ كل hook
        """
        results = []
        
        if event not in self.hooks:
            return results
        
        start_time = time.time()
        errors = []
        
        for callback in self.hooks[event]:
            try:
                if inspect.iscoroutinefunction(callback):
                    result = await callback(**kwargs)
                else:
                    result = callback(**kwargs)
                results.append(result)
                
            except Exception as e:
                error_msg = f"erro in hook '{event}': {e}"
                logger.error(f"❌ {error_msg}")
                errors.append(error_msg)
                self.analytics.record_hook_error(event, str(e))
        
        # تسجيل في Analytics
        execution_time = time.time() - start_time
        self.analytics.record_hook_execution(event, execution_time, len(results))
        
        if errors:
            logger.warning(f"⚠️ {len(errors)} errors in hook '{event}'")
        
        return results
    # ══════════════════════════════════════════════════════════════════════
    # ⚡ تنفيذ الإضافات
    # ══════════════════════════════════════════════════════════════════════
    
    async def execute_plugin(self, name: str, use_retry: bool = False, **kwargs) -> Any:
        """
        تنفيذ إضافة مع قياس الأداء\n
        execute plugin with performance measurement
        
        Args:
            name: اسم الإضافة
            use_retry: استخدام إعادة المحاولة عند الفشل
            **kwargs: معاملات التنفيذ
        """
        if name not in self.plugins:
            raise PluginManagerError(f"plugin is not registered: {name}")
        
        plugin = self.plugins[name]
        
        if not plugin.enabled:
            logger.warning(f"⚠️ plugin is not enabled: {name}")
            return None
        
        try:
            # تنفيذ مع أو بدون retry
            if use_retry:
                result = await plugin.retry_execute(**kwargs)
            else:
                result = await plugin.safe_execute(**kwargs)
            
            # تسجيل في Analytics
            self.analytics.record_plugin_execution(
                name, 
                plugin.last_execution_time, 
                True
            )
            
            # تشغيل hook بعد التنفيذ
            await self.trigger_hook('plugin_executed', plugin=plugin, result=result)
            
            return result
            
        except (PluginError, PluginTimeoutError) as e:
            self.analytics.record_plugin_execution(
                name, 
                plugin.last_execution_time, 
                False, 
                str(e)
            )
            logger.error(f"❌ erro in executing plugin {name}: {e}")
            raise
    
    async def execute_batch(self, 
                           plugin_names: List[str], 
                           **kwargs) -> Dict[str, Any]:
        """
        تنفيذ عدة إضافات بشكل متوازي\n
        execute batch of plugins in parallel
        
        Returns:
            قاموس {اسم الإضافة: النتيجة}
        """
        tasks = {
            name: self.execute_plugin(name, **kwargs) 
            for name in plugin_names
        }
        
        results = {}
        for name, task in tasks.items():
            try:
                results[name] = await task
            except Exception as e:
                results[name] = {'error': str(e)}
                logger.error(f"❌ error in executing plugin {name}: {e}")
        
        return results
    
    # ══════════════════════════════════════════════════════════════════════
    # 🔍 Auto-Discovery - الاكتشاف التلقائي
    # ══════════════════════════════════════════════════════════════════════
    
    async def discover_plugins(self) -> List[str]:
        """اكتشاف الإضافات تلقائياً من المجلد\n
            discover plugins automatically from the plugins directory
        """
        discovered = []
        
        if not self.plugins_dir.exists():
            self.plugins_dir.mkdir(parents=True)
            logger.info(f"📁 folder is created: {self.plugins_dir}")
            return discovered
        
        for plugin_path in self.plugins_dir.glob("*.py"):
            if plugin_path.name.startswith("_"):
                continue
            
            try:
                plugin_name = plugin_path.stem
                
                # تحميل الوحدة
                spec = importlib.util.spec_from_file_location(plugin_name, plugin_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[plugin_name] = module
                    spec.loader.exec_module(module)
                    
                    # البحث عن فئات Plugin
                    for name, obj in inspect.getmembers(module):
                        if (inspect.isclass(obj) and 
                            issubclass(obj, Plugin) and 
                            obj != Plugin):
                            
                            try:
                                # إنشاء instance
                                plugin_instance = obj()
                                
                                # تسجيل
                                if await self.register_plugin(plugin_instance):
                                    discovered.append(plugin_name)
                                    logger.info(f"🔍 discoverd plugin: {plugin_name}")
                            except Exception as e:
                                logger.error(f"❌ error in discovering plugin {name}: {e}")
                            
            except Exception as e:
                logger.error(f"❌ error in discovering plugin {plugin_path}: {e}")
        
        return discovered
    
    # ══════════════════════════════════════════════════════════════════════
    # 🔄 Hot Reload - إعادة التحميل الساخن
    # ══════════════════════════════════════════════════════════════════════
    
    async def enable_hot_reload(self, check_interval: float = 5.0):
        """تفعيل إعادة التحميل التلقائي\n
            enable hot reload automatically
        """
        if self._hot_reload_enabled:
            logger.warning("⚠️ Hot Reload is already enabled")
            return
        
        self._hot_reload_enabled = True
        self._hot_reload_task = asyncio.create_task(
            self._hot_reload_worker(check_interval)
        )
        logger.info(f"🔥 Hot Reload activated( check every {check_interval}s)")
    
    async def disable_hot_reload(self):
        """تعطيل إعادة التحميل التلقائي\n
            disable hot reload automatically
        """ 
        if not self._hot_reload_enabled:
            return
        
        self._hot_reload_enabled = False
        if self._hot_reload_task:
            self._hot_reload_task.cancel()
            try:
                await self._hot_reload_task
            except asyncio.CancelledError:
                pass
        logger.info("🔴 Hot Reload disabled")
    
    async def _hot_reload_worker(self, interval: float):
        """عامل فحص التغييرات
            hot reload worker to check for changes
        """
        while self._hot_reload_enabled and not self._shutting_down:
            try:
                await asyncio.sleep(interval)
                
                for plugin_name, plugin in list(self.plugins.items()):
                    plugin_file = self.plugins_dir / f"{plugin_name}.py"
                    
                    if not plugin_file.exists():
                        continue
                    
                    # فحص التعديل
                    current_mtime = plugin_file.stat().st_mtime
                    last_mtime = self.file_watchers.get(plugin_name, 0)
                    
                    if current_mtime > last_mtime:
                        logger.info(f"🔄 there a chang in plugin: {plugin_name}")
                        
                        # إعادة التحميل
                        if await self.reload_plugin(plugin_name):
                            self.file_watchers[plugin_name] = current_mtime
                            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Error in Hot Reload worker: {e}")
    
    async def reload_plugin(self, name: str) -> bool:
        """إعادة تحميل إضافة
            reload plugin
        """
        if name not in self.plugins:
            return False
        
        try:
            # حفظ الإعدادات
            old_plugin = self.plugins[name]
            old_config = old_plugin.config
            
            # إلغاء التسجيل
            await self.unregister_plugin(name)
            
            # إعادة الاكتشاف والتسجيل
            await self.discover_plugins()
            
            # استعادة الإعدادات
            if name in self.plugins:
                self.plugins[name].config = old_config
            
            logger.info(f"♻️ reloded plugin: {name}")
            return True
            
        except Exception as e:
            logger.error(f"❌ error in reloading plugin {name}: {e}")
            return False
    
    # ══════════════════════════════════════════════════════════════════════
    # 🔗 إدارة التبعيات
    # ══════════════════════════════════════════════════════════════════════
    
    async def _check_dependencies(self, plugin: Plugin) -> bool:
        """فحص وحل التبعيات"""
        missing_deps = []
        
        for dep in plugin.metadata.dependencies:
            if dep not in self.plugins:
                logger.warning(f"⚠️ there is no plugin for dependency: {dep} لـ {plugin.name}")
                missing_deps.append(dep)
        
        if not missing_deps:
            return True
        
        # محاولة التثبيت من Marketplace
        for dep in missing_deps:
            if await self.marketplace.install_plugin(dep, self):
                logger.info(f"✅ install plugin success: {dep}")
            else:
                logger.error(f"❌ error in install plugin: {dep}")
                return False
        
        return True
    
    def _update_dependency_graph(self, plugin: Plugin):
        """تحديث رسم التبعيات"""
        for dep in plugin.metadata.dependencies:
            self.dependency_graph[plugin.name].add(dep)
            self.reverse_dependencies[dep].add(plugin.name)
    
    def get_dependency_tree(self, plugin_name: str, max_depth: int = 10) -> Dict:
        """الحصول على شجرة التبعيات\n
           get dependency tree
        """
        if plugin_name not in self.plugins:
            return {}
        
        def build_tree(name: str, visited: Set[str] = None, depth: int = 0) -> Dict:
            if visited is None:
                visited = set()
            
            if name in visited:
                return {'name': name, 'circular': True}
            
            if depth >= max_depth:
                return {'name': name, 'max_depth_reached': True}
            
            visited.add(name)
            deps = self.dependency_graph.get(name, set())
            
            return {
                'name': name,
                'dependencies': [
                    build_tree(dep, visited.copy(), depth + 1) 
                    for dep in deps
                ]
            }
        
        return build_tree(plugin_name)
    
    def get_load_order(self) -> List[str]:
        """الحصول على ترتيب التحميل الصحيح (topological sort)
          get correct load order (topological sort)
        """
        # حساب عدد التبعيات لكل إضافة
        in_degree = {name: 0 for name in self.plugins}
        
        for deps in self.dependency_graph.values():
            for dep in deps:
                if dep in in_degree:
                    in_degree[dep] += 1
        
        # البدء بالإضافات بدون تبعيات
        queue = [name for name, degree in in_degree.items() if degree == 0]
        result = []
        
        while queue:
            current = queue.pop(0)
            result.append(current)
            
            # تقليل عداد التبعيات للإضافات المعتمدة
            for dependent in self.reverse_dependencies.get(current, set()):
                if dependent in in_degree:
                    in_degree[dependent] -= 1
                    if in_degree[dependent] == 0:
                        queue.append(dependent)
        
        return result
    
    # ══════════════════════════════════════════════════════════════════════
    # 🔐 نظام الأذونات
    # ══════════════════════════════════════════════════════════════════════
    
    def grant_permission(self, plugin_name: str, permission: str):
        """منح إذن لإضافة\n
           allow permission to add
        """
        self.permissions_granted[plugin_name].add(permission)
        logger.info(f"🔓 allwo done'{permission}' to {plugin_name}")
    
    def revoke_permission(self, plugin_name: str, permission: str):
        """سحب إذن من إضافة\n
           revoke permission from add
        """
        if permission in self.permissions_granted[plugin_name]:
            self.permissions_granted[plugin_name].remove(permission)
            logger.info(f"🔒 revoke done'{permission}' from  {plugin_name}")
    
    def grant_all_permissions(self, plugin_name: str):
        """منح جميع الأذونات المطلوبة\n
           allow all required permissions
        """
        if plugin_name not in self.plugins:
            return
        
        plugin = self.plugins[plugin_name]
        for perm in plugin.metadata.permissions:
            self.grant_permission(plugin_name, perm)
    
    def _check_permissions(self, plugin: Plugin) -> bool:
        """فحص أذونات الإضافة"""
        if not plugin.metadata.permissions:
            return True
        
        granted = self.permissions_granted.get(plugin.name, set())
        required = set(plugin.metadata.permissions)
        missing = required - granted
        
        if missing:
            logger.warning(
                f"⚠️ there are missing permissions for plugin: {plugin.name}: {', '.join(missing)}"
            )
            return False
        
        return True
    
    # ══════════════════════════════════════════════════════════════════════
    # 📊 معلومات وإحصائيات
    # ══════════════════════════════════════════════════════════════════════
    
    def list_plugins(self, 
                     status_filter: Optional[PluginStatus] = None,
                     include_stats: bool = False) -> List[Dict[str, Any]]:
        """قائمة الإضافات مع خيار التصفية\n
           list plugins with filtering option
        """
        plugins_list = []
        
        for name, plugin in self.plugins.items():
            if status_filter and plugin.status != status_filter:
                continue
            
            info = {
                'name': name,
                'version': plugin.metadata.version,
                'author': plugin.metadata.author,
                'enabled': plugin.enabled,
                'status': plugin.status.value,
                'dependencies': plugin.metadata.dependencies
            }
            
            if include_stats:
                info['stats'] = plugin.get_stats()
                info['health'] = plugin.get_health_status()
            
            plugins_list.append(info)
        
        return plugins_list
    
    def get_plugin_info(self, name: str) -> Dict[str, Any]:
        """معلومات تفصيلية عن إضافة
           plugin information with details
        """
        if name not in self.plugins:
            return {}
        
        plugin = self.plugins[name]
        
        return {
            'name': name,
            'metadata': plugin.metadata.to_dict(),
            'status': plugin.status.value,
            'enabled': plugin.enabled,
            'dependencies': plugin.metadata.dependencies,
            'dependents': list(self.reverse_dependencies.get(name, set())),
            'permissions': {
                'required': plugin.metadata.permissions,
                'granted': list(self.permissions_granted.get(name, set()))
            },
            'stats': plugin.get_stats(),
            'health': plugin.get_health_status(),
            'error': plugin.error_message
        }
    
    def get_system_stats(self) -> Dict[str, Any]:
        """إحصائيات النظام الشاملة
           system statistics with full details
        """
        plugins_by_status = defaultdict(int)
        for plugin in self.plugins.values():
            plugins_by_status[plugin.status.value] += 1
        
        return {
            'total_plugins': len(self.plugins),
            'enabled_plugins': sum(1 for p in self.plugins.values() if p.enabled),
            'disabled_plugins': sum(1 for p in self.plugins.values() if not p.enabled),
            'plugins_by_status': dict(plugins_by_status),
            'total_hooks': sum(len(hooks) for hooks in self.hooks.values()),
            'hot_reload_enabled': self._hot_reload_enabled,
            'safe_mode': self.safe_mode,
            'system_version': self.system_version,
            'analytics': self.analytics.get_summary()
        }
    
    async def shutdown(self):
        """إيقاف مدير الإضافات بشكل آمن
           shutdown plugin manager in a safe way
        """
        logger.info("🛑  Shutdown PluginManager...")
        self._shutting_down = True
        
        # تعطيل Hot Reload
        await self.disable_hot_reload()
        
        # تنظيف جميع الإضافات
        for name in list(self.plugins.keys()):
            try:
                await self.unregister_plugin(name, force=True)
            except Exception as e:
                logger.error(f"❌ error in unregistering plugin {name}: {e}")
        
        logger.info("✅ Shutdown PluginManager successfully")


# ============================================================================
# 📊 PLUGIN ANALYTICS
# ============================================================================

class PluginAnalytics:
    """نظام تحليلات للإضافات
        plugin analytics system
    """
    
    def __init__(self):
        self.plugin_executions: Dict[str, List[Dict]] = defaultdict(list)
        self.hook_executions: Dict[str, List[Dict]] = defaultdict(list)
        self.errors: List[Dict] = []
        self.registrations: Dict[str, float] = {}
    
    def record_plugin_registration(self, plugin_name: str):
        """تسجيل تسجيل إضافة"""
        self.registrations[plugin_name] = time.time()
    
    def record_plugin_execution(self, plugin_name: str, execution_time: float, 
                               success: bool, error: str = None):
        """تسجيل تنفيذ إضافة"""
        self.plugin_executions[plugin_name].append({
            'timestamp': time.time(),
            'execution_time': execution_time,
            'success': success,
            'error': error
        })
    
    def record_hook_execution(self, event: str, execution_time: float, 
                             results_count: int):
        """تسجيل تنفيذ hook"""
        self.hook_executions[event].append({
            'timestamp': time.time(),
            'execution_time': execution_time,
            'results_count': results_count
        })
    
    def record_hook_error(self, event: str, error: str):
        """تسجيل خطأ hook"""
        self.errors.append({
            'timestamp': time.time(),
            'type': 'hook',
            'event': event,
            'error': error
        })
    
    def get_summary(self) -> Dict[str, Any]:
        """ملخص التحليلات"""
        total_plugin_execs = sum(
            len(execs) for execs in self.plugin_executions.values()
        )
        total_hook_execs = sum(
            len(execs) for execs in self.hook_executions.values()
        )
        
        return {
            'total_plugins_registered': len(self.registrations),
            'total_plugin_executions': total_plugin_execs,
            'total_hook_executions': total_hook_execs,
            'total_errors': len(self.errors),
            'error_rate': (len(self.errors) / total_plugin_execs * 100 
                          if total_plugin_execs > 0 else 0)
        }


# ============================================================================
# 🛒 PLUGIN MARKETPLACE
# ============================================================================

class PluginMarketplace:
    """سوق الإضافات
      plugin marketplace
    """
    
    def __init__(self, registry_url: str = "https://plugins.example.com/registry"):
        self.registry_url = registry_url
        self.cache: Dict[str, Dict] = {}
    
    async def search_plugins(self, query: str) -> List[Dict]:
        """البحث عن إضافات في السوق\n
           search plugins in marketplace
        """
        # TODO: تطبيق بحث حقيقي
        logger.info(f"🔍  serching plugins with query: {query}")
        return []
    
    async def install_plugin(self, plugin_name: str, manager: 'PluginManager') -> bool:
        """تثبيت إضافة من السوق\n
           install plugin from marketplace
        """
        # TODO: تطبيق تحميل وتثبيت حقيقي
        logger.info(f"🛒 installing plugin:{plugin_name} ")
        return False
    
    async def update_plugin(self, plugin_name: str) -> bool:
        """تحديث إضافة من السوق\n
           update plugin from marketplace
        """
        # TODO: تطبيق تحديث
        logger.info(f"🔄 update plugin:{plugin_name}")
        return False