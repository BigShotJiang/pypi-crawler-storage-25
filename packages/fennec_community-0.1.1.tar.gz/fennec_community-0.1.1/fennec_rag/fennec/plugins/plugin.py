from abc import ABC, abstractmethod
from typing import Any, Optional, Dict, List
from datetime import datetime
from .base import PluginMetadata, PluginStatus, PluginConfig
import asyncio


class PluginError(Exception):
    """استثناء مخصص لأخطاء الإضافات 
       specific exception for plugin errors
    """
    pass


class PluginTimeoutError(PluginError):
    """استثناء لتجاوز وقت التنفيذ
       exception for exceeding execution time
    """
    pass


class Plugin(ABC):
    """الإضافة الأساسية المحسّنة\n
       basic plugin class
    """
    
    def __init__(self, metadata: PluginMetadata, config: Optional[PluginConfig] = None):
        # التحقق من صحة البيانات
        if not isinstance(metadata, PluginMetadata):
            raise TypeError("metadata must be an instance of PluginMetadata")
        
        
        self.metadata = metadata
        self.name = metadata.name
        self.config = config or PluginConfig()
        self.enabled = self.config.enabled
        self.status = PluginStatus.DISABLED
        self.error_message: Optional[str] = None
        
        # إحصائيات التنفيذ
        self.execution_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.total_execution_time = 0.0
        self.last_execution_time = 0.0
        self.min_execution_time = float('inf')
        self.max_execution_time = 0.0
        
        # تواريخ مهمة
        self.initialized_at: Optional[datetime] = None
        self.last_executed_at: Optional[datetime] = None
        self.last_error_at: Optional[datetime] = None
        
        # تتبع الأخطاء
        self.error_history: List[Dict[str, Any]] = []
        self.max_error_history = 50  # الاحتفاظ بآخر 50 خطأ
        
        # قفل للتنفيذ المتزامن
        self._execution_lock = asyncio.Lock()
    
    @abstractmethod
    async def initialize(self) -> bool:
        """
        تهيئة الإضافة
        يجب أن يُنفذ في الفئات الفرعية

        intialize plugin 
        """
        pass
    
    @abstractmethod
    async def execute(self, **kwargs) -> Any:
        """
        تنفيذ الإضافة
        يجب أن يُنفذ في الفئات الفرعية

        execute plugin 
        """
        pass
    
    @abstractmethod
    async def cleanup(self):
        """
        تنظيف موارد الإضافة
        يجب أن يُنفذ في الفئات الفرعية

        cleanup plugin 
        """
        pass
    
    async def safe_execute(self, **kwargs) -> Any:
        """
        تنفيذ آمن مع معالجة الأخطاء والوقت المحدد

        safe execution with error handling and timeout management 
        """
        if not self.enabled:
            raise PluginError(f"plugin disabled:{self.name} ")
        
        if self.status == PluginStatus.ERROR:
            raise PluginError(f"plugin error:{self.name} error message:  {self.error_message}")
        
        # منع التنفيذ المتزامن
        async with self._execution_lock:
            start_time = datetime.now()
            
            try:
                # تنفيذ مع timeout
                result = await asyncio.wait_for(
                    self.execute(**kwargs),
                    timeout=self.config.timeout
                )
                
                # تحديث الإحصائيات
                self._update_success_stats(start_time)
                return result
                
            except asyncio.TimeoutError:
                self._handle_error(start_time, f"timeout after ({self.config.timeout}s)")
                raise PluginTimeoutError(f" time exeeded for execution: {self.name}")
            
            except Exception as e:
                self._handle_error(start_time, str(e))
                raise PluginError(f"error in execution: {self.name}: {e}") from e
    
    async def retry_execute(self, **kwargs) -> Any:
        """
        تنفيذ مع إعادة المحاولة عند الفشل\n
        execute with retry on failure
        """
        last_exception = None
        
        for attempt in range(self.config.max_retries + 1):
            try:
                return await self.safe_execute(**kwargs)
            except PluginError as e:
                last_exception = e
                if attempt < self.config.max_retries:
                    # انتظار قبل إعادة المحاولة (exponential backoff)
                    await asyncio.sleep(2 ** attempt)
                    continue
                break
        
        raise last_exception if last_exception else PluginError("فشل التنفيذ")
    
    def _update_success_stats(self, start_time: datetime):
        """تحديث إحصائيات التنفيذ الناجح
        
        update success execution stats 
        """
        execution_time = (datetime.now() - start_time).total_seconds()
        
        self.execution_count += 1
        self.success_count += 1
        self.total_execution_time += execution_time
        self.last_execution_time = execution_time
        self.last_executed_at = datetime.now()
        
        # تحديث أقل وأكبر وقت تنفيذ
        self.min_execution_time = min(self.min_execution_time, execution_time)
        self.max_execution_time = max(self.max_execution_time, execution_time)
    
    def _handle_error(self, start_time: datetime, error_msg: str):
        """معالجة الأخطاء وتسجيلها"""
        execution_time = (datetime.now() - start_time).total_seconds()
        
        self.execution_count += 1
        self.failure_count += 1
        self.total_execution_time += execution_time
        self.last_execution_time = execution_time
        self.last_error_at = datetime.now()
        self.error_message = error_msg
        
        # إضافة للسجل
        error_record = {
            'timestamp': datetime.now(),
            'message': error_msg,
            'execution_time': execution_time
        }
        self.error_history.append(error_record)
        
        # الاحتفاظ بعدد محدود من الأخطاء
        if len(self.error_history) > self.max_error_history:
            self.error_history.pop(0)
        
        # تحديث الحالة
        if self.failure_count > 10:  # إذا تكررت الأخطاء كثيراً
            self.status = PluginStatus.ERROR
    
    def reset_stats(self):
        """إعادة تعيين الإحصائيات\n
           reset execution stats
        """
        self.execution_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.total_execution_time = 0.0
        self.last_execution_time = 0.0
        self.min_execution_time = float('inf')
        self.max_execution_time = 0.0
        self.error_history.clear()
    def get_stats(self) -> Dict[str, Any]:
        """إحصائيات شاملة للإضافة
        
        stats for the plugin 
        """
        from datetime import datetime

        def _format_time(ts):
            if ts is None:
                return None
            if isinstance(ts, float):
                return datetime.fromtimestamp(ts).isoformat()
            return ts.isoformat()

        avg_time = (self.total_execution_time / self.execution_count 
                    if self.execution_count > 0 else 0)
        success_rate = (self.success_count / self.execution_count * 100 
                        if self.execution_count > 0 else 0)

        return {
            'name': self.name,
            'version': self.metadata.version,
            'status': self.status.value,
            'enabled': self.enabled,
            'execution_stats': {
                'total_executions': self.execution_count,
                'successful': self.success_count,
                'failed': self.failure_count,
                'success_rate': f"{success_rate:.2f}%"
            },
            'timing_stats': {
                'total_time': f"{self.total_execution_time:.3f}s",
                'average_time': f"{avg_time:.3f}s",
                'min_time': f"{self.min_execution_time:.3f}s" if self.min_execution_time != float('inf') else "N/A",
                'max_time': f"{self.max_execution_time:.3f}s",
                'last_time': f"{self.last_execution_time:.3f}s"
            },
            'timestamps': {
                'initialized_at': _format_time(self.initialized_at),
                'last_executed_at': _format_time(self.last_executed_at),
                'last_error_at': _format_time(self.last_error_at)
            },
            'current_error': self.error_message,
            'recent_errors': len(self.error_history)
        }
    def get_health_status(self) -> Dict[str, Any]:
        """حالة صحة الإضافة\n
            health status for the plugin
        """
        if self.execution_count == 0:
            health = "not executed"
            score = 0
        else:
            success_rate = self.success_count / self.execution_count
            if success_rate >= 0.95:
                health = "excellent"
                score = 100
            elif success_rate >= 0.80:
                health = "good"
                score = 80
            elif success_rate >= 0.60:
                health = "medium"
                score = 60
            else:
                health = "weak"
                score = 40
        
        return {
            'health': health,
            'score': score,
            'status': self.status.value,
            'enabled': self.enabled,
            'has_errors': bool(self.error_message),
            'error_count': self.failure_count
        }
    
    def __repr__(self) -> str:
        return (f"Plugin(name='{self.name}', version='{self.metadata.version}', "
                f"status={self.status.value}, enabled={self.enabled})")