from enum import Enum
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime


class PluginStatus(Enum):
    """حالات الإضافة\n
       plugin status
    """
    DISABLED = "disabled"
    ENABLED = "enabled"
    LOADING = "loading"
    ERROR = "error"
    UPDATING = "updating"
    DEPRECATED = "deprecated"
    INITIALIZING = "initializing"  # إضافة حالة جديدة


class PluginPriority(Enum):
    """أولوية تنفيذ الإضافات - كلما زادت القيمة زادت الأولوية\n
       plugin priority 
    """
    CRITICAL = 1000
    HIGH = 100
    NORMAL = 50
    LOW = 10
    BACKGROUND = 1


class PermissionType(Enum):
    """أنواع الأذونات المتاحة\n
        available permission types
    """
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    NETWORK_ACCESS = "network_access"
    SYSTEM_CALL = "system_call"
    DATABASE_ACCESS = "database_access"
    USER_DATA_ACCESS = "user_data_access"


@dataclass
class PluginMetadata:
    """بيانات الإضافة الوصفية\n
        metadata for the plugin
    """
    name: str
    version: str
    author: str
    description: str
    dependencies: List[str] = field(default_factory=list)
    required_hooks: List[str] = field(default_factory=list)
    permissions: List[str] = field(default_factory=list)
    min_system_version: str = "1.0.0"
    max_system_version: str = "999.0.0"
    tags: List[str] = field(default_factory=list)
    homepage: str = ""
    license: str = "MIT"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    def __post_init__(self):
        """التحقق من صحة البيانات بعد الإنشاء"""
        if not self.name or not self.name.strip():
            raise ValueError("plugin name is required")
        
        if not self._is_valid_version(self.version):
            raise ValueError(f" plugin version '{self.version}' is invalid")
        
        if not self.description or not self.description.strip():
            raise ValueError("plugin description: {self.version}")
        
        if not self.author or not self.author.strip():
            raise ValueError("author name is required")
        
        # تعيين التواريخ إذا لم تكن موجودة
        if not self.created_at:
            self.created_at = datetime.now()
        if not self.updated_at:
            self.updated_at = datetime.now()
    
    @staticmethod
    def _is_valid_version(version: str) -> bool:
        """التحقق من صحة صيغة الإصدار (semantic versioning)"""
        try:
            parts = version.split('.')
            if len(parts) != 3:
                return False
            for part in parts:
                int(part)  # التأكد أن كل جزء رقم
            return True
        except (ValueError, AttributeError):
            return False
    
    def is_compatible_with(self, system_version: str) -> bool:
        """التحقق من توافق الإضافة مع إصدار النظام"""
        return (self._compare_versions(system_version, self.min_system_version) >= 0 and
                self._compare_versions(system_version, self.max_system_version) <= 0)
    
    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """مقارنة إصدارين - يرجع: -1 إذا v1 < v2، 0 إذا متساوية، 1 إذا v1 > v2"""
        parts1 = [int(x) for x in v1.split('.')]
        parts2 = [int(x) for x in v2.split('.')]
        
        for p1, p2 in zip(parts1, parts2):
            if p1 < p2:
                return -1
            elif p1 > p2:
                return 1
        return 0
    
    def to_dict(self) -> Dict[str, Any]:
        """تحويل إلى قاموس للتخزين أو النقل"""
        return {
            'name': self.name,
            'version': self.version,
            'author': self.author,
            'description': self.description,
            'dependencies': self.dependencies,
            'required_hooks': self.required_hooks,
            'permissions': self.permissions,
            'min_system_version': self.min_system_version,
            'max_system_version': self.max_system_version,
            'tags': self.tags,
            'homepage': self.homepage,
            'license': self.license,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PluginMetadata':
        """إنشاء من قاموس"""
        # تحويل التواريخ من نص إلى datetime
        if data.get('created_at'):
            data['created_at'] = datetime.fromisoformat(data['created_at'])
        if data.get('updated_at'):
            data['updated_at'] = datetime.fromisoformat(data['updated_at'])
        
        return cls(**data)


@dataclass
class PluginConfig:
    """إعدادات الإضافة القابلة للتخصيص\n
        configuration for the plugin
    
    """
    enabled: bool = True
    auto_update: bool = False
    timeout: float = 30.0  # بالثواني
    max_retries: int = 3
    custom_settings: Dict[str, Any] = field(default_factory=dict)
    
    def validate(self) -> bool:
        """التحقق من صحة الإعدادات"""
        if self.timeout <= 0:
            raise ValueError("timeout must be a positive number")
        if self.max_retries < 0:
            raise ValueError("max_retries must be a non-negative number")
        return True