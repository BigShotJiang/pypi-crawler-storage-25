import  time, re, json
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from datetime import datetime
from .eval_result import EvalResult
from .eval_report import EvalReport
from .retrieval_metrics import RetrievalMetrics
from .generation_metrics import GenerationMetrics
from ..llm.hallucination import (
    HallucinationGuard, GroundingContext
)
from ..monitor import MetricsCollector



class RAGEvaluator:
    """
       main evaluator class\n
    الاستخدام:
        evaluator = RAGEvaluator(rag_system)
        report    = evaluator.evaluate(questions)
        evaluator.print_report(report)
    """

    def __init__(
        self,
        rag,
        hallucination_threshold: float = 0.65,
        verbose: bool = True,
    ):
        self.rag     = rag
        self.verbose = verbose

        # ── HallucinationGuard من luffy-rag ───────────────────────────────────
        self.guard = HallucinationGuard(
            threshold=hallucination_threshold,
            require_sources=True,
            fact_check_enabled=True,
            confidence_check_enabled=True,
            enable_logging=True,
        )

        # ── MetricsCollector من luffy-rag ─────────────────────────────────────
        self.metrics = MetricsCollector(max_metrics=50_000)

    # ── واجهة رئيسية ─────────────────────────────────────────────────────────

    def evaluate(
        self,
        questions: List[str],
        reference_answers: Optional[List[str]] = None,
    ) -> EvalReport:
        """
        يقيّم نظام RAG على قائمة أسئلة.\n
        evaluater rag system on a list of questions.


        Args:
            questions:          قائمة الأسئلة  | List Of Quesions
            reference_answers:  إجابات مرجعية اختيارية لحساب دقة أعلى

        Returns:
            EvalReport كامل
        """
        report = EvalReport()
        n = len(questions)

        if self.verbose:
            print(f"\n{'═'*60}")
            print(f"  🧪  RAG Smart Evaluator")
            print(f"  Number Of Query: {n}")
            print(f"{'═'*60}\n")

        for i, question in enumerate(questions, 1):
            ref = reference_answers[i - 1] if reference_answers else None

            if self.verbose:
                print(f"[{i}/{n}]  📝 {question[:70]}...")

            result = self._eval_single(question, ref)
            report.results.append(result)

            if self.verbose:
                self._print_single_line(result)

        # إحصائيات النظام من luffy-rag
        report.rag_stats = self.rag.get_stats() if hasattr(self.rag, "get_stats") else {}

        if self.verbose:
            print(f"\n{'═'*60}")
            self.print_summary(report)

        return report

    def eval_single(self, question: str, reference: str = None) -> EvalResult:
        """تقييم سؤال واحد\n
           evaluator one quesion
        """
        return self._eval_single(question, reference)

    # ── التقييم الداخلي ───────────────────────────────────────────────────────

    def _eval_single(self, question: str, reference: Optional[str]) -> EvalResult:
        # 1. قياس الاسترجاع
        ret_metrics = self._measure_retrieval(question)

        # 2. قياس التوليد
        gen_metrics = self._measure_generation(question, ret_metrics, reference)

        # 3. تسجيل في MetricsCollector
        self._record_metrics(question, ret_metrics, gen_metrics)

        return EvalResult(
            query=question,
            answer=gen_metrics.answer,
            retrieval=ret_metrics,
            generation=gen_metrics,
        )

    def _measure_retrieval(self, question: str) -> RetrievalMetrics:
        """يقيس جودة الاسترجاع باستخدام rag.retrieve()"""
        t0 = time.time()
        try:
            chunks = self.rag.retrieve(question)
        except Exception:
            chunks = []
        latency = (time.time() - t0) * 1000

        scores = [s for _, s in chunks] if chunks else []

        return RetrievalMetrics(
            query=question,
            num_chunks=len(chunks),
            top_score=max(scores) if scores else 0.0,
            avg_score=sum(scores) / len(scores) if scores else 0.0,
            min_score=min(scores) if scores else 0.0,
            score_variance=self._variance(scores),
            has_results=bool(chunks),
            latency_ms=latency,
        )

    def _measure_generation(
        self,
        question: str,
        ret: RetrievalMetrics,
        reference: Optional[str],
    ) -> GenerationMetrics:
        """يقيس جودة التوليد باستخدام HallucinationGuard من luffy-rag"""
        # توليد الإجابة
        t0 = time.time()
        try:
            answer = self.rag.generate(question, include_sources=False)
        except Exception as e:
            answer = f"[erro in generate: {e}]"
        gen_latency = (time.time() - t0) * 1000

        # بناء GroundingContext لـ HallucinationGuard
        chunks = []
        sources = []
        try:
            raw = self.rag.retrieve(question)
            for chunk, _ in raw:
                text = getattr(chunk, "text", "")
                doc  = getattr(chunk, "doc_id", "unknown")
                chunks.append(text)
                sources.append(doc)
        except Exception:
            pass

        ctx = GroundingContext(
            sources=sources,
            retrieved_facts=chunks[:5],
            context_window=" ".join(chunks[:3])[:2000],
        )

        # HallucinationGuard.check_response()
        hall_check = self.guard.check_response(
            response=answer,
            grounding_context=ctx,
            original_query=question,
        )

        # درجات جودة الإجابة
        faithfulness = self._score_faithfulness(answer, chunks)
        relevance    = self._score_relevance(answer, question)
        completeness = self._score_completeness(answer, question, reference)

        return GenerationMetrics(
            query=question,
            answer=answer,
            answer_length=len(answer),
            latency_ms=gen_latency,
            hallucination=hall_check,
            faithfulness_score=faithfulness,
            relevance_score=relevance,
            completeness_score=completeness,
        )

    # ── حساب الدرجات ─────────────────────────────────────────────────────────

    def _score_faithfulness(self, answer: str, context_chunks: List[str]) -> float:
        """مدى التزام الإجابة بالسياق المسترجع"""
        if not context_chunks or not answer:
            return 0.5
        combined = " ".join(context_chunks).lower()
        ans_words = set(w for w in re.findall(r'\w+', answer.lower()) if len(w) > 3)
        ctx_words = set(w for w in re.findall(r'\w+', combined) if len(w) > 3)
        if not ans_words:
            return 0.5
        overlap = len(ans_words & ctx_words) / len(ans_words)
        # تطبيع منحنى نعومة
        return min(1.0, overlap * 1.4)

    def _score_relevance(self, answer: str, question: str) -> float:
        """مدى صلة الإجابة بالسؤال"""
        if not answer or not question:
            return 0.0
        q_words = set(w for w in re.findall(r'\w+', question.lower()) if len(w) > 3)
        a_words = set(w for w in re.findall(r'\w+', answer.lower()) if len(w) > 3)
        if not q_words:
            return 0.5
        hit = len(q_words & a_words) / len(q_words)
        # عقوبة على الإجابات الفارغة أو القصيرة جداً
        length_penalty = min(1.0, len(answer) / 80)
        return round(hit * 0.65 + length_penalty * 0.35, 3)

    def _score_completeness(
        self,
        answer: str,
        question: str,
        reference: Optional[str],
    ) -> float:
        """مدى اكتمال الإجابة"""
        if reference:
            # مقارنة بالإجابة المرجعية (ROUGE-1 مبسط)
            ref_w = set(w for w in re.findall(r'\w+', reference.lower()) if len(w) > 3)
            ans_w = set(w for w in re.findall(r'\w+', answer.lower()) if len(w) > 3)
            if not ref_w:
                return 0.5
            return min(1.0, len(ref_w & ans_w) / len(ref_w))
        else:
            # تقدير بناءً على الطول والتنوع
            words  = re.findall(r'\w+', answer)
            unique = set(w.lower() for w in words)
            length_score = min(1.0, len(words) / 60)
            diversity    = min(1.0, len(unique) / max(1, len(words)) * 2)
            return round(length_score * 0.6 + diversity * 0.4, 3)

    # ── تسجيل المقاييس في MetricsCollector ───────────────────────────────────

    def _record_metrics(self, q: str, ret: RetrievalMetrics, gen: GenerationMetrics):
        """MetricsCollector """
        self.metrics.increment("eval.total_questions")
        self.metrics.gauge("eval.retrieval.top_score",    ret.top_score)
        self.metrics.gauge("eval.retrieval.num_chunks",   ret.num_chunks)
        self.metrics.gauge("eval.retrieval.latency_ms",   ret.latency_ms)
        self.metrics.gauge("eval.generation.faithfulness", gen.faithfulness_score)
        self.metrics.gauge("eval.generation.relevance",    gen.relevance_score)
        self.metrics.gauge("eval.generation.overall",      gen.overall_score)
        self.metrics.gauge("eval.generation.latency_ms",   gen.latency_ms)
        if gen.hallucination.is_hallucination:
            self.metrics.increment("eval.hallucinations_detected")

    # ── طباعة التقارير ────────────────────────────────────────────────────────

    def _print_single_line(self, r: EvalResult):
        g = r.generation
        icon = "✅" if not g.hallucination.is_hallucination else "⚠️"
        print(
            f"    {icon}  Grade={g.grade}  "
            f"Faith={g.faithfulness_score:.2f}  "
            f"Rel={g.relevance_score:.2f}  "
            f"Hall={g.hallucination.confidence_score:.2f}  "
            f"Ret={r.retrieval.top_score:.2f}  "
            f"⏱{r.retrieval.latency_ms+g.latency_ms:.0f}ms"
        )
    def print_report(self, report: EvalReport):
        """Prints a detailed report"""
        print(f"\n{'═'*60}")
        print("  📊  Full Report:")
        print(f"{'═'*60}")
        print(f"  System health     : {report.system_health}")
        print(f"  Number of questions                 : {report.total}")
        print(f"  Avg retrieval     : {report.avg_retrieval_score:.1%}")
        print(f"  Avg generation    : {report.avg_generation_score:.1%}")
        print(f"  Hallucination rate: {report.hallucination_rate:.1%}")
        print(f"  Avg latency       : {report.avg_latency_ms:.0f} ms")
    
        print(f"\n  Grade distribution:")
        for grade, count in report.grade_distribution.items():
            bar = "█" * count
            print(f"    {grade}  {bar}  ({count})")
    
        print(f"\n  RAG system stats:")
        for k, v in report.rag_stats.items():
            print(f"    {k}: {v}")
    
        # details
        print(f"\n{'─'*60}")
        print("  Details per question:")
        print(f"{'─'*60}")
        for i, r in enumerate(report.results, 1):
            g = r.generation
            hall_flag = "🚨 Hallucination" if g.hallucination.is_hallucination else "✅ Clean"
    
            print(f"\n  [{i}] {r.query[:60]}...")
            print(f"       Grade       : {g.grade}  ({g.overall_score:.1%})")
            print(f"       Faithfulness: {g.faithfulness_score:.1%}")
            print(f"       Relevance   : {g.relevance_score:.1%}")
            print(f"       Completeness: {g.completeness_score:.1%}")
            print(f"       Retrieval   : {r.retrieval.top_score:.2f} ({r.retrieval.quality_label})")
            print(f"       Hallucination: {hall_flag} (conf={g.hallucination.confidence_score:.2f})")
    
            if g.hallucination.is_hallucination:
                print(f"       ⚠️  Recommendation: {g.hallucination.recommendation}")
    
        print(f"\n{'═'*60}\n")
    
    
    def print_summary(self, report: EvalReport):
        print(f"  ✅  Evaluation completed")
        print(f"  Health: {report.system_health}")
        print(
            f"  Generation: {report.avg_generation_score:.1%}  |  "
            f"Retrieval: {report.avg_retrieval_score:.1%}  |  "
            f"Hallucination: {report.hallucination_rate:.1%}"
        )
        print(f"{'═'*60}\n")
    # ── أدوات مساعدة ─────────────────────────────────────────────────────────

    @staticmethod
    def _variance(values: List[float]) -> float:
        if len(values) < 2:
            return 0.0
        mean = sum(values) / len(values)
        return sum((v - mean) ** 2 for v in values) / len(values)

    def get_guard_statistics(self) -> Dict:
        """إحصائيات HallucinationGuard"""
        return self.guard.get_statistics()

    def get_metrics_summary(self) -> Dict:
        """ملخص MetricsCollector"""
        return {
            "counters":   dict(self.metrics.counters),
            "gauges":     dict(self.metrics.gauges),
        }
