from dataclasses import dataclass

@dataclass
class RetrievalMetrics:
    """مقاييس جودة الاسترجاع\n
       metrics for retrival
    """
    query:           str
    num_chunks:      int
    top_score:       float
    avg_score:       float
    min_score:       float
    score_variance:  float
    has_results:     bool
    latency_ms:      float

    @property
    def quality_label(self) -> str:
        if self.top_score >= 0.80: return "excellent"
        if self.top_score >= 0.60: return "good"
        if self.top_score >= 0.40: return "acceptable"
        return "weak"