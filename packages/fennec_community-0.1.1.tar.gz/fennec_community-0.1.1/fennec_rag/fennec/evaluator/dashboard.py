
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .eval_report import EvalReport


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>RAG Evaluator Dashboard</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');

  :root {{
    --bg:       #0d0f14;
    --surface:  #161922;
    --card:     #1e2330;
    --border:   #2a3042;
    --accent:   #4f8ef7;
    --green:    #34d399;
    --amber:    #fbbf24;
    --red:      #f87171;
    --purple:   #a78bfa;
    --text:     #e2e8f0;
    --muted:    #7a8499;
    --mono:     'JetBrains Mono', monospace;
    --sans:     'IBM Plex Sans Arabic', sans-serif;
  }}

  * {{ box-sizing: border-box; margin: 0; padding: 0; }}

  body {{
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    min-height: 100vh;
  }}

  /* ── Header ── */
  .header {{
    background: linear-gradient(135deg, #1a1f2e 0%, #0d1117 100%);
    border-bottom: 1px solid var(--border);
    padding: 24px 32px;
    display: flex;
    align-items: center;
    gap: 16px;
  }}
  .header-icon {{ font-size: 32px; }}
  .header h1  {{ font-size: 22px; font-weight: 600; letter-spacing: -0.5px; }}
  .header p   {{ color: var(--muted); font-size: 13px; margin-top: 2px; }}

  /* ── Layout ── */
  .main {{ padding: 28px 32px; max-width: 1280px; margin: 0 auto; }}

  /* ── Health Banner ── */
  .health-banner {{
    border-radius: 12px;
    padding: 18px 24px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 16px;
    font-weight: 500;
    border: 1px solid var(--border);
  }}
  .health-great  {{ background: rgba(52,211,153,.12); border-color: rgba(52,211,153,.35); }}
  .health-good   {{ background: rgba(251,191,36,.10);  border-color: rgba(251,191,36,.35); }}
  .health-fair   {{ background: rgba(248,161,45,.10);  border-color: rgba(248,161,45,.35); }}
  .health-bad    {{ background: rgba(248,113,113,.10); border-color: rgba(248,113,113,.35); }}

  /* ── KPI Grid ── */
  .kpi-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 14px;
    margin-bottom: 28px;
  }}
  .kpi {{
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 18px 20px;
    position: relative;
    overflow: hidden;
  }}
  .kpi::before {{
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    border-radius: 12px 12px 0 0;
  }}
  .kpi.blue::before   {{ background: var(--accent); }}
  .kpi.green::before  {{ background: var(--green); }}
  .kpi.amber::before  {{ background: var(--amber); }}
  .kpi.red::before    {{ background: var(--red); }}
  .kpi.purple::before {{ background: var(--purple); }}
  .kpi-label  {{ color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: .8px; margin-bottom: 8px; }}
  .kpi-value  {{ font-size: 28px; font-weight: 600; font-family: var(--mono); }}
  .kpi-sub    {{ color: var(--muted); font-size: 11px; margin-top: 4px; }}

  /* ── Section heading ── */
  .section-title {{
    font-size: 15px; font-weight: 600;
    margin: 28px 0 14px;
    display: flex; align-items: center; gap: 8px;
    border-bottom: 1px solid var(--border);
    padding-bottom: 10px;
  }}

  /* ── Grade Bar ── */
  .grade-row {{ display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; }}
  .grade-pill {{
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px 16px;
    display: flex; flex-direction: column; align-items: center; gap: 4px;
    min-width: 70px;
  }}
  .grade-letter {{ font-size: 20px; font-weight: 700; font-family: var(--mono); }}
  .grade-count  {{ font-size: 11px; color: var(--muted); }}
  .gA {{ color: var(--green);  }} .gB {{ color: var(--accent); }}
  .gC {{ color: var(--amber);  }} .gD {{ color: #fb923c; }} .gF {{ color: var(--red); }}

  /* ── Results Table ── */
  .results-table {{ width: 100%; border-collapse: collapse; }}
  .results-table th {{
    background: var(--surface);
    color: var(--muted);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .6px;
    padding: 10px 14px;
    text-align: right;
    font-weight: 500;
  }}
  .results-table td {{
    padding: 12px 14px;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
  }}
  .results-table tr:hover td {{ background: rgba(255,255,255,.025); }}
  .results-table tr:last-child td {{ border-bottom: none; }}

  .tag {{
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-family: var(--mono);
    font-weight: 500;
  }}
  .tag-green  {{ background: rgba(52,211,153,.15); color: var(--green);  }}
  .tag-amber  {{ background: rgba(251,191,36,.15);  color: var(--amber);  }}
  .tag-red    {{ background: rgba(248,113,113,.15); color: var(--red);    }}
  .tag-blue   {{ background: rgba(79,142,247,.15);  color: var(--accent); }}
  .tag-purple {{ background: rgba(167,139,250,.15); color: var(--purple); }}

  .grade-badge {{
    display: inline-flex;
    align-items: center; justify-content: center;
    width: 28px; height: 28px;
    border-radius: 6px;
    font-weight: 700;
    font-size: 13px;
    font-family: var(--mono);
  }}
  .gb-A {{ background: rgba(52,211,153,.2);  color: var(--green);  }}
  .gb-B {{ background: rgba(79,142,247,.2);  color: var(--accent); }}
  .gb-C {{ background: rgba(251,191,36,.2);  color: var(--amber);  }}
  .gb-D {{ background: rgba(251,100,36,.2);  color: #fb923c;       }}
  .gb-F {{ background: rgba(248,113,113,.2); color: var(--red);    }}

  .score-bar-wrap {{ display: flex; align-items: center; gap: 8px; }}
  .score-bar-bg   {{ flex: 1; height: 4px; background: var(--border); border-radius: 2px; }}
  .score-bar-fill {{ height: 100%; border-radius: 2px; }}
  .score-num      {{ font-family: var(--mono); font-size: 12px; min-width: 36px; text-align: left; }}

  .query-text {{ color: var(--text); line-height: 1.5; max-width: 320px; }}
  .answer-preview {{ color: var(--muted); font-size: 12px; line-height: 1.5; max-width: 280px; }}

  /* ── Expand answer ── */
  details summary {{ cursor: pointer; color: var(--accent); font-size: 12px; }}
  details p       {{ margin-top: 8px; color: var(--muted); font-size: 12px; line-height: 1.6; }}

  /* ── Recommendation box ── */
  .rec-box {{
    background: rgba(248,113,113,.08);
    border: 1px solid rgba(248,113,113,.25);
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 11px;
    color: #fca5a5;
    margin-top: 4px;
    max-width: 280px;
    line-height: 1.5;
  }}

  /* ── Footer ── */
  .footer {{
    text-align: center;
    padding: 32px;
    color: var(--muted);
    font-size: 12px;
    border-top: 1px solid var(--border);
    margin-top: 40px;
  }}

  /* ── Responsive ── */
  @media (max-width: 768px) {{
    .main {{ padding: 16px; }}
    .kpi-grid {{ grid-template-columns: 1fr 1fr; }}
    .results-table th:nth-child(n+5),
    .results-table td:nth-child(n+5) {{ display: none; }}
  }}
</style>
</head>
<body>

<div class="header">
  <div class="header-icon">🧪</div>
  <div>
    <h1>RAG Evaluation Dashboard</h1>
    <p>تقييم ذكي مبني على Fennec-RAG · {created_at}</p>
  </div>
</div>

<div class="main">

  <!-- Health Banner -->
  <div class="health-banner {health_class}">
    <span style="font-size:22px">{health_icon}</span>
    <span>{health_label}</span>
  </div>

  <!-- KPIs -->
  <div class="kpi-grid">
    <div class="kpi blue">
      <div class="kpi-label">أسئلة مُقيَّمة</div>
      <div class="kpi-value">{total}</div>
      <div class="kpi-sub">إجمالي الجلسة</div>
    </div>
    <div class="kpi green">
      <div class="kpi-label">متوسط التوليد</div>
      <div class="kpi-value">{avg_gen}%</div>
      <div class="kpi-sub">Faithfulness · Relevance · Completeness</div>
    </div>
    <div class="kpi blue">
      <div class="kpi-label">متوسط الاسترجاع</div>
      <div class="kpi-value">{avg_ret}%</div>
      <div class="kpi-sub">أعلى درجة تشابه</div>
    </div>
    <div class="kpi {hall_kpi_class}">
      <div class="kpi-label">نسبة الهلوسة</div>
      <div class="kpi-value">{hall_rate}%</div>
      <div class="kpi-sub">HallucinationGuard</div>
    </div>
    <div class="kpi purple">
      <div class="kpi-label">متوسط الوقت</div>
      <div class="kpi-value">{avg_lat}ms</div>
      <div class="kpi-sub">استرجاع + توليد</div>
    </div>
  </div>

  <!-- Grade Distribution -->
  <div class="section-title">🎓 توزيع الدرجات</div>
  <div class="grade-row">
    {grade_pills}
  </div>

  <!-- Results Table -->
  <div class="section-title">📋 نتائج تفصيلية</div>
  <div style="overflow-x:auto; background:var(--card); border:1px solid var(--border); border-radius:12px;">
    <table class="results-table">
      <thead>
        <tr>
          <th>#</th>
          <th>السؤال</th>
          <th>Grade</th>
          <th>Faithfulness</th>
          <th>Relevance</th>
          <th>Retrieval</th>
          <th>هلوسة</th>
          <th>الإجابة</th>
        </tr>
      </thead>
      <tbody>
        {rows}
      </tbody>
    </table>
  </div>

</div>

<div class="footer">
  RAG Smart Evaluator · مبني على Fennec-RAG ·(HallucinationGuard + MetricsCollector)
</div>

</body>
</html>"""


def _bar(score: float, color: str) -> str:
    pct = int(score * 100)
    colors = {
        "green":  "#34d399", "blue":   "#4f8ef7",
        "amber":  "#fbbf24", "red":    "#f87171",
    }
    fill = colors.get(color, "#4f8ef7")
    label_color = fill
    return (
        f'<div class="score-bar-wrap">'
        f'<div class="score-bar-bg">'
        f'<div class="score-bar-fill" style="width:{pct}%;background:{fill}"></div>'
        f'</div>'
        f'<span class="score-num" style="color:{label_color}">{pct}%</span>'
        f'</div>'
    )


def _tag_hall(is_hall: bool, conf: float) -> str:
    if is_hall:
        return f'<span class="tag tag-red">🚨 hallusination {conf:.0%}</span>'
    if conf >= 0.80:
        return f'<span class="tag tag-green">✅ excellent {conf:.0%}</span>'
    return f'<span class="tag tag-amber">⚠️ {conf:.0%}</span>'


def generate_dashboard(report, output_path: str = "rag_dashboard.html") -> str:
    """يولّد ملف HTML تفاعلي من EvalReport"""

    data = report.to_dict()

    # health class
    health = data["system_health"]
    if "excellent" in health:
        hcls, hicon = "health-great", "🟢"
    elif "good" in health:
        hcls, hicon = "health-good", "🟡"
    elif "acceptable" in health:
        hcls, hicon = "health-fair", "🟠"
    else:
        hcls, hicon = "health-bad", "🔴"

    # hallucination KPI color
    hr = data["hallucination_rate"]
    hall_kpi_cls = "green" if hr <= 0.1 else ("amber" if hr <= 0.3 else "red")

    # grade pills
    grade_colors = {"A": "gA", "B": "gB", "C": "gC", "D": "gD", "F": "gF"}
    grade_pills = ""
    for g, cnt in data["grade_distribution"].items():
        col = grade_colors.get(g, "gF")
        grade_pills += (
            f'<div class="grade-pill">'
            f'<span class="grade-letter {col}">{g}</span>'
            f'<span class="grade-count">{cnt} سؤال</span>'
            f'</div>'
        )

    # rows
    rows = ""
    for i, r in enumerate(data["results"], 1):
        gen  = r["generation"]
        ret  = r["retrieval"]
        hall = _tag_hall(gen["is_hallucination"], gen["confidence"])
        grade = gen["grade"]
        gcls  = f"gb-{grade}"

        # bar colors
        faith_c = "green" if gen["faithfulness"] >= 0.7 else ("amber" if gen["faithfulness"] >= 0.5 else "red")
        rel_c   = "blue"  if gen["relevance"]    >= 0.7 else ("amber" if gen["relevance"]    >= 0.5 else "red")
        ret_c   = "green" if ret["top_score"]     >= 0.7 else ("amber" if ret["top_score"]     >= 0.5 else "red")

        rec_html = ""
        if gen["is_hallucination"] and gen.get("recommendation"):
            rec_html = f'<div class="rec-box">{gen["recommendation"][:120]}</div>'

        rows += f"""
        <tr>
          <td style="color:var(--muted);font-family:var(--mono)">{i}</td>
          <td><div class="query-text">{r["query"][:100]}</div></td>
          <td><span class="grade-badge {gcls}">{grade}</span></td>
          <td>{_bar(gen["faithfulness"], faith_c)}</td>
          <td>{_bar(gen["relevance"],    rel_c)}</td>
          <td>
            {_bar(ret["top_score"], ret_c)}
            <div style="font-size:11px;color:var(--muted);margin-top:2px">
              {ret["num_chunks"]} chunk · {ret["latency_ms"]:.0f}ms
            </div>
          </td>
          <td>{hall}{rec_html}</td>
          <td>
            <details>
              <summary>عرض الإجابة</summary>
              <p>{r["answer"][:400]}</p>
            </details>
          </td>
        </tr>"""

    html = _HTML_TEMPLATE.format(
        created_at=data["created_at"][:19].replace("T", " "),
        health_class=hcls,
        health_icon=hicon,
        health_label=health,
        total=data["total_questions"],
        avg_gen=round(data["avg_generation_score"] * 100),
        avg_ret=round(data["avg_retrieval_score"] * 100),
        hall_rate=round(data["hallucination_rate"] * 100),
        avg_lat=round(data["avg_latency_ms"]),
        hall_kpi_class=hall_kpi_cls,
        grade_pills=grade_pills,
        rows=rows,
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"🌐 Dashboard Saved in : {output_path}")
    return output_path
