from dataclasses import dataclass
from ..llm.hallucination import HallucinationCheck



@dataclass
class GenerationMetrics:
    """مقاييس جودة التوليد
       metrics for generation
    """
    query:              str
    answer:             str
    answer_length:      int
    latency_ms:         float
    hallucination:      HallucinationCheck
    faithfulness_score: float   # مدى التزام الإجابة بالسياق (0→1)
    relevance_score:    float   # مدى صلة الإجابة بالسؤال (0→1)
    completeness_score: float   # مدى اكتمال الإجابة (0→1)

    @property
    def overall_score(self) -> float:
        w = dict(faith=0.40, rel=0.35, comp=0.25)
        return (
            w["faith"] * self.faithfulness_score +
            w["rel"]   * self.relevance_score     +
            w["comp"]  * self.completeness_score
        )

    @property
    def grade(self) -> str:
        s = self.overall_score
        if s >= 0.85: return "A"
        if s >= 0.70: return "B"
        if s >= 0.55: return "C"
        if s >= 0.40: return "D"
        return "F"
