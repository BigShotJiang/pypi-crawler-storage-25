from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict
from .retrieval_metrics import RetrievalMetrics
from .generation_metrics import GenerationMetrics



@dataclass
class EvalResult:
    """نتيجة تقييم سؤال واحد\n
    eval single question result
    """
    query:      str
    answer:     str
    retrieval:  RetrievalMetrics
    generation: GenerationMetrics
    timestamp:  str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return {
            "query":     self.query,
            "answer":    self.answer[:300],
            "timestamp": self.timestamp,
            "retrieval": {
                "num_chunks":    self.retrieval.num_chunks,
                "top_score":     round(self.retrieval.top_score, 3),
                "avg_score":     round(self.retrieval.avg_score, 3),
                "latency_ms":    round(self.retrieval.latency_ms, 1),
                "quality":       self.retrieval.quality_label,
            },
            "generation": {
                "grade":             self.generation.grade,
                "overall_score":     round(self.generation.overall_score, 3),
                "faithfulness":      round(self.generation.faithfulness_score, 3),
                "relevance":         round(self.generation.relevance_score, 3),
                "completeness":      round(self.generation.completeness_score, 3),
                "latency_ms":        round(self.generation.latency_ms, 1),
                "is_hallucination":  self.generation.hallucination.is_hallucination,
                "confidence":        round(self.generation.hallucination.confidence_score, 3),
                "hallucination_type": (
                    self.generation.hallucination.hallucination_type.value
                    if self.generation.hallucination.hallucination_type else None
                ),
                "recommendation":    self.generation.hallucination.recommendation,
            }
        }
