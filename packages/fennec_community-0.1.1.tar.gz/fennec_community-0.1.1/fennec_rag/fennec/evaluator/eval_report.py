from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List
import json

from .eval_result import EvalResult




@dataclass
class EvalReport:
    """تقرير شامل لمجموعة أسئلة\n
       full query rebort
    """
    results:     List[EvalResult] = field(default_factory=list)
    rag_stats:   Dict            = field(default_factory=dict)
    created_at:  str             = field(default_factory=lambda: datetime.now().isoformat())

    # ── إحصائيات مجمّعة ──────────────────────────────────────────────────────
    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def avg_retrieval_score(self) -> float:
        if not self.results: return 0.0
        return sum(r.retrieval.top_score for r in self.results) / self.total

    @property
    def avg_generation_score(self) -> float:
        if not self.results: return 0.0
        return sum(r.generation.overall_score for r in self.results) / self.total

    @property
    def hallucination_rate(self) -> float:
        if not self.results: return 0.0
        return sum(1 for r in self.results if r.generation.hallucination.is_hallucination) / self.total

    @property
    def avg_latency_ms(self) -> float:
        if not self.results: return 0.0
        total_lat = sum(r.retrieval.latency_ms + r.generation.latency_ms for r in self.results)
        return total_lat / self.total

    @property
    def grade_distribution(self) -> Dict[str, int]:
        dist = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
        for r in self.results:
            dist[r.generation.grade] += 1
        return dist

    @property
    def system_health(self) -> str:
        score = self.avg_generation_score
        hall  = self.hallucination_rate
        ret   = self.avg_retrieval_score
        if score >= 0.80 and hall <= 0.10 and ret >= 0.70:
            return "🟢 excellent"
        if score >= 0.65 and hall <= 0.20 and ret >= 0.55:
            return "🟡 good"
        if score >= 0.50 and hall <= 0.35:
            return "🟠 acceptable-need to improve"
        return "🔴 weak-need to review"

    def to_dict(self) -> Dict:
        return {
            "created_at":           self.created_at,
            "total_questions":      self.total,
            "system_health":        self.system_health,
            "avg_retrieval_score":  round(self.avg_retrieval_score, 3),
            "avg_generation_score": round(self.avg_generation_score, 3),
            "hallucination_rate":   round(self.hallucination_rate, 3),
            "avg_latency_ms":       round(self.avg_latency_ms, 1),
            "grade_distribution":   self.grade_distribution,
            "rag_stats":            self.rag_stats,
            "results":              [r.to_dict() for r in self.results],
        }

    def save(self, path: str = "eval_report.json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
        print(f"💾 Saved: {path}")
