from __future__ import annotations

import os
from pathlib import Path

import pytest
from PIL import Image as PILImage

from coffeecode_cropper import (
    Cropper,
    CropperException,
    ImageNotFoundError,
    UnsupportedImageError,
)


def test_constructor_creates_cache_dir(tmp_path):
    cache = tmp_path / "deep" / "nested" / "cache"
    Cropper(str(cache))
    assert cache.is_dir()


def test_make_returns_webp_by_default(workdir, sample_jpg):
    cropper = Cropper("cache")
    out = cropper.make(sample_jpg(size=(1200, 900)), 200)
    assert out.endswith(".webp")
    assert Path(out).is_file()
    with PILImage.open(out) as img:
        assert img.format == "WEBP"
        # Width-only call: proportional resize, no crop.
        assert img.size == (200, 150)


def test_make_keeps_source_format_when_webp_disabled(workdir, sample_jpg):
    cropper = Cropper("cache", webp=False)
    out = cropper.make(sample_jpg(size=(1200, 900)), 200)
    assert out.endswith(".jpg")
    with PILImage.open(out) as img:
        assert img.format == "JPEG"


def test_make_with_height_does_center_crop(workdir, sample_jpg):
    cropper = Cropper("cache", webp=False)
    out = cropper.make(sample_jpg(size=(1600, 900)), 400, 400)
    with PILImage.open(out) as img:
        assert img.size == (400, 400)


def test_make_png_preserves_format(workdir, sample_png):
    cropper = Cropper("cache", webp=False)
    out = cropper.make(sample_png(size=(800, 800)), 200, 100)
    assert out.endswith(".png")
    with PILImage.open(out) as img:
        assert img.format == "PNG"
        assert img.size == (200, 100)


def test_make_caches_subsequent_calls(workdir, sample_jpg):
    cropper = Cropper("cache")
    src = sample_jpg(size=(800, 600))
    first = cropper.make(src, 100)
    first_mtime = os.path.getmtime(first)

    second = cropper.make(src, 100)
    assert first == second
    # No regeneration → mtime unchanged.
    assert os.path.getmtime(second) == first_mtime


def test_make_different_dimensions_different_files(workdir, sample_jpg):
    cropper = Cropper("cache")
    src = sample_jpg(size=(800, 600))
    a = cropper.make(src, 100)
    b = cropper.make(src, 200)
    c = cropper.make(src, 200, 200)
    assert len({a, b, c}) == 3


def test_flush_with_path_clears_only_variants(workdir, sample_jpg):
    cropper = Cropper("cache")
    a_src = sample_jpg("photo-a.jpg", size=(800, 600))
    b_src = sample_jpg("photo-b.jpg", size=(800, 600))

    cropper.make(a_src, 100)
    cropper.make(a_src, 200)
    cropper.make(b_src, 100)

    cropper.flush(a_src)
    remaining = list(Path("cache").iterdir())
    assert all("photo-b" in p.name for p in remaining)
    assert len(remaining) == 1


def test_flush_without_path_clears_all(workdir, sample_jpg):
    cropper = Cropper("cache")
    cropper.make(sample_jpg("a.jpg"), 100)
    cropper.make(sample_jpg("b.jpg"), 100)
    assert any(Path("cache").iterdir())

    cropper.flush()
    assert not any(Path("cache").iterdir())


def test_make_raises_when_source_missing(workdir):
    cropper = Cropper("cache")
    with pytest.raises(ImageNotFoundError):
        cropper.make("does/not/exist.jpg", 100)


def test_make_raises_for_unsupported_image(workdir, tmp_path, sample_png):
    cropper = Cropper("cache")
    # Save a GIF — disallowed even though it's a real image.
    gif_path = tmp_path / "x.gif"
    PILImage.new("P", (10, 10)).save(gif_path, format="GIF")
    with pytest.raises(UnsupportedImageError):
        cropper.make(str(gif_path), 50)


def test_make_raises_for_garbage_file(workdir, sample_garbage):
    cropper = Cropper("cache")
    with pytest.raises(CropperException):
        cropper.make(sample_garbage(), 50)


def test_filename_slug_handles_accents_and_specials(workdir, sample_jpg):
    cropper = Cropper("cache", webp=False)
    src = sample_jpg("Foto Acentuada (Edição Final).jpg", size=(400, 300))
    out = cropper.make(src, 100)
    assert "foto-acentuada-edicao-final" in Path(out).name


def test_cache_hash_differs_per_basename(workdir, sample_jpg, tmp_path):
    cropper = Cropper("cache")
    a = sample_jpg("alpha.jpg", size=(400, 300))
    b = sample_jpg("beta.jpg", size=(400, 300))
    out_a = cropper.make(a, 100)
    out_b = cropper.make(b, 100)
    assert Path(out_a).stem != Path(out_b).stem
