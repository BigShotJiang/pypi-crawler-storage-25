from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image as PILImage


@pytest.fixture
def workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def sample_jpg(tmp_path):
    def _make(name: str = "Sample Photo.jpg", size=(1600, 900)) -> str:
        path = tmp_path / name
        PILImage.new("RGB", size, (200, 30, 60)).save(path, format="JPEG")
        return str(path)
    return _make


@pytest.fixture
def sample_png(tmp_path):
    def _make(name: str = "logo.png", size=(800, 600)) -> str:
        path = tmp_path / name
        PILImage.new("RGBA", size, (10, 200, 40, 200)).save(path, format="PNG")
        return str(path)
    return _make


@pytest.fixture
def sample_garbage(tmp_path):
    def _make(name: str = "fake.jpg", content: bytes = b"not an image") -> str:
        path = tmp_path / name
        path.write_bytes(content)
        return str(path)
    return _make
