from __future__ import annotations

import html
import os
import re
import unicodedata
import zlib
from pathlib import Path
from typing import ClassVar, Optional, Union

from PIL import Image as PILImage

from .exceptions import (
    CropperException,
    ImageNotFoundError,
    UnsupportedImageError,
)

PathLike = Union[str, os.PathLike]

_PIL_FORMAT_TO_MIME: dict[str, str] = {
    "JPEG": "image/jpeg",
    "PNG": "image/png",
}


class Cropper:
    """Generate cached thumbnails for JPG and PNG images.

    Mirrors the API of the PHP package ``coffeecode/cropper``: two methods,
    :meth:`make` and :meth:`flush`. Thumbnails are cached on disk; subsequent
    calls with the same source path and dimensions return the cached file.

    Args:
        cache_path: Directory where thumbnails are stored. Created if missing.
        quality: JPEG quality (1-100). Also used as default WebP quality.
        compressor: PNG compression level (0-9).
        webp: When True, output ``.webp`` thumbnails (default). Set False to
            keep the source format.
    """

    _ALLOWED_MIMES: ClassVar[set[str]] = {"image/jpeg", "image/png"}

    def __init__(
        self,
        cache_path: PathLike,
        quality: int = 75,
        compressor: int = 5,
        webp: bool = True,
    ) -> None:
        self.cache_path = str(cache_path)
        self.quality = int(quality)
        self.compressor = int(compressor)
        self.webp = bool(webp)

        try:
            Path(self.cache_path).mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise CropperException("Could not create cache folder") from exc

    def make(
        self,
        image_path: PathLike,
        width: int,
        height: Optional[int] = None,
    ) -> str:
        """Return the path to a cached thumbnail, generating it if needed."""
        src = str(image_path)
        if not os.path.isfile(src):
            raise ImageNotFoundError(f"Image not found: {src}")

        try:
            with PILImage.open(src) as probe:
                mime = _PIL_FORMAT_TO_MIME.get(probe.format or "")
        except (PILImage.UnidentifiedImageError, OSError) as exc:
            raise UnsupportedImageError("Not a valid JPG or PNG image") from exc

        if mime not in self._ALLOWED_MIMES:
            raise UnsupportedImageError("Not a valid JPG or PNG image")

        ext = Path(src).suffix.lstrip(".").lower()
        if ext == "jpeg":
            ext = "jpg"

        cache_name = self._name(src, width, height)
        webp_path = f"{self.cache_path}/{cache_name}.webp"
        ext_path = f"{self.cache_path}/{cache_name}.{ext}"

        if self.webp and os.path.isfile(webp_path):
            return webp_path
        if os.path.isfile(ext_path):
            return ext_path

        return self._image_cache(src, mime, ext, cache_name, width, height)

    def flush(self, image_path: Optional[PathLike] = None) -> None:
        """Delete cached files. Pass an image path to clear only its variants."""
        if not os.path.isdir(self.cache_path):
            return

        target_hash = self._hash(str(image_path)) if image_path else None
        for entry in os.listdir(self.cache_path):
            full = os.path.join(self.cache_path, entry)
            if not os.path.isfile(full):
                continue
            if target_hash is None or target_hash in entry:
                try:
                    os.unlink(full)
                except OSError:
                    pass

    def _name(
        self,
        image_path: str,
        width: Optional[int],
        height: Optional[int],
    ) -> str:
        stem = Path(image_path).stem
        slug = self._slugify(stem)
        suffix_w = f"-{width}" if width else ""
        suffix_h = f"x{height}" if height else ""
        return f"{slug}{suffix_w}{suffix_h}-{self._hash(image_path)}"

    @staticmethod
    def _hash(image_path: str) -> str:
        basename = os.path.basename(image_path)
        return f"{zlib.crc32(basename.encode('utf-8')) & 0xFFFFFFFF:08x}"

    @staticmethod
    def _slugify(name: str) -> str:
        name = name.lower()
        name = html.escape(name, quote=False)
        normalized = unicodedata.normalize("NFKD", name)
        ascii_name = normalized.encode("ascii", "ignore").decode("ascii")
        ascii_name = re.sub(r"[^a-z0-9]+", "-", ascii_name)
        ascii_name = re.sub(r"-+", "-", ascii_name).strip("-")
        return ascii_name or "image"

    def _image_cache(
        self,
        src_path: str,
        mime: str,
        ext: str,
        cache_name: str,
        width: int,
        height: Optional[int],
    ) -> str:
        with PILImage.open(src_path) as src:
            src.load()
            src_w, src_h = src.size

            if height is None:
                height = max(1, round((width * src_h) / src_w))

            src_x = 0
            src_y = 0
            cmp_x = src_w / width
            cmp_y = src_h / height

            crop_w = src_w
            crop_h = src_h

            if cmp_x > cmp_y:
                crop_w = round(src_w / cmp_x * cmp_y)
                src_x = round((src_w - crop_w) / 2)
            elif cmp_y > cmp_x:
                crop_h = round(src_h / cmp_y * cmp_x)
                src_y = round((src_h - crop_h) / 2)

            box = (int(src_x), int(src_y), int(src_x + crop_w), int(src_y + crop_h))
            cropped = src.crop(box)
            thumb = cropped.resize((int(width), int(height)), PILImage.LANCZOS)

            output_path = f"{self.cache_path}/{cache_name}.{ext}"

            if mime == "image/jpeg":
                rgb = thumb.convert("RGB") if thumb.mode != "RGB" else thumb
                rgb.save(output_path, format="JPEG", quality=self.quality)
                if rgb is not thumb:
                    rgb.close()
            else:  # image/png
                rgba = thumb.convert("RGBA") if thumb.mode != "RGBA" else thumb
                rgba.save(output_path, format="PNG", compress_level=self.compressor)
                if rgba is not thumb:
                    rgba.close()

            cropped.close()
            thumb.close()

        if self.webp:
            return self._to_webp(output_path)
        return output_path

    def _to_webp(self, image_path: str, unlink_source: bool = True) -> str:
        webp_path = f"{os.path.splitext(image_path)[0]}.webp"
        try:
            with PILImage.open(image_path) as img:
                img.save(webp_path, format="WEBP", quality=self.quality)
        except (OSError, ValueError):
            return image_path

        if unlink_source:
            try:
                os.unlink(image_path)
            except OSError:
                pass
        return webp_path
