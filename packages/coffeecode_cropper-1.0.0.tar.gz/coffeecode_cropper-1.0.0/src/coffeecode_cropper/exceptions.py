class CropperException(Exception):
    """Base exception for cropper errors."""


class ImageNotFoundError(CropperException):
    """Raised when the source image file does not exist."""


class UnsupportedImageError(CropperException):
    """Raised when the source image is not a JPG or PNG."""
