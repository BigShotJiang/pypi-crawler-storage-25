"""Exemplo CLI minimo. Uso:

    python cli_example.py path/para/foto.jpg 400 300
    python cli_example.py path/para/foto.jpg 200            # so largura
"""
from __future__ import annotations

import sys

from coffeecode_cropper import Cropper


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 1

    src = sys.argv[1]
    width = int(sys.argv[2])
    height = int(sys.argv[3]) if len(sys.argv) > 3 else None

    cropper = Cropper("cache")
    out = cropper.make(src, width, height)
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
