"""Exemplo FastAPI: gera thumbnails sob demanda servidos como arquivo estatico."""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from coffeecode_cropper import Cropper, CropperException

CACHE_DIR = "cache"
IMAGES_DIR = "images"

app = FastAPI()
app.mount("/cache", StaticFiles(directory=CACHE_DIR), name="cache")

cropper = Cropper(CACHE_DIR, quality=80, compressor=6, webp=True)


@app.get("/thumb/{name}")
def thumb(name: str, w: int, h: int | None = None):
    """Return (and lazily generate) a thumbnail for IMAGES_DIR/{name}."""
    src = Path(IMAGES_DIR) / name
    if not src.is_file():
        raise HTTPException(404, f"image not found: {name}")
    try:
        out = cropper.make(str(src), w, h)
    except CropperException as e:
        raise HTTPException(400, str(e))
    return FileResponse(out)


@app.delete("/thumb/{name}")
def thumb_flush(name: str):
    src = Path(IMAGES_DIR) / name
    cropper.flush(str(src))
    return {"flushed": name}


@app.delete("/thumb")
def thumb_flush_all():
    cropper.flush()
    return {"flushed": "*"}
