from __future__ import annotations

import json
import re
from math import inf, nextafter
from unittest.mock import ANY

import jsonschema_rs
import pytest
from hypothesis.errors import Unsatisfiable

from schemathesis.core.jsonschema import BUNDLE_STORAGE_KEY
from schemathesis.core.parameters import ParameterLocation
from schemathesis.core.transforms import transform
from schemathesis.generation import GenerationMode
from schemathesis.specs.openapi.converter import to_json_schema
from schemathesis.specs.openapi.coverage._schema import (
    CoverageContext,
    CoverageScenario,
    GeneratedValue,
    _apply_pattern_optimizations,
    _cover_positive_for_type,
    _positive_number,
    _positive_string,
    cover_schema_iter,
)
from schemathesis.specs.openapi.formats import get_default_format_strategies
from schemathesis.specs.openapi.patterns import update_quantifier

PATTERN = "^\\d+$"


def cover_schema(ctx: CoverageContext, schema: dict) -> list:
    return [value.value for value in cover_schema_iter(ctx, schema)]


def assert_unique(values: list):
    seen = set()
    for value in values:
        if isinstance(value, GeneratedValue):
            value = value.value
        if isinstance(value, (dict | list)):
            try:
                serialized = jsonschema_rs.canonical.json.to_string(value)
            except ValueError:
                serialized = json.dumps(value, sort_keys=True)
            key = (type(value), serialized)
        else:
            key = (type(value), value)
        assert key not in seen
        seen.add(key)


def assert_conform(values: list, schema: dict):
    try:
        validator = jsonschema_rs.Draft7Validator(schema, validate_formats=True)
    except jsonschema_rs.ValidationError:
        # Schema itself is invalid (e.g., pattern: 0.0), skip validation
        return
    for value in values:
        if isinstance(value, GeneratedValue):
            value = value.value
        validator.validate(value)


def assert_not_conform(values: list, schema: dict):
    if isinstance(schema, dict) and schema.get("format") == "unknown":
        # Can't validate the format
        return
    try:
        validator = jsonschema_rs.Draft7Validator(schema, validate_formats=True)
    except jsonschema_rs.ValidationError:
        # Schema itself is invalid (e.g., pattern: 0.0), skip validation
        return
    for entry in values:
        try:
            validator.validate(entry)
            raise AssertionError(f"Value {entry} conforms to {schema}")
        except (jsonschema_rs.ValidationError, ValueError):
            pass


@pytest.fixture
def ctx_factory():
    def _factory(
        *,
        location: ParameterLocation = ParameterLocation.QUERY,
        generation_modes: list[GenerationMode] | None = None,
        is_required: bool = True,
        allow_extra_parameters: bool = True,
    ) -> CoverageContext:
        return CoverageContext(
            root_schema={},
            location=location,
            media_type=None,
            generation_modes=generation_modes,
            is_required=is_required,
            custom_formats=get_default_format_strategies(),
            validator_cls=jsonschema_rs.Draft4Validator,
            update_pattern=update_quantifier,
            allow_extra_parameters=allow_extra_parameters,
        )

    return _factory


@pytest.fixture
def ctx(ctx_factory):
    return ctx_factory()


@pytest.fixture
def pctx(ctx_factory):
    return ctx_factory(generation_modes=[GenerationMode.POSITIVE])


@pytest.fixture
def nctx(ctx_factory):
    return ctx_factory(generation_modes=[GenerationMode.NEGATIVE])


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        (True, [None, True, False, "", 0, [None, None], {}]),
        ({}, [None, True, False, "", 0, [None, None], {}]),
        (False, []),
        ({"type": "null"}, [None]),
        ({"type": "boolean"}, [True, False]),
        ({"type": ["boolean", "null"]}, [True, False, None]),
        ({"enum": [1, 2]}, [1, 2]),
        ({"const": 42}, [42]),
        ({"not": {}}, []),
        ({"not": {"type": "null"}}, [0, "false", "AAA", ["null", "null"]]),
    ],
)
def test_positive_primitive_schemas(pctx, schema, expected):
    covered = cover_schema(pctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_conform(covered, schema)


class AnyString:
    def __eq__(self, value: object, /) -> bool:
        return isinstance(value, str)


class AnyNumber:
    def __eq__(self, value: object, /) -> bool:
        return not isinstance(value, bool) and isinstance(value, (int | float))


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        (False, [None, True, False, "", 0, [None, None], {}]),
        (True, []),
        ({}, []),
        ({"type": "null"}, [0, "false", "AAA", ["null", "null"]]),
        ({"type": "boolean"}, [0, "null", "AAA", ["null", "null"]]),
        ({"type": ["boolean", "null"]}, [0, "AAA", ["null", "null"]]),
        # canonicalish drops `type` when `enum` is present; infer it from the values so type
        # violations still appear alongside the enum violation. The enum-negative "AAA"
        # collides with the type-negative "AAA" and dedupes to one entry.
        ({"enum": [1, 2]}, ["AAA", AnyNumber(), "false", "null", ["null", "null"]]),
        ({"enum": [1, 2, {}]}, ["AAA", AnyNumber(), "false", "null", ["null", "null"]]),
        ({"enum": ["a", "b"]}, ["AAA", 0, "false", "null", ["null", "null"]]),
        ({"const": 42}, ["AAA"]),
        ({"multipleOf": 2}, lambda x: x % 2 != 0),
        ({"format": "date-time"}, [AnyString()]),
        ({"format": "hostname"}, [AnyString()]),
        # Unknown formats have no validation semantics, so no negative cases can be generated
        ({"format": "unknown"}, []),
        ({"uniqueItems": True}, [["null", "null"]]),
        ({"maximum": 5}, [6]),
        ({"minimum": 5}, [4]),
        ({"exclusiveMinimum": 5}, [5]),
        ({"exclusiveMaximum": 5}, [5]),
        ({"minimum": 5, "exclusiveMinimum": True}, [4]),
        ({"maximum": 10, "exclusiveMaximum": True}, [11]),
        ({"required": ["a"]}, [{}]),
        ({"not": {}}, [None, True, False, "", 0, [None, None], {}]),
        ({"not": {"type": "null"}}, [None]),
    ],
)
def test_negative_primitive_schemas(nctx, schema, expected):
    covered = cover_schema(nctx, schema)
    if callable(expected):
        assert len(covered) == 1
        assert expected(covered[0])
    else:
        assert covered == expected
    assert_unique(covered)
    assert_not_conform(covered, schema)


@pytest.mark.parametrize(
    "schema",
    [
        # `default: null` — Python `None` after JSON load. Must round-trip through the `null`
        # type branch and not be skipped as "absent". Sentinel-based read ensures that.
        {"type": ["string", "null"], "default": None},
        {"type": ["integer", "null"], "example": None},
    ],
)
def test_positive_null_default_or_example_round_trips(pctx, schema):
    covered = [v.value for v in cover_schema_iter(pctx, schema)]
    assert None in covered, f"`null` default/example was dropped: {covered!r}"


def test_unbounded_array_positive_baseline_is_non_empty(pctx):
    # An empty list never exercises items-level keywords on the wire; coverage must emit a populated baseline first.
    covered = cover_schema(pctx, {"type": "array", "items": {"type": "integer", "format": "int32"}})
    assert covered
    assert covered[0], covered


@pytest.mark.parametrize(
    "location",
    [ParameterLocation.QUERY, ParameterLocation.HEADER, ParameterLocation.BODY],
    ids=["query", "header", "body"],
)
def test_negative_type_string_for_integer_is_non_empty(ctx_factory, location):
    # `_negative_type` draws `st.text()` for the string-type negative on a non-string
    # parameter; Hypothesis shrinks to "" and `_is_not_numeric_string` passes it through.
    # `?param=` / empty header / empty body collapse to absent on the wire, so the
    # negative can't demonstrate a type violation against the declared `integer` type.
    ctx = ctx_factory(generation_modes=[GenerationMode.NEGATIVE], location=location)
    values = [v.value for v in cover_schema_iter(ctx, {"type": "integer", "format": "int32"})]
    assert "" not in values, f"{location}: empty string emitted as string-type negative; got {values!r}"


@pytest.mark.parametrize("allow_extra_parameters", [True, False])
def test_query_unexpected_parameters_control(ctx_factory, allow_extra_parameters):
    schema = {
        "type": "object",
        "properties": {"token": {"type": "string"}},
        "required": ["token"],
        "additionalProperties": False,
    }
    ctx = ctx_factory(generation_modes=[GenerationMode.NEGATIVE], allow_extra_parameters=allow_extra_parameters)
    scenarios = {value.scenario for value in cover_schema_iter(ctx, schema) if isinstance(value, GeneratedValue)}
    if allow_extra_parameters:
        assert CoverageScenario.OBJECT_UNEXPECTED_PROPERTIES in scenarios
    else:
        assert CoverageScenario.OBJECT_UNEXPECTED_PROPERTIES not in scenarios


@pytest.mark.parametrize("allow_extra_parameters", [True, False])
def test_body_unexpected_parameters_control(ctx_factory, allow_extra_parameters):
    schema = {
        "type": "object",
        "properties": {"token": {"type": "string"}},
        "required": ["token"],
        "additionalProperties": False,
    }
    ctx = ctx_factory(
        location=ParameterLocation.BODY,
        generation_modes=[GenerationMode.NEGATIVE],
        allow_extra_parameters=allow_extra_parameters,
    )
    scenarios = {value.scenario for value in cover_schema_iter(ctx, schema) if isinstance(value, GeneratedValue)}
    if allow_extra_parameters:
        assert CoverageScenario.OBJECT_UNEXPECTED_PROPERTIES in scenarios
    else:
        assert CoverageScenario.OBJECT_UNEXPECTED_PROPERTIES not in scenarios


@pytest.mark.parametrize(
    ("schema", "lengths"),
    [
        ({"type": "string"}, {0}),
        ({"type": "string", "example": "test"}, {4}),
        ({"type": "string", "example": "test", "default": "test"}, {4}),
        ({"type": "string", "example": "test", "default": "another"}, {4, 7}),
        ({"type": "string", "default": "test"}, {4}),
        ({"type": "string", "examples": ["A", "BB"]}, {1, 2}),
        ({"type": "string", "minLength": 0}, {0}),
        ({"type": "string", "pattern": "^[\\w\\W]+$"}, {1}),
        ({"type": "string", "minLength": 5}, {5, 6}),
        ({"type": "string", "maxLength": 10}, {9, 10}),
        ({"type": "string", "minLength": 5, "maxLength": 10}, {5, 6, 9, 10}),
        ({"type": "string", "minLength": 5, "maxLength": 6}, {5, 6}),
        ({"type": "string", "minLength": 5, "maxLength": 5}, {5}),
        ({"type": "string", "minLength": 0, "maxLength": 512, "pattern": r"^[\w\W]+$"}, {1}),
        # Nullable string: union type must not leak into boundary generation,
        # otherwise hypothesis-jsonschema may pick null and skip both length variants.
        ({"type": ["string", "null"], "maxLength": 10}, {9, 10}),
        ({"type": ["string", "null"], "minLength": 5, "maxLength": 10}, {5, 6, 9, 10}),
        # Falsy `default`/`example` are still set: empty string must be exercised.
        ({"type": "string", "default": ""}, {0}),
        ({"type": "string", "example": ""}, {0}),
        # Falsy `default` alongside truthy `examples`: both must be emitted.
        ({"type": "string", "default": "", "examples": ["a"]}, {0, 1}),
    ],
)
def test_positive_string(ctx, schema, lengths):
    covered = list(_positive_string(ctx, schema))
    assert_unique(covered)
    for length in lengths:
        assert len([x for x in covered if isinstance(x.value, str) and len(x.value) == length]) == 1
    for value in covered:
        assert isinstance(value.value, str), f"non-string from _positive_string: {value.value!r}"
    assert_conform(covered, schema)


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        # Too permissing - all values will be stringified anyway
        ({"type": "string"}, []),
        ({"type": "string", "minLength": 5}, [0, "true", "null", "0000"]),
        ({"type": "string", "maxLength": 10}, [ANY, ANY, "00000000000"]),
        (
            {"type": "string", "minLength": 5, "maxLength": 10},
            [ANY, "true", "null", ["null", "null"], "0000", "00000000000"],
        ),
        (
            {"type": "string", "pattern": "^[0-9]", "minLength": 1},
            [ANY, ANY, "false", "null", ["null", "null"], AnyString(), ""],
        ),
        ({"type": "string", "pattern": "^[0-9]"}, [ANY, ANY, "false", "null", ["null", "null"], AnyString()]),
        ({"type": "string", "format": "date-time"}, [0, "false", "null", ["null", "null"], ""]),
    ],
)
def test_negative_string(nctx, schema, expected):
    covered = cover_schema(nctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_not_conform(covered, schema)


def test_negative_string_with_pattern(nctx):
    schema = {
        "type": "string",
        "minLength": 5,
        "maxLength": 8,
        "pattern": r"^[\da-z]+$",
    }
    covered = cover_schema(nctx, schema)
    assert covered in [
        [0, "false", "null", ["null", "null"], "0000", "000000000", AnyString()],
        [0, "true", "null", ["null", "null"], "0000", "000000000", AnyString()],
    ]
    assert_unique(covered)
    assert_not_conform(covered, schema)


def test_negative_maxitems_when_unique_items_exhaust_enum(nctx):
    # `uniqueItems: true` + `items.enum` of size `maxItems` makes a length-(max+1) unique
    # array unsatisfiable. The maxItems negative is still meaningful (server may reject
    # on length first), so emit one with duplicates from the enum domain.
    schema = {
        "type": "array",
        "uniqueItems": True,
        "minItems": 1,
        "maxItems": 11,
        "items": {"type": "string", "enum": ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"]},
    }
    above_max = [
        value.value
        for value in cover_schema_iter(nctx, schema)
        if isinstance(value, GeneratedValue) and value.scenario is CoverageScenario.ARRAY_ABOVE_MAX_ITEMS
    ]
    assert above_max, "Expected an above-maxItems negative case"
    assert all(len(v) == 12 for v in above_max)
    assert all(item in schema["items"]["enum"] for v in above_max for item in v)


def test_negative_pattern_for_header_with_permissive_pattern(ctx_factory):
    # `^[A-Z0-9_]*$` accepts the empty string; the negative emitter must still find one
    # header-safe value that violates the pattern.
    ctx = ctx_factory(location=ParameterLocation.HEADER, generation_modes=[GenerationMode.NEGATIVE])
    schema = {"type": "string", "pattern": "^[A-Z0-9_]*$"}
    out = [
        v.value
        for v in cover_schema_iter(ctx, schema)
        if isinstance(v, GeneratedValue) and v.scenario is CoverageScenario.INVALID_PATTERN
    ]
    assert out, "Expected at least one pattern-violation negative for header parameter"
    compiled = re.compile(schema["pattern"])
    for value in out:
        assert isinstance(value, str)
        assert not compiled.fullmatch(value), f"Value {value!r} matches the pattern"


def test_negative_maxlength_emitted_with_unsatisfiable_pattern(nctx):
    # An unsatisfiable `pattern` would block the length-violation generator; the maxLength
    # rule is still server-side enforceable, so emit a too-long string even if it also
    # violates the broken pattern.
    schema = {"type": "string", "maxLength": 90, "minLength": 1, "pattern": r" ^[-\w\._\(\)]+[^\.]$"}
    above_max = [
        v.value
        for v in cover_schema_iter(nctx, schema)
        if isinstance(v, GeneratedValue) and v.scenario is CoverageScenario.STRING_ABOVE_MAX_LENGTH
    ]
    assert above_max, "Expected an above-maxLength negative case"
    assert all(len(s) == 91 for s in above_max)


@pytest.mark.parametrize(
    "schema",
    [
        {"type": "string", "format": "email", "minLength": 6},
        {"type": "string", "format": "uuid", "minLength": 50},
    ],
    ids=["email", "uuid"],
)
def test_negative_minlength_emitted_with_constraining_format(nctx, schema):
    # No valid email of length 5; the minLength violation must still be emitted.
    below_min = [
        v.value
        for v in cover_schema_iter(nctx, schema)
        if isinstance(v, GeneratedValue) and v.scenario is CoverageScenario.STRING_BELOW_MIN_LENGTH
    ]
    assert below_min, "Expected a below-minLength negative case"
    assert all(isinstance(s, str) and len(s) == schema["minLength"] - 1 for s in below_min)


def test_negative_maxlength_emitted_with_constraining_format(nctx):
    # uuid is fixed at 36 chars; the 11-char maxLength violation must still be emitted.
    schema = {"type": "string", "format": "uuid", "maxLength": 10}
    above_max = [
        v.value
        for v in cover_schema_iter(nctx, schema)
        if isinstance(v, GeneratedValue) and v.scenario is CoverageScenario.STRING_ABOVE_MAX_LENGTH
    ]
    assert above_max, "Expected an above-maxLength negative case"
    assert all(isinstance(s, str) and len(s) == 11 for s in above_max)


def test_negative_maxlength_emitted_with_constraining_format_large_limit(nctx):
    # unknown format can't produce a 2001-char string; the violation must still be emitted.
    schema = {"type": "string", "format": "duration", "maxLength": 2000, "minLength": 1}
    above_max = [
        v.value
        for v in cover_schema_iter(nctx, schema)
        if isinstance(v, GeneratedValue) and v.scenario is CoverageScenario.STRING_ABOVE_MAX_LENGTH
    ]
    assert above_max, "Expected an above-maxLength negative case"
    assert all(isinstance(s, str) and len(s) == 2001 for s in above_max)


@pytest.mark.parametrize("max_length", [65536, 350000])
def test_negative_maxlength_above_buffer(nctx, max_length):
    schema = {"type": "string", "maxLength": max_length}
    above_max = [
        value.value
        for value in cover_schema_iter(nctx, schema)
        if isinstance(value, GeneratedValue) and value.scenario is CoverageScenario.STRING_ABOVE_MAX_LENGTH
    ]
    assert len(above_max) == 1
    assert len(above_max[0]) == max_length + 1


@pytest.mark.parametrize("multiple_of", [None, 2])
@pytest.mark.parametrize(
    ("schema", "values", "with_multiple_of"),
    [
        ({"type": "integer"}, [0], [0]),
        ({"type": "integer", "example": 2}, [2], [2]),
        ({"type": "integer", "example": 2, "default": 2}, [2], [2]),
        ({"type": "integer", "example": 2, "default": 4}, [2, 4], [2, 4]),
        ({"type": "integer", "default": 2}, [2], [2]),
        # `default: 0` / `example: 0` are valid spec hints; falsy must not skip them.
        ({"type": "integer", "default": 0}, [0], [0]),
        ({"type": "integer", "example": 0}, [0], [0]),
        # Falsy `default` alongside truthy `examples`: both must be emitted.
        ({"type": "integer", "default": 0, "examples": [1]}, [1, 0], [0]),
        ({"type": "integer", "examples": [42, 44]}, [42, 44], [42, 44]),
        ({"type": "number"}, [0], [0]),
        ({"type": "integer", "minimum": 5}, [5, 6], [6, 8]),
        ({"type": "number", "minimum": 5.5}, [5.5, 6.5], [6, 8]),
        ({"type": "integer", "maximum": 10}, [10, 9], [10, 8]),
        ({"type": "number", "maximum": 11.5}, [11.5, 10.5], [10, 8]),
        ({"type": "integer", "minimum": 5, "maximum": 10}, [5, 6, 10, 9], [6, 8, 10]),
        ({"type": "integer", "minimum": 5, "maximum": 6}, [5, 6], [6]),
        ({"type": "integer", "minimum": 5, "maximum": 5}, [5], None),
        (
            {"type": "integer", "minimum": 0, "exclusiveMinimum": False, "maximum": 30, "exclusiveMaximum": False},
            [0, 1, 30, 29],
            [0, 2, 30, 28],
        ),
        (
            {"type": "integer", "minimum": 0, "exclusiveMinimum": True, "maximum": 30, "exclusiveMaximum": True},
            [1, 2, 29, 28],
            [2, 4, 28, 26],
        ),
        (
            {"type": "number", "minimum": 0, "exclusiveMinimum": True, "maximum": 1, "exclusiveMaximum": True},
            [nextafter(0.0, inf), nextafter(1.0, -inf)],
            [],
        ),
        ({"type": "integer", "exclusiveMinimum": 5}, [6, 7], [6, 8]),
        ({"type": "integer", "exclusiveMaximum": 10}, [9, 8], [8, 6]),
        ({"type": "integer", "exclusiveMinimum": 5, "exclusiveMaximum": 10}, [6, 7, 9, 8], [6, 8]),
    ],
)
def test_positive_number(ctx, schema, multiple_of, values, with_multiple_of):
    if with_multiple_of is None and multiple_of is not None:
        pytest.skip("This test is not applicable for multiple_of=None")
    if multiple_of is not None:
        schema = {**schema, "multipleOf": multiple_of}
        values = with_multiple_of
    covered = [value.value for value in _positive_number(ctx, schema)]
    assert_unique(covered)
    assert covered == values
    assert_conform(covered, schema)


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        ({"type": "object"}, [{}]),
        ({"type": "object", "example": {"A": 42}}, [{"A": 42}]),
        ({"type": "object", "example": {"A": 42}, "default": {"A": 42}}, [{"A": 42}]),
        ({"type": "object", "example": {"A": 42}, "default": {"A": 43}}, [{"A": 42}, {"A": 43}]),
        ({"type": "object", "default": {"A": 42}}, [{"A": 42}]),
        ({"type": "object", "examples": [{"A": 42}, {"B": 43}]}, [{"A": 42}, {"B": 43}]),
        (
            {
                "type": "object",
                "properties": {"foo": True},
                "required": ["foo"],
            },
            [
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {"foo": {}},
                "required": ["foo"],
            },
            [
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
                {"foo": ANY},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {"foo": {"type": "integer", "example": 42}},
                "required": ["foo"],
            },
            [
                {"foo": 42},
            ],
        ),
        (
            {
                # No `type`
                "properties": {"foo": {"type": "integer", "example": 42}},
                "required": ["foo"],
            },
            [
                {"foo": 42},
            ],
        ),
        # Nested object declared with just `properties` (no `type: object`):
        # per-property example must lift into the template, not just appear in per-property variants.
        (
            {
                "type": "object",
                "properties": {
                    "settings": {"properties": {"active": {"type": "boolean", "example": True}}},
                },
                "required": ["settings"],
            },
            [
                {"settings": {"active": True}},
                {"settings": {}},
                {"settings": {"active": False}},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {"foo": {"type": "integer", "default": 42}},
                "required": ["foo"],
            },
            [
                {"foo": 42},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {"foo": {"type": "integer", "examples": [42, 43]}},
                "required": ["foo"],
            },
            [
                {"foo": 42},
                {"foo": 43},
            ],
        ),
        (
            {
                "type": "object",
                "required": ["foo"],
                "properties": {
                    "foo": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["bar"],
                            "properties": {
                                "bar": {
                                    "allOf": [
                                        {
                                            "type": "string",
                                        },
                                        {
                                            "minLength": 1,
                                            "maxLength": 100,
                                        },
                                    ]
                                },
                            },
                        },
                    }
                },
            },
            [
                {"foo": []},
                {
                    "foo": [
                        {
                            "bar": "0",
                        },
                    ],
                },
                {
                    "foo": [
                        {
                            "bar": "00",
                        },
                    ],
                },
                {
                    "foo": [
                        {
                            "bar": "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
                        },
                    ],
                },
                {
                    "foo": [
                        {
                            "bar": "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
                        },
                    ],
                },
            ],
        ),
        (
            {
                "type": "object",
                "required": ["foo"],
                "properties": {
                    "foo": {
                        "type": "array",
                        "items": {"type": "string"},
                    }
                },
            },
            [
                {"foo": []},
                {
                    "foo": [
                        "",
                    ],
                },
            ],
        ),
        (
            {
                "type": "object",
                "properties": {"foo": {"type": "integer"}, "bar": {"type": "string"}},
                "required": ["foo"],
            },
            [
                {"bar": "", "foo": 0},
                {"foo": 0},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {
                    "foo-1": {
                        "type": "object",
                        "properties": {"foo-2": {"type": "integer"}},
                    }
                },
                "required": ["foo-1"],
            },
            [
                {"foo-1": {"foo-2": 0}},
                {"foo-1": {}},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {
                    "foo-1": {
                        "type": "object",
                        "properties": {
                            "foo-2": {
                                "type": "object",
                                "properties": {
                                    "foo-3": {"type": "integer"},
                                },
                            },
                        },
                    }
                },
                "required": ["foo-1"],
            },
            [
                {"foo-1": {"foo-2": {"foo-3": 0}}},
                {"foo-1": {}},
                {"foo-1": {"foo-2": {}}},
            ],
        ),
        (
            {
                "type": "object",
                "properties": {
                    "foo-1": {"type": "integer", "minimum": 2},
                    "foo-2": {"type": "string", "minLength": 2},
                },
                "required": ["foo-1"],
            },
            [
                {"foo-1": 2, "foo-2": "00"},
                {"foo-1": 2},
                {"foo-1": 3, "foo-2": "00"},
                {"foo-1": 2, "foo-2": "000"},
            ],
        ),
        # 3 properties, 2 required
        (
            {
                "type": "object",
                "properties": {
                    "req1": {"type": "string"},
                    "req2": {"type": "integer"},
                    "opt1": {"type": "string"},
                },
                "required": ["req1", "req2"],
            },
            [
                {"req1": "", "req2": 0, "opt1": ""},
                {"req1": "", "req2": 0},
            ],
        ),
        # 6 properties, 2 required
        (
            {
                "type": "object",
                "properties": {
                    "req1": {"type": "string"},
                    "req2": {"type": "integer"},
                    "opt1": {"type": "string"},
                    "opt2": {"type": "number"},
                    "opt3": {"type": "array"},
                    "opt4": {"type": "boolean"},
                },
                "required": ["req1", "req2"],
            },
            [
                {"req1": "", "req2": 0, "opt1": "", "opt2": 0.0, "opt3": [None, None], "opt4": False},
                {"req1": "", "req2": 0, "opt1": ""},
                {"req1": "", "req2": 0, "opt2": 0.0},
                {"req1": "", "req2": 0, "opt3": [None, None]},
                {"req1": "", "req2": 0, "opt4": False},
                {"req1": "", "req2": 0, "opt1": "", "opt2": 0.0},
                {"req1": "", "req2": 0, "opt1": "", "opt2": 0.0, "opt3": [None, None]},
                {"req1": "", "req2": 0},
                {"opt1": "", "opt2": 0.0, "opt3": [None, None], "opt4": True, "req1": "", "req2": 0},
            ],
        ),
        # Nested object with optional properties
        (
            {
                "type": "object",
                "properties": {
                    "req1": {"type": "string"},
                    "opt1": {
                        "type": "object",
                        "properties": {
                            "nested_req": {"type": "integer"},
                            "nested_opt": {"type": "boolean"},
                        },
                        "required": ["nested_req"],
                    },
                },
                "required": ["req1"],
            },
            [
                {"req1": "", "opt1": {"nested_req": 0, "nested_opt": False}},
                {"req1": ""},
                {"req1": "", "opt1": {"nested_req": 0}},
                {"req1": "", "opt1": {"nested_req": 0, "nested_opt": True}},
            ],
        ),
        # Object with all optional properties
        (
            {
                "type": "object",
                "properties": {
                    "opt1": {"type": "string"},
                    "opt2": {"type": "integer"},
                    "opt3": {"type": "boolean"},
                },
            },
            [
                {"opt1": "", "opt2": 0, "opt3": False},
                {"opt1": ""},
                {"opt2": 0},
                {"opt3": False},
                {"opt1": "", "opt2": 0},
                {},
                {"opt1": "", "opt2": 0, "opt3": True},
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "maxItems": 5},
            [
                [0],
                [],
                [0, 0, 0, 0, 0],
                [0, 0, 0, 0],
            ],
        ),
        # Multi-branch items must be exercised individually; boundary-size arrays
        # repeat one branch and miss the other.
        (
            {
                "type": "array",
                "maxItems": 3,
                "items": {
                    "anyOf": [
                        {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["a"],
                            "properties": {"a": {"type": "string"}},
                        },
                        {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["b"],
                            "properties": {"b": {"type": "string"}},
                        },
                    ],
                },
            },
            [
                [{"a": ""}],
                [],
                [{"a": ""}, {"a": ""}, {"a": ""}],
                [{"a": ""}, {"a": ""}],
                [{"b": ""}],
            ],
        ),
        (
            {"type": "array", "items": {"enum": ["FOO"]}},
            [["FOO"], []],
        ),
        (
            {"type": "array", "items": {"enum": ["FOO"]}, "minItems": 1},
            [
                ["FOO"],
                ["FOO", "FOO"],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "example": [1, 2, 3]},
            [
                [1, 2, 3],
                [0],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "example": [1, 2, 3], "default": [1, 2, 3]},
            [
                [1, 2, 3],
                [0],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "example": [1, 2, 3], "default": [4, 5, 6]},
            [
                [1, 2, 3],
                [4, 5, 6],
                [0],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "default": [1, 2, 3]},
            [
                [1, 2, 3],
                [0],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "examples": [[1, 2, 3], [4, 5, 6]]},
            [
                [1, 2, 3],
                [4, 5, 6],
                [0],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "minItems": 2},
            [
                [0, 0],
                [0, 0, 0],
            ],
        ),
        (
            {"type": "array", "items": {"type": "integer"}, "minItems": 2, "maxItems": 5},
            [
                [0, 0],
                [0, 0, 0],
                [0, 0, 0, 0, 0],
                [0, 0, 0, 0],
            ],
        ),
        (
            {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {"foo": {"type": "integer", "minimum": 5}},
                    "required": ["foo"],
                },
                "minItems": 1,
                "maxItems": 2,
            },
            [
                [{"foo": 5}],
                [{"foo": 5}, {"foo": 5}],
                [{"foo": 6}],
            ],
        ),
        (
            {"type": "array", "items": [{"type": "integer"}, {"type": "string"}], "minItems": 2, "maxItems": 5},
            [
                [0, ""],
                [0, "", None],
                [0, "", None, None, None],
                [0, "", None, None],
            ],
        ),
        # Single anyOf subschema
        ({"anyOf": [{"type": "integer"}]}, [0]),
        ({"anyOf": [{"type": "boolean"}]}, [True, False]),
        # Multiple anyOf subschemas
        ({"anyOf": [{"type": "integer", "minimum": 2}, {"type": "boolean"}]}, [2, 3, True, False]),
        ({"anyOf": [{"type": "integer"}, {"type": "string"}]}, [0, ""]),
        ({"anyOf": [{"type": "boolean"}, {"type": "string"}]}, [True, False, ""]),
        # Nested anyOf
        (
            {
                "anyOf": [
                    {"type": "integer", "minimum": 2},
                    {
                        "anyOf": [
                            {"type": "boolean"},
                            {"type": "string"},
                        ]
                    },
                ]
            },
            [2, 3, True, False, ""],
        ),
        (
            {
                "anyOf": [
                    {"type": "integer", "minimum": 2},
                    {
                        "anyOf": [
                            {"type": "boolean"},
                            {"type": "string"},
                            {"type": "null"},
                        ]
                    },
                ]
            },
            [2, 3, True, False, "", None],
        ),
        # anyOf with other keywords
        (
            {
                "anyOf": [
                    {"type": "integer", "minimum": 5},
                    {"type": "integer", "maximum": 10},
                ]
            },
            [5, 6, 10, 9],
        ),
        # Single allOf subschema
        ({"allOf": [{"type": "integer"}]}, [0]),
        ({"allOf": [{"type": "boolean"}]}, [True, False]),
        # Multiple allOf subschemas
        (
            {
                "allOf": [
                    {"type": "integer"},
                    {"minimum": 5},
                ]
            },
            [5, 6],
        ),
        (
            {
                "allOf": [
                    {"type": "string"},
                    {"minLength": 3},
                ]
            },
            ["000", "0000"],
        ),
        (
            {
                "allOf": [
                    {"type": "integer"},
                    {"minimum": 5},
                    {"maximum": 10},
                ]
            },
            [5, 6, 10, 9],
        ),
        # Nested allOf
        (
            {
                "allOf": [
                    {"type": "integer"},
                    {
                        "allOf": [
                            {"minimum": 5},
                            {"maximum": 10},
                        ]
                    },
                ]
            },
            [5, 6, 10, 9],
        ),
        (
            {
                "allOf": [
                    {"type": "string"},
                    {
                        "allOf": [
                            {"minLength": 3},
                            {"maxLength": 5},
                        ]
                    },
                ]
            },
            ["000", "0000", "00000"],
        ),
        # allOf with other keywords
        (
            {
                "allOf": [
                    {"type": "integer"},
                    {"minimum": 5},
                    {"maximum": 10},
                ],
                "exclusiveMinimum": 5,
            },
            [6, 7, 10, 9],
        ),
        # Unsatisfiable allOf - PCRE pattern not supported by Python regex
        (
            {
                "allOf": [
                    {"type": "string", "pattern": "^\\p{Alnum}$"},
                    {"maxLength": 160},
                ]
            },
            [],
        ),
        # Unsatisfiable allOf - invalid pattern type
        (
            {
                "allOf": [
                    {"type": "string", "pattern": 0.0},
                    {"maxLength": 160},
                ]
            },
            [],
        ),
    ],
)
def test_positive_other(pctx, schema, expected):
    covered = cover_schema(pctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_conform(covered, schema)


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        (
            # These are query parameters and strings are not possible to negate
            {
                "properties": {
                    "foo": {"type": "string"},
                    "bar": {"type": "string"},
                },
                "required": ["foo", "bar"],
            },
            [
                {
                    "bar": "",
                },
                {
                    "foo": "",
                },
            ],
        ),
        (
            {
                "properties": {
                    "foo": {"type": "string", "maxLength": 3},
                    "bar": {"type": "string", "maxLength": 3},
                },
                "required": ["foo", "bar"],
            },
            [
                {
                    "foo": AnyNumber(),
                    "bar": "",
                },
                {
                    "foo": AnyNumber(),
                    "bar": "",
                },
                {
                    "bar": "",
                    "foo": "false",
                },
                {
                    "bar": "",
                    "foo": "null",
                },
                {
                    "bar": "",
                    "foo": ["null", "null"],
                },
                {
                    "bar": "",
                    "foo": "0000",
                },
                {
                    "bar": AnyNumber(),
                    "foo": "",
                },
                {
                    "bar": AnyNumber(),
                    "foo": "",
                },
                {
                    "bar": "false",
                    "foo": "",
                },
                {
                    "bar": "null",
                    "foo": "",
                },
                {
                    "bar": ["null", "null"],
                    "foo": "",
                },
                {
                    "bar": "0000",
                    "foo": "",
                },
                {
                    "bar": "",
                },
                {
                    "foo": "",
                },
            ],
        ),
        (
            {
                "properties": {
                    "foo": {"type": "string", "maxLength": 3},
                    "bar": {"type": "string", "maxLength": 3},
                },
            },
            [
                {
                    "bar": "",
                    "foo": AnyNumber(),
                },
                {
                    "bar": "",
                    "foo": AnyNumber(),
                },
                {
                    "bar": "",
                    "foo": "false",
                },
                {
                    "bar": "",
                    "foo": "null",
                },
                {
                    "bar": "",
                    "foo": ["null", "null"],
                },
                {
                    "bar": "",
                    "foo": "0000",
                },
                {
                    "bar": AnyNumber(),
                    "foo": "",
                },
                {
                    "bar": AnyNumber(),
                    "foo": "",
                },
                {
                    "bar": "false",
                    "foo": "",
                },
                {
                    "bar": "null",
                    "foo": "",
                },
                {
                    "bar": ["null", "null"],
                    "foo": "",
                },
                {
                    "bar": "0000",
                    "foo": "",
                },
            ],
        ),
        (
            {
                "properties": {
                    "foo": {"type": "string", "maxLength": 3},
                },
                "additionalProperties": False,
            },
            [
                {
                    "foo": AnyNumber(),
                },
                {
                    "foo": AnyNumber(),
                },
                {
                    "foo": "false",
                },
                {
                    "foo": "null",
                },
                {
                    "foo": ["null", "null"],
                },
                {
                    "foo": "0000",
                },
                {
                    "foo": "",
                    "x-schemathesis-unknown-property": 42,
                },
            ],
        ),
    ],
)
def test_negative_objects(nctx, schema, expected):
    covered = cover_schema(nctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_not_conform(covered, schema)


SCHEMA_WITH_PATTERN = {"minLength": 2, "pattern": "^A{2}$"}


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        # Top-level pattern
        (SCHEMA_WITH_PATTERN, ["A", "00"]),
        # Pattern inside properties
        ({"properties": {"username": SCHEMA_WITH_PATTERN}}, [{"username": "A"}, {"username": "00"}]),
        # Pattern inside items
        ({"items": SCHEMA_WITH_PATTERN}, [["A"], ["00"]]),
        # Pattern inside nested properties
        (
            {
                "properties": {"user": {"properties": {"id": SCHEMA_WITH_PATTERN}}},
            },
            [{"user": {"id": "A"}}, {"user": {"id": "00"}}],
        ),
        # Pattern inside items of an array property
        (
            {
                "properties": {"tags": {"items": SCHEMA_WITH_PATTERN}},
            },
            [{"tags": ["A"]}, {"tags": ["00"]}],
        ),
        # Multiple patterns in different locations
        (
            {
                "properties": {
                    "id": SCHEMA_WITH_PATTERN,
                    "items": {"items": SCHEMA_WITH_PATTERN},
                },
                "patternProperties": {"^meta_": SCHEMA_WITH_PATTERN},
            },
            [
                {"id": "A", "items": None},
                {"id": "00", "items": None},
                {"id": None, "items": ["A"]},
                {"id": None, "items": ["00"]},
                {"id": None, "items": None, "meta_": "A"},
                {"id": None, "items": None, "meta_": "00"},
            ],
        ),
        # Pattern in combination with other keywords
        ({"pattern": "^A{2}$", "minLength": 3, "maxLength": 20}, ["000", "AA", "AA0000000000000000000"]),
        # Pattern inside allOf
        ({"allOf": [SCHEMA_WITH_PATTERN, {"minLength": 5}]}, ["AA", "00000"]),
    ],
)
def test_negative_pattern(nctx, schema, expected):
    covered = cover_schema(nctx, schema)
    assert covered == expected
    assert_unique(covered)


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        (
            {"type": "object", "propertyNames": {"maxLength": 3}},
            [0, "false", "null", "AAA", ["null", "null"], {"0000": ""}],
        ),
        (
            {"type": "object", "propertyNames": {"pattern": "^[a-z]+$"}},
            [0, "false", "null", "AAA", ["null", "null"], {"": ""}],
        ),
        (
            {"type": "object", "propertyNames": {"minLength": 3}},
            [0, "false", "null", "AAA", ["null", "null"], {"00": ""}],
        ),
    ],
)
def test_negative_property_names(nctx, schema, expected):
    covered = cover_schema(nctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_not_conform(covered, schema)
    assert_not_conform(covered, schema)


def test_positive_pattern(pctx):
    schema = {"pattern": r"^[a-zA-Z0-9]{2,4}-\d{4,15}$", "minLength": 7, "maxLength": 20, "type": "string"}
    covered = cover_schema(pctx, schema)
    assert covered == ["0000-0000", "00-0000", "00-00000", "0000-000000000000000", "000-000000000000000"]
    assert_unique(covered)
    assert_conform(covered, schema)


def test_positive_pattern_with_wildcard_prefix_and_digit_limit(pctx):
    # Regression: https://github.com/schemathesis/schemathesis/issues/3154
    # Pattern with `.*` prefix and bounded digit quantifier `{1,10}`.
    # st.from_regex(pattern) without fullmatch=True allowed strings with a trailing \n
    # (Python's `$` matches before \n; JSON Schema / ECMAScript `$` does not),
    # producing values that fail the schema but passed the Python-side filter,
    # causing the hook to see a schema-conformant value while the URL carried an
    # invalid one.
    schema = {"type": "string", "pattern": r"^.*Id,([0-9]{1,10})$"}
    covered = cover_schema(pctx, schema)
    assert_conform(covered, schema)


def test_positive_pattern_with_char_class_and_min_length(pctx):
    # Regression: update_quantifier can't encode minLength into patterns with bare
    # character classes like [a-z] (IN opcode). The .filter() safety net ensures
    # generated strings still respect minLength.
    schema = {"pattern": r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$", "minLength": 3, "type": "string"}
    covered = cover_schema(pctx, schema)
    for value in covered:
        assert len(value) >= 3, f"Generated string {value!r} violates minLength=3"


def test_apply_pattern_optimizations_skips_non_keyword_property_names():
    # JSON Schema meta-schemas (e.g. Kubernetes CRD `JSONSchemaProps`) declare sub-schemas
    # whose property *names* happen to be `pattern` / `minLength` / `maxLength`. The walker
    # must skip these — they are sub-schema dicts, not regex strings / integer bounds.
    bundle = {
        "JSONSchemaProps": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "minLength": {"type": "integer", "format": "int64"},
                "maxLength": {"type": "integer", "format": "int64"},
            },
        }
    }
    _apply_pattern_optimizations(bundle, update_quantifier)


def test_negative_pattern_with_incompatible_length(nctx):
    schema = {
        "minLength": 6,
        "maxLength": 20,
        "pattern": "^[a-zA-Z]{4}-\\d{4,15}$",
    }
    covered = cover_schema(nctx, schema)
    assert covered == ["AAAA-", "AAAA-0000000000000000", "000000"]
    assert_unique(covered)
    assert_not_conform(covered, schema)


def test_negative_multiple_types(nctx):
    schema = {"type": ["integer", "number", "string"]}
    assert not cover_schema(nctx, schema)


def test_positive_multiple_types(pctx):
    # Nullable date-time: string branch must honour `format` (null branch yields `None`).
    schema = {"type": ["string", "null"], "format": "date-time"}
    covered = cover_schema(pctx, schema)
    assert covered == [AnyString(), None]
    assert_conform(covered, schema)


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        (
            {
                "allOf": [
                    {"minimum": 5},
                ],
            },
            [4],
        ),
        (
            {
                "allOf": [
                    {"type": "integer"},
                    {"minimum": 5},
                ],
            },
            [4, AnyNumber(), "false", "null", "AAA", ["null", "null"]],
        ),
        (
            {
                "anyOf": [
                    {"minimum": 5},
                    {"type": "string"},
                ],
            },
            [4],
        ),
        (
            {
                "anyOf": [
                    {"minimum": 5},
                    {"type": "string", "maxLength": 5},
                ],
            },
            (
                [4, AnyNumber(), AnyNumber()],
                [4, AnyNumber()],
                [4],
            ),
        ),
        (
            {
                "allOf": [
                    {
                        "maxLength": 10,
                        "type": "string",
                    },
                    {
                        "anyOf": [
                            {"maxLength": 10},
                            {"type": "null"},
                        ]
                    },
                ]
            },
            # `aaaaaaaaaaa` is the synthesized maxLength violation when the merged allOf can't satisfy length-11.
            ["00000000000", "aaaaaaaaaaa", AnyNumber(), AnyNumber()],
        ),
        (
            {
                "allOf": [
                    {"type": "string", "pattern": 0.0},
                    {"maxLength": 160},
                ]
            },
            [],
        ),
    ],
)
def test_negative_combinators(nctx, schema, expected):
    covered = cover_schema(nctx, schema)
    for exp in expected if isinstance(expected, tuple) else (expected,):
        if covered == exp:
            assert_unique(covered)
            assert_not_conform(covered, schema)
            break
    else:
        pytest.fail(f"Expected value didn't match\nGot: {covered!r}\nExpected: {expected!r}")


@pytest.mark.parametrize(
    ["schema", "expected"],
    [
        (
            {
                "anyOf": [
                    {"type": "number"},
                    {"type": "null"},
                ]
            },
            [
                False,
                "AAA",
                [
                    None,
                    None,
                ],
                {},
            ],
        ),
        (
            {
                "oneOf": [
                    {"type": "number"},
                    {"type": "integer"},
                    {"type": "null"},
                ]
            },
            [
                False,
                "AAA",
                [
                    None,
                    None,
                ],
                {},
                # Matching both, "number" and "integer", hence invalid
                0,
            ],
        ),
    ],
)
def test_negative_one_of(schema, expected):
    # See GH-2975
    nctx = CoverageContext(
        root_schema=schema,
        location=ParameterLocation.BODY,
        media_type=("application", "json"),
        generation_modes=[GenerationMode.NEGATIVE],
        is_required=True,
        custom_formats=get_default_format_strategies(),
        validator_cls=jsonschema_rs.Draft202012Validator,
    )
    covered = cover_schema(nctx, schema)
    assert_not_conform(covered, schema)
    assert covered == expected


@pytest.mark.parametrize(
    "pattern",
    [
        "^[A-Za-z0-9]$|^[A-Za-z0-9][\\w-\\.]*[A-Za-z0-9]$",
        "^[-._\\p{L}\\p{N}]+$",
    ],
)
@pytest.mark.filterwarnings("ignore::UserWarning")
def test_unsupported_patterns(nctx, pattern):
    covered = cover_schema(nctx, {"type": "string", "pattern": pattern})
    assert covered == []
    assert not cover_schema(nctx, {"patternProperties": {pattern: {"type": "string"}}})


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        ({"type": "integer", "format": "int32"}, [0]),
        ({"type": "string", "format": "unknown"}, [""]),
    ],
)
def test_ignoring_unknown_formats(pctx, schema, expected):
    covered = cover_schema(pctx, schema)
    assert covered == expected


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        ({"type": "string", "minLength": 5, "maxLength": 10}, {"/minLength", "/maxLength", "/type"}),
        ({"type": "number", "minimum": 0, "maximum": 100}, {"/minimum", "/maximum", "/type"}),
        (
            {"type": "array", "items": {"type": "string", "pattern": "^[a-z]+$"}},
            {"/items/pattern", "/items/type", "/type"},
        ),
        (
            {"type": "object", "properties": {"name": {"type": "string", "minLength": 3}}},
            {"/properties/name/minLength", "/type", "/properties/name/type"},
        ),
        ({"type": "string", "enum": ["red", "green", "blue"]}, {"/enum", "/type"}),
        (
            {"type": "object", "required": ["id"], "properties": {"id": {"type": "integer"}}},
            {"/required", "/type", "/properties/id/type"},
        ),
        ({"type": "string", "format": "email"}, {"/format", "/type"}),
        ({"anyOf": [{"type": "string"}, {"type": "number"}]}, {"/anyOf/1/type"}),
        (
            {"type": "object", "additionalProperties": False},
            {"/additionalProperties", "/type"},
        ),
        (
            {"type": "object", "patternProperties": {"^meta": {"type": "string"}}},
            {"/type"},
        ),
        (
            {
                "type": "object",
                "properties": {
                    "user": {
                        "type": "object",
                        "properties": {
                            "address": {"type": "object", "properties": {"street": {"type": "string", "minLength": 5}}}
                        },
                    }
                },
            },
            {
                "/properties/user/properties/address/properties/street/minLength",
                "/properties/user/properties/address/properties/street/type",
                "/properties/user/properties/address/type",
                "/properties/user/type",
                "/type",
            },
        ),
    ],
)
def test_negative_value_locations(nctx, schema, expected):
    assert {v.location for v in cover_schema_iter(nctx, schema)} == expected


@pytest.mark.parametrize(
    "ctx, expected",
    (
        (
            "pctx",
            [
                {"name": "0"},
                {"name": "00"},
                {"name": "0" * 4000},
                {"name": "0" * 3999},
            ],
        ),
        (
            "nctx",
            [
                {"name": "0" * 4001},
                {
                    "name": "",
                },
                {},
                0,
                "false",
                "null",
                "AAA",
                [
                    "null",
                    "null",
                ],
            ],
        ),
    ),
)
def test_generate_large_string(request, ctx, expected):
    ctx = request.getfixturevalue(ctx)
    schema = {
        "properties": {
            "name": {"maxLength": 4000, "minLength": 1, "pattern": "^[\\w\\W]+$", "type": "string"},
        },
        "required": ["name"],
        "type": "object",
    }
    assert cover_schema(ctx, schema) == expected


def test_generate_very_large_string(nctx):
    schema = {
        "properties": {
            "name": {"maxLength": 10000, "minLength": 1, "pattern": "^[\\w\\W]*$", "type": "string"},
        },
        "required": ["name"],
        "type": "object",
    }

    assert 10001 in {
        len(item["name"])
        for item in cover_schema(nctx, schema)
        if isinstance(item, dict) and isinstance(item.get("name"), str)
    }


def test_large_string_with_complex_pattern(nctx):
    schema = {
        "maxLength": 4000,
        "minLength": 1,
        "pattern": "^question\\.custom\\.[^,]+(?:,question\\.custom\\.[^,]+)*$",
        "type": "string",
    }
    assert cover_schema(nctx, schema) == [
        "0" * 4001,
        "",
        "0",
        0,
        "false",
        "null",
        [
            "null",
            "null",
        ],
    ]


def test_deeply_nested_values(pctx):
    schema = {
        "properties": {
            "customer": {
                "properties": {
                    "contacts": {
                        "properties": {
                            "contact": {
                                "items": {
                                    "properties": {
                                        "name": {
                                            "maxLength": 10,
                                            "minLength": 1,
                                            "type": "string",
                                        },
                                        "phone": {
                                            "items": {
                                                "properties": {
                                                    "phoneNumber": {
                                                        "maxLength": 15,
                                                        "minLength": 1,
                                                        "type": "string",
                                                    }
                                                },
                                                "type": "object",
                                            },
                                            "type": "array",
                                        },
                                    },
                                    "required": ["name"],
                                    "type": "object",
                                },
                                "type": "array",
                            }
                        },
                        "type": "object",
                    }
                },
                "type": "object",
            },
        },
        "type": "object",
    }
    assert cover_schema(pctx, schema) == [
        {
            "customer": {
                "contacts": {
                    "contact": [],
                },
            },
        },
        {},
        {
            "customer": {},
        },
        {
            "customer": {
                "contacts": {},
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                            "phone": [],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "00",
                            "phone": [],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0000000000",
                            "phone": [],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "000000000",
                            "phone": [],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                            "phone": [
                                {
                                    "phoneNumber": "0",
                                },
                            ],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                            "phone": [
                                {},
                            ],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                            "phone": [
                                {
                                    "phoneNumber": "00",
                                },
                            ],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                            "phone": [
                                {
                                    "phoneNumber": "000000000000000",
                                },
                            ],
                        },
                    ],
                },
            },
        },
        {
            "customer": {
                "contacts": {
                    "contact": [
                        {
                            "name": "0",
                            "phone": [
                                {
                                    "phoneNumber": "00000000000000",
                                },
                            ],
                        },
                    ],
                },
            },
        },
    ]


def test_large_arrays(nctx):
    schema = {
        "properties": {
            "questions": {
                "items": {
                    "properties": {
                        "id": {"minLength": 6, "pattern": "^[0-9]+$", "type": "string"},
                    },
                    "required": ["id"],
                    "type": "object",
                    "additionalProperties": False,
                },
                "maxItems": 500,
                "minItems": 0,
                "type": "array",
            },
        },
        "type": "object",
    }

    assert 501 in {
        len(item["questions"])
        for item in cover_schema(nctx, schema)
        if isinstance(item, dict) and isinstance(item["questions"], list)
    }


def test_large_arrays_nested(nctx):
    schema = {
        "properties": {
            "questions": {
                "items": {
                    "properties": {
                        "answers": {
                            "items": {
                                "type": "null",
                            },
                            "maxItems": 100,
                            "type": "array",
                        },
                        "id": {"minLength": 6, "pattern": "^[0-9]+$", "type": "string"},
                    },
                    "required": ["id"],
                    "type": "object",
                },
                "maxItems": 500,
                "minItems": 1,
                "type": "array",
            },
        },
        "required": ["questions"],
        "type": "object",
    }

    assert 501 in {
        len(item["questions"])
        for item in cover_schema(nctx, schema)
        if isinstance(item, dict) and isinstance(item.get("questions"), list)
    }


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        # Basic $ref to simple type in $defs
        (
            {"$defs": {"SimpleString": {"type": "string", "minLength": 2}}, "$ref": "#/$defs/SimpleString"},
            ["00", "000"],
        ),
        # $ref in object properties
        (
            {
                "$defs": {"UserId": {"type": "integer", "minimum": 1}},
                "type": "object",
                "properties": {"id": {"$ref": "#/$defs/UserId"}},
                "required": ["id"],
            },
            [{"id": 1}, {"id": 2}],
        ),
        # $ref in array items
        (
            {
                "$defs": {"Tag": {"type": "string", "enum": ["red", "blue"]}},
                "type": "array",
                "items": {"$ref": "#/$defs/Tag"},
            },
            [["red"], [], ["blue"]],
        ),
        # Nested $refs - reference pointing to another reference
        (
            {
                "$defs": {
                    "BaseString": {"type": "string"},
                    "LimitedString": {"allOf": [{"$ref": "#/$defs/BaseString"}, {"maxLength": 3}]},
                },
                "$ref": "#/$defs/LimitedString",
            },
            ["000", "00"],
        ),
        # $ref in combinators
        (
            {
                "$defs": {
                    "PositiveInt": {"type": "integer", "minimum": 1},
                    "NegativeInt": {"type": "integer", "maximum": -1},
                },
                "anyOf": [
                    {"$ref": "#/$defs/PositiveInt"},
                    {"$ref": "#/$defs/NegativeInt"},
                ],
            },
            [1, 2, -1, -2],
        ),
        # $ref to boolean schema
        (
            {
                "$defs": {"Anything": True},
                "$ref": "#/$defs/Anything",
            },
            [
                None,
                True,
                False,
                "",
                0,
                [
                    None,
                    None,
                ],
                {},
            ],
        ),
    ],
    ids=["basic", "properties", "array", "nested", "combinators", "bool"],
)
def test_positive_bundled_schema_refs(pctx, schema, expected):
    pctx.root_schema = schema
    covered = cover_schema(pctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_conform(covered, schema)


@pytest.mark.parametrize(
    ("schema", "expected"),
    [
        # Basic $ref negative case
        (
            {"$defs": {"PositiveInt": {"type": "integer", "minimum": 1}}, "$ref": "#/$defs/PositiveInt"},
            [AnyNumber(), "false", "null", "AAA", ["null", "null"], 0],
        ),
        # $ref in object properties - missing required property
        (
            {
                "$defs": {"RequiredString": {"type": "string", "minLength": 3}},
                "type": "object",
                "properties": {"name": {"$ref": "#/$defs/RequiredString"}},
                "required": ["name"],
            },
            [
                0,
                "false",
                "null",
                "AAA",
                ["null", "null"],
                {"name": 0},
                {"name": "00"},
                {},
            ],
        ),
        # $ref with complex validation
        (
            {
                "$defs": {"Email": {"type": "string", "format": "email", "maxLength": 10}},
                "type": "object",
                "properties": {"contact": {"$ref": "#/$defs/Email"}},
            },
            [
                0,
                "false",
                "null",
                "AAA",
                [
                    "null",
                    "null",
                ],
                {
                    "contact": 0,
                },
                {
                    "contact": "false",
                },
                {
                    "contact": "null",
                },
                {
                    "contact": [
                        "null",
                        "null",
                    ],
                },
                {"contact": ""},
                {"contact": AnyString()},
            ],
        ),
    ],
    ids=["basic", "properties", "nested"],
)
def test_negative_bundled_schema_refs(nctx, schema, expected):
    nctx.root_schema = schema
    covered = cover_schema(nctx, schema)
    assert covered == expected
    assert_unique(covered)
    assert_not_conform(covered, schema)


@pytest.mark.parametrize(
    ("schema", "min_expected_negative_count", "should_have_positive"),
    [
        # "not" schema: anything except strings with maxLength=10
        # Negative cases are values that MATCH the inner schema (strings ≤10 chars)
        ({"not": {"type": "string", "maxLength": 10}}, 1, True),
        # "not" schema: anything except null
        # Negative case is null (matches inner schema)
        ({"not": {"type": "null"}}, 1, True),
        # "not" schema with empty inner schema (nothing is valid)
        # All values match the empty schema, so all are negative for "not"
        # No positive cases possible (can't violate an empty schema)
        ({"not": {}}, 1, False),
        # "not" schema with type constraint
        # Negative case is an integer (matches inner schema)
        ({"not": {"type": "integer"}}, 1, True),
    ],
    ids=["maxLength", "null", "empty", "integer"],
)
def test_not_schema_generation_modes_consistency(
    ctx_factory, schema, min_expected_negative_count, should_have_positive
):
    # Test with NEGATIVE mode only
    nctx = ctx_factory(generation_modes=[GenerationMode.NEGATIVE])
    negative_mode_values = list(cover_schema_iter(nctx, schema))

    negative_only_negative = [v for v in negative_mode_values if v.generation_mode == GenerationMode.NEGATIVE]
    negative_only_positive = [v for v in negative_mode_values if v.generation_mode == GenerationMode.POSITIVE]

    # Test with ALL modes (both POSITIVE and NEGATIVE)
    all_ctx = ctx_factory(generation_modes=[GenerationMode.POSITIVE, GenerationMode.NEGATIVE])
    all_mode_values = list(cover_schema_iter(all_ctx, schema))

    all_negative = [v for v in all_mode_values if v.generation_mode == GenerationMode.NEGATIVE]
    all_positive = [v for v in all_mode_values if v.generation_mode == GenerationMode.POSITIVE]

    # NEGATIVE mode should generate the same negative cases as ALL mode
    negative_only_count = len(negative_only_negative)
    all_negative_count = len(all_negative)

    # Both should have at least the minimum expected negative count
    assert negative_only_count >= min_expected_negative_count, (
        f"Expected at least {min_expected_negative_count} negative cases in negative mode, "
        f"but got {negative_only_count}"
    )
    assert all_negative_count >= min_expected_negative_count, (
        f"Expected at least {min_expected_negative_count} negative cases in all mode, but got {all_negative_count}"
    )

    # The number of negative cases should be equal (the main bug we're testing)
    assert negative_only_count == all_negative_count, (
        f"Negative mode generated {negative_only_count} negative cases, "
        f"but all mode generated {all_negative_count} negative cases. "
    )

    # ALL mode should have additional positive cases when expected
    if should_have_positive:
        assert len(all_positive) > 0, "All mode should generate positive cases for 'not' schemas"

    # NEGATIVE mode should not generate positive cases when only negative mode is requested
    assert len(negative_only_positive) == 0, (
        f"Negative mode should not generate positive cases, but got {len(negative_only_positive)}"
    )


@pytest.mark.parametrize(
    ("schema", "ty"),
    [
        (
            {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]},
            "object",
        ),
        (
            {"type": "array", "items": {"type": "string"}, "minItems": 1},
            "array",
        ),
        (
            {"properties": {"name": {"type": "string"}}, "required": ["name"]},
            None,
        ),
    ],
    ids=["object", "array", "implicit-object"],
)
def test_cover_positive_for_type_skips_template_generation_in_negative_mode(ctx_factory, schema, ty, monkeypatch):
    ctx = ctx_factory(generation_modes=[GenerationMode.NEGATIVE])
    calls = 0
    original = CoverageContext.generate_from_schema

    def wrapped(self, schema):
        nonlocal calls
        calls += 1
        return original(self, schema)

    monkeypatch.setattr(CoverageContext, "generate_from_schema", wrapped)

    values = list(_cover_positive_for_type(ctx, schema, ty))

    assert values == []
    assert calls == 0


def test_generate_from_schema_uses_cache_and_returns_fresh_copy(ctx_factory, monkeypatch):
    ctx = ctx_factory(generation_modes=[GenerationMode.NEGATIVE])
    calls = 0

    def wrapped(self, strategy):
        nonlocal calls
        calls += 1
        return {"cached": True}

    monkeypatch.setattr(CoverageContext, "generate_from", wrapped)

    schema_1 = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "additionalProperties": {"type": "string"},
    }
    schema_2 = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "additionalProperties": {"type": "string"},
    }

    first = ctx.generate_from_schema(schema_1)
    first["mutated"] = True
    second = ctx.generate_from_schema(schema_2)

    assert calls == 1
    assert second == {"cached": True}


def test_generate_from_schema_reflects_bundle_mutations():
    schema = {
        "oneOf": [{"$ref": f"#/{BUNDLE_STORAGE_KEY}/schema1"}],
        BUNDLE_STORAGE_KEY: {"schema1": {"type": "integer"}},
    }

    def make_ctx() -> CoverageContext:
        return CoverageContext(
            root_schema=schema,
            location=ParameterLocation.QUERY,
            media_type=None,
            generation_modes=[GenerationMode.POSITIVE],
            is_required=True,
            custom_formats=get_default_format_strategies(),
            validator_cls=jsonschema_rs.Draft4Validator,
        )

    assert isinstance(make_ctx().generate_from_schema(schema), int)

    schema[BUNDLE_STORAGE_KEY]["schema1"] = {"type": "string"}

    assert isinstance(make_ctx().generate_from_schema(schema), str)


def test_generate_from_schema_caches_unsatisfiable_verdict(pctx):
    # JS-style `/.../`-wrapped pattern can never match; the second call must still raise
    # Unsatisfiable, served from the cached sentinel rather than re-running Hypothesis.
    schema = {"type": "string", "pattern": "/^x$/", "format": "date-time"}
    with pytest.raises(Unsatisfiable):
        pctx.generate_from_schema(schema)
    with pytest.raises(Unsatisfiable):
        pctx.generate_from_schema(schema)


def test_generate_from_schema_serves_cached_value(pctx):
    # Two calls on identical schema/context: second must equal the first, served from cache.
    assert pctx.generate_from_schema({"type": "string"}) == pctx.generate_from_schema({"type": "string"})


def test_items_false_with_prefix_items(pctx):
    schema = {
        "type": "array",
        "items": False,
        "prefixItems": [{"type": "string"}, {"type": "string"}],
    }
    covered = cover_schema(pctx, schema)
    assert_unique(covered)
    assert_conform(covered, schema)


def test_negative_prefix_items(nctx):
    schema = {
        "type": "array",
        "items": [{"type": "integer"}, {"type": "boolean"}],
    }
    covered = cover_schema(nctx, schema)
    assert_unique(covered)
    assert_not_conform(covered, schema)
    # Should have negative cases for each position
    arrays = [v for v in covered if isinstance(v, list)]
    assert len(arrays) > 0
    # Each array should have exactly 2 items (matching prefixItems length)
    for arr in arrays:
        assert len(arr) == 2


@pytest.mark.parametrize("keyword", ["anyOf", "oneOf"])
def test_anyof_oneof_with_items_as_list(nctx, keyword):
    schema = {
        "type": "object",
        "properties": {
            "data": {
                keyword: [
                    {"type": "array", "items": [{"type": "string"}]},
                    {"type": "null"},
                ]
            }
        },
    }
    covered = cover_schema(nctx, schema)
    assert_unique(covered)
    assert_not_conform(covered, schema)


def test_negative_binary_string_type_violation(ctx_factory):
    # Binary format strings should still generate non-string type violations
    ctx = ctx_factory(location=ParameterLocation.BODY, generation_modes=[GenerationMode.NEGATIVE])
    schema = {
        "type": "object",
        "properties": {
            "key": {"type": "string"},
            "value": {"type": "string", "format": "binary"},
        },
        "required": ["key", "value"],
    }
    covered = cover_schema(ctx, schema)
    assert_unique(covered)
    # Check that we generate non-string values for the binary property
    non_string_values = [
        v for v in covered if isinstance(v, dict) and "value" in v and not isinstance(v["value"], (str | bytes))
    ]
    assert len(non_string_values) > 0, "Should generate non-string type violations for binary format"
    assert_not_conform(covered, schema)


def test_negative_oneof_with_binary_format_items(ctx_factory):
    ctx = ctx_factory(location=ParameterLocation.BODY, generation_modes=[GenerationMode.NEGATIVE])
    schema = {
        "oneOf": [
            {
                "type": "array",
                "items": {"type": "string", "format": "binary"},
                "maxItems": 10,
            },
            {"type": "string"},
        ]
    }
    covered = cover_schema(ctx, schema)
    assert_unique(covered)


def test_anyof_with_required_constraints(pctx):
    # See GH-3520
    schema = {
        "type": "object",
        "anyOf": [
            {"required": ["name"]},
            {"required": ["id"]},
        ],
        "properties": {
            "type": {"type": "string"},
            "id": {"type": "string"},
            "name": {"type": "string"},
        },
    }
    covered = cover_schema(pctx, schema)
    assert covered == [
        {"type": "", "id": "", "name": ""},
        {"id": "", "name": ""},
        {"type": "", "name": ""},
        {"name": ""},
        {"type": "", "id": "", "name": ""},
        {"id": "", "name": ""},
        {"type": "", "id": ""},
        {"id": ""},
        {"id": "", "name": "", "type": ""},
        {"id": "", "name": ""},
        {"name": "", "type": ""},
        {"name": ""},
    ]
    assert_conform(covered, schema)


def test_merge_with_parent_context_bool_subschema(pctx):
    schema = {
        "type": "object",
        "anyOf": [
            True,
            {"required": ["name"]},
        ],
        "properties": {
            "name": {"type": "string"},
        },
    }
    covered = cover_schema(pctx, schema)
    object_values = [v for v in covered if isinstance(v, dict)]
    assert len(object_values) > 0
    assert_conform(object_values, schema)


def test_merge_with_parent_context_merges_required_lists(pctx):
    # Parent has `required` AND sub has `required` - the two lists get merged
    schema = {
        "type": "object",
        "required": ["type"],
        "anyOf": [
            {"required": ["name"]},
        ],
        "properties": {
            "type": {"type": "string"},
            "name": {"type": "string"},
        },
    }
    covered = cover_schema(pctx, schema)
    assert_conform(covered, schema)
    # The merged sub inherits "type" from parent and adds "name" from sub
    assert all("type" in v and "name" in v for v in covered if isinstance(v, dict))


def test_inline_sub_with_own_properties_is_self_contained(pctx):
    # An inline anyOf sub with its own `properties` is treated as a complete type,
    # just like a $ref to the same schema — parent properties are NOT injected into
    # the sub-schema generation path.
    schema = {
        "type": "object",
        "properties": {
            "parent_field": {"type": "string"},
        },
        "anyOf": [
            {
                "properties": {"id": {"type": "integer"}},
            },
        ],
    }
    covered = cover_schema(pctx, schema)
    assert_conform(covered, schema)
    # Sub is self-contained: generates {"id": 0} without parent_field injected.
    # Parent's own property path generates the other values independently.
    assert covered == [{"id": 0}, {}, {"parent_field": ""}, {}]


def test_with_effective_required_break_when_no_extra_fields(pctx):
    # break fires when the first dict sub-schema with `required` contributes no extra fields
    # because all its required fields are already in the parent's required list
    schema = {
        "type": "object",
        "required": ["name"],
        "anyOf": [
            {"required": ["name"]},  # "name" already required by parent -> extra=[] -> break
            {"required": ["id"]},  # never reached due to break above
        ],
        "properties": {
            "name": {"type": "string"},
            "id": {"type": "string"},
        },
    }
    covered = cover_schema(pctx, schema)
    assert_conform(covered, schema)
    # All positive values must include "name" (always required by parent)
    assert all("name" in v for v in covered if isinstance(v, dict))


def test_no_property_nesting_with_ref_oneof():
    # See GH-3584
    # Generated values for a schema with oneOf $ref sub-schemas
    # must not produce nested objects like {config: {config: {...}}}.
    schema = {
        "type": "object",
        "properties": {
            "config": {
                "oneOf": [
                    {"$ref": "#/x-bundled/schema1"},
                    {"$ref": "#/x-bundled/schema2"},
                ],
            },
        },
        "required": ["config"],
        "x-bundled": {
            "schema1": {
                "type": "object",
                "properties": {"value": {"type": "integer"}},
                "required": ["value"],
            },
            "schema2": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "required": ["name"],
            },
        },
    }
    ctx = CoverageContext(
        root_schema=schema,
        location=ParameterLocation.BODY,
        media_type=None,
        generation_modes=[GenerationMode.POSITIVE],
        is_required=True,
        custom_formats=get_default_format_strategies(),
        validator_cls=jsonschema_rs.Draft4Validator,
    )
    covered = cover_schema(ctx, schema)
    assert_conform(covered, schema)
    # Each oneOf branch generates its own type; no config key inside config values
    assert covered == [
        {"config": {"name": ""}},
        {"config": {"value": 0}},
    ]


def test_ref_with_sibling_keywords_does_not_inherit_parent_properties():
    schema = {
        "type": "object",
        "properties": {
            "config": {
                "oneOf": [
                    {
                        "$ref": "#/x-bundled/schema1",
                        "description": "line config variant",
                    }
                ],
            },
            "extra": {"type": "string"},
        },
        "required": ["config"],
        "x-bundled": {
            "schema1": {
                "type": "object",
                "properties": {"value": {"type": "integer"}},
                "required": ["value"],
            },
        },
    }
    ctx = CoverageContext(
        root_schema=schema,
        location=ParameterLocation.BODY,
        media_type=None,
        generation_modes=[GenerationMode.POSITIVE],
        is_required=True,
        custom_formats=get_default_format_strategies(),
        validator_cls=jsonschema_rs.Draft4Validator,
    )
    covered = cover_schema(ctx, schema)
    assert_conform(covered, schema)
    # Sibling keywords on $ref (description) don't affect resolution — schema1 generated directly
    # Parent properties (extra) appear at the outer object level, not injected inside config
    assert covered == [
        {"config": {"value": 0}, "extra": ""},
        {"config": {"value": 0}},
    ]


def test_ref_to_additive_schema_inherits_parent_properties():
    # A $ref sub-schema that resolves to a schema with NO properties of its own
    # (additive constraint only) SHOULD still inherit parent properties so the
    # generator knows the field definitions for required fields.
    # anyOf has two branches so parent-generated {"name": ""} satisfies the first branch.
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "id": {"type": "integer"},
        },
        "required": ["name"],
        "anyOf": [
            {"required": ["name"]},
            {"$ref": "#/x-bundled/extra_required"},
        ],
        "x-bundled": {
            "extra_required": {"required": ["id"]},
        },
    }
    ctx = CoverageContext(
        root_schema=schema,
        location=ParameterLocation.BODY,
        media_type=None,
        generation_modes=[GenerationMode.POSITIVE],
        is_required=True,
        custom_formats=get_default_format_strategies(),
        validator_cls=jsonschema_rs.Draft4Validator,
    )
    covered = cover_schema(ctx, schema)
    assert_conform(covered, schema)
    # Additive $ref (no properties) merges parent context — both name and id appear
    assert covered == [
        {"name": "", "id": 0},
        {"name": ""},
        {"name": "", "id": 0},
        {"id": 0, "name": ""},
        {"name": ""},
    ]


def test_negative_unique_items_on_scalar_param_emits_both_polarities(nctx):
    # Scalar params with `uniqueItems` need both duplicate and unique pairs to cover both polarities.
    schema = {"type": "integer", "uniqueItems": True}
    covered = [v for v in cover_schema(nctx, schema) if isinstance(v, list)]
    assert any(len(array) == 2 and array[0] == array[1] for array in covered), covered
    assert any(len(array) == 2 and array[0] != array[1] for array in covered), covered


def test_array_with_unique_items_enum_not_violated(pctx):
    schema = {
        "type": "array",
        "items": {"enum": ["A", "B", "C"]},
        "uniqueItems": True,
        "minItems": 3,
        "maxItems": 3,
    }
    covered = cover_schema(pctx, schema)
    # All generated arrays must be valid (no duplicate elements)
    assert_conform(covered, schema)
    # Each enum variant must appear as the first element in at least one array,
    # so every variant gets coverage
    first_elements = {arr[0] for arr in covered if arr}
    assert first_elements == {"A", "B", "C"}


def test_positive_if_then_else_emits_only_conforming_cases(ctx_factory):
    # Body context applies the parent-validator gate; query context skips it.
    pctx = ctx_factory(location=ParameterLocation.BODY, generation_modes=[GenerationMode.POSITIVE])
    original = {
        "type": "object",
        "properties": {"kind": {"type": "string"}, "value": {}},
        "required": ["kind"],
        "if": {"properties": {"kind": {"const": "number"}}},
        "then": {"properties": {"value": {"type": "integer"}}, "required": ["value"]},
        "else": {"properties": {"value": {"type": "string"}}, "required": ["value"]},
    }
    rewritten = transform(original, to_json_schema, nullable_keyword="x-nullable")
    validator = jsonschema_rs.Draft202012Validator(original)
    cases = [v.value for v in cover_schema_iter(pctx, rewritten)]
    invalid = [c for c in cases if not validator.is_valid(c)]
    assert not invalid, f"positive cases violate if/then/else: {invalid}"
    assert any(isinstance(c, dict) and c.get("kind") == "number" for c in cases), "then-branch case missing"
    assert any(isinstance(c, dict) and c.get("kind") != "number" for c in cases), "else-branch case missing"


def test_negative_if_then_else_violates_branches(ctx_factory):
    nctx = ctx_factory(location=ParameterLocation.BODY, generation_modes=[GenerationMode.NEGATIVE])
    original = {
        "type": "object",
        "properties": {"kind": {"type": "string"}, "value": {}},
        "required": ["kind"],
        "if": {"properties": {"kind": {"const": "number"}}},
        "then": {"properties": {"value": {"type": "integer"}}, "required": ["value"]},
        "else": {"properties": {"value": {"type": "string"}}, "required": ["value"]},
    }
    rewritten = transform(original, to_json_schema, nullable_keyword="x-nullable")
    validator = jsonschema_rs.Draft202012Validator(original)
    cases = [v.value for v in cover_schema_iter(nctx, rewritten)]
    invalid = [c for c in cases if isinstance(c, dict) and not validator.is_valid(c)]
    assert invalid, "no negative cases violate the conditional"


def test_negative_allof_with_unmergeable_branches_terminates(nctx):
    # `contains` with conflicting item types prevents canonicalish from merging the `allOf`.
    schema = {
        "allOf": [
            {"type": "object", "properties": {"arr": {"type": "array", "contains": {"type": "string"}}}},
            {"type": "object", "properties": {"arr": {"type": "array", "contains": {"type": "integer"}}}},
        ],
    }
    list(cover_schema_iter(nctx, schema))


def test_minitems_one_yields_empty_array_negative_with_unresolvable_items(nctx):
    schema = {"type": "array", "minItems": 1, "items": {"$ref": "#/components/schemas/Missing"}}
    negatives = [
        value.value
        for value in cover_schema_iter(nctx, schema)
        if isinstance(value, GeneratedValue) and value.scenario is CoverageScenario.ARRAY_BELOW_MIN_ITEMS
    ]
    assert negatives == [[]]


@pytest.mark.parametrize(
    ("schema", "expects_baseline"),
    [
        (
            {
                "type": "array",
                "items": {"type": "object"},
                "properties": {"key": {"type": "string"}, "value": {"type": "string"}},
                "required": ["key", "value"],
            },
            True,
        ),
        (
            {
                "type": ["array", "null"],
                "properties": {"x": {"type": "string"}},
                "required": ["x"],
            },
            True,
        ),
        (
            {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
            False,
        ),
        (
            {
                "type": ["object", "string"],
                "properties": {"x": {"type": "string"}},
                "required": ["x"],
            },
            False,
        ),
    ],
    ids=[
        "outer-array-excludes-object",
        "type-list-excludes-object",
        "type-object-includes-object",
        "type-list-includes-object",
    ],
)
def test_negative_properties_baseline_emission(ctx_factory, schema, expects_baseline):
    # Outer `type` excludes object -> emit a bare template alongside per-leaf negatives;
    # `type` includes object -> positive path already emits it, no double-counting.
    nctx = ctx_factory(location=ParameterLocation.BODY, generation_modes=[GenerationMode.NEGATIVE])
    inner_validator = jsonschema_rs.Draft7Validator(
        {
            "type": "object",
            "properties": schema["properties"],
            "required": schema["required"],
        }
    )
    cases = [value.value for value in cover_schema_iter(nctx, schema)]
    baselines = [c for c in cases if isinstance(c, dict) and inner_validator.is_valid(c)]
    if expects_baseline:
        assert baselines, f"no baseline emitted: {cases}"
        leaf_negatives = [c for c in cases if isinstance(c, dict) and not inner_validator.is_valid(c) and c != {}]
        assert leaf_negatives, f"per-leaf negatives lost: {cases}"
    else:
        assert baselines == [], f"unexpected baseline: {baselines}"


@pytest.mark.parametrize(
    "schema",
    [
        {"type": "array", "patternProperties": {"^x_": {"type": "string"}}},
        {"type": "array", "propertyNames": {"pattern": "^x_"}},
    ],
    ids=["patternProperties", "propertyNames"],
)
def test_negative_object_keyword_baseline_emission(ctx_factory, schema):
    # `_negative_type` already emits `{}` for `type: array`; the new baseline path emits a
    # second `{}`. Counting both guards against a regression in the baseline branch.
    nctx = ctx_factory(location=ParameterLocation.BODY, generation_modes=[GenerationMode.NEGATIVE])
    cases = [value.value for value in cover_schema_iter(nctx, schema)]
    assert cases.count({}) >= 2, f"baseline `{{}}` emission missing: {cases}"


def test_get_properties_resolves_ref_to_implied_object(pctx):
    # Without ref resolution, the nested value would be generated as any JSON value -- often `null`.
    schema = {
        "$defs": {
            "Inner": {
                "properties": {
                    "key": {"type": "string", "example": "myKey"},
                    "value": {"type": "string", "example": "myValue"},
                }
            }
        },
        "type": "object",
        "required": ["nested"],
        "properties": {"nested": {"$ref": "#/$defs/Inner"}},
    }
    pctx.root_schema = schema
    cases = [v.value for v in cover_schema_iter(pctx, schema)]
    populated = [c for c in cases if isinstance(c, dict) and isinstance(c.get("nested"), dict) and c["nested"]]
    assert populated, f"nested ref-to-object never materialized: {cases}"


def test_get_properties_preserves_required_outside_properties(pctx):
    # Required keys not declared in `properties` must still reach the generated template.
    schema = {
        "$defs": {
            "Inner": {
                "required": ["name"],
                "properties": {"value": {"type": "string"}},
            }
        },
        "type": "object",
        "required": ["nested"],
        "properties": {"nested": {"$ref": "#/$defs/Inner"}},
    }
    pctx.root_schema = schema
    cases = [v.value for v in cover_schema_iter(pctx, schema)]
    nested_objects = [c["nested"] for c in cases if isinstance(c, dict) and isinstance(c.get("nested"), dict)]
    assert nested_objects, f"no nested object emitted: {cases}"
    assert all("name" in n for n in nested_objects), f"required key dropped: {nested_objects}"
