from __future__ import annotations

import warnings
from collections.abc import Callable
from typing import Any, Final

from schemathesis.core.cache import MISSING, BoundedCache

# Sentinel cached when generation raised `Unsatisfiable`.
UNSATISFIABLE_RESULT: Final = object()
# Cross-operation cache for `CoverageContext.generate_from_schema`.
schema_generation_cache: Final[BoundedCache] = BoundedCache(maxsize=2048)
# Stable identity for per-(generation_config, mode) custom-format dicts, so downstream caches
# keyed on `id(custom_formats)` actually hit instead of seeing a fresh dict per call.
custom_formats_cache: Final[BoundedCache] = BoundedCache(maxsize=32)
_resolve_result_cache: Final[BoundedCache] = BoundedCache(maxsize=256)
_merged_result_cache: Final[BoundedCache] = BoundedCache(maxsize=512)
_canonicalish_result_cache: Final[BoundedCache] = BoundedCache(maxsize=2048)
_from_schema_result_cache: Final[BoundedCache] = BoundedCache(maxsize=512)
_merged_as_strategies_result_cache: Final[BoundedCache] = BoundedCache(maxsize=512)


def setup() -> None:
    import jsonschema_rs
    from hypothesis import core as root_core
    from hypothesis.errors import InvalidArgument
    from hypothesis.internal.conjecture import engine
    from hypothesis.internal.entropy import deterministic_PRNG
    from hypothesis.internal.reflection import is_first_param_referenced_in_function
    from hypothesis.strategies._internal import collections, core
    from hypothesis.vendor import pretty
    from hypothesis_jsonschema import _canonicalise, _encode, _from_schema, _resolve
    from hypothesis_jsonschema._canonicalise import SCHEMA_KEYS, SCHEMA_OBJECT_KEYS
    from hypothesis_jsonschema._canonicalise import merged as _original_merged

    from schemathesis.core import INTERNAL_BUFFER_SIZE
    from schemathesis.core.compat import RefResolutionError
    from schemathesis.core.errors import InvalidSchema
    from schemathesis.core.jsonschema import (
        BUNDLE_STORAGE_KEY,
        REFERENCE_TO_BUNDLE_PREFIX,
        make_validator,
        make_validator_for,
    )
    from schemathesis.core.jsonschema.types import JsonSchema, JsonSchemaObject, _get_type
    from schemathesis.core.transforms import UNRESOLVABLE, deepclone, resolve_pointer
    from schemathesis.generation._cache import schema_cache_key

    if getattr(setup, "_is_patched", False):
        return

    # Forcefully initializes Hypothesis' global PRNG to avoid races that initialize it
    # if e.g. Schemathesis CLI is used with multiple workers
    with deterministic_PRNG():
        pass

    # A set of performance-related patches
    _encode.encode_canonical_json = jsonschema_rs.canonical.json.to_string
    _canonicalise.encode_canonical_json = jsonschema_rs.canonical.json.to_string
    _from_schema.encode_canonical_json = jsonschema_rs.canonical.json.to_string

    # This one is used a lot, and under the hood it re-parses the AST of the same function
    def _is_first_param_referenced_in_function(f: Callable) -> bool:
        if f.__name__ == "from_object_schema" and f.__module__ == "hypothesis_jsonschema._from_schema":
            return True
        return is_first_param_referenced_in_function(f)

    core.is_first_param_referenced_in_function = _is_first_param_referenced_in_function

    class RepresentationPrinter(pretty.RepresentationPrinter):
        def pretty(self, obj: object) -> None:
            # This one takes way too much - in the coverage phase it may give >2 orders of magnitude improvement
            # depending on the schema size (~300 seconds -> 4.5 seconds in one of the benchmarks)
            return None

    class CacheableSchema:
        """Cache schema by its JSON representation.

        Canonicalisation is not required as schemas with the same JSON representation
        will have the same validator.
        """

        __slots__ = ("schema", "encoded", "serialized", "cache_key")

        def __init__(self, schema: JsonSchemaObject) -> None:
            self.schema = schema
            self.cache_key = schema_cache_key(schema)
            self.serialized = self.cache_key[1]
            self.encoded = hash(self.cache_key)

        def __eq__(self, other: object) -> bool:
            if not isinstance(other, CacheableSchema):
                return NotImplemented
            return self.cache_key == other.cache_key

        def __hash__(self) -> int:
            return self.encoded

    SCHEMA_KEYS = frozenset(SCHEMA_KEYS)
    SCHEMA_OBJECT_KEYS = frozenset(SCHEMA_OBJECT_KEYS)

    def _is_trivial_truthy(schema: object) -> bool:
        return schema is True or schema == {}

    def _canonicalish_checked(schema: JsonSchema) -> JsonSchemaObject:
        result = _canonicalise.canonicalish(schema)
        _canonicalise._get_validator_class(result)
        return result

    def _distribute_anyof(left: JsonSchemaObject, right: JsonSchemaObject) -> JsonSchemaObject | None:
        # `_original_merged` returns None for two distinct `anyOf` lists; distribute
        # the intersection over their branches and drop empty results.
        left_branches = left.get("anyOf")
        right_branches = right.get("anyOf")
        if not isinstance(left_branches, list) or not isinstance(right_branches, list):
            return None
        left_rest = {k: v for k, v in left.items() if k != "anyOf"}
        right_rest = {k: v for k, v in right.items() if k != "anyOf"}
        branches: list[dict[str, Any]] = []
        for left_branch in left_branches:
            for right_branch in right_branches:
                left_combined = {**left_rest, **left_branch} if isinstance(left_branch, dict) else left_branch
                right_combined = {**right_rest, **right_branch} if isinstance(right_branch, dict) else right_branch
                branch = _original_merged([left_combined, right_combined])
                if branch is not None and branch != _canonicalise.FALSEY:
                    branches.append(branch)
        if not branches:
            return None
        if len(branches) == 1:
            return branches[0]
        return {"anyOf": branches}

    def _merged(schemas: list[JsonSchema]) -> JsonSchemaObject | None:
        if len(schemas) > 1:
            filtered = [schema for schema in schemas if not _is_trivial_truthy(schema)]
            if not filtered:
                return {}
            if len(filtered) == 1:
                return _canonicalish_checked(filtered[0])
            schemas = filtered

        if len(schemas) == 2:
            try:
                cache_key = (schema_cache_key(schemas[0]), schema_cache_key(schemas[1]))
            except (TypeError, ValueError):
                cache_key = None
            if cache_key is not None:
                cached = _merged_result_cache.get(cache_key)
                if cached is not MISSING:
                    return deepclone(cached) if isinstance(cached, dict) else cached
                reversed_key = (cache_key[1], cache_key[0])
                cached = _merged_result_cache.get(reversed_key)
                if cached is not MISSING:
                    stored = deepclone(cached) if isinstance(cached, dict) else cached
                    _merged_result_cache[cache_key] = stored
                    return deepclone(stored) if isinstance(stored, dict) else stored

            result = _original_merged(schemas)
            if result is None and isinstance(schemas[0], dict) and isinstance(schemas[1], dict):
                result = _distribute_anyof(schemas[0], schemas[1])
            if cache_key is not None:
                _merged_result_cache[cache_key] = deepclone(result) if isinstance(result, dict) else None
            return result

        return _original_merged(schemas)

    _original_from_schema = _from_schema.__dict__["__from_schema"]
    _original_merged_as_strategies = _from_schema.merged_as_strategies

    def _ensure_canonical_constants() -> None:
        # hypothesis-jsonschema returns these by reference and downstream callers mutate them.
        if _canonicalise.FALSEY != {"not": {}}:
            _canonicalise.FALSEY.clear()
            _canonicalise.FALSEY["not"] = {}
        if _canonicalise.TRUTHY:
            _canonicalise.TRUTHY.clear()

    def _resolve_ref(root_schema: JsonSchemaObject, ref: str) -> object:
        if not ref:
            return root_schema
        if ref.startswith("#"):
            resolved = resolve_pointer(root_schema, ref[1:])
            if resolved is not UNRESOLVABLE:
                return resolved
        raise _canonicalise.HypothesisRefResolutionError(f"Could not resolve reference {ref!r}")

    def _cached_from_schema(schema: JsonSchema, *, alphabet: Any, custom_formats: Any) -> Any:
        _ensure_canonical_constants()
        try:
            key = (schema_cache_key(schema), id(alphabet), id(custom_formats))
        except (TypeError, ValueError):
            key = None

        if key is not None:
            cached = _from_schema_result_cache.get(key)
            if cached is not MISSING:
                return cached

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="Overriding standard format", category=Warning)
            try:
                strategy = _original_from_schema(schema, alphabet=alphabet, custom_formats=custom_formats)
            except InvalidArgument as exc:
                if isinstance(schema, dict) and schema.get("$schema") == "http://json-schema.org/draft-03/schema#":
                    raise InvalidSchema("Draft-03 JSON Schema is not supported") from exc
                raise

        if key is not None:
            _from_schema_result_cache[key] = strategy

        return strategy

    def _cached_merged_as_strategies(schemas: list[JsonSchema], *, alphabet: Any, custom_formats: Any) -> Any:
        try:
            schema_keys = tuple(schema_cache_key(schema) for schema in schemas)
            key = (schema_keys, id(alphabet), id(custom_formats))
        except (TypeError, ValueError):
            key = None

        if key is not None:
            cached = _merged_as_strategies_result_cache.get(key)
            if cached is not MISSING:
                return cached

        strategy = _original_merged_as_strategies(schemas, alphabet=alphabet, custom_formats=custom_formats)

        if key is not None:
            _merged_as_strategies_result_cache[key] = strategy

        return strategy

    def resolve_all_refs(
        schema: JsonSchema,
        *,
        root_schema: JsonSchemaObject | None = None,
    ) -> JsonSchemaObject:
        if schema is True:
            return {}
        if schema is False:
            return {"not": {}}
        if not schema:
            return schema

        _resolve_all_refs = resolve_all_refs
        top_level = root_schema is None
        cache_key: tuple[str, ...] | None = None

        if top_level:
            cacheable_schema = CacheableSchema(schema)
            # No need to traverse if there are no references
            if '"$ref"' not in cacheable_schema.serialized:
                return schema
            cache_key = cacheable_schema.cache_key
            cached = _resolve_result_cache.get(cache_key)
            if cached is not MISSING:
                return deepclone(cached)
            root_schema = schema

        assert root_schema is not None

        if "$ref" in schema:
            s = dict(schema)
            ref = s.pop("$ref")
            resolved = _resolve_ref(root_schema, ref)
            result = _merged(
                [
                    _resolve_all_refs(s, root_schema=root_schema),
                    _resolve_all_refs(deepclone(resolved), root_schema=root_schema),
                ]
            )
            if result is None:
                msg = f"$ref:{ref!r} had incompatible base schema {s!r}"
                raise _canonicalise.HypothesisRefResolutionError(msg)
            if cache_key is not None:
                _resolve_result_cache[cache_key] = deepclone(result)
            return result

        for key, value in schema.items():
            if key in SCHEMA_KEYS:
                if isinstance(value, list):
                    schema[key] = [
                        _resolve_all_refs(v, root_schema=root_schema) if isinstance(v, dict) else v for v in value
                    ]
                elif isinstance(value, dict):
                    schema[key] = _resolve_all_refs(value, root_schema=root_schema)
            if key in SCHEMA_OBJECT_KEYS:
                schema[key] = {
                    k: _resolve_all_refs(v, root_schema=root_schema) if isinstance(v, dict) else v
                    for k, v in value.items()
                }
        if cache_key is not None:
            _resolve_result_cache[cache_key] = deepclone(schema)
        return schema

    root_core.RepresentationPrinter = RepresentationPrinter
    _resolve.deepcopy = deepclone
    _resolve.resolve_all_refs = resolve_all_refs
    _from_schema.deepcopy = deepclone
    _from_schema.get_type = _get_type
    _from_schema.__dict__["__from_schema"] = _cached_from_schema
    _from_schema.merged_as_strategies = _cached_merged_as_strategies
    _from_schema.resolve_all_refs = resolve_all_refs
    _canonicalise.get_type = _get_type
    _canonicalise.CacheableSchema = CacheableSchema

    # Patch canonicalish to skip x-bundled during the deep-copy serialisation.
    _original_canonicalish = _canonicalise.canonicalish

    def _has_bundle_ref(obj: object) -> bool:
        if isinstance(obj, dict):
            ref = obj.get("$ref")
            if isinstance(ref, str) and ref.startswith(REFERENCE_TO_BUNDLE_PREFIX):
                return True
            return any(_has_bundle_ref(v) for v in obj.values())
        if isinstance(obj, list):
            return any(_has_bundle_ref(item) for item in obj)
        return False

    def _fast_canonicalish(schema: JsonSchema) -> JsonSchemaObject:
        try:
            cache_key = schema_cache_key(schema)
        except (TypeError, ValueError):
            cache_key = None

        if cache_key is not None:
            cached = _canonicalish_result_cache.get(cache_key)
            if cached is not MISSING:
                return deepclone(cached)

        if not isinstance(schema, dict) or BUNDLE_STORAGE_KEY not in schema:
            if isinstance(schema, dict):
                ref = schema.get("$ref")
                if isinstance(ref, str) and ref.startswith(REFERENCE_TO_BUNDLE_PREFIX) and len(schema) > 1:
                    return schema
            try:
                result = _original_canonicalish(schema)
            except RefResolutionError:
                # Bundle ref without the bundle root: only the deep resolution crashes;
                # the structural canonicalization that already happened is discarded.
                assert isinstance(schema, dict)
                return schema
            if cache_key is not None:
                _canonicalish_result_cache[cache_key] = deepclone(result)
            return result
        bundle = schema[BUNDLE_STORAGE_KEY]
        schema_without_bundle = {k: v for k, v in schema.items() if k != BUNDLE_STORAGE_KEY}
        schema_for_canonicalish = schema if _has_bundle_ref(schema_without_bundle) else schema_without_bundle
        result = _original_canonicalish(schema_for_canonicalish)
        # Restore x-bundled so downstream $ref resolution can find bundled schemas.
        if isinstance(result, dict) and result and result != {"not": {}}:
            result[BUNDLE_STORAGE_KEY] = bundle
        if cache_key is not None:
            _canonicalish_result_cache[cache_key] = deepclone(result)
        return result

    _canonicalise.canonicalish = _fast_canonicalish
    _from_schema.canonicalish = _fast_canonicalish
    _resolve.canonicalish = _fast_canonicalish
    _canonicalise.merged = _merged
    _from_schema.merged = _merged
    root_core.BUFFER_SIZE = INTERNAL_BUFFER_SIZE
    engine.BUFFER_SIZE = INTERNAL_BUFFER_SIZE
    collections.BUFFER_SIZE = INTERNAL_BUFFER_SIZE

    # Patch make_validator to use jsonschema-rs for instance validation
    from schemathesis.core.errors import is_regex_validation_error
    from schemathesis.transport.serialization import contains_binary

    _original_get_validator_class = _canonicalise._get_validator_class

    class _ValidatorWrapper:
        __slots__ = ("_validator",)

        def __init__(self, validator: jsonschema_rs.Validator) -> None:
            self._validator = validator

        def is_valid(self, value: object) -> bool:
            if contains_binary(value):
                return True
            return self._validator.is_valid(value)

    # `jsonschema_rs.validator_for` defaults to Draft 2020-12 when no `$schema` is present,
    # but hypothesis-jsonschema defaults to Draft 7. Schemas using Draft 4/7 features
    # (e.g. tuple `items`) are rejected by 2020-12, so we fall back through older drafts.
    # TODO: remove once hypothesis-jsonschema propagates the draft version consistently.
    def _make_rust_validator(schema: JsonSchemaObject) -> jsonschema_rs.Validator:
        last_error: jsonschema_rs.ValidationError | None = None
        try:
            return make_validator_for(schema)
        except jsonschema_rs.ValidationError as exc:
            last_error = exc
            if is_regex_validation_error(exc):
                raise

        for cls in (jsonschema_rs.Draft7Validator, jsonschema_rs.Draft4Validator):
            try:
                return make_validator(schema, cls)
            except jsonschema_rs.ValidationError as exc:
                last_error = exc
                if is_regex_validation_error(exc):
                    raise

        assert last_error is not None
        raise last_error

    def _make_wrapped_validator(schema: JsonSchemaObject) -> _ValidatorWrapper:
        try:
            validator = _make_rust_validator(schema)
            return _ValidatorWrapper(validator)
        except jsonschema_rs.ValidationError:
            # Either no Rust draft can compile this schema, or the regex engine differs.
            # In both cases fall back to the original Hypothesis validator.
            cls = _original_get_validator_class(schema)
            return _ValidatorWrapper(cls(schema))

    def _get_validator_class(schema: JsonSchemaObject) -> type[jsonschema_rs.Validator]:
        classes_to_try = [
            jsonschema_rs.validator_cls_for(schema),
            jsonschema_rs.Draft7Validator,
            jsonschema_rs.Draft4Validator,
        ]
        seen = set()
        last_error: jsonschema_rs.ValidationError | None = None

        for cls in classes_to_try:
            if cls in seen:
                continue
            seen.add(cls)
            try:
                make_validator(schema, cls)
                return cls
            except jsonschema_rs.ValidationError as exc:
                last_error = exc
                if is_regex_validation_error(exc):
                    # Keep the class selection from jsonschema-rs even when regex syntax differs.
                    return cls
                continue

        assert last_error is not None
        if last_error.kind.name == "$ref":
            # Unresolvable $ref — happens for intermediate sub-schemas that contain bundled
            # internal refs but have lost the bundle storage key during hypothesis-jsonschema's
            # merging. Fall back to Python; merged() discards the class anyway.
            return _original_get_validator_class(schema)
        raise last_error

    _canonicalise.make_validator = _make_wrapped_validator
    _from_schema.make_validator = _make_wrapped_validator
    _canonicalise._get_validator_class = _get_validator_class
    setup._is_patched = True  # type: ignore[attr-defined]
