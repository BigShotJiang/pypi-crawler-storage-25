#include "decklink_input.hpp"
#include <iostream>
#include <cstring>
#include <chrono>
#include <thread>

#ifdef __APPLE__
    #include <CoreFoundation/CoreFoundation.h>
#endif

namespace {
    constexpr int64_t kEOTF_SDR = 0;
    constexpr int64_t kEOTF_HDR_Traditional = 1;
    constexpr int64_t kEOTF_PQ = 2;  // SMPTE ST 2084
    constexpr int64_t kEOTF_HLG = 3;
}

class DeckLinkInputCallback : public IDeckLinkInputCallback {
public:
    DeckLinkInputCallback(DeckLinkInput* parent) : m_parent(parent), m_refCount(1) {}

    virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, LPVOID* ppv) override {
#ifdef __APPLE__
        CFUUIDBytes iunknown = CFUUIDGetUUIDBytes(IUnknownUUID);
        if (memcmp(&iid, &iunknown, sizeof(REFIID)) == 0) {
            *ppv = static_cast<IDeckLinkInputCallback*>(this);
        } else if (memcmp(&iid, &IID_IDeckLinkInputCallback, sizeof(REFIID)) == 0) {
            *ppv = static_cast<IDeckLinkInputCallback*>(this);
        } else {
            *ppv = nullptr;
            return E_NOINTERFACE;
        }
#else
        REFIID iunknown = IID_IUnknown;
        REFIID inputCallback = IID_IDeckLinkInputCallback;
        if (memcmp(&iid, &iunknown, sizeof(REFIID)) == 0) {
            *ppv = static_cast<IDeckLinkInputCallback*>(this);
        } else if (memcmp(&iid, &inputCallback, sizeof(REFIID)) == 0) {
            *ppv = static_cast<IDeckLinkInputCallback*>(this);
        } else {
            *ppv = nullptr;
            return E_NOINTERFACE;
        }
#endif
        AddRef();
        return S_OK;
    }

    virtual ULONG STDMETHODCALLTYPE AddRef() override {
        return ++m_refCount;
    }

    virtual ULONG STDMETHODCALLTYPE Release() override {
        ULONG newRefValue = --m_refCount;
        if (newRefValue == 0) {
            delete this;
        }
        return newRefValue;
    }

    virtual HRESULT STDMETHODCALLTYPE VideoInputFormatChanged(
        BMDVideoInputFormatChangedEvents notificationEvents,
        IDeckLinkDisplayMode* newDisplayMode,
        BMDDetectedVideoInputFormatFlags detectedSignalFlags) override {
        if (m_parent && newDisplayMode) {
            m_parent->onFormatChanged(newDisplayMode, detectedSignalFlags);
        }
        return S_OK;
    }

    virtual HRESULT STDMETHODCALLTYPE VideoInputFrameArrived(
        IDeckLinkVideoInputFrame* videoFrame,
        IDeckLinkAudioInputPacket* audioPacket) override {
        if (videoFrame && m_parent) {
            m_parent->onFrameArrived(videoFrame);
        }
        return S_OK;
    }

private:
    DeckLinkInput* m_parent;
    std::atomic<ULONG> m_refCount;
};

DeckLinkInput::DeckLinkInput()
    : m_deckLink(nullptr)
    , m_deckLinkInput(nullptr)
    , m_deckLinkConfiguration(nullptr)
    , m_hdmiInputEDID(nullptr)
    , m_callback(nullptr)
    , m_hdmiInputDynamicRanges(bmdDynamicRangeSDR | bmdDynamicRangeHDRStaticPQ | bmdDynamicRangeHDRStaticHLG)
    , m_inputEnabled(false)
    , m_frameReceived(false)
    , m_formatDetected(false)
{
    m_lastFrame.valid = false;
    m_lastFrame.hasMetadata = false;
    m_lastFrame.colorspace = Gamut::Rec709;
    m_lastFrame.eotf = Eotf::SDR;
    m_lastFrame.hasDisplayPrimaries = false;
    m_lastFrame.hasWhitePoint = false;
    m_lastFrame.hasMasteringLuminance = false;
    m_lastFrame.hasMaxCLL = false;
    m_lastFrame.hasMaxFALL = false;
    m_lastFrame.hasTimecode = false;
}

DeckLinkInput::~DeckLinkInput()
{
    cleanup();
}

bool DeckLinkInput::initialize(int deviceIndex, InputConnection* inputConnection)
{
    IDeckLinkIterator* deckLinkIterator = DeckLink::CreateDeckLinkIteratorInstance();
    if (!deckLinkIterator) {
        std::cerr << "Could not create DeckLink iterator" << std::endl;
        return false;
    }

    IDeckLink* deckLink = nullptr;
    for (int i = 0; i <= deviceIndex; i++) {
        if (deckLink) {
            deckLink->Release();
        }
        if (deckLinkIterator->Next(&deckLink) != S_OK) {
            std::cerr << "Could not find DeckLink device at index " << deviceIndex << std::endl;
            deckLinkIterator->Release();
            return false;
        }
    }

    deckLinkIterator->Release();
    m_deckLink = deckLink;

    if (m_deckLink->QueryInterface(IID_IDeckLinkConfiguration, (void**)&m_deckLinkConfiguration) != S_OK) {
        std::cerr << "Could not get IDeckLinkConfiguration interface" << std::endl;
        return false;
    }

    if (inputConnection != nullptr) {
        if (m_deckLinkConfiguration->SetInt(bmdDeckLinkConfigVideoInputConnection,
                                           static_cast<int64_t>(*inputConnection)) != S_OK) {
            std::cerr << "Could not set input connection" << std::endl;
            return false;
        }
    }

    int64_t activeConnection = 0;
    if (m_deckLinkConfiguration->GetInt(bmdDeckLinkConfigVideoInputConnection,
                                        &activeConnection) == S_OK
        && activeConnection == bmdVideoConnectionHDMI) {
        applyHDMIInputDynamicRanges();
    }

    if (m_deckLink->QueryInterface(IID_IDeckLinkInput, (void**)&m_deckLinkInput) != S_OK) {
        std::cerr << "Could not get IDeckLinkInput interface" << std::endl;
        return false;
    }

    m_callback = new DeckLinkInputCallback(this);
    if (m_deckLinkInput->SetCallback(m_callback) != S_OK) {
        std::cerr << "Could not set input callback" << std::endl;
        return false;
    }

    return true;
}

bool DeckLinkInput::startCapture(PixelFormat format)
{
    if (!m_deckLinkInput) {
        std::cerr << "DeckLink input not initialized" << std::endl;
        return false;
    }

    if (m_inputEnabled) {
        m_deckLinkInput->DisableVideoInput();
        m_inputEnabled = false;
    }

    m_currentSettings.format = format;
    m_formatDetected = false;

    BMDPixelFormat bmdPixelFormat;
    switch (format) {
        case PixelFormat::Format10BitYUV:
            bmdPixelFormat = bmdFormat10BitYUV;
            break;
        case PixelFormat::Format8BitYUV:
            bmdPixelFormat = bmdFormat8BitYUV;
            break;
        case PixelFormat::Format8BitBGRA:
            bmdPixelFormat = bmdFormat8BitBGRA;
            break;
        case PixelFormat::Format10BitRGB:
            bmdPixelFormat = bmdFormat10BitRGB;
            break;
        case PixelFormat::Format12BitRGB:
            bmdPixelFormat = bmdFormat12BitRGB;
            break;
        default:
            std::cerr << "Unsupported pixel format for capture" << std::endl;
            return false;
    }

    if (m_deckLinkInput->EnableVideoInput(
            bmdModeHD1080p2997,
            bmdPixelFormat,
            bmdVideoInputEnableFormatDetection) != S_OK) {
        std::cerr << "Could not enable video input with format detection" << std::endl;
        return false;
    }
    m_inputEnabled = true;

    if (m_deckLinkInput->StartStreams() != S_OK) {
        std::cerr << "Could not start input streams" << std::endl;
        return false;
    }

    return true;
}

bool DeckLinkInput::captureFrame(CapturedFrame& frame, int timeoutMs)
{
    if (!m_inputEnabled) {
        std::cerr << "Input not enabled" << std::endl;
        return false;
    }

    auto startTime = std::chrono::steady_clock::now();
    auto deadline = startTime + std::chrono::milliseconds(timeoutMs);

    while (!m_formatDetected.load()) {
        if (std::chrono::steady_clock::now() >= deadline) {
            std::cerr << "Timeout waiting for format detection" << std::endl;
            return false;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    m_frameReceived = false;

    std::unique_lock<std::mutex> lock(m_frameMutex);
    auto remainingTime = std::chrono::duration_cast<std::chrono::milliseconds>(
        deadline - std::chrono::steady_clock::now());

    if (remainingTime.count() <= 0 ||
        !m_frameCondition.wait_for(lock, remainingTime,
                                   [this] { return m_frameReceived.load(); })) {
        std::cerr << "Timeout waiting for frame" << std::endl;
        return false;
    }

    if (!m_lastFrame.valid) {
        std::cerr << "Invalid frame received" << std::endl;
        return false;
    }

    frame = std::move(m_lastFrame);
    return true;
}

void DeckLinkInput::onFrameArrived(IDeckLinkVideoInputFrame* videoFrame)
{
    if (videoFrame->GetFlags() & bmdFrameHasNoInputSource) {
        return;
    }

    m_formatDetected = true;

    CapturedFrame tempFrame;

    tempFrame.width = videoFrame->GetWidth();
    tempFrame.height = videoFrame->GetHeight();
    tempFrame.rowBytes = videoFrame->GetRowBytes();
    tempFrame.format = static_cast<PixelFormat>(videoFrame->GetPixelFormat());
    tempFrame.mode = m_currentSettings.mode;

    tempFrame.hasMetadata = false;
    tempFrame.colorspace = Gamut::Rec709;
    tempFrame.eotf = Eotf::SDR;
    tempFrame.hasDisplayPrimaries = false;
    tempFrame.hasWhitePoint = false;
    tempFrame.hasMasteringLuminance = false;
    tempFrame.hasMaxCLL = false;
    tempFrame.hasMaxFALL = false;
    tempFrame.hasTimecode = false;

    IDeckLinkVideoFrameMetadataExtensions* metadataExt = nullptr;
    if (videoFrame->QueryInterface(IID_IDeckLinkVideoFrameMetadataExtensions, (void**)&metadataExt) == S_OK) {
        int64_t colorspace = 0;
        int64_t eotf = 0;

        if (metadataExt->GetInt(bmdDeckLinkFrameMetadataColorspace, &colorspace) == S_OK) {
            tempFrame.hasMetadata = true;
            switch (colorspace) {
                case bmdColorspaceRec601:
                    tempFrame.colorspace = Gamut::Rec601;
                    break;
                case bmdColorspaceRec709:
                    tempFrame.colorspace = Gamut::Rec709;
                    break;
                case bmdColorspaceRec2020:
                    tempFrame.colorspace = Gamut::Rec2020;
                    break;
            }
        }

        if (metadataExt->GetInt(bmdDeckLinkFrameMetadataHDRElectroOpticalTransferFunc, &eotf) == S_OK) {
            tempFrame.hasMetadata = true;
            switch (eotf) {
                case kEOTF_SDR:
                    tempFrame.eotf = Eotf::SDR;
                    break;
                case kEOTF_HDR_Traditional:
                    tempFrame.eotf = Eotf::HDR_Traditional;
                    break;
                case kEOTF_PQ:
                    tempFrame.eotf = Eotf::PQ;
                    break;
                case kEOTF_HLG:
                    tempFrame.eotf = Eotf::HLG;
                    break;
            }
        }

        if (metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRDisplayPrimariesRedX, &tempFrame.displayPrimariesRedX) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRDisplayPrimariesRedY, &tempFrame.displayPrimariesRedY) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRDisplayPrimariesGreenX, &tempFrame.displayPrimariesGreenX) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRDisplayPrimariesGreenY, &tempFrame.displayPrimariesGreenY) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRDisplayPrimariesBlueX, &tempFrame.displayPrimariesBlueX) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRDisplayPrimariesBlueY, &tempFrame.displayPrimariesBlueY) == S_OK) {
            tempFrame.hasDisplayPrimaries = true;
        }

        if (metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRWhitePointX, &tempFrame.whitePointX) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRWhitePointY, &tempFrame.whitePointY) == S_OK) {
            tempFrame.hasWhitePoint = true;
        }

        if (metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRMaxDisplayMasteringLuminance, &tempFrame.maxMasteringLuminance) == S_OK &&
            metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRMinDisplayMasteringLuminance, &tempFrame.minMasteringLuminance) == S_OK) {
            tempFrame.hasMasteringLuminance = true;
        }

        if (metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRMaximumContentLightLevel, &tempFrame.maxContentLightLevel) == S_OK) {
            tempFrame.hasMaxCLL = true;
        }

        if (metadataExt->GetFloat(bmdDeckLinkFrameMetadataHDRMaximumFrameAverageLightLevel, &tempFrame.maxFrameAverageLightLevel) == S_OK) {
            tempFrame.hasMaxFALL = true;
        }

        metadataExt->Release();
    }

    IDeckLinkTimecode* timecode = nullptr;
    if (videoFrame->GetTimecode(bmdTimecodeRP188Any, &timecode) == S_OK && timecode != nullptr) {
        uint8_t hours, minutes, seconds, frames;
        if (timecode->GetComponents(&hours, &minutes, &seconds, &frames) == S_OK) {
            tempFrame.hasTimecode = true;
            tempFrame.timecodeHours = hours;
            tempFrame.timecodeMinutes = minutes;
            tempFrame.timecodeSeconds = seconds;
            tempFrame.timecodeFrames = frames;
            tempFrame.timecodeIsDropFrame = (timecode->GetFlags() & bmdTimecodeIsDropFrame) != 0;
        }
        timecode->Release();
    }

    void* frameBytes;
    if (videoFrame->GetBytes(&frameBytes) == S_OK) {
        long frameSize = videoFrame->GetRowBytes() * videoFrame->GetHeight();
        tempFrame.data.resize(frameSize);
        std::memcpy(tempFrame.data.data(), frameBytes, frameSize);
        tempFrame.valid = true;
    } else {
        tempFrame.valid = false;
    }

    {
        std::lock_guard<std::mutex> lock(m_frameMutex);
        m_lastFrame = std::move(tempFrame);
        m_frameReceived = true;
    }
    m_frameCondition.notify_one();
}

void DeckLinkInput::onFormatChanged(IDeckLinkDisplayMode* newDisplayMode, BMDDetectedVideoInputFormatFlags detectedSignalFlags)
{
    BMDPixelFormat pixelFormat;

    if (detectedSignalFlags & bmdDetectedVideoInputRGB444) {
        if (detectedSignalFlags & bmdDetectedVideoInput12BitDepth) {
            pixelFormat = bmdFormat12BitRGBLE;
            m_detectedSettings.format = PixelFormat::Format12BitRGB;
        } else {
            pixelFormat = bmdFormat10BitRGBXLE;
            m_detectedSettings.format = PixelFormat::Format10BitRGB;
        }
    } else {
        if (detectedSignalFlags & bmdDetectedVideoInput8BitDepth) {
            pixelFormat = bmdFormat8BitYUV;
            m_detectedSettings.format = PixelFormat::Format8BitYUV;
        } else {
            pixelFormat = bmdFormat10BitYUV;
            m_detectedSettings.format = PixelFormat::Format10BitYUV;
        }
    }

    {
        std::lock_guard<std::mutex> lock(m_formatMutex);

        m_detectedSettings.mode = static_cast<DisplayMode>(newDisplayMode->GetDisplayMode());
        m_detectedSettings.width = newDisplayMode->GetWidth();
        m_detectedSettings.height = newDisplayMode->GetHeight();

        BMDTimeValue frameDuration;
        BMDTimeScale timeScale;
        newDisplayMode->GetFrameRate(&frameDuration, &timeScale);
        m_detectedSettings.framerate = (double)timeScale / (double)frameDuration;

        m_formatDetected = true;
    }

    m_currentSettings.format = m_detectedSettings.format;
    m_currentSettings.mode = m_detectedSettings.mode;

    if (m_deckLinkInput) {
        m_deckLinkInput->PauseStreams();
        m_deckLinkInput->EnableVideoInput(
            newDisplayMode->GetDisplayMode(),
            pixelFormat,
            bmdVideoInputEnableFormatDetection);
        m_deckLinkInput->FlushStreams();
        m_deckLinkInput->StartStreams();
    }
}

DeckLinkInput::VideoSettings DeckLinkInput::getDetectedFormat()
{
    std::lock_guard<std::mutex> lock(m_formatMutex);
    return m_detectedSettings;
}

DeckLinkInput::PixelFormat DeckLinkInput::getDetectedPixelFormat()
{
    std::lock_guard<std::mutex> lock(m_formatMutex);
    return m_detectedSettings.format;
}

bool DeckLinkInput::stopCapture()
{
    if (m_inputEnabled && m_deckLinkInput) {
        m_deckLinkInput->StopStreams();
        m_deckLinkInput->DisableVideoInput();
        m_inputEnabled = false;
    }
    return true;
}

bool DeckLinkInput::setHDMIInputDynamicRanges(int64_t bmdDynamicRangeMask)
{
    m_hdmiInputDynamicRanges = bmdDynamicRangeMask;

    if (!m_deckLink || !m_deckLinkConfiguration) {
        return true;
    }

    int64_t activeConnection = 0;
    if (m_deckLinkConfiguration->GetInt(bmdDeckLinkConfigVideoInputConnection,
                                        &activeConnection) != S_OK
        || activeConnection != bmdVideoConnectionHDMI) {
        return true;
    }

    return applyHDMIInputDynamicRanges();
}

bool DeckLinkInput::applyHDMIInputDynamicRanges()
{
    if (!m_hdmiInputEDID) {
        if (m_deckLink->QueryInterface(IID_IDeckLinkHDMIInputEDID,
                                       (void**)&m_hdmiInputEDID) != S_OK) {
            m_hdmiInputEDID = nullptr;
            return true;
        }
    }

    if (m_hdmiInputEDID->SetInt(bmdDeckLinkHDMIInputEDIDDynamicRange,
                                m_hdmiInputDynamicRanges) != S_OK
        || m_hdmiInputEDID->WriteToEDID() != S_OK) {
        std::cerr << "Could not write HDMI input EDID for HDR — "
                     "source may not send HDR metadata" << std::endl;
        m_hdmiInputEDID->Release();
        m_hdmiInputEDID = nullptr;
        return false;
    }

    return true;
}

void DeckLinkInput::cleanup()
{
    stopCapture();

    if (m_callback) {
        m_callback->Release();
        m_callback = nullptr;
    }

    if (m_deckLinkInput) {
        m_deckLinkInput->Release();
        m_deckLinkInput = nullptr;
    }

    if (m_deckLinkConfiguration) {
        m_deckLinkConfiguration->Release();
        m_deckLinkConfiguration = nullptr;
    }

    if (m_hdmiInputEDID) {
        m_hdmiInputEDID->Release();
        m_hdmiInputEDID = nullptr;
    }

    if (m_deckLink) {
        m_deckLink->Release();
        m_deckLink = nullptr;
    }
}

std::vector<std::string> DeckLinkInput::getDeviceList()
{
    return DeckLink::getDeviceList();
}

std::vector<DeckLinkInput::InputConnection> DeckLinkInput::getAvailableInputConnections(int deviceIndex)
{
    return DeckLink::getAvailableInputConnections(deviceIndex);
}

DeckLinkInput::VideoSettings DeckLinkInput::getVideoSettings(DisplayMode mode)
{
    VideoSettings settings;
    settings.mode = mode;
    settings.format = PixelFormat::Format8BitBGRA;

    if (m_deckLinkInput) {
        IDeckLinkDisplayMode* displayMode = nullptr;
        if (m_deckLinkInput->GetDisplayMode(static_cast<BMDDisplayMode>(mode), &displayMode) == S_OK) {
            settings.width = displayMode->GetWidth();
            settings.height = displayMode->GetHeight();

            BMDTimeValue frameDuration;
            BMDTimeScale timeScale;
            displayMode->GetFrameRate(&frameDuration, &timeScale);
            settings.framerate = (double)timeScale / (double)frameDuration;

            displayMode->Release();
        } else {
            std::cerr << "Warning: Could not get display mode information, using defaults" << std::endl;
            settings.width = 1920;
            settings.height = 1080;
            settings.framerate = 25.0;
        }
    } else {
        std::cerr << "Warning: DeckLink input not initialized, using defaults" << std::endl;
        settings.width = 1920;
        settings.height = 1080;
        settings.framerate = 25.0;
    }

    return settings;
}

std::vector<DeckLinkInput::DisplayModeInfo> DeckLinkInput::getSupportedDisplayModes()
{
    std::vector<DisplayModeInfo> modes;

    if (!m_deckLinkInput) {
        std::cerr << "DeckLink input not initialized" << std::endl;
        return modes;
    }

    IDeckLinkDisplayModeIterator* displayModeIterator = nullptr;
    if (m_deckLinkInput->GetDisplayModeIterator(&displayModeIterator) != S_OK) {
        std::cerr << "Could not get display mode iterator" << std::endl;
        return modes;
    }

    IDeckLinkDisplayMode* displayMode = nullptr;
    while (displayModeIterator->Next(&displayMode) == S_OK) {
        DisplayModeInfo modeInfo;

        modeInfo.displayMode = static_cast<DisplayMode>(displayMode->GetDisplayMode());
        modeInfo.width = displayMode->GetWidth();
        modeInfo.height = displayMode->GetHeight();

        BMDTimeValue frameDuration;
        BMDTimeScale timeScale;
        displayMode->GetFrameRate(&frameDuration, &timeScale);
        modeInfo.framerate = (double)timeScale / (double)frameDuration;

#ifdef __APPLE__
        CFStringRef nameString;
        if (displayMode->GetName(&nameString) == S_OK) {
            CFIndex nameLen = CFStringGetLength(nameString);
            CFIndex maxSize = CFStringGetMaximumSizeForEncoding(nameLen, kCFStringEncodingUTF8) + 1;
            std::vector<char> nameBuffer(maxSize);
            if (CFStringGetCString(nameString, nameBuffer.data(), maxSize, kCFStringEncodingUTF8)) {
                modeInfo.name = std::string(nameBuffer.data());
            }
            CFRelease(nameString);
        }
#elif defined(_WIN32)
        BSTR nameString;
        if (displayMode->GetName(&nameString) == S_OK) {
            int nameLen = WideCharToMultiByte(CP_UTF8, 0, nameString, -1, nullptr, 0, nullptr, nullptr);
            if (nameLen > 0) {
                std::vector<char> nameBuffer(nameLen);
                WideCharToMultiByte(CP_UTF8, 0, nameString, -1, nameBuffer.data(), nameLen, nullptr, nullptr);
                modeInfo.name = std::string(nameBuffer.data());
            }
            SysFreeString(nameString);
        }
#else
        const char* nameString;
        if (displayMode->GetName(&nameString) == S_OK) {
            modeInfo.name = std::string(nameString);
        }
#endif

        modes.push_back(modeInfo);
        displayMode->Release();
    }

    displayModeIterator->Release();
    return modes;
}
