#include "decklink_output.hpp"
#include "decklink_hdr_frame.hpp"
#include <iostream>
#include <cstring>

#ifdef __APPLE__
    #include <CoreFoundation/CoreFoundation.h>
#elif defined(_WIN32)
    #include <comutil.h>
#endif

DeckLinkOutput::DeckLinkOutput()
    : m_deckLink(nullptr)
    , m_deckLinkOutput(nullptr)
    , m_deckLinkConfiguration(nullptr)
    , m_outputEnabled(false)
    , m_frameDuration(0)
    , m_timeScale(0)
    , m_useHdrMetadata(false)
    , m_hdrColorimetry(Gamut::Rec709)
    , m_hdrEotf(Eotf::SDR)
{
}

DeckLinkOutput::~DeckLinkOutput()
{
    cleanup();
}

bool DeckLinkOutput::initialize(int deviceIndex)
{
    IDeckLinkIterator* deckLinkIterator = DeckLink::CreateDeckLinkIteratorInstance();
    if (!deckLinkIterator) {
        std::cerr << "Could not create DeckLink iterator" << std::endl;
        return false;
    }

    IDeckLink* deckLink = nullptr;
    for (int i = 0; i <= deviceIndex; i++) {
        if (deckLink) {
            deckLink->Release();
        }
        if (deckLinkIterator->Next(&deckLink) != S_OK) {
            std::cerr << "Could not find DeckLink device at index " << deviceIndex << std::endl;
            deckLinkIterator->Release();
            return false;
        }
    }

    deckLinkIterator->Release();

    m_deckLink = deckLink;

    if (m_deckLink->QueryInterface(IID_IDeckLinkOutput, (void**)&m_deckLinkOutput) != S_OK) {
        std::cerr << "Could not get IDeckLinkOutput interface" << std::endl;
        return false;
    }

    if (m_deckLink->QueryInterface(IID_IDeckLinkConfiguration, (void**)&m_deckLinkConfiguration) != S_OK) {
        std::cerr << "Could not get IDeckLinkConfiguration interface" << std::endl;
        return false;
    }

    return true;
}

bool DeckLinkOutput::setupOutput(const VideoSettings& settings)
{
    if (!m_deckLinkOutput) {
        std::cerr << "DeckLink output not initialized" << std::endl;
        return false;
    }

    IDeckLinkDisplayModeIterator* displayModeIterator = nullptr;
    if (m_deckLinkOutput->GetDisplayModeIterator(&displayModeIterator) != S_OK) {
        std::cerr << "Could not get display mode iterator" << std::endl;
        return false;
    }

    IDeckLinkDisplayMode* displayMode = nullptr;
    bool modeFound = false;

    while (displayModeIterator->Next(&displayMode) == S_OK) {
        BMDDisplayMode mode = displayMode->GetDisplayMode();
        if (mode == static_cast<BMDDisplayMode>(settings.mode)) {
            displayMode->GetFrameRate(&m_frameDuration, &m_timeScale);
            modeFound = true;
            displayMode->Release();
            break;
        }
        displayMode->Release();
    }

    displayModeIterator->Release();

    if (!modeFound) {
        std::cerr << "Could not find display mode" << std::endl;
        return false;
    }

    if (m_deckLinkConfiguration) {
        if (settings.format == PixelFormat::Format10BitRGB || settings.format == PixelFormat::Format12BitRGB) {
            m_deckLinkConfiguration->SetFlag(bmdDeckLinkConfig444SDIVideoOutput, true);
        } else {
            m_deckLinkConfiguration->SetFlag(bmdDeckLinkConfig444SDIVideoOutput, false);
        }
    }

    if (m_outputEnabled && m_currentSettings.mode != settings.mode) {
        m_deckLinkOutput->DisableVideoOutput();
        m_outputEnabled = false;
    }

    m_currentSettings = settings;

    if (!m_outputEnabled) {
        if (m_deckLinkOutput->EnableVideoOutput(static_cast<BMDDisplayMode>(settings.mode),
                                               bmdVideoOutputFlagDefault) != S_OK) {
            std::cerr << "Could not enable video output" << std::endl;
            return false;
        }
        m_outputEnabled = true;
    }

    size_t frameSize = DeckLink::calculateFrameBufferSize(settings);
    m_frameBuffer.resize(frameSize);

    return true;
}

bool DeckLinkOutput::setFrameData(const uint8_t* data, size_t dataSize)
{
    std::lock_guard<std::mutex> lock(m_frameBufferMutex);

    if (dataSize > m_frameBuffer.size()) {
        std::cerr << "Frame data too large" << std::endl;
        return false;
    }

    std::memcpy(m_frameBuffer.data(), data, dataSize);
    return true;
}

bool DeckLinkOutput::createFrame(IDeckLinkMutableVideoFrame** frame)
{
    std::lock_guard<std::mutex> lock(m_frameBufferMutex);

    int32_t rowBytes;
    switch (m_currentSettings.format) {
        case PixelFormat::Format8BitBGRA:
            rowBytes = m_currentSettings.width * 4;
            break;
        case PixelFormat::Format10BitYUV:
            rowBytes = ((m_currentSettings.width + 5) / 6) * 16;
            break;
        case PixelFormat::Format10BitRGB:
            rowBytes = m_currentSettings.width * 4;
            break;
        case PixelFormat::Format12BitRGB:
            rowBytes = ((m_currentSettings.width + 7) / 8) * 36;
            break;
        case PixelFormat::Format8BitYUV:
        default:
            rowBytes = m_currentSettings.width * 2;
            break;
    }

    if (m_deckLinkOutput->CreateVideoFrame(
            m_currentSettings.width,
            m_currentSettings.height,
            rowBytes,
            static_cast<BMDPixelFormat>(m_currentSettings.format),
            bmdFrameFlagDefault,
            frame) != S_OK) {
        return false;
    }

    void* frameBuffer;
    if ((*frame)->GetBytes(&frameBuffer) == S_OK) {
        std::memcpy(frameBuffer, m_frameBuffer.data(), m_frameBuffer.size());
    }

    return true;
}

bool DeckLinkOutput::displayFrame()
{
    if (!m_deckLinkOutput) {
        std::cerr << "DeckLink output not initialized" << std::endl;
        return false;
    }

    IDeckLinkMutableVideoFrame* mutableFrame = nullptr;
    if (!createFrame(&mutableFrame)) {
        std::cerr << "Could not create frame" << std::endl;
        return false;
    }

    IDeckLinkVideoFrame* frame = mutableFrame;

    if (m_useHdrMetadata) {
        frame = createHdrFrame(mutableFrame);
        mutableFrame->Release();
    }

    HRESULT result = m_deckLinkOutput->DisplayVideoFrameSync(frame);
    frame->Release();

    if (result != S_OK) {
        std::cerr << "Could not display video frame" << std::endl;
        return false;
    }

    return true;
}

bool DeckLinkOutput::stopOutput()
{
    if (m_outputEnabled && m_deckLinkOutput) {
        m_deckLinkOutput->DisableVideoOutput();
        m_outputEnabled = false;
    }
    return true;
}

void DeckLinkOutput::cleanup()
{
    stopOutput();

    if (m_deckLinkConfiguration) {
        m_deckLinkConfiguration->Release();
        m_deckLinkConfiguration = nullptr;
    }

    if (m_deckLinkOutput) {
        m_deckLinkOutput->Release();
        m_deckLinkOutput = nullptr;
    }

    if (m_deckLink) {
        m_deckLink->Release();
        m_deckLink = nullptr;
    }
}

void DeckLinkOutput::setHdrMetadata(Gamut colorimetry, Eotf eotf)
{
    m_useHdrMetadata = true;
    m_hdrColorimetry = colorimetry;
    m_hdrEotf = eotf;

    if (eotf == Eotf::PQ) {
        if (colorimetry == Gamut::Rec2020) {
            m_hdrCustom.displayPrimariesRedX = 0.708;
            m_hdrCustom.displayPrimariesRedY = 0.292;
            m_hdrCustom.displayPrimariesGreenX = 0.170;
            m_hdrCustom.displayPrimariesGreenY = 0.797;
            m_hdrCustom.displayPrimariesBlueX = 0.131;
            m_hdrCustom.displayPrimariesBlueY = 0.046;
        } else {
            m_hdrCustom.displayPrimariesRedX = 0.64;
            m_hdrCustom.displayPrimariesRedY = 0.33;
            m_hdrCustom.displayPrimariesGreenX = 0.30;
            m_hdrCustom.displayPrimariesGreenY = 0.60;
            m_hdrCustom.displayPrimariesBlueX = 0.15;
            m_hdrCustom.displayPrimariesBlueY = 0.06;
        }

        m_hdrCustom.whitePointX = 0.3127;
        m_hdrCustom.whitePointY = 0.3290;

        m_hdrCustom.maxMasteringLuminance = 1000.0;
        m_hdrCustom.minMasteringLuminance = 0.0001;
        m_hdrCustom.maxContentLightLevel = 1000.0;
        m_hdrCustom.maxFrameAverageLightLevel = 50.0;
    } else {
        m_hdrCustom.displayPrimariesRedX = 0.0;
        m_hdrCustom.displayPrimariesRedY = 0.0;
        m_hdrCustom.displayPrimariesGreenX = 0.0;
        m_hdrCustom.displayPrimariesGreenY = 0.0;
        m_hdrCustom.displayPrimariesBlueX = 0.0;
        m_hdrCustom.displayPrimariesBlueY = 0.0;
        m_hdrCustom.whitePointX = 0.0;
        m_hdrCustom.whitePointY = 0.0;
        m_hdrCustom.maxMasteringLuminance = 0.0;
        m_hdrCustom.minMasteringLuminance = 0.0;
        m_hdrCustom.maxContentLightLevel = 0.0;
        m_hdrCustom.maxFrameAverageLightLevel = 0.0;
    }
}

void DeckLinkOutput::setHdrMetadataCustom(Gamut colorimetry, Eotf eotf, const HdrMetadataCustom& custom)
{
    m_useHdrMetadata = true;
    m_hdrColorimetry = colorimetry;
    m_hdrEotf = eotf;
    m_hdrCustom = custom;
}

void DeckLinkOutput::clearHdrMetadata()
{
    m_useHdrMetadata = false;
    m_hdrColorimetry = Gamut::Rec709;
    m_hdrEotf = Eotf::SDR;
    m_hdrCustom.displayPrimariesRedX = 0.0;
    m_hdrCustom.displayPrimariesRedY = 0.0;
    m_hdrCustom.displayPrimariesGreenX = 0.0;
    m_hdrCustom.displayPrimariesGreenY = 0.0;
    m_hdrCustom.displayPrimariesBlueX = 0.0;
    m_hdrCustom.displayPrimariesBlueY = 0.0;
    m_hdrCustom.whitePointX = 0.0;
    m_hdrCustom.whitePointY = 0.0;
    m_hdrCustom.maxMasteringLuminance = 0.0;
    m_hdrCustom.minMasteringLuminance = 0.0;
    m_hdrCustom.maxContentLightLevel = 0.0;
    m_hdrCustom.maxFrameAverageLightLevel = 0.0;
}

IDeckLinkVideoFrame* DeckLinkOutput::createHdrFrame(IDeckLinkMutableVideoFrame* frame)
{
    HdrMetadata::ChromaticityCoordinates primaries = {
        m_hdrCustom.displayPrimariesRedX,
        m_hdrCustom.displayPrimariesRedY,
        m_hdrCustom.displayPrimariesGreenX,
        m_hdrCustom.displayPrimariesGreenY,
        m_hdrCustom.displayPrimariesBlueX,
        m_hdrCustom.displayPrimariesBlueY,
        m_hdrCustom.whitePointX,
        m_hdrCustom.whitePointY
    };

    HdrMetadata metadata = HdrMetadata::custom(
        m_hdrColorimetry,
        m_hdrEotf,
        primaries,
        m_hdrCustom.maxMasteringLuminance,
        m_hdrCustom.minMasteringLuminance,
        m_hdrCustom.maxContentLightLevel,
        m_hdrCustom.maxFrameAverageLightLevel
    );

    return new DeckLinkHdrVideoFrame(frame, metadata);
}

std::vector<std::string> DeckLinkOutput::getDeviceList()
{
    return DeckLink::getDeviceList();
}

DeckLinkOutput::VideoSettings DeckLinkOutput::getVideoSettings(DisplayMode mode)
{
    VideoSettings settings;
    settings.mode = mode;
    settings.format = PixelFormat::Format8BitBGRA;

    if (m_deckLinkOutput) {
        IDeckLinkDisplayMode* displayMode = nullptr;
        if (m_deckLinkOutput->GetDisplayMode(static_cast<BMDDisplayMode>(mode), &displayMode) == S_OK) {
            settings.width = displayMode->GetWidth();
            settings.height = displayMode->GetHeight();

            BMDTimeValue frameDuration;
            BMDTimeScale timeScale;
            displayMode->GetFrameRate(&frameDuration, &timeScale);
            settings.framerate = (double)timeScale / (double)frameDuration;

            displayMode->Release();
        } else {
            std::cerr << "Warning: Could not get display mode information for mode "
                      << static_cast<int>(mode) << ", using defaults" << std::endl;
            settings.width = 1920;
            settings.height = 1080;
            settings.framerate = 25.0;
        }
    } else {
        std::cerr << "Warning: DeckLink output not initialized, using default settings" << std::endl;
        settings.width = 1920;
        settings.height = 1080;
        settings.framerate = 25.0;
    }

    return settings;
}

bool DeckLinkOutput::isPixelFormatSupported(DisplayMode mode, PixelFormat format)
{
    if (!m_deckLinkOutput) {
        return false;
    }

#ifdef _WIN32
    BOOL supported = FALSE;
#else
    bool supported = false;
#endif
    BMDDisplayMode actualMode;

    HRESULT result = m_deckLinkOutput->DoesSupportVideoMode(
        bmdVideoConnectionUnspecified,
        static_cast<BMDDisplayMode>(mode),
        static_cast<BMDPixelFormat>(format),
        bmdNoVideoOutputConversion,
        bmdSupportedVideoModeDefault,
        &actualMode,
        &supported
    );

#ifdef _WIN32
    return (result == S_OK && supported != FALSE);
#else
    return (result == S_OK && supported);
#endif
}

DeckLinkOutput::OutputInfo DeckLinkOutput::getCurrentOutputInfo()
{
    OutputInfo info;

    info.displayMode = m_currentSettings.mode;
    info.pixelFormat = m_currentSettings.format;
    info.width = m_currentSettings.width;
    info.height = m_currentSettings.height;
    info.framerate = m_currentSettings.framerate;
    info.rgb444ModeEnabled = false;

    if (m_deckLinkConfiguration) {
#ifdef _WIN32
        BOOL flagValue = FALSE;
        if (m_deckLinkConfiguration->GetFlag(bmdDeckLinkConfig444SDIVideoOutput, &flagValue) == S_OK) {
            info.rgb444ModeEnabled = (flagValue != FALSE);
        }
#else
        bool flagValue = false;
        if (m_deckLinkConfiguration->GetFlag(bmdDeckLinkConfig444SDIVideoOutput, &flagValue) == S_OK) {
            info.rgb444ModeEnabled = flagValue;
        }
#endif
    }

    BMDDisplayMode bmdMode = static_cast<BMDDisplayMode>(m_currentSettings.mode);
    IDeckLinkDisplayModeIterator* displayModeIterator = nullptr;
    if (m_deckLinkOutput && m_deckLinkOutput->GetDisplayModeIterator(&displayModeIterator) == S_OK) {
        IDeckLinkDisplayMode* displayMode = nullptr;
        while (displayModeIterator->Next(&displayMode) == S_OK) {
            if (displayMode->GetDisplayMode() == bmdMode) {
#ifdef __APPLE__
                CFStringRef modeName;
                if (displayMode->GetName(&modeName) == S_OK) {
                    char buffer[256];
                    CFStringGetCString(modeName, buffer, sizeof(buffer), kCFStringEncodingUTF8);
                    info.displayModeName = buffer;
                    CFRelease(modeName);
                }
#elif defined(_WIN32)
                BSTR modeName = nullptr;
                if (displayMode->GetName(&modeName) == S_OK) {
                    _bstr_t bstr(modeName, false);
                    info.displayModeName = std::string((const char*)bstr);
                    SysFreeString(modeName);
                }
#else
                const char* modeName = nullptr;
                if (displayMode->GetName(&modeName) == S_OK) {
                    info.displayModeName = modeName;
                    free((void*)modeName);
                }
#endif
                displayMode->Release();
                break;
            }
            displayMode->Release();
        }
        displayModeIterator->Release();
    }

    if (info.displayModeName.empty()) {
        info.displayModeName = "Unknown mode";
    }

    BMDPixelFormat bmdFormat = static_cast<BMDPixelFormat>(m_currentSettings.format);
    switch (bmdFormat) {
        case bmdFormat8BitYUV:
            info.pixelFormatName = "8-bit YUV (2vuy)";
            break;
        case bmdFormat8BitBGRA:
            info.pixelFormatName = "8-bit BGRA";
            break;
        case bmdFormat10BitYUV:
            info.pixelFormatName = "10-bit YUV (v210)";
            break;
        case bmdFormat10BitRGBXLE:
            info.pixelFormatName = "10-bit RGB LE (R10l)";
            break;
        case bmdFormat12BitRGBLE:
            info.pixelFormatName = "12-bit RGB LE (R12L)";
            break;
        default:
            info.pixelFormatName = "Unknown format";
            break;
    }

    return info;
}

std::vector<DeckLinkOutput::DisplayModeInfo> DeckLinkOutput::getSupportedDisplayModes()
{
    std::vector<DisplayModeInfo> modes;

    if (!m_deckLinkOutput) {
        std::cerr << "DeckLink output not initialized" << std::endl;
        return modes;
    }

    IDeckLinkDisplayModeIterator* displayModeIterator = nullptr;
    if (m_deckLinkOutput->GetDisplayModeIterator(&displayModeIterator) != S_OK) {
        std::cerr << "Could not get display mode iterator" << std::endl;
        return modes;
    }

    IDeckLinkDisplayMode* displayMode = nullptr;
    while (displayModeIterator->Next(&displayMode) == S_OK) {
        DisplayModeInfo modeInfo;

        modeInfo.displayMode = static_cast<DisplayMode>(displayMode->GetDisplayMode());
        modeInfo.width = displayMode->GetWidth();
        modeInfo.height = displayMode->GetHeight();

        BMDTimeValue frameDuration;
        BMDTimeScale timeScale;
        displayMode->GetFrameRate(&frameDuration, &timeScale);
        modeInfo.framerate = (double)timeScale / (double)frameDuration;

#ifdef __APPLE__
        CFStringRef nameString;
        if (displayMode->GetName(&nameString) == S_OK) {
            CFIndex nameLen = CFStringGetLength(nameString);
            CFIndex maxSize = CFStringGetMaximumSizeForEncoding(nameLen, kCFStringEncodingUTF8) + 1;
            std::vector<char> nameBuffer(maxSize);
            if (CFStringGetCString(nameString, nameBuffer.data(), maxSize, kCFStringEncodingUTF8)) {
                modeInfo.name = std::string(nameBuffer.data());
            }
            CFRelease(nameString);
        }
#elif defined(_WIN32)
        BSTR nameString;
        if (displayMode->GetName(&nameString) == S_OK) {
            int nameLen = WideCharToMultiByte(CP_UTF8, 0, nameString, -1, nullptr, 0, nullptr, nullptr);
            if (nameLen > 0) {
                std::vector<char> nameBuffer(nameLen);
                WideCharToMultiByte(CP_UTF8, 0, nameString, -1, nameBuffer.data(), nameLen, nullptr, nullptr);
                modeInfo.name = std::string(nameBuffer.data());
            }
            SysFreeString(nameString);
        }
#else
        const char* nameString;
        if (displayMode->GetName(&nameString) == S_OK) {
            modeInfo.name = std::string(nameString);
        }
#endif

        modes.push_back(modeInfo);
        displayMode->Release();
    }

    displayModeIterator->Release();
    return modes;
}
