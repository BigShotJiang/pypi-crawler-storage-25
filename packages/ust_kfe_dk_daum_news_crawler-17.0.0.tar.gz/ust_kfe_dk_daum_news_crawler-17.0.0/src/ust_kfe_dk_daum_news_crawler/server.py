import requests
import urllib.parse
from bs4 import BeautifulSoup

from mcp.server.fastmcp import FastMCP


mcp = FastMCP("daum_news_crawler")

@mcp.tool()
def get_crawling(keyword: str, numofpages: int) -> list:
    """
    Crawls Daum news titles and saves them as a text file.
    
    Args:
        keyword (str): Keyword for Daum News search.
        numofpages (int): Number of Daum news pages to collect.
    
    Returns:
        str: Collected Daum News Titles and save result.
    """
    
    base_url = 'https://search.daum.net/search?w=news&nil_search=btn&DA=PGD&enc=utf8' '&cluster=y&cluster_page=1&q=' + urllib.parse.quote(keyword) + '&p='    

    daum_crawling = []
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/126.0.0.0 Safari/537.36'
        }
    
    for i in range(1, numofpages + 1):
        url = base_url + str(i)

        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, "html.parser")
            headlines = soup.find_all(class_="item-title")
            
            for headline in headlines:
                title = headline.get_text(strip=True)
                if title and title not in daum_crawling:
                    daum_crawling.append(title)
                
        except Exception as e:
            print(f"Error while crawling page {i}: {e}")
            continue
     
    if not daum_crawling:
        return f"No results found for keyword '{keyword}'."
    
    contents = "\n".join(daum_crawling)
    
    save_file = ""
    
    try:
        path = Path("D:/contentfile.txt")
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "a", encoding="utf-8") as file:
            file.write(f"--- Keyword: {keyword} ---\n")
            file.write(contents)
            file.write("\n\n")

        save_file = f"\n\n[System] Text saved to {path}"

    except Exception as e:
        save_file = f"\n\n[System] File save failed: {e}"

    return contents + save_file
        
def main() -> None:
    print("Starting Daum News Crawler server...")
    mcp.run(transport='stdio')
    

if __name__ == "__main__":
   main()     