# S14 — Port Hermes ui-tui → cvc-tui (Advanced UI, 20-30k LOC)

**Goal:** Achieve full visual + functional parity with the Hermes Agent TUI in `cvc-tui`,
rebranded as CVC. Final cvc-tui ships with ~20-30k lines of advanced React/Ink UI:
banner, theme, panels, streaming, markdown, thinking, slash commands, model/session
pickers, todo panel, agents overlay, plus CVC-specific renderer parity (branch
indicator, plan blocks, diagnosis, autopilot, permission/diff preview).

**Source:** `_hermes_agent_ref/ui-tui/` (MIT, © 2025 Nous Research)
**Target:** `cvc-tui/`
**Approach:** Port + rebrand, NOT rewrite. Preserve attribution.

## License & Attribution Plan
- Add `cvc-tui/NOTICES.md` crediting Nous Research / Hermes Agent.
- Each ported file keeps an SPDX header noting Hermes origin + MIT.
- `cvc-tui/LICENSE` stays MIT (already there, © 2026 Jai Kumar Meena).
- README documents the port.

## Slice Plan

### S14a — Foundation: hermes-ink + theme + banner (~5k LOC)
- Copy `_hermes_agent_ref/ui-tui/packages/hermes-ink/` → `cvc-tui/packages/cvc-ink/`.
- Rename `@hermes/ink` → `@cvc/ink` in package.json and all imports.
- Port `src/theme.ts` (589L) → `cvc-tui/src/theme.ts`. Rebrand palette to CVC red
  (#e63946 primary, #0d1b2a bg, #4a9eff accent, #8B7070 dim). Keep all semantic tokens.
- Port `src/banner.ts` (93L) → CVC ANSI Shadow wordmark with red gradient + tagline + boot tip.
- Wire `cvc-tui/package.json` to depend on `@cvc/ink: file:./packages/cvc-ink`.
- Verify `bun build` clean. Bump to **0.2.0**, commit, tag.

### S14b — Core components (~7k LOC)
- Port:
  - `components/branding.tsx` (383L) — header bar
  - `components/appChrome.tsx` (484L) — outer chrome
  - `components/appLayout.tsx` (439L) — main layout
  - `components/appOverlays.tsx` (211L) — overlay system
  - `components/markdown.tsx` (837L) — full markdown renderer
  - `components/streamingMarkdown.tsx` (173L) — streaming md
  - `components/streamingAssistant.tsx` (110L) — streaming wrapper
  - `components/thinking.tsx` (1202L) — thinking display
  - `components/textInput.tsx` (1066L) — input with completion
  - `components/messageLine.tsx` (219L) — message rendering
  - `components/prompts.tsx` (239L) — prompt UI
  - `components/maskedPrompt.tsx`, `helpHint.tsx`, `themed.tsx`, `fpsOverlay.tsx`
- Rebrand all hermes references → CVC.
- Bump to **0.3.0**, commit, tag.

### S14c — App logic & gateway (~6k LOC)
- Port:
  - `app/turnController.ts` (844L)
  - `app/useMainApp.ts` (846L)
  - `app/useInputHandlers.ts` (519L)
  - `app/useSubmission.ts` (429L)
  - `app/useComposerState.ts` (364L)
  - `app/createGatewayEventHandler.ts` (704L)
  - `app/createSlashHandler.ts`, all slash commands (core/ops/session/setup/debug)
  - `gatewayClient.ts` (700L) + `gatewayTypes.ts` (523L)
  - All hooks (useCompletion, useGitBranch, useInputHistory, useQueue, useVirtualHistory)
  - `lib/` utilities (clipboard, emoji, history, mathUnicode, memory, perfPane,
    platform, subagentTree, terminalSetup, viewportStore, wheelAccel, ...)
- Rewire gateway client: Hermes JSON-RPC schema → CVC's FastAPI on `:13421`.
- Slash commands: keep Hermes structure, swap commands for CVC's set.
- Bump to **0.4.0**, commit, tag.

### S14d — Pickers & overlays (~3k LOC)
- Port:
  - `components/agentsOverlay.tsx` (1062L)
  - `components/modelPicker.tsx` (506L)
  - `components/sessionPicker.tsx` (227L)
  - `components/skillsHub.tsx` (308L)
  - `components/todoPanel.tsx` (93L)
  - `components/queuedMessages.tsx` (64L)
- Bump to **0.5.0**, commit, tag.

### S14e — CVC-specific renderer parity (~3k LOC, NEW code)
Pull from Python `cvc/agent/renderer.py` (1664L) — features Hermes doesn't have:
- `BranchIndicator` (CVC branch name + turn meter + health bar in input prompt)
- `PlanBlock` + plan approval panel
- `DiagnosisPanel`
- `AutopilotPanel`
- `PermissionPanel`
- `DiffPreviewPanel`
- `RetryStepPanel`
- `RevertPanel`
- `TokenUsageMeter`
Bump to **1.0.0**, tag, commit. Final parity release.

## Acceptance Criteria
- `bun run build` green at every slice
- `bun test` green at every slice (port + adapt existing 99 tests, add new ones)
- Visual: matches Hermes layout but in CVC red, with CVC ANSI banner + tagline
- All Python `renderer.py` panels reachable
- Total LOC: 20-30k after all slices
- MIT attribution preserved; NOTICES.md present

## Conventions (from MEMORY)
- All commits direct to `main`, no feature branches
- Sofia commits as `Sofia (Orchestrator) <sofia@cvc.local>`
- Tina commits as `Tina (Dev Agent) <tina@cvc.local>`
- Sofia NEVER runs `npm publish` — Jai publishes manually after each version bump
- Each slice = version bump + git tag + push
