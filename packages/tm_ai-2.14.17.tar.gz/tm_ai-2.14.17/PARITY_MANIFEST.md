# CVC ⇄ Hermes Parity Manifest

Source of truth for full parity port. Every item must land in CVC. CVC keeps its cognitive core
(Cognome, Telepathy, Holographic Memory, MetaCognition); Hermes provides the surface UX/tools/skills.

## Status legend
- ✅ already in CVC
- 🚧 in progress
- ❌ missing — must port

---

## SLICE 1 — Interactive TUI (`cvc` command)
- ❌ ASCII banner + boot screen (Hermes cli.py style)
- ❌ Interactive REPL with prompt-toolkit (history, ctrl-r, multiline)
- ❌ Slash commands: /help /tools /skills /toolsets /model /provider /memory /todo /cron /clear /exit /compact /branch /commits
- ❌ Toolset selection at boot (`--toolsets web,terminal`)
- ❌ Skill loading at boot (`--skills name1,name2`)
- ❌ Live status bar (model, provider, tokens, cost, branch)
- ❌ Streaming markdown render in terminal
- ❌ Tool-call rendering (collapsible)
- ❌ Curses/Ink fallback (`hermes_cli/curses_ui.py` equivalent)

## SLICE 2 — Browser Dashboard (Hermes-grade interactivity)
- 🚧 Base shell exists (`cvc/web/src/`)
- ❌ Hermes-style sidebar (sessions, branches, kanban, cron, memory, skills, settings)
- ❌ Chat panel with streaming, tool-call cards, image/file attachments
- ❌ Right panel: live context, token meter, cost, model picker dropdown
- ❌ Slash command palette (cmd-k)
- ❌ Settings page: providers, models, fallback chain, voice, plugins
- ❌ Kanban board page
- ❌ Cron jobs page
- ❌ Memory editor page
- ❌ Skills browser page
- ❌ Sessions/history page with search
- ❌ Light/dark theme toggle (CVC-red default)

## SLICE 3 — Tool Registry (port all 50+ tools)
Core (must-have):
- ❌ terminal (foreground+background, pty, notify_on_complete, watch_patterns)
- ❌ process (list/poll/log/wait/kill/write/submit/close)
- ❌ read_file (with offset/limit)
- ❌ write_file (with auto-syntax-check)
- ❌ patch (replace + V4A patch mode + fuzzy match)
- ❌ search_files (ripgrep-backed)
- ❌ web_search, web_extract
- ❌ browser_navigate/snapshot/click/type/scroll/back/press/get_images/vision/console/cdp/dialog
- ❌ vision_analyze
- ❌ image_generate (multi-provider)
- ❌ text_to_speech (edge/openai/elevenlabs/minimax)
- ❌ todo (read/write/merge)
- ❌ memory (add/replace/remove × user/memory)
- ❌ session_search
- ❌ clarify (multiple choice / open)
- ❌ execute_code (Python + hermes_tools shim)
- ❌ delegate_task (single + batch + orchestrator role)
- ❌ cronjob (create/list/update/pause/resume/remove/run + no_agent + script + context_from)
- ❌ skills_list / skill_view / skill_manage
- ❌ send_message (cross-platform)
- ❌ mixture_of_agents
- ❌ video_analyze
- ❌ fact_store, fact_feedback (holographic memory tools)
Extended:
- ❌ kanban_* (show/complete/block/heartbeat/comment/create/link)
- ❌ ha_* (Home Assistant)
- ❌ computer_use (macOS)
- ❌ discord_tool, feishu_doc, feishu_drive, yuanbao
- ❌ spotify_* (already partly via plugin)
- ❌ mcp_tool (native MCP client)

## SLICE 4 — Skills System
- ❌ Skill loader (~/.hermes/skills + project skills)
- ❌ SKILL.md parser (YAML frontmatter + body + linked files)
- ❌ skills_list with category filter
- ❌ skill_view with file_path linked-files navigation
- ❌ skill_manage: create/patch/edit/delete/write_file/remove_file
- ❌ Skill validator (frontmatter schema)
- ❌ Skill provenance tracking
- ❌ Skill auto-injection into system prompt when matched

## SLICE 5 — Memory + Cron + Sessions
- ❌ Memory store (memory.md + user.md format) with chunked entries (§ separator)
- ❌ Memory budget enforcement
- ❌ Cron scheduler daemon + storage
- ❌ Cron job execution with prompt/script/skills/context_from chaining
- ❌ Session search (FTS5 over message archive)
- ❌ Holographic memory (fact_store) with entity resolution + trust scoring

## SLICE 6 — Providers & Adapters
- ❌ Provider plugin system
- ❌ Adapters: anthropic, bedrock, gemini-native, gemini-cloudcode, codex-responses, copilot-acp, openai/openrouter, lmstudio
- ❌ Auxiliary client (small/fast model for utility calls)
- ❌ Model catalog + normalize
- ❌ Rate-limit tracker + nous_rate_guard equivalent
- ❌ Fallback chain config + UI

## SLICE 7 — Gateway + Messaging
- 🚧 Gateway exists (90 routes)
- ❌ Telegram platform integration (full message/media/topic support)
- ❌ Discord platform
- ❌ iMessage / SMS via macOS bridge
- ❌ Email (himalaya integration)
- ❌ Channel directory + home channels
- ❌ Webhook subscriptions
- ❌ Builtin gateway hooks
- ❌ Sticker cache + media handling

## SLICE 8 — Plugins + Toolsets
- ❌ Plugin loader (`plugins/<name>/plugin.yaml` + tools/skills)
- ❌ Toolset definitions (`toolsets.py` equivalent) with composition
- ❌ Toolset distributions per platform (CLI vs Telegram vs Discord)
- ❌ Plugins from Hermes: image_gen, kanban, memory, observability, model-providers, spotify, teams_pipeline, etc.

## SLICE 9 — Auth + Onboarding + Setup
- ❌ `cvc setup` wizard (provider auth, model pick, telegram pair)
- ❌ Copilot OAuth flow
- ❌ Google OAuth
- ❌ Provider auth commands (auth login/logout/status)
- ❌ Doctor command (health checks)
- ❌ Backup/restore

## SLICE 10 — Polish
- ❌ Curator (auto skill/memory cleanup background job)
- ❌ Trajectory logging
- ❌ Insights / usage / pricing
- ❌ Title generator for sessions
- ❌ Tips/onboarding hints
- ❌ Plugin marketplace stub
- ❌ Voice mode (wake-word → STT → agent → TTS)

---

## Execution rule
Ship each slice as a working, demoable vertical. Commit per slice. Show Jai a screenshot/keystroke proof
before moving to the next. No invisible plumbing slices. CVC's cognitive core (Cognome, Telepathy,
holographic memory) stays — it's the unique value add on top of Hermes parity.
