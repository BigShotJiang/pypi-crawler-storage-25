#!/usr/bin/env node
// Vendors @cvc/ink into dist/vendor/cvc-ink/ and rewrites all `@cvc/ink` imports
// in dist/ to relative paths. Eliminates the @cvc/ink npm dep at install time.
import { promises as fs } from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, '..')
const dist = path.join(root, 'dist')
const vendorDir = path.join(dist, 'vendor', 'cvc-ink')
const inkSrc = path.join(root, 'packages', 'cvc-ink')

// 1. copy @cvc/ink dist + index files into dist/vendor/cvc-ink/
await fs.mkdir(vendorDir, { recursive: true })
await fs.cp(path.join(inkSrc, 'dist'), path.join(vendorDir, 'dist'), { recursive: true })
await fs.cp(path.join(inkSrc, 'index.js'), path.join(vendorDir, 'index.js'))
await fs.cp(path.join(inkSrc, 'text-input.js'), path.join(vendorDir, 'text-input.js'))
// minimal package.json so node resolves dist/entry-exports.js
await fs.writeFile(
  path.join(vendorDir, 'package.json'),
  JSON.stringify({ name: '@cvc/ink-vendored', type: 'module', main: './index.js', exports: { '.': './index.js', './text-input': './text-input.js' } }, null, 2)
)

// 2. walk dist/ and rewrite `from '@cvc/ink'` and `from '@cvc/ink/text-input'`
async function* walk(dir) {
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name)
    if (entry.isDirectory()) {
      if (entry.name === 'vendor') continue
      yield* walk(p)
    } else if (entry.name.endsWith('.js')) {
      yield p
    }
  }
}

let rewritten = 0
for await (const file of walk(dist)) {
  const rel = path.relative(path.dirname(file), vendorDir)
  const relIdx = rel.startsWith('.') ? rel : './' + rel
  let txt = await fs.readFile(file, 'utf8')
  const before = txt
  // Match: from '@cvc/ink', from "@cvc/ink", from '@cvc/ink/text-input'
  txt = txt.replace(/(['"])@cvc\/ink\/text-input\1/g, `$1${relIdx}/text-input.js$1`)
  txt = txt.replace(/(['"])@cvc\/ink\1/g, `$1${relIdx}/index.js$1`)
  if (txt !== before) {
    await fs.writeFile(file, txt)
    rewritten++
  }
}
console.log(`✓ vendored @cvc/ink → dist/vendor/cvc-ink (rewrote ${rewritten} files)`)
