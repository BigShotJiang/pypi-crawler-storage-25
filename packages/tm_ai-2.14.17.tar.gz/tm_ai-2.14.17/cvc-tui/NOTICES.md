# Third-Party Notices

cvc-tui includes code ported from the Hermes Agent project by Nous Research,
licensed under the MIT License (https://github.com/NousResearch/hermes-agent).

Copyright (c) 2025 Nous Research

Specifically:
- packages/cvc-ink/  — full port of @hermes/ink (Ink fork)
- src/theme.ts       — ported from ui-tui/src/theme.ts (rebranded for CVC)
- src/banner.ts      — structure ported from ui-tui/src/banner.ts (CVC wordmark)

The MIT License terms apply to all such ported code. See LICENSE for details.
