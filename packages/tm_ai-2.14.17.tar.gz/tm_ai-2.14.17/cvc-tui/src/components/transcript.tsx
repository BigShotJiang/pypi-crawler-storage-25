// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Transcript — renders the message history with role-coloured bubbles.
// User bubbles use a red border (CVC primary); assistant uses a neutral
// border. Streaming-in assistant text is rendered via <StreamingMarkdown>;
// settled history uses the cheaper <Markdown>.

import React from 'react';
import { Box, Text } from 'ink';
import { useStore } from '@nanostores/react';
import { $messages, $turn } from '../app/turnStore.js';
import { Markdown, StreamingMarkdown } from './streamingMarkdown.js';
import { CVC_THEME, type Message } from '../types.js';

const Bubble: React.FC<{ msg: Message; streaming?: boolean }> = ({ msg, streaming }) => {
  const isUser = msg.role === 'user';
  const borderColor = isUser ? CVC_THEME.primary : CVC_THEME.dim;
  const tag = isUser ? 'you' : msg.role === 'assistant' ? 'cvc' : msg.role;
  const tagColor = isUser ? CVC_THEME.primary : CVC_THEME.accent;
  return (
    <Box flexDirection="column" marginBottom={1}>
      <Text bold color={tagColor}>
        {`▌ ${tag}`}
      </Text>
      <Box
        borderStyle="round"
        borderColor={borderColor}
        paddingX={1}
        flexDirection="column"
      >
        {isUser ? (
          <Text>{msg.content}</Text>
        ) : streaming ? (
          <StreamingMarkdown content={msg.content} />
        ) : (
          <Markdown text={msg.content} />
        )}
      </Box>
    </Box>
  );
};

export const Transcript: React.FC = () => {
  const messages = useStore($messages);
  const turn = useStore($turn);
  if (messages.length === 0) {
    return (
      <Box marginY={1}>
        <Text color={CVC_THEME.dim}>— no messages yet — type below to start —</Text>
      </Box>
    );
  }
  const lastId = messages[messages.length - 1]?.id;
  return (
    <Box flexDirection="column" marginY={1}>
      {messages.map((m) => (
        <Bubble
          key={m.id}
          msg={m}
          streaming={
            m.role === 'assistant' && m.id === lastId && turn?.status === 'streaming'
          }
        />
      ))}
    </Box>
  );
};
