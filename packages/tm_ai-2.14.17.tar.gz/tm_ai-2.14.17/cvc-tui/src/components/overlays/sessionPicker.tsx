// @ts-nocheck
// CVC sessionPicker overlay — lists ~/.cvc/sessions/*.json with timestamp +
// first-message preview, arrow-key navigable, filter input.
import React, { useEffect, useMemo, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';
import { CVC_THEME } from '../../types.js';
import { filterRows, windowItems } from './overlayUtils.js';

export interface SessionEntry {
  id: string;
  path: string;
  mtime: number;
  preview: string;
  title?: string;
}

export interface SessionPickerProps {
  sessions?: SessionEntry[]; // when omitted, loaded from ~/.cvc/sessions
  onSelect: (id: string) => void;
  onCancel: () => void;
}

const VISIBLE = 10;

/** Load sessions from ~/.cvc/sessions/*.json. Resilient to malformed files. */
export function loadSessions(dir = path.join(os.homedir(), '.cvc', 'sessions')): SessionEntry[] {
  if (!fs.existsSync(dir)) return [];
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
  const out: SessionEntry[] = [];
  for (const f of files) {
    const fp = path.join(dir, f);
    try {
      const stat = fs.statSync(fp);
      const raw = fs.readFileSync(fp, 'utf8');
      const j = JSON.parse(raw) as {
        id?: string;
        title?: string;
        messages?: { role?: string; content?: string }[];
      };
      const first = (j.messages ?? []).find(m => m.role === 'user');
      const preview = (first?.content ?? '').replace(/\s+/g, ' ').trim().slice(0, 80) || '(empty)';
      out.push({
        id: j.id ?? f.replace(/\.json$/, ''),
        path: fp,
        mtime: stat.mtimeMs,
        preview,
        title: j.title,
      });
    } catch {
      // skip malformed
    }
  }
  return out.sort((a, b) => b.mtime - a.mtime);
}

const fmtAge = (ms: number): string => {
  const d = Math.max(0, Date.now() - ms);
  const m = Math.floor(d / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
};

export const SessionPicker: React.FC<SessionPickerProps> = ({ sessions, onSelect, onCancel }) => {
  const [all, setAll] = useState<SessionEntry[]>(sessions ?? []);
  const [query, setQuery] = useState('');
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (!sessions) setAll(loadSessions());
  }, [sessions]);

  const filtered = useMemo(
    () => filterRows(all, query, s => `${s.title ?? ''} ${s.preview} ${s.id}`),
    [all, query],
  );
  const safeIdx = Math.min(idx, Math.max(0, filtered.length - 1));

  useInput((input, key) => {
    if (key.escape) return onCancel();
    if (key.upArrow && safeIdx > 0) return setIdx(safeIdx - 1);
    if (key.downArrow && safeIdx < filtered.length - 1) return setIdx(safeIdx + 1);
    if (key.return) {
      const s = filtered[safeIdx];
      if (s) onSelect(s.id);
      return;
    }
    if (key.backspace || key.delete) {
      setQuery(q => q.slice(0, -1));
      setIdx(0);
      return;
    }
    if (input && !key.ctrl && !key.meta && !key.tab) {
      setQuery(q => q + input);
      setIdx(0);
    }
  });

  const rows = filtered.map(
    s => `${(s.title ?? s.id).slice(0, 24).padEnd(24)} · ${fmtAge(s.mtime).padEnd(10)} · ${s.preview}`,
  );
  const { items, offset } = windowItems(rows, safeIdx, VISIBLE);

  return (
    <Box flexDirection="column">
      <Text color={CVC_THEME.primary} bold>
        Sessions ({filtered.length}/{all.length})
      </Text>
      <Text dimColor>filter: {query || '(none)'}</Text>
      {offset > 0 ? <Text dimColor>{` ↑ ${offset} more`}</Text> : <Text> </Text>}
      {items.length === 0 ? (
        <Text dimColor>no sessions</Text>
      ) : (
        items.map((row, i) => {
          const k = offset + i;
          const active = safeIdx === k;
          return (
            <Text
              key={filtered[k]?.id ?? `s-${k}`}
              color={active ? CVC_THEME.primary : undefined}
              inverse={active}
              bold={active}
            >
              {active ? '▸ ' : '  '}
              {row}
            </Text>
          );
        })
      )}
      {offset + VISIBLE < rows.length ? (
        <Text dimColor>{` ↓ ${rows.length - offset - VISIBLE} more`}</Text>
      ) : (
        <Text> </Text>
      )}
      <Text dimColor>type to filter · ↑/↓ select · Enter resume · Esc cancel</Text>
    </Box>
  );
};
