// @ts-nocheck
// Secret prompt overlay — masked input. Resolves with the entered string,
// or null on Esc.
import React, { useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { useStore } from '@nanostores/react';
import { $prompt, resolveActivePrompt } from '../../app/promptStore.js';

export const SecretPrompt: React.FC = () => {
  const cur = useStore($prompt);
  const [value, setValue] = useState('');
  if (!cur || cur.kind !== 'secret') return null;
  const mask = cur.mask !== false;

  useInput((input, key) => {
    if (key.escape) {
      resolveActivePrompt(null);
      return;
    }
    if (key.return) {
      resolveActivePrompt(value);
      setValue('');
      return;
    }
    if (key.backspace || key.delete) {
      setValue(value.slice(0, -1));
      return;
    }
    if (input && !key.ctrl && !key.meta && !key.tab) {
      setValue(value + input);
      return;
    }
  });

  const display = mask ? '●'.repeat(value.length) : value;

  return (
    <Box flexDirection="column">
      <Box>
        <Text color="#e63946" bold>🔒 </Text>
        <Text>{cur.prompt} </Text>
        <Text>{display}</Text>
      </Box>
      <Box>
        <Text dimColor>Enter to submit · Esc to cancel</Text>
      </Box>
    </Box>
  );
};
