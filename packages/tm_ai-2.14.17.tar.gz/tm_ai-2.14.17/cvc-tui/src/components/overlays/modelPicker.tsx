// @ts-nocheck
// CVC modelPicker overlay — arrow-key navigable, two-stage (provider → model).
// Behavior parity with CVC ui-tui modelPicker, but consumes preloaded data
// via props so it stays trivial to test and wire.
import React, { useMemo, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { CVC_THEME } from '../../types.js';
import { windowItems } from './overlayUtils.js';

export interface ModelProvider {
  slug: string;
  name: string;
  models: string[];
  is_current?: boolean;
}

export interface ModelPickerProps {
  providers: ModelProvider[];
  currentModel?: string;
  onSelect: (provider: string, model: string) => void;
  onCancel: () => void;
}

const VISIBLE = 10;

export const ModelPicker: React.FC<ModelPickerProps> = ({
  providers,
  currentModel,
  onSelect,
  onCancel,
}) => {
  const [stage, setStage] = useState<'provider' | 'model'>('provider');
  const [pIdx, setPIdx] = useState(() =>
    Math.max(0, providers.findIndex(p => p.is_current)),
  );
  const [mIdx, setMIdx] = useState(0);

  const provider = providers[pIdx];
  const models = provider?.models ?? [];

  useInput((_input, key) => {
    if (key.escape) {
      if (stage === 'model') {
        setStage('provider');
        setMIdx(0);
        return;
      }
      onCancel();
      return;
    }
    const count = stage === 'provider' ? providers.length : models.length;
    const sel = stage === 'provider' ? pIdx : mIdx;
    const setSel = stage === 'provider' ? setPIdx : setMIdx;
    if (key.upArrow && sel > 0) return setSel(sel - 1);
    if (key.downArrow && sel < count - 1) return setSel(sel + 1);
    if (key.return) {
      if (stage === 'provider') {
        if (provider) {
          setStage('model');
          setMIdx(0);
        }
        return;
      }
      const m = models[mIdx];
      if (provider && m) onSelect(provider.slug, m);
    }
  });

  const rows = useMemo(() => {
    if (stage === 'provider') {
      return providers.map(p => `${p.is_current ? '*' : '●'} ${p.name} · ${p.models.length} models`);
    }
    return models.map(m => `${m === currentModel ? '*' : ' '} ${m}`);
  }, [stage, providers, models, currentModel]);

  const sel = stage === 'provider' ? pIdx : mIdx;
  const { items, offset } = windowItems(rows, sel, VISIBLE);

  return (
    <Box flexDirection="column">
      <Text color={CVC_THEME.primary} bold>
        {stage === 'provider' ? 'Select provider (1/2)' : `Select model — ${provider?.name ?? ''} (2/2)`}
      </Text>
      <Text dimColor>
        {currentModel ? `current: ${currentModel}` : ' '}
      </Text>
      {offset > 0 ? <Text dimColor>{` ↑ ${offset} more`}</Text> : <Text> </Text>}
      {items.map((row, i) => {
        const idx = offset + i;
        const active = sel === idx;
        return (
          <Text
            key={`${stage}-${idx}`}
            color={active ? CVC_THEME.primary : undefined}
            inverse={active}
            bold={active}
          >
            {active ? '▸ ' : '  '}
            {row}
          </Text>
        );
      })}
      {offset + VISIBLE < rows.length ? (
        <Text dimColor>{` ↓ ${rows.length - offset - VISIBLE} more`}</Text>
      ) : (
        <Text> </Text>
      )}
      <Text dimColor>↑/↓ select · Enter choose · Esc {stage === 'model' ? 'back' : 'cancel'}</Text>
    </Box>
  );
};
