// @ts-nocheck
// Confirmation prompt overlay — y/N (or Enter for default no, Esc cancels).
import React from 'react';
import { Box, Text, useInput } from 'ink';
import { useStore } from '@nanostores/react';
import { $prompt, resolveActivePrompt } from '../../app/promptStore.js';

export const ConfirmPrompt: React.FC = () => {
  const cur = useStore($prompt);
  if (!cur || cur.kind !== 'confirm') return null;
  const destructive = !!cur.destructive;

  useInput((input, key) => {
    if (key.escape) {
      resolveActivePrompt(null);
      return;
    }
    if (input === 'y' || input === 'Y') {
      resolveActivePrompt(true);
      return;
    }
    if (input === 'n' || input === 'N' || key.return) {
      resolveActivePrompt(false);
      return;
    }
  });

  return (
    <Box flexDirection="column">
      <Box>
        <Text color={destructive ? '#e63946' : '#4a9eff'} bold>
          {destructive ? '⚠  ' : '? '}
        </Text>
        <Text>{cur.prompt}</Text>
      </Box>
      <Box>
        <Text dimColor>[y/N] · Enter = no · Esc = cancel</Text>
      </Box>
    </Box>
  );
};
