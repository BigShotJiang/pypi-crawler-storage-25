// @ts-nocheck
// CVC skillsHub overlay — list skills (via gateway or supplied prop), search/filter,
// arrow-key navigable, Enter triggers an onActivate callback (e.g. to inject the
// skill into the next user message).
import React, { useEffect, useMemo, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { CVC_THEME } from '../../types.js';
import { filterRows, windowItems } from './overlayUtils.js';

export interface SkillEntry {
  name: string;
  description?: string;
  category?: string;
}

export interface SkillsHubProps {
  skills?: SkillEntry[]; // when omitted, fetched via loadSkills()
  loadSkills?: () => Promise<SkillEntry[]>;
  onActivate: (skill: SkillEntry) => void;
  onCancel: () => void;
}

const VISIBLE = 12;

export const SkillsHub: React.FC<SkillsHubProps> = ({
  skills,
  loadSkills,
  onActivate,
  onCancel,
}) => {
  const [all, setAll] = useState<SkillEntry[]>(skills ?? []);
  const [loading, setLoading] = useState<boolean>(!skills && Boolean(loadSkills));
  const [query, setQuery] = useState('');
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (skills || !loadSkills) return;
    let cancelled = false;
    loadSkills()
      .then(list => {
        if (!cancelled) {
          setAll(list);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [skills, loadSkills]);

  const filtered = useMemo(
    () => filterRows(all, query, s => `${s.name} ${s.description ?? ''} ${s.category ?? ''}`),
    [all, query],
  );
  const safeIdx = Math.min(idx, Math.max(0, filtered.length - 1));

  useInput((input, key) => {
    if (key.escape) return onCancel();
    if (key.upArrow && safeIdx > 0) return setIdx(safeIdx - 1);
    if (key.downArrow && safeIdx < filtered.length - 1) return setIdx(safeIdx + 1);
    if (key.return) {
      const s = filtered[safeIdx];
      if (s) onActivate(s);
      return;
    }
    if (key.backspace || key.delete) {
      setQuery(q => q.slice(0, -1));
      setIdx(0);
      return;
    }
    if (input && !key.ctrl && !key.meta && !key.tab) {
      setQuery(q => q + input);
      setIdx(0);
    }
  });

  const rows = filtered.map(s => {
    const cat = s.category ? `[${s.category}] ` : '';
    const desc = s.description ? ` — ${s.description}` : '';
    return `${cat}${s.name}${desc}`;
  });
  const { items, offset } = windowItems(rows, safeIdx, VISIBLE);

  return (
    <Box flexDirection="column">
      <Text color={CVC_THEME.primary} bold>
        Skills Hub ({filtered.length}/{all.length})
      </Text>
      <Text dimColor>filter: {query || '(none)'}</Text>
      {loading ? (
        <Text dimColor>loading skills…</Text>
      ) : items.length === 0 ? (
        <Text dimColor>no skills match</Text>
      ) : (
        <>
          {offset > 0 ? <Text dimColor>{` ↑ ${offset} more`}</Text> : <Text> </Text>}
          {items.map((row, i) => {
            const k = offset + i;
            const active = safeIdx === k;
            return (
              <Text
                key={filtered[k]?.name ?? `sk-${k}`}
                color={active ? CVC_THEME.primary : undefined}
                inverse={active}
                bold={active}
              >
                {active ? '▸ ' : '  '}
                {row}
              </Text>
            );
          })}
          {offset + VISIBLE < rows.length ? (
            <Text dimColor>{` ↓ ${rows.length - offset - VISIBLE} more`}</Text>
          ) : (
            <Text> </Text>
          )}
        </>
      )}
      <Text dimColor>type to filter · ↑/↓ select · Enter activate · Esc cancel</Text>
    </Box>
  );
};
