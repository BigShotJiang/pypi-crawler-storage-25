// @ts-nocheck
// CVC helpOverlay — full-screen /help overlay listing every slash command
// from the central registry, grouped by category. Arrow-key scrollable.
import React, { useMemo, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { CVC_THEME } from '../../types.js';
import { SLASH_COMMANDS } from '../../app/slash/registry.js';
import type { SlashCommand } from '../../app/slash/types.js';
import { windowItems } from './overlayUtils.js';

export interface HelpOverlayProps {
  onClose: () => void;
}

const VISIBLE = 18;

interface Row {
  kind: 'header' | 'cmd';
  text: string;
  cmd?: SlashCommand;
}

const ORDER: (SlashCommand['category'] | 'other')[] = [
  'core',
  'session',
  'ops',
  'setup',
  'toggles',
  'debug',
  'other',
];

const TITLES: Record<string, string> = {
  core: 'Core',
  session: 'Sessions',
  ops: 'Models · Skills · Tools',
  setup: 'Setup',
  toggles: 'Toggles',
  debug: 'Debug',
  other: 'Other',
};

function groupCommands(): Row[] {
  const buckets = new Map<string, SlashCommand[]>();
  for (const c of SLASH_COMMANDS) {
    if (c.hidden) continue;
    const k = (c.category ?? 'other') as string;
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k)!.push(c);
  }
  const rows: Row[] = [];
  for (const k of ORDER) {
    const list = buckets.get(k as string);
    if (!list || list.length === 0) continue;
    rows.push({ kind: 'header', text: TITLES[k as string] ?? String(k) });
    list.sort((a, b) => a.name.localeCompare(b.name));
    for (const c of list) {
      const aliases = c.aliases?.length ? ` (${c.aliases.map(a => `/${a}`).join(', ')})` : '';
      rows.push({ kind: 'cmd', text: `/${c.name}${aliases} — ${c.help}`, cmd: c });
    }
  }
  return rows;
}

export const HelpOverlay: React.FC<HelpOverlayProps> = ({ onClose }) => {
  const rows = useMemo(groupCommands, []);
  const [top, setTop] = useState(0);

  useInput((input, key) => {
    if (key.escape || input === 'q' || (key.ctrl && input === 'c')) return onClose();
    if (key.upArrow && top > 0) return setTop(top - 1);
    if (key.downArrow && top < Math.max(0, rows.length - VISIBLE)) return setTop(top + 1);
    if (key.pageUp) return setTop(Math.max(0, top - VISIBLE));
    if (key.pageDown) return setTop(Math.min(Math.max(0, rows.length - VISIBLE), top + VISIBLE));
  });

  const { items, offset } = windowItems(rows, top + Math.floor(VISIBLE / 2), VISIBLE);

  return (
    <Box flexDirection="column">
      <Text color={CVC_THEME.primary} bold>
        CVC — slash commands ({rows.filter(r => r.kind === 'cmd').length})
      </Text>
      {offset > 0 ? <Text dimColor>{` ↑ ${offset} more`}</Text> : <Text> </Text>}
      {items.map((row, i) => {
        const k = `${offset + i}-${row.kind}`;
        if (row.kind === 'header') {
          return (
            <Text key={k} color={CVC_THEME.primary} bold>
              {row.text}
            </Text>
          );
        }
        return (
          <Text key={k} dimColor={false}>
            {'  '}
            {row.text}
          </Text>
        );
      })}
      {offset + VISIBLE < rows.length ? (
        <Text dimColor>{` ↓ ${rows.length - offset - VISIBLE} more`}</Text>
      ) : (
        <Text> </Text>
      )}
      <Text dimColor>↑/↓ scroll · PgUp/PgDn page · Esc/q close</Text>
    </Box>
  );
};
