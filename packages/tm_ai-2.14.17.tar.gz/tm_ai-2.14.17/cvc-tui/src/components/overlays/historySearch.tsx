// @ts-nocheck
// Reverse-incremental history search overlay (Ctrl+R).
// Keystrokes refine the query; Up/Down moves through matches; Enter accepts;
// Esc cancels.
import React, { useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { searchHistory } from '../../app/historyStore.js';

export interface HistorySearchProps {
  onAccept: (entry: string) => void;
  onCancel: () => void;
}

export const HistorySearch: React.FC<HistorySearchProps> = ({ onAccept, onCancel }) => {
  const [query, setQuery] = useState('');
  const [index, setIndex] = useState(0);

  const matches = searchHistory(query, 50);
  const current = matches[index] ?? '';

  useInput((input, key) => {
    if (key.escape || (key.ctrl && input === 'g')) {
      onCancel();
      return;
    }
    if (key.return) {
      if (current) onAccept(current);
      else onCancel();
      return;
    }
    if (key.upArrow || (key.ctrl && input === 'r')) {
      if (matches.length > 0) setIndex(Math.min(matches.length - 1, index + 1));
      return;
    }
    if (key.downArrow || (key.ctrl && input === 's')) {
      setIndex(Math.max(0, index - 1));
      return;
    }
    if (key.backspace || key.delete) {
      setQuery(query.slice(0, -1));
      setIndex(0);
      return;
    }
    if (input && !key.ctrl && !key.meta && !key.tab) {
      setQuery(query + input);
      setIndex(0);
      return;
    }
  });

  return (
    <Box flexDirection="column">
      <Box>
        <Text color="#e63946">(reverse-i-search)</Text>
        <Text>{`'${query}': `}</Text>
        <Text>{current}</Text>
      </Box>
      <Box>
        <Text dimColor>
          {matches.length > 0
            ? `${index + 1}/${matches.length} match${matches.length === 1 ? '' : 'es'} · ↑/↓ navigate · Enter accept · Esc cancel`
            : 'no matches · Esc cancel'}
        </Text>
      </Box>
    </Box>
  );
};
