// @ts-nocheck
// Tiny shared helpers for CVC arrow-key navigable overlays.
// Keeps modelPicker / sessionPicker / skillsHub / helpOverlay consistent
// without dragging in the heavier CVC overlayControls surface.

export interface Windowed<T> {
  items: T[];
  offset: number;
}

/** Window a list around the selected index so a cursor at any depth stays visible. */
export function windowItems<T>(all: T[], selected: number, visible: number): Windowed<T> {
  if (all.length <= visible) return { items: all, offset: 0 };
  const half = Math.floor(visible / 2);
  let offset = Math.max(0, Math.min(all.length - visible, selected - half));
  return { items: all.slice(offset, offset + visible), offset };
}

/** Filter a list of strings by a case-insensitive substring (q is the query). */
export function filterRows<T>(rows: T[], q: string, key: (t: T) => string): T[] {
  const needle = q.trim().toLowerCase();
  if (!needle) return rows;
  return rows.filter(r => key(r).toLowerCase().includes(needle));
}
