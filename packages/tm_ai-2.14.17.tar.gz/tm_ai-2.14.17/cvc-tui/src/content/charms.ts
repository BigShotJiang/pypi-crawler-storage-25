// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
export const LONG_RUN_CHARMS = ['still cooking…', 'polishing edges…', 'asking the void nicely…']
