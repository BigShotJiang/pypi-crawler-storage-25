// Queue store + prompt store unit coverage.
import { describe, it, expect, beforeEach } from 'vitest';
import { $queue, enqueue, dequeueAll, queueLength, clearQueue } from '../app/queueStore.js';
import { $prompt, requestConfirm, requestSecret, resolveActivePrompt } from '../app/promptStore.js';

describe('queueStore', () => {
  beforeEach(() => clearQueue());

  it('enqueues messages and exposes length for the indicator', () => {
    enqueue('first');
    enqueue('second');
    expect(queueLength()).toBe(2);
    expect($queue.get()).toEqual(['first', 'second']);
  });

  it('enqueue ignores empty / whitespace-only entries', () => {
    enqueue('');
    enqueue('   ');
    expect(queueLength()).toBe(0);
  });

  it('dequeueAll drains the queue', () => {
    enqueue('a');
    enqueue('b');
    expect(dequeueAll()).toEqual(['a', 'b']);
    expect(queueLength()).toBe(0);
  });
});

describe('promptStore', () => {
  beforeEach(() => $prompt.set(null));

  it('requestConfirm publishes a confirm prompt and resolves on action', async () => {
    const p = requestConfirm('Delete it?', { destructive: true });
    expect($prompt.get()?.kind).toBe('confirm');
    expect($prompt.get()?.destructive).toBe(true);
    resolveActivePrompt(true);
    await expect(p).resolves.toBe(true);
    expect($prompt.get()).toBeNull();
  });

  it('requestSecret returns null on Esc (resolveActivePrompt(null))', async () => {
    const p = requestSecret('Token?', { mask: true });
    expect($prompt.get()?.kind).toBe('secret');
    expect($prompt.get()?.mask).toBe(true);
    resolveActivePrompt(null);
    await expect(p).resolves.toBeNull();
  });

  it('requestSecret resolves with the entered string', async () => {
    const p = requestSecret('Token?');
    resolveActivePrompt('hunter2');
    await expect(p).resolves.toBe('hunter2');
  });

  it('secret masking renders ● per character (length-preserving)', () => {
    const value = 'hunter2';
    const masked = '●'.repeat(value.length);
    expect(masked.length).toBe(value.length);
    expect(masked).toBe('●●●●●●●');
    expect(masked).not.toContain('h');
  });
});
