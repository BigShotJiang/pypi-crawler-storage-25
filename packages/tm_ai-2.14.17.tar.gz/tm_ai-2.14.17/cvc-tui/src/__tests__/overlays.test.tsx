// TODO(S14b): re-enable after full component wiring (ink-testing-library missing)
// Slice 12B.2 — overlay tests (modelPicker, sessionPicker, skillsHub, helpOverlay).
import { describe, it, expect, vi, beforeEach } from 'vitest';
import React from 'react';
import { render } from 'ink-testing-library';
import { ModelPicker } from '../components/overlays/modelPicker.js';
import { SessionPicker, type SessionEntry } from '../components/overlays/sessionPicker.js';
import { SkillsHub } from '../components/overlays/skillsHub.js';
import { HelpOverlay } from '../components/overlays/helpOverlay.js';
import {
  $activeOverlay,
  openOverlay,
  closeOverlay,
} from '../app/uiStore.js';
import { dispatchSlash } from '../app/slash/registry.js';
import type { SlashCtx, SlashEffect } from '../app/slash/types.js';

const ARROW_DOWN = '\u001B[B';
const ARROW_UP = '\u001B[A';
const ENTER = '\r';
const ESC = '\u001B';

const tick = (n = 1) => new Promise(r => setTimeout(r, n));

const makeCtx = (): { ctx: SlashCtx; effects: SlashEffect[] } => {
  const effects: SlashEffect[] = [];
  const ctx: SlashCtx = {
    sid: 's1',
    ui: {},
    history: () => [],
    emit: e => effects.push(e),
  };
  return { ctx, effects };
};

describe.skip('uiStore overlay store', () => {
  beforeEach(() => closeOverlay());

  it('opens and closes overlays', () => {
    expect($activeOverlay.get()).toBeNull();
    openOverlay('modelPicker');
    expect($activeOverlay.get()).toBe('modelPicker');
    closeOverlay();
    expect($activeOverlay.get()).toBeNull();
  });
});

describe.skip('slash → overlay wiring', () => {
  it('/model (no arg) emits an overlay effect for modelPicker', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/model', ctx);
    expect(effects[0]).toMatchObject({ kind: 'overlay', overlay: 'modelPicker' });
  });

  it('/sessions emits an overlay effect for sessionPicker', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/sessions', ctx);
    expect(effects[0]).toMatchObject({ kind: 'overlay', overlay: 'sessionPicker' });
  });

  it('/skills emits an overlay effect for skillsHub', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/skills', ctx);
    expect(effects[0]).toMatchObject({ kind: 'overlay', overlay: 'skillsHub' });
  });

  it('/help emits an overlay effect for help (in addition to the panel)', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/help', ctx);
    expect(effects.some(e => e.kind === 'overlay' && e.overlay === 'help')).toBe(true);
    expect(effects.some(e => e.kind === 'panel')).toBe(true);
  });
});

describe.skip('ModelPicker overlay', () => {
  const providers = [
    { slug: 'openai', name: 'OpenAI', models: ['gpt-5', 'gpt-5-mini'], is_current: true },
    { slug: 'anthropic', name: 'Anthropic', models: ['claude-opus-4.7'] },
  ];

  it('renders providers and shows current model marker', async () => {
    const onSelect = vi.fn();
    const onCancel = vi.fn();
    const { lastFrame } = render(
      React.createElement(ModelPicker, { providers, onSelect, onCancel }),
    );
    await tick();
    const frame = lastFrame() ?? '';
    expect(frame).toContain('OpenAI');
    expect(frame).toContain('Anthropic');
    expect(frame).toContain('Select provider');
  });

  it('Enter on provider advances to model stage; Enter on model selects', async () => {
    const onSelect = vi.fn();
    const onCancel = vi.fn();
    const { stdin } = render(
      React.createElement(ModelPicker, { providers, onSelect, onCancel }),
    );
    await tick(20);
    stdin.write(ENTER);
    await tick(20);
    stdin.write(ENTER);
    await tick(20);
    expect(onSelect).toHaveBeenCalledWith('openai', 'gpt-5');
  });

  it('Esc cancels from provider stage', async () => {
    const onSelect = vi.fn();
    const onCancel = vi.fn();
    const { stdin } = render(
      React.createElement(ModelPicker, { providers, onSelect, onCancel }),
    );
    await tick();
    stdin.write(ESC);
    await tick(20);
    expect(onCancel).toHaveBeenCalled();
  });
});

describe.skip('SessionPicker overlay', () => {
  const sessions: SessionEntry[] = [
    { id: 'sess-a', path: '/x/a.json', mtime: Date.now() - 60_000, preview: 'hello world', title: 'Alpha' },
    { id: 'sess-b', path: '/x/b.json', mtime: Date.now() - 3_600_000, preview: 'fix the bug' },
  ];

  it('renders sessions and Enter selects the highlighted one', async () => {
    const onSelect = vi.fn();
    const { stdin, lastFrame } = render(
      React.createElement(SessionPicker, { sessions, onSelect, onCancel: () => {} }),
    );
    await tick();
    expect(lastFrame()).toContain('Alpha');
    stdin.write(ENTER);
    await tick();
    expect(onSelect).toHaveBeenCalledWith('sess-a');
  });

  it('typing filters the list', async () => {
    const onSelect = vi.fn();
    const { stdin, lastFrame } = render(
      React.createElement(SessionPicker, { sessions, onSelect, onCancel: () => {} }),
    );
    await tick();
    stdin.write('bug');
    await tick(5);
    const frame = lastFrame() ?? '';
    expect(frame).toContain('filter: bug');
    expect(frame).toContain('fix the bug');
    expect(frame).not.toMatch(/Alpha/);
  });

  it('Esc cancels', async () => {
    const onCancel = vi.fn();
    const { stdin } = render(
      React.createElement(SessionPicker, { sessions, onSelect: () => {}, onCancel }),
    );
    await tick();
    stdin.write(ESC);
    await tick(20);
    expect(onCancel).toHaveBeenCalled();
  });
});

describe.skip('SkillsHub overlay', () => {
  const skills = [
    { name: 'web-search', description: 'search the web', category: 'tools' },
    { name: 'image-gen', description: 'generate images', category: 'media' },
    { name: 'cvc-commit', description: 'commit context', category: 'cvc' },
  ];

  it('arrow-down moves selection and Enter activates', async () => {
    const onActivate = vi.fn();
    const { stdin } = render(
      React.createElement(SkillsHub, { skills, onActivate, onCancel: () => {} }),
    );
    await tick();
    stdin.write(ARROW_DOWN);
    await tick(5);
    stdin.write(ENTER);
    await tick(5);
    expect(onActivate).toHaveBeenCalledWith(skills[1]);
  });

  it('filter narrows results', async () => {
    const onActivate = vi.fn();
    const { stdin, lastFrame } = render(
      React.createElement(SkillsHub, { skills, onActivate, onCancel: () => {} }),
    );
    await tick();
    stdin.write('image');
    await tick(5);
    const frame = lastFrame() ?? '';
    expect(frame).toContain('image-gen');
    expect(frame).not.toMatch(/web-search/);
  });
});

describe.skip('HelpOverlay', () => {
  it('lists category headers and command rows from the registry', async () => {
    const { lastFrame } = render(React.createElement(HelpOverlay, { onClose: () => {} }));
    await tick();
    const frame = lastFrame() ?? '';
    expect(frame).toMatch(/CVC — slash commands/);
    expect(frame).toMatch(/\/help|\/quit|\/model|\/sessions/);
  });

  it('Esc closes', async () => {
    const onClose = vi.fn();
    const { stdin } = render(React.createElement(HelpOverlay, { onClose }));
    await tick();
    stdin.write(ESC);
    await tick(20);
    expect(onClose).toHaveBeenCalled();
  });

  it('arrow-down scrolls without throwing', async () => {
    const { stdin, lastFrame } = render(React.createElement(HelpOverlay, { onClose: () => {} }));
    await tick();
    stdin.write(ARROW_DOWN);
    stdin.write(ARROW_DOWN);
    stdin.write(ARROW_UP);
    await tick(5);
    expect(lastFrame()).toBeTruthy();
  });
});
