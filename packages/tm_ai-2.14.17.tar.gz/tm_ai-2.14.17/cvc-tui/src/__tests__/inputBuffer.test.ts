// Tests for inputBuffer pure helpers.
import { describe, it, expect } from 'vitest';
import {
  emptyBuffer,
  insert,
  backspace,
  moveLeft,
  moveRight,
  moveUp,
  moveDown,
  onFirstLine,
  onLastLine,
  wrapText,
  bufferStats,
  cursorRowCol,
} from '../app/inputBuffer.js';

describe('inputBuffer', () => {
  it('insert places text at cursor and advances cursor', () => {
    const b = insert(emptyBuffer(), 'hello');
    expect(b.text).toBe('hello');
    expect(b.cursor).toBe(5);
  });

  it('Alt+Enter style: inserting \\n keeps cursor logic correct', () => {
    let b = emptyBuffer();
    b = insert(b, 'foo');
    b = insert(b, '\n'); // Alt+Enter equivalent
    b = insert(b, 'bar');
    expect(b.text).toBe('foo\nbar');
    expect(cursorRowCol(b)).toEqual({ row: 1, col: 3 });
    expect(onLastLine(b)).toBe(true);
    expect(onFirstLine(b)).toBe(false);
  });

  it('backspace removes char before cursor', () => {
    let b = insert(emptyBuffer(), 'abc');
    b = backspace(b);
    expect(b.text).toBe('ab');
    expect(b.cursor).toBe(2);
  });

  it('arrow nav left/right respects bounds', () => {
    let b = insert(emptyBuffer(), 'hi');
    b = moveLeft(b);
    expect(b.cursor).toBe(1);
    b = moveLeft(b);
    b = moveLeft(b);
    expect(b.cursor).toBe(0);
    b = moveRight(b);
    expect(b.cursor).toBe(1);
  });

  it('moveUp/moveDown navigate logical lines', () => {
    let b = insert(emptyBuffer(), 'one\ntwo\nthree');
    expect(onLastLine(b)).toBe(true);
    b = moveUp(b);
    expect(cursorRowCol(b).row).toBe(1);
    b = moveUp(b);
    expect(onFirstLine(b)).toBe(true);
    b = moveDown(b);
    expect(cursorRowCol(b).row).toBe(1);
  });

  it('wrapText word-wraps to columns', () => {
    const rows = wrapText('the quick brown fox jumps', 10);
    for (const r of rows) expect(r.length).toBeLessThanOrEqual(10);
    expect(rows.join('').replace(/\s+/g, ' ').trim()).toContain('quick');
  });

  it('bufferStats counts chars and lines', () => {
    expect(bufferStats('a\nb\nc')).toEqual({ chars: 5, lineCount: 3 });
    expect(bufferStats('')).toEqual({ chars: 0, lineCount: 1 });
  });
});
