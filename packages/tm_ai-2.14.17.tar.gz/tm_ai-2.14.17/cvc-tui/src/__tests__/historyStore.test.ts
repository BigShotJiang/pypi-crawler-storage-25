// History persistence + dedup + reverse-search.
import { describe, it, expect, beforeEach } from 'vitest';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import {
  $history,
  setHistoryPath,
  loadHistory,
  pushHistory,
  searchHistory,
  historyPrev,
  historyNext,
  resetHistoryBrowse,
  HISTORY_MAX,
} from '../app/historyStore.js';

function tmpFile(): string {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'cvc-hist-')), 'agent_history');
}

describe('historyStore', () => {
  beforeEach(() => {
    $history.set([]);
    resetHistoryBrowse();
  });

  it('persists entries to the configured path', () => {
    const f = tmpFile();
    setHistoryPath(f);
    pushHistory('first');
    pushHistory('second');
    expect(fs.readFileSync(f, 'utf8').split('\n').filter(Boolean)).toEqual(['first', 'second']);
  });

  it('dedups consecutive duplicate entries', () => {
    setHistoryPath(tmpFile());
    pushHistory('echo hello');
    pushHistory('echo hello');
    pushHistory('echo hello');
    expect($history.get()).toEqual(['echo hello']);
    pushHistory('echo world');
    pushHistory('echo hello'); // not consecutive — kept
    expect($history.get()).toEqual(['echo hello', 'echo world', 'echo hello']);
  });

  it('loads from disk', () => {
    const f = tmpFile();
    fs.writeFileSync(f, 'a\nb\nc\n');
    setHistoryPath(f);
    const loaded = loadHistory();
    expect(loaded).toEqual(['a', 'b', 'c']);
    expect($history.get()).toEqual(['a', 'b', 'c']);
  });

  it('caps at HISTORY_MAX entries', () => {
    setHistoryPath(tmpFile());
    // Push HISTORY_MAX + 5 unique entries.
    for (let i = 0; i < HISTORY_MAX + 5; i++) pushHistory(`cmd-${i}`);
    expect($history.get().length).toBe(HISTORY_MAX);
    expect($history.get()[0]).toBe('cmd-5'); // oldest dropped
  });

  it('reverse search returns most-recent matches first', () => {
    setHistoryPath(tmpFile());
    pushHistory('git status');
    pushHistory('git log');
    pushHistory('cvc commit');
    pushHistory('git diff');
    const matches = searchHistory('git');
    expect(matches[0]).toBe('git diff');
    expect(matches).toContain('git status');
    expect(matches).toContain('git log');
    expect(matches).not.toContain('cvc commit');
  });

  it('Up/Down history cursor walks entries and restores draft', () => {
    setHistoryPath(tmpFile());
    pushHistory('one');
    pushHistory('two');
    pushHistory('three');
    expect(historyPrev('draft')).toBe('three');
    expect(historyPrev('draft')).toBe('two');
    expect(historyPrev('draft')).toBe('one');
    expect(historyPrev('draft')).toBe('one'); // pinned
    expect(historyNext()).toBe('two');
    expect(historyNext()).toBe('three');
    expect(historyNext()).toBe('draft'); // fallthrough restores draft
  });
});
