// Gateway client tests — exercise the JSON-RPC plumbing through a fake
// transport (PassThrough streams). No real Python subprocess is spawned.

import { describe, it, expect, beforeEach } from 'vitest';
import { PassThrough } from 'node:stream';
import { GatewayClient, osc8Link, type Transport } from '../gateway/client.js';

const makeFakeTransport = () => {
  const stdin = new PassThrough();
  const stdout = new PassThrough();
  const stderr = new PassThrough();
  const writtenLines: string[] = [];
  // Capture stdin writes line by line.
  let buf = '';
  stdin.on('data', (chunk: Buffer) => {
    buf += chunk.toString('utf-8');
    let nl = buf.indexOf('\n');
    while (nl >= 0) {
      writtenLines.push(buf.slice(0, nl));
      buf = buf.slice(nl + 1);
      nl = buf.indexOf('\n');
    }
  });
  let exitCb: ((code: number | null) => void) | null = null;
  const transport: Transport = {
    stdin,
    stdout,
    stderr,
    kill: () => {},
    on: (event, cb) => {
      if (event === 'exit') exitCb = cb;
    },
  };
  return {
    transport,
    stdout,
    stderr,
    writtenLines,
    triggerExit(code: number | null) {
      exitCb?.(code);
    },
  };
};

const sendFrame = (stdout: PassThrough, frame: object) => {
  stdout.write(JSON.stringify(frame) + '\n');
};

describe('GatewayClient', () => {
  let f: ReturnType<typeof makeFakeTransport>;
  beforeEach(() => {
    f = makeFakeTransport();
  });

  it('handshakes via session.info on connect()', async () => {
    const client = new GatewayClient({ transport: f.transport });
    const connectPromise = client.connect();
    // Await one tick so the request is written.
    await new Promise((r) => setImmediate(r));
    expect(f.writtenLines.length).toBe(1);
    const req = JSON.parse(f.writtenLines[0]!);
    expect(req.jsonrpc).toBe('2.0');
    expect(req.method).toBe('session.info');
    expect(req.id).toBeDefined();
    sendFrame(f.stdout, {
      jsonrpc: '2.0',
      id: req.id,
      result: {
        version: '2.14.0',
        model: 'claude-sonnet-4-6',
        provider: 'anthropic',
        cwd: '/tmp',
        session_id: 'abc123',
      },
    });
    const info = await connectPromise;
    expect(info.session_id).toBe('abc123');
    expect(client.isConnected()).toBe(true);
  });

  it('streams chat.delta events into onDelta callbacks', async () => {
    const client = new GatewayClient({ transport: f.transport });
    const connectPromise = client.connect();
    await new Promise((r) => setImmediate(r));
    const handshake = JSON.parse(f.writtenLines[0]!);
    sendFrame(f.stdout, {
      jsonrpc: '2.0',
      id: handshake.id,
      result: { version: 'v', model: 'm', provider: 'p', cwd: '/', session_id: 's' },
    });
    await connectPromise;

    const deltas: string[] = [];
    let started = false;
    let done: Record<string, unknown> | null = null;
    const chatPromise = client.sendChat(
      { message: 'hello' },
      {
        onStart: () => {
          started = true;
        },
        onDelta: (t) => deltas.push(t),
        onDone: (s) => {
          done = s;
        },
      },
    );
    await new Promise((r) => setImmediate(r));
    const sendReq = JSON.parse(f.writtenLines[1]!);
    expect(sendReq.method).toBe('chat.send');
    expect(sendReq.params.message).toBe('hello');

    sendFrame(f.stdout, { jsonrpc: '2.0', method: 'chat.start', params: { provider: 'p', model: 'm' } });
    sendFrame(f.stdout, { jsonrpc: '2.0', method: 'chat.delta', params: { text: 'Hel' } });
    sendFrame(f.stdout, { jsonrpc: '2.0', method: 'chat.delta', params: { text: 'lo!' } });
    sendFrame(f.stdout, { jsonrpc: '2.0', method: 'chat.done', params: { chars: 6 } });
    sendFrame(f.stdout, { jsonrpc: '2.0', id: sendReq.id, result: { chars: 6 } });

    const summary = await chatPromise;
    expect(started).toBe(true);
    expect(deltas.join('')).toBe('Hello!');
    expect(done).not.toBeNull();
    expect(summary.chars).toBe(6);
  });

  it('rejects pending RPCs when the gateway exits unexpectedly', async () => {
    const client = new GatewayClient({ transport: f.transport });
    const connectPromise = client.connect();
    await new Promise((r) => setImmediate(r));
    f.triggerExit(1);
    await expect(connectPromise).rejects.toThrow(/exited/);
    expect(client.isConnected()).toBe(false);
  });

  it('surfaces RPC errors with code + message', async () => {
    const client = new GatewayClient({ transport: f.transport });
    const connectPromise = client.connect();
    await new Promise((r) => setImmediate(r));
    const req = JSON.parse(f.writtenLines[0]!);
    sendFrame(f.stdout, {
      jsonrpc: '2.0',
      id: req.id,
      error: { code: -32601, message: 'method not found' },
    });
    await expect(connectPromise).rejects.toThrow(/method not found/);
  });

  it('emits stderr lines as events', async () => {
    const client = new GatewayClient({ transport: f.transport });
    const lines: string[] = [];
    client.on('stderr', (l: string) => lines.push(l));
    void client.connect().catch(() => {});
    f.stderr.write('hello stderr\n');
    await new Promise((r) => setImmediate(r));
    expect(lines).toContain('hello stderr');
  });

  it('osc8Link wraps text in OSC 8 escape sequences', () => {
    const out = osc8Link('https://example.com', 'click me');
    expect(out).toContain('\x1b]8;;https://example.com\x1b\\');
    expect(out).toContain('click me');
    expect(out.endsWith('\x1b]8;;\x1b\\')).toBe(true);
  });
});
