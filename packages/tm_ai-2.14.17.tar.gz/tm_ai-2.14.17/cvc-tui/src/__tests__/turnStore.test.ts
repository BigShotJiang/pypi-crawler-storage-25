// Turn store tests — verifies streaming delta append behaviour.
import { describe, it, expect, beforeEach } from 'vitest';
import {
  $messages,
  $turn,
  appendDelta,
  beginAssistantTurn,
  clearTranscript,
  endTurn,
  pushUserMessage,
} from '../app/turnStore.js';

// TODO(S14d): re-enable after gateway wiring + store API reconciliation
describe.skip('turnStore', () => {
  beforeEach(() => clearTranscript());

  it('records a user message then begins an assistant turn', () => {
    const uid = pushUserMessage('hello');
    const aid = beginAssistantTurn();
    expect($messages.get().length).toBe(2);
    expect($messages.get()[0]!.id).toBe(uid);
    expect($messages.get()[1]!.id).toBe(aid);
    expect($turn.get()?.status).toBe('streaming');
  });

  it('appendDelta concatenates onto the in-flight assistant message', () => {
    pushUserMessage('hi');
    beginAssistantTurn();
    appendDelta('Hel');
    appendDelta('lo, ');
    appendDelta('world!');
    const list = $messages.get();
    expect(list[list.length - 1]!.content).toBe('Hello, world!');
  });

  it('endTurn flips status to done', () => {
    beginAssistantTurn();
    endTurn();
    expect($turn.get()?.status).toBe('done');
  });

  it('endTurn with error flips status to error', () => {
    beginAssistantTurn();
    endTurn('boom');
    expect($turn.get()?.status).toBe('error');
    expect($turn.get()?.error).toBe('boom');
  });
});
