import { describe, it, expect } from 'vitest';
import { CVC_BANNER, CVC_TAGLINE, BANNER_COLOR, renderBannerPlain } from '../banner.js';

describe('banner', () => {
  it('exposes a non-empty CVC ASCII banner', () => {
    expect(CVC_BANNER.length).toBeGreaterThan(20);
    expect(CVC_BANNER.split('\n').length).toBeGreaterThanOrEqual(5);
  });

  it('uses the CVC red as the banner colour', () => {
    expect(BANNER_COLOR.toLowerCase()).toBe('#e63946');
  });

  it('renders plain banner with version + model', () => {
    const out = renderBannerPlain({ version: '1.2.3', model: 'gpt-x' });
    expect(out).toContain(CVC_TAGLINE);
    expect(out).toContain('v1.2.3');
    expect(out).toContain('gpt-x');
  });
});
