// TODO(S14b): re-enable after full component wiring (ink-testing-library missing)
// Streaming markdown renderer tests.

import { describe, it, expect } from 'vitest';
import { render } from 'ink-testing-library';
import React from 'react';
import {
  Markdown,
  StreamingMarkdown,
  findStableBoundary,
  osc8Link,
} from '../components/streamingMarkdown.js';

describe.skip('findStableBoundary', () => {
  it('returns -1 when no blank line yet', () => {
    expect(findStableBoundary('one line of text')).toBe(-1);
  });
  it('finds the last blank-line boundary', () => {
    const text = 'first paragraph\n\nsecond';
    expect(findStableBoundary(text)).toBe('first paragraph\n\n'.length);
  });
  it('skips boundaries inside an open code fence', () => {
    const text = 'pre\n\n```py\n\nfn():\n  pass';
    // The blank line inside the unclosed code fence is unsafe; the
    // boundary before the fence (after "pre\n\n") is safe.
    expect(findStableBoundary(text)).toBe('pre\n\n'.length);
  });
});

describe.skip('Markdown rendering', () => {
  it('renders a heading with bold text', () => {
    const { lastFrame } = render(React.createElement(Markdown, { text: '# Hello world' }));
    const frame = lastFrame();
    expect(frame).toContain('Hello world');
    expect(frame).toContain('#');
  });

  it('renders a fenced code block with language header', () => {
    const md = '```js\nconst x = 1;\n```';
    const { lastFrame } = render(React.createElement(Markdown, { text: md }));
    const frame = lastFrame()!;
    expect(frame).toContain('const x = 1;');
    // Language header rendered above code.
    expect(frame).toContain('js');
  });

  it('renders bullet list items', () => {
    const md = '- alpha\n- beta\n- gamma';
    const { lastFrame } = render(React.createElement(Markdown, { text: md }));
    const frame = lastFrame()!;
    expect(frame).toContain('alpha');
    expect(frame).toContain('beta');
    expect(frame).toContain('gamma');
    expect(frame).toMatch(/[•·]/);
  });

  it('renders inline code with background styling', () => {
    const md = 'use `fn()` to call it';
    const { lastFrame } = render(React.createElement(Markdown, { text: md }));
    expect(lastFrame()).toContain('fn()');
  });

  it('renders links as OSC 8 hyperlinks', () => {
    const md = 'see [example](https://example.com) for details';
    const { lastFrame } = render(React.createElement(Markdown, { text: md }));
    const frame = lastFrame()!;
    expect(frame).toContain('\x1b]8;;https://example.com\x1b\\');
    expect(frame).toContain('example');
  });

  it('renders blockquotes with a left bar', () => {
    const md = '> quoted text';
    const { lastFrame } = render(React.createElement(Markdown, { text: md }));
    const frame = lastFrame()!;
    expect(frame).toContain('quoted text');
    expect(frame).toContain('│');
  });
});

describe.skip('StreamingMarkdown', () => {
  it('renders streaming-in text without crashing on partial input', () => {
    const partial = '# Heading\n\nstreaming par';
    const { lastFrame } = render(React.createElement(StreamingMarkdown, { content: partial }));
    expect(lastFrame()).toContain('Heading');
    expect(lastFrame()).toContain('streaming par');
  });
});

describe.skip('osc8Link helper', () => {
  it('produces a valid OSC 8 sequence', () => {
    const s = osc8Link('https://x.com', 'hi');
    expect(s).toBe('\x1b]8;;https://x.com\x1b\\hi\x1b]8;;\x1b\\');
  });
});
