// Tab completion: slash + path candidates.
import { describe, it, expect, beforeAll } from 'vitest';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import {
  tokenAtCursor,
  slashCandidates,
  pathCandidates,
  candidatesFor,
  applyCandidate,
} from '../app/completion.js';

// TODO(S14d): re-enable after gateway wiring + store API reconciliation
describe.skip('completion', () => {
  it('detects slash command tokens at line start', () => {
    const ctx = tokenAtCursor('/he', 3);
    expect(ctx).not.toBeNull();
    expect(ctx!.isSlash).toBe(true);
    expect(ctx!.token).toBe('/he');
    expect(ctx!.start).toBe(0);
  });

  it('does not treat mid-message slashes as slash commands', () => {
    const text = 'see /etc/passwd';
    const ctx = tokenAtCursor(text, text.length);
    expect(ctx!.isSlash).toBe(false);
    expect(ctx!.isPath).toBe(true);
  });

  it('slashCandidates filters by prefix', () => {
    const c = slashCandidates('/c');
    expect(c.length).toBeGreaterThan(0);
    expect(c).toContain('/clear');
    expect(c.every((n) => n.startsWith('/c'))).toBe(true);
  });

  let tmpDir: string;
  beforeAll(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cvc-comp-'));
    fs.writeFileSync(path.join(tmpDir, 'alpha.txt'), '');
    fs.writeFileSync(path.join(tmpDir, 'alphabet.txt'), '');
    fs.mkdirSync(path.join(tmpDir, 'beta'));
  });

  it('pathCandidates lists matching files + dirs (dirs suffixed with /)', () => {
    const prefix = path.join(tmpDir, 'al');
    const c = pathCandidates(prefix);
    expect(c).toContain(path.join(tmpDir, 'alpha.txt'));
    expect(c).toContain(path.join(tmpDir, 'alphabet.txt'));
  });

  it('pathCandidates suffixes directories with /', () => {
    const prefix = path.join(tmpDir, 'b');
    const c = pathCandidates(prefix);
    expect(c.some((p) => p.endsWith('/'))).toBe(true);
  });

  it('expands ~/ to homedir', () => {
    const c = pathCandidates('~/');
    // Should at least not throw and return something for a real homedir.
    expect(Array.isArray(c)).toBe(true);
  });

  it('candidatesFor delegates to the right backend', () => {
    expect(candidatesFor({ start: 0, token: '/h', isSlash: true, isPath: false })).toEqual(
      expect.arrayContaining(['/help']),
    );
  });

  it('applyCandidate replaces the token in place', () => {
    const r = applyCandidate('hello /he world', 6, 3, '/help');
    expect(r.text).toBe('hello /help world');
    expect(r.cursor).toBe(11);
  });
});
