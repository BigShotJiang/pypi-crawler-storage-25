import { describe, it, expect } from 'vitest';
import {
  SLASH_COMMANDS,
  findSlashCommand,
  listSlashNames,
  dispatchSlash,
} from '../app/slash/registry.js';
import type { SlashCtx, SlashEffect } from '../app/slash/types.js';
import { flagFromArg } from '../app/slash/types.js';

const makeCtx = (
  overrides: Partial<SlashCtx> = {},
): { ctx: SlashCtx; effects: SlashEffect[] } => {
  const effects: SlashEffect[] = [];
  const ctx: SlashCtx = {
    sid: 'sess-test',
    ui: {},
    history: () => [],
    emit: e => effects.push(e),
    ...overrides,
  };
  return { ctx, effects };
};

// TODO(S14d): re-enable after gateway wiring + store API reconciliation
describe.skip('slash registry', () => {
  it('contains every documented Hermes-parity command', () => {
    const expected = [
      'help', 'clear', 'quit', 'exit', 'status', 'usage', 'history', 'save',
      'resume', 'sessions', 'new', 'model', 'provider', 'skills', 'reload-skills',
      'agents', 'memory', 'mem', 'tools', 'reload', 'reload-mcp', 'compact',
      'compress', 'branch', 'checkpoint', 'rollback', 'undo', 'retry', 'stop',
      'steer', 'verbose', 'reasoning', 'fast', 'yolo', 'personality', 'skin',
      'title', 'statusbar', 'indicator', 'redraw', 'paste', 'copy', 'image',
      'voice', 'background', 'busy', 'queue', 'logs', 'heapdump', 'fortune',
      'setup', 'terminal-setup', 'replay', 'replay-diff', 'browser', 'mouse',
      'details',
    ];
    for (const name of expected) {
      expect(findSlashCommand(name), `expected /${name} to exist`).toBeDefined();
    }
  });

  it('listSlashNames returns sorted "/"-prefixed names', () => {
    const names = listSlashNames();
    expect(names.length).toBeGreaterThanOrEqual(40);
    expect(names[0].startsWith('/')).toBe(true);
    const sorted = [...names].sort();
    expect(names).toEqual(sorted);
  });

  it('aliases resolve to the same command', () => {
    expect(findSlashCommand('exit')?.name).toBe('quit');
    expect(findSlashCommand('q')?.name).toBe('quit');
    expect(findSlashCommand('mem')?.name).toBe('memory');
    expect(findSlashCommand('detail')?.name).toBe('details');
    expect(findSlashCommand('sb')?.name).toBe('statusbar');
  });

  it('flagFromArg parses on/off/toggle', () => {
    expect(flagFromArg('on', false)).toBe(true);
    expect(flagFromArg('off', true)).toBe(false);
    expect(flagFromArg('', true)).toBe(false);
    expect(flagFromArg('toggle', true)).toBe(false);
    expect(flagFromArg('garbage', true)).toBe(null);
  });

  it('every command has a name + help + run', () => {
    for (const c of SLASH_COMMANDS) {
      expect(c.name).toMatch(/^[a-z][a-z0-9-]*$/);
      expect(c.help.length).toBeGreaterThan(0);
      expect(typeof c.run).toBe('function');
    }
  });
});

// TODO(S14d): re-enable after gateway wiring + store API reconciliation
describe.skip('dispatchSlash', () => {
  it('returns false for non-slash lines', async () => {
    const { ctx } = makeCtx();
    expect(await dispatchSlash('hello there', ctx)).toBe(false);
  });

  it('handles unknown commands with a friendly message', async () => {
    const { ctx, effects } = makeCtx();
    expect(await dispatchSlash('/nope', ctx)).toBe(true);
    expect(effects[0].text).toContain('unknown command');
  });

  it('/help emits a panel', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/help', ctx);
    expect(effects.some(e => e.kind === 'panel')).toBe(true);
  });

  it('/quit emits die', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/quit', ctx);
    expect(effects.some(e => e.kind === 'die')).toBe(true);
  });

  it('/sessions opens the sessionPicker overlay', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/sessions', ctx);
    expect(effects[0]).toMatchObject({ kind: 'overlay', overlay: 'sessionPicker' });
  });

  it('/model with no arg opens modelPicker overlay', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/model', ctx);
    expect(effects[0]).toMatchObject({ kind: 'overlay', overlay: 'modelPicker' });
  });

  it('/model <name> emits config.set rpc', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/model gpt-5', ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.method).toBe('config.set');
    expect(rpc?.params).toMatchObject({ key: 'model', value: 'gpt-5' });
  });

  it('toggle commands flip the ui state and report it', async () => {
    const { ctx, effects } = makeCtx({ ui: { yolo: false } });
    await dispatchSlash('/yolo on', ctx);
    expect(effects.some(e => e.kind === 'patchUi' && (e.ui as Record<string, unknown>).yolo === true)).toBe(true);
    expect(effects.some(e => e.kind === 'sys' && e.text === 'yolo on')).toBe(true);
  });

  it('/details cycle advances the mode', async () => {
    const { ctx, effects } = makeCtx({ ui: { detailsMode: 'hidden' } });
    await dispatchSlash('/details cycle', ctx);
    const patch = effects.find(e => e.kind === 'patchUi');
    expect((patch?.ui as Record<string, unknown>).detailsMode).toBe('collapsed');
  });

  it('/history with empty transcript reports nothing yet', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/history', ctx);
    expect(effects[0].text).toContain('no conversation yet');
  });

  it('/history paginates conversation', async () => {
    const messages = [
      { role: 'user', content: 'hi' },
      { role: 'assistant', content: 'hello back' },
    ];
    const { ctx, effects } = makeCtx({ history: () => messages });
    await dispatchSlash('/history 200', ctx);
    expect(effects[0].kind).toBe('page');
    expect(effects[0].text).toContain('hi');
    expect(effects[0].text).toContain('hello back');
  });

  it('/branch requires a name', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/branch', ctx);
    expect(effects[0].text).toContain('usage');
  });

  it('/branch with name emits cvc.branch rpc', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/branch wild-idea', ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.method).toBe('cvc.branch');
    expect(rpc?.params).toMatchObject({ name: 'wild-idea' });
  });
});

// -- Slice 12B.4 parity polish ----------------------------------------------
// TODO(S14d): re-enable after gateway wiring + store API reconciliation
describe.skip('slash parity (Slice 12B.4)', () => {
  it('ships at least 50 commands matching CVC ui-tui surface', () => {
    expect(SLASH_COMMANDS.length).toBeGreaterThanOrEqual(50);
  });

  it('every documented command in the parity list resolves', () => {
    const parity = [
      '/help', '/clear', '/quit', '/exit', '/status', '/usage', '/history',
      '/save', '/resume', '/sessions', '/new', '/model', '/provider',
      '/skills', '/reload-skills', '/agents', '/memory', '/mem', '/tools',
      '/reload', '/reload-mcp', '/compact', '/compress', '/branch',
      '/checkpoint', '/rollback', '/undo', '/retry', '/stop', '/steer',
      '/verbose', '/reasoning', '/fast', '/yolo', '/personality', '/skin',
      '/title', '/statusbar', '/indicator', '/redraw', '/paste', '/copy',
      '/image', '/voice', '/background', '/busy', '/queue', '/logs',
      '/heapdump', '/fortune', '/setup', '/terminal-setup', '/replay',
      '/replay-diff', '/browser', '/mouse', '/details',
    ];
    for (const name of parity) {
      expect(findSlashCommand(name), `expected ${name} to resolve`).toBeDefined();
    }
  });

  it('/model gpt-4 parses argument and emits config.set', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/model gpt-4', ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.method).toBe('config.set');
    expect(rpc?.params).toMatchObject({ key: 'model', value: 'gpt-4' });
  });

  it("/title 'foo bar' strips surrounding single quotes", async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash("/title 'foo bar'", ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.method).toBe('session.title');
    expect(rpc?.params).toMatchObject({ title: 'foo bar' });
  });

  it('/title "quoted with spaces" strips double quotes', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/title "quoted with spaces"', ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.params).toMatchObject({ title: 'quoted with spaces' });
  });

  it('/quit and /exit resolve to the same command', () => {
    const quit = findSlashCommand('quit');
    const exit = findSlashCommand('exit');
    expect(quit).toBeDefined();
    expect(exit).toBe(quit);
  });

  it('unknown command emits a friendly system message', async () => {
    const { ctx, effects } = makeCtx();
    const handled = await dispatchSlash('/totally-not-a-command', ctx);
    expect(handled).toBe(true);
    expect(effects[0].kind).toBe('sys');
    expect(effects[0].text).toMatch(/unknown command/);
    expect(effects[0].text).toMatch(/try \/help/);
  });

  it('toggle commands cover the full parity flag set', () => {
    for (const name of ['verbose', 'reasoning', 'fast', 'yolo', 'busy',
      'queue', 'background', 'browser', 'voice', 'image']) {
      expect(findSlashCommand(name)?.category).toBe('toggles');
    }
  });

  it('/statusbar bottom updates ui state', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/statusbar bottom', ctx);
    const patch = effects.find(e => e.kind === 'patchUi');
    expect((patch?.ui as Record<string, unknown>).statusBar).toBe('bottom');
  });

  it('/replay-diff requires two ids', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/replay-diff', ctx);
    expect(effects[0].text).toContain('usage');
  });

  it('/replay-diff a b emits rpc with both ids', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/replay-diff sess-a sess-b', ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.method).toBe('session.replayDiff');
    expect(rpc?.params).toMatchObject({ a: 'sess-a', b: 'sess-b' });
  });

  it('/rollback without arg shows usage', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/rollback', ctx);
    expect(effects[0].text).toContain('usage');
  });

  it('/rollback <hash> emits cvc.restore rpc', async () => {
    const { ctx, effects } = makeCtx();
    await dispatchSlash('/rollback abc123', ctx);
    const rpc = effects.find(e => e.kind === 'rpc');
    expect(rpc?.method).toBe('cvc.restore');
    expect(rpc?.params).toMatchObject({ commit_hash: 'abc123' });
  });
});
