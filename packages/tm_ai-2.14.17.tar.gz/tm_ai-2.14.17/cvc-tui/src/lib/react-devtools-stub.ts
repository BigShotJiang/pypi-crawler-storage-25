// SPDX-License-Identifier: MIT
// Noop stub for react-devtools-core — used only when DEV=true is set in env.
// Inlined into the bundle so that the published cvc-tui doesn't require an
// external dev-only dependency at runtime.
const noop = () => undefined
const stub = {
  initialize: noop,
  connectToDevTools: noop,
}
export default stub
export const initialize = noop
export const connectToDevTools = noop
