// SPDX-License-Identifier: MIT
// Builds an offline SessionInfo from local config + filesystem so the TUI
// welcome screen renders rich content even when the gateway is down.
//
// The gateway's session.info RPC is the ideal source of truth (it knows the
// active model, full skill registry, MCP statuses, etc.). When it isn't
// reachable we degrade gracefully instead of showing a wasteland.

import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

import type { SessionInfo } from '../types.js'

interface LocalConfig {
  primary_provider?: string
  default_model?: string
}

const SAFE_TOOL_DIRS = new Set(['__pycache__'])

function readYamlMinimal(path: string): LocalConfig {
  // Tiny single-level YAML reader — enough for `key: value` lines.
  // We deliberately avoid pulling in `js-yaml` here; the welcome screen
  // is rendered before any heavy deps load.
  try {
    const raw = readFileSync(path, 'utf-8')
    const out: LocalConfig = {}
    for (const line of raw.split('\n')) {
      const m = line.match(/^([a-z_]+):\s*(.+?)\s*$/i)
      if (!m) continue
      const [, k, v] = m
      const cleaned = v.replace(/^['"]|['"]$/g, '')
      ;(out as Record<string, string>)[k] = cleaned
    }
    return out
  } catch {
    return {}
  }
}

function listDirs(path: string): string[] {
  try {
    return readdirSync(path)
      .filter(name => !name.startsWith('.') && !SAFE_TOOL_DIRS.has(name))
      .filter(name => {
        try {
          return statSync(join(path, name)).isDirectory()
        } catch {
          return false
        }
      })
      .sort()
  } catch {
    return []
  }
}

function listToolFiles(path: string): string[] {
  try {
    return readdirSync(path)
      .filter(name => name.endsWith('.py') && !name.startsWith('_'))
      .map(name => name.slice(0, -3))
      .sort()
  } catch {
    return []
  }
}

function findCvcSitePackages(): string | null {
  // Prefer uv-tool install layout, then a couple of common fallbacks.
  const candidates = [
    join(homedir(), '.local/share/uv/tools/tm-ai/lib/python3.12/site-packages/cvc'),
    join(homedir(), '.local/share/uv/tools/tm-ai/lib/python3.13/site-packages/cvc'),
    join(homedir(), '.local/share/uv/tools/tm-ai/lib/python3.11/site-packages/cvc'),
  ]
  for (const c of candidates) {
    if (existsSync(c)) return c
  }
  return null
}

function readCvcVersion(): string {
  // CVC_VERSION is set by the Python launcher (cvc/cli/agent.py).
  const envV = process.env.CVC_VERSION
  if (envV) return envV
  return '0.0.0+unknown'
}

export function buildLocalSessionInfo(): SessionInfo {
  const configDir = process.env.CVC_CONFIG_DIR || join(homedir(), '.cvc')
  const cfg = readYamlMinimal(join(configDir, 'config.yaml'))
  const sitePkg = findCvcSitePackages()

  const tools: Record<string, string[]> = {}
  const skills: Record<string, string[]> = {}

  if (sitePkg) {
    // Top-level tool modules grouped under `core`
    const coreTools = listToolFiles(join(sitePkg, 'tools'))
    if (coreTools.length) tools.core = coreTools

    // Tool subdirectories (browser, file_ops, web, messaging, media, skills)
    for (const sub of listDirs(join(sitePkg, 'tools'))) {
      const items = listToolFiles(join(sitePkg, 'tools', sub))
      if (items.length) tools[sub] = items
    }

    // Bundled skills — each subdir is a skill name; group under `bundled`.
    const bundled = listDirs(join(sitePkg, 'bundled_skills'))
    if (bundled.length) skills.bundled = bundled
  }

  return {
    cwd: process.cwd(),
    lazy: false,
    mcp_servers: [],
    model: cfg.default_model
      ? `${cfg.primary_provider ?? 'local'}/${cfg.default_model}`
      : 'unknown/offline',
    skills,
    tools,
    update_command: 'cvc update',
    version: readCvcVersion(),
  }
}
