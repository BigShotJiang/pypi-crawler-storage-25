// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
//
// CVC ASCII banner. Rendered once at startup by <Branding/>.
// Colour applied at render-time via Ink <Text color="..."> wrappers.

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

function readPkgVersion(): string {
  try {
    // src/banner.ts → ../package.json (src) or dist/banner.js → ../package.json (dist)
    const here = dirname(fileURLToPath(import.meta.url));
    const candidates = [resolve(here, '../package.json'), resolve(here, '../../package.json')];
    for (const p of candidates) {
      try {
        const raw = readFileSync(p, 'utf8');
        const parsed = JSON.parse(raw) as { name?: string; version?: string };
        if (parsed.name === 'cvc-tui' && typeof parsed.version === 'string') {
          return parsed.version;
        }
      } catch {
        /* try next */
      }
    }
  } catch {
    /* fall through */
  }
  return '0.0.0';
}

export const CVC_BANNER = String.raw`
  ██████╗██╗   ██╗ ██████╗
 ██╔════╝██║   ██║██╔════╝
 ██║     ██║   ██║██║
 ██║     ╚██╗ ██╔╝██║
 ╚██████╗ ╚████╔╝ ╚██████╗
  ╚═════╝  ╚═══╝   ╚═════╝
`.trim();

export const CVC_TAGLINE = 'Cognitive Version Control — git for your AI\u2019s mind';
export const CVC_BOOT_TIP = 'Type /help for commands · Ctrl+C to exit';

export const BANNER_COLOR = '#e63946';
export const TAGLINE_COLOR = '#4a9eff';

/**
 * Version of cvc-tui as published in package.json.
 * Wired here so the banner is never out-of-date with the package version
 * (this fixes the v0.0.1 fallback bug).
 */
export const CVC_VERSION: string = readPkgVersion();

export interface BannerOpts {
  version?: string;
  model?: string;
}

/**
 * Returns the banner as a plain (uncoloured) string suitable for tests
 * and for non-TTY fallbacks. The TTY renderer colours it via Ink.
 */
export function renderBannerPlain({ version = CVC_VERSION, model = 'unknown' }: BannerOpts = {}): string {
  return [CVC_BANNER, '', `${CVC_TAGLINE}  v${version}  ·  model: ${model}`, CVC_BOOT_TIP].join('\n');
}

// --- Compatibility shims for branding.tsx ---------------------------------
// branding.tsx (ported from hermes-ref) expects logo()/caduceus()/artWidth()
// helpers returning [color, text] line tuples. CVC ships its own ASCII banner
// instead of the hermes hero art, so we provide thin wrappers that splice the
// CVC banner lines into that shape. Width constants are conservative defaults
// matched to CVC_BANNER above.
type Line = [string | undefined, string]

export const LOGO_WIDTH = 28
export const CADUCEUS_WIDTH = 28

const _bannerLines = (color: string): Line[] =>
  CVC_BANNER.split('\n').map(t => [color, t] as Line)

export const logo = (_c?: unknown, _customLogo?: string): Line[] =>
  _bannerLines(BANNER_COLOR)

export const caduceus = (_c?: unknown, _customHero?: string): Line[] =>
  _bannerLines(BANNER_COLOR)

export const artWidth = (lines: Line[]): number =>
  lines.reduce((m, [, t]) => Math.max(m, t.length), 0)
