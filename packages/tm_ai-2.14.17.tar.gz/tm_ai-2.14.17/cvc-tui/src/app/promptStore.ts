// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Prompt store — confirmation + secret prompts requested by any subsystem.
// The composer hides while a prompt is active; the prompt overlay owns input.
import { atom } from 'nanostores';

export type PromptKind = 'confirm' | 'secret';

export interface PromptRequest {
  id: string;
  kind: PromptKind;
  prompt: string;
  destructive?: boolean;
  mask?: boolean;
}

export type PromptResolver = (value: string | boolean | null) => void;

interface InternalPrompt extends PromptRequest {
  resolve: PromptResolver;
}

export const $prompt = atom<InternalPrompt | null>(null);

let counter = 0;
function nextId(): string {
  counter += 1;
  return `prompt_${Date.now()}_${counter}`;
}

/** Request a yes/no confirmation. Resolves with `true`/`false`, or `null` on Esc. */
export function requestConfirm(prompt: string, opts: { destructive?: boolean } = {}): Promise<boolean | null> {
  return new Promise((resolve) => {
    $prompt.set({
      id: nextId(),
      kind: 'confirm',
      prompt,
      destructive: opts.destructive,
      resolve: (v) => resolve(v as boolean | null),
    });
  });
}

/** Request a secret. Resolves with the entered string, or `null` on Esc. */
export function requestSecret(prompt: string, opts: { mask?: boolean } = {}): Promise<string | null> {
  return new Promise((resolve) => {
    $prompt.set({
      id: nextId(),
      kind: 'secret',
      prompt,
      mask: opts.mask !== false,
      resolve: (v) => resolve(v as string | null),
    });
  });
}

export function resolveActivePrompt(value: string | boolean | null): void {
  const cur = $prompt.get();
  if (!cur) return;
  cur.resolve(value);
  $prompt.set(null);
}
