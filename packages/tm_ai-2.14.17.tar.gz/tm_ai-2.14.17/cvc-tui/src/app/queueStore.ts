// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Queue store — submissions made while a turn is streaming are queued
// and flushed when the active turn ends. Composer shows `[queued: N]`.
import { atom } from 'nanostores';

export const $queue = atom<string[]>([]);

export function enqueue(text: string): void {
  const t = text.replace(/\s+$/g, '');
  if (!t) return;
  $queue.set([...$queue.get(), t]);
}

export function dequeueAll(): string[] {
  const cur = $queue.get();
  $queue.set([]);
  return cur;
}

export function queueLength(): number {
  return $queue.get().length;
}

export function clearQueue(): void {
  $queue.set([]);
}
