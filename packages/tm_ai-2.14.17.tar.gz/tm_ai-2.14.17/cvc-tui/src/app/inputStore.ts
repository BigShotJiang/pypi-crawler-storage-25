// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Composer state — kept in a nanostore so any subsystem can read/write
// without prop-drilling. Holds the active text buffer + completion state.
import { atom } from 'nanostores';
import { emptyBuffer, type Buffer } from './inputBuffer.js';

export const $buffer = atom<Buffer>(emptyBuffer());

export interface CompletionState {
  active: boolean;
  prefix: string; // the token being completed
  candidates: string[];
  index: number;
  /** Where in the buffer the prefix starts (so we can replace it). */
  start: number;
}

export const $completion = atom<CompletionState>({
  active: false,
  prefix: '',
  candidates: [],
  index: 0,
  start: 0,
});

export function resetCompletion(): void {
  $completion.set({ active: false, prefix: '', candidates: [], index: 0, start: 0 });
}

export function setBuffer(b: Buffer): void {
  $buffer.set(b);
  // Any non-Tab edit should reset the completion cycle.
  resetCompletion();
}

/** Direct setter that does not reset completion (used by the cycle itself). */
export function setBufferRaw(b: Buffer): void {
  $buffer.set(b);
}
