// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Pure text-buffer helpers for the multi-line composer.
// Kept side-effect-free so they can be unit-tested without Ink/React.

export interface Buffer {
  text: string;
  cursor: number; // index into text, 0..text.length
}

export function emptyBuffer(): Buffer {
  return { text: '', cursor: 0 };
}

export function insert(buf: Buffer, s: string): Buffer {
  const text = buf.text.slice(0, buf.cursor) + s + buf.text.slice(buf.cursor);
  return { text, cursor: buf.cursor + s.length };
}

export function backspace(buf: Buffer): Buffer {
  if (buf.cursor === 0) return buf;
  const text = buf.text.slice(0, buf.cursor - 1) + buf.text.slice(buf.cursor);
  return { text, cursor: buf.cursor - 1 };
}

export function del(buf: Buffer): Buffer {
  if (buf.cursor >= buf.text.length) return buf;
  const text = buf.text.slice(0, buf.cursor) + buf.text.slice(buf.cursor + 1);
  return { text, cursor: buf.cursor };
}

export function moveLeft(buf: Buffer): Buffer {
  return { ...buf, cursor: Math.max(0, buf.cursor - 1) };
}

export function moveRight(buf: Buffer): Buffer {
  return { ...buf, cursor: Math.min(buf.text.length, buf.cursor + 1) };
}

export function moveHome(buf: Buffer): Buffer {
  // Move to start of current logical line.
  const before = buf.text.slice(0, buf.cursor);
  const nl = before.lastIndexOf('\n');
  return { ...buf, cursor: nl < 0 ? 0 : nl + 1 };
}

export function moveEnd(buf: Buffer): Buffer {
  const after = buf.text.slice(buf.cursor);
  const nl = after.indexOf('\n');
  return { ...buf, cursor: nl < 0 ? buf.text.length : buf.cursor + nl };
}

/** Lines split on \n (keeps empty trailing line). */
export function lines(text: string): string[] {
  return text.split('\n');
}

/** Convert cursor offset to {row, col} on logical lines. */
export function cursorRowCol(buf: Buffer): { row: number; col: number } {
  const before = buf.text.slice(0, buf.cursor);
  const ls = before.split('\n');
  return { row: ls.length - 1, col: ls[ls.length - 1].length };
}

/** Move cursor up one logical line, preserving column when possible. */
export function moveUp(buf: Buffer): Buffer {
  const { row, col } = cursorRowCol(buf);
  if (row === 0) return buf;
  const ls = lines(buf.text);
  const targetCol = Math.min(col, ls[row - 1].length);
  // Compute new offset: sum of lines 0..row-2 + their newlines + targetCol.
  let off = 0;
  for (let i = 0; i < row - 1; i++) off += ls[i].length + 1;
  off += targetCol;
  return { ...buf, cursor: off };
}

export function moveDown(buf: Buffer): Buffer {
  const { row, col } = cursorRowCol(buf);
  const ls = lines(buf.text);
  if (row >= ls.length - 1) return buf;
  const targetCol = Math.min(col, ls[row + 1].length);
  let off = 0;
  for (let i = 0; i < row + 1; i++) off += ls[i].length + 1;
  off += targetCol;
  return { ...buf, cursor: off };
}

/** True when the cursor is on the first logical line. */
export function onFirstLine(buf: Buffer): boolean {
  return cursorRowCol(buf).row === 0;
}

/** True when the cursor is on the last logical line. */
export function onLastLine(buf: Buffer): boolean {
  return cursorRowCol(buf).row === lines(buf.text).length - 1;
}

/**
 * Word-wrap a logical line into visual rows of width `cols`.
 * Returns array of strings (each ≤ cols chars). Tries to break at spaces.
 */
export function wrapLine(line: string, cols: number): string[] {
  if (cols <= 0) return [line];
  if (line.length <= cols) return [line];
  const out: string[] = [];
  let rest = line;
  while (rest.length > cols) {
    let cut = cols;
    // Look for a space to break at, within a small window.
    const window = rest.slice(0, cols);
    const lastSpace = window.lastIndexOf(' ');
    if (lastSpace > Math.floor(cols * 0.5)) {
      cut = lastSpace + 1;
    }
    out.push(rest.slice(0, cut));
    rest = rest.slice(cut);
  }
  if (rest.length) out.push(rest);
  return out;
}

/** Wrap the full text, returning visual rows. */
export function wrapText(text: string, cols: number): string[] {
  return text.split('\n').flatMap((l) => (l.length === 0 ? [''] : wrapLine(l, cols)));
}

/** Stats for the dim status footer. */
export function bufferStats(text: string): { chars: number; lineCount: number } {
  return { chars: text.length, lineCount: text.split('\n').length };
}
