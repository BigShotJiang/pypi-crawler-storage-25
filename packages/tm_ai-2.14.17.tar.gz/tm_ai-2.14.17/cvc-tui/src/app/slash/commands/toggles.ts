// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Trivial toggle-style commands — boolean UI flags routed through patchUi
// + a config.set RPC so the gateway can persist them.

import type { SlashCommand } from '../types.js';
import { flagFromArg } from '../types.js';

interface Toggle {
  name: string;
  aliases?: string[];
  help: string;
  key: string;          // ui state key
  configKey?: string;   // gateway config key (defaults to name)
}

const TOGGLES: Toggle[] = [
  { name: 'verbose',     help: 'toggle verbose logging',          key: 'verbose' },
  { name: 'reasoning',   help: 'toggle reasoning trace display',  key: 'reasoning' },
  { name: 'fast',        help: 'toggle fast mode (skip extras)',  key: 'fast' },
  { name: 'yolo',        help: 'toggle YOLO mode (auto-approve)', key: 'yolo' },
  { name: 'busy',        help: 'toggle busy indicator',           key: 'busy' },
  { name: 'queue',       help: 'toggle queued-input mode',        key: 'queue' },
  { name: 'background',  help: 'toggle background-task display',  key: 'background' },
  { name: 'browser',     help: 'toggle browser tool',             key: 'browserEnabled', aliases: ['br'] },
  { name: 'voice',       help: 'toggle voice input/output',       key: 'voice' },
  { name: 'image',       help: 'toggle inline image rendering',   key: 'image' },
];

export const toggleCommands: SlashCommand[] = TOGGLES.map(t => ({
  name: t.name,
  aliases: t.aliases,
  category: 'toggles',
  help: t.help,
  run: (arg, ctx) => {
    const cur = Boolean(ctx.ui[t.key]);
    const next = flagFromArg(arg, cur);
    if (next === null) {
      ctx.emit({ kind: 'sys', text: `usage: /${t.name} [on|off|toggle]` });
      return;
    }
    ctx.emit({ kind: 'patchUi', ui: { [t.key]: next } });
    ctx.emit({
      kind: 'rpc',
      method: 'config.set',
      params: { key: t.configKey ?? t.name, value: next ? 'on' : 'off' },
    });
    ctx.emit({ kind: 'sys', text: `${t.name} ${next ? 'on' : 'off'}` });
  },
}));
