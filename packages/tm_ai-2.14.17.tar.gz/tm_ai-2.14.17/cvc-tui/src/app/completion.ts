// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Tab-completion logic. Pure functions where possible, with one
// fs-touching helper for path expansion.
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { listCommandNames } from './slash/registry.js';

export interface CompletionContext {
  /** Token start offset within the buffer text. */
  start: number;
  /** Token text. */
  token: string;
  /** Whether token looks like a slash command. */
  isSlash: boolean;
  /** Whether token looks like a path. */
  isPath: boolean;
}

/**
 * Find the token under the cursor: a maximal run of non-whitespace ending at
 * `cursor`. Returns null when no token (cursor on whitespace at boundary).
 */
export function tokenAtCursor(text: string, cursor: number): CompletionContext | null {
  if (cursor < 0) cursor = 0;
  if (cursor > text.length) cursor = text.length;
  let s = cursor;
  while (s > 0 && !/\s/.test(text[s - 1]!)) s--;
  const tok = text.slice(s, cursor);
  if (!tok) return null;
  const isSlash = tok.startsWith('/') && s === firstNonSpaceOnLine(text, s);
  const isPath = !isSlash && (tok.startsWith('~/') || tok.startsWith('./') || tok.startsWith('../') || tok.startsWith('/'));
  return { start: s, token: tok, isSlash, isPath };
}

function firstNonSpaceOnLine(text: string, off: number): number {
  // Walk back to start of logical line, then forward over spaces/tabs.
  const lineStart = text.lastIndexOf('\n', off - 1) + 1;
  let i = lineStart;
  while (i < text.length && (text[i] === ' ' || text[i] === '\t')) i++;
  return i;
}

/** Slash-command candidates whose name starts with `prefix`. */
export function slashCandidates(prefix: string): string[] {
  return listCommandNames()
    .filter((n: string) => n.startsWith(prefix))
    .sort();
}

/**
 * Path candidates for `prefix`. Reads the parent directory and returns
 * matching entries (files + dirs, dirs suffixed with `/`).
 *
 * Side-effect: touches the filesystem (fs.readdirSync).
 */
export function pathCandidates(prefix: string): string[] {
  let abs = prefix;
  let displayPrefix = prefix;
  if (prefix.startsWith('~/')) {
    abs = path.join(os.homedir(), prefix.slice(2));
  }
  // Decide directory + leaf to filter by.
  const lastSlash = abs.lastIndexOf('/');
  let dirAbs: string;
  let dirDisplay: string;
  let leaf: string;
  if (lastSlash < 0) {
    dirAbs = '.';
    dirDisplay = '';
    leaf = abs;
  } else {
    dirAbs = abs.slice(0, lastSlash + 1) || '/';
    dirDisplay = displayPrefix.slice(0, lastSlash + 1);
    leaf = abs.slice(lastSlash + 1);
  }
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dirAbs, { withFileTypes: true });
  } catch {
    return [];
  }
  const out: string[] = [];
  for (const e of entries) {
    if (!e.name.startsWith(leaf)) continue;
    if (leaf === '' && e.name.startsWith('.')) continue; // skip hidden when no leaf
    out.push(dirDisplay + e.name + (e.isDirectory() ? '/' : ''));
  }
  return out.sort();
}

/** Compute candidates for the given context. */
export function candidatesFor(ctx: CompletionContext): string[] {
  if (ctx.isSlash) return slashCandidates(ctx.token);
  if (ctx.isPath) return pathCandidates(ctx.token);
  return [];
}

/** Apply a candidate to the buffer at the given start offset (replacing token). */
export function applyCandidate(text: string, start: number, tokenLen: number, candidate: string): { text: string; cursor: number } {
  const before = text.slice(0, start);
  const after = text.slice(start + tokenLen);
  const next = before + candidate + after;
  return { text: next, cursor: start + candidate.length };
}
