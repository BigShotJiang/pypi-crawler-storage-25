// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// History store — persists user input to ~/.cvc/agent_history.
// One entry per line, dedup against immediate previous, max 10000.
import { atom } from 'nanostores';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';

export const HISTORY_MAX = 10000;

function defaultHistoryPath(): string {
  return path.join(os.homedir(), '.cvc', 'agent_history');
}

let historyPath = defaultHistoryPath();

/** Used by tests to redirect persistence. */
export function setHistoryPath(p: string): void {
  historyPath = p;
}

export function getHistoryPath(): string {
  return historyPath;
}

export const $history = atom<string[]>([]);

/**
 * Cursor pointing into history while user is browsing with Up/Down.
 * `null` means "not browsing" (i.e. at the live edit buffer).
 */
export const $historyCursor = atom<number | null>(null);

/** Snapshot of the live buffer so we can restore it after browsing. */
export const $historyDraft = atom<string>('');

export function loadHistory(): string[] {
  try {
    if (!fs.existsSync(historyPath)) {
      $history.set([]);
      return [];
    }
    const raw = fs.readFileSync(historyPath, 'utf8');
    // Drop empty trailing line, ignore blank lines.
    const lines = raw.split('\n').filter((l) => l.length > 0);
    $history.set(lines);
    return lines;
  } catch {
    $history.set([]);
    return [];
  }
}

/** Append an entry, dedup-against-previous, cap at HISTORY_MAX, persist. */
export function pushHistory(entry: string): void {
  const trimmed = entry.replace(/\s+$/g, '');
  if (!trimmed) return;
  const cur = $history.get();
  if (cur.length > 0 && cur[cur.length - 1] === trimmed) {
    // Dedup consecutive duplicates without rewriting the file.
    return;
  }
  let next = [...cur, trimmed];
  if (next.length > HISTORY_MAX) {
    next = next.slice(next.length - HISTORY_MAX);
  }
  $history.set(next);
  persist();
}

export function persist(): void {
  try {
    fs.mkdirSync(path.dirname(historyPath), { recursive: true });
    fs.writeFileSync(historyPath, $history.get().join('\n') + '\n', 'utf8');
  } catch {
    // Best-effort — never crash the UI on history I/O failure.
  }
}

/**
 * Reverse-incremental search. Returns up to `limit` matches, most-recent-first.
 */
export function searchHistory(query: string, limit = 50): string[] {
  if (!query) return [];
  const q = query.toLowerCase();
  const out: string[] = [];
  const cur = $history.get();
  for (let i = cur.length - 1; i >= 0 && out.length < limit; i--) {
    if (cur[i].toLowerCase().includes(q)) out.push(cur[i]);
  }
  return out;
}

/** Move history cursor toward older entries; returns the entry text or null. */
export function historyPrev(currentDraft: string): string | null {
  const h = $history.get();
  if (h.length === 0) return null;
  let idx = $historyCursor.get();
  if (idx === null) {
    $historyDraft.set(currentDraft);
    idx = h.length - 1;
  } else if (idx > 0) {
    idx -= 1;
  }
  $historyCursor.set(idx);
  return h[idx];
}

/** Move history cursor toward newer entries; returns the entry text or null on fall-through. */
export function historyNext(): string | null {
  const h = $history.get();
  const idx = $historyCursor.get();
  if (idx === null) return null;
  if (idx >= h.length - 1) {
    // Fell off the end: restore draft.
    $historyCursor.set(null);
    return $historyDraft.get();
  }
  const next = idx + 1;
  $historyCursor.set(next);
  return h[next];
}

export function resetHistoryBrowse(): void {
  $historyCursor.set(null);
  $historyDraft.set('');
}
