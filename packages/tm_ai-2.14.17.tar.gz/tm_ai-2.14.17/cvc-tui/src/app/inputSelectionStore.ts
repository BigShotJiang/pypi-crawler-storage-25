// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
import { atom } from 'nanostores'

export interface InputSelection {
  clear: () => void
  collapseToEnd: () => void
  end: number
  start: number
  value: string
}

export const $inputSelection = atom<InputSelection | null>(null)

export const setInputSelection = (next: InputSelection | null) => $inputSelection.set(next)

export const getInputSelection = () => $inputSelection.get()
