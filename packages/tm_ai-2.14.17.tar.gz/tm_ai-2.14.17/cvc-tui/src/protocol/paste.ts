// SPDX-License-Identifier: MIT
// Ported from Hermes Agent (https://github.com/NousResearch/hermes-agent)
export const PASTE_SNIPPET_RE = /\[\[[^\n]*?\]\]/g
