// SPDX-License-Identifier: MIT
// Ported from Hermes Agent (https://github.com/NousResearch/hermes-agent)
export const INTERPOLATION_RE = /\{!(.+?)\}/g

export const hasInterpolation = (s: string) => /\{!.+?\}/.test(s)
