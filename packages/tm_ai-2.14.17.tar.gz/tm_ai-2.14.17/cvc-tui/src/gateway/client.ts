// Real subprocess GatewayClient.
//
// Spawns `python -m cvc.tui_gateway.entry` (or attaches to a configured
// `cvc-tui-gateway` binary), speaks newline-delimited JSON-RPC 2.0 over
// stdio, and surfaces:
//   * request/response RPCs   — `send(method, params)` → Promise<result>
//   * server-push events      — `on('event', ev => …)`  (e.g. chat.delta,
//                                                       chat.done, chat.start)
//   * stderr lines            — `on('stderr', line => …)`
//   * lifecycle               — `on('exit', code => …)`,
//                               `on('connected', info => …)`
//
// The protocol contract matches the Python gateway in cvc/tui_gateway/:
//   request : {jsonrpc:'2.0', id, method, params}
//   response: {jsonrpc:'2.0', id, result|error}
//   event   : {jsonrpc:'2.0', method, params}     (no id)
//
// During `connect()` we issue a `session.info` handshake; the resolved
// session payload (version, model, provider, session_id, cwd) is emitted
// as `connected` and also returned from connect().
//
// Tests inject a fake transport via the `transport` constructor option.
// In production the transport is a child_process spawned with
// `stdio: ['pipe','pipe','pipe']`.

import { type ChildProcess, spawn } from 'node:child_process';
import { EventEmitter } from 'node:events';
import { existsSync } from 'node:fs';
import { delimiter, resolve } from 'node:path';
import { createInterface, type Interface as ReadlineInterface } from 'node:readline';
import type { Readable, Writable } from 'node:stream';

export interface GatewayEvent {
  method: string;
  params: Record<string, unknown>;
}

export interface SessionInfo {
  version: string;
  model: string;
  provider: string;
  cwd: string;
  session_id: string;
}

export interface SendOptions {
  timeoutMs?: number;
}

export interface ChatStartParams {
  message: string;
  system?: string;
  model?: string;
  model_provider?: string;
}

export interface ChatStreamHandlers {
  onStart?: (info: { provider: string; model: string }) => void;
  onDelta?: (text: string) => void;
  onDone?: (summary: Record<string, unknown>) => void;
  onError?: (err: Error) => void;
}

interface Pending {
  id: string;
  method: string;
  resolve: (v: unknown) => void;
  reject: (e: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

export interface Transport {
  stdin: Writable;
  stdout: Readable;
  stderr?: Readable;
  kill?: () => void;
  on?: (event: 'exit', cb: (code: number | null) => void) => void;
}

export interface GatewayClientOptions {
  /** Override transport (used by tests). */
  transport?: Transport;
  /** Override Python interpreter path. */
  python?: string;
  /** Override workspace root used for venv discovery + PYTHONPATH. */
  cwd?: string;
  /** Default RPC timeout (ms). */
  defaultTimeoutMs?: number;
  /** Verbose stderr forwarding. */
  forwardStderr?: boolean;
}

const DEFAULT_TIMEOUT_MS = Math.max(
  10000,
  parseInt(process.env.CVC_TUI_RPC_TIMEOUT_MS ?? '120000', 10) || 120000
);
const STARTUP_TIMEOUT_MS = Math.max(
  3000,
  parseInt(process.env.CVC_TUI_STARTUP_TIMEOUT_MS ?? '15000', 10) || 15000
);

const resolvePython = (root: string): string => {
  const configured = process.env.CVC_PYTHON?.trim() || process.env.PYTHON?.trim();
  if (configured) return configured;
  const venv = process.env.VIRTUAL_ENV?.trim();
  const candidates = [
    venv && resolve(venv, 'bin/python'),
    venv && resolve(venv, 'bin/python3'),
    venv && resolve(venv, 'Scripts/python.exe'),
    resolve(root, '.venv/bin/python'),
    resolve(root, '.venv/bin/python3'),
    resolve(root, 'venv/bin/python'),
    resolve(root, 'venv/bin/python3'),
  ];
  for (const c of candidates) {
    if (c && existsSync(c)) return c;
  }
  return process.platform === 'win32' ? 'python' : 'python3';
};

const findCvcRoot = (): string => {
  // entry.tsx is typically at <root>/cvc-tui/src/entry.tsx
  // dist/entry.js at <root>/cvc-tui/dist/entry.js
  // Walk up looking for a "cvc/tui_gateway" sibling.
  if (process.env.CVC_PYTHON_SRC_ROOT) return process.env.CVC_PYTHON_SRC_ROOT;
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    if (existsSync(resolve(dir, 'cvc', 'tui_gateway', 'entry.py'))) return dir;
    const parent = resolve(dir, '..');
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
};

export class GatewayClient extends EventEmitter {
  private opts: GatewayClientOptions;
  private proc: ChildProcess | null = null;
  private transport: Transport | null = null;
  private stdoutRl: ReadlineInterface | null = null;
  private stderrRl: ReadlineInterface | null = null;
  private pending = new Map<string, Pending>();
  private reqId = 0;
  private session: SessionInfo | null = null;
  private connected = false;
  private exited = false;

  constructor(opts: GatewayClientOptions = {}) {
    super();
    this.setMaxListeners(0);
    this.opts = opts;
  }

  /** Spawn (or attach) the gateway and run the session.info handshake. */
  async connect(): Promise<SessionInfo> {
    if (this.connected) {
      return this.session!;
    }

    if (this.opts.transport) {
      this.transport = this.opts.transport;
      this.wireTransport();
    } else {
      this.spawnGateway();
    }

    // Handshake — single session.info round-trip with bounded timeout.
    const info = (await this.send('session.info', {}, { timeoutMs: STARTUP_TIMEOUT_MS })) as SessionInfo;
    this.session = info;
    this.connected = true;
    this.emit('connected', info);
    return info;
  }

  private spawnGateway(): void {
    const root = this.opts.cwd ?? findCvcRoot();
    const python = this.opts.python ?? resolvePython(root);
    const env = { ...process.env };
    const pyPath = env.PYTHONPATH?.trim();
    env.PYTHONPATH = pyPath ? `${root}${delimiter}${pyPath}` : root;

    const proc = spawn(python, ['-m', 'cvc.tui_gateway.entry'], {
      cwd: root,
      env,
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    this.proc = proc;
    this.transport = {
      stdin: proc.stdin!,
      stdout: proc.stdout!,
      stderr: proc.stderr!,
      kill: () => proc.kill(),
      on: (event, cb) => {
        proc.on(event, cb);
      },
    };
    proc.on('error', (err) => {
      this.emit('stderr', `[spawn] ${err.message}`);
      this.handleExit(1);
    });
    proc.on('exit', (code) => this.handleExit(code));
    this.wireTransport();
  }

  private wireTransport(): void {
    const t = this.transport!;
    this.stdoutRl = createInterface({ input: t.stdout });
    this.stdoutRl.on('line', (line) => this.handleLine(line));
    if (t.stderr) {
      this.stderrRl = createInterface({ input: t.stderr });
      this.stderrRl.on('line', (line) => {
        const trimmed = line.trim();
        if (!trimmed) return;
        this.emit('stderr', trimmed);
        if (this.opts.forwardStderr) {
          process.stderr.write(`[cvc-gateway] ${trimmed}\n`);
        }
      });
    }
    // Lifecycle: injected transports surface exit through their own `on()`.
    // The real subprocess path also calls handleExit via proc.on('exit')
    // registered in spawnGateway, so guard with `exited` to dedupe.
    t.on?.('exit', (code) => this.handleExit(code));
  }

  private handleLine(raw: string): void {
    const line = raw.trim();
    if (!line) return;
    let frame: Record<string, unknown>;
    try {
      frame = JSON.parse(line);
    } catch {
      this.emit('stderr', `[protocol] malformed stdout: ${line.slice(0, 200)}`);
      return;
    }
    this.dispatch(frame);
  }

  private dispatch(frame: Record<string, unknown>): void {
    // Response — has `id` and (`result` xor `error`).
    if ('id' in frame && (('result' in frame) || ('error' in frame))) {
      const id = String(frame.id);
      const p = this.pending.get(id);
      if (!p) return;
      this.pending.delete(id);
      clearTimeout(p.timer);
      if ('error' in frame && frame.error) {
        const err = frame.error as { code?: number; message?: string };
        p.reject(new Error(`${p.method}: ${err.message ?? 'rpc error'} (code=${err.code ?? '?'})`));
      } else {
        p.resolve(frame.result);
      }
      return;
    }
    // Event — has `method` but no `id`.
    if (typeof frame.method === 'string' && !('id' in frame)) {
      const ev: GatewayEvent = {
        method: frame.method,
        params: (frame.params as Record<string, unknown>) ?? {},
      };
      this.emit('event', ev);
      this.emit(`event:${ev.method}`, ev.params);
      return;
    }
    // Anything else is malformed — log but don't crash.
    this.emit('stderr', `[protocol] unexpected frame: ${JSON.stringify(frame).slice(0, 200)}`);
  }

  private handleExit(code: number | null): void {
    if (this.exited) return;
    this.exited = true;
    for (const p of Array.from(this.pending.values())) {
      clearTimeout(p.timer);
      p.reject(new Error(`gateway exited (code=${code ?? 'null'})`));
    }
    this.pending.clear();
    this.stdoutRl?.close();
    this.stderrRl?.close();
    this.connected = false;
    this.emit('exit', code);
  }

  /** Issue a JSON-RPC request and await its response. */
  send(method: string, params: unknown = {}, opts: SendOptions = {}): Promise<unknown> {
    if (!this.transport) {
      return Promise.reject(new Error('GatewayClient: not connected'));
    }
    if (this.exited) {
      return Promise.reject(new Error('GatewayClient: gateway has exited'));
    }
    const id = String(++this.reqId);
    const frame = JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n';
    const timeoutMs = opts.timeoutMs ?? this.opts.defaultTimeoutMs ?? DEFAULT_TIMEOUT_MS;
    return new Promise<unknown>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`${method}: timeout after ${timeoutMs}ms`));
      }, timeoutMs);
      this.pending.set(id, { id, method, resolve, reject, timer });
      try {
        this.transport!.stdin.write(frame);
      } catch (err) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(err as Error);
      }
    });
  }

  /**
   * Streaming chat helper. Wires `chat.start` / `chat.delta` / `chat.done`
   * to the supplied handlers, then issues `chat.send`. Resolves with the
   * `chat.done` summary; rejects on RPC error.
   */
  async sendChat(params: ChatStartParams, handlers: ChatStreamHandlers = {}): Promise<Record<string, unknown>> {
    const onStart = (p: Record<string, unknown>) => {
      handlers.onStart?.({ provider: String(p.provider ?? ''), model: String(p.model ?? '') });
    };
    const onDelta = (p: Record<string, unknown>) => {
      const t = typeof p.text === 'string' ? p.text : '';
      if (t) handlers.onDelta?.(t);
    };
    const onDone = (p: Record<string, unknown>) => {
      handlers.onDone?.(p);
    };
    this.on('event:chat.start', onStart as (p: unknown) => void);
    this.on('event:chat.delta', onDelta as (p: unknown) => void);
    this.on('event:chat.done', onDone as (p: unknown) => void);
    try {
      const summary = (await this.send('chat.send', params)) as Record<string, unknown>;
      return summary;
    } catch (err) {
      handlers.onError?.(err as Error);
      throw err;
    } finally {
      this.off('event:chat.start', onStart as (p: unknown) => void);
      this.off('event:chat.delta', onDelta as (p: unknown) => void);
      this.off('event:chat.done', onDone as (p: unknown) => void);
    }
  }

  /** Resolved session info from the handshake. */
  getSession(): SessionInfo | null {
    return this.session;
  }

  isConnected(): boolean {
    return this.connected && !this.exited;
  }

  /** Best-effort orderly shutdown — issues system.shutdown and kills proc. */
  async close(): Promise<void> {
    if (!this.transport || this.exited) return;
    try {
      await this.send('system.shutdown', {}, { timeoutMs: 1000 });
    } catch {
      // ignore — the gateway may already be tearing down.
    }
    try {
      this.transport.kill?.();
    } catch {
      // ignore
    }
    if (this.proc && !this.proc.killed) {
      try {
        this.proc.kill();
      } catch {
        // ignore
      }
    }
    this.handleExit(0);
  }
}

/**
 * Render an OSC 8 hyperlink escape sequence: `\x1b]8;;URL\x1b\\TEXT\x1b]8;;\x1b\\`.
 * Re-exported here for tests + downstream consumers that don't want a hard
 * dependency on the markdown component.
 */
export const osc8Link = (url: string, label: string): string =>
  `\x1b]8;;${url}\x1b\\${label}\x1b]8;;\x1b\\`;
