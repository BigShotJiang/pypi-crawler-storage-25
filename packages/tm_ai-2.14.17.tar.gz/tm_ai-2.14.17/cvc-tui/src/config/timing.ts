// @ts-nocheck
// SPDX-License-Identifier: MIT
// Ported from CVC Agent (https://github.com/NousResearch/cvc)
// Original Copyright (c) 2025 Nous Research. CVC adaptations (c) 2026 Jai Kumar Meena.
// Centralised timing constants for the CVC TUI.
// Keep all magic numbers controlling UI cadence in this file.

export const TIMING = {
  /** Spinner frame interval (ms) */
  SPINNER_FRAME_MS: 80,
  /** Throttle for streaming markdown re-renders (ms) */
  STREAM_THROTTLE_MS: 16,
  /** Debounce on text-input change handlers (ms) */
  INPUT_DEBOUNCE_MS: 0,
  /** Gateway connect retry backoff (ms) */
  GATEWAY_RECONNECT_MS: 1500,
  /** Heartbeat ping interval (ms) */
  HEARTBEAT_MS: 15000,
} as const;

// Streaming/render cadence constants (ported from hermes-ref)
export const STREAM_BATCH_MS = 16
export const STREAM_IDLE_BATCH_MS = 16
export const STREAM_SCROLL_BATCH_MS = 96
export const STREAM_TYPING_BATCH_MS = 80
export const TYPING_IDLE_MS = 250
export const REASONING_PULSE_MS = 700
