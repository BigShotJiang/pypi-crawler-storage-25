# =============================================================================
# CVC (Cognitive Version Control) — Clean 2-Phase Installer (Windows-native)
# Usage:  irm https://jaimeena.com/cvc/install.ps1 | iex
#
#   Phase 1: Python core   — uv → uv tool install tm-ai[all] → verify cvc
#   Phase 2: Bun + cvc-tui — install bun (native) → bun install -g cvc-tui
#
# Pure PowerShell. NO PortableGit, NO bash.exe dependency.
# =============================================================================
$ErrorActionPreference = "Continue"

$Package    = "tm-ai[all]"
$PyPiName   = "tm-ai"
$ToolName   = "cvc"
$TuiPkg     = "cvc-tui"
$UvInstall  = "https://astral.sh/uv/install.ps1"
$BunInstall = "https://bun.sh/install.ps1"

# ── CVC branded colours (ANSI 24-bit, fall back gracefully) ─────────────────
$CvcRed    = "`e[38;2;204;51;51m"
$CvcBright = "`e[38;2;255;68;68m"
$CvcDim    = "`e[38;2;139;112;112m"
$CvcGreen  = "`e[38;2;80;200;120m"
$CvcYellow = "`e[38;2;230;180;80m"
$Bold      = "`e[1m"
$Reset     = "`e[0m"

function Write-Info { param($m) Write-Host "  $CvcDim$m$Reset" }
function Write-Ok   { param($m) Write-Host "  $CvcGreen$Bold✓$Reset $m" }
function Write-Warn2{ param($m) Write-Host "  $CvcYellow⚠ $m$Reset" }
function Write-Err2 { param($m) Write-Host "  $CvcRed$Bold✗$Reset $m" -ForegroundColor Red }
function Write-Hdr  { param($m) Write-Host ""; Write-Host "$CvcRed$Bold$m$Reset" }

# Outcomes for final summary
$PyVersion  = ""
$BunVersion = ""
$TuiStatus  = "pending"   # "ok" | "pending" | "missing"
$TuiDetail  = ""

function Test-Cmd { param($Name) [bool](Get-Command $Name -ErrorAction SilentlyContinue) }

function Add-PathFront {
    param($Dir)
    if (-not $Dir) { return }
    if (-not (Test-Path $Dir)) { return }
    if (($env:PATH -split ';') -notcontains $Dir) {
        $env:PATH = "$Dir;$env:PATH"
    }
    # Persist to user PATH (idempotent)
    try {
        $userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
        if (-not $userPath) { $userPath = "" }
        $parts = $userPath -split ';' | Where-Object { $_ -ne "" -and $_ -ne $Dir }
        $newPath = (@($Dir) + $parts) -join ';'
        if ($newPath -ne $userPath) {
            [Environment]::SetEnvironmentVariable("PATH", $newPath, "User")
        }
    } catch {
        Write-Warn2 "Could not persist PATH to user environment: $($_.Exception.Message)"
    }
}

Write-Host ""
Write-Host "$CvcRed$Bold* Installing ${CvcBright}CVC$CvcRed — Cognitive Version Control$Reset"

# =============================================================================
# PHASE 1 — Python core (cvc CLI via uv tool install tm-ai[all])
# =============================================================================
Write-Hdr "Phase 1/2 — Python core (tm-ai)"

# ── Ensure uv is available ──────────────────────────────────────────────────
if (-not (Test-Cmd "uv")) {
    Write-Info "Installing uv package manager..."
    try {
        Invoke-RestMethod -Uri $UvInstall -UseBasicParsing | Invoke-Expression
    } catch {
        Write-Err2 "uv installer failed: $($_.Exception.Message)"
    }
    # uv installs to %USERPROFILE%\.local\bin or %USERPROFILE%\.cargo\bin
    Add-PathFront "$env:USERPROFILE\.local\bin"
    Add-PathFront "$env:USERPROFILE\.cargo\bin"
    if (-not (Test-Cmd "uv")) {
        Write-Err2 "uv is required but could not be installed."
        Write-Info "Manual install: https://docs.astral.sh/uv/getting-started/installation/"
        exit 1
    }
}
try {
    $uvVer = (uv --version 2>$null) -replace '^uv\s+',''
} catch { $uvVer = "" }
Write-Ok "uv ready ($uvVer)"

# ── Compute uv tool bin ─────────────────────────────────────────────────────
$UvToolBin = ""
try {
    $UvToolBin = (uv tool dir --bin 2>$null | Select-Object -First 1).Trim()
} catch { $UvToolBin = "" }
if (-not $UvToolBin -or -not (Test-Path $UvToolBin)) {
    $UvToolBin = "$env:USERPROFILE\.local\bin"
}
$UvToolBin = $UvToolBin.TrimEnd('\')

# ── Purge stale tm-ai installs (idempotent, best-effort) ────────────────────
try {
    $listed = uv tool list 2>$null
    if ($listed -match "^$PyPiName") {
        uv tool uninstall $PyPiName 2>$null | Out-Null
    }
} catch {}

foreach ($pyExe in @("python", "python3", "py")) {
    if (Test-Cmd $pyExe) {
        try {
            & $pyExe -m pip show tm-ai 2>$null | Out-Null
            if ($LASTEXITCODE -eq 0) {
                & $pyExe -m pip uninstall tm-ai -y 2>$null | Out-Null
            }
        } catch {}
    }
}

if (Test-Cmd "pipx") {
    try { pipx uninstall tm-ai 2>$null | Out-Null } catch {}
}

# ── Fresh install via uv tool ───────────────────────────────────────────────
$installOk = $false
try {
    uv tool install --force --refresh $Package 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { $installOk = $true }
} catch {}
if (-not $installOk) {
    Write-Warn2 "Install failed silently. Retrying with verbose output..."
    try {
        uv tool install --force --refresh $Package
        if ($LASTEXITCODE -eq 0) { $installOk = $true }
    } catch {}
}
if (-not $installOk) {
    Write-Err2 "uv tool install failed."
    exit 1
}
Write-Ok "tm-ai installed via uv"

# ── Prepend uv bin to PATH ──────────────────────────────────────────────────
if (-not (Test-Path $UvToolBin)) { New-Item -ItemType Directory -Force -Path $UvToolBin | Out-Null }
Add-PathFront $UvToolBin
try { uv tool update-shell 2>$null | Out-Null } catch {}
Write-Ok "PATH updated (uv tool bin first)"

# ── Verify cvc --version ────────────────────────────────────────────────────
$CvcBin = Join-Path $UvToolBin "cvc.exe"
if (-not (Test-Path $CvcBin)) { $CvcBin = Join-Path $UvToolBin "cvc" }

$verOut = ""
if (Test-Path $CvcBin) {
    try { $verOut = (& $CvcBin --version 2>$null | Select-Object -First 1) } catch {}
} elseif (Test-Cmd $ToolName) {
    try { $verOut = (& $ToolName --version 2>$null | Select-Object -First 1) } catch {}
}
if ($verOut -match '(\d+\.\d+\.\d+)') {
    $PyVersion = $Matches[1]
    Write-Ok "cvc --version → $PyVersion"
} else {
    Write-Warn2 "cvc binary present but --version did not report a number (open a new terminal)."
}

# =============================================================================
# PHASE 2 — Bun + cvc-tui
# =============================================================================
Write-Hdr "Phase 2/2 — Bun + Terminal UI"

if (-not (Test-Cmd "bun")) {
    Write-Info "Installing Bun (JavaScript runtime)..."
    try {
        Invoke-RestMethod -Uri $BunInstall -UseBasicParsing | Invoke-Expression
    } catch {
        Write-Warn2 "Bun installer failed: $($_.Exception.Message)"
    }
    Add-PathFront "$env:USERPROFILE\.bun\bin"
}

if (Test-Cmd "bun") {
    try {
        $BunVersion = (bun --version 2>$null).Trim()
    } catch { $BunVersion = "" }
    Write-Ok "bun ready (v$BunVersion)"

    Write-Info "Installing $TuiPkg globally via bun..."
    $tuiOk = $false
    try {
        bun install -g $TuiPkg 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) { $tuiOk = $true }
    } catch {}
    if ($tuiOk) {
        Write-Ok "$TuiPkg installed globally"
        $TuiStatus = "ok"
        $TuiDetail = "bun global"
    } else {
        Write-Info "$TuiPkg not yet published — run later: bun install -g $TuiPkg"
        $TuiStatus = "pending"
        $TuiDetail = "not yet on npm"
    }
} else {
    Write-Warn2 "Bun unavailable — skipping TUI."
    $TuiStatus = "missing"
    $TuiDetail = "bun unavailable"
}

# =============================================================================
# Final summary
# =============================================================================
Write-Hdr "Summary"
Write-Host ""

function Write-Row {
    param($Sym, $Text)
    $color = switch ($Sym) {
        "✓" { $CvcGreen }
        "⚠" { $CvcYellow }
        default { $CvcRed }
    }
    Write-Host "  $color$Bold$Sym$Reset $Text"
}

if ($PyVersion) {
    Write-Row "✓" "Python core:   cvc $PyVersion  (via uv)"
} else {
    Write-Row "✗" "Python core:   not installed"
}

if ($BunVersion) {
    switch ($TuiStatus) {
        "ok"      { Write-Row "✓" "Bun + TUI:     bun $BunVersion, $TuiPkg installed ($TuiDetail)" }
        "pending" { Write-Row "⚠" "Bun + TUI:     bun $BunVersion, $TuiPkg pending ($TuiDetail)" }
        default   { Write-Row "⚠" "Bun + TUI:     bun $BunVersion, TUI unavailable" }
    }
} else {
    Write-Row "✗" "Bun + TUI:     not installed (TUI unavailable)"
}

Write-Host ""
Write-Host "$CvcBright${Bold}Quickstart:$Reset"
Write-Host "  ${CvcBright}cvc$Reset              ${CvcDim}# launch CLI$Reset"
Write-Host "  ${CvcBright}cvc tui$Reset          ${CvcDim}# interactive terminal UI$Reset"
Write-Host "  ${CvcBright}cvc dashboard$Reset    ${CvcDim}# web dashboard (http://localhost:13422)$Reset"
Write-Host ""
Write-Host "$CvcDim(Open a new terminal if cvc isn't found — PATH changes apply to new sessions.)$Reset"
Write-Host ""
