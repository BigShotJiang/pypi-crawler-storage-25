#!/usr/bin/env bash
# =============================================================================
# CVC (Cognitive Version Control) — Clean 2-Phase Installer (macOS/Linux/WSL)
# Usage:  curl -fsSL https://jaimeena.com/cvc/install.sh | bash
#
#   Phase 1: Python core   — uv → uv tool install tm-ai[all] → verify cvc
#   Phase 2: Bun + cvc-tui — detect/install bun → bun install -g cvc-tui
# =============================================================================
set -uo pipefail   # NOT -e — keep going through non-fatal failures

PACKAGE="tm-ai[all]"
PYPI_NAME="tm-ai"
TOOL_NAME="cvc"
TUI_PKG="cvc-tui"
UV_INSTALL_URL="https://astral.sh/uv/install.sh"
BUN_INSTALL_URL="https://bun.sh/install"

# ── CVC branded colours (24-bit truecolor) ──────────────────────────────────
CVC_RED=$'\033[38;2;204;51;51m'         # #cc3333
CVC_BRIGHT=$'\033[38;2;255;68;68m'      # #ff4444
CVC_DIM=$'\033[38;2;139;112;112m'
CVC_GREEN=$'\033[38;2;80;200;120m'
CVC_YELLOW=$'\033[38;2;230;180;80m'
BOLD=$'\033[1m'
RESET=$'\033[0m'

info() { printf "  %s%s%s\n"     "${CVC_DIM}"    "$1" "${RESET}"; }
ok()   { printf "  %s%s✓%s %s\n" "${CVC_GREEN}"  "${BOLD}" "${RESET}" "$1"; }
warn() { printf "  %s⚠ %s%s\n"   "${CVC_YELLOW}" "$1" "${RESET}"; }
err()  { printf "  %s%s✗%s %s\n" "${CVC_RED}"    "${BOLD}" "${RESET}" "$1" >&2; }
hdr()  { printf "\n%s%s%s%s\n"   "${CVC_RED}"    "${BOLD}" "$1" "${RESET}"; }

# Outcomes for final summary
PY_VERSION=""
BUN_VERSION=""
TUI_STATUS="pending"      # "ok" | "pending" | "missing"
TUI_DETAIL=""

echo ""
printf "%s%s* Installing %sCVC%s — Cognitive Version Control%s\n" \
    "${CVC_RED}" "${BOLD}" "${CVC_BRIGHT}" "${CVC_RED}" "${RESET}"

# =============================================================================
# PHASE 1 — Python core (cvc CLI via uv tool install tm-ai[all])
# =============================================================================
hdr "Phase 1/2 — Python core (tm-ai)"

# ── Ensure uv is available ──────────────────────────────────────────────────
if ! command -v uv &>/dev/null; then
    info "Installing uv package manager..."
    curl -fsSL "$UV_INSTALL_URL" | sh >/dev/null 2>&1 || true
    export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
    if ! command -v uv &>/dev/null; then
        err "uv is required but could not be installed."
        info "Manual install: https://docs.astral.sh/uv/getting-started/installation/"
        exit 1
    fi
fi
ok "uv ready ($(uv --version 2>/dev/null | awk '{print $2}'))"

# ── Compute uv tool bin UP FRONT (never delete from it) ─────────────────────
UV_TOOL_BIN=""
UV_TOOL_BIN=$(uv tool dir --bin 2>/dev/null || true)
if [ -z "$UV_TOOL_BIN" ] || [ ! -d "$UV_TOOL_BIN" ]; then
    UV_TOOL_BIN="$HOME/.local/bin"
fi
UV_TOOL_BIN="${UV_TOOL_BIN%/}"

is_uv_owned() {
    local p="${1%/}"
    [[ "$p" == "$UV_TOOL_BIN"* ]]
}

# ── Purge stale tm-ai installs (idempotent) ─────────────────────────────────
SEEN_PYTHONS=""
IFS=: read -ra PATH_DIRS <<< "$PATH"
for dir in "${PATH_DIRS[@]}"; do
    [ -d "$dir" ] || continue
    for _pyexe in python3 python python3.13 python3.12 python3.11 python3.10; do
        full="$dir/$_pyexe"
        if [ -x "$full" ] && [[ ":$SEEN_PYTHONS:" != *":$full:"* ]]; then
            SEEN_PYTHONS="$SEEN_PYTHONS:$full"
            if "$full" -m pip show tm-ai &>/dev/null; then
                "$full" -m pip uninstall tm-ai -y >/dev/null 2>&1 || true
            fi
        fi
    done
done

if command -v pipx &>/dev/null; then
    pipx uninstall tm-ai >/dev/null 2>&1 || true
fi
if command -v brew &>/dev/null; then
    brew uninstall tm-ai >/dev/null 2>&1 || true
fi

for dir in "${PATH_DIRS[@]}"; do
    [ -d "$dir" ] || continue
    for stale in cvc cvc.py; do
        stale_path="$dir/$stale"
        if [ -f "$stale_path" ] && ! is_uv_owned "$stale_path"; then
            rm -f "$stale_path" >/dev/null 2>&1 || true
        fi
    done
done

if uv tool list 2>/dev/null | grep -q "^$PYPI_NAME"; then
    uv tool uninstall "$PYPI_NAME" >/dev/null 2>&1 || true
fi

# ── Fresh install via uv tool ───────────────────────────────────────────────
if ! uv tool install --force --refresh "$PACKAGE" >/dev/null 2>&1; then
    warn "Install failed silently. Retrying with verbose output..."
    if ! uv tool install --force --refresh "$PACKAGE"; then
        err "uv tool install failed."
        exit 1
    fi
fi
ok "tm-ai installed via uv"

# ── Prepend uv bin to PATH (idempotent shellrc edits) ───────────────────────
mkdir -p "$UV_TOOL_BIN"

add_to_front_of_path() {
    local cfg="$1"
    local guard_start='# >>> cvc path >>>'
    local guard_end='# <<< cvc path <<<'
    local line='export PATH="'"$UV_TOOL_BIN"':$PATH"'

    [ -f "$cfg" ] || return 0

    if grep -q "$guard_start" "$cfg" 2>/dev/null; then
        awk -v s="$guard_start" -v e="$guard_end" '
            $0 == s {skip=1; next}
            $0 == e {skip=0; next}
            !skip {print}
        ' "$cfg" > "${cfg}.tmp" && mv "${cfg}.tmp" "$cfg"
    fi

    local tmp; tmp=$(mktemp)
    {
        echo "$guard_start"
        echo "$line"
        echo "$guard_end"
        echo ""
        cat "$cfg"
    } > "$tmp"
    mv "$tmp" "$cfg"
}

for rc in "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.zshrc" "$HOME/.profile"; do
    [ -f "$rc" ] && add_to_front_of_path "$rc"
done

export PATH="$UV_TOOL_BIN:$PATH"
uv tool update-shell >/dev/null 2>&1 || true
ok "PATH updated (uv tool bin first)"

# ── Verify cvc --version ────────────────────────────────────────────────────
CVC_BIN="$UV_TOOL_BIN/cvc"
if [ -x "$CVC_BIN" ]; then
    PY_VERSION=$("$CVC_BIN" --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
elif command -v "$TOOL_NAME" &>/dev/null; then
    PY_VERSION=$("$TOOL_NAME" --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
fi
if [ -n "$PY_VERSION" ]; then
    ok "cvc --version → $PY_VERSION"
else
    warn "cvc binary present but --version did not report a number (open a new terminal)."
fi

# =============================================================================
# PHASE 2 — Bun + cvc-tui
# =============================================================================
hdr "Phase 2/2 — Bun + Terminal UI"

if command -v bun &>/dev/null; then
    BUN_VERSION=$(bun --version 2>/dev/null || true)
    ok "bun detected (v${BUN_VERSION})"
else
    info "Installing Bun (JavaScript runtime)..."
    if curl -fsSL "$BUN_INSTALL_URL" | bash >/dev/null 2>&1; then
        export BUN_INSTALL="${BUN_INSTALL:-$HOME/.bun}"
        export PATH="$BUN_INSTALL/bin:$PATH"
        if command -v bun &>/dev/null; then
            BUN_VERSION=$(bun --version 2>/dev/null || true)
            ok "Bun installed (v${BUN_VERSION}) at \$HOME/.bun/bin"
        else
            warn "Bun install ran but 'bun' is not on PATH yet."
        fi
    else
        warn "Bun installer failed. Skipping TUI."
    fi
fi

if command -v bun &>/dev/null; then
    info "Installing $TUI_PKG globally via bun..."
    if bun install -g "$TUI_PKG" >/dev/null 2>&1; then
        ok "$TUI_PKG installed globally"
        TUI_STATUS="ok"
        TUI_DETAIL="bun global"
    else
        info "$TUI_PKG not yet published — run later: bun install -g $TUI_PKG"
        TUI_STATUS="pending"
        TUI_DETAIL="not yet on npm"
    fi
else
    TUI_STATUS="missing"
    TUI_DETAIL="bun unavailable"
fi

# =============================================================================
# Final summary
# =============================================================================
hdr "Summary"
echo ""

py_line="✗ Python core:   not installed"
[ -n "$PY_VERSION" ] && py_line="✓ Python core:   cvc ${PY_VERSION}  (via uv)"

if [ -n "$BUN_VERSION" ]; then
    case "$TUI_STATUS" in
        ok)      bun_line="✓ Bun + TUI:     bun ${BUN_VERSION}, ${TUI_PKG} installed (${TUI_DETAIL})" ;;
        pending) bun_line="⚠ Bun + TUI:     bun ${BUN_VERSION}, ${TUI_PKG} pending (${TUI_DETAIL})" ;;
        *)       bun_line="⚠ Bun + TUI:     bun ${BUN_VERSION}, TUI unavailable" ;;
    esac
else
    bun_line="✗ Bun + TUI:     not installed (TUI unavailable)"
fi

print_row() {
    local sym="${1:0:1}"
    local rest="${1:1}"
    local color="${CVC_GREEN}"
    case "$sym" in
        ✓) color="${CVC_GREEN}" ;;
        ⚠) color="${CVC_YELLOW}" ;;
        ✗) color="${CVC_RED}" ;;
    esac
    printf "  %s%s%s%s%s\n" "${color}" "${BOLD}" "$sym" "${RESET}" "$rest"
}
print_row "$py_line"
print_row "$bun_line"

echo ""
printf "%s%sQuickstart:%s\n" "${CVC_BRIGHT}" "${BOLD}" "${RESET}"
printf "  %scvc%s              %s# launch CLI%s\n"                      "${CVC_BRIGHT}" "${RESET}" "${CVC_DIM}" "${RESET}"
printf "  %scvc tui%s          %s# interactive terminal UI%s\n"         "${CVC_BRIGHT}" "${RESET}" "${CVC_DIM}" "${RESET}"
printf "  %scvc dashboard%s    %s# web dashboard (http://localhost:13422)%s\n" "${CVC_BRIGHT}" "${RESET}" "${CVC_DIM}" "${RESET}"
echo ""
printf "%s(Open a new terminal if cvc isn't found — PATH changes apply to new sessions.)%s\n" "${CVC_DIM}" "${RESET}"
echo ""
