"""CVC bundled skills.

These are first-party skills shipped with CVC. Other code can locate the
bundled skills directory via :data:`BUNDLED_SKILLS_DIR`.
"""

from pathlib import Path

BUNDLED_SKILLS_DIR = Path(__file__).parent

__all__ = ["BUNDLED_SKILLS_DIR"]
