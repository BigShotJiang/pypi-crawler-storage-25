---
name: cvc-commit-discipline
description: Trunk-based development on main — atomic commits, no feature branches, push after each batch.
category: cvc-core
version: 1.0
---

# CVC Commit Discipline

CVC ships from `main`. There are no long-lived feature branches. Every commit
must leave the trunk in a working state and be small enough to revert
cleanly.

## When to use

Always. This is the project-wide policy for every code commit on the CVC
repo. Cognitive (CVC DAG) commits follow the same spirit but are governed by
the agent runtime.

## Rules

1. **Trunk only.** Work directly on `main`. Do not create `feature/*`,
   `wip/*`, or personal branches in the shared remote. Local exploratory
   branches are fine but must be rebased and squashed back onto `main`
   before push.
2. **Atomic commits.** One logical change per commit. If the message needs
   the word "and", split it.
3. **Working trunk invariant.** `main` must build and pass the fast test
   suite at every commit. If you can't guarantee that, don't push.
4. **Push after each batch.** A batch is a small group of related atomic
   commits (typically 1–5). Don't sit on local commits — push them so
   other agents see them.
5. **Conventional message format:**
   - `<scope>: <imperative summary>` (≤ 72 chars)
   - Optional body explaining *why*, not *what* (the diff shows what).
   - Reference issue/agent IDs in a trailer: `Refs: #123` or
     `Handoff: robin@cvc.local`.
6. **Authorship.** Agents commit as themselves:
   `git config user.email '<agent>@cvc.local'`,
   `git config user.name '<Agent Name> (<Role>)'`.
7. **Never force-push `main`.** Ever. Recover via revert commits.

## How to use

Typical agent workflow:

```bash
# 1. Sync first
git pull --rebase origin main

# 2. Make a small change
$EDITOR cvc/foo.py

# 3. Stage + commit atomically
git add cvc/foo.py
git commit -m "foo: handle empty payload"

# 4. Repeat for the next atomic change in the same batch

# 5. Run fast tests
pytest -x -q tests/unit

# 6. Push
git push origin main
```

If the push is rejected (someone else pushed first):

```bash
git pull --rebase origin main
# resolve conflicts atomically — one fixup commit per logical conflict
git push origin main
```

## Pitfalls

- **The "big finale" commit.** Holding 30 changes back for one giant push
  defeats trunk-based dev and makes review impossible. Push small, push often.
- **Mixed-purpose commits.** "fix auth + add logging + bump deps" is three
  commits. Split them.
- **Skipping the fast test suite.** A red trunk blocks every other agent.
  Ten seconds of `pytest -x` saves an hour of rollback.
- **Branching "just for safety."** That's what commits are for. If you need
  to experiment destructively, use a local-only branch and rebase/squash
  before push.
- **Force-pushing to fix a bad message.** Use `git commit --amend` only on
  unpushed commits. After push, fix forward with a new commit.

## Examples

Good commit sequence (one batch):

```
auth: extract token rotation into TokenStore
auth: wire middleware to TokenStore.rotate
tests: cover TokenStore rotation edge cases
docs: note new auth contract in README
```

Bad commit (rejected at review):

```
big update: refactor auth and add logging and fix typos
```

Recovering from a broken trunk you just pushed:

```bash
git revert <bad-sha>           # creates a clean revert commit
git push origin main           # trunk is green again
# then fix forward in a new atomic commit
```
