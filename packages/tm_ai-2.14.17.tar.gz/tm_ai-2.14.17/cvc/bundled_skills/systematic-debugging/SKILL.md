---
name: systematic-debugging
description: Four-phase root-cause debugging — reproduce, isolate, hypothesise, fix.
category: software-development
version: 1.0
---

# Systematic Debugging

A structured approach that finds the *root cause* instead of patching the
nearest symptom. Use it whenever a bug isn't obvious in 60 seconds.

## When to use

- The fix you're about to write is "add a try/except" without knowing why.
- The bug is intermittent.
- The same area has been "fixed" before.
- You've changed something and you're not sure why it worked.
- The stack trace points somewhere that "shouldn't be possible".

If the bug is a typo, just fix it. This skill is for everything else.

## The four phases

### 1. Reproduce
- Get a *deterministic* repro. Random failure → reproduce 5× before believing the fix.
- Shrink the input until the failure is minimal (one request, one record, one line).
- Capture the exact command + environment.

### 2. Isolate
- Bisect the surface area. Disable layers (cache, auth, batching) until the
  failure stops, then re-enable one at a time.
- Use `git bisect` if the bug appeared between two known-good commits.
- Add logging *at the boundary*, not inside the suspect function — boundary
  data tells you whether the bug is upstream or downstream.

### 3. Hypothesise
- State the hypothesis as a falsifiable claim:
  *"The cache returns stale data after a TTL refresh because the writer
  doesn't invalidate sibling keys."*
- Predict what an experiment would show if true *and* if false.
- Run the experiment. If neither prediction matches, your model is wrong —
  back to Isolate.

### 4. Fix (and prove)
- Write a failing test that captures the bug at the right layer (unit if
  possible, integration if it's emergent).
- Make the test pass with the smallest change.
- Re-run the original repro 5×. All green.
- Search the codebase for *similar* patterns. The same root cause usually
  hides in 2–3 places.

## Pitfalls

- **Symptom patching.** Wrapping the failing call in try/except hides the bug
  for next quarter's on-call to find. Don't.
- **Speculation-first.** "It's probably the cache" without evidence wastes
  hours. Reproduce before theorising.
- **Single-shot belief.** Intermittent bugs are not "fixed" until you've run
  the repro many times. Five is the floor.
- **No regression test.** If you didn't write a failing test, you don't know
  the bug is gone — you only know your last manual run was green.
- **Fixing the second-nearest cause.** Keep asking "but why?" until the
  answer is a property of the system, not a coincidence.

## Examples

Intermittent test failure:

```
1. Reproduce: pytest -k flaky --count=20 → fails 3/20
2. Isolate: disable parallelism (-p no:xdist) → fails 0/20 → race condition
3. Hypothesise: shared fixture mutated by two tests
   Predict: serialising the two tests fixes it
   Run: --dist=loadfile → green
4. Fix: scope fixture per-test, add test that asserts isolation. Re-run 50×.
```

Production 500 spike:

```
1. Reproduce: replay one of the failing requests in staging → 500
2. Isolate: same request with auth bypassed → 200 → bug is in auth path
3. Hypothesise: token refresh race with revocation list
   Predict: warming the revocation cache before the request → 200
   Run: confirmed
4. Fix: add read-through cache + regression test. Grep for other consumers
   of the revocation list — found 1 more, fixed too.
```
