---
name: writing-plans
description: Format implementation plans as ordered, bite-sized, independently verifiable tasks.
category: software-development
version: 1.0
---

# Writing Plans

A good implementation plan is a sequence of small, independently verifiable
steps. Each step should be small enough that a fresh agent can pick it up,
do it, and verify it without rereading the whole plan.

## When to use

- Inside `plan` mode (the deliverable).
- Before starting any multi-step task longer than ~20 minutes.
- When delegating: a plan is the brief you hand to a subagent.
- After a metacognition `Reflect` step that revealed the original plan was wrong.

## What a step looks like

Each step has four fields. Keep it terse.

- **What** — imperative one-liner. *"Extract `TokenStore.rotate` to `cvc/auth/tokens.py`."*
- **Touches** — files/functions changed. *"`cvc/auth/middleware.py:42-78`, new `cvc/auth/tokens.py`."*
- **Verify** — how you'll know it worked. *"`pytest tests/auth -x` green; `cvc/auth/middleware.py` no longer references `_rotate_jwt`."*
- **Rollback** — how to undo. *"`git revert <sha>`; no schema change."*

## Sizing rules

- **Bite-sized:** ≤ 30 minutes of work, ≤ ~150 lines of diff, *one* logical change.
- **Independently verifiable:** the Verify step doesn't depend on later steps.
- **Atomic:** if step N fails, steps 1..N-1 still leave the trunk green.
- **Ordered:** later steps may depend on earlier ones, but never the other way.

If a step is bigger than this, split it. If splitting is hard, the design
itself is too coupled — fix that first.

## Plan template

```markdown
# Plan: <one-line goal>

**Goal:** <one sentence>
**Assumptions:** <bulleted, flag the shaky ones>
**Approach:** <1–3 sentences>

## Steps

### 1. <imperative one-liner>
- **Touches:** <files/symbols>
- **Verify:** <command or observation>
- **Rollback:** <how to undo>

### 2. <imperative one-liner>
- **Touches:** ...
- **Verify:** ...
- **Rollback:** ...

## Risks & Mitigations
- <risk> → <mitigation>

## Out of scope
- <thing this plan deliberately does not do>
```

## Pitfalls

- **Steps that say "implement X".** Not a step — that's the whole project.
  Decompose until each step is one commit's worth of work.
- **No Verify field.** Without it, "done" is opinion. Verify makes it falsifiable.
- **Hidden coupling.** Step 3 quietly assumes step 2 left a helper behind.
  State the dependency or split differently.
- **Plans without Out-of-scope.** Scope creep starts with ambiguity. Name
  what you are *not* doing.
- **Plan written in prose.** Walls of text don't survive contact with reality.
  Use the structured format.

## Examples

Good step:

```
### 3. Wire middleware to TokenStore
- Touches: cvc/auth/middleware.py (replace inline rotation with `TokenStore(...).rotate()`)
- Verify: `pytest tests/auth -x -q` all green; `rg "_rotate_jwt" cvc/` returns nothing
- Rollback: `git revert <sha>` — middleware was the only call site
```

Bad step (too vague, not verifiable):

```
### 3. Make middleware nicer
- Clean up the auth code
```

Bad step (too big):

```
### 1. Refactor the entire auth subsystem
- Touches: cvc/auth/**
```
