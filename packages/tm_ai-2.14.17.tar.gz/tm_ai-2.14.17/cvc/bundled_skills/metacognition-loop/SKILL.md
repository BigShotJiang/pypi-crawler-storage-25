---
name: metacognition-loop
description: Run a structured plan → act → observe → reflect → adjust loop on non-trivial tasks.
category: cvc-core
version: 1.0
---

# Metacognition Loop

A disciplined self-reflection cycle that prevents the agent from spiralling on
hard tasks. Each iteration commits a checkpoint to the DAG so the loop is
auditable and resumable.

## When to invoke

Trigger the loop when **any** of these hold:

- The task spans more than ~3 tool calls.
- You're uncertain how to start.
- A previous attempt failed and you're about to retry.
- You're about to do something irreversible (deploy, delete, send).
- The task crosses agent boundaries (you'll need to hand off).

Do **not** use it for trivial single-shot tasks — the overhead isn't worth it.

## The five phases

1. **Plan.** Write the smallest plan that could possibly work. List the steps,
   the success criterion, and the rollback path. Commit it.
2. **Act.** Execute *one* step. Just one. Resist combining.
3. **Observe.** Read the actual output. Do not assume — read it.
4. **Reflect.** Did this match the prediction in the plan? If not, *why*?
   Was the model of the system wrong, or the execution?
5. **Adjust.** Update the plan. Pick the next step (or stop). Loop.

## How to use

1. Open the loop with a checkpoint commit:

   ```
   cvc_commit(message="metacog: start <task>", commit_type="checkpoint")
   ```

2. Write the plan to a scratch file or as the commit body. Keep it short —
   bullet points, not prose. Use the `writing-plans` skill for format.
3. After each `act → observe`, write a one-line reflection:
   - `✓ matched prediction` (move on)
   - `✗ mismatch: <reason>` (adjust before continuing)
4. On any `✗`, *do not retry blindly*. Update the plan first.
5. Close the loop with a result commit summarising what changed and what was
   learned. If the lesson is durable, also write it to Holographic Memory.

## Pitfalls

- **Skipping Observe.** The most common failure mode: assuming the action
  worked because the tool returned 0. Always read the output.
- **Reflection theatre.** Writing "looks good" without comparing to the plan.
  If you didn't make a prediction, you can't reflect.
- **Plan bloat.** A 30-step plan is a wishlist. Plan the next 3 steps; replan
  after each act-observe-reflect.
- **Loop without commits.** If you don't checkpoint, you can't restore. The
  loop is only useful because it's resumable.

## Examples

Hard debugging task:

```
# Plan
1. Reproduce: run failing test in isolation → expect AssertionError on line 42
2. Inspect: read fixture → expect missing 'token' field
3. Patch: add fixture field → expect test green

# Act 1
> pytest tests/test_auth.py::test_rotate -x
# Observe
AssertionError: KeyError 'token'  ✓ matched

# Act 2
> read fixture
# Observe
fixture has 'tok' not 'token'  ✗ mismatch — actual issue is naming, not missing
# Adjust: don't add field, rename in test usage instead
```

Irreversible action (deploy):

```
Plan:
  - dry-run deploy → expect plan with 1 service change
  - if plan matches expectation → apply
  - rollback path: `fly releases rollback <prev>`
Act → Observe → Reflect each step. Never skip dry-run.
```
