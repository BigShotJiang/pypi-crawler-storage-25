---
name: plan
description: Plan mode — produce a written markdown plan and stop. Do not execute.
category: software-development
version: 1.0
---

# Plan Mode

When the user asks for a *plan*, your job is to write the plan and stop. No
file edits, no commands, no commits. The plan is the deliverable.

## When to use

- The user says "plan", "design", "propose", "what would you do", "outline".
- A task is large enough that the user wants a checkpoint before execution.
- You're about to do something irreversible and want explicit approval.

If the user says "do it" or "implement", that's not plan mode — execute.

## The contract

While in plan mode you **must not**:

- Edit any file.
- Run any command that mutates state (no `git commit`, no `apply`, no deploy).
- Spawn subagents to execute work.
- Send messages externally.

You **may**:

- Read files, search the codebase, query memory.
- Run read-only commands (`git log`, `pytest --collect-only`, `ls`).
- Ask clarifying questions.

## How to use

1. **Restate the goal in one sentence.** If you can't, ask first.
2. **Survey the relevant code.** Read the files you'd touch. Note current state.
3. **Write the plan as markdown** with these sections:
   - **Goal** — one sentence.
   - **Assumptions** — what you took for granted; flag any that are shaky.
   - **Approach** — 1–3 sentences on the chosen design and why.
   - **Steps** — bite-sized, ordered, each independently verifiable. Use the
     `writing-plans` skill for the format.
   - **Risks & rollback** — what could go wrong, how to undo it.
   - **Out of scope** — what this plan deliberately does not address.
4. **Deliver the plan in chat.** End with: *"Ready to execute on your go."*
5. **Wait.** Do not start.

## Pitfalls

- **Stealth execution.** Editing "just one small file" while planning
  destroys trust. Don't.
- **Vague steps.** "Refactor auth" is not a step. "Extract `TokenStore.rotate`
  from `auth/middleware.py:42-78` into `auth/tokens.py`" is.
- **Plans that hide unknowns.** If you don't know how step 4 works, say so —
  list it as a research spike, not a confident step.
- **Over-planning.** A 40-step plan for a 2-line change is theatre. Match
  plan depth to task size.

## Examples

Good plan opener:

```
**Goal:** Replace ad-hoc token rotation in middleware with a TokenStore service.

**Assumptions:**
- Existing tokens are JWT (verified — see auth/jwt.py:14).
- No external consumers depend on the current rotation timing.

**Approach:** Extract rotation logic into `cvc/auth/tokens.py:TokenStore`,
make middleware delegate. No behaviour change in this pass.

**Steps:**
1. Add `TokenStore` skeleton with `rotate()` (no logic yet) — verify imports.
2. Move rotation body from middleware → `TokenStore.rotate()` — tests still pass.
3. Update middleware to call `TokenStore.rotate()` — green suite.
4. Add unit tests for `TokenStore.rotate()` directly.

**Risks:** Middleware tests rely on monkey-patching the old function path —
will need fixture update (low risk, listed in step 3).

**Rollback:** Single-commit per step → revert any one cleanly.

**Out of scope:** Sibling-key invalidation (separate ticket).

Ready to execute on your go.
```
