---
name: cognome-usage
description: Use the Cognome cognitive substrate to compile minimal, deterministic context preambles instead of dumping raw history.
category: cvc-core
version: 1.0
---

# Cognome Usage

Cognome is CVC's layered cognitive substrate. It compiles a query-specific
**Engram** (a compact preamble) from the Merkle DAG, so each LLM turn carries
only the noemata it actually needs — bounded by a hard token budget and
deterministic for a given (DAG, query, budget) triple.

## When to use

Invoke Cognome when:

- The conversation is long and you'd otherwise blow context window on stale turns.
- You're starting a new sub-task that only touches a slice of prior reasoning.
- A subagent needs a focused brief instead of the full session history.
- You need provenance: every fact in the preamble traces back to a source commit.
- You want reproducibility: same DAG + same query + same budget → byte-identical Engram.

Do **not** invoke Cognome for trivial single-turn questions that don't need recall.

## Layers (L1 / L2 / L3)

- **L1 — Smart Librarian (default):** deterministic semantic compile from the
  Merkle DAG with token budget. Fast, cheap, fully reproducible.
- **L2 — Cached Engrams:** previously compiled Engrams get cached and replayed
  when the query and DAG head match. Zero recompute.
- **L3 — Holographic Fusion:** entity-resolved facts from Holographic Memory
  are fused into the preamble for cross-session recall (use the
  `holographic-recall` skill alongside).

## How to use

1. **Check status first:**
   - `cvc_cognome_status` → confirm initialised + enabled, see active layer.
   - If not initialised: `cvc_cognome_init` (idempotent, safe to repeat).
2. **Compile a preamble for the next turn:**
   - `cvc_cognome_compile(query="...", budget_tokens=1200)`.
   - Pass the user's intent verbatim as `query` — this is what the librarian indexes against.
   - Default budget 1200 tokens is good for most turns; raise for heavy refactors, lower for chat.
3. **Inject globally:** `cvc_cognome_enable` makes upstream LLM calls auto-prepend the Engram.
   Disable with `cvc_cognome_disable` for raw debugging or noise-sensitive evals.
4. **Audit what was compiled:** `cvc_cognome_audit(limit=20)` — shows which commits
   contributed to each Engram and how many tokens were saved.

## Trigger conditions

| Signal | Action |
|--------|--------|
| Context > 50% of window | Compile + enable |
| Subagent spawn | Compile a focused Engram and pass as the brief |
| New branch created | Recompile — branch scope changes the librarian's view |
| Determinism required (eval, test) | Disable injection, compile manually, log the hash |

## Pitfalls

- **Don't dump the Engram into the chat as context** — it's a preamble for the
  *next* LLM call, not a user-facing artefact.
- **Budget too small** → librarian drops important noemata silently. If the
  agent starts hallucinating recent decisions, raise the budget.
- **Forgetting to recompile after a branch switch** — the DAG scope changes and
  cached Engrams may be stale. `cvc_cognome_status` shows the active branch.
- **Treating it as semantic search** — it's a *compiler*, not a retriever.
  For free-form retrieval use `cvc_recall` or `holographic-recall`.

## Examples

Compile a tight preamble before delegating to a subagent:

```
cvc_cognome_compile(
    query="Refactor the auth middleware to use the new TokenStore",
    budget_tokens=800,
)
```

Enable global injection for a long working session:

```
cvc_cognome_enable()
# ... many LLM turns happen, each gets a fresh Engram ...
cvc_cognome_audit(limit=10)   # see token savings
```

Disable for a deterministic eval run:

```
cvc_cognome_disable()
# run eval suite with raw prompts only
```
