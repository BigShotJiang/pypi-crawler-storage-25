---
name: telepathy-handoff
description: Hand off work between agents via the Telepathy bus using a structured message envelope.
category: cvc-core
version: 1.0
---

# Telepathy Handoff

Telepathy is CVC's inter-agent message bus. Agents never call each other
directly; they publish envelopes onto a shared bus and the runtime routes them
based on squad, rank, and tags. This keeps coordination auditable and
replayable through the Merkle DAG.

## When to use Telepathy vs `delegate_task`

| Use Telepathy when… | Use `delegate_task` when… |
|---------------------|---------------------------|
| You need fire-and-forget broadcast | You need a synchronous result back |
| Multiple agents may want to react | Exactly one agent must execute |
| The work is advisory (alerts, FYIs) | The work is a contracted unit |
| You want a durable log on the bus | You want a child session with its own context window |

Rule of thumb: **Telepathy = pub/sub of cognition. `delegate_task` = function call.**

## Message envelope format

Every Telepathy message is a structured envelope:

```json
{
  "from": "tina@cvc.local",
  "to": "squad:dev" ,           // or "agent:robin" or "broadcast"
  "action_type": "DIRECTIVE",   // DIRECTIVE | RESULT | ALERT | QUERY | OBSERVATION
  "subject": "Auth refactor blocked on TokenStore API",
  "content": {
    "summary": "Need TokenStore.rotate() before I can proceed",
    "evidence": ["cvc/auth/middleware.py:42"],
    "blockers": ["TokenStore API undefined"]
  },
  "tags": ["auth", "blocker"],
  "trace_commit": "<HEAD hash at send time>"
}
```

The runtime stamps `id`, `ts`, and `branch` automatically.

## How to use

1. **Decide the action_type** — be honest. `ALERT` should be reserved for things
   another agent must see; `OBSERVATION` is for ambient signal.
2. **Address narrowly.** Prefer `agent:<id>` or `squad:<name>` over `broadcast`.
   Broadcast is for cross-cutting events (security, infra outages).
3. **Send via the agent commit API:**

   ```
   cvc_agent_commit(
       agent_id="tina@cvc.local",
       action_type="DIRECTIVE",
       message="Hand auth refactor over to robin for deploy review",
       target_agent_id="robin@cvc.local",
       content={"summary": "...", "next_steps": ["..."]},
       tags=["auth", "handoff"],
   )
   ```

4. **Confirm receipt** by polling `cvc_agent_context(agent_id=<target>)` if the
   handoff is critical. Telepathy is at-least-once; the receiver's reply on the
   bus is the canonical ack.

## Pitfalls

- **Treating Telepathy like a chat room.** Every envelope is committed to the
  DAG. Keep them structured and meaningful.
- **Broadcast spam.** Squad-targeted messages route faster and stay cheaper.
- **Missing `trace_commit`.** Without it, recipients can't reconstruct your
  cognitive state. The runtime fills it in if you forget, but pin it
  explicitly when handing off long-running work.
- **Using Telepathy for synchronous results.** If you need a return value, use
  `delegate_task` and await it. Telepathy doesn't promise reply ordering.

## Examples

Fire an alert that the gateway is unhealthy (broadcast, high signal):

```
cvc_agent_commit(
    agent_id="sofia@cvc.local",
    action_type="ALERT",
    message="Gateway 5xx rate above 2% — investigating",
    content={"metric": "5xx_rate", "value": 0.027, "window": "5m"},
    tags=["infra", "gateway"],
)
```

Hand off a finished slice of work to another agent:

```
cvc_agent_commit(
    agent_id="tina@cvc.local",
    target_agent_id="robin@cvc.local",
    action_type="RESULT",
    message="Auth refactor merged on main — ready for deploy plan",
    content={"commits": ["a1b2c3d"], "tests_passing": True},
    tags=["handoff", "deploy"],
)
```
