---
name: holographic-recall
description: Query Holographic Memory for entity-resolved facts with trust scoring — use for cross-session knowledge.
category: cvc-core
version: 1.0
---

# Holographic Recall

Holographic Memory is CVC's long-term, entity-resolved fact store. Unlike
session search (FTS5 over conversation text), it stores **propositions about
entities** with a trust score derived from frequency, recency, and source
agreement.

## When to use

| Use Holographic Recall when… | Use FTS5 / `cvc_recall` when… |
|------------------------------|-------------------------------|
| You need a *fact* about a known entity | You need a *quote* from a past chat |
| Cross-session knowledge ("what's Jai's deploy target?") | Within-session retrieval ("what did we decide 30 turns ago?") |
| You want a confidence score | You want raw conversational excerpts |
| You're populating a structured field | You're refreshing context for a new turn |

Holographic Recall is the right tool when the agent is asked *"who / what /
when / where"* and the answer should be stable across sessions. FTS5 search
(via `cvc_recall`) is for *"what did we say about X"*.

## How to use

1. **Resolve the entity first.** Holographic queries are entity-keyed:
   `entity="user:jai"`, `entity="project:cvc"`, `entity="service:gateway"`.
   If the entity is ambiguous, search for it first.
2. **Query a specific predicate** when you can — `predicate="prefers"`,
   `predicate="deploys_to"`, etc. Free-form queries also work but cost more.
3. **Inspect the trust score** on every result. The runtime returns
   `confidence ∈ [0, 1]`:
   - `≥ 0.85` — quote it directly.
   - `0.6 – 0.85` — quote with a hedge ("usually", "tends to").
   - `< 0.6` — ask the user to confirm before acting on it.
4. **Write back** corrections. If a holographic fact is wrong, commit a
   correction so the trust score drops and the new value rises.

## Difference from FTS5 session search

- **Storage:** FTS5 indexes raw message text per commit. Holographic stores
  resolved (subject, predicate, object) triples extracted from many commits.
- **Granularity:** FTS5 returns *snippets*. Holographic returns *facts*.
- **Decay:** FTS5 is timeless (full history searchable). Holographic decays
  unsupported facts so the agent's worldview stays current.
- **Provenance:** Both surface source commits. Holographic additionally
  surfaces *agreement count* — how many independent commits attest the fact.

## Pitfalls

- **Trusting low-confidence facts.** A `confidence < 0.6` result is a
  *hypothesis*, not a fact. Confirm before persisting it externally.
- **Querying without an entity.** Free-form "what does the user like?" is slow
  and noisy. Resolve to `user:jai` first.
- **Overwriting via direct edit.** Don't mutate the holographic store
  directly — commit a corrective observation and let the trust model update.
- **Confusing it with Cognome.** Cognome compiles a *preamble*. Holographic
  answers a *question*. Use Cognome for context loading; use Holographic for
  factual lookup.

## Examples

Look up a stable user preference:

```
holographic_recall(
    entity="user:jai",
    predicate="prefers_editor",
)
# → { value: "neovim", confidence: 0.93, sources: 14, last_seen: "2026-05-01" }
```

Ask a free-form question scoped to an entity:

```
holographic_recall(
    entity="project:cvc",
    query="What is the production deploy target?",
)
# → { answer: "fly.io (sjc region)", confidence: 0.71, sources: 3 }
```

Combine with Cognome — fuse high-trust facts into the next preamble:

```
facts = holographic_recall(entity="project:cvc", min_confidence=0.85)
cvc_cognome_compile(query=user_query, budget_tokens=1200, fuse=facts)
```
