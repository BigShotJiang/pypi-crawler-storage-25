---
name: requesting-code-review
description: Pre-commit checklist — run before asking for review or pushing to main.
category: software-development
version: 1.0
---

# Requesting Code Review

Before you push, before you ask another agent or human to review, run this
checklist. The goal is that the reviewer's first response is feedback on the
*idea*, not on missing tests or stray debug prints.

## When to use

- Before every push to `main`.
- Before opening a review request to another agent (e.g. handing off to Robin
  for deploy review).
- Before merging any work that other agents will build on.

## The checklist

### Code

- [ ] Diff is **scoped to one logical change** (split if not — see `cvc-commit-discipline`).
- [ ] No commented-out code, debug prints, `TODO: remove`, or `dbg!` left behind.
- [ ] No hardcoded secrets, tokens, paths, or personal config.
- [ ] New code follows the surrounding style (naming, error handling, logging).
- [ ] Public APIs have docstrings/types; behaviour changes are noted in the diff.

### Tests

- [ ] **Every behaviour change has a test.** Bug fix → regression test. New
      feature → unit + integration as appropriate.
- [ ] Tests fail before the change and pass after (you watched it RED→GREEN).
- [ ] Full fast suite is green: `pytest -x -q` (or project equivalent).
- [ ] No skipped tests added without a linked issue.

### Diff hygiene

- [ ] `git diff --stat` looks proportional to the claim — no surprise files.
- [ ] No reformatting of unrelated code mixed in (run formatter as a separate commit).
- [ ] Generated files / lockfiles, if changed, are intentional and explained.

### Commit message

- [ ] `<scope>: <imperative summary>` ≤ 72 chars.
- [ ] Body explains **why**, not what (the diff shows what).
- [ ] References issue / handoff trailer where relevant.

### Self-review pass

- [ ] You opened the diff yourself and read every hunk.
- [ ] Each hunk has a one-sentence justification you could give a reviewer.
- [ ] Anything you'd be embarrassed to defend → fix it now.

### For the reviewer

- [ ] Write a 2–4 line summary of what changed and why.
- [ ] Call out **the part you're least sure about** — that's where you want eyes.
- [ ] Note any **out-of-scope** items so the reviewer doesn't ask about them.

## Pitfalls

- **Skipping self-review.** "It's a small change" is how a debug `print` ends
  up on `main`. Read every hunk.
- **Claiming "no behaviour change" without proof.** If there's no test
  showing the new code does what the old code did, the claim is unverified.
- **Bundling formatter churn with logic.** Reviewers can't see the real
  change. Reformat in a separate commit, ideally a separate PR-equivalent.
- **Vague "the part I'm unsure about".** Be specific: file + line + the
  question. Otherwise the reviewer just nods.

## Examples

Good handoff message to a reviewer agent:

```
Refactored token rotation into TokenStore (commits a1b2c3..d4e5f6).
- 3 commits, 1 logical change per commit, full suite green.
- Behaviour preserved; new unit tests cover rotation + sibling invalidation.
- Least sure: cvc/auth/tokens.py:88 — the lock scope. I think it's correct
  for single-process; please sanity-check for the gunicorn worker case.
- Out of scope: persistence (still in-memory; separate ticket #418).
```

Bad handoff:

```
Refactored some auth stuff. PTAL.
```
