---
name: test-driven-development
description: Enforce strict RED-GREEN-REFACTOR — failing test first, minimal code to pass, then refactor.
category: software-development
version: 1.0
---

# Test-Driven Development

Strict TDD: the test is written *before* the production code, fails for the
right reason, then the smallest possible change makes it pass, and only then
do you refactor.

## When to use

- Any new feature with non-trivial logic.
- Any bug fix (the failing test *is* the regression test).
- Any refactor of complex logic — write characterisation tests first.

Skip strict TDD only for: throwaway prototypes, pure config changes, or
glue code with no branching logic.

## The cycle

### 🔴 RED — write a failing test
- Test names are sentences: `test_token_rotation_invalidates_siblings`.
- Test the *behaviour*, not the implementation.
- Run it. **It must fail.** If it passes immediately, the test is wrong.
- Verify it fails for the *right reason* (not an import error or typo).

### 🟢 GREEN — make it pass minimally
- Write the *least* code that turns the test green. Hardcoding a return
  value is allowed at this stage if only one test exists.
- Don't add features the tests don't demand. YAGNI.
- Run the *full* test suite — make sure you didn't break anything else.

### 🔵 REFACTOR — improve without changing behaviour
- Now that you have a green safety net, restructure freely.
- Extract functions, rename, deduplicate.
- Run the suite after each refactor step. Stay green.
- If you can't refactor without breaking tests, the tests are too coupled to
  implementation — fix the tests, not the code.

Loop. Each cycle should take minutes, not hours.

## How to use

```bash
# 1. RED
$EDITOR tests/test_tokens.py     # add the failing test
pytest tests/test_tokens.py::test_rotation_invalidates_siblings
# → FAIL: AttributeError: TokenStore has no attribute 'rotate'  ✓ right reason

# 2. GREEN
$EDITOR cvc/auth/tokens.py       # add minimal implementation
pytest tests/test_tokens.py::test_rotation_invalidates_siblings
# → PASS
pytest                            # full suite still green

# 3. REFACTOR
$EDITOR cvc/auth/tokens.py       # extract helper, clean naming
pytest                            # still green
```

Commit at each green point — never commit red.

## Pitfalls

- **Writing the test after the code.** That's not TDD; that's annotated
  manual testing. The test won't have shaped the design.
- **Tests that never failed.** If you didn't see RED, you don't know the
  test actually exercises the new behaviour.
- **Refactoring on red.** Changing structure while tests are failing means
  you can't tell which change broke what. Get to green first.
- **Over-mocking.** Mocking everything makes tests pass without exercising
  real behaviour. Mock at trust boundaries (network, clock), not internals.
- **One giant test.** A test that asserts 12 things fails uninformatively.
  One concept per test.

## Examples

Bug fix as TDD:

```
RED:    write test that reproduces the production 500 → fails with KeyError
GREEN:  add the missing key to the response builder → test passes
REFACTOR: extract response builder into a typed dataclass, all tests stay green
COMMIT: "auth: include 'sub' claim in token response (fixes #412)"
```

New feature as TDD:

```
RED:    test_rate_limiter_blocks_after_threshold → fails (no limiter exists)
GREEN:  hardcoded counter that blocks at 10 → passes that one test
RED:    test_rate_limiter_resets_after_window → fails
GREEN:  add window logic → both pass
REFACTOR: extract window math, add property tests
```
