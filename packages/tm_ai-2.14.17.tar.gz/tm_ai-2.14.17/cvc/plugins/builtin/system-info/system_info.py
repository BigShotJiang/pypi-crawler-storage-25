"""Built-in system_info plugin — exposes one tool returning host metrics."""
from __future__ import annotations

import os
import platform
import shutil
import socket


def system_info() -> dict:
    """Return a dict of basic system information."""
    info: dict = {
        "os": platform.system(),
        "arch": platform.machine(),
        "cpu_count": os.cpu_count() or 1,
        "hostname": socket.gethostname(),
    }

    # Memory — psutil if available, otherwise stdlib best-effort
    mem_gb: float = 0.0
    try:
        import psutil  # type: ignore

        mem_gb = round(psutil.virtual_memory().total / (1024 ** 3), 2)
    except Exception:
        try:
            page_size = os.sysconf("SC_PAGE_SIZE")
            phys_pages = os.sysconf("SC_PHYS_PAGES")
            mem_gb = round((page_size * phys_pages) / (1024 ** 3), 2)
        except (AttributeError, ValueError, OSError):
            mem_gb = 0.0
    info["mem_gb"] = mem_gb

    # Disk free
    try:
        usage = shutil.disk_usage(os.path.expanduser("~"))
        info["disk_free_gb"] = round(usage.free / (1024 ** 3), 2)
    except Exception:
        info["disk_free_gb"] = 0.0

    return info


def setup() -> dict:
    """Plugin entry point — return contributed tools."""
    return {"tools": ["system_info"]}
