"""Trivial echo plugin — returns whatever text it receives."""
from __future__ import annotations


def echo(text: str) -> str:
    """Return the text unchanged."""
    return text


def setup() -> dict:
    """Plugin entry point — return contributed tools."""
    return {"tools": ["echo"]}
