"""PluginLoader — discovers plugin.yaml files, imports entry_points, registers contributions."""
from __future__ import annotations

import importlib
import importlib.util
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

from .manifest import PluginManifest, load_manifest
from .registry import register_plugin

logger = logging.getLogger(__name__)


class PluginLoader:
    """Discovers and loads CVC plugins from configured directories."""

    def __init__(self, plugin_dirs: Optional[List[Path]] = None):
        if plugin_dirs is None:
            plugin_dirs = self._default_dirs()
        self.plugin_dirs: List[Path] = [Path(p) for p in plugin_dirs]

    @staticmethod
    def _default_dirs() -> List[Path]:
        """Default plugin search path: ~/.cvc/plugins, $CVC_PLUGINS_PATH, builtin/."""
        dirs: List[Path] = []
        user_dir = Path.home() / ".cvc" / "plugins"
        dirs.append(user_dir)

        env_path = os.environ.get("CVC_PLUGINS_PATH")
        if env_path:
            for chunk in env_path.split(os.pathsep):
                chunk = chunk.strip()
                if chunk:
                    dirs.append(Path(chunk))

        builtin = Path(__file__).parent / "builtin"
        dirs.append(builtin)
        return dirs

    def discover(self) -> List[PluginManifest]:
        """Walk plugin_dirs, find plugin.yaml files, parse manifests."""
        manifests: List[PluginManifest] = []
        seen: set[str] = set()
        for root in self.plugin_dirs:
            if not root.exists() or not root.is_dir():
                continue
            for yaml_path in root.rglob("plugin.yaml"):
                try:
                    manifest = load_manifest(yaml_path)
                except Exception as e:
                    logger.warning("Failed to load manifest %s: %s", yaml_path, e)
                    continue
                if manifest.name in seen:
                    # First occurrence wins (user dirs come before builtin)
                    continue
                seen.add(manifest.name)
                manifests.append(manifest)
        return manifests

    def load(self, manifest: PluginManifest) -> dict:
        """Import the entry_point and call setup() if present.

        Returns {tools, platforms, providers} contributed.
        Falls back to manifest.provides_* if no setup() is defined.
        """
        contribution = {
            "tools": list(manifest.provides_tools),
            "platforms": list(manifest.provides_platforms),
            "providers": list(manifest.provides_providers),
        }

        if not manifest.entry_point:
            return contribution

        module_path, _, func_name = manifest.entry_point.partition(":")
        module_path = module_path.strip()
        func_name = (func_name or "setup").strip()

        module = self._import_module(module_path, manifest)
        setup_func = getattr(module, func_name, None)
        if setup_func is None:
            # Module imported, but no entry function — that's OK, just use manifest declarations
            return contribution

        result = setup_func()
        if isinstance(result, dict):
            for key in ("tools", "platforms", "providers"):
                if key in result and result[key]:
                    contribution[key] = list(result[key])
        return contribution

    def _import_module(self, module_path: str, manifest: PluginManifest):
        """Import a module by dotted path, with fallback to file-based loading from source_dir."""
        # Try dotted import first
        try:
            return importlib.import_module(module_path)
        except ImportError:
            pass

        # Fallback: treat the last segment as a .py file inside source_dir
        if manifest.source_dir is None:
            raise ImportError(f"Cannot import '{module_path}' (no source_dir)")

        # Allow either "echo" -> echo.py or "system_info" -> system_info.py
        candidate = manifest.source_dir / f"{module_path}.py"
        if not candidate.exists():
            # Try last segment of dotted path
            last = module_path.rsplit(".", 1)[-1]
            candidate = manifest.source_dir / f"{last}.py"
        if not candidate.exists():
            raise ImportError(f"Cannot resolve module '{module_path}' for plugin '{manifest.name}'")

        spec_name = f"_cvc_plugin_{manifest.name.replace('-', '_')}"
        spec = importlib.util.spec_from_file_location(spec_name, candidate)
        if spec is None or spec.loader is None:
            raise ImportError(f"spec_from_file_location returned None for {candidate}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec_name] = module
        spec.loader.exec_module(module)
        return module

    def load_all(self) -> Dict[str, dict]:
        """Discover + load every enabled plugin. One broken plugin must not crash the loader."""
        results: Dict[str, dict] = {}
        for manifest in self.discover():
            if not manifest.enabled:
                logger.info("Plugin '%s' disabled — skipping", manifest.name)
                continue
            try:
                contribution = self.load(manifest)
            except Exception as e:
                logger.warning("Failed to load plugin '%s': %s", manifest.name, e)
                continue
            register_plugin(manifest, contribution)
            results[manifest.name] = contribution
        return results
