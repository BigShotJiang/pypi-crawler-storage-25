"""Global plugin registry — single source of truth for loaded plugins."""
from __future__ import annotations

from typing import Dict, Optional

from .manifest import PluginManifest


_PLUGINS: Dict[str, dict] = {}


def register_plugin(manifest: PluginManifest, contribution: dict | None = None) -> None:
    """Register a plugin and its contributions in the global registry.

    Idempotent: re-registering the same plugin replaces its previous entry
    (does not double-register).
    """
    contribution = contribution or {}
    _PLUGINS[manifest.name] = {
        "manifest": manifest,
        "tools": list(contribution.get("tools") or []),
        "platforms": list(contribution.get("platforms") or []),
        "providers": list(contribution.get("providers") or []),
    }


def list_plugins() -> Dict[str, dict]:
    """Return a shallow copy of the registry (name -> entry)."""
    return dict(_PLUGINS)


def get_plugin(name: str) -> Optional[dict]:
    """Look up a plugin entry by name."""
    return _PLUGINS.get(name)


def _clear_registry() -> None:
    """Test helper — wipe the registry."""
    _PLUGINS.clear()
