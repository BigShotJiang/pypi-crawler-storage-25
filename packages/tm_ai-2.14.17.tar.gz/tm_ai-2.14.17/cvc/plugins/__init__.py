"""CVC plugin system — auto-discovery and registration of external tools/platforms/providers."""
from __future__ import annotations

from .manifest import PluginManifest, load_manifest
from .registry import register_plugin, list_plugins, get_plugin, _clear_registry
from .loader import PluginLoader


def load_plugins(plugin_dirs=None) -> dict:
    """Discover and load all plugins. Returns dict of {plugin_name: contribution_dict}."""
    loader = PluginLoader(plugin_dirs=plugin_dirs)
    return loader.load_all()


__all__ = [
    "PluginManifest",
    "load_manifest",
    "PluginLoader",
    "load_plugins",
    "register_plugin",
    "list_plugins",
    "get_plugin",
    "_clear_registry",
]
