"""Plugin manifest dataclass + YAML loader."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Literal

import yaml


PluginKind = Literal["backend", "tool", "platform", "provider"]


@dataclass
class PluginManifest:
    """Declarative manifest for a CVC plugin (matches Hermes plugin.yaml format)."""

    name: str
    version: str = "0.0.0"
    description: str = ""
    author: str = ""
    kind: str = "tool"  # 'backend' | 'tool' | 'platform' | 'provider'
    provides_tools: List[str] = field(default_factory=list)
    provides_platforms: List[str] = field(default_factory=list)
    provides_providers: List[str] = field(default_factory=list)
    entry_point: str = ""  # e.g. "module.path:setup_func"
    enabled: bool = True
    # Path to the directory containing plugin.yaml (set by loader, not user-facing)
    source_dir: Path | None = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "kind": self.kind,
            "provides_tools": list(self.provides_tools),
            "provides_platforms": list(self.provides_platforms),
            "provides_providers": list(self.provides_providers),
            "entry_point": self.entry_point,
            "enabled": self.enabled,
        }


def load_manifest(path: Path) -> PluginManifest:
    """Parse a plugin.yaml file into a PluginManifest."""
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    if not isinstance(data, dict):
        raise ValueError(f"Plugin manifest must be a YAML mapping: {path}")
    if "name" not in data or not data["name"]:
        raise ValueError(f"Plugin manifest missing 'name': {path}")

    manifest = PluginManifest(
        name=str(data["name"]),
        version=str(data.get("version", "0.0.0")),
        description=str(data.get("description", "")),
        author=str(data.get("author", "")),
        kind=str(data.get("kind", "tool")),
        provides_tools=list(data.get("provides_tools") or []),
        provides_platforms=list(data.get("provides_platforms") or []),
        provides_providers=list(data.get("provides_providers") or []),
        entry_point=str(data.get("entry_point", "")),
        enabled=bool(data.get("enabled", True)),
        source_dir=path.parent.resolve(),
    )
    return manifest
