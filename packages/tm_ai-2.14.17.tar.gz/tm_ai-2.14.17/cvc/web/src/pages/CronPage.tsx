import { useEffect, useState } from "react";
import { Clock, Pause, Play, Plus, Trash2 } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { cn } from "@/lib/utils";

interface CronJob {
  id: string;
  name: string;
  cron: string;
  paused?: boolean;
  next_run?: number; // unix seconds
  last_status?: "ok" | "error" | "running" | "pending";
  last_output?: string;
}

// TODO(slice-3): replace mock with GET /api/cron/jobs
const SEED: CronJob[] = [
  {
    id: "j1",
    name: "Security scan",
    cron: "0 */3 * * *",
    next_run: Date.now() / 1000 + 3600,
    last_status: "ok",
    last_output: "All systems secure. 0 anomalies. CryptoTokenKit safe.",
  },
  {
    id: "j2",
    name: "Hive memory compact",
    cron: "0 4 * * *",
    next_run: Date.now() / 1000 + 9200,
    last_status: "ok",
    last_output: "Compacted 42 entries → 14 distilled.",
  },
  {
    id: "j3",
    name: "Telegram heartbeat",
    cron: "*/30 * * * *",
    paused: true,
    next_run: undefined,
    last_status: "pending",
    last_output: "Paused.",
  },
];

function fmtCountdown(secs: number): string {
  if (secs <= 0) return "now";
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

export default function CronPage() {
  const [jobs, setJobs] = useState<CronJob[]>(SEED);
  const [now, setNow] = useState(Date.now() / 1000);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now() / 1000), 1000);
    return () => clearInterval(id);
  }, []);

  function toggle(id: string) {
    setJobs((p) => p.map((j) => (j.id === id ? { ...j, paused: !j.paused } : j)));
  }
  function del(id: string) {
    if (!confirm("Delete this job?")) return;
    setJobs((p) => p.filter((j) => j.id !== id));
  }
  function add() {
    const name = window.prompt("Job name?");
    if (!name) return;
    const cron = window.prompt("Cron expression (e.g. */15 * * * *)?", "*/15 * * * *");
    if (!cron) return;
    setJobs((p) => [
      ...p,
      { id: `j${Date.now()}`, name, cron, next_run: Date.now() / 1000 + 900, last_status: "pending" },
    ]);
  }

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Clock className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">Cron</Typography>
          <span className="font-mono-ui text-[0.62rem] uppercase tracking-wider text-midground/45">
            {jobs.length} jobs
          </span>
        </div>
        <button
          onClick={add}
          className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card/60 px-3 py-1.5 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground hover:bg-card"
        >
          <Plus className="h-3.5 w-3.5" /> New job
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {jobs.map((j) => {
          const cd = j.next_run && !j.paused ? fmtCountdown(j.next_run - now) : "—";
          return (
            <div key={j.id} className="rounded-lg border border-border bg-card/50 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Typography variant="sm" className="text-midground">{j.name}</Typography>
                    <StatusBadge status={j.last_status} paused={j.paused} />
                  </div>
                  <div className="mt-1 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/55">
                    cron: <span className="text-midground/80">{j.cron}</span>
                    <span className="mx-2">·</span>
                    next: <span className="text-midground/80">{cd}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => toggle(j.id)}
                    className="rounded-md border border-border bg-background-base/40 p-1.5 text-midground/70 hover:bg-card hover:text-midground"
                    title={j.paused ? "Resume" : "Pause"}
                  >
                    {j.paused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
                  </button>
                  <button
                    onClick={() => del(j.id)}
                    className="rounded-md border border-border bg-background-base/40 p-1.5 text-midground/70 hover:bg-card hover:text-[#e63946]"
                    title="Delete"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
              {j.last_output && (
                <pre className="mt-3 overflow-x-auto rounded-md border border-border bg-background-base/40 p-2 font-mono-ui text-[0.7rem] text-midground/70">
                  {j.last_output}
                </pre>
              )}
            </div>
          );
        })}
        {jobs.length === 0 && (
          <div className="rounded-md border border-dashed border-border p-8 text-center font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/40">
            No jobs configured.
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status, paused }: { status?: string; paused?: boolean }) {
  if (paused) return <Pill color="bg-midground/30">paused</Pill>;
  switch (status) {
    case "ok": return <Pill color="bg-emerald-400">ok</Pill>;
    case "error": return <Pill color="bg-red-400">error</Pill>;
    case "running": return <Pill color="bg-[#4a9eff]">running</Pill>;
    default: return <Pill color="bg-midground/30">pending</Pill>;
  }
}
function Pill({ color, children }: { color: string; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-border bg-background-base/40 px-1.5 py-0.5 font-mono-ui text-[0.55rem] uppercase tracking-wider text-midground/75">
      <span className={cn("h-1.5 w-1.5 rounded-full", color)} />{children}
    </span>
  );
}
