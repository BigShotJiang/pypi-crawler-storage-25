import { useEffect, useMemo, useState } from "react";
import { Wrench, Search } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { api, type MCPTool } from "@/lib/api";

export default function ToolsPage() {
  const [tools, setTools] = useState<MCPTool[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    api.mcpTools()
      .then((r) => setTools(r.tools ?? []))
      .catch((e) => setError(String(e?.message ?? e)));
  }, []);

  const filtered = useMemo(() => {
    const n = q.trim().toLowerCase();
    if (!n) return tools;
    return tools.filter(
      (t) =>
        t.name.toLowerCase().includes(n) ||
        (t.description ?? "").toLowerCase().includes(n),
    );
  }, [tools, q]);

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Wrench className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">Tools</Typography>
          <span className="font-mono-ui text-[0.62rem] uppercase tracking-wider text-midground/45">
            {tools.length} registered (MCP)
          </span>
        </div>
        <div className="relative w-full max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-midground/50" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Filter tools…"
            className="w-full rounded-md border border-border bg-background-base/60 py-1.5 pl-8 pr-2 font-mono-ui text-[0.78rem] text-midground placeholder:text-midground/40 focus:border-midground/50 focus:outline-none"
          />
        </div>
      </div>

      {error && (
        <div className="rounded-md border border-border bg-card/60 p-3 text-sm text-midground/70">
          Gateway: {error}
        </div>
      )}

      <div className="flex flex-col gap-2">
        {filtered.map((t) => {
          const open = expanded === t.name;
          return (
            <div key={t.name} className="rounded-lg border border-border bg-card/40">
              <button
                onClick={() => setExpanded(open ? null : t.name)}
                className="flex w-full items-start justify-between gap-3 p-3 text-left hover:bg-card/70"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Typography variant="sm" className="text-midground">{t.name}</Typography>
                  </div>
                  {t.description && (
                    <p className="mt-1 line-clamp-2 text-xs text-midground/65">{t.description}</p>
                  )}
                </div>
                <div className="shrink-0 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">
                  {/* TODO(slice-3): success_rate + last_invocation surfacing */}
                  rate: — · last: —
                </div>
              </button>
              {open && (
                <pre className="overflow-x-auto border-t border-border bg-background-base/40 p-3 font-mono-ui text-[0.7rem] text-midground/75">
                  {JSON.stringify(t.parameters ?? t, null, 2)}
                </pre>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && !error && (
          <div className="rounded-md border border-dashed border-border p-8 text-center font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/40">
            No tools loaded yet. Check `cvc gateway start` and MCP wiring.
          </div>
        )}
      </div>
    </div>
  );
}
