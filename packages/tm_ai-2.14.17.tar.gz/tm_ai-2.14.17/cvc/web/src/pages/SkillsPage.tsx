import { useMemo, useState } from "react";
import { BookOpen, Search, X } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { cn } from "@/lib/utils";

interface Skill {
  id: string;
  name: string;
  category: string;
  description: string;
  files?: string[];
  content?: string;
}

// TODO(slice-3): replace mock with GET /api/skills
const SEED: Skill[] = [
  { id: "hermes-agent", name: "hermes-agent", category: "core", description: "Hermes agent runtime configuration and orchestration helpers." },
  { id: "vision-analyze", name: "vision-analyze", category: "vision", description: "Multimodal image analysis via vision-capable LLMs." },
  { id: "voice-elevenlabs", name: "voice-elevenlabs", category: "voice", description: "Text-to-speech via ElevenLabs with voice picker." },
  { id: "research-deep", name: "research-deep", category: "research", description: "Multi-hop research with web search + summarization." },
  { id: "ops-deploy", name: "ops-deploy", category: "ops", description: "Deployment recipes for Vercel, Fly, Railway, and bare VPS." },
  { id: "cvc-cognome", name: "cvc-cognome", category: "cvc", description: "Cognome compilation and budget-aware Engram delivery." },
  { id: "telegram-bot", name: "telegram-bot", category: "messaging", description: "Telegram bot helpers, formatting, media delivery." },
  { id: "kanban-sync", name: "kanban-sync", category: "ops", description: "Sync kanban cards with external boards (Linear, Notion)." },
];

export default function SkillsPage() {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<Skill | null>(null);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return SEED;
    return SEED.filter(
      (s) =>
        s.name.toLowerCase().includes(needle) ||
        s.category.toLowerCase().includes(needle) ||
        s.description.toLowerCase().includes(needle),
    );
  }, [q]);

  const grouped = useMemo(() => {
    const m = new Map<string, Skill[]>();
    filtered.forEach((s) => {
      if (!m.has(s.category)) m.set(s.category, []);
      m.get(s.category)!.push(s);
    });
    return [...m.entries()].sort(([a], [b]) => a.localeCompare(b));
  }, [filtered]);

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <BookOpen className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">Skills</Typography>
          <span className="font-mono-ui text-[0.62rem] uppercase tracking-wider text-midground/45">
            {SEED.length} registered
          </span>
        </div>
        <div className="relative w-full max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-midground/50" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search skills…"
            className="w-full rounded-md border border-border bg-background-base/60 py-1.5 pl-8 pr-2 font-mono-ui text-[0.78rem] text-midground placeholder:text-midground/40 focus:border-midground/50 focus:outline-none"
          />
        </div>
      </div>

      <div className="flex flex-col gap-6">
        {grouped.map(([cat, list]) => (
          <section key={cat}>
            <div className="mb-2 font-mono-ui text-[0.65rem] uppercase tracking-[0.2em] text-midground/45">
              {cat}
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setOpen(s)}
                  className={cn(
                    "rounded-lg border border-border bg-card/40 p-3 text-left transition-colors",
                    "hover:border-midground/40 hover:bg-card/70",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <Typography variant="sm" className="text-midground">{s.name}</Typography>
                  </div>
                  <p className="mt-1.5 line-clamp-3 text-xs text-midground/70">{s.description}</p>
                </button>
              ))}
            </div>
          </section>
        ))}
        {grouped.length === 0 && (
          <div className="rounded-md border border-dashed border-border p-8 text-center font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/40">
            No matching skills.
          </div>
        )}
      </div>

      {open && <SkillModal skill={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function SkillModal({ skill, onClose }: { skill: Skill; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background-base/70 backdrop-blur-sm" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl rounded-lg border border-border bg-card p-5 shadow-2xl"
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            <Typography variant="md" className="text-midground">{skill.name}</Typography>
            <div className="mt-1 font-mono-ui text-[0.62rem] uppercase tracking-wider text-midground/50">
              category: {skill.category}
            </div>
          </div>
          <button onClick={onClose} className="rounded-md p-1 text-midground/60 hover:bg-midground/10 hover:text-midground">
            <X className="h-4 w-4" />
          </button>
        </div>
        <p className="text-sm text-midground/85">{skill.description}</p>
        <div className="mt-4 rounded-md border border-border bg-background-base/40 p-3 font-mono-ui text-[0.72rem] text-midground/70">
          {/* TODO(slice-3): GET /api/skills/{id}/content */}
          <span className="text-midground/40"># SKILL.md preview unavailable until /api/skills/{"{id}"}/content lands.</span>
        </div>
      </div>
    </div>
  );
}
