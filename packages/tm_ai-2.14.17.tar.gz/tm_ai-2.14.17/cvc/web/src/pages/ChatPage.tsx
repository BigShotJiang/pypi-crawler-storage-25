import { useEffect, useMemo, useRef, useState } from "react";
import { MessageSquare, Send, Square, Loader2, Copy, RotateCcw, GitBranch, ChevronRight } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import "highlight.js/styles/github-dark.css";
import { Typography } from "@/components/NouiTypography";
import { api, ChatWS, type ChatEvent, type ChatMessage } from "@/lib/api";
import { cn } from "@/lib/utils";

interface ToolCall {
  id: string;
  name: string;
  args?: unknown;
  result?: unknown;
  durationMs?: number;
  startedAt: number;
}

interface DisplayMessage {
  role: "user" | "assistant" | "system";
  content: string;
  pending?: boolean;
  tools?: ToolCall[];
}

export default function ChatPage() {
  const [messages, setMessages] = useState<DisplayMessage[]>([]);
  const [input, setInput] = useState("");
  const [models, setModels] = useState<string[]>([]);
  const [model, setModel] = useState<string>("");
  const [streaming, setStreaming] = useState(false);
  const [status, setStatus] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<ChatWS | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // Load model list + current model
  useEffect(() => {
    api
      .chatModels()
      .then((r) => {
        setModels(r.models ?? []);
      })
      .catch(() => {
        /* gateway down */
      });
    api
      .currentModel()
      .then((m) => {
        if (m?.model) setModel(m.model);
      })
      .catch(() => {
        /* */
      });
  }, []);

  // Connect WS on mount
  useEffect(() => {
    const ws = new ChatWS();
    wsRef.current = ws;

    ws.on("text", (ev: ChatEvent) => {
      const chunk = ev.content ?? "";
      setMessages((prev) => {
        const next = [...prev];
        const last = next[next.length - 1];
        if (last && last.role === "assistant" && last.pending) {
          next[next.length - 1] = { ...last, content: last.content + chunk };
        } else {
          next.push({ role: "assistant", content: chunk, pending: true });
        }
        return next;
      });
    });

    ws.on("tool_start", (ev: ChatEvent) => {
      const name = ev.name ?? "?";
      setStatus(`tool: ${name}…`);
      setMessages((prev) => {
        const next = [...prev];
        const last = next[next.length - 1];
        const tool: ToolCall = { id: `${Date.now()}-${name}`, name, args: ev.args, startedAt: Date.now() };
        if (last && last.role === "assistant" && last.pending) {
          next[next.length - 1] = { ...last, tools: [...(last.tools ?? []), tool] };
        } else {
          next.push({ role: "assistant", content: "", pending: true, tools: [tool] });
        }
        return next;
      });
    });
    ws.on("tool_result", (ev: ChatEvent) => {
      setStatus("");
      setMessages((prev) => {
        const next = [...prev];
        for (let i = next.length - 1; i >= 0; i--) {
          const m = next[i];
          if (m.tools && m.tools.length) {
            const tools = [...m.tools];
            const last = tools[tools.length - 1];
            tools[tools.length - 1] = {
              ...last,
              result: ev.output ?? ev.content,
              durationMs: Date.now() - last.startedAt,
            };
            next[i] = { ...m, tools };
            break;
          }
        }
        return next;
      });
    });
    ws.on("status", (ev: ChatEvent) => {
      setStatus(ev.message ?? "");
    });
    ws.on("done", () => {
      setStreaming(false);
      setStatus("");
      setMessages((prev) =>
        prev.map((m) => (m.pending ? { ...m, pending: false } : m)),
      );
    });
    ws.on("error", (ev: ChatEvent) => {
      setError(ev.message ?? "stream error");
      setStreaming(false);
      setStatus("");
    });

    ws.connect();
    return () => ws.disconnect();
  }, []);

  // Autoscroll
  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, status]);

  const canSend = useMemo(
    () => input.trim().length > 0 && !streaming,
    [input, streaming],
  );

  function send() {
    if (!canSend) return;
    setError(null);
    const userMsg: DisplayMessage = { role: "user", content: input.trim() };
    const history: ChatMessage[] = [...messages, userMsg].map((m) => ({
      role: m.role,
      content: m.content,
    }));
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setStreaming(true);
    wsRef.current?.send({ messages: history, model: model || undefined });
  }

  function abort() {
    wsRef.current?.abort();
    setStreaming(false);
    setStatus("");
  }

  function clearChat() {
    setMessages([]);
    setError(null);
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <div className="mx-auto flex h-full max-w-4xl flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <MessageSquare className="h-5 w-5 text-midground/70" />
          <Typography variant="md" compressed className="text-midground">
            Chat
          </Typography>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="rounded-md border border-border bg-card/40 px-2 py-1 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/80 focus:outline-none"
          >
            <option value="">default</option>
            {models.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={clearChat}
            disabled={messages.length === 0 || streaming}
            className="rounded-md border border-border bg-card/40 px-2.5 py-1 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/70 hover:bg-card/70 disabled:opacity-40"
          >
            Clear
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-400">
          {error}
        </div>
      )}

      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto rounded-lg border border-border bg-card/30 p-4"
      >
        {messages.length === 0 && !streaming && (
          <div className="flex h-full items-center justify-center text-center text-sm text-midground/55">
            <div>
              <div className="font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/50">
                CVC Chat
              </div>
              <div className="mt-2 text-midground/70">
                Connected to gateway. Send a message to start.
              </div>
            </div>
          </div>
        )}
        <div className="flex flex-col gap-3">
          {messages.map((m, i) => (
            <div
              key={i}
              className={
                m.role === "user"
                  ? "self-end max-w-[85%] rounded-lg border border-border bg-midground/10 px-4 py-2.5 text-sm text-midground"
                  : "self-start max-w-[90%] rounded-lg border border-border bg-card/60 px-4 py-2.5 text-sm text-midground/95"
              }
            >
              <div className="mb-1 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">
                {m.role}
                {m.pending && " · streaming"}
              </div>
              <div className="whitespace-pre-wrap break-words">{m.content}</div>
            </div>
          ))}
          {status && (
            <div className="self-start flex items-center gap-2 rounded-md border border-border bg-card/40 px-3 py-1.5 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/60">
              <Loader2 className="h-3 w-3 animate-spin" />
              {status}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-end gap-2 rounded-lg border border-border bg-card/40 p-2">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          rows={2}
          placeholder="Message… (Enter to send, Shift+Enter for newline)"
          className="flex-1 resize-none bg-transparent px-2 py-1.5 text-sm text-midground placeholder:text-midground/40 focus:outline-none"
          disabled={streaming}
        />
        {streaming ? (
          <button
            type="button"
            onClick={abort}
            className="flex items-center gap-1.5 rounded-md border border-border bg-red-500/10 px-3 py-2 font-mono-ui text-[0.7rem] uppercase tracking-wider text-red-400 hover:bg-red-500/20"
          >
            <Square className="h-3.5 w-3.5" />
            Stop
          </button>
        ) : (
          <button
            type="button"
            onClick={send}
            disabled={!canSend}
            className="flex items-center gap-1.5 rounded-md border border-border bg-midground/15 px-3 py-2 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground hover:bg-midground/25 disabled:opacity-40"
          >
            <Send className="h-3.5 w-3.5" />
            Send
          </button>
        )}
      </div>
    </div>
  );
}
