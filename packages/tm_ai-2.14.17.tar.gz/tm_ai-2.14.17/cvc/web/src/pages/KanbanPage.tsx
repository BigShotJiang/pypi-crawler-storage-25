import { useEffect, useMemo, useRef, useState } from "react";
import {
  DndContext,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import { Kanban as KanbanIcon, Plus, X, Heart, MessageCircle, Link2, User } from "lucide-react";
import { Typography } from "@/components/NouiTypography";
import { cn } from "@/lib/utils";

type Column = "pending" | "in_progress" | "blocked" | "completed";

interface KanbanCard {
  id: string;
  title: string;
  description?: string;
  column: Column;
  assignee?: string;
  comments?: { author: string; body: string; ts: number }[];
  links?: { label: string; href: string }[];
  heartbeat?: number;
}

const COLUMNS: { id: Column; label: string }[] = [
  { id: "pending", label: "Pending" },
  { id: "in_progress", label: "In Progress" },
  { id: "blocked", label: "Blocked" },
  { id: "completed", label: "Completed" },
];

// TODO(slice-3): replace mock with GET /api/kanban/cards
const SEED: KanbanCard[] = [
  {
    id: "k1",
    title: "Wire CVC-red theme tokens into nous-ui buttons",
    description: "Override `--color-primary` and ring color in cvc-red.css.",
    column: "in_progress",
    assignee: "tina",
    heartbeat: Date.now() / 1000 - 600,
  },
  {
    id: "k2",
    title: "Slice 3: gateway endpoints for /api/cron and /api/skills",
    column: "pending",
    assignee: "robin",
  },
  {
    id: "k3",
    title: "Investigate flaky chat reconnect on tab refocus",
    column: "blocked",
    assignee: "samantha",
    comments: [{ author: "samantha", body: "Repro on macOS 26.4.1", ts: Date.now() / 1000 - 1800 }],
  },
  {
    id: "k4",
    title: "Publish tm-ai 2.7.0",
    column: "completed",
    assignee: "jai",
  },
  {
    id: "k5",
    title: "Cmd-K palette: fuzzy search across sessions + branches",
    column: "in_progress",
    assignee: "tina",
  },
  {
    id: "k6",
    title: "Right inspector: live token meter wiring",
    column: "pending",
    assignee: "tina",
  },
];

export default function KanbanPage() {
  const [cards, setCards] = useState<KanbanCard[]>(SEED);
  const [open, setOpen] = useState<KanbanCard | null>(null);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  const grouped = useMemo(() => {
    const m: Record<Column, KanbanCard[]> = {
      pending: [], in_progress: [], blocked: [], completed: [],
    };
    cards.forEach((c) => m[c.column].push(c));
    return m;
  }, [cards]);

  function onDragEnd(ev: DragEndEvent) {
    const { active, over } = ev;
    if (!over) return;
    const target = over.id as Column;
    setCards((prev) => prev.map((c) => (c.id === active.id ? { ...c, column: target } : c)));
  }

  function addCard(col: Column) {
    const title = window.prompt("Card title?");
    if (!title) return;
    setCards((p) => [
      ...p,
      { id: `k${Date.now()}`, title, column: col, heartbeat: Date.now() / 1000 },
    ]);
  }

  return (
    <div className="flex h-full flex-col gap-4">
      <div className="flex items-center gap-3">
        <KanbanIcon className="h-5 w-5 text-midground/70" />
        <Typography variant="md" compressed className="text-midground">Kanban</Typography>
        <span className="font-mono-ui text-[0.62rem] uppercase tracking-wider text-midground/45">
          {cards.length} cards · drag to reorder
        </span>
      </div>

      <DndContext sensors={sensors} onDragEnd={onDragEnd}>
        <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
          {COLUMNS.map((col) => (
            <ColumnView
              key={col.id}
              column={col}
              cards={grouped[col.id]}
              onAdd={() => addCard(col.id)}
              onOpen={(c) => setOpen(c)}
            />
          ))}
        </div>
      </DndContext>

      {open && <CardModal card={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

function ColumnView({
  column, cards, onAdd, onOpen,
}: {
  column: { id: Column; label: string };
  cards: KanbanCard[];
  onAdd: () => void;
  onOpen: (c: KanbanCard) => void;
}) {
  const { setNodeRef, isOver } = useDroppable({ id: column.id });
  return (
    <div
      ref={setNodeRef}
      className={cn(
        "flex flex-col rounded-lg border border-border bg-card/40 p-3 transition-colors",
        isOver && "border-midground/40 bg-card/60",
      )}
    >
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Typography variant="sm" compressed className="text-midground uppercase">
            {column.label}
          </Typography>
          <span className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">
            {cards.length}
          </span>
        </div>
        <button
          onClick={onAdd}
          className="rounded-md p-1 text-midground/60 hover:bg-midground/10 hover:text-midground"
          aria-label="Add card"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
      <div className="flex flex-col gap-2 overflow-y-auto pr-1">
        {cards.map((c) => <DraggableCard key={c.id} card={c} onOpen={() => onOpen(c)} />)}
        {cards.length === 0 && (
          <div className="rounded-md border border-dashed border-border/50 px-3 py-6 text-center font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/40">
            empty
          </div>
        )}
      </div>
    </div>
  );
}

function DraggableCard({ card, onOpen }: { card: KanbanCard; onOpen: () => void }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: card.id });
  const style = transform
    ? { transform: `translate(${transform.x}px, ${transform.y}px)` }
    : undefined;
  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      onClick={onOpen}
      className={cn(
        "cursor-grab rounded-md border border-border bg-background-base/60 p-2.5 text-left text-sm shadow-sm transition-colors",
        "hover:border-midground/30 active:cursor-grabbing",
        isDragging && "opacity-60",
      )}
    >
      <div className="text-midground">{card.title}</div>
      <div className="mt-1.5 flex items-center gap-2 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">
        {card.assignee && (<span className="inline-flex items-center gap-1"><User className="h-3 w-3" />{card.assignee}</span>)}
        {card.comments?.length ? (
          <span className="inline-flex items-center gap-1"><MessageCircle className="h-3 w-3" />{card.comments.length}</span>
        ) : null}
        {card.heartbeat && <span className="inline-flex items-center gap-1"><Heart className="h-3 w-3" />{Math.floor((Date.now() / 1000 - card.heartbeat) / 60)}m</span>}
      </div>
    </div>
  );
}

function CardModal({ card, onClose }: { card: KanbanCard; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function onKey(e: KeyboardEvent) { if (e.key === "Escape") onClose(); }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background-base/70 backdrop-blur-sm" onClick={onClose}>
      <div
        ref={ref}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-lg border border-border bg-card p-5 shadow-2xl"
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <Typography variant="md" className="text-midground">{card.title}</Typography>
          <button onClick={onClose} className="rounded-md p-1 text-midground/60 hover:bg-midground/10 hover:text-midground">
            <X className="h-4 w-4" />
          </button>
        </div>
        {card.description && <p className="text-sm text-midground/80">{card.description}</p>}
        <dl className="mt-4 grid grid-cols-2 gap-3 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/60">
          <div><dt className="text-midground/40">Assignee</dt><dd className="mt-1 text-midground">{card.assignee ?? "—"}</dd></div>
          <div><dt className="text-midground/40">Column</dt><dd className="mt-1 text-midground">{card.column}</dd></div>
        </dl>
        {card.comments?.length ? (
          <div className="mt-4">
            <div className="mb-2 font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/50">Comments</div>
            <ul className="flex flex-col gap-2">
              {card.comments.map((c, i) => (
                <li key={i} className="rounded-md border border-border bg-background-base/40 p-2 text-sm">
                  <div className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">{c.author}</div>
                  <div className="text-midground/85">{c.body}</div>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
        {card.links?.length ? (
          <div className="mt-4 space-y-1">
            {card.links.map((l, i) => (
              <a key={i} href={l.href} className="inline-flex items-center gap-1 text-sm text-[#4a9eff] hover:underline">
                <Link2 className="h-3 w-3" /> {l.label}
              </a>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}
