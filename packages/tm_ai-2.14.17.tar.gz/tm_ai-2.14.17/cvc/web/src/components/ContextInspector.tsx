import { useEffect, useState } from "react";
import { Activity, Cpu, GitCommitVertical, Wrench, X } from "lucide-react";
import { api, type CommitEntry, type MCPTool } from "@/lib/api";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onClose: () => void;
}

export function ContextInspector({ open, onClose }: Props) {
  const [commits, setCommits] = useState<CommitEntry[]>([]);
  const [tools, setTools] = useState<MCPTool[]>([]);
  const [model, setModel] = useState<string>(() => localStorage.getItem("cvc.model") ?? "claude-opus-4.7");

  useEffect(() => {
    if (!open) return;
    api.commits(6).then((rows) => setCommits(rows ?? [])).catch(() => {});
    api.mcpTools().then((r) => setTools((r.tools ?? []).slice(0, 8))).catch(() => {});
  }, [open]);

  function pickModel(m: string) {
    setModel(m);
    localStorage.setItem("cvc.model", m);
  }

  // TODO(slice-3): live token meter + cost via WS
  const tokensUsed = 4_823;
  const tokensBudget = 200_000;
  const usedPct = Math.min(100, (tokensUsed / tokensBudget) * 100);
  const cost = (tokensUsed / 1_000_000) * 15;

  return (
    <aside
      className={cn(
        "fixed inset-y-0 right-0 z-40 flex w-80 flex-col border-l border-border bg-background-base/90 backdrop-blur-xl transition-transform",
        open ? "translate-x-0" : "translate-x-full",
      )}
    >
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <span className="font-mono-ui text-[0.65rem] uppercase tracking-[0.18em] text-midground/65">
          Context Inspector
        </span>
        <button onClick={onClose} className="rounded-md p-1 text-midground/60 hover:bg-midground/10 hover:text-midground">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="flex-1 space-y-5 overflow-y-auto px-4 py-4">
        <Section icon={Activity} title="Token meter">
          <div className="font-mono-ui text-[0.7rem] text-midground/70">
            <div className="flex justify-between">
              <span>{tokensUsed.toLocaleString()} / {tokensBudget.toLocaleString()}</span>
              <span>{usedPct.toFixed(1)}%</span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-background-base/60">
              <div className="h-full bg-[#e63946]" style={{ width: `${usedPct}%` }} />
            </div>
            <div className="mt-1.5 text-midground/50">≈ ${cost.toFixed(4)}</div>
          </div>
        </Section>

        <Section icon={Cpu} title="Model">
          <div className="flex flex-col gap-1">
            {["claude-opus-4.7", "claude-sonnet-4", "gpt-5", "gemini-2.5-pro"].map((m) => (
              <button
                key={m}
                onClick={() => pickModel(m)}
                className={cn(
                  "rounded-md border px-2 py-1.5 text-left font-mono-ui text-[0.7rem] uppercase tracking-wider",
                  model === m
                    ? "border-midground/50 bg-midground/15 text-midground"
                    : "border-border bg-background-base/40 text-midground/65 hover:bg-card/60",
                )}
              >
                {m}
              </button>
            ))}
          </div>
        </Section>

        <Section icon={Wrench} title="Active tools">
          {tools.length === 0 && (
            <div className="font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/40">none</div>
          )}
          <ul className="flex flex-col gap-1">
            {tools.map((t) => (
              <li key={t.name} className="truncate font-mono-ui text-[0.7rem] text-midground/75">
                {t.name}
              </li>
            ))}
          </ul>
        </Section>

        <Section icon={GitCommitVertical} title="Recent commits">
          {commits.length === 0 && (
            <div className="font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/40">none</div>
          )}
          <ul className="flex flex-col gap-1.5">
            {commits.map((c) => (
              <li key={c.hash} className="rounded-md border border-border bg-card/40 px-2 py-1.5">
                <div className="font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/50">
                  {c.hash?.slice(0, 8) ?? "—"}
                </div>
                <div className="line-clamp-2 text-xs text-midground/80">
                  {c.message ?? "(no message)"}
                </div>
              </li>
            ))}
          </ul>
        </Section>
      </div>
    </aside>
  );
}

function Section({
  icon: Icon, title, children,
}: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <section>
      <div className="mb-2 flex items-center gap-1.5 font-mono-ui text-[0.6rem] uppercase tracking-[0.18em] text-midground/50">
        <Icon className="h-3 w-3" />
        {title}
      </div>
      {children}
    </section>
  );
}
