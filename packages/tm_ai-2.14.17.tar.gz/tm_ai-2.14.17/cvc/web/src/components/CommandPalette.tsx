import { useEffect, useMemo, useState } from "react";
import { Command } from "cmdk";
import { useNavigate } from "react-router-dom";
import {
  Activity, Bot, Brain, Clock, Cpu, GitBranch, GitCommitVertical,
  Kanban, LayoutDashboard, MessageSquare, Network, Search, Settings, Wrench, BookOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface PaletteItem {
  id: string;
  label: string;
  group: string;
  icon: React.ComponentType<{ className?: string }>;
  action: () => void;
  hint?: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CommandPalette({ open, onOpenChange }: Props) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        onOpenChange(!open);
      }
      if (e.key === "Escape" && open) onOpenChange(false);
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  const items = useMemo<PaletteItem[]>(() => {
    const go = (path: string) => () => { navigate(path); onOpenChange(false); };
    return [
      { id: "nav.overview", label: "Overview", group: "Navigate", icon: LayoutDashboard, action: go("/overview") },
      { id: "nav.chat", label: "Chat", group: "Navigate", icon: MessageSquare, action: go("/chat") },
      { id: "nav.sessions", label: "Sessions", group: "Navigate", icon: Activity, action: go("/sessions") },
      { id: "nav.branches", label: "Branches", group: "Navigate", icon: GitBranch, action: go("/branches") },
      { id: "nav.commits", label: "Commits", group: "Navigate", icon: GitCommitVertical, action: go("/commits") },
      { id: "nav.kanban", label: "Kanban", group: "Navigate", icon: Kanban, action: go("/kanban") },
      { id: "nav.cron", label: "Cron", group: "Navigate", icon: Clock, action: go("/cron") },
      { id: "nav.memory", label: "Memory", group: "Navigate", icon: Brain, action: go("/memory") },
      { id: "nav.skills", label: "Skills", group: "Navigate", icon: BookOpen, action: go("/skills") },
      { id: "nav.tools", label: "Tools", group: "Navigate", icon: Wrench, action: go("/tools") },
      { id: "nav.hive", label: "Hive Mind", group: "Navigate", icon: Network, action: go("/hive") },
      { id: "nav.agents", label: "Agents", group: "Navigate", icon: Bot, action: go("/agents") },
      { id: "nav.models", label: "Models", group: "Navigate", icon: Cpu, action: go("/models") },
      { id: "nav.settings", label: "Settings", group: "Navigate", icon: Settings, action: go("/settings") },
      // Slash-style actions (TODO(slice-3): hydrate from /api/slash/commands)
      { id: "act.new-session", label: "/new — Start new session", group: "Actions", icon: MessageSquare, action: go("/chat") },
      { id: "act.new-branch", label: "/branch — Create cognitive branch", group: "Actions", icon: GitBranch, action: go("/branches") },
      { id: "act.compact", label: "/compact — Compact context window", group: "Actions", icon: Brain, action: () => onOpenChange(false) },
    ];
  }, [navigate, onOpenChange]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-center bg-background-base/70 px-4 pt-[15vh] backdrop-blur-sm"
      onClick={() => onOpenChange(false)}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl overflow-hidden rounded-lg border border-border bg-card shadow-2xl"
      >
        <Command label="Command palette" className="flex flex-col">
          <div className="flex items-center gap-2 border-b border-border px-3">
            <Search className="h-4 w-4 text-midground/60" />
            <Command.Input
              autoFocus
              value={query}
              onValueChange={setQuery}
              placeholder="Type a command, page, or action…"
              className="w-full bg-transparent py-3 font-mono-ui text-[0.85rem] text-midground placeholder:text-midground/40 focus:outline-none"
            />
            <kbd className="hidden rounded border border-border bg-background-base/60 px-1.5 py-0.5 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55 sm:inline">
              esc
            </kbd>
          </div>
          <Command.List className="max-h-[50vh] overflow-y-auto p-2">
            <Command.Empty className="px-3 py-6 text-center font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/40">
              No results
            </Command.Empty>
            {Array.from(new Set(items.map((i) => i.group))).map((group) => (
              <Command.Group
                key={group}
                heading={<span className="px-2 font-mono-ui text-[0.6rem] uppercase tracking-[0.18em] text-midground/45">{group}</span>}
              >
                {items.filter((i) => i.group === group).map((i) => {
                  const Icon = i.icon;
                  return (
                    <Command.Item
                      key={i.id}
                      value={`${i.group} ${i.label}`}
                      onSelect={() => i.action()}
                      className={cn(
                        "flex cursor-pointer items-center gap-2.5 rounded-md px-2.5 py-2 text-sm text-midground/85",
                        "data-[selected=true]:bg-midground/15 data-[selected=true]:text-midground",
                      )}
                    >
                      <Icon className="h-3.5 w-3.5 text-midground/60" />
                      <span>{i.label}</span>
                    </Command.Item>
                  );
                })}
              </Command.Group>
            ))}
          </Command.List>
          <div className="flex items-center justify-between border-t border-border px-3 py-1.5 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/45">
            <span>↑ ↓ to navigate · ↵ to select</span>
            <span>cmd-k</span>
          </div>
        </Command>
      </div>
    </div>
  );
}
