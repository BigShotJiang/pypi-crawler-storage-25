import { useEffect, useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import {
  Activity, Bot, BookOpen, Boxes, Brain, Clock, Cpu, GitBranch, GitCommitVertical,
  History, Kanban, LayoutDashboard, Menu, MessageSquare, Network, PanelRight, Plug,
  Search, Server, Settings, Share2, Wrench, X,
} from "lucide-react";
import { Backdrop } from "@/components/Backdrop";
import { ThemeSwitcher } from "@/components/ThemeSwitcher";
import { Typography } from "@/components/NouiTypography";
import { CommandPalette } from "@/components/CommandPalette";
import { ContextInspector } from "@/components/ContextInspector";
import { useTheme } from "@/themes";
import { cn } from "@/lib/utils";
import { useGatewayStatus } from "@/lib/useGatewayStatus";
import { useDashboardWS } from "@/lib/useDashboardWS";

interface NavItem { to: string; label: string; icon: React.ComponentType<{ className?: string }>; }
interface NavSection { label: string; items: NavItem[]; }

const NAV: NavSection[] = [
  {
    label: "Main",
    items: [
      { to: "/overview", label: "Overview", icon: LayoutDashboard },
      { to: "/chat", label: "Chat", icon: MessageSquare },
      { to: "/sessions", label: "Sessions", icon: Activity },
      { to: "/timeline", label: "Timeline", icon: GitCommitVertical },
    ],
  },
  {
    label: "Workflow",
    items: [
      { to: "/kanban", label: "Kanban", icon: Kanban },
      { to: "/cron", label: "Cron", icon: Clock },
      { to: "/skills", label: "Skills", icon: BookOpen },
      { to: "/tools", label: "Tools", icon: Wrench },
    ],
  },
  {
    label: "Subsystems",
    items: [
      { to: "/hive", label: "Hive Mind", icon: Network },
      { to: "/agents", label: "Agents", icon: Bot },
      { to: "/swarm", label: "Swarm", icon: Share2 },
      { to: "/mcp", label: "MCP", icon: Boxes },
      { to: "/proxy", label: "Proxy", icon: Server },
      { to: "/sdk", label: "SDK", icon: Boxes },
    ],
  },
  {
    label: "Data",
    items: [
      { to: "/memory", label: "Memory", icon: Brain },
      { to: "/branches", label: "Branches", icon: GitBranch },
      { to: "/commits", label: "Commits", icon: History },
      { to: "/operations", label: "Operations", icon: Wrench },
    ],
  },
  {
    label: "Config",
    items: [
      { to: "/models", label: "Models", icon: Cpu },
      { to: "/connections", label: "Connections", icon: Plug },
      { to: "/settings", label: "Settings", icon: Settings },
    ],
  },
];

function StatusDot({ state, label, detail }: { state: "ok" | "down" | "unknown"; label: string; detail?: string }) {
  const color = state === "ok" ? "bg-emerald-400" : state === "down" ? "bg-red-400" : "bg-midground/40";
  return (
    <div
      className="flex items-center gap-1.5 rounded-md border border-border bg-card/40 px-2 py-1 font-mono-ui text-[0.65rem] uppercase tracking-wider text-midground/70"
      title={detail ?? `${label}: ${state}`}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", color)} />
      <span>{label}</span>
    </div>
  );
}

function Sidebar({ open, collapsed, onClose, onToggleCollapse }: {
  open: boolean; collapsed: boolean; onClose: () => void; onToggleCollapse: () => void;
}) {
  return (
    <>
      <div
        className={cn(
          "fixed inset-0 z-40 bg-background-base/60 backdrop-blur-sm transition-opacity md:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex flex-col border-r border-border bg-background-base/85 backdrop-blur-xl transition-all md:static md:translate-x-0",
          collapsed ? "md:w-16" : "w-64",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between border-b border-border px-4 py-4">
          <div className="flex items-center gap-2.5">
            <div
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md font-bold text-background-base shadow-[inset_-1px_-1px_0_0_rgba(0,0,0,0.5),inset_1px_1px_0_0_rgba(255,255,255,0.5)]"
              style={{
                background: "linear-gradient(135deg, var(--midground-base) 0%, color-mix(in srgb, var(--midground-base) 60%, var(--background-base)) 100%)",
              }}
            >
              <span className="font-mono-ui text-sm">CVC</span>
            </div>
            {!collapsed && (
              <Typography variant="sm" compressed className="text-midground uppercase">
                Cognitive VC
              </Typography>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-midground/70 hover:bg-midground/10 hover:text-midground md:hidden"
            aria-label="Close sidebar"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-2 py-3">
          {NAV.map((section) => (
            <div key={section.label} className="mb-4">
              {!collapsed && (
                <div className="px-3 pb-1.5 font-mono-ui text-[0.58rem] uppercase tracking-[0.18em] text-midground/45">
                  {section.label}
                </div>
              )}
              <ul className="flex flex-col gap-0.5">
                {section.items.map(({ to, label, icon: Icon }) => (
                  <li key={to}>
                    <NavLink
                      to={to}
                      onClick={onClose}
                      title={collapsed ? label : undefined}
                      className={({ isActive }) =>
                        cn(
                          "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                          collapsed && "justify-center px-2",
                          isActive
                            ? "bg-midground/15 text-midground shadow-[inset_-1px_-1px_0_0_rgba(0,0,0,0.5),inset_1px_1px_0_0_rgba(255,255,255,0.16)]"
                            : "text-midground/70 hover:bg-midground/8 hover:text-midground",
                        )
                      }
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      {!collapsed && (
                        <span className="font-medium tracking-wide uppercase font-mono-ui text-[0.78rem]">{label}</span>
                      )}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="border-t border-border px-2 py-2">
          {!collapsed && <div className="px-1 pb-2"><ThemeSwitcher dropUp /></div>}
          <button
            onClick={onToggleCollapse}
            className="hidden w-full items-center justify-center rounded-md px-2 py-1.5 font-mono-ui text-[0.6rem] uppercase tracking-wider text-midground/55 hover:bg-midground/10 hover:text-midground md:flex"
          >
            {collapsed ? "›" : "‹ collapse"}
          </button>
        </div>
      </aside>
    </>
  );
}

function TopBar({
  onOpenSidebar, onOpenPalette, onToggleInspector, themeLabel,
}: {
  onOpenSidebar: () => void; onOpenPalette: () => void; onToggleInspector: () => void; themeLabel: string;
}) {
  const status = useGatewayStatus(6000);
  const [workspace, setWorkspace] = useState(() => localStorage.getItem("cvc.workspace") ?? "default");
  function pickWorkspace(w: string) {
    setWorkspace(w);
    localStorage.setItem("cvc.workspace", w);
  }
  return (
    <header className="flex items-center justify-between border-b border-border bg-background-base/60 px-3 py-2.5 backdrop-blur md:px-4">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onOpenSidebar}
          className="rounded-md p-1.5 text-midground/70 hover:bg-midground/10 hover:text-midground md:hidden"
          aria-label="Open sidebar"
        >
          <Menu className="h-4 w-4" />
        </button>
        <select
          value={workspace}
          onChange={(e) => pickWorkspace(e.target.value)}
          className="rounded-md border border-border bg-card/40 px-2 py-1 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/85 focus:border-midground/50 focus:outline-none"
        >
          <option value="default">workspace: default</option>
          <option value="cvc">workspace: cvc</option>
          <option value="hermes">workspace: hermes</option>
        </select>
        <button
          onClick={onOpenPalette}
          className="ml-2 hidden items-center gap-2 rounded-md border border-border bg-card/40 px-2.5 py-1 font-mono-ui text-[0.7rem] uppercase tracking-wider text-midground/65 hover:bg-card md:inline-flex"
        >
          <Search className="h-3 w-3" /> Search
          <kbd className="rounded border border-border bg-background-base/60 px-1 text-[0.55rem]">⌘K</kbd>
        </button>
      </div>
      <div className="flex items-center gap-2">
        <StatusDot state={status.proxy} label="Proxy" detail={`Gateway ${status.proxy}`} />
        <StatusDot state={status.agent} label="Agent" detail={status.agentCount != null ? `${status.agentCount} agents` : undefined} />
        <StatusDot state={status.mcp} label="MCP" detail={status.mcpToolCount != null ? `${status.mcpToolCount} tools` : undefined} />
        <span className="hidden font-mono-ui text-[0.62rem] uppercase tracking-wider text-midground/55 lg:inline">
          · {themeLabel}
        </span>
        <button
          onClick={onToggleInspector}
          title="Toggle inspector"
          className="rounded-md border border-border bg-card/40 p-1.5 text-midground/70 hover:bg-card hover:text-midground"
        >
          <PanelRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </header>
  );
}

function Footer() {
  const [now, setNow] = useState(new Date());
  const { status: wsStatus } = useDashboardWS();
  const connected = wsStatus === "open";
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const wsColor = connected ? "bg-emerald-400" : "bg-red-400";
  return (
    <footer className="flex items-center justify-between border-t border-border bg-background-base/60 px-4 py-1.5 font-mono-ui text-[0.62rem] uppercase tracking-[0.16em] text-midground/55 md:px-6">
      <div className="flex items-center gap-2">
        <span className={cn("h-1.5 w-1.5 rounded-full", wsColor)} />
        <span>WS {connected ? "live" : "offline"}</span>
      </div>
      <span>{now.toLocaleTimeString()}</span>
    </footer>
  );
}

export default function MainLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(() => localStorage.getItem("cvc.sidebar.collapsed") === "1");
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [inspectorOpen, setInspectorOpen] = useState(() => localStorage.getItem("cvc.inspector.open") === "1");
  const { theme } = useTheme();

  useEffect(() => { localStorage.setItem("cvc.sidebar.collapsed", collapsed ? "1" : "0"); }, [collapsed]);
  useEffect(() => { localStorage.setItem("cvc.inspector.open", inspectorOpen ? "1" : "0"); }, [inspectorOpen]);

  useEffect(() => {
    function onResize() { if (window.innerWidth >= 768) setSidebarOpen(false); }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  return (
    <div className="relative isolate flex h-full overflow-hidden">
      <Backdrop />
      <Sidebar
        open={sidebarOpen}
        collapsed={collapsed}
        onClose={() => setSidebarOpen(false)}
        onToggleCollapse={() => setCollapsed((v) => !v)}
      />
      <div className="relative flex min-w-0 flex-1 flex-col">
        <TopBar
          onOpenSidebar={() => setSidebarOpen(true)}
          onOpenPalette={() => setPaletteOpen(true)}
          onToggleInspector={() => setInspectorOpen((v) => !v)}
          themeLabel={theme.label}
        />
        <main className="relative min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8 md:py-8">
          <Outlet />
        </main>
        <Footer />
      </div>
      <ContextInspector open={inspectorOpen} onClose={() => setInspectorOpen(false)} />
      <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} />
    </div>
  );
}
