/**
 * CVC dashboard API client (Phase B+C).
 *
 * Talks to the gateway's REST surface (cvc/gateway.py). Same-origin by default;
 * Vite dev proxy in vite.config.ts forwards `/api` → CVC_GATEWAY_URL.
 *
 * Themes are local-only (stored in localStorage by ThemeProvider) — no server
 * round-trip needed; the no-op stubs here just satisfy the ThemeProvider's
 * optional `apiClient` slot.
 */

import type { DashboardTheme, ThemeListResponse } from "@/themes/types";
export type * from "./types";
export type { CommitEntry as CommitSummary } from "./types";
import type {
  AgentFromPromptResponse,
  AgentTemplate,
  AgentsListResponse,
  AnalyticsResponse,
  AuditEntry,
  BranchRequest,
  BranchSummary,
  ChatRequest,
  CommitEntry,
  CommitRequest,
  ConnectionInfo,
  CurrentModel,
  DiffResult,
  GatewayConfig,
  HiveMemoryEntry,
  HiveMemoryResponse,
  HiveMemoryStats,
  HiveMindAgent,
  MCPStatus,
  MCPTool,
  MemoryBlobsResponse,
  MemoryContextResponse,
  MemoryStatsResponse,
  MergeRequest,
  ModelCatalog,
  OperationResult,
  OpsStatus,
  RecallResult,
  RegisterAgentRequest,
  RestoreRequest,
  ServicesResponse,
  SettingsResponse,
  SettingsSchema,
  SquadInfo,
  StatsResponse,
  TimelineEntry,
  VCSStatus,
  WorkspaceInfo,
} from "./types";

function readBase(): string {
  const w = typeof window !== "undefined" ? window : undefined;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const injected = (w as any)?.__CVC_API_BASE__;
  if (typeof injected === "string" && injected.length) {
    return injected.replace(/\/+$/, "");
  }
  return "/api";
}

export const CVC_API_BASE = readBase();

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function fetchJSON<T>(path: string, init?: RequestInit): Promise<T> {
  const url = path.startsWith("http") ? path : `${CVC_API_BASE}${path}`;
  const res = await fetch(url, {
    ...init,
    headers: {
      "content-type": "application/json",
      accept: "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    let body = "";
    try {
      body = await res.text();
    } catch {
      /* ignore */
    }
    throw new ApiError(
      res.status,
      `${init?.method ?? "GET"} ${path} → ${res.status} ${res.statusText}${body ? ` — ${body.slice(0, 200)}` : ""}`,
    );
  }
  return (await res.json()) as T;
}

const get = <T>(path: string) => fetchJSON<T>(path);
const post = <T>(path: string, body?: unknown) =>
  fetchJSON<T>(path, {
    method: "POST",
    body: body != null ? JSON.stringify(body) : undefined,
  });
const put = <T>(path: string, body?: unknown) =>
  fetchJSON<T>(path, {
    method: "PUT",
    body: body != null ? JSON.stringify(body) : undefined,
  });
const del = <T>(path: string) => fetchJSON<T>(path, { method: "DELETE" });

// ─────────────────────────────────────────────────────────────────────────
// Domain-grouped API surface
// ─────────────────────────────────────────────────────────────────────────

export const api = {
  // ── health / workspace ─────────────────────────────────────────────────
  async health(): Promise<{ status: string; service?: string; version?: string }> {
    // /health is mounted outside /api on the gateway
    const origin = typeof window !== "undefined" ? window.location.origin : "";
    return fetchJSON(`${origin}/health`);
  },
  workspaceCurrent(): Promise<WorkspaceInfo> {
    return get<WorkspaceInfo>("/workspace/current");
  },

  // ── ops ────────────────────────────────────────────────────────────────
  opsStatus(): Promise<OpsStatus> {
    return get<Record<string, unknown>>("/ops/status").then((r) => ({
      branch: (r.branch as string) ?? (r.current_branch as string) ?? "main",
      head: (r.head as string) ?? "",
      total_commits: (r.total_commits as number) ?? 0,
      workspace: r.workspace as string | undefined,
    }));
  },
  opsBranches(): Promise<{ branches: BranchSummary[] } | string[]> {
    return get("/ops/branches");
  },
  opsTimeline(limit = 50): Promise<{ entries: TimelineEntry[] } | TimelineEntry[]> {
    return get(`/ops/timeline?limit=${limit}`);
  },
  opsCommit(req: CommitRequest): Promise<OperationResult> {
    return post("/ops/commit", req);
  },
  opsBranch(req: BranchRequest): Promise<OperationResult> {
    return post("/ops/branch", req);
  },
  opsMerge(req: MergeRequest): Promise<OperationResult> {
    return post("/ops/merge", req);
  },
  opsRestore(req: RestoreRequest): Promise<OperationResult> {
    return post("/ops/restore", req);
  },
  opsRecall(query: string, limit = 10): Promise<RecallResult> {
    return get(`/ops/recall?query=${encodeURIComponent(query)}&limit=${limit}`);
  },
  opsDiff(hash1: string, hash2: string): Promise<DiffResult> {
    return get(`/ops/diff?hash1=${encodeURIComponent(hash1)}&hash2=${encodeURIComponent(hash2)}`);
  },

  // ── gateway / analytics ────────────────────────────────────────────────
  services(): Promise<ServicesResponse> {
    return get("/gateway/services");
  },
  serviceAction(service: string, action: string): Promise<OperationResult> {
    return post(`/gateway/services/${encodeURIComponent(service)}/${encodeURIComponent(action)}`);
  },
  analytics(): Promise<AnalyticsResponse> {
    return get("/gateway/analytics");
  },
  commits(limit = 50): Promise<CommitEntry[]> {
    return get(`/gateway/commits?limit=${limit}`);
  },
  gatewayConfig(): Promise<GatewayConfig> {
    return get("/gateway/config");
  },

  // ── memory ─────────────────────────────────────────────────────────────
  memoryStats(): Promise<MemoryStatsResponse> {
    return get("/memory/stats");
  },
  memoryBlobs(limit = 20): Promise<MemoryBlobsResponse> {
    return get(`/memory/blobs?limit=${limit}`);
  },
  memoryContext(): Promise<MemoryContextResponse> {
    return get("/memory/context");
  },

  // ── models ─────────────────────────────────────────────────────────────
  modelCatalog(): Promise<ModelCatalog> {
    return get("/models/catalog");
  },
  currentModel(): Promise<CurrentModel> {
    return get("/models/current");
  },
  switchModel(provider: string, model: string): Promise<OperationResult> {
    return post("/models/switch", { provider, model });
  },

  // ── chat (streaming SSE) ───────────────────────────────────────────────
  async *chatStream(req: ChatRequest): AsyncGenerator<import("./types").ChatEvent, void, unknown> {
    const res = await fetch(`${CVC_API_BASE}/chat`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...req, stream: true }),
    });
    if (!res.ok) throw new ApiError(res.status, `Chat ${res.status}`);
    const reader = res.body?.getReader();
    if (!reader) return;
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop()!;
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6);
          if (data === "[DONE]") return;
          try {
            const parsed = JSON.parse(data);
            if (parsed.type) {
              yield parsed as import("./types").ChatEvent;
            } else if (parsed.choices?.[0]?.delta?.content) {
              yield { type: "text", content: parsed.choices[0].delta.content };
            }
          } catch {
            /* skip malformed SSE */
          }
        }
      }
    }
  },
  chatModels(): Promise<{ models: string[] }> {
    return get("/chat/models");
  },

  // ── MCP ────────────────────────────────────────────────────────────────
  mcpTools(): Promise<{ tools: MCPTool[]; total?: number }> {
    return get("/mcp/tools");
  },
  mcpStatus(): Promise<MCPStatus> {
    return get("/mcp/status");
  },

  // ── VCS ────────────────────────────────────────────────────────────────
  vcsStatus(): Promise<VCSStatus> {
    return get("/vcs/status");
  },

  // ── audit / stats / sessions / connections ─────────────────────────────
  audit(limit = 100): Promise<AuditEntry[] | { entries: AuditEntry[] }> {
    return get(`/audit?limit=${limit}`);
  },
  stats(): Promise<StatsResponse> {
    return get("/stats");
  },
  sessions(): Promise<unknown[] | { sessions: unknown[] }> {
    return get("/sessions");
  },
  connections(): Promise<{ connections: ConnectionInfo[] } | ConnectionInfo[]> {
    return get("/connections");
  },

  // ── hive mind agents ───────────────────────────────────────────────────
  hivemindAgents(): Promise<HiveMindAgent[] | { agents: HiveMindAgent[] }> {
    return get("/hivemind/agents");
  },
  swarmTopology(): Promise<{
    nodes: Array<{
      id: string;
      name?: string;
      role?: string;
      rank?: string;
      squad?: string;
      tier?: "mc" | "captain" | "specialist" | "misc";
      status?: string;
    }>;
    squads: Array<{ name: string; members: string[]; captain: string | null; count: number }>;
    edges: Array<{ from: string; to: string; type: "command" | "squad" }>;
    total_nodes: number;
    total_squads: number;
    workspace?: string;
  }> {
    return get("/swarm");
  },
  hivemindFeed(limit = 30): Promise<{
    events: Array<{
      hash?: string;
      agent_id?: string;
      branch?: string;
      message?: string;
      timestamp?: number;
    }>;
    total: number;
  }> {
    return get(`/hivemind/feed?limit=${limit}`);
  },
  hivemindStats(): Promise<{
    total_agents: number;
    total_commits: number;
    by_squad: Record<string, number>;
    by_rank: Record<string, number>;
    commits_last_hour: number;
    commits_last_24h: number;
  }> {
    return get("/hivemind/stats");
  },
  hivemindRegister(req: RegisterAgentRequest): Promise<OperationResult> {
    return post("/hivemind/register", req);
  },
  hivemindRemove(agentId: string): Promise<OperationResult> {
    return del(`/hivemind/agents/${encodeURIComponent(agentId)}`);
  },

  // ── hive memory ────────────────────────────────────────────────────────
  hiveMemory(opts?: {
    query?: string;
    category?: string;
    agent_id?: string;
    limit?: number;
  }): Promise<HiveMemoryResponse> {
    const params = new URLSearchParams();
    if (opts?.query) params.set("query", opts.query);
    if (opts?.category) params.set("category", opts.category);
    if (opts?.agent_id) params.set("agent_id", opts.agent_id);
    params.set("limit", String(opts?.limit ?? 50));
    return get(`/hivemind/memory?${params}`);
  },
  hiveMemoryWrite(
    agent_id: string,
    content: string,
    category = "general",
    tags: string[] = [],
  ): Promise<{ status: string; entry: HiveMemoryEntry }> {
    return post("/hivemind/memory", { agent_id, content, category, tags });
  },
  hiveMemoryStats(): Promise<HiveMemoryStats> {
    return get("/hivemind/memory/stats");
  },
  hiveMemorySummary(limit = 10): Promise<{ context: string }> {
    return get(`/hivemind/memory/summary?limit=${limit}`);
  },
  hiveMemoryCompact(): Promise<OperationResult> {
    return post("/hivemind/memory/compact");
  },

  // ── settings ───────────────────────────────────────────────────────────
  settings(): Promise<SettingsResponse> {
    return get("/settings");
  },
  settingsSchema(): Promise<SettingsSchema> {
    return get("/settings/schema");
  },
  settingsUpdate(level: "global" | "project" | "local", data: Record<string, unknown>): Promise<OperationResult> {
    return put(`/settings/${level}`, data);
  },
  settingsReset(level: string): Promise<OperationResult> {
    return post("/settings/reset", { level });
  },
  apiKeys(): Promise<Record<string, string>> {
    return get("/settings/keys");
  },
  setApiKey(provider: string, key: string): Promise<OperationResult> {
    return put(`/settings/keys/${encodeURIComponent(provider)}`, { api_key: key });
  },
  removeApiKey(provider: string): Promise<OperationResult> {
    return del(`/settings/keys/${encodeURIComponent(provider)}`);
  },
  testApiKey(provider: string): Promise<OperationResult> {
    return post(`/settings/keys/${encodeURIComponent(provider)}/test`);
  },
  hooks(): Promise<Record<string, unknown[]>> {
    return get<unknown>("/settings/hooks").then((r) => {
      // Gateway wraps as {hooks: {...}} — unwrap to flat dict.
      if (r && typeof r === "object" && "hooks" in r && typeof (r as { hooks: unknown }).hooks === "object") {
        return ((r as { hooks: Record<string, unknown[]> }).hooks) || {};
      }
      return (r as Record<string, unknown[]>) || {};
    });
  },
  addHook(event: string, command: string): Promise<OperationResult> {
    return post("/settings/hooks", { event, command });
  },
  removeHook(event: string, index: number): Promise<OperationResult> {
    return del(`/settings/hooks/${encodeURIComponent(event)}/${index}`);
  },
  envVars(): Promise<Record<string, string>> {
    return get<unknown>("/settings/env").then((r) => {
      if (r && typeof r === "object" && "env" in r && typeof (r as { env: unknown }).env === "object") {
        return ((r as { env: Record<string, string> }).env) || {};
      }
      return (r as Record<string, string>) || {};
    });
  },
  setEnvVars(vars: Record<string, string>): Promise<OperationResult> {
    return put("/settings/env", vars);
  },
  settingsLevel(level: "global" | "project" | "local"): Promise<Record<string, unknown>> {
    return get(`/settings/${level}`);
  },

  // ── agent templates ────────────────────────────────────────────────────
  agentsList(): Promise<AgentsListResponse> {
    return get("/agents");
  },
  agentsBuiltin(): Promise<AgentTemplate[]> {
    return get("/agents/builtin");
  },
  agentCreate(template: Partial<AgentTemplate>): Promise<{ status: string; agent: AgentTemplate }> {
    return post("/agents", template);
  },
  agentFromPrompt(prompt: string): Promise<AgentFromPromptResponse> {
    return post("/agents/from-prompt", { prompt });
  },
  agentDetail(id: string): Promise<AgentTemplate> {
    return get(`/agents/${encodeURIComponent(id)}`);
  },
  agentUpdate(id: string, data: Partial<AgentTemplate>): Promise<{ status: string; agent: AgentTemplate }> {
    return put(`/agents/${encodeURIComponent(id)}`, data);
  },
  agentDelete(id: string): Promise<OperationResult> {
    return del(`/agents/${encodeURIComponent(id)}`);
  },
  agentHistory(id: string): Promise<CommitEntry[]> {
    return get(`/agents/${encodeURIComponent(id)}/history`);
  },
  squadCreate(name: string, agents: string[]): Promise<OperationResult> {
    return post("/agents/squad", { name, agents });
  },
  squadList(): Promise<SquadInfo[]> {
    return get<{ squads: SquadInfo[] }>("/agents/squads").then((r) => r.squads ?? []);
  },

  // ── gateway workspaces / sessions / telemetry ──────────────────────────
  gatewayWorkspaces(): Promise<import("./types").GatewayWorkspacesResponse> {
    const origin = typeof window !== "undefined" ? window.location.origin : "";
    return fetchJSON(`${origin}/gateway/workspaces`);
  },
  gatewayRegisterWorkspace(
    req: import("./types").RegisterWorkspaceRequest,
  ): Promise<OperationResult> {
    const origin = typeof window !== "undefined" ? window.location.origin : "";
    return fetchJSON(`${origin}/gateway/register_workspace`, {
      method: "POST",
      body: JSON.stringify(req),
    });
  },
  workspaceClose(workspace_id: string): Promise<OperationResult> {
    return post("/workspace/close", { workspace_id });
  },
  telemetry(event: import("./types").TelemetryEvent): Promise<unknown> {
    return post("/telemetry", event).catch(() => ({}));
  },

  // ── themes (local-only stubs for ThemeProvider) ────────────────────────
  async getThemes(): Promise<ThemeListResponse> {
    return { themes: [], active: "cvc-red" };
  },
  async setTheme(name: string): Promise<{ active: string }> {
    return { active: name };
  },
  async createTheme(_definition: DashboardTheme): Promise<{ name: string }> {
    return { name: _definition.name };
  },
};

// ─────────────────────────────────────────────────────────────────────────
// WebSocket — dashboard event bus (existing)
// ─────────────────────────────────────────────────────────────────────────

export function dashboardWsUrl(): string {
  const base = CVC_API_BASE.startsWith("http")
    ? CVC_API_BASE
    : `${typeof window !== "undefined" ? window.location.origin : ""}${CVC_API_BASE}`;
  return base.replace(/^http/, "ws").replace(/\/api$/, "") + "/ws/dashboard";
}

// ─────────────────────────────────────────────────────────────────────────
// WebSocket — chat bridge (/api/ws/chat)
// ─────────────────────────────────────────────────────────────────────────

export function chatWsUrl(): string {
  const base = CVC_API_BASE.startsWith("http")
    ? CVC_API_BASE
    : `${typeof window !== "undefined" ? window.location.origin : ""}${CVC_API_BASE}`;
  return base.replace(/^http/, "ws") + "/ws/chat";
}

type ChatHandler = (ev: import("./types").ChatEvent) => void;

export class ChatWS {
  private ws: WebSocket | null = null;
  private url: string;
  private handlers: Partial<Record<import("./types").ChatEvent["type"], ChatHandler>> = {};
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectDelay = 2000;
  private readonly maxReconnectDelay = 30_000;
  private alive = true;
  private pendingSend: unknown | null = null;

  constructor(url?: string) {
    this.url = url ?? chatWsUrl();
  }

  on(type: import("./types").ChatEvent["type"], handler: ChatHandler): this {
    this.handlers[type] = handler;
    return this;
  }

  off(type: import("./types").ChatEvent["type"]): this {
    delete this.handlers[type];
    return this;
  }

  private dispatch(ev: import("./types").ChatEvent): void {
    const h = this.handlers[ev.type];
    if (h) h(ev);
  }

  connect(): void {
    if (this.ws?.readyState === WebSocket.OPEN) return;
    try {
      this.ws = new WebSocket(this.url);
    } catch {
      this.scheduleReconnect();
      return;
    }
    this.ws.onopen = () => {
      this.reconnectDelay = 2000;
      if (this.pendingSend !== null) {
        this.ws!.send(JSON.stringify(this.pendingSend));
        this.pendingSend = null;
      }
    };
    this.ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data) as import("./types").ChatEvent;
        this.dispatch(msg);
      } catch {
        /* ignore malformed frames */
      }
    };
    this.ws.onclose = () => {
      if (this.alive) this.scheduleReconnect();
    };
    this.ws.onerror = () => {
      this.ws?.close();
    };
  }

  disconnect(): void {
    this.alive = false;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.close();
    this.ws = null;
  }

  send(req: { messages: import("./types").ChatMessage[]; model?: string }): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(req));
    } else {
      this.pendingSend = req;
      if (!this.ws || this.ws.readyState === WebSocket.CLOSED) this.connect();
    }
  }

  abort(): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "abort" }));
    }
  }

  confirmTool(decision: "allow_once" | "allow_always" | "trust_all" | "deny" | "deny_suggest"): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "confirm", result: decision }));
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => this.connect(), this.reconnectDelay);
    this.reconnectDelay = Math.min(this.reconnectDelay * 1.5, this.maxReconnectDelay);
  }
}
