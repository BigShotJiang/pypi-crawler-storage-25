import { Navigate, Route, Routes } from "react-router-dom";
import MainLayout from "@/layouts/MainLayout";

import OverviewPage from "@/pages/OverviewPage";
import OperationsPage from "@/pages/OperationsPage";
import TimelinePage from "@/pages/TimelinePage";
import HomePage from "@/pages/HomePage";
import SessionsPage from "@/pages/SessionsPage";
import BranchesPage from "@/pages/BranchesPage";
import CommitsPage from "@/pages/CommitsPage";
import MemoryPage from "@/pages/MemoryPage";
import ModelsPage from "@/pages/ModelsPage";
import ConnectionsPage from "@/pages/ConnectionsPage";
import SettingsPage from "@/pages/SettingsPage";
import HiveMindPage from "@/pages/HiveMindPage";
import AgentsPage from "@/pages/AgentsPage";
import MCPPage from "@/pages/MCPPage";
import ProxyPage from "@/pages/ProxyPage";
import SDKPage from "@/pages/SDKPage";
import ChatPage from "@/pages/ChatPage";
import SwarmPage from "@/pages/SwarmPage";
import KanbanPage from "@/pages/KanbanPage";
import CronPage from "@/pages/CronPage";
import SkillsPage from "@/pages/SkillsPage";
import ToolsPage from "@/pages/ToolsPage";

export default function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Navigate to="/overview" replace />} />
        <Route path="/overview" element={<OverviewPage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/operations" element={<OperationsPage />} />
        <Route path="/timeline" element={<TimelinePage />} />
        <Route path="/hive" element={<HiveMindPage />} />
        <Route path="/agents" element={<AgentsPage />} />
        <Route path="/swarm" element={<SwarmPage />} />
        <Route path="/mcp" element={<MCPPage />} />
        <Route path="/proxy" element={<ProxyPage />} />
        <Route path="/sdk" element={<SDKPage />} />
        <Route path="/memory" element={<MemoryPage />} />
        <Route path="/branches" element={<BranchesPage />} />
        <Route path="/commits" element={<CommitsPage />} />
        <Route path="/sessions" element={<SessionsPage />} />
        <Route path="/models" element={<ModelsPage />} />
        <Route path="/connections" element={<ConnectionsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/kanban" element={<KanbanPage />} />
        <Route path="/cron" element={<CronPage />} />
        <Route path="/skills" element={<SkillsPage />} />
        <Route path="/tools" element={<ToolsPage />} />
        <Route path="*" element={<Navigate to="/overview" replace />} />
      </Route>
    </Routes>
  );
}
