# Missing Gateway Endpoints — Slice 2 (Dashboard)

Slice 2 wires up a Hermes-grade dashboard against `cvc/gateway.py`. Most pages
hit existing routes. The list below tracks endpoints the new pages **assume**
but the gateway does not yet expose. Each one is mocked client-side with a
`TODO(slice-3)` marker so the UI renders cleanly.

> **Constraint reminder:** Slice 2 must NOT modify `cvc/gateway.py`. Wiring
> these up is the job of Slice 3 (gateway expansion).

## Kanban (`KanbanPage.tsx`)

- `GET  /api/kanban/cards`           → list cards `{id, title, column, …}`
- `POST /api/kanban/cards`           → create card
- `PUT  /api/kanban/cards/{id}`      → update (move column, edit fields)
- `DELETE /api/kanban/cards/{id}`    → delete

Mock: 6 demo cards spread across the four columns; drag/drop persists in
component state only.

## Cron (`CronPage.tsx`)

- `GET  /api/cron/jobs`              → `[{id, name, cron, next_run, last_status, last_output}]`
- `POST /api/cron/jobs`              → create
- `POST /api/cron/jobs/{id}/pause`   → pause
- `POST /api/cron/jobs/{id}/resume`  → resume
- `DELETE /api/cron/jobs/{id}`       → delete

Mock: 3 demo jobs (security-scan, memory-compact, hivemind-sync).

## Skills (`SkillsPage.tsx`)

- `GET /api/skills`                  → `[{id, name, category, description, path, files: [...]}]`
- `GET /api/skills/{id}/content`     → full SKILL.md text

Mock: pulls a curated demo set covering common categories (vision, voice,
research, ops). Modal shows the description as content placeholder.

## Tools (`ToolsPage.tsx`)

- The gateway exposes `/api/mcp/tools` (already wired). Slice 2 reuses that
  for the Tools page — **no mock needed**. `success_rate` and
  `last_invocation` are not yet tracked server-side; surfaced as `—`.

## Chat — slash commands & uploads (`ChatPage.tsx`)

- `GET  /api/slash/commands`         → `[{name, description, args}]`
  Mock: hard-coded set (`/clear`, `/branch`, `/commit`, `/recall`, `/help`).
- `POST /api/uploads`                → multipart file upload, returns `{url, id}`
  Mock: drag-drop attaches files to message state but does not POST.

## Sessions extras (`SessionsPage.tsx`)

- `POST   /api/sessions/{id}/star`     → toggle star
- `POST   /api/sessions/{id}/archive`  → archive
- `DELETE /api/sessions/{id}`          → delete

Mock: actions update local state only.

## Settings — voice/plugins (`SettingsPage.tsx`)

- `GET /api/settings/voice` / `PUT /api/settings/voice`
- `GET /api/settings/plugins` / `PUT /api/settings/plugins/{id}`

Mock: tabs render with demo voices (ElevenLabs preset list) and a static
plugin list. Persistence: localStorage only until Slice 3.

## Right-side context inspector (`MainLayout.tsx`)

- `GET /api/context/live`            → `{tokens_used, tokens_budget, cost_usd, model, active_tools, recent_commits}`

Mock: derived locally — `recent_commits` reuses `/api/gateway/commits` (real
data), the rest is placeholder until Slice 3 ships a unified live-context
endpoint.
