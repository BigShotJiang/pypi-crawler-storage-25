"""
cvc.adapters.copilot — GitHub Copilot API adapter for CVC.

Routes Sofia/CVC agent LLM queries through the GitHub Copilot endpoint
(https://api.githubcopilot.com), using a Copilot OAuth token.

This lets CVC use an existing GitHub Copilot subscription as an LLM
backend without requiring a separate Anthropic or OpenAI API key.

Default model: claude-sonnet-4.6 (best quality for agentic work)
Env var:       COPILOT_GITHUB_TOKEN
"""

import logging

import httpx

from cvc.adapters.openai import OpenAIAdapter

logger = logging.getLogger("cvc.adapters.copilot")

DEFAULT_MODEL = "claude-sonnet-4.6"
COPILOT_BASE_URL = "https://api.githubcopilot.com"


class CopilotAdapter(OpenAIAdapter):
    """
    Adapter that routes requests through the GitHub Copilot API.

    Reuses the OpenAI wire format (chat completions) since the Copilot
    endpoint is OpenAI-compatible when accessed via api_mode=chat_completions.
    """

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL) -> None:
        super().__init__(api_key=api_key, model=model)

        self._api_key = api_key
        self._model = model
        self._client = httpx.AsyncClient(
            base_url=COPILOT_BASE_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                # Required by the Copilot API to identify the integration
                "Copilot-Integration-Id": "vscode-chat",
                "Editor-Version": "vscode/1.99.0",
                "Editor-Plugin-Version": "copilot-chat/0.26.0",
            },
            timeout=120.0,
        )
        logger.info("CopilotAdapter initialised (model=%s, endpoint=%s)", model, COPILOT_BASE_URL)


# Backwards-compat alias for any code still importing HermesAdapter.
# Remove after one release cycle.
HermesAdapter = CopilotAdapter
