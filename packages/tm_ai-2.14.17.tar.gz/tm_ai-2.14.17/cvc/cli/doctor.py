"""cvc.cli.doctor — Comprehensive system health check for CVC.

A beautiful, color-coded diagnostic command that inspects the local
CVC installation and reports back on:

* Python runtime
* Config & auth files (``~/.cvc/``)
* Provider authentication & registry
* Gateway and plugin subsystems
* Disk, SQLite, optional dependencies

Designed to be *nicer* than the Hermes equivalent — single-file,
fast, and friendly. Returns an exit code suitable for shell scripts:

* ``0`` — everything is healthy
* ``1`` — warnings only
* ``2`` — at least one failure
"""
from __future__ import annotations

import importlib
import os
import shutil
import stat
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Callable, List, Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Branding
# ---------------------------------------------------------------------------

CVC_RED = "#E63946"
CVC_GREEN = "#2EC27E"
CVC_YELLOW = "#F4B400"
CVC_DIM = "grey50"

STATUS_OK = "ok"
STATUS_WARN = "warn"
STATUS_FAIL = "fail"

_STATUS_GLYPH = {
    STATUS_OK: ("✔", CVC_GREEN),
    STATUS_WARN: ("⚠", CVC_YELLOW),
    STATUS_FAIL: ("✘", CVC_RED),
}


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class CheckResult:
    """The outcome of a single doctor check."""

    name: str
    status: str  # "ok" | "warn" | "fail"
    message: str = ""
    fix_hint: str = ""
    details: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "CheckResult":
        return cls(
            name=data["name"],
            status=data["status"],
            message=data.get("message", ""),
            fix_hint=data.get("fix_hint", ""),
            details=data.get("details", {}) or {},
        )


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def _cvc_home() -> Path:
    return Path(os.path.expanduser("~/.cvc"))


def check_python_version() -> CheckResult:
    v = sys.version_info
    msg = f"Python {v.major}.{v.minor}.{v.micro}"
    if v < (3, 10):
        return CheckResult(
            "Python ≥ 3.10",
            STATUS_FAIL,
            msg,
            "Upgrade Python to 3.10 or newer (e.g. `brew install python@3.12`).",
        )
    return CheckResult("Python ≥ 3.10", STATUS_OK, msg)


def check_cvc_home() -> CheckResult:
    home = _cvc_home()
    if not home.exists():
        return CheckResult(
            "~/.cvc/ directory",
            STATUS_WARN,
            f"missing: {home}",
            f"Run `cvc setup` or `mkdir -p {home}` to create it.",
        )
    if not os.access(home, os.W_OK):
        return CheckResult(
            "~/.cvc/ directory",
            STATUS_FAIL,
            f"not writable: {home}",
            f"Fix permissions: `chmod u+w {home}`.",
        )
    return CheckResult("~/.cvc/ directory", STATUS_OK, str(home))


def check_config_yaml() -> CheckResult:
    path = _cvc_home() / "config.yaml"
    if not path.exists():
        return CheckResult(
            "~/.cvc/config.yaml",
            STATUS_WARN,
            "missing",
            "Run `cvc setup` to generate a default config.",
        )
    try:
        import yaml  # type: ignore
    except Exception:  # pragma: no cover
        return CheckResult(
            "~/.cvc/config.yaml",
            STATUS_WARN,
            "PyYAML not available — cannot validate",
            "Install PyYAML: `pip install pyyaml`.",
        )
    try:
        with path.open("r", encoding="utf-8") as fh:
            yaml.safe_load(fh)
    except Exception as exc:
        return CheckResult(
            "~/.cvc/config.yaml",
            STATUS_FAIL,
            f"invalid YAML: {exc}",
            f"Open `{path}` and fix the YAML syntax, or `rm` it and re-run `cvc setup`.",
        )
    return CheckResult("~/.cvc/config.yaml", STATUS_OK, str(path))


def check_auth_json(fix: bool = False) -> CheckResult:
    path = _cvc_home() / "auth.json"
    if not path.exists():
        return CheckResult(
            "~/.cvc/auth.json",
            STATUS_WARN,
            "missing",
            "Run `cvc setup` to authenticate a provider.",
        )
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode != 0o600:
        if fix:
            try:
                os.chmod(path, 0o600)
                return CheckResult(
                    "~/.cvc/auth.json",
                    STATUS_OK,
                    f"perms auto-corrected to 0600 (was 0{mode:o})",
                )
            except Exception as exc:
                return CheckResult(
                    "~/.cvc/auth.json",
                    STATUS_FAIL,
                    f"chmod failed: {exc}",
                    f"Run manually: `chmod 600 {path}`.",
                )
        return CheckResult(
            "~/.cvc/auth.json",
            STATUS_WARN,
            f"perms 0{mode:o} (should be 0600)",
            f"Run `chmod 600 {path}` (or pass `--fix`).",
        )
    return CheckResult("~/.cvc/auth.json", STATUS_OK, "0600")


def check_primary_provider() -> CheckResult:
    """Check that the primary provider has credentials available."""
    path = _cvc_home() / "auth.json"
    if not path.exists():
        return CheckResult(
            "Primary provider auth",
            STATUS_WARN,
            "no auth.json — no credentials to validate",
            "Run `cvc setup` to authenticate a provider.",
        )
    try:
        import json
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:
        return CheckResult(
            "Primary provider auth",
            STATUS_FAIL,
            f"could not parse auth.json: {exc}",
            "Re-run `cvc setup` to regenerate credentials.",
        )

    if not isinstance(data, dict) or not data:
        return CheckResult(
            "Primary provider auth",
            STATUS_WARN,
            "auth.json has no providers configured",
            "Run `cvc setup` and choose a provider.",
        )

    # Look for *any* provider with usable credentials.
    for prov, creds in data.items():
        if not isinstance(creds, dict):
            continue
        if creds.get("api_key") or creds.get("token") or creds.get("access_token"):
            return CheckResult(
                "Primary provider auth",
                STATUS_OK,
                f"{prov}: credentials present",
            )
    return CheckResult(
        "Primary provider auth",
        STATUS_WARN,
        "no api_key / token found in auth.json",
        "Re-authenticate with `cvc setup`.",
    )


def check_provider_registry() -> CheckResult:
    try:
        from cvc.providers import list_providers  # type: ignore
    except Exception as exc:
        return CheckResult(
            "Provider registry",
            STATUS_FAIL,
            f"import failed: {exc}",
            "Verify the cvc package is installed (`pip install -e .`).",
        )
    try:
        providers = list(list_providers())
    except Exception as exc:
        return CheckResult(
            "Provider registry",
            STATUS_FAIL,
            f"list_providers() raised: {exc}",
            "Inspect `cvc/providers/__init__.py` for registration errors.",
        )
    if not providers:
        return CheckResult(
            "Provider registry",
            STATUS_FAIL,
            "registry is empty",
            "Ensure provider plugins are installed and discoverable.",
        )
    return CheckResult(
        "Provider registry",
        STATUS_OK,
        f"{len(providers)} providers loaded",
        details={"providers": providers},
    )


def check_gateway_import() -> CheckResult:
    try:
        importlib.import_module("cvc.gateway")
    except Exception as exc:
        return CheckResult(
            "Gateway core",
            STATUS_FAIL,
            f"import failed: {exc}",
            "Reinstall: `pip install -e .` from the repo root.",
        )
    return CheckResult("Gateway core", STATUS_OK, "cvc.gateway importable")


def check_plugin_system() -> CheckResult:
    try:
        plugins = importlib.import_module("cvc.plugins")
    except Exception as exc:
        return CheckResult(
            "Plugin system",
            STATUS_FAIL,
            f"import failed: {exc}",
            "Reinstall the cvc package.",
        )
    # Try to load the registry / loader if available — soft check.
    try:
        importlib.import_module("cvc.plugins.loader")
        importlib.import_module("cvc.plugins.registry")
    except Exception as exc:
        return CheckResult(
            "Plugin system",
            STATUS_WARN,
            f"loader/registry import warning: {exc}",
            "Plugins may not load — investigate import error.",
        )
    return CheckResult("Plugin system", STATUS_OK, "loader & registry OK")


def check_disk_space() -> CheckResult:
    path = _cvc_home() if _cvc_home().exists() else Path.home()
    try:
        usage = shutil.disk_usage(path)
    except Exception as exc:
        return CheckResult(
            "Disk space",
            STATUS_WARN,
            f"could not stat: {exc}",
            "",
        )
    free_gb = usage.free / (1024 ** 3)
    msg = f"{free_gb:.1f} GB free"
    if free_gb < 1.0:
        return CheckResult(
            "Disk space",
            STATUS_FAIL,
            msg,
            "Free up disk — CVC needs at least 1 GB for sessions/logs.",
        )
    if free_gb < 5.0:
        return CheckResult(
            "Disk space",
            STATUS_WARN,
            msg,
            "Consider freeing up disk space — under 5 GB free.",
        )
    return CheckResult("Disk space", STATUS_OK, msg)


def check_sqlite() -> CheckResult:
    try:
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.execute("SELECT 1")
        conn.close()
    except Exception as exc:
        return CheckResult(
            "SQLite",
            STATUS_FAIL,
            f"unavailable: {exc}",
            "Reinstall Python with sqlite3 support.",
        )
    return CheckResult("SQLite", STATUS_OK, f"sqlite3 v{sqlite3.sqlite_version}")


def _check_optional(modname: str) -> CheckResult:
    try:
        mod = importlib.import_module(modname)
        ver = getattr(mod, "__version__", "?")
        return CheckResult(f"optional: {modname}", STATUS_OK, f"v{ver}")
    except Exception:
        return CheckResult(
            f"optional: {modname}",
            STATUS_WARN,
            "not installed",
            f"Install with `pip install {modname}` if you need it.",
        )


def check_optional_deps() -> List[CheckResult]:
    return [_check_optional(m) for m in ("psutil", "telegram", "discord", "rich")]


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


def _collect_checks(fix: bool) -> List[CheckResult]:
    results: List[CheckResult] = [
        check_python_version(),
        check_cvc_home(),
        check_config_yaml(),
        check_auth_json(fix=fix),
        check_primary_provider(),
        check_provider_registry(),
        check_gateway_import(),
        check_plugin_system(),
        check_disk_space(),
        check_sqlite(),
    ]
    results.extend(check_optional_deps())
    return results


def _render_banner(console: Console) -> None:
    title = Text("CVC Doctor", style=f"bold {CVC_RED}")
    subtitle = Text("comprehensive health check", style=CVC_DIM)
    body = Text.assemble(title, "  ", subtitle)
    console.print(Panel(body, border_style=CVC_RED, box=box.ROUNDED, padding=(0, 2)))


def _render_table(console: Console, results: List[CheckResult], verbose: bool, any_fail: bool) -> None:
    table = Table(
        box=box.SIMPLE_HEAVY,
        show_header=True,
        header_style=f"bold {CVC_RED}",
        expand=True,
        pad_edge=False,
    )
    table.add_column("", width=2, no_wrap=True)
    table.add_column("Check", style="bold", no_wrap=True)
    table.add_column("Status", no_wrap=True)
    table.add_column("Detail", overflow="fold")

    for r in results:
        glyph, color = _STATUS_GLYPH.get(r.status, ("?", CVC_DIM))
        status_text = Text(r.status.upper(), style=f"bold {color}")
        detail = r.message
        # Show fix_hints inline if verbose, or if we have any failures (not just warnings).
        if r.fix_hint and (verbose or (any_fail and r.status == STATUS_FAIL)):
            detail = f"{detail}\n[dim]→ {r.fix_hint}[/dim]" if detail else f"[dim]→ {r.fix_hint}[/dim]"
        table.add_row(Text(glyph, style=color), r.name, status_text, detail)

    console.print(table)


def _render_summary(console: Console, results: List[CheckResult]) -> None:
    passed = sum(1 for r in results if r.status == STATUS_OK)
    warns = sum(1 for r in results if r.status == STATUS_WARN)
    fails = sum(1 for r in results if r.status == STATUS_FAIL)

    summary = Text.assemble(
        (f"{passed} passed", f"bold {CVC_GREEN}"),
        ", ",
        (f"{warns} warnings", f"bold {CVC_YELLOW}"),
        ", ",
        (f"{fails} failures", f"bold {CVC_RED}"),
    )
    if fails:
        verdict = Text("UNHEALTHY", style=f"bold {CVC_RED}")
    elif warns:
        verdict = Text("DEGRADED", style=f"bold {CVC_YELLOW}")
    else:
        verdict = Text("HEALTHY", style=f"bold {CVC_GREEN}")

    console.print()
    console.print(Panel.fit(
        Text.assemble(verdict, "  ", summary),
        border_style=CVC_RED,
        box=box.ROUNDED,
        padding=(0, 2),
    ))


def run_doctor(verbose: bool = False, fix: bool = False) -> int:
    """Run all checks and render the report.

    Returns:
        ``0`` if all checks pass, ``1`` if any warnings (but no failures),
        ``2`` if any failures.
    """
    console = Console()
    _render_banner(console)
    results = _collect_checks(fix=fix)

    any_fail = any(r.status == STATUS_FAIL for r in results)
    any_warn = any(r.status == STATUS_WARN for r in results)

    _render_table(console, results, verbose=verbose, any_fail=any_fail)
    _render_summary(console, results)

    if any_fail:
        return 2
    if any_warn:
        return 1
    return 0


# Convenience for ``python -m cvc.cli.doctor``.
if __name__ == "__main__":  # pragma: no cover
    sys.exit(run_doctor(verbose="-v" in sys.argv, fix="--fix" in sys.argv))
