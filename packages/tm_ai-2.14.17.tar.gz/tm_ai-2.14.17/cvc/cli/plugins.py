"""cvc plugins — list / enable / disable CVC plugins.

State is persisted to ``~/.cvc/plugins.json`` (a tiny dict mapping
plugin name → enabled bool). The actual discovery scans
``~/.cvc/plugins/`` for first-party plugins.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

import click
from rich.console import Console
from rich.table import Table

from cvc.cli._legacy import main

console = Console()

STATE_FILE = Path.home() / ".cvc" / "plugins.json"
PLUGINS_DIR = Path.home() / ".cvc" / "plugins"


def _load_state() -> Dict[str, bool]:
    if not STATE_FILE.exists():
        return {}
    try:
        return dict(json.loads(STATE_FILE.read_text()))
    except Exception:
        return {}


def _save_state(state: Dict[str, bool]) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2, sort_keys=True))


def list_plugins() -> List[Dict[str, object]]:
    state = _load_state()
    discovered: set[str] = set(state)
    if PLUGINS_DIR.exists():
        for child in PLUGINS_DIR.iterdir():
            if child.is_dir():
                discovered.add(child.name)
    return [{"name": n, "enabled": bool(state.get(n, False))} for n in sorted(discovered)]


def enable_plugin(name: str) -> Dict[str, bool]:
    state = _load_state()
    state[name] = True
    _save_state(state)
    return state


def disable_plugin(name: str) -> Dict[str, bool]:
    state = _load_state()
    state[name] = False
    _save_state(state)
    return state


@main.group("plugins")
def plugins_grp() -> None:
    """List or toggle CVC plugins."""


@plugins_grp.command("list")
def _list() -> None:  # pragma: no cover
    rows = list_plugins()
    if not rows:
        console.print("[dim]No plugins discovered.[/dim]")
        return
    t = Table(title="CVC Plugins")
    t.add_column("Name")
    t.add_column("Enabled")
    for r in rows:
        t.add_row(str(r["name"]), "yes" if r["enabled"] else "no")
    console.print(t)


@plugins_grp.command("enable")
@click.argument("name")
def _enable(name: str) -> None:  # pragma: no cover
    enable_plugin(name)
    console.print(f"[bold green]✓ enabled[/bold green] {name}")


@plugins_grp.command("disable")
@click.argument("name")
def _disable(name: str) -> None:  # pragma: no cover
    disable_plugin(name)
    console.print(f"[bold yellow]✗ disabled[/bold yellow] {name}")


__all__ = ["list_plugins", "enable_plugin", "disable_plugin", "plugins_grp"]
