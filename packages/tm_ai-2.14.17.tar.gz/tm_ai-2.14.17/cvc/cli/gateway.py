"""cvc gateway — manage the FastAPI gateway daemon on :13421.

Subcommands: start | stop | status. Uses a PID file at
``~/.cvc/gateway.pid`` and shells out to the existing
``cvc.gateway`` entry point if available.
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from cvc.cli._legacy import main

console = Console()

GATEWAY_PORT = 13421
PID_FILE = Path.home() / ".cvc" / "gateway.pid"


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False
    except Exception:
        return False


def _read_pid() -> Optional[int]:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except Exception:
        return None


def gateway_status() -> dict:
    pid = _read_pid()
    alive = bool(pid and _pid_alive(pid))
    return {"pid": pid, "alive": alive, "port": GATEWAY_PORT, "pid_file": str(PID_FILE)}


def gateway_start() -> dict:
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    existing = _read_pid()
    if existing and _pid_alive(existing):
        return {"started": False, "pid": existing, "reason": "already-running"}

    cmd = [sys.executable, "-m", "cvc.gateway", "--port", str(GATEWAY_PORT)]
    try:
        proc = subprocess.Popen(  # noqa: S603
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as exc:
        return {"started": False, "error": str(exc)}
    PID_FILE.write_text(str(proc.pid))
    time.sleep(0.1)
    return {"started": True, "pid": proc.pid, "port": GATEWAY_PORT}


def gateway_stop() -> dict:
    pid = _read_pid()
    if not pid:
        return {"stopped": False, "reason": "no-pid-file"}
    if not _pid_alive(pid):
        try:
            PID_FILE.unlink()
        except Exception:
            pass
        return {"stopped": False, "reason": "not-running"}
    try:
        os.kill(pid, signal.SIGTERM)
    except Exception as exc:
        return {"stopped": False, "error": str(exc)}
    try:
        PID_FILE.unlink()
    except Exception:
        pass
    return {"stopped": True, "pid": pid}


@main.group("gateway")
def gateway_grp() -> None:
    """Manage the CVC FastAPI gateway."""


@gateway_grp.command("start")
def _start() -> None:  # pragma: no cover
    res = gateway_start()
    console.print(res)


@gateway_grp.command("stop")
def _stop() -> None:  # pragma: no cover
    res = gateway_stop()
    console.print(res)


@gateway_grp.command("status")
def _status() -> None:  # pragma: no cover
    res = gateway_status()
    console.print(res)


__all__ = ["gateway_status", "gateway_start", "gateway_stop", "gateway_grp", "GATEWAY_PORT"]
