"""cvc uninstall — confirm, then uv tool uninstall tm-ai.

Optionally removes ~/.cvc as well (with --purge).

Overrides the legacy stub so the canonical Hermes-parity behaviour wins.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from cvc.cli._legacy import main

console = Console()


def run_uninstall(*, purge: bool = False, assume_yes: bool = False, home: Optional[Path] = None) -> int:
    home = home or (Path.home() / ".cvc")

    if not assume_yes:
        if not click.confirm("Uninstall CVC (tm-ai)?", default=False):
            console.print("[dim]Aborted.[/dim]")
            return 130

    rc = 0
    if shutil.which("uv"):
        cmd = ["uv", "tool", "uninstall", "tm-ai"]
        console.print(f"[dim]$ {' '.join(cmd)}[/dim]")
        rc = subprocess.run(cmd, check=False).returncode
    else:
        console.print(
            "[bold yellow]uv not found[/bold yellow] — please run "
            "`pip uninstall tm-ai` manually.")
        rc = 127

    if purge and home.exists():
        shutil.rmtree(home, ignore_errors=True)
        console.print(f"[bold green]✓ Removed[/bold green] {home}")

    if rc == 0:
        console.print("[bold green]✓ CVC uninstalled.[/bold green]")
    return rc


@main.command("uninstall")
@click.option("--purge", is_flag=True, default=False, help="Also remove ~/.cvc.")
@click.option("--yes", "assume_yes", is_flag=True, default=False, help="Skip confirmation.")
def uninstall_cmd(purge: bool, assume_yes: bool) -> None:  # pragma: no cover
    """Uninstall CVC (tm-ai)."""
    raise SystemExit(run_uninstall(purge=purge, assume_yes=assume_yes))


__all__ = ["run_uninstall", "uninstall_cmd"]
