"""Unified auth flow for CVC providers.

Actions:
    login   — provider-specific authentication (Copilot device code,
              others API key prompt). Returns dict with status.
    status  — print + return per-provider authentication status.
    logout  — delete credentials for given provider (with confirm).
    list    — return dict of {provider: bool} authentication status.

Credentials are persisted to:
    ~/.cvc/auth.json            (API keys, chmod 600)
    ~/.cvc/copilot_token.json   (Copilot OAuth token)
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Prompt, Confirm
    _HAS_RICH = True
except Exception:  # pragma: no cover
    _HAS_RICH = False
    Console = None  # type: ignore

KNOWN_PROVIDERS: list[str] = [
    "copilot",
    "anthropic",
    "gemini",
    "nvidia",
    "openrouter",
    "deepseek",
    "xai",
]

ENV_KEYS: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "nvidia": "NVIDIA_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "xai": "XAI_API_KEY",
}

_ACCENT = "#e63946"


def _cvc_home() -> Path:
    home = Path(os.path.expanduser("~")) / ".cvc"
    home.mkdir(parents=True, exist_ok=True)
    return home


def _auth_path() -> Path:
    return _cvc_home() / "auth.json"


def _copilot_token_path() -> Path:
    return _cvc_home() / "copilot_token.json"


def _load_auth() -> dict[str, Any]:
    p = _auth_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text() or "{}")
    except Exception:
        return {}


def _save_auth(data: dict[str, Any]) -> None:
    p = _auth_path()
    p.write_text(json.dumps(data, indent=2))
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass


def _console() -> Any:
    if _HAS_RICH:
        return Console()
    return None


def _is_authenticated(provider: str) -> bool:
    if provider == "copilot":
        if _copilot_token_path().exists():
            try:
                blob = json.loads(_copilot_token_path().read_text() or "{}")
                return bool(blob.get("github_token") or blob.get("token"))
            except Exception:
                return False
        return False
    auth = _load_auth()
    entry = auth.get(provider) or {}
    if isinstance(entry, dict) and entry.get("api_key"):
        return True
    return False


def _interactive() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


# --------------------------------------------------------------------------- #
# Action handlers
# --------------------------------------------------------------------------- #

def _action_status(provider: str | None = None) -> dict[str, bool]:
    """Return {provider: authenticated_bool} for one or all providers."""
    targets = [provider] if provider and provider != "all" else KNOWN_PROVIDERS
    result = {p: _is_authenticated(p) for p in targets}

    console = _console()
    if console is not None:
        table = Table(title="CVC — Provider Auth Status",
                      header_style=f"bold {_ACCENT}", border_style=_ACCENT)
        table.add_column("Provider", style="bold")
        table.add_column("Status")
        table.add_column("Credential Path")
        for prov, ok in result.items():
            path = (_copilot_token_path() if prov == "copilot" else _auth_path())
            badge = "[green]✓ authenticated[/green]" if ok else "[dim]— not set[/dim]"
            table.add_row(prov, badge, str(path))
        console.print(table)
    else:
        for prov, ok in result.items():
            print(f"{prov}: {'authenticated' if ok else 'not set'}")
    return result


def _action_list() -> dict[str, bool]:
    return {p: _is_authenticated(p) for p in KNOWN_PROVIDERS}


def _action_logout(provider: str, *, assume_yes: bool = False) -> dict[str, Any]:
    if provider not in KNOWN_PROVIDERS:
        return {"ok": False, "error": f"unknown provider: {provider}"}

    if not assume_yes and _interactive():
        if _HAS_RICH:
            confirmed = Confirm.ask(
                f"Remove credentials for [bold {_ACCENT}]{provider}[/bold {_ACCENT}]?",
                default=False,
            )
        else:
            confirmed = input(f"Remove credentials for {provider}? [y/N]: ").strip().lower() == "y"
        if not confirmed:
            return {"ok": False, "cancelled": True}

    if provider == "copilot":
        p = _copilot_token_path()
        if p.exists():
            p.unlink()
        return {"ok": True, "provider": provider}

    auth = _load_auth()
    if provider in auth:
        del auth[provider]
        _save_auth(auth)
    return {"ok": True, "provider": provider}


def _action_login(provider: str, *, api_key: str | None = None) -> dict[str, Any]:
    if provider not in KNOWN_PROVIDERS:
        return {"ok": False, "error": f"unknown provider: {provider}"}

    console = _console()

    if provider == "copilot":
        # Real device-code OAuth flow.
        try:
            from cvc.providers.copilot.auth import copilot_device_code_login
        except Exception as exc:
            return {"ok": False, "error": f"copilot auth module unavailable: {exc}"}
        token = copilot_device_code_login(persist=True)
        if not token:
            return {"ok": False, "error": "device code login failed"}
        return {"ok": True, "provider": "copilot"}

    # API-key providers
    if api_key is None:
        env_key = ENV_KEYS.get(provider)
        if env_key and os.environ.get(env_key):
            api_key = os.environ[env_key]
        elif _interactive():
            if _HAS_RICH:
                api_key = Prompt.ask(
                    f"Enter [bold {_ACCENT}]{provider}[/bold {_ACCENT}] API key",
                    password=True,
                )
            else:
                import getpass
                api_key = getpass.getpass(f"{provider} API key: ")
        else:
            msg = (
                f"Non-interactive shell — cannot prompt for {provider} API key.\n"
                f"Set ${env_key or provider.upper() + '_API_KEY'} or run interactively."
            )
            if console is not None:
                console.print(Panel(msg, title="Auth", border_style=_ACCENT))
            else:
                print(msg)
            return {"ok": False, "error": "non-interactive"}

    if not api_key:
        return {"ok": False, "error": "empty api key"}

    auth = _load_auth()
    auth[provider] = {"api_key": api_key}
    _save_auth(auth)
    if console is not None:
        console.print(
            f"[green]✓[/green] Saved [bold]{provider}[/bold] API key → {_auth_path()}"
        )
    return {"ok": True, "provider": provider}


# --------------------------------------------------------------------------- #
# Public dispatch
# --------------------------------------------------------------------------- #

def run_auth(
    provider: str,
    action: str = "login",
    *,
    api_key: str | None = None,
    assume_yes: bool = False,
) -> dict[str, Any]:
    """Dispatch an auth action.

    Args:
        provider: one of KNOWN_PROVIDERS, or any string for 'list'.
        action: 'login' | 'status' | 'logout' | 'list'.
        api_key: optional pre-supplied API key (skips interactive prompt).
        assume_yes: skip confirmations (used by tests).

    Returns:
        Dict with action-specific shape.
    """
    action = (action or "login").lower().strip()

    if action == "list":
        result = _action_list()
        console = _console()
        if console is not None:
            table = Table(title="CVC — Known Providers",
                          header_style=f"bold {_ACCENT}", border_style=_ACCENT)
            table.add_column("Provider", style="bold")
            table.add_column("Authenticated")
            for prov, ok in result.items():
                table.add_row(prov, "[green]yes[/green]" if ok else "[dim]no[/dim]")
            console.print(table)
        return result

    if action == "status":
        return _action_status(provider if provider in KNOWN_PROVIDERS else None)

    if action == "logout":
        return _action_logout(provider, assume_yes=assume_yes)

    if action == "login":
        return _action_login(provider, api_key=api_key)

    return {"ok": False, "error": f"unknown action: {action}"}
