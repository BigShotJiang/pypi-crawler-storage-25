"""cvc memory_setup — Rich-themed wizard for memory store configuration.

Persists to ``~/.cvc/memory.json`` with shape::

    {"backend": "sqlite|chroma|honcho", "path": "~/.cvc/memory.db", "namespace": "default"}
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from cvc.cli._legacy import main

console = Console()

MEMORY_FILE = Path.home() / ".cvc" / "memory.json"
DEFAULTS: Dict[str, Any] = {
    "backend": "sqlite",
    "path": "~/.cvc/memory.db",
    "namespace": "default",
}
BACKENDS = ("sqlite", "chroma", "honcho")


def load_memory_config() -> Dict[str, Any]:
    if not MEMORY_FILE.exists():
        return dict(DEFAULTS)
    try:
        return dict(json.loads(MEMORY_FILE.read_text()))
    except Exception:
        return dict(DEFAULTS)


def save_memory_config(cfg: Dict[str, Any]) -> Path:
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    MEMORY_FILE.write_text(json.dumps(cfg, indent=2, sort_keys=True))
    return MEMORY_FILE


def run_memory_setup(
    *,
    backend: Optional[str] = None,
    path: Optional[str] = None,
    namespace: Optional[str] = None,
    interactive: bool = True,
) -> Dict[str, Any]:
    cfg = load_memory_config()
    if backend or path or namespace or not interactive:
        if backend:
            cfg["backend"] = backend
        if path:
            cfg["path"] = path
        if namespace:
            cfg["namespace"] = namespace
        save_memory_config(cfg)
        return cfg

    console.print(Panel.fit(
        "[bold]Memory store setup[/bold]\nConfigure where CVC keeps long-term memory.",
        border_style="cyan"))
    cfg["backend"] = Prompt.ask("Backend", choices=list(BACKENDS), default=cfg.get("backend", "sqlite"))
    cfg["path"] = Prompt.ask("Path", default=str(cfg.get("path", DEFAULTS["path"])))
    cfg["namespace"] = Prompt.ask("Namespace", default=str(cfg.get("namespace", "default")))
    save_memory_config(cfg)
    console.print(f"[bold green]✓ Saved[/bold green] {MEMORY_FILE}")
    return cfg


@main.command("memory_setup")
@click.option("--backend", type=click.Choice(BACKENDS), default=None)
@click.option("--path", default=None)
@click.option("--namespace", default=None)
@click.option("--non-interactive", is_flag=True, default=False)
def memory_setup_cmd(backend: Optional[str], path: Optional[str], namespace: Optional[str], non_interactive: bool) -> None:  # pragma: no cover
    """Configure the CVC long-term memory store."""
    run_memory_setup(
        backend=backend,
        path=path,
        namespace=namespace,
        interactive=not non_interactive and not any([backend, path, namespace]),
    )


__all__ = ["run_memory_setup", "load_memory_config", "save_memory_config", "memory_setup_cmd", "BACKENDS"]
