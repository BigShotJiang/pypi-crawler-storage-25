"""cvc backup — tar.gz of ~/.cvc/{sessions,skills,memory,history}.

Supports `--restore PATH` to extract a previously created archive back into
``~/.cvc``. Emits a single .tar.gz with a timestamped filename in CWD.
"""
from __future__ import annotations

import datetime as _dt
import tarfile
from pathlib import Path
from typing import Iterable, Optional

import click
from rich.console import Console

from cvc.cli._legacy import main

console = Console()

DEFAULT_SUBDIRS: tuple[str, ...] = ("sessions", "skills", "memory", "history")


def _cvc_home() -> Path:
    return Path.home() / ".cvc"


def run_backup(
    out_dir: Optional[Path] = None,
    subdirs: Iterable[str] = DEFAULT_SUBDIRS,
    *,
    home: Optional[Path] = None,
) -> Path:
    """Create a tar.gz backup. Returns the archive path."""
    home = home or _cvc_home()
    out_dir = Path(out_dir) if out_dir else Path.cwd()
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    archive = out_dir / f"cvc-backup-{stamp}.tar.gz"

    with tarfile.open(archive, "w:gz") as tf:
        for sd in subdirs:
            p = home / sd
            if p.exists():
                tf.add(p, arcname=sd)
    return archive


def run_restore(archive: Path, *, home: Optional[Path] = None) -> Path:
    home = home or _cvc_home()
    home.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:gz") as tf:
        tf.extractall(home)
    return home


@main.command("backup")
@click.option("--restore", "restore_path", default=None, type=click.Path(exists=True, dir_okay=False),
              help="Restore a previous backup archive into ~/.cvc.")
@click.option("--out", "out_dir", default=None, type=click.Path(file_okay=False),
              help="Output directory for the archive (default: cwd).")
def backup_cmd(restore_path: Optional[str], out_dir: Optional[str]) -> None:  # pragma: no cover
    """Backup or restore the CVC user data directory."""
    if restore_path:
        home = run_restore(Path(restore_path))
        console.print(f"[bold green]✓ Restored to[/bold green] {home}")
        return
    archive = run_backup(Path(out_dir) if out_dir else None)
    console.print(f"[bold green]✓ Backup created:[/bold green] {archive}")


__all__ = ["run_backup", "run_restore", "backup_cmd"]
