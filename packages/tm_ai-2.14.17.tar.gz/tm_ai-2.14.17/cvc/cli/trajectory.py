"""cvc.cli.trajectory — Session replay & inspection.

Renders trajectories recorded as JSONL at
``~/.cvc/sessions/<id>/trajectory.jsonl``.

One event per line, with the loose schema::

    {"ts": ..., "event_type": ..., "role": ..., "content": ...,
     "tool": ..., "args": ..., "result": ...}

Actions: ``list``, ``show <id>``, ``last``, ``stats``.
Returns an exit code: 0 ok, 2 user / not-found error.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from rich.console import Console
from rich.table import Table
from rich.tree import Tree

CVC_RED = "#e63946"


def _sessions_dir() -> Path:
    base = os.environ.get("CVC_HOME") or os.path.expanduser("~/.cvc")
    return Path(base) / "sessions"


def _iter_session_dirs() -> List[Path]:
    root = _sessions_dir()
    if not root.is_dir():
        return []
    out = [p for p in root.iterdir() if p.is_dir() and (p / "trajectory.jsonl").exists()]
    out.sort(key=lambda p: (p / "trajectory.jsonl").stat().st_mtime, reverse=True)
    return out


def _load_events(path: Path) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except Exception:
                    continue
    except OSError:
        pass
    return events


def _fmt_ts(ts: Any) -> str:
    if ts is None:
        return "-"
    try:
        if isinstance(ts, (int, float)):
            return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        s = str(ts)
        return s[:19]
    except Exception:
        return str(ts)[:19]


def _summary(session_dir: Path) -> Dict[str, Any]:
    events = _load_events(session_dir / "trajectory.jsonl")
    started = events[0].get("ts") if events else None
    ended = events[-1].get("ts") if events else None
    duration = "-"
    try:
        if isinstance(started, (int, float)) and isinstance(ended, (int, float)):
            duration = f"{float(ended) - float(started):.1f}s"
    except Exception:
        pass
    tool_calls = sum(1 for e in events if e.get("event_type") == "tool_call" or e.get("tool"))
    return {
        "id": session_dir.name,
        "started": _fmt_ts(started) if started else "-",
        "duration": duration,
        "events": len(events),
        "tool_calls": tool_calls,
    }


def _resolve_session(session_id: str) -> Optional[Path]:
    root = _sessions_dir()
    if not root.is_dir():
        return None
    direct = root / session_id
    if direct.is_dir() and (direct / "trajectory.jsonl").exists():
        return direct
    # prefix match
    matches = [p for p in _iter_session_dirs() if p.name.startswith(session_id)]
    if len(matches) == 1:
        return matches[0]
    return None


def _action_list(console: Console) -> int:
    sessions = _iter_session_dirs()
    table = Table(title="CVC Sessions", border_style=CVC_RED, show_lines=False)
    table.add_column("id", style="bold")
    table.add_column("started")
    table.add_column("duration", justify="right")
    table.add_column("events", justify="right")
    table.add_column("tool_calls", justify="right")
    if not sessions:
        console.print(table)
        console.print("[dim]No sessions recorded yet.[/dim]")
        return 0
    for s in sessions:
        info = _summary(s)
        table.add_row(
            info["id"][:8],
            info["started"],
            info["duration"],
            str(info["events"]),
            str(info["tool_calls"]),
        )
    console.print(table)
    return 0


def _action_show(console: Console, session_id: Optional[str]) -> int:
    if not session_id:
        console.print("[red]error:[/red] show requires a session id")
        return 2
    sd = _resolve_session(session_id)
    if sd is None:
        console.print(f"[red]error:[/red] session not found: {session_id}")
        return 2
    events = _load_events(sd / "trajectory.jsonl")
    tree = Tree(f"[bold {CVC_RED}]Session {sd.name[:8]}[/]  ({len(events)} events)")
    for ev in events:
        ts = _fmt_ts(ev.get("ts"))
        et = ev.get("event_type") or ("tool" if ev.get("tool") else "event")
        role = ev.get("role") or ""
        label = f"[dim]{ts}[/dim]  [bold]{et}[/]" + (f"  [{role}]" if role else "")
        node = tree.add(label)
        tool = ev.get("tool")
        if tool:
            node.add(f"[cyan]tool:[/cyan] {tool}  args={ev.get('args')}")
            res = ev.get("result")
            if res is not None:
                rs = str(res)
                node.add(f"[green]result:[/green] {rs[:160]}")
        content = ev.get("content")
        if content:
            cs = str(content)
            node.add(cs[:200] + ("…" if len(cs) > 200 else ""))
    console.print(tree)
    return 0


def _action_last(console: Console) -> int:
    sessions = _iter_session_dirs()
    if not sessions:
        console.print("[dim]No sessions recorded yet.[/dim]")
        return 0
    return _action_show(console, sessions[0].name)


def _action_stats(console: Console) -> int:
    sessions = _iter_session_dirs()
    total_events = 0
    total_tools = 0
    for s in sessions:
        info = _summary(s)
        total_events += info["events"]
        total_tools += info["tool_calls"]
    table = Table(title="CVC Trajectory Stats", border_style=CVC_RED)
    table.add_column("metric", style="bold")
    table.add_column("value", justify="right")
    table.add_row("sessions", str(len(sessions)))
    table.add_row("total events", str(total_events))
    table.add_row("total tool calls", str(total_tools))
    console.print(table)
    return 0


def run_trajectory(action: str = "list", session_id: str | None = None, **kwargs) -> int:
    """Entry point for ``cvc trajectory``."""
    console: Console = kwargs.get("console") or Console()
    action = (action or "list").strip()

    # Allow "show <id>" to be passed as a single string in `action`.
    parts = action.split(maxsplit=1)
    if len(parts) == 2 and parts[0] in {"show"}:
        action, session_id = parts[0], parts[1]

    if action == "list":
        return _action_list(console)
    if action == "show":
        return _action_show(console, session_id)
    if action == "last":
        return _action_last(console)
    if action == "stats":
        return _action_stats(console)

    console.print(f"[red]error:[/red] unknown action: {action}")
    console.print("[dim]actions: list | show <id> | last | stats[/dim]")
    return 2


__all__ = ["run_trajectory"]
