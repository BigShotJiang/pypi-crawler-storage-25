"""CVC first-run setup wizard — beautiful, fast, opinionated.

`run_setup(quick=False)` walks the user through 5 steps:
    1. Pick primary provider
    2. Authenticate (Copilot device code, others API key)
    3. Pick default model
    4. Optional Telegram bot setup
    5. Write ~/.cvc/config.yaml + summary

quick=True skips step 4.

Visual design uses `rich` with a red (#e63946) accent, soft borders, and
clear stepper headers. Designed to feel cleaner than Hermes setup.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

try:
    from rich.align import Align
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Confirm, Prompt
    from rich.table import Table
    from rich.text import Text
    _HAS_RICH = True
except Exception:  # pragma: no cover
    _HAS_RICH = False

try:
    import yaml as _yaml
    _HAS_YAML = True
except Exception:  # pragma: no cover
    _HAS_YAML = False

from .auth import (
    KNOWN_PROVIDERS,
    _action_login,
    _cvc_home,
    _is_authenticated,
)

ACCENT = "#e63946"
DIM = "grey50"


def _console() -> Any:
    if _HAS_RICH:
        return Console()
    return None


def _interactive() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


# --------------------------------------------------------------------------- #
# UI primitives
# --------------------------------------------------------------------------- #

def _banner(console) -> None:
    if console is None:
        print("=== CVC — Cognitive Version Control ===")
        print("The most advanced agentic AI workstation\n")
        return

    title = Text()
    title.append("⚡ ", style=f"bold {ACCENT}")
    title.append("Welcome to CVC", style=f"bold {ACCENT}")
    title.append("  —  ", style=DIM)
    title.append("Cognitive Version Control", style="bold white")

    subtitle = Text(
        "The most advanced agentic AI workstation",
        style=f"italic {DIM}",
    )

    body = Align.center(Text.assemble(title, "\n", subtitle))
    console.print()
    console.print(Panel(body, border_style=ACCENT, padding=(1, 4)))
    console.print()


def _step(console, n: int, total: int, label: str) -> None:
    if console is None:
        print(f"\n--- Step {n}/{total}: {label} ---")
        return
    header = Text()
    header.append(f"Step {n}/{total}", style=f"bold {ACCENT}")
    header.append("  ·  ", style=DIM)
    header.append(label, style="bold white")
    console.print(header)
    console.rule(style=ACCENT)


# --------------------------------------------------------------------------- #
# Provider catalog helpers
# --------------------------------------------------------------------------- #

def _models_for(provider: str) -> list[str]:
    """Return a list of suggested model IDs for `provider`. Best-effort."""
    if provider == "copilot":
        try:
            from cvc.providers.copilot.models import list_copilot_models
            cat = list_copilot_models() or []
            ids = [m.get("id") for m in cat if m.get("id")]
            if ids:
                return ids[:12]
        except Exception:
            pass
        return ["claude-sonnet-4.6", "claude-opus-4.7", "gpt-5", "gemini-2.5-pro"]

    fallback = {
        "anthropic": ["claude-sonnet-4-5", "claude-opus-4-5", "claude-haiku-4-5"],
        "gemini": ["gemini-2.5-pro", "gemini-2.5-flash"],
        "nvidia": ["meta/llama-3.1-405b-instruct", "nvidia/llama-3.1-nemotron-70b"],
        "openrouter": ["anthropic/claude-sonnet-4.5", "openai/gpt-5", "x-ai/grok-4"],
        "deepseek": ["deepseek-chat", "deepseek-reasoner"],
        "xai": ["grok-4", "grok-4-fast"],
    }
    return fallback.get(provider, ["default"])


# --------------------------------------------------------------------------- #
# Config writing
# --------------------------------------------------------------------------- #

def _write_config(cfg: dict[str, Any]) -> Path:
    home = _cvc_home()
    path = home / "config.yaml"
    if _HAS_YAML:
        path.write_text(_yaml.safe_dump(cfg, sort_keys=False))
    else:
        # Fallback: minimal YAML-ish (still parseable as YAML by PyYAML).
        lines = []
        for k, v in cfg.items():
            if isinstance(v, dict):
                lines.append(f"{k}:")
                for ik, iv in v.items():
                    lines.append(f"  {ik}: {iv}")
            else:
                lines.append(f"{k}: {v}")
        path.write_text("\n".join(lines) + "\n")
    return path


# --------------------------------------------------------------------------- #
# Main wizard
# --------------------------------------------------------------------------- #

def run_setup(quick: bool = False) -> dict[str, Any]:
    """Run the CVC first-run setup wizard.

    Returns a dict describing the resulting configuration.
    """
    console = _console()

    if not _interactive() and console is not None and not os.environ.get("CVC_SETUP_NONINTERACTIVE_OK"):
        msg = (
            "CVC setup needs an interactive terminal.\n\n"
            "Run:  [bold]cvc setup[/bold]    in your terminal,\n"
            "or pre-seed [bold]~/.cvc/config.yaml[/bold] manually."
        )
        console.print(Panel(msg, title="Setup", border_style=ACCENT))
        return {"ok": False, "reason": "non-interactive"}
    if not _interactive() and console is None and not os.environ.get("CVC_SETUP_NONINTERACTIVE_OK"):
        print("CVC setup needs an interactive terminal. Aborting.")
        return {"ok": False, "reason": "non-interactive"}

    _banner(console)

    total = 4 if quick else 5

    # ---- Step 1: provider ------------------------------------------------- #
    _step(console, 1, total, "Pick your primary AI provider")
    if console is not None:
        table = Table(show_header=False, box=None, padding=(0, 2))
        for p in KNOWN_PROVIDERS:
            table.add_row(f"[bold {ACCENT}]•[/bold {ACCENT}]", p)
        console.print(table)
        provider = Prompt.ask(
            "Provider",
            choices=KNOWN_PROVIDERS,
            default="copilot",
            show_choices=False,
        )
    else:
        print("Providers:", ", ".join(KNOWN_PROVIDERS))
        provider = input("Provider [copilot]: ").strip() or "copilot"
    if console is not None:
        console.print(f"  [green]✓[/green] {provider}\n")

    # ---- Step 2: auth ----------------------------------------------------- #
    _step(console, 2, total, "Authenticate")
    auth_result = _action_login(provider)
    if not auth_result.get("ok"):
        if console is not None:
            console.print(f"[yellow]⚠[/yellow] auth not completed: {auth_result.get('error')}")
        else:
            print(f"WARN: auth not completed: {auth_result.get('error')}")

    # ---- Step 3: model ---------------------------------------------------- #
    _step(console, 3, total, "Pick default model")
    models = _models_for(provider)
    if console is not None:
        for m in models:
            console.print(f"  [{ACCENT}]·[/{ACCENT}] {m}")
        default_model = Prompt.ask("Model", default=models[0])
    else:
        print("Models:", ", ".join(models))
        default_model = input(f"Model [{models[0]}]: ").strip() or models[0]
    if console is not None:
        console.print(f"  [green]✓[/green] {default_model}\n")

    # ---- Step 4: telegram (skipped in quick mode) ------------------------- #
    telegram: dict[str, Any] = {"enabled": False}
    if not quick:
        _step(console, 4, total, "Optional — Telegram bot")
        if console is not None:
            want = Confirm.ask("Set up Telegram bot now?", default=False)
        else:
            want = input("Set up Telegram bot now? [y/N]: ").strip().lower() == "y"
        if want:
            if console is not None:
                token = Prompt.ask("Bot token (from @BotFather)", password=True)
                chat_id = Prompt.ask("Your Telegram chat_id (optional)", default="")
            else:
                import getpass
                token = getpass.getpass("Bot token: ")
                chat_id = input("chat_id (optional): ").strip()
            if token:
                telegram = {"enabled": True, "bot_token": token, "chat_id": chat_id or None}
                if console is not None:
                    console.print("  [green]✓[/green] Telegram configured\n")
        else:
            if console is not None:
                console.print(f"  [{DIM}]skipped[/{DIM}]\n")

    # ---- Step 5: write config + summary ----------------------------------- #
    final_step = 5 if not quick else 4
    _step(console, final_step, total, "Write config and finish")

    cfg: dict[str, Any] = {
        "primary_provider": provider,
        "default_model": default_model,
        "telegram": telegram,
        "version": 1,
    }
    cfg_path = _write_config(cfg)

    if console is not None:
        summary = Table(title="CVC — Configuration",
                        header_style=f"bold {ACCENT}", border_style=ACCENT)
        summary.add_column("Setting", style="bold")
        summary.add_column("Value")
        summary.add_row("Primary provider", provider)
        summary.add_row("Default model", default_model)
        summary.add_row("Authenticated", "✓" if _is_authenticated(provider) else "✗")
        summary.add_row("Telegram", "enabled" if telegram.get("enabled") else "disabled")
        summary.add_row("Config file", str(cfg_path))
        console.print()
        console.print(summary)

        next_steps = Text()
        next_steps.append("Next: ", style=f"bold {ACCENT}")
        next_steps.append("Run ", style="white")
        next_steps.append("`cvc agent`", style=f"bold {ACCENT}")
        next_steps.append(" to start your AI workstation.", style="white")
        console.print()
        console.print(Panel(next_steps, border_style=ACCENT, padding=(0, 2)))
    else:
        print(f"\nConfig written → {cfg_path}")
        print("Next: Run `cvc agent` to start.\n")

    return {
        "ok": True,
        "config_path": str(cfg_path),
        "primary_provider": provider,
        "default_model": default_model,
        "telegram_enabled": bool(telegram.get("enabled")),
    }
