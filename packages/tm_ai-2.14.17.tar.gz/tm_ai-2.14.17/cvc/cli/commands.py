"""cvc commands — list every CVC command (terminal subcommands + slash
commands) so users can discover what's available without `--help` archaeology.
"""
from __future__ import annotations

from typing import Dict, List

import click
from rich.console import Console
from rich.table import Table

from cvc.cli._legacy import main

console = Console()


SLASH_COMMANDS: List[Dict[str, str]] = [
    {"name": "/help", "summary": "Show in-TUI help."},
    {"name": "/clear", "summary": "Clear the current TUI conversation."},
    {"name": "/model", "summary": "Switch model mid-session."},
    {"name": "/provider", "summary": "Switch provider mid-session."},
    {"name": "/skills", "summary": "List & toggle skills."},
    {"name": "/tools", "summary": "List enabled tools."},
    {"name": "/exit", "summary": "Exit the TUI."},
]


def list_terminal_commands() -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    for name, cmd in sorted(main.commands.items()):
        rows.append({"name": name, "summary": (cmd.help or "").splitlines()[0] if cmd.help else ""})
    return rows


def list_slash_commands() -> List[Dict[str, str]]:
    return list(SLASH_COMMANDS)


def list_all_commands() -> Dict[str, List[Dict[str, str]]]:
    return {
        "terminal": list_terminal_commands(),
        "slash": list_slash_commands(),
    }


@main.command("commands")
def commands_cmd() -> None:  # pragma: no cover
    """List every CVC command (terminal subcommands + slash commands)."""
    tcmd = list_terminal_commands()
    scmd = list_slash_commands()

    t = Table(title="CVC Terminal Commands")
    t.add_column("Command", style="bold")
    t.add_column("Summary")
    for row in tcmd:
        t.add_row(f"cvc {row['name']}", row["summary"] or "")
    console.print(t)

    s = Table(title="CVC Slash Commands (in TUI)")
    s.add_column("Command", style="bold")
    s.add_column("Summary")
    for row in scmd:
        s.add_row(row["name"], row["summary"])
    console.print(s)


__all__ = ["list_all_commands", "list_terminal_commands", "list_slash_commands", "commands_cmd"]
