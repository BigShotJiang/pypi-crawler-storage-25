"""cvc update — upgrade CVC via `uv tool upgrade tm-ai`.

Prints before/after versions. This module is *also* a stand-alone callable
(`run_update()`) so tests can exercise the logic without invoking Click.

This subcommand is registered onto the legacy Click ``main`` group at import
time and intentionally overrides any pre-existing ``update`` command so the
canonical Hermes-parity behaviour wins.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import Optional

import click
from rich.console import Console

from cvc.cli._legacy import main

console = Console()

_PKG = "tm-ai"


def _current_version() -> Optional[str]:
    try:
        from cvc import __version__ as v  # type: ignore
        return str(v)
    except Exception:
        return None


def _query_uv_version() -> Optional[str]:
    """Best-effort: ask uv tool list for the installed tm-ai version."""
    if not shutil.which("uv"):
        return None
    try:
        out = subprocess.run(
            ["uv", "tool", "list"],
            check=False, capture_output=True, text=True, timeout=10,
        ).stdout
        for line in out.splitlines():
            line = line.strip()
            if line.startswith(_PKG + " "):
                # e.g.  "tm-ai v1.4.81"
                parts = line.split()
                if len(parts) >= 2:
                    return parts[1].lstrip("v")
    except Exception:
        return None
    return None


def run_update(*, dry_run: bool = False) -> int:
    """Upgrade tm-ai via uv. Returns process exit code (0 == success)."""
    before = _current_version() or _query_uv_version() or "unknown"
    console.print(f"[dim]Current version:[/dim] [bold]{before}[/bold]")

    if not shutil.which("uv"):
        console.print(
            "[bold red]✗ `uv` is not installed.[/bold red] "
            "Install from https://docs.astral.sh/uv/ and retry.")
        return 127

    cmd = ["uv", "tool", "upgrade", _PKG]
    console.print(f"[dim]$ {' '.join(cmd)}[/dim]")
    if dry_run:
        return 0
    try:
        rc = subprocess.run(cmd, check=False).returncode
    except Exception as exc:
        console.print(f"[bold red]✗ Upgrade failed:[/bold red] {exc}")
        return 1

    after = _query_uv_version() or "unknown"
    if rc == 0:
        console.print(
            f"[bold green]✓ Updated[/bold green]  {before}  →  [bold]{after}[/bold]")
    else:
        console.print(f"[bold red]✗ uv exited with code {rc}.[/bold red]")
    return rc


@main.command("update")
@click.option("--dry-run", is_flag=True, default=False, help="Print the upgrade plan without executing.")
def update_cmd(dry_run: bool) -> None:  # pragma: no cover - thin click wrapper
    """Update CVC (tm-ai) to the latest version via uv."""
    raise SystemExit(run_update(dry_run=dry_run))


__all__ = ["run_update", "update_cmd"]
