"""CVC banner rendering — welcome + install-complete UX.

Renders rich panels with figlet-style branding, a tagline, version line,
and a quick-command cheatsheet. Falls back gracefully when ``pyfiglet``
is not installed.
"""
from __future__ import annotations

from importlib import metadata as _metadata

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.align import Align

# CVC brand red.
CVC_RED = "#e63946"

# Hand-crafted ASCII fallback if pyfiglet isn't available.
_ASCII_CVC = r"""
  ____  __     __  ____ 
 / ___| \ \   / / / ___|
| |      \ \ / / | |    
| |___    \ V /  | |___ 
 \____|    \_/    \____|
"""

_QUICK_COMMANDS = [
    ("cvc setup",     "First-run wizard — pick providers, log in, configure."),
    ("cvc doctor",    "Diagnose your environment, surface fixes."),
    ("cvc agent",     "Launch the agent runtime (interactive workstation)."),
    ("cvc auth",      "Manage provider auth: login / status / logout / list."),
    ("cvc curator",   "Curate context, prompts, and skill libraries."),
    ("cvc tips",      "Daily tips & cheatsheet for power users."),
]


def _figlet(text: str) -> str:
    """Return figlet-rendered text or the hand-crafted fallback."""
    try:
        import pyfiglet  # type: ignore
        return pyfiglet.figlet_format(text, font="ansi_shadow").rstrip("\n")
    except Exception:
        return _ASCII_CVC.strip("\n")


def _version() -> str:
    try:
        return _metadata.version("tm-ai")
    except Exception:
        return "0.0.0"


def _quick_table() -> Table:
    table = Table.grid(padding=(0, 2))
    table.add_column(style=f"bold {CVC_RED}", no_wrap=True)
    table.add_column(style="white")
    for cmd, desc in _QUICK_COMMANDS:
        table.add_row(cmd, desc)
    return table


def print_welcome_banner(console: Console | None = None) -> None:
    """Print the CVC welcome banner."""
    console = console or Console()
    art = Text(_figlet("CVC"), style=f"bold {CVC_RED}")
    subtitle = Text("Cognitive Version Control", style="bold white")
    tagline = Text(
        "The most advanced agentic AI workstation",
        style=f"italic {CVC_RED}",
    )
    version_line = Text(f"v{_version()}", style="dim")

    body = Text()
    body.append(art)
    body.append("\n\n")
    body.append(Align.center(subtitle).renderable if False else subtitle)
    body.append("\n")
    body.append(tagline)
    body.append("\n")
    body.append(version_line)
    body.append("\n")

    panel = Panel(
        body,
        border_style=CVC_RED,
        title="[bold]CVC[/bold]",
        subtitle="[dim]jaimeena.com/cvc[/dim]",
        padding=(1, 2),
    )
    console.print(panel)
    console.print()
    console.print(Panel(
        _quick_table(),
        title=f"[bold {CVC_RED}]Quick commands[/]",
        border_style="grey50",
        padding=(1, 2),
    ))


def print_install_complete(console: Console | None = None) -> None:
    """Print celebratory panel after `cvc setup` completes."""
    console = console or Console()
    msg = Text()
    msg.append("✨ ", style="yellow")
    msg.append("CVC is ready.", style=f"bold {CVC_RED}")
    msg.append(" ✨\n\n", style="yellow")
    msg.append("Your cognitive workstation has been configured.\n", style="white")
    msg.append("\n")
    msg.append("Next: ", style="dim")
    msg.append("cvc agent", style=f"bold {CVC_RED}")
    msg.append("\n", style="white")

    panel = Panel(
        msg,
        title="[bold]✨ Setup complete ✨[/bold]",
        border_style=CVC_RED,
        padding=(1, 2),
    )
    console.print(panel)


__all__ = ["print_welcome_banner", "print_install_complete", "CVC_RED"]
