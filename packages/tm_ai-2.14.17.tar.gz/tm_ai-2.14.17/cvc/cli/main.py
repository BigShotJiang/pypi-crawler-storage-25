"""CVC main CLI entry point — Typer app wiring all subcommands.

Subcommands are imported lazily inside each handler so the app loads even
when sibling slices haven't shipped yet (curator/trajectory/tips/skills).
"""
from __future__ import annotations

from importlib import metadata as _metadata
from typing import Optional

import typer

app = typer.Typer(
    name="cvc",
    help="Cognitive Version Control — the most advanced agentic AI workstation",
    no_args_is_help=False,
    add_completion=False,
)


def _resolve_version() -> str:
    try:
        return _metadata.version("tm-ai")
    except Exception:
        return "0.0.0+unknown"


def _version_callback(value: bool) -> None:
    """Click-style ``--version`` / ``-V`` flag."""
    if value:
        typer.echo(f"cvc, version {_resolve_version()}")
        raise typer.Exit()


# ---------------------------------------------------------------------------
# Root callback — bare ``cvc`` launches the interactive agent TUI directly.
# ---------------------------------------------------------------------------
@app.callback(invoke_without_command=True)
def _root(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        is_flag=True,
        help="Show the CVC version and exit.",
    ),
) -> None:
    """Default action when ``cvc`` is run with no subcommand."""
    if ctx.invoked_subcommand is not None:
        return

    # Bare ``cvc`` — hand off straight to the agent TUI (Hermes-parity UX).
    from cvc.cli.agent import run_agent
    code = run_agent()
    raise typer.Exit(code=code or 0)


# ---------------------------------------------------------------------------
# help — alias for ``cvc --help``
# ---------------------------------------------------------------------------
@app.command("help")
def help_cmd(ctx: typer.Context) -> None:
    """Show the CVC command menu (alias for ``cvc --help``)."""
    typer.echo(ctx.parent.get_help() if ctx.parent else ctx.get_help())


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------
@app.command("version")
def version_cmd() -> None:
    """Print the installed CVC (tm-ai) version."""
    typer.echo(f"cvc {_resolve_version()}")


# ---------------------------------------------------------------------------
# setup
# ---------------------------------------------------------------------------
@app.command("setup")
def setup_cmd(
    quick: bool = typer.Option(False, "--quick", help="Skip optional steps."),
) -> None:
    """Run the CVC first-run setup wizard."""
    from cvc.cli.setup import run_setup
    run_setup(quick=quick)


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------
@app.command("auth")
def auth_cmd(
    action: str = typer.Argument(..., help="login | status | logout | list"),
    provider: Optional[str] = typer.Argument(None, help="Provider name (copilot, openai, anthropic, ...)"),
) -> None:
    """Manage provider authentication."""
    from cvc.cli.auth import run_auth
    run_auth(provider or "copilot", action)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------
@app.command("doctor")
def doctor_cmd(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output."),
    fix: bool = typer.Option(False, "--fix", help="Attempt automatic fixes."),
) -> None:
    """Diagnose your CVC environment."""
    from cvc.cli.doctor import run_doctor
    raise typer.Exit(code=run_doctor(verbose=verbose, fix=fix) or 0)


# ---------------------------------------------------------------------------
# curator (lazy — sibling slice may not exist yet)
# ---------------------------------------------------------------------------
@app.command("curator")
def curator_cmd(
    action: str = typer.Argument(..., help="Curator action (list, add, remove, ...)."),
    name: Optional[str] = typer.Argument(None),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmations."),
) -> None:
    """Curate context, prompts, and skills."""
    try:
        from cvc.cli.curator import run_curator  # type: ignore
    except ImportError:
        typer.echo("Curator not available — upgrade tm-ai")
        raise typer.Exit(code=1)
    run_curator(action, name=name, assume_yes=yes)


# ---------------------------------------------------------------------------
# trajectory (lazy)
# ---------------------------------------------------------------------------
@app.command("trajectory")
def trajectory_cmd(
    action: str = typer.Argument(..., help="Trajectory action (list, show, replay, ...)."),
    id: Optional[str] = typer.Argument(None),
) -> None:
    """Inspect agent trajectories."""
    try:
        from cvc.cli.trajectory import run_trajectory  # type: ignore
    except ImportError:
        typer.echo("Trajectory not available — upgrade tm-ai")
        raise typer.Exit(code=1)
    run_trajectory(action, id=id)


# ---------------------------------------------------------------------------
# tips (lazy)
# ---------------------------------------------------------------------------
@app.command("tips")
def tips_cmd(
    action: Optional[str] = typer.Argument(None, help="Tips action (show, list, next, ...)."),
    arg: Optional[str] = typer.Argument(None),
) -> None:
    """Daily tips and cheatsheet."""
    try:
        from cvc.cli.tips import run_tips  # type: ignore
    except ImportError:
        typer.echo("Tips not available — upgrade tm-ai")
        raise typer.Exit(code=1)
    run_tips(action, arg)


# ---------------------------------------------------------------------------
# daemon — thin wrapper that exposes cvc/daemon.py for cvc gateway lifecycle
# ---------------------------------------------------------------------------
@app.command("daemon")
def daemon_cmd(
    action: str = typer.Argument("start", help="start | stop | status"),
) -> None:
    """Manage the CVC gateway background daemon."""
    try:
        from cvc import daemon as _daemon  # type: ignore
    except Exception as exc:
        typer.echo(f"daemon module unavailable: {exc}", err=True)
        raise typer.Exit(code=1)

    a = (action or "start").strip().lower()
    if a == "start":
        # Best-effort: install + start the launchd/systemd unit so the gateway
        # comes up. Falls back to in-process gateway start.
        try:
            _daemon.install_daemon()
        except Exception:
            pass
        try:
            from cvc.cli._legacy import gateway_start as _gw_start  # type: ignore
            import click as _click
            _click.Context(_gw_start).invoke(
                _gw_start,
                host="127.0.0.1",
                port=13421,
                proxy_port=13421,
                no_browser=True,
                log=False,
            )
        except Exception as exc:
            typer.echo(f"daemon start: {exc}", err=True)
            raise typer.Exit(code=1)
    elif a == "stop":
        try:
            _daemon.kill_gateway_process()
            typer.echo("daemon stopped")
        except Exception as exc:
            typer.echo(f"daemon stop: {exc}", err=True)
            raise typer.Exit(code=1)
    elif a == "status":
        pid = _daemon.read_pid_file()
        typer.echo(f"daemon pid: {pid}" if pid else "daemon not running")
    else:
        typer.echo(f"unknown daemon action: {action}", err=True)
        raise typer.Exit(code=2)


# ---------------------------------------------------------------------------
# agent — launches the Node Ink TUI
# ---------------------------------------------------------------------------
from cvc.cli.agent import register_agent_command  # noqa: E402

register_agent_command(app)


def main() -> None:
    """Console-script entry point."""
    app()


if __name__ == "__main__":
    main()
