"""cvc oneshot <prompt> — fire a single prompt at the configured agent and
print the reply to stdout. No TUI, no banner, no follow-up loop.

The implementation is intentionally thin so unit tests can monkeypatch
``_run_oneshot`` to a stub without dragging in the full agent runtime.
"""
from __future__ import annotations

from typing import Optional

import click

from cvc.cli._legacy import main


def _run_oneshot(prompt: str, *, model: Optional[str] = None, provider: Optional[str] = None) -> str:
    """Default backend: try the cvc agent runner, otherwise echo.

    Returning the string keeps this trivially testable.
    """
    try:
        # Best-effort wiring to existing agent code if present.
        from cvc.cli.agent import run_agent  # type: ignore

        result = run_agent(prompt=prompt, model=model, provider=provider, oneshot=True)
        return result if isinstance(result, str) else str(result)
    except Exception:
        # Fallback: graceful echo so tests + smoke runs don't crash.
        return prompt


def run_oneshot(prompt: str, *, model: Optional[str] = None, provider: Optional[str] = None) -> str:
    text = _run_oneshot(prompt, model=model, provider=provider)
    print(text)
    return text


@main.command("oneshot")
@click.argument("prompt", nargs=-1, required=True)
@click.option("--model", default=None)
@click.option("--provider", default=None)
def oneshot_cmd(prompt: tuple[str, ...], model: Optional[str], provider: Optional[str]) -> None:  # pragma: no cover
    """Run a single non-interactive prompt and print the reply."""
    run_oneshot(" ".join(prompt), model=model, provider=provider)


__all__ = ["run_oneshot", "_run_oneshot", "oneshot_cmd"]
