"""cvc.cli.tips — Rotating CLI tips for CVC.

Baked-in tip library covering setup, providers, fallback, plugins,
gateway, doctor, curator, trajectory, agent, voice, and more.

Actions: ``random``, ``all``, ``category <name>``, ``next``.
"""
from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

CVC_RED = "#e63946"


def _state_dir() -> Path:
    base = os.environ.get("CVC_HOME") or os.path.expanduser("~/.cvc")
    return Path(base)


def _index_file() -> Path:
    return _state_dir() / "tip_index.txt"


TIPS: List[Dict[str, Any]] = [
    # --- setup ---
    {"id": "setup-wizard", "category": "setup", "title": "Run the first-run wizard",
     "body": "The wizard walks you through providers, auth, and a sanity check.",
     "command": "cvc setup"},
    {"id": "setup-quick", "category": "setup", "title": "Quick setup",
     "body": "Skip prompts and use sensible defaults.", "command": "cvc setup --quick"},
    {"id": "setup-home", "category": "setup", "title": "Override CVC home",
     "body": "Set CVC_HOME=/path to relocate your config and sessions."},
    # --- providers ---
    {"id": "providers-list", "category": "providers", "title": "List known providers",
     "body": "See every provider CVC can talk to.", "command": "cvc auth list"},
    {"id": "providers-default", "category": "providers", "title": "Pick your default",
     "body": "CVC remembers your last successful provider per project."},
    {"id": "providers-copilot", "category": "providers", "title": "GitHub Copilot",
     "body": "Copilot uses device-flow login — no API key needed.",
     "command": "cvc auth login --provider copilot"},
    # --- fallback ---
    {"id": "fallback-chain", "category": "fallback", "title": "Provider fallback chain",
     "body": "When a provider fails, CVC walks the chain in order. Configure in ~/.cvc/config.yaml."},
    {"id": "fallback-cost", "category": "fallback", "title": "Cost-aware fallback",
     "body": "Cheap models first, expensive models last — flip with `--prefer-quality`."},
    {"id": "fallback-retry", "category": "fallback", "title": "Retry budgets",
     "body": "Each provider has its own retry/backoff window so one outage can't stall the chain."},
    # --- plugins ---
    {"id": "plugins-list", "category": "plugins", "title": "List plugins",
     "body": "See loaded plugin entry points.", "command": "cvc plugins list"},
    {"id": "plugins-write", "category": "plugins", "title": "Write a plugin",
     "body": "Drop a Python module exposing register(app) into ~/.cvc/plugins/."},
    {"id": "plugins-disable", "category": "plugins", "title": "Disable a plugin",
     "body": "Set CVC_DISABLED_PLUGINS=name1,name2 to skip them at startup."},
    # --- gateway ---
    {"id": "gateway-start", "category": "gateway", "title": "Start the gateway",
     "body": "Run a local OpenAI-compatible proxy.", "command": "cvc gateway up"},
    {"id": "gateway-models", "category": "gateway", "title": "Inspect gateway models",
     "body": "Hit /v1/models to confirm what's exposed."},
    {"id": "gateway-headers", "category": "gateway", "title": "Auth headers",
     "body": "The gateway accepts ``Authorization: Bearer <token>`` from your CVC config."},
    # --- doctor ---
    {"id": "doctor-run", "category": "doctor", "title": "Health check",
     "body": "Diagnose your install in one shot.", "command": "cvc doctor"},
    {"id": "doctor-fix", "category": "doctor", "title": "Auto-fix small issues",
     "body": "Doctor can repair perms and rewrite stale paths.", "command": "cvc doctor --fix"},
    {"id": "doctor-json", "category": "doctor", "title": "Machine-readable output",
     "body": "Pipe doctor results into other tools.", "command": "cvc doctor --json"},
    # --- curator ---
    {"id": "curator-intro", "category": "curator", "title": "Curator basics",
     "body": "The curator distils your sessions into reusable knowledge."},
    {"id": "curator-tag", "category": "curator", "title": "Tag a memory",
     "body": "Tags become searchable facets later.", "command": "cvc curator tag <id> <tag>"},
    {"id": "curator-search", "category": "curator", "title": "Search curated memory",
     "body": "Hybrid keyword + embedding search.", "command": "cvc curator search 'query'"},
    # --- trajectory ---
    {"id": "trajectory-list", "category": "trajectory", "title": "List sessions",
     "body": "See your recent recorded sessions.", "command": "cvc trajectory list"},
    {"id": "trajectory-show", "category": "trajectory", "title": "Replay a session",
     "body": "Walk through tool calls and messages.", "command": "cvc trajectory show <id>"},
    {"id": "trajectory-last", "category": "trajectory", "title": "Replay the latest",
     "body": "Show the most recent session.", "command": "cvc trajectory last"},
    # --- agent ---
    {"id": "agent-loop", "category": "agent", "title": "Agent loop",
     "body": "Agents iterate: think → act → observe. Each step is recorded as a trajectory event."},
    {"id": "agent-tools", "category": "agent", "title": "Tool registry",
     "body": "Tools are pluggable Python callables — anything that returns JSON-serialisable data."},
    {"id": "agent-budget", "category": "agent", "title": "Budgets matter",
     "body": "Cap iterations and tokens to keep runaway agents in check."},
    # --- voice ---
    {"id": "voice-tts", "category": "voice", "title": "Speak the answer",
     "body": "Use --voice to pipe replies through your TTS provider.", "command": "cvc chat --voice"},
    {"id": "voice-stt", "category": "voice", "title": "Mic input",
     "body": "Speech-to-text uses Whisper-class models locally when available."},
    {"id": "voice-providers", "category": "voice", "title": "Voice providers",
     "body": "ElevenLabs, OpenAI, and local Piper are supported out of the box."},
    # --- general ---
    {"id": "general-config", "category": "general", "title": "Edit config",
     "body": "Your config lives at ~/.cvc/config.yaml — version-controlled is fine."},
    {"id": "general-shell", "category": "general", "title": "Shell completion",
     "body": "Most modern shells support `cvc --install-completion`."},
]


def _categories() -> List[str]:
    seen = []
    for t in TIPS:
        if t["category"] not in seen:
            seen.append(t["category"])
    return seen


def _render_tip(console: Console, tip: Dict[str, Any]) -> None:
    body_lines = [tip["body"]]
    if tip.get("command"):
        body_lines.append("")
        body_lines.append(f"[bold cyan]$[/bold cyan] [bold]{tip['command']}[/bold]")
    panel = Panel(
        "\n".join(body_lines),
        title=f"[bold]{tip['title']}[/bold]  [dim]({tip['category']})[/dim]",
        border_style=CVC_RED,
        title_align="left",
    )
    console.print(panel)


def _action_random(console: Console) -> int:
    tip = random.choice(TIPS)
    _render_tip(console, tip)
    return 0


def _action_all(console: Console) -> int:
    table = Table(title="CVC Tips", border_style=CVC_RED)
    table.add_column("id", style="bold")
    table.add_column("category")
    table.add_column("title")
    for t in TIPS:
        table.add_row(t["id"], t["category"], t["title"])
    console.print(table)
    console.print(f"[dim]{len(TIPS)} tips across {len(_categories())} categories.[/dim]")
    return 0


def _action_category(console: Console, name: Optional[str]) -> int:
    if not name:
        console.print("[red]error:[/red] category requires a name")
        console.print(f"[dim]known: {', '.join(_categories())}[/dim]")
        return 2
    matches = [t for t in TIPS if t["category"] == name]
    if not matches:
        console.print(f"[red]error:[/red] no tips for category: {name}")
        console.print(f"[dim]known: {', '.join(_categories())}[/dim]")
        return 2
    for t in matches:
        _render_tip(console, t)
    return 0


def _action_next(console: Console) -> int:
    idx_file = _index_file()
    idx = 0
    try:
        idx_file.parent.mkdir(parents=True, exist_ok=True)
        if idx_file.exists():
            idx = int(idx_file.read_text(encoding="utf-8").strip() or "0")
    except Exception:
        idx = 0
    idx = idx % len(TIPS)
    tip = TIPS[idx]
    _render_tip(console, tip)
    try:
        idx_file.write_text(str((idx + 1) % len(TIPS)), encoding="utf-8")
    except Exception:
        pass
    return 0


def run_tips(action: str = "random", **kwargs) -> int:
    """Entry point for ``cvc tips``."""
    console: Console = kwargs.get("console") or Console()
    action = (action or "random").strip()
    name = kwargs.get("name") or kwargs.get("category")

    parts = action.split(maxsplit=1)
    if len(parts) == 2 and parts[0] == "category":
        action, name = parts[0], parts[1]

    if action == "random":
        return _action_random(console)
    if action == "all":
        return _action_all(console)
    if action == "category":
        return _action_category(console, name)
    if action == "next":
        return _action_next(console)

    console.print(f"[red]error:[/red] unknown action: {action}")
    console.print("[dim]actions: random | all | category <name> | next[/dim]")
    return 2


__all__ = ["run_tips", "TIPS"]
