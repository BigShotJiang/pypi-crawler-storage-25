"""``cvc curator`` — package-manager style UI for managing local skills.

Skills live in ``~/.cvc/skills/`` (or ``$CVC_SKILLS_PATH``). Each is a
directory containing ``SKILL.md`` with a YAML frontmatter block.

Supported actions:
    list      Tabular overview (name, description, pinned, last_used, LOC)
    view      Render a single skill's markdown body
    pin       Mark a skill as pinned (protects from prune)
    unpin     Remove the pin
    prune     Delete skills not used in 90+ days and not pinned
    validate  Verify YAML frontmatter and required keys for every skill
    stats     Print totals (count, pinned, stale, total LOC)

Returns: 0 = ok, 1 = warning (e.g. validation issues, target missing),
2 = hard error (e.g. unknown action).
"""
from __future__ import annotations

import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.markdown import Markdown
from rich.table import Table

from cvc.cli.skills import (
    REQUIRED_KEYS,
    SkillEntry,
    iter_skills,
    load_skill,
    skills_dir,
    split_frontmatter,
    write_frontmatter,
)

PRUNE_DAYS = 90

_VALID_ACTIONS = {"list", "view", "pin", "unpin", "prune", "validate", "stats"}


def _console(**kwargs: Any) -> Console:
    return Console(**kwargs)


def _fmt_last_used(skill: SkillEntry) -> str:
    if skill.last_used is None:
        return "[dim]never[/dim]"
    days = skill.days_since_use or 0
    if days >= PRUNE_DAYS:
        return f"[red]{days}d ago[/red]"
    if days >= 30:
        return f"[yellow]{days}d ago[/yellow]"
    return f"[green]{days}d ago[/green]"


def _action_list(console: Console, base: Path) -> int:
    skills = iter_skills(base)
    if not skills:
        console.print(f"[dim]No skills found in {base}[/dim]")
        return 0
    table = Table(
        title=f"CVC Skills ({len(skills)})",
        title_style="bold cyan",
        header_style="bold magenta",
        expand=False,
    )
    table.add_column("Name", style="bold cyan")
    table.add_column("Description", overflow="fold", max_width=50)
    table.add_column("Pinned", justify="center")
    table.add_column("Last used", justify="right")
    table.add_column("LOC", justify="right", style="dim")
    for s in skills:
        pin = "[green]📌[/green]" if s.pinned else "[dim]·[/dim]"
        table.add_row(s.name, s.description, pin, _fmt_last_used(s), str(s.loc))
    console.print(table)
    return 0


def _find_skill(base: Path, name: str) -> SkillEntry | None:
    target = base / name
    if target.is_dir():
        return load_skill(target)
    # case-insensitive fallback
    for s in iter_skills(base):
        if s.name.lower() == name.lower() or s.path.name.lower() == name.lower():
            return s
    return None


def _action_view(console: Console, base: Path, name: str | None) -> int:
    if not name:
        console.print("[red]error:[/red] view requires a skill name")
        return 2
    skill = _find_skill(base, name)
    if skill is None:
        console.print(f"[yellow]not found:[/yellow] {name}")
        return 1
    console.print(f"[bold cyan]{skill.name}[/bold cyan] [dim]v{skill.version}[/dim]")
    console.print(f"[italic]{skill.description}[/italic]\n")
    console.print(Markdown(skill.body or "*(empty body)*"))
    return 0


def _set_pinned(base: Path, name: str, pinned: bool) -> int:
    skill = _find_skill(base, name)
    if skill is None:
        return 1
    skill_md = skill.path / "SKILL.md"
    text = skill_md.read_text(encoding="utf-8")
    fm, body = split_frontmatter(text)
    if fm is None:
        return 2
    fm["pinned"] = bool(pinned)
    write_frontmatter(skill_md, fm, body)
    return 0


def _action_pin(console: Console, base: Path, name: str | None, pinned: bool) -> int:
    if not name:
        console.print("[red]error:[/red] pin/unpin requires a skill name")
        return 2
    rc = _set_pinned(base, name, pinned)
    if rc == 0:
        verb = "pinned" if pinned else "unpinned"
        console.print(f"[green]✓[/green] {verb} [bold]{name}[/bold]")
    elif rc == 1:
        console.print(f"[yellow]not found:[/yellow] {name}")
    else:
        console.print(f"[red]error:[/red] could not parse SKILL.md for {name}")
    return rc


def _action_validate(console: Console, base: Path) -> int:
    if not base.is_dir():
        console.print(f"[dim]No skills directory at {base}[/dim]")
        return 0
    issues = 0
    checked = 0
    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        checked += 1
        skill_md = child / "SKILL.md"
        if not skill_md.is_file():
            console.print(f"[red]✗[/red] {child.name}: missing SKILL.md")
            issues += 1
            continue
        text = skill_md.read_text(encoding="utf-8", errors="replace")
        fm, _ = split_frontmatter(text)
        if fm is None:
            console.print(f"[red]✗[/red] {child.name}: broken/missing YAML frontmatter")
            issues += 1
            continue
        missing = [k for k in REQUIRED_KEYS if k not in fm or fm[k] in (None, "")]
        if missing:
            console.print(f"[red]✗[/red] {child.name}: missing keys: {', '.join(missing)}")
            issues += 1
            continue
        console.print(f"[green]✓[/green] {child.name}")
    console.print(f"\n[bold]{checked - issues}/{checked}[/bold] skills valid")
    return 0 if issues == 0 else 1


def _action_prune(
    console: Console,
    base: Path,
    yes: bool,
    days: int = PRUNE_DAYS,
) -> int:
    skills = iter_skills(base)
    now = datetime.now(timezone.utc)
    stale: list[SkillEntry] = []
    for s in skills:
        if s.pinned:
            continue
        if s.last_used is None:
            continue  # never-used skills aren't auto-pruned
        d = s.days_since_use or 0
        if d >= days:
            stale.append(s)
    if not stale:
        console.print("[green]Nothing to prune.[/green]")
        return 0
    console.print(f"[yellow]Stale skills ({len(stale)}):[/yellow]")
    for s in stale:
        console.print(f"  • {s.name} [dim]({s.days_since_use}d ago)[/dim]")
    if not yes:
        try:
            answer = input("Delete these? [y/N] ").strip().lower()
        except EOFError:
            answer = ""
        if answer not in ("y", "yes"):
            console.print("[dim]aborted[/dim]")
            return 0
    deleted = 0
    for s in stale:
        try:
            shutil.rmtree(s.path)
            deleted += 1
            console.print(f"[red]−[/red] removed {s.name}")
        except Exception as e:
            console.print(f"[red]error:[/red] {s.name}: {e}")
    console.print(f"\n[bold]{deleted}[/bold] skill(s) pruned")
    return 0


def _action_stats(console: Console, base: Path) -> int:
    skills = iter_skills(base)
    total = len(skills)
    pinned = sum(1 for s in skills if s.pinned)
    stale = sum(
        1
        for s in skills
        if not s.pinned
        and s.last_used is not None
        and (s.days_since_use or 0) >= PRUNE_DAYS
    )
    never = sum(1 for s in skills if s.last_used is None)
    loc = sum(s.loc for s in skills)
    table = Table(title="Skill Stats", header_style="bold magenta", expand=False)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", justify="right", style="bold")
    table.add_row("Skills directory", str(base))
    table.add_row("Total skills", str(total))
    table.add_row("Pinned", str(pinned))
    table.add_row(f"Stale (≥{PRUNE_DAYS}d)", str(stale))
    table.add_row("Never used", str(never))
    table.add_row("Total LOC", str(loc))
    console.print(table)
    return 0


def run_curator(action: str, name: str | None = None, **kwargs: Any) -> int:
    """Entry point for ``cvc curator``.

    Parameters
    ----------
    action: one of list/view/pin/unpin/prune/validate/stats
    name:   skill name (required for view/pin/unpin)
    kwargs: ``yes`` (bool) for prune, ``console`` (rich.Console) for testing,
            ``skills_path`` (Path|str) to override the skills dir.
    """
    if action not in _VALID_ACTIONS:
        Console().print(
            f"[red]unknown action:[/red] {action}\n"
            f"valid: {', '.join(sorted(_VALID_ACTIONS))}"
        )
        return 2

    override = kwargs.get("skills_path")
    if override:
        base = Path(override).expanduser()
    else:
        base = skills_dir()
    base.mkdir(parents=True, exist_ok=True)

    console: Console = kwargs.get("console") or _console()

    if action == "list":
        return _action_list(console, base)
    if action == "view":
        return _action_view(console, base, name)
    if action == "pin":
        return _action_pin(console, base, name, True)
    if action == "unpin":
        return _action_pin(console, base, name, False)
    if action == "validate":
        return _action_validate(console, base)
    if action == "prune":
        return _action_prune(console, base, yes=bool(kwargs.get("yes", False)))
    if action == "stats":
        return _action_stats(console, base)
    return 2  # pragma: no cover


__all__ = ["run_curator", "PRUNE_DAYS"]
