"""Skill metadata loader for the curator command.

A skill lives at ``<skills_dir>/<name>/SKILL.md`` and starts with a YAML
frontmatter block delimited by ``---`` lines. Required keys:
``name``, ``description``. Optional: ``pinned`` (bool), ``version`` (str),
``last_used`` (ISO date or YYYY-MM-DD).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover - yaml is a hard dep elsewhere
    yaml = None  # type: ignore


REQUIRED_KEYS = ("name", "description")


def skills_dir() -> Path:
    """Return the active skills directory (honours ``$CVC_SKILLS_PATH``)."""
    env = os.environ.get("CVC_SKILLS_PATH")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".cvc" / "skills"


@dataclass
class SkillEntry:
    name: str
    description: str
    path: Path
    pinned: bool = False
    version: str = "0.0.0"
    last_used: datetime | None = None
    body: str = ""
    raw_frontmatter: dict[str, Any] = field(default_factory=dict)
    loc: int = 0

    @property
    def days_since_use(self) -> int | None:
        if self.last_used is None:
            return None
        now = datetime.now(timezone.utc)
        lu = self.last_used
        if lu.tzinfo is None:
            lu = lu.replace(tzinfo=timezone.utc)
        return (now - lu).days


def _parse_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None


def split_frontmatter(text: str) -> tuple[dict[str, Any] | None, str]:
    """Split a SKILL.md into (frontmatter_dict, body). Returns (None, text)
    if there is no valid frontmatter block."""
    if not text.startswith("---"):
        return None, text
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, text
    end = -1
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end == -1:
        return None, text
    fm_text = "\n".join(lines[1:end])
    body = "\n".join(lines[end + 1 :])
    if yaml is None:
        return None, body
    try:
        data = yaml.safe_load(fm_text) or {}
    except Exception:
        return None, body
    if not isinstance(data, dict):
        return None, body
    return data, body


def load_skill(path: Path) -> SkillEntry | None:
    """Load a skill directory. Returns ``None`` if SKILL.md is missing or
    has broken/missing frontmatter."""
    path = Path(path)
    skill_md = path / "SKILL.md" if path.is_dir() else path
    if not skill_md.is_file():
        return None
    try:
        text = skill_md.read_text(encoding="utf-8")
    except Exception:
        return None
    fm, body = split_frontmatter(text)
    if fm is None:
        return None
    if not all(k in fm and fm[k] not in (None, "") for k in REQUIRED_KEYS):
        return None
    name = str(fm.get("name") or path.name)
    description = str(fm.get("description") or "")
    pinned = bool(fm.get("pinned", False))
    version = str(fm.get("version", "0.0.0"))
    last_used = _parse_dt(fm.get("last_used"))
    loc = len(text.splitlines())
    return SkillEntry(
        name=name,
        description=description,
        path=path if path.is_dir() else skill_md.parent,
        pinned=pinned,
        version=version,
        last_used=last_used,
        body=body,
        raw_frontmatter=dict(fm),
        loc=loc,
    )


def iter_skills(root: Path | None = None) -> list[SkillEntry]:
    """Return all valid skills found under ``root`` (default: skills_dir())."""
    base = Path(root) if root is not None else skills_dir()
    if not base.is_dir():
        return []
    out: list[SkillEntry] = []
    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        skill = load_skill(child)
        if skill is not None:
            out.append(skill)
    return out


def write_frontmatter(skill_md: Path, frontmatter: dict[str, Any], body: str) -> None:
    """Atomically rewrite a SKILL.md with new frontmatter + preserved body."""
    if yaml is None:  # pragma: no cover
        raise RuntimeError("PyYAML not available")
    fm_text = yaml.safe_dump(frontmatter, sort_keys=False).strip()
    new_text = f"---\n{fm_text}\n---\n{body}" if body.startswith("\n") else f"---\n{fm_text}\n---\n{body}"
    tmp = skill_md.with_suffix(skill_md.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    os.replace(tmp, skill_md)


__all__ = [
    "SkillEntry",
    "REQUIRED_KEYS",
    "skills_dir",
    "load_skill",
    "iter_skills",
    "split_frontmatter",
    "write_frontmatter",
]
