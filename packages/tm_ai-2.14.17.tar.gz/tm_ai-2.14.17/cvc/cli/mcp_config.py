"""cvc mcp_config — list / add / remove MCP server configurations.

State is persisted to ``~/.cvc/mcp.json`` with shape::

    {"servers": [{"name": "...", "command": "...", "args": [...], "env": {...}}]}
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import click
from rich.console import Console
from rich.table import Table

from cvc.cli._legacy import main

console = Console()

CONFIG_FILE = Path.home() / ".cvc" / "mcp.json"


def _empty() -> Dict[str, Any]:
    return {"servers": []}


def load_mcp_config() -> Dict[str, Any]:
    if not CONFIG_FILE.exists():
        return _empty()
    try:
        cfg = json.loads(CONFIG_FILE.read_text())
        if not isinstance(cfg, dict) or "servers" not in cfg:
            return _empty()
        return cfg
    except Exception:
        return _empty()


def save_mcp_config(cfg: Dict[str, Any]) -> Path:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, sort_keys=True))
    return CONFIG_FILE


def list_mcp_servers() -> List[Dict[str, Any]]:
    return list(load_mcp_config().get("servers", []))


def add_mcp_server(name: str, command: str, args: Optional[List[str]] = None, env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    cfg = load_mcp_config()
    cfg["servers"] = [s for s in cfg.get("servers", []) if s.get("name") != name]
    cfg["servers"].append({
        "name": name,
        "command": command,
        "args": list(args or []),
        "env": dict(env or {}),
    })
    save_mcp_config(cfg)
    return cfg


def remove_mcp_server(name: str) -> Dict[str, Any]:
    cfg = load_mcp_config()
    cfg["servers"] = [s for s in cfg.get("servers", []) if s.get("name") != name]
    save_mcp_config(cfg)
    return cfg


@main.group("mcp_config")
def mcp_grp() -> None:
    """Manage MCP server entries."""


@mcp_grp.command("list")
def _list() -> None:  # pragma: no cover
    rows = list_mcp_servers()
    if not rows:
        console.print("[dim]No MCP servers configured.[/dim]")
        return
    t = Table(title="MCP Servers")
    t.add_column("Name", style="bold")
    t.add_column("Command")
    t.add_column("Args")
    for r in rows:
        t.add_row(str(r.get("name", "")), str(r.get("command", "")), " ".join(r.get("args", [])))
    console.print(t)


@mcp_grp.command("add")
@click.argument("name")
@click.argument("command")
@click.argument("args", nargs=-1)
def _add(name: str, command: str, args: tuple[str, ...]) -> None:  # pragma: no cover
    add_mcp_server(name, command, list(args))
    console.print(f"[bold green]✓ added[/bold green] {name}")


@mcp_grp.command("remove")
@click.argument("name")
def _remove(name: str) -> None:  # pragma: no cover
    remove_mcp_server(name)
    console.print(f"[bold yellow]✗ removed[/bold yellow] {name}")


__all__ = [
    "load_mcp_config", "save_mcp_config",
    "list_mcp_servers", "add_mcp_server", "remove_mcp_server",
    "mcp_grp",
]
