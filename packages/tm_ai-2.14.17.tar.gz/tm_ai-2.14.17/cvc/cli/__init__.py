"""cvc.cli — Command-line interface package.

Re-exports the legacy monolithic CLI (``main`` and friends) and the new
modular sub-commands (e.g. :mod:`cvc.cli.doctor`, :mod:`cvc.cli.setup`,
:mod:`cvc.cli.auth`).
"""
from __future__ import annotations

# Re-export everything from the legacy monolithic module so that existing
# imports (``from cvc.cli import main``) continue to work transparently.
from cvc.cli._legacy import *  # noqa: F401,F403
from cvc.cli._legacy import main  # noqa: F401  (explicit for entry point)

# New modular sub-commands.
from cvc.cli.doctor import run_doctor, CheckResult  # noqa: F401

# First-run wizard + unified auth flow (new).
from cvc.cli.setup import run_setup  # noqa: F401
from cvc.cli.auth import run_auth, KNOWN_PROVIDERS  # noqa: F401


def register_setup_commands(app) -> None:
    """Register `cvc setup` and `cvc auth` subcommands on a Typer/Click app.

    Best-effort: tries Typer/Click decorator API. If `app` is None or
    unrecognized, this is a no-op.
    """
    if app is None:
        return
    try:
        @app.command("setup")  # type: ignore[misc]
        def _setup(quick: bool = False) -> None:
            """Run the CVC first-run setup wizard."""
            run_setup(quick=quick)

        @app.command("auth")  # type: ignore[misc]
        def _auth(provider: str = "copilot", action: str = "login") -> None:
            """Manage provider authentication: login | status | logout | list."""
            run_auth(provider, action)
    except Exception:
        pass


__all__ = [
    "main",
    "run_doctor",
    "CheckResult",
    "run_setup",
    "run_auth",
    "KNOWN_PROVIDERS",
    "register_setup_commands",
]

# Optional modular sub-commands (best-effort import).
try:
    from cvc.cli.trajectory import run_trajectory  # noqa: F401
    __all__.append("run_trajectory")
except Exception:  # pragma: no cover
    pass

try:
    from cvc.cli.tips import run_tips  # noqa: F401
    __all__.append("run_tips")
except Exception:  # pragma: no cover
    pass

# Optional sub-commands. Wrapped in try/except so concurrent sibling agents
# adding new modules don't make the package unimportable if their module
# isn't yet on disk.
try:
    from cvc.cli.curator import run_curator  # noqa: F401
    __all__.append("run_curator")
except Exception:
    pass

try:
    from cvc.cli.agent import run_agent  # noqa: F401
    __all__.append("run_agent")
except Exception:
    pass

# ---------------------------------------------------------------------------
# Slice 12B.3 — Hermes-parity terminal subcommands. Each module registers
# itself onto the legacy Click group at import time. Wrapped in try/except
# so a single broken sibling can't make `cvc` unimportable.
# ---------------------------------------------------------------------------
for _mod in (
    "update", "backup", "gateway", "plugins", "oneshot",
    "commands", "uninstall", "memory_setup", "mcp_config",
):
    try:
        __import__(f"cvc.cli.{_mod}")
        __all__.append(_mod)
    except Exception:  # pragma: no cover
        pass

