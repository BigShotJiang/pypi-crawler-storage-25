"""GitHub Copilot model catalog (ported from Hermes hermes_cli/models.py).

Static catalog of Copilot-accessible models with reasoning support flags.
Use list_copilot_models() and github_model_reasoning_efforts() at the API.
"""

from __future__ import annotations

from typing import Any, Optional

# Reasoning effort levels supported by GitHub Copilot model families
COPILOT_REASONING_EFFORTS_GPT5 = ["minimal", "low", "medium", "high"]
COPILOT_REASONING_EFFORTS_O_SERIES = ["low", "medium", "high"]


# id, display_name, api_mode, context_window, supports_reasoning, supports_vision
_CATALOG: list[dict[str, Any]] = [
    # Anthropic (via Copilot anthropic_messages mode)
    {
        "id": "claude-sonnet-4.6",
        "display_name": "Claude Sonnet 4.6",
        "api_mode": "anthropic_messages",
        "context_window": 200000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    {
        "id": "claude-opus-4.7",
        "display_name": "Claude Opus 4.7",
        "api_mode": "anthropic_messages",
        "context_window": 200000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    {
        "id": "claude-3.5-sonnet",
        "display_name": "Claude 3.5 Sonnet",
        "api_mode": "anthropic_messages",
        "context_window": 200000,
        "supports_reasoning": False,
        "supports_vision": True,
    },
    {
        "id": "claude-3.7-sonnet",
        "display_name": "Claude 3.7 Sonnet",
        "api_mode": "anthropic_messages",
        "context_window": 200000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    # OpenAI GPT-5 family (Responses API)
    {
        "id": "gpt-5",
        "display_name": "GPT-5",
        "api_mode": "codex_responses",
        "context_window": 272000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    {
        "id": "gpt-5-codex",
        "display_name": "GPT-5 Codex",
        "api_mode": "codex_responses",
        "context_window": 272000,
        "supports_reasoning": True,
        "supports_vision": False,
    },
    {
        "id": "gpt-5-mini",
        "display_name": "GPT-5 Mini",
        "api_mode": "chat_completions",
        "context_window": 272000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    # OpenAI o-series
    {
        "id": "o1",
        "display_name": "OpenAI o1",
        "api_mode": "chat_completions",
        "context_window": 200000,
        "supports_reasoning": True,
        "supports_vision": False,
    },
    {
        "id": "o3",
        "display_name": "OpenAI o3",
        "api_mode": "chat_completions",
        "context_window": 200000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    {
        "id": "o4-mini",
        "display_name": "OpenAI o4-mini",
        "api_mode": "chat_completions",
        "context_window": 200000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    # OpenAI 4.x
    {
        "id": "gpt-4.1",
        "display_name": "GPT-4.1",
        "api_mode": "chat_completions",
        "context_window": 1000000,
        "supports_reasoning": False,
        "supports_vision": True,
    },
    {
        "id": "gpt-4o",
        "display_name": "GPT-4o",
        "api_mode": "chat_completions",
        "context_window": 128000,
        "supports_reasoning": False,
        "supports_vision": True,
    },
    # Google Gemini
    {
        "id": "gemini-2.5-pro",
        "display_name": "Gemini 2.5 Pro",
        "api_mode": "chat_completions",
        "context_window": 1000000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
    {
        "id": "gemini-3.1-pro-preview",
        "display_name": "Gemini 3.1 Pro (Preview)",
        "api_mode": "chat_completions",
        "context_window": 2000000,
        "supports_reasoning": True,
        "supports_vision": True,
    },
]


def list_copilot_models() -> list[dict[str, Any]]:
    """Return the full Copilot model catalog (list of dicts)."""
    return [dict(m) for m in _CATALOG]


def get_copilot_model(model_id: str) -> Optional[dict[str, Any]]:
    """Lookup a single model entry by ID (case-insensitive)."""
    if not model_id:
        return None
    needle = model_id.strip().lower()
    for entry in _CATALOG:
        if entry["id"].lower() == needle:
            return dict(entry)
    return None


def _github_reasoning_efforts_for_model_id(model_id: str) -> list[str]:
    """Return reasoning effort levels for a given Copilot model ID."""
    raw = (model_id or "").strip().lower()
    if raw.startswith(("openai/o1", "openai/o3", "openai/o4", "o1", "o3", "o4")):
        return list(COPILOT_REASONING_EFFORTS_O_SERIES)
    if raw.startswith("gpt-5"):
        return list(COPILOT_REASONING_EFFORTS_GPT5)
    return []


def github_model_reasoning_efforts(
    model_id: Optional[str],
    *,
    catalog: Optional[list[dict[str, Any]]] = None,
    api_key: Optional[str] = None,
) -> list[str]:
    """Return supported reasoning-effort levels for a Copilot-visible model.

    Ported from Hermes. Catalog/api_key params kept for signature parity but
    we use the static catalog for lookups; pattern fallback for ID matching.
    """
    if not model_id:
        return []

    # Catalog lookup first (allows custom catalogs to override)
    haystack = catalog if catalog is not None else _CATALOG
    entry = next((m for m in haystack if m.get("id") == model_id), None)
    if entry is not None:
        if not entry.get("supports_reasoning"):
            return []
        # Static catalog: derive efforts from model ID family
        return _github_reasoning_efforts_for_model_id(str(model_id))

    # Pattern fallback for unknown IDs
    return _github_reasoning_efforts_for_model_id(str(model_id))
