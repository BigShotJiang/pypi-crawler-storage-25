"""Route a Copilot model ID to its API mode.

Family rules (matching opencode / Hermes):
  - Claude*       → anthropic_messages
  - GPT-5+ / Codex → codex_responses (except gpt-5-mini → chat_completions)
  - o1 / o3 / o4   → chat_completions (with reasoning extras)
  - else           → chat_completions
"""

from __future__ import annotations

import re

from cvc.providers.copilot.models import get_copilot_model


def _should_use_copilot_responses_api(model_id: str) -> bool:
    """Replicates opencode's shouldUseCopilotResponsesApi."""
    match = re.match(r"^gpt-(\d+)", model_id)
    if not match:
        return False
    major = int(match.group(1))
    return major >= 5 and not model_id.startswith("gpt-5-mini")


def route_model_to_api_mode(model_id: str) -> str:
    """Return one of: chat_completions | anthropic_messages | codex_responses."""
    if not model_id:
        return "chat_completions"

    raw = model_id.strip()
    lower = raw.lower()

    # Catalog-driven first (authoritative)
    entry = get_copilot_model(raw)
    if entry:
        mode = entry.get("api_mode")
        if mode in ("chat_completions", "anthropic_messages", "codex_responses"):
            return mode

    # Pattern-based fallback for unknown IDs
    # Strip provider prefix like "anthropic/" or "openai/"
    bare = lower.split("/", 1)[1] if "/" in lower else lower

    if bare.startswith("claude"):
        return "anthropic_messages"
    if bare.startswith(("gpt-5-codex", "codex-")):
        return "codex_responses"
    if _should_use_copilot_responses_api(bare):
        return "codex_responses"
    return "chat_completions"
