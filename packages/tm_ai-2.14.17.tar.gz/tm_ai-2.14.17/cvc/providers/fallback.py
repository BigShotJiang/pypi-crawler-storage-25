"""
cvc.providers.fallback — multi-provider cascading fallback chain.

Wraps a primary provider with a list of fallbacks. On each transient/rate-limit
/context-overflow error, rotate to the next provider. Permanent errors abort.
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional

logger = logging.getLogger("cvc.providers.fallback")

try:
    from cvc.agent.error_classifier import (
        FailoverReason,
        classify_api_error,
    )
    _CLASSIFIER_AVAILABLE = True
except Exception:  # pragma: no cover
    classify_api_error = None  # type: ignore
    FailoverReason = None  # type: ignore
    _CLASSIFIER_AVAILABLE = False


# Reasons that justify rotating to next provider
_ROTATE_REASONS = frozenset()
if _CLASSIFIER_AVAILABLE:
    _ROTATE_REASONS = frozenset({
        FailoverReason.transient,
        FailoverReason.rate_limit,
        FailoverReason.context_overflow,
        FailoverReason.timeout,
        FailoverReason.server_error,
        FailoverReason.overloaded,
        FailoverReason.payload_too_large,
        FailoverReason.model_not_found,
        FailoverReason.billing,
    })


class FallbackChainExhausted(RuntimeError):
    """All providers in the chain have been exhausted."""


class FallbackChain:
    """A primary provider with an ordered list of fallbacks.

    Usage::

        chain = FallbackChain("copilot:claude-sonnet-4.6", ["nvidia:nemotron-3-super-120b"])
        provider = chain.current()
        try:
            ... call provider ...
        except Exception as e:
            provider = chain.select(e)  # rotates if transient, raises if exhausted
    """

    def __init__(
        self,
        primary: str,
        fallbacks: List[str],
        on_failure: Optional[Callable[[str, Exception], None]] = None,
    ) -> None:
        if not primary:
            raise ValueError("primary provider id required")
        self.primary = primary
        self.fallbacks = list(fallbacks or [])
        self.on_failure = on_failure
        self._index = 0  # 0 = primary, 1..N = fallbacks[i-1]

    # ── public API ────────────────────────────────────────────────

    def current(self) -> str:
        """Return the currently active provider id."""
        if self._index == 0:
            return self.primary
        return self.fallbacks[self._index - 1]

    def reset(self) -> None:
        """Reset chain to primary."""
        if self._index != 0:
            logger.info("fallback.reset: returning to primary=%s", self.primary)
        self._index = 0

    def select(self, error: Optional[Exception] = None) -> str:
        """Pick the next provider.

        With no error, returns current (idempotent).
        With an error, classifies it; if transient/rate-limit/context-overflow,
        rotates to the next provider. Otherwise re-raises (or raises if exhausted).
        """
        if error is None:
            return self.current()

        should_rotate = self._should_rotate(error)
        prev = self.current()

        if self.on_failure is not None:
            try:
                self.on_failure(prev, error)
            except Exception:  # pragma: no cover
                logger.exception("on_failure callback raised; ignoring")

        if not should_rotate:
            logger.warning(
                "fallback.select: NOT rotating (permanent error) provider=%s err=%r",
                prev, error,
            )
            raise error

        # Rotate
        self._index += 1
        if self._index > len(self.fallbacks):
            logger.error(
                "fallback.select: chain exhausted after %d providers; last=%s",
                self._index, prev,
            )
            raise FallbackChainExhausted(
                f"All {len(self.fallbacks) + 1} providers exhausted; last error: {error!r}"
            ) from error

        nxt = self.current()
        logger.info(
            "fallback.select: switching %s → %s (reason=%s)",
            prev, nxt, type(error).__name__,
        )
        return nxt

    # ── helpers ───────────────────────────────────────────────────

    def _should_rotate(self, error: Exception) -> bool:
        """Decide whether the error warrants rotating."""
        if not _CLASSIFIER_AVAILABLE or classify_api_error is None:
            # No classifier — be conservative: rotate on common transient names
            name = type(error).__name__.lower()
            transient_hints = ("rate", "timeout", "overload", "server", "transient", "503", "502", "429")
            return any(h in name for h in transient_hints)

        try:
            classified = classify_api_error(error)
        except Exception:  # pragma: no cover
            logger.exception("classify_api_error failed; defaulting to no-rotate")
            return False

        return classified.reason in _ROTATE_REASONS

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"FallbackChain(primary={self.primary!r}, "
            f"fallbacks={self.fallbacks!r}, idx={self._index})"
        )
