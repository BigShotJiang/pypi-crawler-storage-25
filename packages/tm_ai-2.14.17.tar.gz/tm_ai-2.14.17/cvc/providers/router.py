"""
cvc.providers.router — smart provider router.

Routes a model_id to the appropriate provider based on prefix patterns,
and assembles Jai's preferred default fallback chain.
"""

from __future__ import annotations

import os
import re
from typing import List, Optional

from cvc.providers.fallback import FallbackChain

# ── Config ────────────────────────────────────────────────────────────

# Jai's preferred chain (provider:model strings)
_DEFAULT_PRIMARY = "copilot:claude-sonnet-4.6"
_DEFAULT_FALLBACKS: List[str] = [
    "nvidia:nemotron-3-super-120b",
    "gemini:gemini-3.1-pro-preview",
    "gemini:gemini-3.1-flash-lite",
    "openrouter:gemma-4-31b",
    "openrouter:kimi-k2.5",
    "openrouter:minimax-m2.5",
    "openrouter:glm5",
]

# (regex pattern, preferred_provider_with_token, fallback_provider) mapping
# If COPILOT_TOKEN / GH_COPILOT_TOKEN exists, prefer copilot for claude/gpt/gemini.
_ROUTES: list[tuple[re.Pattern[str], str, str]] = [
    (re.compile(r"^claude[-_]"),     "copilot",     "anthropic"),
    (re.compile(r"^(gpt|o1|o3|o4)[-_]"), "copilot", "openai-codex"),
    (re.compile(r"^gemini[-_]"),     "copilot",     "gemini"),
    (re.compile(r"^nemotron"),       "nvidia",      "nvidia"),
    (re.compile(r"^deepseek[-_]"),   "deepseek",    "deepseek"),
    (re.compile(r"^grok[-_]"),       "xai",         "xai"),
    (re.compile(r"^(llama|qwen|gemma|kimi|minimax|glm|mistral|mixtral)"),
                                     "openrouter",  "openrouter"),
]


def _has_copilot_token() -> bool:
    for var in ("COPILOT_TOKEN", "GITHUB_COPILOT_TOKEN", "GH_COPILOT_TOKEN"):
        if os.environ.get(var):
            return True
    # Also accept presence of copilot config file
    cfg = os.path.expanduser("~/.config/github-copilot/hosts.json")
    if os.path.exists(cfg):
        return True
    return False


def resolve_provider(model_id: str) -> Optional[str]:
    """Return provider name for a model id, or None if no match.

    Examples:
        resolve_provider("claude-sonnet-4.6") → "copilot" (or "anthropic")
        resolve_provider("gpt-4o")            → "copilot" (or "openai-codex")
        resolve_provider("nemotron-3-super")  → "nvidia"
        resolve_provider("deepseek-v3")       → "deepseek"
        resolve_provider("grok-3")            → "xai"
        resolve_provider("llama-3.1-70b")     → "openrouter"
    """
    if not model_id:
        return None
    name = model_id.strip().lower()
    # Strip an optional "provider:" prefix
    if ":" in name:
        prefix, rest = name.split(":", 1)
        return prefix or None  # explicit provider wins

    has_copilot = _has_copilot_token()
    for pattern, preferred, fallback in _ROUTES:
        if pattern.match(name):
            if preferred == "copilot" and not has_copilot:
                return fallback
            return preferred
    return None


def default_chain(primary_model: Optional[str] = None) -> FallbackChain:
    """Build Jai's preferred fallback chain.

    Honours the ``CVC_FALLBACK_CHAIN`` env var (comma-separated provider:model),
    where the first entry is primary and the rest are fallbacks.
    """
    override = os.environ.get("CVC_FALLBACK_CHAIN", "").strip()
    if override:
        parts = [p.strip() for p in override.split(",") if p.strip()]
        if parts:
            return FallbackChain(primary=parts[0], fallbacks=parts[1:])

    primary = primary_model or _DEFAULT_PRIMARY
    return FallbackChain(primary=primary, fallbacks=list(_DEFAULT_FALLBACKS))
