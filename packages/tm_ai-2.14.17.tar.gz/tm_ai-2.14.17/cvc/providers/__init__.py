"""Provider registry for CVC (ported from Hermes providers/__init__.py).

Subpackages under cvc.providers.<name>/ are auto-discovered. Each subpackage's
__init__.py calls register_provider(profile) at import time.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from pathlib import Path

from cvc.providers.base import OMIT_TEMPERATURE, ProviderProfile  # noqa: F401

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, ProviderProfile] = {}
_ALIASES: dict[str, str] = {}
_discovered = False


def register_provider(profile: ProviderProfile) -> None:
    """Register a provider profile by name and aliases (last-writer-wins)."""
    _REGISTRY[profile.name] = profile
    for alias in profile.aliases:
        _ALIASES[alias] = profile.name


def get_provider_profile(name: str) -> ProviderProfile | None:
    if not _discovered:
        _discover_providers()
    canonical = _ALIASES.get(name, name)
    return _REGISTRY.get(canonical)


def list_providers() -> list[str]:
    """Return canonical names of all registered providers."""
    if not _discovered:
        _discover_providers()
    return sorted(_REGISTRY.keys())


def list_provider_profiles() -> list[ProviderProfile]:
    if not _discovered:
        _discover_providers()
    seen: set[int] = set()
    result: list[ProviderProfile] = []
    for profile in _REGISTRY.values():
        pid = id(profile)
        if pid not in seen:
            seen.add(pid)
            result.append(profile)
    return result


def _discover_providers() -> None:
    global _discovered
    if _discovered:
        return
    _discovered = True

    pkg_path = Path(__file__).resolve().parent
    for _importer, modname, ispkg in pkgutil.iter_modules([str(pkg_path)]):
        if modname.startswith("_") or modname == "base":
            continue
        try:
            importlib.import_module(f"cvc.providers.{modname}")
        except Exception as exc:
            logger.warning("Failed to load provider %s: %s", modname, exc)
