"""Delegate task to a subagent (single + batch).

This is a structured *intent* — the agent loop in ``cvc.agent.subagent``
materialises the actual subagent execution. Returning a structured payload
keeps the registry/handler decoupled from runtime orchestration.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Spawn one or more subagents with isolated context. role='leaf' for terminal work, 'orchestrator' to fan out further.",
    "parameters": {
        "type": "object",
        "properties": {
            "tasks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "task": {"type": "string"},
                        "context": {"type": "string"},
                        "role": {"type": "string", "enum": ["leaf", "orchestrator"], "default": "leaf"},
                        "toolset": {"type": "string"},
                    },
                    "required": ["task"],
                },
            },
            "max_concurrent_children": {"type": "integer", "default": 3},
        },
        "required": ["tasks"],
    },
}


def _handle_delegate(tasks: List[Dict[str, Any]],
                     max_concurrent_children: int = 3) -> Dict[str, Any]:
    return {
        "kind": "delegate",
        "tasks": tasks,
        "max_concurrent_children": max_concurrent_children,
        "note": ("Subagent dispatch handled by cvc.agent.subagent at the "
                 "agent-loop layer; this tool produces the intent only."),
    }


registry.register(
    name="delegate_task",
    category="delegation",
    schema=SCHEMA,
    handler=_handle_delegate,
    emoji="👥",
)
