"""Mixture-of-Agents — N reference models + 1 aggregator.

Returns a structured intent describing the MoA call. The agent loop
materialises it (because actual provider dispatch lives in
``cvc.agent.providers``). This keeps the tool registry pure.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from cvc.tools.registry import registry

DEFAULT_REFERENCES = [
    "openai:gpt-4o-mini",
    "anthropic:claude-haiku",
    "google:gemini-flash",
    "groq:llama-3.1-70b",
]
DEFAULT_AGGREGATOR = "openai:gpt-4o"


SCHEMA = {
    "description": "Mixture-of-Agents: query N reference models in parallel, "
                   "then aggregate via a chosen aggregator model.",
    "parameters": {
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "references": {"type": "array", "items": {"type": "string"},
                           "description": "Provider:model strings. Default: 4 mixed."},
            "aggregator": {"type": "string"},
            "system": {"type": "string"},
        },
        "required": ["prompt"],
    },
}


def _handle_moa(prompt: str, references: Optional[List[str]] = None,
                aggregator: Optional[str] = None,
                system: Optional[str] = None) -> Dict[str, Any]:
    refs = references or DEFAULT_REFERENCES
    agg = aggregator or DEFAULT_AGGREGATOR
    return {
        "kind": "mixture_of_agents",
        "prompt": prompt,
        "system": system,
        "references": refs,
        "aggregator": agg,
        "note": "Materialised by cvc.agent loop.",
    }


registry.register(
    name="mixture_of_agents",
    category="agents",
    schema=SCHEMA,
    handler=_handle_moa,
    emoji="🧠",
)
