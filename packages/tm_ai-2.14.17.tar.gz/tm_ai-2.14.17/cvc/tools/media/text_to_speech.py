"""Text-to-speech stub — synthesize audio from text."""

from __future__ import annotations

from typing import Any, Dict, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Synthesize speech from text. Returns a path to the generated audio file.",
    "parameters": {
        "type": "object",
        "properties": {
            "text": {"type": "string"},
            "voice": {"type": "string", "description": "Provider-specific voice id."},
            "model": {"type": "string"},
            "format": {"type": "string", "enum": ["mp3", "wav", "ogg"], "default": "mp3"},
        },
        "required": ["text"],
    },
}


def _handle_text_to_speech(text: str, voice: Optional[str] = None,
                           model: Optional[str] = None,
                           format: str = "mp3") -> Dict[str, Any]:
    raise NotImplementedError(
        "text_to_speech requires Slice 6 provider wiring (TTS client not yet integrated)."
    )


registry.register(
    name="text_to_speech",
    category="media",
    schema=SCHEMA,
    handler=_handle_text_to_speech,
    emoji="🔊",
    requires_config=True,
)
