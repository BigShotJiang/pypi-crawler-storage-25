"""Media tools subpackage — vision, video, image generation, TTS.

All four tools register with proper OpenAI schemas in this slice but
their handlers raise :class:`NotImplementedError`. Provider wiring
(OpenAI vision, Gemini video, image-gen APIs, ElevenLabs/OpenAI TTS)
lands in Slice 6.
"""
