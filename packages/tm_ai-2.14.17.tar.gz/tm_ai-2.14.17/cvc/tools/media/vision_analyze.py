"""Vision-analyze stub — analyze an image via a multimodal LLM.

Schema is final; handler is wired up in Slice 6 (provider wiring).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Analyze one or more images with a vision-capable model. Returns a textual description / answer.",
    "parameters": {
        "type": "object",
        "properties": {
            "images": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of image paths or http(s) URLs.",
            },
            "prompt": {"type": "string", "description": "What to ask about the images."},
            "model": {"type": "string", "description": "Optional vision model override."},
        },
        "required": ["images", "prompt"],
    },
}


def _handle_vision_analyze(images: List[str], prompt: str,
                           model: Optional[str] = None) -> Dict[str, Any]:
    raise NotImplementedError(
        "vision_analyze requires Slice 6 provider wiring (multimodal LLM client not yet integrated)."
    )


registry.register(
    name="vision_analyze",
    category="media",
    schema=SCHEMA,
    handler=_handle_vision_analyze,
    emoji="👁️",
    requires_config=True,
)
