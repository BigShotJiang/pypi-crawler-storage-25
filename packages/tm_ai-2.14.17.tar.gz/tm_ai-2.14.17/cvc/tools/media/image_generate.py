"""Image-generate stub — text-to-image via configured provider."""

from __future__ import annotations

from typing import Any, Dict, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Generate an image from a text prompt. Returns a path or URL to the generated image.",
    "parameters": {
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "size": {"type": "string", "default": "1024x1024",
                     "description": "WIDTHxHEIGHT, e.g. 1024x1024."},
            "model": {"type": "string"},
            "n": {"type": "integer", "default": 1, "minimum": 1, "maximum": 4},
        },
        "required": ["prompt"],
    },
}


def _handle_image_generate(prompt: str, size: str = "1024x1024",
                           model: Optional[str] = None, n: int = 1) -> Dict[str, Any]:
    raise NotImplementedError(
        "image_generate requires Slice 6 provider wiring (image-generation client not yet integrated)."
    )


registry.register(
    name="image_generate",
    category="media",
    schema=SCHEMA,
    handler=_handle_image_generate,
    emoji="🎨",
    requires_config=True,
)
