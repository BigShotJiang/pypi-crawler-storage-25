"""Video-analyze stub — describe / Q&A over a video clip."""

from __future__ import annotations

from typing import Any, Dict, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Analyze a video clip with a video-capable multimodal model.",
    "parameters": {
        "type": "object",
        "properties": {
            "video": {"type": "string", "description": "Path or URL to a video file."},
            "prompt": {"type": "string", "description": "Question or instruction."},
            "model": {"type": "string"},
        },
        "required": ["video", "prompt"],
    },
}


def _handle_video_analyze(video: str, prompt: str,
                          model: Optional[str] = None) -> Dict[str, Any]:
    raise NotImplementedError(
        "video_analyze requires Slice 6 provider wiring (Gemini / OpenAI video client not yet integrated)."
    )


registry.register(
    name="video_analyze",
    category="media",
    schema=SCHEMA,
    handler=_handle_video_analyze,
    emoji="🎬",
    requires_config=True,
)
