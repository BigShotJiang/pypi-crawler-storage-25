"""Central tool registry for CVC.

Patterned after Hermes-Agent's `tools/registry.py`, scaled down for CVC.
Each tool module performs a top-level ``registry.register(...)`` call so
``discover_builtin_tools()`` can pick it up via filesystem walk + AST
inspection (no runtime import side-effects from helper modules).

Both sync and async handlers are supported. ``invoke()`` always returns
a coroutine so callers can ``await`` regardless of the underlying
handler — sync handlers are off-loaded to a worker thread via
``asyncio.to_thread`` to keep the event loop responsive.
"""

from __future__ import annotations

import ast
import asyncio
import importlib
import inspect
import logging
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def _is_registry_register_call(node: ast.AST) -> bool:
    if not isinstance(node, ast.Expr) or not isinstance(node.value, ast.Call):
        return False
    func = node.value.func
    if isinstance(func, ast.Attribute) and func.attr == "register":
        if isinstance(func.value, ast.Name) and func.value.id in {"registry", "_registry"}:
            return True
    if isinstance(func, ast.Name) and func.id == "register":
        return True
    return False


def _module_registers_tools(module_path: Path) -> bool:
    try:
        tree = ast.parse(module_path.read_text(encoding="utf-8"), filename=str(module_path))
    except (OSError, SyntaxError):
        return False
    return any(_is_registry_register_call(stmt) for stmt in tree.body)


def discover_builtin_tools(tools_dir: Optional[Path] = None) -> List[str]:
    """Import every tool module in *tools_dir* that self-registers.

    Walks recursively so subpackages (``web/``, ``media/``) are picked up.
    """
    base = Path(tools_dir) if tools_dir else Path(__file__).resolve().parent
    skip_names = {"__init__.py", "registry.py", "toolsets.py"}
    skip_prefixes = ("_",)  # _helpers, _path_security, _approval, _output_limits

    imported: List[str] = []
    for path in sorted(base.rglob("*.py")):
        if path.name in skip_names:
            continue
        if any(part.startswith(skip_prefixes) for part in path.relative_to(base).parts):
            continue
        if not _module_registers_tools(path):
            continue
        rel = path.relative_to(base.parent.parent)  # cvc/tools/...
        mod_name = ".".join(rel.with_suffix("").parts)
        try:
            importlib.import_module(mod_name)
            imported.append(mod_name)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Tool module %s failed to import: %s", mod_name, exc)
    return imported


# ---------------------------------------------------------------------------
# Tool entry
# ---------------------------------------------------------------------------

@dataclass
class ToolEntry:
    """Metadata for a registered tool."""

    name: str
    category: str  # toolset / category — e.g. "file", "web", "terminal"
    schema: Dict[str, Any]
    handler: Callable[..., Any]
    check_fn: Optional[Callable[[], bool]] = None
    requires_env: List[str] = field(default_factory=list)
    is_async: bool = False
    description: str = ""
    emoji: str = ""
    max_result_size_chars: Optional[int] = None
    requires_config: bool = False


# Back-compat alias — some consumers may prefer ``Tool`` over ``ToolEntry``.
Tool = ToolEntry


# ---------------------------------------------------------------------------
# Check_fn TTL cache (mirrors Hermes ~30 s)
# ---------------------------------------------------------------------------

_CHECK_FN_TTL_SECONDS = 30.0
_check_fn_cache: Dict[Callable, tuple[float, bool]] = {}
_check_fn_lock = threading.Lock()


def _check_fn_cached(fn: Callable) -> bool:
    now = time.monotonic()
    with _check_fn_lock:
        cached = _check_fn_cache.get(fn)
        if cached and now - cached[0] < _CHECK_FN_TTL_SECONDS:
            return cached[1]
    try:
        value = bool(fn())
    except Exception:
        value = False
    with _check_fn_lock:
        _check_fn_cache[fn] = (now, value)
    return value


def invalidate_check_fn_cache() -> None:
    with _check_fn_lock:
        _check_fn_cache.clear()


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class ToolRegistry:
    """Thread-safe singleton holding all registered tools."""

    def __init__(self) -> None:
        self._tools: Dict[str, ToolEntry] = {}
        self._lock = threading.RLock()
        self._generation = 0

    # ---- registration --------------------------------------------------

    def register(
        self,
        name: str,
        category: str,
        schema: Dict[str, Any],
        handler: Callable[..., Any],
        check_fn: Optional[Callable[[], bool]] = None,
        requires_env: Optional[List[str]] = None,
        is_async: Optional[bool] = None,
        description: str = "",
        emoji: str = "",
        max_result_size_chars: Optional[int] = None,
        requires_config: bool = False,
    ) -> ToolEntry:
        if is_async is None:
            is_async = inspect.iscoroutinefunction(handler)

        entry = ToolEntry(
            name=name,
            category=category,
            schema=schema,
            handler=handler,
            check_fn=check_fn,
            requires_env=list(requires_env or []),
            is_async=is_async,
            description=description or schema.get("description", ""),
            emoji=emoji,
            max_result_size_chars=max_result_size_chars,
            requires_config=requires_config,
        )
        with self._lock:
            existing = self._tools.get(name)
            if existing and existing.category != category:
                logger.debug("Tool '%s' re-registered (was %s, now %s)",
                             name, existing.category, category)
            self._tools[name] = entry
            self._generation += 1
        return entry

    def deregister(self, name: str) -> None:
        with self._lock:
            self._tools.pop(name, None)
            self._generation += 1

    # ---- lookup --------------------------------------------------------

    def get(self, name: str) -> Optional[ToolEntry]:
        with self._lock:
            return self._tools.get(name)

    def list_all(self, available_only: bool = False) -> List[ToolEntry]:
        with self._lock:
            entries = list(self._tools.values())
        if available_only:
            entries = [e for e in entries if not e.check_fn or _check_fn_cached(e.check_fn)]
        return sorted(entries, key=lambda e: e.name)

    def list_by_category(self, category: str) -> List[ToolEntry]:
        return [e for e in self.list_all() if e.category == category]

    def categories(self) -> List[str]:
        return sorted({e.category for e in self.list_all()})

    # ---- OpenAI schema -------------------------------------------------

    def get_openai_definitions(self, names: Optional[Set[str]] = None,
                               available_only: bool = True) -> List[Dict[str, Any]]:
        """Return OpenAI function-calling format for the requested tools."""
        out: List[Dict[str, Any]] = []
        for entry in self.list_all(available_only=available_only):
            if names is not None and entry.name not in names:
                continue
            schema = entry.schema or {}
            # If the schema is already wrapped in {"type": "function", ...} use it,
            # otherwise wrap it.
            if schema.get("type") == "function":
                out.append(schema)
                continue
            out.append({
                "type": "function",
                "function": {
                    "name": entry.name,
                    "description": entry.description or schema.get("description", ""),
                    "parameters": schema.get("parameters")
                                 or schema.get("input_schema")
                                 or {"type": "object", "properties": {}},
                },
            })
        return out

    # ---- invocation ----------------------------------------------------

    async def invoke(self, name: str, arguments: Dict[str, Any]) -> Any:
        entry = self.get(name)
        if entry is None:
            raise KeyError(f"Tool not found: {name}")
        if entry.requires_config:
            return {"error": f"Tool '{name}' requires configuration (API keys / install)."}
        if entry.is_async:
            result = await entry.handler(**arguments)
        else:
            result = await asyncio.to_thread(entry.handler, **arguments)
        return _truncate_if_needed(result, entry.max_result_size_chars)


def _truncate_if_needed(result: Any, max_chars: Optional[int]) -> Any:
    if max_chars is None:
        return result
    if isinstance(result, str) and len(result) > max_chars:
        marker = f"\n\n…[truncated: {len(result) - max_chars} chars omitted]"
        return result[:max_chars] + marker
    return result


# ---------------------------------------------------------------------------
# Module-level singleton + convenience functions
# ---------------------------------------------------------------------------

registry = ToolRegistry()


def register(*args, **kwargs) -> ToolEntry:
    return registry.register(*args, **kwargs)


def get(name: str) -> Optional[ToolEntry]:
    return registry.get(name)


def list_all(available_only: bool = False) -> List[ToolEntry]:
    return registry.list_all(available_only=available_only)


def list_by_category(category: str) -> List[ToolEntry]:
    return registry.list_by_category(category)


__all__ = [
    "Tool", "ToolEntry", "ToolRegistry", "registry",
    "register", "get", "list_all", "list_by_category",
    "discover_builtin_tools", "invalidate_check_fn_cache",
]
