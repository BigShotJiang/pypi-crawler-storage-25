"""skill_view — read a skill's manifest plus its file tree (delegates to cvc.skills)."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from cvc.skills import load_skill
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Load a skill's manifest content plus a shallow file listing.",
    "parameters": {
        "type": "object",
        "properties": {
            "name": {"type": "string", "description": "Skill name (directory name)."},
            "max_chars": {"type": "integer", "default": 20000},
            "include_tree": {"type": "boolean", "default": True},
        },
        "required": ["name"],
    },
}


def _walk(root: Path, limit: int = 200) -> List[str]:
    out: List[str] = []
    for p in sorted(root.rglob("*")):
        if any(part.startswith(".") for part in p.relative_to(root).parts):
            continue
        out.append(str(p.relative_to(root)) + ("/" if p.is_dir() else ""))
        if len(out) >= limit:
            break
    return out


def _handle_skill_view(name: str, max_chars: int = 20000, include_tree: bool = True) -> Dict[str, Any]:
    skill = load_skill(name)
    if skill is None:
        return {"error": f"Skill not found: {name}"}
    try:
        content = skill.manifest.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return {"error": f"Cannot read manifest: {exc}"}
    truncated = False
    if len(content) > max_chars:
        content = content[:max_chars] + f"\n…[truncated {len(content) - max_chars} chars]"
        truncated = True
    result: Dict[str, Any] = {
        "name": skill.name,
        "source": skill.source,
        "path": str(skill.path),
        "manifest": str(skill.manifest),
        "content": content,
        "truncated": truncated,
    }
    if include_tree:
        result["files"] = _walk(skill.path)
    return result


registry.register(
    name="skill_view",
    category="skills",
    schema=SCHEMA,
    handler=_handle_skill_view,
    emoji="📖",
    max_result_size_chars=40_000,
)
