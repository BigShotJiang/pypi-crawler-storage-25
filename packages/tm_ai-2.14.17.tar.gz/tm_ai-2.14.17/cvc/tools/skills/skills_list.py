"""skills_list — enumerate available skills (delegates to cvc.skills)."""

from __future__ import annotations

from typing import Any, Dict

from cvc.skills import list_skills
from cvc.tools.registry import registry

SCHEMA = {
    "description": "List all available skills from ~/.hermes/skills/ and ~/.cvc/skills/.",
    "parameters": {
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "enum": ["all", "hermes", "cvc"],
                "default": "all",
            },
        },
        "required": [],
    },
}


def _handle_skills_list(source: str = "all") -> Dict[str, Any]:
    skills = list_skills()
    if source != "all":
        skills = [s for s in skills if s.get("source") == source]
    return {
        "count": len(skills),
        "skills": [
            {"name": s["name"], "source": s["source"], "path": s["path"]}
            for s in skills
        ],
    }


registry.register(
    name="skills_list",
    category="skills",
    schema=SCHEMA,
    handler=_handle_skills_list,
    emoji="🧩",
)
