"""Skills toolset — discover, view, and manage skill bundles."""
