"""Common helpers for the skills toolset.

Thin shim over :mod:`cvc.skills` for backward compatibility. Tools should
prefer ``cvc.skills`` directly; this module preserves the old surface
(``SKILL_ROOTS``, ``iter_skill_dirs``, ``find_skill``).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from cvc.skills.loader import SkillLoader, default_skill_roots

SKILL_ROOTS: List[Path] = default_skill_roots()


def iter_skill_dirs() -> List[Dict[str, str]]:
    """Return ``[{name, root, path, manifest, source}]`` for every skill found."""
    loader = SkillLoader(roots=SKILL_ROOTS)
    return [
        {
            "name": e["name"],
            "root": e["root"],
            "path": e["path"],
            "manifest": e["manifest"],
            "source": e["source"],
        }
        for e in loader.discover()
    ]


def find_skill(name: str) -> Optional[Dict[str, str]]:
    for entry in iter_skill_dirs():
        if entry["name"] == name:
            return entry
    return None
