"""skill_manage — create / remove / refresh CVC-local skills.

Mutating operations target ~/.cvc/skills/ only — Hermes skills are read-only
from CVC's perspective. Discovery/scan delegates to :mod:`cvc.skills`.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Dict, Optional

from cvc.skills import get_default_registry, load_skill
from cvc.skills.loader import default_skill_roots
from cvc.tools.registry import registry

CVC_ROOT = Path.home() / ".cvc" / "skills"

SCHEMA = {
    "description": (
        "Manage CVC-local skills under ~/.cvc/skills/. Actions: 'create' "
        "(scaffold a new skill), 'remove' (delete one), 'refresh' (rescan "
        "available roots and report counts)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["create", "remove", "refresh"]},
            "name": {"type": "string", "description": "Skill name (required for create/remove)."},
            "description": {"type": "string", "description": "One-line description for create."},
            "content": {"type": "string", "description": "Optional initial SKILL.md body."},
        },
        "required": ["action"],
    },
}


def _scan() -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for root in default_skill_roots():
        if not root.is_dir():
            counts[str(root)] = 0
            continue
        counts[str(root)] = sum(
            1 for c in root.iterdir()
            if c.is_dir() and not c.name.startswith(".")
        )
    return counts


def _handle_skill_manage(
    action: str,
    name: Optional[str] = None,
    description: str = "",
    content: str = "",
) -> Dict[str, Any]:
    action = action.lower()
    if action == "refresh":
        get_default_registry().refresh()
        return {"action": "refresh", "roots": _scan()}

    if not name:
        return {"error": f"'name' is required for action={action}"}

    if action == "create":
        CVC_ROOT.mkdir(parents=True, exist_ok=True)
        target = CVC_ROOT / name
        if target.exists():
            return {"error": f"Skill already exists: {target}"}
        target.mkdir()
        if content:
            body = content
        else:
            body = (
                "---\n"
                f"name: {name}\n"
                f"description: {description or 'TODO: describe this skill.'}\n"
                "---\n\n"
                f"# {name}\n\n{description or 'TODO: describe this skill.'}\n"
            )
        (target / "SKILL.md").write_text(body, encoding="utf-8")
        get_default_registry().refresh()
        return {"action": "create", "name": name, "path": str(target), "ok": True}

    if action == "remove":
        skill = load_skill(name)
        if skill is None:
            return {"error": f"Skill not found: {name}"}
        if skill.source != "cvc":
            return {"error": f"Refusing to remove non-CVC skill: {skill.path}"}
        shutil.rmtree(skill.path)
        get_default_registry().refresh()
        return {"action": "remove", "name": name, "ok": True}

    return {"error": f"Unknown action: {action}"}


registry.register(
    name="skill_manage",
    category="skills",
    schema=SCHEMA,
    handler=_handle_skill_manage,
    emoji="🛠️",
)
