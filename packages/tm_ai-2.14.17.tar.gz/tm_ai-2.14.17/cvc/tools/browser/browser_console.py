"""browser_console — read or clear the buffered console log."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import (
    get_console,
    playwright_available,
    reset_console,
)
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Read recent console messages from the shared browser session, optionally clear after.",
    "parameters": {
        "type": "object",
        "properties": {
            "limit": {"type": "integer", "default": 100},
            "level": {
                "type": "string",
                "description": "Filter by message type (log/info/warning/error/debug).",
            },
            "clear": {"type": "boolean", "default": False},
        },
        "required": [],
    },
}


def _handle(limit: int = 100, level: str = "", clear: bool = False) -> Dict[str, Any]:
    msgs = get_console()
    if level:
        msgs = [m for m in msgs if m.get("type") == level]
    msgs = msgs[-limit:]
    if clear:
        reset_console()
    return {"count": len(msgs), "messages": msgs}


registry.register(
    name="browser_console",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="📟",
    max_result_size_chars=40_000,
)
