"""browser_navigate — open a URL in the shared Playwright session."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available, reset_console
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Navigate the shared browser to a URL. Returns final URL + page title.",
    "parameters": {
        "type": "object",
        "properties": {
            "url": {"type": "string"},
            "wait_until": {
                "type": "string",
                "enum": ["load", "domcontentloaded", "networkidle", "commit"],
                "default": "load",
            },
            "timeout_ms": {"type": "integer", "default": 30000},
            "headless": {"type": "boolean", "default": True},
        },
        "required": ["url"],
    },
}


def _handle(url: str, wait_until: str = "load",
            timeout_ms: int = 30000, headless: bool = True) -> Dict[str, Any]:
    try:
        page = get_page(headless=headless)
        reset_console()
        page.goto(url, wait_until=wait_until, timeout=timeout_ms)
        return {"url": page.url, "title": page.title(), "ok": True}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_navigate",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="🌐",
)
