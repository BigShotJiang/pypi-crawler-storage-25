"""browser_snapshot — capture a screenshot + accessibility outline of the current page."""

from __future__ import annotations

import base64
import os
import tempfile
from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": (
        "Snapshot the current page: PNG screenshot (saved to disk + optional "
        "base64) and an accessibility-tree outline of interactive elements."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "full_page": {"type": "boolean", "default": False},
            "include_base64": {"type": "boolean", "default": False},
            "output_path": {"type": "string", "description": "Where to write the PNG. Defaults to tmp."},
        },
        "required": [],
    },
}


def _handle(full_page: bool = False, include_base64: bool = False,
            output_path: str = "") -> Dict[str, Any]:
    try:
        page = get_page()
        if not output_path:
            fd, output_path = tempfile.mkstemp(prefix="cvc_browser_", suffix=".png")
            os.close(fd)
        page.screenshot(path=output_path, full_page=full_page)
        result: Dict[str, Any] = {
            "url": page.url,
            "title": page.title(),
            "screenshot": output_path,
        }
        if include_base64:
            with open(output_path, "rb") as f:
                result["screenshot_base64"] = base64.b64encode(f.read()).decode("ascii")
        try:
            tree = page.accessibility.snapshot(interesting_only=True)
            result["accessibility"] = tree
        except Exception as exc:
            result["accessibility_error"] = str(exc)
        return result
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_snapshot",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="📸",
    max_result_size_chars=80_000,
)
