"""browser_back — navigate the shared session backward (or forward)."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Step the browser history backward or forward.",
    "parameters": {
        "type": "object",
        "properties": {
            "direction": {"type": "string", "enum": ["back", "forward"], "default": "back"},
            "timeout_ms": {"type": "integer", "default": 10000},
        },
        "required": [],
    },
}


def _handle(direction: str = "back", timeout_ms: int = 10000) -> Dict[str, Any]:
    try:
        page = get_page()
        if direction == "back":
            page.go_back(timeout=timeout_ms)
        else:
            page.go_forward(timeout=timeout_ms)
        return {"ok": True, "direction": direction, "url": page.url}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_back",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="⬅️",
)
