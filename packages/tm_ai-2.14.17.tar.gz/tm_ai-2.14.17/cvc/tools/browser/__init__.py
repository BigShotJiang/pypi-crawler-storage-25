"""Browser automation toolset (Playwright-backed).

All browser_* tools share a single Playwright session managed by
:mod:`cvc.tools.browser._session`. Playwright is imported lazily inside the
session bootstrap so the registry remains healthy on machines without it.
"""
