"""browser_press — press a keyboard key/chord (e.g. 'Enter', 'Control+L')."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Press a keyboard key or chord on the focused page (or a specific selector).",
    "parameters": {
        "type": "object",
        "properties": {
            "key": {"type": "string", "description": "Playwright key string e.g. 'Enter', 'Control+L'."},
            "selector": {"type": "string", "description": "Optional element to focus first."},
            "timeout_ms": {"type": "integer", "default": 5000},
        },
        "required": ["key"],
    },
}


def _handle(key: str, selector: str = "", timeout_ms: int = 5000) -> Dict[str, Any]:
    try:
        page = get_page()
        if selector:
            page.locator(selector).first.press(key, timeout=timeout_ms)
        else:
            page.keyboard.press(key)
        return {"ok": True, "key": key, "selector": selector or None}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_press",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="🎹",
)
