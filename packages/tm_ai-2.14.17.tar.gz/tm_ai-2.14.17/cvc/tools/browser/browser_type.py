"""browser_type — type text into an input element."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Focus an input/textarea and type text. Optionally clear first or press Enter after.",
    "parameters": {
        "type": "object",
        "properties": {
            "selector": {"type": "string"},
            "text": {"type": "string"},
            "clear": {"type": "boolean", "default": False},
            "submit": {"type": "boolean", "default": False, "description": "Press Enter after typing."},
            "delay_ms": {"type": "integer", "default": 0},
            "timeout_ms": {"type": "integer", "default": 10000},
        },
        "required": ["selector", "text"],
    },
}


def _handle(selector: str, text: str, clear: bool = False, submit: bool = False,
            delay_ms: int = 0, timeout_ms: int = 10000) -> Dict[str, Any]:
    try:
        page = get_page()
        locator = page.locator(selector).first
        if clear:
            locator.fill("", timeout=timeout_ms)
        locator.type(text, delay=delay_ms, timeout=timeout_ms)
        if submit:
            locator.press("Enter", timeout=timeout_ms)
        return {"ok": True, "selector": selector, "submitted": submit}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_type",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="⌨️",
)
