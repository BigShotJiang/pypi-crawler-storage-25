"""browser_scroll — scroll the page by pixels or to an element."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Scroll the page. Either by (dx, dy) pixels or scroll an element into view.",
    "parameters": {
        "type": "object",
        "properties": {
            "dx": {"type": "integer", "default": 0},
            "dy": {"type": "integer", "default": 0},
            "selector": {"type": "string", "description": "Scroll this element into view instead."},
            "to": {
                "type": "string",
                "enum": ["top", "bottom"],
                "description": "Quick jump to top or bottom.",
            },
        },
        "required": [],
    },
}


def _handle(dx: int = 0, dy: int = 0, selector: str = "", to: str = "") -> Dict[str, Any]:
    try:
        page = get_page()
        if selector:
            page.locator(selector).first.scroll_into_view_if_needed(timeout=5000)
            return {"ok": True, "scrolled_to": selector}
        if to == "top":
            page.evaluate("window.scrollTo(0, 0)")
            return {"ok": True, "to": "top"}
        if to == "bottom":
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            return {"ok": True, "to": "bottom"}
        page.evaluate(f"window.scrollBy({dx}, {dy})")
        return {"ok": True, "dx": dx, "dy": dy}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_scroll",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="📜",
)
