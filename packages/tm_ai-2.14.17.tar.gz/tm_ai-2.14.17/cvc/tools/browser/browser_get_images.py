"""browser_get_images — collect <img> sources from the current page."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Collect image URLs (and alt/dimensions) from the current page.",
    "parameters": {
        "type": "object",
        "properties": {
            "limit": {"type": "integer", "default": 50},
            "min_size": {
                "type": "integer",
                "default": 0,
                "description": "Skip images smaller than this width OR height (px).",
            },
        },
        "required": [],
    },
}

_JS = """
() => {
  const out = [];
  for (const img of document.images) {
    out.push({
      src: img.currentSrc || img.src,
      alt: img.alt || '',
      width: img.naturalWidth,
      height: img.naturalHeight,
    });
  }
  return out;
}
"""


def _handle(limit: int = 50, min_size: int = 0) -> Dict[str, Any]:
    try:
        page = get_page()
        items = page.evaluate(_JS) or []
        if min_size:
            items = [i for i in items if (i["width"] or 0) >= min_size or (i["height"] or 0) >= min_size]
        items = items[:limit]
        return {"url": page.url, "count": len(items), "images": items}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_get_images",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="🖼️",
    max_result_size_chars=40_000,
)
