"""browser_click — click an element matched by CSS selector or text."""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Click an element by CSS selector (preferred) or visible text.",
    "parameters": {
        "type": "object",
        "properties": {
            "selector": {"type": "string", "description": "CSS / Playwright selector."},
            "text": {"type": "string", "description": "Visible text fallback."},
            "timeout_ms": {"type": "integer", "default": 10000},
            "button": {"type": "string", "enum": ["left", "right", "middle"], "default": "left"},
            "click_count": {"type": "integer", "default": 1},
        },
        "required": [],
    },
}


def _handle(selector: str = "", text: str = "", timeout_ms: int = 10000,
            button: str = "left", click_count: int = 1) -> Dict[str, Any]:
    if not selector and not text:
        return {"error": "Provide selector or text."}
    try:
        page = get_page()
        locator = page.locator(selector) if selector else page.get_by_text(text, exact=False)
        locator.first.click(timeout=timeout_ms, button=button, click_count=click_count)
        return {"ok": True, "selector": selector or f"text={text!r}", "url": page.url}
    except Exception as exc:
        return {"error": str(exc)}


registry.register(
    name="browser_click",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="🖱️",
)
