"""browser_vision — screenshot the page and run vision_analyze on it.

This delegates to the registered ``vision_analyze`` tool so the LLM can
reason about the visual state of the page using whatever provider is wired
up (OpenAI vision, Claude vision, etc.).
"""

from __future__ import annotations

import asyncio
import os
import tempfile
from typing import Any, Dict

from cvc.tools.browser._session import get_page, playwright_available
from cvc.tools.registry import registry


SCHEMA = {
    "description": (
        "Screenshot the current browser page and pass it to vision_analyze "
        "with a natural-language prompt. Returns the vision model's answer."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "Question / instruction for the vision model.",
                "default": "Describe what is visible on this page.",
            },
            "full_page": {"type": "boolean", "default": False},
            "keep_screenshot": {"type": "boolean", "default": False},
        },
        "required": [],
    },
}


def _handle(prompt: str = "Describe what is visible on this page.",
            full_page: bool = False, keep_screenshot: bool = False) -> Dict[str, Any]:
    # 1. Snapshot
    try:
        page = get_page()
        fd, screenshot_path = tempfile.mkstemp(prefix="cvc_vision_", suffix=".png")
        os.close(fd)
        page.screenshot(path=screenshot_path, full_page=full_page)
        url, title = page.url, page.title()
    except Exception as exc:
        return {"error": f"screenshot failed: {exc}"}

    # 2. Hand off to vision_analyze (lazy lookup so we don't depend on import order)
    from cvc.tools.registry import registry as _reg

    vision = _reg.get("vision_analyze")
    if vision is None:
        return {
            "url": url,
            "title": title,
            "screenshot": screenshot_path,
            "error": "vision_analyze tool is not registered.",
        }

    args = {"path": screenshot_path, "prompt": prompt}
    try:
        if vision.is_async:
            answer = asyncio.run(vision.handler(**args))
        else:
            answer = vision.handler(**args)
    except Exception as exc:
        return {
            "url": url,
            "title": title,
            "screenshot": screenshot_path,
            "error": f"vision_analyze failed: {exc}",
        }

    if not keep_screenshot:
        try:
            os.unlink(screenshot_path)
        except OSError:
            pass
        screenshot_path = ""

    return {
        "url": url,
        "title": title,
        "prompt": prompt,
        "answer": answer,
        "screenshot": screenshot_path or None,
    }


registry.register(
    name="browser_vision",
    category="browser",
    schema=SCHEMA,
    handler=_handle,
    check_fn=playwright_available,
    emoji="👁️",
    max_result_size_chars=40_000,
)
