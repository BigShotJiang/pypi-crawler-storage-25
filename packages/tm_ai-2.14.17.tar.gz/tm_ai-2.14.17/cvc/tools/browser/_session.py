"""Singleton Playwright session shared by all browser_* tools.

Playwright is imported lazily; missing install yields a structured error
instead of crashing the registry. The session is sync-only — every
browser_* handler is a sync function dispatched by the registry via
``asyncio.to_thread``.
"""

from __future__ import annotations

import threading
from typing import Any, Dict, List, Optional

_lock = threading.RLock()
_state: Dict[str, Any] = {
    "playwright": None,
    "browser": None,
    "context": None,
    "page": None,
    "console": [],   # list of {type, text, ts}
    "headless": True,
}


def playwright_available() -> bool:
    try:
        import playwright  # noqa: F401
        return True
    except Exception:
        return False


def _install_console_listener(page) -> None:
    log: List[Dict[str, Any]] = _state["console"]

    def _on_console(msg) -> None:
        try:
            log.append({"type": msg.type, "text": msg.text})
        except Exception:
            pass
        # cap the buffer to avoid unbounded growth
        if len(log) > 500:
            del log[: len(log) - 500]

    page.on("console", _on_console)


def get_page(headless: Optional[bool] = None):
    """Return the shared Playwright page, launching the browser if needed."""
    with _lock:
        if _state["page"] is not None:
            return _state["page"]
        try:
            from playwright.sync_api import sync_playwright  # type: ignore
        except Exception as exc:  # pragma: no cover
            raise RuntimeError(
                "Playwright is not installed. Run: pip install playwright "
                "&& playwright install chromium"
            ) from exc

        pw = sync_playwright().start()
        if headless is not None:
            _state["headless"] = headless
        browser = pw.chromium.launch(headless=_state["headless"])
        context = browser.new_context()
        page = context.new_page()
        _install_console_listener(page)
        _state.update({
            "playwright": pw,
            "browser": browser,
            "context": context,
            "page": page,
        })
        return page


def reset_console() -> None:
    with _lock:
        _state["console"] = []
        if _state["page"] is not None:
            # re-install fresh listener pointing at the new list
            _install_console_listener(_state["page"])


def get_console() -> List[Dict[str, Any]]:
    with _lock:
        return list(_state["console"])


def shutdown() -> None:
    with _lock:
        try:
            if _state["context"]:
                _state["context"].close()
            if _state["browser"]:
                _state["browser"].close()
            if _state["playwright"]:
                _state["playwright"].stop()
        except Exception:
            pass
        _state.update({
            "playwright": None,
            "browser": None,
            "context": None,
            "page": None,
            "console": [],
        })
