"""Terminal command execution tool.

Foreground + background, optional PTY, output cap, workdir override,
notify-on-complete, watch_patterns. Background processes are tracked
in :mod:`cvc.tools.process`.
"""

from __future__ import annotations

import asyncio
import os
import shlex
import subprocess
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import cap_output, resolve_path, strip_ansi
from cvc.tools.registry import registry
from cvc.tools._processes import register_process

SCHEMA = {
    "description": (
        "Execute a shell command. Foreground returns instantly when done. "
        "Set background=true to run long-lived processes; manage them via "
        "the `process` tool."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Shell command to execute."},
            "workdir": {"type": "string", "description": "Working directory (absolute)."},
            "timeout": {"type": "integer", "description": "Foreground timeout seconds (default 180, max 600).", "default": 180},
            "background": {"type": "boolean", "default": False},
            "pty": {"type": "boolean", "default": False, "description": "Allocate a PTY (interactive CLIs)."},
            "notify_on_complete": {"type": "boolean", "default": False},
            "watch_patterns": {
                "type": "array", "items": {"type": "string"},
                "description": "Strings to watch for in background output."
            },
        },
        "required": ["command"],
    },
}


def _handle_terminal(
    command: str,
    workdir: Optional[str] = None,
    timeout: int = 180,
    background: bool = False,
    pty: bool = False,
    notify_on_complete: bool = False,
    watch_patterns: Optional[List[str]] = None,
) -> Dict[str, Any]:
    if timeout > 600 and not background:
        return {"error": "Foreground timeout > 600s rejected — use background=true."}
    cwd = str(resolve_path(workdir)) if workdir else os.getcwd()

    if background:
        # Spawn detached, capture output to a temp pipe handled by the
        # process registry. PTY support deferred — flag is stored.
        proc = subprocess.Popen(
            command, shell=True, cwd=cwd,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1,
            start_new_session=True,
        )
        session_id = register_process(
            proc, command=command, cwd=cwd,
            notify_on_complete=notify_on_complete,
            watch_patterns=watch_patterns or [],
        )
        return {
            "session_id": session_id,
            "pid": proc.pid,
            "background": True,
            "command": command,
            "cwd": cwd,
        }

    try:
        completed = subprocess.run(
            command, shell=True, cwd=cwd,
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "error": f"Command timed out after {timeout}s",
            "stdout": cap_output(strip_ansi(exc.stdout or "")),
            "stderr": cap_output(strip_ansi(exc.stderr or "")),
            "exit_code": None,
        }
    out = strip_ansi(completed.stdout or "")
    err = strip_ansi(completed.stderr or "")
    return {
        "exit_code": completed.returncode,
        "stdout": cap_output(out),
        "stderr": cap_output(err),
        "cwd": cwd,
    }


registry.register(
    name="terminal",
    category="terminal",
    schema=SCHEMA,
    handler=_handle_terminal,
    emoji="💻",
    max_result_size_chars=100_000,
)
