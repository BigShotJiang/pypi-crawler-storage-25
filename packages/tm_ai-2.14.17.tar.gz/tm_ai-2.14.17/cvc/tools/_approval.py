"""Approval gate for dangerous operations.

Three modes:

* ``auto``  — never prompt (used in non-interactive runs / gateway / cron).
* ``ask``   — invoke the registered prompter callback (TUI hooks).
* ``deny``  — always refuse.

The default mode is ``ask`` when stdin is a TTY, else ``auto``.
"""

from __future__ import annotations

import os
import sys
from typing import Callable, Optional

_Mode = str  # "auto" | "ask" | "deny"

_prompter: Optional[Callable[[str], bool]] = None
_mode: _Mode = "ask" if sys.stdin.isatty() else "auto"


def set_prompter(fn: Optional[Callable[[str], bool]]) -> None:
    """Register a UI prompter — called with the question, returns bool."""
    global _prompter
    _prompter = fn


def set_mode(mode: _Mode) -> None:
    global _mode
    if mode not in {"auto", "ask", "deny"}:
        raise ValueError(f"Invalid approval mode: {mode}")
    _mode = mode


def get_mode() -> _Mode:
    env = os.environ.get("CVC_APPROVAL_MODE")
    return env if env in {"auto", "ask", "deny"} else _mode


def request_approval(question: str, *, default: bool = False) -> bool:
    """Return True if the operation is approved."""
    mode = get_mode()
    if mode == "auto":
        return True
    if mode == "deny":
        return False
    if _prompter is not None:
        try:
            return bool(_prompter(question))
        except Exception:
            return default
    # Fallback synchronous TTY prompt.
    if not sys.stdin.isatty():
        return default
    suffix = " [Y/n]: " if default else " [y/N]: "
    try:
        ans = input(question + suffix).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    if not ans:
        return default
    return ans in {"y", "yes"}


__all__ = ["set_prompter", "set_mode", "get_mode", "request_approval"]
