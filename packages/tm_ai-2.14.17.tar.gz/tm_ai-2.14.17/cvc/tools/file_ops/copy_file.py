"""copy_file — copy a file or directory tree."""

from __future__ import annotations

import shutil
from typing import Any, Dict

from cvc.tools._path_security import resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Copy a file or directory. Refuses to overwrite unless overwrite=true.",
    "parameters": {
        "type": "object",
        "properties": {
            "src": {"type": "string"},
            "dst": {"type": "string"},
            "overwrite": {"type": "boolean", "default": False},
        },
        "required": ["src", "dst"],
    },
}


def _handle_copy_file(src: str, dst: str, overwrite: bool = False) -> Dict[str, Any]:
    s = resolve_path(src)
    d = resolve_path(dst)
    if not s.exists():
        return {"error": f"Source not found: {s}"}
    if d.exists() and not overwrite:
        return {"error": f"Destination exists (set overwrite=true): {d}"}
    try:
        if s.is_dir():
            if d.exists() and overwrite:
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s, d)
    except OSError as exc:
        return {"error": str(exc)}
    return {"src": str(s), "dst": str(d), "ok": True}


registry.register(
    name="copy_file",
    category="file",
    schema=SCHEMA,
    handler=_handle_copy_file,
    emoji="📋",
)
