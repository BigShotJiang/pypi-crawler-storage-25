"""list_files — list directory contents with optional glob filter."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from cvc.tools._path_security import resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "List entries in a directory. Optional glob filter and recursion.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Directory path. Defaults to CWD."},
            "pattern": {"type": "string", "description": "Glob pattern (e.g. '*.py').", "default": "*"},
            "recursive": {"type": "boolean", "default": False},
            "limit": {"type": "integer", "default": 200},
            "show_hidden": {"type": "boolean", "default": False},
        },
        "required": [],
    },
}


def _handle_list_files(
    path: Optional[str] = None,
    pattern: str = "*",
    recursive: bool = False,
    limit: int = 200,
    show_hidden: bool = False,
) -> Dict[str, Any]:
    base = resolve_path(path) if path else Path(os.getcwd())
    if not base.exists():
        return {"error": f"Path not found: {base}"}
    if not base.is_dir():
        return {"error": f"Not a directory: {base}"}

    iterator = base.rglob(pattern) if recursive else base.glob(pattern)
    entries: List[Dict[str, Any]] = []
    for p in iterator:
        if not show_hidden and any(part.startswith(".") for part in p.relative_to(base).parts):
            continue
        try:
            stat = p.stat()
        except OSError:
            continue
        entries.append({
            "name": str(p.relative_to(base)),
            "type": "dir" if p.is_dir() else "file",
            "size": stat.st_size,
            "mtime": stat.st_mtime,
        })
        if len(entries) >= limit:
            break

    entries.sort(key=lambda e: (e["type"] != "dir", e["name"]))
    return {"path": str(base), "count": len(entries), "entries": entries}


registry.register(
    name="list_files",
    category="file",
    schema=SCHEMA,
    handler=_handle_list_files,
    emoji="📂",
    max_result_size_chars=50_000,
)
