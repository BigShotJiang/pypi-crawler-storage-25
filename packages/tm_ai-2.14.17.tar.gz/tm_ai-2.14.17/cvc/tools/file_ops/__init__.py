"""File operations toolset — list/info/copy/move/delete with sandbox-aware paths."""
