"""file_info — stat a file or directory."""

from __future__ import annotations

import hashlib
import os
import stat as stat_mod
from typing import Any, Dict

from cvc.tools._path_security import resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Return metadata for a file or directory: size, mtime, mode, sha256 (files only, opt-in).",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Path to inspect."},
            "hash": {"type": "boolean", "default": False, "description": "Compute SHA-256 (files only)."},
        },
        "required": ["path"],
    },
}


def _handle_file_info(path: str, hash: bool = False) -> Dict[str, Any]:
    p = resolve_path(path)
    if not p.exists():
        return {"error": f"Path not found: {p}"}
    st = p.stat()
    info: Dict[str, Any] = {
        "path": str(p),
        "type": "dir" if p.is_dir() else ("symlink" if p.is_symlink() else "file"),
        "size": st.st_size,
        "mtime": st.st_mtime,
        "ctime": st.st_ctime,
        "mode": stat_mod.filemode(st.st_mode),
        "owner_uid": st.st_uid,
        "exists": True,
    }
    if hash and p.is_file():
        h = hashlib.sha256()
        with p.open("rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        info["sha256"] = h.hexdigest()
    return info


registry.register(
    name="file_info",
    category="file",
    schema=SCHEMA,
    handler=_handle_file_info,
    emoji="ℹ️",
)
