"""move_file — rename or move a file/directory."""

from __future__ import annotations

import shutil
from typing import Any, Dict

from cvc.tools._path_security import resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Move (rename) a file or directory.",
    "parameters": {
        "type": "object",
        "properties": {
            "src": {"type": "string"},
            "dst": {"type": "string"},
            "overwrite": {"type": "boolean", "default": False},
        },
        "required": ["src", "dst"],
    },
}


def _handle_move_file(src: str, dst: str, overwrite: bool = False) -> Dict[str, Any]:
    s = resolve_path(src)
    d = resolve_path(dst)
    if not s.exists():
        return {"error": f"Source not found: {s}"}
    if d.exists() and not overwrite:
        return {"error": f"Destination exists (set overwrite=true): {d}"}
    try:
        if d.exists() and overwrite:
            if d.is_dir():
                shutil.rmtree(d)
            else:
                d.unlink()
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
    except OSError as exc:
        return {"error": str(exc)}
    return {"src": str(s), "dst": str(d), "ok": True}


registry.register(
    name="move_file",
    category="file",
    schema=SCHEMA,
    handler=_handle_move_file,
    emoji="🚚",
)
