"""delete_file — delete a file or directory tree."""

from __future__ import annotations

import shutil
from typing import Any, Dict

from cvc.tools._path_security import resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Delete a file or directory tree. Set recursive=true to remove non-empty directories.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "recursive": {"type": "boolean", "default": False},
            "missing_ok": {"type": "boolean", "default": True},
        },
        "required": ["path"],
    },
}


def _handle_delete_file(path: str, recursive: bool = False, missing_ok: bool = True) -> Dict[str, Any]:
    p = resolve_path(path)
    if not p.exists():
        if missing_ok:
            return {"path": str(p), "ok": True, "skipped": "not found"}
        return {"error": f"Path not found: {p}"}
    try:
        if p.is_dir():
            if not recursive:
                return {"error": f"Directory exists; pass recursive=true to delete: {p}"}
            shutil.rmtree(p)
        else:
            p.unlink()
    except OSError as exc:
        return {"error": str(exc)}
    return {"path": str(p), "ok": True}


registry.register(
    name="delete_file",
    category="file",
    schema=SCHEMA,
    handler=_handle_delete_file,
    emoji="🗑️",
)
