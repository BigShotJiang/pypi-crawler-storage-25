"""Search files via ripgrep — content + filename modes."""

from __future__ import annotations

import shutil
import subprocess
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import cap_output, resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Ripgrep-backed content/filename search.",
    "parameters": {
        "type": "object",
        "properties": {
            "pattern": {"type": "string"},
            "path": {"type": "string", "default": "."},
            "target": {"type": "string", "enum": ["content", "files"], "default": "content"},
            "output_mode": {"type": "string", "enum": ["content", "files_only", "count"], "default": "content"},
            "file_glob": {"type": "string"},
            "context": {"type": "integer", "default": 0},
            "limit": {"type": "integer", "default": 50},
            "offset": {"type": "integer", "default": 0},
        },
        "required": ["pattern"],
    },
}


def _have_rg() -> bool:
    return shutil.which("rg") is not None


def _handle_search(pattern: str, path: str = ".", target: str = "content",
                   output_mode: str = "content", file_glob: Optional[str] = None,
                   context: int = 0, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
    base = str(resolve_path(path))
    if target == "files":
        # File search by glob — fall back to Python pathlib if no rg.
        from pathlib import Path
        matches = list(Path(base).rglob(pattern))
        matches.sort(key=lambda p: -p.stat().st_mtime if p.exists() else 0)
        sliced = [str(m) for m in matches[offset:offset + limit]]
        return {"files": sliced, "total": len(matches)}

    if not _have_rg():
        return {"error": "ripgrep (rg) not installed; install via `brew install ripgrep`."}

    cmd = ["rg", "--no-heading", "--color=never"]
    if context:
        cmd += ["-C", str(context)]
    if file_glob:
        cmd += ["-g", file_glob]
    if output_mode == "files_only":
        cmd += ["-l"]
    elif output_mode == "count":
        cmd += ["-c"]
    else:
        cmd += ["-n"]
    cmd += [pattern, base]

    try:
        completed = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return {"error": "search timed out"}
    out = completed.stdout
    lines = out.splitlines()[offset:offset + limit]
    return {
        "matches": lines,
        "shown": len(lines),
        "exit_code": completed.returncode,
        "raw": cap_output("\n".join(lines)),
    }


registry.register(
    name="search_files",
    category="file",
    schema=SCHEMA,
    handler=_handle_search,
    emoji="🔎",
)
