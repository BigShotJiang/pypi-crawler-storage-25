"""Path security: tilde expansion + workspace sandboxing.

CVC tools should always route file paths through :func:`resolve_path`.
Behaviour:

* ``~`` is expanded to the user's home directory.
* Relative paths are resolved against the *workdir* argument or
  :func:`get_workspace_root` when not supplied.
* The resolved path may live anywhere on disk by default; pass
  ``sandbox=True`` to enforce that it remains inside the workspace.
* ``..`` traversal that escapes the sandbox raises :class:`PathSecurityError`.

The workspace root is auto-detected by walking up from CWD looking for
``.cvc/`` or ``.git/``. Override via the ``CVC_WORKSPACE`` env var.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


class PathSecurityError(PermissionError):
    """Raised when a tool tries to access a path outside the sandbox."""


def get_workspace_root(start: Optional[Path] = None) -> Path:
    """Return the workspace root (CVC_WORKSPACE > .cvc/.git > CWD)."""
    env = os.environ.get("CVC_WORKSPACE")
    if env:
        return Path(env).expanduser().resolve()
    cur = (start or Path.cwd()).resolve()
    for parent in (cur, *cur.parents):
        if (parent / ".cvc").is_dir() or (parent / ".git").exists():
            return parent
    return cur


def resolve_path(path: str | os.PathLike, *,
                 workdir: Optional[Path] = None,
                 sandbox: bool = False) -> Path:
    """Expand ``~``, resolve to absolute, optionally enforce sandbox."""
    p = Path(os.fspath(path)).expanduser()
    if not p.is_absolute():
        base = Path(workdir).expanduser().resolve() if workdir else Path.cwd().resolve()
        p = (base / p).resolve()
    else:
        p = p.resolve()
    if sandbox:
        root = get_workspace_root().resolve()
        try:
            p.relative_to(root)
        except ValueError as exc:
            raise PathSecurityError(
                f"Path '{p}' escapes workspace sandbox '{root}'"
            ) from exc
    return p


__all__ = ["PathSecurityError", "get_workspace_root", "resolve_path"]
