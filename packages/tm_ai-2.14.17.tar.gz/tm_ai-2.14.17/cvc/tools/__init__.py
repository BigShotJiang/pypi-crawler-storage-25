"""cvc.tools — modular tool registry (Slice 3).

Each tool module self-registers with :data:`cvc.tools.registry.registry`
at import time. :func:`discover_builtin_tools` walks this package and
imports every module that contains a top-level ``registry.register(...)``
call, mirroring the Hermes-Agent pattern but scoped to the CVC project.

Public surface:

    from cvc.tools import registry, discover_builtin_tools
    from cvc.tools.toolsets import resolve_toolset, get_all_toolsets

The legacy :mod:`cvc.agent.tools` monolith is kept for back-compat and
will be retired once all consumers route through this registry.
"""

from cvc.tools.registry import (  # noqa: F401  re-export
    Tool,
    ToolEntry,
    registry,
    register,
    get,
    list_all,
    list_by_category,
    discover_builtin_tools,
)

__all__ = [
    "Tool",
    "ToolEntry",
    "registry",
    "register",
    "get",
    "list_all",
    "list_by_category",
    "discover_builtin_tools",
]
