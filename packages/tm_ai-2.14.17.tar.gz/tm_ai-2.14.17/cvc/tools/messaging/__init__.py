"""Messaging gateway tools (Slice 7 will wire these to real platforms)."""
