"""send_message — outbound messaging stub.

Schema-only registration so the agent can plan around it; the real handler
lands in Slice 7 once the gateway is in place.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": (
        "Send a message to a chat platform (telegram, discord, slack, "
        "whatsapp, signal, email, sms, webhook, ...). Stub until the Slice "
        "7 gateway is online."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "platform": {"type": "string", "description": "Target platform identifier."},
            "chat_id": {"type": "string", "description": "Channel / chat / user id."},
            "text": {"type": "string", "description": "Message body."},
            "reply_to_message_id": {"type": ["string", "integer", "null"]},
            "media_path": {"type": "string", "description": "Optional local media to attach."},
            "metadata": {"type": "object", "description": "Platform-specific extras."},
        },
        "required": ["platform", "chat_id", "text"],
    },
}


def _handle_send_message(
    platform: str,
    chat_id: str,
    text: str,
    reply_to_message_id: Optional[Any] = None,
    media_path: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    raise NotImplementedError(
        "send_message is a Slice 3 schema stub — the messaging gateway lands "
        "in Slice 7. Args were: "
        f"platform={platform!r}, chat_id={chat_id!r}, "
        f"text_len={len(text)}, has_media={bool(media_path)}"
    )


registry.register(
    name="send_message",
    category="messaging",
    schema=SCHEMA,
    handler=_handle_send_message,
    emoji="✉️",
    requires_config=True,  # blocks invocation until Slice 7 wires it up
)
