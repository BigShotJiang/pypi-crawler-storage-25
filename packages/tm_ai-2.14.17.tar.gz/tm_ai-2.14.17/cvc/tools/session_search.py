"""Session search — FTS5 over the message archive.

Two modes: `query` (full-text) and `browse` (recent-first list). The
underlying SQLite DB lives at ``.cvc/sessions.db``; if it doesn't exist
yet the tool reports that gracefully rather than crashing.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import get_workspace_root
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Search past sessions via FTS5 (mode='query') or list recent (mode='browse').",
    "parameters": {
        "type": "object",
        "properties": {
            "mode": {"type": "string", "enum": ["query", "browse"], "default": "query"},
            "query": {"type": "string"},
            "limit": {"type": "integer", "default": 20},
        },
        "required": ["mode"],
    },
}


def _db_path() -> Path:
    return get_workspace_root() / ".cvc" / "sessions.db"


def _ensure_fts(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute(
            "CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5("
            "session_id, role, content, ts UNINDEXED)"
        )
        return True
    except sqlite3.OperationalError:
        return False


def _handle_session_search(mode: str, query: Optional[str] = None,
                           limit: int = 20) -> Dict[str, Any]:
    db = _db_path()
    if not db.exists():
        return {"results": [], "note": "No session archive at .cvc/sessions.db yet."}
    conn = sqlite3.connect(str(db))
    try:
        conn.row_factory = sqlite3.Row
        if not _ensure_fts(conn):
            return {"error": "FTS5 not available in this SQLite build"}
        if mode == "browse":
            cur = conn.execute(
                "SELECT session_id, role, substr(content, 1, 200) AS preview, ts "
                "FROM messages_fts ORDER BY ts DESC LIMIT ?", (limit,))
        else:
            if not query:
                return {"error": "query required for mode='query'"}
            cur = conn.execute(
                "SELECT session_id, role, substr(content, 1, 300) AS preview, ts "
                "FROM messages_fts WHERE messages_fts MATCH ? "
                "ORDER BY rank LIMIT ?", (query, limit))
        rows: List[Dict[str, Any]] = [dict(r) for r in cur.fetchall()]
        return {"results": rows, "count": len(rows)}
    finally:
        conn.close()


registry.register(
    name="session_search",
    category="memory",
    schema=SCHEMA,
    handler=_handle_session_search,
    emoji="🔍",
)
