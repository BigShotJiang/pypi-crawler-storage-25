"""Execute Python code with a `cvc_tools` shim that wraps common helpers.

Saves LLM round-trips by letting the model script multi-step file/terminal
work in a single tool call. Code runs in a subprocess to isolate failures.
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path
from typing import Any, Dict, Optional

from cvc.tools._helpers import cap_output, resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Run Python code with a built-in `cvc_tools` shim (read_file, write_file, search_files, patch, terminal helpers).",
    "parameters": {
        "type": "object",
        "properties": {
            "code": {"type": "string"},
            "timeout": {"type": "integer", "default": 60},
            "workdir": {"type": "string"},
        },
        "required": ["code"],
    },
}

_SHIM = textwrap.dedent(
    '''\
    class cvc_tools:
        @staticmethod
        def read_file(path):
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                return f.read()
        @staticmethod
        def write_file(path, content):
            import os
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
        @staticmethod
        def search_files(pattern, path="."):
            import subprocess
            return subprocess.run(["rg", "-n", pattern, path],
                                  capture_output=True, text=True).stdout
        @staticmethod
        def terminal(cmd, **kw):
            import subprocess
            return subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)
    '''
)


def _handle_execute_code(code: str, timeout: int = 60,
                         workdir: Optional[str] = None) -> Dict[str, Any]:
    cwd = str(resolve_path(workdir)) if workdir else None
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(_SHIM)
        f.write("\n")
        f.write(code)
        script = f.name
    try:
        completed = subprocess.run(
            [sys.executable, script], capture_output=True, text=True,
            timeout=timeout, cwd=cwd,
        )
    except subprocess.TimeoutExpired as e:
        return {"error": f"timed out after {timeout}s",
                "stdout": cap_output(e.stdout or ""), "stderr": cap_output(e.stderr or "")}
    finally:
        Path(script).unlink(missing_ok=True)
    return {
        "exit_code": completed.returncode,
        "stdout": cap_output(completed.stdout),
        "stderr": cap_output(completed.stderr),
    }


registry.register(
    name="execute_code",
    category="code",
    schema=SCHEMA,
    handler=_handle_execute_code,
    emoji="🐍",
)
