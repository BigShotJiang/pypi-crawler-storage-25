"""Cronjob tool — create/list/update/pause/resume/remove/run.

State is JSON in ``.cvc/cron.json`` — actual scheduling is handled
elsewhere (gateway scheduler / system cron). Supports `no_agent`
(plain script run) and `context_from` chaining for job pipelines.
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import get_workspace_root
from cvc.tools.registry import registry

_LOCK = threading.RLock()


def _store() -> Path:
    p = get_workspace_root() / ".cvc" / "cron.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text("[]", encoding="utf-8")
    return p


def _load() -> List[Dict[str, Any]]:
    try:
        return json.loads(_store().read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(items: List[Dict[str, Any]]) -> None:
    _store().write_text(json.dumps(items, indent=2), encoding="utf-8")


SCHEMA = {
    "description": "Manage scheduled jobs (cron-style). State stored in .cvc/cron.json.",
    "parameters": {
        "type": "object",
        "properties": {
            "action": {"type": "string",
                       "enum": ["create", "list", "update", "pause", "resume", "remove", "run"]},
            "id": {"type": "string"},
            "name": {"type": "string"},
            "schedule": {"type": "string", "description": "Cron expression."},
            "prompt": {"type": "string"},
            "script": {"type": "string", "description": "Shell command — used when no_agent=true."},
            "no_agent": {"type": "boolean", "default": False},
            "context_from": {"type": "string", "description": "Chain context from another job id."},
        },
        "required": ["action"],
    },
}


def _handle_cron(action: str, **kw: Any) -> Dict[str, Any]:
    with _LOCK:
        items = _load()
        if action == "list":
            return {"jobs": items}
        if action == "create":
            new = {
                "id": kw.get("id") or f"cron-{int(time.time()*1000)}",
                "name": kw.get("name", "job"),
                "schedule": kw.get("schedule", "0 * * * *"),
                "prompt": kw.get("prompt"),
                "script": kw.get("script"),
                "no_agent": bool(kw.get("no_agent", False)),
                "context_from": kw.get("context_from"),
                "paused": False,
                "created_at": time.time(),
            }
            items.append(new)
            _save(items)
            return {"created": new}
        # mutating actions need an id
        jid = kw.get("id")
        if not jid:
            return {"error": "id required"}
        for it in items:
            if it["id"] == jid:
                if action == "update":
                    for k in ("name", "schedule", "prompt", "script", "no_agent", "context_from"):
                        if k in kw and kw[k] is not None:
                            it[k] = kw[k]
                    _save(items)
                    return {"updated": it}
                if action == "pause":
                    it["paused"] = True
                    _save(items)
                    return {"paused": jid}
                if action == "resume":
                    it["paused"] = False
                    _save(items)
                    return {"resumed": jid}
                if action == "remove":
                    items.remove(it)
                    _save(items)
                    return {"removed": jid}
                if action == "run":
                    return {"kind": "run_now", "job": it,
                            "note": "Scheduler executes via cvc.daemon."}
        return {"error": f"job not found: {jid}"}


registry.register(
    name="cronjob",
    category="cron",
    schema=SCHEMA,
    handler=_handle_cron,
    emoji="⏰",
)
