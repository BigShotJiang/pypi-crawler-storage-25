"""Write-file tool — auto-creates parents, runs syntax check on .py/.json/.yaml."""

from __future__ import annotations

import ast
import json
from typing import Any, Dict

from cvc.tools._helpers import resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Write content to a file (overwrites). Creates parent dirs.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "content": {"type": "string"},
        },
        "required": ["path", "content"],
    },
}


def _syntax_check(p, content: str) -> str:
    suffix = p.suffix.lower()
    try:
        if suffix == ".py":
            ast.parse(content)
        elif suffix == ".json":
            json.loads(content)
        elif suffix in {".yaml", ".yml"}:
            try:
                import yaml  # type: ignore
                yaml.safe_load(content)
            except ImportError:
                return ""
    except Exception as e:
        return f"⚠ syntax check: {type(e).__name__}: {e}"
    return ""


def _handle_write_file(path: str, content: str) -> Dict[str, Any]:
    p = resolve_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        p.write_text(content, encoding="utf-8")
    except Exception as e:
        return {"error": f"Write failed: {e}"}
    warning = _syntax_check(p, content)
    return {
        "path": str(p),
        "bytes_written": len(content.encode("utf-8")),
        "lines": content.count("\n") + 1,
        "warning": warning or None,
    }


registry.register(
    name="write_file",
    category="file",
    schema=SCHEMA,
    handler=_handle_write_file,
    emoji="✍️",
)
