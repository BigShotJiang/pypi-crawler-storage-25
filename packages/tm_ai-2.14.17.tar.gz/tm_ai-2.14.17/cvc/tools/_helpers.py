"""Shared helpers for CVC tool implementations.

Bundles ANSI stripping, fuzzy matching strategies (9 of them, mirroring
Hermes' patch tool), JSON-Schema sanitiser, and a few smaller utilities.
The dedicated security / output / approval modules live alongside this
file (``_path_security``, ``_output_limits``, ``_approval``) and are
re-exported here for convenience.
"""

from __future__ import annotations

import difflib
import re
from typing import Any, Dict, List, Optional, Tuple

from cvc.tools._approval import request_approval, set_mode, set_prompter
from cvc.tools._output_limits import (
    DEFAULT_MAX_BYTES,
    cap_lines,
    cap_output,
)
from cvc.tools._path_security import (
    PathSecurityError,
    get_workspace_root,
    resolve_path,
)

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")


def strip_ansi(text: str) -> str:
    """Remove ANSI colour / cursor escape sequences."""
    return _ANSI_RE.sub("", text or "")


# ---------------------------------------------------------------------------
# Fuzzy match — 9 strategies, ordered by precision
# ---------------------------------------------------------------------------

def _strat_exact(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    idx = haystack.find(needle)
    return (idx, idx + len(needle)) if idx != -1 else None


def _strat_strip_trailing_ws(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    rstripped = "\n".join(line.rstrip() for line in needle.splitlines())
    h_norm = "\n".join(line.rstrip() for line in haystack.splitlines())
    idx = h_norm.find(rstripped)
    if idx == -1:
        return None
    # Re-anchor to the original haystack by line count.
    line_no = h_norm[:idx].count("\n")
    end_line_no = line_no + rstripped.count("\n") + 1
    lines = haystack.splitlines(keepends=True)
    start = sum(len(l) for l in lines[:line_no])
    end = sum(len(l) for l in lines[:end_line_no])
    return start, end


def _strat_collapse_ws(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    pattern = re.escape(needle).replace(r"\ ", r"\s+").replace(r"\t", r"\s+")
    pattern = re.sub(r"(\\\s\+){2,}", r"\\s+", pattern)
    m = re.search(pattern, haystack)
    return (m.start(), m.end()) if m else None


def _strat_ignore_indent(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    n_lines = [l.lstrip() for l in needle.splitlines()]
    h_lines = haystack.splitlines(keepends=True)
    h_stripped = [l.lstrip().rstrip("\n") for l in h_lines]
    for i in range(len(h_stripped) - len(n_lines) + 1):
        if h_stripped[i:i + len(n_lines)] == [l.rstrip() for l in n_lines]:
            start = sum(len(l) for l in h_lines[:i])
            end = sum(len(l) for l in h_lines[:i + len(n_lines)])
            return start, end
    return None


def _strat_normalize_quotes(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    table = str.maketrans({"\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"'})
    return _strat_exact(haystack.translate(table), needle.translate(table))


def _strat_normalize_eol(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    h = haystack.replace("\r\n", "\n").replace("\r", "\n")
    n = needle.replace("\r\n", "\n").replace("\r", "\n")
    return _strat_exact(h, n)


def _strat_first_last_line(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    n_lines = needle.splitlines()
    if len(n_lines) < 2:
        return None
    first, last = n_lines[0].strip(), n_lines[-1].strip()
    if not first or not last:
        return None
    h_lines = haystack.splitlines(keepends=True)
    starts = [i for i, l in enumerate(h_lines) if l.strip() == first]
    for s in starts:
        for e in range(s + 1, len(h_lines)):
            if h_lines[e].strip() == last:
                start = sum(len(l) for l in h_lines[:s])
                end = sum(len(l) for l in h_lines[:e + 1])
                return start, end
    return None


def _strat_difflib(haystack: str, needle: str, *, cutoff: float = 0.85) -> Optional[Tuple[int, int]]:
    matcher = difflib.SequenceMatcher(a=haystack, b=needle, autojunk=False)
    block = matcher.find_longest_match(0, len(haystack), 0, len(needle))
    if block.size == 0:
        return None
    ratio = matcher.ratio()
    if ratio < cutoff:
        return None
    return block.a, block.a + len(needle)


def _strat_substring_anchor(haystack: str, needle: str) -> Optional[Tuple[int, int]]:
    """Use the longest shared run as anchor, then expand to needle length."""
    n_stripped = needle.strip()
    if len(n_stripped) < 12:
        return None
    anchor = n_stripped[: max(20, len(n_stripped) // 3)]
    idx = haystack.find(anchor)
    if idx == -1:
        return None
    end = min(len(haystack), idx + len(needle))
    return idx, end


_FUZZY_STRATEGIES = (
    _strat_exact,
    _strat_normalize_eol,
    _strat_strip_trailing_ws,
    _strat_normalize_quotes,
    _strat_ignore_indent,
    _strat_collapse_ws,
    _strat_first_last_line,
    _strat_substring_anchor,
    _strat_difflib,
)


def fuzzy_find(haystack: str, needle: str) -> Optional[Tuple[int, int, str]]:
    """Run all 9 strategies, return ``(start, end, strategy_name)`` or None."""
    for strat in _FUZZY_STRATEGIES:
        try:
            res = strat(haystack, needle)
        except Exception:
            res = None
        if res is not None:
            return res[0], res[1], strat.__name__.lstrip("_")
    return None


# ---------------------------------------------------------------------------
# JSON Schema sanitiser — strips fields some providers reject
# ---------------------------------------------------------------------------

_DROP_KEYS = {"$schema", "$id", "$ref", "definitions", "$defs", "examples"}


def sanitize_schema(schema: Any) -> Any:
    """Return a copy of *schema* safe for OpenAI/Anthropic function calling."""
    if isinstance(schema, dict):
        out: Dict[str, Any] = {}
        for k, v in schema.items():
            if k in _DROP_KEYS:
                continue
            out[k] = sanitize_schema(v)
        return out
    if isinstance(schema, list):
        return [sanitize_schema(x) for x in schema]
    return schema


__all__ = [
    # Re-exports
    "PathSecurityError", "get_workspace_root", "resolve_path",
    "cap_output", "cap_lines", "DEFAULT_MAX_BYTES",
    "request_approval", "set_mode", "set_prompter",
    # Defined here
    "strip_ansi", "fuzzy_find", "sanitize_schema",
]
