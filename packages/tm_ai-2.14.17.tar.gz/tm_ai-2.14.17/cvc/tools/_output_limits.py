"""Stdout/stderr output limiter — 50KB cap with truncation marker."""

from __future__ import annotations

DEFAULT_MAX_BYTES = 50 * 1024  # 50 KB
TRUNCATION_MARKER = "\n\n[...output truncated: {dropped} bytes omitted of {total} total]"


def cap_output(text: str, max_bytes: int = DEFAULT_MAX_BYTES) -> str:
    """Cap *text* at *max_bytes* (UTF-8) and append a truncation marker if cut.

    Operates on bytes so multi-byte characters never produce mojibake; we
    decode with ``errors="ignore"`` to drop a partial trailing code-point.
    """
    if not text:
        return text
    encoded = text.encode("utf-8", errors="replace")
    if len(encoded) <= max_bytes:
        return text
    head = encoded[:max_bytes].decode("utf-8", errors="ignore")
    return head + TRUNCATION_MARKER.format(
        dropped=len(encoded) - max_bytes,
        total=len(encoded),
    )


def cap_lines(text: str, max_lines: int) -> str:
    """Cap *text* to *max_lines*, append a truncation marker if cut."""
    if not text:
        return text
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    kept = "\n".join(lines[:max_lines])
    return kept + f"\n\n[...truncated {len(lines) - max_lines} more lines]"


__all__ = ["cap_output", "cap_lines", "DEFAULT_MAX_BYTES", "TRUNCATION_MARKER"]
