"""Todo / task list with single in_progress enforcement and merge."""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import get_workspace_root
from cvc.tools.registry import registry

_LOCK = threading.RLock()
_VALID_STATES = {"pending", "in_progress", "completed", "blocked"}


def _store_path() -> Path:
    p = get_workspace_root() / ".cvc" / "todos.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _load() -> List[Dict[str, Any]]:
    p = _store_path()
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(items: List[Dict[str, Any]]) -> None:
    _store_path().write_text(json.dumps(items, indent=2), encoding="utf-8")


SCHEMA = {
    "description": "Read or write the todo list. Only one task may be in_progress at a time.",
    "parameters": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["read", "write", "merge"]},
            "items": {"type": "array", "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "content": {"type": "string"},
                    "status": {"type": "string", "enum": list(_VALID_STATES)},
                },
                "required": ["content"],
            }},
        },
        "required": ["action"],
    },
}


def _enforce_single_in_progress(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = False
    out = []
    for it in items:
        st = it.get("status", "pending")
        if st == "in_progress":
            if seen:
                it = {**it, "status": "pending"}
            seen = True
        out.append(it)
    return out


def _handle_todo(action: str, items: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    with _LOCK:
        if action == "read":
            return {"items": _load()}
        if not isinstance(items, list):
            return {"error": "items array required"}
        normalized = []
        for i, it in enumerate(items):
            normalized.append({
                "id": it.get("id") or f"t{i+1}",
                "content": it.get("content", ""),
                "status": it.get("status", "pending") if it.get("status") in _VALID_STATES else "pending",
            })
        if action == "write":
            normalized = _enforce_single_in_progress(normalized)
            _save(normalized)
            return {"items": normalized, "saved": len(normalized)}
        if action == "merge":
            existing = {it["id"]: it for it in _load()}
            for it in normalized:
                existing[it["id"]] = it
            merged = _enforce_single_in_progress(list(existing.values()))
            _save(merged)
            return {"items": merged, "saved": len(merged)}
    return {"error": f"unknown action: {action}"}


registry.register(
    name="todo",
    category="planning",
    schema=SCHEMA,
    handler=_handle_todo,
    emoji="✅",
)
