"""Background process registry — shared between `terminal` and `process` tools."""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class _ProcessHandle:
    session_id: str
    proc: object  # subprocess.Popen
    command: str
    cwd: str
    started_at: float
    notify_on_complete: bool = False
    watch_patterns: List[str] = field(default_factory=list)
    output_buffer: List[str] = field(default_factory=list)  # lines
    finished: bool = False
    exit_code: Optional[int] = None
    _reader_thread: Optional[threading.Thread] = None


_REGISTRY: Dict[str, _ProcessHandle] = {}
_LOCK = threading.RLock()


def register_process(proc, *, command: str, cwd: str,
                     notify_on_complete: bool = False,
                     watch_patterns: Optional[List[str]] = None) -> str:
    sid = uuid.uuid4().hex[:12]
    handle = _ProcessHandle(
        session_id=sid, proc=proc, command=command, cwd=cwd,
        started_at=time.time(),
        notify_on_complete=notify_on_complete,
        watch_patterns=list(watch_patterns or []),
    )
    with _LOCK:
        _REGISTRY[sid] = handle

    def _reader() -> None:
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                handle.output_buffer.append(line)
            handle.exit_code = proc.wait()
        except Exception:
            handle.exit_code = -1
        finally:
            handle.finished = True

    t = threading.Thread(target=_reader, daemon=True)
    handle._reader_thread = t
    t.start()
    return sid


def get_handle(sid: str) -> Optional[_ProcessHandle]:
    with _LOCK:
        return _REGISTRY.get(sid)


def list_handles() -> List[_ProcessHandle]:
    with _LOCK:
        return list(_REGISTRY.values())


def remove_handle(sid: str) -> None:
    with _LOCK:
        _REGISTRY.pop(sid, None)


__all__ = ["register_process", "get_handle", "list_handles", "remove_handle"]
