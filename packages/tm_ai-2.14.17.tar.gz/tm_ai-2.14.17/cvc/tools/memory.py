"""Persistent memory tool — user/memory targets, char-budget tracking."""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import get_workspace_root
from cvc.tools.registry import registry

_LOCK = threading.RLock()
_BUDGET_CHARS = 32_000


def _path(target: str) -> Path:
    base = get_workspace_root() / ".cvc" / "memory"
    base.mkdir(parents=True, exist_ok=True)
    name = "user.json" if target == "user" else "memory.json"
    return base / name


def _load(target: str) -> List[Dict[str, Any]]:
    p = _path(target)
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(target: str, items: List[Dict[str, Any]]) -> None:
    _path(target).write_text(json.dumps(items, indent=2), encoding="utf-8")


def _used_chars(items: List[Dict[str, Any]]) -> int:
    return sum(len(it.get("content", "")) for it in items)


SCHEMA = {
    "description": "Persistent memory: add/replace/remove × target=user|memory. char budget 32k.",
    "parameters": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["add", "replace", "remove", "list", "clear"]},
            "target": {"type": "string", "enum": ["user", "memory"], "default": "memory"},
            "id": {"type": "string"},
            "content": {"type": "string"},
        },
        "required": ["action"],
    },
}


def _handle_memory(action: str, target: str = "memory",
                   id: Optional[str] = None,
                   content: Optional[str] = None) -> Dict[str, Any]:
    with _LOCK:
        items = _load(target)
        if action == "list":
            return {"target": target, "items": items, "used": _used_chars(items), "budget": _BUDGET_CHARS}
        if action == "clear":
            _save(target, [])
            return {"cleared": True, "target": target}
        if action == "add":
            if not content:
                return {"error": "content required"}
            new = {"id": id or f"m{int(time.time()*1000)}", "content": content,
                   "ts": time.time()}
            items.append(new)
            if _used_chars(items) > _BUDGET_CHARS:
                return {"error": "budget exceeded; replace or remove existing entries first",
                        "used": _used_chars(items), "budget": _BUDGET_CHARS}
            _save(target, items)
            return {"added": new, "used": _used_chars(items)}
        if action == "replace":
            if not id or content is None:
                return {"error": "id + content required"}
            for it in items:
                if it.get("id") == id:
                    it["content"] = content
                    it["ts"] = time.time()
                    _save(target, items)
                    return {"replaced": id}
            return {"error": f"id not found: {id}"}
        if action == "remove":
            if not id:
                return {"error": "id required"}
            new_items = [it for it in items if it.get("id") != id]
            _save(target, new_items)
            return {"removed": id, "remaining": len(new_items)}
    return {"error": f"unknown action: {action}"}


registry.register(
    name="memory",
    category="planning",
    schema=SCHEMA,
    handler=_handle_memory,
    emoji="🧠",
)
