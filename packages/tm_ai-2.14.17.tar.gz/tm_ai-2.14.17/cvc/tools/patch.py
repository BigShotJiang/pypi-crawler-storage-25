"""Patch tool — replace mode + V4A patch mode + fuzzy match (9 strategies)."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import fuzzy_find, resolve_path
from cvc.tools.registry import registry

SCHEMA = {
    "description": (
        "Targeted edit. mode='replace' (default): unique find/replace with fuzzy "
        "match. mode='patch': V4A multi-file patch."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "mode": {"type": "string", "enum": ["replace", "patch"], "default": "replace"},
            "path": {"type": "string"},
            "old_string": {"type": "string"},
            "new_string": {"type": "string"},
            "replace_all": {"type": "boolean", "default": False},
            "patch": {"type": "string", "description": "V4A patch text (mode='patch')."},
        },
        "required": ["mode"],
    },
}


def _unified_diff(before: str, after: str, path: str) -> str:
    import difflib
    diff = difflib.unified_diff(
        before.splitlines(keepends=True),
        after.splitlines(keepends=True),
        fromfile=f"a/{path}", tofile=f"b/{path}", n=3,
    )
    return "".join(diff)


def _replace(path: str, old: str, new: str, replace_all: bool) -> Dict[str, Any]:
    p = resolve_path(path)
    if not p.exists():
        return {"error": f"File not found: {p}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    if replace_all:
        if old not in text:
            hit = fuzzy_find(text, old)
            if not hit:
                return {"error": "old_string not found (fuzzy: no match)"}
            return {"error": "replace_all requires literal matches; got fuzzy only"}
        new_text = text.replace(old, new)
        n = text.count(old)
    else:
        if text.count(old) == 1:
            new_text = text.replace(old, new, 1)
            n = 1
        elif old in text:
            return {"error": f"old_string not unique ({text.count(old)} matches); use replace_all=true"}
        else:
            hit = fuzzy_find(text, old)
            if not hit:
                return {"error": "old_string not found"}
            s, e, strat = hit
            new_text = text[:s] + new + text[e:]
            n = 1
    p.write_text(new_text, encoding="utf-8")
    return {
        "path": str(p),
        "replacements": n,
        "diff": _unified_diff(text, new_text, str(p))[:6000],
    }


_HUNK_RE = re.compile(r"^\*\*\*\s+Update File:\s*(.+)$")


def _apply_v4a_patch(patch_text: str) -> Dict[str, Any]:
    """Minimal V4A patch parser — Update/Add/Delete File ops."""
    files_touched: List[str] = []
    errors: List[str] = []
    cur_path: Optional[str] = None
    op = None
    buf: List[str] = []

    def _flush() -> None:
        nonlocal cur_path, op, buf
        if cur_path is None or op is None:
            buf = []
            return
        p = resolve_path(cur_path)
        try:
            if op == "delete":
                if p.exists():
                    p.unlink()
                files_touched.append(f"deleted:{cur_path}")
            elif op == "add":
                added = "\n".join(line[1:] if line.startswith("+") else line
                                  for line in buf if not line.startswith("***"))
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(added, encoding="utf-8")
                files_touched.append(f"added:{cur_path}")
            elif op == "update":
                if not p.exists():
                    errors.append(f"update: missing {cur_path}")
                    return
                original = p.read_text(encoding="utf-8")
                # Naive: collect '-' lines as old block, '+' lines as new block.
                old_block = "\n".join(l[1:] for l in buf if l.startswith("-"))
                new_block = "\n".join(l[1:] for l in buf if l.startswith("+"))
                if old_block and old_block in original:
                    updated = original.replace(old_block, new_block, 1)
                else:
                    hit = fuzzy_find(original, old_block) if old_block else None
                    if not hit:
                        errors.append(f"update: hunk not located in {cur_path}")
                        return
                    s, e, _ = hit
                    updated = original[:s] + new_block + original[e:]
                p.write_text(updated, encoding="utf-8")
                files_touched.append(f"updated:{cur_path}")
        except Exception as exc:
            errors.append(f"{op}:{cur_path}: {exc}")
        finally:
            buf = []

    for raw in patch_text.splitlines():
        m = _HUNK_RE.match(raw)
        if raw.startswith("*** Begin Patch") or raw.startswith("*** End Patch"):
            _flush()
            cur_path, op = None, None
            continue
        if m:
            _flush()
            cur_path = m.group(1).strip()
            op = "update"
            continue
        if raw.startswith("*** Add File:"):
            _flush()
            cur_path = raw[len("*** Add File:"):].strip()
            op = "add"
            continue
        if raw.startswith("*** Delete File:"):
            _flush()
            cur_path = raw[len("*** Delete File:"):].strip()
            op = "delete"
            continue
        buf.append(raw)
    _flush()
    return {"files": files_touched, "errors": errors}


def _handle_patch(mode: str = "replace",
                  path: Optional[str] = None,
                  old_string: Optional[str] = None,
                  new_string: Optional[str] = None,
                  replace_all: bool = False,
                  patch: Optional[str] = None) -> Dict[str, Any]:
    if mode == "replace":
        if not path or old_string is None or new_string is None:
            return {"error": "replace mode requires path + old_string + new_string"}
        return _replace(path, old_string, new_string, replace_all)
    if mode == "patch":
        if not patch:
            return {"error": "patch mode requires `patch`"}
        return _apply_v4a_patch(patch)
    return {"error": f"unknown mode: {mode}"}


registry.register(
    name="patch",
    category="file",
    schema=SCHEMA,
    handler=_handle_patch,
    emoji="🔧",
)
