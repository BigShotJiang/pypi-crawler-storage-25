"""Process management for background commands started by `terminal`."""

from __future__ import annotations

import os
import signal
import time
from typing import Any, Dict, List, Optional

from cvc.tools._helpers import cap_output, strip_ansi
from cvc.tools._processes import (
    get_handle,
    list_handles,
    remove_handle,
)
from cvc.tools.registry import registry

SCHEMA = {
    "description": "Manage background processes started with terminal(background=true).",
    "parameters": {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["list", "poll", "log", "wait", "kill", "write", "submit", "close"],
            },
            "session_id": {"type": "string"},
            "data": {"type": "string"},
            "timeout": {"type": "integer", "default": 60},
            "limit": {"type": "integer"},
            "offset": {"type": "integer"},
        },
        "required": ["action"],
    },
}


def _summary(h) -> Dict[str, Any]:
    return {
        "session_id": h.session_id,
        "pid": getattr(h.proc, "pid", None),
        "command": h.command,
        "cwd": h.cwd,
        "finished": h.finished,
        "exit_code": h.exit_code,
        "elapsed_sec": round(time.time() - h.started_at, 2),
        "lines_buffered": len(h.output_buffer),
    }


def _handle_process(action: str, session_id: Optional[str] = None,
                    data: Optional[str] = None, timeout: int = 60,
                    limit: Optional[int] = None, offset: Optional[int] = None) -> Any:
    if action == "list":
        return {"processes": [_summary(h) for h in list_handles()]}
    if not session_id:
        return {"error": "session_id required"}
    h = get_handle(session_id)
    if h is None:
        return {"error": f"unknown session_id: {session_id}"}

    if action == "poll":
        return _summary(h)
    if action == "log":
        lines = h.output_buffer
        if offset is not None:
            lines = lines[offset:]
        if limit is not None:
            lines = lines[-limit:] if limit < 0 else lines[:limit]
        return {
            "session_id": session_id,
            "log": cap_output(strip_ansi("".join(lines))),
            "finished": h.finished,
            "exit_code": h.exit_code,
        }
    if action == "wait":
        deadline = time.time() + max(1, timeout)
        while time.time() < deadline and not h.finished:
            time.sleep(0.2)
        return _summary(h)
    if action == "kill":
        try:
            os.killpg(os.getpgid(h.proc.pid), signal.SIGTERM)  # type: ignore[attr-defined]
        except Exception:
            try:
                h.proc.terminate()  # type: ignore[attr-defined]
            except Exception:
                pass
        return {"killed": True, "session_id": session_id}
    if action in ("write", "submit"):
        try:
            payload = (data or "")
            if action == "submit":
                payload += "\n"
            h.proc.stdin.write(payload)  # type: ignore[union-attr]
            h.proc.stdin.flush()  # type: ignore[union-attr]
        except Exception as e:
            return {"error": f"stdin write failed: {e}"}
        return {"written": len(payload), "session_id": session_id}
    if action == "close":
        try:
            h.proc.stdin.close()  # type: ignore[union-attr]
        except Exception:
            pass
        remove_handle(session_id)
        return {"closed": True, "session_id": session_id}
    return {"error": f"unknown action: {action}"}


registry.register(
    name="process",
    category="terminal",
    schema=SCHEMA,
    handler=_handle_process,
    emoji="🧩",
)
