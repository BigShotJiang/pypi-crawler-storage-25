"""Web extract tool — fetch a URL and return clean text content.

Prefers ``trafilatura`` (best-in-class boilerplate removal), falls back to
``beautifulsoup4`` + stdlib ``urllib`` if trafilatura isn't installed.
"""

from __future__ import annotations

from typing import Any, Dict

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Fetch a URL and extract the main text content (boilerplate removed).",
    "parameters": {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "Absolute http(s) URL."},
            "include_links": {"type": "boolean", "default": False},
            "max_chars": {"type": "integer", "default": 20000, "minimum": 500},
        },
        "required": ["url"],
    },
}


def _check_extract() -> bool:
    try:
        import trafilatura  # noqa: F401
        return True
    except Exception:
        try:
            import bs4  # noqa: F401
            return True
        except Exception:
            return False


def _fetch_with_trafilatura(url: str, include_links: bool) -> Dict[str, Any]:
    import trafilatura  # type: ignore
    downloaded = trafilatura.fetch_url(url)
    if not downloaded:
        return {"error": f"failed to fetch {url}"}
    text = trafilatura.extract(
        downloaded,
        include_links=include_links,
        include_comments=False,
        favor_recall=True,
    ) or ""
    meta = trafilatura.extract_metadata(downloaded)
    title = getattr(meta, "title", None) if meta else None
    return {"url": url, "title": title or "", "text": text, "extractor": "trafilatura"}


def _fetch_with_bs4(url: str) -> Dict[str, Any]:
    import urllib.request
    from bs4 import BeautifulSoup  # type: ignore

    req = urllib.request.Request(url, headers={"User-Agent": "cvc-web-extract/0.1"})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            html = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        return {"error": f"failed to fetch {url}: {exc}"}

    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    title = (soup.title.string or "").strip() if soup.title else ""
    text = "\n".join(line.strip() for line in soup.get_text("\n").splitlines() if line.strip())
    return {"url": url, "title": title, "text": text, "extractor": "beautifulsoup"}


def _handle_web_extract(url: str, include_links: bool = False,
                        max_chars: int = 20000) -> Dict[str, Any]:
    try:
        import trafilatura  # noqa: F401
        result = _fetch_with_trafilatura(url, include_links)
    except Exception:
        try:
            import bs4  # noqa: F401
        except Exception:
            return {
                "error": "no extractor available",
                "hint": "pip install trafilatura  # or: pip install beautifulsoup4",
            }
        result = _fetch_with_bs4(url)

    if "error" not in result and isinstance(result.get("text"), str):
        text = result["text"]
        if len(text) > max_chars:
            result["text"] = text[:max_chars] + f"\n…[truncated {len(text) - max_chars} chars]"
            result["truncated"] = True
    return result


registry.register(
    name="web_extract",
    category="web",
    schema=SCHEMA,
    handler=_handle_web_extract,
    check_fn=_check_extract,
    emoji="📄",
    max_result_size_chars=25_000,
)
