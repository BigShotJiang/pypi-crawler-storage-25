"""Web tools subpackage.

Currently ships :mod:`web_search` (DuckDuckGo via ``ddgs``) and
:mod:`web_extract` (``trafilatura`` with BeautifulSoup fallback).

TODO (Slice 4+): browser_open / browser_navigate / browser_screenshot via
Playwright. Skipped this slice — heavy dependency, requires headless
chromium install. Add when wiring agentic web automation.
"""
