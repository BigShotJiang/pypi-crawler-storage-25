"""Web search tool — DuckDuckGo via the ``ddgs`` library.

Lazy import: registry stays healthy even if ``ddgs`` isn't installed; the
handler returns a clear install hint instead of crashing at import time.
"""

from __future__ import annotations

from typing import Any, Dict, List

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Search the web via DuckDuckGo. Returns a list of {title, url, snippet}.",
    "parameters": {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query."},
            "max_results": {"type": "integer", "default": 10, "minimum": 1, "maximum": 50},
            "region": {"type": "string", "default": "wt-wt"},
        },
        "required": ["query"],
    },
}


def _check_ddgs() -> bool:
    try:
        import ddgs  # noqa: F401
        return True
    except Exception:
        try:
            import duckduckgo_search  # noqa: F401
            return True
        except Exception:
            return False


def _handle_web_search(query: str, max_results: int = 10,
                       region: str = "wt-wt") -> Dict[str, Any]:
    try:
        try:
            from ddgs import DDGS  # type: ignore
        except Exception:
            from duckduckgo_search import DDGS  # type: ignore
    except Exception:
        return {
            "error": "ddgs not installed",
            "hint": "pip install ddgs  # or: pip install duckduckgo-search",
        }

    results: List[Dict[str, str]] = []
    try:
        with DDGS() as ddgs_client:
            for r in ddgs_client.text(query, region=region, max_results=max_results):
                results.append({
                    "title": r.get("title", ""),
                    "url": r.get("href") or r.get("url", ""),
                    "snippet": r.get("body") or r.get("snippet", ""),
                })
    except Exception as exc:
        return {"error": f"search failed: {exc}", "results": []}

    return {"query": query, "count": len(results), "results": results}


registry.register(
    name="web_search",
    category="web",
    schema=SCHEMA,
    handler=_handle_web_search,
    check_fn=_check_ddgs,
    emoji="🔍",
    max_result_size_chars=20_000,
)
