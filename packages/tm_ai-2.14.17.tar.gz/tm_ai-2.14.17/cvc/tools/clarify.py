"""Clarify tool — multiple-choice or open-ended question to the user."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from cvc.tools.registry import registry

SCHEMA = {
    "description": "Ask the user a clarifying question. Choices optional (multi-choice if provided).",
    "parameters": {
        "type": "object",
        "properties": {
            "question": {"type": "string"},
            "choices": {"type": "array", "items": {"type": "string"}},
            "allow_multiple": {"type": "boolean", "default": False},
        },
        "required": ["question"],
    },
}


def _handle_clarify(question: str, choices: Optional[List[str]] = None,
                    allow_multiple: bool = False) -> Dict[str, Any]:
    # In the CVC pattern, the agent loop intercepts this and surfaces the
    # question to the platform UI. Here we just return the structured prompt.
    return {
        "kind": "clarify",
        "question": question,
        "choices": list(choices or []),
        "allow_multiple": allow_multiple,
    }


registry.register(
    name="clarify",
    category="ui",
    schema=SCHEMA,
    handler=_handle_clarify,
    emoji="❓",
)
