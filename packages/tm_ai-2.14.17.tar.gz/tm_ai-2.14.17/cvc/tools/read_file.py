"""Read-file tool with offset/limit + line numbers + binary detection."""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

from cvc.tools._helpers import cap_output, resolve_path
from cvc.tools.registry import registry

_BINARY_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico",
    ".pdf", ".zip", ".gz", ".tar", ".tgz", ".bz2", ".xz",
    ".so", ".dylib", ".dll", ".o", ".a", ".bin", ".class",
    ".mp3", ".mp4", ".mkv", ".mov", ".wav", ".ogg", ".flac",
    ".woff", ".woff2", ".ttf", ".otf",
}

SCHEMA = {
    "description": "Read a text file with line numbers and pagination. Output: 'LINE_NUM|CONTENT'.",
    "parameters": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "offset": {"type": "integer", "default": 1, "minimum": 1},
            "limit": {"type": "integer", "default": 500, "maximum": 2000},
        },
        "required": ["path"],
    },
}


def _is_binary(p) -> bool:
    if p.suffix.lower() in _BINARY_EXTS:
        return True
    try:
        with open(p, "rb") as f:
            chunk = f.read(2048)
        return b"\x00" in chunk
    except Exception:
        return False


def _handle_read_file(path: str, offset: int = 1, limit: int = 500) -> Dict[str, Any]:
    p = resolve_path(path)
    if not p.exists():
        return {"error": f"File not found: {p}"}
    if p.is_dir():
        return {"error": f"Is a directory: {p}"}
    if _is_binary(p):
        return {"error": f"Binary file: {p}. Use vision_analyze for images."}
    try:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except Exception as e:
        return {"error": f"Read failed: {e}"}
    total = len(lines)
    start = max(1, offset)
    end = min(total, start - 1 + max(1, limit))
    selected = lines[start - 1:end]
    body = "".join(f"{start + i:6d}|{line}" for i, line in enumerate(selected))
    return {
        "path": str(p),
        "total_lines": total,
        "showing": [start, end],
        "content": cap_output(body, 100_000),
    }


registry.register(
    name="read_file",
    category="file",
    schema=SCHEMA,
    handler=_handle_read_file,
    emoji="📖",
    max_result_size_chars=100_000,
)
