"""High-level FTS5 search wrapper for cvc.sessions.

Translates a user-friendly query string into a safe FTS5 MATCH expression.
Supports:

* ``"quoted phrases"`` — preserved as-is
* ``OR`` / ``NOT`` boolean operators (case-insensitive in input)
* ``prefix*`` wildcards
* Bare bareword terms — joined with implicit AND
"""

from __future__ import annotations

import re
import shlex
from typing import Sequence

from .db import SearchHit, SessionDB


_BOOLEAN_OPS = {"AND", "OR", "NOT"}
# An FTS5 "bareword" must be alphanumeric / underscore; everything else gets
# wrapped in double quotes so the parser doesn't choke on punctuation.
_BAREWORD_RE = re.compile(r"^[A-Za-z0-9_]+\*?$")


def _build_match(query: str) -> str:
    """Translate a user query into an FTS5 MATCH expression."""
    query = (query or "").strip()
    if not query:
        return ""

    try:
        tokens: Sequence[str] = shlex.split(query, posix=True)
    except ValueError:
        # Unclosed quote — fall back to whitespace split.
        tokens = query.split()

    out: list[str] = []
    for tok in tokens:
        if not tok:
            continue
        upper = tok.upper()
        if upper in _BOOLEAN_OPS:
            out.append(upper)
            continue
        if _BAREWORD_RE.match(tok):
            out.append(tok)
        else:
            # Escape embedded double quotes by doubling, FTS5 convention.
            safe = tok.replace('"', '""')
            out.append(f'"{safe}"')
    return " ".join(out)


def search(
    query: str,
    db: SessionDB | None = None,
    role_filter: str | None = None,
    limit: int = 10,
) -> list[SearchHit]:
    """Run a friendly full-text search across all stored messages."""
    match = _build_match(query)
    if not match:
        return []
    own = False
    if db is None:
        db = SessionDB()
        own = True
    try:
        return db.search(match, role_filter=role_filter, limit=limit)
    finally:
        if own:
            db.close()


def recent(limit: int = 20, db: SessionDB | None = None):
    """Convenience wrapper around :meth:`SessionDB.recent`."""
    own = False
    if db is None:
        db = SessionDB()
        own = True
    try:
        return db.recent(limit=limit)
    finally:
        if own:
            db.close()
