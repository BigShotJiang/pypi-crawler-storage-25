"""CVC sessions package — SQLite + FTS5 conversation store.

Public API:

* :class:`SessionDB`      — low-level store
* :class:`Session`        — session dataclass
* :class:`Message`        — message dataclass
* :class:`SearchHit`      — search result with snippet + score
* :func:`search_sessions` — high-level FTS5 search
* :func:`recent_sessions` — recently updated sessions
"""

from .db import DEFAULT_DB_PATH, Message, SearchHit, Session, SessionDB
from .search import recent as recent_sessions
from .search import search as search_sessions

__all__ = [
    "SessionDB",
    "Session",
    "Message",
    "SearchHit",
    "search_sessions",
    "recent_sessions",
    "DEFAULT_DB_PATH",
]
