"""SessionDB — SQLite + FTS5 backed conversation session store for CVC.

Mirrors the Hermes SessionDB design (see ~/.hermes/hermes-agent/hermes_state.py)
but lives entirely inside the CVC package. One database file at
``~/.cvc/sessions.db`` indexes every persisted session and message, with an
FTS5 virtual table for fast full-text search.
"""

from __future__ import annotations

import json
import os
import sqlite3
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable


DEFAULT_DB_PATH = Path.home() / ".cvc" / "sessions.db"


@dataclass
class Session:
    """A conversation session record."""

    id: str
    title: str = ""
    platform: str = "cvc"
    created_at: float = 0.0
    updated_at: float = 0.0
    message_count: int = 0
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Message:
    """A single message inside a session."""

    id: int
    session_id: str
    role: str
    content: str
    ts: float


@dataclass
class SearchHit:
    """A single full-text search hit with FTS5 snippet context."""

    session_id: str
    message_id: int
    role: str
    snippet: str
    ts: float
    score: float
    session_title: str = ""


class SessionDB:
    """SQLite-backed session store with FTS5 full-text search.

    Schema:
        sessions(id PK, title, platform, created_at, updated_at,
                 message_count, metadata JSON)
        messages(id PK AUTOINCREMENT, session_id FK, role, content, ts)
        messages_fts(content, session_id, role) -- FTS5 contentless-linked
                    via content='messages', content_rowid='id'
    """

    def __init__(self, db_path: str | os.PathLike | None = None) -> None:
        self.db_path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._init_schema()

    # ------------------------------------------------------------------ infra
    def _connect(self) -> sqlite3.Connection:
        if self._conn is None:
            conn = sqlite3.connect(
                str(self.db_path),
                check_same_thread=False,
                isolation_level=None,  # autocommit; we manage transactions
            )
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=5000")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA synchronous=NORMAL")
            self._conn = conn
        return self._conn

    def _init_schema(self) -> None:
        c = self._connect()
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id            TEXT PRIMARY KEY,
                title         TEXT NOT NULL DEFAULT '',
                platform      TEXT NOT NULL DEFAULT 'cvc',
                created_at    REAL NOT NULL,
                updated_at    REAL NOT NULL,
                message_count INTEGER NOT NULL DEFAULT 0,
                metadata      TEXT NOT NULL DEFAULT '{}'
            );

            CREATE INDEX IF NOT EXISTS idx_sessions_updated
                ON sessions(updated_at DESC);

            CREATE TABLE IF NOT EXISTS messages (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                role       TEXT NOT NULL,
                content    TEXT NOT NULL,
                ts         REAL NOT NULL,
                FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_messages_session
                ON messages(session_id, ts);

            CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
                content,
                session_id UNINDEXED,
                role UNINDEXED,
                content='messages',
                content_rowid='id',
                tokenize='unicode61'
            );

            -- Keep FTS in sync via triggers
            CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
                INSERT INTO messages_fts(rowid, content, session_id, role)
                VALUES (new.id, new.content, new.session_id, new.role);
            END;

            CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
                INSERT INTO messages_fts(messages_fts, rowid, content, session_id, role)
                VALUES ('delete', old.id, old.content, old.session_id, old.role);
            END;

            CREATE TRIGGER IF NOT EXISTS messages_au AFTER UPDATE ON messages BEGIN
                INSERT INTO messages_fts(messages_fts, rowid, content, session_id, role)
                VALUES ('delete', old.id, old.content, old.session_id, old.role);
                INSERT INTO messages_fts(rowid, content, session_id, role)
                VALUES (new.id, new.content, new.session_id, new.role);
            END;
            """
        )

    # ------------------------------------------------------------ public API
    def create_session(
        self,
        title: str = "",
        platform: str = "cvc",
        session_id: str | None = None,
        metadata: dict | None = None,
    ) -> Session:
        sid = session_id or uuid.uuid4().hex
        now = time.time()
        meta_json = json.dumps(metadata or {})
        c = self._connect()
        c.execute(
            "INSERT INTO sessions(id, title, platform, created_at, updated_at,"
            " message_count, metadata) VALUES(?,?,?,?,?,?,?)",
            (sid, title, platform, now, now, 0, meta_json),
        )
        return Session(
            id=sid,
            title=title,
            platform=platform,
            created_at=now,
            updated_at=now,
            message_count=0,
            metadata=metadata or {},
        )

    def append_message(
        self,
        session_id: str,
        role: str,
        content: str,
        ts: float | None = None,
    ) -> int:
        ts = ts if ts is not None else time.time()
        c = self._connect()
        cur = c.execute(
            "INSERT INTO messages(session_id, role, content, ts) VALUES(?,?,?,?)",
            (session_id, role, content, ts),
        )
        msg_id = cur.lastrowid
        c.execute(
            "UPDATE sessions SET message_count = message_count + 1,"
            " updated_at = ? WHERE id = ?",
            (ts, session_id),
        )
        return int(msg_id)

    def get_session(self, session_id: str) -> Session | None:
        c = self._connect()
        row = c.execute(
            "SELECT * FROM sessions WHERE id = ?", (session_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_session(row)

    def get_messages(
        self, session_id: str, limit: int | None = None
    ) -> list[Message]:
        c = self._connect()
        sql = "SELECT * FROM messages WHERE session_id = ? ORDER BY ts ASC, id ASC"
        params: tuple = (session_id,)
        if limit is not None:
            sql += " LIMIT ?"
            params = (session_id, int(limit))
        rows = c.execute(sql, params).fetchall()
        return [
            Message(
                id=r["id"],
                session_id=r["session_id"],
                role=r["role"],
                content=r["content"],
                ts=r["ts"],
            )
            for r in rows
        ]

    def recent(self, limit: int = 20) -> list[Session]:
        c = self._connect()
        rows = c.execute(
            "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT ?",
            (int(limit),),
        ).fetchall()
        return [self._row_to_session(r) for r in rows]

    def search(
        self,
        query: str,
        role_filter: str | None = None,
        limit: int = 10,
    ) -> list[SearchHit]:
        """Full-text search across message bodies.

        ``query`` is treated as a raw FTS5 MATCH expression. Use
        :func:`cvc.sessions.search.search` for a friendlier wrapper.
        """
        if not query or not query.strip():
            return []
        c = self._connect()
        sql = (
            "SELECT m.id AS mid, m.session_id AS sid, m.role AS role, m.ts AS ts,"
            " s.title AS title,"
            " snippet(messages_fts, 0, '[', ']', ' … ', 12) AS snip,"
            " bm25(messages_fts) AS score"
            " FROM messages_fts"
            " JOIN messages m ON m.id = messages_fts.rowid"
            " LEFT JOIN sessions s ON s.id = m.session_id"
            " WHERE messages_fts MATCH ?"
        )
        params: list[Any] = [query]
        if role_filter:
            sql += " AND m.role = ?"
            params.append(role_filter)
        sql += " ORDER BY score ASC LIMIT ?"
        params.append(int(limit))
        try:
            rows = c.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            # Malformed FTS query — return empty rather than raise.
            return []
        return [
            SearchHit(
                session_id=r["sid"],
                message_id=r["mid"],
                role=r["role"],
                snippet=r["snip"] or "",
                ts=r["ts"],
                # bm25 is "lower is better"; flip sign for an intuitive score.
                score=-float(r["score"]) if r["score"] is not None else 0.0,
                session_title=r["title"] or "",
            )
            for r in rows
        ]

    def delete_session(self, session_id: str) -> bool:
        c = self._connect()
        cur = c.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        # CASCADE handles messages; FTS triggers fire on the cascade deletes.
        return cur.rowcount > 0

    def update_title(self, session_id: str, title: str) -> bool:
        c = self._connect()
        cur = c.execute(
            "UPDATE sessions SET title = ?, updated_at = ? WHERE id = ?",
            (title, time.time(), session_id),
        )
        return cur.rowcount > 0

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _row_to_session(row: sqlite3.Row) -> Session:
        try:
            meta = json.loads(row["metadata"]) if row["metadata"] else {}
        except (TypeError, ValueError):
            meta = {}
        return Session(
            id=row["id"],
            title=row["title"] or "",
            platform=row["platform"] or "cvc",
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
            message_count=int(row["message_count"]),
            metadata=meta,
        )

    # Context manager sugar
    def __enter__(self) -> "SessionDB":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()
