"""
cvc.tui.render — Rich-based rendering helpers for the CVC TUI.

* Streaming markdown answers (token-by-token)
* Tool-call cards (collapsed by default; show name + arg summary + result preview)
* Code-fence syntax highlighting via Rich's Markdown
* Cost / token meter for the trailing turn
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from rich.console import Console, Group
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cvc.tui.banner import CVC_ACCENT, CVC_DIM, CVC_RED, CVC_RED_DEEP


# ---------------------------------------------------------------------------
# Streaming Markdown
# ---------------------------------------------------------------------------

class StreamingMarkdown:
    """Token-by-token markdown writer with a single Live region.

    Use as a context manager::

        with StreamingMarkdown(console) as stream:
            for chunk in provider.iter():
                stream.feed(chunk)
    """

    def __init__(self, console: Console, *, refresh_per_second: int = 24) -> None:
        self.console = console
        self._buf: list[str] = []
        self._live = Live(
            Markdown(""),
            console=console,
            refresh_per_second=refresh_per_second,
            transient=False,
            auto_refresh=True,
        )

    def __enter__(self) -> "StreamingMarkdown":
        self._live.__enter__()
        return self

    def __exit__(self, *exc: Any) -> None:
        # Final render with the full buffer (no transient — leave on screen).
        self._live.update(Markdown("".join(self._buf)), refresh=True)
        self._live.__exit__(*exc)

    def feed(self, chunk: str) -> None:
        if not chunk:
            return
        self._buf.append(chunk)
        self._live.update(Markdown("".join(self._buf)))

    @property
    def text(self) -> str:
        return "".join(self._buf)


def render_markdown(console: Console, text: str) -> None:
    """Print a complete markdown blob (non-streaming)."""
    if not text:
        return
    console.print(Markdown(text))


# ---------------------------------------------------------------------------
# Tool-call cards
# ---------------------------------------------------------------------------

@dataclass
class ToolCall:
    name: str
    args: dict | None = None
    result: Any = None
    duration_ms: float | None = None
    ok: bool = True


def _summarise_args(args: dict | None, max_len: int = 80) -> str:
    if not args:
        return ""
    try:
        s = json.dumps(args, ensure_ascii=False, default=str)
    except Exception:
        s = str(args)
    if len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s


def _summarise_result(result: Any, max_len: int = 240) -> str:
    if result is None:
        return ""
    if isinstance(result, (dict, list)):
        try:
            s = json.dumps(result, ensure_ascii=False, default=str)
        except Exception:
            s = str(result)
    else:
        s = str(result)
    s = s.strip()
    if len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s


def render_tool_call(console: Console, call: ToolCall, *, expanded: bool = False) -> None:
    """Render a tool invocation as a compact card.

    The default (collapsed) view is one line per call — name, arg summary,
    duration and a status glyph.  ``expanded=True`` adds the result block.
    """
    glyph = "✓" if call.ok else "✗"
    glyph_style = "bold #55AA55" if call.ok else f"bold {CVC_RED}"
    duration = f"  [dim]{call.duration_ms:.0f}ms[/]" if call.duration_ms is not None else ""

    head = Text.from_markup(
        f"[{glyph_style}]{glyph}[/]  "
        f"[bold {CVC_ACCENT}]{call.name}[/]"
        f"  [dim]{_summarise_args(call.args)}[/]"
        f"{duration}"
    )

    if not expanded:
        console.print(head)
        return

    body = Text(_summarise_result(call.result), style="dim")
    panel = Panel(
        Group(head, Text(""), body) if call.result is not None else head,
        border_style=CVC_RED_DEEP,
        padding=(0, 1),
        title=f"[dim {CVC_DIM}]tool[/]",
        title_align="left",
    )
    console.print(panel)


# ---------------------------------------------------------------------------
# Cost / token meter
# ---------------------------------------------------------------------------

def render_turn_meter(
    console: Console,
    *,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cost_usd: float | None = None,
    elapsed_s: float | None = None,
) -> None:
    parts = [
        f"[dim]in[/] [bold]{input_tokens:,}[/]",
        f"[dim]out[/] [bold]{output_tokens:,}[/]",
    ]
    if cost_usd is not None:
        parts.append(f"[dim]cost[/] [bold {CVC_RED}]${cost_usd:.4f}[/]")
    if elapsed_s is not None:
        parts.append(f"[dim]time[/] [bold]{elapsed_s:.2f}s[/]")
    console.print(
        Text.from_markup("  ".join(parts)),
        style=None,
        highlight=False,
        justify="right",
    )


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def info(console: Console, message: str) -> None:
    console.print(f"  [dim]→[/] {message}")


def warn(console: Console, message: str) -> None:
    console.print(f"  [bold #CCAA44]![/] {message}")


def error(console: Console, message: str) -> None:
    console.print(f"  [bold {CVC_RED}]✗[/] {message}")


def ok(console: Console, message: str) -> None:
    console.print(f"  [bold #55AA55]✓[/] {message}")


def render_kv_table(console: Console, title: str, rows: list[tuple[str, str]]) -> None:
    table = Table.grid(padding=(0, 2))
    table.add_column(style=f"bold {CVC_ACCENT}")
    table.add_column(style="white")
    for k, v in rows:
        table.add_row(k, v)
    console.print(Panel(table, title=f"[bold {CVC_RED}]{title}[/]", border_style=CVC_RED_DEEP, padding=(0, 1)))
