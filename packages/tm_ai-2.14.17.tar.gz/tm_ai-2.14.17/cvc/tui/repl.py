"""
cvc.tui.repl — prompt_toolkit input loop for the CVC TUI.

Features
--------
* Multi-line input — ``Enter`` submits, ``Alt+Enter`` inserts a newline.
* Persistent history at ``~/.cvc/history`` with ``Ctrl+R`` reverse search.
* Slash-command autocomplete with descriptions.
* Bottom-toolbar status line: model · provider · tokens · cost · branch · turn.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.styles import Style

from cvc.tui.slash import COMMANDS, command_names

if TYPE_CHECKING:  # pragma: no cover
    from cvc.tui.app import TUIState


HISTORY_PATH = Path.home() / ".cvc" / "history"


# ---------------------------------------------------------------------------
# Slash-command completer
# ---------------------------------------------------------------------------

class SlashCompleter(Completer):
    """Completes /commands when the input line starts with '/'."""

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        if not text.startswith("/"):
            return
        # Only complete the first token
        first = text.split(None, 1)[0]
        if " " in text:
            return  # past the command name
        prefix = first[1:].lower()
        for name in command_names():
            if name.startswith(prefix):
                cmd = COMMANDS[name]
                yield Completion(
                    name,
                    start_position=-len(prefix),
                    display=HTML(f"<b>/{name}</b>"),
                    display_meta=cmd.summary,
                )


# ---------------------------------------------------------------------------
# Key bindings
# ---------------------------------------------------------------------------

def _build_keybindings() -> KeyBindings:
    kb = KeyBindings()

    @kb.add("escape", "enter")  # Alt+Enter → newline
    def _(event):
        event.current_buffer.insert_text("\n")

    @kb.add("enter")
    def _(event):
        # Submit unless the line is in the middle of an unmatched fence
        buf = event.current_buffer
        text = buf.text
        # Multi-line content: only submit if cursor at end and last line not empty‑indent continuation.
        if text.count("```") % 2 == 1:
            buf.insert_text("\n")
            return
        buf.validate_and_handle()

    return kb


# ---------------------------------------------------------------------------
# Bottom toolbar (live status bar)
# ---------------------------------------------------------------------------

def _toolbar_factory(state: "TUIState"):
    def _toolbar():
        cost = f"${state.cost_usd:.4f}" if state.cost_usd else "$0.0000"
        return HTML(
            f" <b><style fg='#e63946'>CVC</style></b> "
            f" <style fg='#888'>model</style> <b>{state.model}</b>"
            f" <style fg='#888'>·</style> <style fg='#888'>provider</style> <b>{state.provider}</b>"
            f" <style fg='#888'>·</style> <style fg='#888'>tokens</style> <b>{state.tokens_in + state.tokens_out:,}</b>"
            f" <style fg='#888'>·</style> <style fg='#888'>cost</style> <b>{cost}</b>"
            f" <style fg='#888'>·</style> <style fg='#888'>branch</style> <b>{state.branch}</b>"
            f" <style fg='#888'>·</style> <style fg='#888'>turn</style> <b>{state.turn}</b>"
        )
    return _toolbar


# ---------------------------------------------------------------------------
# Public REPL session factory
# ---------------------------------------------------------------------------

def make_session(state: "TUIState") -> PromptSession:
    """Construct a configured :class:`PromptSession` bound to ``state``."""
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not HISTORY_PATH.exists():
        HISTORY_PATH.touch()

    style = Style.from_dict({
        "prompt":       "bold #e63946",
        "continuation": "#a4202c",
        "bottom-toolbar": "bg:#0d1b2a #cccccc",
        "bottom-toolbar.text": "#cccccc",
    })

    return PromptSession(
        history=FileHistory(str(HISTORY_PATH)),
        completer=SlashCompleter(),
        complete_while_typing=True,
        multiline=True,
        key_bindings=_build_keybindings(),
        bottom_toolbar=_toolbar_factory(state),
        style=style,
        enable_history_search=True,   # Ctrl+R reverse search
        mouse_support=False,
    )


def prompt_user(session: PromptSession) -> str:
    """Read one logical input line (or multi-line block) from the user."""
    return session.prompt(
        HTML("<style fg='#e63946'><b>cvc › </b></style>"),
    )
