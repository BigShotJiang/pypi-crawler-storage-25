"""
cvc.tui.banner — ASCII banner for the CVC interactive TUI.

Tries pyfiglet for a fresh "CVC" wordmark; falls back to a hand-tuned
ASCII art when pyfiglet isn't installed.  Theming uses the CVC palette:

* Primary       #e63946  (CVC-red)
* Accent        #4a9eff
* Background    #0d1b2a  (dark navy — emitted as styled bg only inside
                          the banner panel; we don't repaint the term.)
* Subtitle dim  #8B7070
"""

from __future__ import annotations

import random
from typing import Iterable

from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text


CVC_RED = "#e63946"
CVC_RED_DEEP = "#a4202c"
CVC_ACCENT = "#4a9eff"
CVC_BG = "#0d1b2a"
CVC_DIM = "#8B7070"


# Fallback art — same family as cvc/cli.py LOGO but tuned for the TUI banner.
_FALLBACK_ART = r"""
 ██████╗ ██╗   ██╗  ██████╗
██╔════╝ ██║   ██║ ██╔════╝
██║      ██║   ██║ ██║
██║      ╚██╗ ██╔╝ ██║
╚██████╗  ╚████╔╝  ╚██████╗
 ╚═════╝   ╚═══╝    ╚═════╝
""".strip("\n")


_BOOT_TIPS: tuple[str, ...] = (
    "Tip: type /help to see every slash command.",
    "Tip: alt+enter inserts a newline; enter submits.",
    "Tip: ctrl+r searches your history fuzzily.",
    "Tip: /branch <name> forks the cognitive timeline.",
    "Tip: /compact trims the context without losing decisions.",
    "Tip: /commits shows the last 10 cognitive checkpoints.",
    "Tip: /tools lists every tool the agent can reach.",
    "Tip: /save exports the session as portable Markdown.",
    "Tip: /model and /provider hot-swap the backend mid-session.",
)


def _figlet(text: str) -> str:
    """Render ``text`` with pyfiglet if installed, else return fallback."""
    try:
        import pyfiglet  # type: ignore
    except Exception:
        return _FALLBACK_ART
    try:
        return pyfiglet.figlet_format(text, font="ansi_shadow").rstrip("\n")
    except Exception:
        try:
            return pyfiglet.figlet_format(text, font="standard").rstrip("\n")
        except Exception:
            return _FALLBACK_ART


def _gradient_lines(art: str, colors: Iterable[str]) -> Text:
    """Apply a top-to-bottom gradient across the lines of ``art``."""
    lines = art.splitlines() or [""]
    palette = list(colors) or [CVC_RED]
    out = Text()
    for i, line in enumerate(lines):
        # spread palette across lines
        if len(lines) == 1:
            color = palette[0]
        else:
            idx = int(round(i * (len(palette) - 1) / max(1, len(lines) - 1)))
            color = palette[idx]
        out.append(line + ("\n" if i < len(lines) - 1 else ""), style=f"bold {color}")
    return out


def render_banner(
    console: Console,
    *,
    version: str = "",
    subtitle: str | None = None,
    tip: str | None = None,
) -> None:
    """Print the CVC TUI banner.

    Parameters
    ----------
    console:
        Rich console to print into.
    version:
        Version string for the panel subtitle (e.g. ``"v2.6.0"``).
    subtitle:
        Optional override for the tagline shown beneath the wordmark.
    tip:
        Optional override for the boot tip; defaults to a random pick.
    """
    art = _figlet("CVC")
    gradient = (CVC_RED, CVC_RED, CVC_RED_DEEP)
    body = _gradient_lines(art, gradient)

    tagline = subtitle or "Cognitive Version Control — Git for the AI Mind"
    chosen_tip = tip if tip is not None else random.choice(_BOOT_TIPS)

    inner = Text()
    inner.append("\n")
    inner.append_text(Align.center(body, width=console.width - 4).renderable if False else body)
    inner.append("\n\n")
    inner.append(tagline, style=f"italic {CVC_DIM}")
    if chosen_tip:
        inner.append("\n")
        inner.append(chosen_tip, style=f"dim {CVC_ACCENT}")

    panel = Panel(
        Align.center(inner),
        border_style=CVC_RED_DEEP,
        padding=(1, 4),
        title=f"[bold {CVC_RED}]CVC TUI[/]" + (f"  [dim]{version}[/]" if version else ""),
        title_align="left",
        subtitle="[dim]press ? for help · /exit to quit[/]",
        subtitle_align="right",
    )
    console.print(panel)
