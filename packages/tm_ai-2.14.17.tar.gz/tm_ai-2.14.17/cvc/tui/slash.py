"""
cvc.tui.slash — slash command registry & handlers for the CVC TUI.

Each handler takes the live :class:`cvc.tui.app.TUIState` and the rest of
the user's command line (string) and returns either ``None`` (continue),
``"exit"`` (terminate the REPL), or ``"new"`` (start a fresh session).

Commands are intentionally fast & local — no network round-trips beyond
asking the running gateway, when one is available.
"""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from cvc.tui.render import error, info, ok, render_kv_table, warn

if TYPE_CHECKING:  # pragma: no cover
    from cvc.tui.app import TUIState

# Return codes from a slash handler
SlashResult = Optional[str]   # None | "exit" | "new" | "clear"


@dataclass(frozen=True)
class SlashCommand:
    name: str            # canonical name (without leading slash)
    summary: str
    handler: Callable[["TUIState", str], SlashResult]
    aliases: tuple[str, ...] = ()
    usage: str = ""


# ---------------------------------------------------------------------------
# Individual handlers
# ---------------------------------------------------------------------------

def _cmd_help(state: "TUIState", _args: str) -> SlashResult:
    rows: list[tuple[str, str]] = []
    seen: set[str] = set()
    for cmd in COMMANDS.values():
        if cmd.name in seen:
            continue
        seen.add(cmd.name)
        label = "/" + cmd.name
        if cmd.aliases:
            label += "  (" + ", ".join("/" + a for a in cmd.aliases) + ")"
        rows.append((label, cmd.summary))
    render_kv_table(state.console, "Slash commands", rows)
    return None


def _cmd_exit(_state: "TUIState", _args: str) -> SlashResult:
    return "exit"


def _cmd_clear(state: "TUIState", _args: str) -> SlashResult:
    state.console.clear()
    return "clear"


def _cmd_new(state: "TUIState", _args: str) -> SlashResult:
    state.reset_session()
    ok(state.console, "Started a new session.")
    return "new"


def _cmd_model(state: "TUIState", args: str) -> SlashResult:
    name = args.strip()
    if not name:
        info(state.console, f"Current model: [bold]{state.model}[/]")
        return None
    state.model = name
    ok(state.console, f"Model set to [bold]{name}[/].")
    return None


def _cmd_provider(state: "TUIState", args: str) -> SlashResult:
    name = args.strip()
    if not name:
        info(state.console, f"Current provider: [bold]{state.provider}[/]")
        return None
    state.provider = name
    ok(state.console, f"Provider set to [bold]{name}[/].")
    return None


def _cmd_tools(state: "TUIState", _args: str) -> SlashResult:
    tools = state.list_tools()
    if not tools:
        warn(state.console, "No tools registered (agent backend not initialised).")
        return None
    rows = [(t["name"], t.get("description", "")[:80]) for t in tools]
    render_kv_table(state.console, f"Tools ({len(tools)})", rows)
    return None


def _cmd_skills(state: "TUIState", _args: str) -> SlashResult:
    skills = state.list_skills()
    if not skills:
        info(state.console, "No skills loaded. Pass --skills name1,name2 at boot to preload.")
        return None
    rows = [(s["name"], s.get("description", "")[:80]) for s in skills]
    render_kv_table(state.console, f"Skills ({len(skills)})", rows)
    return None


def _cmd_toolsets(state: "TUIState", args: str) -> SlashResult:
    name = args.strip()
    if not name:
        active = ", ".join(state.toolsets) if state.toolsets else "(default)"
        info(state.console, f"Active toolsets: [bold]{active}[/]")
        info(state.console, "Switch with: [bold]/toolsets web,terminal[/]")
        return None
    state.toolsets = [t.strip() for t in name.split(",") if t.strip()]
    ok(state.console, f"Toolsets set to: [bold]{', '.join(state.toolsets)}[/]")
    return None


def _cmd_memory(state: "TUIState", _args: str) -> SlashResult:
    try:
        from cvc.core.database import ContextDatabase
        from cvc.core.models import CVCConfig
        cfg = CVCConfig.for_project()
        db = ContextDatabase(cfg)
        # Summarise: count of stored contexts + last commit hash
        rows = [
            ("workspace", str(cfg.project_root)),
            ("storage", str(cfg.storage_root)),
        ]
        try:
            recent = db.list_recent(limit=1)  # type: ignore[attr-defined]
            if recent:
                rows.append(("last commit", str(recent[0])[:80]))
        except Exception:
            pass
        render_kv_table(state.console, "Memory", rows)
    except Exception as exc:
        error(state.console, f"Could not read memory: {exc}")
    return None


def _cmd_todo(state: "TUIState", _args: str) -> SlashResult:
    # CVC's task manager (if present)
    try:
        from cvc.agent.task_manager import TaskManager  # type: ignore
        tm = TaskManager()
        items = list(getattr(tm, "list_tasks", lambda: [])())
        if not items:
            info(state.console, "No active todos.")
            return None
        rows = [(str(getattr(t, "id", i)), str(getattr(t, "title", t))) for i, t in enumerate(items)]
        render_kv_table(state.console, "Todos", rows)
    except Exception:
        info(state.console, "No todo backend wired in this session.")
    return None


def _cmd_cron(state: "TUIState", _args: str) -> SlashResult:
    # Simple inspector: list scheduled jobs from ~/.cvc/cron.json if present.
    cron_file = Path.home() / ".cvc" / "cron.json"
    if not cron_file.exists():
        info(state.console, "No cron file at ~/.cvc/cron.json")
        return None
    try:
        data = json.loads(cron_file.read_text())
        jobs = data.get("jobs", []) if isinstance(data, dict) else data
        if not jobs:
            info(state.console, "No cron jobs scheduled.")
            return None
        rows = [(str(j.get("schedule", "?")), str(j.get("command", j))) for j in jobs]
        render_kv_table(state.console, f"Cron jobs ({len(jobs)})", rows)
    except Exception as exc:
        error(state.console, f"Could not parse cron file: {exc}")
    return None


def _vcs_engine():
    from cvc.core.database import ContextDatabase
    from cvc.core.models import CVCConfig
    from cvc.operations.engine import CVCEngine
    cfg = CVCConfig.for_project()
    cfg.ensure_dirs()
    db = ContextDatabase(cfg)
    return CVCEngine(cfg, db), db, cfg


def _cmd_branch(state: "TUIState", args: str) -> SlashResult:
    name = args.strip()
    try:
        engine, _db, cfg = _vcs_engine()
    except Exception as exc:
        error(state.console, f"VCS unavailable: {exc}")
        return None

    if not name:
        try:
            current = getattr(engine, "current_branch", None) or getattr(cfg, "active_branch", "main")
            info(state.console, f"Current branch: [bold]{current}[/]")
            branches = getattr(engine, "list_branches", lambda: [])()
            if branches:
                info(state.console, "Branches: " + ", ".join(branches))
        except Exception as exc:
            error(state.console, f"Could not read branch state: {exc}")
        return None

    try:
        if hasattr(engine, "create_branch"):
            engine.create_branch(name)
        elif hasattr(engine, "branch"):
            engine.branch(name)
        ok(state.console, f"Created/switched to branch [bold]{name}[/].")
        state.branch = name
    except Exception as exc:
        error(state.console, f"Could not create branch: {exc}")
    return None


def _cmd_commits(state: "TUIState", args: str) -> SlashResult:
    limit = 10
    a = args.strip()
    if a.isdigit():
        limit = max(1, min(int(a), 100))
    try:
        engine, _db, _cfg = _vcs_engine()
    except Exception as exc:
        error(state.console, f"VCS unavailable: {exc}")
        return None
    try:
        commits = getattr(engine, "list_commits", lambda **_k: [])(limit=limit)
        if not commits:
            info(state.console, "No commits yet.")
            return None
        rows = []
        for c in commits[:limit]:
            h = str(getattr(c, "hash", c.get("hash", "?") if isinstance(c, dict) else "?"))[:10]
            msg = str(getattr(c, "message", c.get("message", "") if isinstance(c, dict) else ""))[:80]
            rows.append((h, msg))
        render_kv_table(state.console, f"Commits ({len(rows)})", rows)
    except Exception as exc:
        error(state.console, f"Could not list commits: {exc}")
    return None


def _cmd_compact(state: "TUIState", _args: str) -> SlashResult:
    # Hook into chat session compaction if available; otherwise just report.
    try:
        if state.session is not None and hasattr(state.session, "compact"):
            before = len(getattr(state.session, "messages", []) or [])
            state.session.compact()
            after = len(getattr(state.session, "messages", []) or [])
            ok(state.console, f"Compacted context: {before} → {after} messages.")
        else:
            info(state.console, "No live session to compact.")
    except Exception as exc:
        error(state.console, f"Compact failed: {exc}")
    return None


def _cmd_save(state: "TUIState", args: str) -> SlashResult:
    target = args.strip() or f"cvc-session-{int(time.time())}.md"
    path = Path(target).expanduser().resolve()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        lines = ["# CVC session export", "",
                 f"_model_: `{state.model}`  ·  _provider_: `{state.provider}`  ·  _branch_: `{state.branch}`", ""]
        for turn in state.history_log:
            role = turn.get("role", "user")
            content = turn.get("content", "")
            lines.append(f"## {role}")
            lines.append("")
            lines.append(content)
            lines.append("")
        path.write_text("\n".join(lines), encoding="utf-8")
        ok(state.console, f"Session saved to [bold]{path}[/]")
    except Exception as exc:
        error(state.console, f"Save failed: {exc}")
    return None


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

def _build_registry() -> dict[str, SlashCommand]:
    defs: list[SlashCommand] = [
        SlashCommand("help",     "List all slash commands.",                     _cmd_help,     aliases=("?",)),
        SlashCommand("tools",    "List available tools.",                        _cmd_tools),
        SlashCommand("skills",   "List loaded skills.",                          _cmd_skills),
        SlashCommand("toolsets", "List or switch active toolsets.",              _cmd_toolsets, usage="/toolsets web,terminal"),
        SlashCommand("model",    "Show or switch the active model.",             _cmd_model,    usage="/model claude-sonnet-4.6"),
        SlashCommand("provider", "Show or switch the active provider.",          _cmd_provider, usage="/provider anthropic"),
        SlashCommand("memory",   "Inspect CVC memory state.",                    _cmd_memory),
        SlashCommand("todo",     "List current todos.",                          _cmd_todo),
        SlashCommand("cron",     "List scheduled cron jobs.",                    _cmd_cron),
        SlashCommand("branch",   "Show or create a CVC branch.",                 _cmd_branch,   usage="/branch <name>"),
        SlashCommand("commits",  "Show recent CVC commits (last 10).",           _cmd_commits),
        SlashCommand("compact",  "Compact the active context window.",           _cmd_compact),
        SlashCommand("clear",    "Clear the screen, keep the session.",          _cmd_clear),
        SlashCommand("new",      "Start a fresh session in this REPL.",          _cmd_new),
        SlashCommand("save",     "Export the session as Markdown.",              _cmd_save,     usage="/save [path]"),
        SlashCommand("exit",     "Exit the CVC TUI.",                            _cmd_exit,     aliases=("quit", "q")),
    ]
    table: dict[str, SlashCommand] = {}
    for cmd in defs:
        table[cmd.name] = cmd
        for alias in cmd.aliases:
            table[alias] = cmd
    return table


COMMANDS: dict[str, SlashCommand] = _build_registry()


def dispatch(state: "TUIState", line: str) -> SlashResult:
    """Dispatch ``line`` (which must start with '/') against the registry."""
    body = line.strip()
    if not body.startswith("/"):
        return None
    parts = body[1:].split(None, 1)
    if not parts:
        return None
    name = parts[0].lower()
    rest = parts[1] if len(parts) > 1 else ""
    cmd = COMMANDS.get(name)
    if cmd is None:
        error(state.console, f"Unknown command: /{name}  (try /help)")
        return None
    try:
        return cmd.handler(state, rest)
    except Exception as exc:  # pragma: no cover — last-ditch guard
        error(state.console, f"/{name} crashed: {exc}")
        return None


def command_names() -> list[str]:
    """Stable list of canonical (non-alias) command names for completion."""
    seen: set[str] = set()
    out: list[str] = []
    for cmd in COMMANDS.values():
        if cmd.name in seen:
            continue
        seen.add(cmd.name)
        out.append(cmd.name)
    return out
