"""
cvc.tui — Hermes-grade interactive Terminal User Interface for CVC.

Slice 1 deliverable. Provides:

* Polished ASCII banner + status bar
* prompt_toolkit-based REPL with multi-line input, history, autocomplete
* Slash command dispatcher (/help, /tools, /branch, /commits, /compact, ...)
* rich-based markdown + tool-call rendering
* Bridges into ``cvc.agent.chat`` (in-process) or the running ``cvc.gateway``

Public entry point: :func:`cvc.tui.app.run`.
"""

from __future__ import annotations

from cvc.tui.app import run  # re-exported for ``cvc.tui.run`` shorthand

__all__ = ["run"]
