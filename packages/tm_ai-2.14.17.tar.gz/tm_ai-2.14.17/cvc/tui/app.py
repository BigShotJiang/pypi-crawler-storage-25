"""
cvc.tui.app — main entry point for the CVC interactive TUI.

The TUI is a thin orchestration layer:

1. Bootstraps config (creates ``~/.cvc/config.yaml`` if missing).
2. Probes for a running gateway on ``http://127.0.0.1:13421``; if present,
   chats route through it. Otherwise we lazily spawn an in-process agent.
3. Drives a prompt_toolkit REPL with slash-command dispatch and rich render.

The agent backend integration is intentionally late-bound — slice 1 is
about the *shell*; turning user prose into a real agent run will be wired
up in slice 2 once the gateway streaming protocol is finalised.
"""

from __future__ import annotations

import os
import sys
import textwrap
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from rich.console import Console

from cvc.tui.banner import CVC_ACCENT, CVC_DIM, CVC_RED, render_banner
from cvc.tui.render import error, info, render_markdown, render_turn_meter, warn
from cvc.tui.repl import make_session, prompt_user
from cvc.tui.slash import dispatch as slash_dispatch


GATEWAY_URL = "http://127.0.0.1:13421"
CONFIG_PATH = Path.home() / ".cvc" / "config.yaml"

DEFAULT_CONFIG = textwrap.dedent("""\
    # CVC TUI configuration (auto-generated).
    # Edit freely — values here become defaults for the `cvc` command.
    model: claude-sonnet-4-6
    provider: anthropic
    toolsets: []          # e.g. [web, terminal]
    skills: []            # e.g. [hermes-agent, my-skill]
    show_banner: true
""")


# ---------------------------------------------------------------------------
# State container
# ---------------------------------------------------------------------------

@dataclass
class TUIState:
    console: Console
    model: str = "claude-sonnet-4-6"
    provider: str = "anthropic"
    branch: str = "main"
    toolsets: list[str] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    turn: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    gateway_alive: bool = False
    session: Any = None              # in-process AgentSession, lazily created
    history_log: list[dict] = field(default_factory=list)  # [{role, content}, ...]

    def reset_session(self) -> None:
        self.turn = 0
        self.tokens_in = 0
        self.tokens_out = 0
        self.cost_usd = 0.0
        self.session = None
        self.history_log.clear()

    # ------- backend probes (kept defensive — TUI must boot even if not wired) -------

    def list_tools(self) -> list[dict]:
        if self.gateway_alive:
            try:
                r = httpx.get(f"{GATEWAY_URL}/v1/tools", timeout=2.0)
                if r.status_code == 200:
                    payload = r.json()
                    if isinstance(payload, dict) and "tools" in payload:
                        return list(payload["tools"])
                    if isinstance(payload, list):
                        return payload
            except Exception:
                pass
        # Fallback: try CVC's internal registry
        try:
            from cvc.agent import tools as agent_tools  # type: ignore
            reg = getattr(agent_tools, "TOOL_REGISTRY", None) or getattr(agent_tools, "REGISTRY", None)
            if isinstance(reg, dict):
                return [{"name": k, "description": getattr(v, "__doc__", "") or ""} for k, v in reg.items()]
        except Exception:
            pass
        return []

    def list_skills(self) -> list[dict]:
        try:
            from cvc.agent import skills as agent_skills  # type: ignore
            fn = getattr(agent_skills, "list_skills", None)
            if callable(fn):
                items = fn()
                if isinstance(items, list):
                    return [
                        {"name": getattr(s, "name", str(s)), "description": getattr(s, "description", "")}
                        for s in items
                    ]
        except Exception:
            pass
        return [{"name": s, "description": "(preloaded)"} for s in self.skills]


# ---------------------------------------------------------------------------
# Bootstrapping helpers
# ---------------------------------------------------------------------------

def _ensure_config() -> dict:
    """Create the default config if missing; return parsed values."""
    if not CONFIG_PATH.exists():
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(DEFAULT_CONFIG, encoding="utf-8")
    try:
        import yaml  # type: ignore
        return yaml.safe_load(CONFIG_PATH.read_text()) or {}
    except Exception:
        # YAML not installed → parse the trivial subset we wrote ourselves.
        out: dict = {}
        for line in CONFIG_PATH.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" not in line:
                continue
            k, _, v = line.partition(":")
            v = v.strip()
            if v.startswith("[") and v.endswith("]"):
                inner = v[1:-1].strip()
                out[k.strip()] = [x.strip() for x in inner.split(",") if x.strip()] if inner else []
            elif v.lower() in {"true", "false"}:
                out[k.strip()] = v.lower() == "true"
            else:
                out[k.strip()] = v
        return out


def _probe_gateway() -> bool:
    try:
        r = httpx.get(f"{GATEWAY_URL}/health", timeout=0.5)
        return r.status_code == 200
    except Exception:
        return False


def _detect_branch() -> str:
    """Best-effort current CVC branch (falls back to 'main')."""
    try:
        from cvc.core.models import CVCConfig
        cfg = CVCConfig.for_project()
        return getattr(cfg, "active_branch", None) or "main"
    except Exception:
        return "main"


def list_tools_only(console: Console | None = None) -> int:
    """Implementation of ``cvc --list-tools``."""
    console = console or Console()
    state = TUIState(console=console, gateway_alive=_probe_gateway())
    tools = state.list_tools()
    if not tools:
        console.print("[dim]No tools registered.[/]")
        return 0
    for t in tools:
        name = t.get("name", "?")
        desc = (t.get("description") or "").splitlines()[0]
        console.print(f"[bold {CVC_ACCENT}]{name}[/]  [dim]{desc}[/]")
    console.print(f"\n[dim]{len(tools)} tool(s).[/]")
    return 0


# ---------------------------------------------------------------------------
# Main run loop
# ---------------------------------------------------------------------------

def _handle_chat(state: TUIState, text: str) -> None:
    """Stub agent dispatch.

    Slice 1 ships the *shell* — full streaming chat lives in slice 2 once
    the gateway protocol is locked.  We still record the turn locally so
    /save and the status meter behave correctly.
    """
    state.turn += 1
    state.history_log.append({"role": "user", "content": text})

    # Try gateway first
    response_text = ""
    started = time.perf_counter()
    if state.gateway_alive:
        try:
            r = httpx.post(
                f"{GATEWAY_URL}/v1/chat",
                json={
                    "model": state.model,
                    "provider": state.provider,
                    "messages": [{"role": "user", "content": text}],
                },
                timeout=60.0,
            )
            if r.status_code == 200:
                data = r.json()
                response_text = (
                    data.get("content")
                    or data.get("response")
                    or data.get("output", "")
                ) or ""
                usage = data.get("usage") or {}
                state.tokens_in += int(usage.get("input_tokens", 0) or 0)
                state.tokens_out += int(usage.get("output_tokens", 0) or 0)
        except Exception as exc:
            warn(state.console, f"Gateway call failed: {exc}")

    if not response_text:
        # Slice-1 placeholder reply — keeps the UX honest while the agent
        # bridge is being built.
        response_text = (
            f"_(slice-1 stub — agent backend not yet wired in this REPL; "
            f"ran in shell-only mode. Your message of {len(text)} chars was "
            f"captured to the session log.)_\n\n"
            f"> {text[:200]}{'…' if len(text) > 200 else ''}"
        )

    render_markdown(state.console, response_text)
    state.history_log.append({"role": "assistant", "content": response_text})
    elapsed = time.perf_counter() - started
    render_turn_meter(
        state.console,
        input_tokens=state.tokens_in,
        output_tokens=state.tokens_out,
        cost_usd=state.cost_usd or None,
        elapsed_s=elapsed,
    )


def run(
    *,
    model: str | None = None,
    provider: str | None = None,
    toolsets: list[str] | None = None,
    skills: list[str] | None = None,
    show_banner: bool = True,
) -> int:
    """Boot the CVC TUI. Returns a process exit code (0 on clean exit)."""
    console = Console()

    cfg = _ensure_config()
    state = TUIState(
        console=console,
        model=model or cfg.get("model") or "claude-sonnet-4-6",
        provider=provider or cfg.get("provider") or "anthropic",
        toolsets=list(toolsets) if toolsets is not None else list(cfg.get("toolsets") or []),
        skills=list(skills) if skills is not None else list(cfg.get("skills") or []),
        branch=_detect_branch(),
        gateway_alive=_probe_gateway(),
    )

    if show_banner and cfg.get("show_banner", True):
        try:
            from cvc import __version__ as _v
        except Exception:
            _v = ""
        render_banner(console, version=f"v{_v}" if _v else "")
        backend = "gateway @ :13421" if state.gateway_alive else "in-process (lazy)"
        info(console, f"Backend: [bold]{backend}[/]   Branch: [bold]{state.branch}[/]")
        console.print()

    session = make_session(state)

    while True:
        try:
            line = prompt_user(session)
        except (EOFError, KeyboardInterrupt):
            console.print(f"\n[dim {CVC_DIM}]Goodbye.[/]")
            return 0

        line = (line or "").strip()
        if not line:
            continue

        if line.startswith("/"):
            result = slash_dispatch(state, line)
            if result == "exit":
                console.print(f"[dim {CVC_DIM}]Bye, love. CVC out.[/]")
                return 0
            continue

        try:
            _handle_chat(state, line)
        except Exception as exc:
            error(console, f"Turn failed: {exc}")
