"""TypedDicts for the CVC TUI Gateway JSON-RPC protocol."""

from __future__ import annotations

from typing import Any, Literal, TypedDict, Union


JsonRpcVersion = Literal["2.0"]


class RpcRequest(TypedDict, total=False):
    jsonrpc: JsonRpcVersion
    id: Union[int, str]
    method: str
    params: dict[str, Any]


class RpcError(TypedDict, total=False):
    code: int
    message: str
    data: Any


class RpcResponse(TypedDict, total=False):
    jsonrpc: JsonRpcVersion
    id: Union[int, str, None]
    result: Any
    error: RpcError


class RpcEvent(TypedDict, total=False):
    """Server-pushed event — JSON-RPC notification (no id)."""

    jsonrpc: JsonRpcVersion
    method: str
    params: dict[str, Any]


# JSON-RPC 2.0 standard error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603

# Gateway-specific (application range -32000..-32099)
HANDLER_ERROR = -32000
SHUTDOWN = -32001
