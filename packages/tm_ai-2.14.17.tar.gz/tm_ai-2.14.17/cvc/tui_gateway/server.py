"""Async RPC server: handler registry + dispatch.

Handlers are coroutines that take a server context (``ServerCtx``) and
``params`` dict. They may return a result (single response), or use
``ctx.emit_event(...)`` to push streaming events before returning.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import sys
from typing import Any, Awaitable, Callable, Union

from cvc.tui_gateway.log_ring import LogRing
from cvc.tui_gateway.protocol import (
    ProtocolError,
    make_error,
    make_event,
    make_response,
    parse_request,
    serialize,
)
from cvc.tui_gateway.types import (
    HANDLER_ERROR,
    INVALID_PARAMS,
    METHOD_NOT_FOUND,
)


logger = logging.getLogger("cvc.tui_gateway.server")


HandlerFn = Callable[["ServerCtx", dict[str, Any]], Awaitable[Any]]


class ServerCtx:
    """Per-request context handed to every handler.

    Provides:

    * ``emit_event(method, params)`` — push a server→client notification
      (e.g. ``chat.delta``) on the same stdout stream as the eventual response.
    * ``log_ring`` — the in-memory stderr ring buffer.
    * ``shutdown()`` — request orderly server termination.
    """

    def __init__(self, server: "RpcServer", request_id: Union[int, str, None]) -> None:
        self._server = server
        self.request_id = request_id
        self.log_ring = server.log_ring

    async def emit_event(self, method: str, params: dict[str, Any] | None = None) -> None:
        await self._server.write_message(make_event(method, params))

    def shutdown(self) -> None:
        self._server.request_shutdown()


class RpcServer:
    """Async newline-delimited JSON-RPC 2.0 server over arbitrary streams."""

    def __init__(
        self,
        *,
        log_ring: LogRing | None = None,
        loop: asyncio.AbstractEventLoop | None = None,
    ) -> None:
        self._handlers: dict[str, HandlerFn] = {}
        self.log_ring = log_ring or LogRing()
        self._write_lock = asyncio.Lock()
        self._writer = None  # type: ignore[assignment]
        self._shutdown_event = asyncio.Event()
        self._loop = loop

    # ── Registration ────────────────────────────────────────────────
    def register(self, method: str, handler: HandlerFn) -> None:
        if method in self._handlers:
            logger.debug("overriding handler for %s", method)
        self._handlers[method] = handler

    def methods(self) -> list[str]:
        return sorted(self._handlers.keys())

    # ── Lifecycle ───────────────────────────────────────────────────
    def request_shutdown(self) -> None:
        self._shutdown_event.set()

    # ── I/O ─────────────────────────────────────────────────────────
    async def write_message(self, message: dict[str, Any]) -> None:
        line = serialize(message)
        async with self._write_lock:
            if self._writer is None:
                # Synchronous fallback (used by tests that drive dispatch directly).
                sys.stdout.write(line)
                sys.stdout.flush()
                return
            try:
                self._writer.write(line.encode("utf-8"))
                await self._writer.drain()
            except (BrokenPipeError, ConnectionResetError):
                logger.warning("stdout pipe closed; requesting shutdown")
                self.request_shutdown()

    # ── Dispatch ────────────────────────────────────────────────────
    async def dispatch(self, line: str) -> None:
        """Parse a single line and run the matching handler.

        Writes the JSON-RPC response (and any streamed events) to the active
        writer. Notifications (no ``id``) get no response — only side-effects.
        """
        req_id: Union[int, str, None] = None
        try:
            request = parse_request(line)
        except ProtocolError as exc:
            if exc.req_id is not None or "id" in (line or ""):
                # Best-effort: if the malformed payload had an id, surface it.
                await self.write_message(make_error(exc.req_id, exc.code, exc.message))
            else:
                await self.write_message(make_error(None, exc.code, exc.message))
            return

        req_id = request.get("id")  # type: ignore[assignment]
        method = request["method"]
        params = request.get("params", {}) or {}
        handler = self._handlers.get(method)
        if handler is None:
            if req_id is not None:
                await self.write_message(
                    make_error(req_id, METHOD_NOT_FOUND, f"method not found: {method}")
                )
            return

        ctx = ServerCtx(self, req_id)
        try:
            result = handler(ctx, params)
            if inspect.isawaitable(result):
                result = await result
        except TypeError as exc:
            if req_id is not None:
                await self.write_message(
                    make_error(req_id, INVALID_PARAMS, str(exc))
                )
            return
        except Exception as exc:  # noqa: BLE001
            logger.exception("handler %s raised", method)
            if req_id is not None:
                await self.write_message(
                    make_error(
                        req_id,
                        HANDLER_ERROR,
                        f"{type(exc).__name__}: {exc}",
                    )
                )
            return

        # Notifications get no response.
        if req_id is None:
            return
        await self.write_message(make_response(req_id, result))

    # ── Main loop ───────────────────────────────────────────────────
    async def serve_streams(self, reader: asyncio.StreamReader, writer) -> None:
        """Run the read→dispatch loop on (stdin reader, stdout writer)."""
        self._writer = writer
        try:
            while not self._shutdown_event.is_set():
                read_task = asyncio.create_task(reader.readline())
                shutdown_task = asyncio.create_task(self._shutdown_event.wait())
                done, pending = await asyncio.wait(
                    {read_task, shutdown_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for p in pending:
                    p.cancel()
                if shutdown_task in done and read_task not in done:
                    break
                line_bytes = read_task.result() if read_task in done else b""
                if not line_bytes:
                    # EOF on stdin — Node closed the pipe.
                    break
                try:
                    line = line_bytes.decode("utf-8", errors="replace").rstrip("\r\n")
                except Exception:
                    continue
                if not line:
                    continue
                # Run dispatch concurrently so streaming handlers don't block
                # incoming pings/shutdowns.
                asyncio.create_task(self.dispatch(line))
        finally:
            try:
                if writer is not None and hasattr(writer, "close"):
                    writer.close()
            except Exception:
                pass


__all__ = ["RpcServer", "ServerCtx", "HandlerFn"]
