"""In-memory ring buffer for stderr / log capture.

The Node side captures our stderr as a log stream, but we also keep an
in-process ring (max 1000 lines by default) so handlers like ``system.logs``
can return recent diagnostics without re-reading a file.
"""

from __future__ import annotations

import threading
from collections import deque
from typing import Iterable


class LogRing:
    """Thread-safe bounded ring buffer of log lines."""

    def __init__(self, maxlen: int = 1000) -> None:
        if maxlen <= 0:
            raise ValueError("maxlen must be positive")
        self._buf: deque[str] = deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self.maxlen = maxlen

    def append(self, line: str) -> None:
        # Strip a single trailing newline so callers can pass either form.
        if line.endswith("\n"):
            line = line[:-1]
        with self._lock:
            self._buf.append(line)

    def extend(self, lines: Iterable[str]) -> None:
        with self._lock:
            for line in lines:
                if line.endswith("\n"):
                    line = line[:-1]
                self._buf.append(line)

    def snapshot(self, limit: int | None = None) -> list[str]:
        with self._lock:
            data = list(self._buf)
        if limit is not None and limit >= 0:
            return data[-limit:]
        return data

    def clear(self) -> None:
        with self._lock:
            self._buf.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._buf)


class TeeStderr:
    """File-like wrapper that tees writes to a real stream AND a LogRing.

    Installed as ``sys.stderr`` so any logging.* / print(file=sys.stderr) goes
    to both the parent process's captured pipe and our in-memory ring.
    """

    def __init__(self, underlying, ring: LogRing) -> None:
        self._underlying = underlying
        self._ring = ring
        self._buf = ""

    def write(self, data: str) -> int:
        try:
            n = self._underlying.write(data)
        except Exception:
            n = len(data)
        # Buffer until newline so we capture whole lines.
        self._buf += data
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            if line:
                self._ring.append(line)
        return n if isinstance(n, int) else len(data)

    def flush(self) -> None:
        try:
            self._underlying.flush()
        except Exception:
            pass

    def isatty(self) -> bool:  # pragma: no cover
        try:
            return self._underlying.isatty()
        except Exception:
            return False

    def __getattr__(self, name):  # pragma: no cover — passthrough
        return getattr(self._underlying, name)


__all__ = ["LogRing", "TeeStderr"]
