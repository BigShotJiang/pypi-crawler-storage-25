"""Newline-delimited JSON-RPC 2.0 protocol primitives (stdlib-only).

Every message is a single JSON object on its own line. Three shapes:

* request  ``{jsonrpc:'2.0', id, method, params}``
* response ``{jsonrpc:'2.0', id, result|error}``
* event    ``{jsonrpc:'2.0', method, params}``  (server-push notification, no id)
"""

from __future__ import annotations

import json
from typing import Any, Union

from cvc.tui_gateway.types import (
    HANDLER_ERROR,
    INVALID_REQUEST,
    PARSE_ERROR,
    RpcError,
    RpcEvent,
    RpcRequest,
    RpcResponse,
)


JSONRPC = "2.0"


class ProtocolError(Exception):
    """Raised when an incoming line cannot be parsed as a valid RPC request."""

    def __init__(self, code: int, message: str, *, req_id: Union[int, str, None] = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.req_id = req_id


def parse_request(line: str) -> RpcRequest:
    """Parse a single newline-stripped line into an RpcRequest.

    Raises :class:`ProtocolError` on malformed input.
    """
    if not line or not line.strip():
        raise ProtocolError(INVALID_REQUEST, "empty line")
    try:
        obj = json.loads(line)
    except json.JSONDecodeError as exc:
        raise ProtocolError(PARSE_ERROR, f"invalid JSON: {exc}") from exc
    if not isinstance(obj, dict):
        raise ProtocolError(INVALID_REQUEST, "request must be a JSON object")
    if obj.get("jsonrpc") != JSONRPC:
        raise ProtocolError(
            INVALID_REQUEST,
            f"jsonrpc must be '{JSONRPC}'",
            req_id=obj.get("id"),
        )
    method = obj.get("method")
    if not isinstance(method, str) or not method:
        raise ProtocolError(
            INVALID_REQUEST, "method must be a non-empty string", req_id=obj.get("id")
        )
    params = obj.get("params", {})
    if params is None:
        params = {}
    if not isinstance(params, dict):
        raise ProtocolError(
            INVALID_REQUEST, "params must be an object", req_id=obj.get("id")
        )
    req: RpcRequest = {
        "jsonrpc": JSONRPC,
        "method": method,
        "params": params,
    }
    if "id" in obj:
        req["id"] = obj["id"]
    return req


def make_response(req_id: Union[int, str, None], result: Any) -> RpcResponse:
    return {"jsonrpc": JSONRPC, "id": req_id, "result": result}


def make_error(
    req_id: Union[int, str, None],
    code: int,
    message: str,
    data: Any | None = None,
) -> RpcResponse:
    err: RpcError = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": JSONRPC, "id": req_id, "error": err}


def make_event(method: str, params: dict[str, Any] | None = None) -> RpcEvent:
    return {"jsonrpc": JSONRPC, "method": method, "params": params or {}}


def serialize(message: dict[str, Any]) -> str:
    """Serialize an RPC message to a single-line JSON string with trailing newline.

    Output is compact (no inner whitespace) so that newline framing is
    unambiguous regardless of payload contents.
    """
    return json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n"


__all__ = [
    "JSONRPC",
    "ProtocolError",
    "parse_request",
    "make_response",
    "make_error",
    "make_event",
    "serialize",
    "HANDLER_ERROR",
]
