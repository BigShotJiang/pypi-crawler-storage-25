"""Built-in handler modules. Import :func:`register_all` to wire them into a server."""

from __future__ import annotations

from cvc.tui_gateway.handlers import chat, session, system
from cvc.tui_gateway.server import RpcServer


def register_all(server: RpcServer) -> None:
    """Register every built-in handler on *server*."""
    session.register(server)
    chat.register(server)
    system.register(server)


__all__ = ["register_all"]
