"""``session.*`` handlers — read-only environment introspection."""

from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any

from cvc.tui_gateway import __version__ as GATEWAY_VERSION
from cvc.tui_gateway.server import RpcServer, ServerCtx


_SESSION_ID = os.environ.get("CVC_TUI_SESSION_ID") or uuid.uuid4().hex


def _load_config() -> dict[str, Any]:
    """Best-effort read of ~/.cvc/config.yaml + auth.json — never raises."""
    cfg_path = Path(os.environ.get("CVC_HOME", str(Path.home() / ".cvc"))) / "config.yaml"
    auth_path = Path(os.environ.get("CVC_HOME", str(Path.home() / ".cvc"))) / "auth.json"
    cfg: dict[str, Any] = {}
    try:
        if cfg_path.exists():
            try:
                import yaml  # type: ignore
                cfg = yaml.safe_load(cfg_path.read_text()) or {}
            except Exception:
                # Minimal fallback parser for the simple key: value lines we care about.
                for raw in cfg_path.read_text().splitlines():
                    line = raw.strip()
                    if not line or line.startswith("#") or ":" not in line:
                        continue
                    k, _, v = line.partition(":")
                    cfg[k.strip()] = v.strip().strip('"').strip("'")
    except Exception:
        pass
    auth: dict[str, Any] = {}
    try:
        if auth_path.exists():
            import json
            auth = json.loads(auth_path.read_text())
    except Exception:
        pass
    return {"config": cfg, "auth": auth}


async def session_info(ctx: ServerCtx, params: dict[str, Any]) -> dict[str, Any]:
    bundle = _load_config()
    cfg = bundle.get("config", {})
    auth = bundle.get("auth", {})
    return {
        "version": GATEWAY_VERSION,
        "model": cfg.get("model") or os.environ.get("CVC_MODEL", "claude-sonnet-4-6"),
        "provider": cfg.get("provider") or auth.get("provider") or "anthropic",
        "cwd": os.getcwd(),
        "session_id": _SESSION_ID,
    }


def register(server: RpcServer) -> None:
    server.register("session.info", session_info)


__all__ = ["session_info", "register"]
