"""``system.*`` handlers — health & lifecycle."""

from __future__ import annotations

from typing import Any

from cvc.tui_gateway.server import RpcServer, ServerCtx


async def system_ping(ctx: ServerCtx, params: dict[str, Any]) -> str:
    return "pong"


async def system_shutdown(ctx: ServerCtx, params: dict[str, Any]) -> dict[str, Any]:
    """Request orderly shutdown. Server replies, then exits its read loop."""
    ctx.shutdown()
    return {"ok": True}


async def system_logs(ctx: ServerCtx, params: dict[str, Any]) -> dict[str, Any]:
    """Return recent stderr lines from the in-memory ring buffer."""
    limit = params.get("limit") if isinstance(params, dict) else None
    if not isinstance(limit, int) or limit < 0:
        limit = None
    return {"lines": ctx.log_ring.snapshot(limit)}


def register(server: RpcServer) -> None:
    server.register("system.ping", system_ping)
    server.register("system.shutdown", system_shutdown)
    server.register("system.logs", system_logs)


__all__ = ["system_ping", "system_shutdown", "system_logs", "register"]
