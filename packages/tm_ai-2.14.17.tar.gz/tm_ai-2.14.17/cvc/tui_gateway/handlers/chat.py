"""``chat.*`` handlers — wire the TUI to the CVC provider system.

``chat.send`` accepts ``{"message": str, ["system": str], ["model": str]}``
and:

1. Emits ``chat.start`` (one event) with the resolved provider/model.
2. Emits ``chat.delta`` events with streaming text chunks.
3. Returns when streaming completes; emits ``chat.done`` with usage stats.

If the provider call fails for any reason (auth, network, missing dep), we
fall back to a deterministic echo so the TUI always gets a coherent stream:

    "CVC v2.14 (gateway): I received <message>"

This keeps the gateway useful in dev environments without configured creds.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Any

from cvc.tui_gateway.server import RpcServer, ServerCtx


logger = logging.getLogger("cvc.tui_gateway.chat")


# Pluggable provider factory — tests override this to inject a fake stream.
# Signature: provider_factory(provider, api_key, model, base_url) -> object
#   with `chat_stream(messages, tools, ...) -> AsyncIterator[StreamEvent]`.
_provider_factory = None


def set_provider_factory(factory) -> None:
    """Override the provider factory (used by tests)."""
    global _provider_factory
    _provider_factory = factory


def _resolve_creds() -> dict[str, Any]:
    """Read provider/model/api_key from ~/.cvc/{auth.json,config.yaml}."""
    home = Path(os.environ.get("CVC_HOME", str(Path.home() / ".cvc")))
    cfg: dict[str, Any] = {}
    try:
        cfg_path = home / "config.yaml"
        if cfg_path.exists():
            try:
                import yaml  # type: ignore
                cfg = yaml.safe_load(cfg_path.read_text()) or {}
            except Exception:
                for raw in cfg_path.read_text().splitlines():
                    line = raw.strip()
                    if not line or line.startswith("#") or ":" not in line:
                        continue
                    k, _, v = line.partition(":")
                    cfg[k.strip()] = v.strip().strip('"').strip("'")
    except Exception:
        pass
    auth: dict[str, Any] = {}
    try:
        auth_path = home / "auth.json"
        if auth_path.exists():
            import json
            auth = json.loads(auth_path.read_text())
    except Exception:
        pass
    return {
        "provider": cfg.get("provider") or auth.get("provider") or "anthropic",
        "model": cfg.get("model") or os.environ.get("CVC_MODEL", "claude-sonnet-4-6"),
        "api_key": auth.get("token") or os.environ.get("CVC_API_KEY", ""),
        "base_url": cfg.get("base_url", ""),
    }


def _make_real_provider(provider: str, api_key: str, model: str, base_url: str):
    """Lazy-construct an AgentLLM. Imported here so tests don't need httpx."""
    from cvc.agent.llm import AgentLLM  # type: ignore
    return AgentLLM(provider=provider, api_key=api_key, model=model, base_url=base_url)


def _echo_text(message: str) -> str:
    return f"CVC v2.14 (gateway): I received {message}"


async def _stream_echo(ctx: ServerCtx, text: str) -> dict[str, Any]:
    """Fallback stream — chunk the echo into ~16-char deltas."""
    chunks: list[str] = []
    step = 16
    for i in range(0, len(text), step):
        chunks.append(text[i : i + step])
    total = 0
    for c in chunks:
        await ctx.emit_event("chat.delta", {"text": c})
        total += len(c)
        # Tiny yield so other RPCs can interleave; avoids tight loop.
        await asyncio.sleep(0)
    return {"chars": total, "fallback": True}


async def chat_send(ctx: ServerCtx, params: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(params, dict):
        raise TypeError("params must be an object")
    message = params.get("message", "")
    if not isinstance(message, str):
        raise TypeError("message must be a string")
    system_prompt = params.get("system") if isinstance(params.get("system"), str) else None

    creds = _resolve_creds()
    provider = params.get("model_provider") or creds["provider"]
    model = params.get("model") or creds["model"]
    api_key = creds["api_key"]
    base_url = creds["base_url"]

    await ctx.emit_event(
        "chat.start", {"provider": provider, "model": model}
    )

    factory = _provider_factory or _make_real_provider
    fallback_used = False
    text_chars = 0
    prompt_tokens = 0
    completion_tokens = 0

    try:
        client = factory(provider, api_key, model, base_url)
        messages: list[dict[str, Any]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": message})

        # AgentLLM.chat_stream → AsyncIterator[StreamEvent] with .type/.text.
        stream = client.chat_stream(messages, tools=[])
        async for ev in stream:
            etype = getattr(ev, "type", None) or (ev.get("type") if isinstance(ev, dict) else None)
            etext = getattr(ev, "text", "") or (ev.get("text", "") if isinstance(ev, dict) else "")
            if etype in ("text_delta", "delta") and etext:
                await ctx.emit_event("chat.delta", {"text": etext})
                text_chars += len(etext)
            elif etype == "usage":
                prompt_tokens = int(getattr(ev, "prompt_tokens", 0) or 0)
                completion_tokens = int(getattr(ev, "completion_tokens", 0) or 0)
            elif etype == "done":
                break
    except Exception as exc:  # noqa: BLE001
        logger.warning("provider stream failed (%s); falling back to echo", exc)
        fallback_used = True
        result = await _stream_echo(ctx, _echo_text(message))
        text_chars = int(result.get("chars", 0))

    summary = {
        "provider": provider,
        "model": model,
        "chars": text_chars,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "fallback": fallback_used,
    }
    await ctx.emit_event("chat.done", summary)
    return summary


def register(server: RpcServer) -> None:
    server.register("chat.send", chat_send)


__all__ = ["chat_send", "register", "set_provider_factory"]
