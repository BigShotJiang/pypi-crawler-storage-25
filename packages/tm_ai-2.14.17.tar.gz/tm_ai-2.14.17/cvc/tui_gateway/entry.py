"""Main entry: ``python -m cvc.tui_gateway.entry``.

Sets up:

* Stderr → in-memory :class:`LogRing` tee (so ``system.logs`` can return them
  and stderr never bleeds into the JSON-RPC stdout stream).
* Async stdin reader / stdout writer wired to the :class:`RpcServer`.
* All built-in handlers from :mod:`cvc.tui_gateway.handlers`.
* SIGTERM / SIGINT graceful shutdown.

The Node TUI process spawns this with ``stdio: ['pipe','pipe','pipe']`` and
expects newline-delimited JSON-RPC 2.0 frames on stdout.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
from typing import Optional

from cvc.tui_gateway.handlers import register_all
from cvc.tui_gateway.log_ring import LogRing, TeeStderr
from cvc.tui_gateway.server import RpcServer


def _setup_logging(ring: LogRing) -> None:
    # Tee stderr first — so logging.basicConfig() picks up the wrapped stream.
    sys.stderr = TeeStderr(sys.stderr, ring)
    logging.basicConfig(
        level=os.environ.get("CVC_TUI_GATEWAY_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )


async def _stdin_reader() -> asyncio.StreamReader:
    """Wrap blocking sys.stdin in an asyncio StreamReader."""
    loop = asyncio.get_event_loop()
    reader = asyncio.StreamReader(loop=loop)
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)
    return reader


async def _stdout_writer() -> asyncio.StreamWriter:
    loop = asyncio.get_event_loop()
    transport, protocol = await loop.connect_write_pipe(
        asyncio.streams.FlowControlMixin, sys.stdout
    )
    return asyncio.StreamWriter(transport, protocol, None, loop)


async def run() -> int:
    ring = LogRing(maxlen=1000)
    _setup_logging(ring)
    log = logging.getLogger("cvc.tui_gateway.entry")
    log.info("CVC TUI gateway starting (pid=%d)", os.getpid())

    server = RpcServer(log_ring=ring)
    register_all(server)
    log.debug("registered methods: %s", server.methods())

    try:
        reader = await _stdin_reader()
        writer = await _stdout_writer()
    except Exception as exc:
        # Fallback synchronous loop so we still respond on platforms without
        # full pipe support (e.g. Windows shells in tests).
        log.error("async pipe setup failed: %s — using sync fallback", exc)
        return _run_sync(server)

    def _on_signal(signum, _frame=None):  # noqa: ANN001
        log.info("signal %d received → shutting down", signum)
        server.request_shutdown()

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal, sig)
        except (NotImplementedError, RuntimeError):  # pragma: no cover
            signal.signal(sig, _on_signal)

    await server.serve_streams(reader, writer)
    log.info("CVC TUI gateway exiting cleanly")
    return 0


def _run_sync(server: RpcServer) -> int:
    """Last-resort blocking loop (no async pipes available)."""
    loop = asyncio.new_event_loop()
    try:
        for raw in sys.stdin:
            line = raw.rstrip("\r\n")
            if not line:
                continue
            loop.run_until_complete(server.dispatch(line))
    finally:
        loop.close()
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    try:
        return asyncio.run(run())
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
