"""CVC TUI Gateway — Python JSON-RPC backend for the cvc-tui Node UI.

The cvc-tui Node process spawns ``python -m cvc.tui_gateway.entry`` and speaks
newline-delimited JSON-RPC 2.0 over stdin/stdout. Stderr is captured by Node
into a log ring and never pollutes the protocol stream.

Public surface is intentionally thin — see :mod:`cvc.tui_gateway.entry`.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
