"""
cvc.agent.error_classifier — Compact API error classifier ported from Hermes.

Classifies an exception raised by an LLM client into one of several
recovery categories so the loop can decide what to do:

    transient        → retry with exponential backoff
    rate_limit       → backoff using Retry-After / quota-aware delay
    context_overflow → trigger ContextCompressor before retrying
    permanent        → fail fast (no retry)
    auth             → refresh / rotate credential, then retry
    unknown          → conservative: short retry then fail

This is a deliberately small subset of Hermes's full ``error_classifier.py``
(which has ~1k LOC of provider-specific quirks). The contract — a
``ClassifiedError`` with boolean recovery hints — is the same so the rest
of CVC can swap in the richer Hermes classifier later without changing
call-sites.
"""

from __future__ import annotations

import enum
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger("cvc.agent.error_classifier")


# ── Taxonomy ────────────────────────────────────────────────────────────

class FailoverReason(enum.Enum):
    transient = "transient"                # generic 5xx/timeout — retry+backoff
    rate_limit = "rate_limit"              # 429 / quota — backoff with Retry-After
    context_overflow = "context_overflow"  # context too large — compress
    payload_too_large = "payload_too_large"  # 413 — compress
    auth = "auth"                          # 401/403 — refresh credential
    auth_permanent = "auth_permanent"      # auth retried and still failing
    billing = "billing"                    # 402 / credits exhausted — rotate
    model_not_found = "model_not_found"    # 404 model — fallback model
    overloaded = "overloaded"              # 503/529 — backoff
    server_error = "server_error"          # 500/502 — retry
    timeout = "timeout"                    # network timeout — retry
    format_error = "format_error"          # 400 bad request — abort
    permanent = "permanent"                # not retryable
    unknown = "unknown"                    # unclassifiable


@dataclass
class ClassifiedError:
    """Structured classification with recovery hints."""

    reason: FailoverReason
    status_code: Optional[int] = None
    provider: Optional[str] = None
    model: Optional[str] = None
    message: str = ""
    retry_after: Optional[float] = None  # seconds — from Retry-After header if present
    error_context: Dict[str, Any] = field(default_factory=dict)

    # Recovery action hints (loop checks these instead of re-classifying)
    retryable: bool = True
    should_compress: bool = False
    should_rotate_credential: bool = False
    should_fallback: bool = False
    backoff_seconds: float = 1.0

    @property
    def is_auth(self) -> bool:
        return self.reason in (FailoverReason.auth, FailoverReason.auth_permanent)

    @property
    def is_transient(self) -> bool:
        return self.reason in (
            FailoverReason.transient,
            FailoverReason.timeout,
            FailoverReason.server_error,
            FailoverReason.overloaded,
        )

    @property
    def is_rate_limit(self) -> bool:
        return self.reason == FailoverReason.rate_limit

    @property
    def is_context_overflow(self) -> bool:
        return self.reason in (
            FailoverReason.context_overflow,
            FailoverReason.payload_too_large,
        )

    @property
    def is_permanent(self) -> bool:
        return not self.retryable


# ── Patterns ────────────────────────────────────────────────────────────

_CONTEXT_OVERFLOW_PATTERNS = [
    "context length",
    "context_length_exceeded",
    "maximum context",
    "max_tokens",
    "too many tokens",
    "prompt is too long",
    "input is too long",
    "context window",
    "tokens exceeds",
    "reduce the length",
]

_RATE_LIMIT_PATTERNS = [
    "rate limit",
    "rate_limit",
    "too many requests",
    "quota exceeded",
    "throttl",
]

_BILLING_PATTERNS = [
    "insufficient credits",
    "insufficient_quota",
    "insufficient balance",
    "credit balance",
    "credits have been exhausted",
    "payment required",
]

_AUTH_PATTERNS = [
    "unauthorized",
    "invalid api key",
    "invalid_api_key",
    "authentication",
    "expired token",
    "invalid token",
    "forbidden",
]

_TIMEOUT_PATTERNS = [
    "timed out",
    "timeout",
    "read timed out",
    "connection reset",
    "connection refused",
    "broken pipe",
]

_FORMAT_PATTERNS = [
    "invalid request",
    "bad request",
    "schema validation",
    "unsupported parameter",
]

_MODEL_NOT_FOUND_PATTERNS = [
    "model not found",
    "model_not_found",
    "no such model",
    "unknown model",
]


# ── Helpers ─────────────────────────────────────────────────────────────

def _extract_status_code(error: Exception) -> Optional[int]:
    """Best-effort status code extraction from common HTTP exceptions."""
    for attr in ("status_code", "status", "http_status", "code"):
        val = getattr(error, attr, None)
        if isinstance(val, int) and 100 <= val < 600:
            return val
    resp = getattr(error, "response", None)
    if resp is not None:
        for attr in ("status_code", "status"):
            val = getattr(resp, attr, None)
            if isinstance(val, int) and 100 <= val < 600:
                return val
    # Fallback: regex on str(error)
    m = re.search(r"\b([45]\d{2})\b", str(error))
    if m:
        return int(m.group(1))
    return None


def _extract_retry_after(error: Exception) -> Optional[float]:
    """Pull Retry-After header (seconds) from response if available."""
    resp = getattr(error, "response", None)
    if resp is None:
        return None
    headers = getattr(resp, "headers", None) or {}
    val = None
    if hasattr(headers, "get"):
        val = headers.get("Retry-After") or headers.get("retry-after")
    if val is None:
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        return None


def _msg(error: Exception) -> str:
    return str(error or "").lower()


def _matches_any(text: str, patterns: list[str]) -> bool:
    return any(p in text for p in patterns)


# ── Main entry point ────────────────────────────────────────────────────

def classify_api_error(
    error: Exception,
    *,
    provider: Optional[str] = None,
    model: Optional[str] = None,
) -> ClassifiedError:
    """
    Classify an exception into a ClassifiedError with recovery hints.

    The order of checks matters — context-overflow is checked before
    generic 400/format errors because providers often surface context
    overflows as 400s with a specific message.
    """
    msg = _msg(error)
    status = _extract_status_code(error)
    retry_after = _extract_retry_after(error)

    def _result(reason: FailoverReason, **overrides) -> ClassifiedError:
        ce = ClassifiedError(
            reason=reason,
            status_code=status,
            provider=provider,
            model=model,
            message=str(error)[:500],
            retry_after=retry_after,
        )
        for k, v in overrides.items():
            setattr(ce, k, v)
        return ce

    # 1. Context overflow — highest priority (compress, don't fail)
    if _matches_any(msg, _CONTEXT_OVERFLOW_PATTERNS):
        return _result(
            FailoverReason.context_overflow,
            should_compress=True,
            retryable=True,
            backoff_seconds=0.0,
        )
    if status == 413:
        return _result(
            FailoverReason.payload_too_large,
            should_compress=True,
            retryable=True,
            backoff_seconds=0.0,
        )

    # 2. Rate limit — explicit
    if status == 429 or _matches_any(msg, _RATE_LIMIT_PATTERNS):
        return _result(
            FailoverReason.rate_limit,
            retryable=True,
            backoff_seconds=retry_after if retry_after else 5.0,
            should_rotate_credential=False,
        )

    # 3. Billing — looks like 402 or credit exhaustion
    if status == 402 or _matches_any(msg, _BILLING_PATTERNS):
        return _result(
            FailoverReason.billing,
            retryable=True,
            should_rotate_credential=True,
            backoff_seconds=0.0,
        )

    # 4. Auth
    if status in (401, 403) or _matches_any(msg, _AUTH_PATTERNS):
        return _result(
            FailoverReason.auth,
            retryable=True,
            should_rotate_credential=True,
            backoff_seconds=0.0,
        )

    # 5. Model not found
    if _matches_any(msg, _MODEL_NOT_FOUND_PATTERNS):
        return _result(
            FailoverReason.model_not_found,
            retryable=True,
            should_fallback=True,
            backoff_seconds=0.0,
        )

    # 6. Server-side
    if status in (503, 529):
        return _result(
            FailoverReason.overloaded,
            retryable=True,
            backoff_seconds=retry_after if retry_after else 4.0,
        )
    if status in (500, 502, 504):
        return _result(
            FailoverReason.server_error,
            retryable=True,
            backoff_seconds=2.0,
        )

    # 7. Timeout / transport
    if _matches_any(msg, _TIMEOUT_PATTERNS):
        return _result(
            FailoverReason.timeout,
            retryable=True,
            backoff_seconds=2.0,
        )

    # 8. Format / validation — usually 400
    if status == 400 or _matches_any(msg, _FORMAT_PATTERNS):
        # 400 errors are often non-retryable unless they're context overflow
        # (already handled above).
        return _result(
            FailoverReason.format_error,
            retryable=False,
            backoff_seconds=0.0,
        )

    # 9. 404 — model or endpoint missing
    if status == 404:
        return _result(
            FailoverReason.model_not_found,
            retryable=True,
            should_fallback=True,
        )

    # 10. Generic transient retry
    if status and 500 <= status < 600:
        return _result(
            FailoverReason.transient,
            retryable=True,
            backoff_seconds=2.0,
        )

    # 11. Unknown
    return _result(
        FailoverReason.unknown,
        retryable=True,
        backoff_seconds=1.0,
    )


def compute_backoff(
    classified: ClassifiedError,
    attempt: int,
    *,
    base: float = 1.0,
    cap: float = 60.0,
) -> float:
    """
    Compute the actual sleep duration for a retry attempt (1-indexed).

    - For rate-limit with Retry-After, honour it.
    - For other categories, exponential backoff with jitter cap.
    """
    if classified.retry_after and classified.is_rate_limit:
        return min(float(classified.retry_after), cap)
    if classified.backoff_seconds <= 0:
        return 0.0
    delay = classified.backoff_seconds * (2 ** max(0, attempt - 1))
    return min(delay, cap)
