"""
cvc.agent.iteration_budget — Soft/hard iteration budget with grace-call mechanism.

Ported from Hermes's run_agent.py budget pattern.

Pattern
-------
- ``soft_limit``: warn / signal that we should be wrapping up.
- ``hard_limit``: stop spawning new tool-calling iterations.
- ``grace_call``: when ``hard_limit`` is hit, allow exactly one more LLM call
  with a "you're out of budget, give the user a clean final answer" nudge.

The class is intentionally small and dependency-free so it can be used by
any executor / chat loop in CVC.

Usage
-----
    budget = IterationBudget(soft_limit=60, hard_limit=90)
    while budget.can_continue():
        if interrupt_requested:
            break
        budget.tick()
        if budget.in_grace():
            # add a system nudge: "wrap up cleanly, no new tool calls"
            ...
        ...
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable, Optional

logger = logging.getLogger("cvc.agent.iteration_budget")


@dataclass
class IterationBudget:
    """
    Tracks how many LLM/tool iterations a conversation has consumed and
    enforces a soft/hard limit with a single grace call at the end.
    """

    soft_limit: int = 60
    hard_limit: int = 90
    used: int = 0
    _grace_consumed: bool = False
    on_soft_limit: Optional[Callable[["IterationBudget"], None]] = field(
        default=None, repr=False
    )
    on_hard_limit: Optional[Callable[["IterationBudget"], None]] = field(
        default=None, repr=False
    )

    # ── Properties ─────────────────────────────────────────────────────
    @property
    def remaining(self) -> int:
        """Hard-limit-relative remaining iterations (>=0)."""
        return max(0, self.hard_limit - self.used)

    @property
    def soft_remaining(self) -> int:
        return max(0, self.soft_limit - self.used)

    @property
    def exhausted(self) -> bool:
        """True once we have hit the hard limit."""
        return self.used >= self.hard_limit

    @property
    def soft_exhausted(self) -> bool:
        return self.used >= self.soft_limit

    # ── Lifecycle ──────────────────────────────────────────────────────
    def tick(self, count: int = 1) -> None:
        """Record one (or more) iteration(s) of the loop."""
        prev_soft = self.soft_exhausted
        prev_hard = self.exhausted
        self.used += count

        if not prev_soft and self.soft_exhausted:
            logger.info(
                "IterationBudget soft limit hit (%d/%d)", self.used, self.soft_limit
            )
            if self.on_soft_limit:
                try:
                    self.on_soft_limit(self)
                except Exception:  # pragma: no cover
                    logger.exception("on_soft_limit callback failed")

        if not prev_hard and self.exhausted:
            logger.warning(
                "IterationBudget hard limit hit (%d/%d)", self.used, self.hard_limit
            )
            if self.on_hard_limit:
                try:
                    self.on_hard_limit(self)
                except Exception:  # pragma: no cover
                    logger.exception("on_hard_limit callback failed")

    def can_continue(self) -> bool:
        """
        True if we still have iterations OR we have not yet used our
        single grace call.

        Loop pattern::

            while budget.can_continue():
                budget.tick()
                if budget.in_grace():
                    # tell the model: "no more tool calls, wrap up"
                ...
        """
        if not self.exhausted:
            return True
        return not self._grace_consumed

    def in_grace(self) -> bool:
        """True if we are currently spending the grace call (hard limit hit)."""
        return self.exhausted

    def consume_grace(self) -> bool:
        """
        Mark the grace call as consumed. Returns True if grace was available
        and is now consumed, False if it was already used.
        Call this *after* the grace LLM call returns.
        """
        if self._grace_consumed:
            return False
        if not self.exhausted:
            # Grace can only be consumed at hard limit
            return False
        self._grace_consumed = True
        logger.info("IterationBudget grace call consumed")
        return True

    @property
    def grace_consumed(self) -> bool:
        return self._grace_consumed

    # ── Introspection ──────────────────────────────────────────────────
    def snapshot(self) -> dict:
        return {
            "used": self.used,
            "soft_limit": self.soft_limit,
            "hard_limit": self.hard_limit,
            "remaining": self.remaining,
            "soft_remaining": self.soft_remaining,
            "exhausted": self.exhausted,
            "grace_consumed": self._grace_consumed,
        }

    def grace_nudge_message(self) -> str:
        """Suggested system/user nudge to inject on the grace call."""
        return (
            "[iteration budget exhausted] You have reached the iteration "
            f"hard limit ({self.hard_limit}). Do NOT make any more tool "
            "calls. Use this final turn to give the user a clear, complete "
            "answer based on what you already know."
        )
