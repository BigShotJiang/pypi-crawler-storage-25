"""Platform registry for CVC Gateway.

Mirrors the ``cvc.providers`` discovery pattern: subpackages under
``cvc.gateway.platforms.<name>`` are auto-imported, and each subpackage's
``__init__.py`` is expected to call :func:`register_platform` at import time.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from pathlib import Path
from typing import Optional

from cvc.gateway.base import Platform

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, Platform] = {}
_discovered = False


def register_platform(platform: Platform) -> None:
    """Register a platform instance. Last-writer-wins on name collision."""
    if not isinstance(platform, Platform):
        raise TypeError(
            f"register_platform expected a Platform instance, got {type(platform).__name__}"
        )
    name = platform.name
    if name in _REGISTRY:
        logger.info("Platform '%s' re-registered (replacing existing entry)", name)
    _REGISTRY[name] = platform


def unregister_platform(name: str) -> bool:
    """Remove a platform by name. Returns True if it existed."""
    return _REGISTRY.pop(name, None) is not None


def get_platform(name: str) -> Optional[Platform]:
    """Look up a platform by canonical name."""
    if not _discovered:
        discover_platforms()
    return _REGISTRY.get(name)


def list_platforms() -> list[str]:
    """Return sorted list of registered platform names."""
    if not _discovered:
        discover_platforms()
    return sorted(_REGISTRY.keys())


def all_platforms() -> list[Platform]:
    """Return all registered platform instances."""
    if not _discovered:
        discover_platforms()
    return list(_REGISTRY.values())


def clear_registry() -> None:
    """Wipe the registry (test helper)."""
    global _discovered
    _REGISTRY.clear()
    _discovered = False


def discover_platforms() -> None:
    """Auto-import ``cvc.gateway.platforms.*`` subpackages so they self-register."""
    global _discovered
    if _discovered:
        return
    _discovered = True

    try:
        platforms_pkg = importlib.import_module("cvc.gateway.platforms")
    except ModuleNotFoundError:
        logger.debug("cvc.gateway.platforms package not present — skipping discovery")
        return
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed importing cvc.gateway.platforms: %s", exc)
        return

    pkg_paths = getattr(platforms_pkg, "__path__", None)
    if not pkg_paths:
        return

    for _importer, modname, _ispkg in pkgutil.iter_modules([str(Path(p)) for p in pkg_paths]):
        if modname.startswith("_") or modname == "base":
            continue
        try:
            importlib.import_module(f"cvc.gateway.platforms.{modname}")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to load platform '%s': %s", modname, exc)
