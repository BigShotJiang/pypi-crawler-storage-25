"""Abstract Platform base class for CVC Gateway adapters.

A Platform represents a connection to a single messaging surface
(Telegram, Discord, Email, etc.). Concrete adapters live under
``cvc.gateway.platforms.<name>`` and subclass ``Platform``.

Design notes
------------
- This is intentionally tiny (~150 LOC). The Hermes equivalent is ~3500 LOC
  full of helper soup; here we keep only the contract.
- Adapters are async-first: ``start``/``stop``/``send_message`` are coroutines.
- Inbound messages flow through user-registered handlers via ``on_message``.
"""

from __future__ import annotations

import abc
import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# A handler invoked when an inbound message arrives on a platform.
MessageHandler = Callable[["InboundMessage"], Any]


@dataclass
class InboundMessage:
    """Normalised inbound message from a platform."""

    platform: str
    chat_id: str
    sender_id: str
    content: str
    thread_id: Optional[str] = None
    reply_to: Optional[str] = None
    media: Optional[str] = None
    raw: Any = None
    metadata: dict = field(default_factory=dict)


class Platform(abc.ABC):
    """Abstract base class for all messaging platform adapters.

    Subclasses must implement ``name``, ``start``, ``stop``, and
    ``send_message``. ``on_message`` is provided as a registration
    helper backed by ``_handlers``.
    """

    def __init__(self, config: Optional[dict] = None) -> None:
        self.config: dict = config or {}
        self._handlers: list[MessageHandler] = []
        self._running: bool = False

    # ── Identity ────────────────────────────────────────────────────────
    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Canonical platform name (e.g. ``"telegram"``)."""

    # ── Lifecycle ───────────────────────────────────────────────────────
    @abc.abstractmethod
    async def start(self) -> None:
        """Open the connection / begin polling."""

    @abc.abstractmethod
    async def stop(self) -> None:
        """Close the connection cleanly."""

    @property
    def is_running(self) -> bool:
        return self._running

    # ── Outbound ────────────────────────────────────────────────────────
    @abc.abstractmethod
    async def send_message(
        self,
        target: str,
        content: str,
        media: Optional[str] = None,
        **kwargs: Any,
    ) -> dict:
        """Send a message. Returns a small dict describing the result."""

    # ── Inbound ─────────────────────────────────────────────────────────
    def on_message(self, handler: MessageHandler) -> MessageHandler:
        """Register an inbound message handler. Usable as a decorator."""
        if not callable(handler):
            raise TypeError("handler must be callable")
        self._handlers.append(handler)
        return handler

    def clear_handlers(self) -> None:
        self._handlers.clear()

    async def _dispatch(self, message: InboundMessage) -> None:
        """Invoked by concrete adapters when an inbound message arrives."""
        for h in list(self._handlers):
            try:
                result = h(message)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:  # noqa: BLE001
                logger.exception("Handler %r failed on %s: %s", h, self.name, exc)

    def __repr__(self) -> str:  # pragma: no cover
        state = "running" if self._running else "stopped"
        return f"<Platform {self.name} ({state})>"
