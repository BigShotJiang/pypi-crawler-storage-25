"""CVC gateway platform adapters."""

from .email import EmailPlatform  # noqa: F401
from .discord import DiscordPlatform  # noqa: F401

__all__ = ["EmailPlatform", "DiscordPlatform"]
