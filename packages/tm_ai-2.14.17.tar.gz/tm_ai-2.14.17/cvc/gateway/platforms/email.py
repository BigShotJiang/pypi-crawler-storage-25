"""Email platform for the CVC gateway.

Minimum-viable port:
- SMTP send via stdlib :mod:`smtplib`
- IMAP receive via stdlib :mod:`imaplib` (poll inbox, mark seen)
- target format: ``recipient@example.com`` or ``recipient@example.com:thread_id``
  (thread_id is used as a Subject prefix, e.g. ``[thread_id] subject``)
- Inbound handler payload (dict): ``{from, to, subject, body, attachments, message_id}``
- Attachments are written to ``~/.cvc/email_attachments/``
"""
from __future__ import annotations

import asyncio
import email
import imaplib
import logging
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import parseaddr
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..base import Platform

logger = logging.getLogger(__name__)

DEFAULT_ATTACHMENT_DIR = Path.home() / ".cvc" / "email_attachments"


def _split_target(target: str) -> Tuple[str, Optional[str]]:
    if ":" in target:
        recipient, thread_id = target.split(":", 1)
        return recipient.strip(), thread_id.strip() or None
    return target.strip(), None


def _decode_header(raw: Any) -> str:
    if raw is None:
        return ""
    try:
        from email.header import decode_header, make_header

        return str(make_header(decode_header(raw)))
    except Exception:
        return str(raw)


class EmailPlatform(Platform):
    """SMTP+IMAP minimum-viable email platform."""

    @property
    def name(self) -> str:
        return "email"

    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        username: str,
        password: str,
        imap_host: Optional[str] = None,
        imap_port: int = 993,
        use_tls: bool = True,
        poll_interval: int = 30,
        mailbox: str = "INBOX",
        attachment_dir: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(config=config)
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.imap_host = imap_host or smtp_host
        self.imap_port = imap_port
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self.poll_interval = poll_interval
        self.mailbox = mailbox
        self.attachment_dir = Path(attachment_dir) if attachment_dir else DEFAULT_ATTACHMENT_DIR
        self.attachment_dir.mkdir(parents=True, exist_ok=True)
        self._poll_task: Optional[asyncio.Task] = None

    # ---------------- dict dispatch (overrides base InboundMessage path) ----------------
    async def _dispatch_dict(self, payload: Dict[str, Any]) -> None:
        for h in list(self._handlers):
            try:
                res = h(payload)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                logger.exception("email handler failed")

    # ---------------- SMTP send ----------------
    def _build_message(
        self,
        recipient: str,
        subject: str,
        body: str,
        thread_id: Optional[str] = None,
        attachments: Optional[List[str]] = None,
    ) -> EmailMessage:
        msg = EmailMessage()
        msg["From"] = self.username
        msg["To"] = recipient
        full_subject = f"[{thread_id}] {subject}" if thread_id else subject
        msg["Subject"] = full_subject
        msg.set_content(body or "")
        for path in attachments or []:
            try:
                p = Path(path)
                data = p.read_bytes()
                msg.add_attachment(
                    data,
                    maintype="application",
                    subtype="octet-stream",
                    filename=p.name,
                )
            except Exception:
                logger.exception("failed to attach %s", path)
        return msg

    def _smtp_send_sync(self, msg: EmailMessage) -> None:
        if self.use_tls:
            ctx = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls(context=ctx)
                server.login(self.username, self.password)
                server.send_message(msg)
        else:
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.login(self.username, self.password)
                server.send_message(msg)

    async def send_message(
        self,
        target: str,
        content: str,
        media: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        recipient, thread_id = _split_target(target)
        subject = kwargs.get("subject", "(no subject)")
        attachments = kwargs.get("attachments")
        if media and not attachments:
            attachments = [media]
        msg = self._build_message(
            recipient=recipient,
            subject=subject,
            body=content,
            thread_id=thread_id,
            attachments=attachments,
        )
        await asyncio.to_thread(self._smtp_send_sync, msg)
        return {
            "ok": True,
            "to": recipient,
            "thread_id": thread_id,
            "subject": msg["Subject"],
        }

    # ---------------- IMAP receive ----------------
    def _imap_connect(self) -> imaplib.IMAP4_SSL:
        conn = imaplib.IMAP4_SSL(self.imap_host, self.imap_port)
        conn.login(self.username, self.password)
        conn.select(self.mailbox)
        return conn

    def _save_attachment(self, part: Any, message_id: str) -> Optional[str]:
        filename = part.get_filename()
        if not filename:
            return None
        try:
            from email.header import decode_header, make_header

            filename = str(make_header(decode_header(filename)))
        except Exception:
            pass
        safe_id = "".join(c if c.isalnum() else "_" for c in (message_id or "msg"))[:64]
        target_dir = self.attachment_dir / safe_id
        target_dir.mkdir(parents=True, exist_ok=True)
        path = target_dir / filename
        try:
            payload = part.get_payload(decode=True)
            if payload:
                path.write_bytes(payload)
                return str(path)
        except Exception:
            logger.exception("failed to save attachment %s", filename)
        return None

    def _parse_message(self, raw_bytes: bytes) -> Dict[str, Any]:
        msg = email.message_from_bytes(raw_bytes)
        from_addr = parseaddr(_decode_header(msg.get("From")))[1]
        to_addr = parseaddr(_decode_header(msg.get("To")))[1]
        subject = _decode_header(msg.get("Subject"))
        message_id = msg.get("Message-ID", "")
        body = ""
        attachments: List[str] = []
        if msg.is_multipart():
            for part in msg.walk():
                disp = str(part.get("Content-Disposition", "")).lower()
                ctype = part.get_content_type()
                if "attachment" in disp or part.get_filename():
                    saved = self._save_attachment(part, message_id)
                    if saved:
                        attachments.append(saved)
                elif ctype == "text/plain" and not body:
                    try:
                        body = part.get_payload(decode=True).decode(
                            part.get_content_charset() or "utf-8", errors="replace"
                        )
                    except Exception:
                        body = ""
        else:
            try:
                payload = msg.get_payload(decode=True)
                if payload:
                    body = payload.decode(msg.get_content_charset() or "utf-8", errors="replace")
            except Exception:
                body = msg.get_payload() if isinstance(msg.get_payload(), str) else ""
        return {
            "from": from_addr,
            "to": to_addr,
            "subject": subject,
            "body": body,
            "attachments": attachments,
            "message_id": message_id,
        }

    def _fetch_unseen_sync(self) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        try:
            conn = self._imap_connect()
        except Exception:
            logger.exception("imap connect failed")
            return results
        try:
            status, data = conn.search(None, "UNSEEN")
            if status != "OK" or not data or not data[0]:
                return results
            ids = data[0].split()
            for uid in ids:
                status, msg_data = conn.fetch(uid, "(RFC822)")
                if status != "OK" or not msg_data:
                    continue
                for part in msg_data:
                    if isinstance(part, tuple) and len(part) >= 2:
                        try:
                            parsed = self._parse_message(part[1])
                            results.append(parsed)
                        except Exception:
                            logger.exception("parse message failed")
                try:
                    conn.store(uid, "+FLAGS", "\\Seen")
                except Exception:
                    pass
        finally:
            try:
                conn.close()
            except Exception:
                pass
            try:
                conn.logout()
            except Exception:
                pass
        return results

    async def poll_once(self) -> List[Dict[str, Any]]:
        msgs = await asyncio.to_thread(self._fetch_unseen_sync)
        for m in msgs:
            await self._dispatch_dict(m)
        return msgs

    async def _poll_loop(self) -> None:
        while self._running:
            try:
                await self.poll_once()
            except Exception:
                logger.exception("poll loop error")
            try:
                await asyncio.sleep(self.poll_interval)
            except asyncio.CancelledError:
                break

    async def start(self) -> None:
        self._running = True
        if self._poll_task is None or self._poll_task.done():
            self._poll_task = asyncio.create_task(self._poll_loop())

    async def stop(self) -> None:
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except (asyncio.CancelledError, Exception):
                pass
            self._poll_task = None
