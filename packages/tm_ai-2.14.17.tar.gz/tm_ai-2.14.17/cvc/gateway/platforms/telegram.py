"""Minimum-viable Telegram platform port for the CVC gateway.

Extracted from the full hermes-agent telegram adapter (3744 LOC). Covers ~90%
of real use: bot startup (polling), graceful shutdown, send_message with
text/photo/video/audio dispatch by file extension, MEDIA: inline tag handling,
markdown_v2 conversion, allow-list enforcement, and target parsing of the
``chat_id`` and ``chat_id:thread_id`` formats.

Deferred (intentionally not ported): stickers, reactions, polls, payments,
inline queries, complex media groups, voice transcription, business chat APIs,
advanced retry/rate-limit ladders.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
from typing import Any, Awaitable, Callable, Optional

logger = logging.getLogger(__name__)

# --- Lazy import of the abstract Platform base ------------------------------
try:
    from cvc.gateway.base import Platform  # type: ignore
except Exception:  # pragma: no cover - minimal stub fallback
    import abc

    class Platform(abc.ABC):  # type: ignore[no-redef]
        """Minimal stub of the gateway Platform ABC."""

        def __init__(self, config: Optional[dict] = None) -> None:
            self.config = config or {}
            self._handlers: list = []
            self._running: bool = False

        @property
        def name(self) -> str: ...
        async def start(self) -> None: ...
        async def stop(self) -> None: ...
        async def send_message(self, target, content, media=None, **kwargs): ...

        def on_message(self, handler):
            if not callable(handler):
                raise TypeError("handler must be callable")
            self._handlers.append(handler)
            return handler


# --- Media helpers ----------------------------------------------------------

PHOTO_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
VIDEO_EXTS = {".mp4", ".mov", ".m4v"}
AUDIO_EXTS = {".ogg", ".mp3", ".m4a", ".wav"}

MEDIA_TAG_RE = re.compile(r"MEDIA:(\S+)")


def classify_media(path: str) -> str:
    """Return one of ``photo``/``video``/``audio``/``document`` based on ext."""
    ext = os.path.splitext(path)[1].lower()
    if ext in PHOTO_EXTS:
        return "photo"
    if ext in VIDEO_EXTS:
        return "video"
    if ext in AUDIO_EXTS:
        return "audio"
    return "document"


def extract_media_tag(content: str) -> tuple[str, Optional[str]]:
    """Extract the first ``MEDIA:/path`` tag.

    Returns a tuple ``(stripped_content, media_path_or_None)``. The tag is
    removed from the returned content; surrounding whitespace is collapsed.
    """
    if not content:
        return content, None
    m = MEDIA_TAG_RE.search(content)
    if not m:
        return content, None
    media_path = m.group(1)
    stripped = (content[: m.start()] + content[m.end():]).strip()
    return stripped, media_path


# --- markdown_v2 ------------------------------------------------------------

# Per https://core.telegram.org/bots/api#markdownv2-style — escape these chars
# outside of code/pre/link contexts. We do a conservative blanket escape; the
# advanced ladder lives in the full hermes adapter.
_MDV2_SPECIALS = r"_*[]()~`>#+-=|{}.!"


def to_markdown_v2(text: str) -> str:
    """Conservatively escape text for Telegram MarkdownV2.

    The full adapter does context-aware escaping (preserving ``**bold**``,
    fenced code, etc.). This MVP escapes every reserved char so message text
    never trips Telegram's strict parser. Callers that want real formatting
    should pass ``parse_mode=None``.
    """
    if not text:
        return text
    out = []
    for ch in text:
        if ch in _MDV2_SPECIALS:
            out.append("\\" + ch)
        else:
            out.append(ch)
    return "".join(out)


# --- Target parsing ---------------------------------------------------------

def parse_target(target: str) -> tuple[int, Optional[int]]:
    """Parse a target string of the form ``chat_id`` or ``chat_id:thread_id``.

    Both halves must be integer-coercible. Returns ``(chat_id, thread_id)``
    where ``thread_id`` is ``None`` when not provided.
    """
    if target is None:
        raise ValueError("target is required")
    s = str(target).strip()
    if not s:
        raise ValueError("target is empty")
    if ":" in s:
        chat_str, thread_str = s.split(":", 1)
        return int(chat_str), int(thread_str)
    return int(s), None


# --- Platform implementation ------------------------------------------------

class TelegramPlatform(Platform):
    """Minimum-viable Telegram adapter.

    Parameters
    ----------
    bot_token:
        Bot token from @BotFather.
    allowed_user_ids:
        Optional allow-list. When set, messages from users not in the list
        are silently dropped before reaching the registered handler.
    """

    def __init__(
        self,
        bot_token: str,
        allowed_user_ids: Optional[list[int]] = None,
        config: Optional[dict] = None,
    ) -> None:
        if not bot_token:
            raise ValueError("bot_token is required")
        super().__init__(config=config)
        self.bot_token = bot_token
        self.allowed_user_ids: Optional[set[int]] = (
            set(allowed_user_ids) if allowed_user_ids else None
        )
        self._app = None  # python-telegram-bot Application
        self._started = False

    @property
    def name(self) -> str:
        return "telegram"

    # -- lifecycle ----------------------------------------------------------

    async def start(self) -> None:
        """Boot the python-telegram-bot Application in polling mode."""
        if self._started:
            return
        # Imported lazily so tests can mock without the dep installed locally.
        from telegram.ext import (  # type: ignore
            Application,
            MessageHandler,
            filters,
        )

        self._app = Application.builder().token(self.bot_token).build()
        self._app.add_handler(
            MessageHandler(filters.ALL & (~filters.StatusUpdate.ALL), self._on_update)
        )

        await self._app.initialize()
        await self._app.start()
        # updater is the polling driver in PTB v21
        if getattr(self._app, "updater", None) is not None:
            await self._app.updater.start_polling(drop_pending_updates=True)
        self._started = True
        self._running = True
        logger.info("TelegramPlatform started (polling)")

    async def stop(self) -> None:
        """Graceful shutdown of the underlying Application."""
        if not self._started or self._app is None:
            return
        try:
            if getattr(self._app, "updater", None) is not None:
                await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
        except Exception:  # pragma: no cover - best-effort shutdown
            logger.exception("TelegramPlatform shutdown error")
        finally:
            self._started = False
            self._running = False
            logger.info("TelegramPlatform stopped")

    # -- inbound -----------------------------------------------------------

    async def _on_update(self, update, context) -> None:  # pragma: no cover - PTB integration
        """Internal PTB callback: normalise update → dict → user handler."""
        msg = getattr(update, "effective_message", None) or getattr(update, "message", None)
        user = getattr(update, "effective_user", None)
        if msg is None or user is None:
            return

        user_id = getattr(user, "id", None)
        if self.allowed_user_ids is not None and user_id not in self.allowed_user_ids:
            logger.debug("Drop msg from %s (not in allow-list)", user_id)
            return

        media_path: Optional[str] = None
        try:
            media_path = await self._download_media(msg, context)
        except Exception:
            logger.exception("media download failed")

        reply_to = None
        rt = getattr(msg, "reply_to_message", None)
        if rt is not None:
            reply_to = getattr(rt, "message_id", None)

        normalised = {
            "text": getattr(msg, "text", None) or getattr(msg, "caption", None) or "",
            "chat_id": getattr(getattr(msg, "chat", None), "id", None),
            "user_id": user_id,
            "username": getattr(user, "username", None),
            "thread_id": getattr(msg, "message_thread_id", None),
            "media_path": media_path,
            "reply_to": reply_to,
        }

        if not self._handlers:
            return
        for h in list(self._handlers):
            try:
                result = h(normalised)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                logger.exception("user handler raised")

    async def _download_media(self, msg, context) -> Optional[str]:  # pragma: no cover
        """Best-effort: download attached photo/video/audio/document to /tmp."""
        for attr, ext in (
            ("photo", ".jpg"),
            ("video", ".mp4"),
            ("audio", ".ogg"),
            ("voice", ".ogg"),
            ("document", ""),
        ):
            obj = getattr(msg, attr, None)
            if not obj:
                continue
            tg_file = obj[-1] if attr == "photo" else obj
            file = await context.bot.get_file(tg_file.file_id)
            suffix = ext or os.path.splitext(getattr(tg_file, "file_name", "") or "")[1]
            out = f"/tmp/cvc_tg_{tg_file.file_unique_id}{suffix}"
            await file.download_to_drive(out)
            return out
        return None

    # -- outbound ----------------------------------------------------------

    async def send_message(
        self,
        target: str,
        content: str,
        media: Optional[str] = None,
    ) -> Any:
        """Send a message to ``target``.

        - ``target`` may be ``chat_id`` or ``chat_id:thread_id``.
        - Inline ``MEDIA:/abs/path.ext`` in ``content`` is detected and routed
          to the appropriate send_* method by extension.
        - ``media`` parameter takes precedence over an inline tag.
        """
        chat_id, thread_id = parse_target(target)

        # Resolve media: explicit kwarg wins over inline tag.
        text = content or ""
        inline_path: Optional[str] = None
        if media is None:
            text, inline_path = extract_media_tag(text)
            media = inline_path

        if media:
            kind = classify_media(media)
            method_name = {
                "photo": "_send_photo",
                "video": "_send_video",
                "audio": "_send_audio",
                "document": "_send_document",
            }[kind]
            method = getattr(self, method_name)
            return await method(chat_id, thread_id, media, text)

        return await self._send_text(chat_id, thread_id, text)

    # -- low-level senders -------------------------------------------------

    def _bot(self):
        if self._app is None:
            # Build a bare Bot for stand-alone send (e.g. one-shot scripts).
            from telegram import Bot  # type: ignore
            return Bot(self.bot_token)
        return self._app.bot

    @staticmethod
    def _kwargs(thread_id: Optional[int]) -> dict:
        return {"message_thread_id": thread_id} if thread_id is not None else {}

    async def _send_text(self, chat_id: int, thread_id: Optional[int], text: str):
        bot = self._bot()
        return await bot.send_message(
            chat_id=chat_id,
            text=to_markdown_v2(text),
            parse_mode="MarkdownV2",
            **self._kwargs(thread_id),
        )

    async def _send_photo(self, chat_id: int, thread_id: Optional[int], path: str, caption: str):
        bot = self._bot()
        with open(path, "rb") as fh:
            return await bot.send_photo(
                chat_id=chat_id,
                photo=fh,
                caption=to_markdown_v2(caption) if caption else None,
                parse_mode="MarkdownV2" if caption else None,
                **self._kwargs(thread_id),
            )

    async def _send_video(self, chat_id: int, thread_id: Optional[int], path: str, caption: str):
        bot = self._bot()
        with open(path, "rb") as fh:
            return await bot.send_video(
                chat_id=chat_id,
                video=fh,
                caption=to_markdown_v2(caption) if caption else None,
                parse_mode="MarkdownV2" if caption else None,
                **self._kwargs(thread_id),
            )

    async def _send_audio(self, chat_id: int, thread_id: Optional[int], path: str, caption: str):
        bot = self._bot()
        with open(path, "rb") as fh:
            return await bot.send_audio(
                chat_id=chat_id,
                audio=fh,
                caption=to_markdown_v2(caption) if caption else None,
                parse_mode="MarkdownV2" if caption else None,
                **self._kwargs(thread_id),
            )

    async def _send_document(self, chat_id: int, thread_id: Optional[int], path: str, caption: str):
        bot = self._bot()
        with open(path, "rb") as fh:
            return await bot.send_document(
                chat_id=chat_id,
                document=fh,
                caption=to_markdown_v2(caption) if caption else None,
                parse_mode="MarkdownV2" if caption else None,
                **self._kwargs(thread_id),
            )


__all__ = [
    "TelegramPlatform",
    "parse_target",
    "classify_media",
    "extract_media_tag",
    "to_markdown_v2",
]
