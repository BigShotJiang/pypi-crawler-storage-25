"""Discord platform for the CVC gateway.

Minimum-viable port using :mod:`discord.py`:

- bot init via ``bot_token``
- target format: ``channel_id`` or ``channel_id:thread_id``
- :meth:`send_message` sends text + optional media (auto-detect by extension)
- inbound handler payload:
  ``{content, channel_id, thread_id, user_id, username, attachments}``
- optional allow-lists: ``allowed_guild_ids`` and ``allowed_user_ids``
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import Any, Dict, Iterable, List, Optional, Tuple

from ..base import Platform

logger = logging.getLogger(__name__)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
VIDEO_EXTS = {".mp4", ".mov", ".webm", ".mkv"}
AUDIO_EXTS = {".ogg", ".mp3", ".wav", ".m4a"}


def _split_target(target: str) -> Tuple[int, Optional[int]]:
    """Parse ``channel_id`` or ``channel_id:thread_id``."""
    s = str(target).strip()
    if ":" in s:
        a, b = s.split(":", 1)
        return int(a.strip()), (int(b.strip()) if b.strip() else None)
    return int(s), None


def _classify_media(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    if ext in AUDIO_EXTS:
        return "audio"
    return "file"


class DiscordPlatform(Platform):
    """Minimum-viable Discord platform built on discord.py."""

    @property
    def name(self) -> str:
        return "discord"

    def __init__(
        self,
        bot_token: str,
        allowed_guild_ids: Optional[Iterable[int]] = None,
        allowed_user_ids: Optional[Iterable[int]] = None,
        intents: Any = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(config=config)
        self.bot_token = bot_token
        self.allowed_guild_ids = set(int(x) for x in (allowed_guild_ids or []))
        self.allowed_user_ids = set(int(x) for x in (allowed_user_ids or []))
        self._client: Any = None
        self._intents = intents
        self._run_task: Optional[asyncio.Task] = None
        self._ready_event: Optional[asyncio.Event] = None

    # ---------------- client management ----------------
    def _build_client(self) -> Any:
        import discord  # imported lazily so tests can patch

        intents = self._intents
        if intents is None:
            try:
                intents = discord.Intents.default()
                # message content intent is required for on_message text
                if hasattr(intents, "message_content"):
                    intents.message_content = True
            except Exception:
                intents = None
        client = discord.Client(intents=intents) if intents is not None else discord.Client()

        @client.event
        async def on_ready() -> None:  # pragma: no cover - exercised at runtime
            logger.info("discord ready as %s", getattr(client.user, "name", "?"))
            if self._ready_event is not None:
                self._ready_event.set()

        @client.event
        async def on_message(message: Any) -> None:
            await self._handle_incoming(message)

        return client

    def _is_allowed(self, message: Any) -> bool:
        # filter our own bot messages
        try:
            if self._client is not None and message.author.id == self._client.user.id:
                return False
        except Exception:
            pass
        try:
            if getattr(message.author, "bot", False):
                return False
        except Exception:
            pass
        if self.allowed_user_ids:
            try:
                if int(message.author.id) not in self.allowed_user_ids:
                    return False
            except Exception:
                return False
        if self.allowed_guild_ids:
            guild = getattr(message, "guild", None)
            gid = getattr(guild, "id", None) if guild else None
            try:
                if gid is None or int(gid) not in self.allowed_guild_ids:
                    return False
            except Exception:
                return False
        return True

    async def _handle_incoming(self, message: Any) -> None:
        if not self._is_allowed(message):
            return
        channel = getattr(message, "channel", None)
        channel_id = getattr(channel, "id", None)
        thread_id: Optional[int] = None
        # discord.py: Thread is a subclass of TextChannel-like; detect via parent
        try:
            import discord  # noqa: F401

            parent = getattr(channel, "parent", None)
            if parent is not None:
                thread_id = channel_id
                channel_id = getattr(parent, "id", channel_id)
        except Exception:
            pass
        attachments: List[Dict[str, Any]] = []
        for att in getattr(message, "attachments", []) or []:
            attachments.append(
                {
                    "filename": getattr(att, "filename", None),
                    "url": getattr(att, "url", None),
                    "size": getattr(att, "size", None),
                    "content_type": getattr(att, "content_type", None),
                }
            )
        author = getattr(message, "author", None)
        payload = {
            "content": getattr(message, "content", "") or "",
            "channel_id": channel_id,
            "thread_id": thread_id,
            "user_id": getattr(author, "id", None) if author else None,
            "username": getattr(author, "name", None) if author else None,
            "attachments": attachments,
        }
        await self._dispatch(payload)

    # ---------------- send ----------------
    async def _resolve_send_target(self, target: str) -> Any:
        if self._client is None:
            raise RuntimeError("discord client not started")
        channel_id, thread_id = _split_target(target)
        chan = self._client.get_channel(thread_id or channel_id)
        if chan is None:
            try:
                chan = await self._client.fetch_channel(thread_id or channel_id)
            except Exception:
                chan = None
        if chan is None:
            raise RuntimeError(f"could not resolve channel {target}")
        return chan

    async def send_message(
        self,
        target: str,
        content: str = "",
        media: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        import discord  # lazy import for patchability

        chan = await self._resolve_send_target(target)
        files: List[Any] = []
        for path in media or []:
            try:
                files.append(discord.File(path))
            except Exception:
                logger.exception("failed to wrap file %s", path)
        send_kwargs: Dict[str, Any] = {}
        if content:
            send_kwargs["content"] = content
        if files:
            send_kwargs["files"] = files
        msg = await chan.send(**send_kwargs)
        return {
            "ok": True,
            "channel_id": getattr(chan, "id", None),
            "message_id": getattr(msg, "id", None),
            "media_kinds": [_classify_media(p) for p in (media or [])],
        }

    # ---------------- lifecycle ----------------
    async def start(self) -> None:
        await super().start()
        if self._client is None:
            self._client = self._build_client()
        self._ready_event = asyncio.Event()
        # discord.py's Client.start is awaitable
        self._run_task = asyncio.create_task(self._client.start(self.bot_token))

    async def stop(self) -> None:
        await super().stop()
        if self._client is not None:
            try:
                await self._client.close()
            except Exception:
                pass
        if self._run_task:
            try:
                await asyncio.wait_for(self._run_task, timeout=5)
            except Exception:
                self._run_task.cancel()
            self._run_task = None
