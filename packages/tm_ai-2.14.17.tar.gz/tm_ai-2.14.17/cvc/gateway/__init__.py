"""CVC Gateway — multi-platform messaging framework.

Minimal viable port of the Hermes gateway architecture. Provides:
- A lightweight Platform ABC (cvc.gateway.base)
- A registry with auto-discovery of cvc.gateway.platforms.* subpackages
- Target-string parsing & delivery routing
- A FastAPI runner exposing /health /platforms /send /status

Actual platform adapters (telegram, discord, email, ...) live in
cvc.gateway.platforms.<name>/ and are loaded on demand.
"""

from __future__ import annotations

from cvc.gateway.base import Platform, MessageHandler
from cvc.gateway.delivery import MessageDelivery, parse_target, send
from cvc.gateway.registry import (
    register_platform,
    get_platform,
    list_platforms,
    unregister_platform,
    discover_platforms,
)
from cvc.gateway.run import run_gateway, build_app
from cvc.gateway.session import GatewaySession

__all__ = [
    "Platform",
    "MessageHandler",
    "MessageDelivery",
    "parse_target",
    "send",
    "register_platform",
    "get_platform",
    "list_platforms",
    "unregister_platform",
    "discover_platforms",
    "run_gateway",
    "build_app",
    "GatewaySession",
]
