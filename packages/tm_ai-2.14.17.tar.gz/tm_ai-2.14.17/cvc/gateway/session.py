"""GatewaySession — tracks active platform connections and manages shutdown."""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

from cvc.gateway.base import Platform
from cvc.gateway.registry import all_platforms, register_platform

logger = logging.getLogger(__name__)


class GatewaySession:
    """Lifecycle manager for the set of platforms loaded into the gateway."""

    def __init__(self, platforms: Optional[list[Platform]] = None) -> None:
        self._platforms: list[Platform] = list(platforms) if platforms else []
        self._started: bool = False

    # ── Membership ──────────────────────────────────────────────────────
    def add(self, platform: Platform, *, register: bool = True) -> None:
        """Add a platform to the session and optionally register it globally."""
        if platform not in self._platforms:
            self._platforms.append(platform)
        if register:
            register_platform(platform)

    @property
    def platforms(self) -> list[Platform]:
        return list(self._platforms)

    @property
    def is_started(self) -> bool:
        return self._started

    # ── Lifecycle ───────────────────────────────────────────────────────
    async def start_all(self) -> None:
        """Concurrently start every platform in the session."""
        if self._started:
            return
        results = await asyncio.gather(
            *(self._safe_start(p) for p in self._platforms),
            return_exceptions=False,
        )
        self._started = True
        logger.info("GatewaySession started with %d platform(s)", sum(1 for r in results if r))

    async def stop_all(self) -> None:
        """Graceful shutdown — stop all platforms; never raise."""
        if not self._platforms:
            self._started = False
            return
        await asyncio.gather(
            *(self._safe_stop(p) for p in self._platforms),
            return_exceptions=False,
        )
        self._started = False
        logger.info("GatewaySession stopped")

    # ── Discovery helper ────────────────────────────────────────────────
    @classmethod
    def from_registry(cls) -> "GatewaySession":
        """Build a session from currently-registered platforms."""
        return cls(all_platforms())

    # ── Internals ───────────────────────────────────────────────────────
    async def _safe_start(self, platform: Platform) -> bool:
        try:
            await platform.start()
            platform._running = True  # type: ignore[attr-defined]
            return True
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to start platform %s: %s", platform.name, exc)
            return False

    async def _safe_stop(self, platform: Platform) -> bool:
        try:
            await platform.stop()
            platform._running = False  # type: ignore[attr-defined]
            return True
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to stop platform %s: %s", platform.name, exc)
            return False
