"""Delivery routing for CVC Gateway.

Parses target strings of the form ``"platform:chat_id[:thread_id]"`` and
routes outbound sends to the matching registered platform.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional

from cvc.gateway.registry import get_platform

logger = logging.getLogger(__name__)


@dataclass
class MessageDelivery:
    """A single outbound delivery descriptor."""

    target: str  # The original full target string ("telegram:123:456")
    content: str
    media: Optional[str] = None
    thread_id: Optional[str] = None
    reply_to: Optional[str] = None

    @property
    def platform(self) -> str:
        return parse_target(self.target)[0]

    @property
    def chat_id(self) -> Optional[str]:
        return parse_target(self.target)[1]


def parse_target(target_str: str) -> tuple[str, Optional[str], Optional[str]]:
    """Parse ``"platform:chat_id[:thread_id]"`` → (platform, chat_id, thread_id).

    Examples
    --------
    >>> parse_target("telegram:12345")
    ('telegram', '12345', None)
    >>> parse_target("discord:987:thread-1")
    ('discord', '987', 'thread-1')
    >>> parse_target("email")
    ('email', None, None)
    """
    if not target_str or not isinstance(target_str, str):
        raise ValueError("target must be a non-empty string")

    s = target_str.strip()
    if not s:
        raise ValueError("target must be a non-empty string")

    if ":" not in s:
        return s.lower(), None, None

    parts = s.split(":", 2)
    platform = parts[0].strip().lower()
    if not platform:
        raise ValueError(f"invalid target string: {target_str!r}")
    chat_id = parts[1].strip() if len(parts) > 1 and parts[1].strip() else None
    thread_id = parts[2].strip() if len(parts) > 2 and parts[2].strip() else None
    return platform, chat_id, thread_id


async def send(
    target_str: str,
    content: str,
    media: Optional[str] = None,
    **kwargs: Any,
) -> dict:
    """Route a send to the appropriate registered platform.

    Raises ``ValueError`` if the target is malformed or the platform
    is not registered.
    """
    platform_name, chat_id, thread_id = parse_target(target_str)
    platform = get_platform(platform_name)
    if platform is None:
        raise ValueError(f"unknown platform: {platform_name!r}")

    delivery_target = chat_id if chat_id is not None else ""
    if thread_id is not None and "thread_id" not in kwargs:
        kwargs["thread_id"] = thread_id

    logger.debug("Dispatching to %s → %s", platform_name, delivery_target)
    return await platform.send_message(delivery_target, content, media=media, **kwargs)
