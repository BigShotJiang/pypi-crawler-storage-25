"""FastAPI runner for the CVC Gateway.

Exposes a tiny HTTP surface on port 13421 (configurable):

- ``GET  /health``     → liveness probe
- ``GET  /platforms``  → list registered platforms
- ``GET  /status``     → richer status (platform count, running state)
- ``POST /send``       → dispatch a message to a parsed target
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from cvc.gateway.delivery import parse_target, send
from cvc.gateway.registry import all_platforms, discover_platforms, list_platforms
from cvc.gateway.session import GatewaySession

logger = logging.getLogger(__name__)

DEFAULT_PORT = 13421


class SendRequest(BaseModel):
    target: str
    content: str
    media: Optional[str] = None


def build_app(session: Optional[GatewaySession] = None) -> FastAPI:
    """Construct the FastAPI app. Useful for tests via ``TestClient``."""
    app = FastAPI(title="CVC Gateway", version="0.1.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost",
            "http://localhost:3000",
            "http://localhost:5173",
            "http://127.0.0.1",
        ],
        allow_origin_regex=r"https?://(localhost|127\.0\.0\.1)(:\d+)?",
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health() -> dict:
        return {"status": "ok", "service": "cvc-gateway"}

    @app.get("/platforms")
    async def platforms_endpoint() -> dict:
        return {"platforms": list_platforms()}

    @app.get("/status")
    async def status() -> dict:
        plats = all_platforms()
        return {
            "service": "cvc-gateway",
            "platform_count": len(plats),
            "platforms": [
                {"name": p.name, "running": p.is_running} for p in plats
            ],
            "session_started": bool(session and session.is_started),
        }

    @app.post("/send")
    async def send_endpoint(req: SendRequest) -> dict:
        try:
            platform_name, _chat_id, _thread_id = parse_target(req.target)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        if platform_name not in list_platforms():
            raise HTTPException(
                status_code=404,
                detail=f"platform '{platform_name}' is not registered",
            )

        try:
            result = await send(req.target, req.content, media=req.media)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except Exception as exc:  # noqa: BLE001
            logger.exception("send failed for target=%r", req.target)
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return {"ok": True, "target": req.target, "result": result}

    return app


async def run_gateway(config: Optional[dict[str, Any]] = None) -> None:
    """Async entrypoint: start configured platforms and serve FastAPI."""
    import uvicorn  # local import — avoids hard dep at import time

    config = dict(config or {})
    port = int(config.get("port", DEFAULT_PORT))
    host = str(config.get("host", "127.0.0.1"))

    discover_platforms()
    session = GatewaySession.from_registry()
    await session.start_all()

    app = build_app(session=session)

    server_config = uvicorn.Config(
        app, host=host, port=port, log_level=config.get("log_level", "info")
    )
    server = uvicorn.Server(server_config)

    try:
        await server.serve()
    finally:
        await session.stop_all()
