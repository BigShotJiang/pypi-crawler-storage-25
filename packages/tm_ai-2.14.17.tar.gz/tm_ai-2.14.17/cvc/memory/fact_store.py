"""FactStore — Hermes-compatible structured fact memory facade.

Backed by SQLite at ~/.cvc/facts.db. Provides keyword search, entity
resolution (probe/related/reason), trust scoring, and naive contradiction
detection. Intended as the parity port of Hermes' fact_store, sitting
alongside CVC's Cognome/Holographic substrate without depending on it.
"""
from __future__ import annotations

import os
import re
import sqlite3
import time
from pathlib import Path
from typing import Iterable, List, Optional


_ENTITY_RE = re.compile(r"\b[A-Z][A-Za-z0-9_]{1,}\b")
_NEG_RE = re.compile(r"\bis\s+not\b|\bisn'?t\b|\bnot\b", re.IGNORECASE)


def _default_db_path() -> Path:
    root = Path(os.environ.get("CVC_HOME", str(Path.home() / ".cvc")))
    root.mkdir(parents=True, exist_ok=True)
    return root / "facts.db"


def _extract_entities(text: str) -> List[str]:
    seen: set[str] = set()
    out: List[str] = []
    for m in _ENTITY_RE.findall(text or ""):
        if m.lower() in {"the", "a", "an", "is", "it"}:
            continue
        if m not in seen:
            seen.add(m)
            out.append(m)
    return out


class FactStore:
    """Thin SQLite-backed structured memory with Hermes-compatible API."""

    def __init__(self, db_path: Optional[str | Path] = None) -> None:
        self.db_path = Path(db_path) if db_path else _default_db_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    # ------------------------------------------------------------ schema
    def _init_schema(self) -> None:
        c = self._conn
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS facts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                tags TEXT DEFAULT '',
                trust REAL DEFAULT 0.7,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                helpful_count INTEGER DEFAULT 0,
                unhelpful_count INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS entities (
                fact_id INTEGER NOT NULL,
                entity TEXT NOT NULL,
                FOREIGN KEY(fact_id) REFERENCES facts(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_entities_entity ON entities(entity);
            CREATE INDEX IF NOT EXISTS idx_entities_fact ON entities(fact_id);
            CREATE INDEX IF NOT EXISTS idx_facts_category ON facts(category);
            """
        )
        c.commit()

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass

    # ------------------------------------------------------------ helpers
    def _row_to_dict(self, row: sqlite3.Row) -> dict:
        return {
            "id": row["id"],
            "content": row["content"],
            "category": row["category"],
            "tags": row["tags"],
            "trust": row["trust"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "helpful_count": row["helpful_count"],
            "unhelpful_count": row["unhelpful_count"],
        }

    def _index_entities(self, fact_id: int, content: str) -> None:
        ents = _extract_entities(content)
        self._conn.execute("DELETE FROM entities WHERE fact_id = ?", (fact_id,))
        if ents:
            self._conn.executemany(
                "INSERT INTO entities(fact_id, entity) VALUES (?, ?)",
                [(fact_id, e) for e in ents],
            )

    # ------------------------------------------------------------ CRUD
    def add(
        self,
        content: str,
        category: str = "general",
        tags: str = "",
        trust: float = 0.7,
    ) -> int:
        now = time.time()
        trust = max(0.0, min(1.0, float(trust)))
        cur = self._conn.execute(
            "INSERT INTO facts(content, category, tags, trust, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (content, category, tags, trust, now, now),
        )
        fact_id = int(cur.lastrowid)
        self._index_entities(fact_id, content)
        self._conn.commit()
        return fact_id

    def update(
        self,
        fact_id: int,
        content: Optional[str] = None,
        trust_delta: Optional[float] = None,
        tags: Optional[str] = None,
    ) -> bool:
        row = self._conn.execute(
            "SELECT * FROM facts WHERE id = ?", (fact_id,)
        ).fetchone()
        if not row:
            return False
        new_content = content if content is not None else row["content"]
        new_trust = row["trust"]
        if trust_delta is not None:
            new_trust = max(0.0, min(1.0, row["trust"] + float(trust_delta)))
        new_tags = tags if tags is not None else row["tags"]
        self._conn.execute(
            "UPDATE facts SET content=?, trust=?, tags=?, updated_at=? WHERE id=?",
            (new_content, new_trust, new_tags, time.time(), fact_id),
        )
        if content is not None:
            self._index_entities(fact_id, new_content)
        self._conn.commit()
        return True

    def remove(self, fact_id: int) -> bool:
        cur = self._conn.execute("DELETE FROM facts WHERE id = ?", (fact_id,))
        self._conn.execute("DELETE FROM entities WHERE fact_id = ?", (fact_id,))
        self._conn.commit()
        return cur.rowcount > 0

    def list(self, category: Optional[str] = None, limit: int = 20) -> List[dict]:
        if category:
            rows = self._conn.execute(
                "SELECT * FROM facts WHERE category = ? ORDER BY updated_at DESC LIMIT ?",
                (category, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM facts ORDER BY updated_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # ------------------------------------------------------------ search
    def search(
        self, query: str, limit: int = 10, min_trust: float = 0.3
    ) -> List[dict]:
        like = f"%{query}%"
        rows = self._conn.execute(
            "SELECT * FROM facts WHERE content LIKE ? AND trust >= ? "
            "ORDER BY trust DESC, updated_at DESC LIMIT ?",
            (like, min_trust, limit),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def probe(self, entity: str, limit: int = 10) -> List[dict]:
        rows = self._conn.execute(
            "SELECT f.* FROM facts f "
            "JOIN entities e ON e.fact_id = f.id "
            "WHERE e.entity = ? "
            "ORDER BY f.trust DESC, f.updated_at DESC LIMIT ?",
            (entity, limit),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def related(self, entity: str, limit: int = 10) -> List[dict]:
        rows = self._conn.execute(
            "SELECT e2.entity AS entity, COUNT(*) AS cooc "
            "FROM entities e1 JOIN entities e2 ON e1.fact_id = e2.fact_id "
            "WHERE e1.entity = ? AND e2.entity != ? "
            "GROUP BY e2.entity ORDER BY cooc DESC LIMIT ?",
            (entity, entity, limit),
        ).fetchall()
        return [{"entity": r["entity"], "cooccurrence": r["cooc"]} for r in rows]

    def reason(self, entities: Iterable[str], limit: int = 10) -> List[dict]:
        ents = [e for e in entities if e]
        if not ents:
            return []
        placeholders = ",".join("?" for _ in ents)
        rows = self._conn.execute(
            f"SELECT f.* FROM facts f "
            f"JOIN entities e ON e.fact_id = f.id "
            f"WHERE e.entity IN ({placeholders}) "
            f"GROUP BY f.id HAVING COUNT(DISTINCT e.entity) = ? "
            f"ORDER BY f.trust DESC LIMIT ?",
            (*ents, len(set(ents)), limit),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def contradict(self, limit: int = 10) -> List[dict]:
        """Naive contradiction detection.

        Pairs facts whose content shares an 'is X' / 'is not X' subject.
        Returns list of {'a': fact, 'b': fact} pairs.
        """
        rows = self._conn.execute("SELECT * FROM facts").fetchall()
        # Bucket by (subject, predicate-token) → list of (negated, row)
        buckets: dict[tuple[str, str], list[tuple[bool, sqlite3.Row]]] = {}
        for r in rows:
            text = r["content"]
            # very simple: capture "<Subject> is [not] <Word>"
            m = re.search(
                r"\b([A-Z][A-Za-z0-9_]*)\s+(?:is|are)\s+(not\s+)?([A-Za-z][A-Za-z0-9_]*)",
                text,
            )
            if not m:
                continue
            subj, neg, pred = m.group(1), bool(m.group(2)), m.group(3).lower()
            buckets.setdefault((subj, pred), []).append((neg, r))

        pairs: List[dict] = []
        for (_subj, _pred), items in buckets.items():
            pos = [r for n, r in items if not n]
            neg = [r for n, r in items if n]
            for a in pos:
                for b in neg:
                    pairs.append({"a": self._row_to_dict(a), "b": self._row_to_dict(b)})
                    if len(pairs) >= limit:
                        return pairs
        return pairs

    # ------------------------------------------------------------ feedback
    def feedback(self, fact_id: int, action: str) -> Optional[float]:
        row = self._conn.execute(
            "SELECT trust, helpful_count, unhelpful_count FROM facts WHERE id = ?",
            (fact_id,),
        ).fetchone()
        if not row:
            return None
        if action == "helpful":
            new_trust = min(1.0, row["trust"] + 0.1)
            self._conn.execute(
                "UPDATE facts SET trust=?, helpful_count=helpful_count+1, updated_at=? WHERE id=?",
                (new_trust, time.time(), fact_id),
            )
        elif action == "unhelpful":
            new_trust = max(0.0, row["trust"] - 0.1)
            self._conn.execute(
                "UPDATE facts SET trust=?, unhelpful_count=unhelpful_count+1, updated_at=? WHERE id=?",
                (new_trust, time.time(), fact_id),
            )
        else:
            raise ValueError(f"unknown feedback action: {action}")
        self._conn.commit()
        return new_trust
