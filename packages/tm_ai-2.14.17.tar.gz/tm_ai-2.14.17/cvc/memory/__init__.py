"""CVC structured memory: fact store facade over SQLite/Holographic."""
from cvc.memory.fact_store import FactStore

__all__ = ["FactStore"]
