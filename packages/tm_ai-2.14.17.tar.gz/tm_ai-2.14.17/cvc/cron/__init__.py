"""CVC cron package — scheduled job execution.

Public API:
    CronManager  — high-level facade for managing scheduled jobs
    Job          — dataclass representing a scheduled job
    JobStore     — low-level SQLite-backed persistence
    CronScheduler— tick-driven scheduler
    parse_schedule(spec)         — validate/normalize a schedule spec
    next_run_time(spec, now=None)— compute the next datetime a spec is due
"""
from .jobs import Job, JobStore
from .schedule import parse_schedule, next_run_time
from .scheduler import CronScheduler
from .manager import CronManager

__all__ = [
    "Job",
    "JobStore",
    "CronScheduler",
    "CronManager",
    "parse_schedule",
    "next_run_time",
]
