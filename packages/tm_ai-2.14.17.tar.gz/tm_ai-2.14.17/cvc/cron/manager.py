"""High-level CronManager facade."""
from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from .jobs import Job, JobStore
from .schedule import next_run_time, parse_schedule
from .scheduler import CronScheduler, ExecutorFn


class CronManager:
    """Facade combining JobStore + CronScheduler."""

    def __init__(
        self,
        db_path: Optional[str | Path] = None,
        executor: Optional[ExecutorFn] = None,
        store: Optional[JobStore] = None,
    ):
        self.store = store or JobStore(db_path)
        self.scheduler = CronScheduler(self.store, executor=executor)

    # ---- executor wiring ---------------------------------------------
    def set_executor(self, fn: ExecutorFn) -> None:
        self.scheduler.set_executor(fn)

    # ---- CRUD --------------------------------------------------------
    def create(
        self,
        name: str,
        schedule: str,
        prompt: str = "",
        **fields: Any,
    ) -> Job:
        # validate schedule up front
        parse_schedule(schedule)
        job = Job(name=name, schedule=schedule, prompt=prompt, **{
            k: v for k, v in fields.items()
            if k in {
                "skills", "deliver", "enabled", "repeat_count", "workdir",
                "model", "no_agent", "script", "enabled_toolsets",
                "context_from", "id",
            }
        })
        job.next_run = next_run_time(schedule, datetime.now()).timestamp()
        self.store.add(job)
        return job

    def list(self, enabled_only: bool = False) -> list[Job]:
        return self.store.list(enabled_only=enabled_only)

    def get(self, job_id: str) -> Optional[Job]:
        return self.store.get(job_id)

    def update(self, job_id: str, **fields: Any) -> Optional[Job]:
        if "schedule" in fields and fields["schedule"]:
            parse_schedule(fields["schedule"])
            fields.setdefault(
                "next_run",
                next_run_time(fields["schedule"], datetime.now()).timestamp(),
            )
        return self.store.update(job_id, **fields)

    def pause(self, job_id: str) -> Optional[Job]:
        return self.store.update(job_id, enabled=False)

    def resume(self, job_id: str) -> Optional[Job]:
        job = self.store.get(job_id)
        if not job:
            return None
        nxt = next_run_time(job.schedule, datetime.now()).timestamp()
        return self.store.update(job_id, enabled=True, next_run=nxt)

    def remove(self, job_id: str) -> bool:
        return self.store.remove(job_id)

    # ---- execution helpers -------------------------------------------
    def run_now(self, job_id: str) -> dict:
        """Force-run a job once, immediately, regardless of schedule."""
        job = self.store.get(job_id)
        if not job:
            raise KeyError(job_id)
        result = {"job_id": job_id, "ok": True, "error": None, "result": None}
        try:
            result["result"] = self.scheduler.executor(job)
        except Exception as e:
            result["ok"] = False
            result["error"] = str(e)
        now = time.time()
        new_runs = job.runs_completed + 1
        next_ts = self.scheduler.reschedule(job, datetime.fromtimestamp(now))
        updates = {"last_run": now, "runs_completed": new_runs, "next_run": next_ts}
        if next_ts is None and job.enabled:
            # only auto-disable if it was a one-shot completion
            pass
        self.store.update(job_id, **updates)
        return result

    def tick(self, now: Optional[float] = None) -> list[dict]:
        return self.scheduler.tick(now)

    def close(self) -> None:
        self.store.close()
