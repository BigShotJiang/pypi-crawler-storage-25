"""Schedule parsing and next-run computation.

Supports:
    * cron expressions: '0 9 * * *' (5 fields: min hour dom mon dow)
    * relative offsets: '30m', '2h', '1d', 'every 30m', 'in 2h'
    * ISO-8601 timestamps: '2026-05-09T18:00:00'
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Optional

try:  # optional dependency
    from croniter import croniter as _croniter  # type: ignore
    _HAS_CRONITER = True
except Exception:  # pragma: no cover
    _croniter = None
    _HAS_CRONITER = False


_REL_RE = re.compile(r"^\s*(?:every\s+|in\s+)?(\d+)\s*([smhdw])\s*$", re.IGNORECASE)
_UNIT = {"s": "seconds", "m": "minutes", "h": "hours", "d": "days", "w": "weeks"}


class ScheduleError(ValueError):
    """Raised when a schedule spec cannot be parsed."""


def _is_cron(spec: str) -> bool:
    parts = spec.strip().split()
    return len(parts) == 5


def _parse_iso(spec: str) -> Optional[datetime]:
    s = spec.strip()
    # Accept trailing Z
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt


def parse_schedule(spec: str) -> dict:
    """Validate a schedule spec and return a normalized descriptor.

    Returns dict with keys: kind ('cron'|'relative'|'iso'), spec, plus
    kind-specific fields. Raises ScheduleError on invalid input.
    """
    if not spec or not isinstance(spec, str):
        raise ScheduleError("schedule must be a non-empty string")
    s = spec.strip()

    m = _REL_RE.match(s)
    if m:
        n = int(m.group(1))
        unit = m.group(2).lower()
        kw = {_UNIT[unit]: n}
        # quick validity check
        timedelta(**kw)
        return {"kind": "relative", "spec": s, "delta": kw}

    if _is_cron(s):
        # validate via croniter or simple field check
        if _HAS_CRONITER:
            try:
                _croniter(s, datetime.now())
            except Exception as e:  # pragma: no cover
                raise ScheduleError(f"invalid cron expression: {e}") from e
        else:
            _validate_cron_fallback(s)
        return {"kind": "cron", "spec": s}

    iso = _parse_iso(s)
    if iso is not None:
        return {"kind": "iso", "spec": s, "datetime": iso}

    raise ScheduleError(f"unrecognized schedule spec: {spec!r}")


def next_run_time(spec: str, now: Optional[datetime] = None) -> datetime:
    """Compute the next datetime the given spec should fire (naive local)."""
    desc = parse_schedule(spec)
    base = now or datetime.now()
    kind = desc["kind"]

    if kind == "relative":
        return base + timedelta(**desc["delta"])

    if kind == "iso":
        dt = desc["datetime"]
        # ISO is one-shot; if past, return as-is so scheduler fires immediately once
        return dt

    if kind == "cron":
        if _HAS_CRONITER:
            it = _croniter(desc["spec"], base)
            return it.get_next(datetime)
        return _next_cron_fallback(desc["spec"], base)

    raise ScheduleError(f"unknown schedule kind: {kind}")


# ----- minimal stdlib cron fallback ------------------------------------
# Supports: '*', integers, comma lists, ranges 'a-b', and step '*/n'.
# Five fields: minute hour day-of-month month day-of-week (0=Sun..6=Sat).

def _parse_field(field: str, lo: int, hi: int) -> set[int]:
    out: set[int] = set()
    for token in field.split(","):
        token = token.strip()
        step = 1
        if "/" in token:
            base, step_s = token.split("/", 1)
            step = int(step_s)
        else:
            base = token
        if base == "*" or base == "":
            start, end = lo, hi
        elif "-" in base:
            a, b = base.split("-", 1)
            start, end = int(a), int(b)
        else:
            v = int(base)
            if step == 1:
                out.add(v)
                continue
            start, end = v, hi
        for v in range(start, end + 1, step):
            if lo <= v <= hi:
                out.add(v)
    if not out:
        raise ScheduleError(f"empty cron field: {field!r}")
    return out


def _validate_cron_fallback(spec: str) -> None:
    parts = spec.split()
    if len(parts) != 5:
        raise ScheduleError(f"cron must have 5 fields: {spec!r}")
    bounds = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 6)]
    for p, (lo, hi) in zip(parts, bounds):
        _parse_field(p, lo, hi)


def _next_cron_fallback(spec: str, base: datetime) -> datetime:
    parts = spec.split()
    minutes = _parse_field(parts[0], 0, 59)
    hours = _parse_field(parts[1], 0, 23)
    doms = _parse_field(parts[2], 1, 31)
    months = _parse_field(parts[3], 1, 12)
    # 0=Sunday in standard cron; Python weekday(): 0=Mon..6=Sun
    dows_cron = _parse_field(parts[4], 0, 6)

    candidate = (base + timedelta(minutes=1)).replace(second=0, microsecond=0)
    # Cap search to ~4 years for safety
    cap = candidate + timedelta(days=366 * 4)
    while candidate <= cap:
        if candidate.month not in months:
            # jump to first of next month
            yr = candidate.year + (1 if candidate.month == 12 else 0)
            mo = 1 if candidate.month == 12 else candidate.month + 1
            candidate = datetime(yr, mo, 1, 0, 0)
            continue
        if candidate.day not in doms:
            candidate = (candidate + timedelta(days=1)).replace(hour=0, minute=0)
            continue
        # python weekday: Mon=0..Sun=6  -> cron: Sun=0..Sat=6
        py_dow = candidate.weekday()
        cron_dow = (py_dow + 1) % 7
        if cron_dow not in dows_cron:
            candidate = (candidate + timedelta(days=1)).replace(hour=0, minute=0)
            continue
        if candidate.hour not in hours:
            candidate = (candidate + timedelta(hours=1)).replace(minute=0)
            continue
        if candidate.minute not in minutes:
            candidate = candidate + timedelta(minutes=1)
            continue
        return candidate
    raise ScheduleError(f"could not find next run within 4 years for {spec!r}")
