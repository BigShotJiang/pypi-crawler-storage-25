"""Job dataclass and JobStore (SQLite-backed CRUD)."""
from __future__ import annotations

import json
import os
import sqlite3
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable, Optional


def _default_db_path() -> Path:
    return Path(os.path.expanduser("~/.cvc/cron.db"))


@dataclass
class Job:
    name: str
    schedule: str
    prompt: str = ""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    skills: list = field(default_factory=list)
    deliver: str = ""
    enabled: bool = True
    repeat_count: int = 0  # 0 = unlimited
    runs_completed: int = 0
    last_run: Optional[float] = None
    next_run: Optional[float] = None
    created_at: float = field(default_factory=lambda: time.time())
    workdir: str = ""
    model: Optional[dict] = None
    no_agent: bool = False
    script: str = ""
    enabled_toolsets: list = field(default_factory=list)
    context_from: list = field(default_factory=list)

    def to_row(self) -> tuple:
        return (
            self.id,
            self.name,
            self.schedule,
            self.prompt,
            json.dumps(self.skills or []),
            self.deliver or "",
            int(bool(self.enabled)),
            int(self.repeat_count or 0),
            int(self.runs_completed or 0),
            self.last_run,
            self.next_run,
            self.created_at,
            self.workdir or "",
            json.dumps(self.model) if self.model is not None else None,
            int(bool(self.no_agent)),
            self.script or "",
            json.dumps(self.enabled_toolsets or []),
            json.dumps(self.context_from or []),
        )

    @classmethod
    def from_row(cls, row: sqlite3.Row | tuple) -> "Job":
        if isinstance(row, sqlite3.Row):
            d = dict(row)
        else:
            cols = [
                "id", "name", "schedule", "prompt", "skills", "deliver",
                "enabled", "repeat_count", "runs_completed", "last_run",
                "next_run", "created_at", "workdir", "model", "no_agent",
                "script", "enabled_toolsets", "context_from",
            ]
            d = dict(zip(cols, row))
        return cls(
            id=d["id"],
            name=d["name"],
            schedule=d["schedule"],
            prompt=d.get("prompt") or "",
            skills=json.loads(d.get("skills") or "[]"),
            deliver=d.get("deliver") or "",
            enabled=bool(d.get("enabled")),
            repeat_count=int(d.get("repeat_count") or 0),
            runs_completed=int(d.get("runs_completed") or 0),
            last_run=d.get("last_run"),
            next_run=d.get("next_run"),
            created_at=float(d.get("created_at") or time.time()),
            workdir=d.get("workdir") or "",
            model=json.loads(d["model"]) if d.get("model") else None,
            no_agent=bool(d.get("no_agent")),
            script=d.get("script") or "",
            enabled_toolsets=json.loads(d.get("enabled_toolsets") or "[]"),
            context_from=json.loads(d.get("context_from") or "[]"),
        )

    def as_dict(self) -> dict:
        return asdict(self)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    schedule TEXT NOT NULL,
    prompt TEXT,
    skills TEXT,
    deliver TEXT,
    enabled INTEGER DEFAULT 1,
    repeat_count INTEGER DEFAULT 0,
    runs_completed INTEGER DEFAULT 0,
    last_run REAL,
    next_run REAL,
    created_at REAL,
    workdir TEXT,
    model TEXT,
    no_agent INTEGER DEFAULT 0,
    script TEXT,
    enabled_toolsets TEXT,
    context_from TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_next_run ON jobs(next_run) WHERE enabled=1;
"""


class JobStore:
    """SQLite-backed CRUD for Jobs."""

    def __init__(self, db_path: Optional[str | Path] = None):
        self.db_path = Path(db_path) if db_path else _default_db_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass

    # CRUD --------------------------------------------------------------
    def add(self, job: Job) -> Job:
        self._conn.execute(
            """INSERT INTO jobs
               (id, name, schedule, prompt, skills, deliver, enabled,
                repeat_count, runs_completed, last_run, next_run,
                created_at, workdir, model, no_agent, script,
                enabled_toolsets, context_from)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            job.to_row(),
        )
        self._conn.commit()
        return job

    def get(self, job_id: str) -> Optional[Job]:
        row = self._conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return Job.from_row(row) if row else None

    def list(self, enabled_only: bool = False) -> list[Job]:
        sql = "SELECT * FROM jobs"
        if enabled_only:
            sql += " WHERE enabled=1"
        sql += " ORDER BY created_at ASC"
        return [Job.from_row(r) for r in self._conn.execute(sql).fetchall()]

    def due(self, now: Optional[float] = None) -> list[Job]:
        now = now if now is not None else time.time()
        rows = self._conn.execute(
            "SELECT * FROM jobs WHERE enabled=1 AND next_run IS NOT NULL AND next_run <= ?"
            " ORDER BY next_run ASC",
            (now,),
        ).fetchall()
        return [Job.from_row(r) for r in rows]

    def update(self, job_id: str, **fields: Any) -> Optional[Job]:
        if not fields:
            return self.get(job_id)
        # Serialize JSON fields
        json_fields = {"skills", "model", "enabled_toolsets", "context_from"}
        bool_fields = {"enabled", "no_agent"}
        sets = []
        vals = []
        for k, v in fields.items():
            if k not in {
                "name", "schedule", "prompt", "skills", "deliver", "enabled",
                "repeat_count", "runs_completed", "last_run", "next_run",
                "workdir", "model", "no_agent", "script", "enabled_toolsets",
                "context_from",
            }:
                continue
            if k in json_fields:
                v = json.dumps(v) if v is not None else None
            elif k in bool_fields:
                v = int(bool(v))
            sets.append(f"{k}=?")
            vals.append(v)
        if not sets:
            return self.get(job_id)
        vals.append(job_id)
        self._conn.execute(f"UPDATE jobs SET {', '.join(sets)} WHERE id=?", vals)
        self._conn.commit()
        return self.get(job_id)

    def remove(self, job_id: str) -> bool:
        cur = self._conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
        self._conn.commit()
        return cur.rowcount > 0

    def __len__(self) -> int:
        return self._conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]

    def __iter__(self) -> Iterable[Job]:
        return iter(self.list())
