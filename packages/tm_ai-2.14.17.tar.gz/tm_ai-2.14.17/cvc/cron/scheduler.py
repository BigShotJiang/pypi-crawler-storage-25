"""Tick-driven CronScheduler. No threads — caller drives tick()."""
from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Callable, Optional

from .jobs import Job, JobStore
from .schedule import next_run_time, parse_schedule

log = logging.getLogger(__name__)

# An executor takes a Job and returns anything (result is ignored / logged).
ExecutorFn = Callable[[Job], object]


class CronScheduler:
    """Iterative scheduler. Call .tick() from any external loop or test."""

    def __init__(self, store: JobStore, executor: Optional[ExecutorFn] = None):
        self.store = store
        self.executor: ExecutorFn = executor or (lambda job: None)

    def set_executor(self, fn: ExecutorFn) -> None:
        self.executor = fn

    # ------------------------------------------------------------------
    def schedule_initial(self, job: Job, now: Optional[datetime] = None) -> Job:
        """Compute and persist the initial next_run for a freshly-created job."""
        nxt = next_run_time(job.schedule, now or datetime.now())
        return self.store.update(job.id, next_run=nxt.timestamp()) or job

    def reschedule(self, job: Job, now: Optional[datetime] = None) -> Optional[float]:
        """Compute next_run after a successful run; returns timestamp or None."""
        desc = parse_schedule(job.schedule)
        # one-shot kinds: iso, relative without 'every'
        one_shot = desc["kind"] == "iso" or (
            desc["kind"] == "relative" and not job.schedule.lower().lstrip().startswith("every")
        )
        # repeat_count == 0 means unlimited
        runs_after = job.runs_completed + 1
        if job.repeat_count and runs_after >= job.repeat_count:
            return None
        if one_shot and not job.repeat_count:
            return None
        try:
            nxt = next_run_time(job.schedule, now or datetime.now())
            return nxt.timestamp()
        except Exception as e:  # pragma: no cover
            log.warning("reschedule failed for %s: %s", job.id, e)
            return None

    # ------------------------------------------------------------------
    def tick(self, now: Optional[float] = None) -> list[dict]:
        """Find due jobs, run them, update bookkeeping. Returns list of results."""
        now = now if now is not None else time.time()
        results: list[dict] = []
        for job in self.store.due(now):
            res = {"job_id": job.id, "ok": True, "error": None, "result": None}
            try:
                res["result"] = self.executor(job)
            except Exception as e:
                res["ok"] = False
                res["error"] = str(e)
                log.exception("job %s executor raised", job.id)

            new_runs = job.runs_completed + 1
            next_ts = self.reschedule(job, datetime.fromtimestamp(now))
            updates = {
                "last_run": now,
                "runs_completed": new_runs,
                "next_run": next_ts,
            }
            if next_ts is None:
                # one-shot complete or repeat_count reached → disable
                updates["enabled"] = False
            self.store.update(job.id, **updates)
            results.append(res)
        return results
