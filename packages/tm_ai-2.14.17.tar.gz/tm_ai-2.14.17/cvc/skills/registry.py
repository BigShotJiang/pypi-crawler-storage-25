"""In-memory skill registry with lazy load and search."""

from __future__ import annotations

from pathlib import Path
from threading import RLock
from typing import Any, Dict, List, Optional

from cvc.skills.loader import Skill, SkillLoader


class SkillRegistry:
    """Discovers skills lazily; loads bodies on demand and caches them."""

    def __init__(self, loader: Optional[SkillLoader] = None) -> None:
        self._loader = loader or SkillLoader()
        self._lock = RLock()
        self._entries: Optional[List[Dict[str, Any]]] = None
        self._loaded: Dict[str, Skill] = {}

    # --- internals -------------------------------------------------------

    def _ensure_discovered(self) -> List[Dict[str, Any]]:
        with self._lock:
            if self._entries is None:
                self._entries = self._loader.discover()
            return self._entries

    # --- public API ------------------------------------------------------

    def refresh(self) -> int:
        """Re-scan all roots. Returns the new entry count."""
        with self._lock:
            self._entries = self._loader.discover()
            self._loaded.clear()
            return len(self._entries)

    def list(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        entries = list(self._ensure_discovered())
        if category is None:
            return entries
        # Filtering by category requires loading frontmatter.
        out: List[Dict[str, Any]] = []
        for e in entries:
            sk = self.get(e["name"])
            if sk and (sk.category or "") == category:
                out.append(e)
        return out

    def get(self, name: str) -> Optional[Skill]:
        with self._lock:
            cached = self._loaded.get(name)
            if cached is not None:
                return cached
        skill = self._loader.load(name)
        if skill is not None:
            with self._lock:
                self._loaded[name] = skill
        return skill

    def search(self, query: str) -> List[Skill]:
        q = (query or "").strip().lower()
        if not q:
            return []
        results: List[Skill] = []
        for entry in self._ensure_discovered():
            sk = self.get(entry["name"])
            if sk is None:
                continue
            hay = " ".join([sk.name, sk.description or "", sk.category or ""]).lower()
            if q in hay:
                results.append(sk)
        return results

    def categories(self) -> List[str]:
        cats: set[str] = set()
        for entry in self._ensure_discovered():
            sk = self.get(entry["name"])
            if sk and sk.category:
                cats.add(sk.category)
        return sorted(cats)


# Module-level singleton (lazy).
_default_registry: Optional[SkillRegistry] = None


def get_default_registry() -> SkillRegistry:
    global _default_registry
    if _default_registry is None:
        _default_registry = SkillRegistry()
    return _default_registry
