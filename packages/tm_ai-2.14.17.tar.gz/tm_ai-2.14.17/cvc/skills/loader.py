"""Skill discovery and loading.

A *skill* is a directory containing ``SKILL.md`` (preferred) or ``README.md``.
Skills can live in any of:

  * ``~/.cvc/skills/`` — CVC user skills (mutable)
  * ``~/.hermes/skills/`` — Hermes shared library
  * ``<repo>/skills/``   — bundled with the cvc package (if present)

Skills with the same directory name are de-duplicated; the first root in
``SKILL_ROOTS`` wins. Sub-resources (references/, templates/, scripts/,
assets/) are catalogued as relative paths in ``Skill.linked_files``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from cvc.skills.parser import parse_skill_md


SUBDIRS = ("references", "templates", "scripts", "assets")


def _repo_bundled_root() -> Optional[Path]:
    # cvc/skills/loader.py -> cvc/skills/ -> cvc/ -> repo root
    here = Path(__file__).resolve()
    for parent in (here.parent.parent.parent, here.parent.parent):
        candidate = parent / "skills"
        if candidate.is_dir():
            return candidate
    return None


def default_skill_roots() -> List[Path]:
    roots: List[Path] = [
        Path.home() / ".cvc" / "skills",
        Path.home() / ".hermes" / "skills",
    ]
    bundled = _repo_bundled_root()
    if bundled is not None:
        roots.append(bundled)
    return roots


@dataclass
class Skill:
    name: str
    description: str
    category: Optional[str]
    body: str
    frontmatter: Dict[str, Any]
    path: Path
    manifest: Path
    source: str  # 'cvc' | 'hermes' | 'bundled'
    linked_files: Dict[str, List[str]] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "path": str(self.path),
            "manifest": str(self.manifest),
            "source": self.source,
            "frontmatter": self.frontmatter,
            "linked_files": self.linked_files,
        }


class SkillLoader:
    """Scan skill roots and build :class:`Skill` instances on demand."""

    def __init__(self, roots: Optional[List[Path]] = None) -> None:
        self.roots: List[Path] = roots if roots is not None else default_skill_roots()

    # --- discovery -------------------------------------------------------

    def _source_for(self, root: Path) -> str:
        parts = root.parts
        if ".cvc" in parts:
            return "cvc"
        if ".hermes" in parts:
            return "hermes"
        return "bundled"

    def discover(self) -> List[Dict[str, Any]]:
        """Return raw entries: {name, root, path, manifest, source}."""
        out: List[Dict[str, Any]] = []
        seen: set[str] = set()
        for root in self.roots:
            if not root.is_dir():
                continue
            source = self._source_for(root)
            for child in sorted(self._walk_skill_dirs(root)):
                manifest = self._find_manifest(child)
                if manifest is None:
                    continue
                if child.name in seen:
                    continue
                seen.add(child.name)
                out.append({
                    "name": child.name,
                    "root": str(root),
                    "path": str(child),
                    "manifest": str(manifest),
                    "source": source,
                })
        return out

    def _walk_skill_dirs(self, root: Path) -> List[Path]:
        """Find skill dirs (any subtree containing SKILL.md), shallow-first."""
        results: List[Path] = []
        for dirpath, dirnames, filenames in os.walk(root):
            # skip hidden dirs in-place
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            if any(f in filenames for f in ("SKILL.md", "skill.md", "README.md")):
                results.append(Path(dirpath))
        # Don't include the root itself if it has no manifest
        return [p for p in results if p != root]

    def _find_manifest(self, skill_dir: Path) -> Optional[Path]:
        for fname in ("SKILL.md", "skill.md", "README.md"):
            p = skill_dir / fname
            if p.is_file():
                return p
        return None

    # --- loading ---------------------------------------------------------

    def load(self, name: str) -> Optional[Skill]:
        for entry in self.discover():
            if entry["name"] == name:
                return self._build(entry)
        return None

    def load_path(self, path: Path) -> Optional[Skill]:
        path = Path(path)
        if not path.is_dir():
            return None
        manifest = self._find_manifest(path)
        if manifest is None:
            return None
        entry = {
            "name": path.name,
            "root": str(path.parent),
            "path": str(path),
            "manifest": str(manifest),
            "source": "external",
        }
        return self._build(entry)

    def load_all(self) -> List[Skill]:
        return [s for s in (self._build(e) for e in self.discover()) if s is not None]

    def _build(self, entry: Dict[str, Any]) -> Optional[Skill]:
        manifest = Path(entry["manifest"])
        try:
            text = manifest.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None
        meta, body = parse_skill_md(text)
        skill_dir = Path(entry["path"])
        linked = self._collect_linked(skill_dir)
        return Skill(
            name=str(meta.get("name") or entry["name"]),
            description=str(meta.get("description") or ""),
            category=meta.get("category"),
            body=body,
            frontmatter=meta,
            path=skill_dir,
            manifest=manifest,
            source=entry.get("source", "external"),
            linked_files=linked,
        )

    def _collect_linked(self, skill_dir: Path) -> Dict[str, List[str]]:
        out: Dict[str, List[str]] = {}
        for sub in SUBDIRS:
            d = skill_dir / sub
            if not d.is_dir():
                continue
            files: List[str] = []
            for p in sorted(d.rglob("*")):
                if p.is_file() and not any(
                    part.startswith(".") for part in p.relative_to(skill_dir).parts
                ):
                    files.append(str(p.relative_to(skill_dir)))
            if files:
                out[sub] = files
        return out
