"""Validate skill frontmatter metadata."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")
_MAX_NAME_LEN = 64

_OPTIONAL_FIELDS = {"category", "allowed_tools", "allowed-tools", "version"}
_REQUIRED_FIELDS = ("name", "description")


def validate_frontmatter(meta: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Validate a skill frontmatter dict.

    Returns ``(is_valid, errors)``. Errors are short human-readable strings.
    """
    errors: List[str] = []

    if not isinstance(meta, dict):
        return False, ["frontmatter is not a mapping"]

    for field in _REQUIRED_FIELDS:
        if field not in meta or meta[field] in (None, ""):
            errors.append(f"missing required field: {field}")

    name = meta.get("name")
    if isinstance(name, str):
        if len(name) > _MAX_NAME_LEN:
            errors.append(f"name exceeds {_MAX_NAME_LEN} chars")
        if not _NAME_RE.match(name):
            errors.append(
                "name must be lowercase letters, digits, hyphens, or underscores"
            )
    elif name is not None:
        errors.append("name must be a string")

    description = meta.get("description")
    if description is not None and not isinstance(description, str):
        errors.append("description must be a string")

    version = meta.get("version")
    if version is not None and not isinstance(version, (str, int, float)):
        errors.append("version must be a string or number")

    allowed = meta.get("allowed_tools", meta.get("allowed-tools"))
    if allowed is not None and not isinstance(allowed, (list, str)):
        errors.append("allowed_tools must be a list or string")

    category = meta.get("category")
    if category is not None and not isinstance(category, str):
        errors.append("category must be a string")

    return (not errors), errors
