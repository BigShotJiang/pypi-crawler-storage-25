"""CVC skills core package.

Public API
----------
- :func:`load_skill` — load a single skill by name.
- :func:`list_skills` — enumerate discovered skills (optionally filtered).
- :func:`validate_skill` — validate a SKILL.md file on disk.
- :class:`SkillManager` — convenience facade combining loader/registry/injection.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from cvc.skills.injection import build_skill_message
from cvc.skills.loader import Skill, SkillLoader, default_skill_roots
from cvc.skills.parser import parse_skill_md
from cvc.skills.registry import SkillRegistry, get_default_registry
from cvc.skills.validator import validate_frontmatter

__all__ = [
    "Skill",
    "SkillLoader",
    "SkillRegistry",
    "SkillManager",
    "build_skill_message",
    "default_skill_roots",
    "load_skill",
    "list_skills",
    "parse_skill_md",
    "validate_frontmatter",
    "validate_skill",
    "get_default_registry",
]


def load_skill(name: str) -> Optional[Skill]:
    """Load a single skill by directory name."""
    return get_default_registry().get(name)


def list_skills(category: Optional[str] = None) -> List[Dict[str, Any]]:
    """List discovered skills, optionally filtered by category."""
    return get_default_registry().list(category=category)


def validate_skill(path: Path | str) -> Tuple[bool, List[str]]:
    """Validate the SKILL.md (or skill.md/README.md) at *path*.

    *path* may be the directory or the manifest file itself.
    """
    p = Path(path)
    if p.is_dir():
        for fname in ("SKILL.md", "skill.md", "README.md"):
            cand = p / fname
            if cand.is_file():
                p = cand
                break
        else:
            return False, [f"no SKILL.md found in {path}"]
    if not p.is_file():
        return False, [f"file not found: {path}"]
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return False, [f"cannot read {path}: {exc}"]
    meta, _body = parse_skill_md(text)
    if not meta:
        return False, ["no YAML frontmatter found"]
    return validate_frontmatter(meta)


class SkillManager:
    """High-level facade over the registry, loader, and injection helper."""

    def __init__(self, registry: Optional[SkillRegistry] = None) -> None:
        self.registry = registry or get_default_registry()

    def list(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.registry.list(category=category)

    def load(self, name: str) -> Optional[Skill]:
        return self.registry.get(name)

    def search(self, query: str) -> List[Skill]:
        return self.registry.search(query)

    def refresh(self) -> int:
        return self.registry.refresh()

    def categories(self) -> List[str]:
        return self.registry.categories()

    def build_message(
        self,
        name: str,
        args: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, str]]:
        skill = self.load(name)
        if skill is None:
            return None
        return build_skill_message(skill, args=args)
