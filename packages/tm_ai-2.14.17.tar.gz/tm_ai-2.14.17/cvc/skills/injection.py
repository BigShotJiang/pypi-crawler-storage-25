"""Build chat messages that inject a skill into the conversation.

We deliberately emit a ``user`` role message (NOT a system message). This
preserves prompt-cache locality for the system block — providers like
Anthropic and OpenAI key their caches off the system prompt + early
messages, so mutating the system prompt for every skill load would burst
the cache. A user-role injection is invisible to caching and equally
authoritative for the model.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from cvc.skills.loader import Skill


def _format_args(args: Optional[Dict[str, Any]]) -> str:
    if not args:
        return ""
    lines = ["", "## Invocation arguments", ""]
    for k, v in args.items():
        lines.append(f"- **{k}**: {v}")
    return "\n".join(lines)


def _format_linked(skill: Skill) -> str:
    if not skill.linked_files:
        return ""
    lines = ["", "## Bundled resources", ""]
    for kind, files in skill.linked_files.items():
        lines.append(f"**{kind}/**")
        for f in files:
            lines.append(f"- {f}")
        lines.append("")
    return "\n".join(lines)


def build_skill_message(
    skill: Skill,
    args: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    """Return ``{'role': 'user', 'content': '...'}`` for a loaded skill."""
    header = (
        f"# Skill loaded: {skill.name}\n\n"
        f"_{skill.description}_\n\n"
        f"Source: `{skill.source}` · Path: `{skill.path}`\n"
    )
    parts = [header, "---", "", skill.body.rstrip()]
    linked = _format_linked(skill)
    if linked:
        parts.append(linked)
    arg_block = _format_args(args)
    if arg_block:
        parts.append(arg_block)
    parts.append(
        "\n---\nFollow the instructions above for the user's next request."
    )
    return {"role": "user", "content": "\n".join(parts).strip() + "\n"}
