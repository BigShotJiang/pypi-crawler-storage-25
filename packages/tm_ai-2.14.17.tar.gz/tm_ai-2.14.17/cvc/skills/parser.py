"""Parse SKILL.md files: split YAML frontmatter from markdown body.

Avoids extra deps — uses stdlib + PyYAML (already a CVC dep).
"""

from __future__ import annotations

from typing import Any, Dict, Tuple

try:
    import yaml  # type: ignore
except ImportError:  # pragma: no cover
    yaml = None  # type: ignore


def parse_skill_md(text: str) -> Tuple[Dict[str, Any], str]:
    """Split a SKILL.md document into (frontmatter_dict, body_str).

    Supports the standard ``---\\n<yaml>\\n---\\n<body>`` layout. If no
    frontmatter is present, returns ``({}, text)``.
    """
    if not text:
        return {}, ""
    # Normalize: strip leading BOM/whitespace newlines but preserve internal.
    stripped = text.lstrip("\ufeff")
    if not stripped.startswith("---"):
        return {}, text

    # Find the closing fence. Must be a line that is exactly '---' or '...'.
    lines = stripped.splitlines(keepends=True)
    if not lines or lines[0].rstrip("\r\n") != "---":
        return {}, text

    end_idx = -1
    for i in range(1, len(lines)):
        ln = lines[i].rstrip("\r\n")
        if ln == "---" or ln == "...":
            end_idx = i
            break
    if end_idx == -1:
        return {}, text

    fm_text = "".join(lines[1:end_idx])
    body = "".join(lines[end_idx + 1 :])
    # Drop a single leading newline from body for cleanliness.
    if body.startswith("\n"):
        body = body[1:]

    meta: Dict[str, Any] = {}
    if yaml is not None and fm_text.strip():
        try:
            loaded = yaml.safe_load(fm_text)
            if isinstance(loaded, dict):
                meta = loaded
        except yaml.YAMLError:
            meta = {}
    return meta, body
