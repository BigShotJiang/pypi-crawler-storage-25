"""Host-level HiveFrame config (~/.hiveframe/config.yaml)."""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from pydantic import BaseModel, Field, SecretStr, field_validator


_HOME_CONFIG = Path.home() / ".hiveframe" / "config.yaml"


class NodeSettings(BaseModel):
    """Per-node Proxmox connection settings."""

    name: str = Field(..., description="Logical node name (must match stack node field)")
    host: str = Field(..., description="Proxmox host IP or hostname")
    user: str = Field(default="root@pam")
    token_id: str = Field(..., description="API token ID (e.g. 'hiveframe')")
    token_secret: SecretStr = Field(..., description="API token secret")
    verify_ssl: bool = Field(default=False)

    @field_validator("host")
    @classmethod
    def strip_scheme(cls, v: str) -> str:
        return v.removeprefix("https://").removeprefix("http://").rstrip("/")


class HiveframeSettings(BaseModel):
    nodes: list[NodeSettings] = Field(..., min_length=1)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _migrate_legacy(data: dict) -> dict:
    """Convert old flat single-node config to the nodes-list format."""
    return {
        "nodes": [{
            "name": "pve",
            "host": data["proxmox_host"],
            "user": data.get("proxmox_user", "root@pam"),
            "token_id": data["proxmox_token_id"],
            "token_secret": data["proxmox_token_secret"],
            "verify_ssl": data.get("proxmox_verify_ssl", False),
        }]
    }


def _settings_from_env() -> HiveframeSettings | None:
    """Try to build single-node settings from legacy HIVEFRAME_* env vars."""
    host = os.environ.get("HIVEFRAME_PROXMOX_HOST")
    token_id = os.environ.get("HIVEFRAME_PROXMOX_TOKEN_ID")
    token_secret = os.environ.get("HIVEFRAME_PROXMOX_TOKEN_SECRET")
    if not (host and token_id and token_secret):
        return None
    return HiveframeSettings.model_validate(_migrate_legacy({
        "proxmox_host": host,
        "proxmox_user": os.environ.get("HIVEFRAME_PROXMOX_USER", "root@pam"),
        "proxmox_token_id": token_id,
        "proxmox_token_secret": token_secret,
        "proxmox_verify_ssl": os.environ.get(
            "HIVEFRAME_PROXMOX_VERIFY_SSL", "false"
        ).lower() == "true",
    }))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def resolve_config_path(explicit: Path | None = None) -> Path:
    """Return the config path to use (first existing path wins)."""
    if explicit is not None:
        return explicit
    if _HOME_CONFIG.exists():
        return _HOME_CONFIG
    cwd_cfg = Path.cwd() / "config.yaml"
    if cwd_cfg.exists():
        return cwd_cfg
    return _HOME_CONFIG


def load_settings(path: Path | None = None) -> HiveframeSettings:
    """Load settings from YAML, migrating old single-node format automatically.

    Falls back to HIVEFRAME_* environment variables when no config file exists.
    """
    cfg_path = resolve_config_path(path)

    if not cfg_path.exists():
        env_settings = _settings_from_env()
        if env_settings:
            return env_settings
        raise FileNotFoundError(
            f"No config file found at {cfg_path}\n"
            f"Run: hiveframe config init\n"
            f"Or set HIVEFRAME_PROXMOX_HOST / HIVEFRAME_PROXMOX_TOKEN_ID / "
            f"HIVEFRAME_PROXMOX_TOKEN_SECRET environment variables."
        )

    with cfg_path.open() as fh:
        data: dict = yaml.safe_load(fh) or {}

    if "nodes" in data:
        return HiveframeSettings.model_validate(data)
    if "proxmox_host" in data:
        return HiveframeSettings.model_validate(_migrate_legacy(data))
    raise ValueError(
        "Config must have a 'nodes' list or legacy 'proxmox_host' key.\n"
        "Run: hiveframe config init"
    )


def write_default_config(path: Path | None = None) -> Path:
    """Write a template config file if none exists. Returns the path."""
    cfg_path = path or _HOME_CONFIG
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    if cfg_path.exists():
        return cfg_path
    template = {
        "nodes": [{
            "name": "pve",
            "host": "10.0.20.1",
            "user": "root@pam",
            "token_id": "hiveframe",
            "token_secret": "REPLACE_ME",
            "verify_ssl": False,
        }]
    }
    with cfg_path.open("w") as fh:
        yaml.safe_dump(template, fh, sort_keys=False)
    return cfg_path
