"""Provisioning engine — VLAN, VM, and firewall layers."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from hiveframe.api.client import HiveframeAPIError, NodeRegistry, ProxmoxClient
from hiveframe.models import Stack
from hiveframe.models.vlan import VlanConfig
from hiveframe.models.vm import VmConfig
from hiveframe.models.firewall import FirewallRule
from hiveframe.provision.state import (
    VlanState,
    VmState,
    load_state,
    merge_vlan_states,
    merge_vm_states,
    remove_vlan_states,
    remove_vm_states,
    save_state,
)

_TEMPLATE_DISK_GB = 20  # assumed template base disk size


# ---------------------------------------------------------------------------
# Status check types
# ---------------------------------------------------------------------------

@dataclass
class VlanStatusResult:
    vlan_state: VlanState
    live_status: Literal["OK", "MISSING"]


@dataclass
class VmStatusResult:
    vm_state: VmState
    live_status: Literal["OK", "STOPPED", "MISSING"]


# ---------------------------------------------------------------------------
# VLAN plan / result types
# ---------------------------------------------------------------------------

@dataclass
class PlanAction:
    action: Literal["CREATE", "SKIP"]
    vlan: VlanConfig
    bridge_name: str
    reason: str = ""
    node: str = ""


@dataclass
class ApplyResult:
    outcome: Literal["CREATED", "SKIPPED", "FAILED"]
    vlan: VlanConfig
    bridge_name: str
    reason: str = ""
    node: str = ""


# ---------------------------------------------------------------------------
# VM plan / result types
# ---------------------------------------------------------------------------

@dataclass
class VmPlanAction:
    action: Literal["CREATE", "SKIP"]
    vm: VmConfig
    reason: str = ""
    node: str = ""


@dataclass
class VmApplyResult:
    outcome: Literal["CREATED", "SKIPPED", "FAILED"]
    vm: VmConfig
    vmid: int | None = None
    reason: str = ""
    node: str = ""


# ---------------------------------------------------------------------------
# Firewall plan / result types
# ---------------------------------------------------------------------------

@dataclass
class FwPlanAction:
    action: Literal["CREATE", "REPLACE", "SKIP"]
    vm: VmConfig
    vmid: int | None
    rule_count: int
    reason: str = ""
    node: str = ""


@dataclass
class FwApplyResult:
    outcome: Literal["APPLIED", "SKIPPED", "FAILED"]
    vm: VmConfig
    vmid: int | None
    rule_count: int
    reason: str = ""
    node: str = ""


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ProvisionEngine:
    """Drives VLAN + VM provisioning across one or more Proxmox nodes."""

    def __init__(self, stack: Stack, registry: NodeRegistry) -> None:
        self.stack = stack
        self.registry = registry

    # ------------------------------------------------------------------
    # Per-resource node helpers
    # ------------------------------------------------------------------

    def _vlan_node(self, vlan: VlanConfig, override: str | None = None) -> str:
        return vlan.node or override or self.stack.node

    def _vm_node(self, vm: VmConfig, override: str | None = None) -> str:
        return vm.node or override or self.stack.node

    def _client(self, node_name: str) -> ProxmoxClient:
        return self.registry.get_client(node_name)

    # ------------------------------------------------------------------
    # VLAN plan / apply / destroy
    # ------------------------------------------------------------------

    def plan_vlans(self, node: str | None = None) -> list[PlanAction]:
        actions: list[PlanAction] = []
        for vlan in self.stack.vlans:
            vlan_node = self._vlan_node(vlan, node)
            client = self._client(vlan_node)
            if client.bridge_exists(vlan_node, vlan.bridge):
                actions.append(PlanAction("SKIP", vlan, vlan.bridge, "bridge already exists", node=vlan_node))
            else:
                actions.append(PlanAction("CREATE", vlan, vlan.bridge, "bridge not found", node=vlan_node))
        return actions

    def apply_vlans(self, stack_yaml: Path, node: str | None = None) -> list[ApplyResult]:
        actions = self.plan_vlans(node)
        results: list[ApplyResult] = []
        created_nodes: set[str] = set()

        for action in actions:
            client = self._client(action.node)
            if action.action == "SKIP":
                results.append(ApplyResult("SKIPPED", action.vlan, action.bridge_name, action.reason, node=action.node))
                continue
            try:
                client.create_linux_bridge(action.node, action.vlan)
                results.append(ApplyResult("CREATED", action.vlan, action.bridge_name, node=action.node))
                created_nodes.add(action.node)
            except HiveframeAPIError as exc:
                results.append(ApplyResult("FAILED", action.vlan, action.bridge_name, str(exc), node=action.node))

        for vlan_node in created_nodes:
            self._client(vlan_node).apply_network_config(vlan_node)

        new_states = [
            VlanState(
                vlan_id=r.vlan.vlan_id,
                bridge=r.bridge_name,
                status="applied" if r.outcome in ("CREATED", "SKIPPED") else "failed",
                node=r.node,
            )
            for r in results
        ]
        existing = load_state(stack_yaml)
        save_state(stack_yaml, merge_vlan_states(existing, self.stack.name, new_states))
        return results

    def destroy_vlans(self, stack_yaml: Path, node: str | None = None) -> list[ApplyResult]:
        results: list[ApplyResult] = []
        deleted_nodes: set[str] = set()
        destroyed_ids: set[int] = set()

        for vlan in self.stack.vlans:
            vlan_node = self._vlan_node(vlan, node)
            client = self._client(vlan_node)
            if not client.bridge_exists(vlan_node, vlan.bridge):
                results.append(ApplyResult("SKIPPED", vlan, vlan.bridge, "bridge does not exist", node=vlan_node))
                continue
            try:
                client.delete_network_iface(vlan_node, vlan.bridge)
                results.append(ApplyResult("CREATED", vlan, vlan.bridge, "queued for deletion", node=vlan_node))
                deleted_nodes.add(vlan_node)
                destroyed_ids.add(vlan.vlan_id)
            except HiveframeAPIError as exc:
                results.append(ApplyResult("FAILED", vlan, vlan.bridge, str(exc), node=vlan_node))

        for vlan_node in deleted_nodes:
            self._client(vlan_node).apply_network_config(vlan_node)

        if destroyed_ids:
            existing = load_state(stack_yaml)
            if existing:
                save_state(stack_yaml, remove_vlan_states(existing, destroyed_ids))

        return results

    # ------------------------------------------------------------------
    # VM plan / apply / destroy
    # ------------------------------------------------------------------

    def plan_vms(self, node: str | None = None) -> list[VmPlanAction]:
        """Return what would be created/skipped for VMs — no mutations."""
        # Cache get_vms per node to avoid redundant API calls
        existing_by_node: dict[str, set[str]] = {}
        actions: list[VmPlanAction] = []

        for vm in self.stack.vms:
            vm_node = self._vm_node(vm, node)
            if vm_node not in existing_by_node:
                client = self._client(vm_node)
                existing_by_node[vm_node] = {v["name"] for v in client.get_vms(vm_node)}
            if vm.name in existing_by_node[vm_node]:
                actions.append(VmPlanAction("SKIP", vm, "VM already exists", node=vm_node))
            else:
                actions.append(VmPlanAction("CREATE", vm, "VM not found", node=vm_node))
        return actions

    def apply_vms(self, stack_yaml: Path, node: str | None = None) -> list[VmApplyResult]:
        """Clone, configure, and optionally start VMs for all CREATE actions."""
        actions = self.plan_vms(node)
        results: list[VmApplyResult] = []

        for action in actions:
            if action.action == "SKIP":
                results.append(VmApplyResult("SKIPPED", action.vm, reason=action.reason, node=action.node))
                continue

            vm = action.vm
            vm_node = action.node
            client = self._client(vm_node)
            vmid: int | None = None
            try:
                vmid = client.get_next_vmid(vm_node)
                task = client.clone_vm(vm_node, vm.template_id, vmid, vm.name)
                client.wait_for_task(vm_node, task)

                if vm.disk_gb > _TEMPLATE_DISK_GB:
                    client.resize_disk(vm_node, vmid, "scsi0", vm.disk_gb - _TEMPLATE_DISK_GB)

                client.set_cloud_init(vm_node, vmid, vm.cloud_init, vm.storage)

                vlan = self.stack.vlan_by_name(vm.vlan)
                client.set_network(vm_node, vmid, vlan.bridge, vlan.vlan_id)

                if vm.start_on_create:
                    start_task = client.start_vm(vm_node, vmid)
                    client.wait_for_task(vm_node, start_task)

                results.append(VmApplyResult("CREATED", vm, vmid=vmid, node=vm_node))

            except (HiveframeAPIError, KeyError) as exc:
                results.append(VmApplyResult("FAILED", vm, vmid=vmid, reason=str(exc), node=vm_node))

        new_states = [
            VmState(
                name=r.vm.name,
                vmid=r.vmid or 0,
                vlan=r.vm.vlan,
                status="applied" if r.outcome == "CREATED" else "failed",
                node=r.node,
            )
            for r in results
            if r.outcome in ("CREATED", "FAILED") and r.vmid is not None
        ]
        if new_states:
            existing = load_state(stack_yaml)
            save_state(stack_yaml, merge_vm_states(existing, self.stack.name, new_states))

        return results

    def destroy_vms(self, stack_yaml: Path, node: str | None = None) -> list[VmApplyResult]:
        """Stop and delete VMs tracked in state."""
        existing = load_state(stack_yaml)

        if not existing or not existing.vms:
            return []

        stack_vm_names = {vm.name for vm in self.stack.vms}
        results: list[VmApplyResult] = []
        destroyed_names: set[str] = set()

        for vm_state in existing.vms:
            if vm_state.name not in stack_vm_names:
                continue

            vm_cfg = next((v for v in self.stack.vms if v.name == vm_state.name), None)
            if vm_cfg is None:
                continue

            vm_node = vm_state.node or self._vm_node(vm_cfg, node)
            client = self._client(vm_node)

            try:
                try:
                    client.stop_vm(vm_node, vm_state.vmid)
                except HiveframeAPIError:
                    pass  # already stopped or doesn't exist
                time.sleep(5)
                client.delete_vm(vm_node, vm_state.vmid)
                results.append(VmApplyResult("CREATED", vm_cfg, vmid=vm_state.vmid, node=vm_node))
                destroyed_names.add(vm_state.name)
            except HiveframeAPIError as exc:
                results.append(VmApplyResult("FAILED", vm_cfg, vmid=vm_state.vmid, reason=str(exc), node=vm_node))

        if destroyed_names:
            updated = remove_vm_states(existing, destroyed_names)
            save_state(stack_yaml, updated)

        return results

    # ------------------------------------------------------------------
    # Firewall plan / apply / destroy
    # ------------------------------------------------------------------

    def plan_firewall(
        self, stack_yaml: Path, node: str | None = None
    ) -> list[FwPlanAction]:
        """Return what would happen to firewall rules — no mutations."""
        state = load_state(stack_yaml)
        state_vms = {vs.name: vs for vs in state.vms} if state else {}

        actions: list[FwPlanAction] = []
        for vm in self.stack.vms:
            if not vm.firewall:
                continue
            vm_node = self._vm_node(vm, node)
            vs = state_vms.get(vm.name)
            if vs is None:
                actions.append(FwPlanAction(
                    "SKIP", vm, None, len(vm.firewall),
                    "VM not yet provisioned — apply VMs first",
                    node=vm_node,
                ))
                continue
            fw_node = vs.node or vm_node
            client = self._client(fw_node)
            existing = client.get_vm_firewall_rules(fw_node, vs.vmid)
            if existing:
                actions.append(FwPlanAction(
                    "REPLACE", vm, vs.vmid, len(vm.firewall),
                    f"{len(existing)} existing rule(s) will be replaced",
                    node=fw_node,
                ))
            else:
                actions.append(FwPlanAction(
                    "CREATE", vm, vs.vmid, len(vm.firewall), "no existing rules",
                    node=fw_node,
                ))
        return actions

    def apply_firewall(
        self, stack_yaml: Path, node: str | None = None
    ) -> list[FwApplyResult]:
        """Clear and reapply firewall rules for all VMs with rules in stack."""
        state = load_state(stack_yaml)
        state_vms = {vs.name: vs for vs in state.vms} if state else {}

        results: list[FwApplyResult] = []
        updated_vm_states: list[VmState] = []

        for vm in self.stack.vms:
            if not vm.firewall:
                continue
            vm_node = self._vm_node(vm, node)
            vs = state_vms.get(vm.name)
            if vs is None:
                results.append(FwApplyResult(
                    "SKIPPED", vm, None, 0, "VM not in state — apply VMs first",
                    node=vm_node,
                ))
                continue
            fw_node = vs.node or vm_node
            client = self._client(fw_node)
            try:
                client.clear_vm_firewall_rules(fw_node, vs.vmid)
                for rule in vm.firewall:
                    client.add_vm_firewall_rule(fw_node, vs.vmid, rule)
                client.enable_vm_firewall(fw_node, vs.vmid)
                results.append(FwApplyResult("APPLIED", vm, vs.vmid, len(vm.firewall), node=fw_node))
                updated_vm_states.append(VmState(
                    name=vs.name,
                    vmid=vs.vmid,
                    vlan=vs.vlan,
                    status="applied",
                    firewall_rules_count=len(vm.firewall),
                    node=fw_node,
                ))
            except HiveframeAPIError as exc:
                results.append(FwApplyResult("FAILED", vm, vs.vmid, 0, str(exc), node=fw_node))

        if updated_vm_states:
            existing = load_state(stack_yaml)
            save_state(stack_yaml, merge_vm_states(existing, self.stack.name, updated_vm_states))

        return results

    def destroy_firewall(
        self, stack_yaml: Path, node: str | None = None
    ) -> list[FwApplyResult]:
        """Clear firewall rules for all VMs in state that have rules in the stack."""
        state = load_state(stack_yaml)
        if not state:
            return []

        state_vms = {vs.name: vs for vs in state.vms}
        results: list[FwApplyResult] = []
        cleared_states: list[VmState] = []

        for vm in self.stack.vms:
            if not vm.firewall:
                continue
            vm_node = self._vm_node(vm, node)
            vs = state_vms.get(vm.name)
            if vs is None:
                continue
            fw_node = vs.node or vm_node
            client = self._client(fw_node)
            try:
                client.clear_vm_firewall_rules(fw_node, vs.vmid)
                results.append(FwApplyResult("APPLIED", vm, vs.vmid, 0, "rules cleared", node=fw_node))
                cleared_states.append(VmState(
                    name=vs.name,
                    vmid=vs.vmid,
                    vlan=vs.vlan,
                    status="applied",
                    firewall_rules_count=0,
                    node=fw_node,
                ))
            except HiveframeAPIError as exc:
                results.append(FwApplyResult("FAILED", vm, vs.vmid, 0, str(exc), node=fw_node))

        if cleared_states:
            existing = load_state(stack_yaml)
            save_state(stack_yaml, merge_vm_states(existing, self.stack.name, cleared_states))

        return results

    # ------------------------------------------------------------------
    # Status check (read-only)
    # ------------------------------------------------------------------

    def check_status(
        self, stack_yaml: Path, node: str | None = None
    ) -> tuple[list[VlanStatusResult], list[VmStatusResult]]:
        """Compare state file against live Proxmox. Never mutates anything."""
        state = load_state(stack_yaml)

        if not state:
            return [], []

        vlan_results: list[VlanStatusResult] = []
        for vs in state.vlans:
            vlan_node = vs.node or node or self.stack.node
            client = self._client(vlan_node)
            exists = client.bridge_exists(vlan_node, vs.bridge)
            vlan_results.append(VlanStatusResult(vs, "OK" if exists else "MISSING"))

        vm_results: list[VmStatusResult] = []
        for vs in state.vms:
            vm_node = vs.node or node or self.stack.node
            client = self._client(vm_node)
            try:
                power = client.get_vm_status(vm_node, vs.vmid)
                live = "OK" if power == "running" else "STOPPED"
            except HiveframeAPIError:
                live = "MISSING"
            vm_results.append(VmStatusResult(vs, live))

        return vlan_results, vm_results
