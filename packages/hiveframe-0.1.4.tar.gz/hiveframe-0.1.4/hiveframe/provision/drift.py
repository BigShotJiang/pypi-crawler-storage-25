"""Drift detection — compares desired stack state against live Proxmox node(s)."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal

from hiveframe.api.client import NodeRegistry, ProxmoxClient
from hiveframe.models import Stack

_VMBR_RE = re.compile(r"^vmbr\d+$")


@dataclass
class DriftItem:
    name: str
    kind: Literal["vlan", "vm"]
    status: Literal["OK", "MISSING", "STOPPED", "UNEXPECTED"]
    detail: str | None = None
    node: str = ""


@dataclass
class DriftReport:
    checked_at: datetime
    vlans: list[DriftItem] = field(default_factory=list)
    vms: list[DriftItem] = field(default_factory=list)

    @property
    def has_drift(self) -> bool:
        return any(i.status in ("MISSING", "STOPPED") for i in self.vlans + self.vms)


class DriftDetector:
    def __init__(self, stack: Stack, registry: NodeRegistry) -> None:
        self.stack = stack
        self.registry = registry

    def check(self) -> DriftReport:
        vlan_by_node: dict[str, list] = defaultdict(list)
        for vlan in self.stack.vlans:
            vlan_by_node[vlan.node or self.stack.node].append(vlan)

        vm_by_node: dict[str, list] = defaultdict(list)
        for vm in self.stack.vms:
            vm_by_node[vm.node or self.stack.node].append(vm)

        all_nodes = sorted(set(vlan_by_node) | set(vm_by_node))
        vlans: list[DriftItem] = []
        vms: list[DriftItem] = []

        for node_name in all_nodes:
            client = self.registry.get_client(node_name)
            if node_name in vlan_by_node:
                vlans.extend(self._check_vlans(client, node_name, vlan_by_node[node_name]))
            if node_name in vm_by_node:
                vms.extend(self._check_vms(client, node_name, vm_by_node[node_name]))

        return DriftReport(
            checked_at=datetime.now(timezone.utc),
            vlans=vlans,
            vms=vms,
        )

    def _check_vlans(self, client: ProxmoxClient, node_name: str, vlans: list) -> list[DriftItem]:
        ifaces = client.get_network_config(node_name)
        live_bridges = {i["iface"] for i in ifaces if i.get("iface")}
        stack_bridges = {v.bridge for v in vlans}
        items: list[DriftItem] = []

        for vlan in vlans:
            if vlan.bridge in live_bridges:
                items.append(DriftItem(vlan.bridge, "vlan", "OK", node=node_name))
            else:
                items.append(DriftItem(vlan.bridge, "vlan", "MISSING", "bridge not found on node", node=node_name))

        for iface in sorted(live_bridges):
            if _VMBR_RE.match(iface) and iface not in stack_bridges:
                items.append(DriftItem(
                    iface, "vlan", "UNEXPECTED",
                    "bridge exists on node but not defined in stack",
                    node=node_name,
                ))

        return items

    def _check_vms(self, client: ProxmoxClient, node_name: str, vms: list) -> list[DriftItem]:
        live_vms = {vm["name"]: vm for vm in client.get_vms(node_name)}
        stack_vm_names = {vm.name for vm in vms}
        items: list[DriftItem] = []

        for vm in vms:
            live = live_vms.get(vm.name)
            if live is None:
                items.append(DriftItem(vm.name, "vm", "MISSING", "VM not found on node", node=node_name))
            elif vm.start_on_create and live.get("status") != "running":
                items.append(DriftItem(
                    vm.name, "vm", "STOPPED",
                    f"expected running, got {live.get('status', 'unknown')}",
                    node=node_name,
                ))
            else:
                items.append(DriftItem(vm.name, "vm", "OK", node=node_name))

        for name, live in live_vms.items():
            if name not in stack_vm_names:
                items.append(DriftItem(
                    name, "vm", "UNEXPECTED",
                    f"vmid={live.get('vmid')} — not defined in stack",
                    node=node_name,
                ))

        return items
