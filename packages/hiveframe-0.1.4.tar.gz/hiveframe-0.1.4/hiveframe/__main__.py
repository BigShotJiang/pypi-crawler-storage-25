from hiveframe.cli.main import cli

cli()
