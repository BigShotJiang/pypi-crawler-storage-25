"""HiveFrame CLI entry point."""

from __future__ import annotations

import os
import time
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console(legacy_windows=False)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_stack(file: str):
    from hiveframe.models import Stack
    try:
        return Stack.from_file(file)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Failed to load {file}: {exc}")
        raise SystemExit(1) from exc


def _make_registry(debug: bool = False):
    from hiveframe.api.client import NodeRegistry
    from hiveframe.config.settings import load_settings, resolve_config_path
    try:
        cfg_path = resolve_config_path()
        if debug:
            console.print(f"[dim]config: {cfg_path.resolve()}[/dim]")
        settings = load_settings(cfg_path)
        return NodeRegistry(settings)
    except FileNotFoundError as exc:
        console.print(f"[red]FAIL[/red] Config not found: {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Cannot load config: {exc}")
        raise SystemExit(1) from exc


def _vlan_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Action", style="bold")
    t.add_column("VLAN ID", justify="right")
    t.add_column("Bridge")
    t.add_column("Node")
    t.add_column("CIDR")
    t.add_column("Detail", style="dim")
    for action, vlan_id, bridge, node, cidr, detail, colour in rows:
        t.add_row(
            f"[{colour}]{action}[/{colour}]",
            str(vlan_id), bridge, node, cidr, detail,
        )
    return t


def _vm_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Action", style="bold")
    t.add_column("VM Name")
    t.add_column("VMID", justify="right")
    t.add_column("VLAN")
    t.add_column("Node")
    t.add_column("Detail", style="dim")
    for action, name, vmid, vlan, node, detail, colour in rows:
        t.add_row(
            f"[{colour}]{action}[/{colour}]",
            name, str(vmid) if vmid is not None else "-", vlan, node, detail,
        )
    return t


def _fw_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("VM")
    t.add_column("Rules", justify="right")
    t.add_column("Action", style="bold")
    t.add_column("VMID", justify="right")
    t.add_column("Node")
    t.add_column("Detail", style="dim")
    for vm_name, rule_count, action, vmid, node, detail, colour in rows:
        t.add_row(
            vm_name,
            str(rule_count),
            f"[{colour}]{action}[/{colour}]",
            str(vmid) if vmid is not None else "-",
            node,
            detail,
        )
    return t


def _drift_vlan_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Status", style="bold")
    t.add_column("Bridge")
    t.add_column("VLAN ID", justify="right")
    t.add_column("CIDR")
    t.add_column("Detail", style="dim")
    for status, bridge, vlan_id, cidr, detail, colour in rows:
        t.add_row(f"[{colour}]{status}[/{colour}]", bridge, vlan_id, cidr, detail)
    return t


def _drift_vm_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Status", style="bold")
    t.add_column("VM Name")
    t.add_column("VLAN")
    t.add_column("Detail", style="dim")
    for status, name, vlan, detail, colour in rows:
        t.add_row(f"[{colour}]{status}[/{colour}]", name, vlan, detail)
    return t


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------

@click.group()
@click.version_option(package_name="hiveframe")
@click.option("--debug", is_flag=True, default=False, help="Print config path and extra diagnostics")
@click.pass_context
def cli(ctx: click.Context, debug: bool) -> None:
    """HiveFrame -- Proxmox automation toolkit."""
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--name", "-n", required=True, help="Stack name")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.option("--force", is_flag=True, help="Overwrite if file already exists")
def init(name: str, file: str, force: bool) -> None:
    """Scaffold a new stack.yaml in the current directory."""
    import yaml

    out = Path(file)
    if out.exists() and not force:
        console.print(f"[red]FAIL[/red] {file} already exists. Use [bold]--force[/bold] to overwrite.")
        raise SystemExit(1)

    template = {
        "name": name,
        "description": "",
        "node": "pve",
        "vlans": [
            {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24",
             "gateway": "192.168.10.1", "description": "Management"},
        ],
        "vms": [],
    }

    out.write_text(yaml.safe_dump(template, sort_keys=False, allow_unicode=True))
    console.print(f"[green]OK[/green] Created [bold]{file}[/bold] for stack [bold]{name}[/bold]")
    console.print(f"  Edit it, then run: [bold]hiveframe validate -f {file}[/bold]")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
def validate(file: str) -> None:
    """Validate a stack.yaml against the schema."""
    stack = _load_stack(file)
    console.print(f"[green]OK[/green] {file} is valid -- stack [bold]{stack.name}[/bold]")
    console.print(f"  VLANs : {len(stack.vlans)}")
    console.print(f"  VMs   : {len(stack.vms)}")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.pass_context
def plan(ctx: click.Context, file: str) -> None:
    """Dry-run -- show what would be provisioned."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)
    registry = _make_registry(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, registry)
    stack_path = Path(file)

    try:
        vlan_actions = engine.plan_vlans()
        vm_actions = engine.plan_vms()
        fw_actions = engine.plan_firewall(stack_path)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Plan failed: {exc}")
        raise SystemExit(1) from exc

    # VLAN table
    vlan_rows = []
    for a in vlan_actions:
        colour = "green" if a.action == "CREATE" else "yellow"
        vlan_rows.append((a.action, a.vlan.vlan_id, a.bridge_name, a.node, a.vlan.cidr, a.reason, colour))
    console.print(_vlan_table(f"Plan -- VLANs ({stack.name})", vlan_rows))

    # VM table
    vm_rows = []
    for a in vm_actions:
        colour = "green" if a.action == "CREATE" else "yellow"
        vm_rows.append((a.action, a.vm.name, None, a.vm.vlan, a.node, a.reason, colour))
    if vm_rows:
        console.print(_vm_table(f"Plan -- VMs ({stack.name})", vm_rows))

    # Firewall table
    if fw_actions:
        fw_rows = []
        for a in fw_actions:
            colour = {"CREATE": "green", "REPLACE": "cyan", "SKIP": "yellow"}[a.action]
            fw_rows.append((a.vm.name, a.rule_count, a.action, a.vmid, a.node, a.reason, colour))
        console.print(_fw_table(f"Plan -- Firewall ({stack.name})", fw_rows))

    vlan_creates = sum(1 for a in vlan_actions if a.action == "CREATE")
    vm_creates = sum(1 for a in vm_actions if a.action == "CREATE")
    fw_creates = sum(1 for a in fw_actions if a.action in ("CREATE", "REPLACE"))
    console.print(
        f"\n  VLANs:    [bold]{vlan_creates}[/bold] to create, "
        f"[bold]{len(vlan_actions) - vlan_creates}[/bold] to skip"
    )
    console.print(
        f"  VMs:      [bold]{vm_creates}[/bold] to create, "
        f"[bold]{len(vm_actions) - vm_creates}[/bold] to skip"
    )
    if fw_actions:
        console.print(
            f"  Firewall: [bold]{fw_creates}[/bold] to apply, "
            f"[bold]{len(fw_actions) - fw_creates}[/bold] to skip"
        )


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.pass_context
def apply(ctx: click.Context, file: str) -> None:
    """Provision the stack against the live Proxmox host."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)
    registry = _make_registry(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, registry)
    stack_yaml = Path(file)

    console.print(f"Applying stack [bold]{stack.name}[/bold]...")

    # --- VLANs ---
    try:
        vlan_results = engine.apply_vlans(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] VLAN apply failed: {exc}")
        raise SystemExit(1) from exc

    vlan_rows = []
    for r in vlan_results:
        colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
        vlan_rows.append((r.outcome, r.vlan.vlan_id, r.bridge_name, r.node, r.vlan.cidr, r.reason, colour))
    console.print(_vlan_table(f"Apply -- VLANs ({stack.name})", vlan_rows))

    if any(r.outcome == "FAILED" for r in vlan_results):
        console.print("[red]FAIL[/red] VLAN provisioning had failures -- skipping VMs.")
        raise SystemExit(1)

    # --- VMs ---
    if stack.vms:
        try:
            vm_results = engine.apply_vms(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] VM apply failed: {exc}")
            raise SystemExit(1) from exc

        vm_rows = []
        for r in vm_results:
            colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
            vm_rows.append((r.outcome, r.vm.name, r.vmid, r.vm.vlan, r.node, r.reason, colour))
        console.print(_vm_table(f"Apply -- VMs ({stack.name})", vm_rows))

        if any(r.outcome == "FAILED" for r in vm_results):
            console.print("[red]FAIL[/red] VM provisioning had failures.")
            raise SystemExit(1)

    # --- Firewall ---
    vms_with_fw = [vm for vm in stack.vms if vm.firewall]
    if vms_with_fw:
        try:
            fw_results = engine.apply_firewall(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] Firewall apply failed: {exc}")
            raise SystemExit(1) from exc

        fw_rows = []
        for r in fw_results:
            colour = {"APPLIED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
            fw_rows.append((r.vm.name, r.rule_count, r.outcome, r.vmid, r.node, r.reason, colour))
        console.print(_fw_table(f"Apply -- Firewall ({stack.name})", fw_rows))

        if any(r.outcome == "FAILED" for r in fw_results):
            console.print("[red]FAIL[/red] Firewall provisioning had failures.")
            raise SystemExit(1)

    console.print("\n[green]OK[/green] State written to .hiveframe-state.json")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def destroy(ctx: click.Context, file: str, yes: bool) -> None:
    """Tear down a previously applied stack (firewall, VMs, then VLANs)."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)

    if not yes:
        click.confirm(f"Destroy all resources in stack '{stack.name}'?", abort=True)

    registry = _make_registry(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, registry)
    stack_yaml = Path(file)

    # --- Firewall first ---
    vms_with_fw = [vm for vm in stack.vms if vm.firewall]
    if vms_with_fw:
        try:
            fw_results = engine.destroy_firewall(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] Firewall destroy failed: {exc}")
            raise SystemExit(1) from exc

        if fw_results:
            fw_rows = []
            for r in fw_results:
                colour = {"APPLIED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
                label = "CLEARED" if r.outcome == "APPLIED" else r.outcome
                fw_rows.append((r.vm.name, r.rule_count, label, r.vmid, r.node, r.reason, colour))
            console.print(_fw_table(f"Destroy -- Firewall ({stack.name})", fw_rows))

        if any(r.outcome == "FAILED" for r in fw_results):
            console.print("[red]FAIL[/red] Firewall destroy had failures.")
            raise SystemExit(1)

    # --- VMs second ---
    if stack.vms:
        try:
            vm_results = engine.destroy_vms(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] VM destroy failed: {exc}")
            raise SystemExit(1) from exc

        if vm_results:
            vm_rows = []
            for r in vm_results:
                colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
                label = "DELETED" if r.outcome == "CREATED" else r.outcome
                vm_rows.append((label, r.vm.name, r.vmid, r.vm.vlan, r.node, r.reason, colour))
            console.print(_vm_table(f"Destroy -- VMs ({stack.name})", vm_rows))

        if any(r.outcome == "FAILED" for r in vm_results):
            console.print("[red]FAIL[/red] VM destroy had failures -- skipping VLAN teardown.")
            raise SystemExit(1)

    # --- VLANs last ---
    try:
        vlan_results = engine.destroy_vlans(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] VLAN destroy failed: {exc}")
        raise SystemExit(1) from exc

    vlan_rows = []
    for r in vlan_results:
        colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
        label = "DELETED" if r.outcome == "CREATED" else r.outcome
        vlan_rows.append((label, r.vlan.vlan_id, r.bridge_name, r.node, r.vlan.cidr, r.reason, colour))
    console.print(_vlan_table(f"Destroy -- VLANs ({stack.name})", vlan_rows))

    if any(r.outcome == "FAILED" for r in vlan_results):
        console.print("[red]FAIL[/red] VLAN destroy had failures.")
        raise SystemExit(1)


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True, help="Path to stack file (.yaml or .toml)")
@click.option("--watch", "-w", is_flag=True, default=False, help="Poll continuously for drift")
@click.option(
    "--interval", "-i",
    default=30, show_default=True, type=int,
    help="Polling interval in seconds (min 10, requires --watch)",
)
@click.pass_context
def status(ctx: click.Context, file: str, watch: bool, interval: int) -> None:
    """Show stack drift vs live Proxmox. Use --watch to poll continuously."""
    from hiveframe.provision.drift import DriftDetector
    from hiveframe.provision.state import load_state

    if interval < 10:
        console.print("[red]FAIL[/red] --interval must be at least 10 seconds")
        raise SystemExit(1)

    stack = _load_stack(file)
    stack_yaml = Path(file)
    registry = _make_registry(debug=ctx.obj.get("debug", False))
    detector = DriftDetector(stack, registry)

    _colours = {"OK": "green", "MISSING": "red", "STOPPED": "yellow", "UNEXPECTED": "dim"}

    def _print_report(report) -> None:
        bridge_to_vlan = {v.bridge: v for v in stack.vlans}
        vlan_rows = []
        for item in report.vlans:
            if item.status == "UNEXPECTED":
                continue
            cfg = bridge_to_vlan.get(item.name)
            vlan_rows.append((
                item.status, item.name,
                str(cfg.vlan_id) if cfg else "-",
                cfg.cidr if cfg else "-",
                item.detail or "",
                _colours[item.status],
            ))
        console.print(_drift_vlan_table(f"Status -- VLANs ({stack.name})", vlan_rows))

        name_to_vm = {vm.name: vm for vm in stack.vms}
        vm_rows = []
        for item in report.vms:
            if item.status == "UNEXPECTED":
                continue
            cfg = name_to_vm.get(item.name)
            vm_rows.append((
                item.status, item.name,
                cfg.vlan if cfg else "-",
                item.detail or "",
                _colours[item.status],
            ))
        if vm_rows:
            console.print(_drift_vm_table(f"Status -- VMs ({stack.name})", vm_rows))

        if report.has_drift:
            console.print("\n[red bold]! DRIFT DETECTED[/red bold]")
        else:
            console.print("\n[green]All resources healthy[/green]")

        unmanaged = sum(1 for i in report.vlans + report.vms if i.status == "UNEXPECTED")
        if unmanaged:
            console.print(
                f"  [dim]{unmanaged} unmanaged resource{'s' if unmanaged != 1 else ''} "
                "on node (not tracked by Hiveframe)[/dim]"
            )

    if not watch:
        try:
            report = detector.check()
        except Exception as exc:
            console.print(f"[red]FAIL[/red] Status check failed: {exc}")
            raise SystemExit(1) from exc
        _print_report(report)
        state = load_state(stack_yaml)
        if state:
            console.print(f"\n  Applied at: [dim]{state.applied_at}[/dim]")
        return

    # Watch loop
    try:
        while True:
            os.system("cls" if os.name == "nt" else "clear")
            console.print(
                f"Watching [bold]{stack.name}[/bold] — every {interval}s — Ctrl+C to stop"
            )
            for node_name in registry.list_nodes():
                ns = registry.get_node_settings(node_name)
                try:
                    registry.get_client(node_name)
                    console.print(f"  [green]{node_name} ({ns.host}) — connected[/green]")
                except Exception:
                    console.print(f"  [red]{node_name} ({ns.host}) — unreachable[/red]")
            try:
                report = detector.check()
                console.print(
                    f"  Last checked: [dim]"
                    f"{report.checked_at.strftime('%Y-%m-%d %H:%M:%S')} UTC[/dim]"
                )
                _print_report(report)
            except Exception as exc:
                console.print(
                    f"[yellow]Connection error — retrying in {interval}s: {exc}[/yellow]"
                )
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\nStopped.")
        raise SystemExit(0)


@cli.command()
@click.option("--host", default="127.0.0.1", show_default=True, help="Bind address")
@click.option("--port", default=8080, show_default=True, type=int, help="Port")
def web(host: str, port: int) -> None:
    """Start the HiveFrame web dashboard."""
    import uvicorn
    from hiveframe.web.app import app as fastapi_app
    console.print(f"[green]OK[/green] Dashboard at [bold]http://{host}:{port}[/bold]")
    console.print("  Press Ctrl+C to stop.")
    uvicorn.run(fastapi_app, host=host, port=port, log_level="warning")
