"""FastAPI + HTMX web dashboard."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from jinja2 import Environment, FileSystemLoader

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_jinja_env = Environment(
    loader=FileSystemLoader(str(_TEMPLATES_DIR)),
    cache_size=0,  # disable LRUCache — incompatible with Python 3.14
)
templates = Jinja2Templates(env=_jinja_env)

app = FastAPI(title="HiveFrame Dashboard", version="0.1.0")


# ---------------------------------------------------------------------------
# Data collection
# ---------------------------------------------------------------------------

def _collect() -> dict:
    """Build the full dashboard data dict from state file + live Proxmox."""
    data: dict = {
        "connected": False,
        "node_name": "unknown",
        "node_ip": "unknown",
        "proxmox_version": "unknown",
        "stacks": [],
        "total_vlans": 0,
        "total_vms": 0,
        "error": None,
    }

    cwd = Path.cwd()
    stack_yaml = cwd / "stack.yaml"

    # Load state (works even if stack.yaml doesn't exist — uses parent dir)
    from hiveframe.provision.state import load_state
    state = load_state(stack_yaml)

    # Load stack config for CIDR lookup (best-effort)
    stack = None
    if stack_yaml.exists():
        try:
            from hiveframe.models import Stack
            stack = Stack.from_yaml(stack_yaml)
        except Exception:
            pass

    try:
        from hiveframe.api.client import NodeRegistry
        from hiveframe.config.settings import load_settings
        settings = load_settings()
        registry = NodeRegistry(settings)
        node_name = registry.list_nodes()[0]
        client = registry.get_client(node_name)
        data["connected"] = True
        data["node_ip"] = registry.get_node_settings(node_name).host

        # Node info
        nodes = client.get_nodes()
        live_node_name = nodes[0]["node"] if nodes else node_name
        data["node_name"] = live_node_name
        try:
            info = client.get_node_info(live_node_name)
            raw = info.get("pveversion", "")
            # "pve-manager/8.1.4/..." → "8.1.4"
            data["proxmox_version"] = raw.split("/")[1] if "/" in raw else raw or "unknown"
        except Exception:
            pass

        # Status check
        if state and stack:
            from hiveframe.provision.engine import ProvisionEngine
            engine = ProvisionEngine(stack, registry)
            vlan_results, vm_results = engine.check_status(stack_yaml, node_name)

            vlan_data = []
            for r in vlan_results:
                cfg = next((v for v in stack.vlans if v.vlan_id == r.vlan_state.vlan_id), None)
                vlan_data.append({
                    "vlan_id": r.vlan_state.vlan_id,
                    "bridge": r.vlan_state.bridge,
                    "cidr": cfg.cidr if cfg else "-",
                    "live_status": r.live_status,
                })

            vm_data = [
                {
                    "name": r.vm_state.name,
                    "vmid": r.vm_state.vmid,
                    "vlan": r.vm_state.vlan,
                    "live_status": r.live_status,
                }
                for r in vm_results
            ]

            data["stacks"] = [{
                "stack_name": state.stack_name,
                "applied_at": state.applied_at,
                "vlans": vlan_data,
                "vms": vm_data,
            }]
            data["total_vlans"] = len(vlan_data)
            data["total_vms"] = len(vm_data)

        elif state and not stack:
            # State exists but no stack.yaml — show raw state without live check
            data["stacks"] = [{
                "stack_name": state.stack_name,
                "applied_at": state.applied_at,
                "vlans": [
                    {"vlan_id": v.vlan_id, "bridge": v.bridge, "cidr": "-", "live_status": "UNKNOWN"}
                    for v in state.vlans
                ],
                "vms": [
                    {"name": v.name, "vmid": v.vmid, "vlan": v.vlan, "live_status": "UNKNOWN"}
                    for v in state.vms
                ],
            }]
            data["total_vlans"] = len(state.vlans)
            data["total_vms"] = len(state.vms)

    except Exception as exc:
        data["error"] = str(exc)
        # Still show raw state if we have it
        if state:
            data["stacks"] = [{
                "stack_name": state.stack_name,
                "applied_at": state.applied_at,
                "vlans": [
                    {"vlan_id": v.vlan_id, "bridge": v.bridge, "cidr": "-", "live_status": "UNKNOWN"}
                    for v in state.vlans
                ],
                "vms": [
                    {"name": v.name, "vmid": v.vmid, "vlan": v.vlan, "live_status": "UNKNOWN"}
                    for v in state.vms
                ],
            }]
            data["total_vlans"] = len(state.vlans)
            data["total_vms"] = len(state.vms)

    return data


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse(request, "index.html", _collect())


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.get("/api/status")
def api_status() -> dict:
    return _collect()


@app.post("/api/refresh", response_class=HTMLResponse)
def api_refresh(request: Request):
    return templates.TemplateResponse(request, "_dashboard.html", _collect())
