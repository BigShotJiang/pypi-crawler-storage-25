"""Firewall rule model."""

from __future__ import annotations

import ipaddress
import re
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class RuleAction(StrEnum):
    ACCEPT = "ACCEPT"
    DROP = "DROP"
    REJECT = "REJECT"


class RuleDirection(StrEnum):
    IN = "in"
    OUT = "out"


def _validate_port_spec(v: str | None, field: str) -> str | None:
    if v is None:
        return v
    if re.fullmatch(r"\d+", v):
        port = int(v)
        if not (1 <= port <= 65535):
            raise ValueError(f"{field} port {port} out of range 1-65535")
    elif re.fullmatch(r"\d+:\d+", v):
        low, high = map(int, v.split(":"))
        if not (1 <= low <= 65535 and 1 <= high <= 65535 and low < high):
            raise ValueError(f"{field} range '{v}' invalid: must be low:high within 1-65535")
    else:
        raise ValueError(f"{field} '{v}' must be a port number (22) or range (80:443)")
    return v


def _validate_ip_or_cidr(v: str | None, field: str) -> str | None:
    if v is None:
        return v
    try:
        ipaddress.ip_address(v)
        return v
    except ValueError:
        pass
    try:
        ipaddress.ip_network(v, strict=False)
        return v
    except ValueError:
        raise ValueError(f"{field} '{v}' is not a valid IP address or CIDR")


class FirewallRule(BaseModel):
    direction: RuleDirection = Field(default=RuleDirection.IN)
    action: RuleAction = Field(default=RuleAction.ACCEPT)
    protocol: Literal["tcp", "udp", "icmp"] | None = Field(default=None)
    source: str | None = Field(default=None, description="Source IP, CIDR, or None for any")
    dest: str | None = Field(default=None, description="Destination IP, CIDR, or None for any")
    dport: str | None = Field(default=None, description="Destination port or range e.g. '22' or '80:443'")
    sport: str | None = Field(default=None, description="Source port or range")
    comment: str | None = Field(default=None)
    enabled: bool = Field(default=True)

    @field_validator("dport", mode="before")
    @classmethod
    def validate_dport(cls, v: str | None) -> str | None:
        return _validate_port_spec(v, "dport")

    @field_validator("sport", mode="before")
    @classmethod
    def validate_sport(cls, v: str | None) -> str | None:
        return _validate_port_spec(v, "sport")

    @field_validator("source", mode="before")
    @classmethod
    def validate_source(cls, v: str | None) -> str | None:
        return _validate_ip_or_cidr(v, "source")

    @field_validator("dest", mode="before")
    @classmethod
    def validate_dest(cls, v: str | None) -> str | None:
        return _validate_ip_or_cidr(v, "dest")

    @model_validator(mode="after")
    def protocol_required_for_ports(self) -> FirewallRule:
        if (self.dport is not None or self.sport is not None) and self.protocol is None:
            raise ValueError("protocol is required when dport or sport is specified")
        return self

    def to_proxmox_params(self) -> dict:
        """Return a dict ready for the Proxmox firewall rules POST API."""
        params: dict = {
            "type": str(self.direction),
            "action": str(self.action),
            "enable": int(self.enabled),
        }
        if self.protocol:
            params["proto"] = self.protocol
        if self.source:
            params["source"] = self.source
        if self.dest:
            params["dest"] = self.dest
        if self.dport:
            params["dport"] = self.dport
        if self.sport:
            params["sport"] = self.sport
        if self.comment:
            params["comment"] = self.comment
        return params
