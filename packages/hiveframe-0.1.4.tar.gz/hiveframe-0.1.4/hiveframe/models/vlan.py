"""VLAN definition model."""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class VlanConfig(BaseModel):
    name: str = Field(default="", description="Friendly identifier, used by VMs to reference this VLAN")
    vlan_id: int = Field(..., ge=1, le=4094, description="802.1Q VLAN ID")
    cidr: str = Field(..., description="CIDR subnet, e.g. 192.168.10.0/24")
    description: str = Field(default="")
    gateway: str | None = Field(default=None)
    node: str | None = Field(default=None, description="Override stack-level node for this VLAN")

    @property
    def bridge(self) -> str:
        return f"vmbr{self.vlan_id}"

    @field_validator("cidr")
    @classmethod
    def valid_cidr(cls, v: str) -> str:
        import ipaddress
        ipaddress.ip_network(v, strict=False)
        return v

    @field_validator("gateway")
    @classmethod
    def valid_gateway(cls, v: str | None) -> str | None:
        if v is None:
            return v
        import ipaddress
        ipaddress.ip_address(v)
        return v
