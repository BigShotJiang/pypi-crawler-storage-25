"""Unit tests for the models layer."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from hiveframe.models import Stack, VlanConfig, VmConfig
from hiveframe.models.vm import CloudInitConfig


# ---------------------------------------------------------------------------
# VlanConfig
# ---------------------------------------------------------------------------

def test_vlan_valid():
    v = VlanConfig(name="mgmt", vlan_id=10, cidr="192.168.10.0/24", gateway="192.168.10.1")
    assert v.vlan_id == 10
    assert v.bridge == "vmbr10"


def test_vlan_bad_id():
    with pytest.raises(ValidationError):
        VlanConfig(vlan_id=4095, cidr="192.168.10.0/24")


def test_vlan_bad_cidr():
    with pytest.raises(ValidationError):
        VlanConfig(vlan_id=10, cidr="not-a-cidr")


def test_vlan_bad_gateway():
    with pytest.raises(ValidationError):
        VlanConfig(vlan_id=10, cidr="192.168.10.0/24", gateway="not-an-ip")


def test_vlan_bridge_property():
    v = VlanConfig(vlan_id=99, cidr="192.168.99.0/24")
    assert v.bridge == "vmbr99"


# ---------------------------------------------------------------------------
# CloudInitConfig
# ---------------------------------------------------------------------------

def test_cloud_init_dhcp_shorthand():
    ci = CloudInitConfig(ip_config="dhcp")
    assert ci.proxmox_ipconfig0 == "ip=dhcp"


def test_cloud_init_static_passthrough():
    ci = CloudInitConfig(ip_config="ip=192.168.1.5/24,gw=192.168.1.1")
    assert ci.proxmox_ipconfig0 == "ip=192.168.1.5/24,gw=192.168.1.1"


def test_cloud_init_none():
    ci = CloudInitConfig()
    assert ci.proxmox_ipconfig0 is None


# ---------------------------------------------------------------------------
# VmConfig
# ---------------------------------------------------------------------------

def test_vm_valid():
    vm = VmConfig(name="web-01", template_id=9000, vlan="mgmt")
    assert vm.cores == 2
    assert vm.memory_mb == 2048
    assert vm.disk_gb == 20


def test_vm_invalid_hostname():
    with pytest.raises(ValidationError):
        VmConfig(name="bad name!", template_id=9000, vlan="mgmt")


def test_vm_hostname_hyphen_ok():
    vm = VmConfig(name="my-server-01", template_id=9000, vlan="mgmt")
    assert vm.name == "my-server-01"


# ---------------------------------------------------------------------------
# Stack
# ---------------------------------------------------------------------------

VALID_STACK = {
    "name": "test-stack",
    "node": "pve",
    "vlans": [{"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24"}],
    "vms": [{"name": "vm-01", "template_id": 9000, "vlan": "mgmt"}],
}


def test_stack_valid():
    s = Stack.model_validate(VALID_STACK)
    assert s.name == "test-stack"
    assert len(s.vlans) == 1
    assert len(s.vms) == 1


def test_stack_bad_vlan_ref():
    bad = {**VALID_STACK, "vms": [{"name": "vm-01", "template_id": 9000, "vlan": "missing"}]}
    with pytest.raises(ValidationError, match="vlan 'missing'"):
        Stack.model_validate(bad)


def test_stack_duplicate_vm_names():
    bad = {
        **VALID_STACK,
        "vms": [
            {"name": "vm-01", "template_id": 9000, "vlan": "mgmt"},
            {"name": "vm-01", "template_id": 9000, "vlan": "mgmt"},
        ],
    }
    with pytest.raises(ValidationError, match="Duplicate VM names"):
        Stack.model_validate(bad)


def test_stack_duplicate_vlan_ids():
    bad = {
        **VALID_STACK,
        "vlans": [
            {"name": "a", "vlan_id": 10, "cidr": "192.168.10.0/24"},
            {"name": "b", "vlan_id": 10, "cidr": "192.168.20.0/24"},
        ],
        "vms": [],  # remove VM references so only the duplicate-ID validator fires
    }
    with pytest.raises(ValidationError, match="Duplicate VLAN IDs"):
        Stack.model_validate(bad)


def test_stack_vlan_by_name():
    s = Stack.model_validate(VALID_STACK)
    vlan = s.vlan_by_name("mgmt")
    assert vlan.vlan_id == 10


def test_stack_vlan_by_name_missing():
    s = Stack.model_validate(VALID_STACK)
    with pytest.raises(KeyError):
        s.vlan_by_name("nope")


def test_stack_from_yaml(tmp_path):
    import yaml
    stack_file = tmp_path / "stack.yaml"
    stack_file.write_text(yaml.safe_dump(VALID_STACK))
    s = Stack.from_yaml(stack_file)
    assert s.name == "test-stack"
