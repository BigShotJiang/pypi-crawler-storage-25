"""Tests for VM provisioning — all API calls mocked."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from hiveframe.models import Stack
from hiveframe.provision.engine import ProvisionEngine, VmApplyResult, VmPlanAction
from hiveframe.provision.state import load_state, state_path_for


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

STACK_DATA = {
    "name": "test-stack",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24", "gateway": "192.168.10.1"},
    ],
    "vms": [
        {
            "name": "vm-01",
            "template_id": 9000,
            "vlan": "mgmt",
            "cores": 2,
            "memory_mb": 2048,
            "disk_gb": 20,
            "start_on_create": False,
            "cloud_init": {"user": "ubuntu", "ip_config": "dhcp"},
        }
    ],
}


@pytest.fixture()
def stack() -> Stack:
    return Stack.model_validate(STACK_DATA)


@pytest.fixture()
def mock_client() -> MagicMock:
    client = MagicMock()
    client.get_nodes.return_value = [{"node": "pve"}]
    client.get_next_vmid.return_value = 101
    client.clone_vm.return_value = "UPID:pve:000:clone-task"
    client.start_vm.return_value = "UPID:pve:000:start-task"
    client.wait_for_task.return_value = None
    client.get_vms.return_value = []
    return client


def _make_registry(mock_client: MagicMock) -> MagicMock:
    registry = MagicMock()
    registry.get_client.return_value = mock_client
    return registry


@pytest.fixture()
def mock_registry(mock_client: MagicMock) -> MagicMock:
    return _make_registry(mock_client)


@pytest.fixture()
def engine(stack: Stack, mock_registry: MagicMock) -> ProvisionEngine:
    return ProvisionEngine(stack, mock_registry)


# ---------------------------------------------------------------------------
# plan_vms
# ---------------------------------------------------------------------------

class TestPlanVms:
    def test_create_when_vm_missing(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.get_vms.return_value = []
        actions = engine.plan_vms("pve")
        assert len(actions) == 1
        assert actions[0].action == "CREATE"
        assert actions[0].vm.name == "vm-01"

    def test_skip_when_vm_exists(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.get_vms.return_value = [{"name": "vm-01", "vmid": 101, "status": "running"}]
        actions = engine.plan_vms("pve")
        assert actions[0].action == "SKIP"

    def test_no_api_mutation_during_plan(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.get_vms.return_value = []
        engine.plan_vms("pve")
        mock_client.clone_vm.assert_not_called()
        mock_client.set_cloud_init.assert_not_called()
        mock_client.start_vm.assert_not_called()


# ---------------------------------------------------------------------------
# apply_vms
# ---------------------------------------------------------------------------

class TestApplyVms:
    def test_full_create_sequence(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()

        results = engine.apply_vms(stack_yaml, "pve")

        assert len(results) == 1
        assert results[0].outcome == "CREATED"
        assert results[0].vmid == 101

        mock_client.get_next_vmid.assert_called_once_with("pve")
        mock_client.clone_vm.assert_called_once_with("pve", 9000, 101, "vm-01")
        mock_client.wait_for_task.assert_called()
        mock_client.set_cloud_init.assert_called_once()
        mock_client.set_network.assert_called_once_with("pve", 101, "vmbr10", 10)

    def test_start_vm_called_when_start_on_create_true(
        self, tmp_path: Path
    ):
        data = {**STACK_DATA, "vms": [{**STACK_DATA["vms"][0], "start_on_create": True}]}
        stack = Stack.model_validate(data)
        client = MagicMock()
        client.get_nodes.return_value = [{"node": "pve"}]
        client.get_next_vmid.return_value = 101
        client.clone_vm.return_value = "UPID:clone"
        client.start_vm.return_value = "UPID:start"
        client.get_vms.return_value = []
        engine = ProvisionEngine(stack, _make_registry(client))
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()

        engine.apply_vms(stack_yaml, "pve")

        client.start_vm.assert_called_once_with("pve", 101)

    def test_start_vm_not_called_when_start_on_create_false(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vms(stack_yaml, "pve")
        mock_client.start_vm.assert_not_called()

    def test_resize_skipped_when_disk_gb_equals_template(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vms(stack_yaml, "pve")
        mock_client.resize_disk.assert_not_called()

    def test_resize_called_when_disk_gb_exceeds_template(self, tmp_path: Path):
        data = {**STACK_DATA, "vms": [{**STACK_DATA["vms"][0], "disk_gb": 35}]}
        stack = Stack.model_validate(data)
        client = MagicMock()
        client.get_nodes.return_value = [{"node": "pve"}]
        client.get_next_vmid.return_value = 101
        client.clone_vm.return_value = "UPID:clone"
        client.get_vms.return_value = []
        engine = ProvisionEngine(stack, _make_registry(client))
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()

        engine.apply_vms(stack_yaml, "pve")

        client.resize_disk.assert_called_once_with("pve", 101, "scsi0", 15)

    def test_skip_existing_vm(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.get_vms.return_value = [{"name": "vm-01", "vmid": 101}]
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.apply_vms(stack_yaml, "pve")
        assert results[0].outcome == "SKIPPED"
        mock_client.clone_vm.assert_not_called()

    def test_clone_failure_recorded(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        from hiveframe.api.client import HiveframeAPIError
        mock_client.clone_vm.side_effect = HiveframeAPIError("insufficient storage")
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.apply_vms(stack_yaml, "pve")
        assert results[0].outcome == "FAILED"
        assert "insufficient storage" in results[0].reason


# ---------------------------------------------------------------------------
# destroy_vms
# ---------------------------------------------------------------------------

class TestDestroyVms:
    def _seed_state(self, engine: ProvisionEngine, mock_client: MagicMock, stack_yaml: Path):
        """Helper: run apply_vms to populate state file."""
        engine.apply_vms(stack_yaml, "pve")
        mock_client.reset_mock()
        mock_client.get_nodes.return_value = [{"node": "pve"}]

    def test_stop_then_delete(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        self._seed_state(engine, mock_client, stack_yaml)

        with patch("hiveframe.provision.engine.time.sleep"):
            results = engine.destroy_vms(stack_yaml, "pve")

        assert results[0].outcome == "CREATED"
        mock_client.stop_vm.assert_called_once_with("pve", 101)
        mock_client.delete_vm.assert_called_once_with("pve", 101)

    def test_stop_error_ignored(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        from hiveframe.api.client import HiveframeAPIError
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        self._seed_state(engine, mock_client, stack_yaml)
        mock_client.stop_vm.side_effect = HiveframeAPIError("already stopped")

        with patch("hiveframe.provision.engine.time.sleep"):
            results = engine.destroy_vms(stack_yaml, "pve")

        assert results[0].outcome == "CREATED"
        mock_client.delete_vm.assert_called_once()

    def test_destroy_no_state_returns_empty(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.destroy_vms(stack_yaml, "pve")
        assert results == []
        mock_client.stop_vm.assert_not_called()


# ---------------------------------------------------------------------------
# VM state sidecar
# ---------------------------------------------------------------------------

class TestVmStateSidecar:
    def test_vmid_written_after_apply(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vms(stack_yaml, "pve")

        state = load_state(stack_yaml)
        assert state is not None
        assert len(state.vms) == 1
        assert state.vms[0].name == "vm-01"
        assert state.vms[0].vmid == 101
        assert state.vms[0].vlan == "mgmt"
        assert state.vms[0].status == "applied"

    def test_vm_state_pruned_after_destroy(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vms(stack_yaml, "pve")

        with patch("hiveframe.provision.engine.time.sleep"):
            engine.destroy_vms(stack_yaml, "pve")

        state = load_state(stack_yaml)
        assert state.vms == []

    def test_vm_state_json_schema(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vms(stack_yaml, "pve")

        raw = json.loads(state_path_for(stack_yaml).read_text())
        assert "vms" in raw
        vm = raw["vms"][0]
        assert {"name", "vmid", "vlan", "status"} <= vm.keys()
