"""Tests for TOML stack loading via Stack.from_file()."""

from __future__ import annotations

import textwrap

import pytest
import yaml

from hiveframe.models import Stack


TOML_STACK = textwrap.dedent("""\
    [meta]
    name = "toml-stack"
    node = "pve"

    [[vlans]]
    name = "mgmt"
    vlan_id = 10
    cidr = "192.168.10.0/24"
    gateway = "192.168.10.1"

    [[vms]]
    name = "vm-01"
    template_id = 9000
    vlan = "mgmt"
    cores = 2
    memory_mb = 2048
    disk_gb = 20
    start_on_create = false

    [vms.cloud_init]
    user = "ubuntu"
    ssh_keys = []
    ip_config = "dhcp"
""")

YAML_STACK = {
    "name": "yaml-stack",
    "node": "pve",
    "vlans": [{"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24"}],
    "vms": [{"name": "vm-01", "template_id": 9000, "vlan": "mgmt"}],
}


def test_toml_loads_valid_stack(tmp_path):
    f = tmp_path / "stack.toml"
    f.write_text(TOML_STACK)
    stack = Stack.from_file(f)
    assert stack.name == "toml-stack"
    assert stack.node == "pve"
    assert len(stack.vlans) == 1
    assert stack.vlans[0].vlan_id == 10
    assert len(stack.vms) == 1
    assert stack.vms[0].name == "vm-01"


def test_toml_cloud_init_parsed(tmp_path):
    f = tmp_path / "stack.toml"
    f.write_text(TOML_STACK)
    stack = Stack.from_file(f)
    ci = stack.vms[0].cloud_init
    assert ci is not None
    assert ci.user == "ubuntu"
    assert ci.proxmox_ipconfig0 == "ip=dhcp"


def test_toml_without_meta_table(tmp_path):
    """Top-level name/node (no [meta]) is also valid."""
    content = textwrap.dedent("""\
        name = "bare-stack"
        node = "pve"

        [[vlans]]
        name = "mgmt"
        vlan_id = 10
        cidr = "192.168.10.0/24"

        [[vms]]
        name = "vm-01"
        template_id = 9000
        vlan = "mgmt"
    """)
    f = tmp_path / "stack.toml"
    f.write_text(content)
    stack = Stack.from_file(f)
    assert stack.name == "bare-stack"


def test_unrecognized_extension_raises(tmp_path):
    f = tmp_path / "stack.json"
    f.write_text("{}")
    with pytest.raises(ValueError, match="Unrecognized stack file extension"):
        Stack.from_file(f)


def test_yaml_still_loads_via_from_file(tmp_path):
    f = tmp_path / "stack.yaml"
    f.write_text(yaml.safe_dump(YAML_STACK))
    stack = Stack.from_file(f)
    assert stack.name == "yaml-stack"
    assert len(stack.vlans) == 1


def test_yml_extension_loads(tmp_path):
    f = tmp_path / "stack.yml"
    f.write_text(yaml.safe_dump(YAML_STACK))
    stack = Stack.from_file(f)
    assert stack.name == "yaml-stack"
