"""Tests for multi-node support — NodeRegistry, config migration, routing."""

from __future__ import annotations

import pytest
import yaml
from pathlib import Path
from unittest.mock import MagicMock, patch

from pydantic import ValidationError

from hiveframe.api.client import HiveframeAPIError, NodeRegistry
from hiveframe.config.settings import HiveframeSettings, NodeSettings, load_settings, _migrate_legacy
from hiveframe.models import Stack
from hiveframe.provision.engine import ProvisionEngine
from hiveframe.provision.state import StackState, VlanState, VmState, save_state


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _node_settings(name: str, host: str = "10.0.0.1") -> NodeSettings:
    return NodeSettings(
        name=name,
        host=host,
        user="root@pam",
        token_id="tok",
        token_secret="secret",
    )


def _settings(*node_names: str) -> HiveframeSettings:
    return HiveframeSettings(nodes=[_node_settings(n) for n in node_names])


# ---------------------------------------------------------------------------
# NodeSettings validation
# ---------------------------------------------------------------------------

class TestNodeSettings:
    def test_strips_https_scheme_from_host(self):
        ns = NodeSettings(name="pve", host="https://10.0.0.1/", token_id="t", token_secret="s")
        assert ns.host == "10.0.0.1"

    def test_strips_http_scheme_from_host(self):
        ns = NodeSettings(name="pve", host="http://10.0.0.1", token_id="t", token_secret="s")
        assert ns.host == "10.0.0.1"

    def test_host_unchanged_when_no_scheme(self):
        ns = NodeSettings(name="pve", host="10.0.0.1", token_id="t", token_secret="s")
        assert ns.host == "10.0.0.1"

    def test_default_user_is_root_pam(self):
        ns = NodeSettings(name="pve", host="10.0.0.1", token_id="t", token_secret="s")
        assert ns.user == "root@pam"

    def test_default_verify_ssl_is_false(self):
        ns = NodeSettings(name="pve", host="10.0.0.1", token_id="t", token_secret="s")
        assert ns.verify_ssl is False


class TestHiveframeSettings:
    def test_requires_at_least_one_node(self):
        with pytest.raises(ValidationError):
            HiveframeSettings(nodes=[])

    def test_accepts_multiple_nodes(self):
        s = _settings("pve", "pve2", "pve3")
        assert len(s.nodes) == 3
        assert [n.name for n in s.nodes] == ["pve", "pve2", "pve3"]


# ---------------------------------------------------------------------------
# Config migration
# ---------------------------------------------------------------------------

class TestConfigMigration:
    def test_migrate_legacy_produces_nodes_list(self):
        legacy = {
            "proxmox_host": "10.0.0.1",
            "proxmox_token_id": "tok",
            "proxmox_token_secret": "sec",
        }
        result = _migrate_legacy(legacy)
        assert "nodes" in result
        assert result["nodes"][0]["name"] == "pve"
        assert result["nodes"][0]["host"] == "10.0.0.1"

    def test_migrate_preserves_user(self):
        legacy = {
            "proxmox_host": "10.0.0.1",
            "proxmox_user": "admin@pam",
            "proxmox_token_id": "tok",
            "proxmox_token_secret": "sec",
        }
        result = _migrate_legacy(legacy)
        assert result["nodes"][0]["user"] == "admin@pam"

    def test_migrate_defaults_user_to_root_pam(self):
        legacy = {
            "proxmox_host": "10.0.0.1",
            "proxmox_token_id": "tok",
            "proxmox_token_secret": "sec",
        }
        result = _migrate_legacy(legacy)
        assert result["nodes"][0]["user"] == "root@pam"

    def test_migrate_preserves_verify_ssl(self):
        legacy = {
            "proxmox_host": "10.0.0.1",
            "proxmox_token_id": "tok",
            "proxmox_token_secret": "sec",
            "proxmox_verify_ssl": True,
        }
        result = _migrate_legacy(legacy)
        assert result["nodes"][0]["verify_ssl"] is True

    def test_load_settings_migrates_legacy_file(self, tmp_path):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({
            "proxmox_host": "10.0.0.1",
            "proxmox_token_id": "tok",
            "proxmox_token_secret": "sec",
        }))
        settings = load_settings(cfg)
        assert len(settings.nodes) == 1
        assert settings.nodes[0].name == "pve"

    def test_load_settings_reads_new_format(self, tmp_path):
        cfg = tmp_path / "config.yaml"
        cfg.write_text(yaml.safe_dump({"nodes": [
            {"name": "pve", "host": "10.0.0.1", "token_id": "t", "token_secret": "s"},
            {"name": "pve2", "host": "10.0.0.2", "token_id": "t", "token_secret": "s"},
        ]}))
        settings = load_settings(cfg)
        assert len(settings.nodes) == 2
        assert settings.nodes[1].name == "pve2"

    def test_load_settings_raises_when_no_file_and_no_env(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="No config file found"):
            load_settings(tmp_path / "missing.yaml")


# ---------------------------------------------------------------------------
# NodeRegistry
# ---------------------------------------------------------------------------

class TestNodeRegistry:
    def test_list_nodes_returns_names_in_order(self):
        registry = NodeRegistry(_settings("pve", "pve2", "pve3"))
        assert registry.list_nodes() == ["pve", "pve2", "pve3"]

    def test_get_node_settings_returns_correct_entry(self):
        s = HiveframeSettings(nodes=[
            _node_settings("pve", "10.0.0.1"),
            _node_settings("pve2", "10.0.0.2"),
        ])
        registry = NodeRegistry(s)
        ns = registry.get_node_settings("pve2")
        assert ns.host == "10.0.0.2"

    def test_get_node_settings_unknown_raises(self):
        registry = NodeRegistry(_settings("pve", "pve2"))
        with pytest.raises(HiveframeAPIError, match="Node 'pve3' not found"):
            registry.get_node_settings("pve3")

    def test_get_node_settings_error_lists_available(self):
        registry = NodeRegistry(_settings("pve", "pve2"))
        with pytest.raises(HiveframeAPIError, match="Available: pve, pve2"):
            registry.get_node_settings("bad-node")

    def test_get_client_unknown_raises(self):
        registry = NodeRegistry(_settings("pve"))
        with pytest.raises(HiveframeAPIError, match="Node 'other' not found"):
            registry.get_client("other")

    def test_get_client_is_lazy(self):
        """get_client should not attempt connection for other nodes."""
        s = _settings("pve", "pve2")
        registry = NodeRegistry(s)
        mock_client = MagicMock()
        with patch("hiveframe.api.client.ProxmoxClient", return_value=mock_client) as MockCls:
            registry.get_client("pve")
            assert MockCls.call_count == 1
            # pve2 client should not have been created yet
            assert "pve2" not in registry._clients

    def test_get_client_cached_on_second_call(self):
        s = _settings("pve")
        registry = NodeRegistry(s)
        with patch("hiveframe.api.client.ProxmoxClient") as MockCls:
            MockCls.return_value = MagicMock()
            c1 = registry.get_client("pve")
            c2 = registry.get_client("pve")
            assert c1 is c2
            assert MockCls.call_count == 1

    def test_all_clients_connects_all_nodes(self):
        s = _settings("pve", "pve2")
        registry = NodeRegistry(s)
        with patch("hiveframe.api.client.ProxmoxClient") as MockCls:
            MockCls.return_value = MagicMock()
            clients = registry.all_clients()
            assert set(clients.keys()) == {"pve", "pve2"}
            assert MockCls.call_count == 2


# ---------------------------------------------------------------------------
# ProvisionEngine — multi-node routing
# ---------------------------------------------------------------------------

MULTI_NODE_STACK_DATA = {
    "name": "multi-test",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24"},
        {"name": "app", "vlan_id": 20, "cidr": "192.168.20.0/24", "node": "pve2"},
    ],
    "vms": [
        {"name": "vm-01", "template_id": 9000, "vlan": "mgmt", "start_on_create": False},
        {"name": "vm-02", "template_id": 9000, "vlan": "app", "start_on_create": False, "node": "pve2"},
    ],
}


@pytest.fixture()
def pve_client() -> MagicMock:
    client = MagicMock()
    client.get_nodes.return_value = [{"node": "pve"}]
    client.get_next_vmid.return_value = 101
    client.clone_vm.return_value = "UPID:pve:000:clone"
    client.get_vms.return_value = []
    client.bridge_exists.return_value = False
    return client


@pytest.fixture()
def pve2_client() -> MagicMock:
    client = MagicMock()
    client.get_nodes.return_value = [{"node": "pve2"}]
    client.get_next_vmid.return_value = 201
    client.clone_vm.return_value = "UPID:pve2:000:clone"
    client.get_vms.return_value = []
    client.bridge_exists.return_value = False
    return client


@pytest.fixture()
def multi_registry(pve_client, pve2_client) -> MagicMock:
    registry = MagicMock()
    registry.get_client.side_effect = lambda name: (
        pve_client if name == "pve" else pve2_client
    )
    return registry


@pytest.fixture()
def multi_stack() -> Stack:
    return Stack.model_validate(MULTI_NODE_STACK_DATA)


class TestMultiNodeRouting:
    def test_plan_vlans_routes_to_correct_node(self, multi_stack, multi_registry, pve_client, pve2_client):
        engine = ProvisionEngine(multi_stack, multi_registry)
        actions = engine.plan_vlans("pve")
        vmbr10_action = next(a for a in actions if a.bridge_name == "vmbr10")
        vmbr20_action = next(a for a in actions if a.bridge_name == "vmbr20")
        assert vmbr10_action.node == "pve"
        assert vmbr20_action.node == "pve2"

    def test_apply_vlans_calls_correct_client_per_node(
        self, multi_stack, multi_registry, pve_client, pve2_client, tmp_path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine = ProvisionEngine(multi_stack, multi_registry)
        engine.apply_vlans(stack_yaml, "pve")

        pve_client.create_linux_bridge.assert_called_once()
        pve2_client.create_linux_bridge.assert_called_once()

    def test_apply_network_config_called_per_node(
        self, multi_stack, multi_registry, pve_client, pve2_client, tmp_path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine = ProvisionEngine(multi_stack, multi_registry)
        engine.apply_vlans(stack_yaml, "pve")

        pve_client.apply_network_config.assert_called_once_with("pve")
        pve2_client.apply_network_config.assert_called_once_with("pve2")

    def test_plan_vms_routes_to_correct_node(self, multi_stack, multi_registry):
        engine = ProvisionEngine(multi_stack, multi_registry)
        actions = engine.plan_vms("pve")
        vm01_action = next(a for a in actions if a.vm.name == "vm-01")
        vm02_action = next(a for a in actions if a.vm.name == "vm-02")
        assert vm01_action.node == "pve"
        assert vm02_action.node == "pve2"

    def test_apply_vms_calls_correct_client_per_node(
        self, multi_stack, multi_registry, pve_client, pve2_client, tmp_path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine = ProvisionEngine(multi_stack, multi_registry)
        engine.apply_vms(stack_yaml, "pve")

        pve_client.clone_vm.assert_called_once_with("pve", 9000, 101, "vm-01")
        pve2_client.clone_vm.assert_called_once_with("pve2", 9000, 201, "vm-02")


# ---------------------------------------------------------------------------
# Backward compat — single-node stack still works
# ---------------------------------------------------------------------------

SINGLE_NODE_STACK_DATA = {
    "name": "single-test",
    "node": "pve",
    "vlans": [{"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24"}],
    "vms": [{"name": "vm-01", "template_id": 9000, "vlan": "mgmt", "start_on_create": False}],
}


class TestSingleNodeBackwardCompat:
    def test_single_node_stack_works_with_registry(self, tmp_path):
        stack = Stack.model_validate(SINGLE_NODE_STACK_DATA)
        client = MagicMock()
        client.get_nodes.return_value = [{"node": "pve"}]
        client.get_next_vmid.return_value = 101
        client.clone_vm.return_value = "UPID:pve:000:clone"
        client.get_vms.return_value = []
        client.bridge_exists.return_value = False
        registry = MagicMock()
        registry.get_client.return_value = client

        engine = ProvisionEngine(stack, registry)
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()

        vlan_results = engine.apply_vlans(stack_yaml, "pve")
        vm_results = engine.apply_vms(stack_yaml, "pve")

        assert vlan_results[0].outcome == "CREATED"
        assert vm_results[0].outcome == "CREATED"
        client.create_linux_bridge.assert_called_once()
        client.clone_vm.assert_called_once_with("pve", 9000, 101, "vm-01")

    def test_old_state_file_without_node_field_loads(self, tmp_path):
        """State files written before multi-node must still be readable."""
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        state = StackState(
            stack_name="single-test",
            vlans=[VlanState(vlan_id=10, bridge="vmbr10", status="applied")],
            vms=[VmState(name="vm-01", vmid=101, vlan="mgmt", status="applied")],
        )
        save_state(stack_yaml, state)

        from hiveframe.provision.state import load_state
        loaded = load_state(stack_yaml)
        assert loaded is not None
        assert loaded.vms[0].node == ""
        assert loaded.vlans[0].node == ""

    def test_vm_node_field_defaults_to_none(self):
        from hiveframe.models.vm import VmConfig
        vm = VmConfig(name="vm", template_id=9000, vlan="mgmt")
        assert vm.node is None

    def test_vlan_node_field_defaults_to_none(self):
        from hiveframe.models.vlan import VlanConfig
        vlan = VlanConfig(name="mgmt", vlan_id=10, cidr="192.168.10.0/24")
        assert vlan.node is None
