"""Tests for firewall model validation and firewall provisioning."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError

from hiveframe.models import Stack
from hiveframe.models.firewall import FirewallRule
from hiveframe.provision.engine import FwApplyResult, FwPlanAction, ProvisionEngine
from hiveframe.provision.state import StackState, VlanState, VmState, save_state


# ---------------------------------------------------------------------------
# FirewallRule model validation
# ---------------------------------------------------------------------------

def test_valid_rule_accept_ssh():
    rule = FirewallRule(direction="in", action="ACCEPT", protocol="tcp", dport="22", comment="allow SSH")
    assert rule.dport == "22"
    assert rule.protocol == "tcp"
    assert rule.enabled is True


def test_valid_rule_drop_no_protocol():
    rule = FirewallRule(direction="in", action="DROP")
    assert rule.protocol is None
    assert rule.dport is None


def test_valid_rule_port_range():
    rule = FirewallRule(direction="in", action="ACCEPT", protocol="tcp", dport="8000:8100")
    assert rule.dport == "8000:8100"


def test_invalid_port_out_of_range():
    with pytest.raises(ValidationError, match="out of range"):
        FirewallRule(direction="in", action="ACCEPT", protocol="tcp", dport="99999")


def test_invalid_port_range_reversed():
    with pytest.raises(ValidationError, match="invalid"):
        FirewallRule(direction="in", action="ACCEPT", protocol="tcp", dport="443:80")


def test_invalid_port_not_a_number():
    with pytest.raises(ValidationError, match="must be a port number"):
        FirewallRule(direction="in", action="ACCEPT", protocol="tcp", dport="http")


def test_invalid_cidr_source():
    with pytest.raises(ValidationError, match="not a valid IP address or CIDR"):
        FirewallRule(direction="in", action="ACCEPT", source="not-an-ip")


def test_valid_cidr_source():
    rule = FirewallRule(direction="in", action="ACCEPT", source="10.0.0.0/8")
    assert rule.source == "10.0.0.0/8"


def test_valid_ip_dest():
    rule = FirewallRule(direction="out", action="ACCEPT", dest="192.168.1.1")
    assert rule.dest == "192.168.1.1"


def test_protocol_required_when_dport_set():
    with pytest.raises(ValidationError, match="protocol is required"):
        FirewallRule(direction="in", action="ACCEPT", dport="22")


def test_protocol_required_when_sport_set():
    with pytest.raises(ValidationError, match="protocol is required"):
        FirewallRule(direction="out", action="ACCEPT", sport="1024:65535")


def test_to_proxmox_params_full():
    rule = FirewallRule(
        direction="in", action="ACCEPT", protocol="tcp",
        dport="22", source="10.0.0.0/8", comment="test", enabled=True,
    )
    params = rule.to_proxmox_params()
    assert params["type"] == "in"
    assert params["action"] == "ACCEPT"
    assert params["proto"] == "tcp"
    assert params["dport"] == "22"
    assert params["source"] == "10.0.0.0/8"
    assert params["comment"] == "test"
    assert params["enable"] == 1


def test_to_proxmox_params_minimal():
    rule = FirewallRule(direction="in", action="DROP")
    params = rule.to_proxmox_params()
    assert "proto" not in params
    assert "dport" not in params
    assert "comment" not in params


# ---------------------------------------------------------------------------
# Fixtures shared by engine tests
# ---------------------------------------------------------------------------

STACK_DATA = {
    "name": "fw-test-stack",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24"},
    ],
    "vms": [
        {
            "name": "vm-01",
            "template_id": 9000,
            "vlan": "mgmt",
            "start_on_create": False,
            "firewall": [
                {"direction": "in", "action": "ACCEPT", "protocol": "tcp", "dport": "22", "comment": "allow SSH"},
                {"direction": "in", "action": "DROP"},
            ],
        }
    ],
}


@pytest.fixture()
def stack() -> Stack:
    return Stack.model_validate(STACK_DATA)


@pytest.fixture()
def mock_client() -> MagicMock:
    client = MagicMock()
    client.get_nodes.return_value = [{"node": "pve"}]
    return client


@pytest.fixture()
def mock_registry(mock_client: MagicMock) -> MagicMock:
    registry = MagicMock()
    registry.get_client.return_value = mock_client
    return registry


@pytest.fixture()
def state_with_vm(tmp_path) -> tuple[Path, Path]:
    """Write a state file containing vm-01 with vmid=101."""
    stack_yaml = tmp_path / "stack.yaml"
    stack_yaml.write_text("")
    state = StackState(
        stack_name="fw-test-stack",
        vlans=[VlanState(vlan_id=10, bridge="vmbr10", status="applied")],
        vms=[VmState(name="vm-01", vmid=101, vlan="mgmt", status="applied")],
    )
    save_state(stack_yaml, state)
    return stack_yaml, tmp_path


# ---------------------------------------------------------------------------
# plan_firewall
# ---------------------------------------------------------------------------

def test_plan_firewall_skip_when_vm_not_in_state(stack, mock_client, mock_registry, tmp_path):
    stack_yaml = tmp_path / "stack.yaml"
    stack_yaml.write_text("")
    engine = ProvisionEngine(stack, mock_registry)
    actions = engine.plan_firewall(stack_yaml)
    assert len(actions) == 1
    assert actions[0].action == "SKIP"
    assert actions[0].vmid is None


def test_plan_firewall_create_when_no_existing_rules(stack, mock_client, mock_registry, state_with_vm):
    stack_yaml, _ = state_with_vm
    mock_client.get_vm_firewall_rules.return_value = []
    engine = ProvisionEngine(stack, mock_registry)
    actions = engine.plan_firewall(stack_yaml)
    assert len(actions) == 1
    assert actions[0].action == "CREATE"
    assert actions[0].vmid == 101
    assert actions[0].rule_count == 2


def test_plan_firewall_replace_when_rules_exist(stack, mock_client, mock_registry, state_with_vm):
    stack_yaml, _ = state_with_vm
    mock_client.get_vm_firewall_rules.return_value = [{"type": "in", "action": "DROP"}]
    engine = ProvisionEngine(stack, mock_registry)
    actions = engine.plan_firewall(stack_yaml)
    assert actions[0].action == "REPLACE"


# ---------------------------------------------------------------------------
# apply_firewall
# ---------------------------------------------------------------------------

def test_apply_firewall_clears_then_reapplies(stack, mock_client, mock_registry, state_with_vm):
    stack_yaml, _ = state_with_vm
    mock_client.get_vm_firewall_rules.return_value = []
    engine = ProvisionEngine(stack, mock_registry)
    results = engine.apply_firewall(stack_yaml)

    assert len(results) == 1
    assert results[0].outcome == "APPLIED"
    assert results[0].rule_count == 2
    mock_client.clear_vm_firewall_rules.assert_called_once_with("pve", 101)
    assert mock_client.add_vm_firewall_rule.call_count == 2
    mock_client.enable_vm_firewall.assert_called_once_with("pve", 101)


def test_apply_firewall_skips_vm_not_in_state(stack, mock_client, mock_registry, tmp_path):
    stack_yaml = tmp_path / "stack.yaml"
    stack_yaml.write_text("")
    engine = ProvisionEngine(stack, mock_registry)
    results = engine.apply_firewall(stack_yaml)
    assert results[0].outcome == "SKIPPED"
    mock_client.clear_vm_firewall_rules.assert_not_called()


def test_apply_firewall_updates_state_rule_count(stack, mock_client, mock_registry, state_with_vm):
    from hiveframe.provision.state import load_state
    stack_yaml, _ = state_with_vm
    mock_client.get_vm_firewall_rules.return_value = []
    engine = ProvisionEngine(stack, mock_registry)
    engine.apply_firewall(stack_yaml)
    state = load_state(stack_yaml)
    vm_state = next(vs for vs in state.vms if vs.name == "vm-01")
    assert vm_state.firewall_rules_count == 2


# ---------------------------------------------------------------------------
# destroy_firewall
# ---------------------------------------------------------------------------

def test_destroy_firewall_clears_rules(stack, mock_client, mock_registry, state_with_vm):
    stack_yaml, _ = state_with_vm
    engine = ProvisionEngine(stack, mock_registry)
    results = engine.destroy_firewall(stack_yaml)
    assert len(results) == 1
    assert results[0].outcome == "APPLIED"
    mock_client.clear_vm_firewall_rules.assert_called_once_with("pve", 101)


def test_destroy_firewall_returns_empty_when_no_state(stack, mock_client, mock_registry, tmp_path):
    stack_yaml = tmp_path / "stack.yaml"
    stack_yaml.write_text("")
    engine = ProvisionEngine(stack, mock_registry)
    results = engine.destroy_firewall(stack_yaml)
    assert results == []
    mock_client.clear_vm_firewall_rules.assert_not_called()
