"""Tests for DriftDetector."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from hiveframe.models import Stack
from hiveframe.provision.drift import DriftDetector, DriftItem, DriftReport


STACK_DATA = {
    "name": "drift-test-stack",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24"},
    ],
    "vms": [
        {
            "name": "vm-01",
            "template_id": 9000,
            "vlan": "mgmt",
            "start_on_create": True,
            "cloud_init": {"user": "ubuntu"},
        }
    ],
}


@pytest.fixture()
def stack() -> Stack:
    return Stack.model_validate(STACK_DATA)


@pytest.fixture()
def mock_client() -> MagicMock:
    client = MagicMock()
    client.get_network_config.return_value = [{"iface": "vmbr10", "type": "bridge"}]
    client.get_vms.return_value = [{"name": "vm-01", "vmid": 101, "status": "running"}]
    return client


@pytest.fixture()
def mock_registry(mock_client: MagicMock) -> MagicMock:
    registry = MagicMock()
    registry.get_client.return_value = mock_client
    return registry


# ---------------------------------------------------------------------------
# has_drift property
# ---------------------------------------------------------------------------

def test_all_ok_has_drift_false(stack, mock_registry):
    report = DriftDetector(stack, mock_registry).check()
    assert report.has_drift is False
    assert all(i.status == "OK" for i in report.vlans + report.vms)


# ---------------------------------------------------------------------------
# VLAN drift
# ---------------------------------------------------------------------------

def test_missing_vlan_sets_has_drift_true(stack, mock_client, mock_registry):
    mock_client.get_network_config.return_value = []
    report = DriftDetector(stack, mock_registry).check()
    assert report.has_drift is True
    missing = [i for i in report.vlans if i.status == "MISSING"]
    assert len(missing) == 1
    assert missing[0].name == "vmbr10"
    assert missing[0].kind == "vlan"


def test_unexpected_vlan_detected(stack, mock_client, mock_registry):
    mock_client.get_network_config.return_value = [
        {"iface": "vmbr10"},
        {"iface": "vmbr99"},
    ]
    report = DriftDetector(stack, mock_registry).check()
    assert report.has_drift is False  # UNEXPECTED is informational, not drift
    unexpected = [i for i in report.vlans if i.status == "UNEXPECTED"]
    assert len(unexpected) == 1
    assert unexpected[0].name == "vmbr99"


def test_non_vmbr_iface_not_flagged_as_unexpected(stack, mock_client, mock_registry):
    mock_client.get_network_config.return_value = [
        {"iface": "vmbr10"},
        {"iface": "eth0"},
        {"iface": "bond0"},
    ]
    report = DriftDetector(stack, mock_registry).check()
    unexpected = [i for i in report.vlans if i.status == "UNEXPECTED"]
    assert unexpected == []


# ---------------------------------------------------------------------------
# VM drift
# ---------------------------------------------------------------------------

def test_missing_vm_sets_has_drift_true(stack, mock_client, mock_registry):
    mock_client.get_vms.return_value = []
    report = DriftDetector(stack, mock_registry).check()
    assert report.has_drift is True
    missing = [i for i in report.vms if i.status == "MISSING"]
    assert len(missing) == 1
    assert missing[0].name == "vm-01"
    assert missing[0].kind == "vm"


def test_stopped_vm_with_start_on_create_true_returns_stopped(stack, mock_client, mock_registry):
    mock_client.get_vms.return_value = [{"name": "vm-01", "vmid": 101, "status": "stopped"}]
    report = DriftDetector(stack, mock_registry).check()
    assert report.has_drift is True
    stopped = [i for i in report.vms if i.status == "STOPPED"]
    assert len(stopped) == 1
    assert stopped[0].name == "vm-01"


def test_stopped_vm_with_start_on_create_false_returns_ok():
    data = {**STACK_DATA, "vms": [{**STACK_DATA["vms"][0], "start_on_create": False}]}
    stack = Stack.model_validate(data)
    client = MagicMock()
    client.get_network_config.return_value = [{"iface": "vmbr10"}]
    client.get_vms.return_value = [{"name": "vm-01", "vmid": 101, "status": "stopped"}]
    registry = MagicMock()
    registry.get_client.return_value = client
    report = DriftDetector(stack, registry).check()
    vm_item = next(i for i in report.vms if i.name == "vm-01")
    assert vm_item.status == "OK"
    assert report.has_drift is False


def test_unexpected_vm_detected(stack, mock_client, mock_registry):
    mock_client.get_vms.return_value = [
        {"name": "vm-01", "vmid": 101, "status": "running"},
        {"name": "orphaned-vm", "vmid": 999, "status": "running"},
    ]
    report = DriftDetector(stack, mock_registry).check()
    assert report.has_drift is False  # UNEXPECTED is informational, not drift
    unexpected = [i for i in report.vms if i.status == "UNEXPECTED"]
    assert len(unexpected) == 1
    assert unexpected[0].name == "orphaned-vm"


# ---------------------------------------------------------------------------
# DriftReport metadata
# ---------------------------------------------------------------------------

def test_report_checked_at_is_utc(stack, mock_registry):
    from datetime import timezone
    report = DriftDetector(stack, mock_registry).check()
    assert report.checked_at.tzinfo == timezone.utc


def test_report_has_drift_false_when_all_items_ok(stack, mock_registry):
    report = DriftReport(
        checked_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
        vlans=[DriftItem("vmbr10", "vlan", "OK")],
        vms=[DriftItem("vm-01", "vm", "OK")],
    )
    assert report.has_drift is False


def test_report_has_drift_true_when_any_item_not_ok(stack, mock_registry):
    from datetime import datetime, timezone
    report = DriftReport(
        checked_at=datetime.now(timezone.utc),
        vlans=[DriftItem("vmbr10", "vlan", "OK")],
        vms=[DriftItem("vm-01", "vm", "MISSING")],
    )
    assert report.has_drift is True
