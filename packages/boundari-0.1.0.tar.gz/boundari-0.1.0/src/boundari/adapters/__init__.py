"""Optional framework adapters."""
