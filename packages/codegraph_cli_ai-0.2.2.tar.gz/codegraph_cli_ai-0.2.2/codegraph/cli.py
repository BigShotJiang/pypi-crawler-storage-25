"""
CodeGraph AI - CLI Entry Point
"""

import json
import typer
import webbrowser
import networkx as nx
from pathlib import Path
from typing import Optional
from codegraph.parsers.python_parser import PythonParser
from codegraph.graph.builder import GraphBuilder
from codegraph.indexer.embedder import get_embedder
from codegraph.indexer.node_embedder import NodeEmbedder
import warnings
import os

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message=".*NotOpenSSLWarning.*")
os.environ.setdefault("PYTHONWARNINGS", "ignore")


app = typer.Typer()


@app.callback()
def main():
    """CodeGraph AI - Understand your codebase using graphs and AI."""
    pass


# ──────────────────────────────────────────────
# File scanning filters
# ──────────────────────────────────────────────

IGNORE_DIRS = {
    "venv", ".venv", "env", "bin", "Scripts",
    ".git", "__pycache__", "node_modules", ".codegraph"
}
IGNORE_FILES = {"graph.json", ".DS_Store"}
IGNORE_EXTENSIONS = {".pyc", ".log", ".pyo", ".pyd"}

ASSET_EXTENSIONS = {
    ".csv", ".json", ".db", ".sqlite",
    ".pdf",
    ".png", ".jpg", ".jpeg",
}


def is_virtualenv(path: Path) -> bool:
    """Detect virtual environments by their structure."""
    return (
        (path / "pyvenv.cfg").exists()
        or (path / "bin" / "python").exists()
        or (path / "Scripts" / "python.exe").exists()
    )


def scan_files(root: Path) -> tuple[list[Path], list[Path]]:
    """
    Scan root directory and return (py_files, asset_files),
    skipping venvs, hidden dirs, and ignored extensions.
    """
    venv_dirs = {item for item in root.iterdir() if item.is_dir() and is_virtualenv(item)}

    all_files = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if any(part in IGNORE_DIRS for part in p.parts):
            continue
        if any(v in p.parents for v in venv_dirs):
            continue
        if p.name in IGNORE_FILES:
            continue
        if p.suffix.lower() in IGNORE_EXTENSIONS:
            continue
        all_files.append(p)

    py_files = [f for f in all_files if f.suffix == ".py"]
    asset_files = [f for f in all_files if f.suffix.lower() in ASSET_EXTENSIONS]
    return py_files, asset_files


# ──────────────────────────────────────────────
# index
# ──────────────────────────────────────────────

@app.command()
def index(
    path: str = typer.Argument(".", help="Path to the repo or folder to index"),
    embedder: str = typer.Option(
        "sentence-transformers", "--embedder",
        help="Embedding provider: sentence-transformers | openai | anthropic | google"
    ),
    embedder_model: Optional[str] = typer.Option(
        None, "--embedder-model",
        help="Override the default model for the chosen embedder"
    ),
    skip_embed: bool = typer.Option(
        False, "--skip-embed",
        help="Skip the embedding step (build graph only)"
    ),
):
    """
    Scan a directory, parse all Python files and assets,
    build the knowledge graph, embed nodes, and save everything
    to .codegraph/.
    """
    root = Path(path).resolve()

    if not root.exists():
        typer.echo(f"[error] Path does not exist: {root}", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Indexing: {root}\n")

    # Step 1 — Scan
    py_files, asset_files = scan_files(root)

    if not py_files and not asset_files:
        typer.echo("No supported files found (everything may be ignored).")
        raise typer.Exit()

    typer.echo(f"Found {len(py_files)} Python file(s) and {len(asset_files)} asset(s)\n")

    # Step 2 — Parse Python files
    py_parser = PythonParser()
    parsed_files = []
    failed_files = []

    for filepath in py_files:
        result = py_parser.parse_file(str(filepath))
        if result.errors:
            failed_files.append((str(filepath), result.errors))
        else:
            typer.echo(f"  ✔ [code]  {filepath.relative_to(root)}")
            parsed_files.append(result)

    # Step 3 — Parse assets (multimodal)
    parsed_assets = []
    if asset_files:
        try:
            from codegraph.parsers.multimodal_parser import MultiModalParser
            mm_parser = MultiModalParser()
            for filepath in asset_files:
                try:
                    asset = mm_parser.parse(str(filepath))
                    typer.echo(f"  ✔ [asset] {filepath.relative_to(root)}")
                    parsed_assets.append(asset)
                except Exception as e:
                    failed_files.append((str(filepath), [str(e)]))
        except ImportError:
            typer.echo("  [warn] multimodal_parser not found — skipping assets")

    # Step 4 — Build graph
    typer.echo("\nBuilding graph...")
    builder = GraphBuilder()
    if parsed_assets:
        builder.build(parsed_files, parsed_assets)
    else:
        builder.build(parsed_files)
    summary = builder.summary()

    # Step 5 — Save graph.json
    output_dir = root / ".codegraph"
    output_dir.mkdir(exist_ok=True)
    output_file = output_dir / "graph.json"
    with output_file.open("w", encoding="utf-8") as fp:
        json.dump(builder.to_dict(), fp, indent=2)

    # Step 6 — Embed nodes into FAISS
    if not skip_embed:
        typer.echo(f"\nEmbedding nodes using: {embedder}")
        try:
            emb = get_embedder(embedder, model=embedder_model)
            node_embedder = NodeEmbedder(emb)
            embed_summary = node_embedder.build_and_save(output_dir)
            typer.echo(f"  ✔  Embedded {embed_summary['nodes_embedded']} nodes")
            typer.echo(f"  ✔  Dimension  : {embed_summary['embedding_dim']}")
            typer.echo(f"  ✔  FAISS index: {embed_summary['faiss_index']}")
        except (ImportError, EnvironmentError) as e:
            typer.echo(f"\n  [warn] Embedding skipped: {e}", err=True)
            typer.echo("  [warn] Use --skip-embed to suppress this warning.")
    else:
        typer.echo("\nEmbedding skipped (--skip-embed)")

    # Step 7 — Summary
    typer.echo("\n" + "=" * 50)
    typer.echo("Index complete")
    typer.echo(f"  Graph saved   : {output_file}")
    typer.echo(f"  Files parsed  : {len(parsed_files)}")
    typer.echo(f"  Assets parsed : {len(parsed_assets)}")
    typer.echo(f"  Graph nodes   : {summary['total_nodes']}")
    typer.echo(f"  Graph edges   : {summary['total_edges']}")
    typer.echo("\n  Node breakdown:")
    for kind, count in summary["nodes_by_kind"].items():
        typer.echo(f"    {kind:<12}: {count}")
    typer.echo("\n  Edge breakdown:")
    for rel, count in summary["edges_by_relation"].items():
        typer.echo(f"    {rel:<12}: {count}")

    if failed_files:
        typer.echo(f"\n  Failed files  : {len(failed_files)}")
        for fp, errors in failed_files:
            typer.echo(f"    {fp}: {errors}")


# ──────────────────────────────────────────────
# plot
# ──────────────────────────────────────────────

@app.command()
def plot(
    hide_external: bool = typer.Option(False, "--hide-external", help="Hide external/stdlib nodes"),
    level: Optional[str] = typer.Option(None, "--level", help="Show only: file, function, class, method"),
    focus: Optional[str] = typer.Option(None, "--focus", help="Focus on a specific file (e.g. cli.py)"),
    edge_type: Optional[str] = typer.Option(None, "--edge-type", help="Filter edges: calls, imports, contains, all"),
):
    """Visualize the knowledge graph as a premium interactive HTML file."""
    root = Path(".").resolve()
    graph_file = root / ".codegraph" / "graph.json"

    if not graph_file.exists():
        typer.echo("[error] No graph found. Run 'codegraph index' first.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Loading graph from {graph_file}...")
    with graph_file.open("r", encoding="utf-8") as f:
        data = json.load(f)

    G = nx.DiGraph()
    for node in data.get("nodes", []):
        G.add_node(node["id"], **{k: v for k, v in node.items() if k != "id"})
    for edge in data.get("edges", []):
        G.add_edge(edge["source"], edge["target"], **{k: v for k, v in edge.items() if k not in ["source", "target"]})

    # Apply filters
    if hide_external:
        G.remove_nodes_from([n for n, d in G.nodes(data=True) if d.get("external", False)])

    if level:
        allowed = set(level.split(","))
        G.remove_nodes_from([n for n, d in G.nodes(data=True) if d.get("kind") not in allowed])

    if focus:
        focus_id = f"file:{focus}"
        if focus_id in G:
            keep = {focus_id} | set(G.successors(focus_id)) | set(G.predecessors(focus_id))
            G.remove_nodes_from([n for n in list(G.nodes) if n not in keep])
        else:
            typer.echo(f"[warn] File '{focus}' not found in graph. Showing full graph.")

    if edge_type and edge_type != "all":
        allowed_edges = set(edge_type.split(","))
        G.remove_edges_from([(s, t) for s, t, d in G.edges(data=True) if d.get("relation") not in allowed_edges])
        G.remove_nodes_from(list(nx.isolates(G)))

    typer.echo(f"Rendering {G.number_of_nodes()} nodes, {G.number_of_edges()} edges...")

    html = _build_premium_html(G)
    output_path = root / "graph.html"
    output_path.write_text(html, encoding="utf-8")

    typer.echo(f"Saved to: {output_path}")
    typer.echo("Opening in browser...")
    webbrowser.open(f"file://{output_path.resolve()}")


def _build_premium_html(G: nx.DiGraph) -> str:
    """Generate a self-contained premium HTML visualization using vis.js."""

    STYLES = {
        "file":     {"color": "#4A90E2", "shape": "dot", "size": 30},
        "class":    {"color": "#F5A623", "shape": "dot", "size": 26},
        "function": {"color": "#50C878", "shape": "dot", "size": 18},
        "method":   {"color": "#7ED6A8", "shape": "dot", "size": 16},
        "module":   {"color": "#B0BEC5", "shape": "dot", "size": 16},
        "dataset":  {"color": "#FFD700", "shape": "dot", "size": 24},
        "database": {"color": "#FF69B4", "shape": "dot", "size": 26},
        "document": {"color": "#9B59B6", "shape": "dot", "size": 26},
        "image":    {"color": "#5DADE2", "shape": "dot", "size": 26},
    }

    EDGE_COLORS = {
        "contains":   "#4A90E2",
        "calls":      "#50C878",
        "imports":    "#B0BEC5",
        "defined_in": "#444C5E",
        "uses":       "#FFD700",
        "references": "#9B59B6",
    }

    nodes_js = []
    for node_id, attrs in G.nodes(data=True):
        kind     = attrs.get("kind", "function")
        label    = attrs.get("label", node_id)
        external = attrs.get("external", False)
        style    = STYLES.get(kind, STYLES["function"])

        color = "#2A2D3A" if external else style["color"]
        size  = max(style["size"] - 4, 12) if external else style["size"]

        tooltip_parts = [f"<b>{label}</b>", f"Kind: {kind}"]
        if attrs.get("filename"):
            tooltip_parts.append(f"File: {attrs['filename']}")
        elif attrs.get("file"):
            tooltip_parts.append(f"File: {attrs['file'].replace('file:', '')}")
        if attrs.get("cls"):
            tooltip_parts.append(f"Class: {attrs['cls']}")

        metadata = attrs.get("metadata", {})
        if metadata:
            if "columns" in metadata:
                cols = ", ".join(metadata["columns"][:5])
                tooltip_parts.append(f"Columns: {cols}{'...' if len(metadata['columns']) > 5 else ''}")
            if "tables" in metadata:
                tooltip_parts.append(f"Tables: {', '.join(metadata['tables'])}")
            if "keys" in metadata:
                keys = ", ".join(metadata["keys"][:5])
                tooltip_parts.append(f"Keys: {keys}{'...' if len(metadata['keys']) > 5 else ''}")
            if "num_pages" in metadata:
                tooltip_parts.append(f"Pages: {metadata['num_pages']}")
            if metadata.get("text_preview"):
                tooltip_parts.append(f"Preview: <i>{metadata['text_preview']}</i>")
            if metadata.get("text"):
                tooltip_parts.append(f"OCR: <i>{metadata['text']}</i>")

        if external:
            tooltip_parts.append("<i style='color:#546E7A'>external</i>")

        tooltip = "<br>".join(tooltip_parts)

        nodes_js.append(f"""{{
            id: {json.dumps(node_id)},
            label: {json.dumps(label)},
            title: {json.dumps(tooltip)},
            color: {{
                background: {json.dumps(color)},
                border: {json.dumps(_darken(color))},
                highlight: {{ background: "#FFE082", border: "#FFA000" }},
                hover: {{ background: "#1E2A3A", border: "#4A90E2" }}
            }},
            shape: {json.dumps(style["shape"])},
            size: {size},
            font: {{ size: 14, face: "Inter, system-ui, sans-serif", color: "#E0E0E0",
                     strokeWidth: 4, strokeColor: "#0B0D13" }},
            borderWidth: {"1" if external else "2.5"},
            shadow: {{ enabled: true, color: "rgba(0,0,0,0.4)", size: 12, x: 0, y: 0 }}
        }}""")

    edges_js = []
    for src, dst, attrs in G.edges(data=True):
        relation = attrs.get("relation", "")
        color    = EDGE_COLORS.get(relation, "#3A3D4A")
        dashed   = relation in ("defined_in", "imports")

        edges_js.append(f"""{{
            from: {json.dumps(src)},
            to: {json.dumps(dst)},
            label: {json.dumps(relation)},
            color: {{ color: {json.dumps(color)}, opacity: {"0.3" if dashed else "0.7"} }},
            dashes: {"true" if dashed else "false"},
            width: {"1" if dashed else "2"},
            font: {{ color: "#607D8B", size: 11, face: "Inter, system-ui, sans-serif",
                     align: "middle", strokeWidth: 3, strokeColor: "#0B0D13" }},
            arrows: {{ to: {{ enabled: true, scaleFactor: 0.5 }} }},
            smooth: {{ type: "curvedCW", roundness: 0.2 }}
        }}""")

    nodes_json = "[\n" + ",\n".join(nodes_js) + "\n]"
    edges_json = "[\n" + ",\n".join(edges_js) + "\n]"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CodeGraph AI | Visual Intelligence</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
<style>
  :root {{
    --bg-color: #0B0D13;
    --panel-bg: rgba(22, 27, 34, 0.7);
    --border-color: rgba(255, 255, 255, 0.08);
    --text-primary: #FFFFFF;
    --text-secondary: #90A4AE;
    --accent-color: #4A90E2;
  }}

  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: 'Inter', system-ui, sans-serif;
    background: var(--bg-color);
    color: var(--text-primary);
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }}

  #header {{
    display: flex; align-items: center; justify-content: space-between;
    padding: 16px 28px;
    background: var(--panel-bg);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--border-color);
    flex-shrink: 0;
    z-index: 100;
  }}
  #header h1 {{ font-size: 19px; font-weight: 700; color: #fff; letter-spacing: -0.02em; }}
  #header h1 span {{ color: var(--accent-color); font-weight: 800; }}
  #stats {{ display: flex; gap: 24px; font-size: 13px; color: var(--text-secondary); }}
  #stats b {{ color: #CFD8DC; font-weight: 600; }}

  #top-controls {{
    position: absolute; top: 110px; left: 28px;
    z-index: 90; display: flex; gap: 12px;
  }}
  .glass-card {{
    background: var(--panel-bg);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  }}
  #search-container {{ padding: 8px 12px; display: flex; align-items: center; gap: 10px; min-width: 280px; }}
  #search-container input {{
    background: transparent; border: none; color: #fff; font-size: 14px; outline: none; flex: 1;
    font-family: inherit;
  }}
  #search-container input::placeholder {{ color: #546E7A; }}

  #legend {{
    display: flex; gap: 18px; align-items: center; flex-wrap: wrap;
    padding: 12px 28px;
    background: rgba(15, 17, 23, 0.4);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-bottom: 1px solid var(--border-color);
    flex-shrink: 0;
    z-index: 80;
  }}
  .leg {{ display: flex; align-items: center; gap: 8px; font-size: 11px; color: #B0BEC5; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; }}
  .dot {{ width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }}
  .sep {{ width: 1px; height: 16px; background: rgba(255,255,255,0.1); margin: 0 6px; }}

  #graph-container {{
    flex: 1; position: relative;
    background: radial-gradient(circle at center, #161A26 0%, #0B0D13 100%);
  }}
  #graph-container::before {{
    content: "";
    position: absolute; inset: 0;
    background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.03) 1px, transparent 0);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
  }}
  #graph {{ position: absolute; inset: 0; z-index: 1; }}

  #details-panel {{
    position: absolute; top: 110px; right: 28px; width: 340px; max-height: calc(100vh - 150px);
    overflow-y: auto; z-index: 95; padding: 24px;
    transform: translateX(400px); transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
  }}
  #details-panel.visible {{ transform: translateX(0); }}
  #details-panel h2 {{ font-size: 18px; margin-bottom: 8px; color: #fff; }}
  #details-panel .kind-tag {{
    display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 10px; font-weight: 800;
    text-transform: uppercase; margin-bottom: 20px;
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.15);
  }}
  #details-panel .meta-section {{ margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 16px; }}
  #details-panel .meta-label {{ font-size: 11px; color: var(--text-secondary); margin-bottom: 4px; text-transform: uppercase; }}
  #details-panel .meta-value {{ font-size: 13px; color: #CFD8DC; line-height: 1.5; font-family: 'JetBrains Mono', monospace; }}

  .vis-tooltip {{
    background: #1A1D27 !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
    color: #ECEFF1 !important;
    font-size: 12px !important;
    border-radius: 12px !important;
    padding: 12px 16px !important;
    box-shadow: 0 12px 48px rgba(0,0,0,0.7) !important;
    line-height: 1.6 !important;
    backdrop-filter: blur(8px);
  }}
  .vis-navigationButton {{ background-color: rgba(255,255,255,0.05) !important; border-radius: 8px !important; }}
</style>
</head>
<body>

<div id="header">
  <h1>Code<span>Graph</span> AI</h1>
  <div id="stats">
    <span>Nodes <b id="node-count">-</b></span>
    <span>Edges <b id="edge-count">-</b></span>
  </div>
</div>

<div id="legend">
  <div class="leg"><div class="dot" style="background:#4A90E2"></div>File</div>
  <div class="leg"><div class="dot" style="background:#F5A623"></div>Class</div>
  <div class="leg"><div class="dot" style="background:#50C878"></div>Function</div>
  <div class="leg"><div class="dot" style="background:#7ED6A8"></div>Method</div>
  <div class="leg"><div class="dot" style="background:#B0BEC5"></div>Module</div>
  <div class="sep"></div>
  <div class="leg"><div style="width:18px;height:3px;background:#4A90E2;border-radius:1px"></div>Contains</div>
  <div class="leg"><div style="width:18px;height:3px;background:#50C878;border-radius:1px"></div>Calls</div>
  <div class="leg"><div style="width:18px;height:1px;border-top:2px dashed #B0BEC5"></div>Imports</div>
</div>

<div id="top-controls">
  <div id="search-container" class="glass-card">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#90A4AE" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
    <input type="text" id="node-search" placeholder="Search code components...">
  </div>
</div>

<div id="details-panel" class="glass-card">
  <div id="details-content">
    <p style="color:#546E7A; font-style:italic">Select a node to explore details</p>
  </div>
</div>

<div id="graph-container">
  <div id="graph"></div>
</div>

<script>
const nodesRaw = {nodes_json};
nodesRaw.forEach(n => {{
  if (n.title) {{
    const d = document.createElement("div");
    d.innerHTML = n.title;
    n.title = d;
  }}
}});

const nodes = new vis.DataSet(nodesRaw);
const edges = new vis.DataSet({edges_json});

document.getElementById("node-count").textContent = nodes.length;
document.getElementById("edge-count").textContent = edges.length;

const container = document.getElementById("graph");
const data = {{ nodes, edges }};
const options = {{
  physics: {{
    enabled: true,
    solver: "forceAtlas2Based",
    forceAtlas2Based: {{
      gravitationalConstant: -80,
      centralGravity: 0.01,
      springLength: 220,
      springConstant: 0.05,
      damping: 0.4,
      avoidOverlap: 1.0
    }},
    maxVelocity: 45,
    minVelocity: 0.2,
    timestep: 0.2,
    adaptiveTimestep: true,
    stabilization: {{ iterations: 1200, updateInterval: 50, fit: true }}
  }},
  interaction: {{
    hover: true,
    tooltipDelay: 150,
    navigationButtons: true,
    keyboard: true,
    zoomView: true,
    hideEdgesOnDrag: true
  }},
  edges: {{
    smooth: {{ type: "curvedCW", roundness: 0.2 }},
    font: {{ strokeWidth: 3, strokeColor: "#0B0D13" }},
    selectionWidth: 3
  }},
  nodes: {{
    font: {{ size: 14, face: "'Inter', system-ui, sans-serif",
             strokeWidth: 4, strokeColor: "#0B0D13", color: "#ECEFF1" }}
  }}
}};

const network = new vis.Network(container, data, options);

// Performance & Stability
network.once("stabilized", () => {{
  console.log("Graph stabilized");
  network.setOptions({{ physics: {{ enabled: false }} }});
}});

// Details Panel Logic
network.on("selectNode", (params) => {{
  const nodeId = params.nodes[0];
  const nodeData = nodesRaw.find(n => n.id === nodeId);
  if (!nodeData) return;

  const panel = document.getElementById("details-panel");
  const content = document.getElementById("details-content");

  const kind = nodeData.title.querySelector('br').nextSibling.textContent.replace('Kind: ', '').trim();
  const color = nodeData.color.background;

  let html = `<h2>${{nodeData.label}}</h2>`;
  html += `<span class="kind-tag" style="background:${{color}}44; border-color:${{color}}88; color:#fff">${{kind}}</span>`;

  // Parse original tooltip for metadata
  const lines = Array.from(nodeData.title.childNodes).map(c => c.textContent || c.innerHTML);
  lines.forEach(line => {{
    if (line.includes(': ')) {{
      const [label, ...val] = line.split(': ');
      if (label === 'Kind') return;
      html += `<div class="meta-section">
                <div class="meta-label">${{label}}</div>
                <div class="meta-value">${{val.join(': ')}}</div>
              </div>`;
    }}
  }});

  content.innerHTML = html;
  panel.classList.add("visible");
}});

network.on("deselectNode", () => {{
  document.getElementById("details-panel").classList.remove("visible");
}});

// Search Box
document.getElementById("node-search").addEventListener("input", (e) => {{
  const query = e.target.value.toLowerCase();
  if (!query) return;

  const found = nodesRaw.find(n => n.label.toLowerCase().includes(query));
  if (found) {{
    network.focus(found.id, {{
      scale: 1.2,
      animation: {{ duration: 1000, easingFunction: "easeInOutQuad" }}
    }});
    network.selectNodes([found.id]);
  }}
}});

</script>
</body>
</html>"""


def _darken(hex_color: str) -> str:
    try:
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return f"#{max(0,r-35):02x}{max(0,g-35):02x}{max(0,b-35):02x}"
    except Exception:
        return hex_color


def _darken(hex_color: str) -> str:
    try:
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return f"#{max(0,r-35):02x}{max(0,g-35):02x}{max(0,b-35):02x}"
    except Exception:
        return hex_color


# ──────────────────────────────────────────────
# ask
# ──────────────────────────────────────────────

@app.command()
def ask(
    query: str = typer.Argument(..., help="Question about your codebase"),
    llm: str = typer.Option("anthropic", "--llm", help="LLM provider: anthropic | openai | google"),
    llm_model: Optional[str] = typer.Option(None, "--llm-model", help="Override the default model for the chosen LLM"),
    top_k: int = typer.Option(5, "--top-k", help="Number of graph nodes to retrieve"),
):
    """Ask a question about your codebase using graph-aware RAG."""
    root = Path(".").resolve()
    codegraph_dir = root / ".codegraph"

    # Guard: check index exists
    if not (codegraph_dir / "graph.json").exists():
        typer.echo("[error] No graph found. Run 'codegraph index' first.", err=True)
        raise typer.Exit(code=1)

    if not (codegraph_dir / "faiss.index").exists():
        typer.echo("[error] No FAISS index found. Run 'codegraph index' without --skip-embed.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Query: {query}\n")

    # Step 1 — Retrieve relevant nodes from graph
    try:
        from codegraph.ask.retriever import Retriever
        retriever = Retriever(codegraph_dir)
        context = retriever.retrieve(query, top_k=top_k)
    except ImportError:
        typer.echo("[error] Retriever not found. This feature is coming soon.")
        raise typer.Exit(code=1)

    # Step 2 — Ask the LLM
    try:
        from codegraph.ask.llm import get_llm
        model = get_llm(llm, model=llm_model)
        typer.echo(f"Asking {llm}...\n")
        answer = model.ask(context=context, question=query)
        typer.echo("─" * 50)
        typer.echo(answer)
        typer.echo("─" * 50)
    except (ImportError, EnvironmentError) as e:
        typer.echo(f"[error] {e}", err=True)
        raise typer.Exit(code=1)

# ─────────────────────────────────────────────────────────────────
# PATCH 1: Add these lines at the very top of cli.py
#          (before ALL other imports — line 1 of the file)
# ─────────────────────────────────────────────────────────────────

import warnings
warnings.filterwarnings("ignore")   # silences urllib3, google-auth, FutureWarning etc.


# ─────────────────────────────────────────────────────────────────
# PATCH 2: Add this new CLI command anywhere in cli.py
#          (e.g. after the `ask` command, before `explain`)
# ─────────────────────────────────────────────────────────────────

@app.command(name="set-key")
def set_key(
    provider: str = typer.Argument(..., help="Provider: anthropic | openai | google"),
    key: str      = typer.Argument(..., help="Your API key"),
):
    """
    Save an API key permanently so you are never prompted again.

    Examples:
        codegraph set-key google      AIza...
        codegraph set-key anthropic   sk-ant-...
        codegraph set-key openai      sk-...
    """
    from codegraph.ask.llm import PROVIDER_KEY_MAP, set_api_key, _KEY_STORE

    if provider not in PROVIDER_KEY_MAP:
        available = ", ".join(PROVIDER_KEY_MAP.keys())
        typer.echo(f"[error] Unknown provider '{provider}'. Choose from: {available}", err=True)
        raise typer.Exit(code=1)

    env_var = PROVIDER_KEY_MAP[provider]
    set_api_key(env_var, key)
    typer.echo(f"  ✔  {env_var} saved to {_KEY_STORE}")
    typer.echo(f"  You won't be prompted for this key again.")

# ──────────────────────────────────────────────
# explain
# ──────────────────────────────────────────────

@app.command()
def explain(
    file: str = typer.Argument(..., help="File to explain"),
    llm: str = typer.Option("anthropic", "--llm", help="LLM provider: anthropic | openai | google"),
):
    """Get an AI-generated explanation of a file (coming soon)."""
    typer.echo(f"explain: coming soon — file was: {file}")


# ──────────────────────────────────────────────
# audit
# ──────────────────────────────────────────────

@app.command()
def audit():
    """Audit the codebase for missing docs, unused code, hidden deps (coming soon)."""
    typer.echo("audit: coming soon")


if __name__ == "__main__":
    app()