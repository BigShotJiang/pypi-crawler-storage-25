"""
Graph Builder for CodeGraph AI

Node types:
  - file       : a .py file
  - function   : top-level function
  - class      : a class
  - method     : a method belonging to a class
  - module     : an imported module/package

Edge types:
  - contains   : file → function, file → class, class → method
  - calls      : function/method → function/method
  - imports    : file → module
  - defined_in : function/method → file
"""

import builtins
import networkx as nx
from pathlib import Path
from codegraph.parsers.python_parser import ParsedFile
from codegraph.parsers.multimodal_parser import ParsedAsset


BUILTIN_FUNCTIONS = set(dir(builtins))


class GraphBuilder:
    def __init__(self):
        self.graph = nx.DiGraph()
        self._function_to_file: dict[str, str] = {}
        self._assets: list[ParsedAsset] = []
        self._parsed_files: list[ParsedFile] = []

    def add_file(self, parsed: ParsedFile) -> None:
        self._parsed_files.append(parsed)
        file_id  = self._file_node_id(parsed.filepath)
        filename = Path(parsed.filepath).name

        self._add_node(file_id, kind="file", label=filename, external=False)

        # ── classes ──────────────────────────────────────────────
        for cls in parsed.classes:
            # cls is now a ClassInfo dataclass
            cls_name = cls.name if hasattr(cls, "name") else cls
            cls_id   = f"class:{file_id}:{cls_name}"
            node_attrs = dict(
                kind     = "class",
                label    = cls_name,
                external = False,
                file     = file_id,
            )
            if hasattr(cls, "docstring") and cls.docstring:
                node_attrs["docstring"] = cls.docstring
            if hasattr(cls, "bases") and cls.bases:
                node_attrs["bases"] = ", ".join(cls.bases)
            if hasattr(cls, "lineno"):
                node_attrs["lineno"] = cls.lineno

            self._add_node(cls_id, **node_attrs)
            self._add_edge(file_id, cls_id, relation="contains")

        # ── functions ─────────────────────────────────────────────
        for func in parsed.functions:
            # func is now a FunctionInfo dataclass
            func_name = func.name if hasattr(func, "name") else func
            func_id   = f"func:{file_id}:{func_name}"
            node_attrs = dict(
                kind     = "function",
                label    = func_name,
                external = False,
                file     = file_id,
            )
            if hasattr(func, "signature") and func.signature:
                node_attrs["signature"] = func.signature
            if hasattr(func, "docstring") and func.docstring:
                node_attrs["docstring"] = func.docstring
            if hasattr(func, "return_type") and func.return_type:
                node_attrs["return_type"] = func.return_type
            if hasattr(func, "lineno"):
                node_attrs["lineno"] = func.lineno
            if hasattr(func, "is_async") and func.is_async:
                node_attrs["is_async"] = True

            self._add_node(func_id, **node_attrs)
            self._add_edge(file_id, func_id, relation="contains")
            self._add_edge(func_id, file_id, relation="defined_in")
            self._function_to_file[func_name] = file_id

        # ── methods ───────────────────────────────────────────────
        for method in parsed.methods:
            # method is now a MethodInfo dataclass
            if hasattr(method, "name"):
                cls_name, method_name = method.class_name, method.name
            else:
                cls_name, method_name = method  # backwards compat tuple

            cls_id    = f"class:{file_id}:{cls_name}"
            method_id = f"func:{file_id}:{method_name}"
            node_attrs = dict(
                kind     = "method",
                label    = method_name,
                external = False,
                file     = file_id,
                cls      = cls_name,
            )
            if hasattr(method, "signature") and method.signature:
                node_attrs["signature"] = method.signature
            if hasattr(method, "docstring") and method.docstring:
                node_attrs["docstring"] = method.docstring
            if hasattr(method, "return_type") and method.return_type:
                node_attrs["return_type"] = method.return_type
            if hasattr(method, "lineno"):
                node_attrs["lineno"] = method.lineno
            if hasattr(method, "is_async") and method.is_async:
                node_attrs["is_async"] = True

            self._add_node(method_id, **node_attrs)
            self._add_edge(cls_id, method_id, relation="contains")
            self._add_edge(method_id, file_id, relation="defined_in")
            self._function_to_file[method_name] = file_id

        # ── imports ───────────────────────────────────────────────
        for imp in parsed.imports:
            mod_id = f"module:{imp}"
            self._add_node(mod_id, kind="module", label=imp, external=True)
            self._add_edge(file_id, mod_id, relation="imports")

        # ── calls ─────────────────────────────────────────────────
        for caller, callee in parsed.calls:
            # callee may be "retrieve", "retriever.retrieve", "Retriever", etc.
            short_name = callee.split(".")[-1]   # last segment for graph lookup

            if short_name in BUILTIN_FUNCTIONS:
                continue

            caller_id      = f"func:{file_id}:{caller}"
            target_file_id = self._function_to_file.get(short_name)

            if target_file_id:
                callee_id = f"func:{target_file_id}:{short_name}"
            else:
                # Use full qualified name as label so "retriever.retrieve" is readable
                callee_id = f"func:external:{callee}"
                if not self.graph.has_node(callee_id):
                    self._add_node(callee_id, kind="function", label=callee, external=True)

            self._add_edge(caller_id, callee_id, relation="calls")

    def add_asset(self, asset: ParsedAsset) -> None:
        self._assets.append(asset)
        filename = Path(asset.filepath).name
        node_id  = f"{asset.kind}:{filename}"
        self._add_node(
            node_id,
            kind     = asset.kind,
            label    = filename,
            filename = filename,
            external = False,
            metadata = asset.metadata,
        )

    def link_code_to_assets(self) -> None:
        """Connect code nodes to assets based on name/call/string matches."""
        for node_id, data in list(self.graph.nodes(data=True)):
            if data.get("kind") not in ("function", "method"):
                continue

            func_name = data.get("label")
            file_id   = data.get("file")
            parsed    = next(
                (p for p in self._parsed_files if self._file_node_id(p.filepath) == file_id),
                None,
            )
            if not parsed:
                continue

            for asset in self._assets:
                asset_filename = Path(asset.filepath).name
                asset_id       = f"{asset.kind}:{asset_filename}"
                relation       = "uses" if asset.kind in ("dataset", "database") else "references"

                if asset_filename in func_name:
                    self._add_edge(node_id, asset_id, relation=relation)
                    continue

                calls = [c[1] for c in parsed.calls if c[0] == func_name]
                if any(asset_filename in callee for callee in calls):
                    self._add_edge(node_id, asset_id, relation=relation)
                    continue

                strings = parsed.strings.get(func_name, [])
                if any(asset_filename in s for s in strings):
                    self._add_edge(node_id, asset_id, relation=relation)

    def build(self, parsed_files: list[ParsedFile], assets: list[ParsedAsset] = None) -> nx.DiGraph:
        for parsed in parsed_files:
            if not parsed.errors:
                self.add_file(parsed)
        if assets:
            for asset in assets:
                self.add_asset(asset)
        self.link_code_to_assets()
        return self.graph

    def summary(self) -> dict:
        nodes_by_kind: dict[str, int] = {}
        for _, data in self.graph.nodes(data=True):
            kind = data.get("kind", "unknown")
            nodes_by_kind[kind] = nodes_by_kind.get(kind, 0) + 1

        edges_by_relation: dict[str, int] = {}
        for _, _, data in self.graph.edges(data=True):
            rel = data.get("relation", "unknown")
            edges_by_relation[rel] = edges_by_relation.get(rel, 0) + 1

        return {
            "total_nodes":      self.graph.number_of_nodes(),
            "total_edges":      self.graph.number_of_edges(),
            "nodes_by_kind":    nodes_by_kind,
            "edges_by_relation": edges_by_relation,
        }

    def to_dict(self) -> dict:
        return {
            "nodes": [{"id": node, **data} for node, data in self.graph.nodes(data=True)],
            "edges": [{"source": src, "target": dst, **data} for src, dst, data in self.graph.edges(data=True)],
        }

    def _file_node_id(self, filepath: str) -> str:
        return f"file:{Path(filepath).name}"

    def _add_node(self, node_id: str, **attrs) -> None:
        if not self.graph.has_node(node_id):
            self.graph.add_node(node_id, **attrs)

    def _add_edge(self, src: str, dst: str, **attrs) -> None:
        self.graph.add_edge(src, dst, **attrs)