"""
Graph-aware retriever for CodeGraph AI.

Flow:
  1. Embed the user's query (same embedder used at index time).
  2. Search FAISS for the top-k most similar nodes.
  3. Expand each hit by walking 1-hop neighbours in the graph
     (callers, callees, containing file/class, imports).
  4. Deduplicate and rank the expanded node set.
  5. Serialise everything into a structured context string
     that the LLM prompts can consume.

Usage:
    retriever = Retriever(Path(".codegraph"))
    context   = retriever.retrieve("Where is authentication handled?", top_k=5)
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Any

import numpy as np


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _load_faiss(index_path: Path):
    """Import faiss lazily so the module is importable without it."""
    try:
        import faiss  # type: ignore
    except ImportError:
        raise ImportError(
            "faiss-cpu is not installed.\n"
            "Run: pip install faiss-cpu"
        )
    return faiss.read_index(str(index_path))


def _cosine_scores(query_vec: np.ndarray, vecs: np.ndarray) -> np.ndarray:
    """Fallback cosine similarity when FAISS is unavailable."""
    q = query_vec / (np.linalg.norm(query_vec) + 1e-9)
    norms = np.linalg.norm(vecs, axis=1, keepdims=True) + 1e-9
    return (vecs / norms) @ q


# ──────────────────────────────────────────────────────────────────────────────
# Node serialiser
# ──────────────────────────────────────────────────────────────────────────────

_SKIP_ATTRS = {"id", "label"}

def _fmt_node(node_id: str, attrs: dict[str, Any]) -> str:
    """
    Render a single graph node as a compact text block, e.g.

        [function] login
          file   : auth.py
          class  : AuthManager
          lineno : 42
    """
    kind  = attrs.get("kind", "node")
    label = attrs.get("label", node_id)
    lines = [f"[{kind}] {label}"]

    ordered_keys = ["file", "filename", "cls", "module", "lineno", "docstring", "signature"]
    shown: set[str] = set()

    for key in ordered_keys:
        val = attrs.get(key)
        if val is not None:
            # Strip the "file:" prefix stored by the builder
            if key == "file":
                val = str(val).removeprefix("file:")
            lines.append(f"  {key:<10}: {val}")
            shown.add(key)

    # Any remaining non-trivial attrs (skip internals, skip already shown)
    for key, val in attrs.items():
        if key in _SKIP_ATTRS or key in shown or key == "kind":
            continue
        if isinstance(val, (dict, list)) or val is None or val == "":
            continue
        if key == "external" and not val:
            continue
        lines.append(f"  {key:<10}: {val}")

    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────────
# Retriever
# ──────────────────────────────────────────────────────────────────────────────

# Relation types we follow during graph expansion, and the hop budget per type.
_EXPAND_RELATIONS: dict[str, int] = {
    "calls":      1,   # direct callees
    "called_by":  1,   # direct callers  (reversed edges)
    "contains":   1,   # parent file / class
    "defined_in": 1,   # function → file
    "imports":    1,   # what a file imports
    "uses":       1,   # asset usage
}

# How many expanded neighbours to keep after scoring
_MAX_EXPANDED = 20


class Retriever:
    """
    Retrieve graph context relevant to a natural-language query.

    Args:
        codegraph_dir: path to the `.codegraph` directory produced by
                       `codegraph index`.  Must contain:
                         - graph.json
                         - faiss.index
                         - node_ids.pkl   (list[str] — ordered FAISS row → node id)
                         - embedder.pkl   (the serialised EmbedderBase instance, optional)
    """

    def __init__(self, codegraph_dir: Path | str):
        self._dir = Path(codegraph_dir)
        self._graph:    dict[str, Any]    = {}   # {node_id: attrs}
        self._adj_out:  dict[str, list]   = {}   # node → [(neighbour, relation)]
        self._adj_in:   dict[str, list]   = {}   # node → [(neighbour, relation)]  (reversed)
        self._node_ids: list[str]         = []
        self._faiss_index                 = None
        self._embedder                    = None
        self._np_vecs: np.ndarray | None  = None  # fallback dense matrix

        self._load()

    # ── loading ──────────────────────────────────────────────────────────────

    def _load(self) -> None:
        graph_file   = self._dir / "graph.json"
        faiss_file   = self._dir / "faiss.index"
        node_ids_file = self._dir / "node_ids.pkl"
        embedder_file = self._dir / "embedder.pkl"
        vecs_file     = self._dir / "vectors.npy"   # optional dense dump

        if not graph_file.exists():
            raise FileNotFoundError(
                f"graph.json not found in {self._dir}. "
                "Run 'codegraph index' first."
            )

        # ── graph ────────────────────────────────────────────────────────────
        with graph_file.open("r", encoding="utf-8") as f:
            raw = json.load(f)

        for node in raw.get("nodes", []):
            nid = node["id"]
            self._graph[nid] = {k: v for k, v in node.items() if k != "id"}
            self._adj_out[nid] = []
            self._adj_in[nid]  = []

        for edge in raw.get("edges", []):
            src = edge["source"]
            dst = edge["target"]
            rel = edge.get("relation", "")
            if src in self._adj_out:
                self._adj_out[src].append((dst, rel))
            if dst in self._adj_in:
                self._adj_in[dst].append((src, rel))

        # ── FAISS + node ids ─────────────────────────────────────────────────
        if not faiss_file.exists():
            raise FileNotFoundError(
                f"faiss.index not found in {self._dir}. "
                "Run 'codegraph index' without --skip-embed."
            )
        if not node_ids_file.exists():
            raise FileNotFoundError(
                f"node_ids.pkl not found in {self._dir}. "
                "Re-run 'codegraph index' to regenerate embeddings."
            )

        self._faiss_index = _load_faiss(faiss_file)

        with node_ids_file.open("rb") as f:
            self._node_ids = pickle.load(f)

        # ── optional dense vectors (for diversity re-ranking) ─────────────────
        if vecs_file.exists():
            self._np_vecs = np.load(str(vecs_file))

        # ── embedder ─────────────────────────────────────────────────────────
        if embedder_file.exists():
            with embedder_file.open("rb") as f:
                self._embedder = pickle.load(f)

    # ── public API ───────────────────────────────────────────────────────────

    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        expand_hops: bool = True,
        max_context_nodes: int = 20,
    ) -> str:
        """
        Retrieve a context string for *query*.

        Args:
            query:             natural-language question
            top_k:             number of FAISS seed hits
            expand_hops:       whether to walk 1-hop neighbours
            max_context_nodes: hard cap on total nodes in context

        Returns:
            A multi-section plain-text string ready to paste into an LLM prompt.
        """
        # 1 — embed query
        query_vec = self._embed_query(query)

        # 2 — FAISS search
        seed_ids, seed_scores = self._faiss_search(query_vec, top_k)

        # 3 — graph expansion
        if expand_hops:
            expanded = self._expand(seed_ids, seed_scores)
        else:
            expanded = {nid: score for nid, score in zip(seed_ids, seed_scores)}

        # 4 — rank & trim
        ranked = sorted(expanded.items(), key=lambda x: x[1], reverse=True)
        ranked = ranked[:max_context_nodes]

        # 5 — build context string
        return self._build_context(query, seed_ids, ranked)

    # ── internals ────────────────────────────────────────────────────────────

    def _embed_query(self, query: str) -> np.ndarray:
        """Return a float32 unit-normalised 1-D array for *query*."""
        if self._embedder is None:
            raise RuntimeError(
                "No embedder found in .codegraph/embedder.pkl.\n"
                "Re-run 'codegraph index' to regenerate embeddings, "
                "or ensure NodeEmbedder saves the embedder object."
            )
        vecs = self._embedder.embed([query])          # shape (1, dim)
        vec  = vecs[0].astype(np.float32)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec

    def _faiss_search(
        self, query_vec: np.ndarray, top_k: int
    ) -> tuple[list[str], list[float]]:
        """
        Run an inner-product search against the FAISS index.
        Returns (node_id_list, score_list) sorted best-first.
        """
        k = min(top_k, len(self._node_ids))
        distances, indices = self._faiss_index.search(
            query_vec.reshape(1, -1), k
        )
        ids: list[str]    = []
        scores: list[float] = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(self._node_ids):
                continue
            ids.append(self._node_ids[idx])
            scores.append(float(dist))
        return ids, scores

    def _expand(
        self,
        seed_ids: list[str],
        seed_scores: list[float],
    ) -> dict[str, float]:
        """
        Expand the seed set by 1-hop traversal in the graph.

        Neighbours receive a discounted score:
            neighbour_score = parent_score * decay

        The decay is relation-specific so that structurally important
        links (contains, defined_in) are weighted differently from
        semantic ones (calls, imports).
        """
        DECAY: dict[str, float] = {
            "contains":   0.80,
            "defined_in": 0.80,
            "calls":      0.70,
            "called_by":  0.65,
            "imports":    0.55,
            "uses":       0.60,
            "references": 0.55,
        }
        DEFAULT_DECAY = 0.50

        scores: dict[str, float] = {}

        # Seed nodes
        for nid, sc in zip(seed_ids, seed_scores):
            if nid in self._graph:
                scores[nid] = max(scores.get(nid, 0.0), sc)

        # Expand
        for nid, parent_score in list(scores.items()):
            # outgoing edges
            for neighbour, rel in self._adj_out.get(nid, []):
                if neighbour not in self._graph:
                    continue
                decay = DECAY.get(rel, DEFAULT_DECAY)
                candidate = parent_score * decay
                scores[neighbour] = max(scores.get(neighbour, 0.0), candidate)

            # incoming edges (reversed — gives us callers and containers)
            for neighbour, rel in self._adj_in.get(nid, []):
                if neighbour not in self._graph:
                    continue
                decay = DECAY.get(rel, DEFAULT_DECAY) * 0.9   # slight penalty for reversed
                candidate = parent_score * decay
                scores[neighbour] = max(scores.get(neighbour, 0.0), candidate)

        return scores

    def _build_context(
        self,
        query: str,
        seed_ids: list[str],
        ranked: list[tuple[str, float]],
    ) -> str:
        """
        Assemble the context string.

        Structure
        ---------
        QUERY
        ═════
        <query text>

        SEED MATCHES  (direct FAISS hits)
        ════════════
        1. [function] login  (score: 0.92)
           file: auth.py
           ...

        RELATED NODES  (graph neighbours)
        ═════════════
        ...

        CALL GRAPH SUMMARY
        ══════════════════
        login  →  hash_password, check_token
        ...
        """
        seed_set = set(seed_ids)
        lines: list[str] = []

        # ── header ───────────────────────────────────────────────────────────
        lines += [
            "QUERY",
            "═" * 60,
            query,
            "",
        ]

        # ── seeds ────────────────────────────────────────────────────────────
        seed_ranked  = [(nid, sc) for nid, sc in ranked if nid in seed_set]
        expand_ranked = [(nid, sc) for nid, sc in ranked if nid not in seed_set]

        if seed_ranked:
            lines += ["SEED MATCHES  (top FAISS hits)", "═" * 60]
            for i, (nid, score) in enumerate(seed_ranked, 1):
                attrs = self._graph.get(nid, {})
                lines.append(f"{i}. {_fmt_node(nid, attrs)}  [score: {score:.4f}]")
                lines.append("")

        # ── expanded neighbours ───────────────────────────────────────────────
        if expand_ranked:
            lines += ["RELATED NODES  (graph neighbours)", "═" * 60]
            for i, (nid, score) in enumerate(expand_ranked, 1):
                attrs = self._graph.get(nid, {})
                lines.append(f"{i}. {_fmt_node(nid, attrs)}  [score: {score:.4f}]")
                lines.append("")

        # ── call-graph mini-summary ───────────────────────────────────────────
        call_lines = self._call_summary({nid for nid, _ in ranked})
        if call_lines:
            lines += ["CALL GRAPH SUMMARY", "═" * 60]
            lines += call_lines
            lines.append("")

        # ── import summary ────────────────────────────────────────────────────
        import_lines = self._import_summary({nid for nid, _ in ranked})
        if import_lines:
            lines += ["IMPORT SUMMARY", "═" * 60]
            lines += import_lines
            lines.append("")

        return "\n".join(lines)

    def _call_summary(self, node_set: set[str]) -> list[str]:
        """
        For every function/method in *node_set*, emit one line:
            <name>  →  <callee1>, <callee2>, ...
        Only callees that also appear in node_set are listed, keeping
        the summary tight.  Callers are noted if present.
        """
        lines: list[str] = []
        callable_kinds = {"function", "method"}

        for nid in node_set:
            attrs = self._graph.get(nid, {})
            if attrs.get("kind") not in callable_kinds:
                continue

            label = attrs.get("label", nid)

            callees = [
                self._graph.get(nb, {}).get("label", nb)
                for nb, rel in self._adj_out.get(nid, [])
                if rel == "calls" and nb in self._graph
            ]
            callers = [
                self._graph.get(nb, {}).get("label", nb)
                for nb, rel in self._adj_in.get(nid, [])
                if rel == "calls" and nb in self._graph
            ]

            parts: list[str] = []
            if callees:
                parts.append(f"calls → {', '.join(callees[:8])}")
            if callers:
                parts.append(f"called by ← {', '.join(callers[:4])}")
            if parts:
                lines.append(f"  {label}:  {';  '.join(parts)}")

        return lines

    def _import_summary(self, node_set: set[str]) -> list[str]:
        """
        List which files/modules in node_set import what.
        """
        lines: list[str] = []
        for nid in node_set:
            attrs = self._graph.get(nid, {})
            if attrs.get("kind") not in ("file", "module"):
                continue

            label = attrs.get("label", nid)
            imports = [
                self._graph.get(nb, {}).get("label", nb)
                for nb, rel in self._adj_out.get(nid, [])
                if rel == "imports" and nb in self._graph
            ]
            if imports:
                lines.append(f"  {label}  imports:  {', '.join(imports[:10])}")

        return lines