"""
LLM abstraction for CodeGraph AI.

Providers supported:
  - anthropic   (requires ANTHROPIC_API_KEY)  → Claude
  - openai      (requires OPENAI_API_KEY)     → GPT-4o
  - google      (requires GOOGLE_API_KEY)     → Gemini

API keys are stored in ~/.codegraph_keys (plain text, owner-readable only).
They load automatically on every run — you will never be prompted twice.

Usage:
    llm = get_llm("anthropic")
    answer = llm.ask(context="...", question="Where is auth handled?")
"""

from __future__ import annotations
import os
import getpass
from abc import ABC, abstractmethod
from pathlib import Path


# ──────────────────────────────────────────────
# Key store  (~/.codegraph_keys)
# ──────────────────────────────────────────────

_KEY_STORE = Path.home() / ".codegraph_keys"


def _load_key_store() -> dict[str, str]:
    """Read ~/.codegraph_keys → dict.  Format: KEY=value lines."""
    if not _KEY_STORE.exists():
        return {}
    store: dict[str, str] = {}
    for line in _KEY_STORE.read_text().splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, _, v = line.partition("=")
            store[k.strip()] = v.strip()
    return store


def _save_key_store(store: dict[str, str]) -> None:
    lines = [f"{k}={v}" for k, v in store.items()]
    _KEY_STORE.write_text("\n".join(lines) + "\n")
    _KEY_STORE.chmod(0o600)  # owner read/write only


def _load_keys_into_env() -> None:
    """Inject stored keys into os.environ (called automatically on first use)."""
    for k, v in _load_key_store().items():
        os.environ.setdefault(k, v)


def set_api_key(env_var: str, key: str) -> None:
    """
    Persist an API key to ~/.codegraph_keys and set it in the current session.
    Called by the `codegraph set-key` CLI command.
    """
    store = _load_key_store()
    store[env_var] = key
    _save_key_store(store)
    os.environ[env_var] = key


def _resolve_api_key(env_var: str, provider: str) -> str:
    """
    Return the API key for *env_var*.
    Order: os.environ → ~/.codegraph_keys → one-time prompt (then saved).
    """
    _load_keys_into_env()

    key = os.environ.get(env_var, "").strip()
    if key:
        return key

    # One-time interactive prompt
    print(f"\n  No API key found for {provider}.")
    print(f"  Tip: run  codegraph set-key {env_var} <your_key>  to save permanently.\n")
    key = getpass.getpass(f"  {provider} API key: ").strip()

    if not key:
        raise EnvironmentError(
            f"{env_var} is required for the {provider} LLM.\n"
            f"Run: codegraph set-key {env_var} your_key"
        )

    set_api_key(env_var, key)
    print(f"  Key saved — you won't be asked again.\n")
    return key


# ──────────────────────────────────────────────
# Base class
# ──────────────────────────────────────────────

SYSTEM_PROMPT = """You are CodeGraph AI, an expert code assistant.
You are given a structured context extracted from a knowledge graph of a codebase.
The context includes files, classes, functions, methods, imports, and call relationships.

Rules:
- Answer ONLY using the provided graph context.
- Be specific: mention exact function names, file names, and class names.
- If the context does not contain enough information, say so clearly.
- Do not hallucinate code that is not in the context.
- Keep answers concise and developer-focused.
"""


class LLMBase(ABC):
    @abstractmethod
    def ask(self, context: str, question: str) -> str: ...

    def _build_user_message(self, context: str, question: str) -> str:
        return (
            f"Graph context:\n"
            f"──────────────\n"
            f"{context}\n"
            f"──────────────\n\n"
            f"Question: {question}"
        )


# ──────────────────────────────────────────────
# Provider: Anthropic (Claude)
# ──────────────────────────────────────────────

class AnthropicLLM(LLMBase):
    DEFAULT_MODEL = "claude-3-5-haiku-20241022"

    def __init__(self, model: str = DEFAULT_MODEL):
        try:
            import anthropic
        except ImportError:
            raise ImportError("Run: pip install anthropic")
        api_key = _resolve_api_key("ANTHROPIC_API_KEY", "Anthropic")
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model

    def ask(self, context: str, question: str) -> str:
        msg = self._client.messages.create(
            model=self._model,
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": self._build_user_message(context, question)}],
        )
        return msg.content[0].text


# ──────────────────────────────────────────────
# Provider: OpenAI (GPT)
# ──────────────────────────────────────────────

class OpenAILLM(LLMBase):
    DEFAULT_MODEL = "gpt-4o-mini"

    def __init__(self, model: str = DEFAULT_MODEL):
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("Run: pip install openai")
        api_key = _resolve_api_key("OPENAI_API_KEY", "OpenAI")
        self._client = OpenAI(api_key=api_key)
        self._model = model

    def ask(self, context: str, question: str) -> str:
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": self._build_user_message(context, question)},
            ],
            max_tokens=1024,
        )
        return resp.choices[0].message.content


# ──────────────────────────────────────────────
# Provider: Google (Gemini)
# ──────────────────────────────────────────────

class GoogleLLM(LLMBase):
    DEFAULT_MODEL = "gemini-3-flash-preview"

    def __init__(self, model: str = DEFAULT_MODEL):
        try:
            from google import genai
        except ImportError:
            raise ImportError("Run: pip install google-genai")
        api_key = _resolve_api_key("GOOGLE_API_KEY", "Google")
        self._client = genai.Client(api_key=api_key)
        self._model = model

    def ask(self, context: str, question: str) -> str:
        from google.genai import types
        resp = self._client.models.generate_content(
            model=self._model,
            contents=self._build_user_message(context, question),
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                max_output_tokens=1024,
            ),
        )
        # Filter to text-only parts — suppresses the thought_signature warning
        # Gemini 2.0 Flash emits when thinking blocks are present in the response.
        text_parts = [
            part.text
            for candidate in resp.candidates
            for part in candidate.content.parts
            if hasattr(part, "text") and part.text
        ]
        return "\n".join(text_parts) if text_parts else (resp.text or "")


# ──────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────

PROVIDERS: dict[str, type[LLMBase]] = {
    "anthropic": AnthropicLLM,
    "openai":    OpenAILLM,
    "google":    GoogleLLM,
}

PROVIDER_KEY_MAP: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai":    "OPENAI_API_KEY",
    "google":    "GOOGLE_API_KEY",
}


def get_llm(provider: str, model: str | None = None) -> LLMBase:
    if provider not in PROVIDERS:
        raise ValueError(f"Unknown LLM provider '{provider}'. Available: {', '.join(PROVIDERS)}")
    cls = PROVIDERS[provider]
    return cls(model=model) if model else cls()