"""
Python AST Parser for CodeGraph AI
Extracts functions, classes, imports, and call graphs from Python files.
"""
from __future__ import annotations

import ast
from typing import Optional
from pathlib import Path
from dataclasses import dataclass, field


# ──────────────────────────────────────────────
# Richer per-node metadata
# ──────────────────────────────────────────────

@dataclass
class FunctionInfo:
    name:        str
    signature:   str              # e.g. "(root, path) -> tuple[list[Path], list[Path]]"
    docstring:   str              # first paragraph of docstring, or ""
    return_type: str              # extracted from annotation, or ""
    lineno:      int              # line number in source file
    is_async:    bool = False


@dataclass
class ClassInfo:
    name:      str
    docstring: str
    bases:     list[str]          # parent class names
    lineno:    int


@dataclass
class MethodInfo:
    class_name:  str
    name:        str
    signature:   str
    docstring:   str
    return_type: str
    lineno:      int
    is_async:    bool = False


@dataclass
class ParsedFile:
    filepath:  str
    functions: list[FunctionInfo] = field(default_factory=list)
    classes:   list[ClassInfo]    = field(default_factory=list)
    methods:   list[MethodInfo]   = field(default_factory=list)
    imports:   list[str]          = field(default_factory=list)
    calls:     list[tuple[str, str]] = field(default_factory=list)  # (caller, callee)
    strings:   dict[str, list[str]]  = field(default_factory=dict)
    errors:    list[str]          = field(default_factory=list)

    # ── backwards-compat properties ───────────────────────────────
    # GraphBuilder accesses .functions as list[str] and
    # .methods as list[tuple[str,str]] — keep those views working.

    @property
    def function_names(self) -> list[str]:
        return [f.name for f in self.functions]

    @property
    def class_names(self) -> list[str]:
        return [c.name for c in self.classes]

    @property
    def method_tuples(self) -> list[tuple[str, str]]:
        return [(m.class_name, m.name) for m in self.methods]


class PythonParser:
    """
    Parses a Python file using the built-in ast module.
    Extracts structural information + rich metadata for graph construction.
    """

    def parse_file(self, filepath: str) -> ParsedFile:
        result = ParsedFile(filepath=filepath)
        source = self._read_file(filepath, result)
        if source is None:
            return result

        tree = self._parse_source(source, filepath, result)
        if tree is None:
            return result

        self._extract_imports(tree, result)
        self._extract_classes(tree, result)
        self._extract_functions_and_calls(tree, result)

        return result

    # ── file / parse helpers ─────────────────────────────────────

    def _read_file(self, filepath: str, result: ParsedFile) -> Optional[str]:
        try:
            return Path(filepath).read_text(encoding="utf-8")
        except FileNotFoundError:
            result.errors.append(f"File not found: {filepath}")
            return None
        except Exception as e:
            result.errors.append(f"Could not read file: {e}")
            return None

    def _parse_source(self, source: str, filepath: str, result: ParsedFile) -> Optional[ast.AST]:
        try:
            return ast.parse(source, filename=filepath)
        except SyntaxError as e:
            result.errors.append(f"Syntax error: {e}")
            return None

    # ── imports ──────────────────────────────────────────────────

    def _extract_imports(self, tree: ast.AST, result: ParsedFile) -> None:
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    result.imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    result.imports.append(f"{module}.{alias.name}")

    # ── classes ──────────────────────────────────────────────────

    def _extract_classes(self, tree: ast.AST, result: ParsedFile) -> None:
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                bases = [self._name_from_expr(b) for b in node.bases if self._name_from_expr(b)]
                result.classes.append(ClassInfo(
                    name      = node.name,
                    docstring = self._get_docstring(node),
                    bases     = bases,
                    lineno    = node.lineno,
                ))

    # ── functions & calls ────────────────────────────────────────

    def _extract_functions_and_calls(self, tree: ast.AST, result: ParsedFile) -> None:
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                info = self._build_function_info(node)
                result.functions.append(info)
                self._extract_calls_in_func(node, node.name, result)
                self._extract_strings_in_func(node, node.name, result)

            elif isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        info = self._build_method_info(item, node.name)
                        result.methods.append(info)
                        self._extract_calls_in_func(item, item.name, result)
                        self._extract_strings_in_func(item, item.name, result)

    def _build_function_info(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> FunctionInfo:
        return FunctionInfo(
            name        = node.name,
            signature   = self._build_signature(node),
            docstring   = self._get_docstring(node),
            return_type = self._get_return_type(node),
            lineno      = node.lineno,
            is_async    = isinstance(node, ast.AsyncFunctionDef),
        )

    def _build_method_info(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        class_name: str,
    ) -> MethodInfo:
        return MethodInfo(
            class_name  = class_name,
            name        = node.name,
            signature   = self._build_signature(node),
            docstring   = self._get_docstring(node),
            return_type = self._get_return_type(node),
            lineno      = node.lineno,
            is_async    = isinstance(node, ast.AsyncFunctionDef),
        )

    # ── calls & strings ──────────────────────────────────────────

    # Noisy builtins/framework names to drop from call lists
    _SKIP_CALLS = {
        "append", "extend", "update", "get", "set", "items", "values", "keys",
        "open", "read", "write", "close", "strip", "split", "join", "replace",
        "lower", "upper", "format", "encode", "decode", "print",
        "isinstance", "hasattr", "getattr", "setattr", "len", "range",
        "str", "int", "float", "bool", "list", "dict", "tuple", "set",
        # typer boilerplate
        "command", "Argument", "Option", "echo", "Exit", "Typer",
        # pathlib noise
        "exists", "is_file", "is_dir", "mkdir", "open", "resolve",
        "rglob", "iterdir", "relative_to", "read_text", "write_text",
    }

    def _extract_calls_in_func(self, func_node: ast.AST, func_name: str, result: ParsedFile) -> None:
        for child in ast.walk(func_node):
            if isinstance(child, ast.Call):
                callee, full_callee = self._resolve_call_name(child)
                if not callee or callee in self._SKIP_CALLS:
                    continue
                # Store full qualified name (e.g. "retriever.retrieve") as the callee
                result.calls.append((func_name, full_callee or callee))

    def _extract_strings_in_func(self, func_node: ast.AST, func_name: str, result: ParsedFile) -> None:
        if func_name not in result.strings:
            result.strings[func_name] = []
        for child in ast.walk(func_node):
            if isinstance(child, ast.Constant) and isinstance(child.value, str):
                result.strings[func_name].append(child.value)

    # ── AST annotation helpers ───────────────────────────────────

    def _build_signature(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
        """
        Build a readable signature string, e.g.
            (root: Path, path: str) -> tuple[list[Path], list[Path]]
        """
        args = node.args
        parts: list[str] = []

        # positional-only  (Python 3.8+)
        for i, arg in enumerate(args.posonlyargs):
            parts.append(self._fmt_arg(arg))
            if i == len(args.posonlyargs) - 1:
                parts.append("/")

        # regular args
        num_defaults = len(args.defaults)
        num_args     = len(args.args)
        for i, arg in enumerate(args.args):
            default_offset = i - (num_args - num_defaults)
            if default_offset >= 0:
                default = self._expr_to_str(args.defaults[default_offset])
                parts.append(f"{self._fmt_arg(arg)}={default}")
            else:
                parts.append(self._fmt_arg(arg))

        # *args
        if args.vararg:
            parts.append(f"*{self._fmt_arg(args.vararg)}")
        elif args.kwonlyargs:
            parts.append("*")

        # keyword-only args
        for i, arg in enumerate(args.kwonlyargs):
            kw_default = args.kw_defaults[i]
            if kw_default is not None:
                parts.append(f"{self._fmt_arg(arg)}={self._expr_to_str(kw_default)}")
            else:
                parts.append(self._fmt_arg(arg))

        # **kwargs
        if args.kwarg:
            parts.append(f"**{self._fmt_arg(args.kwarg)}")

        ret = self._get_return_type(node)
        sig = f"({', '.join(parts)})"
        if ret:
            sig += f" -> {ret}"
        return sig

    def _fmt_arg(self, arg: ast.arg) -> str:
        if arg.annotation:
            return f"{arg.arg}: {self._expr_to_str(arg.annotation)}"
        return arg.arg

    def _get_return_type(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
        if node.returns:
            return self._expr_to_str(node.returns)
        return ""

    def _get_docstring(self, node: ast.AST) -> str:
        """Return the first non-empty paragraph of the docstring, capped at 300 chars."""
        try:
            raw = ast.get_docstring(node) or ""
        except TypeError:
            return ""
        if not raw:
            return ""
        # First paragraph only (split on blank line)
        first_para = raw.split("\n\n")[0].replace("\n", " ").strip()
        return first_para[:300]

    def _expr_to_str(self, node: ast.expr) -> str:
        """Convert an annotation/expression AST node to a readable string."""
        try:
            return ast.unparse(node)   # Python 3.9+
        except AttributeError:
            pass
        # Fallback for Python 3.8
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return f"{self._expr_to_str(node.value)}.{node.attr}"
        if isinstance(node, ast.Constant):
            return repr(node.value)
        if isinstance(node, ast.Subscript):
            return f"{self._expr_to_str(node.value)}[{self._expr_to_str(node.slice)}]"
        if isinstance(node, ast.Tuple):
            return f"({', '.join(self._expr_to_str(e) for e in node.elts)})"
        return "..."

    def _name_from_expr(self, node: ast.expr) -> str:
        """Get a simple name string from a base-class expression."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            return node.attr
        return ""

    def _resolve_call_name(self, call_node: ast.Call) -> tuple[Optional[str], Optional[str]]:
        """
        Returns (short_name, full_qualified_name).

        Examples:
            print(x)              → ("print", "print")
            retriever.retrieve()  → ("retrieve", "retriever.retrieve")
            self.client.ask()     → ("ask", "client.ask")
            Retriever(dir)        → ("Retriever", "Retriever")
        """
        func = call_node.func

        if isinstance(func, ast.Name):
            return func.id, func.id

        if isinstance(func, ast.Attribute):
            short = func.attr
            # Build qualified: one level of receiver only (avoids deep chains)
            if isinstance(func.value, ast.Name):
                obj = func.value.id
                # Skip self/cls — they just add noise
                if obj in ("self", "cls"):
                    return short, short
                return short, f"{obj}.{short}"
            if isinstance(func.value, ast.Attribute):
                # e.g. self._client.ask → client.ask
                return short, f"{func.value.attr}.{short}"
            return short, short

        return None, None