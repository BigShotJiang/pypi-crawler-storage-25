"""
Node Embedder for CodeGraph AI.

Pipeline:
  graph.json → build text description per node → embed → save to FAISS

What gets saved to .codegraph/:
  - faiss.index      : the FAISS vector index (IndexFlatIP — inner product / cosine)
  - node_map.json    : maps FAISS integer ID → node ID string
                       e.g. { "0": "func:login", "1": "class:AuthManager" }
  - node_ids.pkl     : ordered list[str] of node IDs (same order as FAISS rows)
  - embedder.pkl     : serialised EmbedderBase instance so the retriever can
                       embed queries in the same vector space
  - vectors.npy      : raw float32 matrix (N, dim) for optional re-ranking

Text descriptions are never saved — they are only used during embedding.
"""

from __future__ import annotations

import json
import pickle
import numpy as np
from pathlib import Path

from codegraph.indexer.embedder import EmbedderBase


class NodeEmbedder:
    """
    Reads graph.json, builds a text description for each node,
    embeds them using the provided embedder, and saves a FAISS index.
    """

    def __init__(self, embedder: EmbedderBase):
        self.embedder = embedder

    def build_and_save(self, codegraph_dir: Path) -> dict:
        """
        Full pipeline:
        1. Load graph.json
        2. Build text description per node
        3. Embed all descriptions
        4. Normalise vectors (for cosine similarity via inner product)
        5. Save FAISS index + node_map.json + node_ids.pkl + embedder.pkl + vectors.npy

        Returns a summary dict.
        """
        graph_file = codegraph_dir / "graph.json"
        if not graph_file.exists():
            raise FileNotFoundError(
                f"graph.json not found at {graph_file}. Run 'codegraph index' first."
            )

        # Step 1 — Load graph
        with graph_file.open("r", encoding="utf-8") as f:
            data = json.load(f)

        nodes = data.get("nodes", [])
        edges = data.get("edges", [])

        if not nodes:
            raise ValueError("graph.json has no nodes.")

        # Step 2 — Build adjacency info for richer descriptions
        outgoing: dict[str, list[str]] = {}
        for edge in edges:
            src      = edge["source"]
            dst      = edge["target"]
            relation = edge.get("relation", "")
            if relation in ("contains", "calls"):
                dst_label = dst.split(":", 1)[-1]
                outgoing.setdefault(src, []).append(dst_label)

        # Step 3 — Build text descriptions
        node_ids:     list[str] = []
        descriptions: list[str] = []

        for node in nodes:
            node_id = node["id"]
            text    = self._build_description(node, outgoing.get(node_id, []))
            node_ids.append(node_id)
            descriptions.append(text)

        # Step 4 — Embed
        vectors = self.embedder.embed(descriptions).astype(np.float32)  # (N, dim)

        # Step 5 — L2-normalise so inner product == cosine similarity
        norms = np.linalg.norm(vectors, axis=1, keepdims=True) + 1e-9
        vectors_norm = vectors / norms

        # Step 6 — Save FAISS index (IndexFlatIP for cosine search)
        faiss_path    = codegraph_dir / "faiss.index"
        node_map_path = codegraph_dir / "node_map.json"
        node_ids_path = codegraph_dir / "node_ids.pkl"
        embedder_path = codegraph_dir / "embedder.pkl"
        vectors_path  = codegraph_dir / "vectors.npy"

        self._save_faiss(vectors_norm, faiss_path)

        # node_map.json  — kept for backwards compatibility
        node_map = {str(i): nid for i, nid in enumerate(node_ids)}
        with node_map_path.open("w", encoding="utf-8") as f:
            json.dump(node_map, f, indent=2)

        # node_ids.pkl  — ordered list the retriever uses
        with node_ids_path.open("wb") as f:
            pickle.dump(node_ids, f)

        # embedder.pkl  — so the retriever can embed queries identically
        with embedder_path.open("wb") as f:
            pickle.dump(self.embedder, f)

        # vectors.npy  — raw normalised matrix for optional diversity re-ranking
        np.save(str(vectors_path), vectors_norm)

        return {
            "nodes_embedded": len(node_ids),
            "embedding_dim":  vectors.shape[1],
            "faiss_index":    str(faiss_path),
            "node_map":       str(node_map_path),
        }

    # ──────────────────────────────────────────
    # Text description builder
    # ──────────────────────────────────────────

    def _build_description(self, node: dict, related: list[str]) -> str:
        """
        Build a human-readable text description for a node.
        This text is what gets embedded — never stored.

        Examples:
          "function login defined in auth.py, calls: validate_password, generate_token"
          "class AuthManager defined in auth.py, contains: login, validate_password"
          "file auth.py"
          "method validate_password in class AuthManager defined in auth.py"
          "module bcrypt"
        """
        kind      = node.get("kind", "node")
        label     = node.get("label", node["id"])
        file_id   = node.get("file", "")
        cls       = node.get("cls", "")
        file_name = file_id.replace("file:", "") if file_id else ""

        parts: list[str] = []

        if kind == "file":
            parts.append(f"file {label}")

        elif kind == "class":
            parts.append(f"class {label}")
            if file_name:
                parts.append(f"defined in {file_name}")

        elif kind == "function":
            parts.append(f"function {label}")
            if file_name:
                parts.append(f"defined in {file_name}")

        elif kind == "method":
            parts.append(f"method {label}")
            if cls:
                parts.append(f"in class {cls}")
            if file_name:
                parts.append(f"defined in {file_name}")

        elif kind == "module":
            parts.append(f"module {label}")

        else:
            parts.append(label)

        # Include signature so queries like "what does X return?" hit the right node
        signature = node.get("signature", "")
        if signature:
            parts.append(f"signature: {signature}")

        # Include docstring (first line only — keeps embedding focused)
        docstring = node.get("docstring", "") or node.get("doc", "")
        if docstring:
            first_line = docstring.strip().splitlines()[0][:120]
            parts.append(f"doc: {first_line}")

        if related:
            parts.append(f"related: {', '.join(related[:8])}")

        return ", ".join(parts)

    # ──────────────────────────────────────────
    # FAISS helpers
    # ──────────────────────────────────────────

    def _save_faiss(self, vectors: np.ndarray, path: Path) -> None:
        try:
            import faiss
        except ImportError:
            raise ImportError(
                "faiss-cpu is not installed.\n"
                "Run: pip install faiss-cpu"
            )

        dim   = vectors.shape[1]
        index = faiss.IndexFlatIP(dim)   # inner product on normalised vecs = cosine
        index.add(vectors)
        faiss.write_index(index, str(path))