"""
Embedder abstraction for CodeGraph AI.

Providers supported:
  - sentence-transformers  (local, no API key needed)
  - openai                 (requires OPENAI_API_KEY)
  - anthropic              (requires ANTHROPIC_API_KEY)
  - google                 (requires GOOGLE_API_KEY)

Usage:
    embedder = get_embedder("openai")
    vectors = embedder.embed(["function login in auth.py", "class AuthManager"])
"""

from __future__ import annotations
import os
import getpass
from abc import ABC, abstractmethod
import numpy as np


# ──────────────────────────────────────────────
# API key resolver
# ──────────────────────────────────────────────

def _resolve_api_key(env_var: str, provider: str) -> str:
    """
    Get an API key from the environment.
    If not set, prompt the user to enter it in the terminal.
    The key is set in os.environ for the current session only —
    never written to disk.
    """
    key = os.environ.get(env_var)
    if key:
        return key

    print(f"\n  [{provider}] API key not found ({env_var} is not set)")
    print(f"  To skip this prompt in future, run: export {env_var}=your_key\n")

    key = getpass.getpass(f"  Enter your {provider} API key: ").strip()

    if not key:
        raise EnvironmentError(
            f"{env_var} is required for the {provider} embedder.\n"
            f"Run: export {env_var}=your_key"
        )

    # Store for the rest of this process
    os.environ[env_var] = key
    print()
    return key


# ──────────────────────────────────────────────
# Base class
# ──────────────────────────────────────────────

class EmbedderBase(ABC):
    """All embedders must implement this interface."""

    @abstractmethod
    def embed(self, texts: list[str]) -> np.ndarray:
        """
        Embed a list of texts.
        Returns a 2D numpy array of shape (len(texts), embedding_dim).
        """
        ...

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Return the embedding dimension."""
        ...


# ──────────────────────────────────────────────
# Provider: sentence-transformers (local)
# ──────────────────────────────────────────────

class SentenceTransformerEmbedder(EmbedderBase):
    """
    Local embeddings using sentence-transformers.
    No API key required.
    Default model: all-MiniLM-L6-v2 (fast, good quality, 384 dims)
    """

    DEFAULT_MODEL = "all-MiniLM-L6-v2"

    def __init__(self, model_name: str = DEFAULT_MODEL):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            raise ImportError(
                "sentence-transformers is not installed.\n"
                "Run: pip install sentence-transformers"
            )
        self._model = SentenceTransformer(model_name)
        self._dim = self._model.get_sentence_embedding_dimension()

    def embed(self, texts: list[str]) -> np.ndarray:
        return self._model.encode(texts, convert_to_numpy=True, show_progress_bar=False)

    @property
    def dimension(self) -> int:
        return self._dim


# ──────────────────────────────────────────────
# Provider: OpenAI
# ──────────────────────────────────────────────

class OpenAIEmbedder(EmbedderBase):
    """
    OpenAI embeddings.
    Requires: OPENAI_API_KEY env var (will prompt if not set).
    Default model: text-embedding-3-small (1536 dims)
    """

    DEFAULT_MODEL = "text-embedding-3-small"
    DIM = 1536

    def __init__(self, model_name: str = DEFAULT_MODEL):
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError(
                "openai is not installed.\n"
                "Run: pip install openai"
            )
        api_key = _resolve_api_key("OPENAI_API_KEY", "OpenAI")
        self._client = OpenAI(api_key=api_key)
        self._model = model_name

    def embed(self, texts: list[str]) -> np.ndarray:
        texts = [t.replace("\n", " ") for t in texts]
        response = self._client.embeddings.create(input=texts, model=self._model)
        vectors = [item.embedding for item in response.data]
        return np.array(vectors, dtype=np.float32)

    @property
    def dimension(self) -> int:
        return self.DIM


# ──────────────────────────────────────────────
# Provider: Anthropic (via Voyage AI)
# ──────────────────────────────────────────────

class AnthropicEmbedder(EmbedderBase):
    """
    Anthropic uses Voyage AI for embeddings.
    Requires: ANTHROPIC_API_KEY env var (will prompt if not set).
    Default model: voyage-code-2 (1536 dims) — optimized for code
    """

    DEFAULT_MODEL = "voyage-code-2"
    DIM = 1536

    def __init__(self, model_name: str = DEFAULT_MODEL):
        try:
            import voyageai
        except ImportError:
            raise ImportError(
                "voyageai is not installed.\n"
                "Run: pip install voyageai"
            )
        api_key = _resolve_api_key("ANTHROPIC_API_KEY", "Anthropic")
        self._client = voyageai.Client(api_key=api_key)
        self._model = model_name

    def embed(self, texts: list[str]) -> np.ndarray:
        response = self._client.embed(texts, model=self._model, input_type="document")
        return np.array(response.embeddings, dtype=np.float32)

    @property
    def dimension(self) -> int:
        return self.DIM


# ──────────────────────────────────────────────
# Provider: Google (Gemini)
# ──────────────────────────────────────────────

class GoogleEmbedder(EmbedderBase):
    """
    Google Gemini embeddings.
    Requires: GOOGLE_API_KEY env var (will prompt if not set).
    Default model: models/text-embedding-004 (768 dims)
    """

    DEFAULT_MODEL = "models/text-embedding-004"
    DIM = 768

    def __init__(self, model_name: str = DEFAULT_MODEL):
        try:
            import google.generativeai as genai
        except ImportError:
            raise ImportError(
                "google-generativeai is not installed.\n"
                "Run: pip install google-generativeai"
            )
        api_key = _resolve_api_key("GOOGLE_API_KEY", "Google")
        genai.configure(api_key=api_key)
        self._genai = genai
        self._model = model_name

    def embed(self, texts: list[str]) -> np.ndarray:
        vectors = []
        for text in texts:
            result = self._genai.embed_content(model=self._model, content=text)
            vectors.append(result["embedding"])
        return np.array(vectors, dtype=np.float32)

    @property
    def dimension(self) -> int:
        return self.DIM


# ──────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────

PROVIDERS: dict[str, type[EmbedderBase]] = {
    "sentence-transformers": SentenceTransformerEmbedder,
    "openai":                OpenAIEmbedder,
    "anthropic":             AnthropicEmbedder,
    "google":                GoogleEmbedder,
}


def get_embedder(provider: str, model: str | None = None) -> EmbedderBase:
    """
    Factory function to get an embedder by provider name.
    If the required API key is not set, the user will be prompted in the terminal.

    Args:
        provider: one of 'sentence-transformers', 'openai', 'anthropic', 'google'
        model:    optional model override. Uses provider default if None.

    Example:
        embedder = get_embedder("openai")
        embedder = get_embedder("openai", model="text-embedding-3-large")
    """
    if provider not in PROVIDERS:
        available = ", ".join(PROVIDERS.keys())
        raise ValueError(f"Unknown embedder provider '{provider}'. Available: {available}")

    cls = PROVIDERS[provider]
    if model:
        return cls(model_name=model)
    return cls()