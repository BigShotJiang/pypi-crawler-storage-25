"""Local-first sweep analysis for ``dl-core``."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
from typing import Any

from dl_core import load_builtin_components, load_local_components
from dl_core.core import METRICS_SOURCE_REGISTRY
from tqdm import tqdm


def get_sweep_tracking_path(sweep_path: Path) -> Path:
    """
    Resolve the tracker JSON for a generated sweep.

    Args:
        sweep_path: Path to the user-facing sweep YAML file

    Returns:
        Path to the generated ``sweep_tracking.json`` file.
    """
    return sweep_path.parent / sweep_path.stem / "sweep_tracking.json"


def get_sweep_analysis_dir(sweep_path: Path) -> Path:
    """Resolve the versioned analysis output directory for a sweep."""
    return sweep_path.parent / sweep_path.stem / "analysis"


def _normalize_analysis_name(report_name: str | None) -> str | None:
    """Normalize an explicit analysis report name."""
    if not isinstance(report_name, str):
        return None
    normalized_name = Path(report_name.strip()).stem
    return normalized_name or None


def _resolve_latest_analysis_name(analysis_dir: Path) -> str:
    """Return the latest existing versioned analysis name, or ``v1``."""
    version_numbers: list[int] = []
    if analysis_dir.exists():
        for path in analysis_dir.glob("v*.md"):
            match = re.fullmatch(r"v(\d+)", path.stem)
            if match:
                version_numbers.append(int(match.group(1)))
    if not version_numbers:
        return "v1"
    return f"v{max(version_numbers)}"


def _resolve_next_analysis_name(analysis_dir: Path) -> str:
    """Return the next versioned analysis name for a sweep."""
    version_numbers: list[int] = []
    if analysis_dir.exists():
        for path in analysis_dir.glob("v*.md"):
            match = re.fullmatch(r"v(\d+)", path.stem)
            if match:
                version_numbers.append(int(match.group(1)))
    if not version_numbers:
        return "v1"
    return f"v{max(version_numbers) + 1}"


def get_sweep_analysis_markdown_path(sweep_path: Path) -> Path:
    """Resolve the latest Markdown analysis report path for a sweep."""
    analysis_dir = get_sweep_analysis_dir(sweep_path)
    return analysis_dir / f"{_resolve_latest_analysis_name(analysis_dir)}.md"


def get_sweep_analysis_json_path(sweep_path: Path) -> Path:
    """Resolve the latest JSON analysis report path for a sweep."""
    analysis_dir = get_sweep_analysis_dir(sweep_path)
    return analysis_dir / f"{_resolve_latest_analysis_name(analysis_dir)}.json"


def get_sweep_analysis_cache_path(sweep_path: Path) -> Path:
    """Resolve the persistent analyzer cache path for a sweep."""
    return get_sweep_tracking_path(sweep_path).parent / "analysis_cache.json"


def _load_json(path: Path) -> dict[str, Any]:
    """Load a JSON file into a dictionary."""
    with open(path, "r") as f:
        return json.load(f)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    """Write a JSON payload to disk with stable formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _emit_progress(message: str) -> None:
    """Write one short analyzer progress message to stderr."""
    print(message, file=sys.stderr)


def _resolve_metrics_source_backend(
    sweep_data: dict[str, Any], run_data: dict[str, Any]
) -> str:
    """
    Resolve the metrics source backend for one tracked run.

    Args:
        sweep_data: Full sweep tracking payload
        run_data: Sweep tracker entry for one run

    Returns:
        Metrics source backend name.
    """
    backend_candidates = (
        run_data.get("metrics_source_backend"),
        run_data.get("tracking_backend"),
        sweep_data.get("metrics_source_backend"),
        sweep_data.get("tracking_backend"),
    )
    for candidate in backend_candidates:
        if isinstance(candidate, str) and candidate:
            return candidate
    return "local"


def collect_sweep_runs(
    sweep_path: str | Path,
    *,
    ranking_metrics: list[dict[str, str]] | None = None,
    rank_method: str = "lexicographic",
    force_refresh: bool = False,
) -> list[dict[str, Any]]:
    """
    Collect normalized run analysis records for a sweep.

    Args:
        sweep_path: Path to the user-facing sweep YAML file

    Returns:
        List of normalized run records.
    """
    resolved_sweep_path = Path(sweep_path).resolve()
    tracking_path = get_sweep_tracking_path(resolved_sweep_path)
    if not tracking_path.exists():
        raise FileNotFoundError(f"Sweep tracking file not found: {tracking_path}")

    _emit_progress(f"Loading sweep tracker: {tracking_path}")
    load_builtin_components()
    load_local_components(resolved_sweep_path)
    sweep_data = _load_json(tracking_path)
    cache_path = get_sweep_analysis_cache_path(resolved_sweep_path)
    if cache_path.exists() and not force_refresh:
        sweep_data["_analysis_cache"] = _load_json(cache_path)
    else:
        sweep_data["_analysis_cache"] = {}
    sweep_data["_tracking_dir"] = str(tracking_path.parent)
    sweep_data["_sweep_path"] = str(resolved_sweep_path)
    sweep_data["_force_analysis_refresh"] = force_refresh
    sweep_data["_ranking_metrics"] = ranking_metrics or [
        {"metric": "test/accuracy", "mode": "max"}
    ]
    sweep_data["_rank_method"] = rank_method
    runs = sweep_data.get("runs", {})
    collected_runs: list[dict[str, Any]] = []
    run_items = sorted(
        ((int(run_index_str), run_data) for run_index_str, run_data in runs.items()),
        key=lambda item: item[0],
    )
    _emit_progress(
        f"Collecting {len(runs)} tracked runs from {resolved_sweep_path.name}"
    )

    prepared_backends: dict[str, Any] = {}
    for run_index, run_data in run_items:
        metrics_source_backend = _resolve_metrics_source_backend(sweep_data, run_data)
        if metrics_source_backend in prepared_backends:
            continue

        metrics_source = METRICS_SOURCE_REGISTRY.get(metrics_source_backend)
        backend_run_items = [
            (item_run_index, item_run_data)
            for item_run_index, item_run_data in run_items
            if _resolve_metrics_source_backend(sweep_data, item_run_data)
            == metrics_source_backend
        ]
        if backend_run_items:
            _emit_progress(
                f"Preparing {len(backend_run_items)} runs via "
                f"{metrics_source_backend}"
            )
            with tqdm(
                total=len(backend_run_items),
                desc=f"Prefetch {metrics_source_backend}",
                unit="run",
                file=sys.stderr,
                leave=False,
            ) as pbar:
                metrics_source.prepare_sweep(
                    run_items=backend_run_items,
                    sweep_data=sweep_data,
                    progress_callback=lambda: pbar.update(1),
                )
        prepared_backends[metrics_source_backend] = metrics_source

    total_runs = len(run_items)
    with tqdm(
        total=total_runs,
        desc="Collect runs",
        unit="run",
        file=sys.stderr,
        leave=False,
    ) as pbar:
        for run_index, run_data in run_items:
            metrics_source_backend = _resolve_metrics_source_backend(
                sweep_data,
                run_data,
            )
            metrics_source = prepared_backends[metrics_source_backend]
            run_name = run_data.get("tracking_run_name") or f"run_{run_index}"
            pbar.set_postfix_str(run_name)
            collected_runs.append(
                metrics_source.collect_run(
                    run_index=run_index,
                    run_data=run_data,
                    sweep_data=sweep_data,
                )
            )
            pbar.update(1)

    analysis_cache = sweep_data.get("_analysis_cache")
    if isinstance(analysis_cache, dict) and analysis_cache:
        _write_json(cache_path, analysis_cache)

    return collected_runs


def _format_metric_value(value: Any) -> str:
    """Format a metric value for terminal output."""
    if isinstance(value, float):
        return f"{value:.6f}"
    if value is None:
        return "-"
    return str(value)


def _get_ranking_entries(run: dict[str, Any]) -> list[dict[str, Any]]:
    """Return normalized ranking entries for one run."""
    ranking_entries = run.get("ranking_metrics")
    if isinstance(ranking_entries, list) and ranking_entries:
        return [entry for entry in ranking_entries if isinstance(entry, dict)]

    selection_metric = run.get("selection_metric")
    selection_mode = run.get("selection_mode")
    if (
        isinstance(selection_metric, str)
        and selection_metric
        and selection_mode in {"min", "max"}
    ):
        return [
            {
                "metric": selection_metric,
                "resolved_metric": selection_metric,
                "mode": selection_mode,
                "value": run.get("selection_value"),
                "best_epoch": run.get("best_epoch"),
                "final_value": None,
            }
        ]
    return []


def _get_ranking_specs(runs: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Resolve the shared ranking metric specs from the collected runs."""
    for run in runs:
        ranking_entries = _get_ranking_entries(run)
        if ranking_entries:
            return [
                {"metric": str(entry["metric"]), "mode": str(entry["mode"])}
                for entry in ranking_entries
                if isinstance(entry.get("metric"), str)
                and entry.get("mode") in {"min", "max"}
            ]
    return []


def _get_rank_method(runs: list[dict[str, Any]]) -> str:
    """Resolve the configured ranking method for the current sweep."""
    for run in runs:
        rank_method = run.get("rank_method")
        if rank_method in {"lexicographic", "pareto", "rank-sum"}:
            return str(rank_method)
    return "lexicographic"


def _get_ranking_value(run: dict[str, Any], metric_name: str) -> Any:
    """Return the ranking value for one requested metric on one run."""
    for entry in _get_ranking_entries(run):
        if entry.get("metric") == metric_name:
            return entry.get("value")
    return None


def _get_ranking_best_epoch(run: dict[str, Any], metric_name: str) -> Any:
    """Return the best epoch for one requested metric on one run."""
    for entry in _get_ranking_entries(run):
        if entry.get("metric") == metric_name:
            return entry.get("best_epoch")
    return None


def _infer_metric_mode(metric_name: str) -> str | None:
    """Infer whether one metric should be minimized or maximized."""
    metric_lower = metric_name.lower()
    minimize_keywords = [
        "eer",
        "error",
        "loss",
        "apcer",
        "bpcer",
        "far",
        "frr",
        "fnr",
        "fpr",
        "miss",
        "false",
        "distance",
        "cost",
    ]
    maximize_keywords = [
        "accuracy",
        "precision",
        "recall",
        "f1",
        "auc",
        "roc",
        "score",
        "iou",
        "dice",
        "jaccard",
        "map",
        "ndcg",
    ]

    for keyword in minimize_keywords:
        if keyword in metric_lower:
            return "min"
    for keyword in maximize_keywords:
        if keyword in metric_lower:
            return "max"
    return None


def _build_requested_ranking_specs(
    metric_names: list[str] | None,
    metric_modes: list[str] | None,
) -> list[dict[str, str]]:
    """Build requested ranking specs from CLI arguments."""
    resolved_metric_names = metric_names or ["test/accuracy"]
    resolved_metric_modes = metric_modes or []
    if resolved_metric_modes and len(resolved_metric_modes) != len(
        resolved_metric_names
    ):
        raise ValueError("Provide one --mode per --metric, or omit --mode entirely.")

    ranking_specs: list[dict[str, str]] = []
    for index, metric_name in enumerate(resolved_metric_names):
        metric_mode = (
            resolved_metric_modes[index]
            if index < len(resolved_metric_modes)
            else (_infer_metric_mode(metric_name) or "max")
        )
        ranking_specs.append({"metric": metric_name, "mode": metric_mode})
    return ranking_specs


def _resolve_primary_metric_details(
    runs: list[dict[str, Any]],
) -> tuple[str, str, str | None]:
    """Resolve the primary metric, effective mode, and any override note."""
    ranking_specs = _get_ranking_specs(runs)
    if ranking_specs:
        primary_spec = ranking_specs[0]
        return primary_spec["metric"], primary_spec["mode"], None

    for run in runs:
        metric = run.get("selection_metric")
        explicit_mode = run.get("selection_mode")
        if not isinstance(metric, str) or not metric:
            continue

        normalized_mode = (
            explicit_mode
            if isinstance(explicit_mode, str) and explicit_mode in {"min", "max"}
            else None
        )
        inferred_mode = _infer_metric_mode(metric)
        if inferred_mode is not None and normalized_mode not in {None, inferred_mode}:
            return (
                metric,
                inferred_mode,
                f"inferred `{inferred_mode}` from metric name; tracker stored `{normalized_mode}`",
            )
        return metric, normalized_mode or inferred_mode or "-", None

    return "-", "-", None


def _sort_runs_for_display(runs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sort runs by selection value when available, otherwise by run index."""
    ranking_specs = _get_ranking_specs(runs)
    if not ranking_specs:
        runs_with_metric = [
            run for run in runs if isinstance(run.get("selection_value"), (int, float))
        ]
        if not runs_with_metric:
            return sorted(runs, key=lambda run: run["run_index"])

        _, effective_mode, _ = _resolve_primary_metric_details(runs_with_metric)
        reverse = effective_mode == "max"
        metric_sorted = sorted(
            runs_with_metric,
            key=lambda run: float(run["selection_value"]),
            reverse=reverse,
        )
        runs_without_metric = [
            run
            for run in runs
            if not isinstance(run.get("selection_value"), (int, float))
        ]
        runs_without_metric.sort(key=lambda run: run["run_index"])
        ordered_runs = metric_sorted + runs_without_metric
    elif _get_rank_method(runs) == "pareto":
        ordered_runs = _sort_runs_by_pareto_front(runs, ranking_specs)
    elif _get_rank_method(runs) == "rank-sum":
        ordered_runs = _sort_runs_by_rank_sum(runs, ranking_specs)
    else:
        ordered_runs = _sort_runs_lexicographically(runs, ranking_specs)

    for rank, run in enumerate(ordered_runs, start=1):
        run["_rank"] = rank
    return ordered_runs


def _sort_runs_lexicographically(
    runs: list[dict[str, Any]],
    ranking_specs: list[dict[str, str]],
) -> list[dict[str, Any]]:
    """Sort runs lexicographically using the configured ranking metrics."""
    def _build_key(run: dict[str, Any]) -> tuple[Any, ...]:
        key_parts: list[Any] = []
        for ranking_spec in ranking_specs:
            metric_value = _get_ranking_value(run, ranking_spec["metric"])
            if not isinstance(metric_value, (int, float)):
                key_parts.extend([1, float("inf")])
                continue
            sortable_value = (
                float(metric_value)
                if ranking_spec["mode"] == "min"
                else -float(metric_value)
            )
            key_parts.extend([0, sortable_value])
        key_parts.append(run["run_index"])
        return tuple(key_parts)

    return sorted(runs, key=_build_key)


def _dominates(
    lhs_run: dict[str, Any],
    rhs_run: dict[str, Any],
    ranking_specs: list[dict[str, str]],
) -> bool:
    """Return whether one run Pareto-dominates another."""
    lhs_better = False
    for ranking_spec in ranking_specs:
        lhs_value = _get_ranking_value(lhs_run, ranking_spec["metric"])
        rhs_value = _get_ranking_value(rhs_run, ranking_spec["metric"])
        if not isinstance(lhs_value, (int, float)) or not isinstance(
            rhs_value,
            (int, float),
        ):
            return False
        if ranking_spec["mode"] == "min":
            if lhs_value > rhs_value:
                return False
            if lhs_value < rhs_value:
                lhs_better = True
        else:
            if lhs_value < rhs_value:
                return False
            if lhs_value > rhs_value:
                lhs_better = True
    return lhs_better


def _sort_runs_by_pareto_front(
    runs: list[dict[str, Any]],
    ranking_specs: list[dict[str, str]],
) -> list[dict[str, Any]]:
    """Sort runs by Pareto front and lexicographic tie-breaks."""
    complete_runs = [
        run
        for run in runs
        if all(
            isinstance(_get_ranking_value(run, spec["metric"]), (int, float))
            for spec in ranking_specs
        )
    ]
    incomplete_runs = [
        run
        for run in runs
        if run not in complete_runs
    ]
    remaining_runs = complete_runs[:]
    ordered_runs: list[dict[str, Any]] = []
    front_index = 1
    while remaining_runs:
        current_front = [
            run
            for run in remaining_runs
            if not any(
                _dominates(other_run, run, ranking_specs)
                for other_run in remaining_runs
                if other_run is not run
            )
        ]
        current_front = _sort_runs_lexicographically(current_front, ranking_specs)
        for run in current_front:
            run["_front"] = front_index
        ordered_runs.extend(current_front)
        remaining_runs = [
            run for run in remaining_runs if run not in current_front
        ]
        front_index += 1

    for run in incomplete_runs:
        run["_front"] = None
    ordered_runs.extend(_sort_runs_lexicographically(incomplete_runs, ranking_specs))
    return ordered_runs


def _sort_runs_by_rank_sum(
    runs: list[dict[str, Any]],
    ranking_specs: list[dict[str, str]],
) -> list[dict[str, Any]]:
    """Sort runs by summed per-metric ranks."""
    run_scores: dict[int, int] = {run["run_index"]: 0 for run in runs}
    incomplete_runs: set[int] = set()

    for ranking_spec in ranking_specs:
        metric_name = ranking_spec["metric"]
        metric_runs = [
            run
            for run in runs
            if isinstance(_get_ranking_value(run, metric_name), (int, float))
        ]
        if not metric_runs:
            continue

        reverse = ranking_spec["mode"] == "max"
        ordered_metric_runs = sorted(
            metric_runs,
            key=lambda run: float(_get_ranking_value(run, metric_name)),
            reverse=reverse,
        )
        for rank, run in enumerate(ordered_metric_runs, start=1):
            run_scores[run["run_index"]] += rank

        complete_metric_run_ids = {run["run_index"] for run in metric_runs}
        for run in runs:
            if run["run_index"] not in complete_metric_run_ids:
                incomplete_runs.add(run["run_index"])

    for run in runs:
        if run["run_index"] in incomplete_runs:
            run["_rank_sum"] = None
        else:
            run["_rank_sum"] = run_scores[run["run_index"]]

    return sorted(
        runs,
        key=lambda run: (
            run.get("_rank_sum") is None,
            run.get("_rank_sum") if isinstance(run.get("_rank_sum"), int) else float("inf"),
            run["run_index"],
        ),
    )


def _summarize_status_counts(runs: list[dict[str, Any]]) -> dict[str, int]:
    """Count runs by analyzer status."""
    counts: dict[str, int] = {}
    for run in runs:
        status = str(run.get("status") or "unknown")
        counts[status] = counts.get(status, 0) + 1
    return counts


def _resolve_primary_metric(runs: list[dict[str, Any]]) -> tuple[str, str]:
    """Resolve the main selection metric and mode for one sweep report."""
    metric, mode, _ = _resolve_primary_metric_details(runs)
    return metric, mode


def _select_common_best_metric_columns(
    runs: list[dict[str, Any]],
    *,
    primary_metric: str,
    max_columns: int = 4,
) -> list[str]:
    """Select a small set of common best-epoch metrics for report tables."""
    metric_sets: list[set[str]] = []
    for run in runs:
        best_metrics = run.get("best_metrics")
        if not isinstance(best_metrics, dict) or not best_metrics:
            continue
        run_metric_names = {
            metric_name
            for metric_name, value in best_metrics.items()
            if isinstance(metric_name, str)
            and metric_name
            and isinstance(value, (int, float))
        }
        if run_metric_names:
            metric_sets.append(run_metric_names)

    if not metric_sets:
        return []

    common_metrics = set.intersection(*metric_sets)
    common_metrics.discard(primary_metric)
    ordered_metrics = sorted(common_metrics)
    return ordered_metrics[:max_columns]


def _get_top_runs(
    runs: list[dict[str, Any]],
    *,
    top_n: int = 3,
) -> list[dict[str, Any]]:
    """Return the top-ranked runs for compact report summaries."""
    return _sort_runs_for_display(runs)[:top_n]


def _collect_metric_statistics(
    runs: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Collect basic statistics for the configured ranking metrics."""
    metric_values: dict[str, list[float]] = {}
    for ranking_spec in _get_ranking_specs(runs):
        metric_name = ranking_spec["metric"]
        metric_values[metric_name] = [
            float(_get_ranking_value(run, metric_name))
            for run in runs
            if isinstance(_get_ranking_value(run, metric_name), (int, float))
        ]

    statistics: list[dict[str, str]] = []
    for metric_name, values in metric_values.items():
        if not values:
            continue
        mean = sum(values) / len(values)
        variance = sum((value - mean) ** 2 for value in values) / len(values)
        statistics.append(
            {
                "metric": metric_name,
                "mean": f"{mean:.6f}",
                "std": f"{variance ** 0.5:.6f}",
                "min": f"{min(values):.6f}",
                "max": f"{max(values):.6f}",
            }
        )
    return statistics


def _render_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    """Render one compact monospace table as plain text lines."""
    widths = [len(header) for header in headers]
    for row in rows:
        for index, cell in enumerate(row):
            widths[index] = max(widths[index], len(cell))

    def _format_row(row: list[str]) -> str:
        return " | ".join(
            cell.ljust(widths[index]) for index, cell in enumerate(row)
        )

    separator = "-+-".join("-" * width for width in widths)
    return [_format_row(headers), separator, *(_format_row(row) for row in rows)]


def _load_analysis_runs(report_path: Path) -> list[dict[str, Any]]:
    """Load normalized runs from a saved analysis JSON report."""
    payload = json.loads(report_path.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise ValueError(f"Analysis report must contain a list of runs: {report_path}")
    return [item for item in payload if isinstance(item, dict)]


def _resolve_compare_report_path(
    sweep_path: Path,
    report_ref: str,
) -> Path:
    """Resolve an analysis JSON report reference for comparison."""
    candidate = Path(report_ref)
    if candidate.suffix == ".json":
        resolved_candidate = candidate.resolve()
        if resolved_candidate.exists():
            return resolved_candidate
        raise FileNotFoundError(f"Comparison report not found: {resolved_candidate}")

    analysis_dir = get_sweep_analysis_dir(sweep_path)
    if report_ref == "latest":
        latest_path = get_sweep_analysis_json_path(sweep_path)
        if latest_path.exists():
            return latest_path
        raise FileNotFoundError(
            f"No previous JSON analysis report found in {analysis_dir}"
        )

    normalized_name = _normalize_analysis_name(report_ref)
    if normalized_name is None:
        raise ValueError("Comparison report name cannot be empty")

    resolved_path = analysis_dir / f"{normalized_name}.json"
    if not resolved_path.exists():
        raise FileNotFoundError(f"Comparison report not found: {resolved_path}")
    return resolved_path


def _format_metric_transition(previous_value: Any, current_value: Any) -> str:
    """Render one metric transition for comparison output."""
    previous_text = _format_metric_value(previous_value)
    current_text = _format_metric_value(current_value)
    if not isinstance(previous_value, (int, float)) or not isinstance(
        current_value,
        (int, float),
    ):
        return f"{previous_text} -> {current_text}"
    delta = float(current_value) - float(previous_value)
    return f"{previous_text} -> {current_text} ({delta:+.6f})"


def _build_comparison_summary(
    current_runs: list[dict[str, Any]],
    previous_runs: list[dict[str, Any]],
    *,
    previous_label: str,
) -> dict[str, Any] | None:
    """Build a compact comparison summary between two analyses."""
    current_sorted = _sort_runs_for_display(current_runs)
    previous_sorted = _sort_runs_for_display(previous_runs)
    previous_by_name = {
        str(run.get("run_name")): run
        for run in previous_sorted
        if isinstance(run.get("run_name"), str)
    }
    current_specs = _get_ranking_specs(current_sorted)

    comparison_rows: list[list[str]] = []
    for current_rank, run in enumerate(current_sorted, start=1):
        run_name = run["run_name"]
        previous_run = previous_by_name.get(run_name)
        if previous_run is None:
            continue

        previous_rank = int(previous_run.get("_rank", 0) or 0)
        rank_delta = previous_rank - current_rank
        comparison_rows.append(
            [
                run_name,
                str(previous_rank or "-"),
                str(current_rank),
                f"{rank_delta:+d}" if previous_rank else "-",
                *[
                    _format_metric_transition(
                        _get_ranking_value(previous_run, spec["metric"]),
                        _get_ranking_value(run, spec["metric"]),
                    )
                    for spec in current_specs
                ],
            ]
        )

    if not comparison_rows:
        return None

    previous_top = previous_sorted[0]["run_name"] if previous_sorted else "-"
    current_top = current_sorted[0]["run_name"] if current_sorted else "-"
    return {
        "label": previous_label,
        "previous_top": previous_top,
        "current_top": current_top,
        "headers": [
            "Run",
            "Old Rank",
            "New Rank",
            "ΔRank",
            *[f"{spec['metric']} Δ" for spec in current_specs],
        ],
        "rows": comparison_rows,
    }


def _render_text_report(
    sweep_path: Path,
    runs: list[dict[str, Any]],
    *,
    comparison: dict[str, Any] | None = None,
) -> str:
    """Render a human-readable text report for the collected sweep runs."""
    sorted_runs = _sort_runs_for_display(runs)
    primary_metric, primary_mode, primary_mode_note = _resolve_primary_metric_details(
        sorted_runs
    )
    rank_method = _get_rank_method(sorted_runs)
    ranking_specs = _get_ranking_specs(sorted_runs)
    status_counts = _summarize_status_counts(sorted_runs)
    top_runs = _get_top_runs(sorted_runs)
    lines = [
        f"Sweep: {sweep_path.name}",
        f"Tracked runs: {len(sorted_runs)}",
        f"Rank method: {rank_method}",
        f"Primary metric: {primary_metric}",
        f"Mode: {primary_mode}",
        (
            "Ranking metrics: "
            + ", ".join(
                f"{spec['metric']} ({spec['mode']})" for spec in ranking_specs
            )
            if ranking_specs
            else "Ranking metrics: -"
        ),
        (
            "Status summary: "
            + ", ".join(
                f"{status}={count}"
                for status, count in sorted(status_counts.items())
            )
        ),
        "",
    ]
    if primary_mode_note:
        lines.extend([f"Mode note: {primary_mode_note}", ""])

    ranking_headers = ["Rank"]
    if rank_method == "pareto":
        ranking_headers.append("Front")
    if rank_method == "rank-sum":
        ranking_headers.append("Rank Sum")
    ranking_headers.extend(["Run", "Status"])
    ranking_headers.extend(
        [
            f"{spec['metric']} [{spec['mode']}]"
            for spec in ranking_specs
        ]
    )
    ranking_rows = [
        (
            [str(run.get("_rank", rank))]
            + (
                [str(run.get("_front", "-"))]
                if rank_method == "pareto"
                else []
            )
            + (
                [str(run.get("_rank_sum", "-"))]
                if rank_method == "rank-sum"
                else []
            )
            + [
                run["run_name"],
                str(run.get("status", "-")),
                *[
                    _format_metric_value(_get_ranking_value(run, spec["metric"]))
                    for spec in ranking_specs
                ],
            ]
        )
        for rank, run in enumerate(sorted_runs, start=1)
    ]
    lines.extend(
        [
            "Ranking",
            *(
                _render_table(
                    ranking_headers,
                    ranking_rows,
                )
            ),
        ]
    )
    if top_runs:
        lines.extend(["", "Top Performers"])
        for rank, run in enumerate(top_runs, start=1):
            lines.append(
                f"{rank}. {run['run_name']} | "
                + " | ".join(
                    (
                        f"{spec['metric']}="
                        f"{_format_metric_value(_get_ranking_value(run, spec['metric']))}"
                        f"@{_get_ranking_best_epoch(run, spec['metric']) or '-'}"
                    )
                    for spec in ranking_specs
                )
            )

    metric_statistics = _collect_metric_statistics(sorted_runs)
    if metric_statistics:
        stats_rows = [
            [
                row["metric"],
                row["mean"],
                row["std"],
                row["min"],
                row["max"],
            ]
            for row in metric_statistics
        ]
        lines.extend(
            [
                "",
                "Metric Statistics",
                *(
                    _render_table(
                        ["Metric", "Mean", "Std", "Min", "Max"],
                        stats_rows,
                    )
                ),
            ]
        )

    if comparison is not None:
        lines.extend(
            [
                "",
                f"Comparison vs {comparison['label']}",
                f"Previous top run: {comparison['previous_top']}",
                f"Current top run: {comparison['current_top']}",
                *(
                    _render_table(
                        comparison["headers"],
                        comparison["rows"],
                    )
                ),
            ]
        )

    failures = [run for run in sorted_runs if run.get("error_message")]
    if failures:
        lines.extend(["", "Failures"])
        for run in failures:
            lines.append(f"- {run['run_name']}: {run['error_message']}")

    warnings = [run for run in sorted_runs if run.get("metrics_source_warning")]
    if warnings:
        lines.extend(["", "Warnings"])
        for run in warnings:
            lines.append(
                f"- {run['run_name']}: {run['metrics_source_warning']}"
            )

    return "\n".join(lines)


def _render_markdown_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    """Render one Markdown table."""
    separator = ["---"] * len(headers)
    markdown_rows = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(separator) + " |",
    ]
    markdown_rows.extend("| " + " | ".join(row) + " |" for row in rows)
    return markdown_rows


def _render_markdown_report(
    sweep_path: Path,
    runs: list[dict[str, Any]],
    *,
    comparison: dict[str, Any] | None = None,
) -> str:
    """Render a Markdown report for one collected sweep."""
    sorted_runs = _sort_runs_for_display(runs)
    primary_metric, primary_mode, primary_mode_note = _resolve_primary_metric_details(
        sorted_runs
    )
    rank_method = _get_rank_method(sorted_runs)
    ranking_specs = _get_ranking_specs(sorted_runs)
    status_counts = _summarize_status_counts(sorted_runs)
    top_runs = _get_top_runs(sorted_runs)
    lines = [
        "# Sweep Analysis",
        "",
        f"- Sweep: `{sweep_path.name}`",
        f"- Tracked runs: {len(sorted_runs)}",
        f"- Rank method: `{rank_method}`",
        f"- Primary metric: `{primary_metric}`",
        f"- Mode: `{primary_mode}`",
        "- Ranking metrics: "
        + (
            ", ".join(
                f"`{spec['metric']}` ({spec['mode']})" for spec in ranking_specs
            )
            if ranking_specs
            else "-"
        ),
        f"- Status summary: "
        + ", ".join(
            f"`{status}={count}`" for status, count in sorted(status_counts.items())
        ),
        "",
    ]
    if primary_mode_note:
        lines.extend([f"- Mode note: {primary_mode_note}", ""])
    lines.extend(["## Ranking", ""])

    ranking_headers = ["Rank"]
    if rank_method == "pareto":
        ranking_headers.append("Front")
    if rank_method == "rank-sum":
        ranking_headers.append("Rank Sum")
    ranking_headers.extend(["Run", "Status"])
    ranking_headers.extend(
        [f"{spec['metric']} [{spec['mode']}]" for spec in ranking_specs]
    )
    ranking_rows = [
        (
            [str(run.get("_rank", rank))]
            + (
                [str(run.get("_front", "-"))]
                if rank_method == "pareto"
                else []
            )
            + (
                [str(run.get("_rank_sum", "-"))]
                if rank_method == "rank-sum"
                else []
            )
            + [
                run["run_name"],
                str(run.get("status", "-")),
                *[
                    _format_metric_value(_get_ranking_value(run, spec["metric"]))
                    for spec in ranking_specs
                ],
            ]
        )
        for rank, run in enumerate(sorted_runs, start=1)
    ]
    lines.extend(
        _render_markdown_table(
            ranking_headers,
            ranking_rows,
        )
    )
    lines.append("")
    if top_runs:
        lines.extend(["## Top Performers", ""])
        for rank, run in enumerate(top_runs, start=1):
            lines.extend(
                [
                    f"### {rank}. {run['run_name']}",
                    "",
                    *[
                        (
                            f"- `{spec['metric']}`: "
                            f"`{_format_metric_value(_get_ranking_value(run, spec['metric']))}` "
                            f"(best epoch `{_get_ranking_best_epoch(run, spec['metric']) or '-'}`)"
                        )
                        for spec in ranking_specs
                    ],
                ]
            )
            lines.append("")

    metric_statistics = _collect_metric_statistics(sorted_runs)
    if metric_statistics:
        lines.extend(["## Metric Statistics", ""])
        lines.extend(
            _render_markdown_table(
                ["Metric", "Mean", "Std", "Min", "Max"],
                [
                    [
                        row["metric"],
                        row["mean"],
                        row["std"],
                        row["min"],
                        row["max"],
                    ]
                    for row in metric_statistics
                ],
            )
        )
        lines.append("")

    if comparison is not None:
        lines.extend(
            [
                f"## Comparison vs {comparison['label']}",
                "",
                f"- Previous top run: `{comparison['previous_top']}`",
                f"- Current top run: `{comparison['current_top']}`",
                "",
                *(
                    _render_markdown_table(
                        comparison["headers"],
                        comparison["rows"],
                    )
                ),
                "",
            ]
        )

    failures = [run for run in sorted_runs if run.get("error_message")]
    if failures:
        lines.extend(["## Failures", ""])
        for run in failures:
            lines.append(f"- `{run['run_name']}`: {run['error_message']}")
        lines.append("")

    warnings = [run for run in sorted_runs if run.get("metrics_source_warning")]
    if warnings:
        lines.extend(["## Warnings", ""])
        for run in warnings:
            lines.append(
                f"- `{run['run_name']}`: {run['metrics_source_warning']}"
            )
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _write_analysis_reports(
    sweep_path: Path,
    runs: list[dict[str, Any]],
    *,
    report_name: str | None,
    comparison: dict[str, Any] | None = None,
) -> tuple[Path, Path]:
    """Write versioned Markdown and JSON analysis reports."""
    analysis_dir = get_sweep_analysis_dir(sweep_path)
    analysis_dir.mkdir(parents=True, exist_ok=True)
    resolved_report_name = _normalize_analysis_name(report_name)
    if resolved_report_name is None:
        resolved_report_name = _resolve_next_analysis_name(analysis_dir)

    markdown_path = analysis_dir / f"{resolved_report_name}.md"
    markdown_path.write_text(
        _render_markdown_report(sweep_path, runs, comparison=comparison),
        encoding="utf-8",
    )

    json_path = analysis_dir / f"{resolved_report_name}.json"
    json_path.write_text(json.dumps(runs, indent=2), encoding="utf-8")

    return markdown_path, json_path


def main(argv: list[str] | None = None) -> int:
    """Run the local sweep analyzer CLI."""
    parser = argparse.ArgumentParser(
        prog="dl-analyze",
        description=(
            "Inspect sweep results and write experiments/<sweep>/analysis/v1.md "
            "by default."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml --name pareto_eer\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml --json\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml --compare latest\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml "
            "--metric test/eer --mode min\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml "
            "--metric test/eer --mode min "
            "--metric test/accuracy --mode max "
            "--rank-method lexicographic\n"
            "  dl-analyze --sweep experiments/lr_sweep.yaml "
            "--metric test/eer --mode min "
            "--metric test/accuracy --mode max "
            "--metric test/loss --mode min "
            "--rank-method rank-sum\n\n"
            "This command reads the generated experiments/<sweep_name>/"
            "sweep_tracking.json and writes reports under experiments/"
            "<sweep_name>/analysis/. It also reuses experiments/<sweep_name>/"
            "analysis_cache.json unless --force is set. A matching JSON report "
            "is always written for reuse and comparisons."
        ),
    )
    parser.add_argument(
        "--sweep",
        required=True,
        help="Path to the user-facing sweep YAML file.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print normalized run records to stdout after writing the reports.",
    )
    parser.add_argument(
        "--name",
        type=str,
        help="Explicit report basename under analysis/ (for example: pareto_eer).",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Ignore persisted analysis_cache.json and refetch ranking metrics.",
    )
    parser.add_argument(
        "--compare",
        type=str,
        help=(
            "Compare this analysis against a saved analysis JSON report. Use "
            "`latest`, a report base name like `v1`, or a direct .json path."
        ),
    )
    parser.add_argument(
        "--metric",
        action="append",
        dest="metrics",
        help=(
            "Metric used for ranking. Repeat to rank by multiple metrics. "
            "Defaults to test/accuracy."
        ),
    )
    parser.add_argument(
        "--mode",
        action="append",
        choices=["min", "max"],
        dest="modes",
        help=(
            "Optimization mode for each --metric. Repeat in the same order as "
            "--metric. When omitted, modes are inferred or default to max."
        ),
    )
    parser.add_argument(
        "--rank-method",
        choices=["lexicographic", "pareto", "rank-sum"],
        default="lexicographic",
        help=(
            "How to rank runs from the requested metrics: lexicographic, "
            "pareto, or rank-sum."
        ),
    )
    args = parser.parse_args(argv)

    sweep_path = Path(args.sweep).resolve()
    try:
        ranking_specs = _build_requested_ranking_specs(args.metrics, args.modes)
    except ValueError as exc:
        parser.error(str(exc))

    runs = collect_sweep_runs(
        sweep_path,
        ranking_metrics=ranking_specs,
        rank_method=args.rank_method,
        force_refresh=args.force,
    )
    comparison = None
    if args.compare:
        compare_path = _resolve_compare_report_path(sweep_path, args.compare)
        previous_runs = _load_analysis_runs(compare_path)
        comparison = _build_comparison_summary(
            runs,
            previous_runs,
            previous_label=compare_path.stem,
        )

    markdown_path, json_path = _write_analysis_reports(
        sweep_path,
        runs,
        report_name=args.name,
        comparison=comparison,
    )
    _emit_progress(f"Wrote Markdown report to {markdown_path}")
    _emit_progress(f"Wrote JSON report to {json_path}")

    if args.json:
        print(json.dumps(runs, indent=2))
    else:
        print(_render_text_report(sweep_path, runs, comparison=comparison))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
