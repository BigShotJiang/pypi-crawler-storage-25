# Technical: 2. Entry Points

`dl-core` exposes several console entrypoints.

## `dl-core`

Creates local component scaffolds inside an experiment repository and lists or
describes registered components. `dl-core describe ...` now also includes a
minimal YAML snippet when the component has a direct config shape.

```bash
uv run dl-core list
uv run dl-core list sampler
uv run dl-core add augmentation Custom1
uv run dl-core add dataset LocalDataset
uv run dl-core add dataset FrameDataset --base frame
uv run dl-core add callback EpochLogger --base metric_logger
uv run dl-core add optimizer AdamwWrapper --base adamw
```

Useful flags:

- `--json` on `dl-core list`
- `--root-dir` on `dl-core list`
- `--base` for selecting a non-default scaffold base
- `--root-dir`
- `--force`

Dataset scaffold bases:

- plain `dl-core`: `base`, `frame`, `text_sequence`, `adaptive_computation`
- with `dl-azure`: `azure_compute`, `azure_streaming`,
  `azure_compute_frame`, `azure_streaming_frame`,
  `azure_compute_multiframe`, `azure_streaming_multiframe`

Non-dataset component scaffolds can also use `--base` with a registered
component name such as `metric_logger`, `standard`, `adamw`, or `cosine`,
or with a fully qualified class path.

Default-base scaffolds for augmentations, metrics, metric managers,
criterions, models, and executors now include ready-to-edit method stubs
instead of empty wrapper subclasses.

Built-in callback bases include `metric_logger` and `dataset_refresh`.

## `dl-init`

Creates a standalone experiment repository scaffold.

```bash
uv run dl-init --name my-exp --root-dir .
```

To initialize the target directory itself instead of creating a nested
subdirectory, omit `--name`:

```bash
uv run dl-init --root-dir .
```

Important arguments:

- `--name` (optional)
- `--root-dir`
- dynamically added extension flags such as `--with-azure`, `--with-mlflow`,
  and `--with-wandb` when the relevant extra package is installed

`dl-init-experiment` remains available as a compatibility alias for older
scripts.

## `dl-run`

Runs a single local training job through the local executor.

```bash
uv run dl-run --config configs/base.yaml
```

Useful flags:

- `--show-registry`
- `--validate-only`
- `--dry-run`
- `--log-level`

Notes:

- `--validate-only` now performs a lightweight preflight: it validates the
  config, resolves the configured components, safely instantiates the dataset,
  models, criterions, optimizer, and optional scheduler, then exits without
  starting training

## `dl-smoke`

Runs a lightweight one-batch dataset and model smoke check.

```bash
uv run dl-smoke --config configs/base.yaml
```

Useful flags:

- `--config`
- `--split`

## `dl-inspect-dataset`

Prints split sizes and one collated batch preview for the configured dataset.

```bash
uv run dl-inspect-dataset --config configs/base.yaml
```

Useful flags:

- `--config`
- `--sample-split`

Notes:

- preserves the configured split logic so the reported split sizes match the
  real dataset behavior
- forces single-process loading so inspection stays lightweight

## `dl-sweep`

Generates run configs from a sweep spec and dispatches them through the
configured executor.

```bash
uv run dl-sweep experiments/lr_sweep.yaml
uv run dl-sweep experiments/lr_sweep.yaml --only "*seed_2025*"
```

Useful flags:

- `--preview`
- `--export`
- `--only`
- `--skip`
- `--dry-run`
- `--resume`
- `--max-workers`
- `--compute`
- `--environment`

Notes:

- `--preview` prints the expanded sweep matrix and exits before saving configs
  or starting runs
- `--export preview.csv` or `--export preview.json` writes that matrix to disk
- `--only` and `--skip` accept repeatable run-name glob patterns
- `--dry-run` still goes through normal executor wiring, but does not execute
  the generated runs

## `dl-sync`

Synchronizes tracked run artifacts into the local repository when the active
backend supports artifact download.

```bash
uv run dl-sync --sweep experiments/lr_sweep.yaml --artifacts
```

Useful flags:

- `--sweep`
- `--artifacts`
- `--force`

Notes:

- local-backed sweeps simply refresh tracker paths from the local artifact tree
- remote-backed integrations can download artifact bundles and patch
  `sweep_tracking.json` with the resolved local paths

## `dl-analyze`

Reads local or backend-provided sweep tracking and writes a compact analysis
report.

```bash
uv run dl-analyze --sweep experiments/lr_sweep.yaml
uv run dl-analyze --sweep experiments/lr_sweep.yaml --name pareto_eer
uv run dl-analyze --sweep experiments/lr_sweep.yaml --compare latest
uv run dl-analyze --sweep experiments/lr_sweep.yaml --metric test/eer --mode min
uv run dl-analyze --sweep experiments/lr_sweep.yaml \
  --metric test/eer --mode min \
  --metric test/accuracy --mode max \
  --rank-method rank-sum
```

Useful flags:

- `--json`
- `--force`
- `--name`
- `--compare`
- `--metric`
- `--mode`
- `--rank-method`

Notes:

- ranking defaults to `test/accuracy` with `max`
- `--metric` and `--mode` are repeatable and matched by order
- fetched remote metric histories are cached in `analysis_cache.json`
- reports are written under `analysis/v1.md`, `analysis/v2.md`, and so on
- a matching JSON report is always written next to each Markdown report
- `--compare latest` or `--compare v1` compares the current analysis against a
  saved JSON report
- supported rank methods are `lexicographic`, `rank-sum`, and `pareto`

## `dl-train-worker`

Internal worker entrypoint used by executors. This is the direct trainer
process, not the normal user-facing entrypoint.

```bash
uv run dl-train-worker --config configs/base.yaml
```

In normal usage, prefer `dl-run` or `dl-sweep`.
