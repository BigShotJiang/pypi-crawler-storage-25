"""Connection factory registry — maps source types to their connection modules.

Replaces the 30-way if/elif chain in cli.py with a declarative lookup table.

Usage:
    from core.connections import get_connection
    conn, source_id = get_connection(cfg.source)
"""

from __future__ import annotations

import importlib
from contextlib import contextmanager
from typing import Any

from core.config import SourceConfig


# Registry: source_type → (module_path, connect_function, source_id_function)
CONNECTION_REGISTRY: dict[str, tuple[str, str, str]] = {
    "oracle": ("probes.oracle.connection", "connect", "source_id"),
    "postgres": ("probes.postgres.connection", "connect", "source_id"),
    "unity_catalog": ("probes.unity_catalog.connection", "get_client", "source_id"),
    "azure_data_factory": ("probes.azure_data_factory.connection", "get_client", "source_id"),
    "adls_gen2": ("probes.adls_gen2.connection", "get_client", "source_id"),
    "blob_storage": ("probes.blob_storage.connection", "get_client", "source_id"),
    "azure_file_share": ("probes.azure_file_share.connection", "get_client", "source_id"),
    "powerbi": ("probes.powerbi.connection", "get_models", "source_id"),
    "excel": ("probes.excel.connection", "get_workbooks", "source_id"),
    "tableau": ("probes.tableau.connection", "get_workbooks", "source_id"),
    "sharepoint": ("probes.sharepoint.connection", "get_client", "source_id"),
    "file_scanner": ("probes.file_scanner.connection", "get_path", "source_id"),
    "azure_sql": ("probes.azure_sql.connection", "connect", "source_id"),
    "sqlserver": ("probes.azure_sql.connection", "connect", "source_id"),
    "synapse": ("probes.azure_sql.connection", "connect", "source_id"),
    "snowflake": ("probes.snowflake.connection", "connect", "source_id"),
    "s3": ("probes.s3.connection", "get_client", "source_id"),
    "mysql": ("probes.mysql.connection", "connect", "source_id"),
    "mariadb": ("probes.mysql.connection", "connect", "source_id"),
    "duckdb": ("probes.duckdb.connection", "connect", "source_id"),
    "trino": ("probes.trino.connection", "connect", "source_id"),
    "bigquery": ("probes.bigquery.connection", "get_client", "source_id"),
    "db2": ("probes.db2.connection", "connect", "source_id"),
    "sap_hana": ("probes.sap_hana.connection", "connect", "source_id"),
    "teradata": ("probes.teradata.connection", "connect", "source_id"),
    "mongodb": ("probes.mongodb.connection", "get_client", "source_id"),
    "elasticsearch": ("probes.elasticsearch.connection", "get_client", "source_id"),
    "qlik": ("probes.qlik.connection", "get_apps", "source_id"),
    "sqlite": ("probes.sqlite.connection", "connect", "source_id"),
    "avro": ("probes.avro.connection", "get_path", "source_id"),
    "informatica_pc": ("probes.informatica_pc.connection", "get_exports", "source_id"),
    "powercenter": ("probes.informatica_pc.connection", "get_exports", "source_id"),
    "informatica_cloud": ("probes.informatica_cloud.connection", "get_client", "source_id"),
    "iics": ("probes.informatica_cloud.connection", "get_client", "source_id"),
    "collibra": ("probes.collibra.connection", "get_client", "source_id"),
    "purview": ("probes.purview.connection", "get_client", "source_id"),
    "blindata": ("probes.blindata.connection", "get_client", "source_id"),
    "witboost": ("probes.witboost.connection", "get_client", "source_id"),
    "airflow": ("probes.airflow.connection", "get_client", "source_id"),
    "alteryx": ("probes.alteryx.connection", "get_workflows", "source_id"),
    "python_transform": ("probes.python_transform.connection", "get_path", "source_id"),
    "oci": ("probes.oci.connection", "get_clients", "source_id"),
    "odi": ("probes.odi.connection", "get_exports", "source_id"),
    "dbt": ("probes.dbt.connection", "get_artifacts", "source_id"),
    "azure_rbac": ("probes.azure_rbac.connection", "get_client", "source_id"),
    "generic": ("probes.generic.connection", "get_path", "source_id"),
}


def get_connection(config: SourceConfig) -> tuple[Any, str]:
    """Connect to a data source using the registry.

    Returns (connection_object, source_id_string).
    Raises ConnectionError if source type is unknown or connection fails.
    """
    entry = CONNECTION_REGISTRY.get(config.type)
    if entry is None:
        raise ConnectionError(f"Unknown source type: {config.type}")

    module_path, connect_fn, sid_fn = entry
    mod = importlib.import_module(module_path)
    conn = getattr(mod, connect_fn)(config)
    sid = getattr(mod, sid_fn)(config)
    return conn, sid


def close_connection(conn: Any) -> None:
    """Safely close a connection object regardless of type."""
    if conn is None:
        return
    try:
        # pymongo Database → close underlying MongoClient
        if hasattr(conn, "client") and callable(getattr(conn.client, "close", None)):
            conn.client.close()
        elif callable(getattr(conn, "close", None)):
            conn.close()
    except Exception:
        pass


@contextmanager
def open_connection(config: SourceConfig):
    """Context manager for safe connection lifecycle.

    Usage:
        with open_connection(cfg.source) as (conn, sid):
            result = probe.run(conn, schema, source_id=sid)
    """
    conn, sid = get_connection(config)
    try:
        yield conn, sid
    finally:
        close_connection(conn)
