"""Pull-mode daemon — serves probe results via HTTP REST API.

Runs as a lightweight server inside the customer network.
External platforms call GET /probes/{pattern} to fetch metadata on demand.

Usage:
  metapod serve --port 9090 --config config.yaml
  # Then from any consumer:
  curl http://metapod-host:9090/probes/oracle.metadata.tables
  curl http://metapod-host:9090/probes/oracle.*
  curl http://metapod-host:9090/catalog
"""

from __future__ import annotations

import json
import logging
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from core.base_probe import ProbeResult
from core.config import ProbeConfig, SourceConfig, load_config
from core.registry import discover_probes, get_probes, list_probes

logger = logging.getLogger("metapod.server")

_config: ProbeConfig | None = None
_connection = None
_cache: dict[str, tuple[float, ProbeResult]] = {}
_cache_ttl: int = 300  # seconds
_api_key: str = ""  # Optional auth
_metrics: dict = {"requests": 0, "probes_run": 0, "errors": 0, "started_at": ""}


def start_server(config_path: str, port: int = 9090, cache_ttl: int = 300, api_key: str = ""):
    """Start the pull-mode HTTP server."""
    global _config, _connection, _cache_ttl, _api_key
    _cache_ttl = cache_ttl
    _api_key = api_key
    _metrics["started_at"] = __import__("datetime").datetime.now().isoformat()

    discover_probes()

    try:
        _config = load_config(config_path)
    except FileNotFoundError:
        _config = ProbeConfig(source=SourceConfig(type="file_scanner"))

    _connect()

    server = HTTPServer(("0.0.0.0", port), _Handler)
    logger.info("metapod daemon listening on port %d", port)
    logger.info("  Source: %s, Cache TTL: %ds, Probes: %d",
                _config.source.type, cache_ttl, len(list_probes("*")))
    logger.info("  Endpoints: /catalog, /probes/{pattern}, /health, /metrics")
    server.serve_forever()


def _connect():
    """Establish connection based on config."""
    global _connection
    if not _config:
        return
    try:
        from core.connections import get_connection
        _connection, _ = get_connection(_config.source)
    except Exception as e:
        logger.warning("Connection failed (%s), running in offline mode", e)
        _connection = None


class _Handler(BaseHTTPRequestHandler):
    """HTTP request handler for pull-mode daemon."""

    def do_GET(self):
        _metrics["requests"] += 1

        # Auth check
        if _api_key:
            auth = self.headers.get("Authorization", "")
            if auth != f"Bearer {_api_key}" and auth != _api_key:
                self._json(401, {"error": "Unauthorized. Provide Authorization: Bearer <key>"})
                return

        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")

        if path == "/metrics":
            self._json(200, _metrics)

        elif path == "/health":
            self._json(200, {"status": "ok", "probes": len(list_probes("*")),
                             "source": _config.source.type if _config else "none"})

        elif path == "/catalog":
            probes = list_probes("*")
            self._json(200, {"probes": probes, "count": len(probes)})

        elif path.startswith("/probes/"):
            pattern = path[len("/probes/"):]
            self._run_probes(pattern)

        else:
            self._json(404, {"error": "Not found. Use /catalog, /probes/{pattern}, or /health"})

    def _run_probes(self, pattern: str):
        """Run matching probes, using cache if available."""
        now = time.time()

        # Check cache
        if pattern in _cache:
            cached_at, cached_result = _cache[pattern]
            if now - cached_at < _cache_ttl:
                self._json(200, {"cached": True, **cached_result.to_dict()})
                return

        probe_classes = get_probes(pattern)
        if not probe_classes:
            self._json(404, {"error": f"No probes matching '{pattern}'",
                             "available": list_probes("*")[:20]})
            return

        all_records = []
        for cls in probe_classes:
            probe = cls()
            result = probe.run(
                _connection,
                _config.source.schema_name if _config else "",
                source_id=_config.source.type if _config else "local",
            )
            all_records.append(result.to_dict())

            _metrics["probes_run"] += 1
            if result.error:
                _metrics["errors"] += 1
            _cache[probe.probe_name()] = (now, result)

        # Cache pattern result
        combined = ProbeResult(
            probe=pattern, source_type=_config.source.type if _config else "local",
            source_id="daemon", records=[r for res in all_records for r in res.get("records", [])],
            record_count=sum(r.get("record_count", 0) for r in all_records),
        )
        _cache[pattern] = (now, combined)

        if len(all_records) == 1:
            self._json(200, all_records[0])
        else:
            self._json(200, {"pattern": pattern, "probe_count": len(all_records), "results": all_records})

    def _json(self, status: int, data: dict):
        body = json.dumps(data, default=str, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        """Quieter logging."""
        pass
