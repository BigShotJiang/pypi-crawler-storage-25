"""Azure resource provisioning for metapod probe testing.

Creates all Azure resources needed to test the 18 Azure probes,
generates config files, uploads sample data, and tears down everything.

Requires: az CLI logged in (az login).

Usage (via CLI):
    metapod provision azure --region westeurope
    metapod provision azure --teardown
"""

from __future__ import annotations

import csv
import io
import json
import os
import random
import string
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ProvisionResult:
    """Result of a provisioning run."""
    resource_group: str = ""
    storage_account: str = ""
    storage_key: str = ""
    sql_server: str = ""
    sql_database: str = ""
    sql_admin: str = "metapod_admin"
    sql_password: str = ""
    adf_name: str = ""
    subscription_id: str = ""
    tenant_id: str = ""
    region: str = ""
    configs_generated: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "sql_password"}
        d["sql_password"] = "***"
        return d


def _run_az(args: list[str], check: bool = True) -> dict | list | str:
    """Run an az CLI command and return parsed JSON output."""
    cmd = ["az"] + args + ["--output", "json"]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        err = result.stderr.strip()
        if check:
            raise RuntimeError(f"az {' '.join(args[:3])}... failed: {err}")
        return {"error": err}
    if not result.stdout.strip():
        return {}
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return result.stdout.strip()


def _run_az_raw(args: list[str]) -> str:
    """Run az CLI and return raw stdout."""
    cmd = ["az"] + args
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        raise RuntimeError(f"az {' '.join(args[:3])}... failed: {result.stderr.strip()}")
    return result.stdout.strip()


def _random_suffix(length: int = 6) -> str:
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))


def _generate_password(length: int = 20) -> str:
    """Generate a strong password meeting Azure SQL requirements."""
    chars = string.ascii_letters + string.digits + "!@#$%"
    while True:
        pwd = "".join(random.choices(chars, k=length))
        has_upper = any(c.isupper() for c in pwd)
        has_lower = any(c.islower() for c in pwd)
        has_digit = any(c.isdigit() for c in pwd)
        has_special = any(c in "!@#$%" for c in pwd)
        if has_upper and has_lower and has_digit and has_special:
            return pwd


# ── Check prerequisites ─────────────────────────────────────

def _load_env(env_path: Path | None = None) -> None:
    """Load .env file into os.environ (simple key=value parser)."""
    candidates = [env_path] if env_path else [
        Path(__file__).parent.parent / ".env",
        Path.cwd() / ".env",
    ]
    for p in candidates:
        if p and p.exists():
            for line in p.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())
            break


def ensure_az_login() -> dict:
    """Log in via service principal from .env if not already logged in, then return account info."""
    _load_env()

    # Check if already logged in
    try:
        account = _run_az(["account", "show"])
        return {
            "logged_in": True,
            "subscription_id": account.get("id", ""),
            "subscription_name": account.get("name", ""),
            "tenant_id": account.get("tenantId", ""),
            "user": account.get("user", {}).get("name", ""),
        }
    except (RuntimeError, FileNotFoundError):
        pass

    # Try service principal login from env vars
    client_id = os.environ.get("AZURE_CLIENT_ID", "")
    client_secret = os.environ.get("AZURE_CLIENT_SECRET", "")
    tenant_id = os.environ.get("AZURE_TENANT_ID", "")

    if client_id and client_secret and tenant_id:
        try:
            _run_az([
                "login", "--service-principal",
                "--username", client_id,
                "--password", client_secret,
                "--tenant", tenant_id,
            ])
            account = _run_az(["account", "show"])
            return {
                "logged_in": True,
                "subscription_id": account.get("id", ""),
                "subscription_name": account.get("name", ""),
                "tenant_id": account.get("tenantId", ""),
                "user": account.get("user", {}).get("name", ""),
                "auth_method": "service_principal",
            }
        except RuntimeError as e:
            return {"logged_in": False, "error": f"Service principal login failed: {e}"}

    return {"logged_in": False, "error": "Run 'az login' or set AZURE_CLIENT_ID/SECRET/TENANT_ID in .env"}


# Keep old name as alias for backward compat
check_az_login = ensure_az_login


# ── Provision ────────────────────────────────────────────────

def provision_azure(
    region: str = "westeurope",
    prefix: str = "metapod",
    output_dir: str = "./configs",
    callback=None,
) -> ProvisionResult:
    """Provision all Azure resources for testing metapod probes.

    Creates:
    1. Resource Group
    2. Storage Account (Blob + ADLS Gen2 + File Share)
    3. Azure SQL Database
    4. Azure Data Factory

    Args:
        region: Azure region
        prefix: Name prefix for resources
        output_dir: Where to write generated config files
        callback: Optional callable(step, message) for progress updates
    """
    def _log(step: str, msg: str):
        if callback:
            callback(step, msg)

    result = ProvisionResult(region=region)
    suffix = _random_suffix()
    rg_name = f"{prefix}-test-{suffix}"
    storage_name = f"{prefix}st{suffix}"  # Storage accounts: lowercase alphanumeric only
    sql_server_name = f"{prefix}-sql-{suffix}"
    sql_db_name = f"{prefix}-testdb"
    adf_name = f"{prefix}-adf-{suffix}"

    # Get subscription info
    _log("auth", "Checking Azure login...")
    account_info = check_az_login()
    if not account_info.get("logged_in"):
        result.errors.append("Not logged in. Run: az login")
        return result

    result.subscription_id = account_info["subscription_id"]
    result.tenant_id = account_info["tenant_id"]
    _log("auth", f"Logged in as {account_info['user']} ({account_info['subscription_name']})")

    # 1. Resource Group
    _log("resource_group", f"Creating resource group {rg_name}...")
    try:
        _run_az(["group", "create", "--name", rg_name, "--location", region])
        result.resource_group = rg_name
    except RuntimeError as e:
        result.errors.append(f"Resource group: {e}")
        return result

    # 2. Storage Account (hierarchical namespace = ADLS Gen2)
    _log("storage", f"Creating storage account {storage_name} (ADLS Gen2 enabled)...")
    try:
        _run_az([
            "storage", "account", "create",
            "--name", storage_name,
            "--resource-group", rg_name,
            "--location", region,
            "--sku", "Standard_LRS",
            "--kind", "StorageV2",
            "--hns", "true",  # Enables ADLS Gen2
            "--allow-blob-public-access", "false",
        ])
        result.storage_account = storage_name

        # Get storage key
        keys = _run_az([
            "storage", "account", "keys", "list",
            "--account-name", storage_name,
            "--resource-group", rg_name,
        ])
        result.storage_key = keys[0]["value"]

        # Create blob container
        _log("storage", "Creating blob container 'test-container'...")
        _run_az([
            "storage", "container", "create",
            "--name", "test-container",
            "--account-name", storage_name,
            "--account-key", result.storage_key,
        ])

        # Create ADLS filesystem
        _log("storage", "Creating ADLS filesystem 'test-fs'...")
        _run_az([
            "storage", "fs", "create",
            "--name", "test-fs",
            "--account-name", storage_name,
            "--account-key", result.storage_key,
        ])

        # Create file share
        _log("storage", "Creating file share 'test-share'...")
        _run_az([
            "storage", "share-rm", "create",
            "--name", "test-share",
            "--storage-account", storage_name,
            "--resource-group", rg_name,
            "--quota", "1",  # 1 GB
        ])

        # Upload sample data
        _log("storage", "Uploading sample data...")
        _upload_sample_data(storage_name, result.storage_key)

    except RuntimeError as e:
        result.errors.append(f"Storage: {e}")

    # 3. Azure SQL
    _log("sql", f"Creating Azure SQL server {sql_server_name}...")
    sql_password = _generate_password()
    try:
        _run_az([
            "sql", "server", "create",
            "--name", sql_server_name,
            "--resource-group", rg_name,
            "--location", region,
            "--admin-user", "metapod_admin",
            "--admin-password", sql_password,
        ])
        result.sql_server = f"{sql_server_name}.database.windows.net"
        result.sql_password = sql_password

        # Allow Azure services
        _log("sql", "Configuring firewall (allow Azure services)...")
        _run_az([
            "sql", "server", "firewall-rule", "create",
            "--resource-group", rg_name,
            "--server", sql_server_name,
            "--name", "AllowAzureServices",
            "--start-ip-address", "0.0.0.0",
            "--end-ip-address", "0.0.0.0",
        ])

        # Allow current IP
        _log("sql", "Adding current IP to firewall...")
        try:
            my_ip = _run_az_raw(["network", "public-ip", "list", "--query", "[0].ipAddress", "--output", "tsv"])
        except RuntimeError:
            # Fallback: try to get IP from external service
            try:
                import urllib.request
                my_ip = urllib.request.urlopen("https://ifconfig.me", timeout=5).read().decode().strip()
            except Exception:
                my_ip = ""

        if my_ip and my_ip.replace(".", "").isdigit():
            _run_az([
                "sql", "server", "firewall-rule", "create",
                "--resource-group", rg_name,
                "--server", sql_server_name,
                "--name", "AllowCurrentIP",
                "--start-ip-address", my_ip,
                "--end-ip-address", my_ip,
            ], check=False)

        # Create database
        _log("sql", f"Creating database {sql_db_name} (Basic tier)...")
        _run_az([
            "sql", "db", "create",
            "--resource-group", rg_name,
            "--server", sql_server_name,
            "--name", sql_db_name,
            "--edition", "Basic",
            "--capacity", "5",
        ])
        result.sql_database = sql_db_name

        # Create sample tables
        _log("sql", "Creating sample schema...")
        _create_sample_sql_schema(result)

    except RuntimeError as e:
        result.errors.append(f"SQL: {e}")

    # 4. Azure Data Factory
    _log("adf", f"Creating Data Factory {adf_name}...")
    try:
        _run_az([
            "datafactory", "create",
            "--resource-group", rg_name,
            "--factory-name", adf_name,
            "--location", region,
        ])
        result.adf_name = adf_name

        # Create linked service to storage
        if result.storage_account:
            _log("adf", "Creating linked service → storage account...")
            ls_payload = json.dumps({
                "type": "AzureBlobStorage",
                "typeProperties": {
                    "connectionString": f"DefaultEndpointsProtocol=https;AccountName={storage_name};AccountKey={result.storage_key};EndpointSuffix=core.windows.net"
                }
            })
            _run_az([
                "datafactory", "linked-service", "create",
                "--resource-group", rg_name,
                "--factory-name", adf_name,
                "--linked-service-name", "StorageLinkedService",
                "--properties", ls_payload,
            ], check=False)

        # Create a simple pipeline
        _log("adf", "Creating sample pipeline...")
        pipeline_payload = json.dumps({
            "activities": [{
                "name": "WaitActivity",
                "type": "Wait",
                "typeProperties": {"waitTimeInSeconds": 1}
            }]
        })
        _run_az([
            "datafactory", "pipeline", "create",
            "--resource-group", rg_name,
            "--factory-name", adf_name,
            "--pipeline-name", "SamplePipeline",
            "--pipeline", pipeline_payload,
        ], check=False)

    except RuntimeError as e:
        result.errors.append(f"ADF: {e}")

    # 5. Generate config files
    _log("configs", "Generating config files...")
    configs_dir = Path(output_dir)
    configs_dir.mkdir(parents=True, exist_ok=True)
    result.configs_generated = _generate_configs(result, configs_dir)

    # 6. Save provisioning state (for teardown)
    state_path = configs_dir / ".provision_state.json"
    state_path.write_text(json.dumps(result.to_dict(), indent=2))
    _log("done", f"Provisioning complete! State saved to {state_path}")

    return result


# ── Sample data upload ───────────────────────────────────────

def _upload_sample_data(storage_name: str, storage_key: str):
    """Upload sample CSV and JSON files to all three storage services."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        # Sample CSV
        csv_path = Path(tmp) / "customers.csv"
        csv_path.write_text(
            "id,name,email,country,revenue\n"
            "1,Acme Corp,acme@example.com,IT,1500000\n"
            "2,Globex Inc,globex@example.com,US,2300000\n"
            "3,Initech,initech@example.com,UK,870000\n"
            "4,Umbrella Corp,umbrella@example.com,DE,4100000\n"
            "5,Stark Industries,stark@example.com,US,9800000\n"
        )

        # Sample JSON
        json_path = Path(tmp) / "orders.json"
        json_path.write_text(json.dumps([
            {"order_id": 1001, "customer_id": 1, "product": "Widget A", "amount": 150.0, "date": "2026-01-15"},
            {"order_id": 1002, "customer_id": 2, "product": "Widget B", "amount": 320.5, "date": "2026-02-01"},
            {"order_id": 1003, "customer_id": 1, "product": "Gadget X", "amount": 89.99, "date": "2026-02-10"},
            {"order_id": 1004, "customer_id": 3, "product": "Widget A", "amount": 150.0, "date": "2026-03-01"},
        ], indent=2))

        # Partitioned parquet-like structure (just CSV for now)
        part_dir = Path(tmp) / "events" / "year=2026" / "month=01"
        part_dir.mkdir(parents=True)
        (part_dir / "part-00000.csv").write_text(
            "event_id,event_type,timestamp\n"
            "e1,click,2026-01-01T10:00:00\n"
            "e2,view,2026-01-01T10:05:00\n"
        )

        # Upload to blob
        for f in [csv_path, json_path]:
            _run_az([
                "storage", "blob", "upload",
                "--account-name", storage_name,
                "--account-key", storage_key,
                "--container-name", "test-container",
                "--file", str(f),
                "--name", f"data/{f.name}",
                "--overwrite",
            ], check=False)

        # Upload to ADLS
        for f in [csv_path, json_path]:
            _run_az([
                "storage", "fs", "file", "upload",
                "--account-name", storage_name,
                "--account-key", storage_key,
                "--file-system", "test-fs",
                "--source", str(f),
                "--path", f"raw/{f.name}",
                "--overwrite",
            ], check=False)

        # Upload to file share
        _run_az([
            "storage", "directory", "create",
            "--account-name", storage_name,
            "--account-key", storage_key,
            "--share-name", "test-share",
            "--name", "data",
        ], check=False)

        for f in [csv_path, json_path]:
            _run_az([
                "storage", "file", "upload",
                "--account-name", storage_name,
                "--account-key", storage_key,
                "--share-name", "test-share",
                "--source", str(f),
                "--path", f"data/{f.name}",
            ], check=False)


# ── Sample SQL schema ────────────────────────────────────────

def _create_sample_sql_schema(result: ProvisionResult):
    """Create sample tables/views/procedures in Azure SQL."""
    sql_statements = """
    CREATE TABLE dbo.customers (
        id INT PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        email NVARCHAR(200),
        country NVARCHAR(50),
        revenue DECIMAL(15,2),
        created_at DATETIME2 DEFAULT GETUTCDATE()
    );

    CREATE TABLE dbo.orders (
        order_id INT PRIMARY KEY,
        customer_id INT NOT NULL,
        product NVARCHAR(100),
        amount DECIMAL(10,2),
        order_date DATE,
        CONSTRAINT FK_orders_customer FOREIGN KEY (customer_id) REFERENCES dbo.customers(id)
    );

    CREATE TABLE dbo.products (
        product_id INT PRIMARY KEY IDENTITY(1,1),
        name NVARCHAR(100) NOT NULL,
        category NVARCHAR(50),
        price DECIMAL(10,2),
        stock INT DEFAULT 0,
        CONSTRAINT UQ_product_name UNIQUE (name)
    );

    INSERT INTO dbo.customers VALUES
        (1, 'Acme Corp', 'acme@example.com', 'IT', 1500000, GETUTCDATE()),
        (2, 'Globex Inc', 'globex@example.com', 'US', 2300000, GETUTCDATE()),
        (3, 'Initech', 'initech@example.com', 'UK', 870000, GETUTCDATE());

    INSERT INTO dbo.orders VALUES
        (1001, 1, 'Widget A', 150.00, '2026-01-15'),
        (1002, 2, 'Widget B', 320.50, '2026-02-01'),
        (1003, 1, 'Gadget X', 89.99, '2026-02-10');

    INSERT INTO dbo.products (name, category, price, stock) VALUES
        ('Widget A', 'Widgets', 150.00, 500),
        ('Widget B', 'Widgets', 320.50, 200),
        ('Gadget X', 'Gadgets', 89.99, 1000);

    CREATE VIEW dbo.v_customer_orders AS
    SELECT c.name AS customer_name, c.country,
           o.order_id, o.product, o.amount, o.order_date
    FROM dbo.customers c
    JOIN dbo.orders o ON c.id = o.customer_id;

    CREATE PROCEDURE dbo.sp_get_top_customers
        @min_revenue DECIMAL(15,2) = 1000000
    AS
    BEGIN
        SELECT name, email, country, revenue
        FROM dbo.customers
        WHERE revenue >= @min_revenue
        ORDER BY revenue DESC;
    END;
    """

    # Use sqlcmd via az sql to execute
    for stmt in sql_statements.strip().split(";"):
        stmt = stmt.strip()
        if not stmt:
            continue
        _run_az([
            "sql", "db", "execute",
            "--resource-group", result.resource_group,
            "--server-name", result.sql_server.replace(".database.windows.net", ""),
            "--database-name", result.sql_database,
            "--admin-user", result.sql_admin,
            "--admin-password", result.sql_password,
            "--sql-text", stmt + ";",
        ], check=False)


# ── Config generation ────────────────────────────────────────

def _generate_configs(result: ProvisionResult, output_dir: Path) -> list[str]:
    """Generate metapod config files for all provisioned services."""
    generated = []

    if result.storage_account and result.storage_key:
        # Blob Storage
        _write_config(output_dir / "config-blob.yaml", {
            "source": {
                "type": "blob_storage",
                "host": result.storage_account,
                "token": result.storage_key,
                "schema_name": "test-container",
            }
        })
        generated.append("config-blob.yaml")

        # ADLS Gen2
        _write_config(output_dir / "config-adls.yaml", {
            "source": {
                "type": "adls_gen2",
                "host": result.storage_account,
                "token": result.storage_key,
                "schema_name": "test-fs",
            }
        })
        generated.append("config-adls.yaml")

        # Azure File Share
        _write_config(output_dir / "config-fileshare.yaml", {
            "source": {
                "type": "azure_file_share",
                "host": result.storage_account,
                "token": result.storage_key,
                "schema_name": "test-share",
            }
        })
        generated.append("config-fileshare.yaml")

    if result.sql_server and result.sql_database:
        _write_config(output_dir / "config-azuresql.yaml", {
            "source": {
                "type": "azure_sql",
                "host": result.sql_server,
                "service_name": result.sql_database,
                "username": result.sql_admin,
                "password": result.sql_password,
            }
        })
        generated.append("config-azuresql.yaml")

    if result.adf_name:
        _write_config(output_dir / "config-adf.yaml", {
            "source": {
                "type": "azure_data_factory",
                "sid": result.subscription_id,
                "host": result.tenant_id,
                "service_name": result.resource_group,
                "schema_name": result.adf_name,
            }
        })
        generated.append("config-adf.yaml")

    # Master config for running all Azure probes
    _write_config(output_dir / "config-all-azure.yaml", {
        "note": "Use individual configs per probe group (see other files)",
        "resource_group": result.resource_group,
        "region": result.region,
        "services": {
            "blob_storage": f"config-blob.yaml",
            "adls_gen2": f"config-adls.yaml",
            "azure_file_share": f"config-fileshare.yaml",
            "azure_sql": f"config-azuresql.yaml",
            "azure_data_factory": f"config-adf.yaml",
        }
    })
    generated.append("config-all-azure.yaml")

    return generated


def _write_config(path: Path, data: dict):
    """Write a YAML config file."""
    import yaml
    path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False), encoding="utf-8")


# ── Teardown ─────────────────────────────────────────────────

def teardown_azure(
    resource_group: str = "",
    state_file: str = "",
    callback=None,
) -> bool:
    """Delete all provisioned Azure resources.

    Provide either resource_group name directly or path to .provision_state.json.
    """
    def _log(step: str, msg: str):
        if callback:
            callback(step, msg)

    if not resource_group and state_file:
        state_path = Path(state_file)
        if state_path.exists():
            state = json.loads(state_path.read_text())
            resource_group = state.get("resource_group", "")

    if not resource_group:
        _log("error", "No resource group specified")
        return False

    _log("teardown", f"Deleting resource group {resource_group} and ALL its resources...")
    try:
        _run_az([
            "group", "delete",
            "--name", resource_group,
            "--yes",
            "--no-wait",
        ])
        _log("teardown", f"Deletion initiated for {resource_group} (runs in background)")
        return True
    except RuntimeError as e:
        _log("error", str(e))
        return False


# ── Test runner ──────────────────────────────────────────────

def run_azure_probes(configs_dir: str = "./configs", output_dir: str = "./output") -> dict:
    """Run all Azure probes using generated configs. Returns results summary."""
    configs = Path(configs_dir)
    results = {}

    probe_groups = [
        ("blob_storage.*", "config-blob.yaml"),
        ("adls_gen2.*", "config-adls.yaml"),
        ("azure_file_share.*", "config-fileshare.yaml"),
        ("azure_sql.metadata.*", "config-azuresql.yaml"),
        ("azure_data_factory.*", "config-adf.yaml"),
    ]

    for pattern, config_file in probe_groups:
        config_path = configs / config_file
        if not config_path.exists():
            results[pattern] = {"status": "skipped", "reason": f"{config_file} not found"}
            continue

        try:
            proc = subprocess.run(
                ["python3", "cli.py", "run", pattern,
                 "--config", str(config_path),
                 "--output", output_dir,
                 "--delta"],
                capture_output=True, text=True, timeout=120,
                cwd=str(Path(__file__).parent.parent),
            )
            results[pattern] = {
                "status": "ok" if proc.returncode == 0 else "error",
                "returncode": proc.returncode,
                "stdout": proc.stdout[-500:] if proc.stdout else "",
                "stderr": proc.stderr[-500:] if proc.stderr else "",
            }
        except subprocess.TimeoutExpired:
            results[pattern] = {"status": "timeout"}
        except Exception as e:
            results[pattern] = {"status": "error", "error": str(e)}

    return results
