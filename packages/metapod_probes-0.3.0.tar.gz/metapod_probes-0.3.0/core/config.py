"""Configuration loader — YAML + environment variables."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel


class SourceConfig(BaseModel):
    type: str  # oracle, postgres, databricks, unity_catalog
    host: str = "localhost"
    port: int = 1521
    service_name: str = ""
    sid: str = ""
    username: str = ""
    password: str = ""
    schema_name: str = ""
    # Databricks/Azure
    workspace_url: str = ""
    token: str = ""
    catalog: str = ""


class TargetConfig(BaseModel):
    url: str = ""  # target API URL (e.g., https://your-platform.example.com)
    api_key: str = ""
    project: str = "default"


class ProbeConfig(BaseModel):
    source: SourceConfig
    target: TargetConfig = TargetConfig()
    output_dir: str = "./output"
    probes: list[str] = ["*"]  # Probe patterns to run (e.g., ["oracle.metadata.*"])
    schedule: str = ""  # Cron expression (empty = one-shot)


def load_config(path: str | Path) -> ProbeConfig:
    """Load config from YAML file with environment variable substitution.

    Supports ${VAR_NAME} syntax in string values.
    """
    import os

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config not found: {p}")

    raw = p.read_text()
    # Expand ${VAR} patterns from environment
    raw = os.path.expandvars(raw)
    data = yaml.safe_load(raw)
    return ProbeConfig(**data)
