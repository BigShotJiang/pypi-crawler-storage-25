"""Standard output models for probe records.

Every probe should return records conforming to these schemas.
Consumers can trust the field names and types.
"""

from __future__ import annotations

from pydantic import BaseModel


class TableRecord(BaseModel):
    """Standard table metadata record."""
    table_name: str
    table_type: str = "TABLE"  # TABLE, VIEW, MATERIALIZED_VIEW
    schema: str = ""
    row_count: int | None = None
    size_bytes: int | None = None
    created: str | None = None
    modified: str | None = None
    comment: str = ""


class ColumnRecord(BaseModel):
    """Standard column metadata record."""
    table_name: str
    column_name: str
    data_type: str = ""
    max_length: int | None = None
    precision: int | None = None
    scale: int | None = None
    nullable: bool = True
    ordinal_position: int = 0
    default_value: str | None = None
    comment: str = ""


class ViewRecord(BaseModel):
    """Standard view definition record."""
    view_name: str
    sql_text: str = ""
    schema: str = ""
    created: str | None = None
    comment: str = ""


class RoutineRecord(BaseModel):
    """Standard procedure/function record."""
    name: str
    routine_type: str = ""  # PROCEDURE, FUNCTION, TRIGGER, PACKAGE BODY
    language: str = ""
    source_code: str = ""
    line_count: int = 0
    created: str | None = None


class ConstraintRecord(BaseModel):
    """Standard constraint record."""
    constraint_name: str
    constraint_type: str = ""  # PRIMARY_KEY, FOREIGN_KEY, UNIQUE
    table_name: str = ""
    column_name: str = ""
    position: int = 0
    ref_table: str | None = None
    ref_column: str | None = None


class IndexRecord(BaseModel):
    """Standard index record."""
    index_name: str
    table_name: str = ""
    index_type: str = ""
    uniqueness: str = ""
    column_name: str = ""
    column_position: int = 0


class LineageRecord(BaseModel):
    """Standard lineage edge record."""
    source_table: str = ""
    source_column: str = ""
    target_table: str = ""
    target_column: str = ""
    transformation: str = ""
    lineage_type: str = "column"  # column, table


class DatasetRecord(BaseModel):
    """Standard file/dataset record (for cloud storage scans)."""
    name: str
    path: str = ""
    format: str = ""
    size_bytes: int = 0
    file_count: int = 1
    partition_type: str = ""
    partition_count: int = 0


class ConnectionRecord(BaseModel):
    """Standard connection/data source record."""
    name: str
    connection_type: str = ""
    host: str = ""
    database: str = ""
    schema: str = ""
    description: str = ""
