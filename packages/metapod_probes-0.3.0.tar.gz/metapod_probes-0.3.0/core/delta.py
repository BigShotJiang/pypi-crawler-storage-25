"""Delta engine — mtime/hash-based incremental extraction for any probe.

Wraps any probe with state persistence. On each run:
1. Load previous state (resource → last_seen metadata)
2. For each record, check if changed since last run
3. Emit only changed/new/deleted records
4. Save new state

Change detection strategies (auto-selected per resource type):
- MTIME: compare modification timestamp (files, dirs, cloud objects)
- DDL_TIME: compare DDL modification time (database tables, views)
- ROW_COUNT: compare row count (quick drift detection)
- HASH: compare content hash (procedures, view definitions)
- ETAG: compare HTTP ETag header (API resources)
- ALWAYS: always re-extract (no delta, fallback)

Usage:
    engine = DeltaEngine(state_path="./output/.metapod_state.json")
    result = engine.run(probe, connection, schema)
    # result.records contains only changed records
    # result.delta_stats shows: new, modified, deleted, unchanged, skipped
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from core.base_probe import BaseProbe, ProbeResult


@dataclass
class ResourceState:
    """State of a single resource (table, file, view, etc.) from last scan."""
    key: str  # Unique identifier (e.g., table_name, file_path)
    mtime: float = 0.0  # Modification timestamp
    size: int = 0  # Size (bytes or row count)
    hash: str = ""  # Content hash (for source code, SQL definitions)
    etag: str = ""  # HTTP ETag
    scan_time: str = ""  # When this was last scanned

    def to_dict(self) -> dict:
        return {"key": self.key, "mtime": self.mtime, "size": self.size,
                "hash": self.hash, "etag": self.etag, "scan_time": self.scan_time}

    @classmethod
    def from_dict(cls, d: dict) -> ResourceState:
        return cls(**{k: d.get(k, v) for k, v in cls.__dataclass_fields__.items() if k in d})


@dataclass
class DeltaState:
    """Full delta state persisted between runs."""
    probe_name: str = ""
    last_scan: str = ""
    scan_count: int = 0
    resources: dict[str, ResourceState] = field(default_factory=dict)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "probe_name": self.probe_name, "last_scan": self.last_scan,
            "scan_count": self.scan_count,
            "resources": {k: v.to_dict() for k, v in self.resources.items()},
        }
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, default=str), encoding="utf-8")
        tmp.rename(path)

    @classmethod
    def load(cls, path: Path) -> DeltaState:
        if not path.exists():
            return cls()
        data = json.loads(path.read_text())
        return cls(
            probe_name=data.get("probe_name", ""),
            last_scan=data.get("last_scan", ""),
            scan_count=data.get("scan_count", 0),
            resources={k: ResourceState.from_dict(v) for k, v in data.get("resources", {}).items()},
        )


@dataclass
class DeltaStats:
    """Statistics from a delta-aware probe run."""
    new: int = 0
    modified: int = 0
    deleted: int = 0
    unchanged: int = 0
    total_previous: int = 0
    total_current: int = 0
    skipped: bool = False  # True if entire probe was skipped (no changes)


# ── Change detection key extraction ─────────────────────────

# Map of record field names to detection strategy
MTIME_FIELDS = ("last_modified", "modified", "last_analyzed", "altered", "last_altered",
                "create_date", "modify_date", "update_time", "last_run_time")
SIZE_FIELDS = ("row_count", "num_rows", "size_bytes", "size", "record_count")
HASH_FIELDS = ("sql_text", "source_code", "definition", "view_definition", "expression")
KEY_FIELDS = ("table_name", "name", "view_name", "column_name", "index_name",
              "constraint_name", "id", "key", "path", "qualified_name", "routine_id")


def _extract_key(record: dict) -> str:
    """Extract a unique key from a record."""
    for k in KEY_FIELDS:
        if k in record and record[k]:
            return str(record[k])
    return hashlib.md5(json.dumps(record, sort_keys=True, default=str).encode()).hexdigest()


def _extract_state(record: dict) -> ResourceState:
    """Extract change-detection metadata from a record."""
    key = _extract_key(record)
    mtime = 0.0
    for f in MTIME_FIELDS:
        if f in record and record[f]:
            try:
                val = record[f]
                if isinstance(val, (int, float)):
                    mtime = float(val)
                elif isinstance(val, str):
                    mtime = datetime.fromisoformat(val.replace("Z", "+00:00")).timestamp()
            except (ValueError, TypeError):
                pass
            if mtime > 0:
                break

    size = 0
    for f in SIZE_FIELDS:
        if f in record and record[f]:
            try:
                size = int(record[f])
            except (ValueError, TypeError):
                pass
            if size > 0:
                break

    content_hash = ""
    for f in HASH_FIELDS:
        if f in record and record[f]:
            content_hash = hashlib.md5(str(record[f]).encode()).hexdigest()
            break

    return ResourceState(key=key, mtime=mtime, size=size, hash=content_hash,
                         scan_time=datetime.now(timezone.utc).isoformat())


def _has_changed(prev: ResourceState, curr: ResourceState) -> bool:
    """Determine if a resource has changed between scans."""
    # Hash comparison (strongest signal — source code, SQL)
    if prev.hash and curr.hash and prev.hash != curr.hash:
        return True
    # mtime comparison (files, DDL)
    if prev.mtime > 0 and curr.mtime > 0 and abs(prev.mtime - curr.mtime) > 0.5:
        return True
    # Size comparison (row count, file size)
    if prev.size > 0 and curr.size > 0 and prev.size != curr.size:
        return True
    # If no signals available, assume unchanged
    if prev.hash == curr.hash and prev.mtime == curr.mtime and prev.size == curr.size:
        return False
    # If we have no previous signals at all, consider changed
    return prev.hash == "" and prev.mtime == 0 and prev.size == 0


class DeltaEngine:
    """Wraps any probe with delta state management.

    Usage:
        engine = DeltaEngine(state_dir=Path("./output/.delta"))
        result, stats = engine.run(probe, connection, schema, source_id="prod-db")

        # result.records contains only NEW + MODIFIED records
        # stats shows: new=5, modified=2, deleted=1, unchanged=100
    """

    def __init__(self, state_dir: Path = Path("./output/.delta")):
        self._state_dir = state_dir

    def run(
        self, probe: BaseProbe, connection: Any, schema: str,
        source_id: str = "", force: bool = False,
    ) -> tuple[ProbeResult, DeltaStats]:
        """Run a probe with delta awareness.

        Args:
            probe: The probe to run
            connection: Database/API connection
            schema: Schema name
            source_id: Unique source identifier
            force: If True, skip delta logic and re-extract everything

        Returns:
            Tuple of (ProbeResult with only changed records, DeltaStats)
        """
        probe_name = probe.probe_name()
        state_path = self._state_dir / f"{probe_name.replace('.', '_')}.json"
        previous = DeltaState.load(state_path)
        stats = DeltaStats(total_previous=len(previous.resources))

        # Run the full probe
        result = probe.run(connection, schema, source_id=source_id)
        if result.error:
            return result, stats

        # Build current state from records
        current_resources: dict[str, ResourceState] = {}
        changed_records: list[dict] = []

        for record in result.records:
            curr_state = _extract_state(record)
            current_resources[curr_state.key] = curr_state

            if force:
                changed_records.append(record)
                stats.new += 1
                continue

            prev_state = previous.resources.get(curr_state.key)
            if prev_state is None:
                # New resource
                changed_records.append(record)
                stats.new += 1
            elif _has_changed(prev_state, curr_state):
                # Modified resource
                changed_records.append(record)
                stats.modified += 1
            else:
                stats.unchanged += 1

        # Detect deletions
        for prev_key in previous.resources:
            if prev_key not in current_resources:
                stats.deleted += 1

        stats.total_current = len(current_resources)

        # Save new state
        new_state = DeltaState(
            probe_name=probe_name,
            last_scan=datetime.now(timezone.utc).isoformat(),
            scan_count=previous.scan_count + 1,
            resources=current_resources,
        )
        new_state.save(state_path)

        # Return result with only changed records
        delta_result = ProbeResult(
            probe=result.probe,
            source_type=result.source_type,
            source_id=result.source_id,
            timestamp=result.timestamp,
            records=changed_records,
            record_count=len(changed_records),
            duration_ms=result.duration_ms,
        )
        return delta_result, stats
