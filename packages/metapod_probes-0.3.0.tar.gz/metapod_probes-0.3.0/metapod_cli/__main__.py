from metapod_cli import app
