"""SharePoint crawler — supports both Graph API and SharePoint REST API.

Two modes:
  1. Graph API (if tenant_id + client_id + client_secret configured)
     - Broader access: cross-site, OneDrive, Teams
  2. SharePoint REST API (if site_url provided directly)
     - Works with site-level app permissions or user Bearer token
     - No Graph API permissions needed

Config:
  host = site URL (e.g., "https://contoso.sharepoint.com/sites/DataTeam")
         OR tenant domain for Graph API mode
  username = client_id (optional, for Graph API)
  password = client_secret (optional, for Graph API)
  service_name = tenant_id (optional, for Graph API)
  schema_name = subsite path (optional)
  token = pre-acquired Bearer token (works with both modes)
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig):
    """Create a SharePoint client.

    Auto-detects mode:
      1. Local path (OneDrive sync folder) → returns Path object
      2. SharePoint REST API (site URL) → returns httpx.Client
      3. Graph API (tenant_id) → returns httpx.Client
    """
    site_url = config.host or ""

    # Mode 0: Local OneDrive sync folder
    from pathlib import Path
    local = Path(site_url)
    if local.is_dir():
        return local  # Just return the Path — probes handle it

    # Mode 1: SharePoint REST API (direct site URL)
    if site_url.startswith("http") and "sharepoint.com" in site_url:
        token = config.token
        if not token and config.username and config.password and config.service_name:
            token = _acquire_sp_token(config)
        if not token:
            raise ConnectionError(
                "SharePoint REST API needs: token (Bearer) or "
                "username=client_id + password=client_secret + service_name=tenant_id"
            )
        base = site_url.rstrip("/")
        return httpx.Client(
            base_url=f"{base}/_api",
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json;odata=nometadata",
            },
            timeout=30,
        )

    # Mode 2: Graph API
    token = config.token or _acquire_graph_token(config)
    return httpx.Client(
        base_url="https://graph.microsoft.com/v1.0",
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        timeout=30,
    )


def _acquire_graph_token(config: SourceConfig) -> str:
    tenant_id = config.service_name or config.host
    if not all([tenant_id, config.username, config.password]):
        raise ConnectionError("Graph API: need service_name=tenant_id, username=client_id, password=client_secret")

    resp = httpx.post(
        f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials",
            "client_id": config.username,
            "client_secret": config.password,
            "scope": "https://graph.microsoft.com/.default",
        },
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def _acquire_sp_token(config: SourceConfig) -> str:
    """Acquire token scoped to SharePoint site (not Graph)."""
    tenant_id = config.service_name
    site_host = config.host.split("//")[1].split("/")[0] if "//" in config.host else config.host

    resp = httpx.post(
        f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials",
            "client_id": config.username,
            "client_secret": config.password,
            "scope": f"https://{site_host}/.default",
        },
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def is_graph_mode(client: httpx.Client) -> bool:
    """Check if client is using Graph API or SP REST API."""
    return "graph.microsoft.com" in str(client.base_url)


def get_site_id(client: httpx.Client, site_path: str) -> str:
    """Resolve site path to site ID (Graph API only)."""
    if not is_graph_mode(client):
        return ""  # SP REST API doesn't need site_id
    if not site_path:
        resp = client.get("/sites/root")
    elif ":" in site_path:
        resp = client.get(f"/sites/{site_path}")
    else:
        resp = client.get(f"/sites/root:/{site_path}")
    resp.raise_for_status()
    return resp.json()["id"]


def source_id(config: SourceConfig) -> str:
    return f"sharepoint://{config.host}/{config.schema_name or 'root'}"
