"""Probe: sharepoint.metadata.sites — list SharePoint sites."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SharePointSitesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "sharepoint.metadata.sites"

    @staticmethod
    def description() -> str:
        return "List accessible SharePoint sites with name, URL, and creation date"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/sites?search=*&$top=200")
        resp.raise_for_status()
        return [
            {
                "name": s.get("displayName", ""),
                "url": s.get("webUrl", ""),
                "id": s.get("id", ""),
                "created": s.get("createdDateTime", ""),
                "description": s.get("description", ""),
            }
            for s in resp.json().get("value", [])
        ]
