"""Probe: sharepoint.metadata.lists — list SharePoint lists and libraries with columns."""

from probes.sharepoint.connection import get_site_id

from core.base_probe import BaseProbe
from core.registry import register


@register
class SharePointListsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "sharepoint.metadata.lists"

    @staticmethod
    def description() -> str:
        return "List SharePoint lists and document libraries with column schemas"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        site_id = get_site_id(connection, schema)
        resp = connection.get(f"/sites/{site_id}/lists?$expand=columns&$top=200")
        resp.raise_for_status()

        results = []
        for lst in resp.json().get("value", []):
            columns = [
                {
                    "name": c.get("name", ""),
                    "display_name": c.get("displayName", ""),
                    "type": c.get("text", c.get("number", c.get("dateTime", c.get("choice", {})))),
                    "description": c.get("description", ""),
                    "hidden": c.get("hidden", False),
                    "read_only": c.get("readOnly", False),
                }
                for c in lst.get("columns", [])
                if not c.get("hidden", False)
            ]
            results.append({
                "name": lst.get("displayName", ""),
                "id": lst.get("id", ""),
                "template": lst.get("list", {}).get("template", ""),
                "item_count": lst.get("list", {}).get("contentTypesEnabled", 0),
                "created": lst.get("createdDateTime", ""),
                "web_url": lst.get("webUrl", ""),
                "column_count": len(columns),
                "columns": columns,
            })
        return results
