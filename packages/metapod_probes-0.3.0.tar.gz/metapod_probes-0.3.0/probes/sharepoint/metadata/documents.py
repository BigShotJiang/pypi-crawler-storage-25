"""Probe: sharepoint.metadata.documents — crawl documents from SharePoint or local OneDrive sync."""

from pathlib import Path

from probes.sharepoint.connection import get_site_id, is_graph_mode

from core.base_probe import BaseProbe
from core.registry import register


@register
class SharePointDocumentsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "sharepoint.metadata.documents"

    @staticmethod
    def description() -> str:
        return "Crawl SharePoint/OneDrive documents: files, sizes, types, authors (local sync or API)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # Local mode: OneDrive sync folder
        if isinstance(connection, Path):
            return self._crawl_local(connection)

        # Graph API mode
        if is_graph_mode(connection):
            return self._crawl_graph(connection, schema)

        # SharePoint REST API mode
        return self._crawl_sp_rest(connection)

    def _crawl_local(self, root: Path) -> list[dict]:
        """Crawl local OneDrive/SharePoint sync folder."""
        results = []
        for f in sorted(root.rglob("*")):
            if f.is_file() and not f.name.startswith(".") and not f.name.startswith("~$"):
                rel = f.relative_to(root)
                if any(part.startswith(".") for part in rel.parts):
                    continue
                ext = f.suffix.lstrip(".").lower()
                stat = f.stat()
                results.append({
                    "library": "local_sync",
                    "path": str(rel),
                    "name": f.name,
                    "size_bytes": stat.st_size,
                    "extension": ext,
                    "mime_type": "",
                    "created_by": "",
                    "modified_by": "",
                    "created": "",
                    "modified": str(stat.st_mtime),
                    "web_url": "",
                    "source": "local_onedrive_sync",
                })
        return results

    def _crawl_graph(self, client, schema: str) -> list[dict]:
        """Crawl via Microsoft Graph API."""
        site_id = get_site_id(client, schema)
        resp = client.get(f"/sites/{site_id}/drives")
        resp.raise_for_status()

        results = []
        for drive in resp.json().get("value", []):
            self._crawl_graph_folder(client, drive["id"], drive.get("name", ""), "", results, 0)
        return results

    def _crawl_graph_folder(self, client, drive_id, library, path, results, depth):
        if depth > 5:
            return
        ep = f"/drives/{drive_id}/root/children" if not path else f"/drives/{drive_id}/root:/{path}:/children"
        try:
            resp = client.get(f"{ep}?$top=200")
            resp.raise_for_status()
        except Exception:
            return

        for item in resp.json().get("value", []):
            full = f"{path}/{item['name']}" if path else item["name"]
            if item.get("folder"):
                self._crawl_graph_folder(client, drive_id, library, full, results, depth + 1)
            elif item.get("file"):
                ext = item["name"].rsplit(".", 1)[-1].lower() if "." in item["name"] else ""
                results.append({
                    "library": library, "path": full, "name": item["name"],
                    "size_bytes": item.get("size", 0), "extension": ext,
                    "mime_type": item.get("file", {}).get("mimeType", ""),
                    "created_by": item.get("createdBy", {}).get("user", {}).get("displayName", ""),
                    "modified_by": item.get("lastModifiedBy", {}).get("user", {}).get("displayName", ""),
                    "created": item.get("createdDateTime", ""),
                    "modified": item.get("lastModifiedDateTime", ""),
                    "web_url": item.get("webUrl", ""),
                    "source": "graph_api",
                })

    def _crawl_sp_rest(self, client) -> list[dict]:
        """Crawl via SharePoint REST API."""
        results = []
        try:
            resp = client.get("/web/GetFolderByServerRelativeUrl('Shared Documents')/Files?$top=500")
            resp.raise_for_status()
            for f in resp.json().get("value", []):
                ext = f["Name"].rsplit(".", 1)[-1].lower() if "." in f.get("Name", "") else ""
                results.append({
                    "library": "Shared Documents", "path": f.get("ServerRelativeUrl", ""),
                    "name": f.get("Name", ""), "size_bytes": f.get("Length", 0),
                    "extension": ext, "mime_type": "", "created_by": f.get("Author", ""),
                    "modified_by": "", "created": f.get("TimeCreated", ""),
                    "modified": f.get("TimeLastModified", ""), "web_url": "",
                    "source": "sp_rest_api",
                })
        except Exception:
            pass
        return results
