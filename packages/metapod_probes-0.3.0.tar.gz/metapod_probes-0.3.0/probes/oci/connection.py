"""Oracle Cloud Infrastructure (OCI) connection — via oci-python-sdk.

Config:
  host = OCI region (e.g., "us-ashburn-1")
  username = tenancy OCID
  password = user OCID
  token = API key fingerprint
  service_name = compartment OCID
  schema_name = specific service filter (optional)

Supports: API key auth, instance principal, resource principal.
"""

from __future__ import annotations

from core.config import SourceConfig


def get_clients(config: SourceConfig) -> dict:
    """Create OCI service clients for metadata extraction."""
    try:
        import oci
    except ImportError:
        raise ConnectionError("oci not installed. Run: pip install oci")

    # Try config file first, then instance principal
    try:
        oci_config = oci.config.from_file()
    except Exception:
        oci_config = {
            "region": config.host,
            "tenancy": config.username,
            "user": config.password,
            "fingerprint": config.token,
        }

    compartment_id = config.service_name

    return {
        "config": oci_config,
        "compartment_id": compartment_id,
        "region": config.host,
        "database": oci.database.DatabaseClient(oci_config),
        "data_integration": oci.data_integration.DataIntegrationClient(oci_config),
        "data_catalog": oci.data_catalog.DataCatalogClient(oci_config),
    }


def source_id(config: SourceConfig) -> str:
    return f"oci://{config.host}/{config.service_name}"
