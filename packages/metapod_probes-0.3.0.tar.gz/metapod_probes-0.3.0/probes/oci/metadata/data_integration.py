"""Probe: oci.metadata.data_integration — extract OCI Data Integration workspaces and pipelines."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class OciDataIntegrationProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oci.metadata.data_integration"

    @staticmethod
    def description() -> str:
        return "List OCI Data Integration workspaces, data flows, and pipelines"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        di_client = connection["data_integration"]
        compartment = connection["compartment_id"]
        results = []

        try:
            workspaces = di_client.list_workspaces(compartment_id=compartment).data
            for ws in workspaces:
                results.append({
                    "type": "workspace",
                    "name": ws.display_name,
                    "id": ws.id,
                    "state": ws.lifecycle_state,
                    "created": str(ws.time_created) if ws.time_created else None,
                })

                # List data flows in each workspace
                try:
                    flows = di_client.list_data_flows(workspace_id=ws.id).data.items
                    for flow in flows:
                        results.append({
                            "type": "data_flow",
                            "workspace": ws.display_name,
                            "name": flow.name,
                            "key": flow.key,
                            "description": flow.description or "",
                        })
                except Exception:
                    pass

                # List pipelines
                try:
                    pipelines = di_client.list_pipelines(workspace_id=ws.id).data.items
                    for pl in pipelines:
                        results.append({
                            "type": "pipeline",
                            "workspace": ws.display_name,
                            "name": pl.name,
                            "key": pl.key,
                            "description": pl.description or "",
                        })
                except Exception:
                    pass

        except Exception as e:
            results.append({"type": "error", "error": str(e)})

        return results
