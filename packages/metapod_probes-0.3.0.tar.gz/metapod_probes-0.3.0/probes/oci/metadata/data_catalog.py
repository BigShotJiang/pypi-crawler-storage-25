"""Probe: oci.metadata.data_catalog — extract OCI Data Catalog assets."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class OciDataCatalogProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oci.metadata.data_catalog"

    @staticmethod
    def description() -> str:
        return "List OCI Data Catalog instances and their data assets"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        dc_client = connection["data_catalog"]
        compartment = connection["compartment_id"]
        results = []

        try:
            catalogs = dc_client.list_catalogs(compartment_id=compartment).data.items
            for cat in catalogs:
                results.append({
                    "type": "catalog",
                    "name": cat.display_name,
                    "id": cat.id,
                    "state": cat.lifecycle_state,
                    "created": str(cat.time_created) if cat.time_created else None,
                })

                # List data assets in each catalog
                try:
                    assets = dc_client.list_data_assets(catalog_id=cat.id).data.items
                    for asset in assets:
                        results.append({
                            "type": "data_asset",
                            "catalog": cat.display_name,
                            "name": asset.display_name,
                            "key": asset.key,
                            "type_key": asset.type_key or "",
                            "description": asset.description or "",
                        })
                except Exception:
                    pass

        except Exception as e:
            results.append({"type": "error", "error": str(e)})

        return results
