"""Probe: oci.metadata.databases — list OCI database instances."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class OciDatabasesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oci.metadata.databases"

    @staticmethod
    def description() -> str:
        return "List Oracle Autonomous and DB System instances in OCI compartment"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        db_client = connection["database"]
        compartment = connection["compartment_id"]
        results = []

        # Autonomous Databases
        try:
            adbs = db_client.list_autonomous_databases(compartment_id=compartment).data
            for adb in adbs:
                results.append({
                    "type": "AUTONOMOUS",
                    "name": adb.display_name,
                    "id": adb.id,
                    "db_name": adb.db_name,
                    "lifecycle_state": adb.lifecycle_state,
                    "workload_type": adb.db_workload,
                    "cpu_count": adb.cpu_core_count,
                    "storage_tb": adb.data_storage_size_in_tbs,
                    "version": adb.db_version or "",
                    "created": str(adb.time_created) if adb.time_created else None,
                })
        except Exception:
            pass

        # DB Systems
        try:
            dbs = db_client.list_db_systems(compartment_id=compartment).data
            for db in dbs:
                results.append({
                    "type": "DB_SYSTEM",
                    "name": db.display_name,
                    "id": db.id,
                    "shape": db.shape,
                    "lifecycle_state": db.lifecycle_state,
                    "node_count": db.node_count,
                    "version": db.version or "",
                    "created": str(db.time_created) if db.time_created else None,
                })
        except Exception:
            pass

        return results
