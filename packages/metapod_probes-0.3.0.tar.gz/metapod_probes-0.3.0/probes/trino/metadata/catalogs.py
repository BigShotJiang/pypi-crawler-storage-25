"""Probe: trino.metadata.catalogs — list available Trino catalogs."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class TrinoCatalogsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "trino.metadata.catalogs"
    @staticmethod
    def description() -> str: return "List all available Trino catalogs (connectors)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SHOW CATALOGS")
        return [{"catalog": r[0]} for r in cur.fetchall()]
