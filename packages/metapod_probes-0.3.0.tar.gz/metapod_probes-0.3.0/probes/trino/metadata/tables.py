"""Probe: trino.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class TrinoTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "trino.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables from Trino information_schema"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = '" + schema + "' ORDER BY table_name")
        return [{"table_name": r[0], "table_type": r[1]} for r in cur.fetchall()]
