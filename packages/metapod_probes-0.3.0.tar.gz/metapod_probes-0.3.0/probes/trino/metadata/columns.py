"""Probe: trino.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class TrinoColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "trino.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions from Trino"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT table_name, column_name, data_type, is_nullable, ordinal_position FROM information_schema.columns WHERE table_schema = '" + schema + "' ORDER BY table_name, ordinal_position")
        return [{"table_name": r[0], "column_name": r[1], "data_type": r[2], "nullable": r[3] == "YES", "position": r[4]} for r in cur.fetchall()]
