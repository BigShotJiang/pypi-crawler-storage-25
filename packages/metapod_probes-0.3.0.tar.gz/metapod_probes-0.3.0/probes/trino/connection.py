"""Trino connection factory."""
from __future__ import annotations
from core.config import SourceConfig

def connect(config: SourceConfig):
    try:
        from trino.dbapi import connect as trino_connect
    except ImportError:
        raise ConnectionError("trino not installed. Run: pip install trino")
    return trino_connect(
        host=config.host, port=config.port or 8080,
        user=config.username or "metapod",
        catalog=config.catalog or config.service_name or "hive",
        schema=config.schema_name or "default",
    )

def source_id(config: SourceConfig) -> str:
    return f"trino://{config.host}:{config.port or 8080}/{config.catalog or 'hive'}/{config.schema_name}"
