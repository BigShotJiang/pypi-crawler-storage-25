"""Probe: excel.metadata.measures — detect KPI/measure formulas in Excel cells.

Identifies cells containing aggregation functions (SUM, AVERAGE, COUNT, etc.)
that reference table-like ranges — these are business measures hidden in cells.
"""

import re

from core.base_probe import BaseProbe
from core.registry import register

MEASURE_PATTERNS = [
    (r"\bSUM\s*\(", "SUM"),
    (r"\bAVERAGE\s*\(", "AVERAGE"),
    (r"\bCOUNT\s*\(", "COUNT"),
    (r"\bCOUNTA?\s*\(", "COUNT"),
    (r"\bCOUNTIF[S]?\s*\(", "COUNTIF"),
    (r"\bSUMIF[S]?\s*\(", "SUMIF"),
    (r"\bSUMPRODUCT\s*\(", "SUMPRODUCT"),
    (r"\bMAX\s*\(", "MAX"),
    (r"\bMIN\s*\(", "MIN"),
    (r"\bMEDIAN\s*\(", "MEDIAN"),
    (r"\bSTDEV", "STDEV"),
    (r"\bVAR\s*\(", "VARIANCE"),
    (r"\bPERCENTILE", "PERCENTILE"),
    (r"\bGROWTH\s*\(", "GROWTH"),
    (r"\bTREND\s*\(", "TREND"),
]


@register
class ExcelMeasuresProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "excel.metadata.measures"

    @staticmethod
    def description() -> str:
        return "Detect KPI/measure cells: formulas with SUM, AVERAGE, COUNT, SUMIF, SUMPRODUCT"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            for sheet in wb.get("sheets", []):
                for f in sheet.get("formulas", []):
                    formula = f["formula"].upper()
                    for pattern, measure_type in MEASURE_PATTERNS:
                        if re.search(pattern, formula, re.IGNORECASE):
                            # Extract range references from formula
                            refs = re.findall(r"([A-Z]+\d+:[A-Z]+\d+|[A-Z]+:\s*[A-Z]+|\w+!\w+)", f["formula"])
                            results.append({
                                "file": wb["file"],
                                "sheet": sheet["name"],
                                "cell": f["cell"],
                                "measure_type": measure_type,
                                "formula": f["formula"],
                                "value": f.get("value", ""),
                                "references": refs,
                            })
                            break
        return results
