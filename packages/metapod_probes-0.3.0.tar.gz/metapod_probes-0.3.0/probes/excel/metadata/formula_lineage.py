"""Probe: excel.metadata.formula_lineage — trace cell-to-cell data flow from formulas.

Builds a mini-lineage graph from Excel formula references:
- Cell A1 = B1 + C1 → B1 flows to A1, C1 flows to A1
- VLOOKUP(A2, Sheet2!A:C, 3) → Sheet2 joins to current sheet
- Cross-sheet references = inter-table lineage
"""

import re

from core.base_probe import BaseProbe
from core.registry import register

# Patterns to extract cell/range references from formulas
_REF_PATTERN = re.compile(r"(?:(\w+)!)?(\$?[A-Z]+\$?\d+(?::\$?[A-Z]+\$?\d+)?)")
_SHEET_REF = re.compile(r"(\w+)!")


@register
class ExcelFormulaLineageProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "excel.metadata.formula_lineage"

    @staticmethod
    def description() -> str:
        return "Trace cell-to-cell lineage from formula references (cross-sheet flows)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            for sheet in wb.get("sheets", []):
                sheet_name = sheet["name"]
                for f in sheet.get("formulas", []):
                    formula = f["formula"]
                    target_cell = f["cell"]

                    # Extract all references
                    refs = _REF_PATTERN.findall(formula)
                    for ref_sheet, ref_range in refs:
                        source_sheet = ref_sheet or sheet_name
                        is_cross_sheet = source_sheet != sheet_name

                        # Detect transformation type
                        transform = _detect_transform(formula)

                        results.append({
                            "file": wb["file"],
                            "target_sheet": sheet_name,
                            "target_cell": target_cell,
                            "source_sheet": source_sheet,
                            "source_range": ref_range,
                            "is_cross_sheet": is_cross_sheet,
                            "transform_type": transform,
                            "formula": formula[:200],
                        })
        return results


def _detect_transform(formula: str) -> str:
    """Classify the formula transformation type."""
    upper = formula.upper()
    if any(f in upper for f in ["VLOOKUP", "HLOOKUP", "INDEX", "MATCH", "XLOOKUP"]):
        return "LOOKUP_JOIN"
    if any(f in upper for f in ["SUM", "AVERAGE", "COUNT", "MAX", "MIN"]):
        return "AGGREGATION"
    if any(f in upper for f in ["SUMIF", "COUNTIF", "AVERAGEIF"]):
        return "FILTERED_AGGREGATION"
    if any(f in upper for f in ["SUMPRODUCT"]):
        return "ARRAY_AGGREGATION"
    if any(f in upper for f in ["IF(", "IFS(", "SWITCH("]):
        return "CONDITIONAL"
    if any(f in upper for f in ["CONCATENATE", "TEXTJOIN", "&"]):
        return "STRING_CONCAT"
    if any(f in upper for f in ["LEFT(", "RIGHT(", "MID(", "TRIM(", "UPPER(", "LOWER("]):
        return "STRING_TRANSFORM"
    if any(f in upper for f in ["DATE(", "YEAR(", "MONTH(", "DAY(", "DATEDIF"]):
        return "DATE_TRANSFORM"
    if any(f in upper for f in ["+", "-", "*", "/", "ROUND(", "INT("]):
        return "ARITHMETIC"
    return "DIRECT_REFERENCE"
