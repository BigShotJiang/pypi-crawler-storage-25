"""Probe: excel.metadata.tables — extract explicit Excel Tables (ListObject)."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ExcelTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "excel.metadata.tables"

    @staticmethod
    def description() -> str:
        return "Extract named Excel Tables (ListObject) with columns and ranges"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            for t in wb.get("tables", []):
                results.append({
                    "file": wb["file"],
                    "table_name": t["name"],
                    "range": t["ref"],
                    "column_count": t["column_count"],
                    "columns": [c["name"] for c in t.get("columns", [])],
                })
        return results
