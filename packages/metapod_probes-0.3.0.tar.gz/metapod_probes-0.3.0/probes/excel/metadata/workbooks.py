"""Probe: excel.metadata.workbooks — overview of Excel workbook structure."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ExcelWorkbooksProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "excel.metadata.workbooks"

    @staticmethod
    def description() -> str:
        return "Extract workbook overview: sheets, tables, connections, formula counts"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                results.append({"file": wb["file"], "error": wb["error"]})
                continue
            total_formulas = sum(s.get("formula_count", 0) for s in wb.get("sheets", []))
            results.append({
                "file": wb["file"],
                "sheet_count": len(wb.get("sheets", [])),
                "table_count": len(wb.get("tables", [])),
                "connection_count": len(wb.get("connections", [])),
                "defined_name_count": len(wb.get("defined_names", [])),
                "total_formulas": total_formulas,
                "sheets": [s["name"] for s in wb.get("sheets", [])],
            })
        return results
