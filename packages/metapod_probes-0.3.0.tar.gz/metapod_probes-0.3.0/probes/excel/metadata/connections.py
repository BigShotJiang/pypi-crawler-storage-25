"""Probe: excel.metadata.connections — extract Power Query and external data connections."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ExcelConnectionsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "excel.metadata.connections"

    @staticmethod
    def description() -> str:
        return "Extract Power Query connections and external data sources from .xlsx"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            for conn in wb.get("connections", []):
                results.append({
                    "file": wb["file"],
                    "connection_name": conn.get("name", ""),
                    "type": conn.get("type", ""),
                    "description": conn.get("description", ""),
                    "connection_string": conn.get("connection_string", "")[:200],
                    "command": conn.get("command", "")[:300],
                })
            # Also check defined names for Power Query references
            for dn in wb.get("defined_names", []):
                if dn["name"].startswith("_xlnm") or "Query" in dn["name"]:
                    results.append({
                        "file": wb["file"],
                        "connection_name": dn["name"],
                        "type": "defined_name",
                        "description": "",
                        "connection_string": "",
                        "command": dn["value"][:300],
                    })
        return results
