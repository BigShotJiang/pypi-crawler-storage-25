"""Probe: excel.metadata.table_detector — detect implicit tables in Excel sheets.

Uses topological analysis to find contiguous rectangular regions where:
- Row 1 contains text headers (non-numeric, non-empty)
- Rows 2+ contain data (consistent types per column)
- The region is bounded by empty rows/columns

These "implicit tables" are structured data that analysts use as tables
without formally declaring them as Excel Table objects.
"""

import re
from collections import defaultdict

from core.base_probe import BaseProbe
from core.registry import register


def _col_to_idx(col: str) -> int:
    """Convert Excel column letter(s) to 0-based index. A=0, B=1, Z=25, AA=26."""
    result = 0
    for c in col.upper():
        result = result * 26 + (ord(c) - ord("A") + 1)
    return result - 1


def _parse_ref(ref: str) -> tuple[int, int]:
    """Parse cell reference like 'B3' into (col_idx, row_num)."""
    m = re.match(r"([A-Z]+)(\d+)", ref)
    if not m:
        return -1, -1
    return _col_to_idx(m.group(1)), int(m.group(2))


@register
class ExcelTableDetectorProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "excel.metadata.table_detector"

    @staticmethod
    def description() -> str:
        return "Detect implicit tables: contiguous cell regions with headers and consistent data"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            # Already-declared tables (skip these regions)
            declared_ranges = {t["ref"] for t in wb.get("tables", [])}

            for sheet in wb.get("sheets", []):
                cells = sheet.get("_cells", [])
                formulas = sheet.get("formulas", [])
                if not cells and not formulas:
                    continue

                # Build a grid: (col, row) → value
                grid: dict[tuple[int, int], str] = {}
                for c in cells:
                    ci, ri = _parse_ref(c["cell"])
                    if ci >= 0:
                        grid[(ci, ri)] = c["value"]
                for f in formulas:
                    ci, ri = _parse_ref(f["cell"])
                    if ci >= 0:
                        grid[(ci, ri)] = f.get("value", f["formula"])

                if not grid:
                    continue

                # Find potential header rows: rows where most cells are text (not numeric)
                detected = self._detect_tables(grid, sheet["name"], wb["file"])
                # Filter out already-declared ranges
                for dt in detected:
                    if dt.get("range", "") not in declared_ranges:
                        results.append(dt)

        return results

    def _detect_tables(self, grid: dict[tuple[int, int], str], sheet_name: str, file_name: str) -> list[dict]:
        """Detect contiguous rectangular regions that look like tables."""
        if not grid:
            return []

        # Group cells by row
        rows: dict[int, list[tuple[int, str]]] = defaultdict(list)
        for (ci, ri), val in grid.items():
            rows[ri].append((ci, val))

        detected = []
        visited_rows: set[int] = set()

        for row_num in sorted(rows.keys()):
            if row_num in visited_rows:
                continue

            row_cells = sorted(rows[row_num])
            if len(row_cells) < 2:
                continue

            # Check if this row looks like headers (text values, not numbers)
            headers = []
            for ci, val in row_cells:
                if val and not _is_numeric(val):
                    headers.append((ci, val))

            if len(headers) < 2:
                continue

            # Check if rows below have data in the same columns
            header_cols = {ci for ci, _ in headers}
            data_rows = 0
            for next_row in range(row_num + 1, row_num + 200):
                if next_row not in rows:
                    break
                next_cells = {ci for ci, _ in rows[next_row]}
                overlap = header_cols & next_cells
                if len(overlap) < len(header_cols) * 0.5:
                    break
                data_rows += 1
                visited_rows.add(next_row)

            if data_rows >= 2:
                visited_rows.add(row_num)
                min_col = min(header_cols)
                max_col = max(header_cols)
                detected.append({
                    "file": file_name,
                    "sheet": sheet_name,
                    "detection": "implicit_table",
                    "header_row": row_num,
                    "data_rows": data_rows,
                    "column_count": len(headers),
                    "columns": [h[1] for _, h in enumerate(headers)],
                    "range": f"{_idx_to_col(min_col)}{row_num}:{_idx_to_col(max_col)}{row_num + data_rows}",
                    "confidence": min(0.95, 0.6 + (data_rows / 50) + (len(headers) / 20)),
                })

        return detected


def _is_numeric(val: str) -> bool:
    try:
        float(val.replace(",", ""))
        return True
    except (ValueError, AttributeError):
        return False


def _idx_to_col(idx: int) -> str:
    """Convert 0-based index to Excel column letter."""
    result = ""
    idx += 1
    while idx > 0:
        idx, rem = divmod(idx - 1, 26)
        result = chr(65 + rem) + result
    return result
