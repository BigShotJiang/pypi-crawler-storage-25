"""Excel metadata extraction — .xlsx/.xlsm OOXML parsing.

.xlsx files are ZIP archives containing XML:
  xl/workbook.xml        — sheet names, defined names
  xl/worksheets/sheet*.xml — cell data, formulas, dimensions
  xl/tables/table*.xml   — structured Excel Tables (ListObject)
  xl/connections.xml     — Power Query / external connections
  xl/sharedStrings.xml   — string lookup table
  xl/pivotTables/        — pivot table definitions

Config:
  host = path to directory containing .xlsx/.xlsm files
  schema_name = specific file (optional, empty = scan all)
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from core.config import SourceConfig

NS = {
    "s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}


def get_workbooks(config: SourceConfig) -> list[dict]:
    """Parse .xlsx/.xlsm files and return structured workbook metadata."""
    directory = Path(config.host or ".")
    target = config.schema_name or ""

    files = []
    if target:
        p = directory / target
        if p.exists():
            files = [p]
    else:
        files = list(directory.glob("*.xlsx")) + list(directory.glob("*.xlsm"))

    workbooks = []
    for f in files:
        try:
            wb = _parse_workbook(f)
            workbooks.append(wb)
        except Exception as e:
            workbooks.append({"file": f.name, "path": str(f), "error": str(e)})
    return workbooks


def _parse_workbook(filepath: Path) -> dict:
    """Parse an xlsx file into structured metadata."""
    wb: dict = {"file": filepath.name, "path": str(filepath), "sheets": [], "tables": [],
                "defined_names": [], "connections": [], "shared_strings": []}

    with zipfile.ZipFile(filepath, "r") as zf:
        names = zf.namelist()

        # Shared strings (for cell value lookup)
        if "xl/sharedStrings.xml" in names:
            tree = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in tree.findall(".//s:si", NS):
                t = si.find(".//s:t", NS)
                wb["shared_strings"].append(t.text if t is not None and t.text else "")

        # Workbook: sheet names + defined names
        if "xl/workbook.xml" in names:
            tree = ET.fromstring(zf.read("xl/workbook.xml"))
            for sheet in tree.findall(".//s:sheet", NS):
                wb["sheets"].append({"name": sheet.get("name", ""), "id": sheet.get("sheetId", "")})
            for dn in tree.findall(".//s:definedName", NS):
                wb["defined_names"].append({
                    "name": dn.get("name", ""),
                    "value": dn.text or "",
                    "scope": dn.get("localSheetId", "global"),
                })

        # Excel Tables (ListObject)
        for name in names:
            if name.startswith("xl/tables/table") and name.endswith(".xml"):
                tree = ET.fromstring(zf.read(name))
                ref = tree.get("ref", "")
                display_name = tree.get("displayName", "")
                columns = []
                for col in tree.findall(".//s:tableColumn", NS):
                    columns.append({
                        "name": col.get("name", ""),
                        "id": col.get("id", ""),
                        "formula": col.get("dataCellStyle", ""),
                    })
                wb["tables"].append({
                    "name": display_name, "ref": ref,
                    "column_count": len(columns), "columns": columns,
                })

        # Connections (Power Query)
        if "xl/connections.xml" in names:
            tree = ET.fromstring(zf.read("xl/connections.xml"))
            for conn in tree.findall(".//s:connection", NS):
                wb["connections"].append({
                    "name": conn.get("name", ""),
                    "type": conn.get("type", ""),
                    "description": conn.get("description", ""),
                    "connection_string": (conn.find(".//s:dbPr", NS) or {}).get("connection", ""),
                    "command": (conn.find(".//s:dbPr", NS) or {}).get("command", ""),
                })

        # Worksheets: cells with formulas
        for i, sheet_info in enumerate(wb["sheets"]):
            sheet_file = f"xl/worksheets/sheet{i + 1}.xml"
            if sheet_file not in names:
                continue
            tree = ET.fromstring(zf.read(sheet_file))
            dim = tree.find(".//s:dimension", NS)
            sheet_info["dimension"] = dim.get("ref", "") if dim is not None else ""

            formulas = []
            cells = []
            for row in tree.findall(".//s:row", NS):
                for cell in row.findall("s:c", NS):
                    ref = cell.get("r", "")
                    cell_type = cell.get("t", "")
                    formula_el = cell.find("s:f", NS)
                    value_el = cell.find("s:v", NS)

                    val = ""
                    if value_el is not None and value_el.text:
                        if cell_type == "s" and value_el.text.isdigit():
                            idx = int(value_el.text)
                            val = wb["shared_strings"][idx] if idx < len(wb["shared_strings"]) else ""
                        else:
                            val = value_el.text

                    if formula_el is not None and formula_el.text:
                        formulas.append({"cell": ref, "formula": formula_el.text, "value": val})
                    elif val:
                        cells.append({"cell": ref, "value": val, "type": cell_type})

            sheet_info["formula_count"] = len(formulas)
            sheet_info["formulas"] = formulas
            sheet_info["cell_count"] = len(cells)
            # Store first row cells for header detection (limit)
            sheet_info["_cells"] = cells[:2000]

    return wb


def source_id(config: SourceConfig) -> str:
    return f"excel://{config.host}/{config.schema_name or '*'}"
