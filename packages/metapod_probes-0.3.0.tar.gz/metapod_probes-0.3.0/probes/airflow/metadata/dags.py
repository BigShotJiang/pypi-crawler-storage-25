"""Probe: airflow.metadata.dags — list all DAGs with schedule and status."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class AirflowDagsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "airflow.metadata.dags"
    @staticmethod
    def description() -> str: return "List all Airflow DAGs with schedule, owner, status, and tags"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/dags?limit=500")
        resp.raise_for_status()
        return [{
            "dag_id": d["dag_id"], "description": d.get("description", ""),
            "schedule": d.get("schedule_interval", {}).get("value", "") if isinstance(d.get("schedule_interval"), dict) else str(d.get("schedule_interval", "")),
            "is_paused": d.get("is_paused", False), "is_active": d.get("is_active", False),
            "owner": ",".join(d.get("owners", [])), "tags": [t["name"] for t in d.get("tags", [])],
            "file_token": d.get("file_token", ""),
        } for d in resp.json().get("dags", [])]
