"""Probe: airflow.metadata.connections — list Airflow connections (data sources)."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class AirflowConnectionsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "airflow.metadata.connections"
    @staticmethod
    def description() -> str: return "List Airflow connections with type, host, schema (passwords masked)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/connections?limit=500")
        resp.raise_for_status()
        return [{
            "conn_id": c["connection_id"], "conn_type": c.get("conn_type", ""),
            "host": c.get("host", ""), "port": c.get("port"),
            "schema": c.get("schema", ""), "login": c.get("login", ""),
            "description": c.get("description", ""),
        } for c in resp.json().get("connections", [])]
