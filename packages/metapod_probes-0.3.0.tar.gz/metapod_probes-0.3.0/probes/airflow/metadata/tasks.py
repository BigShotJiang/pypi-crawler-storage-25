"""Probe: airflow.metadata.tasks — extract task dependencies from DAGs."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class AirflowTasksProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "airflow.metadata.tasks"
    @staticmethod
    def description() -> str: return "Extract tasks and dependency graph from all active DAGs"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        dags = connection.get("/dags?limit=200&only_active=true").json().get("dags", [])
        results = []
        for dag in dags:
            try:
                resp = connection.get(f"/dags/{dag['dag_id']}/tasks")
                resp.raise_for_status()
                for t in resp.json().get("tasks", []):
                    results.append({
                        "dag_id": dag["dag_id"], "task_id": t["task_id"],
                        "operator": t.get("class_ref", {}).get("class_name", ""),
                        "downstream": t.get("downstream_task_ids", []),
                        "pool": t.get("pool", ""),
                    })
            except Exception:
                pass
        return results
