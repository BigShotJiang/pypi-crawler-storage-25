"""Apache Airflow metadata extraction — via REST API.
Config: host = Airflow webserver URL, username/password or token for auth.
"""
from __future__ import annotations
import httpx
from core.config import SourceConfig

def get_client(config: SourceConfig) -> httpx.Client:
    base = config.host.rstrip("/") if config.host else "http://localhost:8080"
    auth = (config.username, config.password) if config.username else None
    headers = {"Accept": "application/json"}
    if config.token:
        headers["Authorization"] = f"Bearer {config.token}"
    return httpx.Client(base_url=f"{base}/api/v1", auth=auth, headers=headers, timeout=30)

def source_id(config: SourceConfig) -> str:
    return f"airflow://{config.host}"
