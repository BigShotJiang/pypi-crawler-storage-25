"""Probe: mariadb.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class MariaDbColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "mariadb.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions (MariaDB)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE, ORDINAL_POSITION, COLUMN_DEFAULT
                           FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s ORDER BY TABLE_NAME, ORDINAL_POSITION""", (schema,))
            return [dict(r) for r in cur.fetchall()]
