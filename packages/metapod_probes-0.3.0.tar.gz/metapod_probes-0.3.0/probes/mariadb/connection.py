"""MariaDB connection — reuses MySQL driver (compatible)."""
from probes.mysql.connection import connect, source_id  # noqa: F401
