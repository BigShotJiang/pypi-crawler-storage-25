"""Probe: python_transform.metadata.scripts — detect data transformations in Python scripts.

Uses AST analysis to find: pandas read/write, spark.read/write, SQL strings,
file I/O patterns, and function call chains.
"""
import ast
import re
from pathlib import Path
from core.base_probe import BaseProbe
from core.registry import register

DATA_READ_PATTERNS = ["read_csv", "read_excel", "read_parquet", "read_json", "read_sql", "read_table", "read_gbq"]
DATA_WRITE_PATTERNS = ["to_csv", "to_excel", "to_parquet", "to_json", "to_sql", "to_gbq", "write"]
SPARK_READ = ["spark.read", "spark.table", "spark.sql"]
SPARK_WRITE = [".write.", ".saveAsTable", ".insertInto"]

@register
class PythonScriptsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "python_transform.metadata.scripts"
    @staticmethod
    def description() -> str: return "Detect data read/write operations in Python scripts (pandas, PySpark, SQL strings)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        root = connection if isinstance(connection, Path) else Path(str(connection))
        results = []
        for f in sorted(root.rglob("*.py")):
            if f.name.startswith(".") or "__pycache__" in str(f): continue
            try:
                source = f.read_text(encoding="utf-8", errors="replace")
                ops = _detect_data_ops(source, str(f.relative_to(root)))
                if ops: results.extend(ops)
            except Exception:
                pass
        return results

def _detect_data_ops(source: str, filename: str) -> list[dict]:
    ops = []
    for i, line in enumerate(source.split("\n"), 1):
        stripped = line.strip()
        for pat in DATA_READ_PATTERNS:
            if pat in stripped:
                target = re.search(r'["\']([^"\']+)["\']', stripped)
                ops.append({"file": filename, "line": i, "op": "READ", "method": pat, "target": target.group(1)[:100] if target else ""})
        for pat in DATA_WRITE_PATTERNS:
            if pat in stripped:
                target = re.search(r'["\']([^"\']+)["\']', stripped)
                ops.append({"file": filename, "line": i, "op": "WRITE", "method": pat, "target": target.group(1)[:100] if target else ""})
        for pat in SPARK_READ:
            if pat in stripped:
                ops.append({"file": filename, "line": i, "op": "SPARK_READ", "method": pat, "target": ""})
        for pat in SPARK_WRITE:
            if pat in stripped:
                ops.append({"file": filename, "line": i, "op": "SPARK_WRITE", "method": pat, "target": ""})
        # Detect SQL strings
        if re.search(r'(SELECT|INSERT|CREATE|MERGE)\s', stripped, re.IGNORECASE) and ("'" in stripped or '"' in stripped):
            ops.append({"file": filename, "line": i, "op": "SQL_STRING", "method": "embedded_sql", "target": stripped[:100]})
    return ops
