"""Probe: unity_catalog.operations.query_history — recent queries from system.access."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCQueryHistoryProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.operations.query_history"

    @staticmethod
    def description() -> str:
        return "Recent query history from system.query.history (top 100 by duration)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        if not connection.warehouse_id:
            return []

        rows = connection.execute_sql_safe("""
            SELECT statement_id, executed_by, statement_type,
                   statement_text, status,
                   execution_start_time_ms, total_duration_ms,
                   read_rows, read_bytes, produced_rows, produced_bytes
            FROM system.query.history
            WHERE total_duration_ms IS NOT NULL
            ORDER BY execution_start_time_ms DESC
            LIMIT 100
        """)
        return [{
            "statement_id": r.get("statement_id", ""),
            "executed_by": r.get("executed_by", ""),
            "statement_type": r.get("statement_type", ""),
            "query_text": (r.get("statement_text", "") or "")[:500],
            "status": r.get("status", ""),
            "start_time_ms": r.get("execution_start_time_ms"),
            "duration_ms": r.get("total_duration_ms"),
            "read_rows": r.get("read_rows"),
            "read_bytes": r.get("read_bytes"),
            "produced_rows": r.get("produced_rows"),
            "produced_bytes": r.get("produced_bytes"),
        } for r in rows]
