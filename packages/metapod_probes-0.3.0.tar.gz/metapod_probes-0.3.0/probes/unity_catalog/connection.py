"""Databricks Unity Catalog connection — REST API + SQL Statement Execution.

Supports two access patterns:
1. REST API (httpx.Client) for catalog/schema/table/volume listing
2. SQL Statement Execution for bulk column discovery and system table lineage

Config:
    host = Databricks workspace URL (e.g., https://adb-xxx.azuredatabricks.net)
    token = Personal Access Token or OAuth token
    catalog = Warehouse ID for SQL statement execution (optional)
    schema_name = Default catalog.schema (e.g., "main.default")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from core.config import SourceConfig


@dataclass
class UCClient:
    """Unity Catalog client wrapping REST API + optional SQL execution."""

    api: httpx.Client
    warehouse_id: str = ""
    _host: str = ""

    def get(self, path: str, **kwargs) -> httpx.Response:
        """REST API GET (proxied to httpx.Client)."""
        return self.api.get(path, **kwargs)

    def execute_sql(self, statement: str) -> list[dict[str, Any]]:
        """Execute SQL via Statement Execution API. Returns list of row dicts.

        Requires warehouse_id to be set. Uses JSON_ARRAY format for efficient
        bulk column/lineage queries (avoids N+1 API calls).
        """
        if not self.warehouse_id:
            raise RuntimeError("warehouse_id required for SQL execution. Set catalog= in config.")

        resp = httpx.post(
            f"{self._host}/api/2.0/sql/statements",
            headers=self.api.headers,
            json={
                "warehouse_id": self.warehouse_id,
                "statement": statement,
                "format": "JSON_ARRAY",
                "disposition": "INLINE",
                "wait_timeout": "120s",
            },
            timeout=180,
        )
        resp.raise_for_status()
        data = resp.json()

        status = data.get("status", {})
        if status.get("state") == "FAILED":
            raise RuntimeError(f"SQL failed: {status.get('error', {}).get('message', 'unknown')}")

        columns = [c["name"] for c in data.get("manifest", {}).get("schema", {}).get("columns", [])]
        rows = data.get("result", {}).get("data_array", [])
        return [dict(zip(columns, row)) for row in rows]

    def execute_sql_safe(self, statement: str) -> list[dict[str, Any]]:
        """Execute SQL, returning empty list on failure (graceful degradation)."""
        try:
            return self.execute_sql(statement)
        except Exception:
            return []

    def close(self):
        self.api.close()


def get_client(config: SourceConfig) -> UCClient:
    """Create a UCClient for Databricks Unity Catalog."""
    workspace_url = getattr(config, "workspace_url", None) or config.host
    if not workspace_url:
        raise ConnectionError("host (workspace URL) required for Unity Catalog")
    token = config.token or config.password
    if not token:
        raise ConnectionError("token required for Unity Catalog auth")

    base_url = workspace_url.rstrip("/")
    if not base_url.startswith("http"):
        base_url = f"https://{base_url}"

    api = httpx.Client(
        base_url=f"{base_url}/api/2.1/unity-catalog",
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        timeout=30,
    )

    # warehouse_id stored in 'catalog' config field (overloaded)
    warehouse_id = getattr(config, "catalog", "") or ""

    return UCClient(api=api, warehouse_id=warehouse_id, _host=base_url)


def source_id(config: SourceConfig) -> str:
    host = getattr(config, "workspace_url", None) or config.host or ""
    catalog = config.schema_name.split(".")[0] if "." in (config.schema_name or "") else "main"
    return f"databricks://{host}/{catalog}"
