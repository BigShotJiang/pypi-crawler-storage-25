"""Probe: unity_catalog.cost.storage — table storage sizes for FinOps."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCStorageCostProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.cost.storage"

    @staticmethod
    def description() -> str:
        return "Table storage sizes via DESCRIBE DETAIL for cost analysis"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        parts = schema.split(".")
        catalog = parts[0] if len(parts) >= 2 else "main"
        schema_name = parts[1] if len(parts) >= 2 else parts[0]

        if not connection.warehouse_id:
            return []

        # Get table list first
        try:
            resp = connection.get(f"/tables?catalog_name={catalog}&schema_name={schema_name}")
            resp.raise_for_status()
            tables = resp.json().get("tables", [])
        except Exception:
            return []

        results = []
        for t in tables:
            full_name = f"{catalog}.{schema_name}.{t['name']}"
            rows = connection.execute_sql_safe(f"DESCRIBE DETAIL `{full_name}`")
            if rows:
                r = rows[0]
                results.append({
                    "table_name": t["name"],
                    "qualified_name": full_name,
                    "format": r.get("format", ""),
                    "location": r.get("location", ""),
                    "num_files": r.get("numFiles", r.get("num_files")),
                    "size_bytes": r.get("sizeInBytes", r.get("size_in_bytes")),
                    "num_partitions": r.get("numPartitions", r.get("num_partitions")),
                    "created_at": r.get("createdAt", r.get("created_at", "")),
                    "last_modified": r.get("lastModified", r.get("last_modified", "")),
                })
        return results
