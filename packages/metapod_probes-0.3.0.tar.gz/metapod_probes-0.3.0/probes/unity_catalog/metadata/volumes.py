"""Probe: unity_catalog.metadata.volumes — list managed and external volumes."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCVolumesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.metadata.volumes"

    @staticmethod
    def description() -> str:
        return "List managed and external volumes with type and storage location"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        parts = schema.split(".")
        catalog = parts[0] if len(parts) >= 2 else "main"
        schema_name = parts[1] if len(parts) >= 2 else parts[0]

        try:
            resp = connection.get(f"/volumes?catalog_name={catalog}&schema_name={schema_name}")
            resp.raise_for_status()
        except Exception:
            return []

        return [
            {
                "name": v["name"],
                "catalog": v.get("catalog_name", catalog),
                "schema": v.get("schema_name", schema_name),
                "qualified_name": f"{v.get('catalog_name', catalog)}.{v.get('schema_name', schema_name)}.{v['name']}",
                "volume_type": v.get("volume_type", ""),
                "storage_location": v.get("storage_location", ""),
                "owner": v.get("owner", ""),
                "comment": v.get("comment", ""),
                "created_at": v.get("created_at"),
                "updated_at": v.get("updated_at"),
            }
            for v in resp.json().get("volumes", [])
        ]
