"""Probe: unity_catalog.metadata.catalogs — list all catalogs with metadata."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCCatalogsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.metadata.catalogs"

    @staticmethod
    def description() -> str:
        return "List all catalogs in the Unity Catalog metastore with owner, type, isolation mode"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/catalogs")
        resp.raise_for_status()
        return [
            {
                "name": c["name"],
                "comment": c.get("comment", ""),
                "owner": c.get("owner", ""),
                "catalog_type": c.get("catalog_type", ""),
                "isolation_mode": c.get("isolation_mode", ""),
                "created_at": c.get("created_at"),
                "updated_at": c.get("updated_at"),
            }
            for c in resp.json().get("catalogs", [])
        ]
