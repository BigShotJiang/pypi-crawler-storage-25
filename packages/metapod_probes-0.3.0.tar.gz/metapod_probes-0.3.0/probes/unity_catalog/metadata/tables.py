"""Probe: unity_catalog.metadata.tables — list tables/views with type and storage info."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.metadata.tables"

    @staticmethod
    def description() -> str:
        return "List tables, views, materialized views, and streaming tables with storage info"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        parts = schema.split(".")
        catalog = parts[0] if len(parts) >= 2 else "main"
        schema_name = parts[1] if len(parts) >= 2 else parts[0]

        resp = connection.get(f"/tables?catalog_name={catalog}&schema_name={schema_name}")
        resp.raise_for_status()

        results = []
        for t in resp.json().get("tables", []):
            # Map table_type to a normalized type
            raw_type = t.get("table_type", "TABLE")
            table_type = {
                "VIEW": "VIEW",
                "MATERIALIZED_VIEW": "MATERIALIZED_VIEW",
                "STREAMING_TABLE": "STREAMING_TABLE",
            }.get(raw_type, "TABLE")

            record = {
                "name": t["name"],
                "catalog": t.get("catalog_name", catalog),
                "schema": t.get("schema_name", schema_name),
                "qualified_name": f"{t.get('catalog_name', catalog)}.{t.get('schema_name', schema_name)}.{t['name']}",
                "table_type": table_type,
                "data_source_format": t.get("data_source_format", ""),
                "storage_location": t.get("storage_location", ""),
                "owner": t.get("owner", ""),
                "comment": t.get("comment", ""),
                "created_at": t.get("created_at"),
                "updated_at": t.get("updated_at"),
            }

            # View definition (if it's a view)
            if table_type in ("VIEW", "MATERIALIZED_VIEW"):
                record["view_definition"] = t.get("view_definition", "")

            # Custom properties (if any)
            props = t.get("properties", {})
            if props:
                record["properties"] = props

            results.append(record)

        return results
