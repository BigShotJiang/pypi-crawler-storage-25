"""Probe: unity_catalog.metadata.lineage — table and column lineage from system tables.

Extracts lineage from system.access.table_lineage and system.access.column_lineage
(requires SQL warehouse). Falls back to REST lineage-tracking API if no warehouse.

Deduplicates edges: multiple events for the same (source, target) pair are collapsed.
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCLineageProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.metadata.lineage"

    @staticmethod
    def description() -> str:
        return "Extract table and column lineage from system tables or lineage API"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # Prefer system tables (bulk, comprehensive), fall back to REST
        if connection.warehouse_id:
            results = self._via_system_tables(connection)
            if results:
                return results

        # Fallback to REST lineage API (per-table, limited)
        return self._via_rest(connection, schema, **kwargs)

    def _via_system_tables(self, connection) -> list[dict]:
        """Bulk lineage from system.access tables (deduplicated)."""
        results = []
        seen: set[tuple[str, str]] = set()

        # Table-level lineage
        rows = connection.execute_sql_safe(
            "SELECT source_table_full_name, target_table_full_name, "
            "source_type, target_type "
            "FROM system.access.table_lineage "
            "WHERE source_table_full_name IS NOT NULL "
            "AND target_table_full_name IS NOT NULL"
        )
        for r in rows:
            src = r.get("source_table_full_name", "")
            tgt = r.get("target_table_full_name", "")
            if not src or not tgt:
                continue
            key = (src, tgt)
            if key in seen:
                continue
            seen.add(key)
            results.append({
                "lineage_type": "table",
                "source_table": src,
                "target_table": tgt,
                "source_type": r.get("source_type", "TABLE"),
                "target_type": r.get("target_type", "TABLE"),
            })

        # Column-level lineage
        col_seen: set[tuple[str, str]] = set()
        rows = connection.execute_sql_safe(
            "SELECT source_table_full_name, source_column_name, "
            "target_table_full_name, target_column_name "
            "FROM system.access.column_lineage "
            "WHERE source_table_full_name IS NOT NULL "
            "AND target_table_full_name IS NOT NULL "
            "AND source_column_name IS NOT NULL "
            "AND target_column_name IS NOT NULL"
        )
        for r in rows:
            src_table = r.get("source_table_full_name", "")
            src_col = r.get("source_column_name", "")
            tgt_table = r.get("target_table_full_name", "")
            tgt_col = r.get("target_column_name", "")
            if not all([src_table, src_col, tgt_table, tgt_col]):
                continue
            src_qn = f"{src_table}.{src_col}"
            tgt_qn = f"{tgt_table}.{tgt_col}"
            key = (src_qn, tgt_qn)
            if key in col_seen:
                continue
            col_seen.add(key)
            results.append({
                "lineage_type": "column",
                "source_table": src_table,
                "source_column": src_col,
                "target_table": tgt_table,
                "target_column": tgt_col,
            })

        return results

    def _via_rest(self, connection, schema: str, **kwargs) -> list[dict]:
        """Fallback: per-table lineage via REST lineage-tracking API."""
        parts = schema.split(".")
        catalog = parts[0] if len(parts) >= 2 else "main"
        schema_name = parts[1] if len(parts) >= 2 else parts[0]

        resp = connection.get(f"/tables?catalog_name={catalog}&schema_name={schema_name}")
        resp.raise_for_status()
        tables = resp.json().get("tables", [])

        results = []
        for table in tables:
            full_name = f"{catalog}.{schema_name}.{table['name']}"
            try:
                lr = connection.get(f"/lineage-tracking/table-lineage?table_name={full_name}")
                if lr.status_code == 200:
                    for upstream in lr.json().get("upstreams", []):
                        info = upstream.get("tableInfo", {})
                        src = f"{info.get('catalog_name', '')}.{info.get('schema_name', '')}.{info.get('name', '')}"
                        results.append({
                            "lineage_type": "table",
                            "source_table": src,
                            "target_table": full_name,
                        })
            except Exception:
                pass

            try:
                cr = connection.get(f"/lineage-tracking/column-lineage?table_name={full_name}")
                if cr.status_code == 200:
                    for entry in cr.json().get("upstream_cols", []):
                        for src_col in entry.get("upstream_cols", []):
                            src_table = f"{src_col.get('catalog_name', '')}.{src_col.get('schema_name', '')}.{src_col.get('table_name', '')}"
                            results.append({
                                "lineage_type": "column",
                                "source_table": src_table,
                                "source_column": src_col.get("name", ""),
                                "target_table": full_name,
                                "target_column": entry.get("name", ""),
                            })
            except Exception:
                pass

        return results
