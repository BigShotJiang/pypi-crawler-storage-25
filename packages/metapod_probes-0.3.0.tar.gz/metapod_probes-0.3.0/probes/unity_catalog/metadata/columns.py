"""Probe: unity_catalog.metadata.columns — bulk column extraction via information_schema SQL.

Uses SQL Statement Execution API for bulk discovery (10x faster than per-table
REST calls). Falls back to REST API if warehouse_id is not configured.
"""

import re

from core.base_probe import BaseProbe
from core.registry import register

_SAFE_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


@register
class UCColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column definitions via information_schema SQL (bulk, fast)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        parts = schema.split(".")
        catalog = parts[0] if len(parts) >= 2 else "main"
        schema_name = parts[1] if len(parts) >= 2 else parts[0]

        # Prefer SQL information_schema (bulk, fast), fall back to REST
        if connection.warehouse_id:
            results = self._via_sql(connection, catalog, schema_name)
            if results:
                return results

        # Fallback to REST API (per-table, slower)
        return self._via_rest(connection, catalog, schema_name)

    def _via_sql(self, connection, catalog: str, schema_name: str) -> list[dict]:
        """Bulk column extraction via information_schema SQL."""
        if not (_SAFE_IDENTIFIER.match(catalog) and _SAFE_IDENTIFIER.match(schema_name)):
            return []  # Reject suspicious identifiers
        rows = connection.execute_sql_safe(
            f"SELECT * FROM `{catalog}`.`information_schema`.`columns` "
            f"WHERE table_schema = '{schema_name}' "
            f"ORDER BY table_name, ordinal_position"
        )
        results = []
        for r in rows:
            # Handle case-insensitive column names (Databricks returns lowercase)
            results.append({
                "table_name": r.get("table_name", r.get("TABLE_NAME", "")),
                "column_name": r.get("column_name", r.get("COLUMN_NAME", "")),
                "data_type": r.get("data_type", r.get("DATA_TYPE", "")),
                "full_data_type": r.get("full_data_type", r.get("FULL_DATA_TYPE", "")),
                "ordinal_position": int(r.get("ordinal_position", r.get("ORDINAL_POSITION", 0)) or 0),
                "nullable": r.get("is_nullable", r.get("IS_NULLABLE", "YES")) in ("YES", "yes", True),
                "column_default": r.get("column_default", r.get("COLUMN_DEFAULT", "")),
                "comment": r.get("comment", r.get("COMMENT", "")),
            })
        return results

    def _via_rest(self, connection, catalog: str, schema_name: str) -> list[dict]:
        """Fallback: per-table column extraction via REST API.

        The list endpoint doesn't include columns, so we fetch each table
        individually via GET /tables/{full_name}.
        """
        resp = connection.get(f"/tables?catalog_name={catalog}&schema_name={schema_name}")
        resp.raise_for_status()
        tables = resp.json().get("tables", [])

        results = []
        for table in tables:
            full_name = f"{catalog}.{schema_name}.{table['name']}"
            try:
                detail = connection.get(f"/tables/{full_name}")
                detail.raise_for_status()
                cols = detail.json().get("columns", [])
            except Exception:
                cols = table.get("columns", [])

            for col in cols:
                results.append({
                    "table_name": table["name"],
                    "column_name": col.get("name", ""),
                    "data_type": col.get("type_name", col.get("type_text", "")),
                    "ordinal_position": col.get("position", 0),
                    "nullable": col.get("nullable", True),
                    "comment": col.get("comment", ""),
                })
        return results
