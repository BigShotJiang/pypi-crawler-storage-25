"""Probe: unity_catalog.metadata.schemas — list schemas in a catalog."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCSchemasProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.metadata.schemas"

    @staticmethod
    def description() -> str:
        return "List all schemas in the specified catalog with owner and storage info"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        catalog = schema.split(".")[0] if "." in schema else (schema or "main")
        resp = connection.get(f"/schemas?catalog_name={catalog}")
        resp.raise_for_status()
        return [
            {
                "name": s["name"],
                "catalog": s.get("catalog_name", ""),
                "comment": s.get("comment", ""),
                "owner": s.get("owner", ""),
                "storage_root": s.get("storage_root", ""),
                "created_at": s.get("created_at"),
                "updated_at": s.get("updated_at"),
            }
            for s in resp.json().get("schemas", [])
        ]
