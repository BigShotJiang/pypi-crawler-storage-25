"""Probe: unity_catalog.governance.grants — extract RBAC grants on all securables.

Iterates catalogs → schemas → tables/views/volumes/functions and extracts
directly assigned privileges for each securable.

Output: one record per (principal, securable) pair with the privilege list.
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCGrantsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.governance.grants"

    @staticmethod
    def description() -> str:
        return "Extract Unity Catalog RBAC grants on catalogs, schemas, tables, volumes"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        parts = schema.split(".")
        catalog = parts[0] if parts[0] else "main"
        schema_filter = parts[1] if len(parts) >= 2 else None

        results = []

        # 1. Catalog-level grants
        self._collect_grants(connection, "catalog", catalog, results)

        # 2. Schema-level grants
        try:
            resp = connection.get(f"/schemas?catalog_name={catalog}")
            resp.raise_for_status()
            schemas = resp.json().get("schemas", [])
        except Exception:
            schemas = []

        for s in schemas:
            sname = s["name"]
            if schema_filter and sname != schema_filter:
                continue
            full_name = f"{catalog}.{sname}"
            self._collect_grants(connection, "schema", full_name, results)

            # 3. Table/view grants
            try:
                tresp = connection.get(f"/tables?catalog_name={catalog}&schema_name={sname}")
                tresp.raise_for_status()
                for t in tresp.json().get("tables", []):
                    tfull = f"{catalog}.{sname}.{t['name']}"
                    self._collect_grants(connection, "table", tfull, results)
            except Exception:
                pass

            # 4. Volume grants
            try:
                vresp = connection.get(f"/volumes?catalog_name={catalog}&schema_name={sname}")
                vresp.raise_for_status()
                for v in vresp.json().get("volumes", []):
                    vfull = f"{catalog}.{sname}.{v['name']}"
                    self._collect_grants(connection, "volume", vfull, results)
            except Exception:
                pass

        return results

    def _collect_grants(
        self, connection, securable_type: str, full_name: str, results: list[dict]
    ) -> None:
        """Fetch grants for a single securable and append to results."""
        try:
            resp = connection.get(f"/permissions/{securable_type}/{full_name}")
            if resp.status_code != 200:
                return
            data = resp.json()
        except Exception:
            return

        for assignment in data.get("privilege_assignments", []):
            principal = assignment.get("principal", "")
            privileges = [p.get("privilege", p) if isinstance(p, dict) else p
                          for p in assignment.get("privileges", [])]
            if not principal or not privileges:
                continue
            results.append({
                "principal": principal,
                "securable_type": securable_type.upper(),
                "securable_name": full_name,
                "privileges": privileges,
                "privilege_count": len(privileges),
            })
