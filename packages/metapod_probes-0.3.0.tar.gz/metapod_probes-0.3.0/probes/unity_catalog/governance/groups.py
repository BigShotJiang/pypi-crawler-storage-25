"""Probe: unity_catalog.governance.groups — extract workspace groups and members.

Uses the SCIM 2.0 API to list all groups and their members (users, service
principals, nested groups). Produces one record per group-member pair.
"""

import httpx

from core.base_probe import BaseProbe
from core.registry import register


@register
class UCGroupsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.governance.groups"

    @staticmethod
    def description() -> str:
        return "Extract workspace groups and their members via SCIM API"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # SCIM API is at /api/2.0, not /api/2.1/unity-catalog
        # We need to call the workspace root, not the UC base URL
        host = connection._host
        headers = dict(connection.api.headers)
        headers["Accept"] = "application/scim+json"

        results = []
        start_index = 1
        page_size = 100

        while True:
            try:
                resp = httpx.get(
                    f"{host}/api/2.0/preview/scim/v2/Groups",
                    headers=headers,
                    params={"startIndex": start_index, "count": page_size},
                    timeout=30,
                )
                resp.raise_for_status()
                data = resp.json()
            except Exception:
                break

            resources = data.get("Resources", [])
            if not resources:
                break

            for group in resources:
                group_id = group.get("id", "")
                group_name = group.get("displayName", "")
                members = group.get("members", [])

                if not members:
                    # Group with no members — still record it
                    results.append({
                        "group_id": group_id,
                        "group_name": group_name,
                        "member_count": 0,
                        "member_id": "",
                        "member_name": "",
                        "member_type": "",
                    })
                    continue

                for member in members:
                    # Determine member type from $ref URL
                    ref = member.get("$ref", "")
                    if "/Users/" in ref:
                        member_type = "USER"
                    elif "/ServicePrincipals/" in ref:
                        member_type = "SERVICE_PRINCIPAL"
                    elif "/Groups/" in ref:
                        member_type = "GROUP"
                    else:
                        member_type = "UNKNOWN"

                    results.append({
                        "group_id": group_id,
                        "group_name": group_name,
                        "member_count": len(members),
                        "member_id": member.get("value", ""),
                        "member_name": member.get("display", ""),
                        "member_type": member_type,
                    })

            total = data.get("totalResults", 0)
            start_index += page_size
            if start_index > total:
                break

        return results
