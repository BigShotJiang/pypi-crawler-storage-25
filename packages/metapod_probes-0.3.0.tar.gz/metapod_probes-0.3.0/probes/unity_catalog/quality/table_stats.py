"""Probe: unity_catalog.quality.table_stats — row counts and sizes from DESCRIBE DETAIL."""

import re

from core.base_probe import BaseProbe
from core.registry import register

_SAFE_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


@register
class UCTableStatsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "unity_catalog.quality.table_stats"

    @staticmethod
    def description() -> str:
        return "Table-level stats: row count, size, file count, partitions from information_schema"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        parts = schema.split(".")
        catalog = parts[0] if len(parts) >= 2 else "main"
        schema_name = parts[1] if len(parts) >= 2 else parts[0]

        if not connection.warehouse_id:
            return []
        if not (_SAFE_IDENTIFIER.match(catalog) and _SAFE_IDENTIFIER.match(schema_name)):
            return []

        rows = connection.execute_sql_safe(f"""
            SELECT table_name, table_type, comment,
                   created, created_by, last_altered, last_altered_by
            FROM `{catalog}`.`information_schema`.`tables`
            WHERE table_schema = '{schema_name}'
            ORDER BY table_name
        """)
        return [{
            "table_name": r.get("table_name", ""),
            "table_type": r.get("table_type", ""),
            "comment": r.get("comment", ""),
            "created": r.get("created", ""),
            "created_by": r.get("created_by", ""),
            "last_altered": r.get("last_altered", ""),
            "last_altered_by": r.get("last_altered_by", ""),
        } for r in rows]
