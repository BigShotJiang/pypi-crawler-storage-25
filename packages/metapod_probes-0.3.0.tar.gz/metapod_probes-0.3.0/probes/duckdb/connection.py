"""DuckDB connection factory."""
from __future__ import annotations
from core.config import SourceConfig

def connect(config: SourceConfig):
    try:
        import duckdb
    except ImportError:
        raise ConnectionError("duckdb not installed. Run: pip install duckdb")
    db_path = config.host or ":memory:"
    return duckdb.connect(db_path, read_only=True)

def source_id(config: SourceConfig) -> str:
    return f"duckdb://{config.host or ':memory:'}/{config.schema_name}"
