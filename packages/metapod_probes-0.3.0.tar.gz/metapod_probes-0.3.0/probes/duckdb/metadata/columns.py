"""Probe: duckdb.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class DuckDbColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "duckdb.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions from DuckDB"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        result = connection.execute(
            "SELECT table_name, column_name, data_type, is_nullable, ordinal_position, column_default FROM information_schema.columns WHERE table_schema = ? ORDER BY table_name, ordinal_position",
            [schema or "main"]
        ).fetchall()
        return [{"table_name": r[0], "column_name": r[1], "data_type": r[2], "nullable": r[3] == "YES", "position": r[4], "default": r[5]} for r in result]
