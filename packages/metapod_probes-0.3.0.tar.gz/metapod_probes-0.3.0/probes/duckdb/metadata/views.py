"""Probe: duckdb.metadata.views"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class DuckDbViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "duckdb.metadata.views"
    @staticmethod
    def description() -> str: return "Extract view definitions from DuckDB"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # Column is view_name in DuckDB >= 0.10; fall back to table_name
        try:
            result = connection.execute(
                "SELECT view_name, sql FROM duckdb_views() WHERE schema_name = ? ORDER BY view_name",
                [schema or "main"]
            ).fetchall()
        except Exception:
            result = connection.execute(
                "SELECT table_name, sql FROM duckdb_views() WHERE schema_name = ? ORDER BY table_name",
                [schema or "main"]
            ).fetchall()
        return [{"view_name": r[0], "sql_text": r[1] or ""} for r in result]
