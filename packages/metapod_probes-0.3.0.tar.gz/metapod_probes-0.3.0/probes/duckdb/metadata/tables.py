"""Probe: duckdb.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class DuckDbTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "duckdb.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables from DuckDB information_schema"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # estimated_size only exists in newer DuckDB; fall back gracefully
        try:
            result = connection.execute(
                "SELECT table_name, table_type, estimated_size FROM information_schema.tables WHERE table_schema = ? ORDER BY table_name",
                [schema or "main"]
            ).fetchall()
            return [{"table_name": r[0], "table_type": r[1], "estimated_size": r[2]} for r in result]
        except Exception:
            result = connection.execute(
                "SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = ? ORDER BY table_name",
                [schema or "main"]
            ).fetchall()
            return [{"table_name": r[0], "table_type": r[1], "estimated_size": None} for r in result]
