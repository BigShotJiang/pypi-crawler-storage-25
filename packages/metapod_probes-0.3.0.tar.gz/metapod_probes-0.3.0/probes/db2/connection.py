"""IBM DB2 connection — via ibm_db_dbi (DB-API 2.0 wrapper)."""
from __future__ import annotations
from core.config import SourceConfig

def connect(config: SourceConfig):
    try:
        import ibm_db_dbi
    except ImportError:
        raise ConnectionError("ibm_db not installed. Run: pip install ibm_db")
    try:
        conn_str = f"DATABASE={config.service_name or config.schema_name};HOSTNAME={config.host};PORT={config.port or 50000};PROTOCOL=TCPIP;UID={config.username};PWD={config.password};"
        return ibm_db_dbi.connect(conn_str)
    except Exception as e:
        raise ConnectionError(f"DB2 connection failed: {e}")

def source_id(config: SourceConfig) -> str:
    return f"db2://{config.host}:{config.port or 50000}/{config.service_name}/{config.schema_name}"
