"""Probe: db2.metadata.views"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class Db2ViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "db2.metadata.views"
    @staticmethod
    def description() -> str: return "Extract view definitions from SYSCAT.VIEWS"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT VIEWNAME, TEXT FROM SYSCAT.VIEWS WHERE VIEWSCHEMA = ? ORDER BY VIEWNAME", (schema.upper(),))
        return [{"view_name": r[0], "sql_text": r[1] or ""} for r in cur.fetchall()]
