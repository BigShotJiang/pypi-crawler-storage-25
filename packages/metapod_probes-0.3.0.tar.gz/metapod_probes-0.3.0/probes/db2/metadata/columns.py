"""Probe: db2.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class Db2ColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "db2.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions from SYSCAT.COLUMNS"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT TABNAME, COLNAME, TYPENAME, LENGTH, SCALE, NULLS, COLNO, DEFAULT, REMARKS FROM SYSCAT.COLUMNS WHERE TABSCHEMA = ? ORDER BY TABNAME, COLNO", (schema.upper(),))
        return [{"table_name": r[0], "column_name": r[1], "data_type": r[2], "length": r[3], "scale": r[4], "nullable": r[5] == "Y", "position": r[6], "default": r[7], "remarks": r[8] or ""} for r in cur.fetchall()]
