"""Probe: db2.metadata.routines — stored procedures and functions."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class Db2RoutinesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "db2.metadata.routines"
    @staticmethod
    def description() -> str: return "Extract stored procedures and functions from SYSCAT.ROUTINES"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT ROUTINENAME, ROUTINETYPE, LANGUAGE, TEXT, CREATE_TIME FROM SYSCAT.ROUTINES WHERE ROUTINESCHEMA = ? ORDER BY ROUTINENAME", (schema.upper(),))
        return [{"name": r[0], "type": {"F": "FUNCTION", "P": "PROCEDURE"}.get(r[1], r[1]), "language": r[2], "source_code": r[3] or "", "created": str(r[4]) if r[4] else None} for r in cur.fetchall()]
