"""Probe: db2.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class Db2TablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "db2.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables from SYSCAT.TABLES"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT TABNAME, TYPE, CARD, CREATE_TIME, ALTER_TIME, REMARKS FROM SYSCAT.TABLES WHERE TABSCHEMA = ? ORDER BY TABNAME", (schema.upper(),))
        return [{"table_name": r[0], "type": r[1], "row_count": r[2], "created": str(r[3]) if r[3] else None, "altered": str(r[4]) if r[4] else None, "remarks": r[5] or ""} for r in cur.fetchall()]
