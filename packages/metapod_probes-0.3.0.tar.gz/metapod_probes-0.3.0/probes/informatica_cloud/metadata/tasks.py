"""Probe: informatica_cloud.metadata.tasks — list IICS tasks (synchronization, mapping tasks, etc.)."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class IICSTasksProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_cloud.metadata.tasks"
    @staticmethod
    def description() -> str: return "List IICS tasks with type, schedule, and last run status"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/api/v2/task")
        resp.raise_for_status()
        return [{
            "name": t.get("name", ""), "id": t.get("id", ""),
            "type": t.get("type", ""),
            "description": t.get("description", ""),
            "schedule": t.get("schedule", ""),
            "last_run_status": t.get("lastRunStatus", ""),
            "last_run_time": t.get("lastRunTime", ""),
        } for t in resp.json()]
