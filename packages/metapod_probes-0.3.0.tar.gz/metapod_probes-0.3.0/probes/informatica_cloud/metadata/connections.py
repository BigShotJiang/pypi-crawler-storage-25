"""Probe: informatica_cloud.metadata.connections — list IICS connections."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class IICSConnectionsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_cloud.metadata.connections"
    @staticmethod
    def description() -> str: return "List all IICS connections with type, host, database info"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/api/v2/connection")
        resp.raise_for_status()
        return [{
            "name": c.get("name", ""), "id": c.get("id", ""),
            "type": c.get("type", ""), "host": c.get("host", ""),
            "database": c.get("database", ""), "schema": c.get("codepage", ""),
            "description": c.get("description", ""),
        } for c in resp.json()]
