"""Probe: informatica_cloud.metadata.mappings — list IICS mappings with source/target."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class IICSMappingsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_cloud.metadata.mappings"
    @staticmethod
    def description() -> str: return "List IICS mappings with source/target connections and field counts"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/api/v2/mapping")
        resp.raise_for_status()
        results = []
        for m in resp.json():
            results.append({
                "name": m.get("name", ""), "id": m.get("id", ""),
                "description": m.get("description", ""),
                "src_connection": m.get("srcConnectionName", ""),
                "tgt_connection": m.get("tgtConnectionName", ""),
                "src_object": m.get("srcObject", ""),
                "tgt_object": m.get("tgtObject", ""),
                "field_count": len(m.get("fieldMappings", {}).get("fieldMapping", [])),
                "updated_at": m.get("updateTime", ""),
            })
        return results
