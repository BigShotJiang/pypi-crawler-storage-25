"""Probe: informatica_cloud.metadata.field_mappings — extract field-level lineage from mappings."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class IICSFieldMappingsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_cloud.metadata.field_mappings"
    @staticmethod
    def description() -> str: return "Extract field-level source→target mappings with transformation expressions"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/api/v2/mapping")
        resp.raise_for_status()
        results = []
        for m in resp.json():
            mapping_name = m.get("name", "")
            field_maps = m.get("fieldMappings", {}).get("fieldMapping", [])
            for fm in field_maps:
                results.append({
                    "mapping": mapping_name,
                    "source_field": fm.get("srcFieldName", ""),
                    "target_field": fm.get("tgtFieldName", ""),
                    "expression": fm.get("expression", ""),
                    "source_object": m.get("srcObject", ""),
                    "target_object": m.get("tgtObject", ""),
                })
        return results
