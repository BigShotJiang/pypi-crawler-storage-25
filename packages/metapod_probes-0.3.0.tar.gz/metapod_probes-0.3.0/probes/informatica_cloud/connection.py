"""Informatica Intelligent Cloud Services (IICS) — REST API v2/v3.

Config:
  host = IICS pod URL (e.g., "https://dm-us.informaticacloud.com")
  username = IICS username
  password = IICS password
  schema_name = org_id (optional, auto-detected from login)
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    """Authenticate to IICS and return an authorized API client."""
    base_url = config.host.rstrip("/") if config.host else "https://dm-us.informaticacloud.com"

    # Login to get session ID and server URL
    login_resp = httpx.post(
        f"{base_url}/saas/public/core/v3/login",
        json={"username": config.username, "password": config.password},
        timeout=30,
    )
    login_resp.raise_for_status()
    login_data = login_resp.json()

    session_id = login_data.get("userInfo", {}).get("sessionId", "")
    server_url = login_data.get("products", [{}])[0].get("baseApiUrl", base_url)

    if not session_id:
        raise ConnectionError("IICS login failed — no session ID returned")

    return httpx.Client(
        base_url=server_url.rstrip("/"),
        headers={
            "INFA-SESSION-ID": session_id,
            "Accept": "application/json",
        },
        timeout=30,
    )


def source_id(config: SourceConfig) -> str:
    return f"iics://{config.host}/{config.schema_name or 'default'}"
