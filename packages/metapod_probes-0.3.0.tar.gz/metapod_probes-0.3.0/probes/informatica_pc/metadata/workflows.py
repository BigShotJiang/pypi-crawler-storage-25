"""Probe: informatica_pc.metadata.workflows — extract workflow/session definitions."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PCWorkflowsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_pc.metadata.workflows"
    @staticmethod
    def description() -> str: return "Extract PowerCenter workflows and sessions with scheduling info"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export: continue
            root = export["root"]
            for wf in root.iter("WORKFLOW"):
                sessions = []
                for sess in wf.iter("SESSION"):
                    mapping_ref = ""
                    for attr in sess.iter("ATTRIBUTE"):
                        if attr.get("NAME") == "Mapping Name":
                            mapping_ref = attr.get("VALUE", "")
                    sessions.append({
                        "name": sess.get("NAME", ""),
                        "mapping": mapping_ref or sess.get("MAPPINGNAME", ""),
                        "reusable": sess.get("REUSABLE", ""),
                    })
                results.append({
                    "file": export["file"],
                    "workflow_name": wf.get("NAME", ""),
                    "description": wf.get("DESCRIPTION", ""),
                    "scheduler": wf.get("SCHEDULERNAME", ""),
                    "session_count": len(sessions),
                    "sessions": sessions[:20],
                })
        return results
