"""Probe: informatica_pc.metadata.sources_targets — extract source/target definitions with fields."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PCSourcesTargetsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_pc.metadata.sources_targets"
    @staticmethod
    def description() -> str: return "Extract PowerCenter source and target definitions with field schemas"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export: continue
            root = export["root"]
            for tag in ("SOURCE", "TARGET"):
                for obj in root.iter(tag):
                    fields = []
                    for field in obj.iter("SOURCEFIELD" if tag == "SOURCE" else "TARGETFIELD"):
                        fields.append({
                            "name": field.get("NAME", ""),
                            "datatype": field.get("DATATYPE", ""),
                            "precision": field.get("PRECISION", ""),
                            "scale": field.get("SCALE", ""),
                            "nullable": field.get("NULLABLE", "") != "NOTNULL",
                        })
                    results.append({
                        "file": export["file"],
                        "direction": tag,
                        "name": obj.get("NAME", ""),
                        "database_type": obj.get("DATABASETYPE", ""),
                        "db_name": obj.get("DBDNAME", obj.get("DATABASENAME", "")),
                        "owner": obj.get("OWNERNAME", ""),
                        "field_count": len(fields),
                        "fields": fields[:50],
                    })
        return results
