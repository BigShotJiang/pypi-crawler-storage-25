"""Probe: informatica_pc.metadata.field_lineage — extract field-level lineage from CONNECTOR elements.

This is the core lineage probe for PowerCenter. CONNECTOR elements define
the actual field-to-field data flow through the mapping pipeline.
"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PCFieldLineageProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_pc.metadata.field_lineage"
    @staticmethod
    def description() -> str: return "Extract field-level lineage from PowerCenter mapping CONNECTORs"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export: continue
            root = export["root"]
            for mapping in root.iter("MAPPING"):
                mapping_name = mapping.get("NAME", "")
                for conn in mapping.iter("CONNECTOR"):
                    results.append({
                        "file": export["file"],
                        "mapping": mapping_name,
                        "from_instance": conn.get("FROMINSTANCE", ""),
                        "from_field": conn.get("FROMFIELD", ""),
                        "from_type": conn.get("FROMINSTANCETYPE", ""),
                        "to_instance": conn.get("TOINSTANCE", ""),
                        "to_field": conn.get("TOFIELD", ""),
                        "to_type": conn.get("TOINSTANCETYPE", ""),
                    })
        return results
