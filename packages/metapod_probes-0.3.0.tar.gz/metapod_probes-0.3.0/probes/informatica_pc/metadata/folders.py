"""Probe: informatica_pc.metadata.folders — extract folder structure from PowerCenter XML."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PCFoldersProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_pc.metadata.folders"
    @staticmethod
    def description() -> str: return "Extract PowerCenter repository folder structure"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export: results.append(export); continue
            root = export["root"]
            for folder in root.iter("FOLDER"):
                name = folder.get("NAME", "")
                results.append({
                    "file": export["file"], "folder_name": name,
                    "description": folder.get("DESCRIPTION", ""),
                    "owner": folder.get("OWNER", ""),
                    "mappings": len(list(folder.iter("MAPPING"))),
                    "sessions": len(list(folder.iter("SESSION"))),
                    "workflows": len(list(folder.iter("WORKFLOW"))),
                    "sources": len(list(folder.iter("SOURCE"))),
                    "targets": len(list(folder.iter("TARGET"))),
                })
        return results
