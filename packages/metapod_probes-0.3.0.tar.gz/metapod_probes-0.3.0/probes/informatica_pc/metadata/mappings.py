"""Probe: informatica_pc.metadata.mappings — extract mapping definitions with transformations."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PCMappingsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "informatica_pc.metadata.mappings"
    @staticmethod
    def description() -> str: return "Extract PowerCenter mappings with source/target/transformation chain"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export: continue
            root = export["root"]
            for mapping in root.iter("MAPPING"):
                name = mapping.get("NAME", "")
                # Collect transformation types
                transforms = []
                for t in mapping.iter("TRANSFORMATION"):
                    transforms.append({
                        "name": t.get("NAME", ""),
                        "type": t.get("TYPE", ""),
                        "description": t.get("DESCRIPTION", ""),
                    })
                # Collect instances (source/target/transform instances in the flow)
                instances = []
                for inst in mapping.iter("INSTANCE"):
                    instances.append({
                        "name": inst.get("NAME", ""),
                        "type": inst.get("TYPE", inst.get("TRANSFORMATION_TYPE", "")),
                        "reusable": inst.get("REUSABLE", ""),
                    })
                # Collect connectors (the actual data flow links)
                connectors = []
                for conn in mapping.iter("CONNECTOR"):
                    connectors.append({
                        "from_instance": conn.get("FROMINSTANCE", ""),
                        "from_field": conn.get("FROMFIELD", ""),
                        "to_instance": conn.get("TOINSTANCE", ""),
                        "to_field": conn.get("TOFIELD", ""),
                        "from_type": conn.get("FROMINSTANCETYPE", ""),
                        "to_type": conn.get("TOINSTANCETYPE", ""),
                    })
                results.append({
                    "file": export["file"],
                    "mapping_name": name,
                    "description": mapping.get("DESCRIPTION", ""),
                    "transformation_count": len(transforms),
                    "transformations": transforms[:30],
                    "instance_count": len(instances),
                    "connector_count": len(connectors),
                })
        return results
