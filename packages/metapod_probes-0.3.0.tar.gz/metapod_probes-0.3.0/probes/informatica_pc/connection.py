"""Informatica PowerCenter metadata extraction — from repository XML export.

PowerCenter exports via `pmrep ObjectExport` or Repository Manager produce XML
files with the POWERMART DTD containing: folders, workflows, sessions, mappings,
sources, targets, transformations, and field-level mapplets.

Config:
  host = directory containing exported XML files
  schema_name = specific file (optional)
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from core.config import SourceConfig


def get_exports(config: SourceConfig) -> list[dict]:
    """Parse PowerCenter repository XML exports."""
    directory = Path(config.host or ".")
    target = config.schema_name or ""

    files = []
    if target:
        p = directory / target
        if p.exists():
            files = [p]
    else:
        files = list(directory.glob("*.xml")) + list(directory.glob("*.XML"))

    exports = []
    for f in files:
        try:
            content = f.read_text(encoding="utf-8", errors="replace")[:500]
            # Check if it's a PowerCenter export (POWERMART DTD)
            if "POWERMART" in content.upper() or "REPOSITORY" in content.upper():
                root = ET.parse(str(f)).getroot()
                exports.append({"file": f.name, "path": str(f), "root": root})
        except Exception as e:
            exports.append({"file": f.name, "path": str(f), "error": str(e)})

    return exports


def source_id(config: SourceConfig) -> str:
    return f"informatica_pc://{config.host}"
