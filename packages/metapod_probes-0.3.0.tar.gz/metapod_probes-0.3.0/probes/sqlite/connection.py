"""SQLite connection — stdlib, no extra deps."""
from __future__ import annotations
import sqlite3
from core.config import SourceConfig

def connect(config: SourceConfig):
    db_path = config.host or config.schema_name or ":memory:"
    return sqlite3.connect(db_path)

def source_id(config: SourceConfig) -> str:
    return f"sqlite://{config.host or config.schema_name}"
