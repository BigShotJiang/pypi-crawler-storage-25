"""Probe: sqlite.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class SqliteTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "sqlite.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables and views from sqlite_master"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT name, type, sql FROM sqlite_master WHERE type IN ('table', 'view') AND name NOT LIKE 'sqlite_%' ORDER BY name")
        return [{"name": r[0], "type": r[1], "sql": r[2] or ""} for r in cur.fetchall()]
