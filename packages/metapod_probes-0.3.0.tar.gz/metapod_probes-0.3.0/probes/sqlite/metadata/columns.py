"""Probe: sqlite.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class SqliteColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "sqlite.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions via PRAGMA table_info"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        tables = [r[0] for r in cur.fetchall()]
        results = []
        for tbl in tables:
            cur.execute(f"PRAGMA table_info([{tbl}])")
            for r in cur.fetchall():
                results.append({"table_name": tbl, "column_name": r[1], "data_type": r[2], "not_null": bool(r[3]), "default": r[4], "is_pk": bool(r[5])})
        return results
