"""Azure Data Lake Storage Gen2 connection — via azure-identity + azure-storage-file-datalake."""

from __future__ import annotations

from core.config import SourceConfig


def get_client(config: SourceConfig):
    """Create a DataLakeServiceClient.

    Config mapping:
      host = storage account name (e.g., "mydatalake")
      token = SAS token or account key (optional if using Azure AD)
      username = client_id (for Service Principal)
      password = client_secret
      service_name = tenant_id
      schema_name = filesystem/container name
    """
    account_name = config.host
    if not account_name:
        raise ConnectionError("host = storage account name required for ADLS Gen2")

    account_url = f"https://{account_name}.dfs.core.windows.net"

    try:
        from azure.storage.filedatalake import DataLakeServiceClient
    except ImportError:
        raise ConnectionError(
            "azure-storage-file-datalake not installed. "
            "Run: pip install azure-storage-file-datalake azure-identity"
        )

    # Auth: SAS token > account key > Service Principal > Default
    if config.token and ("sig=" in config.token or "sv=" in config.token):
        return DataLakeServiceClient(account_url=account_url, credential=config.token)
    elif config.token:
        # Treat as account key
        return DataLakeServiceClient(account_url=account_url, credential=config.token)
    else:
        try:
            from azure.identity import ClientSecretCredential, DefaultAzureCredential

            if config.username and config.password and config.service_name:
                credential = ClientSecretCredential(
                    tenant_id=config.service_name,
                    client_id=config.username,
                    client_secret=config.password,
                )
            else:
                credential = DefaultAzureCredential()
            return DataLakeServiceClient(account_url=account_url, credential=credential)
        except ImportError:
            raise ConnectionError("azure-identity not installed.")


def source_id(config: SourceConfig) -> str:
    return f"adls://{config.host}/{config.schema_name}"
