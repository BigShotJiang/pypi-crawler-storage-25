"""Probe: adls_gen2.metadata.auto_scan — recursive ADLS scan with schema sampling."""

import csv
import io
import json
import re
from collections import defaultdict

from core.base_probe import BaseProbe
from core.registry import register

FORMAT_MAP = {"parquet": "PARQUET", "pq": "PARQUET", "csv": "CSV", "tsv": "TSV",
              "json": "JSON", "jsonl": "JSONL", "avro": "AVRO", "orc": "ORC", "xlsx": "EXCEL"}
PARTITION_RE = [
    (r"(\d{4})-(\d{2})-(\d{2})", "yyyy-mm-dd"), (r"(\d{4})-(\d{2})", "yyyy-mm"),
    (r"year=(\d{4})", "hive_year"), (r"month=(\d{1,2})", "hive_month"),
    (r"date=(\d{4}-\d{2}-\d{2})", "hive_date"), (r"(\w+)=(\w+)", "hive_generic"),
]


@register
class ADLSAutoScanProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "adls_gen2.metadata.auto_scan"
    @staticmethod
    def description() -> str:
        return "Recursive ADLS Gen2 scan: format detection, partition clustering, CSV/JSON schema sampling"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        fs_name = schema
        if not fs_name: return []

        fs_client = connection.get_file_system_client(fs_name)
        datasets: dict[str, dict] = defaultdict(lambda: {
            "files": 0, "bytes": 0, "format": "", "partitions": set(), "ptype": "", "samples": [],
        })

        for path in fs_client.get_paths(recursive=True, max_results=10000):
            if path.is_directory: continue
            name = path.name
            ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
            fmt = FORMAT_MAP.get(ext)
            if not fmt: continue

            ds_name = _ds_name(name)
            ds = datasets[ds_name]
            ds["files"] += 1
            ds["bytes"] += path.content_length or 0
            ds["format"] = fmt
            if len(ds["samples"]) < 3: ds["samples"].append(name)
            for pat, ptype in PARTITION_RE:
                m = re.search(pat, name)
                if m:
                    ds["partitions"].add(m.group(0))
                    if not ds["ptype"]: ds["ptype"] = ptype

        results = []
        for name, ds in sorted(datasets.items()):
            results.append({
                "type": "dataset", "name": name, "format": ds["format"],
                "file_count": ds["files"], "total_bytes": ds["bytes"],
                "partition_type": ds["ptype"], "partition_count": len(ds["partitions"]),
                "sample_paths": ds["samples"],
            })

        # Schema sampling for CSV/JSON
        for name, ds in sorted(datasets.items(), key=lambda x: -x[1]["files"]):
            if ds["format"] in ("CSV", "TSV") and ds["samples"]:
                sch = _sample_csv(fs_client, ds["samples"][0])
                if sch: results.append({"type": "schema", "dataset": name, **sch})
            elif ds["format"] in ("JSON", "JSONL") and ds["samples"]:
                sch = _sample_json(fs_client, ds["samples"][0])
                if sch: results.append({"type": "schema", "dataset": name, **sch})
            if len([r for r in results if r["type"] == "schema"]) >= 20: break

        return results


def _ds_name(path: str) -> str:
    parts = path.split("/")
    if "." in parts[-1]: parts = parts[:-1]
    parts = [p for p in parts if "=" not in p and not re.match(r"^\d{4}(-\d{2}){0,2}$", p)]
    return "/".join(parts) or path.rsplit("/", 1)[0]


def _sample_csv(fs, path: str) -> dict | None:
    try:
        fc = fs.get_file_client(path)
        data = fc.download_file(length=51200).readall().decode("utf-8", errors="replace")
        reader = csv.reader(io.StringIO(data))
        rows = [r for i, r in enumerate(reader) if i < 20]
        if len(rows) < 2: return None
        return {"format": "CSV", "columns": [{"name": h.strip(), "pos": i} for i, h in enumerate(rows[0])], "column_count": len(rows[0])}
    except Exception: return None


def _sample_json(fs, path: str) -> dict | None:
    try:
        fc = fs.get_file_client(path)
        data = fc.download_file(length=51200).readall().decode("utf-8", errors="replace")
        obj = json.loads(data.split("\n")[0])
        if isinstance(obj, dict):
            return {"format": "JSON", "columns": [{"name": k, "type": type(v).__name__} for k, v in obj.items()], "column_count": len(obj)}
    except Exception: return None
