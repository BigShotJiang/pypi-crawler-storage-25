"""Probe: adls_gen2.metadata.paths — list files and directories in a filesystem."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADLSPathsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "adls_gen2.metadata.paths"

    @staticmethod
    def description() -> str:
        return "List files and directories in an ADLS Gen2 filesystem with size and format"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        fs_name = schema or kwargs.get("filesystem", "")
        if not fs_name:
            return []

        fs_client = connection.get_file_system_client(fs_name)
        results = []
        for path in fs_client.get_paths(recursive=True, max_results=5000):
            ext = path.name.rsplit(".", 1)[-1].lower() if "." in path.name else ""
            results.append({
                "path": path.name,
                "is_directory": path.is_directory,
                "size_bytes": path.content_length if not path.is_directory else 0,
                "last_modified": str(path.last_modified) if path.last_modified else None,
                "format": _infer_format(ext),
                "extension": ext,
                "owner": path.owner or "",
                "group": path.group or "",
                "permissions": path.permissions or "",
            })
        return results


def _infer_format(ext: str) -> str:
    formats = {
        "parquet": "PARQUET", "pq": "PARQUET",
        "csv": "CSV", "tsv": "CSV",
        "json": "JSON", "jsonl": "JSON",
        "avro": "AVRO",
        "orc": "ORC",
        "delta": "DELTA",
        "xlsx": "EXCEL", "xls": "EXCEL",
        "sql": "SQL",
        "xml": "XML",
    }
    return formats.get(ext, "UNKNOWN" if ext else "DIRECTORY")
