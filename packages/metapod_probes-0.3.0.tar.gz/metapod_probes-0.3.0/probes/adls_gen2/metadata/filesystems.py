"""Probe: adls_gen2.metadata.filesystems — list all ADLS Gen2 filesystems/containers."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADLSFilesystemsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "adls_gen2.metadata.filesystems"

    @staticmethod
    def description() -> str:
        return "List all filesystems (containers) in the ADLS Gen2 storage account"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for fs in connection.list_file_systems():
            results.append({
                "name": fs.name,
                "last_modified": str(fs.last_modified) if fs.last_modified else None,
                "lease_status": fs.lease.get("status") if hasattr(fs, "lease") and fs.lease else None,
            })
        return results
