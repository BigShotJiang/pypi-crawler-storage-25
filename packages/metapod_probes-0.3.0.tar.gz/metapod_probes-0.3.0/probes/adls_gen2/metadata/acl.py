"""Probe: adls_gen2.metadata.acl — extract ACL/permissions on key paths."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADLSAclProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "adls_gen2.metadata.acl"

    @staticmethod
    def description() -> str:
        return "Extract ACL permissions on top-level directories in ADLS Gen2 filesystem"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        fs_name = schema or kwargs.get("filesystem", "")
        if not fs_name:
            return []

        fs_client = connection.get_file_system_client(fs_name)
        results = []

        # Get top-level directories and their ACLs
        for path in fs_client.get_paths(recursive=False, max_results=200):
            if path.is_directory:
                try:
                    dir_client = fs_client.get_directory_client(path.name)
                    props = dir_client.get_access_control()
                    results.append({
                        "path": path.name,
                        "owner": props.get("owner", ""),
                        "group": props.get("group", ""),
                        "permissions": props.get("permissions", ""),
                        "acl": props.get("acl", ""),
                    })
                except Exception:
                    results.append({"path": path.name, "error": "ACL read denied"})
        return results
