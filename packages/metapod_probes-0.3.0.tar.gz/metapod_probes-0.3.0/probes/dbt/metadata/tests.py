"""Probe: dbt.metadata.tests — extract dbt test definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class DbtTestsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "dbt.metadata.tests"

    @staticmethod
    def description() -> str:
        return "Extract dbt test definitions (schema tests, data tests, custom tests)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        manifest = connection.get("manifest", {})
        nodes = manifest.get("nodes", {})
        return [
            {
                "unique_id": key,
                "name": n.get("name", ""),
                "test_type": n.get("test_metadata", {}).get("name", "custom"),
                "model": n.get("depends_on", {}).get("nodes", [None])[0] or "",
                "column": n.get("column_name", ""),
                "severity": n.get("config", {}).get("severity", "ERROR"),
                "tags": n.get("tags", []),
            }
            for key, n in nodes.items()
            if n.get("resource_type") == "test"
        ]
