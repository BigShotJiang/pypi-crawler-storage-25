"""Probe: dbt.metadata.sources — extract dbt source definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class DbtSourcesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "dbt.metadata.sources"

    @staticmethod
    def description() -> str:
        return "Extract dbt source definitions (external tables/views referenced by models)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        manifest = connection.get("manifest", {})
        sources = manifest.get("sources", {})
        return [
            {
                "unique_id": key,
                "name": s.get("name", ""),
                "source_name": s.get("source_name", ""),
                "schema": s.get("schema", ""),
                "database": s.get("database", ""),
                "description": s.get("description", ""),
                "loader": s.get("loader", ""),
                "freshness": s.get("freshness", {}),
                "columns": [
                    {"name": c["name"], "description": c.get("description", "")}
                    for c in s.get("columns", {}).values()
                ],
            }
            for key, s in sources.items()
        ]
