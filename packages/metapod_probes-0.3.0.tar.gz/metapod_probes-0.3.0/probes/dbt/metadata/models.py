"""Probe: dbt.metadata.models — extract dbt model definitions and lineage."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class DbtModelsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "dbt.metadata.models"

    @staticmethod
    def description() -> str:
        return "Extract dbt models with SQL, materialization, dependencies, and column lineage"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        manifest = connection.get("manifest", {})
        nodes = manifest.get("nodes", {})
        results = []

        for key, node in nodes.items():
            if node.get("resource_type") != "model":
                continue
            results.append({
                "unique_id": key,
                "name": node.get("name", ""),
                "schema": node.get("schema", ""),
                "database": node.get("database", ""),
                "materialized": node.get("config", {}).get("materialized", ""),
                "description": node.get("description", ""),
                "depends_on": node.get("depends_on", {}).get("nodes", []),
                "columns": [
                    {"name": c["name"], "description": c.get("description", ""),
                     "data_type": c.get("data_type", "")}
                    for c in node.get("columns", {}).values()
                ],
                "raw_sql": (node.get("raw_code") or node.get("raw_sql", ""))[:500],
                "tags": node.get("tags", []),
                "path": node.get("path", ""),
            })
        return results
