"""dbt metadata extraction — from manifest.json and catalog.json.

Config:
  host = path to dbt project directory (containing target/ folder)
  schema_name = specific artifact (optional)
"""

from __future__ import annotations

import json
from pathlib import Path

from core.config import SourceConfig


def get_artifacts(config: SourceConfig) -> dict:
    """Load dbt manifest.json and catalog.json."""
    project_dir = Path(config.host or ".")
    target_dir = project_dir / "target"

    if not target_dir.exists():
        raise ConnectionError(f"dbt target directory not found: {target_dir}")

    artifacts: dict = {"project_dir": str(project_dir)}

    manifest_path = target_dir / "manifest.json"
    if manifest_path.exists():
        artifacts["manifest"] = json.loads(manifest_path.read_text())

    catalog_path = target_dir / "catalog.json"
    if catalog_path.exists():
        artifacts["catalog"] = json.loads(catalog_path.read_text())

    if "manifest" not in artifacts:
        raise ConnectionError(f"manifest.json not found in {target_dir}")

    return artifacts


def source_id(config: SourceConfig) -> str:
    return f"dbt://{config.host}"
