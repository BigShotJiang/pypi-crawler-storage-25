"""Probe: azure_data_factory.operations.pipeline_runs — recent pipeline execution history."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AdfPipelineRunsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.operations.pipeline_runs"

    @staticmethod
    def description() -> str:
        return "Recent pipeline runs with status, duration, and error messages"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        since = (now - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
        until = now.strftime("%Y-%m-%dT%H:%M:%SZ")

        try:
            resp = connection.post(
                "/queryPipelineRuns",
                params={"api-version": "2018-06-01"},
                json={
                    "lastUpdatedAfter": since,
                    "lastUpdatedBefore": until,
                },
            )
            resp.raise_for_status()
            runs = resp.json().get("value", [])
        except Exception:
            return []

        return [{
            "run_id": r.get("runId", ""),
            "pipeline_name": r.get("pipelineName", ""),
            "status": r.get("status", ""),
            "started": r.get("runStart", ""),
            "ended": r.get("runEnd", ""),
            "duration_ms": r.get("durationInMs"),
            "triggered_by": r.get("invokedBy", {}).get("name", ""),
            "trigger_type": r.get("invokedBy", {}).get("invokedByType", ""),
            "message": (r.get("message", "") or "")[:200],
            "parameters": r.get("parameters", {}),
        } for r in runs[:100]]
