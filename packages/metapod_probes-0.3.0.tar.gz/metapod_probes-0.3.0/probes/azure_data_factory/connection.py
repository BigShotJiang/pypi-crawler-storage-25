"""Azure Data Factory connection — Management REST API via Azure credentials.

Supports:
- Service Principal (client_id + client_secret + tenant_id)
- Managed Identity (when running on Azure)
- Azure CLI credential fallback
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    """Create an authenticated httpx client for Azure Data Factory Management API."""
    token = _get_azure_token(config)
    subscription_id = config.sid or ""
    resource_group = config.service_name or ""
    factory_name = config.schema_name or ""

    if not all([subscription_id, resource_group, factory_name]):
        raise ConnectionError(
            "ADF requires: sid=subscription_id, service_name=resource_group, schema_name=factory_name"
        )

    base_url = (
        f"https://management.azure.com/subscriptions/{subscription_id}"
        f"/resourceGroups/{resource_group}"
        f"/providers/Microsoft.DataFactory/factories/{factory_name}"
    )

    return httpx.Client(
        base_url=base_url,
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        params={"api-version": "2018-06-01"},
        timeout=30,
    )


def _get_azure_token(config: SourceConfig) -> str:
    """Get Azure AD token via Service Principal or fallback."""
    if config.token:
        return config.token

    # Try azure-identity SDK
    try:
        from azure.identity import ClientSecretCredential, DefaultAzureCredential

        if config.username and config.password:
            # Service Principal: username=client_id, password=client_secret
            tenant_id = config.host  # Overloaded: host = tenant_id for ADF
            credential = ClientSecretCredential(
                tenant_id=tenant_id,
                client_id=config.username,
                client_secret=config.password,
            )
        else:
            credential = DefaultAzureCredential()

        token = credential.get_token("https://management.azure.com/.default")
        return token.token
    except ImportError:
        raise ConnectionError(
            "azure-identity not installed. Run: pip install 'metapod[azure]'"
        )
    except Exception as e:
        raise ConnectionError(f"Azure authentication failed: {e}")


def source_id(config: SourceConfig) -> str:
    return f"adf://{config.service_name}/{config.schema_name}"
