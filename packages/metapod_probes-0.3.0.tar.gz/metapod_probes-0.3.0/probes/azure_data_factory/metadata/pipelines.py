"""Probe: azure_data_factory.metadata.pipelines — list ADF pipelines."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADFPipelinesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.metadata.pipelines"

    @staticmethod
    def description() -> str:
        return "List all pipelines in the Azure Data Factory with activity counts"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/pipelines")
        resp.raise_for_status()
        results = []
        for p in resp.json().get("value", []):
            props = p.get("properties", {})
            results.append({
                "name": p.get("name", ""),
                "description": props.get("description", ""),
                "activities": len(props.get("activities", [])),
                "parameters": list(props.get("parameters", {}).keys()),
                "folder": props.get("folder", {}).get("name", ""),
            })
        return results
