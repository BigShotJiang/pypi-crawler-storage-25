"""Probe: azure_data_factory.metadata.linked_services — list ADF linked services."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADFLinkedServicesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.metadata.linked_services"

    @staticmethod
    def description() -> str:
        return "List all linked services (connections) in Azure Data Factory"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/linkedservices")
        resp.raise_for_status()
        results = []
        for ls in resp.json().get("value", []):
            props = ls.get("properties", {})
            type_props = props.get("typeProperties", {})
            results.append({
                "name": ls.get("name", ""),
                "type": props.get("type", ""),
                "description": props.get("description", ""),
                "connection_string": type_props.get("connectionString", "***masked***")[:50] + "..."
                if type_props.get("connectionString") else "",
                "url": type_props.get("url", ""),
            })
        return results
