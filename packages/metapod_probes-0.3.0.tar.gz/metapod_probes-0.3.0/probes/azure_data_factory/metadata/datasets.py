"""Probe: azure_data_factory.metadata.datasets — list ADF datasets."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADFDatasetsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.metadata.datasets"

    @staticmethod
    def description() -> str:
        return "List all datasets in the Azure Data Factory with type and linked service info"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/datasets")
        resp.raise_for_status()
        results = []
        for d in resp.json().get("value", []):
            props = d.get("properties", {})
            type_props = props.get("typeProperties", {})
            results.append({
                "name": d.get("name", ""),
                "type": props.get("type", ""),
                "linked_service": props.get("linkedServiceName", {}).get("referenceName", ""),
                "description": props.get("description", ""),
                "schema_name": type_props.get("schema", ""),
                "table_name": type_props.get("table", ""),
                "folder": props.get("folder", {}).get("name", ""),
            })
        return results
