"""Probe: azure_data_factory.metadata.triggers — list ADF triggers."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADFTriggersProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.metadata.triggers"

    @staticmethod
    def description() -> str:
        return "List all triggers in Azure Data Factory with type and schedule info"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/triggers")
        resp.raise_for_status()
        results = []
        for t in resp.json().get("value", []):
            props = t.get("properties", {})
            type_props = props.get("typeProperties", {})
            results.append({
                "name": t.get("name", ""),
                "type": props.get("type", ""),
                "runtime_state": props.get("runtimeState", ""),
                "description": props.get("description", ""),
                "recurrence": type_props.get("recurrence", {}),
                "pipelines": [
                    p.get("pipelineReference", {}).get("referenceName", "")
                    for p in props.get("pipelines", [])
                ],
            })
        return results
