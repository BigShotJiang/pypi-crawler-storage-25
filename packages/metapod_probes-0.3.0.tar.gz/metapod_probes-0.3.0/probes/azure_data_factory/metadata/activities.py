"""Probe: azure_data_factory.metadata.activities — extract activity details from all pipelines."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ADFActivitiesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.metadata.activities"

    @staticmethod
    def description() -> str:
        return "Extract all activities from ADF pipelines with type, inputs, outputs, and dependencies"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/pipelines")
        resp.raise_for_status()

        results = []
        for pipeline in resp.json().get("value", []):
            pipeline_name = pipeline.get("name", "")
            props = pipeline.get("properties", {})
            for act in props.get("activities", []):
                inputs = [i.get("referenceName", "") for i in act.get("inputs", [])]
                outputs = [o.get("referenceName", "") for o in act.get("outputs", [])]
                depends = [
                    {"activity": d.get("activity", ""), "conditions": d.get("dependencyConditions", [])}
                    for d in act.get("dependsOn", [])
                ]
                type_props = act.get("typeProperties", {})
                results.append({
                    "pipeline": pipeline_name,
                    "activity_name": act.get("name", ""),
                    "type": act.get("type", ""),
                    "inputs": inputs,
                    "outputs": outputs,
                    "depends_on": depends,
                    "source_type": type_props.get("source", {}).get("type", ""),
                    "sink_type": type_props.get("sink", {}).get("type", ""),
                    "sql_query": type_props.get("source", {}).get("sqlReaderQuery", ""),
                    "stored_procedure": type_props.get("source", {}).get(
                        "sqlReaderStoredProcedureName", ""
                    ) or type_props.get("storedProcedureName", ""),
                })
        return results
