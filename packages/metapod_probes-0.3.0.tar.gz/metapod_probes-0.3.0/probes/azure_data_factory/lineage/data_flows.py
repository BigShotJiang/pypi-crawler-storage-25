"""Probe: azure_data_factory.lineage.data_flows — dataset-to-dataset lineage via activities."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AdfDataFlowsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_data_factory.lineage.data_flows"

    @staticmethod
    def description() -> str:
        return "Extract dataset-to-dataset lineage from ADF pipeline activities (Copy, DataFlow)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # schema = factory name
        factory = schema or "default"
        results = []
        seen: set[tuple[str, str]] = set()

        # Get all pipelines
        try:
            resp = connection.get(f"/pipelines", params={"api-version": "2018-06-01"})
            resp.raise_for_status()
            pipelines = resp.json().get("value", [])
        except Exception:
            return results

        for pipeline in pipelines:
            p_name = pipeline.get("name", "")
            activities = pipeline.get("properties", {}).get("activities", [])

            for activity in activities:
                a_type = activity.get("type", "")
                a_name = activity.get("name", "")

                # Copy activity: input dataset → output dataset
                if a_type == "Copy":
                    inputs = activity.get("inputs", [])
                    outputs = activity.get("outputs", [])
                    for inp in inputs:
                        src = inp.get("referenceName", "")
                        for out in outputs:
                            tgt = out.get("referenceName", "")
                            if src and tgt and (src, tgt) not in seen:
                                seen.add((src, tgt))
                                results.append({
                                    "lineage_type": "dataset",
                                    "source": src,
                                    "target": tgt,
                                    "activity": a_name,
                                    "activity_type": a_type,
                                    "pipeline": p_name,
                                })

                # DataFlow activity: source/sink mappings
                elif a_type == "ExecuteDataFlow":
                    df_ref = activity.get("typeProperties", {}).get("dataflow", {}).get("referenceName", "")
                    if df_ref:
                        results.append({
                            "lineage_type": "dataflow",
                            "source": df_ref,
                            "target": f"{p_name}/{a_name}",
                            "activity": a_name,
                            "activity_type": a_type,
                            "pipeline": p_name,
                        })

                # Execute Pipeline: dependency lineage
                elif a_type == "ExecutePipeline":
                    ref = activity.get("typeProperties", {}).get("pipeline", {}).get("referenceName", "")
                    if ref:
                        results.append({
                            "lineage_type": "pipeline_dependency",
                            "source": ref,
                            "target": p_name,
                            "activity": a_name,
                            "activity_type": a_type,
                            "pipeline": p_name,
                        })

        return results
