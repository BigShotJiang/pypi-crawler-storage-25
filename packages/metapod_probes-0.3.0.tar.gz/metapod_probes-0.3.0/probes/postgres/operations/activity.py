"""Probe: postgres.operations.activity — table access patterns from pg_stat_user_tables."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgActivityProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.operations.activity"

    @staticmethod
    def description() -> str:
        return "Table access patterns: seq/idx scans, inserts, updates, deletes"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT schemaname, relname,
                   seq_scan, seq_tup_read, idx_scan, idx_tup_fetch,
                   n_tup_ins, n_tup_upd, n_tup_del, n_tup_hot_upd,
                   last_vacuum, last_autovacuum,
                   last_analyze, last_autoanalyze
            FROM pg_stat_user_tables
            WHERE schemaname = %s
            ORDER BY seq_scan + COALESCE(idx_scan, 0) DESC
        """, (schema or "public",))
        return [{
            "schema": r[0], "table_name": r[1],
            "seq_scans": r[2], "seq_rows_read": r[3],
            "idx_scans": r[4], "idx_rows_fetched": r[5],
            "inserts": r[6], "updates": r[7], "deletes": r[8], "hot_updates": r[9],
            "last_vacuum": str(r[10]) if r[10] else None,
            "last_autovacuum": str(r[11]) if r[11] else None,
            "last_analyze": str(r[12]) if r[12] else None,
            "last_autoanalyze": str(r[13]) if r[13] else None,
        } for r in cur.fetchall()]
