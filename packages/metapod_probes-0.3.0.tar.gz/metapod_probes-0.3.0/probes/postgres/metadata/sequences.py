"""Probe: postgres.metadata.sequences"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgSequencesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.sequences"

    @staticmethod
    def description() -> str:
        return "Extract sequence definitions from information_schema.sequences"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT sequence_name, data_type, start_value, minimum_value,
                       maximum_value, increment, cycle_option
                FROM information_schema.sequences
                WHERE sequence_schema = %s
                ORDER BY sequence_name
            """, (schema,))
            return [{
                "sequence_name": r[0], "data_type": r[1], "start_value": r[2],
                "min_value": r[3], "max_value": r[4], "increment": r[5],
                "cycle": r[6] == "YES",
            } for r in cur.fetchall()]
