"""Probe: postgres.metadata.views"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.views"

    @staticmethod
    def description() -> str:
        return "Extract view definitions from information_schema.views"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT table_name, view_definition
                FROM information_schema.views
                WHERE table_schema = %s
                ORDER BY table_name
            """, (schema,))
            return [{"view_name": r[0], "sql_text": r[1] or ""} for r in cur.fetchall()]
