"""Probe: postgres.metadata.columns"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column definitions from information_schema.columns"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT table_name, column_name, data_type, character_maximum_length,
                       numeric_precision, numeric_scale, is_nullable, ordinal_position,
                       column_default
                FROM information_schema.columns
                WHERE table_schema = %s
                ORDER BY table_name, ordinal_position
            """, (schema,))
            return [{
                "table_name": r[0], "column_name": r[1], "data_type": r[2],
                "max_length": r[3], "precision": r[4], "scale": r[5],
                "nullable": r[6] == "YES", "ordinal_position": r[7],
                "default_value": r[8],
            } for r in cur.fetchall()]
