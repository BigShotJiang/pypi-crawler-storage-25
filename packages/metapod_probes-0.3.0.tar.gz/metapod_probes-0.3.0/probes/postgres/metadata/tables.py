"""Probe: postgres.metadata.tables"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.tables"

    @staticmethod
    def description() -> str:
        return "Extract table names, row estimates, and size from pg_catalog"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT c.relname, c.reltuples::bigint, pg_total_relation_size(c.oid) AS size_bytes,
                       obj_description(c.oid) AS comment
                FROM pg_class c
                JOIN pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = %s AND c.relkind = 'r'
                ORDER BY c.relname
            """, (schema,))
            return [{"table_name": r[0], "row_estimate": r[1], "size_bytes": r[2], "comment": r[3]} for r in cur.fetchall()]
