"""Probe: postgres.metadata.constraints"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgConstraintsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.constraints"

    @staticmethod
    def description() -> str:
        return "Extract PK, FK, unique constraints from information_schema"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT tc.constraint_name, tc.constraint_type, tc.table_name,
                       kcu.column_name, kcu.ordinal_position,
                       ccu.table_name AS ref_table, ccu.column_name AS ref_column
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                  ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
                LEFT JOIN information_schema.constraint_column_usage ccu
                  ON tc.constraint_name = ccu.constraint_name AND tc.table_schema = ccu.table_schema
                WHERE tc.table_schema = %s
                  AND tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY', 'UNIQUE')
                ORDER BY tc.table_name, tc.constraint_name, kcu.ordinal_position
            """, (schema,))
            return [{
                "constraint_name": r[0], "constraint_type": r[1], "table_name": r[2],
                "column_name": r[3], "position": r[4],
                "ref_table": r[5], "ref_column": r[6],
            } for r in cur.fetchall()]
