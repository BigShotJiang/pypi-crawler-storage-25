"""Probe: postgres.metadata.indexes"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgIndexesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.indexes"

    @staticmethod
    def description() -> str:
        return "Extract index definitions from pg_indexes"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT indexname, tablename, indexdef
                FROM pg_indexes
                WHERE schemaname = %s
                ORDER BY tablename, indexname
            """, (schema,))
            return [{"index_name": r[0], "table_name": r[1], "definition": r[2]} for r in cur.fetchall()]
