"""Probe: postgres.metadata.extensions"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgExtensionsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.extensions"

    @staticmethod
    def description() -> str:
        return "Extract installed PostgreSQL extensions"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("SELECT extname, extversion, extrelocatable FROM pg_extension ORDER BY extname")
            return [{"name": r[0], "version": r[1], "relocatable": r[2]} for r in cur.fetchall()]
