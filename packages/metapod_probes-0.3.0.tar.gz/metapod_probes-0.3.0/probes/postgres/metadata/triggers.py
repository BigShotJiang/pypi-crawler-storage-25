"""Probe: postgres.metadata.triggers"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgTriggersProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.metadata.triggers"

    @staticmethod
    def description() -> str:
        return "Extract trigger metadata from information_schema.triggers"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT trigger_name, event_manipulation, event_object_table,
                       action_timing, action_orientation, action_statement
                FROM information_schema.triggers
                WHERE trigger_schema = %s
                ORDER BY event_object_table, trigger_name
            """, (schema,))
            return [{
                "trigger_name": r[0], "event": r[1], "table_name": r[2],
                "timing": r[3], "orientation": r[4], "action": r[5],
            } for r in cur.fetchall()]
