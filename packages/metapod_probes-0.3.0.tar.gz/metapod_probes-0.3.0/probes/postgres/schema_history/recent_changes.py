"""Probe: postgres.schema_history.recent_changes — track schema modifications."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgRecentChangesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.schema_history.recent_changes"

    @staticmethod
    def description() -> str:
        return "DDL event log from pg_event_trigger or object age analysis"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        # Track object creation times and last DDL changes via pg_class
        cur.execute("""
            SELECT n.nspname AS schema_name, c.relname AS object_name,
                   CASE c.relkind
                       WHEN 'r' THEN 'TABLE'
                       WHEN 'v' THEN 'VIEW'
                       WHEN 'm' THEN 'MATERIALIZED_VIEW'
                       WHEN 'i' THEN 'INDEX'
                       WHEN 'S' THEN 'SEQUENCE'
                       ELSE c.relkind::text
                   END AS object_type,
                   pg_stat_get_last_analyze_time(c.oid) AS last_analyze,
                   pg_stat_get_last_autoanalyze_time(c.oid) AS last_autoanalyze,
                   pg_total_relation_size(c.oid) AS size_bytes,
                   c.reltuples::bigint AS estimated_rows
            FROM pg_class c
            JOIN pg_namespace n ON c.relnamespace = n.oid
            WHERE n.nspname = %s AND c.relkind IN ('r', 'v', 'm', 'S')
            ORDER BY c.relname
        """, (schema or "public",))
        return [{
            "schema": r[0], "object_name": r[1], "object_type": r[2],
            "last_analyze": str(r[3]) if r[3] else None,
            "last_autoanalyze": str(r[4]) if r[4] else None,
            "size_bytes": r[5],
            "estimated_rows": r[6],
        } for r in cur.fetchall()]
