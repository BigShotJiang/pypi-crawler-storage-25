"""Probe: postgres.governance.grants — extract table-level grants from PostgreSQL.

Queries information_schema.role_table_grants to map who has SELECT, INSERT,
UPDATE, DELETE on which tables.
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgGrantsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.governance.grants"

    @staticmethod
    def description() -> str:
        return "Extract table-level grants from information_schema.role_table_grants"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT
                grantee,
                table_schema,
                table_name,
                privilege_type,
                is_grantable,
                grantor
            FROM information_schema.role_table_grants
            WHERE table_schema = %s
            ORDER BY grantee, table_name, privilege_type
        """, (schema or "public",))
        return [{
            "principal": r[0],
            "table_schema": r[1],
            "table_name": r[2],
            "privilege": r[3],
            "is_grantable": r[4] == "YES",
            "grantor": r[5],
        } for r in cur.fetchall()]


@register
class PgRolesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.governance.roles"

    @staticmethod
    def description() -> str:
        return "Extract database roles and their attributes from pg_roles"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT
                r.rolname,
                r.rolsuper,
                r.rolinherit,
                r.rolcreaterole,
                r.rolcreatedb,
                r.rolcanlogin,
                r.rolreplication,
                r.rolconnlimit,
                ARRAY(
                    SELECT m.rolname FROM pg_auth_members am
                    JOIN pg_roles m ON am.roleid = m.oid
                    WHERE am.member = r.oid
                ) AS member_of
            FROM pg_roles r
            WHERE r.rolname NOT LIKE 'pg_%'
            ORDER BY r.rolname
        """)
        return [{
            "role_name": r[0],
            "is_superuser": r[1],
            "inherit": r[2],
            "can_create_role": r[3],
            "can_create_db": r[4],
            "can_login": r[5],
            "replication": r[6],
            "connection_limit": r[7],
            "member_of": r[8] if r[8] else [],
        } for r in cur.fetchall()]
