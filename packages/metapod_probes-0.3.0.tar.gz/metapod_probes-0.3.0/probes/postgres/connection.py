"""PostgreSQL connection factory."""

from __future__ import annotations

from core.config import SourceConfig


def connect(config: SourceConfig):
    """Create a PostgreSQL connection from config."""
    try:
        import psycopg2
    except ImportError:
        raise ConnectionError("psycopg2 not installed. Run: pip install 'metapod[postgres]'")

    try:
        return psycopg2.connect(
            host=config.host,
            port=config.port or 5432,
            dbname=config.service_name or config.sid or "postgres",
            user=config.username,
            password=config.password,
        )
    except Exception as e:
        msg = str(e)
        if "authentication failed" in msg.lower():
            raise ConnectionError(f"Authentication failed for {config.username}@{config.host}")
        if "could not connect" in msg.lower() or "connection refused" in msg.lower():
            raise ConnectionError(f"Cannot reach {config.host}:{config.port or 5432}")
        raise ConnectionError(f"PostgreSQL connection failed: {e}")


def source_id(config: SourceConfig) -> str:
    db = config.service_name or config.sid or "postgres"
    return f"{config.host}:{config.port or 5432}/{db}/{config.schema_name}"
