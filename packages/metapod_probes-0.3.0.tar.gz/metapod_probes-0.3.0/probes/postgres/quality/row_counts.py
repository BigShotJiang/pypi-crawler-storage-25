"""Probe: postgres.quality.row_counts — estimated row counts from pg_stat_user_tables."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgRowCountsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.quality.row_counts"

    @staticmethod
    def description() -> str:
        return "Estimated row counts and dead tuple ratio from pg_stat_user_tables"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT schemaname, relname,
                   n_live_tup, n_dead_tup,
                   CASE WHEN n_live_tup > 0
                        THEN round(n_dead_tup::numeric / n_live_tup, 4)
                        ELSE 0 END AS dead_ratio,
                   pg_total_relation_size(schemaname || '.' || relname) AS total_bytes
            FROM pg_stat_user_tables
            WHERE schemaname = %s
            ORDER BY n_live_tup DESC
        """, (schema or "public",))
        return [{
            "schema": r[0], "table_name": r[1],
            "live_rows": r[2], "dead_rows": r[3],
            "dead_ratio": float(r[4]),
            "total_bytes": r[5],
        } for r in cur.fetchall()]
