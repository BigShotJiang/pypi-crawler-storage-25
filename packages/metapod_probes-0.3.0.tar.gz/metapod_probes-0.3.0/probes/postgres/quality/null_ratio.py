"""Probe: postgres.quality.null_ratio — null percentage per column from pg_stats."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgNullRatioProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.quality.null_ratio"

    @staticmethod
    def description() -> str:
        return "Null percentage per column from pg_stats (no table scan)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT schemaname, tablename, attname, null_frac, n_distinct, avg_width
            FROM pg_stats
            WHERE schemaname = %s
            ORDER BY null_frac DESC, tablename, attname
        """, (schema or "public",))
        return [{
            "schema": r[0], "table_name": r[1], "column_name": r[2],
            "null_fraction": round(float(r[3]), 4) if r[3] else 0,
            "n_distinct": float(r[4]) if r[4] else 0,
            "avg_width": r[5],
        } for r in cur.fetchall()]
