"""Probe: postgres.quality.freshness"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgFreshnessProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.quality.freshness"

    @staticmethod
    def description() -> str:
        return "Check table freshness via pg_stat_user_tables last analyze/vacuum timestamps"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""
                SELECT relname, n_live_tup, last_analyze, last_autoanalyze,
                       last_vacuum, last_autovacuum,
                       EXTRACT(EPOCH FROM (now() - COALESCE(last_analyze, last_autoanalyze))) / 86400 AS days_stale
                FROM pg_stat_user_tables
                WHERE schemaname = %s
                ORDER BY days_stale DESC NULLS FIRST
            """, (schema,))
            return [{
                "table_name": r[0], "live_rows": r[1],
                "last_analyze": str(r[2]) if r[2] else None,
                "last_autoanalyze": str(r[3]) if r[3] else None,
                "last_vacuum": str(r[4]) if r[4] else None,
                "days_stale": round(float(r[6]), 1) if r[6] is not None else None,
                "is_stale": r[6] is not None and float(r[6]) > 7,
            } for r in cur.fetchall()]
