"""Probe: postgres.profiling.column_stats — column-level statistics from pg_stats."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PgColumnStatsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "postgres.profiling.column_stats"

    @staticmethod
    def description() -> str:
        return "Column statistics: distinct values, most common values, histogram bounds"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT schemaname, tablename, attname,
                   null_frac, n_distinct, avg_width,
                   most_common_vals::text, most_common_freqs::text,
                   correlation
            FROM pg_stats
            WHERE schemaname = %s
            ORDER BY tablename, attname
        """, (schema or "public",))
        return [{
            "schema": r[0], "table_name": r[1], "column_name": r[2],
            "null_fraction": round(float(r[3]), 4) if r[3] else 0,
            "n_distinct": float(r[4]) if r[4] else 0,
            "avg_width": r[5],
            "most_common_vals": r[6][:200] if r[6] else "",
            "most_common_freqs": r[7][:200] if r[7] else "",
            "correlation": round(float(r[8]), 4) if r[8] else None,
        } for r in cur.fetchall()]
