"""MongoDB connection — via pymongo."""
from __future__ import annotations
from core.config import SourceConfig

def get_client(config: SourceConfig):
    try:
        from pymongo import MongoClient
    except ImportError:
        raise ConnectionError("pymongo not installed. Run: pip install pymongo")
    uri = config.host if config.host.startswith("mongodb") else f"mongodb://{config.username}:{config.password}@{config.host}:{config.port or 27017}"
    client = MongoClient(uri)
    return client[config.service_name or config.schema_name or "test"]

def source_id(config: SourceConfig) -> str:
    return f"mongodb://{config.host}/{config.service_name or config.schema_name}"
