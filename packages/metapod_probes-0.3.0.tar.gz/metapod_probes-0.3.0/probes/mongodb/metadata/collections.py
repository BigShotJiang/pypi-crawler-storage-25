"""Probe: mongodb.metadata.collections — list collections with document count and indexes."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class MongoCollectionsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "mongodb.metadata.collections"
    @staticmethod
    def description() -> str: return "List MongoDB collections with doc count, indexes, and inferred schema"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for name in connection.list_collection_names():
            col = connection[name]
            stats = connection.command("collStats", name)
            # Sample one doc for schema inference
            sample = col.find_one()
            fields = list(sample.keys()) if sample else []
            results.append({
                "collection": name, "doc_count": stats.get("count", 0),
                "size_bytes": stats.get("size", 0), "index_count": stats.get("nindexes", 0),
                "indexes": list(col.index_information().keys()),
                "sample_fields": fields[:30],
            })
        return results
