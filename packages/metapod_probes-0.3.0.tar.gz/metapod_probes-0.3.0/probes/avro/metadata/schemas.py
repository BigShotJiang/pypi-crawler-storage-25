"""Probe: avro.metadata.schemas — read Avro file schemas from header (no data loaded)."""
import json
from pathlib import Path
from core.base_probe import BaseProbe
from core.registry import register

@register
class AvroSchemaProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "avro.metadata.schemas"
    @staticmethod
    def description() -> str: return "Read Avro file schemas from header: field names, types, namespaces"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        root = connection if isinstance(connection, Path) else Path(str(connection))
        results = []
        for f in sorted(root.rglob("*.avro")):
            if not f.is_file() or f.stat().st_size == 0: continue
            try:
                sch = _read_avro_schema(f)
                if sch:
                    results.append({
                        "path": str(f.relative_to(root)),
                        "name": sch.get("name", f.stem),
                        "namespace": sch.get("namespace", ""),
                        "type": sch.get("type", ""),
                        "field_count": len(sch.get("fields", [])),
                        "fields": [
                            {"name": fld.get("name", ""), "type": str(fld.get("type", "")), "doc": fld.get("doc", "")}
                            for fld in sch.get("fields", [])
                        ],
                    })
            except Exception as e:
                results.append({"path": str(f.relative_to(root)), "error": str(e)})
        return results


def _read_avro_schema(filepath: Path) -> dict | None:
    """Read Avro schema from file header without loading data."""
    try:
        import avro.datafile
        import avro.io
        with open(filepath, "rb") as f:
            reader = avro.datafile.DataFileReader(f, avro.io.DatumReader())
            schema = json.loads(str(reader.meta.get("avro.schema", b"{}").decode("utf-8")))
            reader.close()
            return schema
    except ImportError:
        pass

    # Fallback: parse header manually (Avro magic + sync + schema JSON)
    with open(filepath, "rb") as f:
        magic = f.read(4)
        if magic != b"Obj\x01":
            return None
        # Read header map
        header = {}
        while True:
            count = _read_long(f)
            if count == 0: break
            for _ in range(abs(count)):
                key = _read_bytes(f).decode("utf-8")
                val = _read_bytes(f)
                header[key] = val
        schema_bytes = header.get("avro.schema", b"{}")
        return json.loads(schema_bytes.decode("utf-8"))


def _read_long(f) -> int:
    b = ord(f.read(1))
    n = b & 0x7F; shift = 7
    while b & 0x80:
        b = ord(f.read(1)); n |= (b & 0x7F) << shift; shift += 7
    return (n >> 1) ^ -(n & 1)


def _read_bytes(f) -> bytes:
    length = _read_long(f)
    return f.read(length)
