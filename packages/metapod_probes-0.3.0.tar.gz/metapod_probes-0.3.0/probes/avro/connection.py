"""Avro file schema extraction — reads schema from file header (no data loaded).
Config: host = directory containing .avro files.
"""
from __future__ import annotations
from pathlib import Path
from core.config import SourceConfig

def get_path(config: SourceConfig) -> Path:
    p = Path(config.host or ".")
    if not p.exists(): raise ConnectionError(f"Directory not found: {p}")
    return p

def source_id(config: SourceConfig) -> str:
    return f"avro://{config.host}"
