"""Probe: sap_hana.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class HanaTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "sap_hana.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables from SYS.TABLES"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT TABLE_NAME, TABLE_TYPE, RECORD_COUNT, CREATE_TIME, COMMENTS FROM SYS.TABLES WHERE SCHEMA_NAME = ? ORDER BY TABLE_NAME", (schema.upper(),))
        return [{"table_name": r[0], "type": r[1], "row_count": r[2], "created": str(r[3]) if r[3] else None, "comment": r[4] or ""} for r in cur.fetchall()]
