"""Probe: sap_hana.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class HanaColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "sap_hana.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions from SYS.TABLE_COLUMNS"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE_NAME, LENGTH, SCALE, IS_NULLABLE, POSITION, DEFAULT_VALUE, COMMENTS FROM SYS.TABLE_COLUMNS WHERE SCHEMA_NAME = ? ORDER BY TABLE_NAME, POSITION", (schema.upper(),))
        return [{"table_name": r[0], "column_name": r[1], "data_type": r[2], "length": r[3], "scale": r[4], "nullable": r[5] == "TRUE", "position": r[6], "default": r[7], "comment": r[8] or ""} for r in cur.fetchall()]
