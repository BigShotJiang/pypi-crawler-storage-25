"""SAP HANA connection — via hdbcli."""
from __future__ import annotations
from core.config import SourceConfig

def connect(config: SourceConfig):
    try:
        from hdbcli import dbapi
    except ImportError:
        raise ConnectionError("hdbcli not installed. Run: pip install hdbcli")
    try:
        return dbapi.connect(address=config.host, port=config.port or 30015, user=config.username, password=config.password)
    except Exception as e:
        raise ConnectionError(f"SAP HANA connection failed: {e}")

def source_id(config: SourceConfig) -> str:
    return f"hana://{config.host}:{config.port or 30015}/{config.schema_name}"
