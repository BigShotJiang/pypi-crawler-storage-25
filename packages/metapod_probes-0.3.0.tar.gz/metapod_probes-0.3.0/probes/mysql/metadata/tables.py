"""Probe: mysql.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class MySqlTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "mysql.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables with engine, row count, size from INFORMATION_SCHEMA"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""SELECT TABLE_NAME, TABLE_TYPE, ENGINE, TABLE_ROWS, DATA_LENGTH, CREATE_TIME, UPDATE_TIME, TABLE_COMMENT
                           FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = %s ORDER BY TABLE_NAME""", (schema,))
            return [dict(r) for r in cur.fetchall()]
