"""Probe: mysql.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class MySqlColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "mysql.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions from INFORMATION_SCHEMA.COLUMNS"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                           NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE, ORDINAL_POSITION, COLUMN_DEFAULT, COLUMN_COMMENT
                           FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = %s ORDER BY TABLE_NAME, ORDINAL_POSITION""", (schema,))
            return [dict(r) for r in cur.fetchall()]
