"""Probe: mysql.metadata.routines — stored procedures and functions."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class MySqlRoutinesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "mysql.metadata.routines"
    @staticmethod
    def description() -> str: return "Extract stored procedure and function definitions"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("""SELECT ROUTINE_NAME, ROUTINE_TYPE, ROUTINE_DEFINITION, CREATED, LAST_ALTERED
                           FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA = %s""", (schema,))
            return [dict(r) for r in cur.fetchall()]
