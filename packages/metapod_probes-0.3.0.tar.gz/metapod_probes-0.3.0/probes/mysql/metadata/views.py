"""Probe: mysql.metadata.views"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class MySqlViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "mysql.metadata.views"
    @staticmethod
    def description() -> str: return "Extract view definitions from INFORMATION_SCHEMA.VIEWS"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute("SELECT TABLE_NAME, VIEW_DEFINITION, IS_UPDATABLE FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = %s", (schema,))
            return [dict(r) for r in cur.fetchall()]
