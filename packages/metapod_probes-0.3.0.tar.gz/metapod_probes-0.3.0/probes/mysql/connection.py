"""MySQL / MariaDB connection factory."""
from __future__ import annotations
from core.config import SourceConfig

def connect(config: SourceConfig):
    try:
        import pymysql
    except ImportError:
        raise ConnectionError("pymysql not installed. Run: pip install pymysql")
    try:
        return pymysql.connect(
            host=config.host, port=config.port or 3306,
            user=config.username, password=config.password,
            database=config.service_name or config.schema_name or "",
            cursorclass=pymysql.cursors.DictCursor,
        )
    except Exception as e:
        raise ConnectionError(f"MySQL connection failed: {e}")

def source_id(config: SourceConfig) -> str:
    return f"mysql://{config.host}:{config.port or 3306}/{config.service_name}/{config.schema_name}"
