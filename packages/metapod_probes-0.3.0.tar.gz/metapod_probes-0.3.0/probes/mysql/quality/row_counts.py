"""Probe: mysql.quality.row_counts — row counts and sizes from information_schema."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class MysqlRowCountsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "mysql.quality.row_counts"

    @staticmethod
    def description() -> str:
        return "Row counts, data size, and index size from information_schema.TABLES"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH,
                   AVG_ROW_LENGTH, AUTO_INCREMENT, CREATE_TIME, UPDATE_TIME
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = %s AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_ROWS DESC
        """, (schema or connection._database,))
        return [{
            "table_name": r[0],
            "row_count": r[1],
            "data_bytes": r[2],
            "index_bytes": r[3],
            "avg_row_length": r[4],
            "auto_increment": r[5],
            "created": str(r[6]) if r[6] else None,
            "updated": str(r[7]) if r[7] else None,
        } for r in cur.fetchall()]


@register
class MysqlNullRatioProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "mysql.quality.null_ratio"

    @staticmethod
    def description() -> str:
        return "Nullable column inventory from information_schema.COLUMNS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE,
                   IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = %s
            ORDER BY TABLE_NAME, ORDINAL_POSITION
        """, (schema or connection._database,))
        return [{
            "table_name": r[0], "column_name": r[1], "data_type": r[2],
            "is_nullable": r[3] == "YES",
            "has_default": r[4] is not None,
            "column_key": r[5],
        } for r in cur.fetchall()]
