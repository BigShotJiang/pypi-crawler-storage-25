"""Blindata Data Governance — REST API.

Bidirectional: read catalog/lineage FROM Blindata, push metadata TO Blindata.

Config:
  host = Blindata instance URL (e.g., "https://app.blindata.io")
  username = API user or email
  password = API password
  token = Bearer token (alternative to username/password)
  service_name = tenant/organization ID
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    base = config.host.rstrip("/") if config.host else "https://app.blindata.io"
    headers: dict = {"Accept": "application/json", "Content-Type": "application/json"}

    if config.token:
        headers["Authorization"] = f"Bearer {config.token}"
    elif config.username and config.password:
        # Login to get token
        resp = httpx.post(f"{base}/api/v1/auth/login",
                           json={"username": config.username, "password": config.password})
        resp.raise_for_status()
        headers["Authorization"] = f"Bearer {resp.json().get('token', '')}"
    else:
        raise ConnectionError("Blindata requires: token or username+password")

    if config.service_name:
        headers["X-Tenant-Id"] = config.service_name

    return httpx.Client(base_url=f"{base}/api/v1", headers=headers, timeout=30)


def source_id(config: SourceConfig) -> str:
    return f"blindata://{config.host}/{config.service_name or 'default'}"
