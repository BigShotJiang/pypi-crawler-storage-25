"""Probe: blindata.metadata.physical_entities — extract physical data assets from Blindata."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class BlindataPhysicalEntities(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "blindata.metadata.physical_entities"
    @staticmethod
    def description() -> str: return "Extract physical entities (tables, columns) from Blindata catalog"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/physical-entities", params={"size": 500})
        resp.raise_for_status()
        return [{
            "uuid": e.get("uuid", ""), "name": e.get("name", ""),
            "schema": e.get("schema", ""), "type": e.get("type", ""),
            "system": e.get("system", {}).get("name", ""),
            "description": e.get("description", ""),
            "field_count": len(e.get("physicalFields", [])),
        } for e in resp.json().get("content", resp.json().get("results", []))]
