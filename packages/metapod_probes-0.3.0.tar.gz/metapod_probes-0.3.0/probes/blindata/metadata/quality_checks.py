"""Probe: blindata.metadata.quality_checks — extract quality checks from Blindata."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class BlindataQualityChecks(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "blindata.metadata.quality_checks"
    @staticmethod
    def description() -> str: return "Extract data quality checks and their results from Blindata"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        try:
            resp = connection.get("/quality-checks", params={"size": 500})
            resp.raise_for_status()
            return [{
                "uuid": q.get("uuid", ""), "name": q.get("name", ""),
                "type": q.get("type", ""), "status": q.get("status", ""),
                "entity": q.get("physicalEntity", {}).get("name", ""),
                "field": q.get("physicalField", {}).get("name", ""),
                "threshold": q.get("threshold", ""),
                "last_result": q.get("lastResult", ""),
            } for q in resp.json().get("content", resp.json().get("results", []))]
        except Exception:
            return []
