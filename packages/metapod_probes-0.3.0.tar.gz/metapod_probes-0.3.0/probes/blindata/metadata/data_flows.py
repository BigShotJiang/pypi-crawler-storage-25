"""Probe: blindata.metadata.data_flows — extract lineage/data flows from Blindata."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class BlindataDataFlows(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "blindata.metadata.data_flows"
    @staticmethod
    def description() -> str: return "Extract data flows (lineage) between physical entities in Blindata"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/data-flows", params={"size": 500})
        resp.raise_for_status()
        return [{
            "uuid": f.get("uuid", ""), "name": f.get("name", ""),
            "source": f.get("source", {}).get("name", ""),
            "target": f.get("target", {}).get("name", ""),
            "description": f.get("description", ""),
            "transformation": f.get("transformation", ""),
        } for f in resp.json().get("content", resp.json().get("results", []))]
