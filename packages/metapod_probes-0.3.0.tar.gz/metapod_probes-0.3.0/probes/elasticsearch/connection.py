"""Elasticsearch connection — via elasticsearch-py."""
from __future__ import annotations
from core.config import SourceConfig

def get_client(config: SourceConfig):
    try:
        from elasticsearch import Elasticsearch
    except ImportError:
        raise ConnectionError("elasticsearch not installed. Run: pip install elasticsearch")
    hosts = [f"{'https' if config.token else 'http'}://{config.host}:{config.port or 9200}"]
    kwargs: dict = {}
    if config.username and config.password:
        kwargs["basic_auth"] = (config.username, config.password)
    if config.token:
        kwargs["api_key"] = config.token
    return Elasticsearch(hosts, **kwargs)

def source_id(config: SourceConfig) -> str:
    return f"elasticsearch://{config.host}:{config.port or 9200}"
