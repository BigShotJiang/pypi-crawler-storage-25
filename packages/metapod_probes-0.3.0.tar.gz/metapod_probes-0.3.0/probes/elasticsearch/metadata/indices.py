"""Probe: elasticsearch.metadata.indices — list indices with mappings."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class EsIndicesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "elasticsearch.metadata.indices"
    @staticmethod
    def description() -> str: return "List Elasticsearch indices with doc count, size, and field mappings"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        indices = connection.cat.indices(format="json")
        results = []
        for idx in indices:
            name = idx.get("index", "")
            if name.startswith("."): continue  # Skip system indices
            mapping = connection.indices.get_mapping(index=name)
            props = mapping.get(name, {}).get("mappings", {}).get("properties", {})
            fields = [{"name": k, "type": v.get("type", "object")} for k, v in props.items()]
            results.append({
                "index": name, "doc_count": idx.get("docs.count", "0"),
                "size": idx.get("store.size", ""),
                "health": idx.get("health", ""), "status": idx.get("status", ""),
                "field_count": len(fields), "fields": fields[:50],
            })
        return results
