"""Google BigQuery connection — via google-cloud-bigquery SDK.

Config:
  host = project_id (e.g., "my-gcp-project")
  schema_name = dataset_id (e.g., "analytics")
  token = path to service account JSON key file (optional if using default credentials)
"""

from __future__ import annotations

from core.config import SourceConfig


def get_client(config: SourceConfig):
    try:
        from google.cloud import bigquery
    except ImportError:
        raise ConnectionError("google-cloud-bigquery not installed. Run: pip install google-cloud-bigquery")

    project = config.host or None

    if config.token:
        # Service account key file
        return bigquery.Client.from_service_account_json(config.token, project=project)
    else:
        # Default credentials (gcloud auth, workload identity, etc.)
        return bigquery.Client(project=project)


def source_id(config: SourceConfig) -> str:
    return f"bigquery://{config.host}/{config.schema_name}"
