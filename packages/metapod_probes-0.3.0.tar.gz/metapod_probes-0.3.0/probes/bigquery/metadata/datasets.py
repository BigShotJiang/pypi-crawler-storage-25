"""Probe: bigquery.metadata.datasets — list all datasets in the project."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BQDatasetsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "bigquery.metadata.datasets"

    @staticmethod
    def description() -> str:
        return "List all BigQuery datasets in the project with location and description"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        return [
            {
                "dataset_id": ds.dataset_id,
                "project": ds.project,
                "location": ds.location or "",
                "description": ds.description or "",
                "created": str(ds.created) if ds.created else None,
                "modified": str(ds.modified) if ds.modified else None,
            }
            for ds in connection.list_datasets()
        ]
