"""Probe: bigquery.metadata.tables — list tables in a dataset."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BQTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "bigquery.metadata.tables"

    @staticmethod
    def description() -> str:
        return "List tables and views in a BigQuery dataset with row count and size"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        dataset = schema or kwargs.get("dataset", "")
        if not dataset:
            return []

        results = []
        for table_ref in connection.list_tables(dataset):
            # Get full table metadata
            try:
                t = connection.get_table(table_ref)
                results.append({
                    "table_id": t.table_id,
                    "dataset": t.dataset_id,
                    "table_type": t.table_type,
                    "num_rows": t.num_rows,
                    "num_bytes": t.num_bytes,
                    "created": str(t.created) if t.created else None,
                    "modified": str(t.modified) if t.modified else None,
                    "description": t.description or "",
                    "clustering_fields": t.clustering_fields or [],
                    "partition_type": t.time_partitioning.type_ if t.time_partitioning else None,
                    "partition_field": t.time_partitioning.field if t.time_partitioning else None,
                })
            except Exception:
                results.append({"table_id": table_ref.table_id, "dataset": dataset})

        return results
