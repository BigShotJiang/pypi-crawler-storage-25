"""Probe: bigquery.metadata.views — extract view SQL from BigQuery."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BQViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "bigquery.metadata.views"

    @staticmethod
    def description() -> str:
        return "Extract view SQL definitions from BigQuery"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        dataset = schema or kwargs.get("dataset", "")
        if not dataset:
            return []

        results = []
        for table_ref in connection.list_tables(dataset):
            try:
                t = connection.get_table(table_ref)
                if t.table_type == "VIEW" and t.view_query:
                    results.append({
                        "view_name": t.table_id,
                        "dataset": t.dataset_id,
                        "sql_text": t.view_query,
                        "use_legacy_sql": t.view_use_legacy_sql,
                        "description": t.description or "",
                    })
            except Exception:
                pass

        return results
