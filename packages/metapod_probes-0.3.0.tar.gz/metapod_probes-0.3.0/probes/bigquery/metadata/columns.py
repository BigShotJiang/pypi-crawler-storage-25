"""Probe: bigquery.metadata.columns — extract column schemas from BigQuery tables."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BQColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "bigquery.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column definitions with types, modes, and descriptions from BigQuery"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        dataset = schema or kwargs.get("dataset", "")
        if not dataset:
            return []

        results = []
        for table_ref in connection.list_tables(dataset):
            try:
                t = connection.get_table(table_ref)
                for i, field in enumerate(t.schema):
                    results.append({
                        "table_id": t.table_id,
                        "column_name": field.name,
                        "data_type": field.field_type,
                        "mode": field.mode,  # NULLABLE, REQUIRED, REPEATED
                        "description": field.description or "",
                        "position": i + 1,
                        "is_nested": field.field_type in ("RECORD", "STRUCT"),
                        "sub_fields": [sf.name for sf in (field.fields or [])],
                    })
            except Exception:
                pass

        return results
