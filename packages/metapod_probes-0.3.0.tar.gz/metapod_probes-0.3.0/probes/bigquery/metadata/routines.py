"""Probe: bigquery.metadata.routines — extract UDFs and stored procedures."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BQRoutinesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "bigquery.metadata.routines"

    @staticmethod
    def description() -> str:
        return "Extract BigQuery UDFs and stored procedures with SQL definitions"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        dataset = schema or kwargs.get("dataset", "")
        if not dataset:
            return []

        results = []
        try:
            for routine in connection.list_routines(dataset):
                r = connection.get_routine(routine)
                results.append({
                    "routine_id": r.routine_id,
                    "routine_type": r.type_,  # SCALAR_FUNCTION, PROCEDURE, TABLE_VALUED_FUNCTION
                    "language": r.language or "SQL",
                    "body": r.body or "",
                    "description": r.description or "",
                    "created": str(r.created) if r.created else None,
                    "modified": str(r.modified) if r.modified else None,
                    "arguments": [
                        {"name": a.name, "data_type": str(a.data_type)} for a in (r.arguments or [])
                    ],
                })
        except Exception:
            pass

        return results
