"""Probe: qlik.metadata.apps — extract Qlik app overview."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class QlikAppsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "qlik.metadata.apps"
    @staticmethod
    def description() -> str: return "Extract Qlik Sense/QlikView app overview: title, type, object count"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        return [{
            "file": a.get("file", ""), "type": a.get("type", ""),
            "title": a.get("title", ""), "description": a.get("description", ""),
            "object_count": a.get("object_count", 0),
            "content_types": a.get("content_types", []),
            "error": a.get("error"),
        } for a in connection]
