"""Probe: qlik.metadata.data_model — extract tables and fields from Qlik apps.

For .qvf (Qlik Sense): parsed from SQLite content
For .qvw (QlikView): extracted via binary pattern matching
"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class QlikDataModelProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "qlik.metadata.data_model"
    @staticmethod
    def description() -> str: return "Extract tables and fields from Qlik data model (.qvf SQLite or .qvw binary)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for app in connection:
            if app.get("type") == "qvf" and app.get("load_script"):
                # Parse tables from load script
                import re
                script = app["load_script"]
                # Find table definitions: tablename: LOAD ... FROM ...
                blocks = re.findall(r'(\w+)\s*:\s*(?:SQL\s+)?(?:LOAD|SELECT)\b(.+?)(?:;|STORE|NEXT)', script, re.IGNORECASE | re.DOTALL)
                for table_name, block in blocks:
                    fields = re.findall(r'(?:^|\s)(\w+)\s*(?:,|\s+as\s+)', block, re.IGNORECASE)
                    results.append({
                        "file": app.get("file", ""), "type": "qvf",
                        "table_name": table_name, "field_count": len(fields),
                        "fields": list(dict.fromkeys(fields))[:30],  # dedupe
                    })
            elif app.get("type") == "qvw":
                # Use detected tables/fields from binary parsing
                for table in app.get("tables_detected", []):
                    results.append({
                        "file": app.get("file", ""), "type": "qvw",
                        "table_name": table, "field_count": 0, "fields": [],
                        "note": "Fields not extractable from QVW binary",
                    })
                if app.get("fields_detected"):
                    results.append({
                        "file": app.get("file", ""), "type": "qvw",
                        "table_name": "_ALL_FIELDS", "field_count": len(app["fields_detected"]),
                        "fields": app["fields_detected"][:50],
                    })
        return results
