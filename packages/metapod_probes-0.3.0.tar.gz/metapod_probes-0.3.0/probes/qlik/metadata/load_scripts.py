"""Probe: qlik.metadata.load_scripts — extract Qlik load scripts (data source definitions).

The load script contains SQL statements, file paths, and connection definitions
that define the data model. This is the primary artifact for lineage analysis.
"""
import re
from core.base_probe import BaseProbe
from core.registry import register

@register
class QlikLoadScriptsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "qlik.metadata.load_scripts"
    @staticmethod
    def description() -> str: return "Extract Qlik load scripts with SQL, LOAD statements, and data source references"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for app in connection:
            script = app.get("load_script", "")
            if not script: continue

            # Parse load script sections
            sections = re.split(r'(?m)^//', script)
            for section in sections:
                if not section.strip(): continue
                # Detect data source type
                ds_type = _detect_source(section)
                # Extract table names from STORE/LOAD statements
                tables = re.findall(r'(?:STORE|LOAD|FROM)\s+\[?(\w+)\]?', section, re.IGNORECASE)
                # Extract SQL blocks
                sql_blocks = re.findall(r'SQL\s+(SELECT.*?)(?:;|\n\n)', section, re.IGNORECASE | re.DOTALL)

                if tables or sql_blocks:
                    results.append({
                        "file": app.get("file", ""),
                        "source_type": ds_type,
                        "tables_referenced": list(set(tables))[:20],
                        "sql_statements": [s.strip()[:300] for s in sql_blocks[:5]],
                        "script_length": len(section),
                    })
        return results


def _detect_source(section: str) -> str:
    lower = section.lower()
    if "oledb" in lower or "odbc" in lower: return "DATABASE"
    if "lib://" in lower or "from [lib://" in lower: return "QLIK_LIB"
    if ".qvd" in lower: return "QVD"
    if ".csv" in lower or ".txt" in lower: return "FILE"
    if ".xlsx" in lower or ".xls" in lower: return "EXCEL"
    if "sql " in lower or "select " in lower: return "SQL"
    if "rest://" in lower or "http" in lower: return "REST_API"
    return "UNKNOWN"
