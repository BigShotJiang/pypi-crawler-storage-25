"""Qlik Sense / QlikView metadata extraction.

Qlik Sense (.qvf): SQLite database containing load scripts, data model, variables.
QlikView (.qvw): Proprietary binary — extract XML metadata via QlikView API or
                 parse the embedded XML section (limited).

Config:
  host = directory containing .qvf/.qvw files
  schema_name = specific file (optional)
"""

from __future__ import annotations

import sqlite3
import struct
from pathlib import Path

from core.config import SourceConfig


def get_apps(config: SourceConfig) -> list[dict]:
    """Parse Qlik Sense .qvf and QlikView .qvw files."""
    directory = Path(config.host or ".")
    target = config.schema_name or ""

    files = []
    if target:
        p = directory / target
        if p.exists():
            files = [p]
    else:
        files = list(directory.glob("*.qvf")) + list(directory.glob("*.qvw"))

    apps = []
    for f in files:
        try:
            if f.suffix.lower() == ".qvf":
                apps.append(_parse_qvf(f))
            elif f.suffix.lower() == ".qvw":
                apps.append(_parse_qvw(f))
        except Exception as e:
            apps.append({"file": f.name, "path": str(f), "type": f.suffix, "error": str(e)})

    return apps


def _parse_qvf(filepath: Path) -> dict:
    """Parse Qlik Sense .qvf (SQLite database)."""
    conn = sqlite3.connect(str(filepath))
    conn.row_factory = sqlite3.Row

    app: dict = {"file": filepath.name, "path": str(filepath), "type": "qvf"}

    try:
        # Get load script
        cur = conn.execute("SELECT qContent FROM TransientContent WHERE qType = 'load_script'")
        row = cur.fetchone()
        if row:
            app["load_script"] = row[0] if isinstance(row[0], str) else row[0].decode("utf-8", errors="replace")

        # Get app properties
        cur = conn.execute("SELECT qContent FROM TransientContent WHERE qType = 'app_properties'")
        row = cur.fetchone()
        if row:
            import json
            try:
                props = json.loads(row[0] if isinstance(row[0], str) else row[0].decode("utf-8", errors="replace"))
                app["title"] = props.get("qTitle", "")
                app["description"] = props.get("qDescription", "")
            except Exception:
                pass

        # Get all content types
        cur = conn.execute("SELECT DISTINCT qType FROM TransientContent")
        app["content_types"] = [r[0] for r in cur.fetchall()]

        # Count objects
        try:
            cur = conn.execute("SELECT COUNT(*) FROM TransientContent")
            app["object_count"] = cur.fetchone()[0]
        except Exception:
            app["object_count"] = 0

    finally:
        conn.close()

    return app


def _parse_qvw(filepath: Path) -> dict:
    """Parse QlikView .qvw — extract what we can from the binary format.

    QVW files have an XML metadata section embedded in the binary.
    We search for the XML block containing field definitions.
    """
    app: dict = {"file": filepath.name, "path": str(filepath), "type": "qvw"}

    with open(filepath, "rb") as f:
        data = f.read(min(filepath.stat().st_size, 5_000_000))  # Read first 5MB

    # Search for XML sections
    xml_sections = []
    idx = 0
    while True:
        start = data.find(b"<?xml", idx)
        if start == -1:
            break
        end = data.find(b"</", start + 100)
        if end != -1:
            end = data.find(b">", end) + 1
        if end > start:
            try:
                section = data[start:end].decode("utf-8", errors="replace")
                xml_sections.append(section[:500])
            except Exception:
                pass
        idx = start + 10

    app["xml_sections_found"] = len(xml_sections)
    app["note"] = "QVW is proprietary binary. Limited metadata extracted."

    # Try to find field names via pattern matching
    import re
    field_matches = re.findall(rb'<FieldName>([^<]+)</FieldName>', data)
    app["fields_detected"] = [m.decode("utf-8", errors="replace") for m in field_matches[:100]]

    # Try to find table names
    table_matches = re.findall(rb'<TableName>([^<]+)</TableName>', data)
    app["tables_detected"] = list(set(m.decode("utf-8", errors="replace") for m in table_matches[:50]))

    return app


def source_id(config: SourceConfig) -> str:
    return f"qlik://{config.host}/{config.schema_name or '*'}"
