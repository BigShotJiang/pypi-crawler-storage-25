"""Probe: powerbi.metadata.relationships — extract table relationships from Power BI models."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PBIRelationshipsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "powerbi.metadata.relationships"

    @staticmethod
    def description() -> str:
        return "Extract table relationships (FK-like) with cardinality and cross-filter from .pbit/.pbix"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for entry in connection:
            if "error" in entry:
                continue
            model = entry.get("model", {})
            rels = model.get("model", model).get("relationships", [])
            for r in rels:
                results.append({
                    "file": entry["file"],
                    "from_table": r.get("fromTable", ""),
                    "from_column": r.get("fromColumn", ""),
                    "to_table": r.get("toTable", ""),
                    "to_column": r.get("toColumn", ""),
                    "cardinality": _cardinality(r.get("fromCardinality"), r.get("toCardinality")),
                    "cross_filtering": r.get("crossFilteringBehavior", "oneDirection"),
                    "is_active": r.get("isActive", True),
                })
        return results


def _cardinality(from_c, to_c) -> str:
    mapping = {(None, None): "many-to-one", ("one", None): "one-to-many",
               (None, "one"): "many-to-one", ("one", "one"): "one-to-one",
               ("many", "many"): "many-to-many"}
    return mapping.get((from_c, to_c), f"{from_c or 'many'}-to-{to_c or 'one'}")
