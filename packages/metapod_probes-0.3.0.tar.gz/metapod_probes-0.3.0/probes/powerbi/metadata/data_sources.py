"""Probe: powerbi.metadata.data_sources — extract data source connections from Power BI models."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PBIDataSourcesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "powerbi.metadata.data_sources"

    @staticmethod
    def description() -> str:
        return "Extract data source connection strings and types from .pbit/.pbix M queries"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for entry in connection:
            if "error" in entry:
                continue
            model = entry.get("model", {})
            tables = model.get("model", model).get("tables", [])

            # Extract from partition source expressions (Power Query M)
            for t in tables:
                for p in t.get("partitions", []):
                    src = p.get("source", {})
                    expr = src.get("expression", "")
                    if isinstance(expr, list):
                        expr = "\n".join(expr)
                    if not expr:
                        continue

                    # Parse M expression for data source hints
                    ds_type, ds_detail = _parse_m_source(expr)
                    if ds_type:
                        results.append({
                            "file": entry["file"],
                            "table_name": t.get("name", ""),
                            "source_type": ds_type,
                            "source_detail": ds_detail,
                            "m_expression": expr[:300],
                        })

            # Also check explicit dataSources section
            data_sources = model.get("model", model).get("dataSources", [])
            for ds in data_sources:
                conn_str = ds.get("connectionString", "")
                results.append({
                    "file": entry["file"],
                    "table_name": "",
                    "source_type": ds.get("type", "structured"),
                    "source_detail": _mask_connection(conn_str),
                    "m_expression": "",
                })

        # Deduplicate by source
        seen = set()
        unique = []
        for r in results:
            key = (r["file"], r["source_type"], r["source_detail"][:50])
            if key not in seen:
                seen.add(key)
                unique.append(r)
        return unique


def _parse_m_source(expr: str) -> tuple[str, str]:
    """Detect data source type from Power Query M expression."""
    lower = expr.lower()
    if "sql.database" in lower:
        return "SQL_SERVER", _extract_between(expr, 'Sql.Database("', '"')
    if "oracle.database" in lower:
        return "ORACLE", _extract_between(expr, 'Oracle.Database("', '"')
    if "postgresql.database" in lower:
        return "POSTGRESQL", _extract_between(expr, 'PostgreSQL.Database("', '"')
    if "snowflake.databases" in lower:
        return "SNOWFLAKE", _extract_between(expr, 'Snowflake.Databases("', '"')
    if "azurestorage.blobs" in lower or "azurestorage.datalake" in lower:
        return "AZURE_STORAGE", _extract_between(expr, '("https://', '"')
    if "web.contents" in lower or "web.browsercontents" in lower:
        return "WEB_API", _extract_between(expr, '("', '"')
    if "excel.workbook" in lower:
        return "EXCEL", ""
    if "csv.document" in lower:
        return "CSV", ""
    if "json.document" in lower:
        return "JSON", ""
    if "sharepoint" in lower:
        return "SHAREPOINT", ""
    return "", ""


def _extract_between(text: str, start: str, end: str) -> str:
    try:
        s = text.index(start) + len(start)
        e = text.index(end, s)
        return text[s:e][:100]
    except ValueError:
        return ""


def _mask_connection(conn: str) -> str:
    if "Password=" in conn:
        import re
        conn = re.sub(r"Password=[^;]*", "Password=***", conn)
    return conn[:150]
