"""Probe: powerbi.metadata.datasets — extract dataset overview from .pbit files."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PBIDatasetProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "powerbi.metadata.datasets"

    @staticmethod
    def description() -> str:
        return "Extract dataset name, culture, tables count from .pbit/.pbix files"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # connection is list[dict] from get_models()
        results = []
        for entry in connection:
            if "error" in entry:
                results.append({"file": entry["file"], "error": entry["error"]})
                continue
            model = entry.get("model", {})
            tables = model.get("model", model).get("tables", [])
            results.append({
                "file": entry["file"],
                "name": model.get("name", entry["file"]),
                "culture": model.get("culture", ""),
                "table_count": len(tables),
                "compatibility_level": model.get("compatibilityLevel", ""),
            })
        return results
