"""Probe: powerbi.metadata.measures — extract DAX measures from Power BI models."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PBIMeasuresProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "powerbi.metadata.measures"

    @staticmethod
    def description() -> str:
        return "Extract DAX measure definitions from .pbit/.pbix models"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for entry in connection:
            if "error" in entry:
                continue
            model = entry.get("model", {})
            tables = model.get("model", model).get("tables", [])
            for t in tables:
                for m in t.get("measures", []):
                    expr = m.get("expression", "")
                    if isinstance(expr, list):
                        expr = "\n".join(expr)
                    results.append({
                        "file": entry["file"],
                        "table_name": t.get("name", ""),
                        "measure_name": m.get("name", ""),
                        "expression": expr,
                        "format_string": m.get("formatString", ""),
                        "is_hidden": m.get("isHidden", False),
                        "description": m.get("description", ""),
                    })
        return results
