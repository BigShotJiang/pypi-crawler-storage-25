"""Probe: powerbi.metadata.tables — extract table definitions from Power BI models."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PBITablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "powerbi.metadata.tables"

    @staticmethod
    def description() -> str:
        return "Extract table names, partitions, and source queries from .pbit/.pbix models"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for entry in connection:
            if "error" in entry:
                continue
            model = entry.get("model", {})
            tables = model.get("model", model).get("tables", [])
            for t in tables:
                partitions = t.get("partitions", [])
                source_query = ""
                source_type = ""
                for p in partitions:
                    src = p.get("source", {})
                    if src.get("expression"):
                        expr = src["expression"]
                        source_query = expr if isinstance(expr, str) else "\n".join(expr)
                    source_type = src.get("type", "")

                results.append({
                    "file": entry["file"],
                    "table_name": t.get("name", ""),
                    "is_hidden": t.get("isHidden", False),
                    "column_count": len(t.get("columns", [])),
                    "measure_count": len(t.get("measures", [])),
                    "source_type": source_type,
                    "source_query": source_query[:500],
                })
        return results
