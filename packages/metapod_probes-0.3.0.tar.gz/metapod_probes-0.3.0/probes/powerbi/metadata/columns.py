"""Probe: powerbi.metadata.columns — extract column definitions from Power BI models."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PBIColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "powerbi.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column names, types, and expressions from .pbit/.pbix models"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for entry in connection:
            if "error" in entry:
                continue
            model = entry.get("model", {})
            tables = model.get("model", model).get("tables", [])
            for t in tables:
                for col in t.get("columns", []):
                    results.append({
                        "file": entry["file"],
                        "table_name": t.get("name", ""),
                        "column_name": col.get("name", ""),
                        "data_type": col.get("dataType", ""),
                        "source_column": col.get("sourceColumn", ""),
                        "is_hidden": col.get("isHidden", False),
                        "expression": col.get("expression", ""),
                        "format_string": col.get("formatString", ""),
                        "sort_by_column": col.get("sortByColumn", ""),
                    })
        return results
