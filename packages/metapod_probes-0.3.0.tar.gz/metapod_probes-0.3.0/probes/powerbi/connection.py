"""Power BI metadata extraction — from .pbit/.pbix files.

.pbit files are ZIP archives containing a DataModelSchema JSON file
with full dataset definitions: tables, columns, measures, relationships, data sources.
No Power BI Service API needed — works entirely from exported files.

Config mapping:
  host = path to directory containing .pbit/.pbix files
  schema_name = specific file name (optional, empty = scan all)
"""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

from core.config import SourceConfig


def get_models(config: SourceConfig) -> list[dict]:
    """Extract DataModelSchema from .pbit/.pbix files in the configured directory."""
    directory = Path(config.host or ".")
    target_file = config.schema_name or ""

    models = []
    files = []

    if target_file:
        p = directory / target_file
        if p.exists():
            files = [p]
    else:
        files = list(directory.glob("*.pbit")) + list(directory.glob("*.pbix"))

    for f in files:
        try:
            model = _extract_model(f)
            if model:
                models.append({"file": f.name, "path": str(f), "model": model})
        except Exception as e:
            models.append({"file": f.name, "path": str(f), "error": str(e)})

    return models


def _extract_model(filepath: Path) -> dict | None:
    """Extract DataModelSchema from a .pbit or .pbix ZIP archive."""
    with zipfile.ZipFile(filepath, "r") as zf:
        # .pbit stores model in DataModelSchema
        for name in zf.namelist():
            if "DataModelSchema" in name:
                raw = zf.read(name)
                # Handle BOM and encoding
                text = raw.decode("utf-16-le", errors="replace")
                if text.startswith("\ufeff"):
                    text = text[1:]
                return json.loads(text)

            # Alternative: model.bim (Analysis Services format)
            if name.endswith("model.bim"):
                return json.loads(zf.read(name).decode("utf-8"))

    return None


def source_id(config: SourceConfig) -> str:
    return f"powerbi://{config.host}/{config.schema_name or '*'}"
