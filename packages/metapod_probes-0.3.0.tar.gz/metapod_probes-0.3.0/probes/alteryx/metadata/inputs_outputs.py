"""Probe: alteryx.metadata.inputs_outputs — extract data sources and targets from Alteryx workflows."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class AlteryxIOProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "alteryx.metadata.inputs_outputs"
    @staticmethod
    def description() -> str: return "Extract input/output tool configurations: file paths, DB connections, table names"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wf in connection:
            if "error" in wf: continue
            root = wf["root"]
            for node in root.findall(".//Node"):
                gui = node.find(".//GuiSettings")
                plugin = gui.get("Plugin", "") if gui is not None else ""
                config = node.find(".//Properties/Configuration")
                if not config: continue
                if any(kw in plugin for kw in ["Input", "DbFileInput", "AmazonS3", "AzureBlob"]):
                    file_el = config.find(".//File") or config.find(".//FileName")
                    conn_el = config.find(".//Connection") or config.find(".//ConnStr")
                    table_el = config.find(".//TableName") or config.find(".//Table")
                    results.append({
                        "file": wf["file"], "direction": "INPUT", "tool": plugin,
                        "source_file": file_el.text if file_el is not None else "",
                        "connection": (conn_el.text or "")[:100] if conn_el is not None else "",
                        "table": table_el.text if table_el is not None else "",
                    })
                elif any(kw in plugin for kw in ["Output", "DbFileOutput"]):
                    file_el = config.find(".//File") or config.find(".//FileName")
                    conn_el = config.find(".//Connection") or config.find(".//ConnStr")
                    table_el = config.find(".//TableName") or config.find(".//Table")
                    results.append({
                        "file": wf["file"], "direction": "OUTPUT", "tool": plugin,
                        "target_file": file_el.text if file_el is not None else "",
                        "connection": (conn_el.text or "")[:100] if conn_el is not None else "",
                        "table": table_el.text if table_el is not None else "",
                    })
        return results
