"""Probe: alteryx.metadata.workflows — extract workflow overview."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class AlteryxWorkflowsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "alteryx.metadata.workflows"
    @staticmethod
    def description() -> str: return "Extract Alteryx workflow structure: tools, connections, annotations"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wf in connection:
            if "error" in wf: results.append(wf); continue
            root = wf["root"]
            nodes = root.findall(".//Node")
            connections = root.findall(".//Connection")
            results.append({
                "file": wf["file"],
                "tool_count": len(nodes),
                "connection_count": len(connections),
                "tools": [{"id": n.get("ToolID", ""), "plugin": n.find(".//GuiSettings").get("Plugin", "") if n.find(".//GuiSettings") is not None else ""} for n in nodes[:50]],
            })
        return results
