"""Alteryx workflow metadata extraction — .yxmd/.yxmc/.yxwz XML parsing.

Config: host = directory containing Alteryx workflow files
"""
from __future__ import annotations
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from core.config import SourceConfig

def get_workflows(config: SourceConfig) -> list[dict]:
    directory = Path(config.host or ".")
    files = list(directory.glob("*.yxmd")) + list(directory.glob("*.yxmc")) + list(directory.glob("*.yxwz"))
    if config.schema_name:
        p = directory / config.schema_name
        files = [p] if p.exists() else []
    results = []
    for f in files:
        try:
            if f.suffix == ".yxwz":
                with zipfile.ZipFile(f) as zf:
                    for name in zf.namelist():
                        if name.endswith(".yxmd"):
                            root = ET.fromstring(zf.read(name))
                            results.append({"file": f.name, "root": root})
            else:
                root = ET.parse(str(f)).getroot()
                results.append({"file": f.name, "root": root})
        except Exception as e:
            results.append({"file": f.name, "error": str(e)})
    return results

def source_id(config: SourceConfig) -> str:
    return f"alteryx://{config.host}"
