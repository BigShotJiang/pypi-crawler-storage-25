"""Witboost (Agile Lab) — REST API for data product catalog.

Bidirectional: read data products/components FROM Witboost, push metadata TO Witboost.

Config:
  host = Witboost instance URL
  token = API token / Bearer token
  service_name = marketplace domain filter (optional)
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    base = config.host.rstrip("/") if config.host else ""
    if not base:
        raise ConnectionError("host = Witboost instance URL required")

    headers: dict = {"Accept": "application/json"}
    if config.token:
        headers["Authorization"] = f"Bearer {config.token}"
    elif config.username and config.password:
        headers["Authorization"] = f"Bearer {config.password}"

    return httpx.Client(base_url=f"{base}/api/v1", headers=headers, timeout=30)


def source_id(config: SourceConfig) -> str:
    return f"witboost://{config.host}"
