"""Probe: witboost.metadata.components — extract data product components from Witboost."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class WitboostComponents(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "witboost.metadata.components"
    @staticmethod
    def description() -> str: return "Extract data product components (output ports, storage, workloads) from Witboost"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/marketplace/data-products", params={"limit": 200})
        resp.raise_for_status()
        data = resp.json()
        items = data if isinstance(data, list) else data.get("items", data.get("results", []))
        results = []
        for dp in items:
            for comp in dp.get("components", []):
                results.append({
                    "data_product": dp.get("name", ""),
                    "component_id": comp.get("id", ""),
                    "name": comp.get("name", ""),
                    "kind": comp.get("kind", ""),  # outputport, storage, workload
                    "technology": comp.get("technology", ""),
                    "description": comp.get("description", ""),
                    "schema_fields": len(comp.get("dataContract", {}).get("schema", {}).get("columns", [])),
                })
        return results
