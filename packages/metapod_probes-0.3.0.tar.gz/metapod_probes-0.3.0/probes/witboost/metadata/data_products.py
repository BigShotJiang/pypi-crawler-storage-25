"""Probe: witboost.metadata.data_products — list data products from Witboost marketplace."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class WitboostDataProducts(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "witboost.metadata.data_products"
    @staticmethod
    def description() -> str: return "List data products with domain, owner, version, and component counts"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/marketplace/data-products", params={"limit": 200})
        resp.raise_for_status()
        data = resp.json()
        items = data if isinstance(data, list) else data.get("items", data.get("results", []))
        return [{
            "id": dp.get("id", ""), "name": dp.get("name", ""),
            "domain": dp.get("domain", ""), "version": dp.get("version", ""),
            "owner": dp.get("owner", ""), "description": dp.get("description", ""),
            "status": dp.get("status", ""),
            "components": len(dp.get("components", [])),
        } for dp in items]
