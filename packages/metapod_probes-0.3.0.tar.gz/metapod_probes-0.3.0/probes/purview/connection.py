"""Microsoft Purview (formerly Azure Purview) — REST API.

Bidirectional: read catalog/lineage FROM Purview, push metadata TO Purview.

Config:
  host = Purview account name (e.g., "myorg-purview")
  username = client_id (Azure AD app)
  password = client_secret
  service_name = tenant_id
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    account = config.host
    if not account:
        raise ConnectionError("host = Purview account name required")

    token = _get_token(config)
    base = f"https://{account}.purview.azure.com"

    return httpx.Client(
        base_url=base,
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        timeout=30,
    )


def _get_token(config: SourceConfig) -> str:
    if config.token:
        return config.token
    tenant = config.service_name
    if not all([tenant, config.username, config.password]):
        raise ConnectionError("Purview requires: service_name=tenant_id, username=client_id, password=client_secret")
    resp = httpx.post(
        f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials", "client_id": config.username,
            "client_secret": config.password, "scope": "https://purview.azure.net/.default",
        },
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def source_id(config: SourceConfig) -> str:
    return f"purview://{config.host}"
