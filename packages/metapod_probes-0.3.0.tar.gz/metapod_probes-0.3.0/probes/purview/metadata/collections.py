"""Probe: purview.metadata.collections — list Purview collections."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PurviewCollections(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "purview.metadata.collections"
    @staticmethod
    def description() -> str: return "List Purview collections (folder structure for organizing assets)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/account/collections", params={"api-version": "2019-11-01-preview"})
        resp.raise_for_status()
        return [{
            "name": c.get("name", ""), "friendly_name": c.get("friendlyName", ""),
            "description": c.get("description", ""),
            "parent": c.get("parentCollection", {}).get("referenceName", ""),
        } for c in resp.json().get("value", [])]
