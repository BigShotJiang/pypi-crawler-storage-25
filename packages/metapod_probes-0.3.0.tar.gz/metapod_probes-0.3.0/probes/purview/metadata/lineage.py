"""Probe: purview.metadata.lineage — extract lineage from Purview."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PurviewLineage(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "purview.metadata.lineage"
    @staticmethod
    def description() -> str: return "Extract lineage relationships from Purview catalog (entity GUID based)"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # First search for entities
        body = {"keywords": schema or "*", "limit": 100}
        search = connection.post("/catalog/api/search/query", json=body, params={"api-version": "2022-08-01-preview"})
        search.raise_for_status()
        results = []
        for entity in search.json().get("value", [])[:50]:
            guid = entity.get("id", "")
            if not guid: continue
            try:
                lr = connection.get(f"/catalog/api/atlas/v2/lineage/{guid}",
                                     params={"direction": "BOTH", "depth": 3, "api-version": "2022-08-01-preview"})
                if lr.status_code == 200:
                    lineage = lr.json()
                    for rel in lineage.get("relations", []):
                        results.append({
                            "source_guid": rel.get("fromEntityId", ""),
                            "target_guid": rel.get("toEntityId", ""),
                            "source_name": entity.get("name", ""),
                            "relationship": rel.get("relationshipId", ""),
                        })
            except Exception:
                pass
        return results
