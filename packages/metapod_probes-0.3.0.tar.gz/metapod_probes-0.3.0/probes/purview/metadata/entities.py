"""Probe: purview.metadata.entities — search and extract entities from Purview catalog."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class PurviewEntities(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "purview.metadata.entities"
    @staticmethod
    def description() -> str: return "Search Purview catalog entities (tables, columns, datasets) with classifications"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        body = {"keywords": schema or "*", "limit": 500}
        resp = connection.post("/catalog/api/search/query", json=body, params={"api-version": "2022-08-01-preview"})
        resp.raise_for_status()
        return [{
            "name": e.get("name", ""), "qualified_name": e.get("qualifiedName", ""),
            "type": e.get("entityType", ""), "description": e.get("description", ""),
            "classifications": e.get("classification", []),
            "collection": e.get("assetType", []),
            "owner": e.get("owner", ""),
        } for e in resp.json().get("value", [])]
