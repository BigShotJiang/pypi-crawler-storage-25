"""AWS S3 connection — via boto3."""

from __future__ import annotations

from core.config import SourceConfig


def get_client(config: SourceConfig):
    try:
        import boto3
    except ImportError:
        raise ConnectionError("boto3 not installed. Run: pip install boto3")

    kwargs: dict = {}
    if config.host and config.host != "localhost":
        kwargs["endpoint_url"] = config.host if config.host.startswith("http") else f"https://{config.host}"
    if config.username:
        kwargs["aws_access_key_id"] = config.username
    if config.password:
        kwargs["aws_secret_access_key"] = config.password
    if config.token:
        kwargs["aws_session_token"] = config.token

    return boto3.client("s3", **kwargs)


def source_id(config: SourceConfig) -> str:
    return f"s3://{config.schema_name or '*'}"
