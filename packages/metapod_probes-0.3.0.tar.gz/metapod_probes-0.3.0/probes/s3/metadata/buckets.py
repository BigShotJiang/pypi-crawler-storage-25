"""Probe: s3.metadata.buckets — list S3 buckets."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class S3BucketsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "s3.metadata.buckets"

    @staticmethod
    def description() -> str:
        return "List all accessible S3 buckets with creation date"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.list_buckets()
        return [
            {"name": b["Name"], "created": str(b.get("CreationDate", ""))}
            for b in resp.get("Buckets", [])
        ]
