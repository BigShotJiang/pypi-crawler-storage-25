"""Probe: s3.metadata.objects — list objects in an S3 bucket with format detection."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class S3ObjectsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "s3.metadata.objects"

    @staticmethod
    def description() -> str:
        return "List objects in an S3 bucket with size, format, and partition detection"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        bucket = schema
        if not bucket:
            return [{"error": "schema_name = bucket name required"}]

        results = []
        paginator = connection.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, MaxKeys=5000):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                ext = key.rsplit(".", 1)[-1].lower() if "." in key else ""
                results.append({
                    "key": key,
                    "size_bytes": obj.get("Size", 0),
                    "last_modified": str(obj.get("LastModified", "")),
                    "storage_class": obj.get("StorageClass", ""),
                    "extension": ext,
                    "format": _fmt(ext),
                    "is_partition": any(p in key for p in ["=", "/year=", "/month=", "/date="]),
                })
            if len(results) >= 5000:
                break
        return results


def _fmt(ext: str) -> str:
    return {"parquet": "PARQUET", "pq": "PARQUET", "csv": "CSV", "tsv": "TSV",
            "json": "JSON", "jsonl": "JSONL", "avro": "AVRO", "orc": "ORC",
            "gz": "COMPRESSED", "snappy": "COMPRESSED"}.get(ext, "OTHER")
