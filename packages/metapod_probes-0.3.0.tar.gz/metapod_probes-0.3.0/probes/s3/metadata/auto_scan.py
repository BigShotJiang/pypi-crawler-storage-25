"""Probe: s3.metadata.auto_scan — recursive S3 scan with format detection and partition clustering.

Crawls an S3 bucket, detects file formats, identifies partition patterns (Hive, date-based),
groups files into logical datasets, and generates schema probes for CSV/JSON/Parquet.
"""

from __future__ import annotations

import csv
import io
import json
import re
from collections import defaultdict

from core.base_probe import BaseProbe
from core.registry import register

PARTITION_PATTERNS = [
    (r"(\d{4})-(\d{2})-(\d{2})", "yyyy-mm-dd"),
    (r"(\d{4})-(\d{2})", "yyyy-mm"),
    (r"(\d{4})/(\d{2})/(\d{2})", "yyyy/mm/dd"),
    (r"year=(\d{4})", "hive_year"),
    (r"month=(\d{1,2})", "hive_month"),
    (r"day=(\d{1,2})", "hive_day"),
    (r"date=(\d{4}-\d{2}-\d{2})", "hive_date"),
    (r"region=(\w+)", "hive_region"),
    (r"country=(\w+)", "hive_country"),
    (r"(\w+)=(\w+)", "hive_generic"),
]

FORMAT_MAP = {
    "parquet": "PARQUET", "pq": "PARQUET", "csv": "CSV", "tsv": "TSV",
    "json": "JSON", "jsonl": "JSONL", "avro": "AVRO", "orc": "ORC",
    "gz": "COMPRESSED", "snappy": "COMPRESSED", "xlsx": "EXCEL", "xml": "XML",
}


@register
class S3AutoScanProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "s3.metadata.auto_scan"

    @staticmethod
    def description() -> str:
        return "Recursive S3 scan: detect formats, partition patterns, and sample CSV/JSON schemas"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        bucket = schema
        if not bucket:
            return [{"error": "schema_name = bucket name required"}]

        results = []
        datasets: dict[str, dict] = defaultdict(lambda: {
            "files": 0, "total_bytes": 0, "format": "", "partitions": set(),
            "partition_type": "", "sample_keys": [], "extensions": set(),
        })

        # Phase 1: crawl and classify
        paginator = connection.get_paginator("list_objects_v2")
        all_objects = []
        for page in paginator.paginate(Bucket=bucket, MaxKeys=10000):
            for obj in page.get("Contents", []):
                all_objects.append(obj)
                if len(all_objects) >= 10000:
                    break
            if len(all_objects) >= 10000:
                break

        for obj in all_objects:
            key = obj["Key"]
            ext = key.rsplit(".", 1)[-1].lower() if "." in key else ""
            fmt = FORMAT_MAP.get(ext, "")
            if not fmt:
                continue

            # Derive dataset name by stripping partition segments and filename
            ds_name = _derive_dataset_name(key)
            ds = datasets[ds_name]
            ds["files"] += 1
            ds["total_bytes"] += obj.get("Size", 0)
            ds["format"] = fmt
            ds["extensions"].add(ext)
            if len(ds["sample_keys"]) < 3:
                ds["sample_keys"].append(key)

            # Detect partitions
            for pattern, ptype in PARTITION_PATTERNS:
                if re.search(pattern, key):
                    ds["partitions"].add(re.search(pattern, key).group(0))
                    if not ds["partition_type"]:
                        ds["partition_type"] = ptype

        # Phase 2: build dataset summaries
        for ds_name, ds in sorted(datasets.items()):
            glob = _generate_glob(ds["sample_keys"], ds["partition_type"]) if ds["sample_keys"] else ""
            results.append({
                "type": "dataset",
                "name": ds_name,
                "format": ds["format"],
                "file_count": ds["files"],
                "total_bytes": ds["total_bytes"],
                "partition_type": ds["partition_type"],
                "partition_count": len(ds["partitions"]),
                "suggested_glob": glob,
                "sample_keys": ds["sample_keys"],
            })

        # Phase 3: sample schema for top CSV/JSON datasets
        for ds_name, ds in sorted(datasets.items(), key=lambda x: -x[1]["files"]):
            if ds["format"] in ("CSV", "TSV") and ds["sample_keys"]:
                schema = _sample_csv_schema(connection, bucket, ds["sample_keys"][0])
                if schema:
                    results.append({"type": "schema", "dataset": ds_name, "format": "CSV", **schema})
            elif ds["format"] in ("JSON", "JSONL") and ds["sample_keys"]:
                schema = _sample_json_schema(connection, bucket, ds["sample_keys"][0])
                if schema:
                    results.append({"type": "schema", "dataset": ds_name, "format": "JSON", **schema})
            if len([r for r in results if r["type"] == "schema"]) >= 20:
                break

        return results


def _derive_dataset_name(key: str) -> str:
    """Strip partitions and filenames to get a logical dataset name."""
    parts = key.split("/")
    # Remove filename (last part with extension)
    if "." in parts[-1]:
        parts = parts[:-1]
    # Remove Hive partition segments (key=value)
    parts = [p for p in parts if "=" not in p and not re.match(r"^\d{4}(-\d{2}){0,2}$", p)]
    return "/".join(parts) or key.rsplit("/", 1)[0]


def _generate_glob(keys: list[str], partition_type: str) -> str:
    if not keys:
        return "*"
    path = keys[0]
    if partition_type.startswith("hive"):
        return re.sub(r"(\w+)=\w+", r"\1=*", path.rsplit("/", 1)[0]) + "/*"
    if "yyyy-mm-dd" in partition_type:
        return re.sub(r"\d{4}-\d{2}-\d{2}", "*", path)
    if "yyyy-mm" in partition_type:
        return re.sub(r"\d{4}-\d{2}", "*", path)
    return re.sub(r"\d+", "*", path)


def _sample_csv_schema(client, bucket: str, key: str) -> dict | None:
    """Download first 50KB of a CSV and infer column schema."""
    try:
        resp = client.get_object(Bucket=bucket, Key=key, Range="bytes=0-51200")
        sample = resp["Body"].read().decode("utf-8", errors="replace")
        sniffer = csv.Sniffer()
        try:
            dialect = sniffer.sniff(sample[:5000])
            delimiter = dialect.delimiter
        except csv.Error:
            delimiter = ","
        reader = csv.reader(io.StringIO(sample), delimiter=delimiter)
        rows = [r for i, r in enumerate(reader) if i < 30]
        if len(rows) < 2:
            return None
        headers = rows[0]
        return {
            "columns": [{"name": h.strip(), "position": i} for i, h in enumerate(headers)],
            "column_count": len(headers),
            "delimiter": repr(delimiter),
            "sample_rows": len(rows) - 1,
        }
    except Exception:
        return None


def _sample_json_schema(client, bucket: str, key: str) -> dict | None:
    """Download first 50KB of a JSON file and infer key schema."""
    try:
        resp = client.get_object(Bucket=bucket, Key=key, Range="bytes=0-51200")
        sample = resp["Body"].read().decode("utf-8", errors="replace")
        # Try JSONL first
        lines = [l for l in sample.split("\n") if l.strip()]
        if lines:
            obj = json.loads(lines[0])
            if isinstance(obj, dict):
                return {
                    "columns": [{"name": k, "type": type(v).__name__} for k, v in obj.items()],
                    "column_count": len(obj),
                    "format_variant": "JSONL" if len(lines) > 1 else "JSON",
                }
        # Try standard JSON
        data = json.loads(sample)
        if isinstance(data, list) and data:
            return {
                "columns": [{"name": k, "type": type(v).__name__} for k, v in data[0].items()],
                "column_count": len(data[0]),
                "format_variant": "JSON_ARRAY",
            }
    except Exception:
        pass
    return None
