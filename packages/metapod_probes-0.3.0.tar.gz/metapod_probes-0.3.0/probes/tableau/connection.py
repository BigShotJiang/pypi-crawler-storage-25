"""Tableau workbook metadata extraction — .twb/.twbx XML parsing.

.twb files are plain XML with the Tableau workbook schema.
.twbx files are ZIP archives containing the .twb + data extracts.

Config:
  host = path to directory containing .twb/.twbx files
  schema_name = specific file (optional)
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from core.config import SourceConfig


def get_workbooks(config: SourceConfig) -> list[dict]:
    """Parse .twb/.twbx files and return structured metadata."""
    directory = Path(config.host or ".")
    target = config.schema_name or ""

    files = []
    if target:
        p = directory / target
        if p.exists():
            files = [p]
    else:
        files = list(directory.glob("*.twb")) + list(directory.glob("*.twbx"))

    workbooks = []
    for f in files:
        try:
            root = _parse_twb(f)
            workbooks.append({"file": f.name, "path": str(f), "root": root})
        except Exception as e:
            workbooks.append({"file": f.name, "path": str(f), "error": str(e)})
    return workbooks


def _parse_twb(filepath: Path) -> ET.Element:
    """Parse the XML root from .twb or .twbx."""
    if filepath.suffix.lower() == ".twbx":
        with zipfile.ZipFile(filepath, "r") as zf:
            for name in zf.namelist():
                if name.endswith(".twb"):
                    return ET.fromstring(zf.read(name))
        raise ValueError("No .twb found in .twbx archive")
    else:
        return ET.parse(str(filepath)).getroot()


def source_id(config: SourceConfig) -> str:
    return f"tableau://{config.host}/{config.schema_name or '*'}"
