"""Probe: tableau.metadata.columns — extract column definitions from Tableau data sources."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TableauColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "tableau.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column names, types, roles, and calculations from .twb/.twbx data sources"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            root = wb["root"]
            for ds in root.findall(".//datasource"):
                ds_name = ds.get("name", "") or ds.get("caption", "")

                for col in ds.findall(".//column"):
                    calc = col.find("calculation")
                    results.append({
                        "file": wb["file"],
                        "datasource": ds_name,
                        "column_name": col.get("name", "").strip("[]"),
                        "caption": col.get("caption", ""),
                        "datatype": col.get("datatype", ""),
                        "role": col.get("role", ""),  # dimension / measure
                        "type": col.get("type", ""),  # quantitative / ordinal / nominal
                        "is_calculated": calc is not None,
                        "calculation": calc.get("formula", "") if calc is not None else "",
                    })
        return results
