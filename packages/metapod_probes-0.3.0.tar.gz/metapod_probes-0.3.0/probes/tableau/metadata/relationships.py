"""Probe: tableau.metadata.relationships — extract join/relationship definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TableauRelationshipsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "tableau.metadata.relationships"

    @staticmethod
    def description() -> str:
        return "Extract table joins and relationships from Tableau data model"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            root = wb["root"]
            for ds in root.findall(".//datasource"):
                ds_name = ds.get("name", "") or ds.get("caption", "")

                # Relationships (Tableau 2020.2+ data model)
                for rel in ds.findall(".//relation"):
                    join_type = rel.get("join", rel.get("type", ""))
                    if not join_type or join_type == "table":
                        continue

                    # Extract join clause
                    clause = rel.find("clause")
                    clause_text = ""
                    if clause is not None:
                        expr = clause.find(".//expression")
                        if expr is not None:
                            clause_text = expr.get("op", "")

                    # Get table names from sub-relations
                    tables = []
                    for sub in rel.findall("relation"):
                        tname = sub.get("name", sub.get("table", ""))
                        if tname:
                            tables.append(tname.strip("[]"))

                    if tables:
                        results.append({
                            "file": wb["file"],
                            "datasource": ds_name,
                            "join_type": join_type,
                            "tables": tables,
                            "clause": clause_text,
                        })

        return results
