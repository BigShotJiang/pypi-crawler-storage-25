"""Probe: tableau.metadata.worksheets — extract worksheet/view definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TableauWorksheetsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "tableau.metadata.worksheets"

    @staticmethod
    def description() -> str:
        return "Extract worksheet names, referenced datasources, and field usage from .twb/.twbx"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            root = wb["root"]
            for ws in root.findall(".//worksheet"):
                name = ws.get("name", "")
                # Collect datasource dependencies
                ds_deps = set()
                for dep in ws.findall(".//datasource-dependencies"):
                    ds_deps.add(dep.get("datasource", ""))

                # Collect field references
                fields = []
                for field in ws.findall(".//datasource-dependencies/column"):
                    fields.append(field.get("name", "").strip("[]"))

                # Rows/columns shelves
                rows_fields = [f.text or f.get("name", "") for f in ws.findall(".//rows//*") if f.tag != "rows"]
                cols_fields = [f.text or f.get("name", "") for f in ws.findall(".//cols//*") if f.tag != "cols"]

                results.append({
                    "file": wb["file"],
                    "worksheet_name": name,
                    "datasources": sorted(ds_deps),
                    "field_count": len(fields),
                    "fields": fields[:30],
                })
        return results
