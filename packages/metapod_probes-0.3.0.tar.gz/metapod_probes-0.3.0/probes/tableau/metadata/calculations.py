"""Probe: tableau.metadata.calculations — extract calculated fields with formulas."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TableauCalculationsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "tableau.metadata.calculations"

    @staticmethod
    def description() -> str:
        return "Extract calculated field definitions and their Tableau formulas"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                continue
            root = wb["root"]
            for ds in root.findall(".//datasource"):
                ds_name = ds.get("name", "") or ds.get("caption", "")
                for col in ds.findall(".//column"):
                    calc = col.find("calculation")
                    if calc is None:
                        continue
                    formula = calc.get("formula", "")
                    if not formula:
                        continue

                    # Extract referenced fields from formula
                    import re
                    refs = re.findall(r"\[([^\]]+)\]", formula)

                    results.append({
                        "file": wb["file"],
                        "datasource": ds_name,
                        "calculation_name": col.get("caption", col.get("name", "")).strip("[]"),
                        "formula": formula,
                        "datatype": col.get("datatype", ""),
                        "role": col.get("role", ""),
                        "referenced_fields": refs,
                        "reference_count": len(refs),
                    })
        return results
