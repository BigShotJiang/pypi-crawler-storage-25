"""Probe: tableau.metadata.data_sources — extract data source connections from Tableau workbooks."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TableauDataSourcesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "tableau.metadata.data_sources"

    @staticmethod
    def description() -> str:
        return "Extract data source connections (database, server, schema) from .twb/.twbx"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for wb in connection:
            if "error" in wb:
                results.append({"file": wb["file"], "error": wb["error"]})
                continue
            root = wb["root"]
            for ds in root.findall(".//datasource"):
                name = ds.get("name", "") or ds.get("caption", "")
                has_extract = ds.get("hasconnection", "") == "yes"

                # Connection details
                conn = ds.find(".//connection")
                conn_info = {}
                if conn is not None:
                    conn_info = {
                        "class": conn.get("class", ""),
                        "server": conn.get("server", ""),
                        "port": conn.get("port", ""),
                        "dbname": conn.get("dbname", ""),
                        "schema": conn.get("schema", ""),
                        "username": conn.get("username", ""),
                    }

                # Named connection (Tableau 2020+)
                named_conn = ds.find(".//named-connection/connection")
                if named_conn is not None and not conn_info.get("class"):
                    conn_info = {
                        "class": named_conn.get("class", ""),
                        "server": named_conn.get("server", ""),
                        "port": named_conn.get("port", ""),
                        "dbname": named_conn.get("dbname", ""),
                        "schema": named_conn.get("schema", ""),
                    }

                results.append({
                    "file": wb["file"],
                    "datasource_name": name,
                    "connection_class": conn_info.get("class", ""),
                    "server": conn_info.get("server", ""),
                    "port": conn_info.get("port", ""),
                    "database": conn_info.get("dbname", ""),
                    "schema": conn_info.get("schema", ""),
                    "has_extract": has_extract,
                })
        return results
