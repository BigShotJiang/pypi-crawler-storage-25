"""Probe: azure_rbac.governance.role_assignments — extract Azure role assignments.

Lists all RBAC role assignments across the subscription (or filtered by resource
group). Resolves role definition names for human-readable output.

Produces one record per (principal, role, scope) triple.
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzureRoleAssignmentsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_rbac.governance.role_assignments"

    @staticmethod
    def description() -> str:
        return "Extract Azure RBAC role assignments with principal, role, and scope"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # schema can be a resource group name for filtering
        resource_group = schema if schema and schema != "default" else ""

        # 1. Fetch role definitions (for name resolution)
        role_names = self._load_role_definitions(connection)

        # 2. Fetch role assignments
        if resource_group:
            url = f"/resourceGroups/{resource_group}/providers/Microsoft.Authorization/roleAssignments"
        else:
            url = "/providers/Microsoft.Authorization/roleAssignments"

        results = []
        try:
            resp = connection.get(url, params={"api-version": "2022-04-01"})
            resp.raise_for_status()
            assignments = resp.json().get("value", [])
        except Exception:
            return results

        for a in assignments:
            props = a.get("properties", {})
            role_def_id = props.get("roleDefinitionId", "")
            # Extract role definition GUID from the full resource ID
            role_guid = role_def_id.rsplit("/", 1)[-1] if "/" in role_def_id else role_def_id
            role_name = role_names.get(role_guid, role_guid)

            scope = props.get("scope", "")
            # Parse scope into components
            scope_type, scope_name = self._parse_scope(scope)

            results.append({
                "principal_id": props.get("principalId", ""),
                "principal_type": props.get("principalType", ""),
                "role_name": role_name,
                "role_definition_id": role_guid,
                "scope": scope,
                "scope_type": scope_type,
                "scope_name": scope_name,
                "condition": props.get("condition", ""),
                "created_on": props.get("createdOn", ""),
            })

        return results

    def _load_role_definitions(self, connection) -> dict[str, str]:
        """Load role definitions to resolve GUIDs to names."""
        try:
            resp = connection.get(
                "/providers/Microsoft.Authorization/roleDefinitions",
                params={"api-version": "2022-04-01"},
            )
            resp.raise_for_status()
            return {
                rd["name"]: rd.get("properties", {}).get("roleName", rd["name"])
                for rd in resp.json().get("value", [])
            }
        except Exception:
            return {}

    def _parse_scope(self, scope: str) -> tuple[str, str]:
        """Parse an ARM scope string into (type, name)."""
        parts = scope.split("/")
        if "resourceGroups" in parts:
            idx = parts.index("resourceGroups")
            rg = parts[idx + 1] if idx + 1 < len(parts) else ""
            # Check if there's a resource after the RG
            if "providers" in parts:
                pidx = parts.index("providers")
                resource_type = "/".join(parts[pidx + 1 : pidx + 3]) if pidx + 2 < len(parts) else ""
                resource_name = parts[-1] if len(parts) > pidx + 3 else ""
                return resource_type or "resourceGroup", resource_name or rg
            return "resourceGroup", rg
        if "subscriptions" in parts and len(parts) <= 3:
            return "subscription", parts[-1] if len(parts) > 1 else ""
        return "other", scope.rsplit("/", 1)[-1]
