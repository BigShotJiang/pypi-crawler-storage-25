"""Probe: azure_rbac.governance.resource_groups — inventory Azure resource groups and resources.

Lists all resource groups in the subscription, then optionally inventories the
resources within each group (storage accounts, SQL servers, data factories, etc.).
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzureResourceGroupsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_rbac.governance.resource_groups"

    @staticmethod
    def description() -> str:
        return "List Azure resource groups with their resources (storage, SQL, ADF, etc.)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []

        # List resource groups
        try:
            resp = connection.get(
                "/resourcegroups",
                params={"api-version": "2021-04-01"},
            )
            resp.raise_for_status()
            rgs = resp.json().get("value", [])
        except Exception:
            return results

        for rg in rgs:
            rg_name = rg.get("name", "")
            rg_record = {
                "resource_type": "resource_group",
                "name": rg_name,
                "location": rg.get("location", ""),
                "provisioning_state": rg.get("properties", {}).get("provisioningState", ""),
                "tags": rg.get("tags", {}),
                "parent": "",
            }
            results.append(rg_record)

            # List resources within the group
            try:
                rresp = connection.get(
                    f"/resourceGroups/{rg_name}/resources",
                    params={"api-version": "2021-04-01"},
                )
                rresp.raise_for_status()
                resources = rresp.json().get("value", [])
            except Exception:
                continue

            for r in resources:
                rtype = r.get("type", "")
                # Normalize type to short form
                short_type = rtype.rsplit("/", 1)[-1] if "/" in rtype else rtype

                results.append({
                    "resource_type": short_type,
                    "name": r.get("name", ""),
                    "location": r.get("location", ""),
                    "provisioning_state": r.get("properties", {}).get("provisioningState", "") if isinstance(r.get("properties"), dict) else "",
                    "tags": r.get("tags", {}),
                    "parent": rg_name,
                    "full_type": rtype,
                    "resource_id": r.get("id", ""),
                })

        return results
