"""Azure RBAC connection — ARM Management API client.

Uses Azure AD OAuth2 to authenticate and call the ARM REST API for
role assignments, role definitions, and resource inventory.

Config:
    host = tenant_id
    username = client_id
    password = client_secret
    sid = subscription_id
    token = pre-obtained Bearer token (alternative to SP auth)
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    """Create an authenticated ARM API client."""
    token = config.token or _get_sp_token(config)
    sub_id = config.sid
    if not sub_id:
        raise ConnectionError("sid (subscription_id) required for Azure RBAC")

    return httpx.Client(
        base_url=f"https://management.azure.com/subscriptions/{sub_id}",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=30,
    )


def _get_sp_token(config: SourceConfig) -> str:
    """Authenticate via service principal (client_credentials flow)."""
    tenant = config.host
    client_id = config.username
    client_secret = config.password
    if not all([tenant, client_id, client_secret]):
        raise ConnectionError("Azure RBAC requires: host=tenant_id, username=client_id, password=client_secret")

    resp = httpx.post(
        f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": "https://management.azure.com/.default",
        },
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def source_id(config: SourceConfig) -> str:
    return f"azure-rbac://{config.sid}"
