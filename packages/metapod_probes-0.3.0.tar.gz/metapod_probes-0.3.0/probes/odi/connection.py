"""Oracle Data Integrator (ODI) metadata extraction — from Smart Export XML files.

ODI exports its repository as XML via Smart Export. These files contain:
- Projects, folders, mappings, packages, scenarios
- Datastores (source/target table definitions)
- Interfaces/mappings with column-level transformations
- Variables, sequences, load plans

Config:
  host = path to directory containing ODI export XML files
  schema_name = specific file (optional)
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

from core.config import SourceConfig


def get_exports(config: SourceConfig) -> list[dict]:
    """Parse ODI Smart Export XML files."""
    directory = Path(config.host or ".")
    target = config.schema_name or ""

    files = []
    if target:
        p = directory / target
        if p.exists():
            files = [p]
    else:
        files = list(directory.glob("*.xml"))

    exports = []
    for f in files:
        try:
            tree = ET.parse(str(f))
            root = tree.getroot()
            # Check if it's an ODI export (look for ODI namespace or elements)
            if _is_odi_export(root):
                exports.append({"file": f.name, "path": str(f), "root": root})
        except Exception as e:
            exports.append({"file": f.name, "path": str(f), "error": str(e)})

    return exports


def _is_odi_export(root: ET.Element) -> bool:
    """Check if XML is an ODI Smart Export."""
    tag = root.tag.lower()
    if "smartexport" in tag or "odiexport" in tag:
        return True
    # Check for ODI-specific elements
    for child in root:
        ctag = child.tag.lower()
        if any(kw in ctag for kw in ["project", "mapping", "datastore", "interface", "loadplan"]):
            return True
    return len(list(root)) > 0  # Accept any non-empty XML from ODI directory


def source_id(config: SourceConfig) -> str:
    return f"odi://{config.host}/{config.schema_name or '*'}"
