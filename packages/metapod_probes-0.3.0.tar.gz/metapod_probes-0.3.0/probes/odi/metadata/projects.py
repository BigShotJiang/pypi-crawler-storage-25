"""Probe: odi.metadata.projects — extract ODI project structure from Smart Export."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class OdiProjectsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "odi.metadata.projects"

    @staticmethod
    def description() -> str:
        return "Extract ODI projects, folders, and mappings from Smart Export XML"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export:
                results.append({"file": export["file"], "error": export["error"]})
                continue
            root = export["root"]

            # Search for project/folder/mapping elements (case-insensitive)
            for elem in root.iter():
                tag = elem.tag.lower().split("}")[-1]  # Strip namespace
                if tag in ("project", "odiproject"):
                    results.append({
                        "file": export["file"],
                        "type": "PROJECT",
                        "name": elem.get("Name", elem.get("name", elem.text or "")),
                    })
                elif tag in ("folder", "odifolder"):
                    results.append({
                        "file": export["file"],
                        "type": "FOLDER",
                        "name": elem.get("Name", elem.get("name", "")),
                    })
                elif tag in ("mapping", "odimapping", "interface"):
                    results.append({
                        "file": export["file"],
                        "type": "MAPPING",
                        "name": elem.get("Name", elem.get("name", "")),
                        "description": elem.get("Description", elem.get("description", "")),
                    })
                elif tag in ("package", "odipackage"):
                    results.append({
                        "file": export["file"],
                        "type": "PACKAGE",
                        "name": elem.get("Name", elem.get("name", "")),
                    })
                elif tag in ("loadplan", "odiloadplan"):
                    results.append({
                        "file": export["file"],
                        "type": "LOAD_PLAN",
                        "name": elem.get("Name", elem.get("name", "")),
                    })

        return results
