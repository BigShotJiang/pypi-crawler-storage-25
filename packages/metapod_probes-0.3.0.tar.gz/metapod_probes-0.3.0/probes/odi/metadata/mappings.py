"""Probe: odi.metadata.mappings — extract ODI mapping source/target/expression details."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class OdiMappingsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "odi.metadata.mappings"

    @staticmethod
    def description() -> str:
        return "Extract ODI mapping transformations: source→target column flows with expressions"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export:
                continue
            root = export["root"]

            for elem in root.iter():
                tag = elem.tag.lower().split("}")[-1]
                if tag not in ("mapping", "odimapping", "interface"):
                    continue

                mapping_name = elem.get("Name", elem.get("name", ""))
                sources = []
                targets = []

                # Extract source/target datastores from mapping
                for child in elem.iter():
                    ctag = child.tag.lower().split("}")[-1]
                    if ctag in ("sourcedatastore", "source"):
                        sources.append(child.get("Name", child.get("name", child.get("DataStoreName", ""))))
                    elif ctag in ("targetdatastore", "target"):
                        targets.append(child.get("Name", child.get("name", child.get("DataStoreName", ""))))
                    elif ctag in ("mapexpression", "expression", "targetcolumn"):
                        expr = child.get("Expression", child.get("expression", child.text or ""))
                        col_name = child.get("Name", child.get("name", ""))
                        if expr and col_name:
                            results.append({
                                "file": export["file"],
                                "type": "COLUMN_MAPPING",
                                "mapping": mapping_name,
                                "target_column": col_name,
                                "expression": str(expr)[:300],
                                "sources": sources,
                                "targets": targets,
                            })

                if mapping_name and (sources or targets):
                    results.append({
                        "file": export["file"],
                        "type": "MAPPING",
                        "mapping": mapping_name,
                        "sources": sorted(set(sources)),
                        "targets": sorted(set(targets)),
                    })

        return results
