"""Probe: odi.metadata.datastores — extract ODI datastore (table) definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class OdiDatastoresProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "odi.metadata.datastores"

    @staticmethod
    def description() -> str:
        return "Extract ODI datastore definitions (source/target tables with columns)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        for export in connection:
            if "error" in export:
                continue
            root = export["root"]

            for elem in root.iter():
                tag = elem.tag.lower().split("}")[-1]
                if tag in ("datastore", "odidatastore", "model"):
                    name = elem.get("Name", elem.get("name", ""))
                    ds_schema = elem.get("SchemaName", elem.get("schema", ""))
                    columns = []
                    for col in elem.iter():
                        ctag = col.tag.lower().split("}")[-1]
                        if ctag in ("column", "odicolumn", "attribute"):
                            columns.append({
                                "name": col.get("Name", col.get("name", "")),
                                "data_type": col.get("Datatype", col.get("datatype", col.get("Type", ""))),
                                "length": col.get("Length", col.get("length", "")),
                                "nullable": col.get("NotNull", "false").lower() != "true",
                            })

                    if name:
                        results.append({
                            "file": export["file"],
                            "datastore_name": name,
                            "schema": ds_schema,
                            "column_count": len(columns),
                            "columns": columns[:50],  # Limit for large models
                        })

        return results
