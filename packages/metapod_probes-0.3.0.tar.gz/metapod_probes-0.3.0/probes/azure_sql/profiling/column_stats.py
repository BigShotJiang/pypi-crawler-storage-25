"""Probe: azure_sql.profiling.column_stats — column statistics from sys.stats + histograms."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlColumnStatsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.profiling.column_stats"

    @staticmethod
    def description() -> str:
        return "Column statistics: rows, rows sampled, modification counter, last updated"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT s.name AS schema_name, t.name AS table_name,
                   st.name AS stats_name, c.name AS column_name,
                   sp.rows, sp.rows_sampled, sp.modification_counter,
                   sp.last_updated
            FROM sys.stats st
            JOIN sys.tables t ON st.object_id = t.object_id
            JOIN sys.schemas s ON t.schema_id = s.schema_id
            CROSS APPLY sys.dm_db_stats_properties(st.object_id, st.stats_id) sp
            LEFT JOIN sys.stats_columns sc ON st.object_id = sc.object_id AND st.stats_id = sc.stats_id
            LEFT JOIN sys.columns c ON sc.object_id = c.object_id AND sc.column_id = c.column_id
            WHERE s.name = ?
            ORDER BY t.name, st.stats_id
        """, schema or "dbo")
        return [{
            "schema": r[0], "table_name": r[1],
            "stats_name": r[2], "column_name": r[3] or "",
            "rows": r[4], "rows_sampled": r[5],
            "modification_counter": r[6],
            "last_updated": str(r[7]) if r[7] else None,
        } for r in cur.fetchall()]
