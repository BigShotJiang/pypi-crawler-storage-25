"""Probe: azure_sql.schema_history.ddl_changes — track object modification dates."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlDdlChangesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.schema_history.ddl_changes"

    @staticmethod
    def description() -> str:
        return "Object creation and modification dates from sys.objects"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT s.name AS schema_name, o.name AS object_name,
                   o.type_desc, o.create_date, o.modify_date,
                   DATEDIFF(day, o.modify_date, GETUTCDATE()) AS days_since_modified
            FROM sys.objects o
            JOIN sys.schemas s ON o.schema_id = s.schema_id
            WHERE s.name = ? AND o.type IN ('U', 'V', 'P', 'FN', 'IF', 'TF', 'TR')
            ORDER BY o.modify_date DESC
        """, schema or "dbo")
        return [{
            "schema": r[0], "object_name": r[1], "object_type": r[2],
            "created": str(r[3]) if r[3] else None,
            "modified": str(r[4]) if r[4] else None,
            "days_since_modified": r[5],
        } for r in cur.fetchall()]
