"""Probe: azure_sql.cost.db_size — database and table sizes for FinOps."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlDbSizeProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.cost.db_size"

    @staticmethod
    def description() -> str:
        return "Database and per-table storage sizes from sys.dm_db_partition_stats"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        results = []

        # Database-level size
        cur.execute("""
            SELECT DB_NAME() AS db_name,
                   SUM(size) * 8 / 1024 AS total_mb,
                   SUM(CASE WHEN type_desc = 'ROWS' THEN size ELSE 0 END) * 8 / 1024 AS data_mb,
                   SUM(CASE WHEN type_desc = 'LOG' THEN size ELSE 0 END) * 8 / 1024 AS log_mb
            FROM sys.database_files
        """)
        for r in cur.fetchall():
            results.append({
                "level": "database", "name": r[0],
                "total_mb": r[1], "data_mb": r[2], "log_mb": r[3],
            })

        # Per-table sizes
        cur.execute("""
            SELECT s.name AS schema_name, t.name AS table_name,
                   SUM(a.total_pages) * 8 / 1024 AS total_mb,
                   SUM(a.used_pages) * 8 / 1024 AS used_mb,
                   SUM(p.rows) AS row_count
            FROM sys.tables t
            JOIN sys.schemas s ON t.schema_id = s.schema_id
            JOIN sys.indexes i ON t.object_id = i.object_id
            JOIN sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
            JOIN sys.allocation_units a ON p.partition_id = a.container_id
            WHERE s.name = ? AND i.index_id IN (0, 1)
            GROUP BY s.name, t.name
            ORDER BY SUM(a.total_pages) DESC
        """, schema or "dbo")
        for r in cur.fetchall():
            results.append({
                "level": "table", "name": f"{r[0]}.{r[1]}",
                "total_mb": r[2], "used_mb": r[3], "row_count": r[4],
            })

        return results
