"""Probe: azure_sql.metadata.columns"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column definitions from INFORMATION_SCHEMA.COLUMNS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                   NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE, ORDINAL_POSITION,
                   COLUMN_DEFAULT
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = ?
            ORDER BY TABLE_NAME, ORDINAL_POSITION
        """, schema or "dbo")
        return [{
            "table_name": r[0], "column_name": r[1], "data_type": r[2],
            "max_length": r[3], "precision": r[4], "scale": r[5],
            "nullable": r[6] == "YES", "ordinal_position": r[7],
            "default_value": r[8],
        } for r in cur.fetchall()]
