"""Probe: azure_sql.metadata.views — extract view definitions including sys.sql_modules."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.metadata.views"

    @staticmethod
    def description() -> str:
        return "Extract view definitions from sys.views + sys.sql_modules"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT v.name, s.name AS schema_name, m.definition,
                   v.create_date, v.modify_date
            FROM sys.views v
            JOIN sys.schemas s ON v.schema_id = s.schema_id
            LEFT JOIN sys.sql_modules m ON v.object_id = m.object_id
            WHERE s.name = ?
            ORDER BY v.name
        """, schema or "dbo")
        return [{
            "view_name": r[0], "schema": r[1],
            "sql_text": r[2] or "", "created": str(r[3]) if r[3] else None,
            "modified": str(r[4]) if r[4] else None,
        } for r in cur.fetchall()]
