"""Probe: azure_sql.metadata.tables"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.metadata.tables"

    @staticmethod
    def description() -> str:
        return "List tables with row count and size from sys.tables + sys.partitions"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT t.name, s.name AS schema_name, t.type_desc,
                   p.rows, t.create_date, t.modify_date
            FROM sys.tables t
            JOIN sys.schemas s ON t.schema_id = s.schema_id
            LEFT JOIN sys.partitions p ON t.object_id = p.object_id AND p.index_id IN (0, 1)
            WHERE s.name = ?
            ORDER BY t.name
        """, schema or "dbo")
        return [{
            "table_name": r[0], "schema": r[1], "type": r[2],
            "row_count": r[3], "created": str(r[4]) if r[4] else None,
            "modified": str(r[5]) if r[5] else None,
        } for r in cur.fetchall()]
