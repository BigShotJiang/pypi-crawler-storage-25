"""Probe: azure_sql.metadata.constraints"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlConstraintsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.metadata.constraints"

    @staticmethod
    def description() -> str:
        return "Extract PK, FK, unique constraints from sys.key_constraints + sys.foreign_keys"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT tc.CONSTRAINT_NAME, tc.CONSTRAINT_TYPE, tc.TABLE_NAME,
                   kcu.COLUMN_NAME, kcu.ORDINAL_POSITION,
                   ccu.TABLE_NAME AS REF_TABLE, ccu.COLUMN_NAME AS REF_COLUMN
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
            JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
              ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
            LEFT JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
              ON tc.CONSTRAINT_NAME = ccu.CONSTRAINT_NAME
            WHERE tc.TABLE_SCHEMA = ?
              AND tc.CONSTRAINT_TYPE IN ('PRIMARY KEY', 'FOREIGN KEY', 'UNIQUE')
            ORDER BY tc.TABLE_NAME, tc.CONSTRAINT_NAME, kcu.ORDINAL_POSITION
        """, schema or "dbo")
        return [{
            "constraint_name": r[0], "constraint_type": r[1], "table_name": r[2],
            "column_name": r[3], "position": r[4],
            "ref_table": r[5], "ref_column": r[6],
        } for r in cur.fetchall()]
