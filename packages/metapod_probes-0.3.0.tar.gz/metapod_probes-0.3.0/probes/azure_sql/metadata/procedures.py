"""Probe: azure_sql.metadata.procedures — extract T-SQL stored procedure source."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlProceduresProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.metadata.procedures"

    @staticmethod
    def description() -> str:
        return "Extract stored procedure and function source from sys.sql_modules"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT o.name, s.name AS schema_name, o.type_desc, m.definition,
                   o.create_date, o.modify_date
            FROM sys.objects o
            JOIN sys.schemas s ON o.schema_id = s.schema_id
            JOIN sys.sql_modules m ON o.object_id = m.object_id
            WHERE s.name = ? AND o.type IN ('P', 'FN', 'IF', 'TF', 'TR')
            ORDER BY o.name
        """, schema or "dbo")
        return [{
            "name": r[0], "schema": r[1],
            "type": r[2], "source_code": r[3] or "",
            "created": str(r[4]) if r[4] else None,
            "modified": str(r[5]) if r[5] else None,
        } for r in cur.fetchall()]
