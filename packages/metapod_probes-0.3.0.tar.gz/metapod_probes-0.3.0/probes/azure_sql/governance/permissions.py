"""Probe: azure_sql.governance.permissions — extract database permissions and roles.

Queries sys.database_principals and sys.database_permissions to map
who has access to what in Azure SQL / SQL Server.
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlPermissionsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.governance.permissions"

    @staticmethod
    def description() -> str:
        return "Extract database-level permissions from sys.database_permissions + principals"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT
                dp.name AS principal_name,
                dp.type_desc AS principal_type,
                p.permission_name,
                p.state_desc AS permission_state,
                COALESCE(OBJECT_NAME(p.major_id), '') AS object_name,
                COALESCE(OBJECT_SCHEMA_NAME(p.major_id), '') AS object_schema,
                p.class_desc AS object_class
            FROM sys.database_permissions p
            JOIN sys.database_principals dp ON p.grantee_principal_id = dp.principal_id
            WHERE dp.name NOT IN ('public', 'guest', 'INFORMATION_SCHEMA', 'sys')
            ORDER BY dp.name, p.permission_name
        """)
        return [{
            "principal": r[0],
            "principal_type": r[1],
            "permission": r[2],
            "state": r[3],
            "object_name": r[4],
            "object_schema": r[5],
            "object_class": r[6],
        } for r in cur.fetchall()]


@register
class AzSqlRolesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.governance.roles"

    @staticmethod
    def description() -> str:
        return "Extract database role memberships from sys.database_role_members"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT
                r.name AS role_name,
                r.type_desc AS role_type,
                m.name AS member_name,
                m.type_desc AS member_type
            FROM sys.database_role_members rm
            JOIN sys.database_principals r ON rm.role_principal_id = r.principal_id
            JOIN sys.database_principals m ON rm.member_principal_id = m.principal_id
            ORDER BY r.name, m.name
        """)
        return [{
            "role_name": r[0],
            "role_type": r[1],
            "member_name": r[2],
            "member_type": r[3],
        } for r in cur.fetchall()]
