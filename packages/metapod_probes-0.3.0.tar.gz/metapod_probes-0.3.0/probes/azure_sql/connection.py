"""Azure SQL / SQL Server / Synapse connection factory — via pyodbc."""

from __future__ import annotations

from core.config import SourceConfig


def connect(config: SourceConfig):
    try:
        import pyodbc
    except ImportError:
        raise ConnectionError("pyodbc not installed. Run: pip install pyodbc")

    server = config.host
    database = config.service_name or "master"
    driver = "{ODBC Driver 18 for SQL Server}"

    try:
        if config.token:
            # Azure AD token auth
            conn_str = (
                f"DRIVER={driver};SERVER={server};DATABASE={database};"
                f"Authentication=ActiveDirectoryAccessToken;AccessToken={config.token}"
            )
        else:
            conn_str = (
                f"DRIVER={driver};SERVER={server};DATABASE={database};"
                f"UID={config.username};PWD={config.password};"
                f"Encrypt=yes;TrustServerCertificate=yes"
            )
        return pyodbc.connect(conn_str)
    except Exception as e:
        msg = str(e)
        if "Login failed" in msg:
            raise ConnectionError(f"Authentication failed for {config.username}@{server}")
        if "TCP Provider" in msg or "server was not found" in msg:
            raise ConnectionError(f"Cannot reach {server}")
        raise ConnectionError(f"SQL Server connection failed: {e}")


def source_id(config: SourceConfig) -> str:
    return f"azuresql://{config.host}/{config.service_name}/{config.schema_name}"
