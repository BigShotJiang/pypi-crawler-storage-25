"""Probe: azure_sql.quality.null_ratio — null percentage from DBCC SHOW_STATISTICS."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlNullRatioProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.quality.null_ratio"

    @staticmethod
    def description() -> str:
        return "Column-level null count estimate from sys.dm_db_stats_histogram"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT s.name AS schema_name, t.name AS table_name,
                   c.name AS column_name, c.is_nullable,
                   sp.rows AS total_rows,
                   sp.rows_sampled, sp.modification_counter
            FROM sys.tables t
            JOIN sys.schemas s ON t.schema_id = s.schema_id
            JOIN sys.columns c ON t.object_id = c.object_id
            LEFT JOIN sys.stats st ON t.object_id = st.object_id AND st.stats_id = 1
            LEFT JOIN sys.dm_db_stats_properties(t.object_id, 1) sp ON 1=1
            WHERE s.name = ?
            ORDER BY t.name, c.column_id
        """, schema or "dbo")
        return [{
            "schema": r[0], "table_name": r[1], "column_name": r[2],
            "is_nullable": bool(r[3]),
            "total_rows": r[4],
            "rows_sampled": r[5],
            "modification_counter": r[6],
        } for r in cur.fetchall()]
