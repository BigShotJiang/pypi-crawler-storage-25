"""Probe: azure_sql.quality.freshness — table modification timestamps."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlFreshnessProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.quality.freshness"

    @staticmethod
    def description() -> str:
        return "Table freshness from sys.dm_db_index_usage_stats (last read/write times)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT s.name AS schema_name, t.name AS table_name,
                   t.create_date, t.modify_date,
                   MAX(ius.last_user_seek) AS last_seek,
                   MAX(ius.last_user_scan) AS last_scan,
                   MAX(ius.last_user_lookup) AS last_lookup,
                   MAX(ius.last_user_update) AS last_update
            FROM sys.tables t
            JOIN sys.schemas s ON t.schema_id = s.schema_id
            LEFT JOIN sys.dm_db_index_usage_stats ius
                ON t.object_id = ius.object_id AND ius.database_id = DB_ID()
            WHERE s.name = ?
            GROUP BY s.name, t.name, t.create_date, t.modify_date
            ORDER BY t.modify_date DESC
        """, schema or "dbo")
        return [{
            "schema": r[0], "table_name": r[1],
            "created": str(r[2]) if r[2] else None,
            "modified": str(r[3]) if r[3] else None,
            "last_seek": str(r[4]) if r[4] else None,
            "last_scan": str(r[5]) if r[5] else None,
            "last_lookup": str(r[6]) if r[6] else None,
            "last_update": str(r[7]) if r[7] else None,
        } for r in cur.fetchall()]
