"""Probe: azure_sql.quality.row_counts — row counts and sizes from sys.partitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlRowCountsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.quality.row_counts"

    @staticmethod
    def description() -> str:
        return "Row counts and reserved space from sys.dm_db_partition_stats"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT s.name AS schema_name, t.name AS table_name,
                   SUM(p.rows) AS row_count,
                   SUM(a.total_pages) * 8 AS total_kb,
                   SUM(a.used_pages) * 8 AS used_kb,
                   SUM(a.data_pages) * 8 AS data_kb
            FROM sys.tables t
            JOIN sys.schemas s ON t.schema_id = s.schema_id
            JOIN sys.indexes i ON t.object_id = i.object_id
            JOIN sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
            JOIN sys.allocation_units a ON p.partition_id = a.container_id
            WHERE s.name = ? AND i.index_id IN (0, 1)
            GROUP BY s.name, t.name
            ORDER BY SUM(p.rows) DESC
        """, schema or "dbo")
        return [{
            "schema": r[0], "table_name": r[1],
            "row_count": r[2], "total_kb": r[3],
            "used_kb": r[4], "data_kb": r[5],
        } for r in cur.fetchall()]
