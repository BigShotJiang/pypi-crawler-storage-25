"""Probe: azure_sql.compliance.sensitivity_labels — data classification labels."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlSensitivityLabelsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.compliance.sensitivity_labels"

    @staticmethod
    def description() -> str:
        return "Extract sensitivity classifications from sys.sensitivity_classifications"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        try:
            cur.execute("""
                SELECT s.name AS schema_name,
                       o.name AS table_name,
                       c.name AS column_name,
                       sc.label, sc.label_id,
                       sc.information_type, sc.information_type_id,
                       sc.rank, sc.rank_desc
                FROM sys.sensitivity_classifications sc
                JOIN sys.objects o ON sc.major_id = o.object_id
                JOIN sys.schemas s ON o.schema_id = s.schema_id
                JOIN sys.columns c ON sc.major_id = c.object_id AND sc.minor_id = c.column_id
                WHERE s.name = ?
                ORDER BY o.name, c.column_id
            """, schema or "dbo")
            return [{
                "schema": r[0], "table_name": r[1], "column_name": r[2],
                "label": r[3], "label_id": r[4],
                "information_type": r[5], "information_type_id": r[6],
                "rank": r[7], "rank_desc": r[8],
            } for r in cur.fetchall()]
        except Exception:
            return []
