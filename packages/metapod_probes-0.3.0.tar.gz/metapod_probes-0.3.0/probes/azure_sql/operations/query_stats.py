"""Probe: azure_sql.operations.query_stats — top queries by resource consumption."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class AzSqlQueryStatsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_sql.operations.query_stats"

    @staticmethod
    def description() -> str:
        return "Top queries by CPU/reads/writes from sys.dm_exec_query_stats"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("""
            SELECT TOP 50
                qs.total_worker_time / qs.execution_count AS avg_cpu_us,
                qs.total_logical_reads / qs.execution_count AS avg_reads,
                qs.total_logical_writes / qs.execution_count AS avg_writes,
                qs.execution_count,
                qs.total_worker_time AS total_cpu_us,
                qs.total_elapsed_time / 1000 AS total_elapsed_ms,
                qs.creation_time,
                qs.last_execution_time,
                SUBSTRING(qt.text, (qs.statement_start_offset/2)+1,
                    CASE WHEN qs.statement_end_offset = -1
                         THEN LEN(qt.text)
                         ELSE (qs.statement_end_offset - qs.statement_start_offset)/2 + 1
                    END) AS query_text
            FROM sys.dm_exec_query_stats qs
            CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
            ORDER BY qs.total_worker_time DESC
        """)
        return [{
            "avg_cpu_microseconds": r[0],
            "avg_logical_reads": r[1],
            "avg_logical_writes": r[2],
            "execution_count": r[3],
            "total_cpu_microseconds": r[4],
            "total_elapsed_ms": r[5],
            "created": str(r[6]) if r[6] else None,
            "last_executed": str(r[7]) if r[7] else None,
            "query_text": (r[8] or "")[:500],
        } for r in cur.fetchall()]
