"""Probe: file_scanner.metadata.parquet_schema — read Parquet file schemas from footer.

Reads only the Parquet footer (last few KB) — never loads actual data.
Extracts column names, types, row count, compression, and encoding.
"""

from pathlib import Path

from core.base_probe import BaseProbe
from core.registry import register


@register
class ParquetSchemaProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "file_scanner.metadata.parquet_schema"

    @staticmethod
    def description() -> str:
        return "Read Parquet file schemas from footer: columns, types, row count, compression"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        root = connection if isinstance(connection, Path) else Path(str(connection))
        results = []

        for f in sorted(root.rglob("*.parquet")) + sorted(root.rglob("*.pq")):
            if not f.is_file() or f.stat().st_size == 0:
                continue
            try:
                result = self._read_schema(f, root)
                if result:
                    results.append(result)
            except ImportError:
                results.append({
                    "path": str(f.relative_to(root)),
                    "error": "pyarrow not installed. Run: pip install pyarrow",
                })
                break
            except Exception as e:
                results.append({"path": str(f.relative_to(root)), "error": str(e)})

        return results

    def _read_schema(self, filepath: Path, root: Path) -> dict:
        import pyarrow.parquet as pq

        # Read only metadata (footer) — no data loaded
        meta = pq.read_metadata(str(filepath))
        schema = pq.read_schema(str(filepath))

        columns = []
        for i in range(len(schema)):
            field = schema.field(i)
            columns.append({
                "name": field.name,
                "type": str(field.type),
                "nullable": field.nullable,
                "metadata": {k.decode(): v.decode() for k, v in (field.metadata or {}).items()},
            })

        return {
            "path": str(filepath.relative_to(root)),
            "row_count": meta.num_rows,
            "row_groups": meta.num_row_groups,
            "column_count": meta.num_columns,
            "size_bytes": filepath.stat().st_size,
            "created_by": meta.created_by or "",
            "format_version": meta.format_version or "",
            "columns": columns,
            "schema_metadata": {
                k.decode(): v.decode()
                for k, v in (schema.metadata or {}).items()
            } if schema.metadata else {},
        }
