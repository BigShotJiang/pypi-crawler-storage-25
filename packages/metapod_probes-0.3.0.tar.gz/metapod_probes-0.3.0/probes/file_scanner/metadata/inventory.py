"""Probe: file_scanner.metadata.inventory — inventory all data files in a directory."""

from pathlib import Path

from probes.file_scanner.connection import SUPPORTED_EXTENSIONS

from core.base_probe import BaseProbe
from core.registry import register


@register
class FileInventoryProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "file_scanner.metadata.inventory"

    @staticmethod
    def description() -> str:
        return "List all data files (CSV, TSV, JSON, TXT, Parquet) with size and format"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        root = connection if isinstance(connection, Path) else Path(str(connection))
        pattern = schema or "*"
        results = []

        for f in sorted(root.rglob(pattern)):
            if not f.is_file():
                continue
            if f.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue
            if f.name.startswith(".") or f.name.startswith("~$"):
                continue

            stat = f.stat()
            results.append({
                "path": str(f.relative_to(root)),
                "name": f.name,
                "extension": f.suffix.lstrip(".").lower(),
                "size_bytes": stat.st_size,
                "format": _classify(f.suffix.lower()),
            })
        return results


def _classify(ext: str) -> str:
    return {
        ".csv": "CSV", ".tsv": "TSV", ".txt": "TEXT",
        ".json": "JSON", ".jsonl": "JSONL",
        ".xml": "XML", ".parquet": "PARQUET", ".avro": "AVRO",
    }.get(ext, "UNKNOWN")
