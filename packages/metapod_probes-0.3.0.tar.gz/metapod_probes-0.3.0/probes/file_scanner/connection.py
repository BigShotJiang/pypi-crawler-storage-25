"""File scanner connection — simply a local directory path.

Config:
  host = directory path to scan
  schema_name = glob pattern filter (e.g., "*.csv" or "data/*.json")
"""

from __future__ import annotations

from pathlib import Path

from core.config import SourceConfig

SUPPORTED_EXTENSIONS = {".csv", ".tsv", ".txt", ".json", ".jsonl", ".xml", ".parquet", ".avro"}


def get_path(config: SourceConfig) -> Path:
    """Return the directory to scan."""
    p = Path(config.host or ".")
    if not p.exists():
        raise ConnectionError(f"Directory not found: {p}")
    return p


def source_id(config: SourceConfig) -> str:
    return f"files://{config.host}/{config.schema_name or '*'}"
