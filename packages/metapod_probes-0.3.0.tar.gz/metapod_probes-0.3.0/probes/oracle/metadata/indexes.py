"""Probe: oracle.metadata.indexes — extract index definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class IndexesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.indexes"

    @staticmethod
    def description() -> str:
        return "Extract index names, types, and column compositions from ALL_INDEXES"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT i.index_name, i.table_name, i.index_type, i.uniqueness, i.status,
                          ic.column_name, ic.column_position
                   FROM all_indexes i
                   JOIN all_ind_columns ic
                     ON i.owner = ic.index_owner AND i.index_name = ic.index_name
                   WHERE i.owner = :schema
                   ORDER BY i.table_name, i.index_name, ic.column_position""",
                schema=schema.upper(),
            )
            return [
                {
                    "index_name": row[0],
                    "table_name": row[1],
                    "index_type": row[2],
                    "uniqueness": row[3],
                    "status": row[4],
                    "column_name": row[5],
                    "column_position": row[6],
                }
                for row in cur.fetchall()
            ]
