"""Probe: oracle.metadata.comments — extract table and column comments."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class CommentsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.comments"

    @staticmethod
    def description() -> str:
        return "Extract business descriptions from ALL_TAB_COMMENTS and ALL_COL_COMMENTS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        with connection.cursor() as cur:
            # Table comments
            cur.execute(
                """SELECT table_name, table_type, comments
                   FROM all_tab_comments
                   WHERE owner = :schema AND comments IS NOT NULL
                   ORDER BY table_name""",
                schema=schema.upper(),
            )
            for row in cur.fetchall():
                results.append({
                    "level": "table",
                    "table_name": row[0],
                    "table_type": row[1],
                    "comment": row[2],
                })

            # Column comments
            cur.execute(
                """SELECT table_name, column_name, comments
                   FROM all_col_comments
                   WHERE owner = :schema AND comments IS NOT NULL
                   ORDER BY table_name, column_name""",
                schema=schema.upper(),
            )
            for row in cur.fetchall():
                results.append({
                    "level": "column",
                    "table_name": row[0],
                    "column_name": row[1],
                    "comment": row[2],
                })

        return results
