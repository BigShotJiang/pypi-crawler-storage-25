"""Probe: oracle.metadata.privileges — extract table-level grants and roles."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class PrivilegesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.privileges"

    @staticmethod
    def description() -> str:
        return "Extract table/column grants and role privileges from ALL_TAB_PRIVS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        with connection.cursor() as cur:
            # Table-level privileges
            cur.execute(
                """SELECT grantee, table_name, privilege, grantable, type
                   FROM all_tab_privs
                   WHERE table_schema = :schema
                   ORDER BY table_name, grantee, privilege""",
                schema=schema.upper(),
            )
            for row in cur.fetchall():
                results.append({
                    "level": "table",
                    "grantee": row[0],
                    "table_name": row[1],
                    "privilege": row[2],
                    "grantable": row[3] == "YES",
                    "object_type": row[4],
                })

        return results
