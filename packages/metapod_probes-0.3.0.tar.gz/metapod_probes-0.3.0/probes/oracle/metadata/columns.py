"""Probe: oracle.metadata.columns — extract column definitions from ALL_TAB_COLUMNS."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column names, types, nullability, and position from ALL_TAB_COLUMNS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT table_name, column_name, data_type, data_length, data_precision,
                          data_scale, nullable, column_id, data_default
                   FROM all_tab_columns
                   WHERE owner = :schema
                   ORDER BY table_name, column_id""",
                schema=schema.upper(),
            )
            return [
                {
                    "table_name": row[0],
                    "column_name": row[1],
                    "data_type": row[2],
                    "data_length": row[3],
                    "data_precision": row[4],
                    "data_scale": row[5],
                    "nullable": row[6] == "Y",
                    "ordinal_position": row[7],
                    "default_value": str(row[8]).strip() if row[8] else None,
                }
                for row in cur.fetchall()
            ]
