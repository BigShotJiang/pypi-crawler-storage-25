"""Probe: oracle.metadata.triggers — extract trigger metadata (not source code)."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TriggersProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.triggers"

    @staticmethod
    def description() -> str:
        return "Extract trigger metadata: type, timing, status, and referenced table from ALL_TRIGGERS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT trigger_name, trigger_type, triggering_event,
                          table_owner, table_name, status, action_type,
                          description
                   FROM all_triggers
                   WHERE owner = :schema
                   ORDER BY table_name, trigger_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "trigger_name": row[0],
                    "trigger_type": row[1],
                    "triggering_event": row[2],
                    "table_owner": row[3],
                    "table_name": row[4],
                    "status": row[5],
                    "action_type": row[6],
                    "description": (row[7] or "").strip(),
                }
                for row in cur.fetchall()
            ]
