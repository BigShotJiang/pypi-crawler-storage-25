"""Probe: oracle.metadata.materialized_views — extract MV definitions and refresh info."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class MaterializedViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.materialized_views"

    @staticmethod
    def description() -> str:
        return "Extract materialized view definitions, refresh type, and query text from ALL_MVIEWS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT mview_name, container_name, query, refresh_mode,
                          refresh_method, build_mode, last_refresh_type,
                          last_refresh_date, staleness
                   FROM all_mviews
                   WHERE owner = :schema
                   ORDER BY mview_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "mview_name": row[0],
                    "container_name": row[1],
                    "query": str(row[2]) if row[2] else "",
                    "refresh_mode": row[3],
                    "refresh_method": row[4],
                    "build_mode": row[5],
                    "last_refresh_type": row[6],
                    "last_refresh_date": str(row[7]) if row[7] else None,
                    "staleness": row[8],
                }
                for row in cur.fetchall()
            ]
