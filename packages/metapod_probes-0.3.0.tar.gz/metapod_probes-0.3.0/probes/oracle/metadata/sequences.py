"""Probe: oracle.metadata.sequences — extract sequence definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SequencesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.sequences"

    @staticmethod
    def description() -> str:
        return "Extract sequence names, increments, and ranges from ALL_SEQUENCES"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT sequence_name, min_value, max_value, increment_by,
                          cycle_flag, order_flag, cache_size, last_number
                   FROM all_sequences
                   WHERE sequence_owner = :schema
                   ORDER BY sequence_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "sequence_name": row[0],
                    "min_value": row[1],
                    "max_value": row[2],
                    "increment_by": row[3],
                    "cycle": row[4] == "Y",
                    "ordered": row[5] == "Y",
                    "cache_size": row[6],
                    "last_number": row[7],
                }
                for row in cur.fetchall()
            ]
