"""Probe: oracle.metadata.constraints — extract PK, FK, unique constraints."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ConstraintsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.constraints"

    @staticmethod
    def description() -> str:
        return "Extract primary keys, foreign keys, and unique constraints with column details"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT c.constraint_name, c.constraint_type, c.table_name, c.status,
                          c.r_constraint_name, cc.column_name, cc.position,
                          rc.table_name AS ref_table
                   FROM all_constraints c
                   JOIN all_cons_columns cc
                     ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name
                   LEFT JOIN all_constraints rc
                     ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
                   WHERE c.owner = :schema
                     AND c.constraint_type IN ('P', 'R', 'U')
                   ORDER BY c.table_name, c.constraint_name, cc.position""",
                schema=schema.upper(),
            )
            return [
                {
                    "constraint_name": row[0],
                    "constraint_type": {"P": "PRIMARY_KEY", "R": "FOREIGN_KEY", "U": "UNIQUE"}.get(row[1], row[1]),
                    "table_name": row[2],
                    "status": row[3],
                    "column_name": row[5],
                    "position": row[6],
                    "ref_table": row[7],
                }
                for row in cur.fetchall()
            ]
