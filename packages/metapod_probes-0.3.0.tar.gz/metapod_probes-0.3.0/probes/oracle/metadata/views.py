"""Probe: oracle.metadata.views — extract view definitions from ALL_VIEWS."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class ViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.views"

    @staticmethod
    def description() -> str:
        return "Extract view names and SQL text from ALL_VIEWS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT view_name, text_length, text
                   FROM all_views
                   WHERE owner = :schema
                   ORDER BY view_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "view_name": row[0],
                    "text_length": row[1],
                    "sql_text": str(row[2]) if row[2] else "",
                }
                for row in cur.fetchall()
            ]
