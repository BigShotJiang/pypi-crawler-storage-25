"""Probe: oracle.metadata.db_links — extract database links from ALL_DB_LINKS."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class DbLinksProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.db_links"

    @staticmethod
    def description() -> str:
        return "Extract database link definitions from ALL_DB_LINKS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT owner, db_link, username, host, created
                   FROM all_db_links
                   WHERE owner = :schema OR owner = 'PUBLIC'
                   ORDER BY db_link""",
                schema=schema.upper(),
            )
            return [
                {
                    "owner": row[0],
                    "db_link": (row[1] or "").rstrip("."),
                    "username": row[2] or "",
                    "host": row[3] or "",
                    "created": str(row[4]) if row[4] else None,
                }
                for row in cur.fetchall()
            ]
