"""Probe: oracle.metadata.synonyms — extract synonym mappings from ALL_SYNONYMS."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SynonymsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.synonyms"

    @staticmethod
    def description() -> str:
        return "Extract private and public synonym mappings from ALL_SYNONYMS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT owner, synonym_name, table_owner, table_name, db_link
                   FROM all_synonyms
                   WHERE owner = :schema OR owner = 'PUBLIC'
                   ORDER BY owner, synonym_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "owner": row[0],
                    "synonym_name": row[1],
                    "table_owner": row[2],
                    "table_name": row[3],
                    "db_link": (row[4] or "").rstrip("."),
                    "is_public": row[0] == "PUBLIC",
                }
                for row in cur.fetchall()
            ]
