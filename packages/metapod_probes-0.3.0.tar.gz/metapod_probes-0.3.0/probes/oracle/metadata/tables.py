"""Probe: oracle.metadata.tables — extract table inventory from ALL_TABLES."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class TablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.metadata.tables"

    @staticmethod
    def description() -> str:
        return "Extract table names, row counts, and tablespace from ALL_TABLES"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT table_name, tablespace_name, num_rows, last_analyzed
                   FROM all_tables
                   WHERE owner = :schema
                   ORDER BY table_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "table_name": row[0],
                    "tablespace": row[1],
                    "num_rows": row[2],
                    "last_analyzed": str(row[3]) if row[3] else None,
                }
                for row in cur.fetchall()
            ]
