"""Probe: oracle.quality.distinct_count — count distinct values per column."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class DistinctCountProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.quality.distinct_count"

    @staticmethod
    def description() -> str:
        return "Count distinct values per column using Oracle statistics (NUM_DISTINCT)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            # Use ALL_TAB_COL_STATISTICS for pre-computed stats (no table scan)
            cur.execute(
                """SELECT table_name, column_name, num_distinct, num_nulls, density, avg_col_len
                   FROM all_tab_col_statistics
                   WHERE owner = :schema
                   ORDER BY table_name, column_name""",
                schema=schema.upper(),
            )
            return [
                {
                    "table_name": row[0],
                    "column_name": row[1],
                    "distinct_count": row[2],
                    "null_count": row[3],
                    "density": row[4],
                    "avg_col_len": row[5],
                }
                for row in cur.fetchall()
            ]
