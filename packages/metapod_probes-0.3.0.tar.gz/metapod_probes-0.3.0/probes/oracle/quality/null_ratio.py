"""Probe: oracle.quality.null_ratio — measure NULL percentage per column.

Uses Oracle pre-computed statistics (ALL_TAB_COL_STATISTICS) when available.
Falls back to sampled COUNT only when stats are missing.
"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class NullRatioProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.quality.null_ratio"

    @staticmethod
    def description() -> str:
        return "Calculate NULL ratio per column using Oracle statistics (zero table scans)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            # Use pre-computed statistics — no table scan, safe, fast
            cur.execute(
                """SELECT c.table_name, c.column_name, c.nullable,
                          s.num_nulls, s.num_distinct, t.num_rows,
                          CASE WHEN t.num_rows > 0
                               THEN ROUND(NVL(s.num_nulls, 0) / t.num_rows, 4)
                               ELSE 0 END AS null_ratio
                   FROM all_tab_columns c
                   LEFT JOIN all_tab_col_statistics s
                     ON c.owner = s.owner AND c.table_name = s.table_name
                        AND c.column_name = s.column_name
                   LEFT JOIN all_tables t
                     ON c.owner = t.owner AND c.table_name = t.table_name
                   WHERE c.owner = :schema
                   ORDER BY null_ratio DESC NULLS LAST, c.table_name, c.column_id""",
                schema=schema.upper(),
            )
            return [
                {
                    "table_name": row[0],
                    "column_name": row[1],
                    "nullable": row[2] == "Y",
                    "null_count": row[3],
                    "distinct_count": row[4],
                    "total_rows": row[5],
                    "null_ratio": float(row[6]) if row[6] is not None else None,
                }
                for row in cur.fetchall()
            ]
