"""Probe: oracle.quality.pattern_check — detect PII patterns via column name heuristics.

Does NOT scan actual data. Uses column names and data types to infer
potential PII columns. Safe for production — zero table scans.
"""

import re

from core.base_probe import BaseProbe
from core.registry import register

# PII patterns matched against COLUMN NAMES (not data values)
NAME_PATTERNS = [
    (r"\bEMAIL\b|E_?MAIL", "email", 0.90),
    (r"\bPHONE\b|MOBILE|CELL|TEL_?NUM", "phone", 0.85),
    (r"\bSSN\b|SOCIAL_?SEC|TAX_?ID|TIN\b", "ssn", 0.95),
    (r"\bIBAN\b|BANK_?ACCOUNT", "iban", 0.90),
    (r"\bCODICE_?FISCALE\b|CF\b", "codice_fiscale", 0.95),
    (r"\bPASSPORT\b|PASS_?NUM", "passport", 0.90),
    (r"\bDRIVER.?LIC|PATENTE", "drivers_license", 0.85),
    (r"\bCREDIT_?CARD|CARD_?NUM|PAN\b", "credit_card", 0.92),
    (r"\bDOB\b|DATE_?OF_?BIRTH|BIRTH_?DATE|DATA_?NASCITA", "date_of_birth", 0.88),
    (r"\bSALARY\b|STIPENDIO|COMPENSATION|WAGE", "salary", 0.80),
    (r"\bADDRESS\b|INDIRIZZO|STREET|VIA\b", "address", 0.75),
    (r"\bNATIONAL_?ID\b|NATIONAL_?INSURANCE", "national_id", 0.90),
    (r"\bFIRST_?NAME\b|LAST_?NAME\b|FULL_?NAME\b|NOME\b|COGNOME\b", "person_name", 0.85),
    (r"\bIP_?ADDRESS\b|IP_?ADDR", "ip_address", 0.80),
    (r"\bGEO_?LOC|LATITUDE|LONGITUDE|GPS", "geolocation", 0.75),
]


@register
class PatternCheckProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.quality.pattern_check"

    @staticmethod
    def description() -> str:
        return "Detect potential PII columns by name pattern matching (no data scan)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        with connection.cursor() as cur:
            cur.execute(
                """SELECT table_name, column_name, data_type, data_length
                   FROM all_tab_columns
                   WHERE owner = :schema
                   ORDER BY table_name, column_id""",
                schema=schema.upper(),
            )
            for table_name, column_name, data_type, data_length in cur.fetchall():
                upper_name = column_name.upper()
                for pattern, pii_type, confidence in NAME_PATTERNS:
                    if re.search(pattern, upper_name):
                        results.append({
                            "table_name": table_name,
                            "column_name": column_name,
                            "data_type": data_type,
                            "data_length": data_length,
                            "pii_type": pii_type,
                            "confidence": confidence,
                            "detection_method": "column_name_pattern",
                        })
                        break  # First match wins

        return results
