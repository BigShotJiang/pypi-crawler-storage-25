"""Probe: oracle.quality.min_max — extract min/max values for numeric and date columns."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class MinMaxProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.quality.min_max"

    @staticmethod
    def description() -> str:
        return "Extract MIN/MAX values for numeric and date columns (from Oracle statistics)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            # Use ALL_TAB_COL_STATISTICS for low/high values (no table scan)
            cur.execute(
                """SELECT c.table_name, c.column_name, c.data_type,
                          s.low_value, s.high_value, s.num_distinct
                   FROM all_tab_columns c
                   LEFT JOIN all_tab_col_statistics s
                     ON c.owner = s.owner AND c.table_name = s.table_name
                        AND c.column_name = s.column_name
                   WHERE c.owner = :schema
                     AND c.data_type IN ('NUMBER', 'FLOAT', 'INTEGER', 'DATE', 'TIMESTAMP(6)')
                     AND s.low_value IS NOT NULL
                   ORDER BY c.table_name, c.column_id""",
                schema=schema.upper(),
            )
            return [
                {
                    "table_name": row[0],
                    "column_name": row[1],
                    "data_type": row[2],
                    "low_value_raw": row[3].hex() if row[3] else None,
                    "high_value_raw": row[4].hex() if row[4] else None,
                    "distinct_count": row[5],
                }
                for row in cur.fetchall()
            ]
