"""Probe: oracle.quality.freshness — detect data staleness via last analysis date."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class FreshnessProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "oracle.quality.freshness"

    @staticmethod
    def description() -> str:
        return "Detect data freshness: last analyzed date, days since last stats, row count"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        with connection.cursor() as cur:
            cur.execute(
                """SELECT table_name, num_rows, last_analyzed,
                          ROUND(SYSDATE - last_analyzed, 1) AS days_stale
                   FROM all_tables
                   WHERE owner = :schema
                   ORDER BY last_analyzed NULLS FIRST""",
                schema=schema.upper(),
            )
            return [
                {
                    "table_name": row[0],
                    "num_rows": row[1],
                    "last_analyzed": str(row[2]) if row[2] else None,
                    "days_stale": float(row[3]) if row[3] is not None else None,
                    "is_stale": row[3] is not None and float(row[3]) > 7,
                }
                for row in cur.fetchall()
            ]
