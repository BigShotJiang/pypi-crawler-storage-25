"""Oracle connection factory for probes."""

from __future__ import annotations

from core.config import SourceConfig


def connect(config: SourceConfig):
    """Create an Oracle database connection from config.

    Raises ConnectionError with a helpful message on failure.
    """
    try:
        import oracledb
    except ImportError:
        raise ConnectionError(
            "oracledb not installed. Run: pip install 'metapod[oracle]'"
        )

    dsn = f"{config.host}:{config.port}"
    if config.service_name:
        dsn += f"/{config.service_name}"
    elif config.sid:
        dsn += f"/{config.sid}"

    try:
        return oracledb.connect(user=config.username, password=config.password, dsn=dsn)
    except Exception as e:
        msg = str(e)
        if "ORA-01017" in msg:
            raise ConnectionError(f"Authentication failed for {config.username}@{dsn}. Check username/password.")
        if "ORA-12541" in msg:
            raise ConnectionError(f"Cannot reach {dsn}. Check host/port and network connectivity.")
        if "ORA-12514" in msg:
            raise ConnectionError(f"Service '{config.service_name or config.sid}' not found on {config.host}:{config.port}.")
        raise ConnectionError(f"Oracle connection failed: {e}")


def source_id(config: SourceConfig) -> str:
    """Build a human-readable source identifier."""
    db = config.service_name or config.sid or "unknown"
    return f"{config.host}:{config.port}/{db}/{config.schema_name}"
