"""Teradata connection — via teradatasql."""
from __future__ import annotations
from core.config import SourceConfig

def connect(config: SourceConfig):
    try:
        import teradatasql
    except ImportError:
        raise ConnectionError("teradatasql not installed. Run: pip install teradatasql")
    try:
        return teradatasql.connect(host=config.host, user=config.username, password=config.password, database=config.service_name or config.schema_name)
    except Exception as e:
        raise ConnectionError(f"Teradata connection failed: {e}")

def source_id(config: SourceConfig) -> str:
    return f"teradata://{config.host}/{config.schema_name}"
