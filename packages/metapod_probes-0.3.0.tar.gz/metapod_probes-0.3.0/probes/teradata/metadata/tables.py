"""Probe: teradata.metadata.tables"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class TeradataTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "teradata.metadata.tables"
    @staticmethod
    def description() -> str: return "List tables from DBC.TablesV"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT TableName, TableKind, CreateTimeStamp, CommentString FROM DBC.TablesV WHERE DatabaseName = ? ORDER BY TableName", (schema,))
        return [{"table_name": r[0].strip(), "kind": r[1], "created": str(r[2]) if r[2] else None, "comment": (r[3] or "").strip()} for r in cur.fetchall()]
