"""Probe: teradata.metadata.columns"""
from core.base_probe import BaseProbe
from core.registry import register

@register
class TeradataColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "teradata.metadata.columns"
    @staticmethod
    def description() -> str: return "Extract column definitions from DBC.ColumnsV"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        cur.execute("SELECT TableName, ColumnName, ColumnType, ColumnLength, Nullable, ColumnId, DefaultValue, CommentString FROM DBC.ColumnsV WHERE DatabaseName = ? ORDER BY TableName, ColumnId", (schema,))
        return [{"table_name": r[0].strip(), "column_name": r[1].strip(), "data_type": r[2], "length": r[3], "nullable": r[4] == "Y", "position": r[5], "default": r[6], "comment": (r[7] or "").strip()} for r in cur.fetchall()]
