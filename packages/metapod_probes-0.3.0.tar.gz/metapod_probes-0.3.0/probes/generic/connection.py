"""Generic connection — returns the output directory as a Path for offline probes."""

from pathlib import Path

from core.config import SourceConfig


def get_path(config: SourceConfig) -> Path:
    return Path(config.host or "./output")


def source_id(config: SourceConfig) -> str:
    return f"local://{config.host or './output'}"
