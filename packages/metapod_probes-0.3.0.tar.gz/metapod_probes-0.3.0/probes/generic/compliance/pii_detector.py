"""Probe: generic.compliance.pii_detector — pattern-based PII column detection.

Scans column names and types across any probe output to flag likely PII columns.
Works offline — analyzes existing JSON output without a database connection.

Usage:
    metapod run "generic.compliance.pii_detector" --output ./output
"""

import json
import re
from pathlib import Path

from core.base_probe import BaseProbe
from core.registry import register

# PII detection patterns: (pattern_regex, classification, confidence)
_PII_PATTERNS = [
    # Direct identifiers
    (r"(?i)\b(ssn|social_security|fiscal_code|codice_fiscale|tax_id|national_id)\b", "NATIONAL_ID", 0.95),
    (r"(?i)\b(passport|passport_no|passport_number)\b", "PASSPORT", 0.95),
    (r"(?i)\b(driver_license|driving_license|license_no)\b", "DRIVER_LICENSE", 0.90),
    # Names
    (r"(?i)\b(first_name|last_name|full_name|surname|given_name|family_name|nome|cognome)\b", "PERSON_NAME", 0.85),
    (r"(?i)\b(customer_name|employee_name|patient_name|user_name|username)\b", "PERSON_NAME", 0.80),
    # Contact
    (r"(?i)\b(email|email_address|e_mail|mail|pec)\b", "EMAIL", 0.90),
    (r"(?i)\b(phone|telephone|mobile|cell_phone|phone_number|tel)\b", "PHONE", 0.85),
    # Address
    (r"(?i)\b(address|street|city|zip_code|postal_code|state|province|country|indirizzo|cap)\b", "ADDRESS", 0.75),
    (r"(?i)\b(latitude|longitude|lat|lng|geo_location)\b", "GEOLOCATION", 0.70),
    # Financial
    (r"(?i)\b(credit_card|card_number|card_no|iban|bank_account|account_number|conto)\b", "FINANCIAL", 0.90),
    (r"(?i)\b(salary|wage|compensation|income|revenue_personal|stipendio)\b", "FINANCIAL", 0.80),
    # Health
    (r"(?i)\b(diagnosis|medical_record|patient_id|health_id|blood_type|allergies)\b", "HEALTH", 0.90),
    (r"(?i)\b(date_of_birth|dob|birth_date|data_nascita|age)\b", "DATE_OF_BIRTH", 0.85),
    # Authentication
    (r"(?i)\b(password|passwd|pwd|secret|token|api_key|access_key|private_key)\b", "CREDENTIAL", 0.95),
    (r"(?i)\b(ip_address|ip_addr|mac_address|device_id|imei)\b", "DEVICE_ID", 0.80),
]


@register
class PiiDetectorProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "generic.compliance.pii_detector"

    @staticmethod
    def description() -> str:
        return "Pattern-based PII detection on column names from any probe output (no DB needed)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        # Scan existing output directory for column records
        output_dir = connection if isinstance(connection, Path) else Path(schema or "./output")
        results = []
        seen: set[str] = set()

        for jf in output_dir.rglob("*.json"):
            try:
                data = json.loads(jf.read_text())
            except (json.JSONDecodeError, OSError):
                continue

            records = data.get("records", [])
            source = data.get("source", {}).get("type", "")

            for record in records:
                col_name = record.get("column_name", "")
                table_name = record.get("table_name", "")
                if not col_name:
                    continue

                key = f"{table_name}.{col_name}"
                if key in seen:
                    continue

                for pattern, classification, confidence in _PII_PATTERNS:
                    if re.search(pattern, col_name):
                        seen.add(key)
                        results.append({
                            "table_name": table_name,
                            "column_name": col_name,
                            "data_type": record.get("data_type", ""),
                            "pii_classification": classification,
                            "confidence": confidence,
                            "source_type": source,
                            "pattern_matched": pattern,
                        })
                        break

        return results
