"""Azure File Share connection — via azure-storage-file-share."""

from __future__ import annotations

from core.config import SourceConfig


def get_client(config: SourceConfig):
    account_name = config.host
    if not account_name:
        raise ConnectionError("host = storage account name required")

    account_url = f"https://{account_name}.file.core.windows.net"

    try:
        from azure.storage.fileshare import ShareServiceClient
    except ImportError:
        raise ConnectionError("azure-storage-file-share not installed. Run: pip install azure-storage-file-share")

    if config.token:
        return ShareServiceClient(account_url=account_url, credential=config.token)
    else:
        raise ConnectionError("token (account key or SAS) required for Azure File Share")


def source_id(config: SourceConfig) -> str:
    return f"fileshare://{config.host}/{config.schema_name}"
