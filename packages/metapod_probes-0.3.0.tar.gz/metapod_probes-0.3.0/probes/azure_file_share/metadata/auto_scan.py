"""Probe: azure_file_share.metadata.auto_scan — recursive file share scan with schema sampling."""

import csv
import io
import json
import re
from collections import defaultdict

from core.base_probe import BaseProbe
from core.registry import register

FORMAT_MAP = {"csv": "CSV", "tsv": "TSV", "json": "JSON", "jsonl": "JSONL",
              "parquet": "PARQUET", "xlsx": "EXCEL", "xml": "XML"}


@register
class FileShareAutoScanProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "azure_file_share.metadata.auto_scan"
    @staticmethod
    def description() -> str:
        return "Recursive file share scan: format detection, CSV/JSON schema sampling"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        share = schema
        if not share: return []

        sc = connection.get_share_client(share)
        datasets: dict[str, dict] = defaultdict(lambda: {"files": 0, "fmt": "", "samples": []})
        self._walk(sc.get_directory_client(""), "", datasets)

        results = [
            {"type": "dataset", "name": n, "format": d["fmt"], "file_count": d["files"], "sample_paths": d["samples"]}
            for n, d in sorted(datasets.items())
        ]

        # Schema sampling for CSV
        for n, d in sorted(datasets.items(), key=lambda x: -x[1]["files"]):
            if d["fmt"] == "CSV" and d["samples"]:
                try:
                    fc = sc.get_directory_client("").get_file_client(d["samples"][0])
                    raw = fc.download_file(length=51200).readall().decode("utf-8", errors="replace")
                    rows = list(csv.reader(io.StringIO(raw)))
                    if len(rows) >= 2:
                        results.append({"type": "schema", "dataset": n, "format": "CSV",
                                        "columns": [{"name": h.strip()} for h in rows[0]], "column_count": len(rows[0])})
                except Exception: pass
            if len([r for r in results if r["type"] == "schema"]) >= 10: break

        return results

    def _walk(self, dc, prefix: str, datasets: dict, depth: int = 0):
        if depth > 8: return
        try:
            for item in dc.list_directories_and_files():
                path = f"{prefix}/{item['name']}" if prefix else item["name"]
                if item.get("is_directory") or not item.get("size"):
                    self._walk(dc.get_subdirectory_client(item["name"]), path, datasets, depth + 1)
                else:
                    ext = item["name"].rsplit(".", 1)[-1].lower() if "." in item["name"] else ""
                    fmt = FORMAT_MAP.get(ext)
                    if not fmt: continue
                    folder = path.rsplit("/", 1)[0] if "/" in path else ""
                    d = datasets[folder]
                    d["files"] += 1; d["fmt"] = fmt
                    if len(d["samples"]) < 3: d["samples"].append(path)
        except Exception: pass
