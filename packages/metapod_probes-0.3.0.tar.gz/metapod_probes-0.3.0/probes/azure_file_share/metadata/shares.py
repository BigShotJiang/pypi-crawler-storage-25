"""Probe: azure_file_share.metadata.shares — list all file shares."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class FileSharesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_file_share.metadata.shares"

    @staticmethod
    def description() -> str:
        return "List all file shares in the storage account"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        return [
            {
                "name": s.name,
                "quota_gb": getattr(s, "quota", None),
                "last_modified": str(s.last_modified) if getattr(s, "last_modified", None) else None,
            }
            for s in connection.list_shares()
        ]
