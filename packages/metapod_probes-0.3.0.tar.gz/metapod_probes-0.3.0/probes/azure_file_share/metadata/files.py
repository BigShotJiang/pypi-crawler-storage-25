"""Probe: azure_file_share.metadata.files — list files in a share."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class FileShareFilesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "azure_file_share.metadata.files"

    @staticmethod
    def description() -> str:
        return "List files and directories in an Azure File Share"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        share_name = schema or kwargs.get("share", "")
        if not share_name:
            return []

        share_client = connection.get_share_client(share_name)
        results = []
        self._walk(share_client.get_directory_client(""), "", results)
        return results

    def _walk(self, dir_client, prefix: str, results: list, depth: int = 0):
        if depth > 10:
            return
        try:
            for item in dir_client.list_directories_and_files():
                path = f"{prefix}/{item['name']}" if prefix else item['name']
                if item.get("is_directory", False) or not item.get("size"):
                    results.append({"path": path, "is_directory": True, "size_bytes": 0})
                    sub = dir_client.get_subdirectory_client(item["name"])
                    self._walk(sub, path, results, depth + 1)
                else:
                    ext = item["name"].rsplit(".", 1)[-1].lower() if "." in item["name"] else ""
                    results.append({
                        "path": path, "is_directory": False,
                        "size_bytes": item.get("size", 0), "extension": ext,
                    })
        except Exception:
            pass
