"""Probe: snowflake.metadata.views — extract view definitions."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SnowflakeViewsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "snowflake.metadata.views"

    @staticmethod
    def description() -> str:
        return "Extract view SQL definitions from INFORMATION_SCHEMA.VIEWS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        try:
            cur.execute("""
                SELECT table_name, view_definition, is_secure, created, comment
                FROM information_schema.views
                WHERE table_schema = %s
                ORDER BY table_name
            """, (schema.upper(),))
            return [{
                "view_name": r[0], "sql_text": r[1] or "",
                "is_secure": r[2] == "YES",
                "created": str(r[3]) if r[3] else None,
                "comment": r[4] or "",
            } for r in cur.fetchall()]
        finally:
            cur.close()
