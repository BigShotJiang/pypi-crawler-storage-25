"""Probe: snowflake.metadata.tables"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SnowflakeTablesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "snowflake.metadata.tables"

    @staticmethod
    def description() -> str:
        return "List tables with row count, size, and clustering info from INFORMATION_SCHEMA"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        try:
            cur.execute("""
                SELECT table_name, table_type, row_count, bytes,
                       clustering_key, created, last_altered, comment
                FROM information_schema.tables
                WHERE table_schema = %s AND table_type IN ('BASE TABLE', 'VIEW')
                ORDER BY table_name
            """, (schema.upper(),))
            return [{
                "table_name": r[0], "table_type": r[1], "row_count": r[2],
                "size_bytes": r[3], "clustering_key": r[4] or "",
                "created": str(r[5]) if r[5] else None,
                "last_altered": str(r[6]) if r[6] else None,
                "comment": r[7] or "",
            } for r in cur.fetchall()]
        finally:
            cur.close()
