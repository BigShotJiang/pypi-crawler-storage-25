"""Probe: snowflake.metadata.access_history — extract query-based lineage from ACCOUNT_USAGE."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SnowflakeAccessHistoryProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "snowflake.metadata.access_history"

    @staticmethod
    def description() -> str:
        return "Extract table-level lineage from ACCOUNT_USAGE.ACCESS_HISTORY (last 7 days)"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        try:
            cur.execute("""
                SELECT query_id, query_start_time, user_name,
                       direct_objects_accessed, base_objects_accessed, objects_modified
                FROM snowflake.account_usage.access_history
                WHERE query_start_time > DATEADD('day', -7, CURRENT_TIMESTAMP())
                  AND array_size(objects_modified) > 0
                ORDER BY query_start_time DESC
                LIMIT 1000
            """)
            results = []
            for r in cur.fetchall():
                sources = r[4] or []  # base_objects_accessed
                targets = r[5] or []  # objects_modified
                if not isinstance(sources, list):
                    continue
                for target in targets if isinstance(targets, list) else []:
                    tgt_name = target.get("objectName", "") if isinstance(target, dict) else str(target)
                    for source in sources if isinstance(sources, list) else []:
                        src_name = source.get("objectName", "") if isinstance(source, dict) else str(source)
                        if src_name and tgt_name and src_name != tgt_name:
                            results.append({
                                "query_id": r[0],
                                "timestamp": str(r[1]),
                                "user": r[2],
                                "source_table": src_name,
                                "target_table": tgt_name,
                            })
            return results
        except Exception as e:
            return [{"error": str(e), "hint": "Requires IMPORTED PRIVILEGES on SNOWFLAKE database"}]
        finally:
            cur.close()
