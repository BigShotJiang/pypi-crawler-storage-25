"""Probe: snowflake.metadata.columns"""

from core.base_probe import BaseProbe
from core.registry import register


@register
class SnowflakeColumnsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "snowflake.metadata.columns"

    @staticmethod
    def description() -> str:
        return "Extract column definitions from INFORMATION_SCHEMA.COLUMNS"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        cur = connection.cursor()
        try:
            cur.execute("""
                SELECT table_name, column_name, data_type, character_maximum_length,
                       numeric_precision, numeric_scale, is_nullable, ordinal_position,
                       column_default, comment
                FROM information_schema.columns
                WHERE table_schema = %s
                ORDER BY table_name, ordinal_position
            """, (schema.upper(),))
            return [{
                "table_name": r[0], "column_name": r[1], "data_type": r[2],
                "max_length": r[3], "precision": r[4], "scale": r[5],
                "nullable": r[6] == "YES", "ordinal_position": r[7],
                "default_value": r[8], "comment": r[9] or "",
            } for r in cur.fetchall()]
        finally:
            cur.close()
