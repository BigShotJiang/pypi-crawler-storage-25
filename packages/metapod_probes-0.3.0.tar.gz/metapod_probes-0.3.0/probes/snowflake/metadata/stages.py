"""Probe: snowflake.metadata.stages — list Snowflake stages and file formats."""

import re

from core.base_probe import BaseProbe
from core.registry import register

_SAFE_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")


@register
class SnowflakeStagesProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "snowflake.metadata.stages"

    @staticmethod
    def description() -> str:
        return "List Snowflake stages (internal/external) and file formats"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        if not _SAFE_IDENTIFIER.match(schema):
            return []
        cur = connection.cursor()
        safe_schema = schema.upper()
        results = []
        try:
            cur.execute(f"SHOW STAGES IN SCHEMA {safe_schema}")
            for r in cur.fetchall():
                results.append({
                    "name": r[1], "database": r[2], "schema": r[3],
                    "url": r[4] or "", "type": r[6] or "",
                    "owner": r[7] or "", "comment": r[8] or "",
                })
        except Exception:
            pass
        try:
            cur.execute(f"SHOW FILE FORMATS IN SCHEMA {safe_schema}")
            for r in cur.fetchall():
                results.append({
                    "name": r[1], "database": r[2], "schema": r[3],
                    "type": "FILE_FORMAT", "format_type": r[4] or "",
                    "owner": r[5] or "", "comment": r[6] or "",
                })
        except Exception:
            pass
        cur.close()
        return results
