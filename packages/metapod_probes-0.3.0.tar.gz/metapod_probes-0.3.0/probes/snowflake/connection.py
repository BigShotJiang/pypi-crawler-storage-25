"""Snowflake connection factory."""

from __future__ import annotations

from core.config import SourceConfig


def connect(config: SourceConfig):
    try:
        import snowflake.connector
    except ImportError:
        raise ConnectionError("snowflake-connector-python not installed. Run: pip install snowflake-connector-python")

    try:
        return snowflake.connector.connect(
            account=config.host,
            user=config.username,
            password=config.password,
            database=config.service_name or None,
            schema=config.schema_name or None,
            warehouse=config.catalog or None,
            role=config.sid or None,
        )
    except Exception as e:
        raise ConnectionError(f"Snowflake connection failed: {e}")


def source_id(config: SourceConfig) -> str:
    return f"snowflake://{config.host}/{config.service_name}/{config.schema_name}"
