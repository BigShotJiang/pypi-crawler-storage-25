"""Collibra Data Governance — REST API v2.

Bidirectional: read assets/lineage FROM Collibra, push metadata TO Collibra.

Config:
  host = Collibra instance URL (e.g., "https://myorg.collibra.com")
  username = API user
  password = API password or token
  schema_name = community/domain filter (optional)
"""

from __future__ import annotations

import httpx

from core.config import SourceConfig


def get_client(config: SourceConfig) -> httpx.Client:
    base = config.host.rstrip("/") if config.host else ""
    if not base:
        raise ConnectionError("host = Collibra instance URL required")

    return httpx.Client(
        base_url=f"{base}/rest/2.0",
        auth=(config.username, config.password),
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )


def source_id(config: SourceConfig) -> str:
    return f"collibra://{config.host}"
