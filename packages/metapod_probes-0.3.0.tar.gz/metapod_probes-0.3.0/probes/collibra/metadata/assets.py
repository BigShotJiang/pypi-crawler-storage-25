"""Probe: collibra.metadata.assets — extract assets (tables, columns, terms) from Collibra."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class CollibraAssets(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "collibra.metadata.assets"
    @staticmethod
    def description() -> str: return "Extract Collibra assets with type, domain, status, and attributes"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        params: dict = {"limit": 500}
        if schema:
            params["domainId"] = schema
        resp = connection.get("/assets", params=params)
        resp.raise_for_status()
        return [{
            "id": a["id"], "name": a["name"],
            "type": a.get("type", {}).get("name", ""),
            "domain": a.get("domain", {}).get("name", ""),
            "status": a.get("status", {}).get("name", ""),
            "description": a.get("description", ""),
        } for a in resp.json().get("results", [])]
