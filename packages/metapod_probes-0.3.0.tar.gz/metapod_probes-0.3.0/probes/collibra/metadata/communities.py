"""Probe: collibra.metadata.communities — list Collibra communities and domains."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class CollibraCommunities(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "collibra.metadata.communities"
    @staticmethod
    def description() -> str: return "List Collibra communities and domains with asset counts"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []
        resp = connection.get("/communities", params={"limit": 200})
        resp.raise_for_status()
        for c in resp.json().get("results", []):
            results.append({
                "id": c["id"], "name": c["name"], "type": "community",
                "description": c.get("description", ""),
            })
            # Get domains in this community
            dr = connection.get("/domains", params={"communityId": c["id"], "limit": 200})
            if dr.status_code == 200:
                for d in dr.json().get("results", []):
                    results.append({
                        "id": d["id"], "name": d["name"], "type": "domain",
                        "community": c["name"], "domain_type": d.get("type", {}).get("name", ""),
                    })
        return results
