"""Probe: collibra.metadata.relations — extract Collibra asset relations (lineage, containment)."""
from core.base_probe import BaseProbe
from core.registry import register

@register
class CollibraRelations(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "collibra.metadata.relations"
    @staticmethod
    def description() -> str: return "Extract Collibra asset relations: lineage, containment, ownership"
    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        resp = connection.get("/relations", params={"limit": 500})
        resp.raise_for_status()
        return [{
            "id": r["id"],
            "source_id": r.get("source", {}).get("id", ""),
            "source_name": r.get("source", {}).get("name", ""),
            "target_id": r.get("target", {}).get("id", ""),
            "target_name": r.get("target", {}).get("name", ""),
            "relation_type": r.get("type", {}).get("role", ""),
        } for r in resp.json().get("results", [])]
