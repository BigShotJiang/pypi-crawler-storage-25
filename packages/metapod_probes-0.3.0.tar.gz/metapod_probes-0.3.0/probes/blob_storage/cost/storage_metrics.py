"""Probe: blob_storage.cost.storage_metrics — container sizes and blob counts for FinOps."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BlobStorageMetricsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "blob_storage.cost.storage_metrics"

    @staticmethod
    def description() -> str:
        return "Per-container storage metrics: blob count, total size, access tier distribution"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        results = []

        for container in connection.list_containers():
            name = container.name
            total_size = 0
            blob_count = 0
            tiers: dict[str, int] = {}

            container_client = connection.get_container_client(name)
            for blob in container_client.list_blobs():
                blob_count += 1
                total_size += blob.size or 0
                tier = getattr(blob, "blob_tier", "Unknown") or "Unknown"
                tiers[tier] = tiers.get(tier, 0) + 1

            results.append({
                "container": name,
                "blob_count": blob_count,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2),
                "access_tiers": tiers,
                "last_modified": str(container.last_modified) if hasattr(container, "last_modified") and container.last_modified else None,
            })

        return results
