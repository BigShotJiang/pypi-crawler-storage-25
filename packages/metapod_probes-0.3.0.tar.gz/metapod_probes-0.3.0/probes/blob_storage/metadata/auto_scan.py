"""Probe: blob_storage.metadata.auto_scan — recursive blob scan with schema sampling."""

import csv
import io
import json
import re
from collections import defaultdict

from core.base_probe import BaseProbe
from core.registry import register

FORMAT_MAP = {"parquet": "PARQUET", "pq": "PARQUET", "csv": "CSV", "tsv": "TSV",
              "json": "JSON", "jsonl": "JSONL", "avro": "AVRO", "orc": "ORC"}
PARTITION_RE = [
    (r"(\d{4})-(\d{2})-(\d{2})", "yyyy-mm-dd"), (r"(\d{4})-(\d{2})", "yyyy-mm"),
    (r"year=(\d{4})", "hive_year"), (r"date=(\d{4}-\d{2}-\d{2})", "hive_date"),
    (r"(\w+)=(\w+)", "hive_generic"),
]


@register
class BlobAutoScanProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str: return "blob_storage.metadata.auto_scan"
    @staticmethod
    def description() -> str:
        return "Recursive blob scan: format detection, partition clustering, CSV/JSON schema sampling"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        container = schema
        if not container: return []

        cc = connection.get_container_client(container)
        datasets: dict[str, dict] = defaultdict(lambda: {
            "files": 0, "bytes": 0, "fmt": "", "parts": set(), "ptype": "", "samples": [],
        })

        for blob in cc.list_blobs(results_per_page=10000):
            ext = blob.name.rsplit(".", 1)[-1].lower() if "." in blob.name else ""
            fmt = FORMAT_MAP.get(ext)
            if not fmt: continue
            ds = _ds(blob.name)
            d = datasets[ds]
            d["files"] += 1; d["bytes"] += blob.size or 0; d["fmt"] = fmt
            if len(d["samples"]) < 3: d["samples"].append(blob.name)
            for pat, pt in PARTITION_RE:
                m = re.search(pat, blob.name)
                if m: d["parts"].add(m.group(0)); d["ptype"] = d["ptype"] or pt

        results = [
            {"type": "dataset", "name": n, "format": d["fmt"], "file_count": d["files"],
             "total_bytes": d["bytes"], "partition_type": d["ptype"], "partition_count": len(d["parts"]),
             "sample_paths": d["samples"]}
            for n, d in sorted(datasets.items())
        ]

        # Schema sampling
        for n, d in sorted(datasets.items(), key=lambda x: -x[1]["files"]):
            if d["fmt"] in ("CSV", "TSV") and d["samples"]:
                try:
                    bc = cc.get_blob_client(d["samples"][0])
                    raw = bc.download_blob(length=51200).readall().decode("utf-8", errors="replace")
                    rows = list(csv.reader(io.StringIO(raw)))
                    if len(rows) >= 2:
                        results.append({"type": "schema", "dataset": n, "format": "CSV",
                                        "columns": [{"name": h.strip()} for h in rows[0]], "column_count": len(rows[0])})
                except Exception: pass
            elif d["fmt"] in ("JSON", "JSONL") and d["samples"]:
                try:
                    bc = cc.get_blob_client(d["samples"][0])
                    raw = bc.download_blob(length=51200).readall().decode("utf-8", errors="replace")
                    obj = json.loads(raw.split("\n")[0])
                    if isinstance(obj, dict):
                        results.append({"type": "schema", "dataset": n, "format": "JSON",
                                        "columns": [{"name": k} for k in obj.keys()], "column_count": len(obj)})
                except Exception: pass
            if len([r for r in results if r["type"] == "schema"]) >= 20: break

        return results


def _ds(path: str) -> str:
    parts = path.split("/")
    if "." in parts[-1]: parts = parts[:-1]
    return "/".join(p for p in parts if "=" not in p and not re.match(r"^\d{4}(-\d{2}){0,2}$", p)) or path.rsplit("/", 1)[0]
