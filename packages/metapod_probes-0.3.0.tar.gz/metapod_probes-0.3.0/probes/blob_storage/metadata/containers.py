"""Probe: blob_storage.metadata.containers — list all blob containers."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BlobContainersProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "blob_storage.metadata.containers"

    @staticmethod
    def description() -> str:
        return "List all blob containers in the storage account"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        return [
            {
                "name": c.name,
                "last_modified": str(c.last_modified) if c.last_modified else None,
                "lease_status": c.lease.get("status", "") if c.lease else "",
                "public_access": c.public_access or "private",
            }
            for c in connection.list_containers()
        ]
