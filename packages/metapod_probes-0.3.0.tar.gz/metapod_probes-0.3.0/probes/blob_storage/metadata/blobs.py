"""Probe: blob_storage.metadata.blobs — list blobs in a container with format detection."""

from core.base_probe import BaseProbe
from core.registry import register


@register
class BlobsProbe(BaseProbe):
    @staticmethod
    def probe_name() -> str:
        return "blob_storage.metadata.blobs"

    @staticmethod
    def description() -> str:
        return "List blobs in a container with size, content type, and data format"

    def execute(self, connection, schema: str, **kwargs) -> list[dict]:
        container = schema or kwargs.get("container", "")
        if not container:
            return []

        container_client = connection.get_container_client(container)
        results = []
        for blob in container_client.list_blobs(results_per_page=5000):
            ext = blob.name.rsplit(".", 1)[-1].lower() if "." in blob.name else ""
            results.append({
                "name": blob.name,
                "size_bytes": blob.size,
                "content_type": blob.content_settings.content_type if blob.content_settings else "",
                "last_modified": str(blob.last_modified) if blob.last_modified else None,
                "blob_type": blob.blob_type,
                "format": _infer_format(ext),
                "tier": blob.blob_tier or "",
            })
        return results


def _infer_format(ext: str) -> str:
    return {
        "parquet": "PARQUET", "pq": "PARQUET", "csv": "CSV", "tsv": "CSV",
        "json": "JSON", "jsonl": "JSON", "avro": "AVRO", "orc": "ORC",
        "xlsx": "EXCEL", "xls": "EXCEL", "sql": "SQL", "xml": "XML", "delta": "DELTA",
    }.get(ext, "UNKNOWN" if ext else "DIRECTORY")
