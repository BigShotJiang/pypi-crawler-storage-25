"""Azure Blob Storage connection — via azure-storage-blob."""

from __future__ import annotations

from core.config import SourceConfig


def get_client(config: SourceConfig):
    account_name = config.host
    if not account_name:
        raise ConnectionError("host = storage account name required")

    account_url = f"https://{account_name}.blob.core.windows.net"

    try:
        from azure.storage.blob import BlobServiceClient
    except ImportError:
        raise ConnectionError("azure-storage-blob not installed. Run: pip install azure-storage-blob azure-identity")

    if config.token:
        return BlobServiceClient(account_url=account_url, credential=config.token)
    else:
        try:
            from azure.identity import ClientSecretCredential, DefaultAzureCredential

            if config.username and config.password and config.service_name:
                credential = ClientSecretCredential(config.service_name, config.username, config.password)
            else:
                credential = DefaultAzureCredential()
            return BlobServiceClient(account_url=account_url, credential=credential)
        except ImportError:
            raise ConnectionError("azure-identity not installed.")


def source_id(config: SourceConfig) -> str:
    return f"blob://{config.host}/{config.schema_name}"
