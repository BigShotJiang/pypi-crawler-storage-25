"""metapod CLI — run metadata and quality probes."""

from __future__ import annotations

import logging
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

app = typer.Typer(name="metapod", help="Lightweight metadata and quality probes for enterprise metadata management")
console = Console()


@app.command()
def run(
    pattern: str = typer.Argument("oracle.metadata.*", help="Probe pattern (e.g., oracle.metadata.tables, oracle.quality.*)"),
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config file path"),
    schema: str = typer.Option("", "--schema", "-s", help="Override schema from config"),
    output: str = typer.Option("./output", "--output", "-o", help="Output directory"),
    since: str = typer.Option("", "--since", help="Incremental: only objects modified after this ISO timestamp"),
    delta: bool = typer.Option(False, "--delta", "-d", help="Delta mode: only emit new/modified/deleted records"),
    force: bool = typer.Option(False, "--force", help="Force full extraction (ignore delta state)"),
):
    """Run probes matching the given pattern."""
    from core.config import load_config
    from core.registry import discover_probes, get_probes

    # Discover all probes
    discover_probes()

    # Load config
    try:
        cfg = load_config(config)
    except FileNotFoundError:
        console.print(f"[yellow]Config not found: {config}. Using defaults.[/yellow]")
        from core.config import ProbeConfig, SourceConfig
        cfg = ProbeConfig(source=SourceConfig(type="oracle"))

    target_schema = schema or cfg.source.schema_name

    # Find matching probes
    probes = get_probes(pattern)
    if not probes:
        from core.registry import list_probes
        all_probes = list_probes("*")
        console.print(f"[red]No probes matching '{pattern}'[/red]")
        if all_probes:
            console.print(f"Available: {', '.join(all_probes)}")
        raise typer.Exit(1)

    console.print(f"[bold]Running {len(probes)} probes[/bold] matching '{pattern}'")
    console.print(f"Schema: {target_schema or '(not set)'}, Output: {output}\n")

    # Connect using the connection registry
    conn = None
    sid = target_schema or "local"
    try:
        from core.connections import get_connection
        conn, sid = get_connection(cfg.source)
    except ConnectionError as e:
        console.print(f"[red]Connection failed: {e}[/red]")
        raise typer.Exit(1)
    _conn_to_close = conn  # track for cleanup

    output_dir = Path(output)

    # Delta engine setup
    delta_engine = None
    if delta:
        from core.delta import DeltaEngine
        delta_engine = DeltaEngine(state_dir=output_dir / ".delta")
        console.print("[bold yellow]Delta mode enabled[/bold yellow] — only changed records will be emitted\n")

    results_table = Table(title="Probe Results")
    results_table.add_column("Probe", style="cyan")
    results_table.add_column("Records", justify="right")
    results_table.add_column("Duration", justify="right")
    results_table.add_column("Status")
    if delta:
        results_table.add_column("New", justify="right", style="green")
        results_table.add_column("Mod", justify="right", style="yellow")
        results_table.add_column("Del", justify="right", style="red")
        results_table.add_column("Skip", justify="right", style="dim")

    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn

    total_delta_new = 0
    total_delta_mod = 0
    total_delta_del = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Running probes", total=len(probes))

        for probe_cls in probes:
            probe = probe_cls()
            progress.update(task, description=f"[cyan]{probe.probe_name()}")

            if conn is not None:
                if delta_engine:
                    result, stats = delta_engine.run(
                        probe, conn, target_schema, source_id=sid, force=force,
                    )
                    total_delta_new += stats.new
                    total_delta_mod += stats.modified
                    total_delta_del += stats.deleted
                else:
                    result = probe.run(conn, target_schema, source_id=sid, since=since or None)
            else:
                from core.base_probe import ProbeResult
                result = ProbeResult(
                    probe=probe.probe_name(), source_type=cfg.source.type if cfg else "unknown",
                    source_id=sid, error="No database connection (dry run)",
                )

            out_path = probe.write(result, output_dir)

            status = "[green]OK[/green]" if not result.error else f"[red]{result.error[:40]}[/red]"
            row = [probe.probe_name(), str(result.record_count), f"{result.duration_ms}ms", status]
            if delta and delta_engine:
                row += [str(stats.new), str(stats.modified), str(stats.deleted), str(stats.unchanged)]
            results_table.add_row(*row)
            progress.advance(task)

    console.print()
    console.print(results_table)

    if delta:
        console.print(
            f"\n[bold]Delta summary:[/bold] "
            f"[green]+{total_delta_new} new[/green], "
            f"[yellow]~{total_delta_mod} modified[/yellow], "
            f"[red]-{total_delta_del} deleted[/red]"
        )

    from core.connections import close_connection
    close_connection(_conn_to_close)

    console.print(f"\n[dim]Results saved to {output_dir.resolve()}[/dim]")
    console.print(f"[dim]To push: metapod push --output {output}[/dim]")


@app.command()
def push(
    target_url: str = typer.Option("", "--target", "-t", help="target API URL (overrides config)"),
    project: str = typer.Option("", "--project", "-P", help="Target project/tenant ID (overrides config)"),
    api_key: str = typer.Option("", "--api-key", "-k", help="API key (overrides config)"),
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config file path"),
    output: str = typer.Option("./output", "--output", "-o", help="Output directory with probe results"),
    scan: bool = typer.Option(True, "--scan/--no-scan", help="Trigger lineage scan after ingestion"),
):
    """Push previously extracted probe results to a the target platform project.

    Two-step workflow:
      1. metapod run "oracle.*" --schema RISK_MGMT                    (extract)
      2. metapod push --target https://your-platform.example.com --project centrico  (send)

    Target and project can be set via:
      - CLI flags: --target, --project, --api-key
      - Config file: target.url, target.project, target.api_key
      - Environment: METAPOD_TARGET_URL, METAPOD_PROJECT, METAPOD_API_KEY
    """
    import os

    from core.config import TargetConfig

    output_dir = Path(output)
    if not output_dir.exists():
        console.print(f"[red]Output directory not found: {output_dir}[/red]")
        console.print("Run probes first: metapod run 'oracle.*'")
        raise typer.Exit(1)

    json_files = list(output_dir.rglob("*.json"))
    if not json_files:
        console.print(f"[red]No probe results found in {output_dir}[/red]")
        raise typer.Exit(1)

    # Build target config: CLI flags > env vars > config file
    try:
        from core.config import load_config
        cfg = load_config(config)
        cfg_target = cfg.target
    except FileNotFoundError:
        cfg_target = TargetConfig()

    resolved_target = TargetConfig(
        url=target_url or os.environ.get("METAPOD_TARGET_URL", "") or cfg_target.url,
        project=project or os.environ.get("METAPOD_PROJECT", "") or cfg_target.project,
        api_key=api_key or os.environ.get("METAPOD_API_KEY", "") or cfg_target.api_key,
    )

    if not resolved_target.url:
        console.print("[red]No target URL. Use --target or set target.url in config.yaml[/red]")
        raise typer.Exit(1)

    if not resolved_target.project:
        console.print("[red]No project ID. Use --project or set target.project in config.yaml[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]Pushing {len(json_files)} probe results[/bold]")
    console.print(f"  Target:  {resolved_target.url}")
    console.print(f"  Project: [cyan]{resolved_target.project}[/cyan]")
    console.print(f"  Scan:    {scan}\n")

    from core.transport import push_probes
    result = push_probes(output_dir, resolved_target, scan=scan)

    if result.get("status") == "pushed":
        console.print(f"[green]Ingested {result.get('probes', 0)} probes → {result.get('files_created', 0)} files[/green]")
        console.print(f"  Project: [cyan]{resolved_target.project}[/cyan]")
        scan_info = result.get("scan", {})
        if scan_info:
            console.print(f"  Scan: {scan_info.get('edges_created', 0)} edges, {scan_info.get('objects_found', 0)} objects")
    elif result.get("status") == "skipped":
        console.print(f"[yellow]{result.get('reason')}[/yellow]")
    else:
        console.print(f"[red]{result.get('error', 'Push failed')}[/red]")
        raise typer.Exit(1)


@app.command()
def list_probes(
    pattern: str = typer.Argument("*", help="Filter pattern"),
):
    """List all available probes."""
    from core.registry import discover_probes
    from core.registry import list_probes as _list

    discover_probes()
    probes = _list(pattern)

    table = Table(title=f"Available Probes ({len(probes)})")
    table.add_column("Name", style="cyan")
    table.add_column("Description")

    for name in probes:
        from core.registry import get_probe
        cls = get_probe(name)
        desc = cls.description() if cls else ""
        table.add_row(name, desc)

    console.print(table)


@app.command()
def diff(
    current: str = typer.Option("./output", "--current", help="Current output dir"),
    previous: str = typer.Option("./output.prev", "--previous", help="Previous output dir"),
):
    """Compare current vs previous extraction — detect metadata changes."""
    from core.diff import diff_probes

    cur_path = Path(current)
    prev_path = Path(previous)
    if not cur_path.exists():
        console.print(f"[red]Current dir not found: {cur_path}[/red]"); raise typer.Exit(1)
    if not prev_path.exists():
        console.print(f"[red]Previous dir not found: {prev_path}[/red]"); raise typer.Exit(1)

    results = diff_probes(cur_path, prev_path)
    table = Table(title="Probe Diff")
    table.add_column("Probe", style="cyan")
    table.add_column("Status")
    table.add_column("Now", justify="right")
    table.add_column("Prev", justify="right")
    table.add_column("+", justify="right", style="green")
    table.add_column("-", justify="right", style="red")

    for r in results:
        st = {"new": "[green]NEW[/green]", "removed": "[red]REMOVED[/red]",
              "changed": "[yellow]CHANGED[/yellow]", "unchanged": "[dim]ok[/dim]"}.get(r["status"], r["status"])
        table.add_row(r["probe"], st, str(r["current_records"]), str(r["previous_records"]),
                       str(r["added"]) if r["added"] else "", str(r["removed"]) if r["removed"] else "")
    console.print(table)
    changed = sum(1 for r in results if r["status"] not in ("unchanged",))
    console.print(f"\n{changed} changed, {sum(r['added'] for r in results)} added, {sum(r['removed'] for r in results)} removed")


@app.command()
def schedule(
    pattern: str = typer.Argument("oracle.metadata.*"),
    cron: str = typer.Option("0 6 * * *", "--cron", help="Cron expression (minute hour day month weekday)"),
    config: str = typer.Option("config.yaml", "--config", "-c"),
    schema: str = typer.Option("", "--schema", "-s"),
    output: str = typer.Option("./output", "--output", "-o"),
):
    """Run probes on a cron schedule. Blocks forever.

    Example: metapod schedule "oracle.*" --cron "0 6 * * *"
    """
    from core.scheduler import run_schedule

    console.print(f"[bold]Scheduling '{pattern}' with cron: {cron}[/bold]")
    console.print("Press Ctrl+C to stop.\n")

    def _run():
        console.print(f"[dim]{__import__('datetime').datetime.now().isoformat()}[/dim] Running {pattern}...")
        import subprocess
        subprocess.run([
            "python3", "cli.py", "run", pattern,
            "--config", config, "--schema", schema, "--output", output,
        ])

    try:
        run_schedule(cron, _run)
    except KeyboardInterrupt:
        console.print("\n[yellow]Schedule stopped.[/yellow]")


@app.command()
def serve(
    config: str = typer.Option("config.yaml", "--config", "-c"),
    port: int = typer.Option(9090, "--port", "-p"),
    cache_ttl: int = typer.Option(300, "--cache-ttl", help="Cache TTL in seconds"),
    api_key: str = typer.Option("", "--api-key", "-k", help="Require API key for access"),
):
    """Start pull-mode daemon — serves probe results via HTTP.

    External platforms call GET /probes/{pattern} to fetch metadata on demand.

    Examples:
      metapod serve --port 9090
      curl http://localhost:9090/probes/oracle.metadata.tables
      curl http://localhost:9090/catalog
    """
    from core.server import start_server

    try:
        start_server(config, port, cache_ttl, api_key=api_key)
    except KeyboardInterrupt:
        console.print("\n[yellow]Daemon stopped.[/yellow]")


@app.command()
def provision(
    action: str = typer.Argument("azure", help="What to provision: azure, teardown, status, test"),
    region: str = typer.Option("westeurope", "--region", "-r", help="Azure region"),
    configs_dir: str = typer.Option("./configs", "--configs", help="Directory for generated config files"),
    resource_group: str = typer.Option("", "--resource-group", help="Resource group (for teardown)"),
):
    """Provision cloud resources for probe testing.

    Lifecycle:
      metapod provision azure              # Create all Azure resources
      metapod provision test               # Run all Azure probes against provisioned resources
      metapod provision status             # Show provisioned resources
      metapod provision teardown           # Delete everything

    Requires: az login (Azure CLI must be authenticated).
    """
    from core.provision import ensure_az_login, provision_azure, teardown_azure, run_azure_probes

    if action == "azure":
        # Auto-login from .env or check existing session
        info = ensure_az_login()
        if not info.get("logged_in"):
            console.print("[red]Not logged in to Azure CLI.[/red]")
            console.print("Run: [bold]az login[/bold]")
            raise typer.Exit(1)

        console.print(f"[bold]Azure provisioning[/bold]")
        console.print(f"  Account: {info['user']}")
        console.print(f"  Subscription: {info['subscription_name']}")
        console.print(f"  Region: {region}\n")

        from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

        steps_done = []
        with Progress(
            SpinnerColumn(),
            TextColumn("[bold]{task.description}"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Starting...", total=None)

            def _callback(step, msg):
                progress.update(task, description=f"[cyan]{msg}")
                steps_done.append((step, msg))

            result = provision_azure(
                region=region,
                output_dir=configs_dir,
                callback=_callback,
            )

        console.print()
        if result.errors:
            for e in result.errors:
                console.print(f"[red]Error: {e}[/red]")

        # Summary table
        table = Table(title="Provisioned Resources")
        table.add_column("Resource", style="cyan")
        table.add_column("Value")
        table.add_column("Status")

        table.add_row("Resource Group", result.resource_group, "[green]OK[/green]" if result.resource_group else "[red]FAIL[/red]")
        table.add_row("Storage Account", result.storage_account, "[green]OK[/green]" if result.storage_account else "[red]FAIL[/red]")
        table.add_row("Azure SQL", result.sql_server, "[green]OK[/green]" if result.sql_server else "[red]FAIL[/red]")
        table.add_row("Data Factory", result.adf_name, "[green]OK[/green]" if result.adf_name else "[red]FAIL[/red]")
        console.print(table)

        if result.configs_generated:
            console.print(f"\n[bold]Config files generated in {configs_dir}/:[/bold]")
            for c in result.configs_generated:
                console.print(f"  [dim]{c}[/dim]")

        console.print(f"\n[bold]Next steps:[/bold]")
        console.print(f"  metapod provision test       # Run all Azure probes")
        console.print(f"  metapod provision teardown    # Delete everything when done")

    elif action == "teardown":
        state_file = Path(configs_dir) / ".provision_state.json"
        rg = resource_group

        if not rg and state_file.exists():
            import json
            state = json.loads(state_file.read_text())
            rg = state.get("resource_group", "")

        if not rg:
            console.print("[red]No resource group found. Use --resource-group or run provision first.[/red]")
            raise typer.Exit(1)

        console.print(f"[bold red]Tearing down resource group: {rg}[/bold red]")
        console.print("This will delete ALL resources in the group.\n")

        def _callback(step, msg):
            console.print(f"  {msg}")

        ok = teardown_azure(resource_group=rg, callback=_callback)
        if ok:
            console.print(f"\n[green]Deletion initiated for {rg}[/green]")
            console.print("[dim]Azure will delete resources in the background (may take a few minutes).[/dim]")
            # Clean up state file
            if state_file.exists():
                state_file.unlink()
        else:
            console.print("[red]Teardown failed.[/red]")
            raise typer.Exit(1)

    elif action == "status":
        state_file = Path(configs_dir) / ".provision_state.json"
        if not state_file.exists():
            console.print("[yellow]No provisioned resources found.[/yellow]")
            console.print("Run: metapod provision azure")
            raise typer.Exit(0)

        import json
        state = json.loads(state_file.read_text())
        table = Table(title="Provisioned Resources")
        table.add_column("Key", style="cyan")
        table.add_column("Value")
        for k, v in state.items():
            if isinstance(v, list):
                v = ", ".join(v)
            table.add_row(k, str(v))
        console.print(table)

    elif action == "test":
        state_file = Path(configs_dir) / ".provision_state.json"
        if not state_file.exists():
            console.print("[red]No provisioned resources. Run: metapod provision azure[/red]")
            raise typer.Exit(1)

        console.print("[bold]Running all Azure probes against provisioned resources...[/bold]\n")
        results = run_azure_probes(configs_dir=configs_dir)

        table = Table(title="Azure Probe Test Results")
        table.add_column("Probe Group", style="cyan")
        table.add_column("Status")
        table.add_column("Details")

        for pattern, info in results.items():
            status = info.get("status", "unknown")
            st = {"ok": "[green]PASS[/green]", "error": "[red]FAIL[/red]",
                  "timeout": "[yellow]TIMEOUT[/yellow]", "skipped": "[dim]SKIP[/dim]"}.get(status, status)
            detail = info.get("reason", info.get("error", ""))
            if not detail and status == "error":
                detail = info.get("stderr", "")[:80]
            table.add_row(pattern, st, detail)

        console.print(table)

    else:
        console.print(f"[red]Unknown action: {action}[/red]")
        console.print("Use: azure, teardown, status, test")
        raise typer.Exit(1)


@app.command()
def init():
    """Create a default config.yaml file."""
    config_path = Path("config.yaml")
    if config_path.exists():
        console.print("[yellow]config.yaml already exists[/yellow]")
        raise typer.Exit(1)

    config_path.write_text("""# metapod configuration
source:
  type: oracle
  host: localhost
  port: 1521
  service_name: ORCLPDB1
  username: system
  password: ""
  schema_name: RISK_MGMT

target:
  url: ""  # https://your-platform.example.com (empty = local only)
  api_key: ""
  project: default

output_dir: ./output
probes:
  - "oracle.metadata.*"
  - "oracle.quality.*"
schedule: ""  # cron: "0 6 * * *" (empty = one-shot)
""")
    console.print("[green]Created config.yaml[/green]")


if __name__ == "__main__":
    app()
