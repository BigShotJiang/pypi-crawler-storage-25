"""Documentation generation and serving utilities (used by ``rai docs``)."""

from __future__ import annotations

import shutil
import subprocess
import webbrowser
from pathlib import Path
from typing import Iterable, Optional

import click

from . import runtime as _runtime


def find_docs_dir() -> Path:
    """Find the documentation source directory."""
    possible_paths = [
        Path("docs"),
        Path(__file__).parent.parent.parent.parent / "docs",
        Path.cwd() / "docs",
    ]
    for path in possible_paths:
        if path.exists() and (path / "package.json").exists():
            return path.resolve()
    raise click.ClickException(
        "Documentation source directory not found. Expected 'docs/' directory with package.json"
    )


def _has_tool(binary: str) -> bool:
    try:
        subprocess.run([binary, "--version"], capture_output=True, text=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def has_nodejs() -> bool:
    return _has_tool("node")


def has_npm() -> bool:
    return _has_tool("npm")


def _require_tool(binary: str, hint: str) -> None:
    if not _has_tool(binary):
        raise click.ClickException(f"{binary} is not installed. {hint}")


def _require_docs_prereqs(docs_dir: Path) -> None:
    """Ensure node/npm are installed and that ``docs_dir`` contains ``package.json``."""
    _require_tool("node", "Please install Node.js from https://nodejs.org/")
    _require_tool("npm", "npm should come with Node.js installation.")
    if not (docs_dir / "package.json").exists():
        raise click.ClickException(
            f"package.json not found in {docs_dir}. This doesn't appear to be a valid SolidJS project."
        )


def _ensure_node_modules(docs_dir: Path) -> None:
    """Run ``npm install`` if ``node_modules/`` is missing."""
    node_modules = docs_dir / "node_modules"
    if node_modules.exists():
        return
    _runtime.console.print("[blue]Installing dependencies...[/blue]")
    try:
        subprocess.run(
            ["npm", "install"],
            cwd=docs_dir,
            check=True,
            capture_output=True,
            text=True,
        )
        _runtime.console.print("[green]✓ Dependencies installed[/green]")
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr or e.stdout or "Unknown error"
        raise click.ClickException(f"Failed to install dependencies: {error_msg}") from e


def _run_npm(args: Iterable[str], *, cwd: Path, fail_message: str) -> None:
    """Run an ``npm`` subcommand; on failure, raise ``ClickException`` carrying
    the captured stderr/stdout.

    Rendering the diagnostic is left to the caller
    (``exit_on_docs_subcommand_failure``) so each failure only shows up once.
    """
    try:
        subprocess.run(["npm", *args], cwd=cwd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr or e.stdout or "Unknown error"
        raise click.ClickException(f"{fail_message} {error_msg}".strip()) from e


def print_generation_success(output_path: Path) -> None:
    """Print success message after documentation generation."""
    _runtime.console.print("[green]✓ Documentation generated")
    _runtime.console.print()
    _runtime.console.print("[cyan]The documentation site is ready to host![/cyan]")
    _runtime.console.print(f"[dim]Output location: {output_path}[/dim]")
    _runtime.console.print()
    _runtime.console.print("[yellow]You can serve it locally with:[/yellow]")
    _runtime.console.print("  [bold]rai docs serve[/bold]")
    _runtime.console.print()
    _runtime.console.print("[yellow]Or host the dist folder directly:[/yellow]")
    _runtime.console.print(
        "[dim]The dist folder contains a complete static website. You can copy it to any "
        "web server (Nginx, Apache, Flask, etc.), upload it to a CDN, or deploy it to "
        "static hosting services like GitHub Pages, Netlify, or Vercel. All files use "
        "relative paths, so it works regardless of where it's hosted.[/dim]"
    )


def generate_docs(
    output_dir: Optional[str] = None,
    docs_dir: Optional[Path] = None,
) -> Path:
    """Generate a static documentation site and return the output path."""
    if docs_dir is None:
        docs_dir = find_docs_dir()
    _require_docs_prereqs(docs_dir)
    _ensure_node_modules(docs_dir)

    _runtime.console.print("[blue]Building documentation site...[/blue]")
    _run_npm(["run", "build"], cwd=docs_dir, fail_message="Documentation build failed.")
    _runtime.console.print("[green]✓ Build completed successfully[/green]")

    build_output = docs_dir / "dist"
    if not build_output.exists():
        raise click.ClickException("Build output directory not found. Build may have failed.")

    if output_dir:
        output_path = Path(output_dir).resolve()
        if output_path.exists():
            _runtime.console.print(f"[yellow]Output directory '{output_path}' exists. Cleaning...[/yellow]")
            shutil.rmtree(output_path)
        shutil.copytree(build_output, output_path)
        print_generation_success(output_path)
        return output_path

    print_generation_success(build_output)
    return build_output


def serve_docs(
    build_dir: str,
    host: str = "127.0.0.1",
    port: int = 8000,
    open_browser: bool = True,
) -> None:
    """Serve a previously generated documentation site with FastAPI/uvicorn."""
    build_path = Path(build_dir).resolve()

    if not build_path.exists():
        raise click.ClickException("Build directory does not exist. Run 'rai docs generate' first.")

    index_html = build_path / "index.html"
    if not index_html.exists():
        raise click.ClickException(
            "index.html not found. This doesn't appear to be a valid build directory. "
            "Run 'rai docs generate' first."
        )

    try:
        from fastapi import FastAPI
        from fastapi.staticfiles import StaticFiles
        import uvicorn
    except ImportError:
        raise click.ClickException(
            "FastAPI and uvicorn are required for serving documentation. "
            "Install with: pip install fastapi uvicorn"
        )

    app = FastAPI(title="RAI Documentation")
    app.mount("/", StaticFiles(directory=str(build_path), html=True), name="static")

    url = f"http://{host}:{port}"
    _runtime.console.print(f"[green]✓ Documentation server running at {url}[/green]")
    _runtime.console.print("[yellow]Press Ctrl+C to stop the server[/yellow]")

    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            _runtime.console.print(f"[yellow]Could not open browser automatically. Visit {url}[/yellow]")

    try:
        uvicorn.run(app, host=host, port=port, log_level="warning")
    except KeyboardInterrupt:
        _runtime.console.print("\n[yellow]Server stopped[/yellow]")
    except OSError as e:
        if "Address already in use" in str(e):
            raise click.ClickException(
                f"Port {port} is already in use. Try a different port with --port option."
            )
        raise


def dev_docs(
    docs_dir: Optional[Path] = None,
    host: str = "127.0.0.1",
    port: int = 5173,
    open_browser: bool = True,
) -> None:
    """Start the Vite dev server for live documentation preview with HMR."""
    if docs_dir is None:
        docs_dir = find_docs_dir()
    _require_docs_prereqs(docs_dir)
    _ensure_node_modules(docs_dir)

    url = f"http://{host}:{port}"
    _runtime.console.print("[green]✓ Starting development server...[/green]")
    _runtime.console.print(f"[blue]Server will be available at {url}[/blue]")
    _runtime.console.print("[yellow]Press Ctrl+C to stop the server[/yellow]")
    _runtime.console.print("[dim]Note: Changes to files will automatically reload in the browser[/dim]")

    if open_browser:
        import threading
        import time

        def _open_browser_delayed() -> None:
            time.sleep(1.5)
            try:
                webbrowser.open(url)
            except Exception:
                _runtime.console.print(f"[yellow]Could not open browser automatically. Visit {url}[/yellow]")

        threading.Thread(target=_open_browser_delayed, daemon=True).start()

    try:
        subprocess.run(
            ["npm", "run", "dev", "--", "--host", host, "--port", str(port)],
            cwd=docs_dir,
            check=True,
        )
    except KeyboardInterrupt:
        _runtime.console.print("\n[yellow]Development server stopped[/yellow]")
    except subprocess.CalledProcessError as e:
        # The dev server streams its output directly to the user's terminal
        # (stdout/stderr are inherited, not captured), so any real failure
        # detail is already visible above. There's no captured text to
        # include here beyond the npm exit code.
        raise click.ClickException(
            f"Dev server failed (npm exited with code {e.returncode})."
        ) from e
    except OSError as e:
        if "Address already in use" in str(e):
            raise click.ClickException(
                f"Port {port} is already in use. Try a different port with --port option."
            )
        raise


def cleanup_docs(docs_dir: Optional[Path] = None) -> None:
    """Remove generated files and dependencies (``node_modules``, ``dist``)."""
    if docs_dir is None:
        docs_dir = find_docs_dir()

    for name in ("node_modules", "dist"):
        path = docs_dir / name
        if path.exists() and path.is_dir():
            try:
                shutil.rmtree(path)
            except Exception as e:
                raise click.ClickException(f"Failed to remove {name}: {e}")
