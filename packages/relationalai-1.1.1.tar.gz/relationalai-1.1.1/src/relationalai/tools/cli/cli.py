"""
RelationalAI CLI — tools for working with semantic models.

For full documentation visit https://docs.relationalai.com.

Structure
---------

This module is intentionally small. It wires together:

- the :class:`~relationalai.tools.cli._group.RaiGroup` (help formatting)
- the two global flags ``--no-color`` and ``--json``
- every command group under :mod:`~relationalai.tools.cli.commands` via
  :func:`~relationalai.tools.cli.commands.register_all`.

Everything else (runtime context, config loading, client connection, JSON
serialization, rendering, error handling) lives in focused modules.
"""

from __future__ import annotations

import os
from importlib.metadata import PackageNotFoundError, version as _pkg_version

import click

from . import runtime, update_check
from ._group import RaiGroup
from .commands import register_all
from .runtime import flush_diagnostics_on_close


def _version_callback(ctx: click.Context, _param: click.Parameter, value: bool) -> None:
    """Print the version and, when appropriate, nudge if outdated.

    Behaves like ``click.version_option`` but does a *synchronous* PyPI check
    when the user explicitly asks for the version (they're already waiting),
    so the upgrade notice appears immediately rather than next run.

    Honors the same suppression rules as the post-command notice path:
    ``--json``, non-TTY stderr, CI envs, ``RAI_NO_UPDATE_CHECK``, and
    dev/prerelease/local installs. The version string itself is always
    printed — the gate only governs the PyPI lookup and the panel render.

    ``--json`` and ``--no-color`` are honored even though this eager callback
    runs before :func:`cli`: :meth:`RaiGroup.parse_args` primes the runtime
    from raw args before any option callback fires.
    """
    if not value or ctx.resilient_parsing:
        return

    try:
        installed = _pkg_version("relationalai")
    except PackageNotFoundError:
        installed = "unknown"
    click.echo(f"rai, version {installed}")

    if installed == "unknown" or update_check.should_skip_notice():
        ctx.exit()
        return

    latest = update_check.check_now_sync()
    if latest is not None:
        try:
            from packaging.version import Version

            if Version(latest) > Version(installed):
                update_check.render_upgrade_panel(installed=installed, latest=latest)
        except Exception:
            pass
    ctx.exit()


@click.group(
    invoke_without_command=True,
    cls=RaiGroup,
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.option(
    "--version",
    is_flag=True,
    is_eager=True,
    expose_value=False,
    callback=_version_callback,
    help="Show the version and exit.",
)
@click.option(
    "--no-color",
    is_flag=True,
    default=False,
    help="Disable colored terminal output. A non-empty NO_COLOR environment variable does the same.",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Print supported commands as JSON (reasoners/jobs list & get).",
)
@click.pass_context
def cli(ctx: click.Context, no_color: bool, json_output: bool) -> None:
    """RelationalAI CLI - Tools for working with semantic models.

    For more documentation on these commands, visit: https://docs.relationalai.com
    """
    rt = runtime.get_runtime(ctx)
    rt.json_output = bool(json_output)

    no_color = bool(no_color) or (os.environ.get("NO_COLOR", "").strip() != "")
    rt.no_color = no_color
    if no_color:
        ctx.color = False
    runtime.configure_console(no_color=no_color)

    flush_diagnostics_on_close(ctx)

    update_check.maybe_start_check()
    ctx.call_on_close(update_check.maybe_print_notice)

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


register_all(cli)


if __name__ == "__main__":
    cli()
