"""CLI runtime: shared state and lifecycle helpers for every Click command.

This module is the single source of truth for:

- the shared Rich :class:`~rich.console.Console` (``console``, rebuilt by ``configure_console``)
- the :class:`CliRuntime` context object attached to ``ctx.obj`` (``--json``, ``--no-color``, config, interactivity)
- ``load_config`` (thin wrapper over ``create_config`` with friendlier errors)
- ``cli_connect_sync`` (context manager that also plumbs execution diagnostics)
- ``is_interactive`` / ``cli_wants_json`` / ``emit_cli_json`` (small context-aware helpers)

Commands in ``commands/*.py`` import this module by name and look helpers up at
runtime (``from relationalai.tools.cli import runtime`` → ``runtime.load_config()``).
That way tests can monkeypatch ``relationalai.tools.cli.runtime.load_config`` once
and affect every command without hunting for import-time rebindings.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import TYPE_CHECKING, Any, TypeVar

import click
from rich.console import Console

from .cli_output_prefs import set_cli_no_color
from .execution_diagnostics import (
    BufferedExecutionLogHandler,
    disable_execution_logging_buffer,
    enable_execution_logging_buffer,
    flush_execution_logging_buffer,
    print_execution_metrics_if_enabled,
)

if TYPE_CHECKING:
    from relationalai.client.client_sync import ClientSync
    from relationalai.config.config import Config

T = TypeVar("T")


# ── Shared Rich console ──────────────────────────────────────────────────────

console: Console = Console()


def configure_console(*, no_color: bool) -> None:
    """Rebuild the module-level Rich :class:`Console` after parsing ``--no-color``."""
    set_cli_no_color(no_color)
    global console
    console = Console(no_color=no_color)


# ── CliRuntime (attached to ``ctx.obj``) ─────────────────────────────────────


@dataclass
class CliRuntime:
    """Per-invocation runtime state, stored on ``click.Context.obj``.

    Commands should accept this via ``@click.pass_obj`` (or read it from
    ``click.get_current_context().obj``). It carries global flag values and
    the slots used by :func:`flush_diagnostics_on_close`.
    """

    json_output: bool = False
    no_color: bool = False
    diag_flush_registered: bool = False
    execution_diag_config: "Config | None" = None
    execution_log_handler: BufferedExecutionLogHandler | None = None
    execution_metrics: Any | None = None


def get_runtime(ctx: click.Context | None = None) -> CliRuntime:
    """Return the current :class:`CliRuntime`, creating one if necessary."""
    if ctx is None:
        ctx = click.get_current_context(silent=True)
    if ctx is None:
        # No Click context (unit tests); return a throwaway runtime.
        return CliRuntime()

    obj = ctx.ensure_object(dict) if not isinstance(ctx.obj, CliRuntime) else ctx.obj
    if isinstance(obj, CliRuntime):
        return obj

    # Legacy dict-based ctx.obj (older tests/wiring) — migrate values in place.
    rt = CliRuntime(
        json_output=bool(obj.get("json_output", False)),
        no_color=bool(obj.get("no_color", False)),
        diag_flush_registered=bool(obj.get("_execution_diag_on_close_registered", False)),
        execution_diag_config=obj.get("_execution_diag_config"),
        execution_log_handler=obj.get("_execution_log_handler"),
        execution_metrics=obj.get("_execution_metrics"),
    )
    ctx.obj = rt
    return rt


# ── Small context-aware helpers ──────────────────────────────────────────────


def cli_wants_json() -> bool:
    """True when the current command was run with global ``--json``."""
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return False
    rt = get_runtime(ctx)
    return rt.json_output


def _json_default(obj: Any) -> Any:
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, timedelta):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _json_default_lenient(obj: Any) -> Any:
    """Like :func:`_json_default` but falls back to ``str(obj)`` for unknown
    types instead of raising.

    Used for CLI output that can carry arbitrary structured payloads from
    backend services (e.g. ``jobs:events``), where a never-before-seen type
    in a value should still print rather than crash the command.
    """
    try:
        return _json_default(obj)
    except TypeError:
        return str(obj)


def emit_cli_json(data: Any, *, lenient: bool = False) -> None:
    """Print JSON to stdout (no Rich markup).

    With ``lenient=True``, unknown types (e.g. ``Decimal`` or service-layer
    objects without a JSON encoder) fall back to ``str(obj)`` rather than
    raising. Use lenient mode for outputs that can carry arbitrary
    backend-supplied payloads; leave it off for outputs whose schema we
    control so any type drift surfaces loudly.
    """
    default = _json_default_lenient if lenient else _json_default
    click.echo(json.dumps(data, indent=2, default=default))


def is_interactive() -> bool:
    """Return True when CLI can prompt interactively (stdin is a TTY)."""
    try:
        return bool(getattr(sys.stdin, "isatty", lambda: False)())
    except Exception:
        return False


# ── Config + client lifecycle ────────────────────────────────────────────────


def load_config() -> "Config":
    """Load config via ``create_config()`` with a friendlier error surface."""
    try:
        from relationalai.config import create_config

        return create_config()
    except ModuleNotFoundError as e:
        raise click.ClickException(
            "Failed to load config. Ensure optional config dependencies are installed "
            "(e.g. `pydantic-settings`) and that your configuration is valid."
        ) from e
    except Exception as e:
        raise click.ClickException(f"Failed to load config: {e}") from e


@contextmanager
def cli_connect_sync(config: "Config") -> Iterator["ClientSync"]:
    """Connect a sync client and plumb execution diagnostics through ``ctx.obj``."""
    from relationalai.client import connect_sync

    handler = enable_execution_logging_buffer(config)
    ctx = click.get_current_context(silent=True)
    rt = get_runtime(ctx) if ctx is not None else None
    if rt is not None:
        if handler is not None:
            rt.execution_log_handler = handler
        rt.execution_diag_config = config

    with connect_sync(config=config) as client:
        try:
            yield client
        finally:
            if rt is not None:
                rt.execution_metrics = getattr(client, "execution_metrics", None)


@contextmanager
def cli_session() -> Iterator[tuple["Config", bool, "ClientSync"]]:
    """Bundle the standard CLI command preamble: load config + interactivity + connect.

    Yields ``(config, interactive, client)``. Use this for commands whose only
    pre-connect work is ``load_config()`` and ``is_interactive()``; commands
    that validate user input *before* opening a connection (e.g. ``jobs:list``)
    should keep using :func:`load_config` + :func:`cli_connect_sync` directly so
    bad arguments fail fast without touching the network.

    Exception behavior: this helper does no exception translation of its own.
    Errors raised by :func:`load_config` (bad/missing ``raiconfig.yaml``) and
    :func:`is_interactive` propagate *before* the connection is opened, so the
    standard ``handle_cli_errors`` decorator on each command sees them and
    renders the right diagnostic. Errors raised inside the ``cli_connect_sync``
    context follow that helper's own behavior — connection cleanup is handled
    by ``cli_connect_sync``, not by this wrapper.
    """
    config = load_config()
    interactive = is_interactive()
    with cli_connect_sync(config) as client:
        yield config, interactive, client


# ── Spinner-wrapped call ─────────────────────────────────────────────────────


def run_with_spinner(message: str, fn: Callable[[], T]) -> T:
    """Run ``fn()`` under a :class:`WaitSpinner` and return its result.

    Eliminates the ``x: Any = None; with WaitSpinner(...): x = fn()`` dance
    that otherwise confuses type checkers about post-block bindings.
    """
    from .components import WaitSpinner

    with WaitSpinner(message):
        return fn()


def flush_diagnostics_on_close(ctx: click.Context) -> None:
    """Register a one-shot ``call_on_close`` that flushes execution diagnostics.

    Idempotent: multiple invocations within the same context only register once.
    """
    rt = get_runtime(ctx)
    if rt.diag_flush_registered:
        return
    rt.diag_flush_registered = True

    def _flush() -> None:
        cfg = rt.execution_diag_config
        handler = rt.execution_log_handler

        flush_execution_logging_buffer(handler, cfg=cfg)
        disable_execution_logging_buffer(handler)

        if cfg is not None:
            print_execution_metrics_if_enabled(cfg, rt.execution_metrics)

        rt.execution_log_handler = None
        rt.execution_metrics = None
        rt.execution_diag_config = None

    ctx.call_on_close(_flush)
