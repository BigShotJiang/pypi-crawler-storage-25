"""CLI-wide output preferences (shared by Rich stdout and stderr diagnostics).

Avoids import cycles between ``runtime`` and ``execution_diagnostics``.
"""

from __future__ import annotations

_cli_no_color: bool = False


def set_cli_no_color(value: bool) -> None:
    """Set when the root ``rai`` group parses ``--no-color`` / ``NO_COLOR``."""
    global _cli_no_color
    _cli_no_color = bool(value)


def cli_requests_no_color() -> bool:
    """True when the user asked for no ANSI color for this CLI invocation."""
    return _cli_no_color
