"""JSON serialization helpers for reasoner/job records.

Prefer pydantic ``model_dump(mode="json")`` when available; fall back to a
fixed list of attributes so that non-pydantic mocks (tests) still round-trip.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date, datetime, timedelta
from typing import Any

_REASONER_ATTRS = (
    "id",
    "name",
    "type",
    "size",
    "state",
    "created_by",
    "created_on",
    "updated_on",
    "version",
    "auto_suspend_mins",
    "suspends_at",
    "settings",
    "runtime",
)

_JOB_ATTRS = (
    "id",
    "reasoner_type",
    "name",
    "model",
    "state",
    "created_by",
    "created_on",
    "finished_at",
    "duration",
    "abort_reason",
    "details",
    "artifacts",
    "events",
    "problems",
    "raw",
)


def _maybe_model_dump(obj: Any) -> dict[str, Any] | None:
    md = getattr(obj, "model_dump", None)
    if not callable(md):
        return None
    try:
        out = md(mode="json")
    except Exception:
        try:
            out = md()
        except Exception:
            return None
    return dict(out) if isinstance(out, Mapping) else None


def _jsonify_scalar(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, timedelta):
        return str(v)
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, Mapping):
        return dict(v)
    if isinstance(v, (list, tuple)):
        return [_jsonify_scalar(x) for x in v]
    return v


def reasoner_record_as_json(obj: Any) -> dict[str, Any]:
    """Serialize a reasoner record for global ``--json``."""
    dumped = _maybe_model_dump(obj)
    if dumped is not None:
        return dumped
    return {k: _jsonify_scalar(getattr(obj, k, None)) for k in _REASONER_ATTRS}


def job_record_as_json(obj: Any) -> dict[str, Any]:
    """Serialize a job record for global ``--json``."""
    dumped = _maybe_model_dump(obj)
    if dumped is not None:
        return dumped
    out: dict[str, Any] = {k: _jsonify_scalar(getattr(obj, k, None)) for k in _JOB_ATTRS}
    ev = out.get("events")
    if ev is not None and not isinstance(ev, (dict, list, str, int, float, bool, type(None))):
        out["events"] = {
            "events": list(getattr(ev, "events", [])),
            "continuation_token": getattr(ev, "continuation_token", None),
        }
    return out
