"""Background check that nudges users when a newer ``relationalai`` is on PyPI.

Design (mirrors ``gh``, ``npm``, ``poetry``, ``aws`` v2):

1. On CLI startup, :func:`maybe_start_check` kicks off a daemon thread that
   refreshes a small JSON cache at ``~/.cache/relationalai/version_check.json``
   (respecting ``XDG_CACHE_HOME``) at most once every 24 hours by hitting
   ``https://pypi.org/pypi/relationalai/json``. Any failure is silently
   swallowed — an update notice must never break a CLI invocation.
2. Just before the CLI exits, :func:`maybe_print_notice` reads the cache and,
   if a newer version is available, renders a styled multi-line Rich panel to
   **stderr** so it never pollutes ``--json`` output or stdout pipelines.
3. :func:`check_now_sync` does a blocking PyPI check (used by ``rai --version``
   where the user is already waiting on the version string).

Two suppression gates drive every entry point:

- :func:`should_skip_pypi_check` — *never* contact PyPI. True for the
  ``RAI_NO_UPDATE_CHECK`` opt-out, CI environments, and prerelease /
  dev / local installs (where we'd suppress the notice anyway).
- :func:`should_skip_notice` — never *render* the panel. Adds two more
  reasons on top of the above: ``--json`` is active and ``stderr`` is not
  a TTY (the CLI is being piped or redirected).

The background refresh keeps running under ``--json`` and non-TTY so the
*next* interactive run is up to date; it stops entirely under the PyPI gate.
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# 24 hours between PyPI lookups. The cache file timestamp is the source of truth.
_CACHE_TTL_SECONDS = 24 * 60 * 60

# Hard timeout for the PyPI HTTP request. Kept tight so a slow network never
# delays process exit (the daemon thread is detached, but a quick timeout also
# means a dev's flaky wifi doesn't burn CPU on a stuck socket).
_PYPI_TIMEOUT_SECONDS = 1.5

_PYPI_URL = "https://pypi.org/pypi/relationalai/json"
_PACKAGE_NAME = "relationalai"

_CI_ENV_VARS = (
    "CI",
    "CONTINUOUS_INTEGRATION",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "BUILDKITE",
    "CIRCLECI",
    "JENKINS_URL",
    "TF_BUILD",  # Azure Pipelines
)

# Module-level guard so :func:`maybe_start_check` is idempotent within a
# single process even if the root group is invoked more than once (tests).
# Both the read and the write happen *inside* the ``with _check_started:``
# block in :func:`maybe_start_check`, so this flag is safe under concurrent
# invocation regardless of CPython's GIL semantics.
_check_started = threading.Lock()
_check_already_started = False


# ── Public API ───────────────────────────────────────────────────────────────


def maybe_start_check() -> None:
    """Spawn a daemon thread to refresh the PyPI cache, at most once per process.

    Returns immediately. Safe to call when offline or in CI: every failure mode
    is swallowed by the worker.
    """
    global _check_already_started
    if should_skip_pypi_check():
        return
    with _check_started:
        if _check_already_started:
            return
        _check_already_started = True

    thread = threading.Thread(
        target=_refresh_cache_safely,
        name="rai-update-check",
        daemon=True,
    )
    thread.start()


def maybe_print_notice() -> None:
    """If the cache says a newer version is available, print a styled panel to stderr.

    Suppressed via :func:`should_skip_notice` (``--json``, non-TTY stderr, CI,
    dev/prerelease builds, and the ``RAI_NO_UPDATE_CHECK`` opt-out). Never raises.
    """
    try:
        if should_skip_notice():
            return
        installed = _installed_version()
        if installed is None:
            return
        latest = _read_cached_latest()
        if latest is None:
            return
        if not _is_strictly_newer(latest, installed):
            return
        render_upgrade_panel(installed=installed, latest=latest)
    except Exception:
        # Never let a version-check bug surface to users.
        return


def format_version_summary(*, use_color: bool = True) -> str:
    """One-line version summary for embedding in ``rai --help`` output.

    Reads the installed version from package metadata. **Never hits the
    network** — adds zero perceptible latency to the help screen.

    Always returns just ``Version: x.y.z``. The post-command panel
    rendered by :func:`maybe_print_notice` handles the upgrade nudge when
    the user is outdated, so we don't duplicate that messaging here.
    """
    installed = _installed_version() or "unknown"
    if not use_color:
        return f"Version: {installed}"
    try:
        import click as _click

        return f"{_click.style('Version:', dim=True)} {_click.style(installed, bold=True)}"
    except Exception:
        return f"Version: {installed}"


def render_upgrade_panel(*, installed: str, latest: str) -> None:
    """Render the upgrade notice as a Rich panel on stderr.

    Adds a leading blank line so the panel never bumps up against the
    preceding command output, and styles the ``pip install`` command in the
    same accent color used elsewhere in the CLI.
    """
    try:
        from rich.console import Console
        from rich.panel import Panel

        from .cli_output_prefs import cli_requests_no_color

        no_color = cli_requests_no_color()
        console = Console(stderr=True, no_color=no_color, highlight=False)

        body = (
            f"A new version of [bold]rai[/bold] is available: "
            f"[red]{installed}[/red] [dim]->[/dim] [bold green]{latest}[/bold green]\n"
            f"Upgrade with: [bold cyan]pip install -U {_PACKAGE_NAME}[/bold cyan]"
        )
        panel = Panel(
            body,
            title="[bold yellow]Update available[/bold yellow]",
            border_style="yellow",
            padding=(1, 2),
        )
        # Blank line so the panel is visually separated from prior output.
        console.print()
        console.print(panel)
    except Exception:
        # Fall back to a plain stderr line if Rich isn't usable for any reason.
        print(
            f"\nA new version of rai is available: {installed} -> {latest}\n"
            f"Upgrade with: pip install -U {_PACKAGE_NAME}",
            file=sys.stderr,
        )


def check_now_sync() -> str | None:
    """Do a blocking PyPI lookup, refresh the cache, and return ``latest`` or ``None``.

    Used by ``rai --version`` where the user is explicitly waiting. Honors the
    same PyPI suppression rules as the background path (env opt-out, CI,
    prerelease/local installs). Returns ``None`` on any failure or suppression.
    """
    if should_skip_pypi_check():
        return None
    latest = _fetch_latest_from_pypi()
    if latest is not None:
        _write_cache(latest)
    return latest


# ── Public suppression helpers ───────────────────────────────────────────────


def should_skip_pypi_check() -> bool:
    """True when *no* path (background or synchronous) should contact PyPI.

    Combines the universal opt-outs (``RAI_NO_UPDATE_CHECK``, CI envs) with
    contexts where a result would be useless anyway: prerelease / dev / local
    installs (developers manage their own versions and would never see the
    notice).
    """
    if _read_truthy_env("RAI_NO_UPDATE_CHECK"):
        return True
    if _running_in_ci():
        return True
    installed = _installed_version()
    if installed is not None and _is_prerelease_or_local(installed):
        return True
    return False


def should_skip_notice() -> bool:
    """True when no upgrade panel should be rendered, regardless of cache state.

    Adds the user-facing rules on top of :func:`should_skip_pypi_check`:
    ``--json`` is active, or ``stderr`` is not a TTY (piped/redirected).
    """
    if should_skip_pypi_check():
        return True
    if _json_output_active():
        return True
    if not _stderr_is_tty():
        return True
    return False


# ── Internals: suppression building blocks ───────────────────────────────────


def _read_truthy_env(name: str) -> bool:
    val = os.environ.get(name, "").strip().lower()
    return val not in ("", "0", "false", "no", "off")


def _running_in_ci() -> bool:
    return any(_read_truthy_env(name) for name in _CI_ENV_VARS)


def _json_output_active() -> bool:
    """True when the current Click invocation set ``--json``."""
    try:
        # Imported lazily to avoid a runtime <-> update_check import cycle.
        from . import runtime

        return runtime.cli_wants_json()
    except Exception:
        return False


def _stderr_is_tty() -> bool:
    try:
        return bool(getattr(sys.stderr, "isatty", lambda: False)())
    except Exception:
        return False


# ── Internals: version handling ──────────────────────────────────────────────


def _installed_version() -> str | None:
    try:
        import importlib.metadata as md

        return md.version(_PACKAGE_NAME)
    except Exception:
        return None


def _is_prerelease_or_local(version: str) -> bool:
    """Skip the notice on dev/alpha/beta/rc/local builds (developers)."""
    try:
        from packaging.version import InvalidVersion, Version

        try:
            v = Version(version)
        except InvalidVersion:
            return True
        return bool(v.is_prerelease or v.is_devrelease or v.local is not None)
    except Exception:
        # ``packaging`` is a hard dep, but stay defensive.
        marker = ("a", "b", "rc", "dev", "+")
        return any(token in version for token in marker)


def _is_strictly_newer(latest: str, installed: str) -> bool:
    try:
        from packaging.version import Version

        return Version(latest) > Version(installed)
    except Exception:
        return False


# ── Internals: cache I/O ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class _CachedEntry:
    latest: str
    fetched_at: float  # unix seconds (UTC)


def _cache_path() -> Path:
    base = os.environ.get("XDG_CACHE_HOME") or os.path.join(
        os.path.expanduser("~"), ".cache"
    )
    return Path(base) / "relationalai" / "version_check.json"


def _read_cache() -> _CachedEntry | None:
    path = _cache_path()
    try:
        if not path.is_file():
            return None
        data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
        latest = data.get("latest")
        fetched_at = data.get("fetched_at")
        if not isinstance(latest, str) or not isinstance(fetched_at, (int, float)):
            return None
        return _CachedEntry(latest=latest, fetched_at=float(fetched_at))
    except Exception:
        return None


def _read_cached_latest() -> str | None:
    entry = _read_cache()
    return entry.latest if entry is not None else None


def _write_cache(latest: str) -> None:
    """Write the cache atomically.

    The background daemon thread can be writing the cache while another
    process / thread reads it on exit. Writing through a same-directory temp
    file plus :func:`os.replace` keeps readers from ever seeing a
    partially-written JSON document.
    """
    path = _cache_path()
    tmp_path: Path | None = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            {"latest": latest, "fetched_at": time.time()},
            separators=(",", ":"),
        )
        tmp_path = path.parent / (
            f".{path.name}.{os.getpid()}.{threading.get_ident()}.{time.time_ns()}.tmp"
        )
        with tmp_path.open("w", encoding="utf-8") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
    except Exception:
        if tmp_path is not None:
            try:
                tmp_path.unlink()
            except Exception:
                pass


def _cache_is_fresh(entry: _CachedEntry, now: float | None = None) -> bool:
    """True when ``entry`` is younger than the TTL.

    A negative age (system clock moved backward, or the file timestamp is in
    the future for any other reason) is treated as *not fresh* — we'd rather
    refresh once unnecessarily than honor a bogus future timestamp.
    """
    now = time.time() if now is None else now
    age = now - entry.fetched_at
    if age < 0:
        return False
    return age < _CACHE_TTL_SECONDS


# ── Internals: PyPI fetch ────────────────────────────────────────────────────


def _refresh_cache_safely() -> None:
    """Daemon-thread entry point. Skip the network if the cache is still fresh.

    Self-gates on :func:`should_skip_pypi_check` as defense-in-depth — even if
    the spawn site forgets to gate, this never phones home in suppressed envs.
    """
    try:
        if should_skip_pypi_check():
            return
        entry = _read_cache()
        if entry is not None and _cache_is_fresh(entry):
            return
        latest = _fetch_latest_from_pypi()
        if latest is not None:
            _write_cache(latest)
    except Exception:
        return


def _fetch_latest_from_pypi() -> str | None:
    """Return the latest *stable* version from PyPI, or ``None`` on any failure.

    Walks ``payload['releases']`` and picks the highest non-prerelease,
    non-yanked version. PyPI's ``info.version`` is *not* a reliable "latest
    stable" field — it can be a prerelease, in which case ``pip install -U``
    wouldn't actually pick it by default, and we'd nudge users toward a
    version they couldn't install. Falls back to ``info.version`` only when
    no stable release is discoverable.

    Uses ``urllib`` (stdlib) so we don't pull ``requests`` into CLI startup.
    """
    try:
        import urllib.request

        req = urllib.request.Request(
            _PYPI_URL,
            headers={"User-Agent": f"rai-cli-update-check/{_installed_version() or 'unknown'}"},
        )
        with urllib.request.urlopen(req, timeout=_PYPI_TIMEOUT_SECONDS) as resp:  # noqa: S310 - https only
            if getattr(resp, "status", 200) != 200:
                return None
            payload = json.loads(resp.read().decode("utf-8"))
        return _select_latest_stable(payload)
    except Exception:
        return None


def _select_latest_stable(payload: Any) -> str | None:
    """Pick the newest stable, non-yanked version from a PyPI JSON payload.

    A "stable" version is one whose ``packaging.Version`` is neither a
    prerelease nor a dev release and has no local segment. A version is
    considered "yanked" when *every* file under that version has
    ``yanked == True`` (PyPI's per-file yank semantics).
    """
    if not isinstance(payload, dict):
        return None
    releases = payload.get("releases")
    candidates: list[tuple[Any, str]] = []

    if isinstance(releases, dict):
        try:
            from packaging.version import InvalidVersion, Version
        except Exception:
            Version = None  # type: ignore[assignment]
            InvalidVersion = Exception  # type: ignore[assignment]

        for ver_str, files in releases.items():
            if not isinstance(ver_str, str) or not ver_str:
                continue
            if Version is None:
                # No packaging available — accept everything; we'll still
                # take the first match below as a coarse fallback.
                candidates.append((ver_str, ver_str))
                continue
            try:
                v = Version(ver_str)
            except InvalidVersion:
                continue
            if v.is_prerelease or v.is_devrelease or v.local is not None:
                continue
            if isinstance(files, list) and files and all(
                isinstance(f, dict) and f.get("yanked") for f in files
            ):
                continue
            candidates.append((v, ver_str))

    if candidates:
        candidates.sort(key=lambda t: t[0])
        return candidates[-1][1]

    info = payload.get("info") or {}
    fallback = info.get("version")
    return fallback if isinstance(fallback, str) and fallback else None
