from __future__ import annotations

from typing import Final

JOB_TYPE_LOGIC: Final[str] = "LOGIC"
JOB_TYPE_SOLVER: Final[str] = "SOLVER"
JOB_TYPE_ML: Final[str] = "ML"

JOB_TYPES: Final[tuple[str, ...]] = (JOB_TYPE_LOGIC, JOB_TYPE_SOLVER, JOB_TYPE_ML)

# User-facing labels used in CLI output/help.
JOB_TYPE_LABELS: Final[dict[str, str]] = {
    JOB_TYPE_LOGIC: "Logic",
    JOB_TYPE_SOLVER: "Prescriptive",
    JOB_TYPE_ML: "Predictive",
}

# Accepted CLI inputs (case-insensitive) -> canonical job type.
_NORMALIZE: Final[dict[str, str]] = {
    # canonical
    "LOGIC": JOB_TYPE_LOGIC,
    "SOLVER": JOB_TYPE_SOLVER,
    "ML": JOB_TYPE_ML,
    # reasoner-type strings (common mental model)
    "PRESCRIPTIVE": JOB_TYPE_SOLVER,
    "PREDICTIVE": JOB_TYPE_ML,
}


def normalize_job_type(value: str | None) -> str:
    """Normalize a jobs `--type` value to a canonical job type.

    Canonical job types used by the Jobs gateway:
    - `LOGIC` (transactions)
    - `SOLVER` (prescriptive jobs)
    - `ML` (predictive jobs)
    """
    raw = (value or "").strip()
    if not raw:
        raise ValueError("Job type is required.")
    key = raw.upper()
    if key in _NORMALIZE:
        return _NORMALIZE[key]
    raise ValueError(f"Invalid job type {value!r}. Expected: Logic, Prescriptive, or Predictive.")


def job_type_label(value: str | None) -> str | None:
    """Return a stable CLI label for a job type-like string (best-effort).

    Accepts canonical Jobs discriminators (LOGIC/SOLVER/ML), reasoner-type
    names (PRESCRIPTIVE/PREDICTIVE), and the public labels themselves
    (Logic/Prescriptive/Predictive — case-insensitive). Falls back to the
    raw input for unknown types so callers can still display them.
    """
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    try:
        t = normalize_job_type(raw)
    except Exception:
        return raw
    return JOB_TYPE_LABELS.get(t, t)


def cli_type_label(value: str | None) -> str | None:
    """Single entry point for "type string -> user-facing CLI label".

    Tries :func:`job_type_label` first (covers Logic/Prescriptive/Predictive
    and their canonical aliases) and falls back to
    :meth:`relationalai.services.reasoners.models.ReasonerType.get_label`
    so any new reasoner types added to the service still render with their
    proper label without a CLI change.
    """
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    label = job_type_label(raw)
    if label is not None and label != raw:
        return label

    # ``ReasonerType.normalize`` is the only call here that can raise — and it
    # raises ``ValueError`` exactly for "this isn't a recognised reasoner
    # type", which is the case we want to silently fall back on. Other
    # exception types (e.g. ``ImportError`` if the services module is somehow
    # broken) indicate a real installation/environment problem and should
    # propagate so the caller's normal error handling can surface them.
    from relationalai.services.reasoners.models import ReasonerType

    try:
        return ReasonerType.get_label(ReasonerType.normalize(raw))
    except ValueError:
        return label  # raw passthrough


