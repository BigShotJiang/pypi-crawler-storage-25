"""Connection-level validation and Snowflake error → user suggestion mapping.

Used by ``rai connect`` and the connect info panel. Kept separate from the
backend-error → CLI-diagnostic chain in ``error_handlers.py`` because the two
modules don't share helpers and have different consumers.
"""

from __future__ import annotations

import re
from typing import Any


def _use_warehouse_sql(warehouse: str) -> str:
    """Build a ``USE WAREHOUSE`` statement that is injection-safe yet preserves
    Snowflake's case-insensitive unquoted-identifier semantics.

    We use Snowflake's built-in ``IDENTIFIER('...')`` construct. ``IDENTIFIER``
    is a Snowflake meta-function whose argument is parsed as a *string literal*
    (not as SQL), and which then resolves that string using the same rules as
    a bare identifier — so ``my_warehouse``, ``MY_WAREHOUSE`` and
    ``My_Warehouse`` all still resolve to the same warehouse. Because the
    argument is a string literal, the only delimiter we need to defend against
    is the single-quote that ends the literal; doubling any embedded ``'``
    keeps the literal well-formed and prevents SQL injection by design (no
    other character can break out of the literal). See:
    https://docs.snowflake.com/en/sql-reference/identifier-literal
    """
    literal = warehouse.replace("'", "''")
    return f"USE WAREHOUSE IDENTIFIER('{literal}')"


def validate_session(session: Any, warehouse: str | None = None) -> None:
    """Validate a Snowflake/Snowpark session by running a trivial query.

    Raises a :class:`RuntimeError` if the session object doesn't expose a known
    API. Caller maps the exception into a :class:`click.ClickException` for
    user output.
    """
    use_wh = _use_warehouse_sql(warehouse) if warehouse else None
    if hasattr(session, "execute"):
        cur = session.execute("select 1")
        if hasattr(cur, "fetchall"):
            cur.fetchall()
        if use_wh:
            session.execute(use_wh)
        return
    if hasattr(session, "sql"):
        out = session.sql("select 1")
        if hasattr(out, "collect"):
            out.collect()
        elif hasattr(out, "fetchall"):
            out.fetchall()
        if use_wh:
            session.sql(use_wh).collect()
        return
    raise RuntimeError(
        f"Unsupported session type {type(session).__name__!r}; expected .execute() or .sql()."
    )


# Error codes sourced from Snowflake docs and snowflake-connector-python.
_SNOWFLAKE_ERROR_SUGGESTIONS: list[tuple[str, str]] = [
    (
        r"390100|Incorrect username or password",
        "Wrong username or password (error 390100). Check 'user' and 'password' in your raiconfig.yaml.",
    ),
    (
        r"390144|JWT token is invalid",
        "JWT authentication failed (error 390144). Common causes:\n"
        "  • Wrong 'account' identifier — must match the 'iss' claim in your JWT\n"
        "  • Public key fingerprint mismatch — re-register your public key in Snowflake\n"
        "  • Clock skew > 60s — check your system clock is synced (NTP)\n"
        "  Check 'private_key_path' and 'private_key_passphrase' in raiconfig.yaml.",
    ),
    (
        r"390114|Authentication token has expired",
        "Authentication token has expired (error 390114). Refresh your token and "
        "update 'token' or 'token_file_path' in raiconfig.yaml.",
    ),
    (
        r"MFA authentication is required",
        "Your Snowflake account requires MFA but the current authenticator doesn't support it.\n"
        "Switch authenticator in raiconfig.yaml:\n"
        "  connections:\n"
        "    snowflake:\n"
        "      authenticator: programmatic_access_token\n"
        "      token: <your token>\n"
        "  or\n"
        "      authenticator: externalbrowser",
    ),
    (
        r"250001|Failed to connect to DB|Could not connect to Snowflake backend",
        "Could not reach Snowflake (error 250001). Check:\n"
        "  • 'account' identifier in raiconfig.yaml (e.g. myorg-myaccount)\n"
        "  • Network connectivity and firewall rules\n"
        "  • VPN if required by your organization",
    ),
    (
        r"002043|Object does not exist, or operation cannot be performed",
        "Warehouse not found or not accessible. Check the 'warehouse' value in raiconfig.yaml — "
        "it must exist and your role must have USAGE privilege on it.",
    ),
    (
        r"CERTIFICATE_VERIFY_FAILED|SSL|bad handshake",
        "SSL/TLS error. Your network proxy or firewall may be intercepting Snowflake traffic. "
        "Check your SSL certificates and proxy settings.",
    ),
]


def get_connection_suggestion(error_msg: str) -> str | None:
    """Return an actionable suggestion for known Snowflake error patterns."""
    for pattern, suggestion in _SNOWFLAKE_ERROR_SUGGESTIONS:
        if re.search(pattern, error_msg, re.IGNORECASE):
            return suggestion
    return None


def format_connection_info(connection: Any) -> list[tuple[str, str]]:
    """Extract key connection fields for display (preserves display order)."""
    rows: list[tuple[str, str]] = []
    for label, attr in (
        ("Type", "type"),
        ("Authenticator", "authenticator"),
        ("Account", "account"),
        ("User", "user"),
        ("Warehouse", "warehouse"),
        ("Role", "role"),
    ):
        value = getattr(connection, attr, None)
        if value:
            rows.append((label, str(value)))
    return rows
