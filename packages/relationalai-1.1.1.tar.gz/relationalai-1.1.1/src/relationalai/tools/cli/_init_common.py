"""Helpers shared between :mod:`init_wizard` and :mod:`install_init_wizard`.

Kept minimal — anything specific to one entry path stays in its own module.
"""

from __future__ import annotations

from pathlib import Path

import rich

RAICONFIG_YAML = "raiconfig.yaml"
RAICONFIG_YML = "raiconfig.yml"

DIVIDER = "[dim]" + "─" * 52 + "[/dim]"

# Substrings that mark the canonical raiconfig template as still-unfilled.
TEMPLATE_PLACEHOLDERS: frozenset[str] = frozenset(
    {"myorg-myaccount", "you@example.com", "your_password"}
)


def find_existing_yaml() -> Path | None:
    """Return path to ``raiconfig.yaml``/``raiconfig.yml`` searching upward from cwd.

    Matches the discovery behaviour of :func:`relationalai.config.create_config`.
    """
    from confocal import find_upwards

    for name in (RAICONFIG_YAML, RAICONFIG_YML):
        found = find_upwards(Path(name))
        if found:
            return found
    return None


def has_template_values(yaml_path: Path) -> bool:
    """Return ``True`` if the file still contains any known template placeholder.

    This is a deliberately cheap substring check (no YAML parse). It's used
    solely to print a friendly nudge ("you still have template values") at the
    end of ``rai init`` — it never gates real behavior. Because the placeholder
    strings (``myorg-myaccount``, ``you@example.com``, ``your_password``) are
    distinctive and only appear in the canonical template, the false-positive
    rate is acceptably low; in the worst case the user just sees the nudge a
    bit longer than they should. If we ever start using more generic
    placeholders, switch to a YAML parse and field-level check.
    """
    content = yaml_path.read_text(encoding="utf-8")
    return any(placeholder in content for placeholder in TEMPLATE_PLACEHOLDERS)


def explain_existing_yaml(yaml_path: Path, *, rerun_hint: str) -> None:
    """Validate an existing ``raiconfig.yaml`` and print a status block.

    ``rerun_hint`` should describe how the user reruns the wizard (e.g.
    ``"rai init"`` or ``"rai init --install-mode"``).
    """
    try:
        from relationalai.config import create_config

        from .init_wizard import run_explain

        run_explain(create_config())
        rich.print(f"\n{DIVIDER}")
        if has_template_values(yaml_path):
            rich.print("[yellow]⚠ Your config still contains template placeholder values.[/yellow]")
            rich.print(
                f"[dim]Edit [bold]{yaml_path}[/bold] and replace the example values with your own, "
                f"then run [bold]{rerun_hint}[/bold] again.[/dim]"
            )
        else:
            rich.print("[green]✓ You're all set![/green] Your config is valid and ready to use.")
        rich.print(f"{DIVIDER}\n")
    except Exception as e:
        rich.print(f"\n[yellow]⚠ Config has issues:[/yellow]\n{e}")
        rich.print("\n[dim]Edit your raiconfig.yaml to fix the issues above.[/dim]")
