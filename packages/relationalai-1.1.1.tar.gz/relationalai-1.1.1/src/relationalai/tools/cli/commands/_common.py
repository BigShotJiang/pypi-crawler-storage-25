"""Shared option decorators and small helpers used across command modules."""

from __future__ import annotations

import os
from collections.abc import Callable
from typing import Any, TypeVar

import click

F = TypeVar("F", bound=Callable[..., Any])

_STUBS_ENV = "RAI_CLI_ENABLE_STUBS"


def stubs_enabled() -> bool:
    """Return True when ``RAI_CLI_ENABLE_STUBS`` is set to a truthy value.

    Used by :mod:`commands.stubs` (analyze/build/deploy/explore/test/clean)
    to gate not-yet-implemented placeholder commands so they don't show up
    in help (or auto-generated docs) by default and can't be relied on in
    tests. Exposed at this level so other command modules can adopt the
    same gating convention if/when they grow placeholders.
    """
    return os.environ.get(_STUBS_ENV, "").strip().lower() not in ("", "0", "false", "no")


def wait_options(*, default_timeout_s: int = 900) -> Callable[[F], F]:
    """Attach ``--wait`` and ``--timeout-s`` options to a command."""

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--timeout-s",
            type=int,
            default=default_timeout_s,
            show_default=True,
            help="Timeout in seconds while waiting until the reasoner is READY (used with --wait).",
        )(cmd)
        cmd = click.option(
            "--wait",
            is_flag=True,
            help="Wait until the reasoner is READY before returning.",
        )(cmd)
        return cmd

    return decorator


def job_wait_options(*, default_timeout_s: float = 900.0, default_poll_s: float = 0.5) -> Callable[[F], F]:
    """``--timeout-s`` + ``--poll-interval-s`` options for job wait-style commands."""

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--poll-interval-s",
            type=float,
            default=default_poll_s,
            show_default=True,
            help="Polling interval in seconds while waiting until the job reaches a terminal state.",
        )(cmd)
        cmd = click.option(
            "--timeout-s",
            type=float,
            default=default_timeout_s,
            show_default=True,
            help="Timeout in seconds while waiting until the job reaches a terminal state.",
        )(cmd)
        return cmd

    return decorator


def job_options_type_id(
    *,
    type_required: bool = False,
    id_required: bool = False,
) -> Callable[[F], F]:
    """``--type`` + ``--id`` options shared by every jobs command."""

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--id",
            "job_id",
            required=id_required,
            default=None,
            help="Job id." if id_required else "Job id (optional).",
        )(cmd)
        cmd = click.option(
            "--type",
            "job_type",
            required=type_required,
            default=None,
            help="Job type (Logic/Prescriptive/Predictive)." + ("" if type_required else " (optional)"),
        )(cmd)
        return cmd

    return decorator


# ── Reusable params() functions for ``handle_cli_errors`` ────────────────────


def select_params(*keys: str, **aliases: str) -> Callable[..., dict[str, Any]]:
    """Build a ``params=`` callback that picks ``kwargs`` values into a fixed dict.

    Each positional ``key`` is copied verbatim; each ``alias=src`` entry maps
    ``kwargs[src]`` to the output key ``alias`` (used to expose
    ``job_type`` as ``reasoner_type`` in error context).
    """

    def _extract(**kwargs: Any) -> dict[str, Any]:
        out: dict[str, Any] = {k: kwargs.get(k) for k in keys}
        out.update({dst: kwargs.get(src) for dst, src in aliases.items()})
        return out

    return _extract


# Pre-built selectors used by command modules; keep the names stable so
# renames of a command's kwargs break loudly.
params_reasoner_type_name = select_params("reasoner_type", "reasoner_name")
params_reasoner_type_name_size = select_params("reasoner_type", "reasoner_name", "reasoner_size")
params_reasoner_type_name_auto_suspend = select_params(
    "reasoner_type", "reasoner_name", "auto_suspend_mins"
)
params_job_type_id = select_params("job_type", "job_id")
params_jobs_list = select_params(
    "job_id", "state", "name", "created_by", reasoner_type="job_type"
)
params_job_events = select_params("job_type", "job_id", "stream_name")
