"""Private helpers scoped to ``commands/reasoners.py``.

Kept in a sibling module so the command module stays focused on Click wiring.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

import click

from .. import runtime
from ..flows import ensure_reasoner_name, ensure_reasoner_type, select_reasoner
from ..markup import tip

F = TypeVar("F", bound=Callable[..., Any])


def reasoner_options_type_name(
    *,
    type_help: str = "Reasoner type (Logic/Prescriptive/Predictive) (optional).",
    name_help: str = "Reasoner name (optional).",
) -> Callable[[F], F]:
    """``--type`` / ``--name`` options shared by every reasoner command."""

    def decorator(cmd: F) -> F:
        cmd = click.option("--type", "reasoner_type", required=False, default=None, help=type_help)(cmd)
        cmd = click.option("--name", "reasoner_name", required=False, default=None, help=name_help)(cmd)
        return cmd

    return decorator


reasoner_options_type_name_filter = reasoner_options_type_name(
    type_help="Reasoner type filter (Logic/Prescriptive/Predictive) (optional).",
    name_help="Reasoner name (optional).",
)
reasoner_options_type_name_direct = reasoner_options_type_name(
    type_help="Reasoner type (Logic/Prescriptive/Predictive) (optional).",
    name_help="Reasoner name (optional).",
)


def print_reasoner_async_operation_started(
    *,
    verb: str,
    operation_id: str,
    t_label: str,
    name: str,
) -> None:
    """Print the standard "operation accepted, running in background" message."""
    runtime.console.print(f"[green]{verb}: OK[/green] (operation_id={operation_id})")
    runtime.console.print("")
    if verb == "create":
        runtime.console.print("Reasoner creation has started and will continue in the background.")
    else:
        runtime.console.print("Reasoner resume has started and will continue in the background.")
    runtime.console.print(f"Check status: [green]rai reasoners:get --type {t_label} --name {name}[/green]")
    runtime.console.print(tip("use [cyan]--wait[/cyan] flag to block until reasoner is in READY status."))


def _require_reasoner_identity_non_interactive(
    *,
    reasoner_type: str | None,
    reasoner_name: str | None,
    interactive: bool,
) -> None:
    if interactive:
        return
    if not (reasoner_type or "").strip():
        raise click.ClickException("Reasoner type is required. Use --type.")
    if not (reasoner_name or "").strip():
        raise click.ClickException("Reasoner name is required. Use --name.")


def resolve_reasoner_target(
    reasoners: Any,
    *,
    reasoner_type: str | None,
    reasoner_name: str | None,
    interactive: bool,
    prompt: str,
    state: str | None = None,
    exclude_states: set[str] | None = None,
) -> tuple[str, str, str] | None:
    """Resolve a reasoner target to ``(normalized_type, display_label, name)``."""
    _require_reasoner_identity_non_interactive(
        reasoner_type=reasoner_type,
        reasoner_name=reasoner_name,
        interactive=interactive,
    )

    if reasoner_name and not reasoner_type:
        t_norm, t_label = ensure_reasoner_type(None, interactive=interactive, console=runtime.console)
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        return t_norm, t_label, name

    if reasoner_type and reasoner_name:
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=runtime.console)
        # Funnel through ``ensure_reasoner_name`` so whitespace stripping and
        # validation match the other branches before we hit the backend.
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        return t_norm, t_label, name

    picked = select_reasoner(
        reasoners,
        reasoner_type=reasoner_type,
        reasoner_name=reasoner_name,
        state=state,
        exclude_states=exclude_states,
        interactive=interactive,
        console=runtime.console,
        prompt=prompt,
    )
    if picked is None:
        return None

    r_type, r_name = picked
    t_norm, t_label = ensure_reasoner_type(r_type, interactive=interactive, console=runtime.console)
    return t_norm, t_label, r_name


def reasoner_with_state(
    *,
    reasoner: Any | None,
    reasoner_type: str,
    reasoner_name: str,
    state: str,
) -> dict[str, Any]:
    """Return a displayable reasoner-like mapping with an overridden state."""
    data: dict[str, Any] = {
        "name": reasoner_name,
        "type": reasoner_type,
        "state": state,
    }
    if reasoner is not None:
        for key in (
            "id",
            "name",
            "type",
            "size",
            "state",
            "created_by",
            "created_on",
            "updated_on",
            "auto_suspend_mins",
            "suspends_at",
            "settings",
        ):
            value = getattr(reasoner, key, None)
            if value is not None:
                data[key] = value
        data["state"] = state
    return data
