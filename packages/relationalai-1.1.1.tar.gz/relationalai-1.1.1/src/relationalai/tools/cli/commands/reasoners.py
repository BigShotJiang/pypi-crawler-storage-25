"""``rai reasoners:*`` commands."""

from __future__ import annotations

from typing import Any

import click

from ....util.docutils import include_in_docs
from .. import runtime
from ..display import show_reasoner, show_reasoner_detail, show_reasoners
from ..errors import handle_cli_errors, set_error_params
from ..flows import ensure_reasoner_name, ensure_reasoner_size, ensure_reasoner_type
from ..render import PaginationInfo, build_filter_args, render_detail, render_list
from ..serialize import reasoner_record_as_json
from ._common import (
    params_reasoner_type_name,
    params_reasoner_type_name_auto_suspend,
    params_reasoner_type_name_size,
    wait_options,
)
from ._reasoners_helpers import (
    print_reasoner_async_operation_started,
    reasoner_options_type_name_direct,
    reasoner_options_type_name_filter,
    reasoner_with_state,
    resolve_reasoner_target,
)


def register(cli: click.Group) -> None:
    _register_create(cli)
    _register_delete(cli)
    _register_alter(cli)
    _register_suspend(cli)
    _register_resume(cli)
    _register_list(cli)
    _register_get(cli)


# ── reasoners:create ─────────────────────────────────────────────────────────


def _register_create(cli: click.Group) -> None:
    @cli.command(name="reasoners:create")
    @click.option(
        "--type",
        "reasoner_type",
        required=False,
        default=None,
        help="Reasoner type (Logic / Prescriptive / Predictive). If omitted, you'll be prompted to select.",
    )
    @click.option(
        "--name",
        "reasoner_name",
        default=None,
        help="Reasoner name. If omitted, you'll be prompted to enter one.",
    )
    @click.option(
        "--size",
        "reasoner_size",
        default=None,
        help="Reasoner size. If omitted, you can choose (or use config default).",
    )
    @click.option(
        "--auto-suspend-mins",
        type=int,
        default=None,
        help="Auto-suspend after N minutes of inactivity (optional).",
    )
    @click.option(
        "--await-storage-vacuum/--no-await-storage-vacuum",
        default=None,
        help="Wait for storage vacuum work before suspending the reasoner (use "
             "--await-storage-vacuum to enable, --no-await-storage-vacuum to disable).",
    )
    @wait_options(default_timeout_s=900)
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:create",
        message="Failed to create reasoner.",
        click_message="Reasoners create failed.",
        params=params_reasoner_type_name_size,
    )
    def reasoners_create(
        reasoner_type: str | None,
        reasoner_name: str | None,
        reasoner_size: str | None,
        auto_suspend_mins: int | None,
        await_storage_vacuum: bool | None,
        timeout_s: int,
        wait: bool,
    ) -> None:
        """Create a reasoner."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()

        # Step-by-step resolution. Each step stashes the latest resolved values
        # on the Click context so `handle_cli_errors` can include them even if
        # a later step fails.
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=runtime.console)
        set_error_params({"reasoner_type": t_norm, "reasoner_name": reasoner_name, "reasoner_size": reasoner_size})

        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        set_error_params({"reasoner_type": t_norm, "reasoner_name": name, "reasoner_size": reasoner_size})

        with runtime.cli_connect_sync(config) as client:
            size = ensure_reasoner_size(
                client.reasoners, reasoner_size, interactive=interactive, console=runtime.console
            )
            set_error_params({"reasoner_type": t_norm, "reasoner_name": name, "reasoner_size": size})

            size_display = size or "default"
            if wait:
                reasoner = runtime.run_with_spinner(
                    f"Creating {t_label} reasoner '{name}' (size {size_display})... (may take a few minutes)",
                    lambda: client.reasoners.create_ready(
                        reasoner_type=t_norm,
                        reasoner_name=name,
                        reasoner_size=size,
                        auto_suspend_mins=auto_suspend_mins,
                        await_storage_vacuum=await_storage_vacuum,
                        timeout_s=timeout_s,
                    ),
                )
                show_reasoner(reasoner)
                return

            op = runtime.run_with_spinner(
                f"Starting {t_label} reasoner create for '{name}' (size {size_display})...",
                lambda: client.reasoners.create(
                    reasoner_type=t_norm,
                    reasoner_name=name,
                    reasoner_size=size,
                    auto_suspend_mins=auto_suspend_mins,
                    await_storage_vacuum=await_storage_vacuum,
                    settings=None,
                ),
            )
            print_reasoner_async_operation_started(
                verb="create", operation_id=op.id, t_label=t_label, name=name
            )


# ── reasoners:delete ─────────────────────────────────────────────────────────


def _register_delete(cli: click.Group) -> None:
    @cli.command(name="reasoners:delete")
    @reasoner_options_type_name_filter
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:delete",
        message="Failed to delete reasoner.",
        click_message="Reasoners delete failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_delete(reasoner_type: str | None, reasoner_name: str | None) -> None:
        """Delete a reasoner."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                prompt="Select a reasoner to delete:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved

            def _delete() -> Any:
                before = client.reasoners.get(reasoner_type=t_norm, reasoner_name=name)
                client.reasoners.delete(reasoner_type=t_norm, reasoner_name=name)
                return before

            before = runtime.run_with_spinner(f"Deleting {t_label} reasoner '{name}'...", _delete)
        show_reasoner(
            reasoner_with_state(
                reasoner=before, reasoner_type=t_norm, reasoner_name=name, state="DELETED"
            )
        )


# ── reasoners:alter ──────────────────────────────────────────────────────────


def _register_alter(cli: click.Group) -> None:
    @cli.command(name="reasoners:alter", short_help="Alter a reasoner's settings.")
    @reasoner_options_type_name_direct
    @click.option(
        "--auto-suspend-mins",
        type=int,
        default=None,
        help="New auto-suspend timeout in minutes.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:alter",
        message="Failed to alter reasoner.",
        click_message="Reasoners alter failed.",
        params=params_reasoner_type_name_auto_suspend,
    )
    def reasoners_alter(
        reasoner_type: str | None,
        reasoner_name: str | None,
        auto_suspend_mins: int | None,
    ) -> None:
        """Alter a reasoner's settings (e.g. auto-suspend timeout)."""
        if auto_suspend_mins is None:
            raise click.UsageError("At least one setting to alter must be provided (e.g. --auto-suspend-mins).")

        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                prompt="Select a reasoner to alter:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved
            runtime.run_with_spinner(
                f"Altering {t_label} reasoner '{name}'...",
                lambda: client.reasoners.alter_auto_suspend_mins(
                    reasoner_type=t_norm,
                    reasoner_name=name,
                    auto_suspend_mins=auto_suspend_mins,
                ),
            )
            r = client.reasoners.get(reasoner_type=t_norm, reasoner_name=name)
            show_reasoner(r)


# ── reasoners:suspend ────────────────────────────────────────────────────────


def _register_suspend(cli: click.Group) -> None:
    @cli.command(name="reasoners:suspend")
    @reasoner_options_type_name_filter
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:suspend",
        message="Failed to suspend reasoner.",
        click_message="Reasoners suspend failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_suspend(reasoner_type: str | None, reasoner_name: str | None) -> None:
        """Suspend a reasoner."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                exclude_states={"SUSPENDED"},
                prompt="Select a reasoner to suspend:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved

            def _suspend() -> Any:
                client.reasoners.suspend(reasoner_type=t_norm, reasoner_name=name)
                return client.reasoners.get(reasoner_type=t_norm, reasoner_name=name)

            r_after = runtime.run_with_spinner(f"Suspending {t_label} reasoner '{name}'...", _suspend)
        show_reasoner(
            reasoner_with_state(
                reasoner=r_after, reasoner_type=t_norm, reasoner_name=name, state="SUSPENDED"
            )
        )


# ── reasoners:resume ─────────────────────────────────────────────────────────


def _register_resume(cli: click.Group) -> None:
    @cli.command(name="reasoners:resume")
    @reasoner_options_type_name_filter
    @wait_options(default_timeout_s=900)
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:resume",
        message="Failed to resume reasoner.",
        click_message="Reasoners resume failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_resume(
        reasoner_type: str | None,
        reasoner_name: str | None,
        timeout_s: int,
        wait: bool,
    ) -> None:
        """Resume a reasoner."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                state="SUSPENDED",
                prompt="Select a reasoner to resume:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved
            _resume_one(
                client=client,
                t_norm=t_norm,
                t_label=t_label,
                name=name,
                wait=wait,
                timeout_s=timeout_s,
            )


def _resume_one(
    *,
    client: Any,
    t_norm: str,
    t_label: str,
    name: str,
    wait: bool,
    timeout_s: int,
) -> None:
    if wait:
        r = runtime.run_with_spinner(
            f"Resuming {t_label} reasoner '{name}'... (may take a few minutes)",
            lambda: client.reasoners.resume_ready(
                reasoner_type=t_norm, reasoner_name=name, timeout_s=timeout_s
            ),
        )
        show_reasoner(r)
        return

    op = runtime.run_with_spinner(
        f"Starting {t_label} reasoner resume for '{name}'...",
        lambda: client.reasoners.resume(reasoner_type=t_norm, reasoner_name=name),
    )
    print_reasoner_async_operation_started(
        verb="resume", operation_id=op.id, t_label=t_label, name=name
    )

    r = runtime.run_with_spinner(
        f"Fetching {t_label} reasoner '{name}'...",
        lambda: client.reasoners.get(reasoner_type=t_norm, reasoner_name=name),
    )
    show_reasoner(
        reasoner_with_state(
            reasoner=r, reasoner_type=t_norm, reasoner_name=name, state="PENDING"
        )
    )


# ── reasoners:list ───────────────────────────────────────────────────────────


def _register_list(cli: click.Group) -> None:
    @cli.command(name="reasoners:list")
    @click.option("--type", "reasoner_type", required=False, default=None,
                  help="Filter by reasoner type (Logic/Prescriptive/Predictive) (optional).")
    @click.option("--name", "reasoner_name", required=False, default=None, help="Filter by reasoner name (optional).")
    @click.option("--size", "reasoner_size", required=False, default=None, help="Filter by reasoner size (optional).")
    @click.option("--state", required=False, default=None, help="Filter by reasoner state (optional).")
    @click.option("--created-by", "created_by", required=False, default=None,
                  help="Filter by creator username (optional).")
    @click.option(
        "--limit",
        type=click.IntRange(min=1),
        default=100,
        show_default=True,
        help="Maximum results to display (must be >= 1).",
    )
    @click.option(
        "--offset",
        type=click.IntRange(min=0),
        default=0,
        show_default=True,
        help="Number of results to skip.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:list",
        message="Failed to list reasoners.",
        click_message="Reasoners list failed.",
    )
    def reasoners_list(
        reasoner_type: str | None,
        reasoner_name: str | None,
        reasoner_size: str | None,
        state: str | None,
        created_by: str | None,
        limit: int,
        offset: int,
    ) -> None:
        """List reasoners with optional filters."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()

        t_norm: str | None = None
        t_label: str | None = None
        raw_type = (reasoner_type or "").strip()
        if raw_type:
            t_norm, t_label = ensure_reasoner_type(raw_type, interactive=interactive, console=runtime.console)

        with runtime.cli_connect_sync(config) as client:
            msg = "Fetching reasoners..." if not t_label else f"Fetching {t_label.lower()} reasoners..."
            items = runtime.run_with_spinner(
                msg,
                lambda: client.reasoners.list(
                    state=state,
                    reasoner_name=reasoner_name,
                    reasoner_type=t_norm,
                    reasoner_size=reasoner_size,
                    created_by=created_by,
                    limit=limit,
                    offset=offset,
                ),
            )

        filter_args = build_filter_args(
            [
                ("--type", t_label),
                ("--name", reasoner_name),
                ("--size", reasoner_size),
                ("--state", state),
                ("--created-by", created_by),
            ]
        )

        render_list(
            items,
            json_key="reasoners",
            json_mapper=reasoner_record_as_json,
            renderer=show_reasoners,
            empty_message="[yellow]No reasoners found.[/yellow]",
            pagination=PaginationInfo(
                limit=limit,
                offset=offset,
                command="reasoners:list",
                filter_args=filter_args,
            ),
        )


# ── reasoners:get ────────────────────────────────────────────────────────────


def _register_get(cli: click.Group) -> None:
    @cli.command(name="reasoners:get")
    @reasoner_options_type_name_direct
    @include_in_docs
    @handle_cli_errors(
        name="reasoners:get",
        message="Failed to get reasoner.",
        click_message="Reasoners get failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_get(reasoner_type: str | None, reasoner_name: str | None) -> None:
        """Get a reasoner by type and name."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=runtime.console)
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)

        with runtime.cli_connect_sync(config) as client:
            r = runtime.run_with_spinner(
                f"Fetching {t_label} reasoner '{name}'...",
                lambda: client.reasoners.get(reasoner_type=t_norm, reasoner_name=name),
            )

        render_detail(
            r,
            json_key="reasoner",
            json_mapper=reasoner_record_as_json,
            renderer=show_reasoner_detail,
            not_found_message="[yellow]Reasoner not found.[/yellow]",
        )
