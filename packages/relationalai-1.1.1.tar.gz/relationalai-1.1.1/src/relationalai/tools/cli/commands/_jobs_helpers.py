"""Private helpers scoped to ``commands/jobs.py``."""

from __future__ import annotations

import json
from typing import Any, TYPE_CHECKING

import click

from relationalai.services.jobs.util import JobIncludeDict

from .. import runtime
from ..display import show_job
from ..flows import select_job
from ..job_types import job_type_label
from ..markup import tip

if TYPE_CHECKING:
    from relationalai.config.config import Config


# ── Background-operation messaging ───────────────────────────────────────────


def print_job_background_instructions(
    *,
    job_type_label: str,
    job_id: str,
    created: bool = True,
) -> None:
    if created:
        runtime.console.print("")
        runtime.console.print("Job started and will continue running in the background.")
    runtime.console.print(
        f"Wait for completion: [green]rai jobs:wait --type {job_type_label} --id {job_id}[/green]"
    )
    runtime.console.print(tip("use [cyan]--wait[/cyan] flag to block until job is in COMPLETED state."))


# ── Job ``--include`` helpers ────────────────────────────────────────────────


def job_include_from_flags(includes: tuple[str, ...]) -> JobIncludeDict | None:
    """Convert repeated ``--include`` flags into a typed :class:`JobIncludeDict`."""
    if not includes:
        return None

    inc: JobIncludeDict = {}
    for k in includes:
        match str(k).strip().lower():
            case "details":
                inc["details"] = True
            case "events":
                inc["events"] = True
            case "artifacts":
                inc["artifacts"] = True
            case "problems":
                inc["problems"] = True
            case "raw":
                inc["raw"] = True
    return inc


def job_get_include_from_flags(includes: tuple[str, ...]) -> JobIncludeDict:
    """Include dict for ``jobs:get``: always includes ``details``."""
    extra = job_include_from_flags(includes)
    return {**(extra or {}), "details": True}


# ── Job identity resolution ──────────────────────────────────────────────────


def ensure_job_identity(
    jobs: Any,
    *,
    config: "Config",
    job_type: str | None,
    job_id: str | None,
    interactive: bool,
    prompt: str,
    only_active: bool = False,
) -> tuple[str, str] | None:
    """Return ``(job_type, job_id)`` for a job, prompting when needed."""
    jtype = job_type
    jid = job_id

    if jid and not (jtype and str(jtype).strip()):
        xs: list[Any] = []
        try:
            xs = jobs.list(None, job_id=jid, limit=5)
        except Exception:
            xs = []
        if len(xs) == 1:
            jtype = getattr(xs[0], "reasoner_type", None)
        elif len(xs) > 1 and interactive:
            picked = select_job(
                jobs,
                config=config,
                reasoner_type=None,
                job_id=jid,
                interactive=interactive,
                console=runtime.console,
                prompt=prompt,
                only_active=only_active,
            )
            if picked is None:
                return None
            jtype, jid = picked

    if not (jtype and str(jtype).strip() and jid and str(jid).strip()):
        if not interactive:
            raise click.ClickException("--type and --id are required (or run interactively).")
        picked = select_job(
            jobs,
            config=config,
            reasoner_type=jtype,
            job_id=jid,
            interactive=interactive,
            console=runtime.console,
            prompt=prompt,
            only_active=only_active,
        )
        if picked is None:
            return None
        jtype, jid = picked

    t_public = job_type_label(str(jtype)) or str(jtype)
    return str(t_public), str(jid)


# ── jobs:create payload helpers ──────────────────────────────────────────────


def parse_json_object(
    text: str | None, *, flag: str, allow_missing: bool = False
) -> dict[str, Any] | None:
    """Decode JSON and require it to be an object (dict)."""
    if text is None:
        if allow_missing:
            return None
        raise click.ClickException(f"{flag} is required but was not provided.")
    try:
        value = json.loads(text or "{}")
    except json.JSONDecodeError as e:
        raise click.ClickException(f"{flag} must be valid JSON. {e}") from e
    if not isinstance(value, dict):
        raise click.ClickException(f"{flag} must decode to a JSON object (dict).")
    return value


def prompt_missing_logic_fields(
    *,
    t_public: str,
    raw_code: str | None,
    database: str | None,
    payload_override: dict[str, Any],
    interactive: bool,
) -> tuple[str | None, str | None]:
    """Prompt for ``raw_code`` / ``database`` when missing and interactive."""
    from ..components import text_prompt

    if raw_code is None and payload_override == {}:
        if interactive:
            raw_code = text_prompt("Raw code:", default=None)
            runtime.console.print()
        else:
            raise click.ClickException(
                "No payload provided. Pass `--payload-json '{...}'` or provide `--raw-code` "
                "(and `--database` for Logic)."
            )

    if str(t_public).strip().lower() == "logic" and raw_code is not None and not database:
        if interactive:
            database = text_prompt("Database:", default=None)
            runtime.console.print()
        else:
            raise click.ClickException(
                "--database is required for Logic when using --raw-code/--raw-code-file."
            )

    return raw_code, database


def build_payload(
    *,
    t_public: str,
    database: str | None,
    raw_code: str | None,
    inputs: dict[str, Any] | None,
    headers: dict[str, Any] | None,
    language: str,
    readonly: bool,
    timeout_mins: int | None,
    bypass_index: bool,
    gi_setup_skipped: bool,
    payload_override: dict[str, Any],
) -> dict[str, Any]:
    from relationalai.services.jobs.util import compose_payload

    composed: dict[str, Any] = {}
    if raw_code is not None:
        composed = compose_payload(
            reasoner_type=t_public,
            database=database,
            raw_code=raw_code,
            inputs=inputs,
            readonly=bool(readonly),
            language=language,
            headers=headers,
            timeout_mins=timeout_mins,
            bypass_index=bool(bypass_index),
            gi_setup_skipped=bool(gi_setup_skipped),
        )

    payload = dict(composed)
    payload.update(payload_override)
    return payload


def submit_and_maybe_wait(
    *,
    client: Any,
    t_public: str,
    t_label: str,
    reasoner_name_norm: str,
    payload: dict[str, Any],
    timeout_mins: int | None,
    wait: bool,
    timeout_s: float,
    poll_interval_s: float,
) -> None:
    def _create() -> str:
        op = client.jobs.create(t_public, reasoner_name_norm, payload, timeout_mins=timeout_mins)
        return op.id

    op_id = runtime.run_with_spinner(
        f"Starting {t_label} job on reasoner '{reasoner_name_norm}'...",
        _create,
    )
    if not op_id:
        raise click.ClickException("Job create did not return an id.")

    if not wait:
        job = runtime.run_with_spinner(
            f"Fetching job {op_id}...",
            lambda: client.jobs.get(str(t_public), str(op_id), include=None),
        )
        if job is None:
            runtime.console.print(f"[green]create: OK[/green] (id={op_id})")
        else:
            show_job(job)
        print_job_background_instructions(job_type_label=t_label, job_id=op_id, created=True)
        return

    job_result = runtime.run_with_spinner(
        f"Waiting for job {op_id}...",
        lambda: client.jobs.wait(
            str(t_public),
            str(op_id),
            timeout_s=float(timeout_s),
            poll_interval_s=float(poll_interval_s),
        ),
    )
    show_job(job_result)
    state = str(getattr(job_result, "state", "") or "").upper()
    if state and state not in {"COMPLETED", "SUCCEEDED"}:
        raise click.ClickException(f"Job finished in state {state}.")
