"""CLI command modules.

Each module defines a group of related ``@cli.command(...)`` callbacks and
exposes a ``register(cli)`` function that attaches them to the root Click
group. :func:`register_all` wires every subgroup in one call.
"""

from __future__ import annotations

import click

from . import (
    connect as connect_cmd,
    debugger as debugger_cmd,
    docs as docs_cmd,
    init as init_cmd,
    jobs as jobs_cmd,
    models as models_cmd,
    reasoners as reasoners_cmd,
    stubs as stubs_cmd,
)


def register_all(cli: click.Group) -> None:
    """Attach every command module's commands to ``cli``."""
    connect_cmd.register(cli)
    init_cmd.register(cli)
    reasoners_cmd.register(cli)
    jobs_cmd.register(cli)
    models_cmd.register(cli)
    docs_cmd.register(cli)
    debugger_cmd.register(cli)
    stubs_cmd.register(cli)


__all__ = ["register_all"]
