"""Hidden placeholder commands (analyze/build/deploy/explore/test/clean).

These are parked behind ``RAI_CLI_ENABLE_STUBS`` so they don't appear in help
by default and can't accidentally be relied on in tests. Set
``RAI_CLI_ENABLE_STUBS=1`` to expose them while iterating on real
implementations.
"""

from __future__ import annotations

from collections.abc import Callable

import click

from .. import runtime
from ._common import stubs_enabled


def register(cli: click.Group) -> None:
    if not stubs_enabled():
        return

    for cmd_name, doc, printed in (
        ("analyze", "Check for errors, warnings, and performance issues in the models.", "analyze"),
        ("build", "Create artifacts, show compilation errors, and produce SQL for the models.", "build"),
        ("deploy", "Deploy models/views to the database and produce SQL for execution.", "deploy"),
        ("explore", "Model explorer for visualization of data.", "explore"),
        ("test", "Run constraints and tests.", "test"),
    ):

        def _make(line: str) -> Callable[[], None]:
            def _stub() -> None:
                runtime.console.print(line)

            return _stub

        stub_fn = _make(printed)
        stub_fn.__doc__ = doc
        stub_fn.__name__ = str(cmd_name)
        cli.command(hidden=True, name=cmd_name)(stub_fn)

    @cli.command(hidden=True)
    @click.option("--uninstall", is_flag=True, help="Nukes the database")
    def clean(uninstall: bool) -> None:
        """Clean up build folder and remove artifacts."""
        runtime.console.print("clean")
