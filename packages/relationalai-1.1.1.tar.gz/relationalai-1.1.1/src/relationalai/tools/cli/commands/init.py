"""``rai init`` and ``rai config:explain``."""

from __future__ import annotations

import click

from ....util.docutils import include_in_docs
from .. import runtime


def register(cli: click.Group) -> None:
    @cli.command()
    @click.option("--migrate", is_flag=True, default=False, help="Migrate raiconfig.toml to raiconfig.yaml immediately.")
    @click.option(
        "--install-mode",
        "install_mode",
        is_flag=True,
        default=False,
        hidden=True,
        help="Scaffold a new install-mode starter project.",
    )
    @include_in_docs
    def init(migrate: bool, install_mode: bool) -> None:
        """Create or validate raiconfig.yaml."""
        if install_mode:
            from ..install_init_wizard import run_install_wizard
            run_install_wizard()
            return
        from ..init_wizard import run_init_wizard
        run_init_wizard(migrate=migrate)

    @cli.command(name="config:explain", short_help="Show the active config and provenance.")
    @click.option("--verbose", "-v", is_flag=True, default=False, help="Show full provenance details.")
    @include_in_docs
    def config_explain(verbose: bool) -> None:
        """Show the active config and where each value comes from."""
        from ..init_wizard import run_explain
        config = runtime.load_config()
        run_explain(config, verbose=verbose)
