"""Private helpers scoped to ``commands/models.py``."""

from __future__ import annotations

from .. import runtime

import click
import importlib.util
from pathlib import Path
import sys

# TODO: potentially move this into a services/models module
def install_model(model_file_path: Path|None=None, model_name: str|None=None, schema: str|None=None, force: bool|None=None) -> None:
    """Install a model from a Python file."""
    config = runtime.load_config()
    path_str = model_file_path or config.model.model_file_path
    if path_str is None:
        raise click.ClickException("Model file path is required (positional argument or config.model.model_file_path).")

    path = Path(path_str)
    if path.is_dir():
        # if path is a directory, load it as a package
        # add the parent directory to sys.path so Python knows the package context
        parent = str(path.parent)
        if parent not in sys.path:
            sys.path.insert(0, parent)

        # import the package
        importlib.import_module(path.name)
    else:
        # if path is a file, load it as a module
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load model from {path}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

    # now find the desired model (either by name or last one)
    from relationalai.semantics import Model
    if model_name is not None:
        model = next((m for m in Model.all_models if m.name == model_name), None)
        if model is None:
            raise ValueError(f"Model named '{model_name}' not found.")
    elif Model.all_models:
        model = Model.all_models[-1]
    else:
        raise ValueError("No models found to install.")

    # now execute the install with a spinner
    from ..components import WaitSpinner
    with WaitSpinner(f"Installing model '{model.name}'...", f"Model '{model.name}' installed!"):
        # TODO: deal with schema and force (may need to add to config)
        model._get_executor().install(model)
