"""``rai debugger`` command."""

from __future__ import annotations

from pathlib import Path

import click

from ....util.docutils import include_in_docs


def register(cli: click.Group) -> None:
    @cli.command()
    @click.argument(
        "file",
        required=False,
        default=None,
        metavar="[FILE]",
        type=click.Path(exists=True, dir_okay=False, path_type=Path),
    )
    @click.option("--host", default="0.0.0.0", show_default=True, help="Host to bind to.")
    @click.option("--port", "-p", default=8080, show_default=True, type=int, help="Port to listen on.")
    @include_in_docs
    def debugger(file: Path | None, host: str, port: int) -> None:
        """Launch the PyRel debugger UI."""
        import sys

        try:
            from relationalai.tools import rai_debugger
        except ImportError as e:
            if "nicegui" not in str(e).lower():
                raise
            raise click.ClickException(
                "nicegui is required for the debugger. "
                "Install it with: pip install relationalai[debugger]"
            )

        # NiceGUI rebuilds pages by calling runpy.run_path(sys.argv[0], run_name='__main__').
        # We must point sys.argv[0] at rai_debugger.py so NiceGUI re-runs that script
        # instead of the `rai` CLI entry point (which would crash on re-execution).
        orig_argv = sys.argv[:]
        sys.argv = [rai_debugger.__file__] + ([str(file)] if file else [])
        try:
            rai_debugger.main(host=host, port=port, file2=file)
        finally:
            sys.argv = orig_argv
