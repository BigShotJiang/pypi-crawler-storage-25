"""``rai models:*`` commands.

Only ``models:install`` is real today; the other commands are placeholder
scaffolds that print "Not implemented".

All commands in this group — including ``models:install`` — are registered
with ``hidden=True`` because the ``models:*`` surface is still being
designed and we don't want any of it to show up in ``rai --help`` while
that's in flight. The ``@include_in_docs`` decorator is what gates
inclusion in auto-generated docs: it's applied only to the real commands
so the docs don't advertise placeholders as features. When a placeholder
becomes real, drop ``hidden=True`` (or remove all of them at once when
the surface is ready) and add ``@include_in_docs`` to the corresponding
command.
"""

from __future__ import annotations

from pathlib import Path
import click

from ....util.docutils import include_in_docs
from .. import runtime
from ._models_helpers import install_model


def register(cli: click.Group) -> None:
    @cli.command(name="models:install", hidden=True)
    @click.option("--model-file-path", default=None, type=click.Path(exists=True, dir_okay=False, path_type=Path),
        help="Path to the model file to install. If omitted, will use the model_file_path from the config file."
    )
    @click.option("--name", "model_name", default=None,
        help="Name of the model to install. If omitted, will install the last model created by the target.",
    )
    @click.option("--schema", required=False, default=None,
        help="Target schema to install the model to (defaults to schema from the config file)."
    )
    @click.option("--force", is_flag=True, default=False, help="Force install, overriding divergence checks.")
    @include_in_docs
    def models_install(model_file_path: Path|None, model_name: str|None, schema: str|None, force: bool):
        """Install a model into a schema."""
        install_model(model_file_path, model_name, schema, force)

    @cli.command(name="models:list", hidden=True)
    @click.option(
        "--limit",
        type=click.IntRange(min=1),
        default=100,
        show_default=True,
        help="Maximum results to display (must be >= 1).",
    )
    @click.option(
        "--offset",
        type=click.IntRange(min=0),
        default=0,
        show_default=True,
        help="Number of results to skip.",
    )
    def models_list(limit: int, offset: int) -> None:
        """List model schemas."""
        runtime.console.print("[yellow]Not implemented[/yellow]")

    @cli.command(name="models:pull", hidden=True)
    def models_pull() -> None:
        """Pull remote model changes into the local shared model file."""
        runtime.console.print("[yellow]Not implemented[/yellow]")

    @cli.command(name="models:branch", hidden=True)
    @click.argument("name")
    @click.option("--ref", default=None, help="Source schema to branch from (defaults to current schema).")
    @click.option("--static", is_flag=True, default=False, help="Create a static (frozen) branch instead of live.")
    def models_branch(name: str, ref: str | None, static: bool) -> None:
        """Create a new model branch (schema)."""
        runtime.console.print("[yellow]Not implemented[/yellow]")

    @cli.command(name="models:switch", hidden=True)
    @click.argument("name")
    def models_switch(name: str) -> None:
        """Switch the current schema to a different model schema."""
        runtime.console.print("[yellow]Not implemented[/yellow]")

    @cli.command(name="models:delete", hidden=True)
    @click.argument("name")
    @click.option("--force", is_flag=True, default=False, help="Force delete even with downstream branches.")
    def models_delete(name: str, force: bool) -> None:
        """Delete a model schema."""
        runtime.console.print("[yellow]Not implemented[/yellow]")

    @cli.command(name="models:dump", hidden=True)
    def models_dump() -> None:
        """Dump a semantic model."""
        runtime.console.print("[yellow]Not implemented[/yellow]")
