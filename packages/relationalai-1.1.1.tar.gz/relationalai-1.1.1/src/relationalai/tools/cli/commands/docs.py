"""``rai docs`` subgroup (hidden).

The heavy lifting lives in :mod:`relationalai.tools.cli.docs`; this module
only wires up the Click commands.
"""

from __future__ import annotations

import click

from ..errors import exit_on_docs_subcommand_failure


def register(cli: click.Group) -> None:
    @cli.group(hidden=True)
    def docs() -> None:
        """Generate and serve documentation site."""
        pass

    @docs.command()
    @click.option(
        "--output",
        "-o",
        default=None,
        help="Output directory for generated documentation (defaults to docs/dist)",
    )
    def generate(output: str | None) -> None:
        """Generate static documentation site from models."""
        from ..docs import generate_docs

        try:
            generate_docs(output_dir=output)
        except Exception as e:
            exit_on_docs_subcommand_failure(e, headline="Failed to generate documentation.")

    @docs.command()
    @click.option("--port", "-p", default=8000, type=int, help="Port to serve documentation on (default: 8000)")
    @click.option("--host", default="127.0.0.1", help="Host to bind to (default: 127.0.0.1)")
    @click.option("--build-dir", default=None,
                  help="Directory containing built documentation (defaults to docs/dist)")
    @click.option("--no-open", is_flag=True, help="Don't open browser automatically")
    def serve(port: int, host: str, build_dir: str | None, no_open: bool) -> None:
        """Serve generated documentation site."""
        from ..docs import find_docs_dir, serve_docs

        try:
            if build_dir is None:
                docs_dir = find_docs_dir()
                build_dir = str(docs_dir / "dist")
            serve_docs(
                build_dir=build_dir,
                host=host,
                port=port,
                open_browser=not no_open,
            )
        except Exception as e:
            exit_on_docs_subcommand_failure(e, headline="Failed to start documentation server.")

    @docs.command()
    @click.option("--port", "-p", default=5173, type=int,
                  help="Port to serve development server on (default: 5173)")
    @click.option("--host", default="127.0.0.1", help="Host to bind to (default: 127.0.0.1)")
    @click.option("--no-open", is_flag=True, help="Don't open browser automatically")
    def dev(port: int, host: str, no_open: bool) -> None:
        """Start development server with hot module replacement (HMR).

        This command runs Vite's dev server which provides:
        - Hot module replacement - changes reflect instantly
        - Fast refresh - no need to rebuild on every change
        - Source maps for debugging

        Use this for development instead of 'rai docs generate' + 'rai docs serve'.
        """
        from ..docs import dev_docs

        try:
            dev_docs(host=host, port=port, open_browser=not no_open)
        except Exception as e:
            exit_on_docs_subcommand_failure(e, headline="Failed to start documentation dev server.")

    @docs.command(name="clean")
    def clean_docs() -> None:
        """Remove auto generated files and directories."""
        from ..docs import cleanup_docs

        try:
            cleanup_docs()
        except Exception as e:
            exit_on_docs_subcommand_failure(e, headline="Failed to clean documentation artifacts.")
