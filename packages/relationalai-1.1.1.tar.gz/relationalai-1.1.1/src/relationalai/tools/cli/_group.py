"""Custom Click group that formats subcommands in colored, spaced sections."""

from __future__ import annotations

import os

import click

from .runtime import get_runtime


class RaiGroup(click.Group):
    """Root CLI group. Renders subcommands in colored, prefix-grouped sections.

    The color state is read from the :class:`~relationalai.tools.cli.runtime.CliRuntime`
    attached to the Click context, so ``rai --no-color --help`` produces plain
    output without ANSI escapes (honoring the ``NO_COLOR`` env var as well).
    """

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        """Prime ``--json`` / ``--no-color`` from raw args before option parsing.

        Eager option callbacks (like ``--version``) fire from inside Click's
        parser, *before* :func:`cli` runs. Without this hook, those callbacks
        couldn't tell that the user also passed ``--json`` or ``--no-color``,
        so the upgrade panel could leak into JSON output or render with ANSI
        when the user asked for plain text. We do a cheap pre-scan here so
        the runtime is correct from the very first eager callback onward.

        ``cli()`` re-asserts these from the parsed ``ctx.params`` afterwards;
        the values agree, so re-asserting is a no-op.
        """
        try:
            from .cli_output_prefs import set_cli_no_color

            json_flag = "--json" in args
            no_color_flag = "--no-color" in args
            no_color_env = os.environ.get("NO_COLOR", "").strip() != ""
            no_color = no_color_flag or no_color_env

            rt = get_runtime(ctx)
            rt.json_output = json_flag
            rt.no_color = no_color
            set_cli_no_color(no_color)
            if no_color:
                ctx.color = False
        except Exception:
            # Never let priming fail the parse; ``cli()`` will populate
            # these correctly from ``ctx.params`` regardless.
            pass
        return super().parse_args(ctx, args)

    def format_help_text(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Inject a short version summary right under the command description.

        Uses the installed package version as formatted by
        :func:`update_check.format_version_summary`; it does not consult
        cached PyPI ``latest`` data here. The post-command panel rendered
        by :func:`update_check.maybe_print_notice` owns the upgrade nudge.
        """
        super().format_help_text(ctx, formatter)
        try:
            from . import update_check

            rt = get_runtime(ctx)
            use_color = (not rt.no_color) and getattr(ctx, "color", None) is not False
            line = update_check.format_version_summary(use_color=use_color)
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(line)
        except Exception:
            # Never let a help-screen embellishment break ``rai --help``.
            return

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        rows: list[tuple[str, str, str]] = []
        rt = get_runtime(ctx)
        no_color = rt.no_color
        use_color = (not no_color) and getattr(ctx, "color", None) is not False

        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or getattr(cmd, "hidden", False):
                continue
            label = name
            if use_color:
                if ":" in name:
                    prefix, rest = name.split(":", 1)
                    label = click.style(prefix + ":", dim=False, fg="bright_blue") + rest
                else:
                    label = click.style(name, dim=False, fg="bright_blue")
            rows.append((name, label, cmd.get_short_help_str()))

        if not rows:
            return

        def _by_prefix(prefix: str | None) -> list[tuple[str, str]]:
            if prefix is None:
                return [(label, h) for (n, label, h) in rows if ":" not in n]
            return [(label, h) for (n, label, h) in rows if n.startswith(prefix)]

        sections: list[list[tuple[str, str]]] = []
        sections.append(_by_prefix(None))
        prefixes = sorted({n.split(":", 1)[0] for (n, _label, _h) in rows if ":" in n})
        for p in prefixes:
            sections.append(_by_prefix(f"{p}:"))
        sections = [s for s in sections if s]

        with formatter.section("Commands"):
            for i, sec in enumerate(sections):
                if i:
                    formatter.write_paragraph()
                formatter.write_dl(sec)
