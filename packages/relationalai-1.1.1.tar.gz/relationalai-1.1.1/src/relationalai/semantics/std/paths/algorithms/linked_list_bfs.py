from __future__ import annotations

from relationalai.semantics import (
    Integer, AnyEntity, Model, Variable, Fragment, Relationship, Chain,
)
from relationalai.semantics.std.paths import PathTraversal
from relationalai.semantics.std.common import hash, Hash


def enumerate_all_paths_via_filtered_bfs(
    m: Model,
    edge: Relationship | Chain | Fragment,
    src_dst_fields: tuple[int, int],
    src: Variable,
    dst: Variable | None,
    repeats: tuple[int, int],
) -> Relationship:
    """
    Enumerate all paths using BFS, pre-filtering to only nodes that can reach `dst`.

    Before running BFS, computes backward reachability from `dst` and restricts
    traversal to nodes that can reach destination nodes. Also filters initial `src`
    to only nodes that can reach `dst`. When `dst` is None, behaves identically
    to the naive linked_list variant.

    Note: we do not apply any filtering based on reachability from `src`, since we are
    already starting the BFS from `src` and will only traverse nodes reachable from it.

    Complexity: the same asymptotic complexity as the naive BFS, but for certain graph
    structures and queries, the filtering can significantly reduce the number of paths
    explored and thus the runtime. The backward reach computation is linear in the size
    of the graph, but can significantly reduce the search space of nodes traversed, e.g.,
    when there are many dead-ends that cannot reach `dst`. This can improve performance
    because the linked-list BFS enumeration is exponential in the number of nodes traversed.

    IMPLEMENTATION NOTE:
        Instead of passing the `reaches_dst` Relationship to `_enumerate_all_paths_via_bfs`,
        we considered passing a `filtered_edge` Relationship/Fragment that only contains
        edges to nodes that can reach `dst`. However, we could not retain the proper
        higher-arity edge information.

    See `_enumerate_all_paths_via_bfs` for full algorithm details and args.
    """
    if dst is None:
        # If dst is None, then filtered BFS collapses to naive BFS (no pre-filtering).
        return enumerate_all_paths_via_naive_bfs(
            m, edge, src_dst_fields, src, dst, repeats
        )

    _validate_edge(edge, src_dst_fields)
    src_field, dst_field = src_dst_fields

    # Define the backward reach of `dst`, so that we can filter the BFS to only explore nodes that can reach `dst`.
    reaches_dst = m.Relationship(f"{AnyEntity:node} can reach dst", short_name="reaches_dst")
    m.define(reaches_dst(dst))
    m.define(reaches_dst(edge[src_field])).where(reaches_dst(edge[dst_field]))

    # Perf optimization: filter the initial `src` set to only those that can reach `dst`.
    # RAI-49696: Loopy + AnyEntity bug causes this spelling to fail to filter
    # filtered_src = m.where(reaches_dst(src)).select(src)
    filtered_src = m.where(src == reaches_dst).select(src)

    return _enumerate_all_paths_via_bfs(
        m, edge, src_dst_fields, filtered_src, dst, repeats, reaches_dst_filter=reaches_dst
    )

def enumerate_all_paths_via_naive_bfs(
    m: Model,
    edge: Relationship | Chain | Fragment,
    src_dst_fields: tuple[int, int],
    src: Variable,
    dst: Variable | None,
    repeats: tuple[int, int],
) -> Relationship:
    """
    Enumerate all paths by building linked-lists via BFS (no pre-filtering
    to nodes that can reach `dst`).

    See `_enumerate_all_paths_via_bfs` for full algorithm details and args.
    """
    return _enumerate_all_paths_via_bfs(
        m, edge, src_dst_fields, src, dst, repeats
    )


def _enumerate_all_paths_via_bfs(
    m: Model,
    edge: Relationship | Chain | Fragment,
    src_dst_fields: tuple[int, int],
    src: Variable,
    dst: Variable | None,
    repeats: tuple[int, int],
    reaches_dst_filter: Relationship | None = None,
) -> Relationship:
    """
    Enumerate all paths by building linked-lists via BFS,
    with optional destination-reachability filtering.

    Enumerates all paths between `src` and `dst` defined by `edge`,
    with hop counts bounded by `repeats`.

    The algorithm follows a standard BFS / transitive closure loop, but rather than
    computing reachability it computes a unique Hash for every *path* traversed and
    stores the nodes visited along it. Each path is represented as a linked-list
    (grown from the tail), reusing shared prefixes — so the collection of paths forms
    a tree with only back-edges, rooted from nil.

    Complexity: Exponential in the number of nodes traversed / reachable from `src`,
    since each path is tracked separately and there can be exponentially many paths.
    If there are cycles and `repeats` is unbounded (currently unsupported), the
    cardinality of paths may be infinite, so this algorithm would not terminate.

    Args:
        m: The Model instance used to define relationships, properties, and procedures.
        edge: A relationship, chain, or fragment whose indexed fields define the
            edges of the graph.
        src_dst_fields: The field indices in `edge` that correspond to the source and
            destination nodes. For a 2-arity relationship `edge`, this is typically
            `(0, 1)`.
        src: Source node(s) to start the BFS from. Can be certain Variables, e.g., a
            Concept population, its Ref, a specific instance via `.new()`, a Union of
            instances, or a Fragment (a filtered selection).
        dst: Destination node(s) — same types as src, or None to match any destination.
            Only paths ending at a dst node are included in the result.
        repeats: A tuple `(min_repeats, max_repeats)` specifying the allowed range of
            hops for matched paths.
        reaches_dst_filter: An optional Relationship used to restrict traversal to nodes
            that can reach `dst`. Supplied by `enumerate_all_paths_via_filtered_bfs`;
            if None, no filtering is applied (naive BFS).

    IMPLEMENTATION NOTE:
        We considered stopping iteration of a path after it reaches a node in `dst`,
        but if there is more than one node in `dst`, we need to continue traversing in
        case we can reach other `dst` nodes. So this optimisation is not valid.
    """
    _validate_edge(edge, src_dst_fields)
    _validate_repeats(repeats)
    src_field, dst_field = src_dst_fields
    aux_field_indices = _aux_edge_field_indices(edge, src_dst_fields)
    min_repeats, max_repeats = repeats

    nil = Hash(0)

    path_length = m.Property(f"{PathTraversal:path} has {Integer:length} hops", short_name="path_length")

    # The linked-lists of PathTraversal objects.
    path_head = m.Property(f"{PathTraversal:path} has {AnyEntity:node}", short_name="path_head")
    path_tail = m.Property(f"{PathTraversal:path} has {PathTraversal:tail}", short_name="path_tail")

    # Per-path record of the edge field values used to reach this PathTraversal, excluding
    # the src/dst fields. Allows disambiguation of multi-edges between the same nodes.
    # TODO [RAI-49933]: optimization opportunity - each edge's field values are repeatedly stored,
    #       once per path that traverses it. Can we use a more efficient representation?
    #       Also, for edges of arity 4 or more, we could store an edge hash, which reduces
    #       the hash cost in the below Loopy BFS, by replacing
    #       `*[edge[field_index] for field_index in aux_field_indices]` with 1 argument.
    path_edge_fields = m.Property(
        f"{PathTraversal:path}'s current edge at field number {Integer:field_index} has value {AnyEntity:field}"
    )

    with m._procedure(path_length, path_head, path_tail, path_edge_fields) as p:
        frontier_paths = m.Relationship(f"{PathTraversal:path} points to {AnyEntity:node}", short_name="frontier_paths")
        start_path = PathTraversal(hash(src, nil))
        p.assign(frontier_paths(start_path, src))

        step = m.Property(f"{Integer}", short_name="bfs_step")
        p.assign(step(0))
        p.assign(path_length(start_path, step))
        p.assign(path_head(start_path, src))
        p.assign(path_tail(start_path, nil))

        # TODO: A bug in the typer prevents us from doing p.empty here,
        # Even though this value is dropped anyway. [RAI-49604]
        p.assign(path_edge_fields(start_path, -1, src))

        with p.loop():
            p.break_if(step >= max_repeats)
            p.assign(step(step + 1))

            # Match a single step — hash on all edge fields except src so that
            # different edges between the same nodes produce distinct paths.
            next_node, next_path = m.where(
                current_node := frontier_paths["node"],
                current_path := frontier_paths["path"],
                edge[src_field] == current_node,
                successor := edge[dst_field],
                *([reaches_dst_filter(successor)] if reaches_dst_filter is not None else []),
            ).select(
                successor,
                PathTraversal(hash(
                    *[edge[field_index] for field_index in aux_field_indices],
                    successor,
                    current_path,
                ))
            )

            p.break_if(m.not_(next_path))

            p.with_arity(0).upsert(path_tail(next_path, current_path))
            p.with_arity(0).upsert(path_length(next_path, step))
            p.with_arity(0).upsert(path_head(next_path, next_node))
            for field_index in aux_field_indices:
                p.with_arity(0).upsert(path_edge_fields(next_path, field_index, edge[field_index]))

            p.assign(frontier_paths(next_path, next_node))

    # Now store the results of the paths traversal into the model:
    paths = m.Relationship(f"{PathTraversal:path}", short_name="paths")
    m.define(paths(PathTraversal)).where(
        path_len := path_length(PathTraversal),
        path_len >= min_repeats,
        # NOTE: We stop iteration after max_repeats, so all paths will have:
        #   path_len <= max_repeats,

        # RAI-49696: Loopy + AnyEntity bug causes this spelling to fail to filter
        # in certain cases, so we use the equality form instead, which works correctly.
        # (path_head(PathTraversal, dst) if dst is not None else True),
        *([path_head(PathTraversal) == dst] if dst is not None else []),
    )

    # - paths() already contains the set of paths that match the min/max repeat pattern.
    # - Save the length for each of the matched paths.
    # - Note: `paths` is a unary Relationship with a named field (`:path`), so using it
    #   directly (e.g. `paths` in `path_length(paths)`) binds its trailing slot as a
    #   variable. Because the field is named, repeated uses of `paths` in the same
    #   expression unify on that name — so both occurrences of `paths` below refer to
    #   the same PathTraversal.
    m.define(PathTraversal.length(paths, path_length(paths)))

    # - Traverse the linked lists backwards to get the Nodes matched for each path:
    path_ancestor = m.Relationship(f"{PathTraversal} has {PathTraversal:ancestor}", short_name="path_ancestor")
    m.define(
        path_ancestor(paths, paths),
        path_ancestor(paths, path_tail(path_ancestor(paths))),
    )

    # Emit per-edge field values. path_length > 0 skips start_path (no incoming edge).
    # Subtract 1 so edge_index is 0-based, consistent with PathTraversal.nodes.
    m.where(
        ancestor := path_ancestor(PathTraversal),
        path_length(ancestor) > 0,
        field_value := path_edge_fields(ancestor, field_index := Integer)
    ).define(
        PathTraversal.relationship_fields(path_length(ancestor) - 1, field_index, field_value)
    )

    # Finally, store the head node at each ancestor as a node along the path:
    m.where(
        ancestor := path_ancestor(PathTraversal)
    ).define(PathTraversal.nodes(path_length(ancestor), path_head(ancestor)))

    return paths

def _edge_arity(edge: Relationship | Chain | Fragment) -> int:
    """Return the number of fields (arity) of an edge."""
    if isinstance(edge, Relationship):
        return len(edge._fields)
    elif isinstance(edge, Chain):
        return len(edge._next._fields)
    elif isinstance(edge, Fragment):
        return len(edge._get_cols()) # or len(edge._select)
    else:
        raise TypeError(f"Unsupported edge type: {type(edge)}.")

def _aux_edge_field_indices(
    edge: Relationship | Chain | Fragment,
    src_dst_fields: tuple[int, int],
) -> list[int]:
    """
    Returns auxiliary indices of edge fields, i.e., all indices excluding src and dst fields.

    Empty for binary edges. Works for all supported `edge` types:
    Relationship, Chain, and Fragment.
    """
    return [i for i in range(_edge_arity(edge)) if i not in src_dst_fields]

def _validate_edge(
    edge: Relationship | Chain | Fragment,
    src_dst_fields: tuple[int, int],
) -> None:
    """Validate edge and src_dst_fields together."""
    src_field, dst_field = src_dst_fields
    if src_field < 0 or dst_field < 0:
        raise ValueError(
            f"`src_dst_fields` indices must be non-negative, "
            f"but got: {src_dst_fields!r}."
        )
    if src_field == dst_field:
        raise ValueError(
            f"`src_dst_fields` indices must be distinct, "
            f"but got: {src_dst_fields!r}."
        )
    num_fields = _edge_arity(edge)
    if max(src_field, dst_field) + 1 > num_fields:
        raise ValueError(
            f"`src_dst_fields` indices {src_dst_fields!r} exceed the arity of "
            f"`edge` (which has {num_fields} fields)."
        )

def _validate_repeats(repeats: tuple[int, int]) -> None:
    min_repeats, max_repeats = repeats
    if min_repeats < 0:
        raise ValueError(
            f"The `repeats` argument must have non-negative min_repeats, "
            f"but got min_repeats={min_repeats}."
        )
    if max_repeats < 0:
        raise ValueError(
            f"The `repeats` argument must have non-negative max_repeats, "
            f"but got max_repeats={max_repeats}."
        )
    if min_repeats > max_repeats:
        raise ValueError(
            f"The `repeats` argument must satisfy min_repeats <= max_repeats, "
            f"but got min_repeats={min_repeats} and max_repeats={max_repeats}."
        )
