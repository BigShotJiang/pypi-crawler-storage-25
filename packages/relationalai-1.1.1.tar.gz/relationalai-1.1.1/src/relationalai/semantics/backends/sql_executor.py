"""SQL-specific executor — lowers, emits, and executes SQL blocks."""

from __future__ import annotations

import rich
from collections.abc import Callable
from pandas import DataFrame

from ...util.error import exc
from .executor import add_to_span
from ...config.config import Config
from ...config.config_fields import DEFAULT_TABLE_MATERIALIZATION
from ...config.connections.duckdb import DuckDBConnection
from ...config.connections.snowflake import SnowflakeConnection
from ..metamodel import metamodel as mm
from v0.relationalai import debugging

from .sql.artifacts import BlockVersionState, Catalog, ExecutionPlan, PlannedSemiNaiveLoop, PlannedSQLStep, SQLExecutionStep
from .sql.coalescer import CoalescedBlock

# SQL-specific passes
from .sql.normalizer import SQLNormalizer
from .sql.lowerer import Lowerer
from .sql.sql_optimizer import SQLOptimizer
from .sql.emitter import SQLEmitter
from .sql.pprint import pprint as sql_pprint


class SQLExecutor:
    """Handles SQL-specific planning and execution: schema,
    seed views, SQL block compilation, and SQL step execution."""

    def __init__(self, config: Config, model_config: Config) -> None:
        self._config = config
        self._model_config = model_config
        self._sql_backend = self._create_sql_backend()
        self._resolved_schema_name = self._sql_backend.resolve_model_schema(self._config)
        self._schema_ensured = False
        self._sql_normalizer = SQLNormalizer()
        self._optimizer = SQLOptimizer()
        self._emitter = SQLEmitter(self._sql_backend)

    def execute_query(
        self,
        query: mm.Task,
        install_result,
        storage_normalizer,
        *,
        dry_run: bool,
        show_debug_logs: bool,
    ) -> DataFrame:
        with debugging.span("SQL Normalizer") as span:
            canonical = self._sql_normalizer.normalize(query)
            add_to_span(span, canonical)
        with debugging.span("Storage Normalizer") as span:
            canonical = storage_normalizer.bind_fragment(
                canonical,
                install_result.version_state.latest_tables_by_relation_id,
            )
            span["metamodel"] = str(canonical)
        if not isinstance(canonical, mm.Task):
            return DataFrame()

        with debugging.span("Lowerer") as span:
            lowered = Lowerer(install_result.catalog).lower_fragment(canonical)
            add_to_span(span, lowered, "result", lambda ir: self._emitter.pretty(ir))
        if lowered is None:
            return DataFrame()

        with debugging.span("Optimizer") as span:
            lowered = self._optimizer.optimize_query(lowered)
            add_to_span(span, lowered, "result", lambda ir: self._emitter.pretty(ir))

        with debugging.span("Emitter") as span:
            frag_sql = self._emitter.emit(lowered)
            if dry_run:
                add_to_span(span, frag_sql, "result")
            if show_debug_logs:
                rich.print("\n[cyan]--------------------------------------------------------------[/cyan]")
                rich.print(self._emitter.pretty(frag_sql))

        if dry_run:
            return DataFrame()

        with debugging.span("Execute SQL Query") as span:
            add_to_span(span, frag_sql, "result")
            result = self._sql_backend.execute_sql(frag_sql)
            span["sort_results"] = True
        return result

    @property
    def schema_name(self) -> str | None:
        return self._resolved_schema_name

    def ensure_schema_exists(self) -> None:
        if self._schema_ensured:
            return
        try:
            with debugging.span("Schema Exists Check"):
                self._sql_backend.execute_sql(f"CREATE SCHEMA IF NOT EXISTS {self._resolved_schema_name}")
        except Exception as e:
            exc(
                "Schema setup failed",
                f"Failed to ensure install schema '{self._resolved_schema_name}' exists.",
                [str(e)],
            )
        self._schema_ensured = True

    @property
    def execute_sql(self) -> Callable[[str], DataFrame]:
        return self._sql_backend.execute_sql

    @property
    def execute_sql_batch(self) -> Callable[[list[str]], None]:
        return self._sql_backend.execute_sql_batch

    def plan_seed_views(
        self,
        seed_object_names: tuple[str, ...],
        catalog: Catalog,
    ) -> list[PlannedSQLStep]:
        lowerer = Lowerer(catalog)
        seed_views = lowerer._seed_views(seed_object_names)
        if not seed_views:
            return []
        batch = tuple(self._emitter.emit(v) for v in seed_views)
        fqns = tuple(self._sql_backend.quote_table_name(v.name) for v in seed_views)
        view_names = tuple(v.name for v in seed_views)
        return [PlannedSQLStep(view_names, batch, fqns, ())]

    def plan_block(
        self,
        block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        storage_normalizer,
        show_debug_logs: bool,
    ) -> list[PlannedSQLStep]:
        lowerer = Lowerer(catalog)
        with debugging.span("Storage Normalizer") as span:
            normalized = storage_normalizer.normalize_sql_block(
                block, model, catalog, version_state
            )
            add_to_span(span, normalized, "result")
        if normalized is None:
            return []
        with debugging.span("Lowerer") as span:
            lowered = lowerer.lower_block(normalized)
            add_to_span(span, lowered, "result", sql_pprint)
        with debugging.span("Optimizer") as span:
            optimized = self._optimizer.optimize_plan(ExecutionPlan(steps=tuple(lowered)))
            add_to_span(span, optimized, "result", sql_pprint)
        with debugging.span("Emitter") as span:
            planned_steps: list[PlannedSQLStep] = []
            pretty_stmts: list[str] = []
            for sql_step in optimized.steps:
                assert isinstance(sql_step, SQLExecutionStep)
                batch = tuple(self._emitter.emit(view) for view in sql_step.views)
                fqns = tuple(self._sql_backend.quote_table_name(view.name) for view in sql_step.views)
                view_names = tuple(view.name for view in sql_step.views)
                install_sql_batch = tuple(
                    self._sql_backend.install_table_ddl_for_target(sql, view.name, view.column_types)
                    for sql, view in zip(batch, sql_step.views)
                    if view.column_types
                )
                pretty_stmts.extend(self._emitter.pretty(s) for s in batch)
                semi_naive: list[PlannedSemiNaiveLoop] = []
                for loop in sql_step.semi_naive_loops:
                    table_names = tuple(t.table_name for t in loop.tables)
                    plan = self._sql_backend.build_semi_naive_plan(loop, self._emitter)
                    install_sql = tuple(
                        self._sql_backend.install_table_ddl(t.table_name, t.column_types)
                        for t in loop.tables
                        if t.column_types
                    )
                    semi_naive.append(PlannedSemiNaiveLoop(table_names, plan, install_sql))
                planned_steps.append(PlannedSQLStep(
                    view_names=view_names,
                    refresh_sql_batch=batch,
                    fqns=fqns,
                    semi_naive_loops=tuple(semi_naive),
                    install_sql_batch=install_sql_batch,
                ))
            if show_debug_logs:
                for sql in pretty_stmts:
                    rich.print("\n[yellow]--------------------------------------------------------------[/yellow]")
                    rich.print(sql)
        return planned_steps

    def execute_block(self, plan: list[PlannedSQLStep]) -> None:
        for planned in plan:
            if planned.refresh_sql_batch:
                try:
                    with debugging.span("Execute SQL Batch") as span:
                        add_to_span(span, planned.refresh_sql_batch, "result")
                        self._sql_backend.execute_sql_batch(list(planned.refresh_sql_batch))
                except Exception as e:
                    exc(
                        "Model install failed",
                        "Failed to execute model-install SQL batch.",
                        [str(e)],
                    )
            for planned_loop in planned.semi_naive_loops:
                try:
                    with debugging.span("Execute Semi-Naive Loop") as span:
                        add_to_span(span, ", ".join(planned_loop.table_names), "result")
                        self._sql_backend.execute_semi_naive(planned_loop.plan)
                except Exception as e:
                    exc(
                        "Model install failed",
                        "Failed to execute recursive model-install loop.",
                        [str(e)],
                    )

    def _create_sql_backend(self):
        conn = self._config.get_default_connection()
        if isinstance(conn, DuckDBConnection):
            from relationalai.semantics.backends.sql.duckdb_backend import DuckDBBackend
            return DuckDBBackend(conn.get_session(), conn.path)
        elif isinstance(conn, SnowflakeConnection):
            from .sql.snowflake_backend import SnowflakeBackend
            session = conn.get_session()
            schedule_cfg = getattr(self._config, "schedule", None)
            table_materialization_default = getattr(schedule_cfg, "table_materialization_default", DEFAULT_TABLE_MATERIALIZATION)
            table_materialization = getattr(schedule_cfg, "table_materialization", {}) or {}
            return SnowflakeBackend(
                session,
                table_materialization_default=table_materialization_default,
                table_materialization=table_materialization,
            )
        else:
            raise ValueError(
                f"Unsupported connection type: {type(conn)}. "
                "Supported connections are 'snowflake' and 'duckdb'."
            )
