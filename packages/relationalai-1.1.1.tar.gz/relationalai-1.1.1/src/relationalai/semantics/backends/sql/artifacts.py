from __future__ import annotations

from dataclasses import dataclass, field
from ...metamodel import metamodel as mm
from .sql_ir import SQLCreateView, SQLQuery

#------------------------------------------------------
# Common abstractions
#------------------------------------------------------

class CompilationArtifact:
    """ Common abstraction for all artifacts produced during compilation. """
    def __str__(self) -> str:
        try:
            from .pprint import pprint
            return pprint(self)
        except Exception as e:
            print(e)
            return object.__repr__(self)


#------------------------------------------------------
# Catalog
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class StoreColumn(CompilationArtifact):
    name: str
    sql_type: str | None
    semantic_name: str | None = None

@dataclass(frozen=True, slots=True)
class EntityStore(CompilationArtifact):
    type_id: int
    type_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    key_columns: tuple[str, ...] = ("_id",)


@dataclass(frozen=True, slots=True)
class RelationStore(CompilationArtifact):
    relation_id: int
    relation_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    key_columns: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DataStore(CompilationArtifact):
    type_id: int
    type_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    source_name: str | None = None
    rows: tuple[tuple[object | None, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class Catalog(CompilationArtifact):
    entity_stores: tuple[EntityStore, ...]
    relation_stores: tuple[RelationStore, ...]
    data_stores: tuple[DataStore, ...]
    folded_property_owner_type_ids: dict[int, int]
    data_column_store_type_ids: dict[int, int]

    def entity_store(self, ref: str | mm.Relation) -> EntityStore:
        if isinstance(ref, mm.Relation):
            type_id = getattr(ref, "id", None)
        else:
            type_id = None
        if isinstance(type_id, int):
            for store in self.entity_stores:
                if store.type_id == type_id:
                    return store
        type_name = ref if isinstance(ref, str) else getattr(ref, "name", None)
        for store in self.entity_stores:
            if store.type_name == type_name:
                return store
        raise KeyError(f"Unknown sql9 entity store for {type_name!r}.")

    def relation_store(self, ref: mm.Relation | str) -> RelationStore:
        if isinstance(ref, mm.Relation) and self.is_data_column(ref):
            raise KeyError(f"Data column relation {ref.name!r} does not have a sql9 relation store.")
        relation_id = getattr(ref, "id", None)
        if isinstance(relation_id, int):
            for store in self.relation_stores:
                if store.relation_id == relation_id:
                    return store
        relation_name = ref if isinstance(ref, str) else getattr(ref, "name", None)
        for store in self.relation_stores:
            if store.relation_name == relation_name:
                return store
        raise KeyError(f"Unknown sql9 relation store for {relation_name!r}.")

    def data_store(self, ref: mm.Data | mm.Table | str) -> DataStore:
        type_id = getattr(ref, "id", None)
        if isinstance(type_id, int):
            for store in self.data_stores:
                if store.type_id == type_id:
                    return store
        type_name = ref if isinstance(ref, str) else getattr(ref, "name", None)
        for store in self.data_stores:
            if store.type_name == type_name:
                return store
        raise KeyError(f"Unknown sql9 data store for {type_name!r}.")

    def is_folded_property(self, relation: mm.Relation) -> bool:
        return relation.id in self.folded_property_owner_type_ids

    def owner_store_for_property(self, relation: mm.Relation) -> EntityStore:
        owner_type_id = self.folded_property_owner_type_ids[relation.id]
        for store in self.entity_stores:
            if store.type_id == owner_type_id:
                return store
        raise KeyError(f"Missing owner store for folded property {relation.name!r}.")

    def is_data_column(self, relation: mm.Relation) -> bool:
        return relation.id in self.data_column_store_type_ids

    def data_store_for_column(self, relation: mm.Relation) -> DataStore:
        store_type_id = self.data_column_store_type_ids[relation.id]
        for store in self.data_stores:
            if store.type_id == store_type_id:
                return store
        raise KeyError(f"Missing data store for column relation {relation.name!r}.")

    def physical_anchor_id(self, relation_id: int, model: mm.Model) -> int:
        """Storage-level anchor: folded properties/data columns → owner type_id; else self."""
        relation = next((r for r in model.relations if r.id == relation_id), None)
        if relation is not None:
            if relation.id in self.folded_property_owner_type_ids:
                return self.folded_property_owner_type_ids[relation.id]
            if relation.id in self.data_column_store_type_ids:
                return self.data_column_store_type_ids[relation.id]
        return relation_id

#------------------------------------------------------
# Stratifier
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class SCCGraph(CompilationArtifact):
    """SCC-level dependency graph exposed for backend routing.

    ``sccs[i]`` is the set of relation_ids in SCC i.
    ``dependencies[i]`` is the set of SCC indexes that SCC i depends on
    (i.e. must be computed before SCC i).
    ``has_self_loop[i]`` is True when SCC i has a recursive self-edge.
    ``stratum_index_by_scc[i]`` maps each SCC to its containing stratum index.
    """

    sccs: tuple[tuple[int, ...], ...]
    dependencies: tuple[frozenset[int], ...]
    has_self_loop: tuple[bool, ...]
    stratum_index_by_scc: tuple[int, ...]

#------------------------------------------------------
# Coalescer
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class Target(CompilationArtifact):
    kind: str
    object_name: str
    column_names: tuple[str, ...]
    key_columns: tuple[str, ...]
    anchor_id: int
    relation_ids: tuple[int, ...]

@dataclass(frozen=True, slots=True)
class Contribution(CompilationArtifact):
    target: Target
    task: mm.Logical

@dataclass(frozen=True, slots=True)
class PlannedTarget(CompilationArtifact):
    target: Target
    contributions: tuple[Contribution, ...]
    recursive: bool
    recursive_component_relation_ids: tuple[int, ...] = ()

@dataclass(frozen=True, slots=True)
class CoalescedBlock(CompilationArtifact):
    """Coalescer output for one execution block (SQL or Logic)."""

    index: int
    reasoner_type: str  # lowercased reasoner type, e.g. "sql", "logic"
    targets: tuple[PlannedTarget, ...]
    recursive: bool
    input_relation_ids: tuple[int, ...]
    output_relation_ids: tuple[int, ...]
    interval_mins: int = 0

#------------------------------------------------------
# Storage Normalizer
#------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TargetPlan(CompilationArtifact):
    target: Target
    tasks: tuple[mm.Logical, ...]
    output_table: mm.Table
    prior_table: mm.Table | None = None
    requires_coalesce: bool = True

@dataclass(frozen=True, slots=True)
class RecursiveTargetPlan(CompilationArtifact):
    target: Target
    seed_tasks: tuple[mm.Logical, ...]
    recursive_tasks: tuple[mm.Logical, ...]
    output_table: mm.Table
    marker_table: mm.Table
    prior_table: mm.Table | None = None
    requires_coalesce: bool = True

@dataclass(frozen=True, slots=True)
class RecursiveComponentPlan(CompilationArtifact):
    relation_ids: tuple[int, ...]
    targets: tuple[RecursiveTargetPlan, ...]


@dataclass(slots=True)
class BlockVersionState(CompilationArtifact):
    latest_tables_by_relation_id: dict[int, mm.Table]
    entry_tables_by_relation_id: dict[int, mm.Table]
    materialized_tables_by_object_name: dict[str, mm.Table] = field(default_factory=dict)
    stage_numbers_by_object_name: dict[str, int] = field(default_factory=dict)

    def latest_table_for(self, relation_id: int) -> mm.Table | None:
        return self.latest_tables_by_relation_id.get(relation_id)

    def entry_table_for(self, relation_id: int) -> mm.Table | None:
        return self.entry_tables_by_relation_id.get(relation_id)

    def prior_table_for(self, object_name: str) -> mm.Table | None:
        return self.materialized_tables_by_object_name.get(object_name)

    def note_output_name(self, object_name: str) -> int:
        next_stage = self.stage_numbers_by_object_name.get(object_name, 0) + 1
        self.stage_numbers_by_object_name[object_name] = next_stage
        return next_stage

    def materialize_object(self, object_name: str, output_table: mm.Table) -> None:
        self.materialized_tables_by_object_name[object_name] = output_table

    def bind_relation_table(self, relation_id: int, table: mm.Table) -> None:
        self.latest_tables_by_relation_id[relation_id] = table


@dataclass(frozen=True, slots=True)
class NormalizedSQLBlock(CompilationArtifact):
    """One SQL execution unit.

    ``items`` contains ``TargetPlan`` / ``RecursiveComponentPlan`` entries
    produced by the storage normalizer.
    """

    index: int
    items: tuple[TargetPlan | RecursiveComponentPlan, ...]
    recursive: bool = False
    input_relation_ids: tuple[int, ...] = ()
    output_relation_ids: tuple[int, ...] = ()


#------------------------------------------------------
# Lowerer
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class SemiNaiveTable(CompilationArtifact):
    """Semi-naive evaluation plan for one recursive target.

    Invariant
    ---------
    ``delta_i = accum_{i+1} \\ accum_i`` — the delta at iteration ``i`` is, by
    definition, the new tuples that this iteration adds to ``accum``. The
    lowerer encodes this directly: ``next_delta_query`` is constructed as
    ``next_accum EXCEPT accum`` over views the runtime materializes. Runtime
    code never re-derives the difference, so backends inherit the convergence
    semantics for free and partial-column rule variants (e.g. NULL-padded
    aggregate-only branches) cannot leak through a full-row set comparison.

    Fields
    ------
    base_query
        Initial accumulation (seeds + recursive-rule branches against empty
        recursive inputs).
    delta_query
        Raw recursive rule output. May produce partial-column rows when a
        target has multiple rules with disjoint column subsets — those rows
        are reconciled into accum's column shape inside ``merge_query``. Kept
        as a field so the optimizer can walk it independently; not consumed
        directly by the runtime convergence loop.
    merge_query
        ``next_accum`` — existing accum coalesced with ``delta_query``. Has
        the same column shape as accum.
    next_delta_query
        ``next_accum EXCEPT accum`` — the actual change between accum states.
        This is what the runtime counts to detect a fixpoint and what gets
        swapped into ``delta_view`` for the next iteration's rule firings.
    final_query
        How to project the finalized accum into the public view.
    """
    table_name: str
    columns: tuple[str, ...]
    base_query: SQLQuery
    delta_query: SQLQuery
    merge_query: SQLQuery
    next_delta_query: SQLQuery
    final_query: SQLQuery
    accum_view_name: str
    delta_view_name: str
    next_accum_view_name: str
    next_delta_view_name: str
    # Typed columns for the table_name target — used to emit schema-only DDL at
    # async-install time without depending on upstream tables. Same length and
    # order as `columns`.
    column_types: tuple["StoreColumn", ...] = ()


@dataclass(frozen=True, slots=True)
class SemiNaiveLoop(CompilationArtifact):
    tables: tuple[SemiNaiveTable, ...] = ()

@dataclass(frozen=True, slots=True)
class View(SQLCreateView):
    # Typed columns of this View's output — used to emit schema-only DDL at
    # async-install time without resolving the inner SELECT against upstream
    # tables. Empty when the View doesn't write to a catalog store (e.g. seed
    # views built via VALUES, which never need schema-only materialization).
    column_types: tuple["StoreColumn", ...] = ()

@dataclass(frozen=True, slots=True)
class PlannedSemiNaiveLoop(CompilationArtifact):
    table_names: tuple[str, ...]
    plan: object  # opaque, dialect-specific — each orchestrator knows how to consume it
    install_sql: tuple[str, ...] = ()  # DDL to create empty output tables at schema-install time

@dataclass(frozen=True, slots=True)
class PlannedSQLStep(CompilationArtifact):
    view_names: tuple[str, ...]
    refresh_sql_batch: tuple[str, ...]
    fqns: tuple[str, ...]
    semi_naive_loops: tuple[PlannedSemiNaiveLoop, ...]
    install_sql_batch: tuple[str, ...] = ()

@dataclass(frozen=True, slots=True)
class SQLExecutionStep(CompilationArtifact):
    views: tuple[View, ...] = ()
    semi_naive_loops: tuple[SemiNaiveLoop, ...] = ()


@dataclass(frozen=True, slots=True)
class LogicExecutionStep(CompilationArtifact):
    lqp_plan: LogicBlock


# A step targets exactly one backend: SQL engine or logic reasoner.
ExecutionStep = SQLExecutionStep | LogicExecutionStep

@dataclass(frozen=True, slots=True)
class ExecutionPlan(CompilationArtifact):
    steps: tuple[ExecutionStep, ...] = ()


@dataclass(frozen=True, slots=True)
class LogicBlock(CompilationArtifact):
    """All information the logic reasoner needs to compile and execute a block.

    ``install_root``         — task subtree compiled and installed into the LR backend.
    ``export_query``         — task that reads results back out of the LR backend.
    ``output_table_names``   — catalog object names the LR backend materializes.
    """

    install_root: mm.Task
    export_query: mm.Task
    output_table_names: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ModelPlan(CompilationArtifact):
    catalog: Catalog
    blocks: tuple[CoalescedBlock, ...]
    version_state: BlockVersionState
    seed_object_names: tuple[str, ...] = ()
