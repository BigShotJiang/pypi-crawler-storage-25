from __future__ import annotations

import re

from ....config.config_fields import TableMaterialization


def resolve_materialization(
    name: str,
    materialization_map: dict[str, TableMaterialization],
    default: TableMaterialization = TableMaterialization.DYNAMIC_TABLE,
) -> TableMaterialization:
    if not materialization_map:
        return default
    unqualified = name.split(".")[-1].strip('"').lower()
    if unqualified in materialization_map:
        return materialization_map[unqualified]
    base_name = re.sub(r"_t\d+$", "", unqualified)
    return materialization_map.get(base_name, default)
