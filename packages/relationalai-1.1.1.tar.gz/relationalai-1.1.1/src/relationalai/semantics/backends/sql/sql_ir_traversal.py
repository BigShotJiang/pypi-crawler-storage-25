"""Generic traversal toolkit for SQL IR trees.

Two operations:

- `fold(node, step, acc)` — read-only post-order walk. Visits every IR node
  reachable from `node` (`SQLExpr`, `SQLSource`, `SQLQuery`, plus the glue
  records `SQLFromItem`/`SQLJoin`/`SQLSelectItem`/`SQLOrderItem`) and threads
  an accumulator through `step(node, acc) -> acc`.

- `transform(node, *, expr_fn, source_fn, query_fn)` — bottom-up rewrite.
  Children are rewritten first, then each `*_fn` (when provided) fires on its
  respective IR-base category. Returns the same instance when nothing
  changed (structural sharing), so callers can detect "did anything change
  this pass" with cheap `is` checks.

Both operations are dataclass-fields-driven: any field whose value is
itself an IR node is descended into, as is every IR-node element of a
tuple or list field. Leaf primitives (str, int, bool, None) are ignored.
Nested containers (e.g. `SQLValuesSource.rows: tuple[tuple[SQLExpr, ...], ...]`)
are handled uniformly. New IR node types added to sql_ir.py are picked up
automatically as long as their fields are typed as ordinary IR nodes or
tuples/lists thereof — there is nothing here to keep in sync.
"""
from __future__ import annotations

from dataclasses import fields, is_dataclass, replace
from typing import Callable, TypeVar, cast

from .sql_ir import (
    SQLExpr,
    SQLFromItem,
    SQLJoin,
    SQLOrderItem,
    SQLQuery,
    SQLSelectItem,
    SQLSource,
)

A = TypeVar("A")
T = TypeVar("T")
Step = Callable[[object, A], A]
Rewrite = Callable[[object], object]

_IR_BASES = (SQLExpr, SQLSource, SQLQuery, SQLFromItem, SQLJoin, SQLSelectItem, SQLOrderItem)


# ---------------------------------------------------------------------------
# Fold: read-only post-order walk
# ---------------------------------------------------------------------------


def _walk_value(value: object, step: Step, acc: A) -> A:
    if isinstance(value, _IR_BASES):
        return _walk_node(value, step, acc)
    if isinstance(value, (tuple, list)):
        for elem in value:
            acc = _walk_value(elem, step, acc)
    return acc


def _walk_node(node: object, step: Step, acc: A) -> A:
    if is_dataclass(node):
        for f in fields(node):
            acc = _walk_value(getattr(node, f.name), step, acc)
    return step(node, acc)


def fold(node: object, step: Step[A], acc: A) -> A:
    """Post-order fold: visit every IR node reachable from `node`, returning the final accumulator."""
    return _walk_node(node, step, acc)


# ---------------------------------------------------------------------------
# Transform / try_transform: bottom-up rewrite with structural sharing
# ---------------------------------------------------------------------------
#
# Both share one internal walker. The only difference is what a callback
# returning `None` means:
#   - transform     : None is impossible (callbacks promise to return a node).
#   - try_transform : None aborts the whole rewrite, propagating up.
# Internally the walker uses an `_ABORT` sentinel for the abort signal —
# Python `None` is reserved for legitimate field values (e.g.
# `SQLLiteral(None)`), so we can't use it as the abort marker too.

TryRewrite = Callable[[object], object | None]
_ABORT = object()


def _rewrite_value(value: object,
                   expr_fn: TryRewrite | None,
                   source_fn: TryRewrite | None,
                   query_fn: TryRewrite | None) -> object:
    if isinstance(value, _IR_BASES):
        return _rewrite_node(value, expr_fn, source_fn, query_fn)
    if isinstance(value, (tuple, list)):
        new_elems: list[object] = []
        any_changed = False
        for elem in value:
            new_elem = _rewrite_value(elem, expr_fn, source_fn, query_fn)
            if new_elem is _ABORT:
                return _ABORT
            if new_elem is not elem:
                any_changed = True
            new_elems.append(new_elem)
        if not any_changed:
            return value
        return tuple(new_elems) if isinstance(value, tuple) else new_elems
    return value


def _rewrite_node(node: object,
                  expr_fn: TryRewrite | None,
                  source_fn: TryRewrite | None,
                  query_fn: TryRewrite | None) -> object:
    # Bottom-up: rewrite every field's value first, reconstruct the node only
    # if any field actually changed, then apply the matching user fn.
    rewritten = node
    if is_dataclass(node) and not isinstance(node, type):
        changes: dict[str, object] = {}
        for f in fields(node):
            old = getattr(node, f.name)
            new = _rewrite_value(old, expr_fn, source_fn, query_fn)
            if new is _ABORT:
                return _ABORT
            if new is not old:
                changes[f.name] = new
        if changes:
            rewritten = replace(node, **changes)

    for fn, base in ((expr_fn, SQLExpr), (source_fn, SQLSource), (query_fn, SQLQuery)):
        if fn is not None and isinstance(rewritten, base):
            result = fn(rewritten)
            if result is None:
                return _ABORT
            rewritten = result
    return rewritten


def transform(node: T,
              *,
              expr_fn: Rewrite | None = None,
              source_fn: Rewrite | None = None,
              query_fn: Rewrite | None = None) -> T:
    """Bottom-up rewrite. Each `*_fn`, when given, fires on every reachable
    node of its IR base category (post-order — children rewritten first).

    Returns the same instance when nothing changed (structural sharing).
    Callbacks must return a node — None is reserved for `try_transform`.
    """
    result = _rewrite_node(node, expr_fn, source_fn, query_fn)
    assert result is not _ABORT, "transform callback returned None; use try_transform for fail-stop semantics"
    return cast(T, result)


def try_transform(node: T, *, expr_fn: TryRewrite) -> T | None:
    """Bottom-up rewrite with fail-stop semantics: if `expr_fn` returns None
    for any expression, the whole rewrite aborts and `None` propagates up.

    Used by passes that need to substitute column references but must back
    out atomically when one ref can't be resolved.
    """
    result = _rewrite_node(node, expr_fn, None, None)
    if result is _ABORT:
        return None
    return cast(T, result)
