"""Orchestrator: metadata plan table management and Snowflake refresh task support.
"""

from __future__ import annotations

import re
from pathlib import Path

from ....config.config_fields import DEFAULT_TABLE_MATERIALIZATION, TableMaterialization
from ._utils import resolve_materialization
from typing import TYPE_CHECKING, Callable

from pandas import DataFrame

if TYPE_CHECKING:
    import snowflake.snowpark
    from .artifacts import LogicExecutionStep, PlannedSQLStep
    from ..sql_executor import SQLExecutor



_SQL_TEMPLATES_DIR = Path(__file__).parent / "sql_templates"
_JS_PROCEDURES_DIR = _SQL_TEMPLATES_DIR / "js_procedures"


def _load_sql_template(name: str, **kwargs: str) -> str:
    return (_SQL_TEMPLATES_DIR / name).read_text().format(**kwargs)


def _load_js_procedure(name: str, **kwargs: str) -> str:
    lib_path = _JS_PROCEDURES_DIR / "lib.js"
    js_parts: list[str] = []
    if lib_path.exists():
        js_parts.append(lib_path.read_text())
    js_parts.append((_JS_PROCEDURES_DIR / f"{name}.js").read_text())
    js_body = "\n\n".join(part.rstrip() for part in js_parts if part)
    return _load_sql_template(f"js_procedures/{name}.sql", js_body=js_body, **kwargs)


# ---------------------------------------------------------------------------
# PlanTable
# ---------------------------------------------------------------------------

# Each entry: (target_table_names, block_index, sql_statements, reasoner, refresh_interval_minutes)
# refresh_interval_minutes == 0 means "no scheduled refresh".
PlanEntry = tuple[str, int, str, str, int]


class PlanTable:

    def __init__(self, execute_sql: Callable[[str], DataFrame]) -> None:
        self._execute_sql = execute_sql

    def create(self, meta_schema: str) -> None:
        """Create the plan (and refresh log) tables in *meta_schema*.

        Recreates the PLAN table from scratch on every install so that stale
        entries from a previous version of the model are removed.
        """
        self._execute_sql(f"CREATE SCHEMA IF NOT EXISTS {meta_schema}")
        self._execute_sql(
            f"CREATE OR REPLACE HYBRID TABLE {meta_schema}.PLAN ("
            "entry_id INTEGER PRIMARY KEY, "
            "target_table_names VARCHAR, "
            "block_index INTEGER, "
            "sql_statements VARCHAR, "
            "reasoner VARCHAR, "
            "refresh_interval_minutes INTEGER)"
        )
        self._execute_sql(
            f"CREATE OR REPLACE HYBRID TABLE {meta_schema}.REFRESH_LOG ("
            "log_id INTEGER AUTOINCREMENT PRIMARY KEY, "
            "target_table_names VARCHAR NOT NULL, "
            "block_index INTEGER, "
            "run_start_time TIMESTAMP_LTZ NOT NULL, "
            "run_end_time TIMESTAMP_LTZ, "
            "state VARCHAR NOT NULL, "
            "error_message VARCHAR)"
        )

    def write_entries(self, meta_schema: str, entries: list[PlanEntry]) -> None:
        self.create(meta_schema)
        if not entries:
            return

        def _esc(s: str) -> str:
            return "'" + s.replace("'", "''") + "'"

        rows = ", ".join(
            f"({idx}, {_esc(e[0])}, {e[1]}, {_esc(e[2])}, {_esc(e[3])}, {e[4]})"
            for idx, e in enumerate(entries)
        )
        self._execute_sql(f"INSERT INTO {meta_schema}.plan VALUES {rows}")


# ---------------------------------------------------------------------------
# Orchestrator (no-op base — used for DuckDB)
# ---------------------------------------------------------------------------

class Orchestrator:
    """No-op orchestrator used for backends that do not support plan tables or refresh tasks."""

    def __init__(
        self,
        sql_executor: SQLExecutor,
    ) -> None:
        self._sql_executor = sql_executor
        self._install_actions: list[Callable[[], None]] = []

    def register_sql_block(
        self,
        block_index: int,
        steps: "list[PlannedSQLStep]",
    ) -> None:
        sql_executor = self._sql_executor
        if sql_executor is None or not steps:
            return
        plan = list(steps)
        self._install_actions.append(lambda plan=plan, sql_executor=sql_executor: sql_executor.execute_block(plan))

    def register_logic_block(
        self,
        block_index: int,
        block: LogicExecutionStep,
        run_sql: str,
        schema_only_sql: tuple[str, ...] = (),
    ) -> None:
        raise NotImplementedError(
            "Logic blocks are not supported in the base Orchestrator. Use SnowflakeOrchestrator instead.",
        )

    def finalize(self) -> None:
        for action in self._install_actions:
            action()


# ---------------------------------------------------------------------------
# SnowflakeOrchestrator
# ---------------------------------------------------------------------------

class SnowflakeOrchestrator(Orchestrator):
    """Orchestrator for Snowflake backends: writes plan entries and manages refresh tasks."""

    def __init__(
        self,
        session: "snowflake.snowpark.Session",
        app_name: str,
        sql_executor: SQLExecutor,
        meta_schema: str,
        schedule_cfg: object,
    ) -> None:
        super().__init__(sql_executor)
        self._plan_table = PlanTable(execute_sql=sql_executor.execute_sql)
        self._snowflake_task_manager = SnowflakeTaskManager(session, app_name)
        self._meta_schema = meta_schema
        self._refresh_cfg = schedule_cfg
        table_refresh_intervals: dict[str, int] = getattr(schedule_cfg, "table_intervals", {}) if schedule_cfg else {}
        self._refresh_interval_normalized: dict[str, int] = {k.lower(): v for k, v in table_refresh_intervals.items()}
        self._refresh_interval_default: int = getattr(schedule_cfg, "interval_mins", None) or 0
        table_materialization: dict[str, TableMaterialization] = getattr(schedule_cfg, "table_materialization", {}) if schedule_cfg else {}
        self._materialization_normalized: dict[str, TableMaterialization] = {k.lower(): v for k, v in (table_materialization or {}).items()}
        self._materialization_default: TableMaterialization = getattr(schedule_cfg, "table_materialization_default", DEFAULT_TABLE_MATERIALIZATION)
        self._plan_entries: list[PlanEntry] = []
        self._install_sql: list[str] = []

    def register_sql_block(
        self,
        block_index: int,
        steps: "list[PlannedSQLStep]",
    ) -> None:
        """Accumulate a single plan entry for an entire SQL block (Snowflake only).

        Combines all SQL steps and semi-naive loops belonging to one execution
        block into one :data:`PlanEntry` in their original execution order, so
        the refresh procedure can replay the whole block atomically.

        Args:
            block_index: Index of the execution block.
            steps: Planned SQL steps for the block.
        """
        if self._snowflake_task_manager is None:
            return
        if not steps:
            return

        all_sql: list[str] = []
        all_names: list[str] = []
        block_interval: int = 0

        for step in steps:
            self._install_sql.extend(stmt for stmt in step.install_sql_batch if stmt)
            for sql_str, view_name, fqn in zip(step.refresh_sql_batch, step.view_names, step.fqns):
                materialization = resolve_materialization(
                    view_name, self._materialization_normalized, self._materialization_default,
                )
                if materialization == TableMaterialization.VIEW:
                    # Views are installed once at finalize via _install_sql
                    # (install_table_ddl_for_view returns the CREATE VIEW verbatim for
                    # view-typed outputs). Excluding them from the plan SQL means refresh
                    # tasks never replay the CREATE VIEW DDL. However, we still list them in
                    # target_table_names to track block affiliation.
                    all_names.append(view_name)
                    continue
                if re.search(r'\bDYNAMIC\s+TABLE\b', sql_str, re.IGNORECASE):
                    plan_sql = SnowflakeTaskManager.dynamic_table_refresh_sql(fqn, self._meta_schema)
                else:
                    plan_sql = sql_str
                all_sql.append(plan_sql)
                all_names.append(view_name)
                interval = self._resolve_refresh_interval(view_name)
                if interval != 0 and (block_interval == 0 or interval < block_interval):
                    block_interval = interval
            for loop in step.semi_naive_loops:
                self._install_sql.extend(stmt for stmt in loop.install_sql if stmt)
                intervals = [self._resolve_refresh_interval(t) for t in loop.table_names]
                non_zero = [i for i in intervals if i != 0]
                interval = min(non_zero) if non_zero else 0
                if interval != 0 and (block_interval == 0 or interval < block_interval):
                    block_interval = interval
                assert isinstance(loop.plan, str), "In Snowflake, semi-naive plans must be SQL strings."
                all_sql.append(loop.plan)
                all_names.append(", ".join(loop.table_names))

        if not all_sql:
            # Block had only view-typed outputs — nothing to refresh, no plan entry.
            return

        self._plan_entries.append((
            ", ".join(all_names), block_index,
            "\n".join(s.rstrip().rstrip(";") + ";" for s in all_sql), "sql", block_interval,
        ))

    def register_logic_block(
        self,
        block_index: int,
        block: LogicExecutionStep,
        run_sql: str,
        schema_only_sql: tuple[str, ...] = (),
    ) -> None:
        """Accumulate a plan entry for a logic-reasoner block execution.

        The ``reasoner`` column is set to ``"logic"`` so the refresh procedure can dispatch
        back to the logic reasoner rather than re-executing SQL. One entry is written per
        logic block; ``block_index`` equals the block index (one step per block).

        Args:
            block_index: Block index — equals the execution block's index.
            output_tables: Output table names of the logic step to record.
        """
        if self._snowflake_task_manager is None:
            return
        self._install_sql.extend(stmt for stmt in schema_only_sql if stmt)
        intervals = [self._resolve_refresh_interval(t) for t in block.lqp_plan.output_table_names]
        non_zero = [i for i in intervals if i != 0]
        interval = min(non_zero) if non_zero else 0
        self._plan_entries.append(
            (",".join(block.lqp_plan.output_table_names), block_index, run_sql, "logic", interval,
        ))

    def finalize(self) -> None:
        """Write plan entries, create procedures, run initial data population, and create refresh tasks."""
        self._plan_table.write_entries(self._meta_schema, self._plan_entries)
        self._create_refresh_procedures()
        if self._install_sql:
            self._sql_executor.execute_sql_batch(self._install_sql)
        # Currently, we still trigger the initial execution synchronously.
        # TODO: perform this async as soon as we enforce a clear separation between model
        # and query.
        self._snowflake_task_manager.session.sql(f"CALL {self._meta_schema}.REFRESH_MODEL(-1)").collect()
        self._create_refresh_tasks_if_configured()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _create_refresh_procedures(self) -> None:
        # TODO: batch procedure creation into a single sql call
        self._snowflake_task_manager.create_poll_until_done_procedure(self._meta_schema)
        self._snowflake_task_manager.create_poll_use_index_until_ready_procedure(self._meta_schema)
        self._snowflake_task_manager.create_run_lqp_block_procedure(self._meta_schema)
        self._snowflake_task_manager.create_refresh_procedure(self._meta_schema)

    def _create_refresh_tasks_if_configured(self) -> None:
        if self._refresh_cfg is None or getattr(self._refresh_cfg, "interval_mins", None) is None:
            return
        self._snowflake_task_manager.drop_refresh_tasks(meta_schema=self._meta_schema)
        unique_intervals: set[int] = {e[4] for e in self._plan_entries if e[4] != 0}
        for interval in unique_intervals:
            self._snowflake_task_manager.create_refresh_task(
                meta_schema=self._meta_schema,
                interval_mins=interval,
                warehouse=self._snowflake_task_manager.session.get_current_warehouse(),
            )

    def _resolve_refresh_interval(self, view_name: str) -> int:
        """Return the refresh interval in minutes for *view_name*, or 0 if none configured.

        Looks up *view_name* (unqualified, case-insensitive) in
        ``refresh_cfg.table_intervals``, falling back to
        ``refresh_cfg.interval_mins``.  Returns ``0`` when no
        ``refresh_cfg`` was provided.

        Internal entity store tables are named ``{concept}_t{id}`` after
        ``_safe_identifier`` collapses double underscores (e.g.
        ``connection_t806``).  A key of ``"connection"`` in ``table_intervals``
        is therefore matched against the concept-name prefix by stripping the
        trailing ``_t<digits>`` suffix before the lookup.
        """
        if not self._refresh_interval_normalized:
            return self._refresh_interval_default
        unqualified = view_name.split(".")[-1].lower()
        if unqualified in self._refresh_interval_normalized:
            return self._refresh_interval_normalized[unqualified]
        base_name = re.sub(r"_t\d+$", "", unqualified)
        return self._refresh_interval_normalized.get(base_name, self._refresh_interval_default)


# ---------------------------------------------------------------------------
# SnowflakeTaskManager
# ---------------------------------------------------------------------------

class SnowflakeTaskManager:

    def __init__(self, session: "snowflake.snowpark.Session", app_name: str) -> None:
        self.session = session
        self._app_name = app_name

    # ------------------------------------------------------------------
    # Dynamic tables
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_fqn(table_name: str) -> list[str]:
        """Split a (possibly quoted) Snowflake FQN into unquoted component strings."""
        parts = []
        for part in table_name.split("."):
            part = part.strip()
            if part.startswith('"') and part.endswith('"'):
                part = part[1:-1].replace('""', '"')
            parts.append(part)
        return parts

    @staticmethod
    def dynamic_table_refresh_sql(table_name: str, meta_schema: str) -> str:
        """Return a Snowflake Scripting block that triggers a dynamic table refresh
        and polls until a terminal state is reached.

        Using ``SCHEDULER = DISABLE`` means no automatic cascade, so each refresh
        must be triggered and awaited explicitly.

        Args:
            table_name: Fully-qualified table name.
            meta_schema: Fully-qualified meta schema (e.g. ``MY_DB.MY_SCHEMA_META``).
        """
        parts = SnowflakeTaskManager._parse_fqn(table_name)

        if len(parts) >= 3:
            db, schema, tbl = parts[0], parts[1], parts[2]
            info_schema = f'"{db}".INFORMATION_SCHEMA'
            history_args = f"NAME => '{db}.{schema}.{tbl}'"
        elif len(parts) == 2:
            schema, tbl = parts[0], parts[1]
            info_schema = "INFORMATION_SCHEMA"
            history_args = f"NAME => '{schema}.{tbl}'"
        else:
            info_schema = "INFORMATION_SCHEMA"
            history_args = f"NAME => '{parts[0]}'"

        # Single-quotes inside history_args are embedded in a SQL string literal
        # inside the template, so they must be escaped as ''.
        return _load_sql_template(
            "dynamic_table_refresh.sql",
            table_name=table_name,
            info_schema=info_schema,
            history_args=history_args.replace("'", "''"),
            meta_schema=meta_schema,
        )

    # ------------------------------------------------------------------
    # Refresh task
    # ------------------------------------------------------------------

    @staticmethod
    def _procedure_name(meta_schema: str) -> str:
        return f"{meta_schema}.REFRESH_MODEL"

    @staticmethod
    def _get_run_lqp_block_procedure_name(meta_schema: str) -> str:
        return f"{meta_schema}.RUN_LQP_BLOCK"

    @staticmethod
    def _task_name(meta_schema: str, interval_mins: int) -> str:
        return f"{meta_schema}.REFRESH_TASK_{interval_mins}MIN"

    def create_poll_until_done_procedure(self, meta_schema: str) -> None:
        """Create the ``POLL_UNTIL_DONE`` JavaScript stored procedure.

        The procedure polls a query with capped exponential backoff until the
        result matches one of the provided terminal states.

        Args:
            meta_schema: Fully-qualified meta schema (e.g. ``MY_DB.MY_SCHEMA_META``).
        """
        proc_sql = _load_js_procedure("poll_until_done", schema=meta_schema)
        self.session.sql(proc_sql).collect()

    def create_poll_use_index_until_ready_procedure(self, meta_schema: str) -> None:
        proc_sql = _load_js_procedure("poll_use_index_until_ready", schema=meta_schema)
        self.session.sql(proc_sql).collect()

    def create_run_lqp_block_procedure(self, meta_schema: str) -> str:
        proc_name = self._get_run_lqp_block_procedure_name(meta_schema)
        proc_sql = _load_js_procedure(
            "run_lqp_block",
            schema=meta_schema,
            app_name=self._app_name,
        )
        self.session.sql(proc_sql).collect()
        return proc_name

    def create_refresh_procedure(self, meta_schema: str) -> str:
        """Create the ``REFRESH_MODEL`` stored procedure.

        Args:
            meta_schema: Fully-qualified meta schema.

        Returns:
            The fully-qualified procedure name.
        """
        proc_name = self._procedure_name(meta_schema)
        proc_sql = _load_sql_template(
            "refresh_procedure.sql",
            proc_name=proc_name,
            meta_schema=meta_schema,
        )
        self.session.sql(proc_sql).collect()
        return proc_name

    def create_refresh_task(
        self,
        meta_schema: str,
        interval_mins: int,
        warehouse: str | None = None,
    ) -> None:
        """Create and resume a Snowflake scheduled task that calls the refresh procedure.

        Args:
            meta_schema: Fully-qualified meta schema.
            interval_mins: How often the task runs, in minutes.
            warehouse: Snowflake warehouse for the task. If ``None``, uses serverless
                compute (``USER_TASK_MANAGED_INITIAL_WAREHOUSE_SIZE = 'XSMALL'``).
        """
        proc_name = self._procedure_name(meta_schema)
        task_name = self._task_name(meta_schema, interval_mins)
        warehouse_clause = (
            f"WAREHOUSE = {warehouse}"
            if warehouse
            else "USER_TASK_MANAGED_INITIAL_WAREHOUSE_SIZE = 'XSMALL'"
        )
        task_sql = _load_sql_template(
            "refresh_task.sql",
            task_name=task_name,
            warehouse_clause=warehouse_clause,
            interval_mins=str(interval_mins),
            proc_name=proc_name,
        )
        self.session.sql(task_sql).collect()
        self.session.sql(f"ALTER TASK {task_name} RESUME").collect()

    def drop_refresh_tasks(self, meta_schema: str) -> None:
        """Drop all refresh tasks and the refresh procedure.

        Called before recreating them so that changed intervals take effect.

        Args:
            meta_schema: Fully-qualified meta schema.
        """
        rows = self.session.sql(
            f"SHOW TASKS LIKE 'REFRESH_TASK_%' IN SCHEMA {meta_schema}"
        ).collect()
        for row in rows:
            task_name = f"{meta_schema}.{row['name']}"
            self.session.sql(f"DROP TASK IF EXISTS {task_name}").collect()
