"""SQL IR-level optimizations for the sql backend.

Optimizations applied after lowering, before emitting:

  Plan-level passes (applied once per execution step):
    SingleConsumerInline    — Inline views that are consumed by exactly one other view

  View-level passes (applied bottom-up inside each view's query, iterated to fixpoint):
    SingleBranchUnionElim   — Remove double-paren wrapper from a single-branch UNION ALL
    UnionToValuesLift       — Singleton UNION ALL of same-structure branches → single SELECT over VALUES
    AggSubqueryFlatten      — Push MAX through a pure-projection subquery into the subquery itself
    ProjectOverAggregateFold — Inline a pure projection on top of an aggregating subquery into it
    SingletonFromLift       — Eliminate FROM (SELECT 1) when the singleton contributes no columns
    DeadLeftJoinElim        — Drop LEFT JOINs whose alias is never referenced anywhere in the query
    DeadSubqueryColumnPrune — Remove SELECT items from subqueries that the outer query never references
    DistinctBeforeGroupByElim — Drop DISTINCT from an inner subquery consumed by an outer GROUP BY with no aggregates
    DoubleNegElim+TrivialConditionElim — Eliminate NOT(NOT(x)), drop trivially-true IS NOT NULL guards,
                              and drop WHERE/JOIN ON conditions that are always TRUE (SQLLiteral(True))
    JoinImpliedNullGuardElim — Drop IS NOT NULL WHERE guards already implied by a JOIN equi-condition
    RedundantCastElim       — Drop CAST(expr AS T) when expr already has type T
    RedundantDistinctElim   — Drop SELECT DISTINCT when uniqueness is already guaranteed (VALUES rows, UNION source, GROUP BY, or entity-store _id)
    DistinctWrapperElim     — Inline a pass-through SELECT DISTINCT wrapper into its inner subquery
"""
from __future__ import annotations

import re

from .artifacts import ExecutionPlan, SQLExecutionStep, SemiNaiveLoop, SemiNaiveTable, View
from .sql_ir import (
    SQLBinaryOp,
    SQLCast,
    SQLColumnRef,
    SQLConcat,
    SQLExpr,
    SQLFromItem,
    SQLFunctionCall,
    SQLIsNotNull,
    SQLJoin,
    SQLLiteral,
    SQLNot,
    SQLQuery,
    SQLSelectItem,
    SQLSelectQuery,
    SQLSingletonSource,
    SQLSource,
    SQLSubquerySource,
    SQLTableSource,
    SQLTryCast,
    SQLUnionQuery,
    SQLValuesSource,
)
from .sql_ir_traversal import fold, transform, try_transform


# SQL reserved keywords that are unsafe to use as unquoted column names in VALUES clauses.
_SQL_RESERVED_KEYWORDS: frozenset[str] = frozenset({
    "all", "alter", "and", "any", "as", "asc", "between", "by", "case",
    "check", "constraint", "create", "cross", "current", "default", "delete",
    "desc", "distinct", "drop", "else", "end", "except", "exists", "false",
    "first", "following", "foreign", "from", "full", "group", "having",
    "in", "index", "inner", "insert", "intersect", "into", "is", "join",
    "key", "last", "left", "like", "limit", "natural", "not", "null",
    "offset", "on", "or", "order", "outer", "over", "partition", "preceding",
    "primary", "range", "references", "right", "row", "rows", "select",
    "set", "some", "table", "then", "true", "unbounded", "union", "unique",
    "update", "using", "values", "view", "when", "where", "window", "with",
})


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


class SQLOptimizer:
    """SQL IR-level optimization pass; runs after lowering, before emitting.

    Set ``enabled = False`` (or the env var ``PYREL__OPTIMIZER=0``) to
    bypass all optimizations and emit raw lowered SQL.
    """

    enabled: bool = True

    def __init__(self) -> None:
        import os
        env = os.environ.get("PYREL__OPTIMIZER", "").strip()
        if env == "0":
            self.enabled = False

    def optimize_query(self, query: SQLQuery) -> SQLQuery:
        """Apply view-level optimizations to a fragment query."""
        if not self.enabled:
            return query
        return _apply_query_opts(query)

    def optimize_plan(self, plan: ExecutionPlan) -> ExecutionPlan:
        if not self.enabled:
            return plan
        # For each step, collect view names that are referenced from outside it.
        external_refs_per_step = _compute_external_refs(plan)
        return ExecutionPlan(
            steps=tuple(
                _optimize_step(step, external_refs) if isinstance(step, SQLExecutionStep) else step
                for step, external_refs in zip(plan.steps, external_refs_per_step)
            )
        )


# ---------------------------------------------------------------------------
# Program-level driver
# ---------------------------------------------------------------------------


def _optimize_semi_naive_table(t: SemiNaiveTable) -> SemiNaiveTable:
    """Apply query optimizations to every query of a SemiNaiveTable."""
    return SemiNaiveTable(
        table_name=t.table_name,
        columns=t.columns,
        base_query=_apply_query_opts(t.base_query),
        delta_query=_apply_query_opts(t.delta_query),
        merge_query=_apply_query_opts(t.merge_query),
        next_delta_query=_apply_query_opts(t.next_delta_query),
        final_query=_apply_query_opts(t.final_query),
        accum_view_name=t.accum_view_name,
        delta_view_name=t.delta_view_name,
        next_accum_view_name=t.next_accum_view_name,
        next_delta_view_name=t.next_delta_view_name,
        column_types=t.column_types,
    )


def _optimize_step(
    step: SQLExecutionStep, external_refs: set[str]
) -> SQLExecutionStep:
    """Apply all optimizer passes to a single execution step until no further changes."""
    views = list(step.views)
    while True:
        prev = views

        # UnionToValuesLift, AggSubqueryFlatten, ProjectOverAggregateFold, etc.: applied bottom-up inside each view's query
        views = [View(name=v.name, query=_apply_query_opts(v.query), column_types=v.column_types) for v in views]

        # SingleConsumerInline: inline single-consumer views
        views = _inline_single_consumer_views(views, external_refs)

        if views == prev:
            break

    semi_naive_loops = tuple(
        SemiNaiveLoop(tables=tuple(_optimize_semi_naive_table(t) for t in loop.tables))
        for loop in step.semi_naive_loops
    )
    return SQLExecutionStep(views=tuple(views), semi_naive_loops=semi_naive_loops)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _is_staging_view(name: str) -> bool:
    """Return True for internal staging views (e.g. Person_t781__stage_2)."""
    local = name.split(".")[-1].strip('"')
    return "__" in local


# ---------------------------------------------------------------------------
# RedundantDistinctElim — Drop redundant DISTINCT when inner subquery GROUP BY guarantees uniqueness
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Uniqueness oracle — _id semantic guarantees
# ---------------------------------------------------------------------------

# Entity-store views are named <TypeName>_t<id> (no "rel_" prefix, ends _t<digits>).
# Relation stores are named rel_<name>_<Type>_<Type>.
# The _id column is a reserved name for entity identity: always an MD5 hash, always non-null,
# and guaranteed unique within any entity-store view (deduped by GROUP BY "_id" at write time).
_ENTITY_TABLE_RE = re.compile(r"(?:.*\.)?[A-Za-z]\w*_t\d+$")


def _is_entity_store_table(name: str) -> bool:
    """Return True if name is an entity-store table (TypeName_tNNN pattern).

    Entity stores have a unique, non-null _id column. Relation stores use the
    rel_<name>_<Type>_<Type> naming convention and are excluded.
    """
    return bool(_ENTITY_TABLE_RE.match(name))


def _source_has_unique_id(source: SQLSource) -> bool:
    """Return True if source guarantees that its _id column values are unique.

    Two cases:
    - A direct entity-store table reference (_id is the deduplication key).
    - A subquery whose own GROUP BY includes "_id" (the group key is unique).
    """
    if isinstance(source, SQLTableSource):
        return _is_entity_store_table(source.name)
    if isinstance(source, SQLSubquerySource):
        q = source.query
        if isinstance(q, SQLSelectQuery):
            return any(
                isinstance(g, SQLColumnRef) and g.column_name == "_id"
                for g in q.group_by
            )
    return False


def _columns_are_unique(query: SQLSelectQuery) -> bool:
    """Return True if the query's SELECT output is guaranteed to contain unique rows.

    Three cases:

    1. GROUP BY on non-constant keys when every SELECT item is a group key or
       aggregate — GROUP BY already produces one row per unique key combination.

    2. _id from an entity-store source with only LEFT JOINs — entity stores
       guarantee unique _id, and LEFT JOINs never multiply the left-hand rows.

    3. _id from a subquery that itself groups by _id (same argument as case 2
       but the uniqueness comes from the subquery's own GROUP BY).
    """
    # Case 1: GROUP BY uniqueness (mirrors RedundantDistinctElim Case 2)
    if query.group_by and not all(isinstance(g, SQLLiteral) for g in query.group_by):
        if all(
            any(item.expr == g for g in query.group_by) or _is_aggregate_expr(item.expr)
            for item in query.select
        ):
            return True

    # Cases 2 & 3: _id from a unique source, no row-multiplying joins
    id_aliases: set[str | None] = {
        item.expr.table_alias
        for item in query.select
        if isinstance(item.expr, SQLColumnRef) and item.expr.column_name == "_id"
    }
    if not id_aliases:
        return False

    # Build alias → source map for FROM + all JOINs
    alias_to_source: dict[str | None, SQLSource] = {}
    if query.from_item is not None:
        alias_to_source[query.from_item.alias] = query.from_item.source
    for j in query.joins:
        alias_to_source[j.alias] = j.source

    # At least one _id alias must point to a source with guaranteed unique _id
    entity_id_aliases = {
        alias
        for alias in id_aliases
        if alias in alias_to_source and _source_has_unique_id(alias_to_source[alias])
    }
    if not entity_id_aliases:
        return False

    # The FROM item must itself be the entity source (or a subquery we trust).
    # If FROM is a different table, it acts as an implicit INNER JOIN that can
    # multiply rows for each entity row.
    if query.from_item is not None and query.from_item.alias not in entity_id_aliases:
        return False

    # Every join that is not one of our unique-id sources must be a LEFT JOIN
    # (LEFT JOINs never multiply left-hand rows; INNER JOINs may).
    for j in query.joins:
        if j.alias in entity_id_aliases:
            continue
        if "LEFT" not in j.kind.upper():
            return False

    return True


# ---------------------------------------------------------------------------
# Aggregate helper
# ---------------------------------------------------------------------------

_AGGREGATE_FUNCTION_NAMES = frozenset({"COUNT", "SUM", "AVG", "MIN", "MAX"})


def _is_aggregate_expr(expr: SQLExpr) -> bool:
    """Return True if expr is an aggregate function call, possibly wrapped in CAST/TRY_CAST."""
    while isinstance(expr, (SQLCast, SQLTryCast)):
        expr = expr.expr
    return isinstance(expr, SQLFunctionCall) and expr.name.upper() in _AGGREGATE_FUNCTION_NAMES


def _drop_redundant_distinct(query: SQLQuery) -> SQLQuery:
    """RedundantDistinctElim: Remove DISTINCT when row uniqueness is already guaranteed.

    Case 1 — FROM is a VALUES source whose rows are all syntactically distinct:
      Each SELECT expression (MD5, CAST, etc.) produces a unique output row,
      so DISTINCT is a no-op. Only fires with no JOINs, WHERE, or GROUP BY.

    Case 2 — FROM is a UNION (not UNION ALL) subquery, full pass-through projection:
      UNION already deduplicates. An outer DISTINCT over a full column-ref pass-through
      adds nothing. All outer SELECT items must be column refs and the outer must select
      all columns of the inner.

    Case 3 — DISTINCT with no own GROUP BY, FROM subquery has GROUP BY all-constants:
      GROUP BY on a constant collapses all rows into one group (at most one output row),
      so DISTINCT on that one row is always a no-op.

    Case 4 — DISTINCT on a query that itself has GROUP BY on non-constant keys:
      GROUP BY guarantees exactly one row per unique combination of group-key values.
      When every projected column is either a GROUP BY expression or an aggregate
      function call (possibly CAST-wrapped), the output is already unique per group,
      so DISTINCT is redundant.

    Case 5 — DISTINCT on a query whose SELECT includes _id from an entity-store source
      with only LEFT JOINs:
      Entity stores guarantee unique _id; LEFT JOINs never multiply left-hand rows,
      so the output rows are already unique on _id and therefore overall.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.distinct:
        return query

    # Case 1: VALUES source with all-unique rows
    if not query.joins and not query.where and not query.group_by:
        if query.from_item is not None and isinstance(query.from_item.source, SQLValuesSource):
            rows = query.from_item.source.rows
            if len(rows) == len(set(rows)):
                return SQLSelectQuery(
                    from_item=query.from_item, joins=query.joins, where=query.where,
                    select=query.select, group_by=query.group_by, order_by=query.order_by,
                    distinct=False, limit=query.limit,
                )

    # Case 2: full pass-through over a UNION subquery
    if not query.group_by and not query.where and not query.joins and query.from_item is not None:
        if isinstance(query.from_item.source, SQLSubquerySource):
            inner = query.from_item.source.query
            if isinstance(inner, SQLUnionQuery) and inner.operator == "UNION":
                outer_alias = query.from_item.alias
                all_col_refs = all(
                    isinstance(item.expr, SQLColumnRef) and
                    (item.expr.table_alias is None or item.expr.table_alias == outer_alias)
                    for item in query.select
                )
                first_branch = inner.queries[0]
                if (all_col_refs and isinstance(first_branch, SQLSelectQuery)
                        and len(query.select) == len(first_branch.select)):
                    return SQLSelectQuery(
                        from_item=query.from_item, joins=query.joins, where=query.where,
                        select=query.select, group_by=query.group_by, order_by=query.order_by,
                        distinct=False, limit=query.limit,
                    )

    # Case 3: no own GROUP BY; FROM subquery groups by all-constants
    if not query.group_by and not query.joins and not query.where:
        if query.from_item is not None and isinstance(query.from_item.source, SQLSubquerySource):
            inner = query.from_item.source.query
            if isinstance(inner, SQLSelectQuery) and inner.group_by:
                if all(isinstance(g, SQLLiteral) for g in inner.group_by):
                    return SQLSelectQuery(
                        from_item=query.from_item, joins=query.joins, where=query.where,
                        select=query.select, group_by=query.group_by, order_by=query.order_by,
                        distinct=False, limit=query.limit,
                    )

    # Cases 4 & 5: delegate to the uniqueness oracle
    if _columns_are_unique(query):
        return SQLSelectQuery(
            from_item=query.from_item, joins=query.joins, where=query.where,
            select=query.select, group_by=query.group_by, order_by=query.order_by,
            distinct=False, limit=query.limit,
        )

    return query


# ---------------------------------------------------------------------------
# JoinImpliedNullGuardElim — Drop IS NOT NULL guards made redundant by JOIN equi-conditions
# ---------------------------------------------------------------------------


def _drop_join_constrained_null_guards(query: SQLQuery) -> SQLQuery:
    """JoinImpliedNullGuardElim: Remove WHERE `col IS NOT NULL` conditions that are already implied
    by a JOIN equi-condition on the same column.

    A JOIN ON (a.x = b.y) guarantees both sides are non-NULL (NULL fails =),
    so any `IS NOT NULL(a.x)` or `IS NOT NULL(b.y)` in WHERE is redundant.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.where or not query.joins:
        return query

    # Collect (table_alias, column_name) pairs from JOIN equi-conditions
    join_eq_cols: set[tuple[str | None, str]] = set()
    for j in query.joins:
        for cond in j.conditions:
            if isinstance(cond, SQLBinaryOp) and cond.operator == "=":
                for side in (cond.left, cond.right):
                    if isinstance(side, SQLColumnRef):
                        join_eq_cols.add((side.table_alias, side.column_name))

    if not join_eq_cols:
        return query

    def _redundant(expr: SQLExpr) -> bool:
        if isinstance(expr, SQLIsNotNull) and isinstance(expr.expr, SQLColumnRef):
            col = expr.expr
            return (col.table_alias, col.column_name) in join_eq_cols
        return False

    new_where = tuple(c for c in query.where if not _redundant(c))
    if new_where == query.where:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=query.joins,
        where=new_where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# DistinctWrapperElim — Inline redundant pass-through SELECT DISTINCT wrapper
# ---------------------------------------------------------------------------


def _inline_passthrough_wrapper(query: SQLQuery) -> SQLQuery:
    """DistinctWrapperElim: Remove an outer SELECT DISTINCT that is a pure pass-through over an
    inner SQLSelectQuery subquery.

    Pattern:
        SELECT DISTINCT merged."c1" AS "c1", merged."c2" AS "c2", ...
        FROM (inner_select) AS merged

    When:
      - No JOINs, WHERE, GROUP BY, ORDER BY, LIMIT on the outer query
      - All SELECT items are SQLColumnRef(name) AS name  (identity projections)
      - The inner query is a SQLSelectQuery

    Action: return inner_select with distinct=True, discarding the wrapper.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if (
        query.joins
        or query.where
        or query.group_by
        or query.order_by
        or query.limit is not None
        or not query.distinct
        or query.from_item is None
    ):
        return query
    if not isinstance(query.from_item.source, SQLSubquerySource):
        return query
    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query

    # Verify every outer SELECT item is an identity column ref
    outer_alias = query.from_item.alias
    for item in query.select:
        if not isinstance(item.expr, SQLColumnRef):
            return query
        col = item.expr
        # Must reference the subquery alias (or no alias) and match output alias
        if col.table_alias is not None and col.table_alias != outer_alias:
            return query
        expected_alias = item.alias if item.alias is not None else col.column_name
        if col.column_name != expected_alias:
            return query

    # Safe to inline: return inner with distinct forced on
    if inner.distinct:
        return inner
    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=inner.select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=True,
        limit=inner.limit,
    )


# ---------------------------------------------------------------------------
# UnionToValuesLift, AggSubqueryFlatten, ProjectOverAggregateFold — applied together via recursive bottom-up query walk
# ---------------------------------------------------------------------------


def _apply_local_query_opts(query: SQLQuery) -> SQLQuery:
    """Apply every optimization pass once at this query level. Children are
    handled by the caller's `transform` recursion."""
    query = _unwrap_single_branch_union(query)         # SingleBranchUnionElim
    query = _singleton_union_to_values(query)          # UnionToValuesLift
    query = _aggregate_subquery_flatten(query)         # AggSubqueryFlatten
    query = _project_over_aggregate_fold(query)        # ProjectOverAggregateFold
    query = _lift_singleton_from(query)                # SingletonFromLift
    query = _reorder_lateral_joins(query)              # LateralJoinReorder
    query = _drop_dead_left_joins(query)               # DeadLeftJoinElim
    query = _prune_dead_subquery_columns(query)        # DeadSubqueryColumnPrune
    query = _drop_distinct_before_group_by(query)      # DistinctBeforeGroupByElim
    query = _simplify_negations_in_query(query)        # DoubleNegElim+TrivialConditionElim
    query = _drop_join_constrained_null_guards(query)  # JoinImpliedNullGuardElim
    query = _simplify_casts_in_query(query)            # RedundantCastElim
    query = _drop_redundant_distinct(query)            # RedundantDistinctElim
    query = _inline_passthrough_wrapper(query)         # DistinctWrapperElim
    return query


def _apply_query_opts(query: SQLQuery) -> SQLQuery:
    """Apply every optimization pass post-order to `query` and every IR node
    reachable from it (sub-queries via FROM/JOIN sources, UNION branches, and
    EXISTS subquery bodies — the last of which the legacy `_map_subqueries`
    walker did not reach)."""
    return transform(query, query_fn=_apply_local_query_opts)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# SingleBranchUnionElim — Unwrap UNION ALL with a single branch
# ---------------------------------------------------------------------------


def _unwrap_single_branch_union(query: SQLQuery) -> SQLQuery:
    """SingleBranchUnionElim: Replace a UNION ALL (or UNION) with exactly one branch
    with the branch itself.

    A single-branch union is semantically identical to its sole member.
    Unwrapping it eliminates double-paren artifacts ((SELECT...)) that the
    printer emits when a SQLUnionQuery is nested inside a SQLSubquerySource,
    unblocking DistinctWrapperElim and RedundantDistinctElim Case 1.
    """
    if isinstance(query, SQLUnionQuery) and len(query.queries) == 1:
        return query.queries[0]
    return query


# ---------------------------------------------------------------------------
# UnionToValuesLift — Singleton UNION ALL → VALUES lift
# ---------------------------------------------------------------------------


def _singleton_union_to_values(query: SQLQuery) -> SQLQuery:
    """
    UnionToValuesLift: Replace a UNION ALL of singleton-source branches with a compact form
    by grouping structurally compatible branches into VALUES blocks.

    Branches that share identical expression structure (only literal values differ) are
    grouped together and lifted into a single SELECT over VALUES. Branches with different
    structures (e.g. different-arity MD5 concatenations from entities with different fields)
    form separate groups: groups of ≥2 are lifted, singletons are left as-is.

    The outer SELECT wrapper (including any GROUP BY / MAX) is preserved; only
    the inner union is replaced.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    fi = query.from_item
    if fi is None or not isinstance(fi.source, SQLSubquerySource):
        return query

    union = fi.source.query
    if not isinstance(union, SQLUnionQuery) or union.operator != "UNION ALL":
        return query
    if len(union.queries) < 2:
        return query

    branches = union.queries

    # Every branch must be a singleton-source SELECT with no JOIN / GROUP BY.
    # A WHERE clause is allowed only if every condition is a provably-always-true
    # NOT <non-null-expr> IS NULL guard (emitted by the lowerer for MD5 outputs).
    for b in branches:
        if not isinstance(b, SQLSelectQuery):
            return query
        if b.joins or b.group_by or b.distinct:
            return query
        if b.from_item is None or not isinstance(b.from_item.source, SQLSingletonSource):
            return query
        if b.where and not _all_trivially_true(b.where):
            return query

    # All branches must expose the same column aliases (same output schema)
    aliases = tuple(item.alias for item in branches[0].select) #type: ignore
    for b in branches[1:]:
        if tuple(item.alias for item in b.select) != aliases: #type: ignore
            return query

    # Group branches by structural compatibility (different-arity expressions form
    # separate groups; each group is lifted independently)
    groups = _group_singleton_branches(list(branches), aliases) #type: ignore

    result_parts: list[SQLQuery] = []
    any_lifted = False
    for group_indices in groups:
        group_branches = [branches[i] for i in group_indices]
        if len(group_indices) >= 2:
            lifted = _lift_branch_group_to_values(group_branches, aliases) #type: ignore
            if lifted is not None:
                result_parts.append(lifted)
                any_lifted = True
                continue
        result_parts.extend(group_branches)

    if not any_lifted:
        return query

    if len(result_parts) == 1:
        new_inner: SQLSource = SQLSubquerySource(result_parts[0])
    else:
        new_inner = SQLSubquerySource(
            SQLUnionQuery(queries=tuple(result_parts), operator="UNION ALL")
        )
    new_fi = SQLFromItem(source=new_inner, alias=fi.alias)
    return SQLSelectQuery(
        from_item=new_fi,
        joins=query.joins,
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _group_singleton_branches(
    branches: list[SQLSelectQuery], aliases: tuple[str | None, ...]
) -> list[list[int]]:
    """Group branch indices by structural expression compatibility.

    Two branches are compatible if their SELECT expressions can be anti-unified
    (same shape, only literal values differ). Uses the first branch in each group
    as the representative for compatibility checks.
    """
    groups: list[list[int]] = []
    for i, b in enumerate(branches):
        placed = False
        for g in groups:
            rep = branches[g[0]]
            compatible = all(
                _anti_unify_literals(
                    [rep.select[col_idx].expr, b.select[col_idx].expr], []
                ) is not None
                for col_idx in range(len(aliases))
            )
            if compatible:
                g.append(i)
                placed = True
                break
        if not placed:
            groups.append([i])
    return groups


def _lift_branch_group_to_values(
    branches: list[SQLSelectQuery], aliases: tuple[str | None, ...]
) -> SQLSelectQuery | None:
    """Anti-unify a group of compatible branches into a single SELECT-over-VALUES query.

    Returns None if anti-unification fails or produces no holes (all branches identical).
    """
    holes: list[list[object]] = []
    template_items: list[SQLSelectItem] = []
    for col_idx, alias in enumerate(aliases):
        col_exprs = [b.select[col_idx].expr for b in branches] #type: ignore
        template_expr = _anti_unify_literals(col_exprs, holes)
        if template_expr is None:
            return None
        template_items.append(SQLSelectItem(template_expr, alias=alias))

    if not holes:
        return None  # all branches identical — nothing to lift

    # Deduplicate holes: merge holes that carry identical value sequences
    canonical_idx = list(range(len(holes)))
    for i in range(1, len(holes)):
        for j in range(i):
            if holes[j] == holes[i]:
                canonical_idx[i] = j
                break
    seen_canonical: set[int] = set()
    kept_order: list[int] = []
    for i in range(len(holes)):
        ci = canonical_idx[i]
        if ci not in seen_canonical:
            seen_canonical.add(ci)
            kept_order.append(ci)
    final_idx = {orig: new for new, orig in enumerate(kept_order)}
    rename_map = {
        f"__p{i}": f"__p{final_idx[canonical_idx[i]]}"
        for i in range(len(holes))
    }
    if any(v != k for k, v in rename_map.items()):
        template_items = [
            SQLSelectItem(_rename_col_refs_batch(item.expr, rename_map), alias=item.alias)
            for item in template_items
        ]
    holes = [holes[i] for i in kept_order]

    # Semantic hole naming
    item_hole_sets = [_holes_in_expr(item.expr) for item in template_items]
    used_names: set[str] = set()
    hole_names_list: list[str] = []
    for i in range(len(holes)):
        candidates = [
            template_items[j].alias
            for j in range(len(template_items))
            if i in item_hole_sets[j]
            and len(item_hole_sets[j]) == 1
            and template_items[j].alias is not None
        ]
        if len(candidates) == 1 and candidates[0] not in used_names and candidates[0].lower() not in _SQL_RESERVED_KEYWORDS:  # type: ignore[union-attr]
            name = candidates[0]
        else:
            name = f"__p{i}"
        assert isinstance(name, str)
        hole_names_list.append(name)
        used_names.add(name)
    for i, new_name in enumerate(hole_names_list):
        old_name = f"__p{i}"
        if new_name != old_name:
            template_items = [
                SQLSelectItem(
                    _rename_col_ref_in_expr(item.expr, old_name, new_name),
                    alias=item.alias,
                )
                for item in template_items
            ]
    hole_names = tuple(hole_names_list)
    rows = tuple(
        tuple(SQLLiteral(holes[i][bi]) for i in range(len(holes)))
        for bi in range(len(branches))
    )
    return SQLSelectQuery(
        from_item=SQLFromItem(source=SQLValuesSource(column_names=hole_names, rows=rows), alias="t"),
        select=tuple(template_items),
    )


def _anti_unify_literals(
    exprs: list[SQLExpr], holes: list[list[object]]
) -> SQLExpr | None:
    """
    Anti-unify a list of expressions (one per branch) by extracting varying
    SQLLiteral nodes as holes.

    Returns a template expression where each hole is represented by
    SQLColumnRef("__p{i}"), or None if the expressions differ at a non-literal
    node (structurally incompatible).

    New holes are appended to `holes`; holes[i] is the list of per-branch
    literal values for placeholder __p{i}.
    """
    # Identical everywhere — no hole needed
    if all(e == exprs[0] for e in exprs):
        return exprs[0]

    first = exprs[0]

    # If first is SQLCast, normalize any SQLLiteral(None) entries (produced by R4)
    # to SQLCast(NULL, T) so they are structurally compatible.
    if isinstance(first, SQLCast):
        normalized: list[SQLCast] = []
        for e in exprs:
            if isinstance(e, SQLLiteral) and e.value is None:
                normalized.append(SQLCast(e, first.type_name))
            elif isinstance(e, SQLCast):
                normalized.append(e)
            else:
                return None
        if not all(e.type_name == first.type_name for e in normalized):
            return None
        inner = _anti_unify_literals([e.expr for e in normalized], holes)
        return None if inner is None else SQLCast(inner, first.type_name)

    # All must share the same concrete type to unify structurally
    if not all(type(e) is type(first) for e in exprs):
        return None

    if isinstance(first, SQLLiteral):
        values = [e.value for e in exprs]  # type: ignore[union-attr]
        # Bail if literal values have mixed Python types within the same column —
        # DuckDB cannot combine e.g. VARCHAR and INTEGER_LITERAL in a VALUES clause
        # without an explicit cast.  The original UNION branches may have had CASTs
        # that resolved this; preserving the UNION is safer.
        value_types = {type(v) for v in values if v is not None}
        if len(value_types) > 1:
            return None
        idx = len(holes)
        holes.append(values)
        return SQLColumnRef(f"__p{idx}")

    if isinstance(first, SQLTryCast):
        casts2: list[SQLTryCast] = exprs  # type: ignore[assignment]
        if not all(e.type_name == first.type_name for e in casts2):
            return None
        inner = _anti_unify_literals([e.expr for e in casts2], holes)
        return None if inner is None else SQLTryCast(inner, first.type_name)

    if isinstance(first, SQLFunctionCall):
        fns: list[SQLFunctionCall] = exprs  # type: ignore[assignment]
        if not all(
            e.name == first.name
            and len(e.args) == len(first.args)
            and e.sql_type == first.sql_type
            for e in fns
        ):
            return None
        new_args = []
        for i in range(len(first.args)):
            arg = _anti_unify_literals([e.args[i] for e in fns], holes)
            if arg is None:
                return None
            new_args.append(arg)
        return SQLFunctionCall(first.name, tuple(new_args), first.sql_type)

    if isinstance(first, SQLConcat):
        concats: list[SQLConcat] = exprs  # type: ignore[assignment]
        if not all(len(e.args) == len(first.args) for e in concats):
            return None
        new_args = []
        for i in range(len(first.args)):
            arg = _anti_unify_literals([e.args[i] for e in concats], holes)
            if arg is None:
                return None
            new_args.append(arg)
        return SQLConcat(tuple(new_args))

    if isinstance(first, SQLBinaryOp):
        ops: list[SQLBinaryOp] = exprs  # type: ignore[assignment]
        if not all(e.operator == first.operator for e in ops):
            return None
        left = _anti_unify_literals([e.left for e in ops], holes)
        if left is None:
            return None
        right = _anti_unify_literals([e.right for e in ops], holes)
        return None if right is None else SQLBinaryOp(left, first.operator, right)

    if isinstance(first, SQLIsNotNull):
        nodes: list[SQLIsNotNull] = exprs  # type: ignore[assignment]
        inner = _anti_unify_literals([e.expr for e in nodes], holes)
        return None if inner is None else SQLIsNotNull(inner)

    if isinstance(first, SQLNot):
        nots: list[SQLNot] = exprs  # type: ignore[assignment]
        inner = _anti_unify_literals([e.expr for e in nots], holes)
        return None if inner is None else SQLNot(inner)

    # Any other node type that isn't a literal and isn't handled above:
    # if all are equal we already returned above, so they must differ — can't unify
    return None


# ---------------------------------------------------------------------------
# UnionToValuesLift helpers — hole introspection and renaming
# ---------------------------------------------------------------------------


def _holes_in_expr(expr: SQLExpr) -> frozenset[int]:
    """Return the set of hole indices (__p{i}) referenced anywhere in expr."""
    def step(node: object, acc: set[int]) -> set[int]:
        if isinstance(node, SQLColumnRef):
            n = node.column_name
            if n.startswith("__p") and n[3:].isdigit():
                acc.add(int(n[3:]))
        return acc
    return frozenset(fold(expr, step, set()))


def _rename_col_refs_batch(expr: SQLExpr, rename_map: dict[str, str]) -> SQLExpr:
    """Rename multiple column refs in one pass using a name→name map."""
    def rewrite_expr(node: object) -> object:
        if isinstance(node, SQLColumnRef):
            new_name = rename_map.get(node.column_name)
            if new_name is not None:
                return SQLColumnRef(new_name, node.table_alias)
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


def _rename_col_ref_in_expr(expr: SQLExpr, old: str, new: str) -> SQLExpr:
    """Rename every SQLColumnRef(column_name=old) to SQLColumnRef(new) in expr."""
    def rewrite_expr(node: object) -> object:
        if isinstance(node, SQLColumnRef) and node.column_name == old:
            return SQLColumnRef(new, node.table_alias)
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# UnionToValuesLift helpers — trivially-true guard detection
# ---------------------------------------------------------------------------


# Base facts: SQL functions that always return a non-null value.
_NONNULL_FUNCTIONS: frozenset[str] = frozenset({"MD5"})

# Base facts: column names that are pipeline-guaranteed non-null.
# "_id" is always MD5(CONCAT(...)) — derivable with data-flow, asserted here as a domain fact.
_NONNULL_COLUMNS: frozenset[str] = frozenset({"_id"})


def _is_always_nonnull(expr: SQLExpr) -> bool:
    """Return True if expr can never evaluate to NULL at runtime.

    Base facts  (domain assertions, not derivable from each other at this level):
      SQLLiteral(v)          v is not None
      SQLFunctionCall(f)     f in _NONNULL_FUNCTIONS
      SQLColumnRef(col)      col in _NONNULL_COLUMNS

    Inference rules  (propagate non-nullability structurally):
      CAST/TRY_CAST(x)       non-null iff x is non-null
      SQLConcat(a, b, ...)   non-null iff every arg is non-null
    """
    if isinstance(expr, SQLLiteral):
        return expr.value is not None
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return _is_always_nonnull(expr.expr)
    if isinstance(expr, SQLFunctionCall):
        return expr.name in _NONNULL_FUNCTIONS
    if isinstance(expr, SQLConcat):
        return all(_is_always_nonnull(a) for a in expr.args)
    if isinstance(expr, SQLColumnRef):
        return expr.column_name in _NONNULL_COLUMNS
    return False


def _is_trivially_true_condition(expr: SQLExpr) -> bool:
    """Return True if a single WHERE/JOIN condition is always true and can be dropped.

    The lowerer emits `NOT x IS NULL` as SQLIsNotNull(x) in the IR — i.e.
    "x IS NOT NULL". This is trivially true whenever x is always non-null.
    SQLLiteral(True) (emitted as TRUE) is trivially true by definition.
    """
    if isinstance(expr, SQLLiteral) and expr.value is True:
        return True
    if isinstance(expr, SQLIsNotNull):
        return _is_always_nonnull(expr.expr)
    return False


def _all_trivially_true(conditions: tuple) -> bool:
    """Return True if every condition in a WHERE tuple is trivially always true."""
    return all(_is_trivially_true_condition(c) for c in conditions)


# ---------------------------------------------------------------------------
# DoubleNegElim — Double-negation elimination
# ---------------------------------------------------------------------------


def _simplify_negation_expr(expr: SQLExpr) -> SQLExpr:
    """Recursively eliminate NOT(NOT(x)) → x throughout an expression."""
    def rewrite_expr(node: object) -> object:
        # Children are already simplified (post-order); collapse double-negation here.
        if isinstance(node, SQLNot) and isinstance(node.expr, SQLNot):
            return node.expr.expr
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


def _simplify_negations_in_query(query: SQLQuery) -> SQLQuery:
    """DoubleNegElim: Eliminate NOT(NOT(x)) and drop trivially-true IS NOT NULL guards
    throughout all WHERE / JOIN conditions."""
    if not isinstance(query, SQLSelectQuery):
        return query
    new_where = tuple(
        _simplify_negation_expr(c)
        for c in query.where
        if not _is_trivially_true_condition(c)
    )
    new_joins = tuple(
        SQLJoin(
            kind=j.kind,
            source=j.source,
            alias=j.alias,
            conditions=tuple(
                _simplify_negation_expr(c)
                for c in j.conditions
                if not _is_trivially_true_condition(c)
            ),
        )
        for j in query.joins
    )
    if new_where == query.where and new_joins == query.joins:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=new_joins,
        where=new_where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# SingleConsumerInline — Single-consumer view inlining
# ---------------------------------------------------------------------------


def _inline_single_consumer_views(
    views: list[View], external_refs: set[str]
) -> list[View]:
    """
    SingleConsumerInline: Inline a view into its one consumer when it has no external consumers.

    A view V is inlinable when:
    - Exactly one other view in this step references V by name.
    - V's name is not in external_refs (not referenced from outside this step).
    - V is an internal staging view (base name contains "__"), not a public final view.
      Public views (entity tables, relation tables) may be referenced by queries compiled
      separately and must therefore remain as named views.
    """
    step_names = {v.name for v in views}

    # Count how many views within this step reference each step-local name
    ref_counts: dict[str, int] = {name: 0 for name in step_names}
    for v in views:
        for name in _collect_table_refs_in_query(v.query):
            if name in ref_counts:
                ref_counts[name] += 1


    inlinable = {
        name
        for name, count in ref_counts.items()
        if count == 1 and name not in external_refs and _is_staging_view(name)
    }
    if not inlinable:
        return views

    inline_map = {v.name: v.query for v in views if v.name in inlinable}
    return [
        View(name=v.name, query=_substitute_table_sources(v.query, inline_map), column_types=v.column_types)
        for v in views
        if v.name not in inlinable
    ]


# ---------------------------------------------------------------------------
# AggSubqueryFlatten — Aggregate-subquery flatten
# ---------------------------------------------------------------------------


def _aggregate_subquery_flatten(query: SQLQuery) -> SQLQuery:
    """
    AggSubqueryFlatten: Push MAX aggregates through a pure-projection subquery.

    Pattern:
      SELECT key_col, MAX(col1), MAX(col2), ...
      FROM (SELECT expr_k AS key_col, expr1 AS col1, expr2 AS col2, ... FROM src) AS t
      GROUP BY key_col
    →
      SELECT expr_k AS key_col, MAX(expr1) AS col1, MAX(expr2) AS col2, ...
      FROM src
      GROUP BY expr_k

    Preconditions:
    - Outer has GROUP BY and no WHERE, no DISTINCT, no extra joins.
    - Outer SELECT contains only the key column (direct col-ref) and MAX(col-ref) items.
    - Inner is a pure projection: no GROUP BY, no DISTINCT, no extra joins.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.group_by or query.where or query.joins or query.distinct:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query

    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if inner.group_by or inner.distinct or inner.joins or inner.from_item is None:
        return query

    # outer_alias = query.from_item.alias

    # Build inner projection map: alias → expr
    inner_map: dict[str, SQLExpr] = {}
    for item in inner.select:
        alias = item.alias
        if alias is None:
            if isinstance(item.expr, SQLColumnRef):
                alias = item.expr.column_name
            else:
                return query
        inner_map[alias] = item.expr

    # Rewrite GROUP BY: each col-ref must resolve through inner_map
    new_group_by: list[SQLExpr] = []
    for gb_expr in query.group_by:
        if not isinstance(gb_expr, SQLColumnRef):
            return query
        if gb_expr.column_name not in inner_map:
            return query
        new_group_by.append(inner_map[gb_expr.column_name])

    # Rewrite SELECT: key col-ref or MAX(col-ref), both resolved through inner_map
    new_select: list[SQLSelectItem] = []
    for item in query.select:
        expr = item.expr
        if isinstance(expr, SQLColumnRef):
            col_name = expr.column_name
            if col_name not in inner_map:
                return query
            new_select.append(SQLSelectItem(inner_map[col_name], alias=item.alias))
        elif (
            isinstance(expr, SQLFunctionCall)
            and expr.name == "MAX"
            and len(expr.args) == 1
            and isinstance(expr.args[0], SQLColumnRef)
        ):
            col_name = expr.args[0].column_name
            if col_name not in inner_map:
                return query
            new_select.append(SQLSelectItem(
                SQLFunctionCall("MAX", (inner_map[col_name],)),
                alias=item.alias,
            ))
        else:
            return query  # non-MAX, non-key expression in outer — can't flatten

    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# ProjectOverAggregateFold — Project-over-aggregate fold
# ---------------------------------------------------------------------------


def _project_over_aggregate_fold(query: SQLQuery) -> SQLQuery:
    """
    ProjectOverAggregateFold: Fold a pure projection over an aggregating subquery directly into it.

    Pattern:
      SELECT f(carry.col1), carry.col2, ...
      FROM (SELECT expr1 AS col1, MAX(col2) AS col2, ... FROM src GROUP BY key) AS carry
    →
      SELECT f(expr1) AS ..., MAX(col2) AS col2, ...
      FROM src
      GROUP BY key

    Preconditions:
    - Outer is a pure projection: no GROUP BY, no WHERE, no extra joins.
      DISTINCT is allowed and is propagated into the folded result.
    - Outer SELECT contains no aggregate functions.
    - Inner is an aggregating query with GROUP BY.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if query.group_by or query.where or query.joins:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query

    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if not inner.group_by or inner.from_item is None:
        return query
    # Skip if inner uses positional GROUP BY (integer literals like GROUP BY 1):
    # after rewriting the SELECT list the positions would refer to different columns.
    if any(isinstance(g, SQLLiteral) and isinstance(g.value, int) for g in inner.group_by):
        return query

    outer_alias = query.from_item.alias

    # Outer SELECT must not contain aggregates (would create illegal nested aggs)
    for item in query.select:
        if _contains_aggregate(item.expr):
            return query

    # Build inner projection map: alias → expr
    inner_map: dict[str, SQLExpr] = {}
    for item in inner.select:
        alias = item.alias
        if alias is None:
            if isinstance(item.expr, SQLColumnRef):
                alias = item.expr.column_name
            else:
                return query
        inner_map[alias] = item.expr

    # Substitute col-refs in each outer SELECT item using the inner map
    new_select: list[SQLSelectItem] = []
    for item in query.select:
        new_expr = _substitute_col_refs(item.expr, inner_map, outer_alias)
        if new_expr is None:
            return query
        # If the outer item had no explicit alias but was a bare column ref, keep
        # that name as the alias so the folded result still names its columns
        # correctly when embedded in a UNION ALL / wrapped by GROUP BY.
        alias = item.alias
        if alias is None and isinstance(item.expr, SQLColumnRef):
            alias = item.expr.column_name
        new_select.append(SQLSelectItem(new_expr, alias=alias))

    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=tuple(new_select),
        group_by=inner.group_by,
        order_by=query.order_by or inner.order_by,
        distinct=query.distinct or inner.distinct,
        limit=query.limit if query.limit is not None else inner.limit,
    )


def _contains_aggregate(expr: SQLExpr) -> bool:
    """Return True if expr contains any aggregate function call (MAX, MIN, etc.)."""
    def step(node: object, acc: bool) -> bool:
        if acc:
            return acc
        return isinstance(node, SQLFunctionCall) and node.name in ("MAX", "MIN", "SUM", "COUNT", "AVG")
    return fold(expr, step, False)


# ---------------------------------------------------------------------------
# RedundantCastElim — Redundant CAST elimination (type-aware)
# ---------------------------------------------------------------------------


def _infer_sql_type(expr: SQLExpr) -> str | None:
    """
    Infer the SQL type of expr where determinable.

    Rules:
    - CAST(_, T) / TryCast(_, T)  → T
    - MAX(e) / MIN(e)             → type of e  (aggregate preserves element type)
    - MD5(...)                    → VARCHAR
    - Otherwise                   → None (unknown)
    """
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return expr.type_name
    if isinstance(expr, SQLFunctionCall):
        if expr.name in ("MAX", "MIN") and len(expr.args) == 1:
            return _infer_sql_type(expr.args[0])
        if expr.name == "MD5":
            return "VARCHAR"
    if isinstance(expr, SQLLiteral) and isinstance(expr.value, str):
        return "TEXT"
    return None


def _simplify_casts_in_query(query: SQLQuery) -> SQLQuery:
    """RedundantCastElim: Remove CAST(expr AS T) when type(expr) is already T throughout a query."""
    if not isinstance(query, SQLSelectQuery):
        return query
    changed = False

    new_select = []
    for item in query.select:
        s = _simplify_cast_expr(item.expr)
        new_select.append(SQLSelectItem(s, alias=item.alias))
        if s is not item.expr:
            changed = True

    new_where = []
    for w in query.where:
        s = _simplify_cast_expr(w)
        new_where.append(s)
        if s is not w:
            changed = True

    new_group_by = []
    for g in query.group_by:
        s = _simplify_cast_expr(g)
        new_group_by.append(s)
        if s is not g:
            changed = True

    new_joins = []
    for j in query.joins:
        new_conds = tuple(_simplify_cast_expr(c) for c in j.conditions)
        if new_conds != j.conditions:
            new_joins.append(SQLJoin(kind=j.kind, source=j.source, alias=j.alias, conditions=new_conds))
            changed = True
        else:
            new_joins.append(j)

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(new_joins),
        where=tuple(new_where),
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _simplify_cast_expr(expr: SQLExpr) -> SQLExpr:
    """Recursively remove CAST(expr AS T) when the type of expr is already T,
    and simplify CAST(NULL AS T) → NULL."""
    def rewrite_expr(node: object) -> object:
        # Children already simplified (post-order); fold redundant casts here.
        if isinstance(node, (SQLCast, SQLTryCast)):
            inner = node.expr
            if isinstance(inner, SQLLiteral) and inner.value is None:
                return inner
            if _infer_sql_type(inner) == node.type_name:
                return inner
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


def _substitute_col_refs(
    expr: SQLExpr,
    sub_map: dict[str, SQLExpr],
    outer_alias: str | None,
) -> SQLExpr | None:
    """
    Replace SQLColumnRef(col, outer_alias) with sub_map[col] throughout expr.
    Returns None if a col-ref targeting outer_alias is missing from sub_map.
    Col-refs targeting other aliases are left unchanged.
    """
    def rewrite_expr(node: object) -> object | None:
        if isinstance(node, SQLColumnRef) and node.table_alias in (None, outer_alias):
            if node.column_name in sub_map:
                return sub_map[node.column_name]
            return None
        return node
    return try_transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# SingletonFromLift — Eliminate a FROM (SELECT 1) that contributes no columns
# ---------------------------------------------------------------------------


def _is_trivial_join_condition(conditions: tuple) -> bool:
    """Return True if a join condition is effectively unconditional (TRUE or empty)."""
    return not conditions or (len(conditions) == 1 and isinstance(conditions[0], SQLLiteral) and conditions[0].value is True)


def _alias_used_in_expr(alias: str, expr: SQLExpr) -> bool:
    """Return True if any SQLColumnRef anywhere in expr references the given table alias."""
    return _alias_used_in_query(alias, expr)


def _alias_used_in_query(alias: str, root: object) -> bool:
    """True if `alias` appears anywhere in the IR subtree rooted at `root` (queries, exprs, sources)."""
    def step(node: object, acc: bool) -> bool:
        if acc:
            return acc
        return isinstance(node, SQLColumnRef) and node.table_alias == alias
    return fold(root, step, False)


def _lift_singleton_from(query: SQLQuery) -> SQLQuery:
    """SingletonFromLift: Eliminate a FROM (SELECT 1) singleton when it contributes no columns.

    Pattern:
        SELECT ...
        FROM (SELECT 1) AS a        -- singleton, alias 'a' unreferenced
        JOIN source AS b ON TRUE    -- INNER JOIN only (LEFT JOIN would change semantics)
        [more joins...]

    The (SELECT 1) always returns exactly one row. An INNER JOIN with it on TRUE
    is a no-op — it doesn't filter or multiply rows. When the singleton alias is
    unreferenced elsewhere in the query, it can be removed and the first INNER
    JOIN promoted to the FROM item.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if query.from_item is None or not query.joins:
        return query
    if not isinstance(query.from_item.source, SQLSingletonSource):
        return query

    singleton_alias = query.from_item.alias

    # Safety: singleton alias must not be referenced anywhere in the query
    if _alias_used_in_query(singleton_alias, query):
        return query

    # Find the first INNER JOIN with a trivial condition to promote
    first_join = query.joins[0]
    if "LEFT" in first_join.kind.upper() or "RIGHT" in first_join.kind.upper():
        return query
    if not _is_trivial_join_condition(first_join.conditions):
        return query

    return SQLSelectQuery(
        from_item=SQLFromItem(source=first_join.source, alias=first_join.alias),
        joins=query.joins[1:],
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )



# ---------------------------------------------------------------------------
# LateralJoinReorder — Move LATERAL joins up next to their correlation anchor
# ---------------------------------------------------------------------------


def _aliases_referenced_by_join(join: SQLJoin, candidate_aliases: set[str]) -> set[str]:
    """Outer aliases referenced by a join's ON conditions and (for LATERAL) its subquery body."""
    refs: set[str] = set()
    for cond in join.conditions:
        for a in candidate_aliases:
            if _alias_used_in_expr(a, cond):
                refs.add(a)
    if "LATERAL" in join.kind.upper() and isinstance(join.source, SQLSubquerySource):
        inner = join.source.query
        for a in candidate_aliases:
            if _alias_used_in_query(a, inner):
                refs.add(a)
    return refs


def _reorder_lateral_joins(query: SQLQuery) -> SQLQuery:
    """Move each LATERAL join up to immediately after its latest referenced alias.

    DuckDB's decorrelator OOMs on ``LEFT JOIN LATERAL (...)`` placed after an
    INNER-JOIN chain it doesn't correlate with. LATERALs only move up, never
    down; non-LATERAL joins keep relative order.

    Lives here, not in the Lowerer. The bad shape originates in
    ``_lower_logical``'s IR-order body walk, but that walk is also
    semantically ordered (``=``/cast binding-arrival, ``body[index+1:]``
    lookahead, deferral state, aggregate ``rowset_query`` snapshots), so
    reordering it is a substantial refactor. Join reordering is canonical
    optimizer territory; correctness stays in the Lowerer, plan shape
    stays here.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.joins or not any("LATERAL" in j.kind.upper() for j in query.joins):
        return query
    if query.from_item is None:
        return query

    all_aliases = {query.from_item.alias, *(j.alias for j in query.joins)}

    result: list[SQLJoin] = []
    changed = False
    for join in query.joins:
        if "LATERAL" not in join.kind.upper():
            result.append(join)
            continue
        refs = _aliases_referenced_by_join(join, all_aliases)
        # A LATERAL can't correlate against itself from the outside.
        refs.discard(join.alias)
        latest_dep_pos = -1
        for i, r in enumerate(result):
            if r.alias in refs:
                latest_dep_pos = i
        insert_pos = latest_dep_pos + 1
        if insert_pos != len(result):
            changed = True
        result.insert(insert_pos, join)

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(result),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# DeadLeftJoinElim — Drop LEFT JOINs whose columns are never referenced
# ---------------------------------------------------------------------------


def _drop_dead_left_joins(query: SQLQuery) -> SQLQuery:
    """DeadLeftJoinElim: Remove LEFT JOINs whose alias is never referenced in the query.

    A LEFT JOIN does not filter rows from the base relation. When the joined
    table's alias appears in no SELECT item, WHERE condition, GROUP BY, ORDER BY,
    or other JOIN condition, the join has no observable effect and can be removed.

    Only LEFT JOINs are eligible — INNER JOINs can filter rows, so removing them
    would change semantics even when their columns are unreferenced.
    """
    if not isinstance(query, SQLSelectQuery):
        return query

    live_joins = []
    changed = False
    for join in query.joins:
        if "LEFT" not in join.kind.upper():
            live_joins.append(join)
            continue
        if _alias_used_in_query(join.alias, query):
            live_joins.append(join)
            continue
        # Check the alias isn't used in other joins' conditions that we've already kept
        # (covered by _alias_used_in_query scanning all join conditions including this join's own)
        changed = True  # this join is dead — drop it

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(live_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )




# ---------------------------------------------------------------------------
# DistinctBeforeGroupByElim — Remove DISTINCT from a subquery consumed by an outer GROUP BY
# ---------------------------------------------------------------------------


def _drop_distinct_before_group_by(query: SQLQuery) -> SQLQuery:
    """DistinctBeforeGroupByElim: Remove DISTINCT from a subquery when the only consumer is
    an outer query with GROUP BY and no aggregate functions.

    Pattern:
        SELECT <key cols only, no aggregates>
        FROM (SELECT DISTINCT <key cols>, <other cols> ...) AS s
        GROUP BY <key cols>

    The outer GROUP BY already deduplicates on the key columns. Since the outer SELECT
    uses no aggregate functions, the non-key columns from the inner are irrelevant to the
    result. Removing the inner DISTINCT unblocks DeadSubqueryColumnPrune to prune them.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.group_by or query.where or query.joins or query.from_item is None:
        return query
    if not isinstance(query.from_item.source, SQLSubquerySource):
        return query
    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery) or not inner.distinct:
        return query
    # All outer SELECT items must be simple column refs (no aggregate functions)
    for item in query.select:
        if not isinstance(item.expr, SQLColumnRef):
            return query
    # Safe: remove DISTINCT from inner
    new_inner = SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=inner.select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=False,
        limit=inner.limit,
    )
    return SQLSelectQuery(
        from_item=SQLFromItem(SQLSubquerySource(new_inner), query.from_item.alias),
        joins=query.joins,
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# DeadSubqueryColumnPrune — Remove unused output columns from subqueries
# ---------------------------------------------------------------------------


def _used_cols_for_alias(alias: str | None, root: object) -> set[str]:
    """Collect every column name referenced via `alias` anywhere in `root`.

    Accepts any IR subtree (expr or query). Generic fold: visits every
    reachable node — SELECT, WHERE, GROUP BY, ORDER BY, JOIN conditions,
    LATERAL bodies (whether the body is a SELECT or a UNION), nested EXISTS
    subqueries, SQLValuesSource rows, table-function args, and any future IR
    node containing column refs — uniformly. The visibility analysis is
    therefore correct by construction.
    """
    def step(node: object, acc: set[str]) -> set[str]:
        if isinstance(node, SQLColumnRef) and node.table_alias == alias:
            acc.add(node.column_name)
        return acc
    return fold(root, step, set())


def _try_prune_inner(inner: SQLSelectQuery, used_cols: set[str]) -> SQLSelectQuery | None:
    """Return a pruned copy of inner with unused SELECT items removed, or None if unchanged.

    Refuses to prune if:
    - inner has DISTINCT (every column participates in deduplication — removing one changes the row set)
    - inner has positional GROUP BY (removing items would shift positions)
    - pruning would leave an empty SELECT list
    """
    if inner.distinct:
        return None
    if any(isinstance(g, SQLLiteral) and isinstance(g.value, int) for g in inner.group_by):
        return None
    new_select = tuple(item for item in inner.select if item.alias in used_cols)
    if not new_select or len(new_select) == len(inner.select):
        return None
    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=new_select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=inner.distinct,
        limit=inner.limit,
    )


def _prune_dead_subquery_columns(query: SQLQuery) -> SQLQuery:
    """DeadSubqueryColumnPrune: Remove SELECT items from subqueries that are never
    referenced by the outer query.

    Applies to both the FROM subquery and any JOIN subqueries.  Only prunes
    SQLSubquerySource nodes (table sources have no SELECT list to trim).
    Refuses to prune subqueries that still have positional GROUP BY items, as
    removing columns would shift positions.
    """
    if not isinstance(query, SQLSelectQuery):
        return query

    changed = False

    # Prune FROM subquery
    new_from_item = query.from_item
    if (
        query.from_item is not None
        and isinstance(query.from_item.source, SQLSubquerySource)
        and isinstance(query.from_item.source.query, SQLSelectQuery)
    ):
        used = _used_cols_for_alias(query.from_item.alias, query)
        pruned = _try_prune_inner(query.from_item.source.query, used)
        if pruned is not None:
            new_from_item = SQLFromItem(source=SQLSubquerySource(query=pruned), alias=query.from_item.alias)
            changed = True

    # Prune JOIN subqueries
    new_joins = list(query.joins)
    for i, j in enumerate(query.joins):
        if not isinstance(j.source, SQLSubquerySource):
            continue
        if "LATERAL" in j.kind.upper():
            # LATERAL joins have outer-reference semantics; pruning projected
            # columns can change row counts, so skip them entirely.
            continue
        if not isinstance(j.source.query, SQLSelectQuery):
            continue
        used = _used_cols_for_alias(j.alias, query)
        pruned = _try_prune_inner(j.source.query, used)
        if pruned is not None:
            new_joins[i] = SQLJoin(kind=j.kind, source=SQLSubquerySource(query=pruned), alias=j.alias, conditions=j.conditions)
            changed = True

    if not changed:
        return query

    return SQLSelectQuery(
        from_item=new_from_item,
        joins=tuple(new_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# Query traversal helpers
# ---------------------------------------------------------------------------


def _collect_table_refs_in_query(query: SQLQuery) -> set[str]:
    """Collect all SQLTableSource names referenced anywhere in query."""
    def step(node: object, acc: set[str]) -> set[str]:
        if isinstance(node, SQLTableSource):
            acc.add(node.name)
        return acc
    return fold(query, step, set())


def _substitute_table_sources(query: SQLQuery, subs: dict[str, SQLQuery]) -> SQLQuery:
    """Replace every SQLTableSource(name) where name is in subs with a subquery.

    Substituted bodies are themselves walked so any nested SQLTableSource
    that's also in `subs` is inlined transitively.
    """
    if not subs:
        return query

    def rewrite_source(node: object) -> object:
        if isinstance(node, SQLTableSource) and node.name in subs:
            return SQLSubquerySource(_substitute_table_sources(subs[node.name], subs))
        return node
    return transform(query, source_fn=rewrite_source)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Plan-level reference analysis
# ---------------------------------------------------------------------------


def _compute_external_refs(plan: ExecutionPlan) -> list[set[str]]:
    """
    For each step, return the set of view names that are referenced from
    *outside* that step (other steps' views, any semi-naive loop queries).
    """
    # Collect all refs per step (views + loops within the step itself)
    step_all_refs: list[set[str]] = []
    for step in plan.steps:
        if not isinstance(step, SQLExecutionStep):
            raise TypeError(f"_compute_external_refs expects only SQLExecutionStep, got {type(step)}")
        refs: set[str] = set()
        for v in step.views:
            refs |= _collect_table_refs_in_query(v.query)
        for loop in step.semi_naive_loops:
            for t in loop.tables:
                for q in (t.base_query, t.delta_query, t.merge_query, t.next_delta_query, t.final_query):
                    refs |= _collect_table_refs_in_query(q)
        step_all_refs.append(refs)

    total = len(plan.steps)
    external: list[set[str]] = []
    for i in range(total):
        ext: set[str] = set()
        for j in range(total):
            if j != i:
                ext |= step_all_refs[j]
        # Also include semi-naive loop refs from the current step (they are not
        # rewritten by the optimizer so they count as external consumers)
        current_step = plan.steps[i]
        assert isinstance(current_step, SQLExecutionStep)
        for loop in current_step.semi_naive_loops:
            for t in loop.tables:
                for q in (t.base_query, t.delta_query, t.merge_query, t.next_delta_query, t.final_query):
                    ext |= _collect_table_refs_in_query(q)
        external.append(ext)

    return external


__all__ = ["SQLOptimizer"]
