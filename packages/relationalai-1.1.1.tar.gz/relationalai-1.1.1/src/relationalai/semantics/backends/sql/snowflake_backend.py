import json
import re
from decimal import Decimal
from math import isnan
from typing import TYPE_CHECKING, Any, Mapping, cast, Sequence
import pandas as pd

from v0.relationalai.clients.result_helpers import Int128Dtype

if TYPE_CHECKING:
    import snowflake.snowpark
    from .artifacts import SemiNaiveLoop, StoreColumn

from ....config.config_fields import DEFAULT_TABLE_MATERIALIZATION, TableMaterialization
from ._utils import resolve_materialization
from ....util.error import warn as _warn
from .sql_backend import SQLBackend
from .artifacts import SemiNaiveTable
from .emitter import SQLEmitter


class SnowflakeBackend(SQLBackend):
    def __init__(
        self,
        session,
        table_materialization_default: TableMaterialization = DEFAULT_TABLE_MATERIALIZATION,
        table_materialization: Mapping[str, TableMaterialization] | None = None,
    ) -> None:
        self._session = session
        self._table_materialization_default = table_materialization_default
        self._warehouse: str | None = None  # lazily fetched from session
        self._table_materialization: dict[str, TableMaterialization] = {
            k.lower(): v for k, v in (table_materialization or {}).items()
        }

    #------------------------------------------------------
    # Dialect handling
    #------------------------------------------------------
    _UNQUOTED_IDENTIFIER_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*$")
    # Conservative reserved-word set for object identifiers in Snowflake paths.
    _RESERVED_IDENTIFIERS = frozenset(
        {
            "ALL",
            "ALTER",
            "AND",
            "ANY",
            "AS",
            "BETWEEN",
            "BY",
            "CASE",
            "CAST",
            "CHECK",
            "COLUMN",
            "CONNECT",
            "CONSTRAINT",
            "CREATE",
            "CROSS",
            "CURRENT",
            "CURRENT_DATE",
            "CURRENT_TIME",
            "CURRENT_TIMESTAMP",
            "CURRENT_USER",
            "DATABASE",
            "DELETE",
            "DISTINCT",
            "DROP",
            "ELSE",
            "EXISTS",
            "FALSE",
            "FOLLOWING",
            "FOR",
            "FROM",
            "FULL",
            "GRANT",
            "GROUP",
            "HAVING",
            "ILIKE",
            "IN",
            "INCREMENT",
            "INNER",
            "INSERT",
            "INTERSECT",
            "INTO",
            "IS",
            "ISSUE",
            "JOIN",
            "LATERAL",
            "LEFT",
            "LIKE",
            "LOCALTIME",
            "LOCALTIMESTAMP",
            "MINUS",
            "NATURAL",
            "NOT",
            "NULL",
            "OF",
            "ON",
            "OR",
            "ORDER",
            "QUALIFY",
            "REGEXP",
            "REVOKE",
            "RIGHT",
            "RLIKE",
            "ROW",
            "ROWS",
            "SAMPLE",
            "SCHEMA",
            "SELECT",
            "SET",
            "SOME",
            "START",
            "TABLE",
            "TABLESAMPLE",
            "THEN",
            "TO",
            "TRIGGER",
            "TRUE",
            "TRY_CAST",
            "UNION",
            "UNIQUE",
            "UPDATE",
            "USING",
            "VALUES",
            "VIEW",
            "WHEN",
            "WHENEVER",
            "WHERE",
            "WITH",
        }
    )
    _IS_DYNAMIC_TABLE_RE = re.compile(
        r'^\s*CREATE\s+OR\s+REPLACE\s+DYNAMIC\s+TABLE\b', re.IGNORECASE
    )
    _IS_VIEW_RE = re.compile(
        r'^\s*CREATE\s+OR\s+REPLACE\s+VIEW\b', re.IGNORECASE
    )
    # Matches FROM/JOIN followed by a (possibly qualified, possibly quoted) table reference.
    _TABLE_REF_RE = re.compile(
        r'\b(FROM|JOIN)\s+((?:"[^"]*"|\w+)(?:\.(?:"[^"]*"|\w+))*)',
        re.IGNORECASE,
    )

    def dialect_name(self) -> str:
        return "snowflake"

    def materialize_install_views_as_tables(self) -> bool:
        return True

    def emit_create_statement(self, name: str, query_sql: str) -> str:
        quoted = self.quote_table_name(name)
        materialization = resolve_materialization(
            name, self._table_materialization, self._table_materialization_default,
        )
        has_from_or_join = bool(re.search(r'\b(?:FROM|JOIN)\s+["\w]', query_sql, re.IGNORECASE))

        if materialization == TableMaterialization.VIEW:
            return f"CREATE OR REPLACE VIEW {quoted} AS\n{query_sql}"

        # DYNAMIC TABLE requires the body to reference at least one base table; Snowflake
        # rejects dynamic tables built from constant queries. Fall back to a plain TABLE
        # in that case rather than emitting invalid DDL.
        if materialization == TableMaterialization.DYNAMIC_TABLE and has_from_or_join:
            if self._warehouse is None:
                self._warehouse = self._session.get_current_warehouse() or ""
            body = self._wrap_view_refs_with_refresh_boundary(query_sql)
            return (
                f"CREATE OR REPLACE DYNAMIC TABLE {quoted}\n"
                f"  WAREHOUSE = {self._warehouse}\n"
                f"  SCHEDULER = DISABLE\nAS\n{body}"
            )
        elif materialization == TableMaterialization.DYNAMIC_TABLE:
            _warn(
                "Dynamic table fallback",
                f"Table {name!r} was configured as a DYNAMIC TABLE but its query has no "
                f"FROM or JOIN clause. Snowflake requires dynamic tables to reference at "
                f"least one base table. Falling back to a plain TABLE.",
            )
        return f"CREATE OR REPLACE TABLE {quoted}\n  CHANGE_TRACKING = TRUE\nAS\n{query_sql}"

    def _wrap_view_refs_with_refresh_boundary(self, query_sql: str) -> str:
        """Wrap references to view-materialized tables in DYNAMIC_TABLE_REFRESH_BOUNDARY().

        Snowflake rejects dynamic tables that read from views containing other dynamic
        tables unless the view is wrapped in DYNAMIC_TABLE_REFRESH_BOUNDARY().

        *query_sql* is always machine-generated relational SQL from ``emit_query`` — it
        contains no string literals with SQL keywords or comments, so the regex match
        against FROM/JOIN clauses will not produce false positives.
        """
        def _replace(m: re.Match) -> str:
            keyword, table_ref = m.group(1), m.group(2)
            materialization = resolve_materialization(
                table_ref, self._table_materialization, self._table_materialization_default,
            )
            if materialization == TableMaterialization.VIEW:
                return f"{keyword} DYNAMIC_TABLE_REFRESH_BOUNDARY({table_ref})"
            return m.group(0)

        return self._TABLE_REF_RE.sub(_replace, query_sql)

    def install_table_ddl(
        self, table_name: str, columns: "Sequence[StoreColumn]"
    ) -> str:
        parts = []
        for c in columns:
            if c.sql_type is None:
                raise ValueError(f"No SQL type for column {c.name!r} in {table_name}")
            parts.append(f"{self._always_quote(c.name)} {c.sql_type}")
        col_defs = ", ".join(parts)
        # For now, we enable change tracking on all standard tables in Snowflake. We need
        # change tracking when a dynamic table references a standard table. In the future,
        # we might want to enable change tracking only when the table is actually referenced
        # by a dynamic table or by a logic reasoner.
        return f"CREATE OR REPLACE TABLE {self.quote_table_name(table_name)} ({col_defs})\n  CHANGE_TRACKING = TRUE"

    def install_table_ddl_for_target(
        self,
        target_sql: str,
        table_name: str,
        columns: "Sequence[StoreColumn]",
    ) -> str:
        # Views install instantly and don't read upstream rows, so we don't need
        # a typed-empty placeholder — the original CREATE VIEW is fine to emit
        # at schema-only time.
        if self._IS_VIEW_RE.match(target_sql):
            return target_sql
        # Dynamic tables: keep the full DDL (body SELECT is parsed for schema
        # only — Snowflake doesn't read upstream rows) but add INITIALIZE =
        # ON_SCHEDULE so the table is created without blocking on data.
        # emit_create_statement always produces `\nAS\n` as the separator.
        if self._IS_DYNAMIC_TABLE_RE.match(target_sql):
            result = target_sql.replace('\nAS\n', '\n  INITIALIZE = ON_SCHEDULE\nAS\n', 1)
            assert result != target_sql, (
                f"Failed to inject INITIALIZE clause into dynamic table DDL for {table_name!r}: "
                f"separator '\\nAS\\n' not found"
            )
            return result
        # Plain tables: emit a self-contained typed empty table; the body of the
        # original CTAS may reference upstream dynamic tables that are not yet
        # initialized, so we must not touch it.
        return self.install_table_ddl(table_name, columns)

    def normalize_schema_name(self, name) -> str:
        return name

    def normalize_column_name(self, name: str) -> str:
        if name.startswith('"') and name.endswith('"'):
            return name[1:-1]
        return name

    def quote_table_name(self, name: str) -> str:
        parts = name.split(".")
        if len(parts) == 3:
            db, schema, table = parts
            return f"{db}.{schema}.{table}"
        return name

    def _always_quote(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def quote_identifier(self, name: str) -> str:
        token = name.strip()
        if token == "*":
            return token
        if token.startswith('"') and token.endswith('"'):
            return token
        upper = token.upper()
        if self._UNQUOTED_IDENTIFIER_RE.fullmatch(token) and upper not in self._RESERVED_IDENTIFIERS:
            return upper
        escaped = token.replace('"', '""')
        return f'"{escaped}"'

    #------------------------------------------------------
    # Metadata fetching
    #------------------------------------------------------

    def fetch_schema(self, database: str, schema: str, table: str) -> dict[str, type | str]:
        try:
            # Use SHOW COLUMNS which works with Snowflake permissions
            show_query = f"SHOW COLUMNS IN {database}.{schema}.{table}"
            self._session.sql(show_query).collect()

            # Get results from result_scan
            result_query = """
                SELECT "column_name", "data_type"
                FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
            """
            rows = self._session.sql(result_query).collect()

            result: dict[str, type | str] = {}
            for row in rows:
                column_name = str(row[0])
                data_type_json = row[1]
                if not isinstance(data_type_json, (str, bytes, bytearray)):
                    continue

                # Parse the JSON data type info
                type_info = json.loads(data_type_json)
                sf_type = type_info.get("type", "TEXT")

                result[column_name] = _map_snowflake_type(sf_type, type_info)

            return result
        except Exception:
            # If schema fetch fails, return empty dict
            return {}

    #------------------------------------------------------
    # SQL execution
    #------------------------------------------------------

    def execute_sql(self, sql: str) -> pd.DataFrame:
        self._drop_view_if_exists_for_create_table(sql)
        snow_df = self._session.sql(sql)
        column_names = [self.normalize_column_name(name) for name in snow_df.columns]
        rows = [tuple(row) for row in snow_df.collect()]
        df = pd.DataFrame(rows, columns=column_names)
        formatted_df = self._format_snowflake_columns(df, snow_df)
        formatted_df.attrs["sql_output_types"] = self._collect_sql_output_types(snow_df, column_names)
        return formatted_df

    def execute_sql_batch(self, statements: list[str]) -> None:
        if not statements:
            return
        for statement in statements:
            self._drop_view_if_exists_for_create_table(statement)
        body = "\n".join(stmt.rstrip().rstrip(";") + ";" for stmt in statements)
        script = "BEGIN\n" + body + "\nEND;"
        self._session.sql(script).collect()

    def _drop_view_if_exists_for_create_table(self, sql: str) -> None:
        target = self._create_table_target(sql)
        if not target:
            return
        is_view = bool(self._IS_VIEW_RE.match(sql))
        is_dynamic_table = bool(self._IS_DYNAMIC_TABLE_RE.match(sql))
        if not is_view:
            # CREATE [DYNAMIC] TABLE replaces a same-named TABLE/DYNAMIC TABLE in
            # place, but Snowflake errors if a VIEW exists at that name; drop it.
            try:
                self._session.sql(f"DROP VIEW IF EXISTS {target}").collect()
            except Exception:
                pass
        if is_view:
            # CREATE VIEW won't replace a TABLE or DYNAMIC TABLE; drop both.
            try:
                self._session.sql(f"DROP TABLE IF EXISTS {target}").collect()
            except Exception:
                pass
            try:
                self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {target}").collect()
            except Exception:
                pass
        elif is_dynamic_table:
            # When upgrading a plain table to a dynamic table, drop the old plain table.
            try:
                self._session.sql(f"DROP TABLE IF EXISTS {target}").collect()
            except Exception:
                pass
        else:
            # When creating a plain table, drop any pre-existing dynamic table.
            try:
                self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {target}").collect()
            except Exception:
                pass

    def _create_table_target(self, sql: str) -> str | None:
        # Matches CREATE OR REPLACE [DYNAMIC] TABLE / VIEW in these forms:
        #   CREATE OR REPLACE TABLE name AS <query>
        #   CREATE OR REPLACE DYNAMIC TABLE name WAREHOUSE = ... AS <query>
        #   CREATE OR REPLACE TABLE name (col TYPE, ...)   ← schema-only DDL
        #   CREATE OR REPLACE VIEW name AS <query>
        match = re.match(
            r'^\s*CREATE\s+OR\s+REPLACE\s+(?:DYNAMIC\s+TABLE|TABLE|VIEW)\s+(.+?)\s*(?:\(|WAREHOUSE\b|SCHEDULER\b|AS\b)',
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if not match:
            return None
        return match.group(1).strip()

    def _format_snowflake_columns(
            self,
            result_frame: pd.DataFrame,
            snow_df: "snowflake.snowpark.DataFrame",
        ) -> pd.DataFrame:
        """Schema-driven DataFrame formatting for Snowflake results."""
        if result_frame.shape[0] == 0:
            return result_frame

        from snowflake.snowpark.types import (
            DecimalType,
            ByteType,
            ShortType,
            IntegerType,
            LongType,
            StringType,
        )

        int64_min = -(1 << 63)
        int64_max = (1 << 63) - 1

        def _is_null(value: object) -> bool:
            if value is None or value is pd.NA:
                return True
            if isinstance(value, float):
                try:
                    return isnan(value)
                except Exception:
                    return False
            return False

        def _requires_int128(series: pd.Series) -> bool:
            for value in series:
                if _is_null(value):
                    continue
                int_value = int(value)
                if int_value < int64_min or int_value > int64_max:
                    return True
            return False

        def _cast_integer_series(series: pd.Series) -> pd.Series:
            if _requires_int128(series):
                return series.astype(Int128Dtype())
            if bool(series.isna().any()):
                return series.astype("Int64")
            return series.astype("int64")

        def _to_decimal(value: object, *, scale: int) -> Decimal | None:
            if _is_null(value):
                return None
            quant = Decimal(1).scaleb(-scale)
            if isinstance(value, Decimal):
                return value.quantize(quant)
            return Decimal(str(value)).quantize(quant)

        def _cast_bool_string_series(series: pd.Series) -> pd.Series:
            normalized = series.map(lambda v: None if _is_null(v) else str(v).strip().lower())
            valid = {v for v in normalized.tolist() if v is not None}
            if not valid.issubset({"true", "false"}):
                return series
            return normalized.map(lambda v: None if v is None else (v == "true")).astype("boolean")

        for field_ix, field in enumerate(snow_df.schema.fields):
            if field_ix >= len(result_frame.columns):
                break
            series = result_frame.iloc[:, field_ix]
            def _assign(series_value: pd.Series) -> None:
                # Use positional assignment so extension dtypes (e.g. Int128) survive.
                result_frame.isetitem(field_ix, cast(Any, series_value))

            if isinstance(field.datatype, (ByteType, ShortType, IntegerType, LongType)):
                _assign(_cast_integer_series(series))
                continue

            if not isinstance(field.datatype, DecimalType):
                if isinstance(field.datatype, StringType):
                    _assign(_cast_bool_string_series(series))
                continue

            scale = field.datatype.scale
            if scale == 0:
                _assign(_cast_integer_series(series))
                continue
            _assign(series.map(lambda value: _to_decimal(value, scale=scale)))

        return result_frame

    def _collect_sql_output_types(
            self,
            snow_df: "snowflake.snowpark.DataFrame",
            column_names: list[str],
        ) -> tuple[dict[str, int | str | None], ...]:
        out: list[dict[str, int | str | None]] = []
        for ix, field in enumerate(snow_df.schema.fields):
            col_name = column_names[ix] if ix < len(column_names) else self.normalize_column_name(field.name)
            out.append(
                {
                    "name": col_name,
                    "snowflake_type": type(field.datatype).__name__,
                    "precision": getattr(field.datatype, "precision", None),
                    "scale": getattr(field.datatype, "scale", None),
                }
            )
        return tuple(out)

    #------------------------------------------------------
    # Semi-naive execution
    #------------------------------------------------------

    def build_semi_naive_plan(self, loop: "SemiNaiveLoop", emitter: "SQLEmitter") -> str:
        max_iterations = 1000
        schema_context: str | None = None
        if loop.tables:
            first_table_name = loop.tables[0].table_name
            parts = first_table_name.split(".")
            if len(parts) >= 3:
                # db.schema.table  →  USE SCHEMA db.schema
                schema_context = ".".join(parts[:2])
            elif len(parts) == 2:
                # schema.table  →  USE SCHEMA schema
                schema_context = parts[0]

        def qcol(name: str) -> str:
            token = name.strip()
            if (
                re.fullmatch(r"[A-Za-z_][A-Za-z0-9_$]*", token)
                and token.upper() == token
                and token.upper() not in SnowflakeBackend._RESERVED_IDENTIFIERS
            ):
                return token
            return emitter._quote_identifier(token)

        def cols_sql(table: SemiNaiveTable) -> str:
            return ", ".join(qcol(c) for c in table.columns)

        # Initialize accum_view and delta_view from base_query for each
        # target. Both views share base_query: at iteration 0 the delta
        # *is* the seed.
        init_stmts = []
        cols_by_table = {table.table_name: cols_sql(table) for table in loop.tables}
        for table in loop.tables:
            base_sql = emitter.emit(table.base_query)
            cols = cols_by_table[table.table_name]
            init_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.accum_view_name} AS\n"
                f"SELECT {cols} FROM ({base_sql}) AS base"
            )
            init_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.delta_view_name} AS\n"
                f"SELECT {cols} FROM ({base_sql}) AS base"
            )

        # Loop body: mirrors DuckDB's two-phase loop so multi-table SCCs see
        # consistent cross-table state during a single iteration.
        #   Phase 1: compute next_accum and next_delta for ALL tables, using
        #            the iteration's *current* accum/delta. (A's merge_query
        #            may JOIN B's accum and vice versa — neither has been
        #            swapped yet, so both reads are at iteration N.)
        #   Phase 2: count total_rows added across the SCC.
        #   Phase 3: if any progress, swap accum<-next_accum and
        #            delta<-next_delta for ALL tables atomically.
        # No EXCEPT or store-with-_gen logic here — encoded by lowerer.
        compute_stmts: list[str] = []
        count_stmts: list[str] = []
        swap_stmts: list[str] = []
        for table in loop.tables:
            cols = cols_by_table[table.table_name]
            merge_sql = emitter.emit(table.merge_query)
            next_delta_sql = emitter.emit(table.next_delta_query)
            compute_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.next_accum_view_name} AS\n"
                f"SELECT {cols} FROM ({merge_sql}) AS merged;"
            )
            compute_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.next_delta_view_name} AS\n"
                f"SELECT {cols} FROM ({next_delta_sql}) AS diff;"
            )
            count_stmts.append(
                f"total_rows := total_rows + (SELECT COUNT(*) FROM {table.next_delta_view_name});"
            )
            swap_stmts.append(
                f"DROP TABLE IF EXISTS {table.accum_view_name};\n"
                f"ALTER TABLE {table.next_accum_view_name} RENAME TO {table.accum_view_name};\n"
                f"DROP TABLE IF EXISTS {table.delta_view_name};\n"
                f"ALTER TABLE {table.next_delta_view_name} RENAME TO {table.delta_view_name};"
            )
        # Wrap swaps in a single IF so all tables advance together (or none).
        swap_block = (
            "IF (total_rows > 0) THEN\n"
            + "\n".join("  " + line for stmt in swap_stmts for line in stmt.splitlines())
            + "\nEND IF;"
        )
        loop_body = compute_stmts + count_stmts + [swap_block]

        # Materialize the public view from accum.
        final_stmts = []
        for table in loop.tables:
            final_sql = emitter.emit(table.final_query)
            view_name = self.quote_table_name(table.table_name)
            _mat = resolve_materialization(
                table.table_name, self._table_materialization, self._table_materialization_default,
            )
            if _mat != TableMaterialization.TABLE:
                _warn(
                    "Recursive table fallback",
                    f"Table {table.table_name!r} was configured as {_mat.value!r} but it is part "
                    f"of a recursive (semi-naive) computation. Recursive tables cannot use that "
                    f"materialization. Falling back to a plain TABLE.",
                )
            final_stmts.append(
                f"CREATE OR REPLACE TABLE {view_name} AS\n"
                f"{final_sql}"
            )

        script = "\n".join([
            "DECLARE",
            "  iter INTEGER := 0;",
            "  total_rows INTEGER := 1;",
            "  max_iter INTEGER := " + str(max_iterations) + ";",
            "BEGIN",
            *([f"  USE SCHEMA {schema_context};"] if schema_context else []),
            *[f"  {stmt};" for stmt in init_stmts],
            "  WHILE (total_rows > 0 AND iter < max_iter) DO",
            "    total_rows := 0;",
            *["    " + line for stmt in loop_body for line in stmt.splitlines()],
            "    iter := iter + 1;",
            "  END WHILE;",
            *[f"  {stmt};" for stmt in final_stmts],
            "END;",
        ])

        return script

    def execute_semi_naive(self, plan: object) -> None:
        assert isinstance(plan, str)
        self._session.sql(plan).collect()


#------------------------------------------------------
# Helpers
#------------------------------------------------------
# Type mapping from Snowflake types to Python/RAI types
SNOWFLAKE_TYPE_MAP: dict[str, type | str] = {
    'TEXT': str,
    'VARCHAR': str,
    'CHAR': str,
    'STRING': str,
    'BINARY': bytes,
    'NUMBER': 'Decimal',
    'FIXED': 'Decimal',
    'FLOAT': float,
    'REAL': float,
    'DOUBLE': float,
    'BOOLEAN': bool,
    'DATE': 'Date',
    'TIME': 'DateTime',
    'TIMESTAMP': 'DateTime',
    'TIMESTAMP_LTZ': 'DateTime',
    'TIMESTAMP_NTZ': 'DateTime',
    'TIMESTAMP_TZ': 'DateTime',
}

def _map_snowflake_type(sf_type: str, type_info: dict) -> type | str:
    base_type = sf_type.upper()

    # Handle FIXED/NUMBER with precision/scale
    if base_type in ('FIXED', 'NUMBER'):
        precision = type_info.get('precision', 38)
        scale = type_info.get('scale', 0)

        if scale == 0:
            # Integer types
            if precision <= 18:
                return 'Decimal(18,0)'
            else:
                return 'Decimal(38,0)'
        else:
            return f'Decimal({precision},{scale})'

    return SNOWFLAKE_TYPE_MAP.get(base_type, str)
