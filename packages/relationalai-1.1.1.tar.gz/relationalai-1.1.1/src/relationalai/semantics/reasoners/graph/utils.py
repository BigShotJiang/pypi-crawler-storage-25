from functools import _make_key, update_wrapper
from relationalai.semantics import Relationship


def _cache_wrapper(user_function):
    """
    This function behaves similarly to ``functools._lru_cache_wrapper(user_function, maxsize=None)``.
    I.e. it returns a function that wraps ``user_function`` so that calls are memoized.

    The difference between this function and ``functools._lru_cache_wrapper(user_function, maxsize=None)`` is:
    * this function does not count cache usage
    * `user_function` can be a function that accepts arguments of type ``Relationship``,
      which are not hashable.
    """
    cache = {}
    def wrapper(*args, **kwds):
        arg_ids = tuple(
            arg.to_dict_key()
            if isinstance(arg, Relationship) else arg
            for arg in args
            )
        kwarg_as_ids = {
            k: v.to_dict_key()
               if isinstance(v, Relationship) else v
               for k, v in kwds.items()
            }
        key = _make_key(arg_ids, kwarg_as_ids, False)
        if key not in cache:
            cache[key] = user_function(*args, **kwds)
        return cache.get(key)

    return wrapper

def cache_allowing_relationship_args(user_function, /):
    """
    This function behaves as ``functools.cache``, with the only modification being that
    the arguments to a function decorated with `@cache_allowing_relationship_args`
    can be of type ``Relationship`` in addition to hashable types.
    """
    wrapper = _cache_wrapper(user_function)
    # Note: `wrapper` already has the behaviour of "`user_function` with caching", but has
    # a different name etc. `update_wrapper`` changes some private attributes of `wrapper`
    # to make it look more like `user_function`, e.g. it sets `wrapper.__name__` to
    # `user_function.__name__`.
    return update_wrapper(wrapper, user_function)
