"""Async Graphs service client.

This module provides the async-first API exposed off the root `Client`
(i.e. `client.graphs`). Backend-specific behavior is delegated to a
`GraphsGateway` implementation.
"""

from __future__ import annotations

from types import TracebackType
from typing import TYPE_CHECKING

from ._client_shared import normalize_name
from .models import Graph
from .protocol import GraphsGateway


if TYPE_CHECKING:
    from relationalai.config.config import Config


# NOTE: This module is intentionally NOT marked with `__include_in_docs__` and
# the public class/methods are NOT decorated with `@include_in_docs`. The
# graphs/databases management API is currently treated as internal and is
# excluded from the generated public reference docs.


class GraphsClient:
    """Async-first graphs client.

    Graph databases are the persistence primitive consumed by the Logic reasoner;
    they are exposed via the RAI Direct Access HTTP API. This client is a thin,
    async wrapper around those endpoints with stable domain models and exceptions.

    On deployments that do not expose Direct Access (for example, SQL-only
    Snowflake installations), the root `Client` still surfaces `client.graphs`
    for stable typing, but every method raises
    :class:`~relationalai.services.graphs.errors.GraphsUnsupportedError`.
    """

    def __init__(
        self,
        gateway: GraphsGateway,
        *,
        config: "Config | None" = None,
    ):
        """Create an async graphs client.

        Args:
            gateway: Backend adapter implementing `GraphsGateway`.
            config: Optional config (retained for future use; e.g. defaults).
        """
        self._gateway = gateway
        self._config = config
        self._closed = False

    # ---- lifecycle ----

    async def aclose(self) -> None:
        """Close the client (best-effort).

        Returns
        -------
        None
            Always returns `None`.
        """
        await self._gateway.aclose()
        self._closed = True

    # NOTE: no `__del__`-based "session not closed" warning. The DA aiohttp
    # session is owned by `ClientCore` (root client) which closes it in its own
    # `aclose()`. A prior heuristic that inspected `gw.session` could never
    # reliably see the real session because the production wiring wraps the
    # gateway in `NoClose(LazyAsyncGateway(...))`, so the warning is removed
    # rather than left as dead code.

    async def __aenter__(self) -> "GraphsClient":
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    # ---- public API ----

    async def list(self) -> list[Graph]:
        """List all graphs visible to the caller.

        Returns
        -------
        list[Graph]
            The graphs the server returns, sorted by name.
        """
        graphs = await self._gateway.list()
        return sorted(graphs, key=lambda g: g.name)

    async def get(self, name: str) -> Graph | None:
        """Get a graph by name, returning `None` if it does not exist.

        Returns
        -------
        Graph | None
            The graph, or `None` if not found.
        """
        n = normalize_name(name)
        return await self._gateway.get(n)

    async def create(self, name: str) -> None:
        """Create a new (empty) graph.

        Args:
            name: The graph name to create.

        Returns
        -------
        None
            Always returns `None`.
        """
        n = normalize_name(name)
        await self._gateway.create(n)

    async def clone(self, source: str, target: str, *, force: bool = False) -> None:
        """Clone ``source`` to a new graph ``target``.

        Args:
            source: Existing graph to clone from.
            target: New graph to create.
            force: When True, delete an existing `target` before cloning.

        Returns
        -------
        None
            Always returns `None`.
        """
        s = normalize_name(source, field="source")
        t = normalize_name(target, field="target")
        await self._gateway.clone(s, t, force=force)

    async def delete(
        self,
        name: str,
        *,
        force: bool = False,
        language: str = "rel",
    ) -> None:
        """Delete (or release the index for) a graph.

        Args:
            name: The graph to delete.
            force: Bypass ``model.reuse_model`` and force a full delete.
            language: Language hint forwarded only on index-release deletes
                (``"rel"`` or ``"lqp"``). **Ignored when ``use_graph_index`` is
                disabled** — the plain database-delete endpoint does not accept
                a language hint. Matches v0 ``delete_graph(..., language=...)``
                behavior.

        Returns
        -------
        None
            Always returns `None`. Missing graphs are treated as a no-op.
        """
        n = normalize_name(name)
        await self._gateway.delete(n, force=force, language=language)
