"""Synchronous Graphs service client.

This module provides the blocking (sync) API used by
`relationalai.client.connect_sync()`. The client delegates backend-specific
behavior to a `GraphsGatewaySync`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._client_shared import normalize_name
from .models import Graph
from .protocol import GraphsGatewaySync


if TYPE_CHECKING:
    from relationalai.config.config import Config


# NOTE: This module is intentionally NOT marked with `__include_in_docs__` and
# the public class/methods are NOT decorated with `@include_in_docs`. The
# graphs/databases management API is currently treated as internal and is
# excluded from the generated public reference docs.


class GraphsClientSync:
    """Synchronous graphs client (public API for `connect_sync()`).

    See :class:`~relationalai.services.graphs.client.GraphsClient` for full
    semantics; methods here mirror that API but return synchronously.
    """

    def __init__(
        self,
        gateway: GraphsGatewaySync,
        *,
        config: "Config | None" = None,
    ):
        """Create a synchronous graphs client.

        Args:
            gateway: Backend adapter implementing `GraphsGatewaySync`.
            config: Optional config (retained for future use).
        """
        self._gateway = gateway
        self._config = config

    def close(self) -> None:
        """Close the client (no-op).

        Gateways do not own shared transports; the root platform client is
        responsible for closing transports/sessions.

        Returns
        -------
        None
            Always returns `None`.
        """
        return None

    # ---- public API ----

    def list(self) -> list[Graph]:
        """List all graphs visible to the caller.

        Returns
        -------
        list[Graph]
            The graphs the server returns, sorted by name.
        """
        return sorted(self._gateway.list(), key=lambda g: g.name)

    def get(self, name: str) -> Graph | None:
        """Get a graph by name, returning `None` if it does not exist.

        Returns
        -------
        Graph | None
            The graph, or `None` if not found.
        """
        n = normalize_name(name)
        return self._gateway.get(n)

    def create(self, name: str) -> None:
        """Create a new (empty) graph.

        Args:
            name: The graph name to create.

        Returns
        -------
        None
            Always returns `None`.
        """
        n = normalize_name(name)
        self._gateway.create(n)

    def clone(self, source: str, target: str, *, force: bool = False) -> None:
        """Clone ``source`` to a new graph ``target``.

        Args:
            source: Existing graph to clone from.
            target: New graph to create.
            force: When True, delete an existing `target` before cloning.

        Returns
        -------
        None
            Always returns `None`.
        """
        s = normalize_name(source, field="source")
        t = normalize_name(target, field="target")
        self._gateway.clone(s, t, force=force)

    def delete(
        self,
        name: str,
        *,
        force: bool = False,
        language: str = "rel",
    ) -> None:
        """Delete (or release the index for) a graph.

        Args:
            name: The graph to delete.
            force: Bypass ``model.reuse_model`` and force a full delete.
            language: Language hint forwarded only on index-release deletes
                (``"rel"`` or ``"lqp"``). **Ignored when ``use_graph_index`` is
                disabled** — the plain database-delete endpoint does not accept
                a language hint. Matches v0 ``delete_graph(..., language=...)``
                behavior.

        Returns
        -------
        None
            Always returns `None`. Missing graphs are treated as a no-op.
        """
        n = normalize_name(name)
        self._gateway.delete(n, force=force, language=language)
