"""Public API for promptree."""

from importlib.metadata import PackageNotFoundError, version

from promptree._exceptions import AmbiguousTemplateError, PromptreeError, TemplateNotFoundError
from promptree._node import TemplateNode
from promptree._template import TemplateCallable
from promptree._tree import Promptree

try:
    __version__ = version("promptree")
except PackageNotFoundError:  # pragma: no cover - local source tree fallback
    __version__ = "0+unknown"

__all__ = [
    "__version__",
    "Promptree",
    "TemplateNode",
    "TemplateCallable",
    "PromptreeError",
    "AmbiguousTemplateError",
    "TemplateNotFoundError",
]
