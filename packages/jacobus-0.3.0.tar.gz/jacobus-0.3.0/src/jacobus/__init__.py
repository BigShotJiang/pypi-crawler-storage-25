from jacobus.core import main, run

if __name__ == "__main__":
    main()
