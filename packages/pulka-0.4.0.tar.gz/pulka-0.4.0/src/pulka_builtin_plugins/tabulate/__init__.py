"""Tabulate plugin for Pulka."""

from .plugin import TabulateSheet, register

__all__ = ["TabulateSheet", "register"]
