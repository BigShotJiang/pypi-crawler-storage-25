"""Tabulate (cross-tab) sheet plugin."""

from __future__ import annotations

import contextlib
import weakref
from collections.abc import Mapping
from concurrent.futures import Future
from time import monotonic_ns
from typing import TYPE_CHECKING, Any

import polars as pl
from prompt_toolkit.eventloop import call_soon_threadsafe

from pulka.core.engine.contracts import EnginePayloadHandle
from pulka.core.engine.polars_adapter import collect_lazyframe, unwrap_lazyframe_handle
from pulka.core.jobs import JobRequest, JobResult, JobRunner
from pulka.core.plan import normalized_columns_key
from pulka.core.sheet import Sheet
from pulka.core.viewer import Viewer
from pulka.sheets.data_sheet import DataSheet

if TYPE_CHECKING:  # pragma: no cover - typing only
    from pulka.command.registry import CommandContext, CommandRegistry
    from pulka.core.viewer.view_stack import ViewStack
    from pulka.data.scanners import ScannerRegistry
    from pulka.sheets.registry import SheetRegistry
    from pulka.tui.screen import Screen


_DEFAULT_NULL_LABEL = "(null)"
_DEFAULT_MAX_CATEGORIES = 200
_DEFAULT_MAX_CELLS = 20_000


def _is_string_like_dtype(dtype: pl.DataType | None) -> bool:
    if dtype is None:
        return False
    is_categorical = getattr(pl.datatypes, "is_categorical", None)
    if is_categorical is not None:
        with contextlib.suppress(Exception):
            if is_categorical(dtype):
                return True
    with contextlib.suppress(Exception):
        if dtype in {
            pl.Utf8,
            pl.String,
            pl.Categorical,
            pl.Enum,
            pl.datatypes.Utf8,
            pl.datatypes.String,
        }:
            return True
    dtype_name = type(dtype).__name__.lower()
    return "categorical" in dtype_name or "enum" in dtype_name


def _is_discrete_dtype(dtype: pl.DataType | None) -> bool:
    if dtype is None:
        return False
    if _is_string_like_dtype(dtype):
        return True
    if dtype == pl.Boolean:
        return True
    with contextlib.suppress(Exception):
        if dtype.is_integer():
            return True
    return dtype in {pl.Date, pl.Time, pl.Datetime, pl.Duration}


def _declared_level_order(dtype: pl.DataType | None) -> list[str] | None:
    categories = getattr(dtype, "categories", None)
    if categories is None:
        return None
    with contextlib.suppress(Exception):
        values = categories.to_list() if hasattr(categories, "to_list") else list(categories)
        return [str(value) for value in values]
    return None


def _ordered_levels(
    observed: list[str],
    declared: list[str] | None,
    *,
    null_label: str,
) -> list[str]:
    observed_set = set(observed)
    if declared:
        result = [level for level in declared if level in observed_set or observed_set]
        result.extend(sorted(level for level in observed_set if level not in set(result)))
    else:
        result = sorted(observed_set)
    if null_label in result:
        result = [level for level in result if level != null_label]
        result.append(null_label)
    return result


def _unique_display_name(name: str, used: set[str]) -> str:
    candidate = str(name)
    if candidate not in used:
        used.add(candidate)
        return candidate
    index = 2
    while True:
        candidate = f"{name} ({index})"
        if candidate not in used:
            used.add(candidate)
            return candidate
        index += 1


def _lazyframe_for_sheet(sheet: Sheet) -> pl.LazyFrame | None:
    lf_handle = getattr(sheet, "lf", None)
    if isinstance(lf_handle, EnginePayloadHandle):
        with contextlib.suppress(Exception):
            return unwrap_lazyframe_handle(lf_handle)
    if hasattr(sheet, "to_lazy"):
        with contextlib.suppress(Exception):
            candidate = sheet.to_lazy()
            if isinstance(candidate, EnginePayloadHandle):
                return unwrap_lazyframe_handle(candidate)
    return None


def _schema_for_sheet(sheet: Sheet) -> Mapping[str, pl.DataType]:
    schema_dict = getattr(sheet, "schema_dict", None)
    if callable(schema_dict):
        with contextlib.suppress(Exception):
            schema = schema_dict()
            if isinstance(schema, Mapping):
                return schema
    schema = getattr(sheet, "schema", None)
    if isinstance(schema, Mapping):
        return schema

    lf = _lazyframe_for_sheet(sheet)
    if lf is not None:
        with contextlib.suppress(Exception):
            return dict(lf.collect_schema())
    return {}


def _select_columns_from_summary_view(viewer: Viewer, sheet: Sheet) -> list[str]:
    if "column" not in getattr(sheet, "columns", ()):
        return []
    selected_ids = set(getattr(viewer, "_selected_row_ids", set()))
    selected: list[str] = []
    if selected_ids:
        for row_id in selected_ids:
            if isinstance(row_id, str):
                selected.append(row_id)
                continue
            with contextlib.suppress(Exception):
                name = sheet.get_value_at(int(row_id), "column")
                if isinstance(name, str):
                    selected.append(name)
    return list(dict.fromkeys(selected))


def _rendered_levels_for_lazyframe(
    lf: pl.LazyFrame,
    left_col: str,
    right_col: str,
    *,
    schema: Mapping[str, pl.DataType],
    keep_null_bucket: bool,
    null_label: str,
) -> tuple[list[str], list[str]]:
    pairs = lf.select(
        pl.col(left_col).cast(pl.Utf8, strict=False).alias("_left"),
        pl.col(right_col).cast(pl.Utf8, strict=False).alias("_right"),
    )
    if keep_null_bucket:
        pairs = pairs.with_columns(
            pl.col("_left").fill_null(null_label),
            pl.col("_right").fill_null(null_label),
        )
    else:
        pairs = pairs.drop_nulls()

    unique_df = collect_lazyframe(
        pairs.select(
            pl.col("_left").unique().implode().alias("_left"),
            pl.col("_right").unique().implode().alias("_right"),
        )
    )
    observed_left = unique_df.item(0, "_left") if unique_df.height else []
    observed_right = unique_df.item(0, "_right") if unique_df.height else []

    def _as_list(values: Any) -> list[Any]:
        if values is None:
            return []
        if hasattr(values, "to_list"):
            return list(values.to_list())
        return list(values)

    left_levels = _ordered_levels(
        [str(value) for value in _as_list(observed_left)],
        _declared_level_order(schema.get(left_col)),
        null_label=null_label,
    )
    right_levels = _ordered_levels(
        [str(value) for value in _as_list(observed_right)],
        _declared_level_order(schema.get(right_col)),
        null_label=null_label,
    )
    return left_levels, right_levels


def _validate_tabulate_columns(
    base_sheet: Sheet,
    left_col: str,
    right_col: str,
    *,
    keep_null_bucket: bool = False,
    null_label: str = _DEFAULT_NULL_LABEL,
    max_categories: int = _DEFAULT_MAX_CATEGORIES,
    max_cells: int = _DEFAULT_MAX_CELLS,
) -> str | None:
    available = set(getattr(base_sheet, "columns", []))
    if left_col not in available or right_col not in available:
        return "tabulate columns not found"
    if left_col == right_col:
        return "tabulate requires two distinct columns"

    schema = _schema_for_sheet(base_sheet)
    left_dtype = schema.get(left_col)
    right_dtype = schema.get(right_col)
    if not _is_discrete_dtype(left_dtype) or not _is_discrete_dtype(right_dtype):
        return "tabulate requires categorical or low-cardinality discrete columns"

    lf = _lazyframe_for_sheet(base_sheet)
    if lf is None:
        return "tabulate requires a Polars-backed sheet"

    try:
        left_levels, right_levels = _rendered_levels_for_lazyframe(
            lf,
            left_col,
            right_col,
            schema=schema,
            keep_null_bucket=keep_null_bucket,
            null_label=null_label,
        )
        left_unique = len(left_levels)
        right_unique = len(right_levels)
    except Exception as exc:
        return f"tabulate validation error: {exc}"[:120]

    if left_unique > max_categories:
        return f"tabulate too many categories: {left_col} has {left_unique} unique values"
    if right_unique > max_categories:
        return f"tabulate too many categories: {right_col} has {right_unique} unique values"
    if left_unique * right_unique > max_cells:
        return f"tabulate too many cells: {left_unique}x{right_unique}"
    return None


def _row_header(left_col: str, right_col: str) -> str:
    return f"{left_col} ↓ / {right_col} →"


def _empty_tabulate_frame(row_label: str = "row") -> pl.DataFrame:
    return pl.DataFrame({row_label: pl.Series(row_label, [], dtype=pl.Utf8)})


def _format_count_percent(count: int, grand_total: int) -> str:
    percent = (float(count) * 100.0 / float(grand_total)) if grand_total > 0 else 0.0
    return f"{count} ({percent:.1f}%)"


def _total_label(existing: list[str]) -> str:
    if "Total" not in existing:
        return "Total"
    return "(total)"


def _tabulate_matrix(
    df: pl.DataFrame,
    left_col: str,
    right_col: str,
    *,
    keep_null_bucket: bool,
    null_label: str,
    include_totals: bool,
    left_order: list[str] | None = None,
    right_order: list[str] | None = None,
) -> pl.DataFrame:
    row_label = _row_header(left_col, right_col)
    if left_col not in df.columns or right_col not in df.columns:
        return _empty_tabulate_frame(row_label)

    pairs = df.select(
        pl.col(left_col).cast(pl.Utf8, strict=False).alias("_left"),
        pl.col(right_col).cast(pl.Utf8, strict=False).alias("_right"),
    )
    if keep_null_bucket:
        pairs = pairs.with_columns(
            pl.col("_left").fill_null(null_label),
            pl.col("_right").fill_null(null_label),
        )
    else:
        pairs = pairs.drop_nulls()

    observed_left = pairs.get_column("_left").to_list() if pairs.height else []
    observed_right = pairs.get_column("_right").to_list() if pairs.height else []
    left_levels = _ordered_levels(
        [str(value) for value in observed_left],
        left_order,
        null_label=null_label,
    )
    right_levels = _ordered_levels(
        [str(value) for value in observed_right],
        right_order,
        null_label=null_label,
    )
    if not left_levels:
        return _empty_tabulate_frame(row_label)

    counts = pairs.group_by(["_left", "_right"]).len().rename({"len": "count"})
    grand_total = int(counts.get_column("count").sum()) if counts.height else 0
    count_lookup = {
        (str(left), str(right)): int(count) for left, right, count in counts.iter_rows()
    }
    used_column_names = {row_label}
    right_display = {
        level: _unique_display_name(level, used_column_names) for level in right_levels
    }
    total_label = _unique_display_name(
        _total_label(list(right_display.values())),
        used_column_names,
    )
    rows: list[dict[str, str]] = []
    column_totals = dict.fromkeys(right_levels, 0)
    for left in left_levels:
        row: dict[str, str] = {row_label: left}
        row_total = 0
        for right in right_levels:
            count = count_lookup.get((left, right), 0)
            row_total += count
            column_totals[right] += count
            row[right_display[right]] = _format_count_percent(count, grand_total)
        if include_totals:
            row[total_label] = _format_count_percent(row_total, grand_total)
        rows.append(row)
    if include_totals:
        total_row: dict[str, str] = {row_label: total_label}
        for right in right_levels:
            total_row[right_display[right]] = _format_count_percent(
                column_totals[right], grand_total
            )
        total_row[total_label] = _format_count_percent(grand_total, grand_total)
        rows.append(total_row)
    return pl.DataFrame(rows)


def compute_tabulate_df_for_sheet(
    base_sheet: Sheet,
    left_col: str,
    right_col: str,
    *,
    keep_null_bucket: bool,
    null_label: str,
    include_totals: bool = False,
) -> pl.DataFrame:
    lf = _lazyframe_for_sheet(base_sheet)
    if lf is None:
        raise ValueError("Tabulate requires a Polars-backed sheet")

    schema = _schema_for_sheet(base_sheet)
    data = collect_lazyframe(lf.select([left_col, right_col]))
    return _tabulate_matrix(
        data,
        left_col,
        right_col,
        keep_null_bucket=keep_null_bucket,
        null_label=null_label,
        include_totals=include_totals,
        left_order=_declared_level_order(schema.get(left_col)),
        right_order=_declared_level_order(schema.get(right_col)),
    )


class TabulateSheet(DataSheet):
    """Cross-tab matrix sheet for a pair of source columns."""

    is_tabulate_view = True
    hide_transforms_panel_by_default = True
    hide_insight_panel_by_default = True

    def __init__(
        self,
        base_sheet: Sheet,
        left_col: str,
        right_col: str,
        *,
        runner: JobRunner,
        keep_null_bucket: bool = False,
        null_label: str = _DEFAULT_NULL_LABEL,
        include_totals: bool = False,
        tabulate_df: pl.DataFrame | None = None,
    ) -> None:
        if runner is None:  # pragma: no cover - defensive guard
            msg = "TabulateSheet requires a JobRunner instance"
            raise ValueError(msg)
        frame = (
            tabulate_df
            if tabulate_df is not None
            else _empty_tabulate_frame(_row_header(left_col, right_col))
        )
        super().__init__(frame.lazy(), columns=list(frame.columns), runner=runner)

        self.source_sheet = base_sheet
        self.left_col = left_col
        self.right_col = right_col
        self.keep_null_bucket = bool(keep_null_bucket)
        self.null_label = str(null_label)
        self.include_totals = bool(include_totals)
        self._pending_future: Future[JobResult] | None = None

        self._job_sheet_id: str | None = getattr(base_sheet, "sheet_id", None)
        plan_hash = ""
        job_context = getattr(base_sheet, "job_context", None)
        if callable(job_context):
            with contextlib.suppress(Exception):
                sheet_id, _generation, plan_hash = job_context()
                self._job_sheet_id = sheet_id

        colsig = normalized_columns_key((self.left_col, self.right_col))
        self._job_tag = (
            f"tabulate:cols={colsig}:plan={plan_hash}:"
            f"null={int(self.keep_null_bucket)}:{self.null_label}:"
            f"totals={int(self.include_totals)}"
        )
        self._preserve_jobs_from = self._job_sheet_id

        if tabulate_df is None:
            self._ensure_job()

    @classmethod
    def from_dataframe(
        cls,
        base_sheet: Sheet,
        df: pl.DataFrame,
        *,
        left_col: str,
        right_col: str,
        runner: JobRunner,
        keep_null_bucket: bool,
        null_label: str,
        include_totals: bool,
    ) -> TabulateSheet:
        return cls(
            base_sheet,
            left_col,
            right_col,
            runner=runner,
            keep_null_bucket=keep_null_bucket,
            null_label=null_label,
            include_totals=include_totals,
            tabulate_df=df,
        )

    def _ensure_job(self) -> None:
        sheet_id = self._job_sheet_id
        if sheet_id is None:
            return
        gen = self.job_runner.current_generation(sheet_id)
        if self.job_runner.get(sheet_id, self._job_tag) is not None:
            return
        if self._pending_future is not None:
            return

        base_sheet = self.source_sheet
        left_col = self.left_col
        right_col = self.right_col
        keep_null_bucket = self.keep_null_bucket
        null_label = self.null_label
        include_totals = self.include_totals
        runner = self.job_runner

        def _fn(job_gen: int) -> pl.DataFrame | None:
            if runner.current_generation(sheet_id) != job_gen:
                return None
            return compute_tabulate_df_for_sheet(
                base_sheet,
                left_col,
                right_col,
                keep_null_bucket=keep_null_bucket,
                null_label=null_label,
                include_totals=include_totals,
            )

        self._pending_future = runner.enqueue(
            JobRequest(sheet_id=sheet_id, generation=gen, tag=self._job_tag, fn=_fn)
        )


class _TabulateUiHandle:
    _tick_interval_ns = int(0.15 * 1e9)

    def __init__(self, sheet: TabulateSheet, screen: Screen | None) -> None:
        self._sheet_ref: weakref.ReferenceType[TabulateSheet] | None = weakref.ref(sheet)
        self._screen_ref: weakref.ReferenceType[Screen] | None = (
            weakref.ref(screen) if screen is not None else None
        )
        self._last_result_ts: int = getattr(sheet, "_result_ts", 0)
        self._last_tick_ns: int = monotonic_ns()
        self._finished = False

    def _invalidate_screen(self) -> None:
        screen_ref = self._screen_ref
        if screen_ref is None:
            return
        screen = screen_ref()
        if screen is None:
            return
        app = getattr(screen, "app", None)
        if app is None:
            return
        try:
            call_soon_threadsafe(app.invalidate)
        except Exception:
            with contextlib.suppress(Exception):
                app.invalidate()

    def notify_ready(self, _future: Future[JobResult] | None = None) -> None:
        self._invalidate_screen()

    def consume_update(self, viewer: Viewer) -> bool:
        sheet = self._sheet_ref() if self._sheet_ref is not None else None
        if sheet is None or viewer.sheet is not sheet:
            self._finished = True
            return True

        sheet_id = getattr(sheet, "_job_sheet_id", None)
        tag = getattr(sheet, "_job_tag", None)
        if sheet_id is None or tag is None:
            self._finished = True
            return True

        result = sheet.job_runner.get(sheet_id, tag)
        pending = sheet._pending_future
        if result is None or result.ts_ns <= self._last_result_ts:
            if pending is None:
                self._finished = True
                viewer.status_message = None
                return True
            now = monotonic_ns()
            if now - self._last_tick_ns >= self._tick_interval_ns:
                self._last_tick_ns = now
                self._invalidate_screen()
            viewer.status_message = "computing tabulate…"
            return False

        self._last_result_ts = result.ts_ns

        if result.error is not None:
            viewer.status_message = f"tabulate error: {result.error!s}"[:120]
            self._finished = True
            return True

        value = result.value
        if not isinstance(value, pl.DataFrame):
            viewer.status_message = "tabulate unavailable"
            self._finished = True
            return True

        source_sheet = getattr(sheet, "source_sheet", sheet)
        replacement = TabulateSheet.from_dataframe(
            source_sheet,
            value,
            left_col=sheet.left_col,
            right_col=sheet.right_col,
            runner=sheet.job_runner,
            keep_null_bucket=sheet.keep_null_bucket,
            null_label=sheet.null_label,
            include_totals=sheet.include_totals,
        )
        viewer.replace_sheet(replacement, source_path=None)
        with contextlib.suppress(Exception):
            total_rows = int(len(replacement))
            viewer._total_rows = total_rows
            viewer._row_count_stale = False
            viewer._row_count_future = None
            viewer._row_count_display_pending = False
            viewer.mark_status_dirty()
        viewer.status_message = f"tabulate: {sheet.left_col} × {sheet.right_col}"
        self._finished = True
        return True


def register_tabulate_ui_handle(
    tab_sheet: TabulateSheet,
    viewer: Viewer,
    screen: Screen | None,
) -> None:
    if screen is None:
        return
    handle = _TabulateUiHandle(tab_sheet, screen)
    screen.register_job(viewer, handle)
    pending = getattr(tab_sheet, "_pending_future", None)
    if pending is not None:

        def _deliver_result() -> None:
            handle.consume_update(viewer)
            with contextlib.suppress(Exception):
                viewer.ui_hooks.invalidate()

        def _on_done(_future: Future[JobResult]) -> None:
            handle.notify_ready()
            try:
                viewer.ui_hooks.call_soon(_deliver_result)
            except Exception:
                _deliver_result()

        with contextlib.suppress(Exception):
            pending.add_done_callback(_on_done)
    else:
        handle.notify_ready()


def _activate_viewer(
    base_viewer: Viewer,
    derived_viewer: Viewer,
    *,
    view_stack: ViewStack | None,
) -> Viewer:
    if view_stack is not None:
        view_stack.push(derived_viewer)
        return view_stack.active or derived_viewer
    base_viewer.replace_sheet(derived_viewer.sheet, source_path=None)
    base_viewer.status_message = getattr(derived_viewer, "status_message", None)
    return base_viewer


def open_tabulate_viewer(
    base_viewer: Viewer,
    left_col: str,
    right_col: str,
    *,
    keep_null_bucket: bool = False,
    null_label: str = _DEFAULT_NULL_LABEL,
    include_totals: bool = False,
    session: Any | None = None,
    view_stack: ViewStack | None = None,
    screen: Screen | None = None,
    runner: JobRunner,
    tabulate_df: pl.DataFrame | None = None,
) -> Viewer:
    base_sheet = getattr(base_viewer.sheet, "source_sheet", base_viewer.sheet)
    tab_sheet = TabulateSheet(
        base_sheet,
        left_col,
        right_col,
        runner=runner,
        keep_null_bucket=keep_null_bucket,
        null_label=null_label,
        include_totals=include_totals,
        tabulate_df=tabulate_df,
    )
    derived_viewer = Viewer(
        tab_sheet,
        viewport_rows=base_viewer._viewport_rows_override,
        viewport_cols=base_viewer._viewport_cols_override,
        source_path=None,
        session=session or base_viewer.session,
        runner=runner,
    )
    derived_viewer.status_message = "computing tabulate…"
    active = _activate_viewer(base_viewer, derived_viewer, view_stack=view_stack)
    register_tabulate_ui_handle(tab_sheet, active, screen)
    return active


def _tabulate_cmd(context: CommandContext, args: list[str]) -> None:
    viewer = context.viewer
    sheet = viewer.sheet
    base_sheet = getattr(sheet, "source_sheet", sheet)

    runner = getattr(base_sheet, "job_runner", None) or getattr(viewer, "job_runner", None)
    if not isinstance(runner, JobRunner):
        runner = viewer.job_runner  # type: ignore[assignment]

    keep_null_bucket = False
    include_totals = False
    cleaned_args: list[str] = []
    for arg in args:
        text = str(arg).strip()
        if text in {"--keep-null", "keep-null", "nulls"}:
            keep_null_bucket = True
            continue
        if text in {"--totals", "totals", "total", "--margins", "margins"}:
            include_totals = True
            continue
        if text:
            cleaned_args.append(text)

    if cleaned_args:
        if len(cleaned_args) != 2:
            viewer.status_message = "tabulate requires exactly two columns"
            return
        left_col, right_col = cleaned_args[0], cleaned_args[1]
    else:
        selected = _select_columns_from_summary_view(viewer, sheet)
        column_order = {name: idx for idx, name in enumerate(getattr(base_sheet, "columns", []))}
        selected.sort(key=lambda name: column_order.get(name, len(column_order)))
        if len(selected) != 2:
            viewer.status_message = "tabulate requires exactly two selected columns"
            return
        left_col, right_col = selected

    validation_error = _validate_tabulate_columns(
        base_sheet,
        left_col,
        right_col,
        keep_null_bucket=keep_null_bucket,
        null_label=_DEFAULT_NULL_LABEL,
    )
    if validation_error is not None:
        viewer.status_message = validation_error
        return

    ui = getattr(context, "ui", None) or getattr(context, "screen", None)
    screen = ui if ui is not None else None
    session = getattr(context, "session", None) or viewer.session
    view_stack = getattr(context, "view_stack", None)
    if view_stack is None and session is not None:
        view_stack = getattr(session, "view_stack", None)

    precomputed: pl.DataFrame | None = None
    if screen is None:
        try:
            precomputed = compute_tabulate_df_for_sheet(
                base_sheet,
                left_col,
                right_col,
                keep_null_bucket=keep_null_bucket,
                null_label=_DEFAULT_NULL_LABEL,
                include_totals=include_totals,
            )
        except Exception as exc:
            viewer.status_message = f"tabulate error: {exc}"[:120]
            return

    try:
        active = open_tabulate_viewer(
            viewer,
            left_col,
            right_col,
            keep_null_bucket=keep_null_bucket,
            null_label=_DEFAULT_NULL_LABEL,
            include_totals=include_totals,
            session=session,
            view_stack=view_stack,
            screen=screen,
            runner=runner,
            tabulate_df=precomputed,
        )
        context.viewer = active
        context.sheet = active.sheet
        if screen is None:
            active.status_message = f"tabulate: {left_col} × {right_col}"
    except Exception as exc:  # pragma: no cover - guardrail
        viewer.status_message = f"tabulate error: {exc}"[:120]
    if screen is not None:
        screen.refresh(skip_metrics=True)


def register(
    *,
    commands: CommandRegistry | None = None,
    sheets: SheetRegistry | None = None,
    scanners: ScannerRegistry | None = None,
) -> None:
    if sheets is not None:
        kinds = set(sheets.list_kinds())
        if "tabulate_sheet" not in kinds:
            sheets.register_sheet("tabulate_sheet", TabulateSheet)

    if commands is not None:
        with contextlib.suppress(ValueError):
            commands.register(
                "tabulate_sheet",
                _tabulate_cmd,
                "Two-column cross-tab matrix",
                -1,
                aliases=("tabulate", "tab"),
                domain="Sheets",
            )

        def _open_tabulate(context: CommandContext) -> None:
            _tabulate_cmd(context, [])

        commands.register_sheet_opener("tabulate_sheet", _open_tabulate)

    _ = scanners


__all__ = [
    "TabulateSheet",
    "_tabulate_cmd",
    "compute_tabulate_df_for_sheet",
    "open_tabulate_viewer",
    "register",
    "register_tabulate_ui_handle",
]
