from __future__ import annotations

import sys
import types
from datetime import date, timedelta
from importlib import metadata

import polars as pl
import pytest

from pulka.api.runtime import Runtime
from pulka.command.registry import CommandContext, CommandRegistry
from pulka.core.engine.polars_adapter import unwrap_lazyframe_handle
from pulka.data.scanners import ScannerRegistry
from pulka.plugin.manager import PluginManager
from pulka.render.viewport_plan import compute_viewport_plan
from pulka.sheets.registry import SheetRegistry
from pulka_builtin_plugins.summary.correlation import compute_association_table


class DummyEntryPoints(list):
    """Helper object that mimics ``entry_points().select``."""

    def select(self, *, group: str) -> DummyEntryPoints:
        if group == "pulka.plugins":
            return DummyEntryPoints(self)
        return DummyEntryPoints()


@pytest.fixture()
def registries() -> tuple[CommandRegistry, SheetRegistry, ScannerRegistry]:
    commands = CommandRegistry(load_builtin_commands=False)
    sheets = SheetRegistry()
    scanners = ScannerRegistry()
    return commands, sheets, scanners


def _install_module(monkeypatch: pytest.MonkeyPatch, name: str, register_fn) -> None:
    module = types.ModuleType(name)
    module.register = register_fn
    monkeypatch.setitem(sys.modules, name, module)


def _write_sample_dataset(tmp_path) -> str:
    df = pl.DataFrame({"fruit": ["apple", "banana", "apple"], "size": [1, 2, 3]})
    path = tmp_path / "sample.parquet"
    df.write_parquet(path)
    return str(path)


def _write_tabulate_dataset(tmp_path) -> str:
    df = pl.DataFrame(
        {
            "fruit": [
                "apple",
                "apple",
                "banana",
                "banana",
                "banana",
                "cherry",
                "cherry",
                "apple",
                "banana",
                "cherry",
                None,
                "apple",
            ],
            "color": [
                "red",
                "green",
                "red",
                "yellow",
                "yellow",
                "red",
                "green",
                "yellow",
                "green",
                "red",
                "red",
                "red",
            ],
            "store": [
                "north",
                "north",
                "south",
                "south",
                "north",
                "south",
                "north",
                "west",
                "west",
                "south",
                "east",
                "east",
            ],
            "ripe": [True, False, True, True, False, True, False, False, True, True, True, False],
            "organic": [
                True,
                True,
                False,
                False,
                False,
                True,
                True,
                False,
                False,
                True,
                None,
                True,
            ],
            "size": [1, 2, 1, 2, 3, 1, 2, 2, 1, 3, 1, 3],
            "visit_date": [date(2026, 1, 1) + timedelta(days=i % 4) for i in range(12)],
            "price": [1.25, 2.10, 1.35, 2.45, 3.75, 1.50, 2.20, 2.80, 1.40, 3.10, 1.15, 3.60],
        }
    )
    path = tmp_path / "tabulate.parquet"
    df.write_parquet(path)
    return str(path)


def _write_high_cardinality_tabulate_dataset(tmp_path) -> str:
    df = pl.DataFrame(
        {
            "customer_id": [f"customer-{idx:03d}" for idx in range(201)],
            "segment": ["retail" if idx % 2 else "business" for idx in range(201)],
        }
    )
    path = tmp_path / "tabulate_high_cardinality.parquet"
    df.write_parquet(path)
    return str(path)


def _write_grade_enum_tabulate_dataset(tmp_path) -> str:
    grade_dtype = pl.Enum(["A", "B", "C", "D", "E", "F"])
    df = pl.DataFrame(
        {
            "grade_before": pl.Series(
                "grade_before",
                ["F", "A", "C", "B", "E", "D", "A", "F", "C", None],
                dtype=grade_dtype,
            ),
            "grade_after": pl.Series(
                "grade_after",
                ["A", "F", "B", "C", "D", "E", "A", "B", "F", "C"],
                dtype=grade_dtype,
            ),
            "teacher": ["Kim", "Kim", "Rao", "Rao", "Ito", "Ito", "Kim", "Rao", "Ito", "Kim"],
        }
    )
    path = tmp_path / "tabulate_grades.parquet"
    df.write_parquet(path)
    return str(path)


def _write_large_enum_tabulate_dataset(tmp_path) -> str:
    level_dtype = pl.Enum([f"L{idx:03d}" for idx in range(250)])
    df = pl.DataFrame(
        {
            "before": pl.Series("before", ["L001", "L002"], dtype=level_dtype),
            "after": pl.Series("after", ["L001", "L002"], dtype=level_dtype),
        }
    )
    path = tmp_path / "tabulate_large_enum.parquet"
    df.write_parquet(path)
    return str(path)


def _write_tabulate_collision_dataset(tmp_path) -> str:
    df = pl.DataFrame(
        {
            "left": ["a", "b", "a"],
            "right": ["left ↓ / right →", "Total", "Total"],
        }
    )
    path = tmp_path / "tabulate_collision.parquet"
    df.write_parquet(path)
    return str(path)


def _context(session) -> CommandContext:
    return CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )


def _collect_active_frame(session) -> pl.DataFrame:
    frame = unwrap_lazyframe_handle(session.viewer.sheet.lf).collect()
    return frame.select([name for name in frame.columns if not name.startswith("__pulka_")])


def test_plugin_manager_loads_modules_and_entry_points(monkeypatch: pytest.MonkeyPatch, registries):
    calls: list[str] = []

    def register_entry(*, commands=None, sheets=None, scanners=None):
        calls.append("entry")
        if commands is not None:
            commands.register("entry-cmd", lambda ctx, args: None, "entry")

    def register_module(*, commands=None, sheets=None, scanners=None):
        calls.append("module")
        if sheets is not None:

            class DummySheet:
                def __init__(self, base, *_args, **_kwargs):
                    self._base = base
                    self.columns = list(getattr(base, "columns", []))

                def fetch_slice(self, row_start, row_count, columns):
                    return self._base.fetch_slice(row_start, row_count, columns)

                def get_value_at(self, row_index, column_name=None):
                    return self._base.get_value_at(row_index, column_name)

            sheets.register_sheet("dummy", DummySheet)

    _install_module(monkeypatch, "tests.fake_entry", register_entry)
    _install_module(monkeypatch, "tests.fake_module", register_module)

    entry_point = metadata.EntryPoint(
        name="ep-plugin", value="tests.fake_entry:register", group="pulka.plugins"
    )
    monkeypatch.setattr(metadata, "entry_points", lambda: DummyEntryPoints([entry_point]))

    commands, sheets, scanners = registries
    manager = PluginManager(modules=["tests.fake_module"])

    loaded = manager.load(commands=commands, sheets=sheets, scanners=scanners)

    assert loaded == ["ep-plugin", "tests.fake_module"]
    assert calls == ["entry", "module"]
    assert commands.get_command("entry-cmd") is not None
    assert "dummy" in sheets.list_kinds()


def test_plugin_manager_handles_import_error(monkeypatch: pytest.MonkeyPatch, registries, caplog):
    caplog.set_level("ERROR", logger="pulka.plugin.manager")

    entry_point = metadata.EntryPoint(
        name="broken", value="missing.module:register", group="pulka.plugins"
    )
    monkeypatch.setattr(metadata, "entry_points", lambda: DummyEntryPoints([entry_point]))

    def register_module(*, commands=None, sheets=None, scanners=None):
        if commands is not None:
            commands.register("ok", lambda ctx, args: None)

    _install_module(monkeypatch, "tests.ok_module", register_module)

    commands, sheets, scanners = registries
    manager = PluginManager(modules=["tests.ok_module"])

    loaded = manager.load(commands=commands, sheets=sheets, scanners=scanners)

    assert loaded == ["tests.ok_module"]
    assert any("broken" in record.getMessage() for record in caplog.records)


def test_plugin_manager_duplicate_registration_errors(
    monkeypatch: pytest.MonkeyPatch, registries, caplog
):
    caplog.set_level("ERROR", logger="pulka.plugin.manager")

    def register_one(*, commands=None, sheets=None, scanners=None):
        if commands is not None:
            commands.register("dup", lambda ctx, args: None)

    def register_two(*, commands=None, sheets=None, scanners=None):
        if commands is not None:
            commands.register("dup", lambda ctx, args: None)

    _install_module(monkeypatch, "tests.first_plugin", register_one)
    _install_module(monkeypatch, "tests.second_plugin", register_two)

    commands, sheets, scanners = registries
    manager = PluginManager(modules=["tests.first_plugin", "tests.second_plugin"])

    loaded = manager.load(
        commands=commands,
        sheets=sheets,
        scanners=scanners,
        include_entry_points=False,
    )

    assert loaded == ["tests.first_plugin"]
    assert "Command 'dup' already provided by tests.first_plugin" in caplog.text


def test_builtin_plugins_available_by_default(tmp_path, monkeypatch):
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    path = _write_sample_dataset(tmp_path)
    runtime = Runtime()
    session = runtime.open(path, viewport_rows=10, viewport_cols=6)

    assert {"pulka-summary", "pulka-freq", "pulka-transpose", "pulka-tabulate"} <= set(
        session.loaded_plugins
    )

    context = CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )
    session.commands.execute("summary_sheet", context, [])
    assert session.viewer.status_message == "summary view"
    assert session.viewer.sheet.__class__.__name__ == "SummarySheet"
    assert session.viewer.frozen_column_count == 2
    assert session.viewer.frozen_columns[:2] == ["column", "dtype"]
    assert session.view_stack.active is session.viewer

    session.viewer._selected_row_ids = set()  # type: ignore[attr-defined]
    session.commands.execute("cor_sheet", context, [])
    assert session.viewer.sheet.__class__.__name__ == "CorrelationSheet"
    assert tuple(session.viewer.sheet.selected_columns) == ("fruit", "size")
    assert session.view_stack.active is session.viewer

    session.open(path)
    context = CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )
    session.commands.execute("summary_sheet", context, [])
    assert session.viewer.sheet.__class__.__name__ == "SummarySheet"

    session.viewer._selected_row_ids = {"fruit", "size"}  # type: ignore[attr-defined]
    session.commands.execute("cor_sheet", context, [])
    assert session.viewer.sheet.__class__.__name__ == "CorrelationSheet"
    assert len(session.view_stack.viewers) in {2, 3}
    assert session.view_stack.active is session.viewer
    action = session.viewer.sheet.enter_action(session.viewer)
    assert action is not None
    assert set(action.columns) == {"fruit", "size"}

    session.open(path)
    assert session.view_stack.active is session.viewer
    context = CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )
    session.commands.execute("frequency_sheet", context, ["fruit"])
    assert session.viewer.sheet.__class__.__name__ == "FreqSheet"
    assert session.viewer.is_freq_view is True
    assert session.viewer.stack_depth == 1
    assert len(session.view_stack.viewers) == 2
    assert session.view_stack.active is session.viewer

    session.open(_write_tabulate_dataset(tmp_path))
    assert session.view_stack.active is session.viewer
    context = CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )
    session.commands.execute("tabulate_sheet", context, ["fruit", "color"])
    assert session.viewer.sheet.__class__.__name__ == "TabulateSheet"
    assert session.viewer.sheet.is_tabulate_view is True
    assert session.viewer.stack_depth == 1
    assert len(session.view_stack.viewers) == 2
    assert session.view_stack.active is session.viewer

    session.open(path)
    assert len(session.view_stack.viewers) == 1
    assert session.view_stack.active is session.viewer
    context = CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )
    session.commands.execute("transpose_sheet", context, [])
    assert session.viewer.sheet.__class__.__name__ == "TransposeSheet"
    assert session.viewer.stack_depth == 1
    assert session.viewer.frozen_column_count == 2
    assert session.viewer.frozen_columns[:2] == ["column", "dtype"]
    assert len(session.view_stack.viewers) == 2
    assert session.view_stack.active is session.viewer


def test_correlation_supports_categorical_dtype() -> None:
    df = pl.DataFrame(
        {
            "cat": pl.Series(["a", "a", "b", "b"]).cast(pl.Categorical),
            "num": [1.0, 2.0, 3.0, 4.0],
        }
    )
    result = compute_association_table(df, ["cat", "num"], df.schema, sample_rows=None)
    assert result.height == 1
    measure = result.get_column("measure")[0]
    notes = result.get_column("notes")[0]
    assert measure == "eta2"
    assert "unsupported dtype" not in notes


def test_tabulate_command_builds_pairwise_count_matrix(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(_write_tabulate_dataset(tmp_path), viewport_rows=10, viewport_cols=8)
    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "color"])

    assert session.viewer.sheet.__class__.__name__ == "TabulateSheet"
    frame = _collect_active_frame(session)
    assert frame.to_dicts() == [
        {
            "fruit ↓ / color →": "apple",
            "green": "1 (9.1%)",
            "red": "2 (18.2%)",
            "yellow": "1 (9.1%)",
        },
        {
            "fruit ↓ / color →": "banana",
            "green": "1 (9.1%)",
            "red": "1 (9.1%)",
            "yellow": "2 (18.2%)",
        },
        {
            "fruit ↓ / color →": "cherry",
            "green": "1 (9.1%)",
            "red": "2 (18.2%)",
            "yellow": "0 (0.0%)",
        },
    ]
    assert session.viewer.status_message == "tabulate: fruit × color"


def test_tabulate_summary_selection_requires_exactly_two_columns(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(_write_tabulate_dataset(tmp_path), viewport_rows=10, viewport_cols=8)
    session.commands.execute("summary_sheet", _context(session), [])
    assert session.viewer.sheet.__class__.__name__ == "SummarySheet"

    session.viewer._selected_row_ids = {"fruit", "color"}  # type: ignore[attr-defined]
    session.commands.execute("tabulate_sheet", _context(session), [])
    assert session.viewer.sheet.__class__.__name__ == "TabulateSheet"
    assert session.viewer.sheet.left_col == "fruit"
    assert session.viewer.sheet.right_col == "color"

    session.open(_write_tabulate_dataset(tmp_path))
    session.commands.execute("summary_sheet", _context(session), [])
    session.viewer._selected_row_ids = {"fruit"}  # type: ignore[attr-defined]
    session.commands.execute("tabulate_sheet", _context(session), [])
    assert session.viewer.sheet.__class__.__name__ == "SummarySheet"
    assert session.viewer.status_message == "tabulate requires exactly two selected columns"


def test_tabulate_rejects_invalid_column_pairs(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(_write_tabulate_dataset(tmp_path), viewport_rows=10, viewport_cols=8)

    session.commands.execute("tabulate_sheet", _context(session), ["fruit"])
    assert session.viewer.status_message == "tabulate requires exactly two columns"

    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "fruit"])
    assert session.viewer.status_message == "tabulate requires two distinct columns"

    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "missing"])
    assert session.viewer.status_message == "tabulate columns not found"

    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "price"])
    assert (
        session.viewer.status_message
        == "tabulate requires categorical or low-cardinality discrete columns"
    )

    session = Runtime().open(
        _write_high_cardinality_tabulate_dataset(tmp_path),
        viewport_rows=10,
        viewport_cols=8,
    )
    session.commands.execute("tabulate_sheet", _context(session), ["customer_id", "segment"])
    assert session.viewer.status_message == (
        "tabulate too many categories: customer_id has 201 unique values"
    )

    session = Runtime().open(
        _write_large_enum_tabulate_dataset(tmp_path),
        viewport_rows=10,
        viewport_cols=8,
    )
    session.commands.execute("tabulate_sheet", _context(session), ["before", "after"])
    assert session.viewer.status_message == (
        "tabulate too many categories: before has 250 unique values"
    )


def test_tabulate_allows_mixed_low_cardinality_discrete_pairs(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(_write_tabulate_dataset(tmp_path), viewport_rows=10, viewport_cols=8)
    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "ripe"])

    assert session.viewer.sheet.__class__.__name__ == "TabulateSheet"
    frame = _collect_active_frame(session)
    assert frame.columns == ["fruit ↓ / ripe →", "false", "true"]
    assert frame.to_dicts() == [
        {"fruit ↓ / ripe →": "apple", "false": "3 (27.3%)", "true": "1 (9.1%)"},
        {"fruit ↓ / ripe →": "banana", "false": "1 (9.1%)", "true": "3 (27.3%)"},
        {"fruit ↓ / ripe →": "cherry", "false": "1 (9.1%)", "true": "2 (18.2%)"},
    ]

    session.open(_write_tabulate_dataset(tmp_path))
    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "size"])
    assert session.viewer.sheet.__class__.__name__ == "TabulateSheet"
    assert _collect_active_frame(session).columns == ["fruit ↓ / size →", "1", "2", "3"]

    session.open(_write_tabulate_dataset(tmp_path))
    session.commands.execute("tabulate_sheet", _context(session), ["store", "visit_date"])
    assert session.viewer.sheet.__class__.__name__ == "TabulateSheet"


def test_tabulate_preserves_enum_level_order(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(
        _write_grade_enum_tabulate_dataset(tmp_path),
        viewport_rows=10,
        viewport_cols=8,
    )
    session.commands.execute(
        "tabulate_sheet",
        _context(session),
        ["grade_before", "grade_after"],
    )

    frame = _collect_active_frame(session)
    assert frame.columns == ["grade_before ↓ / grade_after →", "A", "B", "C", "D", "E", "F"]
    assert frame.get_column("grade_before ↓ / grade_after →").to_list() == [
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
    ]

    session.open(_write_grade_enum_tabulate_dataset(tmp_path))
    session.commands.execute(
        "tabulate_sheet",
        _context(session),
        ["--keep-null", "grade_before", "grade_after"],
    )
    frame = _collect_active_frame(session)
    assert frame.get_column("grade_before ↓ / grade_after →").to_list() == [
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "(null)",
    ]


def test_tabulate_totals_adds_margin_row_and_column(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(
        _write_grade_enum_tabulate_dataset(tmp_path),
        viewport_rows=10,
        viewport_cols=8,
    )
    session.commands.execute(
        "tabulate_sheet",
        _context(session),
        ["--totals", "grade_before", "grade_after"],
    )

    frame = _collect_active_frame(session)
    assert frame.columns == [
        "grade_before ↓ / grade_after →",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "Total",
    ]
    assert frame.get_column("grade_before ↓ / grade_after →").to_list() == [
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "Total",
    ]
    total_row = frame.row(-1, named=True)
    assert total_row["A"] == "2 (22.2%)"
    assert total_row["B"] == "2 (22.2%)"
    assert total_row["Total"] == "9 (100.0%)"


def test_tabulate_disambiguates_generated_column_name_collisions(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(
        _write_tabulate_collision_dataset(tmp_path),
        viewport_rows=10,
        viewport_cols=8,
    )
    session.commands.execute(
        "tabulate_sheet",
        _context(session),
        ["--totals", "left", "right"],
    )

    frame = _collect_active_frame(session)
    assert frame.columns == ["left ↓ / right →", "Total", "left ↓ / right → (2)", "(total)"]
    assert frame.to_dicts() == [
        {
            "left ↓ / right →": "a",
            "Total": "1 (33.3%)",
            "left ↓ / right → (2)": "1 (33.3%)",
            "(total)": "2 (66.7%)",
        },
        {
            "left ↓ / right →": "b",
            "Total": "1 (33.3%)",
            "left ↓ / right → (2)": "0 (0.0%)",
            "(total)": "1 (33.3%)",
        },
        {
            "left ↓ / right →": "(total)",
            "Total": "2 (66.7%)",
            "left ↓ / right → (2)": "1 (33.3%)",
            "(total)": "3 (100.0%)",
        },
    ]


def test_tabulate_keep_null_option_adds_null_bucket(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(_write_tabulate_dataset(tmp_path), viewport_rows=10, viewport_cols=8)
    session.commands.execute(
        "tabulate_sheet",
        _context(session),
        ["--keep-null", "fruit", "color"],
    )

    frame = _collect_active_frame(session)
    assert frame.get_column("fruit ↓ / color →").to_list() == [
        "apple",
        "banana",
        "cherry",
        "(null)",
    ]
    null_row = frame.row(-1, named=True)
    assert null_row["red"] == "1 (8.3%)"


def test_tabulate_render_recovers_from_stale_width_cache(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    session = Runtime().open(_write_tabulate_dataset(tmp_path), viewport_rows=10, viewport_cols=8)
    session.commands.execute("tabulate_sheet", _context(session), ["fruit", "color"])

    session.viewer._header_widths = session.viewer._header_widths[:1]
    session.viewer._default_header_widths = session.viewer._default_header_widths[:1]

    plan = compute_viewport_plan(session.viewer, 100, 20)

    assert [column.name for column in plan.columns] == [
        "fruit ↓ / color →",
        "green",
        "red",
        "yellow",
    ]


def test_open_sheet_view_reports_missing_runner_keyword(tmp_path):
    path = _write_sample_dataset(tmp_path)

    class LegacySheet:
        def __init__(self, base_sheet):
            self._base = base_sheet
            self.columns = list(getattr(base_sheet, "columns", []))
            self.schema = getattr(base_sheet, "schema", {})

        def fetch_slice(self, row_start, row_count, columns):
            return self._base.fetch_slice(row_start, row_count, columns)

        def get_value_at(self, row_index, column_name=None):
            return self._base.get_value_at(row_index, column_name)

    runtime = Runtime()
    runtime.sheets.register_sheet("legacy", LegacySheet)
    session = runtime.open(path, viewport_rows=6)

    with pytest.raises(TypeError) as excinfo:
        session.open_sheet_view("legacy", base_viewer=session.viewer)

    message = str(excinfo.value)
    assert "runner" in message
    assert "legacy" in message


def test_builtin_plugins_load_via_explicit_modules(tmp_path, monkeypatch):
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.setenv("PULKA_NO_ENTRYPOINTS", "1")
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    modules = [
        "pulka_builtin_plugins.summary.plugin",
        "pulka_builtin_plugins.freq.plugin",
        "pulka_builtin_plugins.transpose.plugin",
    ]

    path = _write_sample_dataset(tmp_path)
    runtime = Runtime(plugins=modules, load_entry_points=False)
    session = runtime.open(path, viewport_rows=10, viewport_cols=6)

    assert session.loaded_plugins == sorted(modules)

    context = CommandContext(
        session.viewer.sheet,
        session.viewer,
        session=session,
        view_stack=session.view_stack,
    )
    session.commands.execute("summary_sheet", context, [])
    assert session.viewer.sheet.__class__.__name__ == "SummarySheet"


def test_builtin_plugin_can_be_disabled_via_config(tmp_path, monkeypatch):
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)

    config = tmp_path / "pulka.toml"
    config.write_text('[plugins]\ndisable = ["pulka-summary"]\n', encoding="utf-8")
    monkeypatch.setenv("PULKA_CONFIG", str(config))

    path = _write_sample_dataset(tmp_path)
    runtime = Runtime()
    session = runtime.open(path, viewport_rows=10, viewport_cols=6)

    assert "pulka-summary" not in session.loaded_plugins
    assert session.commands.get_command("summary_sheet") is None
    assert session.commands.get_command("frequency_sheet") is not None
    assert session.commands.get_command("tabulate_sheet") is not None
    assert session.commands.get_command("transpose_sheet") is not None


def test_runtime_exposes_plugin_metadata(tmp_path, monkeypatch):
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.setenv("PULKA_NO_ENTRYPOINTS", "1")
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    modules = [
        "pulka_builtin_plugins.summary.plugin",
        "pulka_builtin_plugins.freq.plugin",
    ]

    runtime = Runtime(plugins=modules, load_entry_points=False)

    assert runtime.loaded_plugins == sorted(modules)
    assert runtime.disabled_plugins == []
    assert runtime.plugin_failures == []

    class DummyRecorder:
        def __init__(self) -> None:
            self.enabled = True
            self.calls: list[dict] = []

        def record_session_start(self, **payload):
            self.calls.append(payload)

    recorder = DummyRecorder()
    runtime.bootstrap_recorder(recorder)

    assert recorder.calls
    payload = recorder.calls[0]
    assert payload["plugins"] == runtime.recorder_bootstrap.plugins
    assert payload["disabled"] == runtime.recorder_bootstrap.disabled


def test_session_surfaces_plugin_failures(tmp_path, monkeypatch):
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.setenv("PULKA_NO_ENTRYPOINTS", "1")
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    def register_fail(**_registries):
        raise RuntimeError("boom")

    _install_module(monkeypatch, "tests.fail_plugin", register_fail)

    path = _write_sample_dataset(tmp_path)
    runtime = Runtime(plugins=["tests.fail_plugin"], load_entry_points=False)
    session = runtime.open(path, viewport_rows=10, viewport_cols=6)

    assert "tests.fail_plugin" not in session.loaded_plugins
    assert session.plugin_failures
    assert session.viewer.status_message == "Plugin tests.fail_plugin failed to load; see logs"


def test_run_script_mode_uses_updated_session_viewer(tmp_path, monkeypatch):
    monkeypatch.setenv("PULKA_TEST", "1")
    monkeypatch.delenv("PULKA_NO_ENTRYPOINTS", raising=False)
    monkeypatch.delenv("PULKA_CONFIG", raising=False)

    path = _write_sample_dataset(tmp_path)
    runtime = Runtime()
    session = runtime.open(path, viewport_rows=10, viewport_cols=6)

    outputs = session.run_script(["frequency_sheet fruit", "render"], auto_render=False)

    assert session.viewer.is_freq_view is True
    assert session.viewer.stack_depth == 1
    assert "count" in session.viewer.columns
    assert outputs and "count" in outputs[-1]
