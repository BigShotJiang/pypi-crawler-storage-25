"""Web Push notification sending service."""
from datetime import datetime, timezone

from loguru import logger


def send_push_to_all(title: str, message: str, url: str | None = None, tag: str | None = None) -> dict:
    """Send a push notification to all active subscriptions.

    Returns {"sent": N, "failed": N, "removed": N}.
    """
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        logger.debug("pywebpush not installed — skipping push")
        return {"sent": 0, "failed": 0, "removed": 0, "error": "pywebpush not installed"}

    from .config import NotificationCenterSettings
    settings = NotificationCenterSettings()

    if not settings.web_push_enabled or not settings.vapid_private_key:
        return {"sent": 0, "failed": 0, "removed": 0, "error": "push disabled or no VAPID keys"}

    from fastpluggy.core.database import session_scope
    from .models import PushSubscription
    import json

    payload = json.dumps({
        "title": title,
        "message": message,
        "url": url or "/",
        "tag": tag or "notification",
    })

    vapid_claims = {
        "sub": f"mailto:{settings.vapid_contact_email}" if settings.vapid_contact_email else "mailto:noreply@localhost",
    }

    stats = {"sent": 0, "failed": 0, "removed": 0}

    with session_scope() as db:
        subscriptions = db.query(PushSubscription).filter(PushSubscription.failed_count < 5).all()

        for sub in subscriptions:
            try:
                webpush(
                    subscription_info={
                        "endpoint": sub.endpoint,
                        "keys": {
                            "p256dh": sub.p256dh_key,
                            "auth": sub.auth_key,
                        },
                    },
                    data=payload,
                    vapid_private_key=settings.vapid_private_key,
                    vapid_claims=vapid_claims,
                )
                sub.last_used_at = datetime.now(timezone.utc)
                sub.failed_count = 0
                stats["sent"] += 1
            except WebPushException as e:
                if e.response and e.response.status_code == 410:
                    db.delete(sub)
                    stats["removed"] += 1
                    logger.info(f"Removed expired push subscription: {sub.endpoint[:50]}...")
                else:
                    sub.failed_count += 1
                    stats["failed"] += 1
                    logger.warning(f"Push failed for {sub.endpoint[:50]}: {e}")
            except Exception as e:
                sub.failed_count += 1
                stats["failed"] += 1
                logger.error(f"Push error: {e}")

    return stats
