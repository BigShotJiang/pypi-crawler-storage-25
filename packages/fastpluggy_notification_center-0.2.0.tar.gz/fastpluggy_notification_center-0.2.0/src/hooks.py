"""db_purge integration — register notification cleanup target."""

from .models import Notification


def register_purge_targets() -> None:
    """Register notification_center tables as purgeable.

    Notification center — remove notifications older than 30 days.
    """
    try:
        from fastpluggy_plugin.db_purge.hooks import register_purge_target
    except ImportError:
        return

    register_purge_target(
        Notification.__tablename__,
        "created_at",
        default_retention_days=30,
    )
