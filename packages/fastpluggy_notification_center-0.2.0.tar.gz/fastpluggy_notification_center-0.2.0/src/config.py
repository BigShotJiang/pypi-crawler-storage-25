from fastpluggy.core.config import BaseDatabaseSettings


class NotificationCenterSettings(BaseDatabaseSettings):
    notification_retention_days: int = 30
    max_notifications_per_page: int = 50

    # Channel relay settings
    relay_enabled: bool = False
    relay_channels: list = []  # empty = all discovered channels
    relay_categories: list = ["error"]  # only relay these categories by default

    # VAPID Web Push settings
    vapid_private_key: str = ""
    vapid_public_key: str = ""
    vapid_contact_email: str = ""
    web_push_enabled: bool = True
