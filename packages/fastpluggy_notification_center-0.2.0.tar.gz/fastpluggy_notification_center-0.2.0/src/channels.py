"""Pluggable notification delivery channels."""
from typing import Protocol, runtime_checkable

from loguru import logger


@runtime_checkable
class NotificationChannel(Protocol):
    """Protocol for notification delivery channels.

    Any plugin can register as a channel by adding a `notification_channel`
    attribute to its plugin class that implements this protocol.
    """
    channel_name: str

    def send(self, title: str, message: str, category: str, data: dict | None = None) -> None: ...


# Registry of discovered channels
_channels: dict[str, NotificationChannel] = {}


def discover_channels(fast_pluggy) -> None:
    """Discover notification channels from all loaded plugins."""
    _channels.clear()
    for name, plugin_state in fast_pluggy.module_manager.modules.items():
        plugin = plugin_state.plugin
        channel = getattr(plugin, 'notification_channel', None)
        if channel is not None and isinstance(channel, NotificationChannel):
            _channels[channel.channel_name] = channel
            logger.info(f"notification_center: discovered channel '{channel.channel_name}' from {name}")


def get_channels() -> dict[str, NotificationChannel]:
    """Return all discovered channels."""
    return dict(_channels)


def relay_to_channels(title: str, message: str, category: str, data: dict | None = None,
                      channels: list[str] | None = None) -> dict:
    """Send a notification to matching channels.

    Args:
        channels: If provided, only send to these channel names. None = all.
    Returns:
        {"sent": [...channel_names], "failed": [...]}
    """
    from .config import NotificationCenterSettings
    settings = NotificationCenterSettings()

    target_channels = _channels
    if channels:
        target_channels = {k: v for k, v in _channels.items() if k in channels}
    elif settings.relay_channels:
        target_channels = {k: v for k, v in _channels.items() if k in settings.relay_channels}

    sent = []
    failed = []
    for name, channel in target_channels.items():
        try:
            channel.send(title=title, message=message, category=category, data=data)
            sent.append(name)
        except Exception as e:
            failed.append(name)
            logger.error(f"notification_center: channel '{name}' relay failed: {e}")

    return {"sent": sent, "failed": failed}
