from datetime import datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from fastpluggy.core.database import session_scope

from ..models import Notification
from ..repository import (
    create_notification,
    get_unread_count,
    mark_all_read,
    mark_read,
)

api_router = APIRouter()


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class CreateNotificationBody(BaseModel):
    title: str
    message: str
    category: str = "info"
    source: str | None = None
    data: dict | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _notification_to_dict(n: Notification) -> dict:
    """Convert an ORM Notification to a plain dict for JSON response."""
    return {
        "id": n.id,
        "title": n.title,
        "message": n.message,
        "category": n.category,
        "source": n.source,
        "read": n.read,
        "read_at": n.read_at.isoformat() if isinstance(n.read_at, datetime) else n.read_at,
        "created_at": n.created_at.isoformat() if isinstance(n.created_at, datetime) else n.created_at,
        "updated_at": n.updated_at.isoformat() if isinstance(n.updated_at, datetime) else n.updated_at,
        "data": n.data,
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@api_router.get("/api/notifications")
def api_list_notifications(
    read: bool | None = None,
    category: str | None = None,
    source: str | None = None,
    limit: int = 50,
    offset: int = 0,
):
    """List notifications with optional filters."""
    with session_scope() as db:
        query = db.query(Notification)
        if read is not None:
            query = query.filter(Notification.read == read)
        if category is not None:
            query = query.filter(Notification.category == category)
        if source is not None:
            query = query.filter(Notification.source == source)
        total = query.count()
        rows = query.order_by(Notification.created_at.desc()).offset(offset).limit(limit).all()
        return {
            "notifications": [_notification_to_dict(n) for n in rows],
            "total": total,
        }


@api_router.get("/api/unread-count")
def api_unread_count():
    """Return the number of unread notifications."""
    return {"count": get_unread_count()}


@api_router.post("/api/notifications/{notification_id}/read")
def api_mark_read(notification_id: int):
    """Mark a single notification as read."""
    if not mark_read(notification_id):
        raise HTTPException(status_code=404, detail="Notification not found")
    return {"status": "ok"}


@api_router.post("/api/notifications/read-all")
def api_mark_all_read():
    """Mark all unread notifications as read."""
    count = mark_all_read()
    return {"status": "ok", "count": count}


@api_router.delete("/api/notifications/{notification_id}")
def api_delete_notification(notification_id: int):
    """Delete a single notification by id."""
    with session_scope() as db:
        notification = db.query(Notification).filter(Notification.id == notification_id).first()
        if notification is None:
            raise HTTPException(status_code=404, detail="Notification not found")
        db.delete(notification)
    return {"status": "ok"}


@api_router.post("/api/notifications")
def api_create_notification(body: CreateNotificationBody):
    """Create a new notification."""
    notification = create_notification(
        title=body.title,
        message=body.message,
        category=body.category,
        source=body.source,
        data=body.data,
    )
    return _notification_to_dict(notification)
