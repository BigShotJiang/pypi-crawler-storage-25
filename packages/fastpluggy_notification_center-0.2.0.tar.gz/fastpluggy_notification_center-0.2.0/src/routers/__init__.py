from fastapi import APIRouter

from .api import api_router
from .front import front_router
from .push_api import push_api_router

notification_router = APIRouter()
notification_router.include_router(api_router)
notification_router.include_router(front_router)
notification_router.include_router(push_api_router)
