from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse

from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.widgets import CustomTemplateWidget
from ..repository import count_notifications, list_notifications

front_router = APIRouter()


@front_router.get("/", response_class=HTMLResponse, name="notification_center_index")
async def notification_index(
    request: Request,
    page: int = 1,
    read: str | None = None,
    category: str | None = None,
    view_builder=Depends(get_view_builder),
):
    per_page = 50
    offset = (page - 1) * per_page

    read_filter = None
    if read == "true":
        read_filter = True
    elif read == "false":
        read_filter = False

    notifications = list_notifications(read=read_filter, limit=per_page, offset=offset)
    total = count_notifications(read=read_filter)

    return view_builder.generate(
        request,
        title="Notifications",
        widgets=[
            CustomTemplateWidget(
                template_name="notification_center/full_page.html.j2",
                context={
                    "request": request,
                    "notifications": notifications,
                    "total": total,
                    "page": page,
                    "per_page": per_page,
                    "filter_read": read,
                    "filter_category": category,
                },
            ),
        ],
    )
