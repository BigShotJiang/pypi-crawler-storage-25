"""Push subscription API routes."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from fastpluggy.core.database import session_scope

from ..config import NotificationCenterSettings
from ..models import PushSubscription

push_api_router = APIRouter(prefix="/api/push")


class SubscribeRequest(BaseModel):
    endpoint: str
    p256dh: str
    auth: str
    user_agent: str | None = None


@push_api_router.post("/subscribe", status_code=201)
async def subscribe(body: SubscribeRequest):
    """Store a push subscription."""
    with session_scope() as db:
        existing = db.query(PushSubscription).filter_by(endpoint=body.endpoint).first()
        if existing:
            existing.p256dh_key = body.p256dh
            existing.auth_key = body.auth
            existing.user_agent = body.user_agent
            existing.failed_count = 0
            return {"status": "updated"}

        sub = PushSubscription(
            endpoint=body.endpoint,
            p256dh_key=body.p256dh,
            auth_key=body.auth,
            user_agent=body.user_agent,
        )
        db.add(sub)
    return {"status": "subscribed"}


@push_api_router.delete("/unsubscribe")
async def unsubscribe(endpoint: str):
    """Remove a push subscription by endpoint."""
    with session_scope() as db:
        sub = db.query(PushSubscription).filter_by(endpoint=endpoint).first()
        if not sub:
            raise HTTPException(status_code=404, detail="Subscription not found")
        db.delete(sub)
    return {"status": "unsubscribed"}


@push_api_router.get("/vapid-public-key")
async def vapid_public_key():
    """Return the VAPID public key for PushManager.subscribe()."""
    settings = NotificationCenterSettings()
    if not settings.vapid_public_key:
        raise HTTPException(status_code=503, detail="VAPID keys not configured")
    return {"public_key": settings.vapid_public_key}


@push_api_router.post("/generate-vapid-keys")
async def generate_vapid_keys_endpoint():
    """Generate (or regenerate) VAPID keys. Existing subscriptions will be invalidated."""
    from ..vapid_keys import generate_vapid_keys
    private_key, public_key = generate_vapid_keys()
    if not private_key:
        raise HTTPException(status_code=500, detail="Failed to generate keys — cryptography package may be missing")

    settings = NotificationCenterSettings()
    from fastpluggy.core.database import SessionLocal
    from fastpluggy.core.repository.app_settings import set_app_setting
    with SessionLocal() as db:
        set_app_setting(db, settings, "vapid_private_key", private_key)
        set_app_setting(db, settings, "vapid_public_key", public_key)

    return {"generated": True, "public_key": public_key}


@push_api_router.get("/status")
async def push_status():
    """Return push subscription stats."""
    settings = NotificationCenterSettings()
    with session_scope() as db:
        total = db.query(PushSubscription).count()
        active = db.query(PushSubscription).filter(PushSubscription.failed_count < 5).count()
    return {
        "enabled": settings.web_push_enabled,
        "has_vapid_keys": bool(settings.vapid_private_key),
        "total_subscriptions": total,
        "active_subscriptions": active,
    }
