"""VAPID key generation for Web Push notifications."""
import base64

from loguru import logger


def generate_vapid_keys() -> tuple[str, str]:
    """Generate a VAPID key pair.

    Returns (private_key_urlsafe_b64, public_key_urlsafe_b64) with no padding.
    The public key is in uncompressed point format (65 bytes), which is what
    PushManager.subscribe() expects as applicationServerKey.
    """
    try:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import serialization
    except ImportError:
        logger.warning("cryptography not installed — cannot generate VAPID keys")
        return "", ""

    private_key = ec.generate_private_key(ec.SECP256R1())

    # Private key as raw 32-byte big-endian integer -> URL-safe base64 (no padding)
    raw_private = private_key.private_numbers().private_value.to_bytes(32, "big")
    private_b64 = base64.urlsafe_b64encode(raw_private).decode().rstrip("=")

    # Public key as uncompressed X9.62 point (0x04 || x || y) -> URL-safe base64 (no padding)
    raw_public = private_key.public_key().public_bytes(
        serialization.Encoding.X962,
        serialization.PublicFormat.UncompressedPoint,
    )
    public_b64 = base64.urlsafe_b64encode(raw_public).decode().rstrip("=")

    return private_b64, public_b64
