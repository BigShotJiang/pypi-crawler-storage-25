from fastpluggy.core.database import Base
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, JSON, Index, func


class Notification(Base):
    __tablename__ = "notification_center_notifications"
    __table_args__ = (
        Index("ix_notification_created_at", "created_at"),
        Index("ix_notification_read", "read"),
        Index("ix_notification_source", "source"),
        Index("ix_notification_category", "category"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(256), nullable=False)
    message = Column(Text, nullable=False)
    category = Column(String(32), nullable=False, default="info")
    source = Column(String(128), nullable=True)
    read = Column(Boolean, nullable=False, default=False)
    read_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=func.now())
    updated_at = Column(DateTime, nullable=True, server_default=func.now(), onupdate=func.now())
    data = Column(JSON, nullable=True)

    def __repr__(self) -> str:
        return (
            f"<Notification(id={self.id}, title={self.title!r}, "
            f"category={self.category!r}, source={self.source!r}, read={self.read})>"
        )


class PushSubscription(Base):
    __tablename__ = "notification_center_push_subscriptions"
    __table_args__ = (
        Index("ix_push_sub_endpoint", "endpoint"),
        Index("ix_push_sub_failed_count", "failed_count"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    endpoint = Column(String(2048), unique=True, nullable=False)
    p256dh_key = Column(String(256), nullable=False)
    auth_key = Column(String(256), nullable=False)
    user_agent = Column(String(512), nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=func.now())
    last_used_at = Column(DateTime, nullable=True)
    failed_count = Column(Integer, nullable=False, default=0)

    def __repr__(self) -> str:
        return (
            f"<PushSubscription(id={self.id}, endpoint={self.endpoint[:60]!r}..., "
            f"failed_count={self.failed_count})>"
        )
