from datetime import datetime, timedelta, timezone

from fastpluggy.core.database import session_scope

from .models import Notification


def get_unread_count() -> int:
    """Count notifications where read=False."""
    with session_scope() as db:
        return db.query(Notification).filter(Notification.read == False).count()


def count_notifications(read: bool | None = None) -> int:
    """Count notifications with optional read filter."""
    with session_scope() as db:
        query = db.query(Notification)
        if read is not None:
            query = query.filter(Notification.read == read)
        return query.count()


def list_notifications(
    read: bool | None = None, limit: int = 50, offset: int = 0
) -> list[Notification]:
    """List notifications ordered by created_at DESC, with optional read filter."""
    with session_scope() as db:
        query = db.query(Notification)
        if read is not None:
            query = query.filter(Notification.read == read)
        return query.order_by(Notification.created_at.desc()).offset(offset).limit(limit).all()


def mark_read(notification_id: int) -> bool:
    """Set read=True and read_at=now for a single notification. Return True if found."""
    with session_scope() as db:
        notification = db.query(Notification).filter(Notification.id == notification_id).first()
        if notification is None:
            return False
        notification.read = True
        notification.read_at = datetime.now(timezone.utc)
        return True


def mark_all_read() -> int:
    """Mark all unread notifications as read. Return count updated."""
    with session_scope() as db:
        now = datetime.now(timezone.utc)
        count = (
            db.query(Notification)
            .filter(Notification.read == False)
            .update({"read": True, "read_at": now})
        )
        return count


def delete_old(days: int = 30) -> int:
    """Delete notifications older than N days. Return count deleted."""
    with session_scope() as db:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        count = db.query(Notification).filter(Notification.created_at < cutoff).delete()
        return count


def create_notification(
    title: str,
    message: str,
    category: str = "info",
    source: str | None = None,
    data: dict | None = None,
) -> Notification:
    """Create a new notification and return it."""
    with session_scope() as db:
        notification = Notification(
            title=title,
            message=message,
            category=category,
            source=source,
            data=data,
        )
        db.add(notification)
        db.flush()
        db.expunge(notification)
        return notification
