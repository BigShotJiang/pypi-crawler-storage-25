from typing import Annotated, Any

from loguru import logger

from fastpluggy.core.module_base import FastPluggyBaseModule
from fastpluggy.core.tools.inspect_tools import InjectDependency

from .config import NotificationCenterSettings


def get_router():
    from .routers import notification_router
    return notification_router


class NotificationCenterPlugin(FastPluggyBaseModule):
    module_name: str = "notification_center"
    module_menu_name: str = "Notifications"
    module_menu_icon: str = "ti ti-bell"
    module_menu_type: str = "no"  # no menu entry — topbar action used instead

    module_router: Any = get_router
    module_settings: Any = NotificationCenterSettings

    extra_js_files: list = [
        "/app_static/notification_center/js/notifications.js",
        "/app_static/notification_center/js/push-subscribe.js",
    ]
    extra_css_files: list = [
        "/app_static/notification_center/css/notifications.css",
    ]
    sw_handler_files: list = ["js/sw-handlers.js"]

    def on_load_complete(self, fast_pluggy: Annotated["FastPluggy", InjectDependency]) -> None:
        from fastpluggy.core.database import create_table_if_not_exist
        from .models import Notification, PushSubscription
        create_table_if_not_exist(Notification)
        create_table_if_not_exist(PushSubscription)

        from .hooks import register_purge_targets
        register_purge_targets()

        # Auto-generate VAPID keys on first load if not set
        settings = NotificationCenterSettings()
        if settings.web_push_enabled and not settings.vapid_private_key:
            from .vapid_keys import generate_vapid_keys
            private_key, public_key = generate_vapid_keys()
            if private_key and public_key:
                from fastpluggy.core.database import SessionLocal
                from fastpluggy.core.repository.app_settings import set_app_setting
                with SessionLocal() as db:
                    set_app_setting(db, settings, "vapid_private_key", private_key)
                    set_app_setting(db, settings, "vapid_public_key", public_key)
                logger.info("notification_center: auto-generated VAPID keys")

        # Subscribe to all notification.* events on the event bus
        fast_pluggy.events.on_namespace("notification", self._handle_notification_create)
        fast_pluggy.events.on("notification.push", self._handle_push)
        logger.info("notification_center: subscribed to notification.* events")

        # Discover notification channels from loaded plugins
        from .channels import discover_channels
        discover_channels(fast_pluggy)

        # Subscribe to notification.relay events (explicit relay to all channels)
        fast_pluggy.events.on("notification.relay", self._handle_relay)
        logger.info("notification_center: channel relay configured")

        # Register topbar bell icon
        from fastpluggy.core.global_registry import GlobalRegistry
        from fastpluggy.core.topbar import TopbarAction

        GlobalRegistry.extend_globals('topbar_actions', items=[
            TopbarAction(
                id='notification-center',
                icon='ti ti-bell',
                tooltip='Notifications',
                position=90,
                js_onclick='toggleNotificationPanel()',
            )
        ])

    def _handle_notification_create(self, event) -> None:
        """Create a Notification record from an event bus notification.* event."""
        from .repository import create_notification
        from .config import NotificationCenterSettings

        payload = event.payload
        category = payload.get("category", "info")

        create_notification(
            title=payload.get("title", "Notification"),
            message=payload.get("message", ""),
            category=category,
            source=event.source,
            data=payload.get("data"),
        )

        # Auto-relay to channels if enabled and category matches
        settings = NotificationCenterSettings()
        if settings.relay_enabled and category in settings.relay_categories:
            from .channels import relay_to_channels
            relay_to_channels(
                title=payload.get("title", "Notification"),
                message=payload.get("message", ""),
                category=category,
                data=payload.get("data"),
            )

    def _handle_relay(self, event) -> None:
        """Explicitly relay to all channels, bypassing category filter."""
        from .channels import relay_to_channels
        payload = event.payload
        relay_to_channels(
            title=payload.get("title", "Notification"),
            message=payload.get("message", ""),
            category=payload.get("category", "info"),
            data=payload.get("data"),
        )

    def _handle_push(self, event) -> None:
        """Send browser push notification from event bus."""
        from .push_service import send_push_to_all

        payload = event.payload
        send_push_to_all(
            title=payload.get("title", "Notification"),
            message=payload.get("message", ""),
            url=payload.get("url"),
            tag=payload.get("tag"),
        )
