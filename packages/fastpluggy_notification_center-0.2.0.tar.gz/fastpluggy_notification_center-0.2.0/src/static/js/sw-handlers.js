// notification_center — service worker push handlers
// Overrides core's minimal push/notificationclick with richer behavior:
// action buttons, image support, vibration, and client notification on click.

self.swPushHandler = function(event) {
    if (!event.data) return;
    let data;
    try {
        data = event.data.json();
    } catch (e) {
        data = { title: 'Notification', message: event.data.text() };
    }
    const options = {
        body: data.message || '',
        icon: data.icon || '/static/favicon.svg',
        badge: data.badge || '/static/favicon.svg',
        data: { url: data.url || '/', actions_map: data.actions_map || {} },
        tag: data.tag || 'fp-notification',
        renotify: !!data.tag,
        silent: data.silent || false,
    };
    if (data.image) options.image = data.image;
    if (data.actions) options.actions = data.actions;
    if (data.vibrate) options.vibrate = data.vibrate;
    event.waitUntil(
        self.registration.showNotification(data.title || 'FastPluggy', options)
    );
};

self.swNotificationClickHandler = function(event) {
    event.notification.close();
    const data = event.notification.data || {};
    const url = data.url || '/';

    // Handle action button clicks
    if (event.action && data.actions_map && data.actions_map[event.action]) {
        event.waitUntil(clients.openWindow(data.actions_map[event.action]));
        return;
    }

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clientList) {
            for (var i = 0; i < clientList.length; i++) {
                var client = clientList[i];
                if (client.url.includes(url) && 'focus' in client) {
                    client.postMessage({ type: 'NC_NOTIFICATION_CLICKED', url: url });
                    return client.focus();
                }
            }
            if (clients.openWindow) return clients.openWindow(url);
        })
    );
};
