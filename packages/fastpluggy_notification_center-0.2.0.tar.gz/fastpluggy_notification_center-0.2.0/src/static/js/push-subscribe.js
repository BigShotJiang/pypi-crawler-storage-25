/**
 * Web Push subscription management for notification_center.
 * Handles browser permission, VAPID subscription, and server registration.
 */
(function() {
    'use strict';

    function getPushApiBase() {
        // Reuse NC_API_BASE from notifications.js if available
        if (typeof NC_API_BASE !== 'undefined') return NC_API_BASE;
        return '/plugin-pkg/notification_center';
    }

    /**
     * Get the existing service worker registration (from websocket_tool).
     * Returns the registration, or null if not available within timeout.
     */
    async function ensureServiceWorker() {
        if (!('serviceWorker' in navigator)) return null;
        try {
            // Wait for the existing SW (registered by websocket_tool at /)
            // with a timeout so we don't hang if no SW is available
            var reg = await Promise.race([
                navigator.serviceWorker.ready,
                new Promise(function(resolve) { setTimeout(function() { resolve(null); }, 3000); })
            ]);
            return reg;
        } catch (e) {
            return null;
        }
    }

    /**
     * Check if push is supported and get current state.
     * Returns: 'supported', 'denied', 'granted', 'subscribed', 'unsupported'
     */
    async function getPushState() {
        if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
            return 'unsupported';
        }
        if (Notification.permission === 'denied') return 'denied';

        var reg = await ensureServiceWorker();
        if (!reg) return 'supported';
        try {
            var sub = await reg.pushManager.getSubscription();
        } catch (e) {
            // Stale subscription (e.g. VAPID key changed) — allow re-subscribe
            return Notification.permission === 'granted' ? 'granted' : 'supported';
        }
        if (sub) return 'subscribed';
        if (Notification.permission === 'granted') return 'granted';
        return 'supported';
    }

    /**
     * Subscribe to push notifications.
     */
    async function subscribePush() {
        var base = getPushApiBase();
        // Fetch VAPID public key
        var resp = await fetch(base + '/api/push/vapid-public-key');
        if (!resp.ok) {
            showNotification('Push not available — VAPID keys not configured', 'warning');
            return false;
        }
        var data = await resp.json();
        var publicKey = data.public_key;

        // Convert URL-safe base64 to Uint8Array
        var b64 = publicKey.replace(/-/g, '+').replace(/_/g, '/');
        var padding = '='.repeat((4 - b64.length % 4) % 4);
        var rawKey = atob(b64 + padding);
        var keyArray = new Uint8Array(rawKey.length);
        for (var i = 0; i < rawKey.length; i++) {
            keyArray[i] = rawKey.charCodeAt(i);
        }

        var reg = await ensureServiceWorker();
        if (!reg) {
            showNotification('Service worker not available — cannot enable push', 'warning');
            return false;
        }
        var sub = await reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: keyArray,
        });

        // Send subscription to server
        var keys = sub.toJSON().keys;
        await fetch(base + '/api/push/subscribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                endpoint: sub.endpoint,
                p256dh: keys.p256dh,
                auth: keys.auth,
                user_agent: navigator.userAgent,
            }),
        });
        showNotification('Push notifications enabled!', 'success');
        return true;
    }

    /**
     * Unsubscribe from push notifications.
     */
    async function unsubscribePush() {
        var base = getPushApiBase();
        var reg = await ensureServiceWorker();
        if (!reg) return false;
        var sub;
        try { sub = await reg.pushManager.getSubscription(); } catch (e) { sub = null; }
        if (sub) {
            await fetch(base + '/api/push/unsubscribe?endpoint=' + encodeURIComponent(sub.endpoint), { method: 'DELETE' });
            await sub.unsubscribe();
        }
        showNotification('Push notifications disabled', 'info');
        return true;
    }

    /**
     * Update the push toggle button state.
     */
    async function updatePushButton() {
        var btn = document.getElementById('nc-push-toggle');
        if (!btn) return;

        var state = await getPushState();
        btn.disabled = false;

        switch (state) {
            case 'unsupported':
                btn.innerHTML = '<i class="ti ti-bell-off me-1"></i>Push not supported';
                btn.disabled = true;
                btn.className = 'btn btn-sm btn-outline-secondary';
                break;
            case 'denied':
                btn.innerHTML = '<i class="ti ti-bell-x me-1"></i>Push blocked by browser';
                btn.disabled = true;
                btn.className = 'btn btn-sm btn-outline-danger';
                break;
            case 'subscribed':
                btn.innerHTML = '<i class="ti ti-bell-ringing me-1"></i>Push enabled';
                btn.className = 'btn btn-sm btn-success';
                btn.onclick = async function() { await unsubscribePush(); updatePushButton(); };
                break;
            default:
                btn.innerHTML = '<i class="ti ti-bell-plus me-1"></i>Enable push';
                btn.className = 'btn btn-sm btn-primary';
                btn.onclick = async function() { await subscribePush(); updatePushButton(); };
        }
    }

    // Export
    window.subscribePush = subscribePush;
    window.unsubscribePush = unsubscribePush;
    window.updatePushButton = updatePushButton;
    window.getPushState = getPushState;

    // Auto-update button on load
    document.addEventListener('DOMContentLoaded', updatePushButton);

    // Re-update when SW activates (may arrive after initial timeout)
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('controllerchange', updatePushButton);
    }
})();
