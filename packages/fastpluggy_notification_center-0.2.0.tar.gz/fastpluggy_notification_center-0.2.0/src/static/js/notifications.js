/**
 * Notification Center — topbar panel & badge
 */

/* ---------- API base URL detection ---------- */
var NC_API_BASE = (function() {
    var scripts = document.querySelectorAll('script[src*="notification_center"]');
    if (scripts.length) {
        var src = scripts[0].src;
        var match = src.match(/(\/plugin(?:-pkg)?\/notification_center)\//);
        if (match) return match[1];
    }
    return '/plugin-pkg/notification_center';
})();

/* ---------- Helpers ---------- */

function ncRelativeTime(dateStr) {
    if (!dateStr) return '';
    var now = Date.now();
    var then = new Date(dateStr).getTime();
    var diff = Math.floor((now - then) / 1000);
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
    return new Date(dateStr).toLocaleDateString();
}

function ncCategoryIcon(category) {
    switch (category) {
        case 'warning': return 'ti ti-alert-triangle';
        case 'success': return 'ti ti-circle-check';
        case 'error':   return 'ti ti-alert-circle';
        default:        return 'ti ti-info-circle';
    }
}

function ncCategoryColor(category) {
    switch (category) {
        case 'warning': return 'text-yellow';
        case 'success': return 'text-green';
        case 'error':   return 'text-red';
        default:        return 'text-blue';
    }
}

function ncTruncate(str, len) {
    if (!str) return '';
    return str.length > len ? str.substring(0, len) + '...' : str;
}

/* ---------- Badge ---------- */

function updateBadge() {
    fetch(NC_API_BASE + '/api/unread-count')
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var btn = document.getElementById('notification-center');
            if (!btn) return;
            var badge = btn.querySelector('.badge-notification');
            if (data.count > 0) {
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'badge bg-red badge-notification badge-blink';
                    btn.appendChild(badge);
                }
                badge.textContent = data.count > 99 ? '99+' : data.count;
            } else if (badge) {
                badge.remove();
            }
        })
        .catch(function() { /* silent */ });
}

/* ---------- Panel rendering ---------- */

function renderNotificationItem(n) {
    var unreadCls = n.read ? '' : ' nc-unread';
    var iconCls = ncCategoryIcon(n.category) + ' ' + ncCategoryColor(n.category);
    return '<div class="nc-item' + unreadCls + '" data-nc-id="' + n.id + '" onclick="markRead(' + n.id + ')">' +
        '<div class="nc-item-icon"><i class="' + iconCls + '"></i></div>' +
        '<div class="nc-item-content">' +
            '<div class="nc-item-title">' + ncTruncate(n.title, 60) + '</div>' +
            '<div class="nc-item-message">' + ncTruncate(n.message, 80) + '</div>' +
            '<div class="nc-item-time">' + ncRelativeTime(n.created_at) + '</div>' +
        '</div>' +
    '</div>';
}

function openPanel(notifications) {
    closePanel();

    var body = '';
    if (!notifications || notifications.length === 0) {
        body = '<div class="nc-empty"><i class="ti ti-bell-off" style="font-size:2rem;display:block;margin-bottom:8px"></i>No notifications</div>';
    } else {
        for (var i = 0; i < notifications.length; i++) {
            body += renderNotificationItem(notifications[i]);
        }
    }

    var html =
        '<div id="nc-panel" class="nc-dropdown-panel">' +
            '<div class="nc-panel-header">' +
                '<span class="fw-bold">Notifications</span>' +
                '<a href="#" onclick="markAllRead(); return false;" class="text-muted small">Mark all read</a>' +
            '</div>' +
            '<div class="nc-panel-body">' + body + '</div>' +
            '<div class="nc-panel-footer">' +
                '<a href="' + NC_API_BASE + '/">View all</a>' +
            '</div>' +
        '</div>';

    document.body.insertAdjacentHTML('beforeend', html);
}

function closePanel() {
    var panel = document.getElementById('nc-panel');
    if (panel) panel.remove();
}

function isPanelOpen() {
    return !!document.getElementById('nc-panel');
}

/* ---------- Public actions ---------- */

function toggleNotificationPanel() {
    if (isPanelOpen()) {
        closePanel();
        return;
    }
    fetch(NC_API_BASE + '/api/notifications?limit=10')
        .then(function(r) { return r.json(); })
        .then(function(data) {
            openPanel(data.notifications || []);
        })
        .catch(function() {
            openPanel([]);
        });
}

function markRead(id) {
    fetch(NC_API_BASE + '/api/notifications/' + id + '/read', { method: 'POST' })
        .then(function() {
            var item = document.querySelector('.nc-item[data-nc-id="' + id + '"]');
            if (item) item.classList.remove('nc-unread');
            updateBadge();
        })
        .catch(function() { /* silent */ });
}

function markAllRead() {
    fetch(NC_API_BASE + '/api/notifications/read-all', { method: 'POST' })
        .then(function() {
            var items = document.querySelectorAll('.nc-item.nc-unread');
            for (var i = 0; i < items.length; i++) {
                items[i].classList.remove('nc-unread');
            }
            updateBadge();
        })
        .catch(function() { /* silent */ });
}

/* ---------- Bootstrap ---------- */

document.addEventListener('click', function(e) {
    var panel = document.getElementById('nc-panel');
    if (!panel) return;
    var btn = document.getElementById('notification-center');
    if (panel.contains(e.target) || (btn && btn.contains(e.target))) return;
    closePanel();
});

document.addEventListener('DOMContentLoaded', function() {
    updateBadge();
});
