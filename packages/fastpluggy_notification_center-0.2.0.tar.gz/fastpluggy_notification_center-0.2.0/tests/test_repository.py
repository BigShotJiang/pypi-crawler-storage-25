from datetime import datetime, timedelta, timezone

from fastpluggy_plugin.notification_center.models import Notification
from fastpluggy_plugin.notification_center.repository import (
    create_notification,
    delete_old,
    get_unread_count,
    list_notifications,
    mark_all_read,
    mark_read,
)


def test_create_notification():
    """Create a notification and verify all fields."""
    n = create_notification(
        title="Test Title",
        message="Test message body",
        category="warning",
        source="test_suite",
        data={"key": "value"},
    )
    assert n.id is not None
    assert n.title == "Test Title"
    assert n.message == "Test message body"
    assert n.category == "warning"
    assert n.source == "test_suite"
    assert n.read is False
    assert n.data == {"key": "value"}


def test_create_notification_defaults():
    """Create with minimal args and verify defaults."""
    n = create_notification(title="Minimal", message="Just a message")
    assert n.id is not None
    assert n.category == "info"
    assert n.read is False
    assert n.source is None
    assert n.data is None


def test_get_unread_count():
    """Create 3 notifications, mark 1 read, verify unread count is 2."""
    n1 = create_notification(title="A", message="a")
    create_notification(title="B", message="b")
    create_notification(title="C", message="c")
    mark_read(n1.id)
    assert get_unread_count() == 2


def test_get_unread_count_empty():
    """No notifications should give count 0."""
    assert get_unread_count() == 0


def test_list_notifications_all():
    """Create 3 notifications, list all, verify newest-first ordering."""
    create_notification(title="First", message="1")
    create_notification(title="Second", message="2")
    create_notification(title="Third", message="3")
    results = list_notifications()
    assert len(results) == 3
    # Newest first — IDs are auto-incrementing so the highest ID is newest
    assert results[0].title == "Third"
    assert results[-1].title == "First"


def test_list_notifications_filter_read():
    """Filter by read status."""
    n1 = create_notification(title="A", message="a")
    create_notification(title="B", message="b")
    create_notification(title="C", message="c")
    mark_read(n1.id)

    read_items = list_notifications(read=True)
    assert len(read_items) == 1
    assert read_items[0].title == "A"

    unread_items = list_notifications(read=False)
    assert len(unread_items) == 2


def test_list_notifications_pagination():
    """Create 5, list with limit=2 offset=1, verify correct slice."""
    for i in range(5):
        create_notification(title=f"Item {i}", message=f"msg {i}")
    results = list_notifications(limit=2, offset=1)
    assert len(results) == 2
    # Ordered newest first: Item 4, Item 3, Item 2, Item 1, Item 0
    # offset=1 skips Item 4, so we get Item 3, Item 2
    assert results[0].title == "Item 3"
    assert results[1].title == "Item 2"


def test_mark_read():
    """Mark a notification as read and verify read_at is set."""
    n = create_notification(title="Unread", message="to be read")
    assert n.read is False

    result = mark_read(n.id)
    assert result is True

    items = list_notifications(read=True)
    assert len(items) == 1
    assert items[0].read is True
    assert items[0].read_at is not None


def test_mark_read_not_found():
    """mark_read with a non-existent ID returns False."""
    assert mark_read(99999) is False


def test_mark_all_read():
    """Create 3 unread, mark_all_read returns 3, verify all are read."""
    create_notification(title="A", message="a")
    create_notification(title="B", message="b")
    create_notification(title="C", message="c")

    count = mark_all_read()
    assert count == 3

    unread = list_notifications(read=False)
    assert len(unread) == 0

    all_read = list_notifications(read=True)
    assert len(all_read) == 3
    for item in all_read:
        assert item.read is True


def test_delete_old():
    """Create 2 notifications, backdate one to 31 days ago, delete_old(30) removes only the old one."""
    create_notification(title="Recent", message="new")
    old = create_notification(title="Old", message="ancient")

    # Backdate the old notification's created_at via direct SQL
    from fastpluggy_plugin.notification_center.repository import session_scope
    with session_scope() as db:
        row = db.query(Notification).filter(Notification.id == old.id).first()
        row.created_at = datetime.now(timezone.utc) - timedelta(days=31)

    count = delete_old(30)
    assert count == 1

    remaining = list_notifications()
    assert len(remaining) == 1
    assert remaining[0].title == "Recent"


def test_create_notification_with_data():
    """Create with a data dict and verify it round-trips."""
    payload = {"url": "/test", "badge": "new"}
    n = create_notification(title="With Data", message="has extras", data=payload)
    assert n.data == payload

    items = list_notifications()
    assert len(items) == 1
    assert items[0].data == {"url": "/test", "badge": "new"}
