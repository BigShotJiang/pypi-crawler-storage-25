import pytest
from unittest.mock import patch, MagicMock

from sqlalchemy.orm import sessionmaker

from fastpluggy.core.database import Base
from fastpluggy_plugin.notification_center.models import PushSubscription

from db_helpers import create_test_engine, make_test_session_scope


# ---------------------------------------------------------------------------
# Fixtures — push_service imports session_scope lazily (inside the function),
# so we patch the canonical location in fastpluggy.core.database.
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def test_db():
    """Patch session_scope at the database module level so push_service's
    lazy import picks it up."""
    engine = create_test_engine()
    Base.metadata.create_all(engine)
    TestSession = sessionmaker(bind=engine, expire_on_commit=False)
    mock_scope = make_test_session_scope(TestSession)

    with patch(
        "fastpluggy.core.database.session_scope",
        mock_scope,
    ):
        yield engine, TestSession

    Base.metadata.drop_all(engine)


def _add_subscription(TestSession, endpoint="https://push.example.com/sub/1",
                       p256dh="BKey1", auth="auth1", failed_count=0):
    """Helper: insert a PushSubscription directly into the test DB."""
    session = TestSession()
    sub = PushSubscription(
        endpoint=endpoint,
        p256dh_key=p256dh,
        auth_key=auth,
        failed_count=failed_count,
    )
    session.add(sub)
    session.commit()
    sub_id = sub.id
    session.close()
    return sub_id


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_send_push_no_pywebpush(test_db):
    """When pywebpush is not installed, send_push_to_all returns an error dict."""
    import sys

    # Ensure pywebpush is not in sys.modules so the lazy import triggers
    saved = sys.modules.pop("pywebpush", None)

    import builtins
    real_import = builtins.__import__

    def mock_import(name, *args, **kwargs):
        if name == "pywebpush":
            raise ImportError("mocked: pywebpush not installed")
        return real_import(name, *args, **kwargs)

    try:
        with patch("builtins.__import__", side_effect=mock_import):
            from fastpluggy_plugin.notification_center.push_service import send_push_to_all
            result = send_push_to_all("Test", "Hello")
    finally:
        # Restore so subsequent tests aren't affected
        if saved is not None:
            sys.modules["pywebpush"] = saved

    assert result["error"] == "pywebpush not installed"
    assert result["sent"] == 0


def test_send_push_disabled(test_db):
    """When web_push_enabled is False, returns error without sending."""
    mock_settings = MagicMock()
    mock_settings.web_push_enabled = False
    mock_settings.vapid_private_key = ""

    # Provide a fake pywebpush so the import succeeds and we reach the settings check
    fake_pywebpush = MagicMock()
    fake_pywebpush.WebPushException = Exception

    with (
        patch(
            "fastpluggy_plugin.notification_center.config.NotificationCenterSettings",
            return_value=mock_settings,
        ),
        patch.dict("sys.modules", {"pywebpush": fake_pywebpush}),
    ):
        from fastpluggy_plugin.notification_center.push_service import send_push_to_all
        result = send_push_to_all("Test", "Hello")

    assert result["error"] == "push disabled or no VAPID keys"
    assert result["sent"] == 0


def test_send_push_success(test_db):
    """Successful push to multiple subscriptions increments sent count."""
    _engine, TestSession = test_db

    _add_subscription(TestSession, endpoint="https://push.example.com/sub/1")
    _add_subscription(TestSession, endpoint="https://push.example.com/sub/2")

    mock_settings = MagicMock()
    mock_settings.web_push_enabled = True
    mock_settings.vapid_private_key = "fake-private-key"
    mock_settings.vapid_contact_email = "test@example.com"

    mock_webpush = MagicMock()

    with (
        patch(
            "fastpluggy_plugin.notification_center.config.NotificationCenterSettings",
            return_value=mock_settings,
        ),
        patch.dict("sys.modules", {"pywebpush": MagicMock(
            webpush=mock_webpush,
            WebPushException=Exception,
        )}),
    ):
        from fastpluggy_plugin.notification_center.push_service import send_push_to_all
        result = send_push_to_all("Deploy", "v1.0 deployed", url="/deploy", tag="deploy")

    assert result["sent"] == 2
    assert result["failed"] == 0
    assert result["removed"] == 0
    assert mock_webpush.call_count == 2


def test_send_push_410_removes_subscription(test_db):
    """A 410 response from the push service removes the subscription."""
    _engine, TestSession = test_db

    sub_id = _add_subscription(TestSession, endpoint="https://push.example.com/sub/expired")

    mock_settings = MagicMock()
    mock_settings.web_push_enabled = True
    mock_settings.vapid_private_key = "fake-private-key"
    mock_settings.vapid_contact_email = ""

    # Create a real-looking WebPushException with a 410 response
    mock_response = MagicMock()
    mock_response.status_code = 410

    class FakeWebPushException(Exception):
        def __init__(self, msg, response=None):
            super().__init__(msg)
            self.response = response

    exc_410 = FakeWebPushException("Gone", response=mock_response)

    mock_webpush = MagicMock(side_effect=exc_410)

    fake_pywebpush = MagicMock()
    fake_pywebpush.webpush = mock_webpush
    fake_pywebpush.WebPushException = FakeWebPushException

    with (
        patch(
            "fastpluggy_plugin.notification_center.config.NotificationCenterSettings",
            return_value=mock_settings,
        ),
        patch.dict("sys.modules", {"pywebpush": fake_pywebpush}),
    ):
        from fastpluggy_plugin.notification_center.push_service import send_push_to_all
        result = send_push_to_all("Test", "msg")

    assert result["removed"] == 1
    assert result["sent"] == 0

    # Verify the subscription was actually deleted from DB
    session = TestSession()
    count = session.query(PushSubscription).filter_by(id=sub_id).count()
    session.close()
    assert count == 0


def test_send_push_increments_failed_count(test_db):
    """A non-410 error increments failed_count on the subscription."""
    _engine, TestSession = test_db

    _add_subscription(TestSession, endpoint="https://push.example.com/sub/flaky")

    mock_settings = MagicMock()
    mock_settings.web_push_enabled = True
    mock_settings.vapid_private_key = "fake-private-key"
    mock_settings.vapid_contact_email = "test@example.com"

    # A WebPushException with a non-410 response (e.g. 429 rate limit)
    mock_response = MagicMock()
    mock_response.status_code = 429

    class FakeWebPushException(Exception):
        def __init__(self, msg, response=None):
            super().__init__(msg)
            self.response = response

    exc_429 = FakeWebPushException("Too Many Requests", response=mock_response)

    mock_webpush = MagicMock(side_effect=exc_429)

    fake_pywebpush = MagicMock()
    fake_pywebpush.webpush = mock_webpush
    fake_pywebpush.WebPushException = FakeWebPushException

    with (
        patch(
            "fastpluggy_plugin.notification_center.config.NotificationCenterSettings",
            return_value=mock_settings,
        ),
        patch.dict("sys.modules", {"pywebpush": fake_pywebpush}),
    ):
        from fastpluggy_plugin.notification_center.push_service import send_push_to_all
        result = send_push_to_all("Test", "msg")

    assert result["failed"] == 1
    assert result["sent"] == 0
    assert result["removed"] == 0

    # Verify failed_count was incremented in DB
    session = TestSession()
    sub = session.query(PushSubscription).filter_by(
        endpoint="https://push.example.com/sub/flaky"
    ).first()
    assert sub is not None
    assert sub.failed_count == 1
    session.close()
