import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock

from sqlalchemy.orm import sessionmaker

from fastpluggy.core.database import Base
from fastpluggy_plugin.notification_center.routers import notification_router

from db_helpers import create_test_engine, make_test_session_scope


# ---------------------------------------------------------------------------
# Fixtures — patch session_scope in push_api and repository modules
# so that the push endpoints and model queries share the same in-memory DB.
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def test_db():
    """Patch session_scope in both core.database and repository modules
    with the same in-memory DB."""
    engine = create_test_engine()
    Base.metadata.create_all(engine)
    TestSession = sessionmaker(bind=engine, expire_on_commit=False)
    mock_scope = make_test_session_scope(TestSession)

    with (
        patch(
            "fastpluggy_plugin.notification_center.routers.push_api.session_scope",
            mock_scope,
        ),
        patch(
            "fastpluggy_plugin.notification_center.repository.session_scope",
            mock_scope,
        ),
    ):
        yield engine

    Base.metadata.drop_all(engine)


# ---------------------------------------------------------------------------
# TestClient wired to the notification router (includes push_api_router)
# ---------------------------------------------------------------------------

app = FastAPI()
app.include_router(notification_router)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_subscribe():
    """POST /api/push/subscribe stores a new subscription and returns 201."""
    resp = client.post(
        "/api/push/subscribe",
        json={
            "endpoint": "https://push.example.com/sub/abc123",
            "p256dh": "BNcRdreA...",
            "auth": "tBHItJ...",
            "user_agent": "TestBrowser/1.0",
        },
    )
    assert resp.status_code == 201
    assert resp.json()["status"] == "subscribed"


def test_subscribe_update():
    """POSTing twice with the same endpoint updates the existing subscription."""
    payload = {
        "endpoint": "https://push.example.com/sub/same-endpoint",
        "p256dh": "original-p256dh",
        "auth": "original-auth",
        "user_agent": "Browser/1.0",
    }
    resp1 = client.post("/api/push/subscribe", json=payload)
    assert resp1.status_code == 201
    assert resp1.json()["status"] == "subscribed"

    # Subscribe again with updated keys
    payload["p256dh"] = "updated-p256dh"
    payload["auth"] = "updated-auth"
    resp2 = client.post("/api/push/subscribe", json=payload)
    assert resp2.status_code == 201
    assert resp2.json()["status"] == "updated"


def test_unsubscribe():
    """Subscribe then DELETE removes the subscription."""
    # First subscribe
    client.post(
        "/api/push/subscribe",
        json={
            "endpoint": "https://push.example.com/sub/to-remove",
            "p256dh": "key1",
            "auth": "auth1",
        },
    )

    # Then unsubscribe
    resp = client.delete(
        "/api/push/unsubscribe",
        params={"endpoint": "https://push.example.com/sub/to-remove"},
    )
    assert resp.status_code == 200
    assert resp.json()["status"] == "unsubscribed"


def test_unsubscribe_not_found():
    """DELETE non-existent subscription returns 404."""
    resp = client.delete(
        "/api/push/unsubscribe",
        params={"endpoint": "https://push.example.com/sub/does-not-exist"},
    )
    assert resp.status_code == 404
    assert resp.json()["detail"] == "Subscription not found"


def test_vapid_public_key():
    """GET /api/push/vapid-public-key returns the key when configured."""
    mock_settings = MagicMock()
    mock_settings.vapid_public_key = "BFakePublicKeyBase64..."

    with patch(
        "fastpluggy_plugin.notification_center.routers.push_api.NotificationCenterSettings",
        return_value=mock_settings,
    ):
        resp = client.get("/api/push/vapid-public-key")

    assert resp.status_code == 200
    assert resp.json()["public_key"] == "BFakePublicKeyBase64..."


def test_vapid_public_key_not_configured():
    """GET /api/push/vapid-public-key returns 503 when key is empty."""
    mock_settings = MagicMock()
    mock_settings.vapid_public_key = ""

    with patch(
        "fastpluggy_plugin.notification_center.routers.push_api.NotificationCenterSettings",
        return_value=mock_settings,
    ):
        resp = client.get("/api/push/vapid-public-key")

    assert resp.status_code == 503
    assert resp.json()["detail"] == "VAPID keys not configured"


def test_push_status():
    """GET /api/push/status returns subscription counts and config state."""
    # Add a couple of subscriptions
    client.post(
        "/api/push/subscribe",
        json={
            "endpoint": "https://push.example.com/sub/1",
            "p256dh": "key1",
            "auth": "auth1",
        },
    )
    client.post(
        "/api/push/subscribe",
        json={
            "endpoint": "https://push.example.com/sub/2",
            "p256dh": "key2",
            "auth": "auth2",
        },
    )

    mock_settings = MagicMock()
    mock_settings.web_push_enabled = True
    mock_settings.vapid_private_key = "some-private-key"

    with patch(
        "fastpluggy_plugin.notification_center.routers.push_api.NotificationCenterSettings",
        return_value=mock_settings,
    ):
        resp = client.get("/api/push/status")

    assert resp.status_code == 200
    body = resp.json()
    assert body["enabled"] is True
    assert body["has_vapid_keys"] is True
    assert body["total_subscriptions"] == 2
    assert body["active_subscriptions"] == 2
