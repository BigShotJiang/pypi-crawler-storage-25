"""Tests for the notification channel system."""
from unittest.mock import MagicMock, patch

import pytest

from fastpluggy_plugin.notification_center.channels import (
    NotificationChannel,
    _channels,
    discover_channels,
    get_channels,
    relay_to_channels,
)


class _MockChannel:
    """A concrete class satisfying NotificationChannel protocol, backed by a MagicMock."""

    def __init__(self, name: str, side_effect=None):
        self.channel_name = name
        self.send = MagicMock()
        if side_effect:
            self.send.side_effect = side_effect


def _make_mock_channel(name: str, side_effect=None) -> _MockChannel:
    """Create a mock channel that passes isinstance(ch, NotificationChannel)."""
    return _MockChannel(name, side_effect=side_effect)


@pytest.fixture(autouse=True)
def clear_channels():
    """Ensure the global _channels registry is clean for each test."""
    _channels.clear()
    yield
    _channels.clear()


# --- Protocol ---

def test_notification_channel_protocol():
    """A class with channel_name and send is recognized as NotificationChannel."""

    class GoodChannel:
        channel_name: str = "test"

        def send(self, title: str, message: str, category: str, data: dict | None = None) -> None:
            pass

    assert isinstance(GoodChannel(), NotificationChannel)


def test_notification_channel_protocol_rejects_missing_send():
    """An object without send() is NOT a NotificationChannel."""

    class BadChannel:
        channel_name: str = "bad"

    assert not isinstance(BadChannel(), NotificationChannel)


# --- discover_channels ---

def test_discover_channels():
    """Discovers a plugin that exposes a notification_channel attribute."""
    channel = _make_mock_channel("email")

    plugin = MagicMock()
    plugin.notification_channel = channel

    plugin_state = MagicMock()
    plugin_state.plugin = plugin

    fast_pluggy = MagicMock()
    fast_pluggy.module_manager.modules = {"email_plugin": plugin_state}

    discover_channels(fast_pluggy)

    assert "email" in _channels
    assert _channels["email"] is channel


def test_discover_channels_ignores_non_channels():
    """Plugins without a notification_channel attribute are skipped."""
    plugin = MagicMock(spec=[])  # no notification_channel attr
    del plugin.notification_channel  # ensure getattr returns None

    plugin_state = MagicMock()
    plugin_state.plugin = plugin

    fast_pluggy = MagicMock()
    fast_pluggy.module_manager.modules = {"plain_plugin": plugin_state}

    discover_channels(fast_pluggy)

    assert _channels == {}


def test_discover_channels_ignores_non_protocol_channel():
    """A notification_channel that doesn't satisfy the protocol is ignored."""
    bad_channel = "not a channel object"

    plugin = MagicMock()
    plugin.notification_channel = bad_channel

    plugin_state = MagicMock()
    plugin_state.plugin = plugin

    fast_pluggy = MagicMock()
    fast_pluggy.module_manager.modules = {"bad_plugin": plugin_state}

    discover_channels(fast_pluggy)

    assert _channels == {}


def test_discover_channels_clears_previous():
    """discover_channels() clears old entries before scanning."""
    _channels["stale"] = _make_mock_channel("stale")

    fast_pluggy = MagicMock()
    fast_pluggy.module_manager.modules = {}

    discover_channels(fast_pluggy)

    assert _channels == {}


# --- relay_to_channels ---

@patch("fastpluggy_plugin.notification_center.config.NotificationCenterSettings")
def test_relay_to_channels_all(mock_settings_cls):
    """All registered channels receive the notification when no filter is given."""
    mock_settings_cls.return_value = MagicMock(relay_channels=[])

    ch1 = _make_mock_channel("ch1")
    ch2 = _make_mock_channel("ch2")
    _channels["ch1"] = ch1
    _channels["ch2"] = ch2

    result = relay_to_channels(title="t", message="m", category="info")

    ch1.send.assert_called_once_with(title="t", message="m", category="info", data=None)
    ch2.send.assert_called_once_with(title="t", message="m", category="info", data=None)
    assert set(result["sent"]) == {"ch1", "ch2"}
    assert result["failed"] == []


@patch("fastpluggy_plugin.notification_center.config.NotificationCenterSettings")
def test_relay_to_channels_filtered(mock_settings_cls):
    """Only the explicitly requested channel is called."""
    mock_settings_cls.return_value = MagicMock(relay_channels=[])

    ch1 = _make_mock_channel("ch1")
    ch2 = _make_mock_channel("ch2")
    _channels["ch1"] = ch1
    _channels["ch2"] = ch2

    result = relay_to_channels(title="t", message="m", category="info", channels=["ch1"])

    ch1.send.assert_called_once()
    ch2.send.assert_not_called()
    assert result["sent"] == ["ch1"]
    assert result["failed"] == []


@patch("fastpluggy_plugin.notification_center.config.NotificationCenterSettings")
def test_relay_to_channels_error_handling(mock_settings_cls):
    """A failing channel doesn't prevent delivery to other channels."""
    mock_settings_cls.return_value = MagicMock(relay_channels=[])

    ch1 = _make_mock_channel("ch1", side_effect=RuntimeError("boom"))
    ch2 = _make_mock_channel("ch2")
    _channels["ch1"] = ch1
    _channels["ch2"] = ch2

    result = relay_to_channels(title="t", message="m", category="error")

    ch2.send.assert_called_once()
    assert "ch1" in result["failed"]
    assert "ch2" in result["sent"]


@patch("fastpluggy_plugin.notification_center.config.NotificationCenterSettings")
def test_relay_respects_config_channels(mock_settings_cls):
    """When settings.relay_channels is set, only those channels are used (no explicit arg)."""
    mock_settings_cls.return_value = MagicMock(relay_channels=["ch1"])

    ch1 = _make_mock_channel("ch1")
    ch2 = _make_mock_channel("ch2")
    _channels["ch1"] = ch1
    _channels["ch2"] = ch2

    result = relay_to_channels(title="t", message="m", category="info")

    ch1.send.assert_called_once()
    ch2.send.assert_not_called()
    assert result["sent"] == ["ch1"]


@patch("fastpluggy_plugin.notification_center.config.NotificationCenterSettings")
def test_relay_explicit_channels_override_config(mock_settings_cls):
    """Explicit channels= arg takes precedence over settings.relay_channels."""
    mock_settings_cls.return_value = MagicMock(relay_channels=["ch1"])

    ch1 = _make_mock_channel("ch1")
    ch2 = _make_mock_channel("ch2")
    _channels["ch1"] = ch1
    _channels["ch2"] = ch2

    result = relay_to_channels(title="t", message="m", category="info", channels=["ch2"])

    ch1.send.assert_not_called()
    ch2.send.assert_called_once()
    assert result["sent"] == ["ch2"]


# --- get_channels ---

def test_get_channels_returns_copy():
    """get_channels() returns a copy, not the internal dict."""
    ch = _make_mock_channel("ch1")
    _channels["ch1"] = ch

    result = get_channels()
    assert result == {"ch1": ch}

    # Mutating the copy should not affect the internal registry
    result["ch1"] = None
    assert _channels["ch1"] is ch
