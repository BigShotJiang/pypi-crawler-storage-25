import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from unittest.mock import patch

from sqlalchemy.orm import sessionmaker

from fastpluggy.core.database import Base
from fastpluggy_plugin.notification_center.routers import notification_router
from fastpluggy_plugin.notification_center.repository import create_notification, mark_read

from db_helpers import create_test_engine, make_test_session_scope


# ---------------------------------------------------------------------------
# Fixtures — override conftest test_db to also patch routers.api.session_scope,
# since api.py imports session_scope directly for inline queries.
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def test_db():
    """Patch session_scope in both repository and routers.api modules
    with the same in-memory DB."""
    engine = create_test_engine()
    Base.metadata.create_all(engine)
    TestSession = sessionmaker(bind=engine, expire_on_commit=False)
    mock_scope = make_test_session_scope(TestSession)

    with (
        patch(
            "fastpluggy_plugin.notification_center.repository.session_scope",
            mock_scope,
        ),
        patch(
            "fastpluggy_plugin.notification_center.routers.api.session_scope",
            mock_scope,
        ),
    ):
        yield engine

    Base.metadata.drop_all(engine)


# ---------------------------------------------------------------------------
# TestClient wired to the notification router
# ---------------------------------------------------------------------------

app = FastAPI()
app.include_router(notification_router)
client = TestClient(app)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_create_notification():
    """POST /api/notifications with full body returns all fields."""
    resp = client.post(
        "/api/notifications",
        json={
            "title": "Deploy finished",
            "message": "v2.3.0 deployed to production",
            "category": "success",
            "source": "ci_pipeline",
            "data": {"pipeline_id": 42},
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["title"] == "Deploy finished"
    assert body["message"] == "v2.3.0 deployed to production"
    assert body["category"] == "success"
    assert body["source"] == "ci_pipeline"
    assert body["read"] is False
    assert body["read_at"] is None
    assert body["data"] == {"pipeline_id": 42}
    assert body["id"] is not None
    assert body["created_at"] is not None


def test_create_notification_minimal():
    """POST with only title+message uses default category and null optionals."""
    resp = client.post(
        "/api/notifications",
        json={"title": "Hello", "message": "World"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["title"] == "Hello"
    assert body["message"] == "World"
    assert body["category"] == "info"
    assert body["source"] is None
    assert body["data"] is None
    assert body["read"] is False


def test_create_notification_invalid():
    """POST with missing required fields returns 422."""
    # Missing both title and message
    resp = client.post("/api/notifications", json={})
    assert resp.status_code == 422

    # Missing message
    resp = client.post("/api/notifications", json={"title": "Only title"})
    assert resp.status_code == 422

    # Missing title
    resp = client.post("/api/notifications", json={"message": "Only message"})
    assert resp.status_code == 422


def test_list_notifications():
    """Create 3 notifications, GET /api/notifications, verify count and newest-first order."""
    for label in ("First", "Second", "Third"):
        create_notification(title=label, message=f"msg {label}")

    resp = client.get("/api/notifications")
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 3
    assert len(body["notifications"]) == 3
    # Newest first (highest ID = last created)
    assert body["notifications"][0]["title"] == "Third"
    assert body["notifications"][-1]["title"] == "First"


def test_list_notifications_filter_read():
    """Create 3, mark 1 read, filter with ?read=false returns only unread."""
    n1 = create_notification(title="A", message="a")
    create_notification(title="B", message="b")
    create_notification(title="C", message="c")
    mark_read(n1.id)

    resp = client.get("/api/notifications", params={"read": "false"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 2
    assert len(body["notifications"]) == 2
    titles = {n["title"] for n in body["notifications"]}
    assert titles == {"B", "C"}

    # Also verify read=true filter
    resp = client.get("/api/notifications", params={"read": "true"})
    body = resp.json()
    assert body["total"] == 1
    assert body["notifications"][0]["title"] == "A"


def test_list_notifications_pagination():
    """Create 5, GET with ?limit=2&offset=1, verify correct slice."""
    for i in range(5):
        create_notification(title=f"Item {i}", message=f"msg {i}")

    resp = client.get("/api/notifications", params={"limit": 2, "offset": 1})
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 5  # total is unaffected by pagination
    assert len(body["notifications"]) == 2
    # Ordered newest first: Item 4, 3, 2, 1, 0 — offset=1 skips Item 4
    assert body["notifications"][0]["title"] == "Item 3"
    assert body["notifications"][1]["title"] == "Item 2"


def test_get_unread_count():
    """Create 3, mark 1 read, GET /api/unread-count returns 2."""
    n1 = create_notification(title="A", message="a")
    create_notification(title="B", message="b")
    create_notification(title="C", message="c")
    mark_read(n1.id)

    resp = client.get("/api/unread-count")
    assert resp.status_code == 200
    assert resp.json() == {"count": 2}


def test_mark_read():
    """POST /api/notifications/{id}/read marks it read."""
    n = create_notification(title="Unread", message="will be read")

    resp = client.post(f"/api/notifications/{n.id}/read")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}

    # Verify via list endpoint
    list_resp = client.get("/api/notifications", params={"read": "true"})
    body = list_resp.json()
    assert body["total"] == 1
    assert body["notifications"][0]["read"] is True
    assert body["notifications"][0]["read_at"] is not None


def test_mark_read_not_found():
    """POST mark read on non-existent id returns 404."""
    resp = client.post("/api/notifications/99999/read")
    assert resp.status_code == 404
    assert resp.json()["detail"] == "Notification not found"


def test_mark_all_read():
    """Create 3, POST /api/notifications/read-all, verify all marked."""
    create_notification(title="A", message="a")
    create_notification(title="B", message="b")
    create_notification(title="C", message="c")

    resp = client.post("/api/notifications/read-all")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["count"] == 3

    # Verify unread count is now 0
    count_resp = client.get("/api/unread-count")
    assert count_resp.json()["count"] == 0


def test_delete_notification():
    """Create a notification, DELETE it, verify it is gone."""
    n = create_notification(title="Doomed", message="bye")

    resp = client.delete(f"/api/notifications/{n.id}")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}

    # Verify it's gone
    list_resp = client.get("/api/notifications")
    assert list_resp.json()["total"] == 0


def test_delete_not_found():
    """DELETE non-existent notification returns 404."""
    resp = client.delete("/api/notifications/99999")
    assert resp.status_code == 404
    assert resp.json()["detail"] == "Notification not found"
