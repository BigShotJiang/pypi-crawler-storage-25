def route() -> str:
    return "/"
