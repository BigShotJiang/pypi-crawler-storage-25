from unittest.mock import MagicMock, patch

import pytest

from primitive.monitor.actions import Monitor


class TestMonitorInitialCheckIn:
    def _make_monitor(self):
        mon = Monitor.__new__(Monitor)
        mon.primitive = MagicMock()
        mon.primitive.DEBUG = False
        return mon

    @patch("primitive.monitor.actions.sleep")
    def test_initial_checkin_exits_on_failure(self, mock_sleep):
        """Initial check-in exits with code 1 when it fails."""
        mon = self._make_monitor()
        mon.primitive.hardware.check_in.side_effect = ConnectionError("fail")

        with pytest.raises(SystemExit) as exc_info:
            mon.start()

        assert exc_info.value.code == 1
        assert mon.primitive.hardware.check_in.call_count == 1

    @patch("primitive.monitor.actions.sleep")
    def test_initial_checkin_succeeds(self, mock_sleep):
        """Monitor proceeds to main loop after successful check-in."""
        mon = self._make_monitor()
        mon.primitive.hardware.check_in.return_value = None

        # After initial check-in succeeds, the main loop starts.
        # Make get_own_hardware_details raise KeyboardInterrupt to exit.
        mon.primitive.hardware.get_own_hardware_details.side_effect = KeyboardInterrupt

        with pytest.raises(SystemExit):
            mon.start()

        # 1 for initial check-in, 1 for shutdown
        assert mon.primitive.hardware.check_in.call_count == 2


class TestMonitorLoopResilience:
    def _make_monitor(self):
        mon = Monitor.__new__(Monitor)
        mon.primitive = MagicMock()
        mon.primitive.DEBUG = False
        return mon

    @patch("primitive.monitor.actions.sleep")
    def test_loop_continues_after_exception(self, mock_sleep):
        """Main loop catches exceptions and continues instead of crashing."""
        mon = self._make_monitor()

        # First iteration: raise an error
        # Second iteration: raise KeyboardInterrupt to stop the loop
        call_count = 0

        def side_effect():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("transient error")
            raise KeyboardInterrupt

        mon.primitive.hardware.check_in.return_value = None
        mon.primitive.hardware.get_own_hardware_details.side_effect = side_effect

        with pytest.raises(SystemExit):
            mon.start()

        # Should have been called twice (error + interrupt)
        assert call_count == 2
