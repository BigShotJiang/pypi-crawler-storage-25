import configparser
import subprocess
from unittest.mock import patch

from primitive.daemons.launch_service import LaunchService


class TestSystemdServiceHardening:
    def test_populate_includes_restart_sec(self):
        """Generated systemd service includes RestartSec=10."""
        svc = LaunchService(label="tech.primitive.monitor", command="monitor start")
        svc.executable = "/usr/bin/primitive"

        with patch.object(svc, "verify", return_value=True):
            svc.populate()

        config = configparser.ConfigParser()
        config.optionxform = str  # type: ignore
        config.read(svc.file_path)

        assert config["Service"]["RestartSec"] == "10"

    def test_populate_includes_start_limit(self):
        """Generated systemd service includes StartLimitIntervalSec and StartLimitBurst."""
        svc = LaunchService(label="tech.primitive.monitor", command="monitor start")
        svc.executable = "/usr/bin/primitive"

        with patch.object(svc, "verify", return_value=True):
            svc.populate()

        config = configparser.ConfigParser()
        config.optionxform = str  # type: ignore
        config.read(svc.file_path)

        assert config["Unit"]["StartLimitIntervalSec"] == "300"
        assert config["Unit"]["StartLimitBurst"] == "10"

    def test_populate_still_has_restart_always(self):
        """Generated systemd service still has Restart=always."""
        svc = LaunchService(label="tech.primitive.monitor", command="monitor start")
        svc.executable = "/usr/bin/primitive"

        with patch.object(svc, "verify", return_value=True):
            svc.populate()

        config = configparser.ConfigParser()
        config.optionxform = str  # type: ignore
        config.read(svc.file_path)

        assert config["Service"]["Restart"] == "always"


class TestLoginctlLinger:
    @patch("primitive.daemons.launch_service.subprocess.check_output")
    def test_install_enables_linger_for_non_root(self, mock_check_output):
        """install() calls loginctl enable-linger for non-root users."""
        svc = LaunchService(
            label="tech.primitive.monitor", command="monitor start", root_user=False
        )

        with (
            patch.object(svc, "stop", return_value=True),
            patch.object(svc, "disable", return_value=True),
            patch.object(svc, "create_stdout_file", return_value=True),
            patch.object(svc, "populate", return_value=True),
            patch.object(svc, "enable", return_value=True),
            patch.object(svc, "start", return_value=True),
            patch.dict("os.environ", {"USER": "testuser"}),
        ):
            svc.install()

        # First call should be loginctl enable-linger
        mock_check_output.assert_any_call(
            ["loginctl", "enable-linger", "testuser"],
            stderr=subprocess.DEVNULL,
        )

    @patch("primitive.daemons.launch_service.subprocess.check_output")
    def test_install_skips_linger_for_root(self, mock_check_output):
        """install() does not call loginctl enable-linger for root users."""
        svc = LaunchService(
            label="tech.primitive.monitor", command="monitor start", root_user=True
        )

        with (
            patch.object(svc, "stop", return_value=True),
            patch.object(svc, "disable", return_value=True),
            patch.object(svc, "create_stdout_file", return_value=True),
            patch.object(svc, "populate", return_value=True),
            patch.object(svc, "enable", return_value=True),
            patch.object(svc, "start", return_value=True),
        ):
            svc.install()

        # loginctl should not be called at all
        for call in mock_check_output.call_args_list:
            assert "loginctl" not in call[0][0]

    @patch("primitive.daemons.launch_service.subprocess.check_output")
    def test_install_continues_if_linger_fails(self, mock_check_output):
        """install() continues even if loginctl enable-linger fails."""
        import subprocess

        mock_check_output.side_effect = [
            subprocess.CalledProcessError(1, "loginctl"),  # linger fails
        ]

        svc = LaunchService(
            label="tech.primitive.monitor", command="monitor start", root_user=False
        )

        with (
            patch.object(svc, "stop", return_value=True),
            patch.object(svc, "disable", return_value=True),
            patch.object(svc, "create_stdout_file", return_value=True),
            patch.object(svc, "populate", return_value=True),
            patch.object(svc, "enable", return_value=True),
            patch.object(svc, "start", return_value=True),
        ):
            result = svc.install()

        assert result is True
