import socket
import ssl
from unittest.mock import MagicMock, patch

import pika.exceptions

from primitive.messaging.actions import (
    MAX_MESSAGING_BACKOFF_TIME,
    TRANSIENT_CONNECTION_ERRORS,
    Messaging,
)


class TestTransientConnectionErrors:
    def test_includes_dns_errors(self):
        assert socket.gaierror in TRANSIENT_CONNECTION_ERRORS

    def test_includes_ssl_errors(self):
        assert ssl.SSLError in TRANSIENT_CONNECTION_ERRORS

    def test_includes_connection_errors(self):
        assert ConnectionResetError in TRANSIENT_CONNECTION_ERRORS
        assert ConnectionRefusedError in TRANSIENT_CONNECTION_ERRORS

    def test_includes_amqp_connection_error(self):
        assert pika.exceptions.AMQPConnectionError in TRANSIENT_CONNECTION_ERRORS

    def test_includes_os_error(self):
        assert OSError in TRANSIENT_CONNECTION_ERRORS


class TestMaxBackoffTime:
    def test_backoff_time_is_five_minutes(self):
        assert MAX_MESSAGING_BACKOFF_TIME == 300


class TestSendMessageRetries:
    @patch("primitive.messaging.actions.pika.BlockingConnection")
    def test_send_message_succeeds_on_first_try(self, mock_conn_cls):
        """send_message publishes when connection succeeds immediately."""
        mock_conn = MagicMock()
        mock_channel = MagicMock()
        mock_conn.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn.__exit__ = MagicMock(return_value=False)
        mock_conn.channel.return_value = mock_channel
        mock_conn_cls.return_value = mock_conn

        messaging = Messaging.__new__(Messaging)
        messaging.ready = True
        messaging.fingerprint = "test-fingerprint"
        messaging.token = "test-token"
        messaging.common_name = "test-cn"
        messaging.parameters = MagicMock()

        from primitive.messaging.actions import MESSAGE_TYPES

        messaging.send_message(
            message_type=MESSAGE_TYPES.CHECK_IN,
            message={"is_healthy": True},
        )

        mock_channel.basic_publish.assert_called_once()

    @patch("primitive.messaging.actions.pika.BlockingConnection")
    def test_send_message_retries_on_transient_error(self, mock_conn_cls):
        """send_message retries on transient errors and succeeds."""
        mock_conn = MagicMock()
        mock_channel = MagicMock()
        mock_conn.__enter__ = MagicMock(return_value=mock_conn)
        mock_conn.__exit__ = MagicMock(return_value=False)
        mock_conn.channel.return_value = mock_channel

        # Fail twice, then succeed
        mock_conn_cls.side_effect = [
            ConnectionRefusedError("refused"),
            socket.gaierror("DNS fail"),
            mock_conn,
        ]

        messaging = Messaging.__new__(Messaging)
        messaging.ready = True
        messaging.fingerprint = "test-fingerprint"
        messaging.token = "test-token"
        messaging.common_name = "test-cn"
        messaging.parameters = MagicMock()

        from primitive.messaging.actions import MESSAGE_TYPES

        messaging.send_message(
            message_type=MESSAGE_TYPES.CHECK_IN,
            message={"is_healthy": True},
        )

        assert mock_conn_cls.call_count == 3
        mock_channel.basic_publish.assert_called_once()

    def test_send_message_skips_when_not_ready(self):
        """send_message returns early when not ready."""
        messaging = Messaging.__new__(Messaging)
        messaging.ready = False

        from primitive.messaging.actions import MESSAGE_TYPES

        # Should not raise
        messaging.send_message(
            message_type=MESSAGE_TYPES.CHECK_IN,
            message={"is_healthy": True},
        )
