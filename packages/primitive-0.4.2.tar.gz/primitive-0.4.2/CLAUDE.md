# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

primitive-cli is a Python CLI tool (`primitive`) for interacting with the Primitive hardware management platform (https://primitive.tech). Published to PyPI as `primitive`. Entry point: `primitive = "primitive.cli:cli"`.

## Build & Development Commands

```bash
make setup                                 # install git hooks + uv sync
uv sync                                    # install dependencies
uv run ruff check                          # lint
uv run ruff format                         # format
uv run ruff check --fix --unsafe-fixes     # auto-fix lint issues
uv run pyright                             # type check
pytest tests/                              # run tests
hatch build                                # build package
```

The Makefile uses fish shell. CI runs both `ruff check` and `pyright` on all PRs.

## Architecture

### CLI Layer (`src/primitive/cli.py`)
Click-based CLI with a root group and subcommands. Global options: `--host`, `--yes`, `--debug`, `--json`, `-v/--verbose`. Creates a `Primitive` client instance stored in Click context (`context.obj["PRIMITIVE"]`).

### Client Layer (`src/primitive/client.py`)
`Primitive` class is the central orchestrator. Initializes all module action classes and manages host/token/transport configuration from `~/.config/primitive/credentials.json` or environment variables (`PRIMITIVE_HOST`, `PRIMITIVE_TOKEN`, `PRIMITIVE_TRANSPORT`).

### Module Pattern
Each module in `src/primitive/<module>/` follows a consistent structure:
- `commands.py` — Click commands (CLI interface), accesses `Primitive` client via `@click.pass_context`
- `actions.py` — Business logic class extending `BaseAction` (`utils/actions.py`), holds reference to `Primitive` client via `self.primitive`
- `graphql/` — GraphQL queries, mutations, and fragments (where applicable)
- `ui.py` — Rich table rendering (where applicable)

### Key Utilities
- `utils/auth.py`: `@guard` decorator wraps API calls with backoff retry logic and lazy GraphQL session creation
- `graphql/sdk.py`: `create_session()` for GraphQL client setup; `handle_mutation_response()` for standardized error handling
- GraphQL uses Relay-style IDs (base64 encoded `TypeName:NodeID`)

### API Communication
- **GraphQL** via `gql` with aiohttp transport — primary API interface
- **REST** via `requests.Session` — file uploads
- **RabbitMQ/AMQP** via `pika` — messaging (hardware check-ins, events, metrics)
- **Redfish** — BMC/out-of-band hardware management

### Long-Running Daemons
- **Agent** (`agent/`): Polls for pending job runs, downloads source code, executes tasks, uploads artifacts
- **Monitor** (`monitor/`): Hardware check-in, system info pushing, GPU health monitoring, reservation provisioning
- Platform support: macOS (LaunchAgent) and Linux (systemd) for daemon management

## Code Style
- Formatter/Linter: ruff with default config (no ruff.toml)
- Type checker: pyright targeting Python 3.13, Linux platform
- Logging: loguru with Rich handler (configured in `client.py`)
- Python requirement: >=3.11

## Release Process
```bash
make release              # patch bump (0.2.x → 0.2.x+1)
make release BUMP=minor   # minor bump (0.x.y → 0.x+1.0)
make release BUMP=major   # major bump (x.y.z → x+1.0.0)
git push                  # push to main to trigger CI
```
CI automatically detects the version bump, creates a git tag, GitHub Release, and publishes to PyPI via trusted publishing.


## Verification
- Install: uv sync
- Format: uv run ruff format
- Lint: uv run ruff check
- Test: pytest tests/
