import json
import sys
import time
import threading
from datetime import timezone
from functools import wraps

from loguru import logger


def log_context(**context):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            with logger.contextualize(**context):
                return func(*args, **kwargs)

        return wrapper

    return decorator


def fmt(record) -> str:
    extra = record["extra"]
    label = extra.get("label", None)
    tag = extra.get("tag", None)
    type = extra.get("type", "system")

    context_object = {
        "label": label,
        "type": type,
        "utc": record["time"]
        .astimezone(timezone.utc)
        .strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
        "level": record["level"].name,
        "name": record["name"],
        "function": record["function"],
        "line": record["line"],
        "message": record["message"],
    }

    if tag:
        context_object["tag"] = tag

    # Loguru will fail if you return a string that doesn't select
    # something within its record
    record["extra"]["serialized"] = json.dumps(context_object)
    return "{extra[serialized]}\n"


class BatchedSink:
    def __init__(self, send, max_ms=250, max_kb=500):
        self.send = send
        self.max_s = max_ms / 1000
        self.max_bytes = max_kb * 1024

        self.batch = []
        self.bytes = 0
        self.last = time.monotonic()

        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._timer, daemon=True)
        self._thread.start()

    def _take_batch(self):
        """Caller must hold self._lock."""
        if not self.batch:
            return None

        batch = self.batch
        self.batch = []
        self.bytes = 0
        self.last = time.monotonic()
        return batch

    def _send_batch(self, batch, on_fail_requeue=True):
        try:
            self.send(batch)
        except Exception as exception:
            if len(batch) == 1:
                print(
                    f"BatchedSink failed to send 1 message, dropping: {exception}",
                    file=sys.stderr,
                )
                return

            print(
                f"BatchedSink send failed for {len(batch)} messages, splitting and retrying: {exception}",
                file=sys.stderr,
            )
            mid = len(batch) // 2
            self._send_batch(batch[:mid], on_fail_requeue=on_fail_requeue)
            self._send_batch(batch[mid:], on_fail_requeue=on_fail_requeue)

    def __call__(self, message):
        msg = str(message)
        batch = None

        with self._lock:
            self.batch.append(msg)
            self.bytes += len(msg)

            if self.bytes >= self.max_bytes:
                batch = self._take_batch()

        if batch:
            self._send_batch(batch)

    def _timer(self):
        while not self._stop.wait(self.max_s / 2):
            batch = None
            with self._lock:
                if self.batch and time.monotonic() - self.last >= self.max_s:
                    batch = self._take_batch()

            if batch:
                self._send_batch(batch)

    def stop(self):
        self._stop.set()

        self._thread.join(timeout=1)
        if self._thread.is_alive():
            print(
                "BatchedSink background thread did not stop in time.",
                file=sys.stderr,
            )

        batch = None
        with self._lock:
            batch = self._take_batch()
        if batch:
            self._send_batch(batch, on_fail_requeue=False)
