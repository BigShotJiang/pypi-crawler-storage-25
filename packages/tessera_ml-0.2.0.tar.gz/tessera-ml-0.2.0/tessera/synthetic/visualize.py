"""
TESSERA Synthetic Data Visualization

Diagnostic plots for inspecting landscapes and datasets.
Uses PCA/UMAP for dimensionality reduction to 2D.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch
from sklearn.decomposition import PCA
from typing import Optional, Tuple

from .landscape import Landscape
from .outcomes import TesseraDataset


# Consistent color scheme
DOMAIN_CMAP = plt.cm.Set2
OUTCOME_COLORS = {"success": "#2ecc71", "failure": "#e74c3c"}
PATTERN_COLORS = {
    "ecotone": "#e67e22",
    "isolated": "#9b59b6",
    "diffuse": "#3498db",
    "success": "#2ecc71",
}


def _reduce_2d(
    features: np.ndarray, method: str = "pca"
) -> Tuple[np.ndarray, object]:
    """Reduce features to 2D for visualization."""
    if method == "pca":
        reducer = PCA(n_components=2)
        coords_2d = reducer.fit_transform(features)
        return coords_2d, reducer
    else:
        raise ValueError(f"Unknown reduction method: {method}")


def plot_landscape(
    landscape: Landscape,
    method: str = "pca",
    ax: Optional[plt.Axes] = None,
    figsize: Tuple[float, float] = (10, 8),
    alpha: float = 0.4,
    s: float = 8,
    title: Optional[str] = None,
) -> plt.Figure:
    """
    Plot landscape topology colored by domain assignment.

    Parameters
    ----------
    landscape : Landscape
        The landscape to visualize.
    method : str
        Dimensionality reduction method ("pca").
    ax : matplotlib Axes, optional
        Axes to plot on. Creates new figure if None.
    figsize : tuple
        Figure size.
    alpha : float
        Point transparency.
    s : float
        Point size.
    title : str, optional
        Plot title.
    """
    if ax is None:
        fig, ax = plt.subplots(1, 1, figsize=figsize)
    else:
        fig = ax.figure

    coords, reducer = _reduce_2d(landscape.features, method)

    n_domains = landscape.n_domains
    colors = [DOMAIN_CMAP(i / max(n_domains - 1, 1)) for i in range(n_domains)]

    for k in range(n_domains):
        mask = landscape.domain_mask(k)
        ax.scatter(
            coords[mask, 0],
            coords[mask, 1],
            c=[colors[k]],
            label=f"Domain {k} (n={mask.sum()})",
            alpha=alpha,
            s=s,
            edgecolors="none",
        )

    # Plot centroids projected to 2D
    centroids_2d = reducer.transform(landscape.centroids)
    for k in range(n_domains):
        ax.scatter(
            centroids_2d[k, 0],
            centroids_2d[k, 1],
            c=[colors[k]],
            marker="*",
            s=200,
            edgecolors="black",
            linewidths=1,
            zorder=5,
        )

    ax.set_xlabel(f"PC1 ({reducer.explained_variance_ratio_[0]:.1%} var)")
    ax.set_ylabel(f"PC2 ({reducer.explained_variance_ratio_[1]:.1%} var)")
    ax.set_title(title or "Landscape Topology (PCA)")
    ax.legend(loc="best", framealpha=0.8, fontsize=9)

    fig.tight_layout()
    return fig


def plot_dataset(
    dataset: TesseraDataset,
    color_by: str = "outcome",
    method: str = "pca",
    ax: Optional[plt.Axes] = None,
    figsize: Tuple[float, float] = (10, 8),
    alpha: float = 0.5,
    s: float = 10,
    title: Optional[str] = None,
) -> plt.Figure:
    """
    Plot dataset colored by outcome or failure pattern.

    Parameters
    ----------
    dataset : TesseraDataset
        The dataset to visualize.
    color_by : str
        "outcome" (success/failure) or "pattern" (ecotone/isolated/diffuse).
    method : str
        Dimensionality reduction method.
    """
    if ax is None:
        fig, ax = plt.subplots(1, 1, figsize=figsize)
    else:
        fig = ax.figure

    coords, reducer = _reduce_2d(dataset.features, method)

    if color_by == "outcome":
        # Plot successes first (background), then failures (foreground)
        success_mask = dataset.outcomes == 0
        fail_mask = dataset.outcomes == 1

        ax.scatter(
            coords[success_mask, 0],
            coords[success_mask, 1],
            c=OUTCOME_COLORS["success"],
            label=f"Success (n={success_mask.sum()})",
            alpha=alpha * 0.6,
            s=s,
            edgecolors="none",
        )
        ax.scatter(
            coords[fail_mask, 0],
            coords[fail_mask, 1],
            c=OUTCOME_COLORS["failure"],
            label=f"Failure (n={fail_mask.sum()})",
            alpha=alpha,
            s=s * 1.5,
            edgecolors="none",
            zorder=3,
        )

    elif color_by == "pattern":
        # Plot by failure pattern type
        for pattern, color in PATTERN_COLORS.items():
            mask = dataset.pattern_labels == pattern
            if not mask.any():
                continue
            ax.scatter(
                coords[mask, 0],
                coords[mask, 1],
                c=color,
                label=f"{pattern.capitalize()} (n={mask.sum()})",
                alpha=alpha if pattern != "success" else alpha * 0.4,
                s=s * 1.5 if pattern != "success" else s,
                edgecolors="none",
                zorder=3 if pattern != "success" else 1,
            )

    else:
        raise ValueError(f"color_by must be 'outcome' or 'pattern', "
                         f"got '{color_by}'")

    ax.set_xlabel(f"PC1 ({reducer.explained_variance_ratio_[0]:.1%} var)")
    ax.set_ylabel(f"PC2 ({reducer.explained_variance_ratio_[1]:.1%} var)")
    ax.set_title(title or f"TESSERA Dataset ({color_by})")
    ax.legend(loc="best", framealpha=0.8, fontsize=9)

    fig.tight_layout()
    return fig


def plot_ecotone_heatmap(
    dataset: TesseraDataset,
    method: str = "pca",
    figsize: Tuple[float, float] = (10, 8),
    title: Optional[str] = None,
) -> plt.Figure:
    """
    Heatmap of ecotone scores projected to 2D.

    Highlights the transition zones between domains.
    """
    fig, ax = plt.subplots(1, 1, figsize=figsize)

    coords, reducer = _reduce_2d(dataset.features, method)
    scores = dataset.ecotone_scores

    scatter = ax.scatter(
        coords[:, 0],
        coords[:, 1],
        c=scores,
        cmap="YlOrRd",
        alpha=0.5,
        s=8,
        edgecolors="none",
    )

    # Overlay failures
    fail_mask = dataset.outcomes == 1
    ax.scatter(
        coords[fail_mask, 0],
        coords[fail_mask, 1],
        c="none",
        edgecolors="black",
        linewidths=0.5,
        s=15,
        alpha=0.7,
        zorder=4,
        label=f"Failures (n={fail_mask.sum()})",
    )

    plt.colorbar(scatter, ax=ax, label="Boundary Score", shrink=0.8)
    ax.set_xlabel(f"PC1 ({reducer.explained_variance_ratio_[0]:.1%} var)")
    ax.set_ylabel(f"PC2 ({reducer.explained_variance_ratio_[1]:.1%} var)")
    ax.set_title(title or "Boundary Score Heatmap")
    ax.legend(loc="best", framealpha=0.8, fontsize=9)

    fig.tight_layout()
    return fig


def plot_diagnostic_panel(
    dataset: TesseraDataset,
    method: str = "pca",
    figsize: Tuple[float, float] = (18, 12),
    suptitle: Optional[str] = None,
) -> plt.Figure:
    """
    Four-panel diagnostic plot:
    1. Domain topology
    2. Outcomes (success/failure)
    3. Failure patterns (ecotone/isolated/diffuse)
    4. Boundary score heatmap
    """
    fig, axes = plt.subplots(2, 2, figsize=figsize)

    coords, reducer = _reduce_2d(dataset.features, method)

    # Panel 1: Domains
    ax = axes[0, 0]
    n_domains = len(np.unique(dataset.domain_labels))
    colors = [DOMAIN_CMAP(i / max(n_domains - 1, 1)) for i in range(n_domains)]

    for k in range(n_domains):
        mask = dataset.domain_labels == k
        ax.scatter(
            coords[mask, 0], coords[mask, 1],
            c=[colors[k]], label=f"Domain {k}",
            alpha=0.3, s=6, edgecolors="none",
        )
    ax.set_title("Domain Topology")
    ax.legend(loc="best", fontsize=8, framealpha=0.8)

    # Panel 2: Outcomes
    ax = axes[0, 1]
    success_mask = dataset.outcomes == 0
    fail_mask = dataset.outcomes == 1

    ax.scatter(
        coords[success_mask, 0], coords[success_mask, 1],
        c=OUTCOME_COLORS["success"], alpha=0.2, s=5, edgecolors="none",
    )
    ax.scatter(
        coords[fail_mask, 0], coords[fail_mask, 1],
        c=OUTCOME_COLORS["failure"], alpha=0.6, s=10, edgecolors="none",
        zorder=3,
    )
    ax.set_title(
        f"Outcomes ({dataset.n_failures} failures / "
        f"{dataset.n_entities} total)"
    )

    # Panel 3: Pattern labels
    ax = axes[1, 0]
    for pattern, color in PATTERN_COLORS.items():
        mask = dataset.pattern_labels == pattern
        if not mask.any():
            continue
        ax.scatter(
            coords[mask, 0], coords[mask, 1],
            c=color, label=pattern.capitalize(),
            alpha=0.4 if pattern != "success" else 0.15,
            s=8 if pattern != "success" else 4,
            edgecolors="none",
            zorder=3 if pattern != "success" else 1,
        )
    ax.set_title("Failure Patterns")
    ax.legend(loc="best", fontsize=8, framealpha=0.8)

    # Panel 4: Boundary heatmap
    ax = axes[1, 1]
    scatter = ax.scatter(
        coords[:, 0], coords[:, 1],
        c=dataset.ecotone_scores, cmap="YlOrRd",
        alpha=0.4, s=6, edgecolors="none",
    )
    ax.scatter(
        coords[fail_mask, 0], coords[fail_mask, 1],
        c="none", edgecolors="black", linewidths=0.4, s=10,
        alpha=0.5, zorder=4,
    )
    plt.colorbar(scatter, ax=ax, label="Boundary Score", shrink=0.8)
    ax.set_title("Boundary Scores + Failures")

    # Common formatting
    for ax in axes.flat:
        ax.set_xlabel(f"PC1 ({reducer.explained_variance_ratio_[0]:.1%})")
        ax.set_ylabel(f"PC2 ({reducer.explained_variance_ratio_[1]:.1%})")

    fig.suptitle(
        suptitle or "TESSERA Diagnostic Panel",
        fontsize=14, fontweight="bold", y=1.01,
    )
    fig.tight_layout()
    return fig
