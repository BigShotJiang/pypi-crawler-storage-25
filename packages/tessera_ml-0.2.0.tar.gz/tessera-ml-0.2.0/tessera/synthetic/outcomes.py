"""
TESSERA Outcome Assigner

Assigns binary outcomes to entities in a Landscape according to
controllable geometric failure patterns:
  - boundary-concentrated: failures at domain boundaries
  - isolated: failures in a distinct region
  - diffuse: failures scattered by feature thresholds

Also supports mixed patterns with configurable weights.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Tuple
import json
import warnings

from .landscape import Landscape


@dataclass
class TesseraDataset:
    """
    Complete TESSERA synthetic dataset.

    Contains feature matrix, outcomes, domain labels, failure pattern
    ground truth, temporal windows, and full provenance metadata.
    """
    features: np.ndarray              # (N, D) feature matrix
    outcomes: np.ndarray              # (N,) binary 0/1
    domain_labels: np.ndarray         # (N,) integer domain assignment
    pattern_labels: np.ndarray        # (N,) str pattern that caused failure
    time_windows: np.ndarray          # (N,) integer time window
    ecotone_scores: np.ndarray        # (N,) boundary proximity score
    failure_probabilities: np.ndarray # (N,) P(failure) before thresholding
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def n_entities(self) -> int:
        return self.features.shape[0]

    @property
    def n_dimensions(self) -> int:
        return self.features.shape[1]

    @property
    def failure_rate(self) -> float:
        return self.outcomes.mean()

    @property
    def n_failures(self) -> int:
        return int(self.outcomes.sum())

    def pattern_distribution(self) -> Dict[str, int]:
        """Count of failures by pattern type."""
        unique, counts = np.unique(
            self.pattern_labels[self.outcomes == 1], return_counts=True
        )
        return dict(zip(unique, counts.astype(int)))

    def verify_pattern(self, verbose: bool = True) -> Dict[str, Any]:
        """
        Verify that intended failure patterns manifested in the data.

        Returns diagnostics including:
        - Boundary concentration: are boundary-labeled failures actually
          at domain boundaries?
        - Isolation separation: are isolated-cluster failures actually
          distant from main domains?
        - Diffuse spread: are diffuse failures actually distributed
          across domains?
        """
        results = {}

        fail_mask = self.outcomes == 1
        success_mask = self.outcomes == 0

        # Overall metrics
        results["n_entities"] = self.n_entities
        results["n_failures"] = self.n_failures
        results["failure_rate"] = float(self.failure_rate)
        results["pattern_distribution"] = self.pattern_distribution()

        # Ecotone verification: failures labeled ecotone should have
        # higher ecotone scores than other failures
        eco_mask = (self.pattern_labels == "ecotone") & fail_mask
        non_eco_fail = fail_mask & (self.pattern_labels != "ecotone")

        if eco_mask.any():
            eco_scores = self.ecotone_scores[eco_mask]
            results["boundary_verification"] = {
                "mean_boundary_score_boundary_failures": float(
                    eco_scores.mean()
                ),
                "mean_boundary_score_other_failures": float(
                    self.ecotone_scores[non_eco_fail].mean()
                ) if non_eco_fail.any() else None,
                "mean_boundary_score_successes": float(
                    self.ecotone_scores[success_mask].mean()
                ) if success_mask.any() else None,
                "verified": bool(
                    eco_scores.mean() > self.ecotone_scores[success_mask].mean()
                ) if success_mask.any() else None,
            }

        # Isolated verification: isolated failures should be far from
        # all main domain centroids
        iso_mask = (self.pattern_labels == "isolated") & fail_mask
        if iso_mask.any():
            # Mean distance to nearest domain centroid
            from .landscape import Landscape  # avoid circular

            iso_features = self.features[iso_mask]
            success_features = self.features[success_mask]

            # Use Euclidean to centroids stored in metadata
            if "centroids" in self.metadata.get("landscape_params", {}):
                centroids = np.array(
                    self.metadata["landscape_params"]["centroids"]
                )
                iso_dists = np.min(
                    np.linalg.norm(
                        iso_features[:, None, :] - centroids[None, :, :],
                        axis=2,
                    ),
                    axis=1,
                )
                success_dists = np.min(
                    np.linalg.norm(
                        success_features[:, None, :] - centroids[None, :, :],
                        axis=2,
                    ),
                    axis=1,
                ) if success_mask.any() else np.array([])

                results["isolated_verification"] = {
                    "mean_dist_isolated_failures": float(iso_dists.mean()),
                    "mean_dist_successes": float(success_dists.mean())
                    if len(success_dists) > 0 else None,
                    "verified": bool(iso_dists.mean() > success_dists.mean())
                    if len(success_dists) > 0 else None,
                }

        # Diffuse verification: diffuse failures should be spread across
        # domains, not concentrated
        diff_mask = (self.pattern_labels == "diffuse") & fail_mask
        if diff_mask.any():
            diffuse_domains = self.domain_labels[diff_mask]
            unique_domains, domain_counts = np.unique(
                diffuse_domains, return_counts=True
            )
            total_diffuse = diff_mask.sum()

            # Entropy of domain distribution (higher = more spread)
            probs = domain_counts / total_diffuse
            entropy = -np.sum(probs * np.log2(probs + 1e-10))
            max_entropy = np.log2(len(unique_domains)) if len(
                unique_domains
            ) > 1 else 1.0

            results["diffuse_verification"] = {
                "n_domains_with_failures": int(len(unique_domains)),
                "domain_entropy": float(entropy),
                "max_possible_entropy": float(max_entropy),
                "normalized_entropy": float(entropy / max_entropy)
                if max_entropy > 0 else 0.0,
                "verified": bool(
                    len(unique_domains) > 1
                    and entropy / max_entropy > 0.5
                ) if max_entropy > 0 else False,
            }

        if verbose:
            print(self._format_verification(results))

        return results

    def _format_verification(self, results: Dict) -> str:
        """Format verification results for display."""
        lines = [
            "TESSERA Dataset Verification",
            "=" * 45,
            f"Entities:      {results['n_entities']}",
            f"Failures:      {results['n_failures']} "
            f"({results['failure_rate']:.1%})",
            f"Patterns:      { {self._PATTERN_DISPLAY.get(k,k): v for k,v in results['pattern_distribution'].items()} }",
        ]

        eco = results.get("boundary_verification")
        if eco:
            status = "PASS" if eco.get("verified") else "FAIL"
            lines.append(f"\nBoundary [{status}]:")
            lines.append(
                f"  Boundary failure score:  "
                f"{eco['mean_boundary_score_boundary_failures']:.3f}"
            )
            if eco["mean_boundary_score_successes"] is not None:
                lines.append(
                    f"  Success score:          "
                    f"{eco['mean_boundary_score_successes']:.3f}"
                )

        iso = results.get("isolated_verification")
        if iso:
            status = "PASS" if iso.get("verified") else "FAIL"
            lines.append(f"\nIsolated [{status}]:")
            lines.append(
                f"  Isolated dist to centroids:  "
                f"{iso['mean_dist_isolated_failures']:.3f}"
            )
            if iso["mean_dist_successes"] is not None:
                lines.append(
                    f"  Success dist to centroids:   "
                    f"{iso['mean_dist_successes']:.3f}"
                )

        diff = results.get("diffuse_verification")
        if diff:
            status = "PASS" if diff.get("verified") else "FAIL"
            lines.append(f"\nDiffuse [{status}]:")
            lines.append(
                f"  Domains with failures:  "
                f"{diff['n_domains_with_failures']}"
            )
            lines.append(
                f"  Normalized entropy:     "
                f"{diff['normalized_entropy']:.3f}"
            )

        return "\n".join(lines)

    # Display name mapping for user-facing output
    _PATTERN_DISPLAY = {"ecotone": "boundary", "isolated": "isolated",
                        "diffuse": "diffuse", "success": "success"}

    def summary(self) -> str:
        """Human-readable dataset summary."""
        lines = [
            "TESSERA Dataset Summary",
            "=" * 40,
            f"Entities:        {self.n_entities}",
            f"Dimensions:      {self.n_dimensions}",
            f"Failures:        {self.n_failures} ({self.failure_rate:.1%})",
            f"Time windows:    {len(np.unique(self.time_windows))}",
            "",
            "Failure patterns:",
        ]
        for pattern, count in sorted(self.pattern_distribution().items()):
            display = self._PATTERN_DISPLAY.get(pattern, pattern)
            pct = 100 * count / max(self.n_failures, 1)
            lines.append(f"  {display}: {count} ({pct:.1f}%)")

        return "\n".join(lines)

    def save(self, path: str):
        """Save full dataset and metadata to npz + json."""
        base = path.rsplit(".", 1)[0] if "." in path else path

        # Save arrays
        np.savez_compressed(
            f"{base}.npz",
            features=self.features,
            outcomes=self.outcomes,
            domain_labels=self.domain_labels,
            pattern_labels=self.pattern_labels,
            time_windows=self.time_windows,
            ecotone_scores=self.ecotone_scores,
            failure_probabilities=self.failure_probabilities,
        )

        # Save metadata
        with open(f"{base}_metadata.json", "w") as f:
            json.dump(self.metadata, f, indent=2, default=str)

    @classmethod
    def load(cls, path: str) -> "TesseraDataset":
        """Load dataset from saved files."""
        base = path.rsplit(".", 1)[0] if "." in path else path

        data = np.load(f"{base}.npz", allow_pickle=True)

        with open(f"{base}_metadata.json", "r") as f:
            metadata = json.load(f)

        return cls(
            features=data["features"],
            outcomes=data["outcomes"],
            domain_labels=data["domain_labels"],
            pattern_labels=data["pattern_labels"],
            time_windows=data["time_windows"],
            ecotone_scores=data["ecotone_scores"],
            failure_probabilities=data["failure_probabilities"],
            metadata=metadata,
        )


class OutcomeAssigner:
    """
    Assigns binary outcomes to a Landscape according to geometric patterns.

    Parameters
    ----------
    failure_rate : float
        Target overall failure rate (0.0 to 1.0). Default: 0.15
    difficulty : float
        Controls pattern separability (0.0 = trivial, 1.0 = near-random).
        At low difficulty, patterns are clean and easy to detect.
        At high difficulty, noise obscures the geometric structure.
        Default: 0.5
    noise : float
        Additional random noise in failure probability. Default: 0.05
    random_state : int or None
        Random seed for reproducibility.
    """

    VALID_PATTERNS = {"ecotone", "isolated", "diffuse", "mixed"}

    def __init__(
        self,
        failure_rate: float = 0.15,
        difficulty: float = 0.5,
        noise: float = 0.05,
        random_state: Optional[int] = None,
    ):
        if not 0.0 < failure_rate < 1.0:
            raise ValueError("failure_rate must be between 0 and 1")
        if not 0.0 <= difficulty <= 1.0:
            raise ValueError("difficulty must be between 0 and 1")

        self.failure_rate = failure_rate
        self.difficulty = difficulty
        self.noise = noise
        self.random_state = random_state

    def apply(
        self,
        landscape: Landscape,
        pattern: str = "ecotone",
        weights: Optional[Dict[str, float]] = None,
    ) -> TesseraDataset:
        """
        Apply failure pattern(s) to a landscape.

        Parameters
        ----------
        landscape : Landscape
            The feature space topology.
        pattern : str
            One of "ecotone", "isolated", "diffuse", "mixed".
        weights : dict, optional
            For "mixed" pattern: weights for each sub-pattern.
            Default: {"ecotone": 0.5, "isolated": 0.3, "diffuse": 0.2}
        """
        if pattern not in self.VALID_PATTERNS:
            raise ValueError(
                f"pattern must be one of {self.VALID_PATTERNS}, "
                f"got '{pattern}'"
            )

        rng = np.random.default_rng(self.random_state)
        N = landscape.n_entities

        if pattern == "mixed":
            if weights is None:
                weights = {
                    "ecotone": 0.5,
                    "isolated": 0.3,
                    "diffuse": 0.2,
                }
            return self._apply_mixed(landscape, weights, rng)

        elif pattern == "isolated":
            # Isolated pattern injects entities into a distinct region
            return self._apply_isolated(landscape, rng)

        else:
            # Ecotone or diffuse — no feature modification needed
            fail_probs, pattern_labels = self._compute_failure_probs(
                landscape, pattern, rng
            )

            # Calibrate to target failure rate
            fail_probs = self._calibrate_rate(fail_probs, rng)

            # Sample outcomes
            outcomes = (rng.random(N) < fail_probs).astype(int)

            return self._build_dataset(
                landscape, outcomes, fail_probs, pattern_labels, rng
            )

    def _compute_failure_probs(
        self,
        landscape: Landscape,
        pattern: str,
        rng: np.random.Generator,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Compute raw failure probabilities for ecotone or diffuse pattern."""
        N = landscape.n_entities
        # Initialize all as "success"; failures get relabeled after sampling
        pattern_labels = np.full(N, "success", dtype="U10")

        if pattern == "ecotone":
            fail_probs = self._ecotone_probs(landscape, rng)
        elif pattern == "diffuse":
            fail_probs = self._diffuse_probs(landscape, rng)
        else:
            raise ValueError(
                f"Pattern '{pattern}' not handled by _compute_failure_probs. "
                f"Use apply() for isolated/mixed patterns."
            )

        # Store pattern name for labeling after outcome sampling
        self._current_pattern = pattern

        return fail_probs, pattern_labels

    def _apply_isolated(
        self,
        landscape: Landscape,
        rng: np.random.Generator,
        n_failures_override: Optional[int] = None,
    ) -> Tuple:
        """
        Isolated cluster pattern with entity injection.

        Creates a phantom centroid far from existing domains, generates
        new entities around it, and swaps them into the feature matrix.
        These injected entities become the isolated failure cluster.

        Parameters
        ----------
        landscape : Landscape
            The feature space topology.
        rng : np.random.Generator
            Random number generator.
        n_failures_override : int, optional
            If provided, inject this many failures instead of using
            self.failure_rate. Used by _apply_mixed for partial injection.

        Returns
        -------
        TesseraDataset or tuple
            If n_failures_override is None, returns TesseraDataset.
            If n_failures_override is set, returns (modified_features,
            injected_indices, phantom_centroid) for use by _apply_mixed.
        """
        N = landscape.n_entities
        D = landscape.n_dimensions

        # How many entities to inject
        if n_failures_override is not None:
            n_inject = n_failures_override
        else:
            n_inject = int(N * self.failure_rate)

        # ── Place phantom centroid ───────────────────────────────
        # Find the direction that maximizes distance from all centroids
        mean_centroid = landscape.centroids.mean(axis=0)
        max_dist = np.max(
            np.linalg.norm(landscape.centroids - mean_centroid, axis=1)
        )

        # Random direction, placed 2.5-4x the max centroid spread
        direction = rng.standard_normal(D)
        direction /= np.linalg.norm(direction)

        # Distance modulated by difficulty:
        # Low difficulty → far away (easy to detect)
        # High difficulty → closer (harder to distinguish)
        base_dist = 4.0 * (1.0 - self.difficulty) + 2.0 * self.difficulty
        phantom_centroid = mean_centroid + direction * max_dist * base_dist

        # ── Generate injected entities ───────────────────────────
        # Covariance: tighter than main domains (isolated cluster is compact)
        # Difficulty modulates spread: low difficulty → very tight cluster
        spread = 0.3 * (1.0 - self.difficulty) + 0.8 * self.difficulty
        phantom_cov = np.eye(D) * spread

        injected_features = rng.multivariate_normal(
            mean=phantom_centroid,
            cov=phantom_cov,
            size=n_inject,
        )

        # ── Swap into feature matrix ────────────────────────────
        modified_features = landscape.features.copy()

        # Select random entities to replace (not biased by domain)
        inject_indices = rng.choice(N, size=n_inject, replace=False)
        modified_features[inject_indices] = injected_features

        # If called from _apply_mixed, return components
        if n_failures_override is not None:
            return modified_features, inject_indices, phantom_centroid

        # ── Build full dataset for pure isolated ─────────────────
        # Failure probabilities: injected entities → high, others → low
        fail_probs = np.full(N, 0.02)  # baseline noise
        fail_probs[inject_indices] = 0.95

        # Add small noise
        noise = rng.normal(0, self.noise, size=N)
        fail_probs = np.clip(fail_probs + noise, 0.01, 0.99)

        # Deterministic outcomes for injected entities + noise elsewhere
        outcomes = np.zeros(N, dtype=int)
        outcomes[inject_indices] = 1

        # Small number of random false positives for realism
        n_noise_fails = max(1, int(n_inject * 0.05))
        non_injected = np.setdiff1d(np.arange(N), inject_indices)
        noise_fail_idx = rng.choice(
            non_injected, size=min(n_noise_fails, len(non_injected)),
            replace=False
        )
        outcomes[noise_fail_idx] = 1

        # Pattern labels
        pattern_labels = np.full(N, "success", dtype="U10")
        pattern_labels[outcomes == 1] = "isolated"

        # Build with modified features
        self._current_pattern = "isolated"
        metadata_extra = {
            "phantom_centroid": phantom_centroid.tolist(),
            "n_injected": int(n_inject),
            "phantom_distance": float(
                np.linalg.norm(phantom_centroid - mean_centroid)
            ),
        }

        return self._build_dataset(
            landscape, outcomes, fail_probs, pattern_labels, rng,
            modified_features=modified_features,
            extra_metadata=metadata_extra,
        )

    def _ecotone_probs(
        self, landscape: Landscape, rng: np.random.Generator
    ) -> np.ndarray:
        """
        Ecotone pattern: failure probability proportional to ecotone score.

        Entities deep within a domain have low failure probability.
        Entities at domain boundaries (high ecotone score) have high
        failure probability.
        """
        scores = landscape.ecotone_scores()

        # Sharpen or soften based on difficulty
        # Low difficulty → sharp transition (high exponent)
        # High difficulty → gradual transition (low exponent)
        exponent = 3.0 * (1.0 - self.difficulty) + 0.5 * self.difficulty
        fail_probs = scores ** exponent

        # Add noise
        noise = rng.normal(0, self.noise, size=len(fail_probs))
        fail_probs = np.clip(fail_probs + noise, 0.01, 0.99)

        return fail_probs

    def _diffuse_probs(
        self, landscape: Landscape, rng: np.random.Generator
    ) -> np.ndarray:
        """
        Diffuse pattern: failures driven by individual feature thresholds,
        not relational position.

        Randomly select a subset of features. For each, set a threshold.
        Entities exceeding multiple thresholds have higher failure prob.
        This is the pattern where TESSERA should NOT outperform a simple
        classifier — it's a control condition.
        """
        N = landscape.n_entities
        D = landscape.n_dimensions

        # Select 2-4 features as "failure drivers"
        n_drivers = rng.integers(2, min(5, D + 1))
        driver_features = rng.choice(D, size=n_drivers, replace=False)

        # Set thresholds at various percentiles
        violation_count = np.zeros(N)
        for feat_idx in driver_features:
            values = landscape.features[:, feat_idx]
            # Threshold at 60th-80th percentile
            pctile = rng.uniform(60, 80)
            threshold = np.percentile(values, pctile)
            violation_count += (values > threshold).astype(float)

        # Normalize to [0, 1]
        fail_probs = violation_count / n_drivers

        # Difficulty modulation
        exponent = 2.0 * (1.0 - self.difficulty) + 0.5 * self.difficulty
        fail_probs = fail_probs ** exponent

        # Add noise
        noise = rng.normal(0, self.noise, size=N)
        fail_probs = np.clip(fail_probs + noise, 0.01, 0.99)

        return fail_probs

    def _apply_mixed(
        self,
        landscape: Landscape,
        weights: Dict[str, float],
        rng: np.random.Generator,
    ) -> TesseraDataset:
        """
        Mixed pattern: combines ecotone, isolated, and diffuse failures.

        Isolated failures use entity injection (modified features).
        Ecotone and diffuse use probability-based assignment on original
        features. All three coexist in the same dataset.
        """
        N = landscape.n_entities

        # Normalize weights
        total = sum(weights.values())
        normalized = {k: v / total for k, v in weights.items()}

        # Target failures per pattern
        n_total_failures = int(N * self.failure_rate)
        n_per_pattern = {
            pat: int(n_total_failures * w)
            for pat, w in normalized.items()
            if w > 0
        }

        # ── Handle isolated injection first ──────────────────────
        modified_features = landscape.features.copy()
        injected_indices = np.array([], dtype=int)
        extra_metadata = {}

        if "isolated" in n_per_pattern and n_per_pattern["isolated"] > 0:
            n_iso = n_per_pattern["isolated"]
            modified_features, injected_indices, phantom_centroid = \
                self._apply_isolated(
                    landscape, rng, n_failures_override=n_iso
                )
            extra_metadata = {
                "phantom_centroid": phantom_centroid.tolist(),
                "n_injected": int(n_iso),
            }

        # ── Compute ecotone and diffuse probs ────────────────────
        prob_components = {}
        for pat in ["ecotone", "diffuse"]:
            if pat in normalized and normalized[pat] > 0:
                if pat == "ecotone":
                    prob_components[pat] = self._ecotone_probs(landscape, rng)
                elif pat == "diffuse":
                    prob_components[pat] = self._diffuse_probs(landscape, rng)

        # ── Combine into outcomes ────────────────────────────────
        outcomes = np.zeros(N, dtype=int)
        pattern_labels = np.full(N, "success", dtype="U10")
        fail_probs = np.full(N, 0.01)

        # 1. Isolated: injected entities are deterministic failures
        if len(injected_indices) > 0:
            outcomes[injected_indices] = 1
            pattern_labels[injected_indices] = "isolated"
            fail_probs[injected_indices] = 0.95

        # 2. Ecotone + diffuse: probability-based on non-injected entities
        non_injected = np.setdiff1d(np.arange(N), injected_indices)

        if prob_components:
            # Weighted combination of ecotone/diffuse probs
            combined = np.zeros(N)
            weight_sum = sum(
                normalized[p] for p in prob_components
            )
            for pat, probs in prob_components.items():
                combined += probs * (normalized[pat] / weight_sum)

            # Only apply to non-injected entities
            # Calibrate to achieve remaining failure count
            n_remaining = n_total_failures - len(injected_indices)

            if n_remaining > 0 and len(non_injected) > 0:
                # Rank non-injected by combined probability, take top n
                non_inj_probs = combined[non_injected]
                top_indices = np.argsort(non_inj_probs)[::-1][:n_remaining]
                fail_indices = non_injected[top_indices]

                outcomes[fail_indices] = 1
                fail_probs[fail_indices] = combined[fail_indices]

                # Label by dominant pattern
                for idx in fail_indices:
                    best_pat = max(
                        prob_components.keys(),
                        key=lambda p: prob_components[p][idx] * normalized[p]
                    )
                    pattern_labels[idx] = best_pat

        # ── Build dataset ────────────────────────────────────────
        self._current_pattern = "mixed"

        return self._build_dataset(
            landscape, outcomes, fail_probs, pattern_labels, rng,
            modified_features=modified_features,
            extra_metadata=extra_metadata if extra_metadata else None,
        )

    def _calibrate_rate(
        self, fail_probs: np.ndarray, rng: np.random.Generator
    ) -> np.ndarray:
        """
        Calibrate failure probabilities to achieve target failure rate.

        Uses a sigmoid shift to adjust the overall rate while preserving
        the relative ordering of probabilities.
        """
        # Sort probabilities and find the threshold that gives target rate
        sorted_probs = np.sort(fail_probs)[::-1]
        target_count = int(self.failure_rate * len(fail_probs))

        if target_count == 0 or target_count >= len(fail_probs):
            return fail_probs

        # Scale probabilities so that their mean matches target failure rate
        current_mean = fail_probs.mean()
        if current_mean > 0:
            scale = self.failure_rate / current_mean
            calibrated = fail_probs * scale
            calibrated = np.clip(calibrated, 0.01, 0.99)
            return calibrated

        return fail_probs

    def _build_dataset(
        self,
        landscape: Landscape,
        outcomes: np.ndarray,
        fail_probs: np.ndarray,
        pattern_labels: np.ndarray,
        rng: np.random.Generator,
        modified_features: Optional[np.ndarray] = None,
        extra_metadata: Optional[Dict] = None,
    ) -> TesseraDataset:
        """Assemble the TesseraDataset from components."""
        fail_mask = outcomes == 1

        # For pure patterns, label all failures with the pattern name
        current_pattern = getattr(self, "_current_pattern", None)
        if current_pattern and current_pattern not in ("mixed", "isolated"):
            pattern_labels[fail_mask] = current_pattern

        # Use modified features if provided (e.g., isolated injection)
        features = modified_features if modified_features is not None \
            else landscape.features

        metadata = {
            "generator": "OutcomeAssigner",
            "version": "1.0.0",
            "outcome_params": {
                "failure_rate_target": self.failure_rate,
                "failure_rate_actual": float(outcomes.mean()),
                "difficulty": self.difficulty,
                "noise": self.noise,
                "random_state": self.random_state,
            },
            "landscape_params": landscape.metadata.get("params", {}),
        }

        # Store centroids for verification
        if landscape.centroids is not None:
            metadata["landscape_params"]["centroids"] = (
                landscape.centroids.tolist()
            )

        # Merge any extra metadata (e.g., phantom centroid info)
        if extra_metadata:
            metadata["isolated_injection"] = extra_metadata

        # Recompute ecotone scores on actual features used
        # (important if features were modified by isolated injection)
        ecotone_scores = landscape.ecotone_scores()

        return TesseraDataset(
            features=features,
            outcomes=outcomes,
            domain_labels=landscape.domain_labels,
            pattern_labels=pattern_labels,
            time_windows=landscape.time_windows,
            ecotone_scores=ecotone_scores,
            failure_probabilities=fail_probs,
            metadata=metadata,
        )
