"""
TESSERA Synthetic Landscape Builder

Constructs multi-dimensional feature space topologies with controllable
domain structure, overlap, correlation, and temporal drift.
"""

import numpy as np
from scipy.stats import special_ortho_group
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
import json
import warnings


@dataclass
class Landscape:
    """
    A generated feature space topology.

    Contains entity feature vectors, domain assignments, temporal windows,
    and full metadata about the construction parameters.
    """
    features: np.ndarray              # (N, D) feature matrix
    domain_labels: np.ndarray         # (N,) integer domain assignment
    time_windows: np.ndarray          # (N,) integer time window assignment
    centroids: np.ndarray             # (K, D) domain centroids
    covariances: np.ndarray           # (K, D, D) domain covariance matrices
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def n_entities(self) -> int:
        return self.features.shape[0]

    @property
    def n_dimensions(self) -> int:
        return self.features.shape[1]

    @property
    def n_domains(self) -> int:
        return len(np.unique(self.domain_labels))

    @property
    def n_time_windows(self) -> int:
        return len(np.unique(self.time_windows))

    def domain_mask(self, domain_id: int) -> np.ndarray:
        """Boolean mask for entities in a given domain."""
        return self.domain_labels == domain_id

    def time_mask(self, window_id: int) -> np.ndarray:
        """Boolean mask for entities in a given time window."""
        return self.time_windows == window_id

    def domain_distances(self) -> np.ndarray:
        """
        (N, K) matrix of Mahalanobis distances from each entity to each
        domain centroid, accounting for domain covariance.
        """
        N = self.n_entities
        K = len(self.centroids)
        distances = np.zeros((N, K))

        for k in range(K):
            diff = self.features - self.centroids[k]
            cov_inv = np.linalg.inv(self.covariances[k])
            # Mahalanobis: sqrt((x - mu)^T @ Sigma^{-1} @ (x - mu))
            distances[:, k] = np.sqrt(
                np.sum(diff @ cov_inv * diff, axis=1)
            )

        return distances

    def ecotone_scores(self) -> np.ndarray:
        """
        Compute ecotone score for each entity.

        Score = 1 - |d_nearest - d_second| / (d_nearest + d_second)

        Ranges from 0 (deep within a domain) to 1 (equidistant between
        two domains — maximum ecotone).
        """
        distances = self.domain_distances()

        # Sort distances along domain axis
        sorted_d = np.sort(distances, axis=1)
        d_nearest = sorted_d[:, 0]
        d_second = sorted_d[:, 1]

        # Avoid division by zero
        denom = d_nearest + d_second
        denom = np.where(denom == 0, 1e-10, denom)

        scores = 1.0 - np.abs(d_nearest - d_second) / denom
        return scores

    def summary(self) -> str:
        """Human-readable summary of the landscape."""
        lines = [
            "TESSERA Landscape Summary",
            "=" * 40,
            f"Entities:        {self.n_entities}",
            f"Dimensions:      {self.n_dimensions}",
            f"Domains:         {self.n_domains}",
            f"Time windows:    {self.n_time_windows}",
            "",
            "Domain sizes:",
        ]
        for k in range(self.n_domains):
            count = np.sum(self.domain_labels == k)
            pct = 100 * count / self.n_entities
            lines.append(f"  Domain {k}: {count} ({pct:.1f}%)")

        lines.append("")
        lines.append("Boundary score distribution:")
        scores = self.ecotone_scores()
        lines.append(f"  Mean:   {scores.mean():.3f}")
        lines.append(f"  Std:    {scores.std():.3f}")
        lines.append(f"  Median: {np.median(scores):.3f}")
        lines.append(f"  Max:    {scores.max():.3f}")

        return "\n".join(lines)

    def save_metadata(self, path: str):
        """Save construction metadata to JSON for reproducibility."""
        with open(path, "w") as f:
            json.dump(self.metadata, f, indent=2, default=str)


class LandscapeBuilder:
    """
    Constructs a synthetic feature space topology.

    Builds K operational domains in D-dimensional space with controllable
    geometry, overlap, feature correlations, and temporal drift.

    Parameters
    ----------
    n_entities : int
        Total number of entities to generate.
    n_dimensions : int
        Number of feature dimensions.
    n_domains : int
        Number of operational domains (clusters).
    domain_sizes : list of float, optional
        Relative proportions for each domain. Must sum to 1.
        Default: uniform distribution.
    domain_geometry : str
        Shape of domain clusters. One of:
        - "spherical": isotropic Gaussian (identity covariance)
        - "elliptical": anisotropic Gaussian (random rotation + axis scaling)
        - "mixed": randomly choose per domain
    overlap : float
        Controls inter-domain distance relative to spread.
        0.0 = well-separated, 1.0 = heavily overlapping.
        Default: 0.15
    feature_correlation : str
        Correlation structure within domains:
        - "none": features are independent
        - "block": features within groups are correlated
        - "random": random correlation structure per domain
    n_correlated_groups : int
        Number of correlated feature groups (for "block" correlation).
    n_time_windows : int
        Number of temporal windows. Default: 1 (no temporal structure).
    drift_rate : float
        Magnitude of centroid drift per time window. 0.0 = static.
    random_state : int or None
        Random seed for reproducibility.
    """

    def __init__(
        self,
        n_entities: int = 5000,
        n_dimensions: int = 15,
        n_domains: int = 4,
        domain_sizes: Optional[List[float]] = None,
        domain_geometry: str = "elliptical",
        overlap: float = 0.15,
        feature_correlation: str = "block",
        n_correlated_groups: int = 3,
        n_time_windows: int = 1,
        drift_rate: float = 0.0,
        random_state: Optional[int] = None,
    ):
        self.n_entities = n_entities
        self.n_dimensions = n_dimensions
        self.n_domains = n_domains
        self.domain_geometry = domain_geometry
        self.overlap = overlap
        self.feature_correlation = feature_correlation
        self.n_correlated_groups = n_correlated_groups
        self.n_time_windows = n_time_windows
        self.drift_rate = drift_rate
        self.random_state = random_state

        # Validate and set domain sizes
        if domain_sizes is None:
            self.domain_sizes = [1.0 / n_domains] * n_domains
        else:
            if len(domain_sizes) != n_domains:
                raise ValueError(
                    f"domain_sizes length ({len(domain_sizes)}) must match "
                    f"n_domains ({n_domains})"
                )
            total = sum(domain_sizes)
            if not np.isclose(total, 1.0):
                warnings.warn(
                    f"domain_sizes sum to {total}, normalizing to 1.0"
                )
                self.domain_sizes = [s / total for s in domain_sizes]
            else:
                self.domain_sizes = list(domain_sizes)

        # Validate geometry
        valid_geom = {"spherical", "elliptical", "mixed"}
        if self.domain_geometry not in valid_geom:
            raise ValueError(
                f"domain_geometry must be one of {valid_geom}, "
                f"got '{self.domain_geometry}'"
            )

        # Validate correlation
        valid_corr = {"none", "block", "random"}
        if self.feature_correlation not in valid_corr:
            raise ValueError(
                f"feature_correlation must be one of {valid_corr}, "
                f"got '{self.feature_correlation}'"
            )

    def build(self) -> Landscape:
        """Construct the landscape."""
        rng = np.random.default_rng(self.random_state)

        # Step 1: Generate domain centroids with controlled overlap
        centroids = self._generate_centroids(rng)

        # Step 2: Generate covariance matrices per domain
        covariances = self._generate_covariances(rng)

        # Step 3: Assign entities to domains
        domain_counts = self._assign_domain_counts()

        # Step 4: Generate features per domain, per time window
        all_features = []
        all_domains = []
        all_times = []

        entities_per_window = self.n_entities // self.n_time_windows
        remainder = self.n_entities % self.n_time_windows

        for t in range(self.n_time_windows):
            # Apply temporal drift to centroids
            drifted_centroids = self._apply_drift(centroids, t, rng)

            # Number of entities in this time window
            n_window = entities_per_window + (1 if t < remainder else 0)

            # Scale domain counts for this window
            window_counts = self._scale_counts(domain_counts, n_window)

            for k in range(self.n_domains):
                n_k = window_counts[k]
                if n_k == 0:
                    continue

                samples = rng.multivariate_normal(
                    mean=drifted_centroids[k],
                    cov=covariances[k],
                    size=n_k,
                )

                all_features.append(samples)
                all_domains.append(np.full(n_k, k, dtype=int))
                all_times.append(np.full(n_k, t, dtype=int))

        features = np.vstack(all_features)
        domain_labels = np.concatenate(all_domains)
        time_windows = np.concatenate(all_times)

        # Shuffle to avoid ordered structure
        shuffle_idx = rng.permutation(len(features))
        features = features[shuffle_idx]
        domain_labels = domain_labels[shuffle_idx]
        time_windows = time_windows[shuffle_idx]

        # Build metadata
        metadata = {
            "generator": "LandscapeBuilder",
            "version": "1.0.0",
            "params": {
                "n_entities": self.n_entities,
                "n_dimensions": self.n_dimensions,
                "n_domains": self.n_domains,
                "domain_sizes": self.domain_sizes,
                "domain_geometry": self.domain_geometry,
                "overlap": self.overlap,
                "feature_correlation": self.feature_correlation,
                "n_correlated_groups": self.n_correlated_groups,
                "n_time_windows": self.n_time_windows,
                "drift_rate": self.drift_rate,
                "random_state": self.random_state,
            },
            "centroids": centroids.tolist(),
        }

        return Landscape(
            features=features,
            domain_labels=domain_labels,
            time_windows=time_windows,
            centroids=centroids,
            covariances=covariances,
            metadata=metadata,
        )

    def _generate_centroids(self, rng: np.random.Generator) -> np.ndarray:
        """
        Generate domain centroids with controlled inter-domain distance.

        The overlap parameter modulates how far apart centroids are placed.
        overlap=0 → centroids ~3 std apart (well-separated)
        overlap=1 → centroids ~0.5 std apart (heavily overlapping)
        """
        # Base separation: inversely proportional to overlap
        separation = 3.0 * (1.0 - self.overlap) + 0.5 * self.overlap

        # Place centroids using rejection-free approach:
        # Sample on a sphere of radius `separation` and jitter
        centroids = np.zeros((self.n_domains, self.n_dimensions))

        if self.n_domains == 1:
            return centroids

        # Use Fibonacci-like placement for first centroids, then random
        for k in range(1, self.n_domains):
            # Random direction in D dimensions
            direction = rng.standard_normal(self.n_dimensions)
            direction /= np.linalg.norm(direction)

            # Place at `separation` distance from origin with jitter
            jitter = rng.uniform(0.8, 1.2)
            centroids[k] = direction * separation * jitter

        # Re-center so mean is at origin
        centroids -= centroids.mean(axis=0)

        return centroids

    def _generate_covariances(
        self, rng: np.random.Generator
    ) -> np.ndarray:
        """Generate covariance matrices per domain."""
        D = self.n_dimensions
        K = self.n_domains
        covariances = np.zeros((K, D, D))

        for k in range(K):
            # Determine geometry for this domain
            if self.domain_geometry == "mixed":
                geom = rng.choice(["spherical", "elliptical"])
            else:
                geom = self.domain_geometry

            if geom == "spherical":
                cov = np.eye(D)
            else:
                # Elliptical: random rotation with varying axis scales
                # Eigenvalues range from 0.3 to 2.0
                eigenvalues = rng.uniform(0.3, 2.0, size=D)

                # Random rotation matrix
                if D >= 2:
                    rotation = special_ortho_group.rvs(D, random_state=rng)
                else:
                    rotation = np.array([[1.0]])

                cov = rotation @ np.diag(eigenvalues) @ rotation.T

            # Apply correlation structure
            if self.feature_correlation == "block":
                cov = self._apply_block_correlation(cov, rng)
            elif self.feature_correlation == "random":
                cov = self._apply_random_correlation(cov, rng)

            # Ensure positive definite
            cov = self._ensure_positive_definite(cov)
            covariances[k] = cov

        return covariances

    def _apply_block_correlation(
        self, cov: np.ndarray, rng: np.random.Generator
    ) -> np.ndarray:
        """
        Add block correlation structure.

        Features are divided into groups; within-group correlations are
        injected (0.3-0.7), between-group correlations remain as-is.
        """
        D = cov.shape[0]
        n_groups = min(self.n_correlated_groups, D)
        group_size = D // n_groups

        for g in range(n_groups):
            start = g * group_size
            end = start + group_size if g < n_groups - 1 else D

            for i in range(start, end):
                for j in range(i + 1, end):
                    corr = rng.uniform(0.3, 0.7)
                    std_i = np.sqrt(cov[i, i])
                    std_j = np.sqrt(cov[j, j])
                    cov[i, j] = corr * std_i * std_j
                    cov[j, i] = cov[i, j]

        return cov

    def _apply_random_correlation(
        self, cov: np.ndarray, rng: np.random.Generator
    ) -> np.ndarray:
        """Add random off-diagonal correlations."""
        D = cov.shape[0]

        # Randomly correlate ~30% of feature pairs
        for i in range(D):
            for j in range(i + 1, D):
                if rng.random() < 0.3:
                    corr = rng.uniform(0.2, 0.6)
                    std_i = np.sqrt(cov[i, i])
                    std_j = np.sqrt(cov[j, j])
                    cov[i, j] = corr * std_i * std_j
                    cov[j, i] = cov[i, j]

        return cov

    @staticmethod
    def _ensure_positive_definite(cov: np.ndarray) -> np.ndarray:
        """Ensure matrix is symmetric positive definite."""
        # Symmetrize
        cov = (cov + cov.T) / 2

        # Eigenvalue floor
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        eigenvalues = np.maximum(eigenvalues, 1e-6)
        cov = eigenvectors @ np.diag(eigenvalues) @ eigenvectors.T

        return cov

    def _assign_domain_counts(self) -> List[int]:
        """Assign entity counts per domain based on domain_sizes."""
        counts = [int(s * self.n_entities) for s in self.domain_sizes]

        # Handle rounding remainder
        remainder = self.n_entities - sum(counts)
        for i in range(remainder):
            counts[i % self.n_domains] += 1

        return counts

    def _scale_counts(
        self, domain_counts: List[int], n_window: int
    ) -> List[int]:
        """Scale domain counts to fit a specific time window size."""
        total = sum(domain_counts)
        if total == 0:
            return [0] * len(domain_counts)

        counts = [int(c * n_window / total) for c in domain_counts]
        remainder = n_window - sum(counts)
        for i in range(remainder):
            counts[i % len(counts)] += 1

        return counts

    def _apply_drift(
        self,
        centroids: np.ndarray,
        time_step: int,
        rng: np.random.Generator,
    ) -> np.ndarray:
        """
        Apply temporal drift to centroids.

        Each time step shifts centroids by a consistent random direction
        scaled by drift_rate.
        """
        if self.drift_rate == 0.0 or time_step == 0:
            return centroids.copy()

        # Deterministic drift direction per domain (seeded by domain index)
        drifted = centroids.copy()
        for k in range(len(centroids)):
            # Use a sub-seed for reproducibility
            drift_rng = np.random.default_rng(
                (self.random_state or 0) + k * 1000 + 1
            )
            direction = drift_rng.standard_normal(centroids.shape[1])
            direction /= np.linalg.norm(direction)

            drifted[k] += direction * self.drift_rate * time_step

        return drifted
