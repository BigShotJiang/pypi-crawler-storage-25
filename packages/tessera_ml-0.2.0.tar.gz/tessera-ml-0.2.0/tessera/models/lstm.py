"""
TESSERA LSTM Model

Long Short-Term Memory network for capturing temporal dynamics
in the response landscape. Operates on per-time-window aggregate
feature statistics to detect temporal drift patterns.

This is Step 4b of the TESSERA workflow.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Optional, Dict, Tuple


class TesseraLSTM(nn.Module):
    """
    LSTM for temporal response prediction.

    For each entity, constructs a temporal context by aggregating
    feature statistics across time windows, then uses the LSTM
    to capture temporal drift patterns.

    Architecture:
    - Input: per-window feature summaries (mean, std, failure rate)
    - Bidirectional LSTM
    - Attention pooling over time steps
    - MLP classification head

    Parameters
    ----------
    in_channels : int
        Feature dimension per time step.
    hidden_channels : int
        LSTM hidden dimension. Default: 32
    n_lstm_layers : int
        Number of LSTM layers. Default: 1
    dropout : float
        Dropout rate. Default: 0.3
    bidirectional : bool
        Use bidirectional LSTM. Default: True
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int = 32,
        n_lstm_layers: int = 1,
        dropout: float = 0.3,
        bidirectional: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.bidirectional = bidirectional
        self.n_directions = 2 if bidirectional else 1

        self.lstm = nn.LSTM(
            input_size=in_channels,
            hidden_size=hidden_channels,
            num_layers=n_lstm_layers,
            batch_first=True,
            dropout=dropout if n_lstm_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )

        lstm_out_dim = hidden_channels * self.n_directions

        # Attention mechanism for pooling over time steps
        self.attention = nn.Sequential(
            nn.Linear(lstm_out_dim, lstm_out_dim // 2),
            nn.Tanh(),
            nn.Linear(lstm_out_dim // 2, 1),
        )

        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(lstm_out_dim, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Parameters
        ----------
        x : Tensor (N, T, F)
            Temporal feature sequences. N entities, T time steps,
            F features per step.

        Returns
        -------
        Tensor (N,)
            Predicted response probabilities.
        """
        # LSTM encoding
        lstm_out, _ = self.lstm(x)  # (N, T, hidden * directions)

        # Attention pooling
        attn_weights = self.attention(lstm_out)  # (N, T, 1)
        attn_weights = torch.softmax(attn_weights, dim=1)
        context = (lstm_out * attn_weights).sum(dim=1)  # (N, hidden * dirs)

        # Classification
        logits = self.classifier(context).squeeze(-1)
        return torch.sigmoid(logits)


def prepare_lstm_data(
    features: np.ndarray,
    outcomes: np.ndarray,
    time_windows: np.ndarray,
    community_labels: Optional[np.ndarray] = None,
    device: str = "cpu",
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Prepare temporal sequences for the LSTM.

    For each entity, builds a temporal context from the aggregate
    statistics of its community across time windows.

    Each time step contains:
    - Mean feature values of the entity's community in that window
    - Std of features in that window
    - Community failure rate in that window
    - Entity's own features (repeated for each window it appears in)

    Parameters
    ----------
    features : np.ndarray (N, D)
        Entity features.
    outcomes : np.ndarray (N,)
        Binary outcomes.
    time_windows : np.ndarray (N,)
        Time window assignment per entity.
    community_labels : np.ndarray (N,), optional
        Community assignments.
    device : str
        Device for tensors.

    Returns
    -------
    sequences : Tensor (N, T, F)
        Temporal feature sequences.
    labels : Tensor (N,)
        Outcome labels.
    """
    N, D = features.shape
    unique_windows = np.sort(np.unique(time_windows))
    T = len(unique_windows)

    if community_labels is None:
        community_labels = np.zeros(N, dtype=int)

    n_communities = int(community_labels.max()) + 1

    # Per-window, per-community statistics
    # Features per time step: D (community mean) + D (community std)
    #                       + 1 (community fail rate) + D (entity features)
    F_per_step = D + D + 1 + D
    sequences = np.zeros((N, T, F_per_step), dtype=np.float32)

    for t_idx, t in enumerate(unique_windows):
        t_mask = time_windows == t

        for c in range(n_communities):
            ct_mask = t_mask & (community_labels == c)

            if ct_mask.sum() == 0:
                continue

            ct_features = features[ct_mask]
            ct_outcomes = outcomes[ct_mask]

            comm_mean = ct_features.mean(axis=0)
            comm_std = ct_features.std(axis=0)
            comm_fail_rate = ct_outcomes.mean()

            # For all entities in this community (regardless of window),
            # set their t-th time step
            c_entities = community_labels == c

            sequences[c_entities, t_idx, :D] = comm_mean
            sequences[c_entities, t_idx, D:2*D] = comm_std
            sequences[c_entities, t_idx, 2*D] = comm_fail_rate

    # Add entity's own features to each time step
    for t_idx in range(T):
        sequences[:, t_idx, 2*D+1:] = features

    x = torch.tensor(sequences, device=device)
    y = torch.tensor(outcomes, dtype=torch.float32, device=device)

    return x, y
