"""
TESSERA GNN Model

Graph Neural Network for response prediction on similarity networks.
Uses the network topology, node features, community labels, and
regime divergence scores to predict entity outcomes.

This is Step 4a of the TESSERA workflow.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, GATConv, SAGEConv
from torch_geometric.data import Data
from typing import Optional, Dict, Any
import numpy as np


class TesseraGNN(nn.Module):
    """
    Graph Neural Network for TESSERA response prediction.

    Architecture:
    - Input: node features + community labels (one-hot) + RD scores
    - 2-3 graph convolution layers (configurable type)
    - Skip connections
    - MLP classification head

    Parameters
    ----------
    in_channels : int
        Number of input features per node.
    hidden_channels : int
        Hidden layer dimension. Default: 64
    n_layers : int
        Number of graph conv layers. Default: 2
    conv_type : str
        Type of graph convolution: "gcn", "gat", "sage". Default: "gcn"
    dropout : float
        Dropout rate. Default: 0.3
    heads : int
        Number of attention heads for GAT. Default: 4
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int = 64,
        n_layers: int = 2,
        conv_type: str = "gcn",
        dropout: float = 0.3,
        heads: int = 4,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.n_layers = n_layers
        self.conv_type = conv_type
        self.dropout = dropout

        # Build convolution layers
        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()

        for i in range(n_layers):
            in_ch = in_channels if i == 0 else hidden_channels
            out_ch = hidden_channels

            if conv_type == "gcn":
                self.convs.append(GCNConv(in_ch, out_ch))
            elif conv_type == "gat":
                if i == 0:
                    self.convs.append(
                        GATConv(in_ch, out_ch // heads, heads=heads)
                    )
                else:
                    self.convs.append(
                        GATConv(hidden_channels, out_ch // heads, heads=heads)
                    )
            elif conv_type == "sage":
                self.convs.append(SAGEConv(in_ch, out_ch))
            else:
                raise ValueError(f"Unknown conv_type: {conv_type}")

            self.norms.append(nn.BatchNorm1d(hidden_channels))

        # Skip connection projection (if input dim != hidden dim)
        self.skip_proj = nn.Linear(in_channels, hidden_channels) \
            if in_channels != hidden_channels else nn.Identity()

        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(hidden_channels, hidden_channels // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels // 2, 1),
        )

    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        edge_weight: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Forward pass.

        Parameters
        ----------
        x : Tensor (N, in_channels)
            Node features.
        edge_index : Tensor (2, E)
            Edge indices.
        edge_weight : Tensor (E,), optional
            Edge weights (similarity values).

        Returns
        -------
        Tensor (N,)
            Predicted response probabilities.
        """
        h = x
        h_skip = self.skip_proj(h)

        for i, (conv, norm) in enumerate(zip(self.convs, self.norms)):
            if self.conv_type == "gcn" and edge_weight is not None:
                h = conv(h, edge_index, edge_weight=edge_weight)
            else:
                h = conv(h, edge_index)

            h = norm(h)
            h = F.relu(h)
            h = F.dropout(h, p=self.dropout, training=self.training)

            # Skip connection after first layer
            if i == 0:
                h = h + h_skip

        # Classification
        logits = self.classifier(h).squeeze(-1)
        return torch.sigmoid(logits)


def prepare_gnn_data(
    features: np.ndarray,
    outcomes: np.ndarray,
    edge_index: np.ndarray,
    edge_weights: np.ndarray,
    community_labels: Optional[np.ndarray] = None,
    rd_scores: Optional[np.ndarray] = None,
    device: str = "cpu",
) -> Data:
    """
    Prepare PyTorch Geometric Data object from TESSERA components.

    Concatenates raw features with community one-hot encoding and
    regime divergence scores to form the full node feature vector.

    Parameters
    ----------
    features : np.ndarray (N, D)
        Raw entity features.
    outcomes : np.ndarray (N,)
        Binary outcome labels.
    edge_index : np.ndarray (2, E)
        Edge indices.
    edge_weights : np.ndarray (E,)
        Edge weights.
    community_labels : np.ndarray (N,), optional
        Community assignments. Encoded as one-hot.
    rd_scores : np.ndarray (N,), optional
        Per-entity regime divergence scores.
    device : str
        Device to place tensors on.

    Returns
    -------
    torch_geometric.data.Data
    """
    # Start with raw features
    feature_list = [features]

    # Add community one-hot encoding
    if community_labels is not None:
        n_communities = int(community_labels.max()) + 1
        max_one_hot = 20  # cap to prevent feature drowning
        if n_communities <= max_one_hot:
            # One-hot for small number of communities
            one_hot = np.zeros((len(community_labels), n_communities))
            one_hot[np.arange(len(community_labels)),
                    community_labels.astype(int)] = 1.0
            feature_list.append(one_hot)
        else:
            # Compact encoding for many communities:
            # normalized community ID + community size + community outcome rate
            # Compact: normalized community ID + community size (no outcome leakage)
            comm_ids = community_labels.astype(float) / max(n_communities - 1, 1)
            comm_sizes = np.zeros(len(community_labels))
            for c in range(n_communities):
                mask = community_labels == c
                comm_sizes[mask] = mask.sum() / len(community_labels)
            feature_list.append(comm_ids.reshape(-1, 1))
            feature_list.append(comm_sizes.reshape(-1, 1))

    # Add RD scores as a feature
    if rd_scores is not None:
        feature_list.append(rd_scores.reshape(-1, 1))

    # Concatenate
    x = np.hstack(feature_list).astype(np.float32)

    data = Data(
        x=torch.tensor(x, device=device),
        y=torch.tensor(outcomes, dtype=torch.float32, device=device),
        edge_index=torch.tensor(edge_index, dtype=torch.long, device=device),
        edge_attr=torch.tensor(
            edge_weights, dtype=torch.float32, device=device
        ),
    )

    return data
