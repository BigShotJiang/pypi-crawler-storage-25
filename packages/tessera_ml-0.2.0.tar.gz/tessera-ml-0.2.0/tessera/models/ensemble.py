"""
TESSERA Ensemble Meta-Learner

Combines predictions from GNN (relational), LSTM (temporal), and
autoencoder (anomaly) into a final response prediction.

The learned weights reveal which signal source matters per domain:
- GNN-dominant → relational structure drives outcomes
- LSTM-dominant → temporal dynamics matter
- Autoencoder-dominant → anomaly detection captures failures

This is Step 4d of the TESSERA workflow.
"""

import torch
import torch.nn as nn
import numpy as np

try:
    from ..core.safety import safe_array, safe_probabilities
except ImportError:
    safe_array = lambda arr, **kw: arr
    safe_probabilities = lambda arr, **kw: arr
from typing import Optional, Dict, Tuple


class TesseraEnsemble(nn.Module):
    """
    Ensemble meta-learner combining three signal sources.

    Architecture:
    - Input: GNN predictions + LSTM predictions + AE anomaly features
    - Learned weighted combination with interaction terms
    - Small MLP head for final prediction

    Parameters
    ----------
    n_ae_features : int
        Number of autoencoder anomaly features (default: 3).
    hidden_channels : int
        Hidden dimension of meta-learner MLP. Default: 16
    dropout : float
        Dropout rate. Default: 0.2
    """

    def __init__(
        self,
        n_ae_features: int = 3,
        hidden_channels: int = 16,
        dropout: float = 0.2,
    ):
        super().__init__()

        # Input: gnn_pred (1) + lstm_pred (1) + ae_features (3) = 5
        in_dim = 2 + n_ae_features

        self.meta_learner = nn.Sequential(
            nn.Linear(in_dim, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, hidden_channels // 2),
            nn.ReLU(),
            nn.Linear(hidden_channels // 2, 1),
        )

        # Interpretable component weights (for analysis)
        self.component_weights = nn.Parameter(torch.ones(3) / 3)

    def forward(
        self,
        gnn_pred: torch.Tensor,
        lstm_pred: torch.Tensor,
        ae_features: torch.Tensor,
    ) -> torch.Tensor:
        """
        Forward pass.

        Parameters
        ----------
        gnn_pred : Tensor (N,)
            GNN predicted probabilities.
        lstm_pred : Tensor (N,)
            LSTM predicted probabilities.
        ae_features : Tensor (N, 3)
            Autoencoder anomaly features.

        Returns
        -------
        Tensor (N,)
            Final ensemble predictions.
        """
        # Concatenate all signals
        x = torch.cat([
            gnn_pred.unsqueeze(-1),
            lstm_pred.unsqueeze(-1),
            ae_features,
        ], dim=-1)

        logits = self.meta_learner(x).squeeze(-1)
        return torch.sigmoid(logits)

    def get_component_importance(self) -> Dict[str, float]:
        """
        Compute relative importance of each signal source.

        Uses gradient-based attribution on the meta-learner's
        first layer weights.

        Returns
        -------
        dict
            Normalized importance scores for GNN, LSTM, Autoencoder.
        """
        first_layer = self.meta_learner[0]
        weights = first_layer.weight.detach().abs()

        # Sum of absolute weights connected to each input
        gnn_importance = weights[:, 0].sum().item()
        lstm_importance = weights[:, 1].sum().item()
        ae_importance = weights[:, 2:].sum().item()

        total = gnn_importance + lstm_importance + ae_importance
        if total > 0:
            gnn_importance /= total
            lstm_importance /= total
            ae_importance /= total

        return {
            "gnn": gnn_importance,
            "lstm": lstm_importance,
            "autoencoder": ae_importance,
        }


class TesseraTrainer:
    """
    Training pipeline for all TESSERA model components.

    Handles training of GNN, LSTM, autoencoder bank, and ensemble
    meta-learner, including proper train/val splitting.

    Parameters
    ----------
    device : str
        Device for training. Default: auto-detect.
    gnn_epochs : int
        Training epochs for GNN. Default: 200
    lstm_epochs : int
        Training epochs for LSTM. Default: 100
    ae_epochs : int
        Training epochs for autoencoders. Default: 100
    ensemble_epochs : int
        Training epochs for ensemble. Default: 50
    lr : float
        Learning rate. Default: 1e-3
    weight_decay : float
        L2 regularization. Default: 1e-4
    """

    def __init__(
        self,
        device: Optional[str] = None,
        gnn_epochs: int = 200,
        lstm_epochs: int = 100,
        ae_epochs: int = 100,
        ensemble_epochs: int = 50,
        lr: float = 1e-3,
        weight_decay: float = 1e-4,
    ):
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        self.gnn_epochs = gnn_epochs
        self.lstm_epochs = lstm_epochs
        self.ae_epochs = ae_epochs
        self.ensemble_epochs = ensemble_epochs
        self.lr = lr
        self.weight_decay = weight_decay

    def train_gnn(
        self,
        model,
        data,
        train_mask: np.ndarray,
        val_mask: np.ndarray,
        class_weight: Optional[float] = None,
    ) -> Dict[str, list]:
        """Train the GNN model."""
        model = model.to(self.device)
        data = data.to(self.device)

        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.lr, weight_decay=self.weight_decay
        )

        # Class weighting for imbalanced data
        if class_weight is None:
            n_pos = data.y[train_mask].sum().item()
            n_neg = train_mask.sum() - n_pos
            class_weight = n_neg / max(n_pos, 1)

        pos_weight = torch.tensor([class_weight], device=self.device)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        train_idx = torch.tensor(
            np.where(train_mask)[0], device=self.device
        )
        val_idx = torch.tensor(
            np.where(val_mask)[0], device=self.device
        )

        history = {"train_loss": [], "val_loss": [], "val_auc": []}

        for epoch in range(self.gnn_epochs):
            # Train
            model.train()
            optimizer.zero_grad()

            pred = model(data.x, data.edge_index, data.edge_attr)

            # Use raw logits for BCEWithLogitsLoss
            logits = torch.log(pred / (1 - pred + 1e-8) + 1e-8)
            loss = criterion(logits[train_idx], data.y[train_idx])

            loss.backward()
            optimizer.step()
            history["train_loss"].append(loss.item())

            # Validate
            model.eval()
            with torch.no_grad():
                pred = model(data.x, data.edge_index, data.edge_attr)
                logits = torch.log(pred / (1 - pred + 1e-8) + 1e-8)
                val_loss = criterion(logits[val_idx], data.y[val_idx])
                history["val_loss"].append(val_loss.item())

                # AUC
                try:
                    from sklearn.metrics import roc_auc_score
                    auc = roc_auc_score(
                        data.y[val_idx].cpu().numpy(),
                        pred[val_idx].cpu().numpy(),
                    )
                    history["val_auc"].append(auc)
                except (ValueError, ImportError):
                    history["val_auc"].append(0.5)

        return history

    def train_lstm(
        self,
        model,
        sequences: torch.Tensor,
        labels: torch.Tensor,
        train_mask: np.ndarray,
        val_mask: np.ndarray,
        class_weight: Optional[float] = None,
    ) -> Dict[str, list]:
        """Train the LSTM model."""
        model = model.to(self.device)
        sequences = sequences.to(self.device)
        labels = labels.to(self.device)

        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.lr, weight_decay=self.weight_decay
        )

        if class_weight is None:
            n_pos = labels[train_mask].sum().item()
            n_neg = train_mask.sum() - n_pos
            class_weight = n_neg / max(n_pos, 1)

        pos_weight = torch.tensor([class_weight], device=self.device)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        train_idx = torch.tensor(
            np.where(train_mask)[0], device=self.device
        )
        val_idx = torch.tensor(
            np.where(val_mask)[0], device=self.device
        )

        history = {"train_loss": [], "val_loss": []}

        for epoch in range(self.lstm_epochs):
            model.train()
            optimizer.zero_grad()

            pred = model(sequences[train_idx])
            logits = torch.log(pred / (1 - pred + 1e-8) + 1e-8)
            loss = criterion(logits, labels[train_idx])

            loss.backward()
            optimizer.step()
            history["train_loss"].append(loss.item())

            model.eval()
            with torch.no_grad():
                pred = model(sequences[val_idx])
                logits = torch.log(pred / (1 - pred + 1e-8) + 1e-8)
                val_loss = criterion(logits, labels[val_idx])
                history["val_loss"].append(val_loss.item())

        return history

    def train_ensemble(
        self,
        ensemble,
        gnn_preds: np.ndarray,
        lstm_preds: np.ndarray,
        ae_features: np.ndarray,
        labels: np.ndarray,
        train_mask: np.ndarray,
        val_mask: np.ndarray,
        class_weight: Optional[float] = None,
    ) -> Dict[str, list]:
        """Train the ensemble meta-learner."""
        ensemble = ensemble.to(self.device)

        gnn_t = torch.tensor(gnn_preds, dtype=torch.float32, device=self.device)
        lstm_t = torch.tensor(lstm_preds, dtype=torch.float32, device=self.device)
        ae_t = torch.tensor(ae_features, dtype=torch.float32, device=self.device)
        labels_t = torch.tensor(labels, dtype=torch.float32, device=self.device)

        optimizer = torch.optim.Adam(
            ensemble.parameters(), lr=self.lr
        )

        if class_weight is None:
            n_pos = labels[train_mask].sum()
            n_neg = train_mask.sum() - n_pos
            class_weight = n_neg / max(n_pos, 1)

        pos_weight = torch.tensor([class_weight], device=self.device)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        train_idx = torch.tensor(
            np.where(train_mask)[0], device=self.device
        )
        val_idx = torch.tensor(
            np.where(val_mask)[0], device=self.device
        )

        history = {"train_loss": [], "val_loss": []}

        for epoch in range(self.ensemble_epochs):
            ensemble.train()
            optimizer.zero_grad()

            pred = ensemble(
                gnn_t[train_idx], lstm_t[train_idx], ae_t[train_idx]
            )
            logits = torch.log(pred / (1 - pred + 1e-8) + 1e-8)
            loss = criterion(logits, labels_t[train_idx])

            loss.backward()
            optimizer.step()
            history["train_loss"].append(loss.item())

            ensemble.eval()
            with torch.no_grad():
                pred = ensemble(
                    gnn_t[val_idx], lstm_t[val_idx], ae_t[val_idx]
                )
                logits = torch.log(pred / (1 - pred + 1e-8) + 1e-8)
                val_loss = criterion(logits, labels_t[val_idx])
                history["val_loss"].append(val_loss.item())

        return history

    def predict_all(
        self,
        gnn_model,
        lstm_model,
        ae_bank,
        ensemble,
        gnn_data,
        lstm_sequences: torch.Tensor,
        features: np.ndarray,
        community_labels: np.ndarray,
    ) -> Dict[str, np.ndarray]:
        """
        Generate predictions from all components.

        Returns dict with predictions from each model and the ensemble.
        """
        gnn_data = gnn_data.to(self.device)
        lstm_sequences = lstm_sequences.to(self.device)

        with torch.no_grad():
            gnn_model.eval()
            gnn_preds = gnn_model(
                gnn_data.x, gnn_data.edge_index, gnn_data.edge_attr
            ).cpu().numpy()

            lstm_model.eval()
            lstm_preds = lstm_model(lstm_sequences).cpu().numpy()

            ae_features = ae_bank.compute_anomaly_features(
                features, community_labels
            )

            gnn_t = torch.tensor(
                gnn_preds, dtype=torch.float32, device=self.device
            )
            lstm_t = torch.tensor(
                lstm_preds, dtype=torch.float32, device=self.device
            )
            ae_t = torch.tensor(
                ae_features, dtype=torch.float32, device=self.device
            )

            ensemble.eval()
            ensemble_preds = ensemble(gnn_t, lstm_t, ae_t).cpu().numpy()

        return {
            "gnn": safe_probabilities(gnn_preds),
            "lstm": safe_probabilities(lstm_preds),
            "ae_features": safe_array(ae_features, clip_min=-1e6, clip_max=1e6),
            "ensemble": safe_probabilities(ensemble_preds),
        }
