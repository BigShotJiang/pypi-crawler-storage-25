"""
TESSERA Autoencoder

Per-community autoencoder for anomaly detection. Entities with high
reconstruction error are poorly described by their community's feature
profile — indicating they may sit at regime boundaries or in isolated
failure clusters.

The autoencoder does not predict outcomes directly. Instead, it
produces reconstruction error features that feed into the ensemble.

This is Step 4c of the TESSERA workflow.
"""

import torch
import torch.nn as nn
import numpy as np

try:
    from ..core.safety import safe_array
except ImportError:
    from tessera.core.safety import safe_array
from typing import Optional, Dict, List, Tuple


class TesseraAutoencoder(nn.Module):
    """
    Autoencoder for community-based anomaly detection.

    Architecture:
    - Encoder: input → hidden → latent
    - Decoder: latent → hidden → reconstructed input
    - Symmetric with tied dimensions

    Parameters
    ----------
    in_channels : int
        Input feature dimension.
    hidden_channels : int
        Hidden layer dimension. Default: 32
    latent_channels : int
        Latent space dimension. Default: 8
    dropout : float
        Dropout rate. Default: 0.2
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int = 32,
        latent_channels: int = 8,
        dropout: float = 0.2,
    ):
        super().__init__()

        self.in_channels = in_channels

        self.encoder = nn.Sequential(
            nn.Linear(in_channels, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, latent_channels),
            nn.ReLU(),
        )

        self.decoder = nn.Sequential(
            nn.Linear(latent_channels, hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, in_channels),
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass.

        Returns
        -------
        reconstructed : Tensor (N, D)
            Reconstructed features.
        latent : Tensor (N, latent_dim)
            Latent representations.
        """
        latent = self.encoder(x)
        reconstructed = self.decoder(latent)
        return reconstructed, latent

    def reconstruction_error(self, x: torch.Tensor) -> torch.Tensor:
        """
        Compute per-entity reconstruction error (MSE).

        Parameters
        ----------
        x : Tensor (N, D)

        Returns
        -------
        Tensor (N,)
            Per-entity MSE reconstruction error.
        """
        reconstructed, _ = self.forward(x)
        error = ((x - reconstructed) ** 2).mean(dim=1)
        return error


class CommunityAutoencoderBank:
    """
    Bank of autoencoders, one per community.

    Trains a separate autoencoder on each community's entities.
    At inference, each entity's reconstruction error from its
    own community's autoencoder AND from neighboring communities'
    autoencoders are computed — the contrast reveals boundary entities.

    Parameters
    ----------
    hidden_channels : int
        Hidden dim for each autoencoder. Default: 32
    latent_channels : int
        Latent dim. Default: 8
    dropout : float
        Dropout rate. Default: 0.2
    n_epochs : int
        Training epochs per autoencoder. Default: 100
    lr : float
        Learning rate. Default: 1e-3
    device : str
        Device. Default: "cpu"
    """

    def __init__(
        self,
        hidden_channels: int = 32,
        latent_channels: int = 8,
        dropout: float = 0.2,
        n_epochs: int = 100,
        lr: float = 1e-3,
        device: str = "cpu",
    ):
        self.hidden_channels = hidden_channels
        self.latent_channels = latent_channels
        self.dropout = dropout
        self.n_epochs = n_epochs
        self.lr = lr
        self.device = device

        self.autoencoders: Dict[int, TesseraAutoencoder] = {}
        self.is_trained = False

    def train_bank(
        self,
        features: np.ndarray,
        community_labels: np.ndarray,
        verbose: bool = False,
    ):
        """
        Train one autoencoder per community.

        Parameters
        ----------
        features : np.ndarray (N, D)
            Entity features.
        community_labels : np.ndarray (N,)
            Community assignments.
        verbose : bool
            Print training progress.
        """
        D = features.shape[1]
        unique_communities = np.unique(community_labels)

        for comm_id in unique_communities:
            comm_id = int(comm_id)
            mask = community_labels == comm_id
            comm_features = features[mask]

            if len(comm_features) < 5:
                # Too small to train meaningfully
                continue

            ae = TesseraAutoencoder(
                in_channels=D,
                hidden_channels=self.hidden_channels,
                latent_channels=self.latent_channels,
                dropout=self.dropout,
            ).to(self.device)

            optimizer = torch.optim.Adam(ae.parameters(), lr=self.lr)
            x = torch.tensor(
                comm_features, dtype=torch.float32, device=self.device
            )

            ae.train()
            for epoch in range(self.n_epochs):
                optimizer.zero_grad()
                reconstructed, _ = ae(x)
                loss = nn.functional.mse_loss(reconstructed, x)
                loss.backward()
                optimizer.step()

            if verbose:
                ae.eval()
                with torch.no_grad():
                    final_loss = nn.functional.mse_loss(
                        ae(x)[0], x
                    ).item()
                print(f"  Community {comm_id}: n={len(comm_features)}, "
                      f"final loss={final_loss:.6f}")

            ae.eval()
            self.autoencoders[comm_id] = ae

        self.is_trained = True

    def compute_anomaly_features(
        self,
        features: np.ndarray,
        community_labels: np.ndarray,
    ) -> np.ndarray:
        """
        Compute anomaly features for all entities.

        For each entity, computes:
        1. Reconstruction error from its own community's autoencoder
        2. Min reconstruction error across all other communities' AEs
        3. Ratio of (1) to (2) — high ratio = well-explained by own
           community, low ratio = better explained by another

        Returns
        -------
        np.ndarray (N, 3)
            [own_error, min_other_error, error_ratio] per entity.
        """
        if not self.is_trained:
            raise RuntimeError("Call train_bank() first")

        N = len(features)
        x_all = torch.tensor(
            features, dtype=torch.float32, device=self.device
        )

        # Compute reconstruction error from each community's AE
        n_comms = len(self.autoencoders)
        all_errors = np.full((N, n_comms), np.inf)

        comm_ids = sorted(self.autoencoders.keys())

        with torch.no_grad():
            for idx, comm_id in enumerate(comm_ids):
                ae = self.autoencoders[comm_id]
                errors = ae.reconstruction_error(x_all).cpu().numpy()
                all_errors[:, idx] = errors

        # Per-entity features
        anomaly_features = np.zeros((N, 3), dtype=np.float32)

        for i in range(N):
            own_comm = int(community_labels[i])

            if own_comm in self.autoencoders:
                own_idx = comm_ids.index(own_comm)
                own_error = all_errors[i, own_idx]
            else:
                own_error = np.inf

            # Min error from other communities
            other_errors = [
                all_errors[i, idx]
                for idx, cid in enumerate(comm_ids)
                if cid != own_comm
            ]
            min_other = min(other_errors) if other_errors else np.inf

            # Error ratio (own / min_other)
            # High = entity fits own community well relative to others
            # Low = entity is better explained by another community
            if min_other > 1e-10:
                ratio = own_error / min_other
            else:
                ratio = 1.0

            anomaly_features[i] = [own_error, min_other, ratio]

        # Sanitize: reconstruction errors can overflow for
        # entities far from any community's training distribution
        anomaly_features = safe_array(
            anomaly_features, clip_min=-1e6, clip_max=1e6,
            name="ae_anomaly_features"
        )
        # Sanitize: reconstruction errors can overflow for
        # entities far from any community's training distribution
        anomaly_features = safe_array(
            anomaly_features, clip_min=-1e6, clip_max=1e6,
            name="ae_anomaly_features"
        )
        return anomaly_features
