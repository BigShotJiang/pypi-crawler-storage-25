"""
TESSERA Regime Divergence

Quantifies the magnitude of response transitions at regime boundaries.
Adapted from Uyeda & Harmon (2014) bayou's regime divergence metric
for phylogenetic comparative data, generalized to similarity networks.

Regime divergence (RD) at a boundary between communities i and j:

    RD(i,j) = |R_i - R_j| / sqrt(σ²_i + σ²_j)

where R is the response rate and σ² is the within-community
response variance.

This is Step 3 of the TESSERA workflow:
  Characterize → Discover → **Quantify** → Predict → Test → Generalize
"""

import numpy as np

try:
    from .safety import safe_array
except ImportError:
    safe_array = lambda arr, **kw: arr
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field

from .community import CommunityStructure


@dataclass
class RegimeDivergenceMap:
    """
    Complete regime divergence landscape across the network.

    Contains pairwise RD between communities, per-entity local RD
    scores, and boundary classification. Optionally includes
    persistence-weighted RD that downweights transient regimes.
    """
    # Pairwise regime divergence between communities
    pairwise_rd: Dict[Tuple[int, int], float]

    # Per-community response statistics
    community_response_rates: Dict[int, float]
    community_response_vars: Dict[int, float]
    community_sizes: Dict[int, int]

    # Per-entity scores
    entity_rd_scores: np.ndarray        # (N,) local regime divergence
    entity_boundary_fraction: np.ndarray # (N,) fraction of cross-community neighbors

    # Persistence-weighted scores (None if persistence not provided)
    pairwise_rd_weighted: Optional[Dict[Tuple[int, int], float]] = None
    entity_rd_weighted: Optional[np.ndarray] = None
    community_persistence: Optional[Dict[int, float]] = None

    # Classification thresholds
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def n_entities(self) -> int:
        return len(self.entity_rd_scores)

    @property
    def max_rd(self) -> float:
        """Maximum pairwise regime divergence."""
        if not self.pairwise_rd:
            return 0.0
        return max(self.pairwise_rd.values())

    @property
    def mean_rd(self) -> float:
        """Mean pairwise regime divergence."""
        if not self.pairwise_rd:
            return 0.0
        return float(np.mean(list(self.pairwise_rd.values())))

    def classify_geometry(
        self,
        community_labels: np.ndarray,
        edge_index: np.ndarray,
        rd_threshold: float = 0.5,
        boundary_threshold: float = 0.3,
        isolation_threshold: float = 0.8,
    ) -> np.ndarray:
        """
        Classify each entity's local response geometry.

        Categories (continuous, but labeled for interpretation):
        - "boundary": high RD + high cross-community neighbor fraction
        - "isolated": entity in small community with high RD to all neighbors
        - "diffuse": low RD everywhere locally
        - "interior": deep within a community, low boundary fraction

        Parameters
        ----------
        community_labels : np.ndarray
            Community assignments.
        edge_index : np.ndarray
            (2, E) edge list.
        rd_threshold : float
            RD score above which a boundary is considered "sharp".
        boundary_threshold : float
            Cross-community neighbor fraction for boundary classification.
        isolation_threshold : float
            Fraction of entity's neighbors in different communities
            for isolated classification.

        Returns
        -------
        np.ndarray
            (N,) string array with geometry labels.
        """
        N = len(self.entity_rd_scores)
        geometry = np.full(N, "interior", dtype="U20")

        for i in range(N):
            rd = self.entity_rd_scores[i]
            bf = self.entity_boundary_fraction[i]
            comm = community_labels[i]
            comm_size = self.community_sizes.get(int(comm), 0)

            # Small community + high RD → isolated
            total_entities = sum(self.community_sizes.values())
            is_small = comm_size < (total_entities * 0.05)

            if is_small and rd > rd_threshold:
                geometry[i] = "isolated"
            elif rd > rd_threshold and bf > boundary_threshold:
                geometry[i] = "boundary"
            elif rd < rd_threshold * 0.5:
                geometry[i] = "diffuse"
            # else remains "interior"

        return geometry

    def summary(self) -> str:
        """Human-readable summary."""
        lines = [
            "TESSERA Regime Divergence Map",
            "=" * 50,
            f"Entities:              {self.n_entities}",
            f"Community pairs:       {len(self.pairwise_rd)}",
            f"Mean pairwise RD:      {self.mean_rd:.4f}",
            f"Max pairwise RD:       {self.max_rd:.4f}",
            "",
            "Per-community response rates:",
        ]

        for comm_id in sorted(self.community_response_rates.keys()):
            rate = self.community_response_rates[comm_id]
            var = self.community_response_vars[comm_id]
            size = self.community_sizes[comm_id]
            pers = ""
            if self.community_persistence is not None:
                p = self.community_persistence.get(comm_id, 0.0)
                status = "STABLE" if p > 0.8 else "TRANSIENT" if p < 0.3 else "moderate"
                pers = f"  persistence={p:.2f} [{status}]"
            lines.append(
                f"  Community {comm_id}: rate={rate:.3f}  "
                f"var={var:.4f}  n={size}{pers}"
            )

        lines.append("")
        lines.append("Entity RD score distribution:")
        scores = self.entity_rd_scores
        lines.append(f"  Mean:   {scores.mean():.4f}")
        lines.append(f"  Std:    {scores.std():.4f}")
        lines.append(f"  Median: {np.median(scores):.4f}")
        lines.append(f"  Max:    {scores.max():.4f}")

        # Persistence-weighted RD
        if self.entity_rd_weighted is not None:
            lines.append("")
            lines.append("Persistence-weighted entity RD:")
            w = self.entity_rd_weighted
            lines.append(f"  Mean:   {w.mean():.4f}")
            lines.append(f"  Std:    {w.std():.4f}")
            lines.append(f"  Max:    {w.max():.4f}")
            lines.append(f"  Attenuation: {1 - w.mean() / max(scores.mean(), 1e-10):.1%} "
                          f"reduction from raw RD")

        # Boundary entity count
        n_boundary = np.sum(self.entity_boundary_fraction > 0.3)
        lines.append(f"")
        lines.append(
            f"Boundary entities (>30% cross-community): "
            f"{n_boundary} ({100 * n_boundary / self.n_entities:.1f}%)"
        )

        return "\n".join(lines)


class RegimeDivergenceComputer:
    """
    Computes regime divergence across a community-structured network.

    Given community assignments and entity outcomes, computes:
    1. Pairwise RD between all adjacent community pairs
    2. Per-entity local RD scores based on neighborhood composition
    3. Response geometry classification

    Parameters
    ----------
    smoothing : float
        Laplace smoothing for response rate estimation in small
        communities. Default: 1.0
    min_community_size : int
        Minimum community size for reliable RD estimation.
        Communities smaller than this get pooled variance estimates.
        Default: 10
    """

    def __init__(
        self,
        smoothing: float = 1.0,
        min_community_size: int = 10,
    ):
        self.smoothing = smoothing
        self.min_community_size = min_community_size

    def compute(
        self,
        community_structure: CommunityStructure,
        outcomes: np.ndarray,
        edge_index: np.ndarray,
        edge_weights: Optional[np.ndarray] = None,
        persistence: Optional[Dict[int, float]] = None,
    ) -> RegimeDivergenceMap:
        """
        Compute the full regime divergence landscape.

        Parameters
        ----------
        community_structure : CommunityStructure
            Discovered community assignments.
        outcomes : np.ndarray
            (N,) binary outcome labels.
        edge_index : np.ndarray
            (2, E) edge list from TesseraGraph.
        edge_weights : np.ndarray, optional
            (E,) edge weights. Used for weighted RD computation.
        persistence : dict, optional
            {community_id: persistence_score} from CommunityPersistenceAnalyzer.
            If provided, computes persistence-weighted RD that downweights
            transient regime boundaries.

        Returns
        -------
        RegimeDivergenceMap
        """
        labels = community_structure.labels
        N = len(labels)

        # ── Step 1: Community-level response statistics ──────────
        comm_rates = {}
        comm_vars = {}
        comm_sizes = {}

        # Global pooled variance for small communities
        global_var = np.var(outcomes) if len(outcomes) > 0 else 1e-6

        for comm_id in range(community_structure.n_communities):
            mask = labels == comm_id
            n_comm = mask.sum()
            comm_sizes[comm_id] = int(n_comm)

            if n_comm == 0:
                comm_rates[comm_id] = 0.0
                comm_vars[comm_id] = global_var
                continue

            comm_outcomes = outcomes[mask]

            # Laplace-smoothed response rate
            rate = (comm_outcomes.sum() + self.smoothing) / \
                   (n_comm + 2 * self.smoothing)
            comm_rates[comm_id] = float(rate)

            # Within-community variance
            if n_comm >= self.min_community_size:
                comm_vars[comm_id] = float(np.var(comm_outcomes))
            else:
                # Pool with global variance for small communities
                comm_vars[comm_id] = float(
                    (np.var(comm_outcomes) + global_var) / 2
                )

        # ── Step 2: Pairwise regime divergence ───────────────────
        boundary_pairs = community_structure.find_boundary_pairs(edge_index)
        pairwise_rd = {}

        for ci, cj in boundary_pairs:
            rd = self._compute_rd(
                comm_rates[ci], comm_rates[cj],
                comm_vars[ci], comm_vars[cj],
            )
            pairwise_rd[(ci, cj)] = rd

        # ── Step 3: Per-entity local regime divergence ───────────
        entity_rd = np.zeros(N)
        entity_bf = np.zeros(N)  # boundary fraction

        for node in range(N):
            neighbor_mask = edge_index[0] == node
            neighbors = edge_index[1, neighbor_mask]

            if len(neighbors) == 0:
                continue

            node_comm = labels[node]
            neighbor_comms = labels[neighbors]

            # Boundary fraction: proportion of neighbors in other communities
            n_cross = np.sum(neighbor_comms != node_comm)
            entity_bf[node] = n_cross / len(neighbors)

            # Local RD: weighted average of RD to each neighboring community
            if edge_weights is not None:
                local_weights = edge_weights[neighbor_mask]
            else:
                local_weights = np.ones(len(neighbors))

            # Group neighbors by community
            unique_neighbor_comms = np.unique(neighbor_comms)
            weighted_rd_sum = 0.0
            weight_sum = 0.0

            for nc in unique_neighbor_comms:
                if nc == node_comm:
                    continue

                pair = (min(node_comm, nc), max(node_comm, nc))
                rd = pairwise_rd.get(pair, 0.0)

                # Weight by number of neighbors in this community
                nc_mask = neighbor_comms == nc
                w = local_weights[nc_mask].sum()

                weighted_rd_sum += rd * w
                weight_sum += w

            if weight_sum > 0:
                entity_rd[node] = weighted_rd_sum / weight_sum

        # ── Sanitize RD scores ────────────────────────────────
        entity_rd = safe_array(entity_rd, clip_min=0, clip_max=100,
                               name="entity_rd_scores")
        entity_bf = safe_array(entity_bf, clip_min=0, clip_max=1,
                               name="entity_boundary_fraction")

        # ── Sanitize RD scores ────────────────────────────────
        entity_rd = safe_array(entity_rd, clip_min=0, clip_max=100,
                               name="entity_rd_scores")
        entity_bf = safe_array(entity_bf, clip_min=0, clip_max=1,
                               name="entity_boundary_fraction")

        # ── Step 4: Persistence-weighted RD (if available) ─────
        pairwise_rd_weighted = None
        entity_rd_weighted = None

        if persistence is not None:
            # Weighted pairwise RD:
            #   RD_w(i,j) = RD(i,j) × persistence(i) × persistence(j)
            # High-RD boundary between two persistent communities = reliable signal
            # High-RD boundary with transient community = downweighted
            pairwise_rd_weighted = {}
            for (ci, cj), rd in pairwise_rd.items():
                p_i = persistence.get(ci, 0.0)
                p_j = persistence.get(cj, 0.0)
                pairwise_rd_weighted[(ci, cj)] = rd * p_i * p_j

            # Per-entity weighted RD
            entity_rd_weighted = np.zeros(N)
            for node in range(N):
                neighbor_mask = edge_index[0] == node
                neighbors = edge_index[1, neighbor_mask]

                if len(neighbors) == 0:
                    continue

                node_comm = labels[node]
                neighbor_comms = labels[neighbors]

                if edge_weights is not None:
                    local_weights = edge_weights[neighbor_mask]
                else:
                    local_weights = np.ones(len(neighbors))

                unique_neighbor_comms = np.unique(neighbor_comms)
                weighted_rd_sum = 0.0
                weight_sum = 0.0

                for nc in unique_neighbor_comms:
                    if nc == node_comm:
                        continue

                    pair = (min(node_comm, nc), max(node_comm, nc))
                    rd_w = pairwise_rd_weighted.get(pair, 0.0)

                    nc_mask = neighbor_comms == nc
                    w = local_weights[nc_mask].sum()

                    weighted_rd_sum += rd_w * w
                    weight_sum += w

                if weight_sum > 0:
                    entity_rd_weighted[node] = weighted_rd_sum / weight_sum

        # ── Build result ─────────────────────────────────────────
        return RegimeDivergenceMap(
            pairwise_rd=pairwise_rd,
            community_response_rates=comm_rates,
            community_response_vars=comm_vars,
            community_sizes=comm_sizes,
            entity_rd_scores=entity_rd,
            entity_boundary_fraction=entity_bf,
            pairwise_rd_weighted=pairwise_rd_weighted,
            entity_rd_weighted=entity_rd_weighted,
            community_persistence=persistence,
            metadata={
                "smoothing": self.smoothing,
                "min_community_size": self.min_community_size,
                "n_boundary_pairs": len(boundary_pairs),
                "persistence_weighted": persistence is not None,
            },
        )

    @staticmethod
    def _compute_rd(
        rate_i: float,
        rate_j: float,
        var_i: float,
        var_j: float,
        max_rd: float = 10.0,
    ) -> float:
        """
        Compute regime divergence between two communities.

        RD(i,j) = |R_i - R_j| / sqrt(σ²_i + σ²_j)

        Analogous to Uyeda & Harmon (2014) regime divergence:
        shift magnitude normalized by stationary variance.

        Capped at max_rd to avoid inf from zero-variance communities.
        """
        denom = np.sqrt(var_i + var_j)

        if denom < 1e-10:
            if abs(rate_i - rate_j) > 1e-10:
                return max_rd
            return 0.0

        return float(min(abs(rate_i - rate_j) / denom, max_rd))
