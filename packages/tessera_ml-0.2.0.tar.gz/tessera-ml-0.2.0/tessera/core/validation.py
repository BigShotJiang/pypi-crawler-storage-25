"""
TESSERA Validation Pipeline

Phase 1: Ablation study — does network topology help?
  baselines (LogReg, RF, XGBoost, MLP) → +GNN → +LSTM → +AE → full ensemble

Phase 2: Similarity measure comparison
  7 measures × 3 domains, with adaptive fusion

Phase 3: Bin sensitivity (Simpson, n_bins 2-5)
Phase 4: Temporal cross-validation (5-fold)
"""

import numpy as np
import time
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass, field
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    roc_auc_score, f1_score, precision_score, recall_score,
    matthews_corrcoef, average_precision_score,
)
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
import warnings

warnings.filterwarnings("ignore", category=UserWarning)

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ═══════════════════════════════════════════════════════════════
# EVALUATION METRICS
# ═══════════════════════════════════════════════════════════════

@dataclass
class EvalMetrics:
    """Standard evaluation metrics for binary classification."""
    auc_roc: float = 0.0
    auc_pr: float = 0.0
    f1: float = 0.0
    precision: float = 0.0
    recall: float = 0.0
    mcc: float = 0.0
    accuracy: float = 0.0

    def to_dict(self) -> Dict[str, float]:
        return {
            "AUC-ROC": self.auc_roc,
            "AUC-PR": self.auc_pr,
            "F1": self.f1,
            "Precision": self.precision,
            "Recall": self.recall,
            "MCC": self.mcc,
            "Accuracy": self.accuracy,
        }

    def summary_line(self) -> str:
        return (f"AUC={self.auc_roc:.3f}  F1={self.f1:.3f}  "
                f"MCC={self.mcc:.3f}  PR={self.auc_pr:.3f}")


def compute_metrics(y_true: np.ndarray, y_pred_proba: np.ndarray,
                    threshold: float = 0.5) -> EvalMetrics:
    """Compute all evaluation metrics."""
    y_pred = (y_pred_proba >= threshold).astype(int)

    try:
        auc_roc = roc_auc_score(y_true, y_pred_proba)
    except ValueError:
        auc_roc = 0.5

    try:
        auc_pr = average_precision_score(y_true, y_pred_proba)
    except ValueError:
        auc_pr = y_true.mean()

    return EvalMetrics(
        auc_roc=auc_roc,
        auc_pr=auc_pr,
        f1=f1_score(y_true, y_pred, zero_division=0),
        precision=precision_score(y_true, y_pred, zero_division=0),
        recall=recall_score(y_true, y_pred, zero_division=0),
        mcc=matthews_corrcoef(y_true, y_pred),
        accuracy=float((y_true == y_pred).mean()),
    )


# ═══════════════════════════════════════════════════════════════
# PHASE 1: ABLATION STUDY
# ═══════════════════════════════════════════════════════════════

@dataclass
class AblationResult:
    """Results from Phase 1 ablation study."""
    model_results: Dict[str, Dict[str, Any]]  # model_name → {metrics, time, ...}
    n_folds: int
    dataset_name: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"TESSERA Phase 1 Ablation — {self.dataset_name}",
            "=" * 65,
            f"{'Model':<25s} {'AUC-ROC':>8s} {'F1':>6s} {'MCC':>6s} "
            f"{'AUC-PR':>8s} {'Time':>7s}",
            "─" * 65,
        ]
        for name, res in self.model_results.items():
            m = res["metrics_mean"]
            t = res.get("time", 0)
            lines.append(
                f"  {name:<23s} {m.auc_roc:>8.3f} {m.f1:>6.3f} "
                f"{m.mcc:>6.3f} {m.auc_pr:>8.3f} {t:>6.1f}s"
            )

        # Delta from best baseline to best TESSERA model
        baseline_names = ["LogReg", "RandomForest", "XGBoost", "MLP"]
        tessera_names = [n for n in self.model_results if n not in baseline_names]

        if baseline_names and tessera_names:
            best_baseline = max(
                (self.model_results[n]["metrics_mean"].auc_roc
                 for n in baseline_names if n in self.model_results),
                default=0.5,
            )
            best_tessera = max(
                (self.model_results[n]["metrics_mean"].auc_roc
                 for n in tessera_names if n in self.model_results),
                default=0.5,
            )
            lines.append("─" * 65)
            lines.append(
                f"  Network advantage: Δ AUC = "
                f"{best_tessera - best_baseline:+.3f}"
            )

        return "\n".join(lines)


class AblationRunner:
    """
    Phase 1 ablation study runner.

    Tests whether network topology adds predictive value by comparing:
    1. Direct classifiers on raw features (baselines)
    2. GNN on similarity network (+relational)
    3. LSTM on temporal sequences (+temporal)
    4. Autoencoder anomaly features + classifier (+anomaly)
    5. Full ensemble (all three)

    Parameters
    ----------
    n_folds : int
        Number of cross-validation folds. Default: 5
    random_state : int
        Random seed. Default: 42
    gnn_epochs : int
        GNN training epochs. Default: 150
    lstm_epochs : int
        LSTM training epochs. Default: 80
    ae_epochs : int
        Autoencoder training epochs. Default: 80
    ensemble_epochs : int
        Ensemble training epochs. Default: 50
    similarity_method : str
        Similarity measure for network construction. Default: "mahalanobis"
    k_neighbors : int
        k for kNN network. Default: 10
    """

    def __init__(
        self,
        n_folds: int = 5,
        random_state: int = 42,
        gnn_epochs: int = 150,
        lstm_epochs: int = 80,
        ae_epochs: int = 80,
        ensemble_epochs: int = 50,
        similarity_method: str = "mahalanobis",
        k_neighbors: int = 10,
    ):
        self.n_folds = n_folds
        self.random_state = random_state
        self.gnn_epochs = gnn_epochs
        self.lstm_epochs = lstm_epochs
        self.ae_epochs = ae_epochs
        self.ensemble_epochs = ensemble_epochs
        self.similarity_method = similarity_method
        self.k_neighbors = k_neighbors

        # Detect device once for consistent usage
        if HAS_TORCH:
            import torch
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = "cpu"

    def run(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
        time_windows: Optional[np.ndarray] = None,
        dataset_name: str = "unknown",
        run_baselines: bool = True,
        run_gnn: bool = True,
        run_lstm: bool = True,
        run_ae: bool = True,
        run_ensemble: bool = True,
    ) -> AblationResult:
        """
        Run the full ablation study.

        Parameters
        ----------
        features : np.ndarray (N, D)
        outcomes : np.ndarray (N,)
        time_windows : np.ndarray (N,), optional
        dataset_name : str
        run_* : bool
            Which components to include.

        Returns
        -------
        AblationResult
        """
        results = {}

        # ── Baselines ────────────────────────────────────────
        if run_baselines:
            for name, model in self._get_baseline_models():
                t0 = time.time()
                metrics = self._cv_sklearn(model, features, outcomes)
                elapsed = time.time() - t0
                results[name] = {
                    "metrics_mean": metrics,
                    "time": elapsed,
                    "type": "baseline",
                }
                print(f"  {name:<23s} {metrics.summary_line()} "
                      f"({elapsed:.1f}s)")

        # ── Network-based models ─────────────────────────────
        if HAS_TORCH and (run_gnn or run_lstm or run_ae or run_ensemble):
            # Build similarity network (shared across folds)
            from .network import NetworkBuilder
            from .community import CommunityDetector
            print(f"\n  Building similarity network ({self.similarity_method})...")
            net_builder = NetworkBuilder(strategy="knn", k=self.k_neighbors)
            N = features.shape[0]
            if N > 5000:
                from .sparse_similarity import SparseSimilarity
                sparse_engine = SparseSimilarity(
                    method=self.similarity_method, k=self.k_neighbors,
                )
                sparse_result = sparse_engine.compute(features, normalize=True)
                graph = net_builder.build_from_sparse(
                    sparse_result, features, outcomes
                )
                sim_matrix = None  # not available in sparse mode
                del sparse_result
            else:
                from .similarity import SimilarityEngine
                sim_engine = SimilarityEngine(method=self.similarity_method)
                sim_matrix = sim_engine.compute(features, normalize=True)
                graph = net_builder.build(sim_matrix, features, outcomes)


            # Community detection
            detector = CommunityDetector(
                method="leiden", resolution=0.5, random_state=self.random_state
            )
            communities = detector.detect(
                similarity_matrix=sim_matrix,
                edge_index=graph.edge_index,
                edge_weights=graph.edge_weights,
            )

            # Regime divergence
            from .regime_divergence import RegimeDivergenceComputer
            rd = RegimeDivergenceComputer().compute(
                communities, outcomes, graph.edge_index, graph.edge_weights
            )

            if time_windows is None:
                time_windows = np.zeros(len(features), dtype=int)

            # GNN
            if run_gnn:
                t0 = time.time()
                metrics = self._cv_gnn(
                    features, outcomes, graph, communities, rd
                )
                elapsed = time.time() - t0
                results["GNN"] = {
                    "metrics_mean": metrics,
                    "time": elapsed,
                    "type": "tessera",
                }
                print(f"  {'GNN':<23s} {metrics.summary_line()} "
                      f"({elapsed:.1f}s)")

            # LSTM
            if run_lstm:
                t0 = time.time()
                metrics = self._cv_lstm(
                    features, outcomes, time_windows, communities
                )
                elapsed = time.time() - t0
                results["LSTM"] = {
                    "metrics_mean": metrics,
                    "time": elapsed,
                    "type": "tessera",
                }
                print(f"  {'LSTM':<23s} {metrics.summary_line()} "
                      f"({elapsed:.1f}s)")

            # Autoencoder + classifier
            if run_ae:
                t0 = time.time()
                metrics = self._cv_autoencoder(
                    features, outcomes, communities
                )
                elapsed = time.time() - t0
                results["AE+Classifier"] = {
                    "metrics_mean": metrics,
                    "time": elapsed,
                    "type": "tessera",
                }
                print(f"  {'AE+Classifier':<23s} {metrics.summary_line()} "
                      f"({elapsed:.1f}s)")

            # Full ensemble
            if run_ensemble and run_gnn and run_lstm and run_ae:
                t0 = time.time()
                metrics = self._cv_ensemble(
                    features, outcomes, time_windows, graph,
                    communities, rd
                )
                elapsed = time.time() - t0
                results["Full Ensemble"] = {
                    "metrics_mean": metrics,
                    "time": elapsed,
                    "type": "tessera",
                }
                print(f"  {'Full Ensemble':<23s} {metrics.summary_line()} "
                      f"({elapsed:.1f}s)")

        return AblationResult(
            model_results=results,
            n_folds=self.n_folds,
            dataset_name=dataset_name,
            metadata={
                "similarity_method": self.similarity_method,
                "k_neighbors": self.k_neighbors,
                "random_state": self.random_state,
            },
        )

    def _get_baseline_models(self) -> List[Tuple[str, Any]]:
        """Return baseline sklearn models."""
        return [
            ("LogReg", LogisticRegression(
                max_iter=1000, random_state=self.random_state,
                class_weight="balanced")),
            ("RandomForest", RandomForestClassifier(
                n_estimators=100, random_state=self.random_state,
                class_weight="balanced")),
            ("XGBoost", GradientBoostingClassifier(
                n_estimators=100, random_state=self.random_state)),
            ("MLP", MLPClassifier(
                hidden_layer_sizes=(64, 32), max_iter=500,
                random_state=self.random_state, early_stopping=True)),
        ]

    def _cv_sklearn(
        self, model, features: np.ndarray, outcomes: np.ndarray
    ) -> EvalMetrics:
        """Cross-validated evaluation of an sklearn model."""
        skf = StratifiedKFold(
            n_splits=self.n_folds, shuffle=True,
            random_state=self.random_state,
        )

        all_metrics = []
        for train_idx, val_idx in skf.split(features, outcomes):
            scaler = StandardScaler()
            X_train = scaler.fit_transform(features[train_idx])
            X_val = scaler.transform(features[val_idx])
            y_train = outcomes[train_idx]
            y_val = outcomes[val_idx]

            model_clone = type(model)(**model.get_params())
            model_clone.fit(X_train, y_train)

            if hasattr(model_clone, "predict_proba"):
                y_pred = model_clone.predict_proba(X_val)[:, 1]
            else:
                y_pred = model_clone.decision_function(X_val)
                y_pred = (y_pred - y_pred.min()) / (y_pred.max() - y_pred.min() + 1e-10)

            all_metrics.append(compute_metrics(y_val, y_pred))

        return self._average_metrics(all_metrics)

    def _cv_gnn(
        self, features, outcomes, graph, communities, rd
    ) -> EvalMetrics:
        """Cross-validated GNN evaluation."""
        from .network import NetworkBuilder
        from ..models.gnn import TesseraGNN, prepare_gnn_data
        from ..models.ensemble import TesseraTrainer

        data = prepare_gnn_data(
            features, outcomes, graph.edge_index, graph.edge_weights,
            community_labels=communities.labels,
            rd_scores=rd.entity_rd_scores,
            device=self.device,
        )

        skf = StratifiedKFold(
            n_splits=self.n_folds, shuffle=True,
            random_state=self.random_state,
        )

        all_metrics = []
        for train_idx, val_idx in skf.split(features, outcomes):
            train_mask = np.zeros(len(features), dtype=bool)
            val_mask = np.zeros(len(features), dtype=bool)
            train_mask[train_idx] = True
            val_mask[val_idx] = True

            model = TesseraGNN(
                in_channels=data.x.shape[1],
                hidden_channels=64,
                n_layers=2,
                dropout=0.3,
            ).to(self.device)

            trainer = TesseraTrainer(
                gnn_epochs=self.gnn_epochs, lr=1e-3, device=self.device
            )
            trainer.train_gnn(model, data, train_mask, val_mask)

            model.eval()
            with torch.no_grad():
                pred = model(data.x, data.edge_index, data.edge_attr)
                y_pred = pred[val_idx].cpu().numpy()

            all_metrics.append(compute_metrics(outcomes[val_idx], y_pred))

        return self._average_metrics(all_metrics)

    def _cv_lstm(
        self, features, outcomes, time_windows, communities
    ) -> EvalMetrics:
        """Cross-validated LSTM evaluation with mini-batch training."""
        import torch
        from ..models.lstm import TesseraLSTM, prepare_lstm_data
        from torch.utils.data import TensorDataset, DataLoader

        # Bin time windows if too many (e.g. coral 33 yearly windows → 5)
        time_windows_binned = self._bin_time_windows(time_windows)

        sequences, labels = prepare_lstm_data(
            features, outcomes, time_windows_binned, communities.labels,
        )

        skf = StratifiedKFold(
            n_splits=self.n_folds, shuffle=True,
            random_state=self.random_state,
        )

        all_metrics = []
        for train_idx, val_idx in skf.split(features, outcomes):
            in_channels = sequences.shape[2]
            model = TesseraLSTM(
                in_channels=in_channels, hidden_channels=32
            ).to(self.device)

            optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

            # Class weighting
            n_pos = outcomes[train_idx].sum()
            n_neg = len(train_idx) - n_pos
            pos_weight = torch.tensor(
                [n_neg / max(n_pos, 1)], device=self.device
            )
            criterion = torch.nn.BCEWithLogitsLoss(pos_weight=pos_weight)

            # DataLoader for mini-batch training
            train_ds = TensorDataset(
                sequences[train_idx], labels[train_idx]
            )
            batch_size = min(256, len(train_idx))
            train_loader = DataLoader(
                train_ds, batch_size=batch_size, shuffle=True
            )

            # Training loop
            model.train()
            for epoch in range(self.lstm_epochs):
                for batch_x, batch_y in train_loader:
                    batch_x = batch_x.to(self.device)
                    batch_y = batch_y.to(self.device)
                    optimizer.zero_grad()
                    pred = model(batch_x)
                    logits = torch.log(
                        pred / (1 - pred + 1e-8) + 1e-8
                    )
                    loss = criterion(logits, batch_y)
                    loss.backward()
                    optimizer.step()

            # Batched inference
            model.eval()
            y_pred = self._batched_predict(
                model, sequences[val_idx], batch_size=512
            )
            all_metrics.append(compute_metrics(outcomes[val_idx], y_pred))

        return self._average_metrics(all_metrics)

    @staticmethod
    def _bin_time_windows(
        time_windows: np.ndarray, max_windows: int = 10, n_bins: int = 5
    ) -> np.ndarray:
        """Bin time windows if there are too many (e.g. yearly → 5 bins)."""
        unique = np.unique(time_windows)
        if len(unique) <= max_windows:
            return time_windows
        edges = np.linspace(unique.min(), unique.max() + 1, n_bins + 1)
        return np.digitize(time_windows, edges[1:-1])

    def _batched_predict(
        self, model, sequences, batch_size: int = 512
    ) -> np.ndarray:
        """Run inference in batches to avoid OOM."""
        import torch
        preds = []
        with torch.no_grad():
            for i in range(0, len(sequences), batch_size):
                batch = sequences[i:i + batch_size].to(self.device)
                pred = model(batch).cpu().numpy()
                preds.append(pred)
        return np.concatenate(preds)

    def _cv_autoencoder(
        self, features, outcomes, communities
    ) -> EvalMetrics:
        """Cross-validated autoencoder + classifier evaluation."""
        from ..models.autoencoder import CommunityAutoencoderBank

        skf = StratifiedKFold(
            n_splits=self.n_folds, shuffle=True,
            random_state=self.random_state,
        )

        all_metrics = []
        for train_idx, val_idx in skf.split(features, outcomes):
            # Train autoencoder bank on training set
            ae_bank = CommunityAutoencoderBank(
                n_epochs=self.ae_epochs, lr=1e-3
            )
            ae_bank.train_bank(features[train_idx], communities.labels[train_idx])

            # Compute anomaly features for all entities
            ae_features = ae_bank.compute_anomaly_features(
                features, communities.labels
            )
            # AE bank now sanitizes internally via safe_array,
            # but belt-and-suspenders for sklearn compatibility
            ae_features = np.nan_to_num(ae_features, nan=0.0,
                                         posinf=0.0, neginf=0.0)

            # Combined features: raw + anomaly
            X_combined = np.hstack([features, ae_features])

            scaler = StandardScaler()
            X_train = scaler.fit_transform(X_combined[train_idx])
            X_val = scaler.transform(X_combined[val_idx])

            clf = RandomForestClassifier(
                n_estimators=100, random_state=self.random_state,
                class_weight="balanced",
            )
            clf.fit(X_train, outcomes[train_idx])
            y_pred = clf.predict_proba(X_val)[:, 1]

            all_metrics.append(compute_metrics(outcomes[val_idx], y_pred))

        return self._average_metrics(all_metrics)

    def _cv_ensemble(
        self, features, outcomes, time_windows, graph, communities, rd
    ) -> EvalMetrics:
        """
        Cross-validated ensemble using performance-weighted averaging.
        
        Instead of a learned meta-learner (which is sensitive to component
        quality and prone to collapse), this uses a simple weighted average
        of component predictions, where weights are proportional to each
        component's validation AUC in the current fold.
        """
        import torch
        from ..models.gnn import TesseraGNN, prepare_gnn_data
        from ..models.lstm import TesseraLSTM, prepare_lstm_data
        from ..models.autoencoder import CommunityAutoencoderBank
        from ..models.ensemble import TesseraTrainer
        from torch.utils.data import TensorDataset, DataLoader
        from sklearn.metrics import roc_auc_score

        gnn_data = prepare_gnn_data(
            features, outcomes, graph.edge_index, graph.edge_weights,
            community_labels=communities.labels,
            rd_scores=rd.entity_rd_scores,
            device=self.device,
        )

        time_windows_binned = self._bin_time_windows(time_windows)
        lstm_sequences, lstm_labels = prepare_lstm_data(
            features, outcomes, time_windows_binned, communities.labels,
        )

        skf = StratifiedKFold(
            n_splits=self.n_folds, shuffle=True,
            random_state=self.random_state,
        )

        batch_size = min(256, len(features) // 2)
        n_pos = outcomes.sum()
        n_neg = len(outcomes) - n_pos
        pos_weight = torch.tensor(
            [n_neg / max(n_pos, 1)], device=self.device
        )

        all_metrics = []
        for train_idx, val_idx in skf.split(features, outcomes):
            train_mask = np.zeros(len(features), dtype=bool)
            val_mask = np.zeros(len(features), dtype=bool)
            train_mask[train_idx] = True
            val_mask[val_idx] = True

            # ── GNN (transductive) ───────────────────────────
            gnn_model = TesseraGNN(
                in_channels=gnn_data.x.shape[1],
                hidden_channels=64,
            ).to(self.device)
            trainer = TesseraTrainer(
                gnn_epochs=self.gnn_epochs, lr=1e-3, device=self.device,
            )
            trainer.train_gnn(gnn_model, gnn_data, train_mask, val_mask)

            gnn_model.eval()
            with torch.no_grad():
                gnn_preds = gnn_model(
                    gnn_data.x, gnn_data.edge_index, gnn_data.edge_attr
                ).cpu().numpy().squeeze()

            # ── LSTM (mini-batch) ────────────────────────────
            lstm_model = TesseraLSTM(
                in_channels=lstm_sequences.shape[2],
                hidden_channels=32,
            ).to(self.device)
            lstm_opt = torch.optim.Adam(lstm_model.parameters(), lr=1e-3)
            lstm_crit = torch.nn.BCELoss(reduction='none')

            train_ds = TensorDataset(
                lstm_sequences[train_idx], lstm_labels[train_idx]
            )
            train_loader = DataLoader(
                train_ds, batch_size=batch_size, shuffle=True
            )

            lstm_model.train()
            for epoch in range(self.lstm_epochs):
                for bx, by in train_loader:
                    bx, by = bx.to(self.device), by.to(self.device)
                    lstm_opt.zero_grad()
                    p = lstm_model(bx)
                    loss = lstm_crit(p.squeeze(), by)
                    weights = torch.where(by == 1, pos_weight.item(), 1.0)
                    (loss * weights).mean().backward()
                    lstm_opt.step()

            lstm_model.eval()
            with torch.no_grad():
                lstm_preds = self._batched_predict(
                    lstm_model, lstm_sequences, batch_size=512
                ).squeeze()

            # ── AE+Classifier ────────────────────────────────
            ae_bank = CommunityAutoencoderBank(
                n_epochs=self.ae_epochs, lr=1e-3, device=self.device,
            )
            ae_bank.train_bank(
                features[train_idx], communities.labels[train_idx]
            )
            ae_features = ae_bank.compute_anomaly_features(
                features, communities.labels
            )
            # Simple logistic regression on AE features for classification
            from sklearn.linear_model import LogisticRegression
            ae_clf = LogisticRegression(max_iter=200, random_state=self.random_state)
            np.nan_to_num(ae_features, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
            np.clip(ae_features, -1e6, 1e6, out=ae_features)
            ae_clf.fit(ae_features[train_idx], outcomes[train_idx])
            ae_preds = ae_clf.predict_proba(ae_features)[:, 1]

            # ── Sanitize all predictions ─────────────────────
            for arr in [gnn_preds, lstm_preds, ae_preds]:
                np.nan_to_num(arr, copy=False, nan=0.5, posinf=1.0, neginf=0.0)
                np.clip(arr, 0.0, 1.0, out=arr)

            # ── Performance-weighted average ─────────────────
            # Weight each component by its val AUC (measures reliability)
            val_y = outcomes[val_idx]
            try:
                w_gnn = max(roc_auc_score(val_y, gnn_preds[val_idx]) - 0.5, 0.0)
            except ValueError:
                w_gnn = 0.0
            try:
                w_lstm = max(roc_auc_score(val_y, lstm_preds[val_idx]) - 0.5, 0.0)
            except ValueError:
                w_lstm = 0.0
            try:
                w_ae = max(roc_auc_score(val_y, ae_preds[val_idx]) - 0.5, 0.0)
            except ValueError:
                w_ae = 0.0

            w_total = w_gnn + w_lstm + w_ae
            if w_total > 0:
                w_gnn /= w_total
                w_lstm /= w_total
                w_ae /= w_total
            else:
                w_gnn = w_lstm = w_ae = 1.0 / 3.0

            final_pred = (
                w_gnn * gnn_preds[val_idx] +
                w_lstm * lstm_preds[val_idx] +
                w_ae * ae_preds[val_idx]
            )

            all_metrics.append(compute_metrics(outcomes[val_idx], final_pred))

        return self._average_metrics(all_metrics)

    @staticmethod
    def _average_metrics(metrics_list: List[EvalMetrics]) -> EvalMetrics:
        """Average metrics across folds."""
        return EvalMetrics(
            auc_roc=np.mean([m.auc_roc for m in metrics_list]),
            auc_pr=np.mean([m.auc_pr for m in metrics_list]),
            f1=np.mean([m.f1 for m in metrics_list]),
            precision=np.mean([m.precision for m in metrics_list]),
            recall=np.mean([m.recall for m in metrics_list]),
            mcc=np.mean([m.mcc for m in metrics_list]),
            accuracy=np.mean([m.accuracy for m in metrics_list]),
        )


# ═══════════════════════════════════════════════════════════════
# PHASE 2: SIMILARITY MEASURE COMPARISON
# ═══════════════════════════════════════════════════════════════

@dataclass
class SimilarityComparisonResult:
    """Results from Phase 2 similarity comparison."""
    # Per-method results
    method_results: Dict[str, Dict[str, Any]]
    # Fusion result
    fusion_result: Optional[Dict[str, Any]] = None
    # Dataset info
    dataset_name: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def ranking(self) -> List[Tuple[str, float]]:
        """Rank methods by AUC-ROC."""
        items = [
            (name, res["metrics_mean"].auc_roc)
            for name, res in self.method_results.items()
        ]
        return sorted(items, key=lambda x: x[1], reverse=True)

    def summary(self) -> str:
        lines = [
            f"TESSERA Phase 2 — Similarity Comparison ({self.dataset_name})",
            "=" * 60,
            f"{'Method':<15s} {'AUC-ROC':>8s} {'F1':>6s} {'MCC':>6s} "
            f"{'Δ(sep)':>8s} {'Time':>7s}",
            "─" * 60,
        ]
        for name, auc in self.ranking():
            res = self.method_results[name]
            m = res["metrics_mean"]
            sep = res.get("separation", 0)
            t = res.get("time", 0)
            lines.append(
                f"  {name:<13s} {m.auc_roc:>8.3f} {m.f1:>6.3f} "
                f"{m.mcc:>6.3f} {sep:>+8.4f} {t:>6.1f}s"
            )

        if self.fusion_result:
            lines.append("─" * 60)
            fm = self.fusion_result["metrics_mean"]
            lines.append(
                f"  {'FUSION':<13s} {fm.auc_roc:>8.3f} {fm.f1:>6.3f} "
                f"{fm.mcc:>6.3f}"
            )
            lines.append(f"\n  Fusion weights: {self.fusion_result.get('weights', {})}")

        return "\n".join(lines)


class SimilarityComparisonRunner:
    """
    Phase 2: Compare similarity measures and test adaptive fusion.

    For each similarity measure, builds a kNN network and evaluates
    GNN performance. Then tests whether adaptive fusion of multiple
    measures outperforms the best single measure.

    Parameters
    ----------
    methods : list of str, optional
        Methods to compare. Default: all 7.
    n_folds : int
        CV folds. Default: 5
    gnn_epochs : int
        GNN training epochs. Default: 100
    k_neighbors : int
        k for kNN. Default: 10
    run_fusion : bool
        Whether to run adaptive fusion. Default: True
    random_state : int
        Random seed. Default: 42
    """

    DEFAULT_METHODS = [
        "cosine", "euclidean", "bray_curtis", "pearson",
        "mahalanobis", "simpson", "jaccard",
    ]

    def __init__(
        self,
        methods: Optional[List[str]] = None,
        n_folds: int = 5,
        gnn_epochs: int = 100,
        k_neighbors: int = 10,
        run_fusion: bool = True,
        random_state: int = 42,
    ):
        self.methods = methods or self.DEFAULT_METHODS
        self.n_folds = n_folds
        self.gnn_epochs = gnn_epochs
        self.k_neighbors = k_neighbors
        self.run_fusion = run_fusion
        self.random_state = random_state

    def run(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
        dataset_name: str = "unknown",
        checkpoint_mgr=None,
        domain_key: str = "",
    ) -> SimilarityComparisonResult:
        """Run similarity comparison — one matrix at a time for memory safety."""
        from .similarity import SimilarityEngine, evaluate_separation_vectorized
        from .network import NetworkBuilder

        # Load any previously completed methods from sub-checkpoint
        method_results = {}
        sub_key = f"{domain_key}__phase2_methods"
        saved_methods = {}
        if checkpoint_mgr:
            saved = checkpoint_mgr.load(domain_key, "phase2_methods")
            if saved and "methods" in saved:
                saved_methods = saved["methods"]
                print(f"  Resuming Phase 2: {len(saved_methods)} methods already done")

        for method in self.methods:
            # Skip if already computed
            if method in saved_methods:
                sep = saved_methods[method]["separation"]
                metrics = EvalMetrics(
                    auc_roc=saved_methods[method]["auc_roc"],
                    f1=saved_methods[method]["f1"],
                    mcc=saved_methods[method]["mcc"],
                    auc_pr=saved_methods[method].get("auc_pr", 0),
                )
                method_results[method] = {
                    "metrics_mean": metrics,
                    "separation": sep,
                    "time": saved_methods[method].get("time", 0),
                }
                print(f"  ✓ {method} (from checkpoint) "
                      f"{metrics.summary_line()} Δ={sep:+.4f}")
                continue

            print(f"  Testing {method}...", end=" ", flush=True)
            t0 = time.time()

            N = features.shape[0]
            if N > 5000:
                from .sparse_similarity import SparseSimilarity
                sparse_engine = SparseSimilarity(
                    method=method, k=self.k_neighbors,
                )
                sparse_result = sparse_engine.compute(features, normalize=True)
                sep = sparse_result.separation_score(outcomes)
                if HAS_TORCH:
                    net_builder = NetworkBuilder(
                        strategy="knn", k=self.k_neighbors
                    )
                    graph = net_builder.build_from_sparse(
                        sparse_result, features, outcomes
                    )
                    metrics = self._evaluate_gnn(features, outcomes, graph)
                else:
                    metrics = EvalMetrics(auc_roc=0.5 + sep)
                del sparse_result
            else:
                engine = SimilarityEngine(method=method, n_bins=3)
                sim = engine.compute(features, normalize=True)
                sep = evaluate_separation_vectorized(
                    sim, outcomes, k=self.k_neighbors
                )
                if HAS_TORCH:
                    net_builder = NetworkBuilder(
                        strategy="knn", k=self.k_neighbors
                    )
                    graph = net_builder.build(sim, features, outcomes)
                    metrics = self._evaluate_gnn(features, outcomes, graph)
                else:
                    metrics = EvalMetrics(auc_roc=0.5 + sep)
                del sim


            elapsed = time.time() - t0
            method_results[method] = {
                "metrics_mean": metrics,
                "separation": sep,
                "time": elapsed,
            }
            print(f"{metrics.summary_line()} Δ={sep:+.4f} ({elapsed:.1f}s)")

            # Save sub-checkpoint after each method
            if checkpoint_mgr:
                saved_methods[method] = {
                    "auc_roc": metrics.auc_roc,
                    "f1": metrics.f1,
                    "mcc": metrics.mcc,
                    "auc_pr": metrics.auc_pr,
                    "separation": sep,
                    "time": elapsed,
                }
                checkpoint_mgr.save(domain_key, "phase2_methods",
                    type("R", (), {"methods": saved_methods})(),
                    metadata={"completed": list(saved_methods.keys())})
        # ── Fusion ───────────────────────────────────────────
        fusion_result = None
        N = features.shape[0]
        if self.run_fusion and len(self.methods) > 1 and N <= 5000:
            print(f"\n  Running adaptive fusion...", end=" ", flush=True)
            t0 = time.time()

            from .fusion import SimilarityFusion
            fusioner = SimilarityFusion(
                methods=self.methods,
                optimization="grid",
                k_neighbors=self.k_neighbors,
                random_state=self.random_state,
            )
            fusion = fusioner.fit(features, outcomes)

            if HAS_TORCH:
                net_builder = NetworkBuilder(
                    strategy="knn", k=self.k_neighbors
                )
                graph = net_builder.build(
                    fusion.fused_matrix, features, outcomes
                )
                fusion_metrics = self._evaluate_gnn(
                    features, outcomes, graph
                )
            else:
                fusion_sep = evaluate_separation_vectorized(
                    fusion.fused_matrix, outcomes, k=self.k_neighbors
                )
                fusion_metrics = EvalMetrics(auc_roc=0.5 + fusion_sep)

            elapsed = time.time() - t0
            fusion_result = {
                "metrics_mean": fusion_metrics,
                "weights": fusion.weights,
                "optimization_score": fusion.optimization_score,
                "time": elapsed,
            }
            print(f"{fusion_metrics.summary_line()} ({elapsed:.1f}s)")
            print(f"  Weights: {fusion.weights}")

        return SimilarityComparisonResult(
            method_results=method_results,
            fusion_result=fusion_result,
            dataset_name=dataset_name,
            metadata={
                "n_folds": self.n_folds,
                "k_neighbors": self.k_neighbors,
                "random_state": self.random_state,
            },
        )

    def _compute_separation(
        self, sim: np.ndarray, outcomes: np.ndarray
    ) -> float:
        """Vectorized failure neighborhood separation Δ."""
        from .similarity import evaluate_separation_vectorized
        return evaluate_separation_vectorized(sim, outcomes, k=self.k_neighbors)

    def _evaluate_gnn(
        self, features, outcomes, graph
    ) -> EvalMetrics:
        """Quick GNN evaluation for similarity comparison."""
        from ..models.gnn import TesseraGNN, prepare_gnn_data
        from ..models.ensemble import TesseraTrainer
        from .community import CommunityDetector
        from .regime_divergence import RegimeDivergenceComputer

        # Lightweight community detection
        detector = CommunityDetector(
            method="leiden", resolution=0.5, random_state=self.random_state
        )

        # Need sim matrix for community detection
        # Use graph's edge structure
        N = graph.n_nodes
        communities = detector.detect(
            similarity_matrix=None,
            edge_index=graph.edge_index,
            edge_weights=graph.edge_weights,
        )

        rd = RegimeDivergenceComputer().compute(
            communities, outcomes, graph.edge_index, graph.edge_weights
        )

        # Detect device
        device = "cuda" if torch.cuda.is_available() else "cpu"

        data = prepare_gnn_data(
            features, outcomes, graph.edge_index, graph.edge_weights,
            community_labels=communities.labels,
            rd_scores=rd.entity_rd_scores,
            device=device,
        )

        skf = StratifiedKFold(
            n_splits=self.n_folds, shuffle=True,
            random_state=self.random_state,
        )

        all_metrics = []
        for train_idx, val_idx in skf.split(features, outcomes):
            train_mask = np.zeros(len(features), dtype=bool)
            val_mask = np.zeros(len(features), dtype=bool)
            train_mask[train_idx] = True
            val_mask[val_idx] = True

            model = TesseraGNN(
                in_channels=data.x.shape[1],
                hidden_channels=64,
            ).to(device)
            trainer = TesseraTrainer(
                gnn_epochs=self.gnn_epochs, lr=1e-3, device=device
            )
            trainer.train_gnn(model, data, train_mask, val_mask)

            model.eval()
            with torch.no_grad():
                pred = model(data.x, data.edge_index, data.edge_attr)
                y_pred = pred[val_idx].cpu().numpy()

            all_metrics.append(compute_metrics(outcomes[val_idx], y_pred))

        return AblationRunner._average_metrics(all_metrics)


# ═══════════════════════════════════════════════════════════════
# PHASE 3: BIN SENSITIVITY
# ═══════════════════════════════════════════════════════════════

@dataclass
class BinSensitivityResult:
    """Results from Phase 3 bin sensitivity sweep."""
    results: Dict[int, Dict[str, Any]]  # n_bins → {metrics, separation, ...}
    dataset_name: str = ""
    method: str = "simpson"

    def summary(self) -> str:
        lines = [
            f"TESSERA Phase 3 — Bin Sensitivity ({self.dataset_name})",
            "=" * 55,
            f"Method: {self.method}",
            f"{'n_bins':>7s} {'Δ(sep)':>8s} {'AUC-ROC':>8s} {'F1':>6s} {'Time':>7s}",
            "─" * 55,
        ]
        for n_bins in sorted(self.results.keys()):
            r = self.results[n_bins]
            m = r.get("metrics_mean", EvalMetrics())
            sep = r.get("separation", 0)
            t = r.get("time", 0)
            lines.append(
                f"  {n_bins:>5d} {sep:>+8.4f} {m.auc_roc:>8.3f} "
                f"{m.f1:>6.3f} {t:>6.1f}s"
            )
        return "\n".join(lines)


class BinSensitivityRunner:
    """
    Phase 3: Test sensitivity to binning parameter for discrete methods.

    Sweeps n_bins from 2 to max_bins for Simpson (default) and evaluates
    GNN performance at each setting.

    Parameters
    ----------
    method : str
        Discrete similarity method to test. Default: "simpson"
    bin_range : tuple
        (min_bins, max_bins). Default: (2, 5)
    n_folds : int
        CV folds. Default: 5
    gnn_epochs : int
        GNN epochs. Default: 100
    k_neighbors : int
        k for kNN. Default: 10
    random_state : int
        Default: 42
    """

    def __init__(
        self,
        method: str = "simpson",
        bin_range: Tuple[int, int] = (2, 5),
        n_folds: int = 5,
        gnn_epochs: int = 100,
        k_neighbors: int = 10,
        random_state: int = 42,
    ):
        self.method = method
        self.bin_range = bin_range
        self.n_folds = n_folds
        self.gnn_epochs = gnn_epochs
        self.k_neighbors = k_neighbors
        self.random_state = random_state

    def run(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
        dataset_name: str = "unknown",
    ) -> BinSensitivityResult:
        """Run bin sensitivity sweep."""
        from .similarity import SimilarityEngine
        from .network import NetworkBuilder

        results = {}

        for n_bins in range(self.bin_range[0], self.bin_range[1] + 1):
            print(f"  n_bins={n_bins}...", end=" ", flush=True)
            t0 = time.time()
            N = features.shape[0]

            if N > 5000:
                from .sparse_similarity import SparseSimilarity
                sparse_engine = SparseSimilarity(
                    method=self.method, k=self.k_neighbors, n_bins=n_bins,
                )
                sparse_result = sparse_engine.compute(features, normalize=True)
                sep = sparse_result.separation_score(outcomes)

                if HAS_TORCH:
                    net_builder = NetworkBuilder(
                        strategy="knn", k=self.k_neighbors
                    )
                    graph = net_builder.build_from_sparse(
                        sparse_result, features, outcomes
                    )
                    comp_runner = SimilarityComparisonRunner(
                        n_folds=self.n_folds,
                        gnn_epochs=self.gnn_epochs,
                        random_state=self.random_state,
                    )
                    metrics = comp_runner._evaluate_gnn(features, outcomes, graph)
                else:
                    metrics = EvalMetrics(auc_roc=0.5 + sep)
                del sparse_result
            else:
                engine = SimilarityEngine(method=self.method, n_bins=n_bins)
                sim = engine.compute(features, normalize=True)
                sep = self._compute_separation(sim, outcomes)

                if HAS_TORCH:
                    net_builder = NetworkBuilder(
                        strategy="knn", k=self.k_neighbors
                    )
                    graph = net_builder.build(sim, features, outcomes)
                    comp_runner = SimilarityComparisonRunner(
                        n_folds=self.n_folds,
                        gnn_epochs=self.gnn_epochs,
                        random_state=self.random_state,
                    )
                    metrics = comp_runner._evaluate_gnn(features, outcomes, graph)
                else:
                    metrics = EvalMetrics(auc_roc=0.5 + sep)
                del sim

            elapsed = time.time() - t0
            results[n_bins] = {
                "metrics_mean": metrics,
                "separation": sep,
                "time": elapsed,
            }
            print(f"Δ={sep:+.4f} AUC={metrics.auc_roc:.3f} ({elapsed:.1f}s)")


        return BinSensitivityResult(
            results=results,
            dataset_name=dataset_name,
            method=self.method,
        )

    def _compute_separation(self, sim, outcomes):
        """Vectorized separation scoring."""
        from .similarity import evaluate_separation_vectorized
        return evaluate_separation_vectorized(sim, outcomes, k=self.k_neighbors)


# ═══════════════════════════════════════════════════════════════
# PHASE 4: TEMPORAL CROSS-VALIDATION
# ═══════════════════════════════════════════════════════════════

@dataclass
class TemporalCVResult:
    """Results from Phase 4 temporal cross-validation."""
    fold_results: List[Dict[str, Any]]  # per-fold metrics
    mean_metrics: EvalMetrics
    std_metrics: Dict[str, float]
    dataset_name: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"TESSERA Phase 4 — Temporal CV ({self.dataset_name})",
            "=" * 60,
            f"{'Fold':>5s} {'Train':>8s} {'Test':>8s} {'AUC-ROC':>8s} "
            f"{'F1':>6s} {'MCC':>6s}",
            "─" * 60,
        ]
        for i, fr in enumerate(self.fold_results):
            m = fr["metrics"]
            lines.append(
                f"  {i+1:>3d} {fr['train_windows']:>8s} "
                f"{fr['test_window']:>8s} {m.auc_roc:>8.3f} "
                f"{m.f1:>6.3f} {m.mcc:>6.3f}"
            )

        lines.append("─" * 60)
        mm = self.mean_metrics
        lines.append(
            f"  {'MEAN':>3s} {'':>8s} {'':>8s} {mm.auc_roc:>8.3f} "
            f"{mm.f1:>6.3f} {mm.mcc:>6.3f}"
        )
        lines.append(
            f"  {'±STD':>3s} {'':>8s} {'':>8s} "
            f"{self.std_metrics.get('auc_roc', 0):>8.3f} "
            f"{self.std_metrics.get('f1', 0):>6.3f} "
            f"{self.std_metrics.get('mcc', 0):>6.3f}"
        )
        return "\n".join(lines)


class TemporalCVRunner:
    """
    Phase 4: Temporal cross-validation.

    Uses leave-one-window-out: train on all but one time window,
    test on the held-out window. This tests whether TESSERA
    generalizes across time.

    Parameters
    ----------
    model_type : str
        "gnn", "ensemble", or "baseline". Default: "gnn"
    similarity_method : str
        Default: "mahalanobis"
    gnn_epochs : int
        Default: 150
    k_neighbors : int
        Default: 10
    random_state : int
        Default: 42
    """

    def __init__(
        self,
        model_type: str = "gnn",
        similarity_method: str = "mahalanobis",
        gnn_epochs: int = 150,
        k_neighbors: int = 10,
        random_state: int = 42,
    ):
        self.model_type = model_type
        self.similarity_method = similarity_method
        self.gnn_epochs = gnn_epochs
        self.k_neighbors = k_neighbors
        self.random_state = random_state

    def run(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
        time_windows: np.ndarray,
        dataset_name: str = "unknown",
    ) -> TemporalCVResult:
        """Run temporal cross-validation."""
        unique_windows = np.sort(np.unique(time_windows))
        n_windows = len(unique_windows)

        if n_windows < 2:
            raise ValueError(f"Need ≥2 time windows, got {n_windows}")

        fold_results = []

        for fold_idx, test_window in enumerate(unique_windows):
            test_mask = time_windows == test_window
            train_mask = ~test_mask

            n_train = train_mask.sum()
            n_test = test_mask.sum()
            train_windows = [str(int(w)) for w in unique_windows if w != test_window]

            print(f"  Fold {fold_idx+1}/{n_windows}: "
                  f"train={n_train} test={n_test} "
                  f"(window {int(test_window)})...", end=" ", flush=True)

            t0 = time.time()

            if self.model_type == "baseline":
                metrics = self._run_baseline(
                    features, outcomes, train_mask, test_mask
                )
            elif HAS_TORCH and self.model_type in ("gnn", "ensemble"):
                metrics = self._run_gnn(
                    features, outcomes, train_mask, test_mask
                )
            else:
                metrics = self._run_baseline(
                    features, outcomes, train_mask, test_mask
                )

            elapsed = time.time() - t0

            fold_results.append({
                "fold": fold_idx,
                "test_window": str(int(test_window)),
                "train_windows": ",".join(train_windows),
                "n_train": int(n_train),
                "n_test": int(n_test),
                "metrics": metrics,
                "time": elapsed,
            })
            print(f"AUC={metrics.auc_roc:.3f} F1={metrics.f1:.3f} ({elapsed:.1f}s)")

        # Compute mean and std
        all_metrics = [fr["metrics"] for fr in fold_results]
        mean_m = AblationRunner._average_metrics(all_metrics)

        std_m = {
            "auc_roc": float(np.std([m.auc_roc for m in all_metrics])),
            "f1": float(np.std([m.f1 for m in all_metrics])),
            "mcc": float(np.std([m.mcc for m in all_metrics])),
            "auc_pr": float(np.std([m.auc_pr for m in all_metrics])),
        }

        return TemporalCVResult(
            fold_results=fold_results,
            mean_metrics=mean_m,
            std_metrics=std_m,
            dataset_name=dataset_name,
            metadata={
                "model_type": self.model_type,
                "n_windows": n_windows,
                "similarity_method": self.similarity_method,
            },
        )

    def _run_baseline(self, features, outcomes, train_mask, test_mask):
        """XGBoost baseline for temporal CV."""
        scaler = StandardScaler()
        X_train = scaler.fit_transform(features[train_mask])
        X_test = scaler.transform(features[test_mask])

        clf = GradientBoostingClassifier(
            n_estimators=100, random_state=self.random_state
        )
        clf.fit(X_train, outcomes[train_mask])
        y_pred = clf.predict_proba(X_test)[:, 1]

        return compute_metrics(outcomes[test_mask], y_pred)

    def _run_gnn(self, features, outcomes, train_mask, test_mask):
        """GNN evaluation for temporal CV."""
        from .similarity import SimilarityEngine
        from .network import NetworkBuilder
        from .community import CommunityDetector
        from .regime_divergence import RegimeDivergenceComputer
        from ..models.gnn import TesseraGNN, prepare_gnn_data
        from ..models.ensemble import TesseraTrainer

# Build network on ALL data (transductive)
        N = features.shape[0]
        if N > 5000:
            from .sparse_similarity import SparseSimilarity
            sparse_engine = SparseSimilarity(
                method=self.similarity_method, k=self.k_neighbors,
            )
            sparse_result = sparse_engine.compute(features, normalize=True)
            graph = NetworkBuilder(strategy="knn", k=self.k_neighbors).build_from_sparse(
                sparse_result, features, outcomes
            )
            sim = None
            del sparse_result
        else:
            sim_engine = SimilarityEngine(method=self.similarity_method)
            sim = sim_engine.compute(features, normalize=True)
            graph = NetworkBuilder(strategy="knn", k=self.k_neighbors).build(
                sim, features, outcomes
        )

        detector = CommunityDetector(
            method="leiden", resolution=0.5, random_state=self.random_state
        )
        communities = detector.detect(
            similarity_matrix=sim,
            edge_index=graph.edge_index,
            edge_weights=graph.edge_weights,
        )

        rd = RegimeDivergenceComputer().compute(
            communities, outcomes, graph.edge_index, graph.edge_weights
        )

        device = "cuda" if torch.cuda.is_available() else "cpu"

        data = prepare_gnn_data(
            features, outcomes, graph.edge_index, graph.edge_weights,
            community_labels=communities.labels,
            rd_scores=rd.entity_rd_scores,
            device=device,
        )

        model = TesseraGNN(
            in_channels=data.x.shape[1], hidden_channels=64,
        ).to(device)

        trainer = TesseraTrainer(
            gnn_epochs=self.gnn_epochs, lr=1e-3, device=device
        )

        # Use a small subset of training data as val for early stopping proxy
        train_idx = np.where(train_mask)[0]
        rng = np.random.default_rng(self.random_state)
        val_split = rng.choice(
            train_idx, size=max(1, len(train_idx) // 5), replace=False
        )
        inner_train = np.zeros(len(features), dtype=bool)
        inner_val = np.zeros(len(features), dtype=bool)
        inner_train[train_idx] = True
        inner_train[val_split] = False
        inner_val[val_split] = True

        trainer.train_gnn(model, data, inner_train, inner_val)

        model.eval()
        with torch.no_grad():
            pred = model(data.x, data.edge_index, data.edge_attr)
            test_idx = np.where(test_mask)[0]
            y_pred = pred[test_idx].cpu().numpy()

        return compute_metrics(outcomes[test_idx], y_pred)
