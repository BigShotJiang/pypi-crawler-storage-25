"""
TESSERA Similarity Measures

Implements pairwise similarity computation between entities using
multiple measures from ecology, statistics, and geometry.

All measures return an (N, N) similarity matrix in [0, 1] where
1 = identical and 0 = maximally dissimilar.
"""

import numpy as np
from scipy.spatial.distance import pdist, squareform
from scipy.stats import pearsonr
from typing import Optional, Dict, Any, Callable
import warnings

try:
    from .safety import safe_similarity_matrix
except ImportError:
    safe_similarity_matrix = None


class SimilarityEngine:
    """
    Computes pairwise similarity matrices between entities.

    Supports seven similarity measures spanning ecological, statistical,
    and geometric traditions. Each measure captures different aspects
    of relational structure in feature space.

    Parameters
    ----------
    method : str
        Similarity measure to use. One of:
        - "simpson": Simpson similarity (discretized features)
        - "cosine": Cosine similarity (continuous)
        - "bray_curtis": Bray-Curtis similarity (ecology standard)
        - "jaccard": Jaccard similarity (discretized features)
        - "pearson": Pearson correlation similarity
        - "euclidean": Inverse Euclidean distance
        - "mahalanobis": Inverse Mahalanobis distance
    n_bins : int
        Number of bins for discretization (Simpson, Jaccard only).
        Default: 3
    bin_method : str
        Binning strategy: "equal_width", "equal_freq", "custom".
        Default: "equal_width"
    """

    VALID_METHODS = {
        "simpson", "cosine", "bray_curtis", "jaccard",
        "pearson", "euclidean", "mahalanobis",
    }

    # Which methods require discretization
    DISCRETE_METHODS = {"simpson", "jaccard"}

    def __init__(
        self,
        method: str = "simpson",
        n_bins: int = 3,
        bin_method: str = "equal_width",
    ):
        if method not in self.VALID_METHODS:
            raise ValueError(
                f"method must be one of {self.VALID_METHODS}, "
                f"got '{method}'"
            )
        self.method = method
        self.n_bins = n_bins
        self.bin_method = bin_method

    def compute(
        self,
        features: np.ndarray,
        normalize: bool = True,
    ) -> np.ndarray:
        """
        Compute pairwise similarity matrix.

        Parameters
        ----------
        features : np.ndarray
            (N, D) feature matrix.
        normalize : bool
            If True, normalize features before computation (recommended
            for distance-based methods).

        Returns
        -------
        np.ndarray
            (N, N) similarity matrix with values in [0, 1].
        """
        if normalize and self.method not in self.DISCRETE_METHODS:
            features = self._normalize(features)

        dispatch = {
            "simpson": self._simpson,
            "cosine": self._cosine,
            "bray_curtis": self._bray_curtis,
            "jaccard": self._jaccard,
            "pearson": self._pearson,
            "euclidean": self._euclidean,
            "mahalanobis": self._mahalanobis,
        }

        sim_matrix = dispatch[self.method](features)

        # Ensure [0, 1] range and symmetry
        sim_matrix = np.clip(sim_matrix, 0.0, 1.0)
        sim_matrix = (sim_matrix + sim_matrix.T) / 2
        np.fill_diagonal(sim_matrix, 1.0)

        return sim_matrix

    def metadata(self) -> Dict[str, Any]:
        """Return configuration metadata for reproducibility."""
        meta = {
            "method": self.method,
        }
        if self.method in self.DISCRETE_METHODS:
            meta["n_bins"] = self.n_bins
            meta["bin_method"] = self.bin_method
        return meta

    # ── Discretization ───────────────────────────────────────────

    def _discretize(self, features: np.ndarray) -> np.ndarray:
        """
        Discretize continuous features into categorical bins.

        Returns an (N, D) integer matrix where each value is a bin label.
        """
        N, D = features.shape
        binned = np.zeros_like(features, dtype=int)

        for d in range(D):
            col = features[:, d]

            if self.bin_method == "equal_width":
                edges = np.linspace(col.min(), col.max() + 1e-10, self.n_bins + 1)
                binned[:, d] = np.digitize(col, edges[1:-1])
            elif self.bin_method == "equal_freq":
                percentiles = np.linspace(0, 100, self.n_bins + 1)
                edges = np.percentile(col, percentiles)
                edges[-1] += 1e-10  # include max
                binned[:, d] = np.digitize(col, edges[1:-1])
            else:
                raise ValueError(f"Unknown bin_method: {self.bin_method}")

        return binned

    def _normalize(self, features: np.ndarray) -> np.ndarray:
        """Z-score normalization per feature."""
        means = features.mean(axis=0)
        stds = features.std(axis=0)
        stds = np.where(stds == 0, 1.0, stds)
        return (features - means) / stds

    # ── Similarity Measures ──────────────────────────────────────

    def _simpson(self, features: np.ndarray) -> np.ndarray:
        """
        Simpson similarity.

        For discretized features, Simpson similarity between two entities
        i and j is:

            S(i,j) = C(i,j) / min(R_i, R_j)

        where C(i,j) is the count of features where both entities share
        the same bin, R_i is entity i's "richness" (number of distinct
        bin values across its features), and min() ensures nestedness
        correction — the biogeographical hallmark of Simpson's index.

        Unlike Jaccard, Simpson is asymmetry-aware: a species-poor site
        nested entirely within a species-rich site scores 1.0.
        """
        binned = self._discretize(features)
        N, D = binned.shape

        # Shared bins: vectorized pairwise comparison
        # (N, 1, D) == (1, N, D) → (N, N, D) boolean → sum over D
        shared = (binned[:, None, :] == binned[None, :, :]).sum(axis=2)

        # Richness per entity: number of unique bin values
        richness = np.array([len(np.unique(binned[i])) for i in range(N)])

        # min(R_i, R_j) for all pairs
        min_rich = np.minimum(richness[:, None], richness[None, :])
        min_rich = np.where(min_rich == 0, 1, min_rich)

        # Simpson = shared / min(richness_i, richness_j)
        # Normalize by D to keep in [0,1] when richness is small
        sim = shared.astype(float) / D

        # Apply Simpson nestedness correction:
        # Scale by (shared/min_rich) to weight nestedness
        nestedness = shared.astype(float) / min_rich
        sim = sim * nestedness

        return np.clip(sim, 0.0, 1.0)

    def _cosine(self, features: np.ndarray) -> np.ndarray:
        """
        Cosine similarity.

        S(i,j) = (x_i · x_j) / (||x_i|| * ||x_j||)

        Measures directional alignment in feature space.
        Insensitive to magnitude, captures proportional similarity.
        """
        # Normalize rows to unit length
        norms = np.linalg.norm(features, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1.0, norms)
        unit = features / norms

        sim = unit @ unit.T

        # Cosine similarity is in [-1, 1]; map to [0, 1]
        sim = (sim + 1.0) / 2.0

        return sim

    def _bray_curtis(self, features: np.ndarray) -> np.ndarray:
        """
        Bray-Curtis similarity (1 - Bray-Curtis dissimilarity).

        BC(i,j) = 1 - sum(|x_i - x_j|) / sum(|x_i| + |x_j|)

        The ecology standard for abundance/composition data.
        Sensitive to both composition and magnitude differences.
        """
        # Shift features to be non-negative (BC requires this)
        shifted = features - features.min(axis=0)

        dists = squareform(pdist(shifted, metric="braycurtis"))
        sim = 1.0 - dists

        return sim

    def _jaccard(self, features: np.ndarray) -> np.ndarray:
        """
        Jaccard similarity on discretized features.

        J(i,j) = C(i,j) / (2D - C(i,j))

        where C(i,j) counts features with matching bins, and D is
        the number of features. Each entity has D (feature, bin) pairs,
        so union = 2D - intersection.

        Unlike Simpson, Jaccard penalizes differences in composition
        without nestedness correction.
        """
        binned = self._discretize(features)
        N, D = binned.shape

        # Shared bins: vectorized
        shared = (binned[:, None, :] == binned[None, :, :]).sum(axis=2).astype(float)

        # Jaccard = intersection / union = shared / (2D - shared)
        union = 2 * D - shared
        union = np.where(union == 0, 1, union)

        sim = shared / union

        return sim

    def _pearson(self, features: np.ndarray) -> np.ndarray:
        """
        Pearson correlation similarity.

        S(i,j) = (r(i,j) + 1) / 2

        Maps correlation from [-1, 1] to [0, 1].
        Captures linear relationship between entity profiles.
        """
        # Correlation matrix of rows (entities)
        # Center each entity's features
        centered = features - features.mean(axis=1, keepdims=True)
        norms = np.linalg.norm(centered, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1.0, norms)
        normed = centered / norms

        corr = normed @ normed.T

        # Map [-1, 1] → [0, 1]
        sim = (corr + 1.0) / 2.0

        return sim

    def _euclidean(self, features: np.ndarray) -> np.ndarray:
        """
        Inverse Euclidean distance similarity.

        S(i,j) = 1 / (1 + d(i,j))

        Simple geometric distance, sensitive to magnitude.
        """
        dists = squareform(pdist(features, metric="euclidean"))
        sim = 1.0 / (1.0 + dists)

        return sim

    def _mahalanobis(self, features: np.ndarray) -> np.ndarray:
        """
        Inverse Mahalanobis distance similarity.

        S(i,j) = 1 / (1 + d_M(i,j))

        Accounts for feature correlations via the covariance matrix.
        More appropriate than Euclidean when features are correlated.
        """
        # Compute covariance matrix with regularization
        cov = np.cov(features.T)
        # Regularize for numerical stability
        cov += np.eye(cov.shape[0]) * 1e-6

        try:
            cov_inv = np.linalg.inv(cov)
        except np.linalg.LinAlgError:
            warnings.warn(
                "Covariance matrix singular, falling back to Euclidean"
            )
            return self._euclidean(features)

        # Pairwise Mahalanobis distances
        N = features.shape[0]
        dists = np.zeros((N, N))

        for i in range(N):
            diff = features[i] - features  # (N, D)
            # d_M = sqrt(diff @ cov_inv @ diff.T) per row
            dists[i] = np.sqrt(
                np.maximum(np.sum(diff @ cov_inv * diff, axis=1), 0.0)
            )

        sim = 1.0 / (1.0 + dists)

        return sim


def compute_similarity_batch(
    features,
    methods=None,
    n_bins=3,
    normalize=True,
    parallel=True,
):
    """
    Compute similarity matrices for multiple methods.
    When parallel=True, uses joblib for concurrent computation.
    """
    if methods is None:
        methods = list(SimilarityEngine.VALID_METHODS)

    def _compute_one(method):
        engine = SimilarityEngine(method=method, n_bins=n_bins)
        return method, engine.compute(features, normalize=normalize)

    if parallel and len(methods) > 1:
        try:
            from .parallel import TesseraParallel, estimate_similarity_memory_gb, parallel_config
            mem_per = estimate_similarity_memory_gb(features.shape[0])
            # Only parallelize if all matrices fit in memory
            total_mem = mem_per * len(methods) * 1.5
            if total_mem < parallel_config.max_memory_gb * 0.7:
                tp = TesseraParallel(
                    memory_per_job_gb=mem_per * 1.5,
                    desc="Similarity batch",
                )
                pairs = tp.map(_compute_one, methods)
                return {m: s for m, s in pairs}
            else:
                print(f"({mem_per:.1f}GB/matrix × {len(methods)} = {total_mem:.0f}GB > available, computing sequentially)")
        except (ImportError, Exception):
            pass

    return {m: s for m, s in (_compute_one(m) for m in methods)}


def evaluate_separation_vectorized(
    similarity_matrix,
    outcomes,
    k=10,
):
    """
    Vectorized failure neighborhood separation.
    Uses argpartition O(N) instead of argsort O(N log N).
    ~50-100x faster than Python loop for N > 1000.
    """
    N = similarity_matrix.shape[0]
    k = min(k, N - 1)

    sim = similarity_matrix.copy()
    np.fill_diagonal(sim, -np.inf)

    top_k_idx = np.argpartition(sim, -k, axis=1)[:, -k:]
    neighbor_fail_rate = outcomes[top_k_idx].mean(axis=1)

    fail_mask = outcomes == 1
    succ_mask = outcomes == 0

    if fail_mask.sum() == 0 or succ_mask.sum() == 0:
        return 0.0

    return float(
        neighbor_fail_rate[fail_mask].mean() -
        neighbor_fail_rate[succ_mask].mean()
    )
