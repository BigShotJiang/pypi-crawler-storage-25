"""
TESSERA Similarity Fusion

Adaptive fusion of multiple similarity measures. Memory-safe
implementation that avoids holding all matrices simultaneously
for large datasets.

Uses TESSERA parallel infrastructure for concurrent computation.
"""

import numpy as np
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass, field

from .similarity import SimilarityEngine
from .parallel import (
    TesseraParallel, parallel_config,
    estimate_similarity_memory_gb,
)


@dataclass
class FusionResult:
    """Result of similarity fusion optimization."""
    fused_matrix: np.ndarray
    weights: Dict[str, float]
    individual_scores: Dict[str, float]
    optimization_score: float
    metadata: Dict[str, Any] = field(default_factory=dict)

    def ranking(self) -> List[Tuple[str, float]]:
        return sorted(self.individual_scores.items(),
                      key=lambda x: x[1], reverse=True)

    def summary(self) -> str:
        lines = [
            "TESSERA Similarity Fusion",
            "=" * 45,
            f"Methods fused:      {len(self.weights)}",
            f"Optimization score: {self.optimization_score:.4f}",
            "",
            "Learned weights:",
        ]
        for method, w in sorted(self.weights.items(),
                                 key=lambda x: x[1], reverse=True):
            bar = "█" * int(w * 30)
            sep = self.individual_scores.get(method, 0)
            lines.append(f"  {method:15s} w={w:.3f} Δ={sep:+.4f} {bar}")
        return "\n".join(lines)


def _compute_single_similarity(args):
    """Worker: compute one similarity matrix + separation score."""
    method, features, outcomes, n_bins, k_neighbors, normalize = args
    engine = SimilarityEngine(method=method, n_bins=n_bins)
    sim = engine.compute(features, normalize=normalize)
    N = sim.shape[0]
    upper = sim[np.triu_indices(N, k=1)]
    mean_s, std_s = upper.mean(), upper.std()
    if std_s > 1e-10:
        sim = (sim - mean_s) / std_s
    sim_min, sim_max = sim.min(), sim.max()
    if sim_max - sim_min > 1e-10:
        sim = (sim - sim_min) / (sim_max - sim_min)
    from .similarity import evaluate_separation_vectorized
    sep = evaluate_separation_vectorized(sim, outcomes, k=k_neighbors)
    return method, sim, sep


class SimilarityFusion:
    """
    Memory-safe adaptive fusion of similarity measures.

    Automatically switches between:
    - Parallel mode: all matrices in memory (small datasets)
    - Streaming mode: one at a time (large datasets)
    """

    DEFAULT_METHODS = [
        "cosine", "euclidean", "bray_curtis", "pearson",
        "mahalanobis", "simpson", "jaccard",
    ]

    def __init__(
        self,
        methods: Optional[List[str]] = None,
        n_bins: int = 3,
        optimization: str = "grid",
        grid_resolution: int = 11,
        k_neighbors: int = 10,
        max_matrices_in_memory: Optional[int] = None,
        random_state: Optional[int] = None,
    ):
        self.methods = methods or self.DEFAULT_METHODS
        self.n_bins = n_bins
        self.optimization = optimization
        self.grid_resolution = grid_resolution
        self.k_neighbors = k_neighbors
        self.max_matrices_in_memory = max_matrices_in_memory
        self.random_state = random_state

    def fit(self, features, outcomes, normalize=True) -> FusionResult:
        N = features.shape[0]
        mem_per = estimate_similarity_memory_gb(N)

        max_in_mem = self.max_matrices_in_memory
        if max_in_mem is None:
            available = parallel_config.max_memory_gb
            max_in_mem = max(2, int(available * 0.6 / max(mem_per, 0.01)))

        if len(self.methods) <= max_in_mem:
            return self._fit_parallel(features, outcomes, normalize)
        else:
            return self._fit_streaming(features, outcomes, normalize)

    def _fit_parallel(self, features, outcomes, normalize) -> FusionResult:
        N = features.shape[0]
        args_list = [
            (m, features, outcomes, self.n_bins, self.k_neighbors, normalize)
            for m in self.methods
        ]
        tp = TesseraParallel(
            memory_per_job_gb=estimate_similarity_memory_gb(N) * 2,
            desc="Similarity fusion",
        )
        results = tp.map(_compute_single_similarity, args_list)

        individual = {}
        scores = {}
        for method, sim, sep in results:
            individual[method] = sim
            scores[method] = sep

        weights, opt_score = self._optimize_grid(individual, outcomes)

        fused = np.zeros((N, N))
        for m, w in weights.items():
            if w > 0:
                fused += w * individual[m]
        fused = np.clip(fused, 0, 1)
        np.fill_diagonal(fused, 1.0)

        return FusionResult(fused_matrix=fused, weights=weights,
                            individual_scores=scores,
                            optimization_score=opt_score,
                            metadata={"strategy": "parallel", "n_entities": N})

    def _fit_streaming(self, features, outcomes, normalize) -> FusionResult:
        """Memory-safe: compute one matrix at a time, keep only scores."""
        N = features.shape[0]
        from .parallel import estimate_similarity_memory_gb, parallel_config
        mem_per = estimate_similarity_memory_gb(N)

        # If even 3 matrices won't fit, skip matrix reconstruction
        # and return the best single measure's matrix instead
        skip_reconstruction = (mem_per * 3.5 > parallel_config.max_memory_gb * 0.8)
        if skip_reconstruction:
            print(f"  [Fusion] Large dataset mode: {mem_per:.1f} GB/matrix, "
                  f"using best single measure")

        scores = {}

        print(f"  [Fusion] Streaming mode ({N} entities, "
              f"{estimate_similarity_memory_gb(N):.1f} GB/matrix)")

        for method in self.methods:
            engine = SimilarityEngine(method=method, n_bins=self.n_bins)
            sim = engine.compute(features, normalize=normalize)
            upper = sim[np.triu_indices(N, k=1)]
            mean_s, std_s = upper.mean(), upper.std()
            if std_s > 1e-10:
                sim = (sim - mean_s) / std_s
            sim_min, sim_max = sim.min(), sim.max()
            if sim_max - sim_min > 1e-10:
                sim = (sim - sim_min) / (sim_max - sim_min)
            scores[method] = self._evaluate_separation(sim, outcomes)
            print(f"    {method:15s} Δ={scores[method]:+.4f}")
            del sim

        # Top 3 by score
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        top_methods = [m for m, s in ranked[:3]]

        # Weighted combination of top 3
        weights = {m: 0.0 for m in self.methods}
        top_seps = np.array([max(scores[m], 0) for m in top_methods])
        total = top_seps.sum()
        if total > 0:
            for m, w in zip(top_methods, top_seps / total):
                weights[m] = float(w)
        else:
            for m in top_methods:
                weights[m] = 1.0 / len(top_methods)

        if skip_reconstruction:
            # Use best single measure directly (no multi-matrix fusion)
            best_method = top_methods[0]
            engine = SimilarityEngine(method=best_method, n_bins=self.n_bins)
            fused = engine.compute(features, normalize=normalize)
            upper = fused[np.triu_indices(N, k=1)]
            mean_s, std_s = upper.mean(), upper.std()
            if std_s > 1e-10:
                fused = (fused - mean_s) / std_s
            fused_min, fused_max = fused.min(), fused.max()
            if fused_max - fused_min > 1e-10:
                fused = (fused - fused_min) / (fused_max - fused_min)
            fused = np.clip(fused, 0, 1)
            np.fill_diagonal(fused, 1.0)
            opt_score = scores[best_method]
            weights = {m: (1.0 if m == best_method else 0.0) for m in self.methods}
        else:
            # Build fused from top methods (max 3 matrices in memory)
            fused = np.zeros((N, N))
            for m in top_methods:
                if weights[m] > 0:
                    engine = SimilarityEngine(method=m, n_bins=self.n_bins)
                    sim = engine.compute(features, normalize=normalize)
                    upper = sim[np.triu_indices(N, k=1)]
                    mean_s, std_s = upper.mean(), upper.std()
                    if std_s > 1e-10:
                        sim = (sim - mean_s) / std_s
                    sim_min, sim_max = sim.min(), sim.max()
                    if sim_max - sim_min > 1e-10:
                        sim = (sim - sim_min) / (sim_max - sim_min)
                    fused += weights[m] * sim
                    del sim

            fused = np.clip(fused, 0, 1)
            np.fill_diagonal(fused, 1.0)
            opt_score = self._evaluate_separation(fused, outcomes)

        return FusionResult(fused_matrix=fused, weights=weights,
                            individual_scores=scores,
                            optimization_score=opt_score,
                            metadata={"strategy": "streaming", "n_entities": N,
                                      "top_methods": top_methods})

    def _optimize_grid(self, matrices, outcomes):
        methods = list(matrices.keys())
        scores = {m: self._evaluate_separation(matrices[m], outcomes)
                  for m in methods}
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        top = [m for m, s in ranked[:4]]

        best_w = {m: 0.0 for m in methods}
        best_s = -np.inf
        steps = np.linspace(0, 1, self.grid_resolution)

        if len(top) <= 2:
            for w0 in steps:
                w1 = 1.0 - w0
                if w1 < 0:
                    continue
                fused = w0 * matrices[top[0]] + w1 * matrices[top[1]]
                s = self._evaluate_separation(fused, outcomes)
                if s > best_s:
                    best_s = s
                    best_w = {m: 0.0 for m in methods}
                    best_w[top[0]], best_w[top[1]] = w0, w1
        else:
            coarse = np.linspace(0, 1, min(self.grid_resolution, 6))
            combos = []
            for w0 in coarse:
                for w1 in coarse:
                    rem = 1.0 - w0 - w1
                    if rem >= -0.01:
                        combos.append((w0, w1, max(rem, 0)))

            def eval_combo(combo):
                f = sum(combo[i] * matrices[top[i]]
                        for i in range(min(len(combo), len(top))) if combo[i] > 0)
                return self._evaluate_separation(f, outcomes)

            tp = TesseraParallel(desc="Grid search", backend="threading")
            results = tp.map(eval_combo, combos)

            for combo, s in zip(combos, results):
                if s > best_s:
                    best_s = s
                    best_w = {m: 0.0 for m in methods}
                    for i, m in enumerate(top[:len(combo)]):
                        best_w[m] = combo[i]

        return best_w, best_s

    def _evaluate_separation(self, sim, outcomes) -> float:
        """Vectorized separation scoring."""
        from .similarity import evaluate_separation_vectorized
        return evaluate_separation_vectorized(sim, outcomes, k=self.k_neighbors)
