"""
TESSERA Vectorized Utilities

High-performance vectorized implementations of common operations
that replace Python for-loops with NumPy/SciPy operations.
"""

import numpy as np
from typing import Tuple


def vectorized_knn_separation(
    similarity_matrix: np.ndarray,
    outcomes: np.ndarray,
    k: int = 10,
) -> float:
    """
    Compute failure neighborhood separation Δ using vectorized NumPy.

    Replaces the O(N) Python loop with batch operations.
    ~50-100× faster than the loop version for N > 1000.

    Parameters
    ----------
    similarity_matrix : np.ndarray (N, N)
    outcomes : np.ndarray (N,)
    k : int
        Number of nearest neighbors.

    Returns
    -------
    float
        Δ = mean_fail_neighbor_rate(failures) - mean_fail_neighbor_rate(successes)
    """
    N = similarity_matrix.shape[0]
    k = min(k, N - 1)

    # Zero out diagonal so self isn't a neighbor
    sim = similarity_matrix.copy()
    np.fill_diagonal(sim, -np.inf)

    # Top-k neighbors for all nodes at once (N, k)
    # Use argpartition for O(N) instead of full argsort O(N log N)
    top_k_idx = np.argpartition(sim, -k, axis=1)[:, -k:]

    # Gather outcome labels of neighbors (N, k)
    neighbor_outcomes = outcomes[top_k_idx]

    # Failure rate in each node's neighborhood (N,)
    neighbor_fail_rate = neighbor_outcomes.mean(axis=1)

    # Split by outcome
    fail_mask = outcomes == 1
    succ_mask = outcomes == 0

    if fail_mask.sum() == 0 or succ_mask.sum() == 0:
        return 0.0

    delta = neighbor_fail_rate[fail_mask].mean() - \
            neighbor_fail_rate[succ_mask].mean()

    return float(delta)


def vectorized_modularity(
    similarity_matrix: np.ndarray,
    labels: np.ndarray,
) -> float:
    """
    Compute Newman modularity using vectorized NumPy.

    Replaces O(N²) Python loop with matrix operations.

    Parameters
    ----------
    similarity_matrix : np.ndarray (N, N)
    labels : np.ndarray (N,)

    Returns
    -------
    float
    """
    W = similarity_matrix.copy()
    np.fill_diagonal(W, 0)
    m = W.sum() / 2

    if m == 0:
        return 0.0

    k = W.sum(axis=1)  # node strengths

    # Build community membership matrix (N, C)
    unique_labels = np.unique(labels)
    C = len(unique_labels)
    S = np.zeros((len(labels), C))
    label_to_idx = {l: i for i, l in enumerate(unique_labels)}
    for i, l in enumerate(labels):
        S[i, label_to_idx[l]] = 1.0

    # Q = (1/2m) * Tr(S^T * (W - k*k^T / 2m) * S)
    B = W - np.outer(k, k) / (2 * m)
    Q = np.trace(S.T @ B @ S) / (2 * m)

    return float(Q)
