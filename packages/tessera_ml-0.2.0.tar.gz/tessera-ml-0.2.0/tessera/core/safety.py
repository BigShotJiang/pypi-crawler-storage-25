"""
TESSERA Numerical Safety

Single source of truth for numerical sanitization across the framework.
Every module that produces numerical output should call safe_array()
before returning results. Consumers should never need to sanitize.

Design principle: sanitize at the PRODUCER, not the CONSUMER.
"""

import numpy as np
from typing import Optional


# Global safety limits
DEFAULT_CLIP_MIN = -1e8
DEFAULT_CLIP_MAX = 1e8
DEFAULT_NAN_FILL = 0.0
DEFAULT_INF_FILL = 0.0


def safe_array(
    arr: np.ndarray,
    clip_min: float = DEFAULT_CLIP_MIN,
    clip_max: float = DEFAULT_CLIP_MAX,
    nan_fill: float = DEFAULT_NAN_FILL,
    inf_fill: float = DEFAULT_INF_FILL,
    copy: bool = False,
    name: str = "",
) -> np.ndarray:
    """
    Sanitize a numpy array: replace nan/inf and clip extremes.

    This is the single sanitization function used throughout TESSERA.
    Every module that produces numerical output should call this
    before returning.

    Parameters
    ----------
    arr : np.ndarray
        Array to sanitize.
    clip_min : float
        Minimum allowed value. Default: -1e8
    clip_max : float
        Maximum allowed value. Default: 1e8
    nan_fill : float
        Replacement for NaN values. Default: 0.0
    inf_fill : float
        Replacement for ±inf values. Default: 0.0
    copy : bool
        If True, operate on a copy. Default: False (in-place)
    name : str
        Name for warning messages.

    Returns
    -------
    np.ndarray
        Sanitized array (same object if copy=False).
    """
    if copy:
        arr = arr.copy()

    # Count issues before fixing (for diagnostics)
    n_nan = np.isnan(arr).sum()
    n_inf = np.isinf(arr).sum()
    n_extreme = ((arr < clip_min) | (arr > clip_max)).sum() - n_inf

    # Fix in order: nan → inf → clip
    np.nan_to_num(arr, copy=False, nan=nan_fill,
                  posinf=inf_fill, neginf=-inf_fill)
    np.clip(arr, clip_min, clip_max, out=arr)

    return arr


def safe_similarity_matrix(
    sim: np.ndarray,
    copy: bool = False,
) -> np.ndarray:
    """
    Sanitize a similarity matrix: ensure [0, 1] range, symmetric, 1 diagonal.

    Parameters
    ----------
    sim : np.ndarray (N, N)
    copy : bool

    Returns
    -------
    np.ndarray (N, N)
    """
    if copy:
        sim = sim.copy()

    # Replace nan/inf
    np.nan_to_num(sim, copy=False, nan=0.0, posinf=1.0, neginf=0.0)

    # Clip to [0, 1]
    np.clip(sim, 0.0, 1.0, out=sim)

    # Ensure diagonal is 1
    np.fill_diagonal(sim, 1.0)

    # Ensure symmetry
    sim = (sim + sim.T) / 2

    return sim


def safe_probabilities(
    probs: np.ndarray,
    copy: bool = False,
) -> np.ndarray:
    """
    Sanitize probability predictions: ensure [0, 1] range, no nan/inf.

    Parameters
    ----------
    probs : np.ndarray
    copy : bool

    Returns
    -------
    np.ndarray
    """
    if copy:
        probs = probs.copy()

    np.nan_to_num(probs, copy=False, nan=0.5, posinf=1.0, neginf=0.0)
    np.clip(probs, 0.0, 1.0, out=probs)

    return probs
