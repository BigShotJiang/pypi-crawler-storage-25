"""
TESSERA Parallel Execution

Provides automatic parallelization across the framework.
Uses joblib for CPU parallelism with memory-aware scheduling.

Usage:
    from tessera.core.parallel import TesseraParallel, parallel_config

    # Set global config
    parallel_config.n_jobs = -1      # all cores
    parallel_config.backend = "loky" # or "threading" for GIL-free ops
    parallel_config.verbose = 1

    # Use in any module
    tp = TesseraParallel()
    results = tp.map(func, items)
"""

import os
import psutil
import numpy as np
from typing import Optional, Callable, List, Any, Dict
from dataclasses import dataclass
import warnings

try:
    from joblib import Parallel, delayed
    HAS_JOBLIB = True
except ImportError:
    HAS_JOBLIB = False


@dataclass
class ParallelConfig:
    """
    Global parallelization configuration for TESSERA.

    Attributes
    ----------
    n_jobs : int
        Number of parallel workers. -1 = all cores, 1 = sequential.
        Default: -1
    backend : str
        Joblib backend: "loky" (process), "threading", "multiprocessing".
        Default: "loky"
    max_memory_gb : float
        Maximum memory per worker in GB. Used for automatic scheduling.
        Default: auto-detect
    verbose : int
        Verbosity level. 0 = silent, 1 = progress, 2+ = debug.
        Default: 0
    prefer_gpu : bool
        Prefer GPU when available. Default: True
    chunk_size : Optional[int]
        For large arrays, process in chunks of this size.
        Default: None (auto)
    """
    n_jobs: int = -1
    backend: str = "loky"
    max_memory_gb: float = 0.0  # 0 = auto-detect
    verbose: int = 0
    prefer_gpu: bool = True
    chunk_size: Optional[int] = None

    def __post_init__(self):
        if self.max_memory_gb <= 0:
            self.max_memory_gb = self._detect_available_memory()

    @staticmethod
    def _detect_available_memory() -> float:
        """Detect available system memory in GB."""
        try:
            mem = psutil.virtual_memory()
            # Use 80% of available memory
            return mem.available / (1024 ** 3) * 0.8
        except Exception:
            return 8.0  # conservative default

    @property
    def effective_n_jobs(self) -> int:
        """Resolve -1 to actual core count."""
        if self.n_jobs == -1:
            return os.cpu_count() or 1
        return max(1, self.n_jobs)

    def memory_safe_n_jobs(self, per_job_gb: float) -> int:
        """
        Compute max parallel jobs that fit in available memory.

        Parameters
        ----------
        per_job_gb : float
            Estimated memory per job in GB.

        Returns
        -------
        int
            Safe number of parallel jobs.
        """
        if per_job_gb <= 0:
            return self.effective_n_jobs

        max_by_memory = max(1, int(self.max_memory_gb / per_job_gb))
        return min(self.effective_n_jobs, max_by_memory)


# Global config instance — modules import and check this
parallel_config = ParallelConfig()


class TesseraParallel:
    """
    Parallel execution engine for TESSERA.

    Wraps joblib with memory-aware scheduling and automatic
    fallback to sequential execution.

    Parameters
    ----------
    n_jobs : int, optional
        Override global config. Default: use parallel_config.
    backend : str, optional
        Override global config.
    memory_per_job_gb : float, optional
        Estimated memory per job. Used to cap parallelism.
    desc : str
        Description for verbose output.
    """

    def __init__(
        self,
        n_jobs: Optional[int] = None,
        backend: Optional[str] = None,
        memory_per_job_gb: float = 0.0,
        desc: str = "",
    ):
        self.config = parallel_config
        self.n_jobs = n_jobs or self.config.n_jobs
        self.backend = backend or self.config.backend
        self.memory_per_job_gb = memory_per_job_gb
        self.desc = desc

    @property
    def effective_jobs(self) -> int:
        """Actual number of jobs considering memory constraints."""
        if self.memory_per_job_gb > 0:
            return self.config.memory_safe_n_jobs(self.memory_per_job_gb)
        return self.config.effective_n_jobs if self.n_jobs == -1 else max(1, self.n_jobs)

    def map(
        self,
        func: Callable,
        items: List[Any],
        **kwargs,
    ) -> List[Any]:
        """
        Parallel map with automatic fallback.

        Parameters
        ----------
        func : callable
            Function to apply to each item.
        items : list
            Items to process.

        Returns
        -------
        list
            Results in same order as items.
        """
        n = self.effective_jobs

        if n <= 1 or not HAS_JOBLIB or len(items) <= 1:
            return [func(item, **kwargs) for item in items]

        if self.config.verbose >= 1 and self.desc:
            print(f"  [{self.desc}] Running {len(items)} tasks "
                  f"on {n} workers...")

        try:
            results = Parallel(
                n_jobs=n,
                backend=self.backend,
                verbose=max(0, self.config.verbose - 1),
            )(delayed(func)(item, **kwargs) for item in items)
            return results
        except Exception as e:
            if self.config.verbose >= 1:
                print(f"  [{self.desc}] Parallel failed ({e}), "
                      f"falling back to sequential")
            return [func(item, **kwargs) for item in items]

    def starmap(
        self,
        func: Callable,
        args_list: List[tuple],
    ) -> List[Any]:
        """
        Parallel starmap — each item is a tuple of arguments.

        Parameters
        ----------
        func : callable
        args_list : list of tuples

        Returns
        -------
        list
        """
        n = self.effective_jobs

        if n <= 1 or not HAS_JOBLIB or len(args_list) <= 1:
            return [func(*args) for args in args_list]

        if self.config.verbose >= 1 and self.desc:
            print(f"  [{self.desc}] Running {len(args_list)} tasks "
                  f"on {n} workers...")

        try:
            results = Parallel(
                n_jobs=n,
                backend=self.backend,
                verbose=max(0, self.config.verbose - 1),
            )(delayed(func)(*args) for args in args_list)
            return results
        except Exception as e:
            if self.config.verbose >= 1:
                print(f"  [{self.desc}] Parallel failed ({e}), "
                      f"falling back to sequential")
            return [func(*args) for args in args_list]


def estimate_similarity_memory_gb(n_entities: int) -> float:
    """Estimate memory for one N×N similarity matrix in GB."""
    return (n_entities ** 2 * 8) / (1024 ** 3)


def compute_chunk_size(n_entities: int, n_matrices: int = 1) -> Optional[int]:
    """
    Determine if chunked processing is needed.

    Returns None if full matrices fit in memory, otherwise
    returns a chunk size that fits.
    """
    mem_per_matrix = estimate_similarity_memory_gb(n_entities)
    available = parallel_config.max_memory_gb

    if mem_per_matrix * n_matrices < available * 0.5:
        return None  # fits in memory

    # Find chunk size that fits
    target_mem = available * 0.3  # conservative
    chunk = int(np.sqrt(target_mem * (1024 ** 3) / 8))
    return min(chunk, n_entities)
