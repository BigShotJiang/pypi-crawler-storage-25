"""
TESSERA Checkpoint System

Saves results after every completed unit of work and resumes
from the last checkpoint on restart.

Design:
- Results stored as JSON in a checkpoint directory
- Each result keyed by (domain, phase, parameters_hash)
- On startup, existing checkpoints are loaded and completed work is skipped
- Thread-safe file writing (atomic rename)

Usage:
    ckpt = CheckpointManager("results/run_001")

    # Check if work is already done
    if ckpt.is_complete("coral", "phase1"):
        result = ckpt.load("coral", "phase1")
    else:
        result = run_phase1(...)
        ckpt.save("coral", "phase1", result)
"""

import os
import json
import hashlib
import time
import tempfile
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy types."""
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            if obj.size < 1000:
                return obj.tolist()
            else:
                return f"<ndarray shape={obj.shape} dtype={obj.dtype}>"
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif hasattr(obj, "to_dict"):
            return obj.to_dict()
        elif hasattr(obj, "__dict__"):
            return {k: v for k, v in obj.__dict__.items()
                    if not k.startswith("_") and not callable(v)}
        return super().default(obj)


class CheckpointManager:
    """
    Manages checkpoints for TESSERA validation runs.

    Saves results after each completed phase and enables
    resumption from the last successful checkpoint.

    Parameters
    ----------
    checkpoint_dir : str
        Directory for checkpoint files.
    run_id : str, optional
        Unique identifier for this run. If None, auto-generated
        from timestamp.
    """

    def __init__(
        self,
        checkpoint_dir: str = "results",
        run_id: Optional[str] = None,
    ):
        self.checkpoint_dir = checkpoint_dir
        self.run_id = run_id or f"run_{int(time.time())}"
        self.run_dir = os.path.join(checkpoint_dir, self.run_id)
        os.makedirs(self.run_dir, exist_ok=True)

        # Load existing checkpoint index
        self._index_path = os.path.join(self.run_dir, "index.json")
        self._index = self._load_index()

        # Track timing
        self._start_time = time.time()

    def _load_index(self) -> Dict[str, Any]:
        """Load existing checkpoint index."""
        if os.path.exists(self._index_path):
            with open(self._index_path, "r") as f:
                return json.load(f)
        return {
            "run_id": self.run_id,
            "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "completed": {},
            "config": {},
        }

    def _save_index(self):
        """Save checkpoint index atomically."""
        self._index["last_updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._atomic_write(self._index_path, self._index)

    def _key(self, domain: str, phase: str) -> str:
        """Generate checkpoint key."""
        return f"{domain}__{phase}"

    def _filepath(self, domain: str, phase: str) -> str:
        """Generate checkpoint file path."""
        return os.path.join(self.run_dir, f"{domain}_{phase}.json")

    def save_config(self, config: Dict[str, Any]):
        """Save run configuration for reproducibility."""
        self._index["config"] = config
        self._save_index()

    def is_complete(self, domain: str, phase: str) -> bool:
        """Check if a (domain, phase) combination is already done."""
        key = self._key(domain, phase)
        return key in self._index["completed"]

    def save(
        self,
        domain: str,
        phase: str,
        result: Any,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Save a completed phase result.

        Parameters
        ----------
        domain : str
            Domain name (e.g., "synthetic", "coral", "secom")
        phase : str
            Phase name (e.g., "phase1", "phase2", "phase3", "phase4")
        result : Any
            Result object (must be JSON-serializable or have to_dict/summary)
        metadata : dict, optional
            Additional metadata to store.
        """
        key = self._key(domain, phase)
        filepath = self._filepath(domain, phase)

        # Serialize result
        checkpoint = {
            "domain": domain,
            "phase": phase,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "elapsed_seconds": time.time() - self._start_time,
            "metadata": metadata or {},
        }

        # Handle different result types
        if isinstance(result, dict):
            checkpoint.update(result)
            self._atomic_write(filepath, checkpoint)
            self._index["completed"][key] = {
                "timestamp": checkpoint["timestamp"],
                "filepath": os.path.basename(filepath),
            }
            self._save_index()
            return

        if hasattr(result, "summary"):
            checkpoint["summary"] = result.summary()

        if hasattr(result, "model_results"):
            # AblationResult
            checkpoint["model_results"] = {}
            for name, res in result.model_results.items():
                m = res["metrics_mean"]
                checkpoint["model_results"][name] = {
                    "auc_roc": m.auc_roc,
                    "auc_pr": m.auc_pr,
                    "f1": m.f1,
                    "mcc": m.mcc,
                    "precision": m.precision,
                    "recall": m.recall,
                    "accuracy": m.accuracy,
                    "time": res.get("time", 0),
                    "type": res.get("type", "unknown"),
                }

        if hasattr(result, "method_results"):
            # SimilarityComparisonResult
            checkpoint["method_results"] = {}
            for name, res in result.method_results.items():
                m = res["metrics_mean"]
                checkpoint["method_results"][name] = {
                    "auc_roc": m.auc_roc,
                    "f1": m.f1,
                    "mcc": m.mcc,
                    "separation": res.get("separation", 0),
                    "time": res.get("time", 0),
                }
            if hasattr(result, "fusion_result") and result.fusion_result:
                fr = result.fusion_result
                checkpoint["fusion"] = {
                    "auc_roc": fr["metrics_mean"].auc_roc,
                    "weights": fr.get("weights", {}),
                }

        if hasattr(result, "results") and isinstance(result.results, dict):
            # BinSensitivityResult
            checkpoint["bin_results"] = {}
            for n_bins, res in result.results.items():
                m = res.get("metrics_mean")
                checkpoint["bin_results"][str(n_bins)] = {
                    "auc_roc": m.auc_roc if m else 0,
                    "f1": m.f1 if m else 0,
                    "separation": res.get("separation", 0),
                    "time": res.get("time", 0),
                }

        if hasattr(result, "fold_results"):
            # TemporalCVResult
            checkpoint["fold_results"] = []
            for fr in result.fold_results:
                m = fr["metrics"]
                checkpoint["fold_results"].append({
                    "fold": fr["fold"],
                    "test_window": fr["test_window"],
                    "auc_roc": m.auc_roc,
                    "f1": m.f1,
                    "mcc": m.mcc,
                })
            checkpoint["mean_auc"] = result.mean_metrics.auc_roc
            checkpoint["std_auc"] = result.std_metrics.get("auc_roc", 0)

        # Write atomically
        self._atomic_write(filepath, checkpoint)

        # Update index
        self._index["completed"][key] = {
            "timestamp": checkpoint["timestamp"],
            "filepath": os.path.basename(filepath),
        }
        self._save_index()

        print(f"  [Checkpoint] Saved: {domain}/{phase}")

    def load(self, domain: str, phase: str) -> Optional[Dict[str, Any]]:
        """
        Load a saved checkpoint.

        Returns
        -------
        dict or None
        """
        filepath = self._filepath(domain, phase)
        if os.path.exists(filepath):
            with open(filepath, "r") as f:
                return json.load(f)
        return None

    def list_completed(self) -> List[str]:
        """List all completed (domain, phase) combinations."""
        return list(self._index["completed"].keys())

    def progress_summary(self) -> str:
        """Human-readable progress summary."""
        completed = self._index["completed"]
        elapsed = time.time() - self._start_time

        lines = [
            f"TESSERA Checkpoint Summary — {self.run_id}",
            "=" * 50,
            f"Directory:   {self.run_dir}",
            f"Completed:   {len(completed)} phases",
            f"Elapsed:     {elapsed / 60:.1f} minutes",
            "",
        ]

        if completed:
            lines.append("Completed work:")
            for key, info in sorted(completed.items()):
                lines.append(f"  ✓ {key:30s} ({info['timestamp']})")

        # Show what's pending
        all_work = []
        for domain in ["synthetic", "coral", "secom"]:
            for phase in ["phase1", "phase2", "phase3", "phase4"]:
                all_work.append(f"{domain}__{phase}")

        pending = [w for w in all_work if w not in completed]
        if pending:
            lines.append("")
            lines.append("Pending:")
            for key in pending:
                lines.append(f"  ○ {key}")

        return "\n".join(lines)

    def _atomic_write(self, filepath: str, data: Any):
        """Write file atomically via temporary file + rename."""
        dir_name = os.path.dirname(filepath)
        with tempfile.NamedTemporaryFile(
            mode="w", dir=dir_name, suffix=".tmp",
            delete=False,
        ) as tmp:
            json.dump(data, tmp, indent=2, cls=NumpyEncoder)
            tmp_path = tmp.name

        os.replace(tmp_path, filepath)


def get_or_create_checkpoint(
    results_dir: str = "results",
    run_id: Optional[str] = None,
    resume: bool = True,
) -> CheckpointManager:
    """
    Get an existing checkpoint or create a new one.

    If resume=True and a previous run exists, loads it.
    Otherwise creates a fresh checkpoint.

    Parameters
    ----------
    results_dir : str
    run_id : str, optional
        Specific run to resume. If None and resume=True,
        uses the most recent run.
    resume : bool
        Whether to attempt resuming.

    Returns
    -------
    CheckpointManager
    """
    if resume and run_id is None:
        # Find most recent run
        if os.path.exists(results_dir):
            runs = [
                d for d in os.listdir(results_dir)
                if os.path.isdir(os.path.join(results_dir, d))
                and os.path.exists(os.path.join(results_dir, d, "index.json"))
            ]
            if runs:
                # Sort by modification time (most recent first)
                runs.sort(
                    key=lambda d: os.path.getmtime(
                        os.path.join(results_dir, d, "index.json")
                    ),
                    reverse=True,
                )
                run_id = runs[0]
                print(f"  [Checkpoint] Resuming: {run_id}")

    return CheckpointManager(results_dir, run_id)
