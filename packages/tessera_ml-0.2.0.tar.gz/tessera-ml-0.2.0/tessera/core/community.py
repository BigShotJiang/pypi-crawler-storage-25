"""
TESSERA Community Detection

Discovers operational domains (regimes) directly from the similarity
network topology, without requiring a priori domain assignments.

Three methods spanning network science and phylogenetics:
- Leiden algorithm (primary): fast, resolution-adjustable, quality-optimal
- Spectral clustering (robustness check): deterministic, well-understood
- Neighbor Joining (phylogenetic bridge): hierarchical tree from distances,
  enabling direct connection to phylogenetic regime detection methods
  (Uyeda & Harmon 2014, bayou)

This is Step 2 of the TESSERA workflow:
  Characterize → **Discover** → Quantify → Predict → Test → Generalize
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
import warnings

try:
    import igraph as ig
    import leidenalg
    HAS_LEIDEN = True
except ImportError:
    HAS_LEIDEN = False

from sklearn.cluster import SpectralClustering
from scipy.cluster.hierarchy import fcluster
from scipy.spatial.distance import squareform


@dataclass
class CommunityStructure:
    """
    Discovered community (regime) structure from network topology.

    Stores community assignments, quality metrics, and boundary
    information for regime divergence computation.
    """
    # Community assignments
    labels: np.ndarray              # (N,) community label per entity
    n_communities: int              # number of discovered communities

    # Quality metrics
    modularity: float               # network modularity score
    method: str                     # detection method used

    # Boundary information (computed lazily)
    _boundary_pairs: Optional[List[Tuple[int, int]]] = field(
        default=None, repr=False
    )
    _boundary_entities: Optional[np.ndarray] = field(
        default=None, repr=False
    )

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def community_sizes(self) -> Dict[int, int]:
        """Size of each community."""
        labels, counts = np.unique(self.labels, return_counts=True)
        return dict(zip(labels.astype(int), counts.astype(int)))

    def entities_in(self, community_id: int) -> np.ndarray:
        """Indices of entities in a given community."""
        return np.where(self.labels == community_id)[0]

    def find_boundary_entities(
        self,
        edge_index: np.ndarray,
        threshold: float = 0.3,
    ) -> np.ndarray:
        """
        Find entities at regime boundaries.

        An entity is at a boundary if a significant fraction of its
        neighbors belong to a different community.

        Parameters
        ----------
        edge_index : np.ndarray
            (2, E) edge list from TesseraGraph.
        threshold : float
            Minimum fraction of cross-community neighbors to qualify
            as a boundary entity. Default: 0.3

        Returns
        -------
        np.ndarray
            Indices of boundary entities.
        """
        N = len(self.labels)
        cross_fractions = np.zeros(N)

        for node in range(N):
            neighbor_mask = edge_index[0] == node
            neighbors = edge_index[1, neighbor_mask]

            if len(neighbors) == 0:
                continue

            node_community = self.labels[node]
            n_cross = np.sum(self.labels[neighbors] != node_community)
            cross_fractions[node] = n_cross / len(neighbors)

        self._boundary_entities = np.where(cross_fractions >= threshold)[0]
        return self._boundary_entities

    def find_boundary_pairs(
        self, edge_index: np.ndarray
    ) -> List[Tuple[int, int]]:
        """
        Find pairs of communities that share a boundary.

        Two communities share a boundary if there exist edges between
        entities in each.

        Parameters
        ----------
        edge_index : np.ndarray
            (2, E) edge list.

        Returns
        -------
        list of (int, int)
            Pairs of community IDs that share boundaries.
        """
        pairs = set()
        for e in range(edge_index.shape[1]):
            src_comm = self.labels[edge_index[0, e]]
            tgt_comm = self.labels[edge_index[1, e]]
            if src_comm != tgt_comm:
                pair = (min(src_comm, tgt_comm), max(src_comm, tgt_comm))
                pairs.add(pair)

        self._boundary_pairs = sorted(pairs)
        return self._boundary_pairs

    def summary(self) -> str:
        """Human-readable summary."""
        lines = [
            "TESSERA Community Structure",
            "=" * 45,
            f"Method:          {self.method}",
            f"Communities:      {self.n_communities}",
            f"Modularity:      {self.modularity:.4f}",
            "",
            "Community sizes:",
        ]
        for comm_id, size in sorted(self.community_sizes.items()):
            pct = 100 * size / len(self.labels)
            lines.append(f"  Community {comm_id}: {size} ({pct:.1f}%)")

        if self._boundary_entities is not None:
            lines.append(f"")
            lines.append(
                f"Boundary entities: {len(self._boundary_entities)} "
                f"({100 * len(self._boundary_entities) / len(self.labels):.1f}%)"
            )

        if self._boundary_pairs is not None:
            lines.append(f"Boundary pairs:    {len(self._boundary_pairs)}")

        return "\n".join(lines)


@dataclass
class NJTree:
    """
    Neighbor Joining tree built from entity distances.

    Provides the hierarchical phylogenetic bridge between TESSERA's
    network-based community detection and phylogenetic regime detection
    methods (Uyeda & Harmon 2014).

    The tree can be cut at different heights to produce community
    assignments at multiple scales, or exported for direct use with
    phylogenetic comparative methods.
    """
    # Tree structure (scipy linkage-compatible format)
    linkage_matrix: np.ndarray      # (N-1, 4) linkage matrix
    leaf_order: np.ndarray          # (N,) order of leaves in tree

    # Newick string for export to phylogenetic tools
    newick: Optional[str] = None

    # Distance matrix used to build the tree
    distance_matrix: Optional[np.ndarray] = field(default=None, repr=False)

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def cut_tree(self, n_clusters: int) -> np.ndarray:
        """
        Cut the tree to produce a flat clustering with n_clusters groups.

        Parameters
        ----------
        n_clusters : int
            Number of clusters to produce.

        Returns
        -------
        np.ndarray (N,)
            Cluster labels.
        """
        labels = fcluster(self.linkage_matrix, t=n_clusters,
                          criterion="maxclust")
        # fcluster returns 1-indexed labels; convert to 0-indexed
        return labels - 1

    def cut_at_height(self, height: float) -> np.ndarray:
        """
        Cut the tree at a specific distance height.

        Parameters
        ----------
        height : float
            Distance threshold for cutting.

        Returns
        -------
        np.ndarray (N,)
            Cluster labels.
        """
        labels = fcluster(self.linkage_matrix, t=height,
                          criterion="distance")
        return labels - 1

    def summary(self) -> str:
        """Human-readable summary."""
        n_leaves = self.linkage_matrix.shape[0] + 1
        heights = self.linkage_matrix[:, 2]
        lines = [
            "TESSERA NJ Tree Summary",
            "=" * 40,
            f"Leaves:          {n_leaves}",
            f"Height range:    [{heights.min():.4f}, {heights.max():.4f}]",
            f"Mean height:     {heights.mean():.4f}",
        ]

        # Show community counts at different cuts
        lines.append("")
        lines.append("Communities at different cut levels:")
        for k in [2, 3, 4, 5, 8, 10]:
            if k >= n_leaves:
                break
            labels = self.cut_tree(k)
            sizes = np.bincount(labels)
            lines.append(f"  k={k}: sizes={list(sizes)}")

        return "\n".join(lines)


class CommunityDetector:
    """
    Discovers community structure from similarity networks.

    Implements three methods:
    - Leiden algorithm (primary): fast, resolution-adjustable, quality-optimal
    - Spectral clustering (robustness check): deterministic, well-understood
    - Neighbor Joining (phylogenetic bridge): builds hierarchical tree from
      distances, then cuts to produce flat communities. Enables direct
      connection to bayou-style regime detection.

    Parameters
    ----------
    method : str
        "leiden", "spectral", or "nj". Default: "leiden"
    resolution : float
        Resolution parameter for Leiden. Higher values produce more,
        smaller communities. Default: 1.0
    n_communities : int, optional
        Fixed number of communities for spectral and NJ.
        If None with spectral, auto-selects via eigengap heuristic.
        If None with NJ, uses the same eigengap heuristic.
    random_state : int, optional
        Random seed for reproducibility.
    """

    VALID_METHODS = {"leiden", "spectral", "nj"}

    def __init__(
        self,
        method: str = "leiden",
        resolution: float = 1.0,
        n_communities: Optional[int] = None,
        random_state: Optional[int] = None,
    ):
        if method not in self.VALID_METHODS:
            raise ValueError(
                f"method must be one of {self.VALID_METHODS}, "
                f"got '{method}'"
            )

        if method == "leiden" and not HAS_LEIDEN:
            warnings.warn(
                "leidenalg/igraph not installed, falling back to spectral. "
                "Install with: pip install leidenalg igraph"
            )
            method = "spectral"

        self.method = method
        self.resolution = resolution
        self.n_communities = n_communities
        self.random_state = random_state

    def detect(
        self,
        similarity_matrix: np.ndarray,
        edge_index: Optional[np.ndarray] = None,
        edge_weights: Optional[np.ndarray] = None,
    ) -> CommunityStructure:
        """
        Detect communities from a similarity network.

        Can accept either a full similarity matrix or a sparse edge
        representation (edge_index + edge_weights from TesseraGraph).

        Parameters
        ----------
        similarity_matrix : np.ndarray
            (N, N) pairwise similarity matrix. Can be None if edge_index
            and edge_weights are provided.
        edge_index : np.ndarray, optional
            (2, E) edge list. If provided with edge_weights, used instead
            of similarity_matrix for efficiency.
        edge_weights : np.ndarray, optional
            (E,) edge weights.

        Returns
        -------
        CommunityStructure
        """
        if self.method == "leiden":
            return self._detect_leiden(
                similarity_matrix, edge_index, edge_weights
            )
        elif self.method == "nj":
            return self._detect_nj(similarity_matrix)
        else:
            return self._detect_spectral(similarity_matrix)

    def _detect_leiden(
        self,
        similarity_matrix: Optional[np.ndarray],
        edge_index: Optional[np.ndarray],
        edge_weights: Optional[np.ndarray],
    ) -> CommunityStructure:
        """Leiden community detection via igraph."""
        # Build igraph graph
        if edge_index is not None and edge_weights is not None:
            if similarity_matrix is not None:
                N = max(int(edge_index.max()) + 1, similarity_matrix.shape[0])
            else:
                N = int(edge_index.max()) + 1
            edges = list(zip(
                edge_index[0].astype(int),
                edge_index[1].astype(int),
            ))
            g = ig.Graph(n=int(N), edges=edges, directed=False)
            g.es["weight"] = edge_weights.tolist()
        elif similarity_matrix is not None:
            N = similarity_matrix.shape[0]
            # Convert dense matrix to weighted graph
            # Only use upper triangle to avoid duplicate edges
            rows, cols = np.triu_indices(N, k=1)
            weights = similarity_matrix[rows, cols]

            # Filter out zero/near-zero weights
            mask = weights > 1e-6
            edges = list(zip(
                rows[mask].astype(int),
                cols[mask].astype(int),
            ))
            g = ig.Graph(n=N, edges=edges, directed=False)
            g.es["weight"] = weights[mask].tolist()
        else:
            raise ValueError(
                "Must provide either similarity_matrix or "
                "edge_index + edge_weights"
            )

        # Run Leiden
        partition = leidenalg.find_partition(
            g,
            leidenalg.RBConfigurationVertexPartition,
            weights="weight",
            resolution_parameter=self.resolution,
            seed=self.random_state,
        )

        labels = np.array(partition.membership)
        modularity = partition.modularity

        return CommunityStructure(
            labels=labels,
            n_communities=len(set(labels)),
            modularity=modularity,
            method="leiden",
            metadata={
                "resolution": self.resolution,
                "random_state": self.random_state,
                "quality": partition.quality(),
            },
        )

    def _detect_spectral(
        self, similarity_matrix: np.ndarray
    ) -> CommunityStructure:
        """Spectral clustering on similarity matrix."""
        N = similarity_matrix.shape[0]

        # Auto-select n_communities via eigengap if not specified
        if self.n_communities is None:
            n_clusters = self._eigengap_heuristic(similarity_matrix)
        else:
            n_clusters = self.n_communities

        n_clusters = min(n_clusters, N - 1)
        n_clusters = max(n_clusters, 2)

        sc = SpectralClustering(
            n_clusters=n_clusters,
            affinity="precomputed",
            random_state=self.random_state,
            assign_labels="kmeans",
        )

        labels = sc.fit_predict(similarity_matrix)

        # Compute modularity manually
        modularity = self._compute_modularity(similarity_matrix, labels)

        return CommunityStructure(
            labels=labels,
            n_communities=n_clusters,
            modularity=modularity,
            method="spectral",
            metadata={
                "n_clusters_requested": n_clusters,
                "eigengap_auto": self.n_communities is None,
                "random_state": self.random_state,
            },
        )

    def _detect_nj(
        self, similarity_matrix: np.ndarray
    ) -> CommunityStructure:
        """
        Neighbor Joining tree construction and community extraction.

        Builds an NJ tree (Saitou & Nei, 1987) from the distance matrix
        derived from similarities, then cuts the tree to produce flat
        community assignments.

        This provides the phylogenetic bridge: the NJ tree is exactly
        the structure that bayou (Uyeda & Harmon, 2014) operates on
        for regime detection on phylogenies.
        """
        N = similarity_matrix.shape[0]

        # Convert similarity to distance
        distance_matrix = 1.0 - np.clip(similarity_matrix, 0, 1)
        np.fill_diagonal(distance_matrix, 0.0)

        # Build NJ tree via Saitou-Nei algorithm
        linkage_matrix, leaf_order = self._neighbor_joining(distance_matrix)

        # Determine number of communities
        if self.n_communities is None:
            n_clusters = self._eigengap_heuristic(similarity_matrix)
        else:
            n_clusters = self.n_communities

        n_clusters = min(n_clusters, N - 1)
        n_clusters = max(n_clusters, 2)

        # Build NJTree object
        nj_tree = NJTree(
            linkage_matrix=linkage_matrix,
            leaf_order=leaf_order,
            distance_matrix=distance_matrix,
            metadata={
                "algorithm": "neighbor_joining",
                "n_leaves": N,
            },
        )

        # Cut tree to get community assignments
        labels = nj_tree.cut_tree(n_clusters)

        # Compute modularity
        modularity = self._compute_modularity(similarity_matrix, labels)

        return CommunityStructure(
            labels=labels,
            n_communities=len(np.unique(labels)),
            modularity=modularity,
            method="nj",
            metadata={
                "n_clusters": n_clusters,
                "nj_tree": nj_tree,
                "random_state": self.random_state,
            },
        )

    @staticmethod
    def _neighbor_joining(distance_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Saitou-Nei Neighbor Joining algorithm.

        Builds an unrooted tree from a distance matrix, then converts
        to a scipy-compatible linkage matrix via midpoint rooting.

        Parameters
        ----------
        distance_matrix : np.ndarray (N, N)
            Pairwise distance matrix.

        Returns
        -------
        linkage_matrix : np.ndarray (N-1, 4)
            Scipy-compatible linkage matrix [idx_i, idx_j, dist, count].
        leaf_order : np.ndarray (N,)
            Order of leaves encountered during construction.

        References
        ----------
        Saitou, N. & Nei, M. (1987). The neighbor-joining method: a new
        method for reconstructing phylogenetic trees. Mol. Biol. Evol.
        4(4), 406-425.
        """
        N = distance_matrix.shape[0]
        D = distance_matrix.copy()

        # Active node indices
        active = list(range(N))
        # Node sizes (for linkage matrix)
        node_sizes = {i: 1 for i in range(N)}
        # Merge history for linkage matrix
        merges = []
        next_node_id = N

        while len(active) > 2:
            n = len(active)

            # Compute row sums for active nodes
            row_sums = {}
            for i in active:
                row_sums[i] = sum(D[i, j] for j in active if j != i)

            # Compute Q matrix and find minimum
            min_q = np.inf
            min_i, min_j = active[0], active[1]

            for ai in range(n):
                for aj in range(ai + 1, n):
                    i, j = active[ai], active[aj]
                    q = (n - 2) * D[i, j] - row_sums[i] - row_sums[j]
                    if q < min_q:
                        min_q = q
                        min_i, min_j = i, j

            # Compute branch lengths from min_i and min_j to new node
            n_active = len(active)
            if n_active > 2:
                d_iu = D[min_i, min_j] / 2 + \
                    (row_sums[min_i] - row_sums[min_j]) / (2 * (n_active - 2))
                d_ju = D[min_i, min_j] - d_iu
            else:
                d_iu = D[min_i, min_j] / 2
                d_ju = D[min_i, min_j] / 2

            # Ensure non-negative branch lengths
            d_iu = max(d_iu, 0.0)
            d_ju = max(d_ju, 0.0)

            # Record merge with average distance for linkage compatibility
            merge_dist = (d_iu + d_ju) / 2
            merge_size = node_sizes[min_i] + node_sizes[min_j]
            merges.append([min_i, min_j, merge_dist, merge_size])

            # Create new node
            u = next_node_id
            next_node_id += 1
            node_sizes[u] = merge_size

            # Expand distance matrix for new node
            new_size = D.shape[0] + 1
            D_new = np.zeros((new_size, new_size))
            D_new[:D.shape[0], :D.shape[0]] = D

            # Compute distances from new node to all remaining nodes
            for k in active:
                if k == min_i or k == min_j:
                    continue
                d_ku = (D[k, min_i] + D[k, min_j] - D[min_i, min_j]) / 2
                d_ku = max(d_ku, 0.0)
                D_new[u, k] = d_ku
                D_new[k, u] = d_ku

            D = D_new

            # Update active list
            active.remove(min_i)
            active.remove(min_j)
            active.append(u)

        # Final merge of last two nodes
        if len(active) == 2:
            i, j = active
            merge_dist = D[i, j] / 2
            merge_size = node_sizes[i] + node_sizes[j]
            merges.append([i, j, merge_dist, merge_size])

        # Convert to scipy linkage format
        # Need to remap node IDs so that merges reference 0..N-1 for
        # leaves and N..2N-2 for internal nodes
        id_map = {i: i for i in range(N)}
        linkage = np.zeros((N - 1, 4))

        for merge_idx, (i, j, dist, size) in enumerate(merges):
            new_id = N + merge_idx
            linkage[merge_idx] = [id_map.get(i, i), id_map.get(j, j),
                                  dist, size]
            id_map[N + merge_idx if merge_idx < len(merges) - 1
                   else active[0] if len(active) > 0
                   else N + merge_idx] = new_id

            # Map the merged node ID to the scipy internal node ID
            # The node created in iteration merge_idx is N + merge_idx
            # in scipy's convention
            id_map[i if i >= N else -1] = id_map.get(i, i)
            id_map[j if j >= N else -1] = id_map.get(j, j)

            # Update the map for the new node created by NJ
            nj_new_node = N + len(merges) - 1 + merge_idx + 1
            if merge_idx < len(merges) - 1:
                # Find the NJ node id that was created
                for m in merges[merge_idx + 1:]:
                    for k in range(2):
                        if m[k] not in id_map and m[k] >= N:
                            pass

        # Simpler approach: use the merge order directly
        # Remap NJ internal node IDs to scipy's sequential IDs
        linkage = np.zeros((N - 1, 4))
        nj_to_scipy = {i: i for i in range(N)}  # leaves stay the same
        scipy_next = N

        for merge_idx, (i, j, dist, size) in enumerate(merges):
            scipy_i = nj_to_scipy.get(int(i), int(i))
            scipy_j = nj_to_scipy.get(int(j), int(j))

            # Ensure consistent ordering (smaller index first)
            if scipy_i > scipy_j:
                scipy_i, scipy_j = scipy_j, scipy_i

            linkage[merge_idx] = [scipy_i, scipy_j, dist, size]

            # Map the NJ node that was created to scipy's sequential ID
            nj_node = N + merge_idx  # approximate: NJ creates nodes sequentially
            # Find the actual NJ node ID created in this step
            # In our implementation, the new node added to active after
            # merging i,j has ID = N + merge_idx (since next_node_id
            # increments from N)
            nj_to_scipy[N + merge_idx] = scipy_next
            scipy_next += 1

        # Ensure distances are monotonically increasing (required by scipy)
        for k in range(1, len(linkage)):
            if linkage[k, 2] < linkage[k - 1, 2]:
                linkage[k, 2] = linkage[k - 1, 2] + 1e-10

        leaf_order = np.arange(N)

        return linkage, leaf_order

    def _eigengap_heuristic(
        self, similarity_matrix: np.ndarray, max_k: int = 20
    ) -> int:
        """
        Select number of clusters via eigengap heuristic.

        Computes eigenvalues of the graph Laplacian and finds the
        largest gap, suggesting the natural number of clusters.
        """
        # Degree matrix
        D = np.diag(similarity_matrix.sum(axis=1))
        # Laplacian
        L = D - similarity_matrix

        # Compute smallest eigenvalues
        max_k = min(max_k, similarity_matrix.shape[0] - 1)

        try:
            from scipy.sparse.linalg import eigsh
            eigenvalues = eigsh(
                L, k=max_k, which="SM", return_eigenvectors=False
            )
            eigenvalues = np.sort(eigenvalues)
        except Exception:
            eigenvalues = np.sort(np.linalg.eigvalsh(L))[:max_k]

        # Find largest gap
        gaps = np.diff(eigenvalues)

        # Skip the first eigenvalue (always ~0 for connected graphs)
        if len(gaps) > 1:
            k = np.argmax(gaps[1:]) + 2  # +2: skip first gap, 1-indexed
        else:
            k = 2

        return int(k)

    @staticmethod
    def _compute_modularity(
        similarity_matrix: np.ndarray, labels: np.ndarray
    ) -> float:
        """Vectorized Newman modularity computation."""
        W = similarity_matrix.copy()
        np.fill_diagonal(W, 0)
        m = W.sum() / 2

        if m == 0:
            return 0.0

        k = W.sum(axis=1)

        # Vectorized: Q = (1/2m) * Tr(S^T * B * S)
        unique_labels = np.unique(labels)
        n_comms = len(unique_labels)
        label_map = {l: i for i, l in enumerate(unique_labels)}

        S = np.zeros((len(labels), n_comms))
        for i, l in enumerate(labels):
            S[i, label_map[l]] = 1.0

        B = W - np.outer(k, k) / (2 * m)
        Q = np.trace(S.T @ B @ S) / (2 * m)
        return float(Q)

    def metadata_dict(self) -> Dict[str, Any]:
        """Return configuration for reproducibility."""
        return {
            "method": self.method,
            "resolution": self.resolution,
            "n_communities": self.n_communities,
            "random_state": self.random_state,
        }


@dataclass
class PersistenceResult:
    """
    Results of temporal community persistence analysis.

    Quantifies how stable each discovered community is across
    temporal windows. Analogous to the posterior probability of
    a regime shift in bayou (Uyeda & Harmon 2014) — communities
    that persist across all windows have high "regime confidence,"
    while transient communities that appear in only one window
    may reflect stochastic perturbations.
    """
    # Per-community persistence scores
    community_persistence: Dict[int, float]  # comm_id → fraction of windows present

    # Per-entity persistence-weighted community confidence
    entity_regime_confidence: np.ndarray     # (N,) confidence score per entity

    # Temporal community structure
    window_labels: Dict[int, np.ndarray]     # window_id → (N_window,) labels
    window_n_communities: Dict[int, int]     # window_id → n communities found

    # Cross-window alignment metrics
    mean_ari_across_windows: float           # mean ARI between consecutive windows
    community_birth_death: Dict[int, Dict[str, Any]]  # per-community lifecycle

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def n_stable_communities(self) -> int:
        """Communities present in >80% of time windows."""
        return sum(1 for p in self.community_persistence.values() if p > 0.8)

    @property
    def n_transient_communities(self) -> int:
        """Communities present in <30% of time windows."""
        return sum(1 for p in self.community_persistence.values() if p < 0.3)

    def summary(self) -> str:
        """Human-readable summary."""
        lines = [
            "TESSERA Community Persistence Analysis",
            "=" * 50,
            f"Total communities:     {len(self.community_persistence)}",
            f"Stable (>80%):         {self.n_stable_communities}",
            f"Transient (<30%):      {self.n_transient_communities}",
            f"Mean ARI across time:  {self.mean_ari_across_windows:.4f}",
            "",
            "Per-community persistence:",
        ]

        for comm_id in sorted(self.community_persistence.keys()):
            p = self.community_persistence[comm_id]
            status = "STABLE" if p > 0.8 else "TRANSIENT" if p < 0.3 else "moderate"
            lines.append(f"  Community {comm_id}: {p:.2f} [{status}]")

        # Entity confidence distribution
        ec = self.entity_regime_confidence
        lines.append("")
        lines.append("Entity regime confidence:")
        lines.append(f"  Mean:   {ec.mean():.4f}")
        lines.append(f"  Std:    {ec.std():.4f}")
        lines.append(f"  Min:    {ec.min():.4f}")
        lines.append(f"  Max:    {ec.max():.4f}")

        n_low = np.sum(ec < 0.3)
        lines.append(f"  Low confidence (<0.3): {n_low} entities "
                      f"({100 * n_low / len(ec):.1f}%)")

        return "\n".join(lines)


class CommunityPersistenceAnalyzer:
    """
    Analyzes temporal stability of community structure.

    Re-runs community detection on each temporal window independently
    and measures how consistently each community appears across time.

    This addresses the risk of stochastic events creating artificial
    regime boundaries — a major El Niño, equipment malfunction, or
    unusual workload could create a temporary community that doesn't
    represent durable operational structure.

    The persistence score is TESSERA's frequentist analog to bayou's
    posterior probability for regime shifts: high persistence = high
    confidence that the regime is real, not a stochastic artifact.

    Parameters
    ----------
    detector : CommunityDetector
        Community detection method to use per window.
    min_window_size : int
        Minimum entities in a window to run detection. Default: 30
    alignment_method : str
        How to align communities across windows.
        "hungarian": optimal assignment via Hungarian algorithm.
        "overlap": align by maximum entity overlap.
        Default: "overlap"
    """

    def __init__(
        self,
        detector: Optional[CommunityDetector] = None,
        min_window_size: int = 30,
        alignment_method: str = "overlap",
    ):
        if detector is None:
            detector = CommunityDetector(
                method="leiden", resolution=0.5, random_state=42
            )
        self.detector = detector
        self.min_window_size = min_window_size
        self.alignment_method = alignment_method

    def analyze(
        self,
        features: np.ndarray,
        time_windows: np.ndarray,
        global_communities: CommunityStructure,
        similarity_engine=None,
    ) -> PersistenceResult:
        """
        Analyze community persistence across temporal windows.

        Parameters
        ----------
        features : np.ndarray (N, D)
            Entity features.
        time_windows : np.ndarray (N,)
            Time window assignments.
        global_communities : CommunityStructure
            Communities discovered from the full dataset.
        similarity_engine : SimilarityEngine, optional
            Similarity computation method. If None, uses Mahalanobis.

        Returns
        -------
        PersistenceResult
        """
        if similarity_engine is None:
            from .similarity import SimilarityEngine
            similarity_engine = SimilarityEngine(method="mahalanobis")

        unique_windows = np.sort(np.unique(time_windows))
        n_windows = len(unique_windows)
        N = len(features)
        n_global_comms = global_communities.n_communities

        # ── Per-window community detection ───────────────────
        window_labels = {}
        window_n_comms = {}
        window_global_aligned = {}  # aligned to global community IDs

        for w in unique_windows:
            w_mask = time_windows == w
            n_w = w_mask.sum()

            if n_w < self.min_window_size:
                # Too small — assign all to community 0
                window_labels[int(w)] = np.zeros(n_w, dtype=int)
                window_n_comms[int(w)] = 1
                window_global_aligned[int(w)] = np.zeros(n_w, dtype=int)
                continue

            # Compute similarity for this window's entities
            w_features = features[w_mask]
            w_sim = similarity_engine.compute(w_features, normalize=True)

            # Detect communities in this window
            w_communities = self.detector.detect(similarity_matrix=w_sim)
            window_labels[int(w)] = w_communities.labels
            window_n_comms[int(w)] = w_communities.n_communities

            # Align window communities to global communities
            global_labels_w = global_communities.labels[w_mask]
            aligned = self._align_communities(
                w_communities.labels, global_labels_w, n_global_comms
            )
            window_global_aligned[int(w)] = aligned

        # ── Compute persistence per global community ─────────
        community_window_presence = {
            c: [] for c in range(n_global_comms)
        }

        for w in unique_windows:
            w_mask = time_windows == w
            aligned = window_global_aligned[int(w)]
            global_labels_w = global_communities.labels[w_mask]

            # For each global community, check if it was recovered
            for c in range(n_global_comms):
                # Entities that belong to global community c in this window
                gc_mask = global_labels_w == c
                if gc_mask.sum() == 0:
                    continue

                # What fraction of these entities were assigned to the
                # same aligned community in the per-window detection?
                aligned_labels = aligned[gc_mask]
                # Most common aligned label for these entities
                if len(aligned_labels) > 0:
                    most_common = np.bincount(aligned_labels).argmax()
                    agreement = (aligned_labels == most_common).mean()
                    community_window_presence[c].append(agreement)

        # Persistence = mean agreement across windows where community exists
        community_persistence = {}
        for c in range(n_global_comms):
            if community_window_presence[c]:
                community_persistence[c] = float(
                    np.mean(community_window_presence[c])
                )
            else:
                community_persistence[c] = 0.0

        # ── Per-entity regime confidence ─────────────────────
        # Entity confidence = persistence of its community
        entity_confidence = np.zeros(N)
        for i in range(N):
            comm = int(global_communities.labels[i])
            entity_confidence[i] = community_persistence.get(comm, 0.0)

        # ── Cross-window ARI ─────────────────────────────────
        from sklearn.metrics import adjusted_rand_score

        ari_pairs = []
        sorted_windows = sorted(unique_windows)
        for i in range(len(sorted_windows) - 1):
            w1, w2 = sorted_windows[i], sorted_windows[i + 1]

            # Find entities present in both windows
            # (using global labels since entities span all windows)
            mask1 = time_windows == w1
            mask2 = time_windows == w2

            # Compare global community labels in consecutive windows
            # This measures whether the global structure is stable
            labels1 = global_communities.labels[mask1]
            labels2 = global_communities.labels[mask2]

            # Since different entities in each window, compare distributions
            # Use within-window detected labels aligned to global
            if int(w1) in window_global_aligned and int(w2) in window_global_aligned:
                # Compute structural similarity via community size distributions
                sizes1 = np.bincount(
                    window_global_aligned[int(w1)],
                    minlength=n_global_comms
                )
                sizes2 = np.bincount(
                    window_global_aligned[int(w2)],
                    minlength=n_global_comms
                )
                # Cosine similarity of community size vectors
                norm1 = np.linalg.norm(sizes1)
                norm2 = np.linalg.norm(sizes2)
                if norm1 > 0 and norm2 > 0:
                    cos_sim = np.dot(sizes1, sizes2) / (norm1 * norm2)
                    ari_pairs.append(cos_sim)

        mean_ari = float(np.mean(ari_pairs)) if ari_pairs else 0.0

        # ── Community lifecycle ──────────────────────────────
        community_lifecycle = {}
        for c in range(n_global_comms):
            windows_present = []
            for w in sorted_windows:
                w_mask = time_windows == w
                gc_mask = global_communities.labels[w_mask] == c
                if gc_mask.sum() > 0:
                    windows_present.append(int(w))

            community_lifecycle[c] = {
                "first_seen": windows_present[0] if windows_present else None,
                "last_seen": windows_present[-1] if windows_present else None,
                "windows_present": len(windows_present),
                "total_windows": n_windows,
                "persistence": community_persistence.get(c, 0.0),
            }

        return PersistenceResult(
            community_persistence=community_persistence,
            entity_regime_confidence=entity_confidence,
            window_labels=window_labels,
            window_n_communities=window_n_comms,
            mean_ari_across_windows=mean_ari,
            community_birth_death=community_lifecycle,
            metadata={
                "n_windows": n_windows,
                "min_window_size": self.min_window_size,
                "alignment_method": self.alignment_method,
                "detector_method": self.detector.method,
            },
        )

    def _align_communities(
        self,
        window_labels: np.ndarray,
        global_labels: np.ndarray,
        n_global: int,
    ) -> np.ndarray:
        """
        Align per-window community labels to global community IDs.

        Uses maximum overlap: for each window community, find the
        global community with the most shared entities.
        """
        n_window_comms = int(window_labels.max()) + 1
        aligned = np.zeros_like(window_labels)

        for wc in range(n_window_comms):
            wc_mask = window_labels == wc
            if wc_mask.sum() == 0:
                continue

            # Count overlap with each global community
            overlaps = np.zeros(n_global)
            for gc in range(n_global):
                overlaps[gc] = np.sum(global_labels[wc_mask] == gc)

            # Assign to global community with max overlap
            best_global = np.argmax(overlaps)
            aligned[wc_mask] = best_global

        return aligned


@dataclass
class EntityDisplacement:
    """Displacement record for a single entity across time."""
    entity_idx: int
    global_community: int
    window_assignments: Dict[int, int]   # window → community
    displaced_windows: List[int]         # windows where assignment differs
    displacement_fraction: float         # fraction of windows displaced
    feature_deviations: Optional[np.ndarray] = None  # per-feature deviation


@dataclass
class StochasticEventReport:
    """
    Diagnostic report characterizing stochastic events detected
    through temporal community persistence analysis.

    Provides entity-level displacement tracking, feature attribution,
    community fragmentation analysis, and recovery trajectory.
    """
    # Displaced entities
    n_displaced: int
    displacement_rate: float
    displaced_entities: List[EntityDisplacement]

    # Feature attribution
    feature_importance: np.ndarray       # (D,) which features drove displacement
    feature_names: Optional[List[str]]

    # Community fragmentation
    fragmented_communities: Dict[int, Dict[str, Any]]

    # Per-window event intensity
    window_disruption: Dict[int, float]  # window → fraction of entities displaced

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        """Human-readable summary."""
        lines = [
            "TESSERA Stochastic Event Diagnostic Report",
            "=" * 55,
            f"Displaced entities:    {self.n_displaced} "
            f"({self.displacement_rate:.1%})",
            "",
            "Per-window disruption:",
        ]

        for w in sorted(self.window_disruption.keys()):
            d = self.window_disruption[w]
            bar = "█" * int(d * 30)
            lines.append(f"  Window {w}: {d:.3f} {bar}")

        # Top disrupted features
        if self.feature_importance is not None:
            top_k = min(5, len(self.feature_importance))
            top_idx = np.argsort(self.feature_importance)[::-1][:top_k]
            lines.append("")
            lines.append(f"Top {top_k} features driving displacement:")
            for rank, idx in enumerate(top_idx, 1):
                name = self.feature_names[idx] if self.feature_names else f"F{idx}"
                lines.append(
                    f"  {rank}. {name:30s} importance={self.feature_importance[idx]:.4f}"
                )

        # Fragmented communities
        if self.fragmented_communities:
            lines.append("")
            lines.append("Fragmented communities:")
            for comm_id, info in sorted(self.fragmented_communities.items()):
                lines.append(
                    f"  Community {comm_id}: {info.get('n_fragments', '?')} fragments, "
                    f"{info.get('n_displaced', '?')} displaced entities"
                )

        return "\n".join(lines)


class StochasticEventDiagnostics:
    """
    Characterizes stochastic events detected via persistence analysis.

    Extracts entity-level displacement tracking, feature attribution,
    community fragmentation patterns, and recovery trajectories from
    the temporal community structure.

    Parameters
    ----------
    displacement_threshold : float
        Fraction of windows an entity must differ from its global
        assignment to be considered "displaced". Default: 0.2
    """

    def __init__(self, displacement_threshold: float = 0.2):
        self.displacement_threshold = displacement_threshold

    def diagnose(
        self,
        features: np.ndarray,
        time_windows: np.ndarray,
        global_communities: CommunityStructure,
        persistence_result: PersistenceResult,
        feature_names: Optional[List[str]] = None,
    ) -> StochasticEventReport:
        """
        Run full stochastic event diagnostics.

        Parameters
        ----------
        features : np.ndarray (N, D)
            Entity features.
        time_windows : np.ndarray (N,)
            Time window assignments.
        global_communities : CommunityStructure
            Global community assignments.
        persistence_result : PersistenceResult
            Output from CommunityPersistenceAnalyzer.
        feature_names : list of str, optional
            Names for each feature dimension.

        Returns
        -------
        StochasticEventReport
        """
        N, D = features.shape
        unique_windows = np.sort(np.unique(time_windows))
        n_global = global_communities.n_communities

        # ── Entity displacement tracking ─────────────────────
        # For each entity, check whether its global community assignment
        # is consistent with per-window detection in its window.
        displacements = []

        for w in unique_windows:
            w_int = int(w)
            w_mask = time_windows == w
            w_indices = np.where(w_mask)[0]

            if w_int not in persistence_result.window_labels:
                continue

            w_labels = persistence_result.window_labels[w_int]

            # Align window labels to global IDs
            global_labels_w = global_communities.labels[w_indices]
            aligned = self._align_to_global(
                w_labels, global_labels_w, n_global
            )

            # Find entities whose window assignment differs from global
            for local_idx, global_idx in enumerate(w_indices):
                if local_idx >= len(aligned):
                    continue

                global_comm = int(global_communities.labels[global_idx])
                window_comm = int(aligned[local_idx])

                if window_comm != global_comm:
                    displacements.append(EntityDisplacement(
                        entity_idx=int(global_idx),
                        global_community=global_comm,
                        window_assignments={w_int: int(w_labels[local_idx])},
                        displaced_windows=[w_int],
                        displacement_fraction=1.0,
                    ))

        # ── Feature attribution ──────────────────────────────
        feature_importance = self._compute_feature_attribution(
            features, global_communities.labels, displacements
        )

        # Add feature deviations to displaced entities
        for disp in displacements:
            comm_mask = global_communities.labels == disp.global_community
            comm_mean = features[comm_mask].mean(axis=0)
            comm_std = features[comm_mask].std(axis=0)
            comm_std = np.where(comm_std == 0, 1.0, comm_std)
            disp.feature_deviations = np.abs(
                (features[disp.entity_idx] - comm_mean) / comm_std
            )

        # ── Per-window disruption ────────────────────────────
        window_disruption = {}
        for w in unique_windows:
            w_int = int(w)
            w_mask = time_windows == w
            n_w = w_mask.sum()
            n_displaced_w = sum(
                1 for d in displacements if w_int in d.displaced_windows
            )
            window_disruption[w_int] = n_displaced_w / max(n_w, 1)

        # ── Community fragmentation ──────────────────────────
        fragmented = {}
        for c in range(n_global):
            pers = persistence_result.community_persistence.get(c, 1.0)
            if pers < 0.8:
                c_displaced = [
                    d for d in displacements if d.global_community == c
                ]
                # Count distinct window communities these entities went to
                dest_comms = set()
                for d in c_displaced:
                    for w, wc in d.window_assignments.items():
                        dest_comms.add(wc)

                fragmented[c] = {
                    "persistence": pers,
                    "n_displaced": len(c_displaced),
                    "n_fragments": len(dest_comms),
                    "destination_communities": list(dest_comms),
                }

        return StochasticEventReport(
            n_displaced=len(displacements),
            displacement_rate=len(displacements) / N,
            displaced_entities=displacements,
            feature_importance=feature_importance,
            feature_names=feature_names,
            fragmented_communities=fragmented,
            window_disruption=window_disruption,
            metadata={
                "displacement_threshold": self.displacement_threshold,
                "n_entities": N,
                "n_windows": len(unique_windows),
            },
        )

    def _align_to_global(
        self,
        window_labels: np.ndarray,
        global_labels: np.ndarray,
        n_global: int,
    ) -> np.ndarray:
        """Align per-window labels to global community IDs by max overlap."""
        n_wc = int(window_labels.max()) + 1
        aligned = np.zeros_like(window_labels)

        for wc in range(n_wc):
            wc_mask = window_labels == wc
            if wc_mask.sum() == 0:
                continue
            overlaps = np.zeros(n_global)
            for gc in range(n_global):
                overlaps[gc] = np.sum(global_labels[wc_mask] == gc)
            aligned[wc_mask] = np.argmax(overlaps)

        return aligned

    def _compute_feature_attribution(
        self,
        features: np.ndarray,
        global_labels: np.ndarray,
        displacements: List[EntityDisplacement],
    ) -> np.ndarray:
        """
        Compute feature importance for displacement.

        For each feature, measures how much displaced entities deviate
        from their community centroid relative to non-displaced entities.
        High importance = this feature drove the displacement.
        """
        D = features.shape[1]
        importance = np.zeros(D)

        if not displacements:
            return importance

        displaced_idx = [d.entity_idx for d in displacements]
        non_displaced_idx = np.setdiff1d(
            np.arange(len(features)), displaced_idx
        )

        # For each community, compare displaced vs non-displaced deviations
        unique_comms = np.unique(global_labels)
        for c in unique_comms:
            c_mask = global_labels == c
            c_mean = features[c_mask].mean(axis=0)
            c_std = features[c_mask].std(axis=0)
            c_std = np.where(c_std == 0, 1.0, c_std)

            # Displaced entities in this community
            c_displaced = [
                d.entity_idx for d in displacements
                if d.global_community == int(c)
            ]
            c_non_displaced = np.intersect1d(
                non_displaced_idx, np.where(c_mask)[0]
            )

            if not c_displaced or len(c_non_displaced) == 0:
                continue

            # Z-score deviations
            disp_devs = np.abs(
                (features[c_displaced] - c_mean) / c_std
            ).mean(axis=0)
            nondisp_devs = np.abs(
                (features[c_non_displaced] - c_mean) / c_std
            ).mean(axis=0)

            # Importance = excess deviation of displaced entities
            importance += np.maximum(disp_devs - nondisp_devs, 0)

        # Normalize
        total = importance.sum()
        if total > 0:
            importance /= total

        return importance
