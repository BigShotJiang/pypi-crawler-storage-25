"""
TESSERA Core Module

Similarity computation, network construction, community detection,
regime divergence analysis, temporal persistence, and response
landscape spatial methods.
"""

from .similarity import SimilarityEngine, compute_similarity_batch
from .network import NetworkBuilder, TesseraGraph
from .community import (
    CommunityDetector,
    CommunityStructure,
    NJTree,
    PersistenceResult,
    CommunityPersistenceAnalyzer,
    StochasticEventDiagnostics,
    StochasticEventReport,
    EntityDisplacement,
)
from .regime_divergence import RegimeDivergenceComputer, RegimeDivergenceMap
from .response_landscape import (
    ReferenceLandscapeBuilder,
    ResponseSurface,
    GradientFieldAnalyzer,
    GradientAnalysis,
    PersistentHomologyAnalyzer,
    TopologicalFeatures,
    SpatialScanStatistic,
    ScanResult,
)
from .fusion import SimilarityFusion, FusionResult
from .parallel import TesseraParallel, parallel_config, ParallelConfig
from .safety import safe_array, safe_similarity_matrix, safe_probabilities
from .checkpoint import CheckpointManager, get_or_create_checkpoint
from .sparse_similarity import SparseSimilarity, SparseKNNResult, compute_sparse_knn_batch
from .validation import (
    AblationRunner,
    AblationResult,
    SimilarityComparisonRunner,
    SimilarityComparisonResult,
    BinSensitivityRunner,
    BinSensitivityResult,
    TemporalCVRunner,
    TemporalCVResult,
    compute_metrics,
    EvalMetrics,
)

__all__ = [
    "SimilarityEngine",
    "compute_similarity_batch",
    "NetworkBuilder",
    "TesseraGraph",
    "CommunityDetector",
    "CommunityStructure",
    "NJTree",
    "PersistenceResult",
    "CommunityPersistenceAnalyzer",
    "StochasticEventDiagnostics",
    "StochasticEventReport",
    "EntityDisplacement",
    "RegimeDivergenceComputer",
    "RegimeDivergenceMap",
    "ReferenceLandscapeBuilder",
    "ResponseSurface",
    "GradientFieldAnalyzer",
    "GradientAnalysis",
    "PersistentHomologyAnalyzer",
    "TopologicalFeatures",
    "SpatialScanStatistic",
    "ScanResult",
    "SimilarityFusion",
    "FusionResult",
    "TesseraParallel",
    "parallel_config",
    "ParallelConfig",
    "AblationRunner",
    "AblationResult",
    "SimilarityComparisonRunner",
    "SimilarityComparisonResult",
    "BinSensitivityRunner",
    "BinSensitivityResult",
    "TemporalCVRunner",
    "TemporalCVResult",
    "compute_metrics",
    "EvalMetrics",
]
