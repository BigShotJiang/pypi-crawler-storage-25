"""
TESSERA Response Landscape

Constructs a continuous response surface from entity similarity data,
then applies spatial statistical methods from landscape ecology and
topological data analysis to detect, characterize, and predict
response patterns.

Components:
1. ReferenceLandscape — KDE-based continuous response surface
2. GradientField — directional regime transition measure
3. PersistentHomologyAnalyzer — multi-scale topological features
4. SpatialScanStatistic — formal hypothesis testing for response clusters

This generalizes geographic/ecological landscape methods to arbitrary
feature spaces, treating the similarity network as terrain.

This is a core analytical layer that sits between Steps 3 (Quantify)
and 4 (Predict) of the TESSERA workflow.
"""

import numpy as np
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, field
from scipy.stats import gaussian_kde
from scipy.ndimage import gaussian_filter
from sklearn.decomposition import PCA
import warnings

try:
    from ripser import ripser
    HAS_RIPSER = True
except ImportError:
    HAS_RIPSER = False


# ═══════════════════════════════════════════════════════════════
# 1. REFERENCE LANDSCAPE
# ═══════════════════════════════════════════════════════════════

@dataclass
class ResponseSurface:
    """
    Continuous response surface built from entity data.

    The surface maps positions in (reduced) feature space to response
    probabilities, creating a topographic landscape where elevation
    represents risk.
    """
    # Grid definition
    grid_points: np.ndarray          # (G, G, 2) or mesh coordinates
    grid_x: np.ndarray               # (G,) x-axis values
    grid_y: np.ndarray               # (G,) y-axis values

    # Surfaces
    density_surface: np.ndarray      # (G, G) entity density
    response_surface: np.ndarray     # (G, G) response probability
    reference_surface: Optional[np.ndarray] = None  # (G, G) stable reference

    # Gradient fields
    gradient_x: Optional[np.ndarray] = None   # (G, G) x-component
    gradient_y: Optional[np.ndarray] = None   # (G, G) y-component
    gradient_magnitude: Optional[np.ndarray] = None  # (G, G)

    # Dimensionality reduction
    reducer: Optional[Any] = None    # PCA or UMAP object
    explained_variance: Optional[np.ndarray] = None

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def resolution(self) -> int:
        return len(self.grid_x)

    def score_entities(
        self,
        features_2d: np.ndarray,
    ) -> Dict[str, np.ndarray]:
        """
        Score entities against the response surface.

        For each entity, returns its local response probability,
        gradient magnitude, and deviation from reference.

        Parameters
        ----------
        features_2d : np.ndarray (N, 2)
            Entity positions in reduced feature space.

        Returns
        -------
        dict with keys:
            response_prob: (N,) interpolated response probability
            gradient_mag: (N,) local gradient magnitude
            reference_deviation: (N,) difference from reference (if available)
        """
        from scipy.interpolate import RegularGridInterpolator

        scores = {}

        # Interpolate response probability
        interp_resp = RegularGridInterpolator(
            (self.grid_x, self.grid_y), self.response_surface,
            method="linear", bounds_error=False, fill_value=np.nan,
        )
        scores["response_prob"] = interp_resp(features_2d)

        # Interpolate gradient magnitude
        if self.gradient_magnitude is not None:
            interp_grad = RegularGridInterpolator(
                (self.grid_x, self.grid_y), self.gradient_magnitude,
                method="linear", bounds_error=False, fill_value=np.nan,
            )
            scores["gradient_mag"] = interp_grad(features_2d)

        # Deviation from reference
        if self.reference_surface is not None:
            interp_ref = RegularGridInterpolator(
                (self.grid_x, self.grid_y), self.reference_surface,
                method="linear", bounds_error=False, fill_value=np.nan,
            )
            ref_vals = interp_ref(features_2d)
            resp_vals = scores["response_prob"]
            scores["reference_deviation"] = resp_vals - ref_vals

        return scores

    def summary(self) -> str:
        lines = [
            "TESSERA Response Surface",
            "=" * 45,
            f"Grid resolution:   {self.resolution} × {self.resolution}",
            f"Response range:    [{np.nanmin(self.response_surface):.4f}, "
            f"{np.nanmax(self.response_surface):.4f}]",
            f"Mean response:     {np.nanmean(self.response_surface):.4f}",
        ]
        if self.gradient_magnitude is not None:
            lines.append(
                f"Max gradient:      {np.nanmax(self.gradient_magnitude):.4f}"
            )
        if self.reference_surface is not None:
            diff = self.response_surface - self.reference_surface
            lines.append(
                f"Max ref deviation: {np.nanmax(np.abs(diff)):.4f}"
            )
        if self.explained_variance is not None:
            lines.append(
                f"PCA variance:      {self.explained_variance.sum():.1%} "
                f"({self.explained_variance[0]:.1%}, "
                f"{self.explained_variance[1]:.1%})"
            )
        return "\n".join(lines)


class ReferenceLandscapeBuilder:
    """
    Builds continuous response surfaces from entity data.

    Uses kernel density estimation to create smooth surfaces of
    entity density and response probability across feature space.

    The reference landscape (built from stable temporal windows)
    serves as a null model against which current/empirical data
    is compared.

    Parameters
    ----------
    resolution : int
        Grid resolution for the surface. Default: 100
    bandwidth : str or float
        KDE bandwidth. "scott" or "silverman" for automatic,
        or a float value. Default: "scott"
    n_components : int
        PCA components for feature space reduction. Default: 2
    smoothing : float
        Gaussian smoothing sigma for the response surface.
        Default: 1.0
    """

    def __init__(
        self,
        resolution: int = 100,
        bandwidth: str = "scott",
        n_components: int = 2,
        smoothing: float = 1.0,
    ):
        self.resolution = resolution
        self.bandwidth = bandwidth
        self.n_components = n_components
        self.smoothing = smoothing

    def build(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
        time_windows: Optional[np.ndarray] = None,
        stable_windows: Optional[List[int]] = None,
        reducer: Optional[Any] = None,
    ) -> ResponseSurface:
        """
        Build the response surface.

        Parameters
        ----------
        features : np.ndarray (N, D)
            Entity features.
        outcomes : np.ndarray (N,)
            Binary outcomes.
        time_windows : np.ndarray (N,), optional
            Time window assignments. Used with stable_windows.
        stable_windows : list of int, optional
            Which windows to use for the reference surface.
            If None, uses all data as reference.
        reducer : PCA or similar, optional
            Pre-fitted dimensionality reduction. If None, fits PCA.

        Returns
        -------
        ResponseSurface
        """
        N, D = features.shape

        # ── Dimensionality reduction ─────────────────────────
        if reducer is None:
            reducer = PCA(n_components=self.n_components)
            features_2d = reducer.fit_transform(features)
        else:
            features_2d = reducer.transform(features)

        explained_var = getattr(reducer, "explained_variance_ratio_", None)

        # ── Build grid ───────────────────────────────────────
        margin = 0.1
        x_range = features_2d[:, 0].max() - features_2d[:, 0].min()
        y_range = features_2d[:, 1].max() - features_2d[:, 1].min()

        grid_x = np.linspace(
            features_2d[:, 0].min() - margin * x_range,
            features_2d[:, 0].max() + margin * x_range,
            self.resolution,
        )
        grid_y = np.linspace(
            features_2d[:, 1].min() - margin * y_range,
            features_2d[:, 1].max() + margin * y_range,
            self.resolution,
        )
        xx, yy = np.meshgrid(grid_x, grid_y, indexing="ij")
        grid_positions = np.column_stack([xx.ravel(), yy.ravel()])

        # ── Density surface (all entities) ───────────────────
        try:
            kde_all = gaussian_kde(
                features_2d.T, bw_method=self.bandwidth
            )
            density = kde_all(grid_positions.T).reshape(
                self.resolution, self.resolution
            )
        except np.linalg.LinAlgError:
            density = np.ones((self.resolution, self.resolution))

        # ── Response surface ─────────────────────────────────
        response = self._build_response_surface(
            features_2d, outcomes, grid_x, grid_y
        )

        # ── Reference surface (from stable windows) ──────────
        reference = None
        if time_windows is not None and stable_windows is not None:
            stable_mask = np.isin(time_windows, stable_windows)
            if stable_mask.sum() > 10:
                stable_2d = features_2d[stable_mask]
                stable_outcomes = outcomes[stable_mask]
                reference = self._build_response_surface(
                    stable_2d, stable_outcomes, grid_x, grid_y
                )

        # ── Gradient field ───────────────────────────────────
        grad_y_arr, grad_x_arr = np.gradient(response)
        grad_mag = np.sqrt(grad_x_arr**2 + grad_y_arr**2)

        return ResponseSurface(
            grid_points=np.stack([xx, yy], axis=-1),
            grid_x=grid_x,
            grid_y=grid_y,
            density_surface=density,
            response_surface=response,
            reference_surface=reference,
            gradient_x=grad_x_arr,
            gradient_y=grad_y_arr,
            gradient_magnitude=grad_mag,
            reducer=reducer,
            explained_variance=explained_var,
            metadata={
                "resolution": self.resolution,
                "bandwidth": str(self.bandwidth),
                "smoothing": self.smoothing,
                "n_entities": N,
                "n_positive": int(outcomes.sum()),
                "stable_windows": stable_windows,
            },
        )

    def _build_response_surface(
        self,
        features_2d: np.ndarray,
        outcomes: np.ndarray,
        grid_x: np.ndarray,
        grid_y: np.ndarray,
    ) -> np.ndarray:
        """
        Build response probability surface using KDE ratio estimation.

        P(response | x) ≈ kde_positive(x) / kde_all(x)
        """
        pos_mask = outcomes == 1

        if pos_mask.sum() < 3 or (~pos_mask).sum() < 3:
            return np.full(
                (self.resolution, self.resolution),
                outcomes.mean()
            )

        xx, yy = np.meshgrid(grid_x, grid_y, indexing="ij")
        grid_positions = np.column_stack([xx.ravel(), yy.ravel()])

        try:
            kde_all = gaussian_kde(
                features_2d.T, bw_method=self.bandwidth
            )
            kde_pos = gaussian_kde(
                features_2d[pos_mask].T, bw_method=self.bandwidth
            )

            density_all = kde_all(grid_positions.T).reshape(
                self.resolution, self.resolution
            )
            density_pos = kde_pos(grid_positions.T).reshape(
                self.resolution, self.resolution
            )

            # Ratio with smoothing to avoid division by zero
            base_rate = outcomes.mean()
            response = np.where(
                density_all > 1e-10,
                density_pos / density_all * base_rate,
                base_rate,
            )
        except np.linalg.LinAlgError:
            response = np.full(
                (self.resolution, self.resolution),
                outcomes.mean()
            )

        # Smooth and clip
        response = gaussian_filter(response, sigma=self.smoothing)
        response = np.clip(response, 0.0, 1.0)

        return response


# ═══════════════════════════════════════════════════════════════
# 2. GRADIENT FIELD ANALYSIS
# ═══════════════════════════════════════════════════════════════

@dataclass
class GradientAnalysis:
    """
    Results of gradient field analysis on the response surface.

    Identifies regime boundaries as ridgelines (high gradient magnitude)
    and stable interiors as basins (low gradient).
    """
    # Per-entity gradient scores
    entity_gradient_magnitude: np.ndarray   # (N,) gradient at each entity
    entity_gradient_direction: np.ndarray   # (N, 2) gradient vector

    # Topographic features
    ridgeline_mask: np.ndarray              # (G, G) boolean: is this a ridge?
    saddle_points: List[Tuple[float, float]]  # (x, y) coordinates
    basin_labels: Optional[np.ndarray] = None  # (G, G) basin assignments

    # Statistics
    metadata: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            "TESSERA Gradient Analysis",
            "=" * 45,
            f"Mean gradient:     {self.entity_gradient_magnitude.mean():.4f}",
            f"Max gradient:      {self.entity_gradient_magnitude.max():.4f}",
            f"Saddle points:     {len(self.saddle_points)}",
        ]
        if self.ridgeline_mask is not None:
            n_ridge = self.ridgeline_mask.sum()
            total = self.ridgeline_mask.size
            lines.append(
                f"Ridge coverage:    {n_ridge}/{total} "
                f"({100 * n_ridge / total:.1f}%)"
            )
        return "\n".join(lines)


class GradientFieldAnalyzer:
    """
    Analyzes the gradient field of the response surface.

    Identifies:
    - Ridgelines: connected regions of high gradient (regime boundaries)
    - Saddle points: transition points between basins
    - Basins: connected regions of low gradient (stable regimes)

    Parameters
    ----------
    ridge_percentile : float
        Percentile of gradient magnitude above which a point is
        considered part of a ridgeline. Default: 85
    """

    def __init__(self, ridge_percentile: float = 85):
        self.ridge_percentile = ridge_percentile

    def analyze(
        self,
        surface: ResponseSurface,
        features_2d: np.ndarray,
    ) -> GradientAnalysis:
        """
        Run gradient analysis on the response surface.

        Parameters
        ----------
        surface : ResponseSurface
            The built response surface with gradients.
        features_2d : np.ndarray (N, 2)
            Entity positions in reduced space.

        Returns
        -------
        GradientAnalysis
        """
        # ── Per-entity gradient scores ───────────────────────
        from scipy.interpolate import RegularGridInterpolator

        # Gradient magnitude interpolation
        interp_mag = RegularGridInterpolator(
            (surface.grid_x, surface.grid_y),
            surface.gradient_magnitude,
            method="linear", bounds_error=False, fill_value=0.0,
        )
        entity_grad_mag = interp_mag(features_2d)

        # Gradient direction interpolation
        interp_gx = RegularGridInterpolator(
            (surface.grid_x, surface.grid_y),
            surface.gradient_x,
            method="linear", bounds_error=False, fill_value=0.0,
        )
        interp_gy = RegularGridInterpolator(
            (surface.grid_x, surface.grid_y),
            surface.gradient_y,
            method="linear", bounds_error=False, fill_value=0.0,
        )
        entity_grad_dir = np.column_stack([
            interp_gx(features_2d),
            interp_gy(features_2d),
        ])

        # ── Ridgeline detection ──────────────────────────────
        threshold = np.percentile(
            surface.gradient_magnitude[surface.gradient_magnitude > 0],
            self.ridge_percentile,
        ) if np.any(surface.gradient_magnitude > 0) else 0

        ridgeline_mask = surface.gradient_magnitude >= threshold

        # ── Saddle point detection ───────────────────────────
        saddle_points = self._find_saddle_points(surface)

        # ── Basin segmentation via gradient descent ──────────
        basin_labels = self._segment_basins(surface)

        return GradientAnalysis(
            entity_gradient_magnitude=entity_grad_mag,
            entity_gradient_direction=entity_grad_dir,
            ridgeline_mask=ridgeline_mask,
            saddle_points=saddle_points,
            basin_labels=basin_labels,
            metadata={
                "ridge_percentile": self.ridge_percentile,
                "ridge_threshold": float(threshold),
            },
        )

    def _find_saddle_points(
        self, surface: ResponseSurface
    ) -> List[Tuple[float, float]]:
        """
        Find saddle points on the response surface.

        Saddle points are where the Hessian has eigenvalues of
        opposite sign — local minimum in one direction, maximum
        in the other. These are transition points between regimes.
        """
        resp = surface.response_surface
        G = surface.resolution
        saddles = []

        # Compute second derivatives (Hessian components)
        dyy, dyx = np.gradient(surface.gradient_y)
        dxy, dxx = np.gradient(surface.gradient_x)

        # Find saddle points: det(H) < 0
        det_H = dxx * dyy - dxy * dyx

        # Also require gradient magnitude to be low (near critical point)
        grad_mag = surface.gradient_magnitude
        low_grad = grad_mag < np.percentile(grad_mag[grad_mag > 0], 30) \
            if np.any(grad_mag > 0) else np.ones_like(grad_mag, dtype=bool)

        saddle_mask = (det_H < 0) & low_grad

        # Extract coordinates
        saddle_idx = np.where(saddle_mask)
        for i, j in zip(saddle_idx[0], saddle_idx[1]):
            if 2 <= i < G - 2 and 2 <= j < G - 2:
                saddles.append((
                    float(surface.grid_x[i]),
                    float(surface.grid_y[j]),
                ))

        # Deduplicate nearby saddle points
        if saddles:
            saddles = self._deduplicate_points(saddles, min_dist=0.5)

        return saddles

    def _segment_basins(
        self, surface: ResponseSurface
    ) -> np.ndarray:
        """
        Segment the landscape into basins via gradient descent.

        Each grid cell is assigned to the basin it flows into when
        following the negative gradient (toward local minima of
        response probability).
        """
        G = surface.resolution
        resp = surface.response_surface
        labels = -np.ones((G, G), dtype=int)
        basin_id = 0

        # Find local minima
        from scipy.ndimage import minimum_filter
        local_min = minimum_filter(resp, size=5)
        minima_mask = (resp == local_min) & (resp < np.percentile(resp, 50))

        # Label each minimum as a basin seed
        minima_idx = np.where(minima_mask)
        for i, j in zip(minima_idx[0], minima_idx[1]):
            if labels[i, j] == -1:
                labels[i, j] = basin_id
                basin_id += 1

        if basin_id == 0:
            return np.zeros((G, G), dtype=int)

        # Watershed-like expansion from minima
        from collections import deque

        queue = deque()
        for i, j in zip(minima_idx[0], minima_idx[1]):
            queue.append((i, j))

        while queue:
            i, j = queue.popleft()
            for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ni, nj = i + di, j + dj
                if 0 <= ni < G and 0 <= nj < G and labels[ni, nj] == -1:
                    labels[ni, nj] = labels[i, j]
                    queue.append((ni, nj))

        return labels

    @staticmethod
    def _deduplicate_points(
        points: List[Tuple[float, float]], min_dist: float
    ) -> List[Tuple[float, float]]:
        """Remove points closer than min_dist to each other."""
        if not points:
            return points

        filtered = [points[0]]
        for p in points[1:]:
            too_close = False
            for f in filtered:
                d = np.sqrt((p[0] - f[0])**2 + (p[1] - f[1])**2)
                if d < min_dist:
                    too_close = True
                    break
            if not too_close:
                filtered.append(p)

        return filtered


# ═══════════════════════════════════════════════════════════════
# 3. PERSISTENT HOMOLOGY
# ═══════════════════════════════════════════════════════════════

@dataclass
class TopologicalFeatures:
    """
    Topological features of the response landscape detected via
    persistent homology.

    H0 features (connected components): represent distinct response regimes
    H1 features (loops): represent cyclic regime transitions
    """
    # Persistence diagrams
    h0_diagram: np.ndarray    # (n_h0, 2) birth-death pairs for components
    h1_diagram: np.ndarray    # (n_h1, 2) birth-death pairs for loops

    # Persistence (lifetime) of each feature
    h0_persistence: np.ndarray  # (n_h0,) death - birth
    h1_persistence: np.ndarray  # (n_h1,)

    # Significant features (above noise threshold)
    n_significant_regimes: int    # persistent H0 features
    n_significant_transitions: int  # persistent H1 features

    # Betti curve (topological summary across filtration)
    filtration_values: np.ndarray
    betti_0: np.ndarray    # n components at each filtration value
    betti_1: np.ndarray    # n loops at each filtration value

    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def max_h0_persistence(self) -> float:
        return float(self.h0_persistence.max()) if len(self.h0_persistence) > 0 else 0.0

    @property
    def max_h1_persistence(self) -> float:
        return float(self.h1_persistence.max()) if len(self.h1_persistence) > 0 else 0.0

    def summary(self) -> str:
        lines = [
            "TESSERA Topological Features (Persistent Homology)",
            "=" * 55,
            f"H0 features (regimes):     {len(self.h0_diagram)}",
            f"  Significant (persistent): {self.n_significant_regimes}",
            f"  Max persistence:          {self.max_h0_persistence:.4f}",
            f"H1 features (transitions): {len(self.h1_diagram)}",
            f"  Significant:              {self.n_significant_transitions}",
            f"  Max persistence:          {self.max_h1_persistence:.4f}",
        ]
        return "\n".join(lines)


class PersistentHomologyAnalyzer:
    """
    Persistent homology analysis of the response landscape.

    Computes topological features that persist across multiple scales,
    distinguishing robust regime structure from noise.

    A "persistent" connected component in the failure region represents
    a robust failure regime. A component that appears briefly and
    disappears is a stochastic artifact.

    Parameters
    ----------
    max_dimension : int
        Maximum homology dimension. Default: 1 (H0 + H1)
    significance_threshold : float
        Persistence below this fraction of the max is considered noise.
        Default: 0.1
    n_subsample : int, optional
        Subsample to this many points for computational efficiency.
        Default: 500
    """

    def __init__(
        self,
        max_dimension: int = 1,
        significance_threshold: float = 0.1,
        n_subsample: int = 500,
    ):
        self.max_dimension = max_dimension
        self.significance_threshold = significance_threshold
        self.n_subsample = n_subsample

    def analyze(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
        features_2d: Optional[np.ndarray] = None,
    ) -> TopologicalFeatures:
        """
        Compute persistent homology of the response-weighted point cloud.

        Parameters
        ----------
        features : np.ndarray (N, D)
            Entity features (full dimensional).
        outcomes : np.ndarray (N,)
            Binary outcomes.
        features_2d : np.ndarray (N, 2), optional
            Reduced features for visualization. If None, uses PCA.

        Returns
        -------
        TopologicalFeatures
        """
        N = len(features)

        # Subsample for efficiency
        if N > self.n_subsample:
            rng = np.random.default_rng(42)
            idx = rng.choice(N, self.n_subsample, replace=False)
            features_sub = features[idx]
            outcomes_sub = outcomes[idx]
        else:
            features_sub = features
            outcomes_sub = outcomes

        if HAS_RIPSER:
            return self._analyze_ripser(features_sub, outcomes_sub)
        else:
            return self._analyze_fallback(features_sub, outcomes_sub)

    def _analyze_ripser(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
    ) -> TopologicalFeatures:
        """Persistent homology via Ripser."""
        # Weight distances by response: failure entities are "closer"
        # to each other (response-weighted distance)
        from scipy.spatial.distance import pdist, squareform

        dists = squareform(pdist(features))

        # Response weighting: reduce distances between same-outcome pairs
        for i in range(len(features)):
            for j in range(i + 1, len(features)):
                if outcomes[i] == outcomes[j] == 1:
                    dists[i, j] *= 0.5
                    dists[j, i] *= 0.5

        result = ripser(
            dists,
            maxdim=self.max_dimension,
            distance_matrix=True,
        )

        diagrams = result["dgms"]
        h0 = diagrams[0]
        h1 = diagrams[1] if len(diagrams) > 1 else np.empty((0, 2))

        # Remove infinite persistence from H0 (the single connected component)
        h0_finite = h0[np.isfinite(h0[:, 1])] if len(h0) > 0 else np.empty((0, 2))

        return self._build_result(h0_finite, h1)

    def _analyze_fallback(
        self,
        features: np.ndarray,
        outcomes: np.ndarray,
    ) -> TopologicalFeatures:
        """
        Approximate persistent homology without Ripser.

        Uses hierarchical clustering dendrogram heights as a proxy
        for H0 persistence (connected components).
        """
        from scipy.cluster.hierarchy import linkage
        from scipy.spatial.distance import pdist

        dists = pdist(features)
        Z = linkage(dists, method="single")

        # H0: merge heights are "death" times of components
        # Birth is 0 for all (each point starts as its own component)
        h0 = np.column_stack([
            np.zeros(len(Z)),
            Z[:, 2],
        ])

        # No H1 approximation in fallback
        h1 = np.empty((0, 2))

        return self._build_result(h0, h1)

    def _build_result(
        self, h0: np.ndarray, h1: np.ndarray
    ) -> TopologicalFeatures:
        """Build TopologicalFeatures from persistence diagrams."""
        # Compute persistence
        h0_pers = (h0[:, 1] - h0[:, 0]) if len(h0) > 0 else np.array([])
        h1_pers = (h1[:, 1] - h1[:, 0]) if len(h1) > 0 else np.array([])

        # Significance threshold
        max_pers = max(
            h0_pers.max() if len(h0_pers) > 0 else 0,
            h1_pers.max() if len(h1_pers) > 0 else 0,
            1e-10,
        )
        sig_thresh = self.significance_threshold * max_pers

        n_sig_h0 = int(np.sum(h0_pers > sig_thresh))
        n_sig_h1 = int(np.sum(h1_pers > sig_thresh))

        # Betti curve
        all_vals = np.concatenate([h0.ravel(), h1.ravel()])
        all_vals = all_vals[np.isfinite(all_vals)]

        if len(all_vals) > 0:
            filt_values = np.linspace(all_vals.min(), all_vals.max(), 100)
        else:
            filt_values = np.linspace(0, 1, 100)

        betti_0 = np.zeros(len(filt_values))
        betti_1 = np.zeros(len(filt_values))

        for k, t in enumerate(filt_values):
            if len(h0) > 0:
                betti_0[k] = np.sum((h0[:, 0] <= t) & (h0[:, 1] > t))
            if len(h1) > 0:
                betti_1[k] = np.sum((h1[:, 0] <= t) & (h1[:, 1] > t))

        return TopologicalFeatures(
            h0_diagram=h0,
            h1_diagram=h1,
            h0_persistence=h0_pers,
            h1_persistence=h1_pers,
            n_significant_regimes=n_sig_h0,
            n_significant_transitions=n_sig_h1,
            filtration_values=filt_values,
            betti_0=betti_0,
            betti_1=betti_1,
            metadata={
                "method": "ripser" if HAS_RIPSER else "linkage_fallback",
                "max_dimension": self.max_dimension,
                "significance_threshold": self.significance_threshold,
            },
        )


# ═══════════════════════════════════════════════════════════════
# 4. SPATIAL SCAN STATISTICS
# ═══════════════════════════════════════════════════════════════

@dataclass
class ScanCluster:
    """A detected cluster of elevated response rate."""
    center: np.ndarray          # (2,) center in reduced space
    radius: float               # cluster radius
    n_entities: int             # entities in cluster
    n_positive: int             # positive outcomes in cluster
    observed_rate: float        # observed response rate in cluster
    expected_rate: float        # expected rate under null
    relative_risk: float        # observed / expected
    log_likelihood_ratio: float # test statistic
    p_value: float              # Monte Carlo p-value
    entity_indices: np.ndarray  # indices of entities in cluster


@dataclass
class ScanResult:
    """Results of spatial scan statistical analysis."""
    clusters: List[ScanCluster]
    n_significant: int          # clusters with p < 0.05
    global_rate: float          # overall response rate
    metadata: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            "TESSERA Spatial Scan Statistics",
            "=" * 50,
            f"Clusters found:    {len(self.clusters)}",
            f"Significant (p<0.05): {self.n_significant}",
            f"Global rate:       {self.global_rate:.4f}",
        ]
        for i, c in enumerate(self.clusters[:5]):  # top 5
            lines.append(
                f"\n  Cluster {i+1}:")
            lines.append(
                f"    Entities: {c.n_entities}, "
                f"Rate: {c.observed_rate:.3f} vs "
                f"expected {c.expected_rate:.3f}")
            lines.append(
                f"    Relative risk: {c.relative_risk:.2f}, "
                f"p={c.p_value:.4f}")

        return "\n".join(lines)


class SpatialScanStatistic:
    """
    Kulldorff-type spatial scan statistic for response clusters.

    Detects regions of feature space with significantly elevated
    response rates compared to the global rate. Provides formal
    hypothesis testing (p-values via Monte Carlo permutation).

    Parameters
    ----------
    max_cluster_fraction : float
        Maximum fraction of entities in a cluster. Default: 0.5
    n_permutations : int
        Number of Monte Carlo permutations for p-values. Default: 999
    n_candidate_centers : int
        Number of candidate cluster centers to test. Default: 50
    random_state : int, optional
        Random seed for reproducibility.
    """

    def __init__(
        self,
        max_cluster_fraction: float = 0.5,
        n_permutations: int = 999,
        n_candidate_centers: int = 50,
        random_state: Optional[int] = None,
    ):
        self.max_cluster_fraction = max_cluster_fraction
        self.n_permutations = n_permutations
        self.n_candidate_centers = n_candidate_centers
        self.random_state = random_state

    def scan(
        self,
        features_2d: np.ndarray,
        outcomes: np.ndarray,
    ) -> ScanResult:
        """
        Run the spatial scan statistic.

        Parameters
        ----------
        features_2d : np.ndarray (N, 2)
            Entity positions in reduced feature space.
        outcomes : np.ndarray (N,)
            Binary outcomes.

        Returns
        -------
        ScanResult
        """
        rng = np.random.default_rng(self.random_state)
        N = len(features_2d)
        global_rate = outcomes.mean()
        global_positive = outcomes.sum()
        max_size = int(N * self.max_cluster_fraction)

        # ── Select candidate centers ─────────────────────────
        # Use positive entities as candidate centers (enriched for signal)
        pos_idx = np.where(outcomes == 1)[0]
        if len(pos_idx) > self.n_candidate_centers:
            center_idx = rng.choice(
                pos_idx, self.n_candidate_centers, replace=False
            )
        else:
            center_idx = pos_idx

        # ── Compute distances from each center to all entities ─
        from scipy.spatial.distance import cdist
        dists = cdist(features_2d[center_idx], features_2d)

        # ── Find best cluster for each center ────────────────
        best_clusters = []

        for ci in range(len(center_idx)):
            order = np.argsort(dists[ci])

            best_llr = 0.0
            best_k = 0

            cumsum = np.cumsum(outcomes[order])

            for k in range(5, min(max_size, N)):
                n_in = k
                c_in = cumsum[k - 1]
                c_out = global_positive - c_in
                n_out = N - n_in

                # Expected counts under null
                e_in = n_in * global_rate
                e_out = n_out * global_rate

                # Log-likelihood ratio (Poisson model)
                llr = self._log_likelihood_ratio(
                    c_in, e_in, c_out, e_out, n_in, n_out
                )

                if llr > best_llr:
                    best_llr = llr
                    best_k = k

            if best_k > 0:
                radius = dists[ci, order[best_k - 1]]
                entities_in = order[:best_k]
                n_pos = int(outcomes[entities_in].sum())

                best_clusters.append(ScanCluster(
                    center=features_2d[center_idx[ci]],
                    radius=float(radius),
                    n_entities=best_k,
                    n_positive=n_pos,
                    observed_rate=n_pos / best_k,
                    expected_rate=global_rate,
                    relative_risk=(n_pos / best_k) / max(global_rate, 1e-10),
                    log_likelihood_ratio=best_llr,
                    p_value=1.0,  # computed below
                    entity_indices=entities_in,
                ))

        if not best_clusters:
            return ScanResult(
                clusters=[], n_significant=0,
                global_rate=global_rate,
            )

        # ── Monte Carlo p-values ─────────────────────────────
        # Get the observed max LLR
        observed_max_llr = max(c.log_likelihood_ratio for c in best_clusters)

        # Permutation test
        null_max_llrs = []
        for perm in range(self.n_permutations):
            perm_outcomes = rng.permutation(outcomes)
            perm_max_llr = 0.0

            for ci in range(len(center_idx)):
                order = np.argsort(dists[ci])
                cumsum = np.cumsum(perm_outcomes[order])

                for k in range(5, min(max_size, N)):
                    c_in = cumsum[k - 1]
                    c_out = global_positive - c_in
                    n_out = N - k

                    llr = self._log_likelihood_ratio(
                        c_in, k * global_rate, c_out, n_out * global_rate,
                        k, n_out
                    )
                    perm_max_llr = max(perm_max_llr, llr)

            null_max_llrs.append(perm_max_llr)

        null_max_llrs = np.array(null_max_llrs)

        # Assign p-values
        for cluster in best_clusters:
            cluster.p_value = float(
                (np.sum(null_max_llrs >= cluster.log_likelihood_ratio) + 1)
                / (self.n_permutations + 1)
            )

        # Sort by LLR (most significant first)
        best_clusters.sort(
            key=lambda c: c.log_likelihood_ratio, reverse=True
        )

        # Remove overlapping clusters (keep stronger one)
        filtered = self._remove_overlaps(best_clusters)

        n_sig = sum(1 for c in filtered if c.p_value < 0.05)

        return ScanResult(
            clusters=filtered,
            n_significant=n_sig,
            global_rate=global_rate,
            metadata={
                "n_permutations": self.n_permutations,
                "max_cluster_fraction": self.max_cluster_fraction,
                "n_candidate_centers": len(center_idx),
            },
        )

    @staticmethod
    def _log_likelihood_ratio(
        c_in: float, e_in: float,
        c_out: float, e_out: float,
        n_in: int, n_out: int,
    ) -> float:
        """Compute Kulldorff log-likelihood ratio."""
        if e_in <= 0 or e_out <= 0 or n_in <= 0 or n_out <= 0:
            return 0.0

        rate_in = c_in / n_in
        rate_out = c_out / n_out if n_out > 0 else 0

        # Only detect elevated rates (not depleted)
        if rate_in <= rate_out:
            return 0.0

        llr = 0.0
        if c_in > 0 and e_in > 0:
            llr += c_in * np.log(c_in / e_in)
        if c_out > 0 and e_out > 0:
            llr += c_out * np.log(c_out / e_out)

        return max(llr, 0.0)

    @staticmethod
    def _remove_overlaps(
        clusters: List[ScanCluster], overlap_threshold: float = 0.5
    ) -> List[ScanCluster]:
        """Remove overlapping clusters, keeping the stronger one."""
        if not clusters:
            return clusters

        filtered = [clusters[0]]
        for c in clusters[1:]:
            overlaps = False
            for f in filtered:
                # Check entity overlap
                shared = len(
                    set(c.entity_indices) & set(f.entity_indices)
                )
                min_size = min(c.n_entities, f.n_entities)
                if min_size > 0 and shared / min_size > overlap_threshold:
                    overlaps = True
                    break

            if not overlaps:
                filtered.append(c)

        return filtered
