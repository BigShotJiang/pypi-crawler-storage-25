"""
TESSERA Sparse kNN Similarity

Memory-safe similarity computation that only stores k-nearest neighbors
per entity. For N=31K and k=10, memory is ~5MB instead of 7.3GB.

The key insight: every downstream consumer (NetworkBuilder, GNN,
separation scoring) only uses kNN edges. Computing the full N×N
matrix is wasted work and memory.

Approach:
1. Process entities in chunks (e.g., 1000 rows at a time)
2. For each chunk, compute distance to ALL entities
3. Find top-k per row via argpartition (O(N) per row)
4. Store only (knn_indices, knn_similarities) — shape (N, k) each
5. Total memory: N × k × 16 bytes (two float64 arrays)

Usage:
    from tessera.core.sparse_similarity import SparseSimilarity

    sparse = SparseSimilarity(method="mahalanobis", k=10)
    result = sparse.compute(features)

    # result.knn_indices: (N, k) indices of k nearest neighbors
    # result.knn_similarities: (N, k) similarity values
    # result.to_edge_index(): (2, E) edge list for GNN
    # result.separation_score(outcomes): vectorized Δ
"""

import numpy as np
from scipy.spatial.distance import cdist
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class SparseKNNResult:
    """
    Sparse kNN similarity result.

    Stores only the k nearest neighbors per entity.
    Memory: N × k × 16 bytes (vs N × N × 8 for dense).
    """
    knn_indices: np.ndarray      # (N, k) neighbor indices
    knn_similarities: np.ndarray  # (N, k) similarity values
    n_entities: int
    k: int
    method: str
    metadata: Dict[str, Any]

    @property
    def memory_mb(self) -> float:
        """Memory usage in MB."""
        return (self.knn_indices.nbytes + self.knn_similarities.nbytes) / 1e6

    def to_edge_index(self, symmetric: bool = True) -> Tuple[np.ndarray, np.ndarray]:
        """
        Convert to edge list for GNN consumption.

        Parameters
        ----------
        symmetric : bool
            If True, add reverse edges (i→j implies j→i).

        Returns
        -------
        edge_index : np.ndarray (2, E)
        edge_weights : np.ndarray (E,)
        """
        N, k = self.knn_indices.shape
        sources = np.repeat(np.arange(N), k)
        targets = self.knn_indices.ravel()
        weights = self.knn_similarities.ravel()

        if symmetric:
            # Add reverse edges
            all_sources = np.concatenate([sources, targets])
            all_targets = np.concatenate([targets, sources])
            all_weights = np.concatenate([weights, weights])

            # Deduplicate (keep max weight for duplicate edges)
            edge_set = {}
            for s, t, w in zip(all_sources, all_targets, all_weights):
                key = (int(s), int(t))
                if key not in edge_set or w > edge_set[key]:
                    edge_set[key] = w

            if edge_set:
                edges = list(edge_set.keys())
                sources = np.array([e[0] for e in edges])
                targets = np.array([e[1] for e in edges])
                weights = np.array([edge_set[e] for e in edges])
            else:
                sources = np.array([], dtype=int)
                targets = np.array([], dtype=int)
                weights = np.array([], dtype=float)

        # Remove self-loops
        mask = sources != targets
        edge_index = np.stack([sources[mask], targets[mask]])
        edge_weights = weights[mask]

        return edge_index, edge_weights

    def separation_score(self, outcomes: np.ndarray) -> float:
        """
        Compute failure neighborhood separation Δ directly from kNN.

        No dense matrix needed — uses pre-computed neighbors.

        Parameters
        ----------
        outcomes : np.ndarray (N,)

        Returns
        -------
        float Δ
        """
        # Neighbor outcome rates for all entities
        neighbor_fail_rate = outcomes[self.knn_indices].mean(axis=1)

        fail_mask = outcomes == 1
        succ_mask = outcomes == 0

        if fail_mask.sum() == 0 or succ_mask.sum() == 0:
            return 0.0

        return float(
            neighbor_fail_rate[fail_mask].mean() -
            neighbor_fail_rate[succ_mask].mean()
        )

    def to_dense(self) -> np.ndarray:
        """
        Convert to dense N×N matrix (use only for small datasets).

        WARNING: This defeats the purpose of sparse computation.
        Only use for compatibility with code that requires dense input.
        """
        N = self.n_entities
        dense = np.zeros((N, N))
        for i in range(N):
            dense[i, self.knn_indices[i]] = self.knn_similarities[i]
        # Symmetrize
        dense = np.maximum(dense, dense.T)
        np.fill_diagonal(dense, 1.0)
        return dense


class SparseSimilarity:
    """
    Memory-safe sparse kNN similarity computation.

    Computes pairwise distances in chunks, keeping only the k nearest
    neighbors per entity. Never holds the full N×N matrix.

    Parameters
    ----------
    method : str
        Similarity measure (same as SimilarityEngine).
    k : int
        Number of nearest neighbors. Default: 10
    chunk_size : int
        Rows to process at once. Default: 1000
    n_bins : int
        Bins for discrete methods. Default: 3
    """

    VALID_METHODS = {
        "simpson", "cosine", "bray_curtis", "jaccard",
        "pearson", "euclidean", "mahalanobis",
    }

    DISCRETE_METHODS = {"simpson", "jaccard"}

    def __init__(
        self,
        method: str = "mahalanobis",
        k: int = 10,
        chunk_size: int = 1000,
        n_bins: int = 3,
    ):
        if method not in self.VALID_METHODS:
            raise ValueError(f"method must be one of {self.VALID_METHODS}")
        self.method = method
        self.k = k
        self.chunk_size = chunk_size
        self.n_bins = n_bins

    def compute(
        self,
        features: np.ndarray,
        normalize: bool = True,
    ) -> SparseKNNResult:
        """
        Compute sparse kNN similarity.

        Parameters
        ----------
        features : np.ndarray (N, D)
        normalize : bool

        Returns
        -------
        SparseKNNResult
        """
        N, D = features.shape
        k = min(self.k, N - 1)

        if normalize and self.method not in self.DISCRETE_METHODS:
            features = self._normalize(features)

        # Pre-compute method-specific data
        precomputed = self._precompute(features)

        # Process in chunks
        all_indices = np.zeros((N, k), dtype=np.int64)
        all_sims = np.zeros((N, k), dtype=np.float64)

        for start in range(0, N, self.chunk_size):
            end = min(start + self.chunk_size, N)
            chunk_size_actual = end - start

            # Compute distances from chunk to ALL entities
            sim_chunk = self._compute_chunk(
                features, start, end, precomputed
            )  # (chunk_size, N)

            # Zero out self-similarity
            for i in range(chunk_size_actual):
                sim_chunk[i, start + i] = -np.inf

            # Top-k via argpartition (O(N) per row)
            top_k_idx = np.argpartition(sim_chunk, -k, axis=1)[:, -k:]

            # Get actual similarities for top-k
            for i in range(chunk_size_actual):
                idx = top_k_idx[i]
                sims = sim_chunk[i, idx]
                # Sort by similarity (descending)
                order = np.argsort(sims)[::-1]
                all_indices[start + i] = idx[order]
                all_sims[start + i] = sims[order]

        # Clip similarities to [0, 1]
        np.clip(all_sims, 0.0, 1.0, out=all_sims)

        dense_memory_gb = (N * N * 8) / 1e9
        sparse_memory_mb = (N * k * 16) / 1e6

        return SparseKNNResult(
            knn_indices=all_indices,
            knn_similarities=all_sims,
            n_entities=N,
            k=k,
            method=self.method,
            metadata={
                "chunk_size": self.chunk_size,
                "normalize": normalize,
                "dense_would_be_gb": round(dense_memory_gb, 2),
                "sparse_memory_mb": round(sparse_memory_mb, 2),
                "savings_factor": round(dense_memory_gb * 1000 / max(sparse_memory_mb, 0.01)),
            },
        )

    def _precompute(self, features: np.ndarray) -> Dict[str, Any]:
        """Pre-compute method-specific data structures."""
        precomputed = {}

        if self.method == "cosine":
            norms = np.linalg.norm(features, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1.0, norms)
            precomputed["unit"] = features / norms

        elif self.method == "pearson":
            centered = features - features.mean(axis=1, keepdims=True)
            norms = np.linalg.norm(centered, axis=1, keepdims=True)
            norms = np.where(norms == 0, 1.0, norms)
            precomputed["normed"] = centered / norms

        elif self.method == "mahalanobis":
            cov = np.cov(features.T)
            cov += np.eye(cov.shape[0]) * 1e-6
            try:
                # Cholesky: Σ^{-1} = L L^T, so d_M(x,y) = ||Lx - Ly||
                # Transform features once, then use fast Euclidean
                L = np.linalg.cholesky(np.linalg.inv(cov))
                precomputed["transformed"] = features @ L
                precomputed["mahal_mode"] = "cholesky"
            except np.linalg.LinAlgError:
                precomputed["transformed"] = features
                precomputed["mahal_mode"] = "fallback_euclidean"

        elif self.method == "bray_curtis":
            precomputed["shifted"] = features - features.min(axis=0)

        elif self.method in self.DISCRETE_METHODS:
            precomputed["binned"] = self._discretize(features)

        return precomputed

    def _compute_chunk(
        self,
        features: np.ndarray,
        start: int,
        end: int,
        precomputed: Dict[str, Any],
    ) -> np.ndarray:
        """
        Compute similarity from chunk [start:end] to all entities.

        Returns (chunk_size, N) similarity matrix.
        """
        N = features.shape[0]

        if self.method == "euclidean":
            dists = cdist(features[start:end], features, metric="euclidean")
            return 1.0 / (1.0 + dists)

        elif self.method == "cosine":
            unit = precomputed["unit"]
            sim = unit[start:end] @ unit.T
            return (sim + 1.0) / 2.0

        elif self.method == "pearson":
            normed = precomputed["normed"]
            corr = normed[start:end] @ normed.T
            return (corr + 1.0) / 2.0

        elif self.method == "mahalanobis":
            # After Cholesky transform, Mahalanobis = Euclidean
            transformed = precomputed["transformed"]
            dists = cdist(transformed[start:end], transformed, metric="euclidean")
            return 1.0 / (1.0 + dists)

        elif self.method == "bray_curtis":
            shifted = precomputed["shifted"]
            dists = cdist(shifted[start:end], shifted, metric="braycurtis")
            return 1.0 - np.nan_to_num(dists, nan=1.0)

        elif self.method == "simpson":
            binned = precomputed["binned"]
            chunk_binned = binned[start:end]
            D = binned.shape[1]
            # (chunk, N, D) comparison
            shared = (chunk_binned[:, None, :] == binned[None, :, :]).sum(axis=2)
            richness_chunk = np.array([
                len(np.unique(chunk_binned[i])) for i in range(end - start)
            ])
            richness_all = np.array([
                len(np.unique(binned[i])) for i in range(N)
            ])
            min_rich = np.minimum(
                richness_chunk[:, None], richness_all[None, :]
            )
            min_rich = np.where(min_rich == 0, 1, min_rich)
            sim = (shared.astype(float) / D)
            nestedness = shared.astype(float) / min_rich
            return np.clip(sim * nestedness, 0.0, 1.0)

        elif self.method == "jaccard":
            binned = precomputed["binned"]
            chunk_binned = binned[start:end]
            D = binned.shape[1]
            shared = (chunk_binned[:, None, :] == binned[None, :, :]).sum(axis=2).astype(float)
            union = 2 * D - shared
            union = np.where(union == 0, 1, union)
            return shared / union

        raise ValueError(f"Unknown method: {self.method}")

    def _normalize(self, features: np.ndarray) -> np.ndarray:
        means = features.mean(axis=0)
        stds = features.std(axis=0)
        stds = np.where(stds == 0, 1.0, stds)
        return (features - means) / stds

    def _discretize(self, features: np.ndarray) -> np.ndarray:
        N, D = features.shape
        binned = np.zeros_like(features, dtype=int)
        for d in range(D):
            col = features[:, d]
            edges = np.linspace(col.min(), col.max() + 1e-10, self.n_bins + 1)
            binned[:, d] = np.digitize(col, edges[1:-1])
        return binned


def compute_sparse_knn_batch(
    features: np.ndarray,
    methods: Optional[list] = None,
    k: int = 10,
    chunk_size: int = 1000,
    n_bins: int = 3,
    normalize: bool = True,
) -> Dict[str, SparseKNNResult]:
    """
    Compute sparse kNN for multiple methods.

    Memory-safe: processes one method at a time,
    each using chunked computation.

    Parameters
    ----------
    features : np.ndarray (N, D)
    methods : list of str
    k : int
    chunk_size : int
    n_bins : int
    normalize : bool

    Returns
    -------
    dict {method_name: SparseKNNResult}
    """
    if methods is None:
        methods = list(SparseSimilarity.VALID_METHODS)

    results = {}
    for method in methods:
        sparse = SparseSimilarity(
            method=method, k=k, chunk_size=chunk_size, n_bins=n_bins
        )
        results[method] = sparse.compute(features, normalize=normalize)

    return results
