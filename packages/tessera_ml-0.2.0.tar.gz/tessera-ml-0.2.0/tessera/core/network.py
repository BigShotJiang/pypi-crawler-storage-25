"""
TESSERA Network Construction

Builds graph representations from similarity matrices for GNN input.
Supports multiple graph construction strategies:
  - threshold: connect entities above a similarity threshold
  - knn: connect each entity to its k most similar neighbors
  - weighted_full: fully connected weighted graph (similarity as edge weight)
"""

import numpy as np
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass, field


@dataclass
class TesseraGraph:
    """
    Graph representation of entity similarity network.

    Stores edge list, edge weights, node features, and node labels
    ready for GNN consumption.
    """
    # Edge structure
    edge_index: np.ndarray       # (2, E) source/target node indices
    edge_weights: np.ndarray     # (E,) similarity weights

    # Node data
    node_features: np.ndarray    # (N, D) feature matrix
    node_labels: np.ndarray      # (N,) outcome labels (0/1)

    # Metadata
    n_nodes: int
    n_edges: int
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Optional extras
    domain_labels: Optional[np.ndarray] = None
    time_windows: Optional[np.ndarray] = None
    pattern_labels: Optional[np.ndarray] = None

    @property
    def density(self) -> float:
        """Graph density: actual edges / possible edges."""
        max_edges = self.n_nodes * (self.n_nodes - 1)
        return self.n_edges / max_edges if max_edges > 0 else 0.0

    @property
    def avg_degree(self) -> float:
        """Average node degree."""
        return self.n_edges / self.n_nodes if self.n_nodes > 0 else 0.0

    def degree_distribution(self) -> np.ndarray:
        """Degree of each node."""
        degrees = np.zeros(self.n_nodes, dtype=int)
        if self.n_edges > 0:
            nodes, counts = np.unique(
                self.edge_index[0], return_counts=True
            )
            degrees[nodes] = counts
        return degrees

    def weight_distribution(self) -> Dict[str, float]:
        """Statistics of edge weights."""
        if self.n_edges == 0:
            return {"mean": 0, "std": 0, "min": 0, "max": 0, "median": 0}
        return {
            "mean": float(self.edge_weights.mean()),
            "std": float(self.edge_weights.std()),
            "min": float(self.edge_weights.min()),
            "max": float(self.edge_weights.max()),
            "median": float(np.median(self.edge_weights)),
        }

    def summary(self) -> str:
        """Human-readable graph summary."""
        degrees = self.degree_distribution()
        wstats = self.weight_distribution()

        lines = [
            "TESSERA Graph Summary",
            "=" * 40,
            f"Nodes:           {self.n_nodes}",
            f"Edges:           {self.n_edges}",
            f"Density:         {self.density:.4f}",
            f"Avg degree:      {self.avg_degree:.1f}",
            f"Degree range:    [{degrees.min()}, {degrees.max()}]",
            f"",
            f"Edge weights:",
            f"  Mean:          {wstats['mean']:.4f}",
            f"  Std:           {wstats['std']:.4f}",
            f"  Range:         [{wstats['min']:.4f}, {wstats['max']:.4f}]",
        ]

        if self.node_labels is not None:
            n_pos = int(self.node_labels.sum())
            lines.append(f"")
            lines.append(f"Labels:          {n_pos} positive / "
                         f"{self.n_nodes - n_pos} negative")

        return "\n".join(lines)


class NetworkBuilder:
    """
    Constructs graphs from similarity matrices.

    Parameters
    ----------
    strategy : str
        Graph construction strategy:
        - "threshold": connect pairs with similarity >= threshold
        - "knn": connect each node to k nearest neighbors
        - "weighted_full": fully connected, similarity as weight
    threshold : float
        Similarity threshold for "threshold" strategy. Default: 0.5
    k : int
        Number of neighbors for "knn" strategy. Default: 10
    symmetric_knn : bool
        If True, make kNN graph symmetric (if i→j, add j→i).
        Default: True
    min_weight : float
        Minimum edge weight to include (prunes very weak connections).
        Default: 0.0
    self_loops : bool
        Include self-loops. Default: False
    """

    VALID_STRATEGIES = {"threshold", "knn", "weighted_full"}

    def __init__(
        self,
        strategy: str = "knn",
        threshold: float = 0.5,
        k: int = 10,
        symmetric_knn: bool = True,
        min_weight: float = 0.0,
        self_loops: bool = False,
    ):
        if strategy not in self.VALID_STRATEGIES:
            raise ValueError(
                f"strategy must be one of {self.VALID_STRATEGIES}, "
                f"got '{strategy}'"
            )
        self.strategy = strategy
        self.threshold = threshold
        self.k = k
        self.symmetric_knn = symmetric_knn
        self.min_weight = min_weight
        self.self_loops = self_loops

    def build(
        self,
        similarity_matrix: np.ndarray,
        node_features: np.ndarray,
        node_labels: np.ndarray,
        domain_labels: Optional[np.ndarray] = None,
        time_windows: Optional[np.ndarray] = None,
        pattern_labels: Optional[np.ndarray] = None,
    ) -> TesseraGraph:
        """
        Build a graph from a similarity matrix.

        Parameters
        ----------
        similarity_matrix : np.ndarray
            (N, N) pairwise similarity matrix.
        node_features : np.ndarray
            (N, D) feature matrix for nodes.
        node_labels : np.ndarray
            (N,) binary outcome labels.
        domain_labels : np.ndarray, optional
            (N,) domain assignments.
        time_windows : np.ndarray, optional
            (N,) time window assignments.
        pattern_labels : np.ndarray, optional
            (N,) failure pattern labels.

        Returns
        -------
        TesseraGraph
        """
        N = similarity_matrix.shape[0]

        dispatch = {
            "threshold": self._build_threshold,
            "knn": self._build_knn,
            "weighted_full": self._build_weighted_full,
        }

        edge_index, edge_weights = dispatch[self.strategy](similarity_matrix)

        # Apply minimum weight filter
        if self.min_weight > 0 and len(edge_weights) > 0:
            mask = edge_weights >= self.min_weight
            edge_index = edge_index[:, mask]
            edge_weights = edge_weights[mask]

        metadata = {
            "strategy": self.strategy,
            "threshold": self.threshold if self.strategy == "threshold" else None,
            "k": self.k if self.strategy == "knn" else None,
            "symmetric_knn": self.symmetric_knn if self.strategy == "knn" else None,
            "min_weight": self.min_weight,
            "self_loops": self.self_loops,
        }

        return TesseraGraph(
            edge_index=edge_index,
            edge_weights=edge_weights,
            node_features=node_features,
            node_labels=node_labels,
            n_nodes=N,
            n_edges=edge_index.shape[1] if edge_index.size > 0 else 0,
            metadata=metadata,
            domain_labels=domain_labels,
            time_windows=time_windows,
            pattern_labels=pattern_labels,
        )


    def build_from_sparse(
        self,
        sparse_result,
        node_features,
        node_labels,
        domain_labels=None,
        time_windows=None,
        pattern_labels=None,
    ):
        """Build graph directly from SparseKNNResult."""
        edge_index, edge_weights = sparse_result.to_edge_index(
            symmetric=self.symmetric_knn
        )

        if self.min_weight > 0 and len(edge_weights) > 0:
            mask = edge_weights >= self.min_weight
            edge_index = edge_index[:, mask]
            edge_weights = edge_weights[mask]

        N = sparse_result.n_entities
        metadata = {
            "strategy": "sparse_knn",
            "k": sparse_result.k,
            "method": sparse_result.method,
            "memory_mb": sparse_result.memory_mb,
        }

        return TesseraGraph(
            edge_index=edge_index,
            edge_weights=edge_weights,
            node_features=node_features,
            node_labels=node_labels,
            n_nodes=N,
            n_edges=edge_index.shape[1] if edge_index.size > 0 else 0,
            metadata=metadata,
            domain_labels=domain_labels,
            time_windows=time_windows,
            pattern_labels=pattern_labels,
        )

    def _build_threshold(
        self, sim: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Connect all pairs with similarity >= threshold."""
        N = sim.shape[0]

        if self.self_loops:
            mask = sim >= self.threshold
        else:
            mask = (sim >= self.threshold) & ~np.eye(N, dtype=bool)

        rows, cols = np.where(mask)
        weights = sim[rows, cols]

        edge_index = np.stack([rows, cols], axis=0)
        return edge_index, weights

    def _build_knn(
        self, sim: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Connect each node to its k nearest neighbors."""
        N = sim.shape[0]
        k = min(self.k, N - 1)

        sources = []
        targets = []
        weights = []

        for i in range(N):
            # Get similarities to all other nodes
            sims = sim[i].copy()
            if not self.self_loops:
                sims[i] = -1  # exclude self

            # Top-k neighbors
            neighbors = np.argsort(sims)[::-1][:k]

            for j in neighbors:
                if sims[j] > 0:  # skip zero similarity
                    sources.append(i)
                    targets.append(j)
                    weights.append(sims[j])

        if not sources:
            return np.zeros((2, 0), dtype=int), np.zeros(0)

        edge_index = np.stack(
            [np.array(sources, dtype=int), np.array(targets, dtype=int)],
            axis=0,
        )
        edge_weights = np.array(weights)

        if self.symmetric_knn:
            # Add reverse edges
            reverse_index = np.stack([edge_index[1], edge_index[0]], axis=0)
            edge_index = np.concatenate([edge_index, reverse_index], axis=1)
            edge_weights = np.concatenate([edge_weights, edge_weights])

            # Remove duplicates
            edge_index, edge_weights = self._deduplicate_edges(
                edge_index, edge_weights
            )

        return edge_index, edge_weights

    def _build_weighted_full(
        self, sim: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Fully connected graph with similarity as edge weight."""
        N = sim.shape[0]

        if self.self_loops:
            mask = np.ones((N, N), dtype=bool)
        else:
            mask = ~np.eye(N, dtype=bool)

        rows, cols = np.where(mask)
        weights = sim[rows, cols]

        # Filter out zero-weight edges
        nonzero = weights > 0
        rows = rows[nonzero]
        cols = cols[nonzero]
        weights = weights[nonzero]

        edge_index = np.stack([rows, cols], axis=0)
        return edge_index, weights

    @staticmethod
    def _deduplicate_edges(
        edge_index: np.ndarray, edge_weights: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Remove duplicate edges, keeping the one with higher weight."""
        # Create canonical edge representation (smaller index first)
        canonical = np.sort(edge_index, axis=0)
        # Unique edge identifier
        edge_ids = canonical[0] * edge_index.shape[1] + canonical[1]

        # For duplicates, keep higher weight
        unique_ids, indices = np.unique(edge_ids, return_index=True)

        return edge_index[:, indices], edge_weights[indices]

    def metadata_dict(self) -> Dict[str, Any]:
        """Return configuration for reproducibility."""
        return {
            "strategy": self.strategy,
            "threshold": self.threshold,
            "k": self.k,
            "symmetric_knn": self.symmetric_knn,
            "min_weight": self.min_weight,
            "self_loops": self.self_loops,
        }
