"""
TESSERA - Topological Entity Similarity Structure for Emergent Response Analysis

A domain-general framework for detecting and exploiting geometric structure
in multi-dimensional feature spaces for predictive classification.

Modules:
- tessera.core: Similarity, network, community detection, regime divergence
- tessera.synthetic: Synthetic data generation
- tessera.models: GNN, LSTM, Autoencoder, Ensemble
"""

__version__ = "0.2.0"
