#!/usr/bin/env python3
"""
TESSERA Pipeline Test — Data → Similarity → Network
"""

import sys
import os
import time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import numpy as np
from tessera.synthetic import LandscapeBuilder, OutcomeAssigner
from tessera.core import SimilarityEngine, NetworkBuilder, compute_similarity_batch


def main():
    print("=" * 60)
    print("TESSERA Pipeline Test — Data → Similarity → Network")
    print("=" * 60)

    # ── Step 1: Generate data ────────────────────────────────────
    print("\n[1/4] Generating synthetic data...")
    t0 = time.time()

    builder = LandscapeBuilder(
        n_entities=1000,
        n_dimensions=15,
        n_domains=4,
        domain_geometry="elliptical",
        overlap=0.15,
        feature_correlation="block",
        n_time_windows=5,
        drift_rate=0.03,
        random_state=42,
    )
    landscape = builder.build()

    assigner = OutcomeAssigner(
        failure_rate=0.15,
        difficulty=0.5,
        random_state=42,
    )
    dataset = assigner.apply(landscape, pattern="ecotone")

    print(f"  Generated {dataset.n_entities} entities, "
          f"{dataset.n_failures} failures "
          f"({dataset.failure_rate:.1%}) in {time.time()-t0:.2f}s")

    # ── Step 2: Compare all similarity measures ──────────────────
    print("\n[2/4] Computing similarity matrices (all 7 measures)...")

    N_SAMPLE = 500
    rng = np.random.default_rng(42)
    sample_idx = rng.choice(dataset.n_entities, N_SAMPLE, replace=False)
    sample_features = dataset.features[sample_idx]
    sample_labels = dataset.outcomes[sample_idx]

    timings = {}
    sim_matrices = {}

    methods = ["cosine", "euclidean", "bray_curtis", "pearson",
               "mahalanobis", "simpson", "jaccard"]

    for method in methods:
        t0 = time.time()
        engine = SimilarityEngine(method=method, n_bins=3)
        sim = engine.compute(sample_features, normalize=True)
        elapsed = time.time() - t0
        timings[method] = elapsed
        sim_matrices[method] = sim

        upper = sim[np.triu_indices(N_SAMPLE, k=1)]
        print(f"  {method:15s}  mean={upper.mean():.4f}  "
              f"std={upper.std():.4f}  "
              f"range=[{upper.min():.4f}, {upper.max():.4f}]  "
              f"time={elapsed:.3f}s")

    # ── Step 3: Compare graph construction strategies ────────────
    print("\n[3/4] Building networks (multiple strategies × cosine)...")

    sim_cosine = sim_matrices["cosine"]
    strategies = [
        ("knn_5", NetworkBuilder(strategy="knn", k=5)),
        ("knn_10", NetworkBuilder(strategy="knn", k=10)),
        ("knn_20", NetworkBuilder(strategy="knn", k=20)),
        ("threshold_0.5", NetworkBuilder(strategy="threshold", threshold=0.5)),
        ("threshold_0.7", NetworkBuilder(strategy="threshold", threshold=0.7)),
        ("threshold_0.9", NetworkBuilder(strategy="threshold", threshold=0.9)),
    ]

    for name, net_builder in strategies:
        t0 = time.time()
        graph = net_builder.build(
            similarity_matrix=sim_cosine,
            node_features=sample_features,
            node_labels=sample_labels,
        )
        elapsed = time.time() - t0

        degrees = graph.degree_distribution()
        print(f"  {name:20s}  nodes={graph.n_nodes}  edges={graph.n_edges:>7d}  "
              f"density={graph.density:.4f}  "
              f"avg_deg={graph.avg_degree:>6.1f}  "
              f"deg_range=[{degrees.min()}, {degrees.max()}]  "
              f"time={elapsed:.3f}s")

    # ── Step 4: Cross-measure failure separation ─────────────────
    print("\n[4/4] Best method × strategy for failure separation...\n")

    results = []

    for method, sim in sim_matrices.items():
        net_builder = NetworkBuilder(strategy="knn", k=10)
        graph = net_builder.build(
            similarity_matrix=sim,
            node_features=sample_features,
            node_labels=sample_labels,
        )

        fail_neighbor_ratios = []
        for node in range(graph.n_nodes):
            neighbor_mask = graph.edge_index[0] == node
            neighbors = graph.edge_index[1, neighbor_mask]

            if len(neighbors) == 0:
                continue

            n_fail_neighbors = sample_labels[neighbors].sum()
            ratio = n_fail_neighbors / len(neighbors)
            fail_neighbor_ratios.append((ratio, sample_labels[node]))

        fail_ratios = [r for r, label in fail_neighbor_ratios if label == 1]
        success_ratios = [r for r, label in fail_neighbor_ratios if label == 0]

        mean_fail = np.mean(fail_ratios) if fail_ratios else 0
        mean_success = np.mean(success_ratios) if success_ratios else 0
        separation = mean_fail - mean_success

        results.append((method, separation, mean_fail, mean_success))
        print(f"  {method:15s}  fail_neighbor_rate: "
              f"failures={mean_fail:.3f}  successes={mean_success:.3f}  "
              f"Δ={separation:+.3f}")

    results.sort(key=lambda x: x[1], reverse=True)
    print(f"\n  Ranking by failure neighborhood separation (Δ):")
    for rank, (method, sep, mf, ms) in enumerate(results, 1):
        print(f"    {rank}. {method:15s}  Δ={sep:+.3f}")

    print("\n" + "=" * 60)
    print("PIPELINE TEST COMPLETE")
    print("=" * 60)
    best = results[0]
    print(f"\nBest similarity measure: {best[0]} (Δ={best[1]:+.3f})")


if __name__ == "__main__":
    main()
