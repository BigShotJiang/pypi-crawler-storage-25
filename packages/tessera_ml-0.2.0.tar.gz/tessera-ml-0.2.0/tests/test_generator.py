#!/usr/bin/env python3
"""
TESSERA Synthetic Data Generator — Validation Script

Generates all four dataset types (ecotone, isolated, diffuse, mixed)
on the same landscape, runs verification, and produces diagnostic plots.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import numpy as np
from tessera.synthetic import (
    LandscapeBuilder,
    OutcomeAssigner,
    plot_landscape,
    plot_dataset,
    plot_diagnostic_panel,
)

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "test_output")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def main():
    print("=" * 60)
    print("TESSERA Synthetic Data Generator — Validation")
    print("=" * 60)

    # ── Step 1: Build landscape ──────────────────────────────────
    print("\n[1/5] Building landscape...")

    builder = LandscapeBuilder(
        n_entities=5000,
        n_dimensions=15,
        n_domains=4,
        domain_sizes=[0.30, 0.25, 0.25, 0.20],
        domain_geometry="elliptical",
        overlap=0.15,
        feature_correlation="block",
        n_correlated_groups=3,
        n_time_windows=5,
        drift_rate=0.03,
        random_state=42,
    )

    landscape = builder.build()
    print(landscape.summary())

    # Save landscape plot
    fig = plot_landscape(landscape, title="Test Landscape — 4 Domains")
    fig.savefig(f"{OUTPUT_DIR}/01_landscape.png", dpi=150, bbox_inches="tight")
    print(f"\n  → Saved landscape plot")

    # ── Step 2: Generate pure-pattern datasets ───────────────────
    assigner = OutcomeAssigner(
        failure_rate=0.15,
        difficulty=0.5,
        noise=0.05,
        random_state=42,
    )

    patterns = ["ecotone", "isolated", "diffuse"]

    for i, pattern in enumerate(patterns, start=2):
        print(f"\n[{i}/5] Generating {pattern} dataset...")

        ds = assigner.apply(landscape, pattern=pattern)
        print(f"\n{ds.summary()}")

        # Verify
        print(f"\nVerification:")
        ds.verify_pattern(verbose=True)

        # Diagnostic panel
        fig = plot_diagnostic_panel(
            ds,
            suptitle=f"TESSERA — {pattern.capitalize()} Pattern",
        )
        fig.savefig(
            f"{OUTPUT_DIR}/0{i}_{pattern}_diagnostics.png",
            dpi=150,
            bbox_inches="tight",
        )
        print(f"  → Saved diagnostic panel")

        # Save dataset
        ds.save(f"{OUTPUT_DIR}/{pattern}_dataset")
        print(f"  → Saved dataset files")

    # ── Step 3: Generate mixed dataset ───────────────────────────
    print(f"\n[5/5] Generating mixed dataset...")

    ds_mixed = assigner.apply(
        landscape,
        pattern="mixed",
        weights={"ecotone": 0.5, "isolated": 0.3, "diffuse": 0.2},
    )
    print(f"\n{ds_mixed.summary()}")

    print(f"\nVerification:")
    ds_mixed.verify_pattern(verbose=True)

    fig = plot_diagnostic_panel(
        ds_mixed,
        suptitle="TESSERA — Mixed Pattern (50% eco / 30% iso / 20% diff)",
    )
    fig.savefig(
        f"{OUTPUT_DIR}/05_mixed_diagnostics.png",
        dpi=150,
        bbox_inches="tight",
    )
    print(f"  → Saved diagnostic panel")

    ds_mixed.save(f"{OUTPUT_DIR}/mixed_dataset")
    print(f"  → Saved dataset files")

    # ── Summary ──────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("VALIDATION COMPLETE")
    print("=" * 60)
    print(f"\nOutputs saved to: {OUTPUT_DIR}/")

    for f in sorted(os.listdir(OUTPUT_DIR)):
        size = os.path.getsize(f"{OUTPUT_DIR}/{f}")
        print(f"  {f:45s} {size / 1024:.1f} KB")

    # ── Reproducibility check ────────────────────────────────────
    print("\n\nReproducibility check...")
    builder2 = LandscapeBuilder(
        n_entities=5000, n_dimensions=15, n_domains=4,
        domain_sizes=[0.30, 0.25, 0.25, 0.20],
        domain_geometry="elliptical", overlap=0.15,
        feature_correlation="block", n_correlated_groups=3,
        n_time_windows=5, drift_rate=0.03, random_state=42,
    )
    landscape2 = builder2.build()

    if np.allclose(landscape.features, landscape2.features):
        print("  ✓ Landscape is reproducible (same seed → same data)")
    else:
        print("  ✗ WARNING: Landscape not reproducible!")


if __name__ == "__main__":
    main()
