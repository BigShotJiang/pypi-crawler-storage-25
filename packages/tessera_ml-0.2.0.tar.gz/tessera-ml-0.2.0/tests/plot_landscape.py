#!/usr/bin/env python3
"""
TESSERA Response Landscape — Visualization Suite

Generates diagnostic figures for the spatial analysis framework:
1. Response surface topography with entity overlay
2. Gradient field with ridgelines and saddle points
3. Persistence diagrams and Betti curves
4. Spatial scan clusters
5. Reference vs empirical comparison
6. Combined 6-panel diagnostic
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Circle
from matplotlib.collections import LineCollection
from sklearn.decomposition import PCA

from tessera.synthetic import LandscapeBuilder, OutcomeAssigner
from tessera.core.similarity import SimilarityEngine
from tessera.core.network import NetworkBuilder
from tessera.core.community import CommunityDetector, CommunityPersistenceAnalyzer
from tessera.core.regime_divergence import RegimeDivergenceComputer
from tessera.core.response_landscape import (
    ReferenceLandscapeBuilder,
    GradientFieldAnalyzer,
    PersistentHomologyAnalyzer,
    SpatialScanStatistic,
)

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "test_output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Color scheme ─────────────────────────────────────────────
CMAP_RESPONSE = "YlOrRd"
CMAP_GRADIENT = "inferno"
CMAP_DENSITY = "Blues"
COLOR_FAIL = "#e74c3c"
COLOR_SUCCESS = "#2ecc71"
COLOR_RIDGE = "#ffffff"
COLOR_SADDLE = "#00ffff"


def generate_data(pattern="boundary", n_entities=1000):
    """Generate synthetic data for visualization."""
    builder = LandscapeBuilder(
        n_entities=n_entities, n_dimensions=15, n_domains=4,
        domain_geometry="elliptical", overlap=0.15,
        feature_correlation="block", n_time_windows=5,
        drift_rate=0.03, random_state=42,
    )
    landscape = builder.build()
    assigner = OutcomeAssigner(failure_rate=0.15, difficulty=0.5, random_state=42)

    # Map display name to internal pattern name
    internal_pattern = "ecotone" if pattern == "boundary" else pattern

    if internal_pattern == "mixed":
        dataset = assigner.apply(landscape, pattern="mixed",
            weights={"ecotone": 0.5, "isolated": 0.3, "diffuse": 0.2})
    else:
        dataset = assigner.apply(landscape, pattern=internal_pattern)

    return dataset, landscape


def run_landscape_analysis(dataset):
    """Run all landscape analyses."""
    # PCA reduction
    reducer = PCA(n_components=2, random_state=42)
    features_2d = reducer.fit_transform(dataset.features)

    # Response surface
    lb = ReferenceLandscapeBuilder(resolution=80, smoothing=1.5)
    surface = lb.build(
        features=dataset.features,
        outcomes=dataset.outcomes,
        time_windows=dataset.time_windows,
        stable_windows=[0, 1, 2, 4],
        reducer=reducer,
    )

    # Gradient
    ga = GradientFieldAnalyzer(ridge_percentile=85)
    gradients = ga.analyze(surface, features_2d)

    # Persistent homology
    ph = PersistentHomologyAnalyzer(significance_threshold=0.1, n_subsample=400)
    topo = ph.analyze(dataset.features, dataset.outcomes)

    # Scan statistics
    scan = SpatialScanStatistic(
        n_permutations=99, n_candidate_centers=30, random_state=42
    )
    scan_result = scan.scan(features_2d, dataset.outcomes)

    # Entity scores
    scores = surface.score_entities(features_2d)

    return features_2d, surface, gradients, topo, scan_result, scores, reducer


def plot_response_surface(ax, surface, features_2d, outcomes, title=None):
    """Plot the response probability surface with entity overlay."""
    # Surface
    im = ax.contourf(
        surface.grid_x, surface.grid_y,
        surface.response_surface.T,
        levels=20, cmap=CMAP_RESPONSE, alpha=0.8,
    )

    # Contour lines
    ax.contour(
        surface.grid_x, surface.grid_y,
        surface.response_surface.T,
        levels=8, colors="black", linewidths=0.3, alpha=0.4,
    )

    # Entities
    succ = outcomes == 0
    fail = outcomes == 1
    ax.scatter(features_2d[succ, 0], features_2d[succ, 1],
               c=COLOR_SUCCESS, s=6, alpha=0.2, edgecolors="none", zorder=2)
    ax.scatter(features_2d[fail, 0], features_2d[fail, 1],
               c=COLOR_FAIL, s=15, alpha=0.6, edgecolors="white",
               linewidths=0.3, zorder=3)

    plt.colorbar(im, ax=ax, label="Response Probability", shrink=0.8)
    ax.set_title(title or "Response Surface", fontsize=11, fontweight="bold")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")


def plot_gradient_field(ax, surface, gradients, features_2d, outcomes, title=None):
    """Plot gradient magnitude with ridgelines and saddle points."""
    # Gradient magnitude
    im = ax.contourf(
        surface.grid_x, surface.grid_y,
        surface.gradient_magnitude.T,
        levels=20, cmap=CMAP_GRADIENT, alpha=0.85,
    )

    # Ridgelines
    ridge = gradients.ridgeline_mask
    ridge_y, ridge_x = np.where(ridge.T)
    if len(ridge_x) > 0:
        ax.scatter(
            surface.grid_x[ridge_x], surface.grid_y[ridge_y],
            c=COLOR_RIDGE, s=1, alpha=0.5, zorder=3, label="Ridgeline",
        )

    # Saddle points
    if gradients.saddle_points:
        sx = [p[0] for p in gradients.saddle_points[:20]]
        sy = [p[1] for p in gradients.saddle_points[:20]]
        ax.scatter(sx, sy, c=COLOR_SADDLE, marker="x", s=40,
                   linewidths=1.5, zorder=4, label="Saddle points")

    # Gradient arrows (subsampled)
    step = max(1, surface.resolution // 15)
    gx_sub = surface.gradient_x[::step, ::step]
    gy_sub = surface.gradient_y[::step, ::step]
    xx_sub = surface.grid_x[::step]
    yy_sub = surface.grid_y[::step]
    xx_mesh, yy_mesh = np.meshgrid(xx_sub, yy_sub, indexing="ij")

    mag = np.sqrt(gx_sub**2 + gy_sub**2)
    mag = np.where(mag == 0, 1, mag)
    ax.quiver(xx_mesh, yy_mesh, gx_sub / mag, gy_sub / mag,
              color="white", alpha=0.4, scale=30, width=0.003, zorder=2)

    # Failure entities
    fail = outcomes == 1
    ax.scatter(features_2d[fail, 0], features_2d[fail, 1],
               c=COLOR_FAIL, s=12, alpha=0.5, edgecolors="white",
               linewidths=0.3, zorder=5)

    plt.colorbar(im, ax=ax, label="Gradient Magnitude", shrink=0.8)
    ax.legend(loc="upper right", fontsize=7, framealpha=0.8)
    ax.set_title(title or "Gradient Field", fontsize=11, fontweight="bold")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")


def plot_persistence_diagram(ax, topo, title=None):
    """Plot persistence diagram (birth-death scatter)."""
    # H0
    if len(topo.h0_diagram) > 0:
        ax.scatter(topo.h0_diagram[:, 0], topo.h0_diagram[:, 1],
                   c="#3498db", s=15, alpha=0.5, label=f"H0 (n={len(topo.h0_diagram)})",
                   zorder=3)

    # H1
    if len(topo.h1_diagram) > 0:
        ax.scatter(topo.h1_diagram[:, 0], topo.h1_diagram[:, 1],
                   c="#e67e22", s=15, alpha=0.5, label=f"H1 (n={len(topo.h1_diagram)})",
                   zorder=3)

    # Diagonal (birth = death)
    all_vals = []
    if len(topo.h0_diagram) > 0:
        all_vals.extend(topo.h0_diagram.ravel())
    if len(topo.h1_diagram) > 0:
        all_vals.extend(topo.h1_diagram.ravel())

    if all_vals:
        all_vals = [v for v in all_vals if np.isfinite(v)]
        if all_vals:
            lo, hi = min(all_vals), max(all_vals)
            ax.plot([lo, hi], [lo, hi], "k--", alpha=0.3, linewidth=1)

            # Significance threshold line
            max_pers = max(
                topo.h0_persistence.max() if len(topo.h0_persistence) > 0 else 0,
                topo.h1_persistence.max() if len(topo.h1_persistence) > 0 else 0,
            )
            thresh = 0.1 * max_pers
            ax.plot([lo, hi - thresh], [lo + thresh, hi],
                    "r--", alpha=0.3, linewidth=1, label=f"Significance threshold")

    ax.legend(fontsize=7, framealpha=0.8)
    ax.set_xlabel("Birth")
    ax.set_ylabel("Death")
    ax.set_title(title or "Persistence Diagram", fontsize=11, fontweight="bold")


def plot_betti_curves(ax, topo, title=None):
    """Plot Betti number curves across filtration."""
    ax.plot(topo.filtration_values, topo.betti_0,
            c="#3498db", linewidth=2, label="β₀ (components)")
    ax.plot(topo.filtration_values, topo.betti_1,
            c="#e67e22", linewidth=2, label="β₁ (loops)")

    ax.fill_between(topo.filtration_values, topo.betti_0,
                     alpha=0.15, color="#3498db")
    ax.fill_between(topo.filtration_values, topo.betti_1,
                     alpha=0.15, color="#e67e22")

    ax.legend(fontsize=8, framealpha=0.8)
    ax.set_xlabel("Filtration Value")
    ax.set_ylabel("Betti Number")
    ax.set_title(title or "Betti Curves", fontsize=11, fontweight="bold")


def plot_scan_clusters(ax, surface, scan_result, features_2d, outcomes, title=None):
    """Plot spatial scan clusters on response surface."""
    # Background surface
    ax.contourf(
        surface.grid_x, surface.grid_y,
        surface.response_surface.T,
        levels=15, cmap=CMAP_RESPONSE, alpha=0.5,
    )

    # All entities (faded)
    succ = outcomes == 0
    fail = outcomes == 1
    ax.scatter(features_2d[succ, 0], features_2d[succ, 1],
               c=COLOR_SUCCESS, s=4, alpha=0.1, edgecolors="none")
    ax.scatter(features_2d[fail, 0], features_2d[fail, 1],
               c=COLOR_FAIL, s=8, alpha=0.3, edgecolors="none")

    # Scan clusters
    colors = plt.cm.Set1(np.linspace(0, 1, max(len(scan_result.clusters), 1)))
    for i, cluster in enumerate(scan_result.clusters[:5]):
        circle = Circle(
            cluster.center, cluster.radius,
            fill=False, edgecolor=colors[i], linewidth=2,
            linestyle="--" if cluster.p_value >= 0.05 else "-",
            alpha=0.8,
        )
        ax.add_patch(circle)

        # Highlight entities in cluster
        ax.scatter(
            features_2d[cluster.entity_indices, 0],
            features_2d[cluster.entity_indices, 1],
            c=[colors[i]], s=12, alpha=0.6, edgecolors="white",
            linewidths=0.3, zorder=4,
        )

        # Label
        ax.annotate(
            f"RR={cluster.relative_risk:.1f}\np={cluster.p_value:.2f}",
            xy=cluster.center,
            fontsize=6, ha="center", va="bottom",
            bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.7),
        )

    ax.set_title(title or "Scan Clusters", fontsize=11, fontweight="bold")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")


def plot_reference_deviation(ax, surface, features_2d, outcomes, title=None):
    """Plot deviation from reference landscape."""
    if surface.reference_surface is None:
        ax.text(0.5, 0.5, "No reference surface", transform=ax.transAxes,
                ha="center", va="center", fontsize=12)
        return

    deviation = surface.response_surface - surface.reference_surface

    # Diverging colormap centered on zero
    vmax = max(abs(np.nanmin(deviation)), abs(np.nanmax(deviation)))
    im = ax.contourf(
        surface.grid_x, surface.grid_y,
        deviation.T,
        levels=20, cmap="RdBu_r", vmin=-vmax, vmax=vmax, alpha=0.85,
    )

    # Entities colored by outcome
    fail = outcomes == 1
    ax.scatter(features_2d[fail, 0], features_2d[fail, 1],
               c="black", s=12, alpha=0.4, edgecolors="white",
               linewidths=0.3, zorder=3, label="Failures")

    plt.colorbar(im, ax=ax, label="Deviation from Reference", shrink=0.8)
    ax.legend(fontsize=7, framealpha=0.8)
    ax.set_title(title or "Reference Deviation", fontsize=11, fontweight="bold")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")


def plot_basin_segmentation(ax, surface, gradients, features_2d, outcomes, title=None):
    """Plot basin segmentation of the landscape."""
    if gradients.basin_labels is not None:
        n_basins = int(gradients.basin_labels.max()) + 1
        cmap = plt.cm.Set3(np.linspace(0, 1, max(n_basins, 1)))

        ax.contourf(
            surface.grid_x, surface.grid_y,
            gradients.basin_labels.T,
            levels=np.arange(-0.5, n_basins + 0.5),
            colors=cmap[:n_basins], alpha=0.5,
        )

    # Ridgeline overlay
    ridge = gradients.ridgeline_mask
    ridge_y, ridge_x = np.where(ridge.T)
    if len(ridge_x) > 0:
        ax.scatter(
            surface.grid_x[ridge_x], surface.grid_y[ridge_y],
            c="black", s=0.5, alpha=0.6, zorder=2,
        )

    # Entities
    fail = outcomes == 1
    succ = outcomes == 0
    ax.scatter(features_2d[succ, 0], features_2d[succ, 1],
               c=COLOR_SUCCESS, s=6, alpha=0.15, edgecolors="none", zorder=3)
    ax.scatter(features_2d[fail, 0], features_2d[fail, 1],
               c=COLOR_FAIL, s=12, alpha=0.5, edgecolors="white",
               linewidths=0.3, zorder=4)

    ax.set_title(title or "Basin Segmentation", fontsize=11, fontweight="bold")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")


def main():
    print("=" * 60)
    print("TESSERA Response Landscape — Visualization Suite")
    print("=" * 60)

    for pattern in ["boundary", "isolated", "mixed"]:
        # Display name for titles
        display_name = "Boundary-Concentrated" if pattern == "boundary" else pattern.capitalize()

        print(f"\n── Generating figures for: {display_name} ──")

        # Generate data
        dataset, landscape = generate_data(pattern, n_entities=1000)

        # Run analysis
        features_2d, surface, gradients, topo, scan_result, scores, reducer = \
            run_landscape_analysis(dataset)

        # ── 6-Panel Diagnostic ───────────────────────────────
        fig, axes = plt.subplots(2, 3, figsize=(20, 13))

        plot_response_surface(
            axes[0, 0], surface, features_2d, dataset.outcomes,
            title="Response Surface"
        )
        plot_gradient_field(
            axes[0, 1], surface, gradients, features_2d, dataset.outcomes,
            title="Gradient Field + Ridgelines"
        )
        plot_basin_segmentation(
            axes[0, 2], surface, gradients, features_2d, dataset.outcomes,
            title="Basin Segmentation"
        )
        plot_persistence_diagram(
            axes[1, 0], topo,
            title="Persistence Diagram"
        )
        plot_betti_curves(
            axes[1, 1], topo,
            title="Betti Curves"
        )
        plot_scan_clusters(
            axes[1, 2], surface, scan_result, features_2d, dataset.outcomes,
            title="Spatial Scan Clusters"
        )

        fig.suptitle(
            f"TESSERA Response Landscape — {display_name} Pattern",
            fontsize=15, fontweight="bold", y=1.01,
        )
        fig.tight_layout()

        path = f"{OUTPUT_DIR}/landscape_{pattern}_6panel.png"
        fig.savefig(path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        print(f"  → Saved: {path}")

        # ── Reference Deviation (separate) ───────────────────
        fig, ax = plt.subplots(1, 1, figsize=(10, 8))
        plot_reference_deviation(
            ax, surface, features_2d, dataset.outcomes,
            title=f"Reference Deviation — {display_name}"
        )
        fig.tight_layout()
        path = f"{OUTPUT_DIR}/landscape_{pattern}_deviation.png"
        fig.savefig(path, dpi=150, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)
        print(f"  → Saved: {path}")

    print(f"\n{'=' * 60}")
    print(f"All figures saved to: {OUTPUT_DIR}/")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
