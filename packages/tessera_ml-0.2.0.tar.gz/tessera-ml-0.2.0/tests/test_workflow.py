#!/usr/bin/env python3
"""
TESSERA Workflow Test — Steps 1-3
Data → Similarity → Network → Community Detection → Regime Divergence
"""

import sys
import os
import time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import numpy as np
from tessera.synthetic import LandscapeBuilder, OutcomeAssigner
from tessera.core import (
    SimilarityEngine,
    NetworkBuilder,
    CommunityDetector,
    RegimeDivergenceComputer,
)


def test_workflow(pattern: str, n_entities: int = 1000):
    """Run full Steps 1-3 workflow on a given failure pattern."""
    # Map display name to internal generator pattern
    internal_pattern = "ecotone" if pattern == "boundary" else pattern
    display_name = "Boundary-Concentrated" if pattern == "boundary" else pattern.capitalize()

    print(f"\n{'─' * 55}")
    print(f"  Pattern: {display_name}")
    print(f"{'─' * 55}")

    # ── Step 0: Generate data ────────────────────────────────
    builder = LandscapeBuilder(
        n_entities=n_entities,
        n_dimensions=15,
        n_domains=4,
        domain_geometry="elliptical",
        overlap=0.15,
        feature_correlation="block",
        n_time_windows=5,
        drift_rate=0.03,
        random_state=42,
    )
    landscape = builder.build()

    assigner = OutcomeAssigner(
        failure_rate=0.15,
        difficulty=0.5,
        random_state=42,
    )

    if internal_pattern == "mixed":
        dataset = assigner.apply(
            landscape, pattern="mixed",
            weights={"ecotone": 0.5, "isolated": 0.3, "diffuse": 0.2},
        )
    else:
        dataset = assigner.apply(landscape, pattern=internal_pattern)

    print(f"  Data: {dataset.n_entities} entities, "
          f"{dataset.n_failures} failures ({dataset.failure_rate:.1%})")

    # ── Step 1: Characterize (Similarity + Network) ──────────
    t0 = time.time()
    sim_engine = SimilarityEngine(method="mahalanobis")
    sim_matrix = sim_engine.compute(dataset.features, normalize=True)
    t_sim = time.time() - t0

    t0 = time.time()
    net_builder = NetworkBuilder(strategy="knn", k=10)
    graph = net_builder.build(
        similarity_matrix=sim_matrix,
        node_features=dataset.features,
        node_labels=dataset.outcomes,
    )
    t_net = time.time() - t0

    print(f"  Network: {graph.n_nodes} nodes, {graph.n_edges} edges "
          f"(sim={t_sim:.2f}s, net={t_net:.3f}s)")

    # ── Step 2: Discover (Community Detection) ───────────────
    t0 = time.time()

    # Primary: Leiden
    detector_leiden = CommunityDetector(
        method="leiden",
        resolution=0.5,
        random_state=42,
    )
    communities = detector_leiden.detect(
        similarity_matrix=sim_matrix,
        edge_index=graph.edge_index,
        edge_weights=graph.edge_weights,
    )
    t_comm = time.time() - t0

    # Robustness check: Spectral
    t0_spec = time.time()
    detector_spectral = CommunityDetector(
        method="spectral",
        n_communities=communities.n_communities,  # match Leiden count
        random_state=42,
    )
    communities_spectral = detector_spectral.detect(similarity_matrix=sim_matrix)
    t_spec = time.time() - t0_spec

    # Find boundary entities
    communities.find_boundary_entities(graph.edge_index, threshold=0.3)
    communities.find_boundary_pairs(graph.edge_index)

    print(f"  Communities (Leiden): {communities.n_communities} discovered "
          f"(modularity={communities.modularity:.4f}, time={t_comm:.2f}s)")
    print(f"  Communities (Spectral): {communities_spectral.n_communities} "
          f"(modularity={communities_spectral.modularity:.4f}, time={t_spec:.2f}s)")
    print(f"  Sizes (Leiden): {communities.community_sizes}")

    # ── Step 3: Quantify (Regime Divergence) ─────────────────
    t0 = time.time()
    rd_computer = RegimeDivergenceComputer(smoothing=1.0)
    rd_map = rd_computer.compute(
        community_structure=communities,
        outcomes=dataset.outcomes,
        edge_index=graph.edge_index,
        edge_weights=graph.edge_weights,
    )
    t_rd = time.time() - t0

    print(f"  Regime Divergence: mean={rd_map.mean_rd:.4f}, "
          f"max={rd_map.max_rd:.4f} (time={t_rd:.3f}s)")

    # ── Pairwise RD table ────────────────────────────────────
    print(f"\n  Pairwise regime divergence:")
    for (ci, cj), rd in sorted(rd_map.pairwise_rd.items()):
        rate_i = rd_map.community_response_rates[ci]
        rate_j = rd_map.community_response_rates[cj]
        print(f"    Comm {ci} ↔ Comm {cj}: RD={rd:.4f}  "
              f"(rates: {rate_i:.3f} vs {rate_j:.3f})")

    # ── Entity-level analysis ────────────────────────────────
    scores = rd_map.entity_rd_scores
    bf = rd_map.entity_boundary_fraction

    # Correlation between entity RD and actual failure
    fail_rd = scores[dataset.outcomes == 1].mean()
    success_rd = scores[dataset.outcomes == 0].mean()

    print(f"\n  Entity RD by outcome:")
    print(f"    Failures:  mean RD = {fail_rd:.4f}")
    print(f"    Successes: mean RD = {success_rd:.4f}")
    print(f"    Δ = {fail_rd - success_rd:+.4f}")

    # Boundary fraction analysis
    fail_bf = bf[dataset.outcomes == 1].mean()
    success_bf = bf[dataset.outcomes == 0].mean()

    print(f"\n  Boundary fraction by outcome:")
    print(f"    Failures:  mean BF = {fail_bf:.4f}")
    print(f"    Successes: mean BF = {success_bf:.4f}")
    print(f"    Δ = {fail_bf - success_bf:+.4f}")

    # ── Geometry classification ──────────────────────────────
    geometry = rd_map.classify_geometry(
        community_labels=communities.labels,
        edge_index=graph.edge_index,
    )
    unique_geom, geom_counts = np.unique(geometry, return_counts=True)
    print(f"\n  Geometry classification:")
    for g, c in zip(unique_geom, geom_counts):
        # What fraction of entities in this geometry are failures?
        g_mask = geometry == g
        g_fail_rate = dataset.outcomes[g_mask].mean()
        print(f"    {g:15s}: {c:5d} entities  "
              f"(failure rate: {g_fail_rate:.1%})")

    # ── Compare discovered vs ground truth ───────────────────
    if hasattr(dataset, 'domain_labels'):
        from sklearn.metrics import adjusted_rand_score
        ari_leiden = adjusted_rand_score(dataset.domain_labels, communities.labels)
        ari_spectral = adjusted_rand_score(dataset.domain_labels, communities_spectral.labels)
        print(f"\n  ARI vs ground truth:  Leiden={ari_leiden:.4f}  Spectral={ari_spectral:.4f}")

    return rd_map, communities


def main():
    print("=" * 60)
    print("TESSERA Workflow Test — Steps 1-3")
    print("Characterize → Discover → Quantify")
    print("=" * 60)

    patterns = ["boundary", "isolated", "diffuse", "mixed"]
    results = {}

    for pattern in patterns:
        rd_map, communities = test_workflow(pattern, n_entities=1000)
        results[pattern] = (rd_map, communities)

    # ── Cross-pattern comparison ─────────────────────────────
    print(f"\n{'=' * 60}")
    print("Cross-Pattern Summary")
    print(f"{'=' * 60}")
    print(f"\n  {'Pattern':<12s} {'Mean RD':>10s} {'Max RD':>10s} "
          f"{'Fail Δ(RD)':>12s} {'Fail Δ(BF)':>12s}")
    print(f"  {'─' * 56}")

    for pattern in patterns:
        rd_map, _ = results[pattern]
        # Recompute deltas
        # (We'd need outcomes again — just display from rd_map)
        print(f"  {pattern:<12s} {rd_map.mean_rd:>10.4f} {rd_map.max_rd:>10.4f}")

    print(f"\n{'=' * 60}")
    print("WORKFLOW TEST COMPLETE")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
