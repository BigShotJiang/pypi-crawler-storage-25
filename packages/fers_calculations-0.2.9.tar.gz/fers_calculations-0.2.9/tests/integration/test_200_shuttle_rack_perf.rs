// test_200_shuttle_rack_perf.rs
// Performance test: real shuttle rack model (config 2445, single combo).
// Uses calculate_from_json_internal_with_tier(Premium) because the model
// has ~1058 members which exceeds Free tier limits.

use fers_calculations::analysis::calculate_from_json_internal_with_tier;
use fers_calculations::limits::LicenseTier;

/// Load the shuttle rack 2445 JSON fixture (single combo 4).
fn load_shuttle_json() -> String {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("shuttle_rack_2445_combo4.json");
    std::fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("Failed to read {}: {e}", path.display()))
}

#[test]
fn test_200_shuttle_rack_combo4_converges() {
    let json = load_shuttle_json();
    let t0 = std::time::Instant::now();
    let result = calculate_from_json_internal_with_tier(&json, LicenseTier::Premium);
    let elapsed = t0.elapsed();

    match &result {
        Ok(res_json) => {
            // Check that we got actual results, not an embedded error
            assert!(
                !res_json.contains("\"error\""),
                "Result JSON contains an error field"
            );
            eprintln!(
                "✅ Shuttle rack combo 4 solved in {:.1}s",
                elapsed.as_secs_f64()
            );
        }
        Err(e) => {
            panic!(
                "❌ Shuttle rack combo 4 FAILED after {:.1}s: {e}",
                elapsed.as_secs_f64()
            );
        }
    }

    // Check timing log was written
    let log_path = "nr_timing.log";
    if let Ok(log) = std::fs::read_to_string(log_path) {
        eprintln!("\n=== NR Timing Log ===\n{log}");
        // Clean up
        let _ = std::fs::remove_file(log_path);
    }
}
