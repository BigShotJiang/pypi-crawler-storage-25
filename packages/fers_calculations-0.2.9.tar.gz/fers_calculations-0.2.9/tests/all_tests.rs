// Single integration test binary — all test modules compiled once.
// This avoids 45+ separate binaries and dramatically speeds up cargo test.

#[path = "test_support/mod.rs"]
mod test_support;

#[path = "integration/test_001.rs"]
mod test_001;
#[path = "integration/test_002.rs"]
mod test_002;
#[path = "integration/test_003.rs"]
mod test_003;
#[path = "integration/test_004.rs"]
mod test_004;
#[path = "integration/test_005.rs"]
mod test_005;
#[path = "integration/test_006.rs"]
mod test_006;
#[path = "integration/test_007.rs"]
mod test_007;
#[path = "integration/test_021.rs"]
mod test_021;
#[path = "integration/test_021b.rs"]
mod test_021b;
#[path = "integration/test_041.rs"]
mod test_041;
#[path = "integration/test_042.rs"]
mod test_042;
#[path = "integration/test_051.rs"]
mod test_051;
#[path = "integration/test_061.rs"]
mod test_061;
#[path = "integration/test_081.rs"]
mod test_081;
#[path = "integration/test_082.rs"]
mod test_082;
#[path = "integration/test_083.rs"]
mod test_083;
#[path = "integration/test_084_skyciv.rs"]
mod test_084_skyciv;
#[path = "integration/test_084.rs"]
mod test_084;
#[path = "integration/test_085.rs"]
mod test_085;
#[path = "integration/test_086.rs"]
mod test_086;
#[path = "integration/test_087.rs"]
mod test_087;
#[path = "integration/test_091.rs"]
mod test_091;
#[path = "integration/test_093.rs"]
mod test_093;
#[path = "integration/test_101.rs"]
mod test_101;
#[path = "integration/test_102.rs"]
mod test_102;
#[path = "integration/test_103.rs"]
mod test_103;
#[path = "integration/test_104.rs"]
mod test_104;
#[path = "integration/test_105.rs"]
mod test_105;
#[path = "integration/test_106.rs"]
mod test_106;
#[path = "integration/test_107.rs"]
mod test_107;
#[path = "integration/test_108.rs"]
mod test_108;
#[path = "integration/test_109.rs"]
mod test_109;
#[path = "integration/test_110.rs"]
mod test_110;
#[path = "integration/test_111.rs"]
mod test_111;
#[path = "integration/test_112.rs"]
mod test_112;
#[path = "integration/test_113.rs"]
mod test_113;
#[path = "integration/test_114.rs"]
mod test_114;
#[path = "integration/test_115.rs"]
mod test_115;
#[path = "integration/test_116.rs"]
mod test_116;
#[path = "integration/test_117.rs"]
mod test_117;
#[path = "integration/test_118.rs"]
mod test_118;
#[path = "integration/test_119.rs"]
mod test_119;
#[path = "integration/test_120.rs"]
mod test_120;
#[path = "integration/test_120f_diag.rs"]
mod test_120f_diag;
#[path = "integration/test_corot.rs"]
mod test_corot;
#[path = "integration/test_skyciv_comparison.rs"]
mod test_skyciv_comparison;
#[path = "integration/test_130_stiffness_curve.rs"]
mod test_130_stiffness_curve;
#[path = "integration/test_131_force_component_curves.rs"]
mod test_131_force_component_curves;
#[path = "integration/test_132_member_hinge_curves.rs"]
mod test_132_member_hinge_curves;
#[path = "integration/test_133_frame_stiffness_curve.rs"]
mod test_133_frame_stiffness_curve;
#[path = "integration/test_200_shuttle_rack_perf.rs"]
mod test_200_shuttle_rack_perf;

// Benchmarks are in a separate file (bench_sparse_vs_dense.rs) with #[ignore]