"""
mcpclient.py — simcpi client
=============================
Standalone LLM + MCP client. Completely independent of mcpserver.py.
Point it at ANY MCP server — yours or someone else's.

Usage:
    import asyncio
    from mcpclient import MCPClient

    client = MCPClient(
        mcp_server="http://localhost:8000/mcp/mcp",
        provider="openai",
        api_key="sk-...",
    )
    result = asyncio.run(client.run("Add 42 and 58"))
    print(result.answer)
    print(result.tools_called)
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from typing import Literal

# ── Dependency check ──────────────────────────────────────────────────────────
_REQUIRED = {
    "fastmcp": "fastmcp>=3.0.0",
}
_missing = []
for _pkg, _spec in _REQUIRED.items():
    try:
        __import__(_pkg)
    except ImportError:
        _missing.append(_spec)
if _missing:
    print("[simcpi] Missing dependencies. Run: pip install " + " ".join(_missing))
    sys.exit(1)
# ─────────────────────────────────────────────────────────────────────────────

from fastmcp import Client as _MCPInternalClient
from fastmcp.client import StreamableHttpTransport


# ─────────────────────────────────────────────────────────────────────────────
# Result types
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ToolCall:
    """A single tool invocation made by the LLM."""
    name:      str    # tool name
    arguments: dict   # arguments the LLM passed
    result:    str    # what the MCP server returned


@dataclass
class MCPResult:
    """
    Returned by MCPClient.run().

    Attributes
    ----------
    answer:       Final text response from the LLM.
    tools_called: Ordered list of every tool the LLM invoked.
    success:      False if an exception occurred.
    error:        Error message if success=False.
    """
    answer:       str
    tools_called: list[ToolCall]
    success:      bool = True
    error:        str | None = None


# ─────────────────────────────────────────────────────────────────────────────
# MCPClient
# ─────────────────────────────────────────────────────────────────────────────

class MCPClient:
    """
    Connects to any MCP server and wires it to an LLM.
    The LLM sees the tools, calls them, and returns a final answer.
    This is what Claude Desktop does internally — packaged as a Python function.

    Parameters
    ----------
    mcp_server:  MCP server URL  e.g. "http://localhost:8000/mcp/mcp"
                 OR a FastMCP instance directly (for in-process use).
    provider:    "openai" or "anthropic"
    api_key:     Your LLM API key.
    model:       Model name. Defaults: gpt-4o / claude-sonnet-4-20250514.
    system:      Optional system prompt for every conversation.
    timeout:     HTTP timeout in seconds (default 30).
    base_url:    Custom LLM endpoint e.g. AICredits, OpenRouter.
    """

    DEFAULTS = {
        "openai":    "gpt-4o",
        "anthropic": "claude-sonnet-4-20250514",
    }

    def __init__(
        self,
        mcp_server: str | object,
        provider:   Literal["openai", "anthropic"],
        api_key:    str,
        model:      str | None = None,
        system:     str | None = None,
        timeout:    int = 30,
        base_url:   str | None = None,
    ):
        self.mcp_server = mcp_server
        self.provider   = provider
        self.api_key    = api_key
        self.model      = model or self.DEFAULTS[provider]
        self.system     = system
        self.timeout    = timeout
        self.base_url   = base_url

    # ── Transport ─────────────────────────────────────────────────────────────

    def _transport(self):
        """
        URL string   → StreamableHttpTransport (real HTTP connection)
        FastMCP obj  → pass directly (in-process, no network needed)
        """
        if isinstance(self.mcp_server, str):
            return StreamableHttpTransport(self.mcp_server)
        return self.mcp_server

    # ── Public API ────────────────────────────────────────────────────────────

    async def list_tools(self) -> list[dict]:
        """Fetch available tools from the MCP server."""
        async with _MCPInternalClient(self._transport()) as client:
            tools = await client.list_tools()
        return [
            {"name": t.name, "description": t.description, "inputSchema": t.inputSchema}
            for t in tools
        ]

    async def run(self, prompt: str, interpret: bool = True) -> MCPResult:
        """
        Send a prompt, call MCP tools, return the result.

        Parameters
        ----------
        prompt:     The user message / question.
        interpret:  True  — LLM calls tools AND explains the result in natural language.
                    False — tools are called, raw tool result returned, no LLM wrap.
                    Default: True.

        Returns
        -------
        MCPResult with .answer, .tools_called, .success, .error
        """
        try:
            tools = await self.list_tools()
            if not interpret:
                return await self._run_direct(prompt, tools)
            if self.provider == "openai":
                return await self._run_openai(prompt, tools)
            else:
                return await self._run_anthropic(prompt, tools)
        except Exception as e:
            return MCPResult(answer="", tools_called=[], success=False, error=str(e))

    # ── Internal ──────────────────────────────────────────────────────────────

    async def _call_tool(self, name: str, arguments: dict) -> str:
        """Execute one tool call on the MCP server and return the result."""
        async with _MCPInternalClient(self._transport()) as client:
            result = await client.call_tool(name, arguments)
        return result.content[0].text if result.content else str(result)

    async def _run_direct(self, prompt: str, mcp_tools: list[dict]) -> MCPResult:
        """
        interpret=False path.
        Ask the LLM to pick a tool and extract arguments only — no final explanation.
        Execute the tool, return the raw result as .answer.
        """
        if self.provider == "openai":
            from openai import AsyncOpenAI
            kw = dict(api_key=self.api_key, timeout=self.timeout)
            if self.base_url:
                kw["base_url"] = self.base_url
            client = AsyncOpenAI(**kw)

            oai_tools = [
                {"type": "function", "function": {
                    "name":        t["name"],
                    "description": t.get("description", ""),
                    "parameters":  t.get("inputSchema", {"type": "object", "properties": {}}),
                }}
                for t in mcp_tools
            ]
            messages: list = []
            if self.system:
                messages.append({"role": "system", "content": self.system})
            messages.append({"role": "user", "content": prompt})

            response = await client.chat.completions.create(
                model=self.model, messages=messages,
                tools=oai_tools, tool_choice="auto",
            )
            msg = response.choices[0].message

        else:  # anthropic
            import anthropic as sdk
            kw = dict(api_key=self.api_key, timeout=self.timeout)
            if self.base_url:
                kw["base_url"] = self.base_url
            client = sdk.AsyncAnthropic(**kw)

            ant_tools = [
                {"name": t["name"], "description": t.get("description", ""),
                 "input_schema": t.get("inputSchema", {"type": "object", "properties": {}})}
                for t in mcp_tools
            ]
            kw2 = dict(model=self.model, max_tokens=256, messages=[{"role": "user", "content": prompt}],
                       tools=ant_tools)
            if self.system:
                kw2["system"] = self.system
            response = await client.messages.create(**kw2)

            # find first tool_use block
            tool_block = next((b for b in response.content if b.type == "tool_use"), None)
            if not tool_block:
                text = " ".join(b.text for b in response.content if b.type == "text")
                return MCPResult(answer=text, tools_called=[], success=True)

            result = await self._call_tool(tool_block.name, tool_block.input)
            return MCPResult(
                answer=result,
                tools_called=[ToolCall(name=tool_block.name, arguments=tool_block.input, result=result)],
            )

        # openai path — check if tool was called
        if not msg.tool_calls:
            return MCPResult(answer=msg.content or "", tools_called=[])

        tc     = msg.tool_calls[0]  # first tool only in direct mode
        args   = json.loads(tc.function.arguments)
        result = await self._call_tool(tc.function.name, args)
        return MCPResult(
            answer=result,
            tools_called=[ToolCall(name=tc.function.name, arguments=args, result=result)],
        )

    async def _run_openai(self, prompt: str, mcp_tools: list[dict]) -> MCPResult:
        from openai import AsyncOpenAI

        kw = dict(api_key=self.api_key, timeout=self.timeout)
        if self.base_url:
            kw["base_url"] = self.base_url
        client = AsyncOpenAI(**kw)

        oai_tools = [
            {"type": "function", "function": {
                "name":        t["name"],
                "description": t.get("description", ""),
                "parameters":  t.get("inputSchema", {"type": "object", "properties": {}}),
            }}
            for t in mcp_tools
        ]

        messages: list = []
        if self.system:
            messages.append({"role": "system", "content": self.system})
        messages.append({"role": "user", "content": prompt})
        tool_calls: list[ToolCall] = []

        while True:
            response = await client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=oai_tools or None,
                tool_choice="auto" if oai_tools else None,
            )
            msg = response.choices[0].message
            messages.append(msg)

            if msg.tool_calls:
                results = []
                for tc in msg.tool_calls:
                    args   = json.loads(tc.function.arguments)
                    result = await self._call_tool(tc.function.name, args)
                    tool_calls.append(ToolCall(name=tc.function.name, arguments=args, result=result))
                    results.append({"tool_call_id": tc.id, "role": "tool", "content": result})
                messages.extend(results)
            else:
                return MCPResult(answer=msg.content or "", tools_called=tool_calls)

    async def _run_anthropic(self, prompt: str, mcp_tools: list[dict]) -> MCPResult:
        import anthropic as sdk

        kw = dict(api_key=self.api_key, timeout=self.timeout)
        if self.base_url:
            kw["base_url"] = self.base_url
        client = sdk.AsyncAnthropic(**kw)

        ant_tools = [
            {"name": t["name"], "description": t.get("description", ""),
             "input_schema": t.get("inputSchema", {"type": "object", "properties": {}})}
            for t in mcp_tools
        ]
        messages: list = [{"role": "user", "content": prompt}]
        tool_calls: list[ToolCall] = []

        while True:
            kw2 = dict(model=self.model, max_tokens=1024, messages=messages)
            if self.system:
                kw2["system"] = self.system
            if ant_tools:
                kw2["tools"] = ant_tools

            response = await client.messages.create(**kw2)
            asst_content, tool_blocks = [], []

            for block in response.content:
                if block.type == "text":
                    asst_content.append({"type": "text", "text": block.text})
                elif block.type == "tool_use":
                    asst_content.append({"type": "tool_use", "id": block.id,
                                         "name": block.name, "input": block.input})
                    tool_blocks.append(block)

            messages.append({"role": "assistant", "content": asst_content})

            if tool_blocks:
                results = []
                for block in tool_blocks:
                    result = await self._call_tool(block.name, block.input)
                    tool_calls.append(ToolCall(name=block.name, arguments=block.input, result=result))
                    results.append({"type": "tool_result", "tool_use_id": block.id, "content": result})
                messages.append({"role": "user", "content": results})
            else:
                final = " ".join(b["text"] for b in asst_content if b.get("type") == "text")
                return MCPResult(
                    answer=tool_calls[-1].result if not final and tool_calls else final,
                    tools_called=tool_calls,
                )