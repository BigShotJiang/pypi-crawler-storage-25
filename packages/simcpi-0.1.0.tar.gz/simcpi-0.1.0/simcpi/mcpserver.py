"""
mcpserver.py — simcpi server
============================
Single @app.create_tool_api() decorator → REST route + MCP tool.

Routes added automatically:
  GET  /docs          Swagger UI
  GET  /mcpark        MCPark — visual explorer + LLM tester
  POST /mcpark/tools  List registered MCP tools (internal)
  POST /mcpark/run    Run LLM+MCP loop (internal)
  POST /mcp/mcp       MCP streamable-http transport
"""

from __future__ import annotations

import json
import inspect
import sys
from inspect import cleandoc
import functools
from contextlib import asynccontextmanager
from typing import Callable, Literal, get_type_hints

# ── Dependency check ──────────────────────────────────────────────────────────
_REQUIRED = {
    "fastapi": "fastapi>=0.100.0",
    "fastmcp": "fastmcp>=3.0.0",
    "pydantic": "pydantic>=2.0.0",
    "uvicorn": "uvicorn>=0.20.0",
}
_missing = []
for _pkg, _spec in _REQUIRED.items():
    try:
        __import__(_pkg)
    except ImportError:
        _missing.append(_spec)
if _missing:
    print("[simcpi] Missing dependencies. Run: pip install " + " ".join(_missing))
    sys.exit(1)
# ─────────────────────────────────────────────────────────────────────────────

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastmcp import FastMCP
from fastmcp import Client as _MCPInternalClient
from fastmcp.client import StreamableHttpTransport
from pydantic import BaseModel
from pathlib import Path



# ─────────────────────────────────────────────────────────────────────────────
# MCPark HTML — served at /mcpark
# ─────────────────────────────────────────────────────────────────────────────

html_path = Path(__file__).parent / "static" / "mcpark.html"

with open(html_path, "r", encoding="utf-8") as f:
    MCPARK_HTML = f.read()


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic models
# ─────────────────────────────────────────────────────────────────────────────

class RunRequest(BaseModel):
    prompt:   str
    api_key:  str | None = None
    provider: Literal["openai", "anthropic"] | None = None
    model:    str = "gpt-4o"
    base_url: str | None = None


# ─────────────────────────────────────────────────────────────────────────────
# MCPApi — the server class
# ─────────────────────────────────────────────────────────────────────────────

class MCPApi:
    """
    Merges FastAPI and FastMCP into a single server.

    Parameters
    ----------
    title:          API / MCP server name.
    mcp_path:       MCP transport prefix (default: "/mcp").
    version:        Version string.
    description:    Shown in OpenAPI docs and MCP server instructions.
    mcpark_path:    Path for MCPark UI (default: "/mcpark"). None to disable.
    provider:       Default LLM provider — "openai" or "anthropic".
    api_key:        Default LLM API key. Inherited by MCPark UI + get_client().
    base_url:       Default LLM base URL (for proxies like AICredits, OpenRouter).
    model:          Default model name. Shown pre-selected in MCPark.
    """

    def __init__(
        self,
        title:        str = "simcpi",
        mcp_path:     str = "/mcp",
        version:      str = "0.1.0",
        description:  str | None = None,
        mcpark_path:  str | None = "/mcpark",
        provider:     Literal["openai", "anthropic"] | None = None,
        api_key:      str | None = None,
        base_url:     str | None = None,
        model:        str | None = None,
    ):
        self.title       = title
        self.mcp_path    = mcp_path.rstrip("/")
        self.mcpark_path = mcpark_path
        self.provider    = provider
        self.api_key     = api_key
        self.base_url    = base_url
        self.model       = model

        # ── FastMCP ──────────────────────────────────────────────────────────
        self.mcp     = FastMCP(name=title, version=version, instructions=description)
        self._mcp_app = self.mcp.http_app()

        # ── FastAPI + wired MCP lifespan ─────────────────────────────────────
        mcp_app = self._mcp_app

        @asynccontextmanager
        async def combined_lifespan(app: FastAPI):
            async with mcp_app.lifespan(mcp_app):
                yield

        self.api = FastAPI(
            title=title,
            version=version,
            description=description or "",
            lifespan=combined_lifespan,
        )

        self.api.mount(self.mcp_path, self._mcp_app)

        # ── Routes ───────────────────────────────────────────────────────────
        self._register_mcpark()

        # ── Registry ─────────────────────────────────────────────────────────
        self._registry: dict[str, Callable] = {}

    # ── MCPark routes ─────────────────────────────────────────────────────────

    def _register_mcpark(self):
        if not self.mcpark_path:
            return

        path = self.mcpark_path

        # Build server config dict — injected into the HTML so UI pre-fills
        def _server_config(self=self) -> dict:
            return {
                "provider": self.provider or "openai",
                "has_server_key": bool(self.api_key),
                "base_url": self.base_url,
                "model":    self.model or "gpt-4o",
                "mcp_path": self.mcp_path,
            }

        @self.api.get(path, response_class=HTMLResponse, include_in_schema=False)
        async def mcpark_ui():
            import json as _json
            config_json = _json.dumps(_server_config())
            html = MCPARK_HTML.replace("__SERVER_CONFIG__", config_json)
            return HTMLResponse(html)

        @self.api.post(f"{path}/tools", include_in_schema=False)
        async def mcpark_tools():
            async with _MCPInternalClient(self.mcp) as client:
                tools = await client.list_tools()
            return JSONResponse({
                "tools": [
                    {"name": t.name, "description": t.description, "inputSchema": t.inputSchema}
                    for t in tools
                ]
            })

        @self.api.post(f"{path}/run", include_in_schema=False)
        async def mcpark_run(req: RunRequest, request: Request):
            # Resolve — request body wins, instance defaults as fallback
            resolved_provider = req.provider or self.provider
            resolved_api_key  = req.api_key  or self.api_key
            resolved_base_url = req.base_url or self.base_url
            resolved_model    = req.model    or self.model or "gpt-4o"

            if not resolved_provider or not resolved_api_key:
                return JSONResponse({
                    "error": "provider and api_key are required — set on MCPApi() or pass in the UI",
                    "trace": [], "tools_called": False
                })

            base    = str(request.base_url).rstrip("/")
            mcp_url = f"{base}{self.mcp_path}/mcp"

            # Fetch tools via real HTTP transport
            transport = StreamableHttpTransport(mcp_url)
            async with _MCPInternalClient(transport) as client:
                raw_tools = await client.list_tools()

            mcp_tools = [
                {"name": t.name, "description": t.description, "inputSchema": t.inputSchema}
                for t in raw_tools
            ]

            trace:        list[dict] = []
            tools_called: bool      = False

            try:
                if resolved_provider == "openai":
                    from openai import AsyncOpenAI
                    kw = dict(api_key=resolved_api_key)
                    if resolved_base_url:
                        kw["base_url"] = resolved_base_url
                    oai = AsyncOpenAI(**kw)

                    oai_tools = [
                        {"type": "function", "function": {
                            "name":        t["name"],
                            "description": t.get("description", ""),
                            "parameters":  t.get("inputSchema", {"type": "object", "properties": {}}),
                        }}
                        for t in mcp_tools
                    ]
                    messages = [{"role": "user", "content": req.prompt}]

                    while True:
                        resp = await oai.chat.completions.create(
                            model=resolved_model, messages=messages,
                            tools=oai_tools, tool_choice="auto",
                        )
                        msg = resp.choices[0].message
                        messages.append(msg)

                        if msg.tool_calls:
                            tools_called = True
                            results = []
                            for tc in msg.tool_calls:
                                import json as _j
                                args = _j.loads(tc.function.arguments)
                                trace.append({"type": "tool_call", "name": tc.function.name, "arguments": args})
                                async with _MCPInternalClient(StreamableHttpTransport(mcp_url)) as c:
                                    r = await c.call_tool(tc.function.name, args)
                                txt = r.content[0].text if r.content else str(r)
                                trace.append({"type": "tool_result", "name": tc.function.name, "result": txt})
                                results.append({"tool_call_id": tc.id, "role": "tool", "content": txt})
                            messages.extend(results)
                        else:
                            if msg.content:
                                trace.append({"type": "message", "content": msg.content})
                            break

                else:  # anthropic
                    import anthropic as _sdk
                    kw = dict(api_key=resolved_api_key)
                    if resolved_base_url:
                        kw["base_url"] = resolved_base_url
                    ant = _sdk.AsyncAnthropic(**kw)

                    ant_tools = [
                        {"name": t["name"], "description": t.get("description", ""),
                         "input_schema": t.get("inputSchema", {"type": "object", "properties": {}})}
                        for t in mcp_tools
                    ]
                    messages = [{"role": "user", "content": req.prompt}]

                    while True:
                        resp = await ant.messages.create(
                            model=resolved_model, max_tokens=1024,
                            tools=ant_tools, messages=messages,
                        )
                        asst_content, tool_blocks = [], []
                        for block in resp.content:
                            if block.type == "text":
                                asst_content.append({"type": "text", "text": block.text})
                                if block.text:
                                    trace.append({"type": "message", "content": block.text})
                            elif block.type == "tool_use":
                                tools_called = True
                                asst_content.append({"type": "tool_use", "id": block.id,
                                                     "name": block.name, "input": block.input})
                                trace.append({"type": "tool_call", "name": block.name, "arguments": block.input})
                                tool_blocks.append(block)

                        messages.append({"role": "assistant", "content": asst_content})

                        if tool_blocks:
                            results = []
                            for block in tool_blocks:
                                async with _MCPInternalClient(StreamableHttpTransport(mcp_url)) as c:
                                    r = await c.call_tool(block.name, block.input)
                                txt = r.content[0].text if r.content else str(r)
                                trace.append({"type": "tool_result", "name": block.name, "result": txt})
                                results.append({"type": "tool_result", "tool_use_id": block.id, "content": txt})
                            messages.append({"role": "user", "content": results})
                        else:
                            break

            except Exception as e:
                return JSONResponse({"error": str(e), "trace": trace, "tools_called": tools_called})

            return JSONResponse({"trace": trace, "tools_called": tools_called})

    # ── @create_tool_api decorator ────────────────────────────────────────────

    def create_tool_api(
        self,
        path: str,
        *,
        method:    Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "POST",
        tool_name: str | None = None,
        tags:      list[str] | None = None,
        summary:   str | None = None,
    ) -> Callable:
        """
        Register a function as both a FastAPI REST endpoint and a FastMCP tool.

        The function's docstring becomes the MCP tool description —
        write it for the LLM, not just for humans.

        Usage:
            @app.create_tool_api("/add", method="POST")
            def add(a: int, b: int) -> int:
                \"\"\"
                Add two numbers.
                Use this when the user asks to sum or total numbers.
                \"\"\"
                return a + b
        """
        def decorator(fn: Callable) -> Callable:
            name = tool_name or fn.__name__
            doc  = cleandoc(fn.__doc__) if fn.__doc__ else ""

            # 1. FastMCP tool
            self.mcp.tool(name=name, description=doc)(fn)

            # 2. FastAPI route
            @functools.wraps(fn)
            async def route_handler(*args, **kwargs):
                if inspect.iscoroutinefunction(fn):
                    return await fn(*args, **kwargs)
                return fn(*args, **kwargs)

            route_handler.__annotations__ = get_type_hints(fn)
            route_handler.__doc__ = doc

            getattr(self.api, method.lower())(
                path, summary=summary or name,
                description=doc, tags=tags, name=name,
            )(route_handler)

            self._registry[name] = fn
            return fn

        return decorator

    # ── ASGI passthrough ──────────────────────────────────────────────────────

    async def __call__(self, scope, receive, send):
        await self.api(scope, receive, send)

    # ── get_client — returns a wired MCPClient ────────────────────────────────

    def get_client(
        self,
        provider: Literal["openai", "anthropic"] | None = None,
        api_key:  str | None = None,
        model:    str | None = None,
        system:   str | None = None,
        timeout:  int = 30,
        base_url: str | None = None,
    ) -> "MCPClient":
        """
        Return an MCPClient pre-wired to this server's MCP instance (in-process).

        Falls back to provider/api_key/base_url/model set on MCPApi().

        Usage:
            app = MCPApi(provider="openai", api_key="sk-...")
            client = app.get_client()
            result = await client.run("Add 42 and 58")
        """
        from .mcpclient import MCPClient

        resolved_provider = provider or self.provider
        resolved_api_key  = api_key  or self.api_key
        resolved_base_url = base_url or self.base_url
        resolved_model    = model    or self.model

        if not resolved_provider:
            raise ValueError("provider required — set on MCPApi() or pass to get_client()")
        if not resolved_api_key:
            raise ValueError("api_key required — set on MCPApi() or pass to get_client()")

        return MCPClient(
            mcp_server=self.mcp,
            provider=resolved_provider,
            api_key=resolved_api_key,
            model=resolved_model,
            system=system,
            timeout=timeout,
            base_url=resolved_base_url,
        )

    def list_tools(self) -> list[str]:
        """Return names of all registered tools."""
        return list(self._registry.keys())