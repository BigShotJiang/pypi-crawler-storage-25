\# simcpi ⚡



`simcpi` is an experimental framework that intends to make working with MCP significantly easier.



The project currently focuses on reducing the friction between:

\- APIs

\- MCP tools

\- LLM orchestration

\- frontend integrations



\---



\# Current Goals



`simcpi` currently intends to fulfill 3 major goals:



\## 1. Unified API + MCP Tool Creation



Define both:

\- REST APIs

\- MCP tools



using a single decorator and a single function.



```python

@app.create\_tool\_api("/add")

def add(a: int, b: int) -> int:

&#x20;   return a + b



This automatically creates:



FastAPI route

Swagger documentation

MCP tool registration



without requiring duplicate definitions.



2\. Swagger-Style MCP Interface (MCPark)



simcpi includes MCPark, a visual interface inspired by Swagger UI.



It allows you to:



inspect MCP tools

test tool calls

interact with LLMs

view execution traces

debug MCP workflows visually



The goal is to make MCP servers easier to explore and test during development.



3\. Simplified LLM + MCP Client Integration



simcpi also provides a lightweight MCP client abstraction that combines:



LLM orchestration

MCP transport handling

tool execution



into a simple interface.



result = await client.run("Add 42 and 58")



The intention is to make integrating MCP into applications and frontends much simpler.



Experimental Warning ⚠️



This project is currently highly experimental and under active development.



Things may change rapidly, including:



APIs

architecture

transport handling

orchestration logic

interfaces



Please be careful when using this in:



production systems

public deployments

security-sensitive environments



At the moment, the framework is mainly intended for:



experimentation

prototyping

local development

learning MCP workflows

rapid iteration

Installation

pip install simcpi

Quick Example

from simcpi import MCPApi

import uvicorn

import os



app = MCPApi(

&#x20;   provider="openai",

&#x20;   api\_key=os.getenv("AI\_API\_KEY"),

&#x20;   base\_url="https://api.aicredits.in/v1"

)



@app.create\_tool\_api("/greet-hindi")

def greet\_hindi(name: str) -> str:

&#x20;   """

&#x20;   Greet the user in Hindi.

&#x20;   """



&#x20;   return f"नमस्ते {name}! आपका स्वागत है 🚀"





@app.create\_tool\_api("/greet-telugu")

def greet\_telugu(name: str) -> str:

&#x20;   """

&#x20;   Greet the user in Telugu.

&#x20;   """



&#x20;   return f"నమస్కారం {name}! మీకు స్వాగతం 🚀"





if \_\_name\_\_ == "\_\_main\_\_":

&#x20;   uvicorn.run(app, host="127.0.0.1", port=8000)

Interfaces



Once running:



Interface	URL

Swagger UI	/docs

MCPark	/mcpark

MCP Endpoint	/mcp/mcp

Future Plans



The project will continue evolving with additional features and improvements moving forward.

