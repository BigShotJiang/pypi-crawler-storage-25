#!/usr/bin/env python3
"""
Setup script for DOCX to Markdown Converter package.
"""

from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip()
                    and not line.startswith("#")]

setup(
    name="word2md",
    version="1.0.3",
    author="hnrobert",
    description="A Python tool for converting Microsoft Word documents (.docx/.doc) to Markdown format",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hnrobert/word2md",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Markup",
        "Topic :: Utilities",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "word2md=docx_converter.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
