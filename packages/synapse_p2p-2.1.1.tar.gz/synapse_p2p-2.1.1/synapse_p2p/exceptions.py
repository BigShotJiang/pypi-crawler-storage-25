class InvalidMessageError(Exception):
    pass
