"""Tests for `Agent` / `SubAgent` pure-data invariants.

Provider-specific options assembly used to live here; it moved to
`packages/zeno-provider-claude/tests/test_agent_options.py` when the
Claude SDK translation moved out of core in 1.0.0rc2.
"""

from __future__ import annotations

import pytest
from zeno.agent import Agent, SubAgent
from zeno.exceptions import ZenoError


def test_agent_duplicate_sub_agent_names_rejected() -> None:
    sa_a = SubAgent(name="dup", instructions="a")
    sa_b = SubAgent(name="dup", instructions="b")

    with pytest.raises(ZenoError, match="duplicate sub-agent names"):
        Agent(name="root", instructions="i", sub_agents=[sa_a, sa_b])
