"""Observability primitives — tracer, event types, failure policies.

The SDK hook bridge (`build_hooks`) used to live here; it moved to
`zeno-provider-claude` in 1.0.0rc2 since hook-loop wiring is
Claude-Agent-SDK-specific. Import it from
``zeno.providers.claude_sdk._hooks`` if you need it directly.
"""

from __future__ import annotations

from zeno.observability.events import (
    InboundMessage,
    MemoryRead,
    MemoryWrite,
    OutboundConfirmed,
    OutboundDispatched,
    SchedulerFireConsumed,
    SchedulerFireErrored,
    SchedulerFireQueued,
    SendFailed,
    SubAgentCompleted,
    SubAgentStarted,
    ToolCallCompleted,
    ToolCallStarted,
    TraceEvent,
    TriggerCancelled,
    TriggerDropped,
    TurnCompleted,
    TurnFailed,
    TurnStarted,
    event_payload,
)
from zeno.observability.tracer import BackgroundDispatcher, NoOpTracer, StdoutTracer, Tracer

__all__ = [
    # Event types
    "InboundMessage",
    "MemoryRead",
    "MemoryWrite",
    "OutboundConfirmed",
    "OutboundDispatched",
    "SchedulerFireConsumed",
    "SchedulerFireErrored",
    "SchedulerFireQueued",
    "SendFailed",
    "SubAgentCompleted",
    "SubAgentStarted",
    "ToolCallCompleted",
    "ToolCallStarted",
    "TraceEvent",
    "TriggerCancelled",
    "TriggerDropped",
    "TurnCompleted",
    "TurnFailed",
    "TurnStarted",
    # Event helpers
    "event_payload",
    # Tracers
    "BackgroundDispatcher",
    "NoOpTracer",
    "StdoutTracer",
    "Tracer",
]
