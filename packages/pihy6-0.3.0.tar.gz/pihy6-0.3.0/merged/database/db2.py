# import pymysql 
# from pymysql import MySQLError

# def db_connect():
#     try:
#         return pymysql.connect(
#             host='localhost', user='root', password='qwerty',
#             database='kvalik',
#             cursorClass=pymysql.cursors.DictCursor,
#             autocommit=True
#         )
#     except MySQLError as e:
#         print('ошибка подключения к бд:', e)

# def check_login(username, password):
#     db = db_connect()
#     try:
#             with db.cursor() as cur:
#                     cur.execute("""
# SELECT
# 	u.user_id,
#     r.name as role,
#     u.fullname as name
# from users u
# join roles r on r.role_id = u.role_id
# where u.username = %s and u.password = %s
# """(username, password))
#                     return cur.fetchone()
#     finally: 
#          db.close

import pymysql
from pymysql import MySQLError

def db_connect():
    try:
        return pymysql.connect(
            host='localhost', user='root', password='qwerty',
            database='kvalik',
            cursorclass = pymysql.cursors.DictCursor,
            autocommit=True
        )
    except MySQLError as e:
        print('ошибка подключения к бд:', e)

def check_login(username, password):
    db = db_connect()
    try:
        with db.cursor() as cur:
            cur.execute("""
SELECT 
u.user_id,
r.name as role,
u.fullname as name
from users u
join roles r on r.role_id = u.user_id
where u.username = %s and u.password = %s
""",(username, password))
            return cur.fetchone()
    finally:
        db.close

def all_menu_items():
    db = db_connect()
    try:
        with db.cursor() as cur:
            cur.execute("""
SELECT 
i.item_id,
i.item_name as name,
i.item_price as prise,
i.description,
i.image,
i.category
from items i
""")
            return cur.fetchall()
    finally:
        db.close

def one_menu_items(item_id):
    db = db_connect()
    try:
        with db.cursor() as cur:
            cur.execute("""
SELECT 
i.item_id,
i.item_name as name,
i.item_price as prise,
i.description,
i.image,
i.category
from items i
where i.item_id = %s
""",(item_id))
            return cur.fetchone()
    finally:
        db.close

def all_orders_by_client(user_id):
    db = db_connect()
    try:
        with db.cursor() as cur:
            cur.execute("""
SELECT 
i.item_id,
o.order_id,
o.order_place, 
o.status,
o.order_date,
o.quantity,
o.total_amount
from orders o
join items i on i.item_id = o.item_id
where o.user_id = %s
""",(user_id,))
            return cur.fetchall()
    finally:
        db.close

def add_item(user_id, item_id,order_place, status,order_date,quantity,total_amount):
    db = db_connect()
    try:
        with db.cursor() as cur:
            cur.execute("""
INSERT INTO orders
(user_id,item_id, order_place,status, order_date,quantity,total_amount)
VALUES
(%s,%s,%s,'в обработке',%s,%s,%s)
""",(user_id, item_id,order_place, status,order_date,quantity,total_amount))
            return True
    except Exception as e:
        print('ошибка', e)
        return False
    finally:
        db.close