import pymysql
from pymysql import MySQLError


def db_connect():
    try:
        return pymysql.connect(
            host='localhost',
            user='root',
            password='qwerty',
            database='kvalik',
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True
        )
    except MySQLError as e:
        print('Ошибка подключения', e)
        return None


# ---------- авторизация ----------

def check_login(username, password):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
SELECT
    users.user_id,
    users.fullname AS full_name,
    roles.name AS role
FROM users
JOIN roles ON roles.role_id = users.role_id
WHERE users.username = %s AND users.password = %s
""", (username, password))
            return cursor.fetchone()
    finally:
        db.close()


# ---------- товары ----------

def all_menu_items():
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
SELECT
    item_id,
    item_name AS name,
    item_price AS price,
    description,
    image,
    category,
    discount
FROM items
""")
            return cursor.fetchall()
    finally:
        db.close()


def one_menu_items(item_id):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
SELECT
    item_id,
    item_name AS name,
    item_price AS price,
    description,
    image,
    category
FROM items
WHERE item_id = %s
""", (item_id,))
            return cursor.fetchone()
    finally:
        db.close()


def add_menu_item(name, category, description, price):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
INSERT INTO items (item_name, category, description, item_price)
VALUES (%s, %s, %s, %s)
""", (name, category, description, price))
            return True
    except Exception as e:
        print('Ошибка добавления товара', e)
        return False
    finally:
        db.close()


def edit_menu_item(item_id, name, category, description, price):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
UPDATE items SET
    item_name   = %s,
    category    = %s,
    description = %s,
    item_price  = %s
WHERE item_id = %s
""", (name, category, description, price, item_id))
            return True
    except Exception as e:
        print('Ошибка изменения товара', e)
        return False
    finally:
        db.close()


def delete_menu_item(item_id):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute(
                "SELECT COUNT(*) FROM orders WHERE item_id = %s", (item_id,))
            result = cursor.fetchone()
            if list(result.values())[0]:
                return False, 'Товар есть в заказах — удалить нельзя.'
            cursor.execute("DELETE FROM items WHERE item_id = %s", (item_id,))
            return True, ''
    except Exception as e:
        print('Ошибка удаления товара', e)
        return False, str(e)
    finally:
        db.close()


# ---------- заказы ----------

def all_orders():
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
SELECT
    orders.order_id,
    orders.order_place,
    orders.status,
    orders.order_date,
    orders.total_amount,
    users.fullname AS full_name,
    items.item_name
FROM orders
LEFT JOIN users ON users.user_id = orders.user_id
LEFT JOIN items ON items.item_id = orders.item_id
ORDER BY orders.order_id DESC
""")
            return cursor.fetchall()
    finally:
        db.close()


def all_orders_by_client(user_id):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
SELECT
    orders.order_id,
    orders.order_place,
    orders.status,
    orders.order_date,
    orders.total_amount,
    items.item_name AS name
FROM orders
JOIN items ON items.item_id = orders.item_id
WHERE orders.user_id = %s
ORDER BY orders.order_id DESC
""", (user_id,))
            return cursor.fetchall()
    finally:
        db.close()


def one_order(order_id):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM orders WHERE order_id = %s", (order_id,))
            return cursor.fetchone()
    finally:
        db.close()


def add_order(order_place, status, order_date):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
INSERT INTO orders (order_place, status, order_date)
VALUES (%s, %s, %s)
""", (order_place, status, order_date))
            return True
    except Exception as e:
        print('Ошибка добавления заказа', e)
        return False
    finally:
        db.close()


def edit_order(order_id, order_place, status, order_date):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
UPDATE orders SET
    order_place = %s,
    status      = %s,
    order_date  = %s
WHERE order_id = %s
""", (order_place, status, order_date, order_id))
            return True
    except Exception as e:
        print('Ошибка изменения заказа', e)
        return False
    finally:
        db.close()


def delete_order(order_id):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute(
                "DELETE FROM orders WHERE order_id = %s", (order_id,))
            return True
    except Exception as e:
        print('Ошибка удаления заказа', e)
        return False
    finally:
        db.close()


# ---------- совместимость со старым order_add.py ----------

def add_item(user_id, item_id, order_place, order_date, quantity, total_amount):
    db = db_connect()
    try:
        with db.cursor() as cursor:
            cursor.execute("""
INSERT INTO orders
    (user_id, item_id, order_place, status, order_date, quantity, total_amount)
VALUES (%s, %s, %s, 'в обработке', %s, %s, %s)
""", (user_id, item_id, order_place, order_date, quantity, total_amount))
            return True
    except Exception as e:
        print('Ошибка добавления заказа', e)
        return False
    finally:
        db.close()
