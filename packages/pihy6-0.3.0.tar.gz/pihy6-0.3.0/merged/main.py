# import sys
# from PyQt6.QtWidgets import QApplication
# from auth.auth import login_window

# app = QApplication(sys.argv)
# win = login_window()
# win.show()
# sys.exit(app.exec())

import sys
from PyQt6.QtWidgets import QApplication
from auth.auth import login_window

app = QApplication(sys.argv)
app.setStyleSheet("""
        QMainWindow, QDialog { background-color: #4caf50; }
        QPushButton { background-color: #1565c0; color: white; border: none; padding: 5px 14px; }
    """)
win = login_window()
win.show()
sys.exit(app.exec())