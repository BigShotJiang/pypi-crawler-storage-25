# from PyQt6.QtWidgets import QDialog, QMessageBox
# from PyQt6.QtCore import QDate
# from ui.order_form import Ui_OrderFormDialog
# from database.db import one_order, add_order, edit_order

# STATUSES = ['в обработке', 'в доставке', 'доставлен']


# class OrderFormDialog(QDialog, Ui_OrderFormDialog):
#     def __init__(self, order_id=None):
#         super().__init__()
#         self.setupUi(self)
#         self.order_id = order_id

#         self.setWindowTitle('Добавить заказ' if order_id is None else 'Редактировать заказ')
#         self.comboBoxStatus.addItems(STATUSES)
#         self.dateEditDate.setDate(QDate.currentDate())
#         self.pushButtonSave.clicked.connect(self.save_data)
#         self.pushButtonCancel.clicked.connect(self.reject)

#         if order_id:
#             self.load_order_data()

#     def load_order_data(self):
#         order = one_order(self.order_id)
#         if not order:
#             QMessageBox.warning(self, 'Ошибка', 'Заказ не найден.')
#             self.reject()
#             return
        
#         self.lineEditPlace.setText(str(order.get('order_place') or ''))
#         idx = self.comboBoxStatus.findText(order.get('status') or '')
#         if idx >= 0:
#             self.comboBoxStatus.setCurrentIndex(idx)
#         if od := order.get('order_date'):
#             self.dateEditDate.setDate(QDate(od.year, od.month, od.day))

#     def save_data(self):
#         place  = self.lineEditPlace.text().strip()
#         status = self.comboBoxStatus.currentText()
#         date   = self.dateEditDate.date().toPyDate()

#         if not place:
#             QMessageBox.warning(self, 'Ошибка', 'Введите адрес выдачи.')
#             return

#         ok = edit_order(self.order_id, place, status, date) if self.order_id else add_order(place, status, date)
#         if ok:
#             self.accept()
#         else:
#             QMessageBox.warning(self, 'Ошибка', 'Не удалось сохранить заказ.')
