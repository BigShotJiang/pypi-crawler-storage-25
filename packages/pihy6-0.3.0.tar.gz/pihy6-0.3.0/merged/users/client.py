from pathlib import Path
from PyQt6.QtWidgets import QMainWindow, QMessageBox, QWidget, QVBoxLayout, QTableWidgetItem
from ui.client_win import Ui_client_window
from database.db import all_menu_items, all_orders_by_client, one_menu_items
from users.card import card


class client_window(QMainWindow, Ui_client_window):
    def __init__(self, user_name, user_id):
         super().__init__()
         self.setupUi(self)
         self.user_id = user_id
         self.user_name = user_name
         self.images_dir = Path(__file__).resolve().parent.parent / 'resourses' / 'images'
         self.items = []

         self.tableWidget.setColumnCount(5)
         self.tableWidget.setHorizontalHeaderLabels([
             'название', 'адрес', 'дата доставки', 'сумма', 'статус'
         ])

         self.pushButton_back_t_log_in.clicked.connect(self.exit_login)
         self.pushButton_refresh.clicked.connect(self.load_menu)
         self.pushButtonOrder.clicked.connect(self.orders)

         self.label__guest_name.setText(user_name)

         self.card_widget = QWidget()
         self.layout_card = QVBoxLayout(self.card_widget)
         self.scrollArea_2.setWidget(self.card_widget)

         self.load_menu()
         self.load_orders()

    def load_menu(self):
       while self.layout_card.count():
           self.layout_card.takeAt(0).widget().deleteLater()
       self.items = all_menu_items()
       for item in self.items:
            cards = card(item,self.images_dir)
            cards.clicked.connect(self.show_item_info)
            self.layout_card.addWidget(cards)
       self.statusbar.showMessage(f'Загружено позиций: {len(self.items)}')      

    def show_item_info(self, item_id):
        item = one_menu_items(item_id)

        text= (
            f"Название: {item['name']}\n"
            f"Категория: {item['category']}\n"
            f"Цена: {float(item['price']):.2f} P\n\n" 
            f"Описание: \n{item['description'] or 'Нет описания'}"
        )
        QMessageBox.information(self,item.get('name'),text)

    def load_orders(self):
        user = self.user_id
        orders = all_orders_by_client(user)
        self.tableWidget.setRowCount(len(orders))
        sum = 0

        for r, row in enumerate(orders):
            self.tableWidget.setItem(r, 0, QTableWidgetItem(str(row['name'])))
            self.tableWidget.setItem(r, 1, QTableWidgetItem(str(row['order_place'])))
            self.tableWidget.setItem(r, 2, QTableWidgetItem(str(row['order_date'])))
            self.tableWidget.setItem(r, 3, QTableWidgetItem(str(row['total_amount'])))
            self.tableWidget.setItem(r, 4, QTableWidgetItem(str(row['status'])))
            sum += int(row['total_amount'])

            self.labelprise_of_all.setText(str(sum))
            self.labelquantity_orders.setText(str(len(orders)))

    def orders(self):
        from dialogs.order_add import order_item
        dialog = order_item(self.user_id)
        if dialog.exec():
            self.load_orders()

    def exit_login(self):
         from auth.auth import login_window
         self.win = login_window()
         self.win.show()
         self.close()