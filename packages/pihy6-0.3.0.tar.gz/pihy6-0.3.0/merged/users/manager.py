from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem
from ui.manager_win import Ui_manager_window
from database.db import all_menu_items, all_orders


class manager_window(QMainWindow, Ui_manager_window):
    def __init__(self, user_name, user_id):
         super().__init__()
         self.setupUi(self)
         self.user_id    = user_id
         self.all_items  = []
         self.sort_order = None

         self.labelCurrentUser.setText(user_name or 'Менеджер')

         self.pushButtonLogout.clicked.connect(self.back_to_login)
         self.comboBoxFilter.currentIndexChanged.connect(self.apply_filter)
         self.pushButtonSortAsc.clicked.connect(self.sort_asc)
         self.pushButtonSortDesc.clicked.connect(self.sort_desc)

         self.load_menu()
         self.load_orders()

     # ---------- товары ----------

    def load_menu(self):
         self.all_items = all_menu_items()
         self.load_filter()
         self.statusbar.showMessage(f'Загружено товаров: {len(self.all_items)}')

    def load_filter(self):
        self.comboBoxFilter.blockSignals(True)
        self.comboBoxFilter.clear()
        self.comboBoxFilter.addItem('Все', None)
        for item in self.all_items:
            self.comboBoxFilter.addItem(f"{item['item_id']} — {item.get('name', '')}", item['item_id'])
        self.comboBoxFilter.blockSignals(False)
        self.apply_filter()

    def apply_filter(self):
        selected_id = self.comboBoxFilter.currentData()

        items = []
        for item in self.all_items:
            if selected_id is None or item['item_id'] == selected_id:
                items.append(item)

        reverse = self.sort_order == 'desc'
        if self.sort_order in ('asc', 'desc'):
            items.sort(key=lambda item: float(item.get('price') or 0), reverse=reverse)

        self.populate_table(items)

    def populate_table(self, data):
        self.tableWidgetProducts.setRowCount(len(data))
        self.tableWidgetProducts.setColumnCount(4)
        self.tableWidgetProducts.setHorizontalHeaderLabels(
            ['ID', 'Название', 'Категория', 'Цена'])

        for row, item in enumerate(data):
            self.tableWidgetProducts.setItem(row, 0, QTableWidgetItem(str(item.get('item_id', ''))))
            self.tableWidgetProducts.setItem(row, 1, QTableWidgetItem(item.get('name') or ''))
            self.tableWidgetProducts.setItem(row, 2, QTableWidgetItem(item.get('category') or ''))
            self.tableWidgetProducts.setItem(row, 3, QTableWidgetItem(str(item.get('price') or '')))

        self.tableWidgetProducts.resizeColumnsToContents()

    def sort_asc(self):
        self.sort_order = 'asc'
        self.apply_filter()

    def sort_desc(self):
        self.sort_order = 'desc'
        self.apply_filter()

    # ---------- заказы ----------

    def load_orders(self):
        data = all_orders()
        self.populate_orders_table(data)

    def populate_orders_table(self, data):
        self.tableWidgetOrders.setRowCount(len(data))
        self.tableWidgetOrders.setColumnCount(6)
        self.tableWidgetOrders.setHorizontalHeaderLabels(
            ['ID', 'Клиент', 'Товар', 'Адрес', 'Статус', 'Дата'])

        for row, o in enumerate(data):
            self.tableWidgetOrders.setItem(row, 0, QTableWidgetItem(str(o.get('order_id', ''))))
            self.tableWidgetOrders.setItem(row, 1, QTableWidgetItem(o.get('full_name') or ''))
            self.tableWidgetOrders.setItem(row, 2, QTableWidgetItem(o.get('item_name') or ''))
            self.tableWidgetOrders.setItem(row, 3, QTableWidgetItem(o.get('order_place') or ''))
            self.tableWidgetOrders.setItem(row, 4, QTableWidgetItem(o.get('status') or ''))
            self.tableWidgetOrders.setItem(row, 5, QTableWidgetItem(str(o.get('order_date') or '')))

        self.tableWidgetOrders.resizeColumnsToContents()

    # ---------- навигация ----------

    def back_to_login(self):
        from auth.auth import login_window
        self.win = login_window()
        self.win.show()
        self.close()