from pathlib import Path
from PyQt6.QtWidgets import QFrame, QLabel, QHBoxLayout
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap

class card(QLabel):
    clicked = pyqtSignal(int)
    def __init__(self, item, path_dir):
        super().__init__()

        self.item_id = item.get('item_id')
        self.setFixedHeight(170)
        self.setFrameShape(QFrame.Shape.Box)
        
        label_image = QLabel()
        layout = QHBoxLayout(self)
        label_image.setFixedSize(170, 170)
        label_image.setFrameShape(QFrame.Shape.Box)
        label_image.setScaledContents(True)

        image_name = item.get('image')
        image_path = Path(path_dir) / image_name if image_name else None

        if image_path:
            label_image.setPixmap(QPixmap(str(image_path)))
        else:
            label_image.setText('нет фото')

        
        name = item.get('name', '')
        description = item.get('description', '') or 'нет описания'
        category = item.get('category', '')
        prise = float(item.get('price', '') or 0)
        discount = float(item.get('discount', '') or 0)

        if discount > 0:
            new_price = prise - prise * discount / 100
            price_text = (
                f"цена: <span style='color:red; text-decoration:line-through;'>"
                f"{prise:.2f} руб.</span>"
                f"<span style='color:black';> {new_price:.2f} руб.</span>"
            )
            discount_text = f"скидка: {discount:g}%"
        else:
            price_text = f"цена: <b>{prise:.2f} руб.</b>"
            discount_text = f"скидки\nнет"

        label_info = QLabel()
        label_info.setTextFormat(Qt.TextFormat.RichText)
        label_info.setText(
            f"{name}<br>"
            f"{description}<br>"
            f"{category}<br>"
            f"{price_text}"
        )
        label_info.setWordWrap(True)

        label_discount = QLabel(discount_text)
        label_discount.setFixedSize(60,60)
        label_discount.setFrameShape(QFrame.Shape.Box)
        label_discount.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(label_image)
        layout.addWidget(label_info)
        layout.addWidget(label_discount)

        if discount >= 20:
            self.setStyleSheet('background-color: #2E8B57;')

    def mousePressEvent(self, event):
        self.clicked.emit(self.item_id)
        return super().mousePressEvent(event)