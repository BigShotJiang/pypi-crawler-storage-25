# from PyQt6.QtWidgets import QMainWindow, QMessageBox

# from ui.admin_win import Ui_admin_window
# from database.db import all_menu_items, all_orders, delete_menu_item, delete_order
# from users.manager import manager_window


# class admin_window(QMainWindow, Ui_admin_window):
#     edit_open = False  # запрет двух окон редактирования

#     def __init__(self, user_name, user_id):
#         super().__init__()
#         self.setupUi(self)
#         self.user_id    = user_id
#         self.all_items  = []
#         self.sort_order = None

#         self.labelCurrentUser.setText(user_name or 'Администратор')

#         self.pushButtonLogout.clicked.connect(self.back_to_login)
#         self.comboBoxFilter.currentIndexChanged.connect(self.apply_filter)
#         self.pushButtonSortAsc.clicked.connect(self.sort_asc)
#         self.pushButtonSortDesc.clicked.connect(self.sort_desc)

#         self.pushButtonAddProduct.clicked.connect(self.add_item_dialog)
#         self.pushButtonDeleteProduct.clicked.connect(self.delete_item_dialog)
#         self.tableWidgetProducts.cellClicked.connect(self.edit_item_dialog)

#         self.pushButtonAddOrder.clicked.connect(self.add_order_dialog)
#         self.pushButtonDeleteOrder.clicked.connect(self.delete_order_dialog)
#         self.tableWidgetOrders.cellDoubleClicked.connect(self.edit_order_dialog)

#         self.load_menu()
#         self.load_orders()

#     # переиспользуем методы менеджера
#     load_menu             = manager_window.load_menu
#     load_filter           = manager_window.load_filter
#     apply_filter          = manager_window.apply_filter
#     populate_table        = manager_window.populate_table
#     populate_orders_table = manager_window.populate_orders_table
#     load_orders           = manager_window.load_orders
#     sort_asc              = manager_window.sort_asc
#     sort_desc             = manager_window.sort_desc

#     # ---------- товары ----------

#     def add_item_dialog(self):
#         if admin_window.edit_open:
#             QMessageBox.warning(self, 'Предупреждение',
#                                 'Уже открыто окно редактирования.\n'
#                                 'Закройте его перед добавлением нового товара.')
#             return
#         admin_window.edit_open = True
#         try:
#             from dialogs.item_form_dialog import ItemFormDialog
#             dialog = ItemFormDialog()
#             if dialog.exec():
#                 self.load_menu()
#         finally:
#             admin_window.edit_open = False

#     def edit_item_dialog(self, row, _col):
#         if admin_window.edit_open:
#             QMessageBox.warning(self, 'Предупреждение',
#                                 'Уже открыто окно редактирования.\n'
#                                 'Закройте его перед редактированием другого товара.')
#             return
#         item = self.tableWidgetProducts.item(row, 0)
#         if not item:
#             return
#         admin_window.edit_open = True
#         try:
#             from dialogs.item_form_dialog import ItemFormDialog
#             dialog = ItemFormDialog(item_id=int(item.text()))
#             if dialog.exec():
#                 self.load_menu()
#         finally:
#             admin_window.edit_open = False

#     def delete_item_dialog(self):
#         row = self.tableWidgetProducts.currentRow()
#         if row < 0:
#             QMessageBox.warning(self, 'Ошибка', 'Выберите товар для удаления.')
#             return
#         item_id = int(self.tableWidgetProducts.item(row, 0).text())
#         ans = QMessageBox.question(
#             self, 'Подтверждение',
#             f'Удалить товар ID={item_id}?\nЭто действие нельзя отменить.',
#             QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
#         )
#         if ans != QMessageBox.StandardButton.Yes:
#             return
#         ok, msg = delete_menu_item(item_id)
#         if ok:
#             QMessageBox.information(self, 'Готово', 'Товар удалён.')
#             self.load_menu()
#         else:
#             QMessageBox.critical(self, 'Ошибка', msg)

#     # ---------- заказы ----------

#     def add_order_dialog(self):
#         from dialogs.order_form_dialog import OrderFormDialog
#         dialog = OrderFormDialog()
#         if dialog.exec():
#             self.load_orders()

#     def edit_order_dialog(self, row, _col):
#         item = self.tableWidgetOrders.item(row, 0)
#         if not item:
#             return
#         from dialogs.order_form_dialog import OrderFormDialog
#         dialog = OrderFormDialog(order_id=int(item.text()))
#         if dialog.exec():
#             self.load_orders()

#     def delete_order_dialog(self):
#         row = self.tableWidgetOrders.currentRow()
#         if row < 0:
#             QMessageBox.warning(self, 'Ошибка', 'Выберите заказ для удаления.')
#             return
#         order_id = int(self.tableWidgetOrders.item(row, 0).text())
#         ans = QMessageBox.question(
#             self, 'Подтверждение',
#             f'Удалить заказ #{order_id}?',
#             QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
#         )
#         if ans == QMessageBox.StandardButton.Yes:
#             if delete_order(order_id):
#                 self.load_orders()
#             else:
#                 QMessageBox.critical(self, 'Ошибка', 'Не удалось удалить заказ.')

#     # ---------- навигация ----------

#     def back_to_login(self):
#         from auth.auth import login_window
#         self.win = login_window()
#         self.win.show()
#         self.close()
