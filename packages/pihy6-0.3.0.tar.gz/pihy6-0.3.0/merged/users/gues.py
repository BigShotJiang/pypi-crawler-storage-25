from pathlib import Path

from PyQt6.QtWidgets import QMainWindow, QMessageBox, QWidget, QVBoxLayout
from ui.gues_window import Ui_gues_window
from database.db import check_login, all_menu_items, one_menu_items
from users.card import card


class guest_window(QMainWindow, Ui_gues_window):
    def __init__(self):
         super().__init__()
         self.setupUi(self)

         self.images_dir = Path(__file__).resolve().parent.parent / 'resourses' / 'images'
         self.items = []

         self.pushButtonLogin.clicked.connect(self.exit_login)
         self.pushButtonRefresh.clicked.connect(self.load_menu)
         
         self.card_widget = QWidget()
         self.layout_card = QVBoxLayout(self.card_widget)
         self.scrollArea.setWidget(self.card_widget)

         self.load_menu()

    def load_menu(self):
       while self.layout_card.count():
           self.layout_card.takeAt(0).widget().deleteLater()
       self.items = all_menu_items()
       for item in self.items:
            cards = card(item,self.images_dir)
            cards.clicked.connect(self.show_item_info)
            self.layout_card.addWidget(cards)
       self.statusbar.showMessage(f'Загружено позиций: {len(self.items)}')      

    def show_item_info(self, item_id):
        item = one_menu_items(item_id)

        text= (
            f"Название: {item['name']}\n"
            f"Категория: {item['category']}\n"
            f"Цена: {float(item['price']):.2f} P\n\n" 
            f"Описание: \n{item['description'] or 'Нет описания'}"
        )
        QMessageBox.information(self,item.get('name'),text)

    def exit_login(self):
         from auth.auth import login_window
         self.win = login_window()
         self.win.show()
         self.close()