from PyQt6.QtWidgets import QMainWindow, QMessageBox
from ui.login_window import Ui_login_window
from database.db import check_login

class login_window(QMainWindow, Ui_login_window):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.pushButton_guest.clicked.connect(self.open_guest)
        self.pushButton_login.clicked.connect(self.login)

    def login(self):

        username = self.lineEditUsername.text().strip()
        password = self.lineEditPassword.text().strip()
        
        if not username or not password:
            QMessageBox.warning(self, 'ошибка', 'введите логин или пароль')
            return
        
        user = check_login(username, password)
        if not user:
            QMessageBox.warning(self, 'ошибка', 'неверный логин или пароль')
            return
    
        name = user['full_name']
        role = user['role']
        user_id = user['user_id']

        if role == 'client':
            from users.client import client_window
            self.win = client_window(name, user_id)
        elif role == 'admin':
            from users.admin import admin_window
            self.win = admin_window(name, user_id)
        elif role == 'manager':
            from users.manager import manager_window
            self.win = manager_window(name, user_id)

        self.win.show()
        self.close()

    def open_guest(self):
        from users.gues import guest_window
        self.win = guest_window()
        self.win.show()
        self.close()