from PyQt6.QtWidgets import QDialog, QMessageBox
from ui.item_form import Ui_ItemFormDialog
from database.db import one_menu_items, add_menu_item, edit_menu_item

class ItemFormDialog(QDialog, Ui_ItemFormDialog):
    def __init__(self, item_id= None):
        super().__init__()
        self.setupUi(self)
        self.item_id = item_id

        self.setWindowTitle('добавление товара' if item_id is None else 'редактирование товара')

        self.pushButtonCancel.clicked.connect(self.reject)
        self.pushButtonSave.clicked.connect(self.save_data)

        if item_id is None:
            self.labelId.hide()
            self.labelIdValue.hide()
        else:
            self.load_item_data()

    def load_item_data(self):
        item = one_menu_items(self.item_id)
        if not item:
            QMessageBox.warning(self, 'ошибка', 'не удалось загрузить товар')
            self.reject()
            return
        
        self.labelIdValue.setText(str(item['item_id']))
        self.lineEditName.setText(item.get('name') or '')
        self.lineEditCategory.setText(item.get('category') or '')
        self.lineEditDescription.setText(item.get('description') or '')
        self.doubleSpinBoxPrice.setValue(float(item.get('price') or 0))

    def save_data(self):
        name = self.lineEditName.text().strip()
        if not name:
            QMessageBox.warning(self, 'ошибка', 'заполните имя товара')
            return
        if self.doubleSpinBoxPrice.value() < 0:
            QMessageBox.warning(self, 'ошибка', 'цена не может быть отрицательной')
            return
        
        category = self.lineEditCategory.text().strip()
        description = self.lineEditDescription.text().strip()
        price = self.doubleSpinBoxPrice.value()
        
        ok = edit_menu_item(self.item_id, name, category, description, price) if self.item_id else add_menu_item(name, category, description, price)
        if ok:
            self.accept()
        else:
            QMessageBox.warning(self, 'ошибка', 'ошибка сохранение товара')

