from PyQt6.QtWidgets import QDialog, QMessageBox
from PyQt6.QtCore import QDate
from ui.order_client import Ui_Dialog_order
from database.db import all_menu_items,add_item, one_menu_items

class order_item(QDialog, Ui_Dialog_order):
    def __init__(self, user_id):
        super().__init__()
        self.setupUi(self)
        self.date = QDate.currentDate().toPyDate()
        self.user_id = user_id
        
        self.pushButtonOrder.clicked.connect(self.order)

        self.load_all()

    def load_all(self):
        items = all_menu_items()

        for item in items:
            self.comboBox.addItem(item.get('name'), item.get('item_id'))

    def order(self):
        item_id = self.comboBox.currentData()
        itemm = one_menu_items(item_id)
        prise = int(itemm['prise'])
        adress = self.lineEditAdres.text()
        quantity = self.spinBoxquantity.value()
        total_amount = prise * quantity

        print(f"заказ: item_id={item_id}, prise={prise}, quantity={quantity}, total_amount={total_amount}")

        if add_item(self.user_id, item_id, adress, self.date, quantity, total_amount):
            self.accept()
        else:
            QMessageBox.warning(self, 'ошибка', 'ошибка добавления')