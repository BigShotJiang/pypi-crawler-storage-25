dature inspect --help
