dature validate --help
