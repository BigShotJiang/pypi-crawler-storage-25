"""nested_resolve_strategy with Docker secrets source."""

from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory

import dature


@dataclass
class Database:
    host: str
    port: int


@dataclass
class Config:
    database: Database


with TemporaryDirectory() as secrets_dir:
    secrets_path = Path(secrets_dir)
    (secrets_path / "database").write_text(
        '{"host": "json-host", "port": "5432"}',
    )
    (secrets_path / "database__host").write_text("flat-host")
    (secrets_path / "database__port").write_text("3306")

    config = dature.load(
        dature.DockerSecretsSource(
            dir_=secrets_path,
            nested_resolve_strategy="json",
        ),
        schema=Config,
    )

    assert config.database.host == "json-host"
    assert config.database.port == 5432
