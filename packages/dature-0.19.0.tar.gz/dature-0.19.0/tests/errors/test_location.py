from dature import EnvFileSource, EnvSource, JsonSource, Toml11Source
from dature.errors import LineRange
from dature.errors.location import ErrorContext, resolve_source_location


class TestResolveSourceLocation:
    def test_env_source(self):
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvSource(prefix="APP_"),
        )
        locs = resolve_source_location(["database", "port"], ctx, file_content=None)
        assert len(locs) == 1
        assert locs[0].location_label == "ENV"
        assert locs[0].env_var_name == "APP_DATABASE__PORT"
        assert locs[0].file_path is None

    def test_env_source_shows_value(self, monkeypatch):
        monkeypatch.setenv("APP_PORT", "abc")
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvSource(prefix="APP_"),
        )
        locs = resolve_source_location(["port"], ctx, file_content=None)
        assert locs[0].env_var_value == "abc"

    def test_env_source_no_value_when_unset(self):
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvSource(prefix="APP_"),
        )
        locs = resolve_source_location(["port"], ctx, file_content=None)
        assert locs[0].env_var_value is None

    def test_env_source_secret_drops_value(self, monkeypatch):
        monkeypatch.setenv("APP_TOKEN", "hunter2")
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvSource(prefix="APP_"),
            secret_paths=frozenset({"token"}),
        )
        locs = resolve_source_location(["token"], ctx, file_content=None)
        assert locs[0].env_var_value is None

    def test_env_source_no_prefix(self):
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvSource(),
        )
        locs = resolve_source_location(["timeout"], ctx, file_content=None)
        assert locs[0].env_var_name == "TIMEOUT"

    def test_env_source_custom_split_symbols(self):
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvSource(prefix="APP_", nested_sep="_"),
        )
        locs = resolve_source_location(["database", "port"], ctx, file_content=None)
        assert locs[0].env_var_name == "APP_DATABASE_PORT"

    def test_json_source_with_line(self):
        content = '{\n  "timeout": "30",\n  "name": "test"\n}'
        ctx = ErrorContext(
            dataclass_name="Config",
            source=JsonSource(file="config.json"),
        )
        locs = resolve_source_location(["timeout"], ctx, file_content=content)
        assert locs[0].location_label == "FILE"
        assert locs[0].line_range == LineRange(start=2, end=2)
        assert locs[0].line_content == ['"timeout": "30",']

    def test_toml_source_with_line(self):
        content = 'timeout = "30"\nname = "test"'
        ctx = ErrorContext(
            dataclass_name="Config",
            source=Toml11Source(file="config.toml"),
        )
        locs = resolve_source_location(["timeout"], ctx, file_content=content)
        assert locs[0].location_label == "FILE"
        assert locs[0].line_range == LineRange(start=1, end=1)
        assert locs[0].line_content == ['timeout = "30"']

    def test_envfilesource(self):
        content = "# comment\nAPP_TIMEOUT=30\nAPP_NAME=test"
        ctx = ErrorContext(
            dataclass_name="Config",
            source=EnvFileSource(file="dummy.env", prefix="APP_"),
        )
        locs = resolve_source_location(["timeout"], ctx, file_content=content)
        assert locs[0].location_label == "ENV FILE"
        assert locs[0].env_var_name == "APP_TIMEOUT"
        assert locs[0].line_range == LineRange(start=2, end=2)
        assert locs[0].line_content == ["APP_TIMEOUT=30"]

    def test_filesource_does_not_mask_non_secret_field(self):
        content = '{\n  "password": "secret123",\n  "timeout": "30"\n}'
        ctx = ErrorContext(
            dataclass_name="Config",
            source=JsonSource(file="config.json"),
            secret_paths=frozenset({"password"}),
        )
        locs = resolve_source_location(["timeout"], ctx, file_content=content)
        assert locs[0].line_content == ['"timeout": "30"']

    def test_filesource_masks_secret_field(self):
        content = '{\n  "password": "secret123",\n  "timeout": "30"\n}'
        ctx = ErrorContext(
            dataclass_name="Config",
            source=JsonSource(file="config.json"),
            secret_paths=frozenset({"password"}),
        )
        locs = resolve_source_location(["password"], ctx, file_content=content)
        assert locs[0].line_content == ['"password": "<REDACTED>",']

    def test_filesource_masks_line_when_secret_on_same_line(self):
        content = '{"password": "secret123", "timeout": "30"}'
        ctx = ErrorContext(
            dataclass_name="Config",
            source=JsonSource(file="config.json"),
            secret_paths=frozenset({"password"}),
        )
        locs = resolve_source_location(["timeout"], ctx, file_content=content)
        assert locs[0].line_content == ['{"password": "<REDACTED>", "timeout": "30"}']
