"""Tests for json5_ module (Json5Source)."""

from dataclasses import dataclass
from pathlib import Path

import pytest

from dature import Json5Source, load
from dature.errors import DatureConfigError, FieldLoadError, LineRange
from dature.sources.json5_ import _build_json5_line_map
from examples.all_types_dataclass import EXPECTED_ALL_TYPES, AllPythonTypesCompact
from tests.sources.checker import assert_all_types_equal


class TestJson5SourceDisplayProperties:
    def test_format_name_and_label(self):
        assert Json5Source.format_name == "json5"
        assert Json5Source.location_label == "FILE"


class TestJson5Source:
    """Tests for Json5Source class."""

    def test_comprehensive_type_conversion(self, all_types_json5_file: Path):
        """Test loading JSON5 with full type coercion to dataclass."""
        result = load(Json5Source(file=all_types_json5_file), schema=AllPythonTypesCompact)

        assert_all_types_equal(result, EXPECTED_ALL_TYPES)

    def test_json5_with_prefix(self, prefixed_json5_file: Path):
        @dataclass
        class PrefixedConfig:
            name: str
            port: int
            debug: bool
            environment: str

        expected_data = PrefixedConfig(
            name="PrefixedApp",
            port=9000,
            debug=False,
            environment="production",
        )

        result = load(
            Json5Source(file=prefixed_json5_file, prefix="app"),
            schema=PrefixedConfig,
        )

        assert result == expected_data

    def test_json5_empty_object(self, tmp_path: Path):
        """Test loading empty JSON5 object."""
        json5_file = tmp_path / "empty.json5"
        json5_file.write_text("{}")

        loader = Json5Source(file=json5_file)
        data = loader._load()

        assert data == {}

    def test_json5_env_var_substitution(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("DB_HOST", "db.example.com")
        monkeypatch.setenv("DB_PORT", "5432")

        json5_file = tmp_path / "env.json5"
        json5_file.write_text('{host: "$DB_HOST", port: "$DB_PORT"}')

        @dataclass
        class DbConfig:
            host: str
            port: int

        result = load(Json5Source(file=json5_file), schema=DbConfig)

        assert result.host == "db.example.com"
        assert result.port == 5432

    def test_json5_env_var_partial_substitution(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("HOST", "localhost")
        monkeypatch.setenv("PORT", "8080")

        json5_file = tmp_path / "env.json5"
        json5_file.write_text('{url: "http://${HOST}:${PORT}/api"}')

        @dataclass
        class Config:
            url: str

        result = load(Json5Source(file=json5_file), schema=Config)

        assert result.url == "http://localhost:8080/api"

    def test_json5_dollar_sign_mid_string_existing_var(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("abc", "replaced")

        json5_file = tmp_path / "dollar.json5"
        json5_file.write_text('{value: "prefix$abc/suffix"}')

        @dataclass
        class Config:
            value: str

        result = load(Json5Source(file=json5_file), schema=Config)

        assert result.value == "prefixreplaced/suffix"

    def test_json5_dollar_sign_mid_string_missing_var(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("nonexistent", raising=False)

        json5_file = tmp_path / "dollar.json5"
        json5_file.write_text('{value: "prefix$nonexistent/suffix"}')

        @dataclass
        class Config:
            value: str

        result = load(Json5Source(file=json5_file), schema=Config)

        assert result.value == "prefix$nonexistent/suffix"

    def test_bool_in_int_field_raises_error(self, tmp_path: Path):
        json5_file = tmp_path / "config.json5"
        json5_file.write_text("{count: true}")

        @dataclass
        class Config:
            count: int

        with pytest.raises(DatureConfigError) as exc_info:
            load(Json5Source(file=json5_file), schema=Config)

        err = exc_info.value
        assert len(err.exceptions) == 1
        first = err.exceptions[0]
        assert isinstance(first, FieldLoadError)
        assert first.field_path == ["count"]
        assert str(first) == (
            f"  [count]  Expected int, got bool\n"
            f"   ├── {json5_file.read_text()}\n"
            f"   │           ^^^^\n"
            f"   └── FILE '{json5_file}', line 1"
        )

    def test_int_in_bool_field_raises_error(self, tmp_path: Path):
        json5_file = tmp_path / "config.json5"
        json5_file.write_text("{flag: 1}")

        @dataclass
        class Config:
            flag: bool

        with pytest.raises(DatureConfigError) as exc_info:
            load(Json5Source(file=json5_file), schema=Config)

        err = exc_info.value
        assert len(err.exceptions) == 1
        first = err.exceptions[0]
        assert isinstance(first, FieldLoadError)
        assert first.field_path == ["flag"]
        assert str(first) == (
            f"  [flag]  Expected bool, got int\n"
            f"   ├── {json5_file.read_text()}\n"
            f"   │          ^\n"
            f"   └── FILE '{json5_file}', line 1"
        )


class TestJson5FindLineRange:
    @pytest.mark.parametrize(
        "content",
        [
            pytest.param("{\n  str1: 'line1\\nkey=1',\n  key: 'real'\n}", id="newline_in_value"),
            pytest.param('{\n  str1: "he said \\"key\\": value",\n  key: 42\n}', id="escaped_quotes"),
        ],
    )
    def test_key_not_confused(self, content: str):
        assert _build_json5_line_map(content).get(("key",)) == LineRange(start=3, end=3)

    def test_scalar_value(self):
        content = "{\n  timeout: 30\n}"
        assert _build_json5_line_map(content).get(("timeout",)) == LineRange(start=2, end=2)

    def test_multiline_dict(self):
        content = '{\n  db: {\n    host: "localhost",\n    port: 5432\n  }\n}'
        assert _build_json5_line_map(content).get(("db",)) == LineRange(start=2, end=5)

    def test_multiline_array(self):
        content = '{\n  tags: [\n    "a",\n    "b"\n  ]\n}'
        assert _build_json5_line_map(content).get(("tags",)) == LineRange(start=2, end=5)

    def test_not_found(self):
        content = '{\n  name: "test"\n}'
        assert _build_json5_line_map(content).get(("missing",)) is None

    def test_inline_dict(self):
        content = '{\n  db: {host: "localhost"}\n}'
        assert _build_json5_line_map(content).get(("db",)) == LineRange(start=2, end=2)

    def test_inline_array(self):
        content = '{\n  tags: ["a", "b"]\n}'
        assert _build_json5_line_map(content).get(("tags",)) == LineRange(start=2, end=2)
