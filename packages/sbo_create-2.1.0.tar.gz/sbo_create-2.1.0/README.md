[![pipeline](https://gitlab.com/dslackw/sbo-create/badges/main/pipeline.svg)](https://gitlab.com/dslackw/sbo-create/-/pipelines)
[![coverage](https://gitlab.com/dslackw/sbo-create/badges/main/coverage.svg)](https://gitlab.com/dslackw/sbo-create/-/commits/main)
[![PyPI](https://img.shields.io/pypi/v/sbo-create.svg)](https://pypi.org/project/sbo-create/)
[![Python](https://img.shields.io/pypi/pyversions/sbo-create.svg)](https://pypi.org/project/sbo-create/)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

## About

sbo-create is a command-line tool for creating and maintaining
<a href="https://www.slackbuilds.org" target="_blank">SlackBuilds.org</a> packages.

It covers the entire package lifecycle: generating files from official SBo templates,
downloading and verifying sources, validating against SBo submission guidelines,
bumping versions, and packaging for submission — all from a single tool.

## Homepage

Visit the project website [here](https://dslackw.gitlab.io/sbo-create/).

## Source

* <a href="https://gitlab.com/dslackw/sbo-create" target="_blank">GitLab</a> repository.
* <a href="https://slackbuilds.org/repository/15.0/system/sbo-create/" target="_blank">SlackBuilds.org</a> repository.
* <a href="https://pypi.org/project/sbo-create/" target="_blank">PyPI</a> repository.

## Features

- File-based SlackBuild templates auto-updated from slackbuilds.org.
- Creates all package files inside a `<prgnam>/` subdirectory, matching the
  SBo layout. Supports interactive mode, `sbc create myapp` (positional), and
  full flag-based non-interactive mode.
- Create submission tarball (`<prgnam>.tar.gz`) with automatic validation.
- Validation of `.info` fields and md5sums against SBo submission guidelines.
- Automatic verification of dependencies in `REQUIRES` against SBo repository.
- Local caching of SBo package list for instantaneous and offline validation.
- Checks whether a package already exists in the SBo repository.
- Fetches and extracts a SlackBuild package from the SBo repository, or copies
  it directly from a local clone when `SBO_REPO_PATH` is configured. Supports
  browsing package files and reading individual files without a full download.
- Shows a unified diff between local package files and the SBo repository.
- Resolves recursive dependencies (`deps`) and reverse dependencies (`rdeps`)
  using the local package index or a local SBo clone.
- Searches for packages by partial name match.
- Downloads source files listed in the `.info` file, with optional URL
  accessibility check via HTTP HEAD requests.
- Bumps version in `.info` and `.SlackBuild`, with optional automatic update
  of `DOWNLOAD` URLs, source download, and MD5SUM recomputation.
- Preview files that would be created without writing anything to disk.
- Auto-correction of quotation marks in `.info` file fields.
- Auto-imports text from `slack-desc` into the `README` file.
- Interactive CLI prompt to create or update maintainer configuration,
  with current values shown as defaults. Type `!` to clear a field.
- Auto-imports maintainer data into the `.SlackBuild` script.
- Auto-imports and verifies MD5 checksums in the `.info` file.
- ARM64 architecture support.
- Opens all package files in the configured editor with a single command.
- Renames package files and updates all `PRGNAM` references and `slack-desc`
  content in one step, with word-boundary matching.
- Interactive `create` mode with arrow-key template selection when no flags given.
- Strip comment lines and inline comments from `.SlackBuild`.
- Strict pre-submission checks: HTTPS URLs, HOMEPAGE accessibility, executable
  bit, exact slack-desc line count, and MAINTAINER/EMAIL match.
- Syncs the local SBo git repository after a weekly public update: pulls the
  main branch, deletes the old working branch, and creates a fresh one.
- Submits a package update via git (commit and push) or opens the SBo web
  submission page if no git repository is configured. Warns if the working
  branch is behind the main branch and auto-detects first-push upstream setup.
- Queries [repology.org](https://repology.org) for package version status by
  maintainer e-mail. Filters by `--newest`, `--outdated`, `--problematic`, or
  shows all statuses when no filter is given.
- ANSI-coloured CLI output and colored help (suppressed when output is piped).

## Usage

```
usage: sbo-create COMMAND [OPTIONS]
       sbc COMMAND [OPTIONS]
```

Note: `sbc` is available as a shorter alias for `sbo-create`.
Available commands: `create`, `download`, `check`, `search`, `clean`, `info`,
`list`, `validate`, `bump`, `package`, `edit`, `rename`, `fetch`, `deps`,
`rdeps`, `diff`, `sync`, `submit`, `update`, `maintainer`, `repology`.

Create all SlackBuild files interactively (arrow-key template selection):

```bash
sbo-create create
```

Create all SlackBuild files non-interactively for a Python package:

```bash
sbo-create create -n prgnam -r 1.0.0 -t python
```

Open package files in the configured editor:

```bash
sbo-create edit
```

Rename package files (updates PRGNAM, SlackBuild header, and slack-desc):

```bash
sbo-create rename newname
```

Create submission tarball (prompts for strict validation before packaging):

```bash
sbo-create package
```

Update templates from slackbuilds.org:

```bash
sbo-create update
```

Search for packages by partial name:

```bash
sbo-create search python3-b
```

Remove downloaded source tarballs:

```bash
sbo-create clean
```

Check if a package exists in the SBo repository:

```bash
sbo-create check python3-build
```

Check multiple packages at once:

```bash
sbo-create check vim slpkg colored
```

Check URL accessibility without downloading:

```bash
sbo-create download --check-urls
```

Validate the `.info` file:

```bash
sbo-create validate
```

Show detailed warnings for missing or untracked source tarballs during validation:

```bash
sbo-create validate --md5
```

Auto-fix common issues across all package files (trailing whitespace, quotes,
PRGNAM, VERSION sync, copyright year, final newline, and MD5SUM recomputation
from local sources when a mismatch is detected):

```bash
sbo-create validate --fix
```

Auto-fix all issues including strict ones (HOMEPAGE http→https, executable bit,
source tarballs, MAINTAINER/EMAIL):

```bash
sbo-create validate --strict --fix
```

Bump version and recompute checksums:

```bash
sbo-create bump 2.0.0 --with-sources
```

Run strict pre-submission validation:

```bash
sbo-create validate --strict
```

List available templates:

```bash
sbo-create list
```

Show dependency tree for a package:

```bash
sbo-create deps neovim-qt
sbo-create deps neovim-qt --tree
```

Show which packages depend on a given package:

```bash
sbo-create rdeps python3-tomlkit
```

Sync the SBo repository after a weekly public update:

```bash
sbo-create sync
```

Fetch and extract a SlackBuild package from SBo (or local clone):

```bash
sbo-create fetch slpkg
```


Submit a package update via git (commit and push):

```bash
sbo-create submit
```

Check package versions via repology.org (all statuses):

```bash
sbo-create repology
```

Show only outdated packages for a specific maintainer e-mail:

```bash
sbo-create repology --outdated -m user@example.com
```

## Documentation

Full documentation is available at [dslackw.gitlab.io/sbo-create](https://dslackw.gitlab.io/sbo-create/).

## License

[GNU General Public License v3 (GPLv3)](https://www.gnu.org/licenses/gpl-3.0.html)

## Donate

Did you know that developers love coffee?

[<img src="https://gitlab.com/dslackw/slpkg/-/raw/site/docs/images/paypaldonate.png" alt="paypal" title="donate">](https://www.paypal.me/dslackw)

## Contributing

Contributions are welcome! Please open an issue or merge request on GitLab.

## Copyrights

Slackware® is a Registered Trademark of Patrick Volkerding.
Linux is a Registered Trademark of Linus Torvalds.
