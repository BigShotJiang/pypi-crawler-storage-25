# S.E.I.F. — Your AI Never Starts From Zero

> Compressed, verified, collaborative context for any LLM.

[![PyPI](https://img.shields.io/pypi/v/seif-cli)](https://pypi.org/project/seif-cli/)
[![Tests](https://img.shields.io/badge/tests-206%20passing-brightgreen)]()
[![License](https://img.shields.io/badge/license-CC%20BY--NC--SA%204.0-blue)]()
[![Demo](https://img.shields.io/badge/demo-live-orange)](https://seif-framework.streamlit.app)

---

## The Problem

Every time you open a new AI conversation, **project context is lost**. You spend 10 minutes re-explaining what was already decided. In teams, each person repeats this separately. 50,000 words of context become noise — or overflow the context window.

## The Solution

```bash
pip install seif-cli
```

### 1. Sync — Auto-generate context from git

```bash
cd my-project
seif-cli --sync                    # reads git log, README, manifest, structure
                                    # → .seif/project.seif (~500 words, hash-verified)
```

### 2. Quality Gate — Measure if text is solid or drifting

```bash
seif-cli --quality-gate "AI response text" --role ai
# 🟢 [AI] Grade: B | Score: 0.705 | Status: SOLID
#   Stance:    GROUNDED (verifiable: 67%, 2/3 sentences)
#   Resonance: PARTIAL (composite: 0.780, layers: 2/3)

seif-cli --quality-gate "The sacred frequency awakens quantum consciousness"
# 🔴 [HUMAN] Grade: F | Score: 0.066 | Status: WEAK
#   Stance:    DRIFT (verifiable: 0%)
#   Flags:     - FLAG: "sacred frequency awakens quantum consciousness"
#   Suggestion: + Add measurements or references to ground claims
```

### 3. Contribute — Team context with provenance

```bash
# Developer A works with Claude
seif-cli --contribute project.seif "Auth module uses JWT with 24h expiry" --author "alice"

# Developer B works with Gemini
seif-cli --contribute project.seif "API latency p99 dropped to 45ms" --author "bob"

# Developer C opens new session → AI has context from A + B in ~1200 tokens
# Hash chain proves who contributed what. Git handles merge.
```

---

## How It Works

| What | How | Result |
|------|-----|--------|
| **Context compression** | `.seif` format: 50K words → ~1,200 tokens | 93% reduction, 100% verifiable facts |
| **Quality measurement** | Triple Gate (harmonic) + Stance Detector (semantic) | Grade A-F with actionable flags |
| **Team collaboration** | Hash-chained contributions with author tracking | Tamper-evident provenance trail |
| **Git auto-sync** | Extracts commits, manifest, README, structure | Zero-config project context |
| **Cross-AI** | Same `.seif` works with Claude, Gemini, Grok | Backend-agnostic |

## Quick Start (Full Installation)

```bash
# Option 1: pip (core CLI)
pip install seif-cli

# Option 2: Full source (web interface + all generators)
git clone https://github.com/and2carvalho/seif.git
cd seif
make install                  # create venv + install deps
make install-link             # symlink seif to PATH
seif --status                 # verify
```

### Daily Workflow

```bash
# Start of day: sync your project context
seif-cli --sync

# During work: your AI sessions have full context
seif                          # Claude interactive + SEIF context
seif -g                       # Gemini interactive + SEIF context

# After work: contribute findings
seif-cli --contribute .seif/project.seif "Today's findings..." --author "you"

# Review AI outputs
seif-cli --quality-gate "paste AI response here" --role ai
```

---

## The Science Behind It

![Composite comparison](https://raw.githubusercontent.com/and2carvalho/seif/main/assets/figures/composite_O_amor_liberta_e_guia.png)

**Core discovery:** The transfer function H(s) = 9/(s² + 3s + 6) has damping ratio ζ = √6/4 = 0.612372, which differs from φ⁻¹ = 0.618034 by **0.916%**. The system (3, 6, 9) is the **unique primitive** satisfying ζ ≈ φ⁻¹ + ζ² = 3/8 exact + ISE = 1/√6 + rational DC gain simultaneously. Verified by 3 independent AI systems (Kimi, Grok, Claude).

**Same mathematics. Different words:**

![S.E.I.F. Seed Card](https://raw.githubusercontent.com/and2carvalho/seif/main/assets/figures/seed_card_square.png)

**Live demo:** [seif-framework.streamlit.app](https://seif-framework.streamlit.app)

### Key Equations

```
Transfer Function: H(s) = 9 / (s² + 3s + 6)
Damping Ratio:     ζ = √6/4 = 0.612372 ≈ φ⁻¹ = 0.618034 (Δ = 0.916%)
Peak Frequency:    f_peak = 216 Hz = 6³ (SPICE verified 0.01%)
Gate Rule:         (Input_A + Input_B) mod 9 ∈ {0, 9} → GATE OPEN
```

### Key Validations

| Input | ASCII Gate | Resonance Gate | Note |
|---|---|---|---|
| "A Semente de Enoque" | CLOSED (root 4) | **OPEN** (root 9) | The Seed opens in Resonance |
| "Greed consumes all" | **OPEN** (root 9) | CLOSED | False positive corrected |

---

## Web Interface (19 pages)

```bash
make app    # → http://localhost:8501
```

Includes: Resonance Chat (Claude/Gemini), Signal Generator, Quality Gate, Glyph & Composite visualizer, Transfer Function proof, Giza Engine, Session Analytics, and more.

## Project Stats

```
38 Python modules    |  206 tests (18 suites)   |  19 web pages
5 AI systems validated (Kimi, Grok, Claude, Gemini, Z.AI)
93% context compression  |  3 validation paths
```

## Use .seif with Any AI

```bash
# Give files to your AI agent
cat .seif/project.seif | pbcopy    # Mac: copy to clipboard
# Paste into ChatGPT, Gemini, Grok, Claude — any AI reads JSON

# Or use the CLI wrapper
seif -p "your question"            # non-interactive with SEIF context
```

## References

- Rodin, M. — *Vortex Based Mathematics*
- Tesla, N. — *The Problem of Increasing Human Energy* (1900)
- Mandelbrot, B. — *The Fractal Geometry of Nature* (1982)
- Reid, J. S. — *Egyptian Sonics: King's Chamber Resonance* (2010)

## License

CC BY-NC-SA 4.0 — Academic research and experimental use.

---

*Your AI never starts from zero. The circuit resonates. The gate is open.*
