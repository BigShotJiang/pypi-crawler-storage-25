"""
Telegram Bot — Biological Voice Channel for S.E.I.F.

The most accessible way for a human to interact with the framework:
send a voice message on Telegram → receive resonance analysis + AI response.

Flow:
  1. Human sends voice message to @seif_bot
  2. Bot downloads .ogg → converts to .wav
  3. audio_analyzer.py extracts frequencies (LOCAL, not sent to AI)
  4. Resonance metadata + transcription sent to AI via ai_bridge
  5. AI responds
  6. Bot sends: AI text + resonance analysis + harmonic audio

Setup:
  1. Create bot via @BotFather on Telegram
  2. Set TELEGRAM_BOT_TOKEN env var
  3. Run: python -m seif.bridge.telegram_bot

"The bot OFFERS a channel (STATE). The human CHOOSES to interact."
"""

import os
import sys
import logging
import tempfile
from pathlib import Path

# Add project to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

from seif.core.resonance_gate import evaluate
from seif.core.resonance_encoding import encode_phrase, describe_melody
from seif.analysis.audio_analyzer import analyze_audio, describe as describe_audio
from seif.bridge.ai_bridge import send, detect_backends
from seif.context.context_manager import build_startup_context, estimate_tokens

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("seif.telegram")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    tokens = estimate_tokens()
    await update.message.reply_text(
        "🌀 *S.E.I.F. — Spiral Encoding Interoperability Framework*\n"
        "_\"Speak the Resonance. Sense the Code.\"_\n\n"
        "Send me:\n"
        "• *Text* — I'll analyze through the resonance gate\n"
        "• *Voice message* — I'll analyze your vocal frequencies\n\n"
        f"Context loaded: KERNEL + {tokens['module_count']} modules (~{tokens['total']} tokens)\n"
        "Backends: " + ", ".join(detect_backends()),
        parse_mode="Markdown",
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /status command."""
    tokens = estimate_tokens()
    backends = detect_backends()
    await update.message.reply_text(
        f"═══ S.E.I.F. STATUS ═══\n"
        f"KERNEL: VALID\n"
        f"Modules: {tokens['module_count']}\n"
        f"Tokens: ~{tokens['total']}\n"
        f"Backends: {', '.join(backends)}",
    )


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle text messages — resonance analysis + AI response."""
    text = update.message.text

    # Resonance analysis
    gate = evaluate(text)
    melody = encode_phrase(text)

    # Build metadata
    metadata = (
        f"ascii_root={gate.digital_root}, "
        f"phase={gate.phase.name}, "
        f"resonance_coherence={melody.coherence_score:.4f}, "
        f"resonance_gate={'OPEN' if melody.gate_open else 'CLOSED'}"
    )

    # Send analysis first
    gate_emoji = "🟢" if gate.gate_open else "🔴"
    res_emoji = "🟢" if melody.gate_open else "🔴"
    await update.message.reply_text(
        f"🔍 *Resonance Analysis*\n"
        f"ASCII: {gate_emoji} root {gate.digital_root} ({gate.phase.name})\n"
        f"Encoding: {res_emoji} coh={melody.coherence_score:.3f}\n"
        f"Gate: {'OPEN' if gate.gate_open or melody.gate_open else 'CLOSED'}",
        parse_mode="Markdown",
    )

    # Send to AI
    await update.message.reply_chat_action("typing")
    response = send(
        message=text,
        backend="auto",
        resonance_metadata=metadata,
    )

    if response.success:
        resp_text = response.text[:4000]
        try:
            await update.message.reply_text(
                f"{resp_text}\n\n_🔗 {response.backend} / {response.model}_",
                parse_mode="Markdown",
            )
        except Exception:
            # Markdown parse error fallback
            await update.message.reply_text(
                f"{resp_text}\n\n🔗 {response.backend} / {response.model}",
            )
    else:
        await update.message.reply_text(f"❌ {response.error}")


async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle voice messages — THE biological input pathway.

    The audio is downloaded, analyzed LOCALLY, and only metadata
    is sent to the AI. The raw audio never leaves our system.
    """
    await update.message.reply_text("🎤 Analyzing your voice frequencies...")

    # Download voice message
    voice = update.message.voice or update.message.audio
    if not voice:
        await update.message.reply_text("No audio found.")
        return

    file = await context.bot.get_file(voice.file_id)

    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as tmp:
        await file.download_to_drive(tmp.name)
        ogg_path = tmp.name

    # Convert .ogg to .wav using ffmpeg
    wav_path = ogg_path.replace(".ogg", ".wav")
    os.system(f"ffmpeg -i {ogg_path} -ar 44100 -ac 1 {wav_path} -y -loglevel quiet")

    if not Path(wav_path).exists():
        await update.message.reply_text("❌ Could not convert audio. Is ffmpeg installed?")
        os.unlink(ogg_path)
        return

    try:
        # Step 1: Frequency analysis (local, fast)
        analysis = analyze_audio(wav_path)

        gate_emoji = "🟢" if analysis.gate_status == "RESONANT" else "🟡" if "PARTIAL" in analysis.gate_status else "🔴"
        await update.message.reply_text(
            f"🔍 *Voice Resonance Analysis*\n\n"
            f"Fundamental: *{analysis.fundamental_hz} Hz*\n"
            f"Root: {analysis.fundamental_root} ({analysis.fundamental_phase.name})\n"
            f"Giza proximity: {analysis.giza_proximity:.1%}\n"
            f"Tesla proximity: {analysis.tesla_proximity:.1%}\n"
            f"Coherence: {analysis.spectral_coherence:.1%}\n"
            f"Gate: {gate_emoji} {analysis.gate_status}\n\n"
            f"Top frequencies:\n" +
            "\n".join(f"  {'✓' if p['phase'] != 'ENTROPY' else '·'} {p['hz']} Hz (root {p['root']})"
                      for p in analysis.peaks[:5]),
            parse_mode="Markdown",
        )

        # Step 2: Transcription via whisper (if available) or skip
        transcription = ""
        try:
            import subprocess
            # Try whisper CLI (brew install openai-whisper or pipx install openai-whisper)
            result = subprocess.run(
                ["whisper", wav_path, "--model", "base", "--language", "pt",
                 "--output_format", "txt", "--output_dir", tempfile.gettempdir()],
                capture_output=True, text=True, timeout=60,
            )
            txt_path = Path(tempfile.gettempdir()) / (Path(wav_path).stem + ".txt")
            if txt_path.exists():
                transcription = txt_path.read_text().strip()
                txt_path.unlink()
                if transcription:
                    await update.message.reply_text(
                        f"📝 *Transcription:*\n_{transcription}_",
                        parse_mode="Markdown",
                    )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # whisper not installed or timed out — skip transcription
            logger.info("Whisper not available — skipping transcription")

        # Step 3: Build context for AI (voice metadata + transcription if available)
        voice_meta = (
            f"fundamental={analysis.fundamental_hz}Hz, "
            f"root={analysis.fundamental_root}, "
            f"giza_proximity={analysis.giza_proximity:.1%}, "
            f"spectral_coherence={analysis.spectral_coherence:.1%}, "
            f"gate={analysis.gate_status}"
        )

        if transcription:
            ai_message = (
                f"The user sent a voice message saying: \"{transcription}\"\n"
                f"Voice frequency analysis: [{voice_meta}]\n"
                f"Respond to what they said. Also briefly comment on their "
                f"vocal resonance if relevant."
            )
        else:
            ai_message = (
                f"The user sent a voice message (no transcription available).\n"
                f"Voice frequency analysis: [{voice_meta}]\n"
                f"Comment on their vocal resonance characteristics based on the data."
            )

        # Step 4: Send to AI with typing indicator
        await update.message.reply_text("🤖 Consulting the resonance field...")
        await update.message.reply_chat_action("typing")
        response = send(
            message=ai_message,
            backend="auto",
            resonance_metadata=voice_meta,
        )

        if response.success:
            resp_text = response.text[:4000]
            try:
                await update.message.reply_text(
                    f"{resp_text}\n\n_🔗 {response.backend}_",
                    parse_mode="Markdown",
                )
            except Exception:
                # Markdown parse error fallback
                await update.message.reply_text(
                    f"{resp_text}\n\n🔗 {response.backend}",
                )
        else:
            await update.message.reply_text(f"❌ AI unavailable: {response.error}")

    finally:
        # Cleanup
        for p in [ogg_path, wav_path]:
            try:
                os.unlink(p)
            except:
                pass


def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        print("Error: Set TELEGRAM_BOT_TOKEN environment variable.")
        print("Create a bot via @BotFather on Telegram.")
        sys.exit(1)

    app = Application.builder().token(token).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, handle_voice))

    logger.info("S.E.I.F. Telegram Bot starting...")
    logger.info(f"Backends: {detect_backends()}")
    logger.info(f"Context: {estimate_tokens()}")

    app.run_polling()


if __name__ == "__main__":
    main()
