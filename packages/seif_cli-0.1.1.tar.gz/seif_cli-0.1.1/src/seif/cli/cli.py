#!/usr/bin/env python3
"""
RPWP CLI — Resonance Proto-Writing Processor

Unified demo interface:
  PYTHONPATH=src python -m seif.cli "O amor liberta e guia"
  PYTHONPATH=src python -m seif.cli --gate "Tesla 369"
  PYTHONPATH=src python -m seif.cli --glyph "A Semente de Enoque"
  PYTHONPATH=src python -m seif.cli --audio "Love and Harmony"
  PYTHONPATH=src python -m seif.cli --fractal "O amor liberta e guia"
"""

import argparse
from pathlib import Path

from seif.core.resonance_gate import evaluate
from seif.analysis.transcompiler import transcompile, describe
from seif.generators.glyph_renderer import render, render_fractal_qr
from seif.generators.harmonic_audio import render_audio
from seif.generators.fractal_qrcode import generate_fractal_qr, describe as describe_fqr
from seif.generators.circuit_generator import generate_from_spec, render_svg
from seif.generators.composite_renderer import render_composite
from seif.core.resonance_encoding import encode_phrase, describe_melody


def cmd_quality_gate(text: str, role: str):
    from seif.analysis.quality_gate import assess, describe_verdict
    verdict = assess(text, role=role)
    print(describe_verdict(verdict))


def cmd_sync(repo_path: str, author: str, via: str):
    from seif.context.git_context import sync_project, extract_git_context
    ctx = extract_git_context(repo_path)
    print(f"Repository:    {ctx.repo_name}")
    print(f"Branch:        {ctx.branch}")
    print(f"Commits:       {ctx.total_commits}")
    print(f"Contributors:  {len(ctx.contributors)}")
    if ctx.manifest_type:
        print(f"Manifest:      {ctx.manifest_type}")
    if ctx.hot_files:
        print(f"Hot files:     {ctx.hot_files[0][0]} ({ctx.hot_files[0][1]}x)")
    print()
    module, path = sync_project(repo_path, author=author, via=via)
    print(f"Synced to:     {path}")
    print(f"  Version:     {module.version}")
    print(f"  Words:       {module.compressed_words}")
    print(f"  Hash:        {module.integrity_hash}")
    if module.parent_hash:
        print(f"  Parent:      {module.parent_hash}")


def cmd_contribute(module_path: str, text: str, author: str, via: str):
    from seif.context.context_manager import contribute_to_module
    module, path = contribute_to_module(module_path, text, author, via)
    print(f"Contributed to: {path}")
    print(f"  Version:      {module.version}")
    print(f"  Contributors: {len(module.contributors)}")
    print(f"  Words:        {module.compressed_words}")
    print(f"  Hash:         {module.integrity_hash}")
    print(f"  Parent hash:  {module.parent_hash}")


def cmd_composite(text: str):
    path = render_composite(text)
    print(f"Mapa de Ressonância Completo salvo: {path}")


def cmd_encode(text: str):
    melody = encode_phrase(text)
    print(describe_melody(melody))


def cmd_constants(text: str):
    from seif.analysis.physical_constants import describe_signature
    from seif.core.resonance_gate import evaluate
    result = evaluate(text)
    print(result)
    print()
    print(describe_signature(result.digital_root))


def cmd_circuit(text: str):
    spec = transcompile(text)
    layout = generate_from_spec(spec)
    path = render_svg(layout)
    print(f"Circuito SFA salvo: {path}")
    print(f"  Traces: {len(layout.traces)}, Pads: {len(layout.pads)}, Layers: {layout.layer_count}")


def cmd_analyze_artifact(image_path: str):
    from seif.analysis.artifact_analyzer import analyze, describe as desc_art, generate_overlay
    from seif.analysis.pattern_comparator import self_compare
    geo = analyze(image_path)
    print(desc_art(geo))
    overlay = generate_overlay(image_path, geo)
    print(f"\nOverlay salvo: {overlay}")
    report = self_compare(geo)
    print()
    print(report)


def cmd_gate(text: str):
    result = evaluate(text)
    print(result)


def cmd_transcompile(text: str):
    spec = transcompile(text)
    print(describe(spec))


def cmd_glyph(text: str):
    spec = transcompile(text)
    path = render(spec)
    print(f"Glifo salvo: {path}")


def cmd_audio(text: str):
    spec = transcompile(text)
    path = render_audio(spec)
    print(f"Áudio salvo: {path}")


def cmd_fractal(text: str):
    qr = generate_fractal_qr(text, max_depth=4)
    print(describe_fqr(qr))
    path = render_fractal_qr(qr)
    print(f"\nFractal QR salvo: {path}")


def cmd_all(text: str):
    print("=" * 60)
    print("RPWP — Processamento Completo")
    print("=" * 60)
    print()

    # 1. Gate
    result = evaluate(text)
    print(result)
    print()

    # 2. Transcompile
    spec = transcompile(text)
    print(describe(spec))
    print()

    # 3. Glyph
    glyph_path = render(spec)
    print(f"Glifo salvo: {glyph_path}")

    # 4. Audio
    audio_path = render_audio(spec)
    print(f"Áudio salvo: {audio_path}")

    # 5. Fractal QR
    qr = generate_fractal_qr(text, max_depth=4)
    print()
    print(describe_fqr(qr))
    qr_path = render_fractal_qr(qr)
    print(f"\nFractal QR salvo: {qr_path}")

    # 6. SFA Circuit
    layout = generate_from_spec(spec)
    circuit_path = render_svg(layout)
    print(f"Circuito SFA salvo: {circuit_path}")

    # 7. Composite Resonance Map
    composite_path = render_composite(text)
    print(f"Mapa de Ressonância Completo salvo: {composite_path}")

    print()
    print("=" * 60)
    print("Processamento completo.")


def main():
    parser = argparse.ArgumentParser(
        description="RPWP — Resonance Proto-Writing Processor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos:\n"
            '  PYTHONPATH=src python -m seif.cli "O amor liberta e guia"\n'
            '  PYTHONPATH=src python -m seif.cli --gate "Tesla 369"\n'
            '  PYTHONPATH=src python -m seif.cli --fractal "A Semente de Enoque"\n'
        ),
    )
    parser.add_argument("text", nargs="?", default="",
                        help="Texto de entrada ou caminho de imagem (com --artifact)")
    parser.add_argument("--gate", action="store_true", help="Apenas Porta de Ressonância")
    parser.add_argument("--transcompile", action="store_true", help="Apenas transcompilação")
    parser.add_argument("--glyph", action="store_true", help="Apenas glifo visual")
    parser.add_argument("--audio", action="store_true", help="Apenas áudio 432Hz")
    parser.add_argument("--fractal", action="store_true", help="Apenas Fractal QR-Code")
    parser.add_argument("--circuit", action="store_true", help="Apenas circuito SFA (SVG)")
    parser.add_argument("--composite", action="store_true", help="Mapa de Ressonância Completo (selo + hardware)")
    parser.add_argument("--encode", action="store_true", help="Resonance Encoding (φ-spiral frequencies)")
    parser.add_argument("--artifact", action="store_true", help="Analisar imagem de artefato antigo")
    parser.add_argument("--all", action="store_true", help="Pipeline completo (padrão)")
    parser.add_argument("--quality-gate", action="store_true",
                        help="Quality Gate: unified stance + resonance verdict")
    parser.add_argument("--role", default="human", choices=["human", "ai"],
                        help="Role of the text author (for --quality-gate)")
    parser.add_argument("--sync", nargs="?", const=".", metavar="REPO_PATH",
                        help="Auto-generate .seif from git context (default: current dir)")
    parser.add_argument("--contribute", metavar="MODULE_PATH",
                        help="Contribute to an existing .seif module (text = contribution content)")
    parser.add_argument("--author", default="unknown", help="Author name for --contribute/--sync")
    parser.add_argument("--via", default="git", help="Tool/model used for --contribute/--sync")

    args = parser.parse_args()

    if args.sync is not None:
        cmd_sync(args.sync, args.author, args.via)
        return

    if args.quality_gate:
        if not args.text:
            parser.error("text is required for --quality-gate")
        cmd_quality_gate(args.text, args.role)
        return

    if args.contribute:
        cmd_contribute(args.contribute, args.text, args.author, args.via)
        return

    if not args.text:
        parser.error("text is required (unless using --sync)")

    flags = [args.gate, args.transcompile, args.glyph, args.audio,
             args.fractal, args.circuit, args.composite, args.encode, args.artifact, args.all]
    if not any(flags):
        args.all = True

    if args.artifact:
        cmd_analyze_artifact(args.text)
    elif args.gate:
        cmd_gate(args.text)
    elif args.transcompile:
        cmd_transcompile(args.text)
    elif args.glyph:
        cmd_glyph(args.text)
    elif args.audio:
        cmd_audio(args.text)
    elif args.fractal:
        cmd_fractal(args.text)
    elif args.circuit:
        cmd_circuit(args.text)
    elif args.composite:
        cmd_composite(args.text)
    elif args.encode:
        cmd_encode(args.text)
    else:
        cmd_all(args.text)


if __name__ == "__main__":
    main()
