"""Milestone Planner agent — wraps planners.MilestonePlanner."""
from __future__ import annotations

from ..planners.milestone_planner import MilestonePlanner as _CorePlanner
from ..schemas import ArchitectureSpec, Language, Milestone, Scale
from ._crewai_bridge import make_agent


class MilestonePlannerAgent:
    def __init__(self) -> None:
        self.core = _CorePlanner()
        self.agent = make_agent(
            role="Milestone Planner",
            goal="Slice delivery into 3-8 verifiable milestones with acceptance criteria.",
            backstory="A delivery lead who turns architecture into checkpoints.",
        )

    def plan(
        self,
        *,
        architecture: ArchitectureSpec,
        languages: list[Language],
        max_milestones: int = 6,
        scale: Scale | None = None,
    ) -> list[Milestone]:
        return self.core.plan(architecture=architecture, languages=languages, max_milestones=max_milestones, scale=scale)


# BMAD-17: register agent menu at module load time
from ..schemas import AgentMenuEntry  # noqa: E402
from ._menu import register_default_menu  # noqa: E402

register_default_menu("milestone_planner", [
    AgentMenuEntry(code="PM", description="Plan milestones from architecture", skill="milestone_planner"),
    AgentMenuEntry(code="SM", description="Show milestone summary", skill="milestone_planner"),
])
