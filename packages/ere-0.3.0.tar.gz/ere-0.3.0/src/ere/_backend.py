from __future__ import annotations

import contextlib
import warnings

import polars as pl


def _ensure_eager(df: pl.DataFrame | pl.LazyFrame) -> pl.DataFrame:
    return df.collect() if isinstance(df, pl.LazyFrame) else df


@contextlib.contextmanager
def _suppress_sortedness_warning():
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="Sortedness of columns cannot be checked",
            category=UserWarning,
        )
        yield
