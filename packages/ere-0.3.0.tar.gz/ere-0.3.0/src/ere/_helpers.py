from __future__ import annotations

from datetime import timedelta

import polars as pl

from ere._backend import _ensure_eager
from ere._types import TemporalSpec


def tag_knowledge_date(
    df: pl.DataFrame | pl.LazyFrame,
    ref_date_col: str,
    lag_days: int,
    knowledge_date_col: str = "knowledge_date",
) -> pl.DataFrame:
    """Add a knowledge_date column computed as ref_date + lag_days."""
    return _ensure_eager(df).with_columns(
        (pl.col(ref_date_col) + timedelta(days=lag_days)).alias(knowledge_date_col)
    )


def deduplicate(df: pl.DataFrame | pl.LazyFrame, spec: TemporalSpec) -> pl.DataFrame:
    """Remove duplicate rows by (entity, ref_date, knowledge_date).

    When multiple rows share the same key, one is kept arbitrarily.
    """
    return _ensure_eager(df).unique(subset=spec.dedup_keys())
