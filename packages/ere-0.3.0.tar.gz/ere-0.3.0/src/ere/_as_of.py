from __future__ import annotations

from typing import Any, overload

import polars as pl

from ere._backend import _ensure_eager
from ere._dispatch import _SourceSet
from ere._snapshot import _Snapshotter
from ere._types import DateLike, Sources, TemporalSpec, _coerce_date


def _as_of_single(
    df: pl.DataFrame | pl.LazyFrame,
    query_date: DateLike,
    spec: TemporalSpec,
) -> pl.DataFrame:
    """Single-frame PIT snapshot."""
    qd = _coerce_date(query_date)
    filtered = _ensure_eager(df).filter(pl.col(spec.knowledge_date) <= qd)
    return spec.resolve_latest(filtered)


def _as_of_multi(
    sources: _SourceSet,
    query_date: DateLike,
    *,
    strategy: str = "backward",
) -> Any:
    """Multi-source PIT snapshot: align each source, asof-join into one frame.

    A single-source list/dict short-circuits to ``_as_of_single`` (the proven
    filter path) to avoid the multi-source join_where overhead.
    """
    if len(sources.items) == 1:
        _, frame, spec = sources.items[0]
        return _as_of_single(frame, query_date, spec)
    return _Snapshotter(sources, strategy=strategy).at(query_date)


@overload
def as_of(
    source: Any,
    query_date: DateLike,
    spec: TemporalSpec,
) -> Any: ...
@overload
def as_of(
    source: Any,
    query_date: DateLike,
    *,
    ref_date: str,
    knowledge_date: str,
    entity: str | None = ...,
) -> Any: ...
@overload
def as_of(
    source: Sources,
    query_date: DateLike,
    *,
    strategy: str = ...,
) -> Any: ...


def as_of(
    source: Any,
    query_date: DateLike,
    spec: TemporalSpec | None = None,
    *,
    ref_date: str | None = None,
    knowledge_date: str | None = None,
    entity: str | None = None,
    strategy: str = "backward",
) -> Any:
    """Return a point-in-time snapshot as knowable at *query_date*.

    *source* may be:

    - A single polars frame plus ``spec`` / spec kwargs — the result is the
      PIT-filtered frame, every row satisfying ``knowledge_date <= query_date``.
    - A list ``[(frame, spec), ...]`` or dict ``{name: (frame, spec), ...}``
      of sources — the result is a single frame with all sources
      asof-joined on the union date grid. Entity-less sources broadcast
      across entities. ``strategy`` controls the asof direction
      (default ``"backward"``).

    Example::

        snap = ere.as_of(prices, "2025-02-15", spec=PRICES)
        snap = ere.as_of([(prices, PRICES), (earnings, EARNINGS)], "2025-02-15")
    """
    if isinstance(source, (list, dict)):
        ss = _SourceSet.from_user_input(
            source,
            spec=spec,
            ref_date=ref_date,
            knowledge_date=knowledge_date,
            entity=entity,
        )
        return _as_of_multi(ss, query_date, strategy=strategy)

    s = TemporalSpec.from_loose(
        spec, ref_date=ref_date, knowledge_date=knowledge_date, entity=entity
    )
    return _as_of_single(source, query_date, s)
