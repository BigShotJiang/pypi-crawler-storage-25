from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any

DateLike = date | datetime | str


def _coerce_date(d: DateLike) -> date:
    if isinstance(d, date):
        return d
    return date.fromisoformat(d)


def _coerce_temporal(d: DateLike) -> date | datetime:
    if isinstance(d, (datetime, date)):
        return d
    try:
        return datetime.fromisoformat(d)
    except ValueError:
        return date.fromisoformat(d)


@dataclass(frozen=True)
class TemporalSpec:
    """Binds column names to temporal roles.

    ``knowledge_date`` defaults to ``ref_date`` when omitted — the right
    semantics for data known when stamped (prices, returns, index membership,
    ...). Pass it explicitly only when there's a real restatement timeline
    (e.g. fiscal_quarter_end vs. filing_date).
    """

    ref_date: str
    knowledge_date: str = None  # type: ignore[assignment]
    entity: str | None = None

    def __post_init__(self) -> None:
        if self.knowledge_date is None:
            object.__setattr__(self, "knowledge_date", self.ref_date)

    def is_universal(self) -> bool:
        """True iff this spec has no entity column (broadcasts across entities)."""
        return self.entity is None

    def group_keys(self, prefix: str | None = None) -> list[str]:
        """Group-by keys for version resolution: [prefix?, entity?, ref_date]."""
        keys: list[str] = []
        if prefix is not None:
            keys.append(prefix)
        if self.entity is not None:
            keys.append(self.entity)
        keys.append(self.ref_date)
        return keys

    def dedup_keys(self) -> list[str]:
        """Uniqueness keys: [entity?, ref_date, knowledge_date]."""
        keys: list[str] = []
        if self.entity is not None:
            keys.append(self.entity)
        keys.extend((self.ref_date, self.knowledge_date))
        return keys

    def entity_columns(self) -> list[str]:
        """Return ``[entity]`` when set, else ``[]``."""
        return [self.entity] if self.entity is not None else []

    def asof_join_by(self, query_date_col: str | None = None) -> str | list[str]:
        """``by=`` argument for ``join_asof``: optional query-date col + entity."""
        keys: list[str] = []
        if query_date_col is not None:
            keys.append(query_date_col)
        if self.entity is not None:
            keys.append(self.entity)
        return keys[0] if len(keys) == 1 else keys

    def resolve_latest(self, frame: Any, *, prefix: str | None = None) -> Any:
        """Sort by knowledge_date, group by [prefix?, entity?, ref_date], keep last."""
        return (
            frame.sort(self.knowledge_date)
            .group_by(self.group_keys(prefix=prefix), maintain_order=True)
            .last()
        )

    @staticmethod
    def assert_compatible_many(specs: Iterable[TemporalSpec]) -> None:
        """Set-of-defined compatibility: among non-universal specs, at most one entity name."""
        names = {s.entity for s in specs if s.entity is not None}
        if len(names) > 1:
            raise ValueError(f"Entity column names must match across specs, got: {sorted(names)}")

    @classmethod
    def from_loose(
        cls,
        spec: TemporalSpec | None = None,
        *,
        ref_date: str | None = None,
        knowledge_date: str | None = None,
        entity: str | None = None,
    ) -> TemporalSpec:
        """Accept a spec or individual kwargs; return a TemporalSpec either way.

        ``knowledge_date`` is optional and defaults to ``ref_date``.
        """
        if spec is not None:
            return spec
        if ref_date is None:
            raise ValueError("Either 'spec' or 'ref_date' must be provided")
        return cls(ref_date=ref_date, knowledge_date=knowledge_date, entity=entity)


Source = tuple[Any, TemporalSpec]
"""A (frame, spec) pair. The frame is a polars DataFrame or LazyFrame."""

Sources = list[Source] | dict[str, Source]
"""A collection of (frame, spec) pairs. Lists preserve order; dicts give named access."""
