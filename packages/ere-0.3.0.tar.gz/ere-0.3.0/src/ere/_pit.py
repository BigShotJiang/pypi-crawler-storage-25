from __future__ import annotations

from collections.abc import Callable
from datetime import date, timedelta
from typing import Any

import polars as pl

from ere._backend import _suppress_sortedness_warning
from ere._dispatch import _SourceSet
from ere._merge import _merge
from ere._snapshot import _Snapshotter
from ere._types import DateLike, TemporalSpec, _coerce_temporal

_QUERY_DATE_COL = "__ere_query_date"


def _pit_lazy_single(
    df: pl.DataFrame | pl.LazyFrame,
    spec: TemporalSpec,
    dates: list[DateLike] | pl.Series,
    *,
    lookback: int | timedelta | None = None,
    query_date_column: str = _QUERY_DATE_COL,
) -> pl.LazyFrame:
    """Per-source multi-date PIT alignment via inequality join.

    Returns a LazyFrame of resolved rows across all *dates*, tagged by
    *query_date_column*.
    """
    lf = df.lazy() if isinstance(df, pl.DataFrame) else df

    if query_date_column in lf.collect_schema().names():
        raise ValueError(
            f"Column {query_date_column!r} already exists in DataFrame. "
            f"Pass a different query_date_column= to avoid collision."
        )

    if isinstance(dates, pl.Series):
        dates_s = dates.unique().sort().alias(query_date_column)
    else:
        if not dates:
            return lf.head(0).with_columns(pl.lit(None, dtype=pl.Date).alias(query_date_column))
        coerced = sorted(set(_coerce_temporal(d) for d in dates))
        dates_s = pl.Series(query_date_column, coerced)

    dates_lf = dates_s.to_frame().lazy()

    predicates: list[pl.Expr] = [
        pl.col(spec.knowledge_date) <= pl.col(query_date_column),
    ]
    if lookback is not None:
        lb = timedelta(days=lookback) if isinstance(lookback, int) else lookback
        predicates.append(pl.col(spec.ref_date) >= pl.col(query_date_column) - lb)

    joined = dates_lf.join_where(lf, *predicates)

    return spec.resolve_latest(joined, prefix=query_date_column)


class _Panel:
    """Internal handle for a multi-date PIT result tagged by query-date sentinel."""

    __slots__ = ("_lf", "_qd_col", "_strategy")

    def __init__(
        self,
        lf: pl.LazyFrame,
        query_date_column: str = _QUERY_DATE_COL,
        strategy: str = "backward",
    ) -> None:
        self._lf = lf
        self._qd_col = query_date_column
        self._strategy = strategy

    @property
    def query_date_column(self) -> str:
        return self._qd_col

    @property
    def strategy(self) -> str:
        return self._strategy

    def lazy(self) -> pl.LazyFrame:
        """Raw tagged LazyFrame, sentinel column intact."""
        return self._lf

    def map(self, fn: Callable[[pl.DataFrame], pl.DataFrame]) -> pl.DataFrame:
        """Apply *fn* per snapshot and re-attach the sentinel column.

        *fn* receives a polars snapshot without the sentinel column and must
        return a polars frame.
        """
        with _suppress_sortedness_warning():
            resolved = self._lf.collect()
        if len(resolved) == 0:
            return resolved

        qd_col = self._qd_col

        def _wrapper(group_df: pl.DataFrame) -> pl.DataFrame:
            qd = group_df[qd_col][0]
            out = fn(group_df.drop(qd_col))
            return out.with_columns(pl.lit(qd).alias(qd_col))

        return resolved.group_by(qd_col, maintain_order=True).map_groups(_wrapper)

    @classmethod
    def from_resolved(
        cls,
        sources: _SourceSet,
        dates: list[DateLike] | pl.Series,
        *,
        lookback: int | timedelta | None,
        query_date_column: str = _QUERY_DATE_COL,
        strategy: str = "backward",
    ) -> _Panel:
        """Build a ``_Panel`` from a validated ``_SourceSet``."""
        aligned = [
            (
                key,
                _pit_lazy_single(
                    frame,
                    spec,
                    dates,
                    lookback=lookback,
                    query_date_column=query_date_column,
                ),
                spec,
            )
            for key, frame, spec in sources.items
        ]
        if len(aligned) == 1:
            lf = aligned[0][1]
        else:
            lf = _merge(aligned, query_date_col=query_date_column, strategy=strategy)
        return cls(lf, query_date_column, strategy)

    @classmethod
    def from_snapshotter(
        cls,
        snap: _Snapshotter,
        dates: list[DateLike] | pl.Series,
        *,
        lookback: int | timedelta | None = None,
        strategy: str = "backward",
    ) -> _Panel:
        """Build a ``_Panel`` by concatenating per-date plans from a ``_Snapshotter``.

        Used by eager panel paths that want the query-date-tagged ``_Panel``
        handle (``.lazy()``, ``.map(fn)``) but built from presorted slices
        rather than one big ``join_where``.
        """
        if isinstance(dates, pl.Series):
            date_list: list[Any] = list(dates.unique().sort())
        else:
            date_list = sorted(set(_coerce_temporal(d) for d in dates))
        qd_col = snap.query_date_column
        if not date_list:
            empty_plan = snap.lazy_at(date(1, 1, 1), lookback=lookback).head(0)
            return cls(empty_plan, qd_col, strategy)
        plan = pl.concat([snap.lazy_at(d, lookback=lookback) for d in date_list])
        return cls(plan, qd_col, strategy)
