from __future__ import annotations

import polars as pl

from ere._backend import _ensure_eager
from ere._types import DateLike, TemporalSpec, _coerce_date


def validate(
    df: pl.DataFrame | pl.LazyFrame,
    spec: TemporalSpec | None = None,
    *,
    ref_date: str | None = None,
    knowledge_date: str | None = None,
    entity: str | None = None,
) -> None:
    """Validate that a polars frame has the required temporal structure.

    Raises ValueError listing all violations found.
    """
    s = TemporalSpec.from_loose(
        spec, ref_date=ref_date, knowledge_date=knowledge_date, entity=entity
    )

    df = _ensure_eager(df)

    errors: list[str] = []

    cols = set(df.columns)
    for name, role in [(s.ref_date, "ref_date"), (s.knowledge_date, "knowledge_date")]:
        if name not in cols:
            errors.append(f"Column '{name}' ({role}) not found in DataFrame")
    for name in s.entity_columns():
        if name not in cols:
            errors.append(f"Column '{name}' (entity) not found in DataFrame")

    if errors:
        raise ValueError("Validation failed:\n" + "\n".join(f"  - {e}" for e in errors))

    date_types = (pl.Date, pl.Datetime)
    for name, role in [(s.ref_date, "ref_date"), (s.knowledge_date, "knowledge_date")]:
        if df[name].dtype not in date_types:
            errors.append(
                f"Column '{name}' ({role}) has dtype {df[name].dtype}, expected Date or Datetime"
            )
        null_count = df[name].null_count()
        if null_count > 0:
            errors.append(f"Column '{name}' ({role}) has {null_count} null values")

    for name in s.entity_columns():
        null_count = df[name].null_count()
        if null_count > 0:
            errors.append(f"Column '{name}' (entity) has {null_count} null values")

    if not errors:
        violations = df.filter(pl.col(s.knowledge_date) < pl.col(s.ref_date))
        if len(violations) > 0:
            errors.append(f"{len(violations)} rows have knowledge_date < ref_date (time travel)")

    if errors:
        raise ValueError("Validation failed:\n" + "\n".join(f"  - {e}" for e in errors))


def audit(
    df: pl.DataFrame | pl.LazyFrame,
    as_of_date: DateLike,
    spec: TemporalSpec | None = None,
    *,
    knowledge_date_col: str = "knowledge_date",
) -> None:
    """Assert no look-ahead: every row must satisfy knowledge_date <= as_of_date.

    Pass ``spec`` to reuse an existing TemporalSpec, or override ``knowledge_date_col``
    directly. Raises AssertionError on any violation.
    """
    col = spec.knowledge_date if spec is not None else knowledge_date_col
    df = _ensure_eager(df)

    query_date = _coerce_date(as_of_date)
    violations = df.filter(pl.col(col) > query_date)
    assert len(violations) == 0, f"Audit failed: {len(violations)} rows have {col} > {query_date}"
