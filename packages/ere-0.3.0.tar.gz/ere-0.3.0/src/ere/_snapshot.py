from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import TYPE_CHECKING, Any

import numpy as np
import polars as pl

from ere._backend import _ensure_eager, _suppress_sortedness_warning
from ere._merge import _merge
from ere._types import DateLike, TemporalSpec, _coerce_temporal

if TYPE_CHECKING:
    from ere._dispatch import _SourceSet


_QUERY_DATE_COL = "__ere_query_date"


class _Snapshotter:
    """Internal eager PIT engine.

    Presort each source by ``knowledge_date`` once at construction and serve
    per-date snapshots via ``np.searchsorted`` + slice + per-snapshot
    ``resolve_latest``. Lifetime is one public-call frame — no state leaks
    past return.
    """

    __slots__ = ("_presorted", "_strategy", "_qd_col")

    def __init__(
        self,
        sources: _SourceSet,
        *,
        strategy: str = "backward",
        query_date_column: str = _QUERY_DATE_COL,
    ) -> None:
        presorted: list[tuple[Any, pl.DataFrame, np.ndarray, TemporalSpec, bool]] = []
        for key, frame, spec in sources.items:
            eager = _ensure_eager(frame)
            if query_date_column in eager.columns:
                raise ValueError(
                    f"Column {query_date_column!r} already exists in DataFrame. "
                    f"Pass a different query_date_column= to avoid collision."
                )
            eager = eager.sort(spec.knowledge_date)
            np_kd = eager[spec.knowledge_date].to_numpy()
            unique_subset = spec.entity_columns() + [spec.ref_date]
            has_collisions = (
                eager.height > 0 and eager.n_unique(subset=unique_subset) != eager.height
            )
            presorted.append((key, eager, np_kd, spec, has_collisions))
        self._presorted = presorted
        self._strategy = strategy
        self._qd_col = query_date_column

    @property
    def query_date_column(self) -> str:
        return self._qd_col

    @staticmethod
    def _slice(
        presorted_df: pl.DataFrame,
        np_kd: np.ndarray,
        spec: TemporalSpec,
        asof_d: date | datetime,
        lookback: int | timedelta | None,
        has_collisions: bool,
    ) -> pl.DataFrame:
        if np_kd.dtype.kind == "M":
            asof_np: Any = np.datetime64(asof_d).astype(np_kd.dtype)
        else:
            asof_np = asof_d
        k = int(np.searchsorted(np_kd, asof_np, side="right"))
        snap = presorted_df.head(k)
        if lookback is not None:
            lb = timedelta(days=lookback) if isinstance(lookback, int) else lookback
            snap = snap.filter(pl.col(spec.ref_date) >= asof_d - lb)
        if has_collisions:
            return spec.resolve_latest(snap)
        return snap

    def at(
        self,
        asof: DateLike,
        *,
        lookback: int | timedelta | None = None,
    ) -> pl.DataFrame:
        """Eager snapshot at one query date. Output excludes the query-date column."""
        asof_d = _coerce_temporal(asof)
        if len(self._presorted) == 1:
            _, presorted_df, np_kd, spec, has_collisions = self._presorted[0]
            return self._slice(presorted_df, np_kd, spec, asof_d, lookback, has_collisions)
        with _suppress_sortedness_warning():
            return self.lazy_at(asof_d, lookback=lookback).collect().drop(self._qd_col)

    def lazy_at(
        self,
        asof: DateLike,
        *,
        lookback: int | timedelta | None = None,
    ) -> pl.LazyFrame:
        """Merged lazy plan for one query date, tagged with the query-date column."""
        asof_d = _coerce_temporal(asof)
        per_source: list[tuple[Any, pl.LazyFrame, TemporalSpec]] = []
        for key, presorted_df, np_kd, spec, has_collisions in self._presorted:
            snap = self._slice(presorted_df, np_kd, spec, asof_d, lookback, has_collisions)
            tagged = snap.lazy().with_columns(pl.lit(asof_d).alias(self._qd_col))
            per_source.append((key, tagged, spec))
        if len(per_source) == 1:
            return per_source[0][1]
        return _merge(per_source, query_date_col=self._qd_col, strategy=self._strategy)
