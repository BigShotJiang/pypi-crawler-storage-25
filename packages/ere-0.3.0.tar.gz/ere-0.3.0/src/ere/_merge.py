from __future__ import annotations

from typing import Any

import polars as pl

from ere._types import TemporalSpec


def _build_spine_lazy(
    aligned: list[tuple[Any, pl.LazyFrame, TemporalSpec]],
    ref_col: str,
    entity_col: str | None,
    query_date_col: str,
) -> pl.LazyFrame:
    """Union of (query_date, ref_date) across sources, cross-joined with entities."""
    spine = pl.concat(
        [lf.select(query_date_col, pl.col(spec.ref_date).alias(ref_col)) for _, lf, spec in aligned]
    ).unique()

    if entity_col is not None:
        entities = pl.concat(
            [
                lf.select(pl.col(spec.entity).alias(entity_col))
                for _, lf, spec in aligned
                if spec.entity is not None
            ]
        ).unique()
        spine = spine.join(entities, how="cross")

    return spine


def _merge(
    aligned: list[tuple[Any, pl.LazyFrame, TemporalSpec]],
    *,
    query_date_col: str,
    strategy: str = "backward",
) -> pl.LazyFrame:
    """Asof-join per-source aligned snapshots into a single LazyFrame.

    The first source's ``ref_date`` column name becomes the output's
    ref-date column. Entity-less sources broadcast across entities via a
    cross-join on the spine. Single-source input is returned unchanged.
    """
    if len(aligned) == 1:
        return aligned[0][1]

    first_spec = aligned[0][2]
    ref_col = first_spec.ref_date
    entity_col = next(
        (spec.entity for _, _, spec in aligned if spec.entity is not None),
        None,
    )

    spine = _build_spine_lazy(aligned, ref_col, entity_col, query_date_col)

    ent_sort = [entity_col] if entity_col is not None else []
    acc = spine.sort(query_date_col, *ent_sort, ref_col)

    for _, lf, spec in aligned:
        has_ent = entity_col is not None and spec.entity is not None
        by: str | list[str] = [query_date_col, entity_col] if has_ent else query_date_col
        right_sort = [query_date_col, *spec.entity_columns(), spec.ref_date]

        acc = acc.sort(query_date_col, *ent_sort, ref_col).join_asof(
            lf.sort(*right_sort),
            left_on=ref_col,
            right_on=spec.ref_date,
            by=by,
            strategy=strategy,
        )

    return acc
