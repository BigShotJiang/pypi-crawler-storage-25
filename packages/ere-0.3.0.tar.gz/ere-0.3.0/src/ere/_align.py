from __future__ import annotations

from typing import Any

from ere._as_of import _as_of_single
from ere._dispatch import _SourceSet
from ere._types import DateLike, Sources


def align(sources: Sources, date: DateLike) -> list[Any] | dict[str, Any]:
    """Per-source point-in-time snapshots at a single date.

    Returns one frame per source. The return type mirrors the input shape:
    list in → list out (preserving position), dict in → dict out.

    Example::

        sources = [(prices, PRICES), (earnings, EARNINGS)]
        snaps = ere.align(sources, "2025-02-15")  # -> [prices_snap, earn_snap]

        named = {"prices": (prices, PRICES), "earnings": (earnings, EARNINGS)}
        snaps = ere.align(named, "2025-02-15")    # -> {"prices": ..., "earnings": ...}
    """
    ss = _SourceSet.from_user_input(sources)
    snapshots = [(key, _as_of_single(frame, date, spec)) for key, frame, spec in ss.items]

    if ss.shape is dict:
        return {str(key): snap for key, snap in snapshots}
    return [snap for _, snap in snapshots]
