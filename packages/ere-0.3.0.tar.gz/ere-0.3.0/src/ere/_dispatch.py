from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ere._types import Sources, TemporalSpec


@dataclass(frozen=True)
class _SourceSet:
    """Validated collection of ``(key, frame, spec)`` triples from user input."""

    items: list[tuple[str | int, Any, TemporalSpec]]
    shape: type
    is_single: bool

    @classmethod
    def from_user_input(
        cls,
        source: Any,
        spec: TemporalSpec | None = None,
        *,
        ref_date: str | None = None,
        knowledge_date: str | None = None,
        entity: str | None = None,
    ) -> _SourceSet:
        if isinstance(source, (list, dict)):
            cls._reject_spec_kwargs(
                spec=spec,
                ref_date=ref_date,
                knowledge_date=knowledge_date,
                entity=entity,
            )
            items = cls._normalise_collection(source)
            if not items:
                raise ValueError("sources must contain at least one (frame, spec) pair")
            TemporalSpec.assert_compatible_many(s for _, _, s in items)
            return cls(items=items, shape=type(source), is_single=False)

        s = TemporalSpec.from_loose(
            spec,
            ref_date=ref_date,
            knowledge_date=knowledge_date,
            entity=entity,
        )
        return cls(
            items=[(0, source, s)],
            shape=list,
            is_single=True,
        )

    @property
    def specs(self) -> list[TemporalSpec]:
        return [s for _, _, s in self.items]

    @property
    def is_universal(self) -> bool:
        return all(s.is_universal() for s in self.specs)

    @staticmethod
    def _normalise_collection(source: Sources) -> list[tuple[str | int, Any, TemporalSpec]]:
        if isinstance(source, dict):
            pairs_iter: Any = source.items()
        else:
            pairs_iter = enumerate(source)

        out: list[tuple[str | int, Any, TemporalSpec]] = []
        for key, pair in pairs_iter:
            if not (
                isinstance(pair, tuple) and len(pair) == 2 and isinstance(pair[1], TemporalSpec)
            ):
                raise TypeError(
                    f"Each source must be a (frame, TemporalSpec) tuple; "
                    f"got {type(pair).__name__} at key {key!r}"
                )
            out.append((key, pair[0], pair[1]))
        return out

    @staticmethod
    def _reject_spec_kwargs(**extras: Any) -> None:
        if any(v is not None for v in extras.values()):
            raise ValueError(
                "When passing a list/dict of sources, each element carries its own "
                "TemporalSpec; do not pass spec= or ref_date=/knowledge_date= kwargs."
            )
