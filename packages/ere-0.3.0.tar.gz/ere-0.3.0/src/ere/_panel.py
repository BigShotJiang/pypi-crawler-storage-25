from __future__ import annotations

from collections.abc import Callable, Generator
from datetime import date, datetime, timedelta
from typing import Any, overload

import polars as pl

from ere._dispatch import _SourceSet
from ere._pit import _QUERY_DATE_COL, _Panel
from ere._snapshot import _Snapshotter
from ere._types import DateLike, Sources, TemporalSpec, _coerce_temporal


@overload
def panel_lazy(
    source: pl.DataFrame | pl.LazyFrame,
    spec: TemporalSpec,
    dates: list[DateLike] | pl.Series,
    *,
    lookback: int | timedelta | None = ...,
    query_date_column: str = ...,
) -> pl.LazyFrame: ...
@overload
def panel_lazy(
    source: Sources,
    spec: None = ...,
    dates: list[DateLike] | pl.Series = ...,
    *,
    lookback: int | timedelta | None = ...,
    query_date_column: str = ...,
    strategy: str = ...,
) -> pl.LazyFrame: ...


def panel_lazy(
    source: Any,
    spec: TemporalSpec | None = None,
    dates: list[DateLike] | pl.Series | None = None,
    *,
    lookback: int | timedelta | None = None,
    query_date_column: str = _QUERY_DATE_COL,
    strategy: str = "backward",
) -> pl.LazyFrame:
    """Fully lazy multi-date PIT snapshots via inequality join.

    Accepts a single frame + spec, or a list/dict of (frame, spec) sources.
    Returns a single LazyFrame with all resolved snapshots tagged by
    *query_date_column*.
    """
    if dates is None:
        raise ValueError("dates is required")
    ss = _SourceSet.from_user_input(source, spec=spec)
    return _Panel.from_resolved(
        ss,
        dates,
        lookback=lookback,
        query_date_column=query_date_column,
        strategy=strategy,
    ).lazy()


@overload
def panel(
    source: Any,
    spec: TemporalSpec,
    dates: list[DateLike] | list[date],
    lookback: int | timedelta | None = ...,
) -> dict[date, Any]: ...
@overload
def panel(
    source: Sources,
    spec: None = ...,
    dates: list[DateLike] | list[date] = ...,
    lookback: int | timedelta | None = ...,
    *,
    strategy: str = ...,
) -> dict[date, Any]: ...


def panel(
    source: Any,
    spec: TemporalSpec | None = None,
    dates: list[DateLike] | list[date] | None = None,
    lookback: int | timedelta | None = None,
    *,
    strategy: str = "backward",
) -> dict[date, Any]:
    """Multi-date PIT snapshots with lookback filtering.

    Returns ``{date: frame}``. Accepts a single frame + spec, or a list/dict
    of (frame, spec) sources — each snapshot in the dict is then the merged
    asof-join of all sources at that date.
    """
    return dict(panel_iter(source, spec, dates, lookback, strategy=strategy))


def panel_iter(
    source: Any,
    spec: TemporalSpec | None = None,
    dates: list[DateLike] | list[date] | None = None,
    lookback: int | timedelta | None = None,
    *,
    strategy: str = "backward",
) -> Generator[tuple[date, Any]]:
    """Iterator version of panel(). Yields ``(date, frame)`` pairs.

    Dates with no resolved rows are skipped (no empty-frame yields).
    """
    if dates is None or not dates:
        return

    ss = _SourceSet.from_user_input(source, spec=spec)
    snap = _Snapshotter(ss, strategy=strategy)
    if isinstance(dates, pl.Series):
        date_list: list[Any] = list(dates.unique().sort())
    else:
        date_list = sorted(set(_coerce_temporal(d) for d in dates))
    for d in date_list:
        frame = snap.at(d, lookback=lookback)
        if frame.height > 0:
            key = d.date() if isinstance(d, datetime) else d
            yield key, frame


@overload
def panel_map(
    source: Any,
    spec: TemporalSpec,
    dates: list[DateLike] | pl.Series,
    fn: Callable[[Any], Any],
    *,
    lookback: int | timedelta | None = ...,
    query_date_column: str = ...,
) -> Any: ...
@overload
def panel_map(
    source: Sources,
    spec: None = ...,
    dates: list[DateLike] | pl.Series = ...,
    fn: Callable[[Any], Any] = ...,
    *,
    lookback: int | timedelta | None = ...,
    query_date_column: str = ...,
    strategy: str = ...,
) -> Any: ...


def panel_map(
    source: Any,
    spec: TemporalSpec | None = None,
    dates: list[DateLike] | pl.Series | None = None,
    fn: Callable[[Any], Any] | None = None,
    *,
    lookback: int | timedelta | None = None,
    query_date_column: str = _QUERY_DATE_COL,
    strategy: str = "backward",
) -> Any:
    """Apply a Python function to each PIT snapshot.

    *fn* receives a polars snapshot (without the query-date column) and must
    return a polars frame. The query-date column is re-attached automatically.

    Accepts single frame + spec, or list/dict of (frame, spec) sources.
    """
    if fn is None:
        raise ValueError("fn is required")
    if dates is None:
        raise ValueError("dates is required")
    ss = _SourceSet.from_user_input(source, spec=spec)
    snap = _Snapshotter(ss, strategy=strategy, query_date_column=query_date_column)
    return _Panel.from_snapshotter(snap, dates, lookback=lookback, strategy=strategy).map(fn)
