"""ere — Point-in-time data operations for quantitative research."""

from importlib.metadata import version

__version__ = version("ere")

from ere._align import align
from ere._as_of import as_of
from ere._helpers import deduplicate, tag_knowledge_date
from ere._panel import panel, panel_iter, panel_lazy, panel_map
from ere._types import DateLike, Sources, TemporalSpec
from ere._validate import audit, validate

__all__ = [
    "__version__",
    "DateLike",
    "Sources",
    "TemporalSpec",
    "align",
    "as_of",
    "audit",
    "deduplicate",
    "panel",
    "panel_iter",
    "panel_lazy",
    "panel_map",
    "tag_knowledge_date",
    "validate",
]
