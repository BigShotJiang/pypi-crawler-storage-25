from fbnconfig import Deployment, horizon


def configure(_):
    instance = horizon.IntegrationInstanceResource(
        id="copp-clark-instance",
        integration_type="copp-clark",
        name="cc2",
        description="my modified cc",
        enabled=True,
        triggers=[
            horizon.Trigger(
                type="time",
                cron_expression="0 13 0 ? * *",
                time_zone="Europe/London",
            )
        ],
        details={
            "paymentSystemsCalendar": {
                "currencyFilter": [
                  "GBP"
                ],
                "importUnqualified": False
            }
        }
    )

    return Deployment("example-copp-clark", [instance])
