"""Apply field descriptions from the JSON report to Python source docstrings.

Reads field_descriptions.json and updates class docstrings in fbnconfig/*.py
with Attributes sections. Existing descriptions are preserved. Attributes
are sorted alphabetically. Lines are wrapped to stay within the ruff limit.

Usage:
    uv run python ci/apply_descriptions.py field_descriptions.json
    uv run python ci/apply_descriptions.py field_descriptions.json --dry-run
"""
import json
import re
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_LINE = 105
# indent for attribute descriptions inside a docstring: 4 (class) + 4 (docstring) = 8
DESC_INDENT = "        "
ATTR_INDENT = "    "
DESC_WIDTH = MAX_LINE - len(DESC_INDENT)


def load_report(path: Path) -> dict:
    return json.loads(path.read_text())


def find_class_in_source(source: str, class_name: str) -> tuple[int, int] | None:
    """Find the docstring range for a class. Returns (start, end) line indices."""
    lines = source.split("\n")
    class_pattern = re.compile(rf"^class {re.escape(class_name)}\b")
    for i, line in enumerate(lines):
        if class_pattern.match(line):
            # find the docstring
            for j in range(i + 1, min(i + 5, len(lines))):
                stripped = lines[j].strip()
                if stripped.startswith('"""') or stripped.startswith("'''"):
                    quote = stripped[:3]
                    if stripped.count(quote) >= 2 and len(stripped) > 6:
                        return (j, j)
                    for k in range(j + 1, len(lines)):
                        if quote in lines[k]:
                            return (j, k)
                    break
                if stripped and not stripped.startswith("#"):
                    break
            return None
    return None


def build_attributes_block(fields: dict, indent: str = ATTR_INDENT) -> str:
    """Build a numpy-style Attributes block from field descriptions."""
    lines = [f"{indent}Attributes", f"{indent}----------"]
    for field_name in sorted(fields.keys()):
        info = fields[field_name]
        desc = info.get("existing_description") or info.get("swagger_description")
        if not desc:
            continue
        # some swagger descriptions start with stray punctuation (e.g. ". The available values...")
        desc = desc.lstrip(" .,;:-")
        # strip "The available values are: ..." suffix
        desc = re.split(r"\.\s*The available values\b", desc)[0]
        lines.append(f"{indent}{field_name}")
        wrapped = textwrap.fill(
            desc, width=DESC_WIDTH, initial_indent="", subsequent_indent=""
        )
        for wline in wrapped.split("\n"):
            lines.append(f"{DESC_INDENT}{wline}")
    return "\n".join(lines)


def _find_class_line(source: str, class_name: str) -> int | None:
    """Find the line index of the class definition."""
    pattern = re.compile(rf"^class {re.escape(class_name)}\b")
    for i, line in enumerate(source.split("\n")):
        if pattern.match(line):
            return i
    return None


def update_docstring(source: str, class_name: str, fields: dict) -> str:
    """Update or add Attributes section in a class docstring."""
    attrs_block = build_attributes_block(fields)
    if not attrs_block.strip().split("\n")[2:]:
        return source
    rng = find_class_in_source(source, class_name)
    if rng is None:
        # no docstring — create one
        class_line = _find_class_line(source, class_name)
        if class_line is None:
            return source
        lines = source.split("\n")
        new_doc = f'    """\n{attrs_block}\n    """'
        new_lines = lines[:class_line + 1] + new_doc.split("\n") + lines[class_line + 1:]
        return "\n".join(new_lines)
    start, end = rng
    lines = source.split("\n")
    doc_lines = lines[start:end + 1]
    quote = '"""'
    doc_text = "\n".join(doc_lines)
    # remove existing Attributes section
    attr_pattern = re.compile(
        r"\n?\s*Attributes\s*:?\s*\n\s*-{3,}\n.*?(?=\n\s*\"\"\"|\n\s*\'\'\'|\Z)",
        re.DOTALL,
    )
    doc_text = attr_pattern.sub("", doc_text)
    # find where to insert (before closing quotes)
    closing_idx = doc_text.rfind(quote)
    if closing_idx == -1:
        return source
    # ensure blank line before attributes
    before = doc_text[:closing_idx].rstrip()
    if before.endswith(quote):
        # single-line docstring, expand it
        inner = before[len(f"    {quote}"):]
        before = f"    {quote}{inner}"
        doc_text = f"{before}\n\n{attrs_block}\n    {quote}"
    else:
        doc_text = f"{before}\n\n{attrs_block}\n    {quote}"
    new_lines = lines[:start] + doc_text.split("\n") + lines[end + 1:]
    return "\n".join(new_lines)


def apply_to_file(filepath: Path, classes: dict[str, dict], dry_run: bool) -> int:
    """Apply descriptions to all matching classes in a file. Returns count of changes."""
    source = filepath.read_text()
    original = source
    for class_name, info in classes.items():
        fields = info["fields"]
        source = update_docstring(source, class_name, fields)
    if source == original:
        return 0
    if not dry_run:
        filepath.write_text(source)
    return 1


def main():
    args = sys.argv[1:]
    if not args:
        print("Usage: apply_descriptions.py <report.json> [--dry-run]", file=sys.stderr)
        sys.exit(1)
    report_path = Path(args[0])
    dry_run = "--dry-run" in args
    report = load_report(report_path)
    # group by module
    by_file: dict[Path, dict[str, dict]] = {}
    for class_name, info in report.items():
        module = info["module"]
        filepath = ROOT / "fbnconfig" / f"{module}.py"
        if not filepath.exists():
            continue
        has_desc = any(
            f.get("existing_description") or f.get("swagger_description")
            for f in info["fields"].values()
        )
        if not has_desc:
            continue
        by_file.setdefault(filepath, {})[class_name] = info
    changed = 0
    for filepath, classes in sorted(by_file.items()):
        result = apply_to_file(filepath, classes, dry_run)
        if result:
            changed += 1
            print(f"{'Would update' if dry_run else 'Updated'}: {filepath.name}", file=sys.stderr)
    print(f"\n{changed} files {'would be ' if dry_run else ''}updated", file=sys.stderr)


if __name__ == "__main__":
    main()
