"""Given the changes on a branch vs its merge base, output the integration
tests (int_*.py) that need to be run.

A test is affected if:
  - The test file itself was modified, OR
  - Any fbnconfig module it imports (transitively) was modified, OR
  - Any tests/integration helper it imports was modified

Usage:
    python ci/affected_tests.py                    # list affected tests
    python ci/affected_tests.py --run              # print reasons then run pytest
    python ci/affected_tests.py --base <ref>       # override base ref
    python ci/affected_tests.py --all              # print all int tests
"""
import ast
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC_PKG = "fbnconfig"
INT_DIR = ROOT / "tests" / "integration"


def git_changed_files(base: str) -> set[Path]:
    merge_base = subprocess.check_output(
        ["git", "merge-base", "HEAD", base], text=True, cwd=ROOT
    ).strip()
    output = subprocess.check_output(
        ["git", "diff", "--name-only", f"{merge_base}..HEAD"], text=True, cwd=ROOT
    )
    return {ROOT / line for line in output.strip().splitlines() if line}


def parse_imports(filepath: Path, package: str | None = None) -> set[str]:
    """Return the set of dotted module names imported by a file.

    Relative imports are resolved against *package* (the dotted name of the
    file's containing package).  ``from pkg import name`` also yields
    ``pkg.name`` so that submodule imports are captured.
    """
    try:
        tree = ast.parse(filepath.read_text(), filename=str(filepath))
    except SyntaxError:
        return set()
    modules = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modules.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.level > 0 and package:
                parts = package.split(".")
                base = ".".join(parts[: max(1, len(parts) - node.level + 1)])
                if node.module:
                    resolved = f"{base}.{node.module}"
                else:
                    resolved = base
            elif node.module:
                resolved = node.module
            else:
                continue
            modules.add(resolved)
            # ``from fbnconfig import drive`` -> also add fbnconfig.drive
            for alias in node.names:
                modules.add(f"{resolved}.{alias.name}")
    return modules


def collect_source_files() -> dict[str, Path]:
    """Map dotted module name -> file path for fbnconfig and tests.integration.

    __init__.py files are excluded — they act as barrel re-exports and would
    cause every change to fan out to all tests.
    """
    modules = {}
    for py in (ROOT / SRC_PKG).rglob("*.py"):
        if py.name == "__init__.py":
            continue
        parts = py.relative_to(ROOT).with_suffix("").parts
        dotted = ".".join(parts)
        modules[dotted] = py
    for py in INT_DIR.glob("*.py"):
        if py.name.startswith("int_") or py.name == "__init__.py":
            continue
        parts = py.relative_to(ROOT).with_suffix("").parts
        dotted = ".".join(parts)
        modules[dotted] = py
    return modules


def resolve_import(imp: str, all_names: set[str]) -> set[str]:
    """Resolve an import string to tracked module names.

    - Exact match: ``import fbnconfig.drive`` -> ``fbnconfig.drive``
    - Bare package import (``import fbnconfig``) is ignored — __init__ is
      excluded from the graph so there is nothing to resolve to.
    """
    hits = set()
    if imp in all_names:
        hits.add(imp)
    return hits


def build_dependency_graph(modules: dict[str, Path]) -> dict[str, set[str]]:
    """For each module, find which other tracked modules it imports."""
    graph: dict[str, set[str]] = {}
    all_names = set(modules.keys())
    for dotted, filepath in modules.items():
        # determine containing package for relative import resolution
        parts = dotted.split(".")
        package = ".".join(parts[:-1]) if len(parts) > 1 else None
        raw_imports = parse_imports(filepath, package=package)
        deps = set()
        for imp in raw_imports:
            deps |= resolve_import(imp, all_names)
        deps.discard(dotted)
        graph[dotted] = deps
    return graph


def transitive_dependents(graph: dict[str, set[str]], changed: set[str]) -> set[str]:
    """Find all modules transitively affected by the changed set.

    Inverts the graph to walk from dependency -> dependents.
    """
    reverse: dict[str, set[str]] = {}
    for mod, deps in graph.items():
        for dep in deps:
            reverse.setdefault(dep, set()).add(mod)
    affected = set(changed)
    queue = list(changed)
    while queue:
        current = queue.pop()
        for dependent in reverse.get(current, set()):
            if dependent not in affected:
                affected.add(dependent)
                queue.append(dependent)
    return affected


def find_affected_int_tests(base: str) -> list[tuple[Path, str]]:
    """Return list of (test_path, reason) tuples for affected integration tests."""
    changed_files = git_changed_files(base)
    source_modules = collect_source_files()
    graph = build_dependency_graph(source_modules)
    file_to_module = {v: k for k, v in source_modules.items()}
    changed_modules = set()
    for f in changed_files:
        if f in file_to_module:
            changed_modules.add(file_to_module[f])
    affected = transitive_dependents(graph, changed_modules)
    all_names = set(source_modules.keys()) | affected
    int_tests = sorted(INT_DIR.glob("int_*.py"))
    result = []
    for test_file in int_tests:
        if test_file in changed_files:
            result.append((test_file, "file modified"))
            continue
        imports = parse_imports(test_file, package="tests.integration")
        test_deps: set[str] = set()
        for imp in imports:
            test_deps |= resolve_import(imp, all_names)
        triggers = sorted(test_deps & affected)
        if triggers:
            result.append((test_file, ", ".join(triggers)))
    seen = set()
    deduped = []
    for path, reason in result:
        if path not in seen:
            seen.add(path)
            deduped.append((path, reason))
    return deduped


def detect_base() -> str:
    """Detect the base to diff against.

    Finds the most recent merge commit that is an ancestor of HEAD but is
    not HEAD itself — that's the point where the current branch diverged.
    """
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], text=True, cwd=ROOT
    ).strip()
    # list merge commits reachable from HEAD, skip HEAD if it is one
    output = subprocess.check_output(
        ["git", "log", "--merges", "--format=%H", "-10"],
        text=True, cwd=ROOT,
    ).strip()
    for sha in output.splitlines():
        if sha != head:
            return sha
    return "origin/master"


def print_affected(tests: list[tuple[Path, str]]) -> None:
    """Print affected tests and their triggering dependencies."""
    max_name = max(len(t.stem) for t, _ in tests) if tests else 0
    for test_file, reason in tests:
        print(f"  {test_file.stem:<{max_name}}  <- {reason}", file=sys.stderr)


def main():
    args = sys.argv[1:]
    if "--all" in args:
        for f in sorted(INT_DIR.glob("int_*.py")):
            print(f.relative_to(ROOT))
        return
    if "--base" in args:
        idx = args.index("--base")
        base = args[idx + 1]
    else:
        base = detect_base()
        print(f"Detected base: {base}", file=sys.stderr)
    tests = find_affected_int_tests(base)
    if not tests:
        print("No affected integration tests.", file=sys.stderr)
        sys.exit(0)
    print(f"\n{len(tests)} affected integration test(s):", file=sys.stderr)
    print_affected(tests)
    print(file=sys.stderr)
    if "--run" in args:
        test_paths = [str(t.relative_to(ROOT)) for t, _ in tests]
        subprocess.check_call(["uv", "venv"], cwd=ROOT)
        subprocess.check_call(["uv", "sync"], cwd=ROOT)
        pytest_args = ["-n", "auto", "--dist", "loadfile", "-v", "-s", "-p", "no:sugar"]
        cmd = ["uv", "run", "pytest"] + test_paths + pytest_args
        print(f"Running: {' '.join(cmd)}", file=sys.stderr)
        sys.exit(subprocess.call(cmd, cwd=ROOT))
    else:
        for t, _ in tests:
            print(t.relative_to(ROOT))


if __name__ == "__main__":
    main()
