"""Extract field descriptions from swagger files and match them to resource classes.

Outputs a JSON report showing which fields have descriptions, which need them,
and what the swagger says.

Usage:
    uv run python ci/import_descriptions.py > field_descriptions.json
    uv run python ci/import_descriptions.py --swaggers ~/src/finbourne/swaggers
"""
import json
import sys
from pathlib import Path
from typing import Any, Union, get_args, get_origin

from pydantic import BaseModel
from pydantic.alias_generators import to_camel

from fbnconfig.resource_abc import RESOURCE_REGISTRY
from fbnconfig.schemagen import parse_docstring_attrs


def _extract_controller(endpoint: str) -> str:
    """Extract the controller name from a swagger or fbnconfig endpoint path.

    e.g. /api/workflows/{scope}/{code} -> workflows
         /api/api/chartofaccounts/{scope}/{code} -> chartofaccounts
         /workflow/api/taskdefinitions/{scope}/{code} -> taskdefinitions
         /identity/api/users/{userId} -> users
    """
    parts = [p for p in endpoint.split("/") if p and p != "api" and not p.startswith("{")]
    # skip service prefixes like workflow, identity, scheduler2, etc.
    service_prefixes = {
        "workflow", "identity", "access", "drive", "notification",
        "configuration", "scheduler2", "horizon", "honeycomb",
    }
    for p in parts:
        if p not in service_prefixes:
            return p
    return parts[-1] if parts else ""


class SwaggerData:
    """Holds parsed swagger data with controller associations."""

    def __init__(self):
        self.schemas: dict[str, dict[str, str]] = {}
        # which controllers reference each schema (via $ref in request/response)
        self.schema_controllers: dict[str, set[str]] = {}
        self.path_params: dict[str, dict[str, str]] = {}

    def schemas_for_controller(self, controller: str) -> dict[str, dict[str, str]]:
        """Get schemas associated with a controller, plus unassociated ones."""
        result: dict[str, dict[str, str]] = {}
        for name, fields in self.schemas.items():
            controllers = self.schema_controllers.get(name, set())
            if controller in controllers or not controllers:
                result[name] = fields
        return result


def _extract_refs(obj: Any) -> list[str]:
    """Extract schema names from $ref values in a swagger operation."""
    refs = []
    if isinstance(obj, dict):
        if "$ref" in obj:
            ref = obj["$ref"]
            # #/components/schemas/Foo or #/definitions/Foo
            name = ref.rsplit("/", 1)[-1]
            refs.append(name)
        for v in obj.values():
            refs.extend(_extract_refs(v))
    elif isinstance(obj, list):
        for item in obj:
            refs.extend(_extract_refs(item))
    return refs


def load_swagger_descriptions(swagger_dir: Path) -> SwaggerData:
    """Load all swagger files and extract schema and path param descriptions."""
    data_out = SwaggerData()
    for path in sorted(swagger_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        defs = data.get("definitions") or data.get("components", {}).get("schemas", {})
        for schema_name, schema_def in (defs or {}).items():
            props = schema_def.get("properties", {})
            field_descs: dict[str, str] = {}
            for prop_name, prop_def in props.items():
                desc = prop_def.get("description")
                if desc:
                    field_descs[prop_name] = desc
            # promote scope/code from id.$ref (e.g. id -> ResourceId)
            id_prop = props.get("id", {})
            id_ref = id_prop.get("$ref", "")
            if id_ref:
                id_schema = (defs or {}).get(id_ref.rsplit("/", 1)[-1], {})
                for key in ("scope", "code"):
                    if key not in field_descs:
                        id_desc = id_schema.get("properties", {}).get(key, {}).get("description")
                        if id_desc:
                            field_descs[key] = id_desc
            if field_descs:
                data_out.schemas[schema_name] = field_descs
        # map controllers to schemas and extract path params
        for endpoint, methods in data.get("paths", {}).items():
            controller = _extract_controller(endpoint)
            if not controller:
                continue
            for method_info in methods.values():
                if not isinstance(method_info, dict):
                    continue
                # associate referenced schemas with this controller
                for ref_name in _extract_refs(method_info):
                    data_out.schema_controllers.setdefault(ref_name, set()).add(controller)
                # extract path and query param descriptions
                for param in method_info.get("parameters", []):
                    if param.get("in") in ("path", "query") and param.get("description"):
                        name = param["name"]
                        desc = param["description"]
                        ctrl_params = data_out.path_params.setdefault(controller, {})
                        if name not in ctrl_params or len(desc) < len(ctrl_params[name]):
                            ctrl_params[name] = desc
    return data_out


def get_field_alias(cls: type, field_name: str) -> str:
    """Get the camelCase alias for a field."""
    info = cls.model_fields[field_name]
    if info.serialization_alias:
        return info.serialization_alias
    return to_camel(field_name)


def get_field_aliases(cls: type) -> set[str]:
    """Get all camelCase aliases for a resource class (excluding id)."""
    return {get_field_alias(cls, f) for f in cls.model_fields if f != "id"}


def find_best_schema(
    resource_name: str,
    aliases: set[str],
    swagger: SwaggerData,
    controller: str,
) -> tuple[str | None, dict[str, str]]:
    """Find the swagger schema that best matches a resource class.

    Prefers schemas associated with the resource's controller. Scores by
    field overlap with a bonus for name similarity. Schemas from the
    resource's controller get an additional bonus.
    """
    resource_words = set(_split_camel(resource_name).lower().split())
    resource_words -= {"resource", "ref", "request", "response", "create", "update"}
    # search controller-scoped schemas first, then all
    candidates = swagger.schemas_for_controller(controller) if controller else swagger.schemas
    best_name: str | None = None
    best_fields: dict[str, str] = {}
    best_score = 0.0
    for schema_name, fields in candidates.items():
        overlap = aliases & set(fields.keys())
        if not overlap:
            continue
        score = len(overlap)
        schema_words = set(_split_camel(schema_name).lower().split())
        schema_words -= {"resource", "ref", "request", "response", "create", "update"}
        name_overlap = resource_words & schema_words
        if name_overlap:
            score += len(name_overlap) * 3
        # bonus for schemas from this controller
        if controller and controller in swagger.schema_controllers.get(schema_name, set()):
            score += 2
        if score > best_score or (
            score == best_score and len(fields) > len(best_fields)
        ):
            best_score = score
            best_name = schema_name
            best_fields = fields
    if not best_name:
        return None, {}
    # accept if score includes a name bonus, or has enough field overlap
    overlap = aliases & set(best_fields.keys())
    if best_score <= len(overlap):
        if len(overlap) < 3 and len(overlap) / max(len(aliases), 1) < 0.5:
            return None, {}
    return best_name, best_fields


def _split_camel(name: str) -> str:
    """Split CamelCase into space-separated words."""
    import re
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", name)


def collect_nested_types() -> dict[str, type]:
    """Find all BaseModel subclasses used as field types in registered resources."""
    seen: dict[str, type] = {}
    queue: list[type] = [info["class"] for info in RESOURCE_REGISTRY.values()]
    visited: set[str] = set(RESOURCE_REGISTRY.keys())
    while queue:
        cls = queue.pop()
        for field_info in cls.model_fields.values():
            for t in _unwrap_types(field_info.annotation):
                if (
                    isinstance(t, type)
                    and issubclass(t, BaseModel)
                    and t is not BaseModel
                    and t.__name__ not in visited
                ):
                    visited.add(t.__name__)
                    seen[t.__name__] = t
                    queue.append(t)
    return seen


def _unwrap_types(annotation) -> list:
    """Unwrap Optional, Union, list, dict annotations to find concrete types."""
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin is Union or origin is list or origin is dict:
        result = []
        for a in args:
            result.extend(_unwrap_types(a))
        return result
    return [annotation]


def _get_resource_controller(cls: type, all_controllers: set[str] | None = None) -> str:
    """Get the controller path segment from a resource's endpoint."""
    for method_name in ("fetch_endpoint", "list_endpoint"):
        fn = getattr(cls, method_name, None)
        if fn:
            try:
                ep = fn()
                return _extract_controller(ep)
            except Exception:
                pass
    # fallback: match class name words against known controllers
    if all_controllers:
        name = cls.__name__.replace("Resource", "").replace("Ref", "").lower()
        for ctrl in all_controllers:
            if ctrl.startswith(name) or name.startswith(ctrl.replace("_", "")):
                return ctrl
    return ""


def _build_class_report(
    cls: type,
    module: str,
    schema_name: str | None,
    matched_schema: dict[str, str],
    path_params: dict[str, dict[str, str]],
) -> dict[str, Any]:
    existing_attrs = parse_docstring_attrs(cls.__doc__)
    all_controllers = set(path_params.keys())
    controller = _get_resource_controller(cls, all_controllers)
    if not controller and cls.__name__.endswith("Ref"):
        resource_name = cls.__name__[:-3] + "Resource"
        resource_cls = RESOURCE_REGISTRY.get(resource_name, {}).get("class")
        if resource_cls:
            controller = _get_resource_controller(resource_cls, all_controllers)
    ctrl_params = path_params.get(controller, {})
    id_desc = "The unique fbnconfig resource identifier"
    fields: dict[str, Any] = {}
    for field_name in cls.model_fields:
        if field_name == "id":
            existing = existing_attrs.get("id")
            fields["id"] = {
                "alias": "id",
                "swagger_description": existing or id_desc,
                "existing_description": existing,
                "status": "has_existing" if existing else "needs_description",
            }
            continue
        alias = get_field_alias(cls, field_name)
        existing = existing_attrs.get(field_name)
        swagger_desc = matched_schema.get(alias) or ctrl_params.get(alias)
        if existing:
            status = "has_existing"
        elif swagger_desc:
            status = "needs_description"
        else:
            status = "no_swagger_match"
        fields[field_name] = {
            "alias": alias,
            "swagger_description": swagger_desc,
            "existing_description": existing,
            "status": status,
        }
    return {"module": module, "matched_schema": schema_name, "fields": fields}


def build_report(swagger_dir: Path) -> dict[str, Any]:
    swagger = load_swagger_descriptions(swagger_dir)
    # collect all classes: registry + nested types
    all_classes: dict[str, tuple[type, str]] = {}
    for resource_type, reg_info in RESOURCE_REGISTRY.items():
        cls = reg_info["class"]
        all_classes[resource_type] = (cls, cls.__module__.split(".")[-1])
    for name, cls in collect_nested_types().items():
        all_classes[name] = (cls, cls.__module__.split(".")[-1])
    # resolve controllers
    all_controllers = set(swagger.path_params.keys())
    controllers: dict[str, str] = {}
    for name, (cls, _module) in all_classes.items():
        controllers[name] = _get_resource_controller(cls, all_controllers)
    # refs inherit controller from their resource
    for name in controllers:
        if not controllers[name] and name.endswith("Ref"):
            resource_name = name[:-3] + "Resource"
            if resource_name in controllers:
                controllers[name] = controllers[resource_name]
    # first pass: match each class to a swagger schema
    matched: dict[str, tuple[str | None, dict[str, str]]] = {}
    for name, (cls, _module) in sorted(all_classes.items()):
        aliases = get_field_aliases(cls)
        matched[name] = find_best_schema(name, aliases, swagger, controllers.get(name, ""))
    # second pass: refs always use their resource's schema (or None if resource has none)
    for name in matched:
        if name.endswith("Ref"):
            resource_name = name[:-3] + "Resource"
            if resource_name in matched:
                matched[name] = matched[resource_name]
    # build report
    report: dict[str, Any] = {}
    for name, (cls, module) in sorted(all_classes.items()):
        schema_name, matched_schema = matched[name]
        report[name] = _build_class_report(
            cls, module, schema_name, matched_schema, swagger.path_params
        )
    return report


def main():
    swagger_dir = Path.home() / "src" / "finbourne" / "swaggers"
    args = sys.argv[1:]
    if "--swaggers" in args:
        idx = args.index("--swaggers")
        swagger_dir = Path(args[idx + 1])
    if not swagger_dir.is_dir():
        print(f"Swagger directory not found: {swagger_dir}", file=sys.stderr)
        sys.exit(1)
    report = build_report(swagger_dir)
    # print summary to stderr
    total = sum(len(r["fields"]) for r in report.values())
    has_existing = sum(
        1 for r in report.values()
        for f in r["fields"].values() if f["status"] == "has_existing"
    )
    needs = sum(
        1 for r in report.values()
        for f in r["fields"].values() if f["status"] == "needs_description"
    )
    no_match = sum(
        1 for r in report.values()
        for f in r["fields"].values() if f["status"] == "no_swagger_match"
    )
    print(f"Total fields: {total}", file=sys.stderr)
    print(f"  has_existing:      {has_existing}", file=sys.stderr)
    print(f"  needs_description: {needs}", file=sys.stderr)
    print(f"  no_swagger_match:  {no_match}", file=sys.stderr)
    json.dump(report, sys.stdout, indent=2)


if __name__ == "__main__":
    main()
