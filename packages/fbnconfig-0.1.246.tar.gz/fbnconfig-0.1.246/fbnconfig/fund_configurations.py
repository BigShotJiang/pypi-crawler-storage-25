import json
import string
from enum import StrEnum
from hashlib import sha256
from typing import Any, List, Sequence

from pydantic import BaseModel, Field, field_serializer, model_validator

from . import property
from .coretypes import StrDateTime
from .properties import PropertyValueInner
from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource
from .urlfmt import Urlfmt

url: string.Formatter = Urlfmt("api/api/fundconfigurations")
CREATE_FUNDCONFIGURATION_URL = ("{base}/{scope}")
FUND_CONFIGURATION_URL = ("{base}/{scope}/{code}")
GROUP = "Fund Accounting"


class PropertyValue(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    effective_from
        The effective datetime from which the property is valid.
    effective_until
        The effective datetime until which the property is valid. If not supplied this will be valid
        indefinitely, or until the next 'effectiveFrom' datetime of the property.
    key
        The key of the property. This takes the format {domain}/{scope}/{code} e.g.
        'Instrument/system/Name' or 'Transaction/strategy/quantsignal'.
    """
    key: property.PropertyKey  # Renamed from property_definition
    value: PropertyValueInner
    effective_from: StrDateTime | None = None
    effective_until: StrDateTime | None = None

    @classmethod
    def create(cls, key, label_value=None, metric_value=None,
                    label_set_value=None, effective_from=None, effective_until=None):
        """Convenience method to create PropertyValue with the nested value structure"""
        value_inner = PropertyValueInner(
            label_value=label_value,
            metric_value=metric_value,
            label_set_value=label_set_value
        )
        return cls(
            key=key,
            value=value_inner,
            effective_from=effective_from,
            effective_until=effective_until
        )


class AppliesToEnum(StrEnum):
    Undefined = "Undefined"
    PnLBucket = "PnLBucket"
    Fees = "Fees"


class ExternalFeeComponentFilter(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    filter
        The filter value
    """
    filter_id: str
    filter: str
    applies_to: AppliesToEnum


class ComponentFilter(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    filter
        The filter value
    """
    filter_id: str
    filter: str


@register_resource(group=GROUP, keys=["scope", "code"])
class FundConfigurationResource(BaseModel, Resource, ListMixin, FetchMixin):
    """
    Attributes
    ----------
    back_out_filters
        The set of filters used to decide which JE lines are included in the back outs.
    code
        The code used to identify an entity
    dealing_filters
        The set of filters used to decide which JE lines are included in the dealing.
    description
        A description for the FundConfiguration.
    display_name
        The name of the FundConfiguration.
    external_fee_filters
        The set of filters used to decide which JE lines are used for inputting fees from an external
        source.
    id
        The unique fbnconfig resource identifier
    pnl_filters
        The set of filters used to decide which JE lines are included in the PnL.
    properties
        A set of properties for the Fund Configuration.
    scope
        The scope used to identify an entity
    """
    id: str = Field(exclude=True)
    scope: str
    # request body
    code: str
    display_name: str | None = None
    description: str | None = None
    dealing_filters: List[ComponentFilter]
    pnl_filters: List[ComponentFilter]
    back_out_filters: List[ComponentFilter]
    external_fee_filters: List[ExternalFeeComponentFilter] | None = None
    properties: List[PropertyValue] | None = None

    @field_serializer("properties", mode="plain")
    def serialize_properties(self, properties, _info):
        if properties is None:
            return None
        return {
            f"FundConfiguration/{pv.key.scope}/{pv.key.code}": pv for pv in properties
        }

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data, info):
        if not isinstance(data, dict):
            return data

        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    def read(self, client, old_state):
        scope, code = old_state.scope, old_state.code
        formatted_url = url.format(FUND_CONFIGURATION_URL, scope=scope, code=code)
        return client.get(formatted_url).json()

    def create(self, client):
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = sha256(sorted_desired.encode("utf-8")).hexdigest()

        scope = desired["scope"]
        code = desired["code"]

        formatted_url = url.format(CREATE_FUNDCONFIGURATION_URL, scope=scope)
        client.post(formatted_url, json=desired)

        return {"scope": scope, "code": code, "content_hash": content_hash}

    def update(self, client, old_state):
        # Currently only some fields can be updated with FundConfiguration
        # So we must delete and recreate a fund configuration if other fields change
        if (self.scope, self.code) != (old_state.scope, old_state.code):
            self.delete(client, old_state)
            return self.create(client)
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        sorted_desired = json.dumps(desired, sort_keys=True)
        desired_hash = sha256(sorted_desired.encode("utf-8")).hexdigest()
        if desired_hash == old_state.content_hash:
            return None
        self.delete(client, old_state)
        return self.create(client)

    @staticmethod
    def delete(client, old_state):
        scope, code = old_state.scope, old_state.code
        formatted_url = url.format(FUND_CONFIGURATION_URL, scope=scope, code=code)
        client.delete(formatted_url)

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"fund-configuration_{data['scope']}_{data['code']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return data["id"]

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/api/api/fundconfigurations/{scope}/{code}"

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/api/api/fundconfigurations"

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        # Extract scope and code from id if present
        resource_id = data["id"]
        scope = resource_id["scope"]
        code = resource_id["code"]

        # Convert properties: empty dict to empty list, None stays None
        properties = data.get("properties")
        if properties == {}:
            properties = []

        # Build result with required fields
        result = {
            "id": cls.create_resource_id({"scope": scope, "code": code}),
            "scope": scope,
            "code": code,
            "dealingFilters": data["dealingFilters"],
            "pnlFilters": data["pnlFilters"],
            "backOutFilters": data["backOutFilters"],
            "displayName": data.get("displayName"),
            "description": data.get("description"),
            "externalFeeFilters": data.get("externalFeeFilters"),
            "properties": properties
        }
        return result

    def deps(self) -> Sequence[Resource | Ref]:
        property_keys = []
        if self.properties is None:
            return property_keys

        for property_def in self.properties:
            if property_def.key is not None:
                property_keys.append(property_def.key)

        return property_keys
