from __future__ import annotations

import json
import string
from enum import StrEnum
from hashlib import sha256
from typing import Annotated, Any, Dict, List

import httpx
from pydantic import BaseModel, BeforeValidator, Field, PlainSerializer, WithJsonSchema, model_validator

from .coretypes import ResourceId
from .property import DefinitionResource, PropertyKey
from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource
from .urlfmt import Urlfmt

url: string.Formatter = Urlfmt("api/api/datamodel")
DATA_MODEL_URL_FORMAT = "{base}/{entity_type}"
FULL_DATA_MODEL_URL = DATA_MODEL_URL_FORMAT + "/{scope}/{code}"

GROUP = "Data Model"


class SortOrder(StrEnum):
    ASC = "ASC"
    DESC = "DESC"


class DataModelProperty(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    property_key
        The property key that is required/allowed on the bound entity.
    required
        Whether property is required or allowed.
    """
    property_key: PropertyKey
    required: bool | None


class IdentifierType(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    identifier_key
        The identifier type that is required/allowed on the bound entity.
    required
        Whether identifier type is required or allowed.
    """
    identifier_key: str
    required: bool | None


class AttributeAlias(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    attribute_alias
        The alias to replace the property key, identifier type, or field on the bound entity.
    attribute_name
        The property key, identifier type, or field to be replaced by an alias.
    """
    attribute_name: str
    attribute_alias: str


class RecommendedSortBy(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    attribute_name
        The property key, identifier type, or field to be sorted by.
    sort_order
        The sorting direction. Either ascending (ASC) or descending (DESC).
    """
    attribute_name: str
    sort_order: SortOrder | None


def ser_parent_data_model(value, info):
    """Serialize parent data model reference."""
    if info.context and info.context.get("style", "api") == "dump":
        if isinstance(value, (Resource, Ref)):
            return {"$ref": value.id}
        return value
    if isinstance(value, (CustomDataModelResource, CustomDataModelRef)):
        return {"scope": value.resource_id.scope, "code": value.resource_id.code}
    return value


def des_parent_data_model(value, info):
    """Deserialize parent data model reference."""
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs") and "$ref" in value:
        ref = info.context["$refs"][value["$ref"]]
        return ref
    # Handle ResourceId format
    if "scope" in value and "code" in value:
        return value
    return value


ParentDataModelKey = Annotated[
    "CustomDataModelResource | CustomDataModelRef | ResourceId | None",
    BeforeValidator(des_parent_data_model),
    PlainSerializer(ser_parent_data_model),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.CustomDataModel"}},
            "required": ["$ref"],
        }
    ),
]


@register_resource(group=GROUP)
class CustomDataModelRef(CamelAlias, BaseModel, Ref):
    """Reference to an existing custom data model.

    Example
    -------
    >>> from fbnconfig.custom_data_model import CustomDataModelRef
    >>> model_ref = CustomDataModelRef(
    ...     id="my_ref",
    ...     entity_type="Instrument",
    ...     resource_id=ResourceId(scope="MyScope", code="MyModel")
    ... )

    Attributes
    ----------
    entity_type
        The entity type of the Data Model.
    id
        The unique fbnconfig resource identifier
    """

    id: str = Field(exclude=True)
    entity_type: str
    resource_id: ResourceId

    def attach(self, client: httpx.Client):
        """Verify the custom data model exists."""
        try:
            (
                client.get(
                    url.format(
                        FULL_DATA_MODEL_URL,
                        entity_type=self.entity_type,
                        scope=self.resource_id.scope,
                        code=self.resource_id.code,
                    )
                ),
            )

        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(
                    f"CustomDataModel {self.entity_type}/{self.resource_id.scope}/"
                    f"{self.resource_id.code} not found"
                )
            else:
                raise ex


@register_resource(group=GROUP, keys=["entityType", "scope", "code"])
class CustomDataModelResource(CamelAlias, BaseModel, Resource, ListMixin, FetchMixin):
    """Resource describing a LUSID Custom Data Model.

    Creates a custom data model if it doesn't exist and updates if it has changed.
    Custom data models define validation rules, required properties, and identifiers
    for LUSID entities.

    Example
    -------
    >>> from fbnconfig import custom_data_model, Deployment
    >>> from fbnconfig.coretypes import ResourceId
    >>> model = custom_data_model.CustomDataModelResource(
    ...     id="my_model",
    ...     entity_type="Instrument",
    ...     resource_id=ResourceId(scope="MyScope", code="MyModel"),
    ...     display_name="My Custom Model",
    ...     description="A custom data model for instruments",
    ...     conditions="InstrumentDefinition.InstrumentType eq 'bond'",
    ...     properties=[
    ...         custom_data_model.DataModelProperty(
    ...             property_key="Instrument/MyScope/Rating",
    ...             required=True
    ...         )
    ...     ]
    ... )
    >>> Deployment("my_deployment", [model])

    Attributes
    ----------
    attribute_aliases
        List of attribute alias mappings
    conditions
        Filter conditions for when this model applies
    description
        A description of the custom data model
    display_name
        The display name for the custom data model
    entity_type
        The entity type this model applies to (e.g., "Instrument", "Portfolio")
    id
        Resource identifier; used in the log to reference the custom data model resource
    identifier_types
        List of identifier types required or validated by this model
    parent_data_model
        Reference to a parent data model to inherit from
    properties
        List of properties required or validated by this model
    recommended_sort_by
        Recommended sorting configuration
    resource_id
        The resource identifier containing scope and code
    """

    id: str = Field(exclude=True)
    entity_type: str = Field(exclude=True)  # Path parameter, not in body
    resource_id: ResourceId = Field(serialization_alias="id")
    display_name: str
    description: str
    parent_data_model: ParentDataModelKey = None
    conditions: str | None = None
    properties: List[DataModelProperty] | None = None
    identifier_types: List[IdentifierType] | None = None
    attribute_aliases: List[AttributeAlias] | None = None
    recommended_sort_by: List[RecommendedSortBy] | None = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data

        # Handle nested id structure from API response first (for resource_id field)
        has_resource_id_in_data = "id" in data and isinstance(data["id"], dict) and "scope" in data["id"]

        if has_resource_id_in_data:
            # This is the resource_id coming from API
            data["resource_id"] = data.pop("id")

        # Handle id and entity_type from context (for dump/undump)
        # The context "id" is the resource identifier, not the resource_id
        if info.context:
            if info.context.get("id") and "id" not in data:
                # Only set if not already consumed from API data
                data["id"] = info.context.get("id")
            if info.context.get("entity_type"):
                data["entity_type"] = info.context.get("entity_type")

        return data

    def __get_content_hash__(self) -> str:
        dump = self.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"entity_type", "resource_id"}
        )
        return sha256(json.dumps(dump, sort_keys=True).encode()).hexdigest()

    def read(self, client: httpx.Client, old_state) -> Dict[str, Any]:
        return client.get(
            url.format(
                FULL_DATA_MODEL_URL,
                entity_type=old_state.entity_type,
                scope=old_state.scope,
                code=old_state.code,
            )
        ).json()

    def create(self, client: httpx.Client):
        desired = self.model_dump(
            mode="json",
            exclude_none=True,
            by_alias=True,
            exclude={"entity_type"},  # entity_type is path param
        )

        remote = client.post(
            url.format(DATA_MODEL_URL_FORMAT, entity_type=self.entity_type), json=desired
        ).json()

        return {
            "id": self.id,
            "entity_type": self.entity_type,
            "scope": self.resource_id.scope,
            "code": self.resource_id.code,
            "source_version": self.__get_content_hash__(),
            "remote_version": f"{remote['version']['asAtVersionNumber']}",
        }

    def update(self, client: httpx.Client, old_state):
        # Check if entity_type/scope/code changed (not allowed)
        if (
            self.entity_type != old_state.entity_type
            or self.resource_id.scope != old_state.scope
            or self.resource_id.code != old_state.code
        ):
            # Delete old and create new
            self.delete(client, old_state)
            return self.create(client)

        remote = self.read(client, old_state) or {}
        remote_version = f"{remote['version']['asAtVersionNumber']}"

        # Build request body (without id/resourceId for update)
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"entity_type", "resource_id"}
        )

        source_version = self.__get_content_hash__()

        # Check if content has changed using both source and remote versions
        if source_version == old_state.source_version and remote_version == old_state.remote_version:
            return None  # No change

        # Update the custom data model
        updated = client.put(
            url.format(
                FULL_DATA_MODEL_URL,
                entity_type=self.entity_type,
                scope=self.resource_id.scope,
                code=self.resource_id.code,
            ),
            json=desired,
        ).json()

        return {
            "id": self.id,
            "entity_type": self.entity_type,
            "scope": self.resource_id.scope,
            "code": self.resource_id.code,
            "source_version": source_version,
            "remote_version": f"{updated['version']['asAtVersionNumber']}",
        }

    @staticmethod
    def delete(client: httpx.Client, old_state):
        client.delete(
            url.format(
                FULL_DATA_MODEL_URL,
                entity_type=old_state.entity_type,
                scope=old_state.scope,
                code=old_state.code,
            )
        )

    def deps(self):
        """Return dependencies."""
        deps = []
        if self.parent_data_model and isinstance(self.parent_data_model, (Resource, Ref)):
            deps.append(self.parent_data_model)
        # Add property_key dependencies from properties
        if self.properties:
            for prop_def in self.properties:
                if isinstance(prop_def.property_key, (Resource, Ref)):
                    deps.append(prop_def.property_key)
        return deps

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/api/api/datamodel/hierarchies"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/api/api/datamodel/{entityType}/{scope}/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        scope, code = data["resourceId"].values()
        return f"custom-data-model_{data['entityType']}_{scope}_{code}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "entityType": data["entityType"],
            "scope": data["id"]["scope"],
            "code": data["id"]["code"]
        }

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        if "dataModelSummary" in data:
            data = data | data.pop("dataModelSummary")

        data.pop("version", None)
        data.pop("type", None)
        data.pop("precedence", None)
        data.pop("children", None)
        data.pop("inherited", None)
        data.pop("incremental", None)
        data.pop("scope", None)
        data.pop("code", None)

        scope, code = data.pop("id").values()
        data["resourceId"] = {"scope": scope, "code": code}
        data["id"] = cls.create_resource_id(data)

        if "parent" in data:
            data["parentDataModel"] = data.pop("parent")

        if "applied" in data:
            data = data | data.pop("applied")
            data.pop("supplementalPropertyKeys", None)
            if "conditions" in data:
                data["conditions"] = ", ".join(data.pop("conditions"))

            properties = []
            for item_property in data.pop("properties", []):
                item_property.pop("displayName", None)
                domain, scope, code = item_property["propertyKey"].split("/")
                property_keys = {
                    "domain": domain,
                    "scope": scope,
                    "code": code
                }
                item_property["propertyKey"] = {
                    "$ref": DefinitionResource.create_resource_id(property_keys),
                    "metadata": {
                        "keys": property_keys,
                        "resource": getattr(DefinitionResource, "resource_type")
                    }
                }
                properties.append(item_property)
            data["properties"] = properties

            identifier_types = []
            for item_identifier_type in data.get("identifierTypes", []):
                item_identifier_type.pop("displayName", None)
                item_identifier_type.pop("identifierType", None)
                identifier_types.append(item_identifier_type)
            data["identifierTypes"] = identifier_types

        return data
