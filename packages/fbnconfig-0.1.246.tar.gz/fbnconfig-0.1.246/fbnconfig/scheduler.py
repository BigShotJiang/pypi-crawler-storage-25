import asyncio
import hashlib
import json
import subprocess
import time
from builtins import ExceptionGroup
from collections import defaultdict
from datetime import datetime
from typing import Annotated, Any, Dict, List, Literal, Optional

import httpx
from httpx import AsyncClient, Client, HTTPStatusError
from pydantic import (
    BaseModel,
    BeforeValidator,
    Field,
    PlainSerializer,
    WithJsonSchema,
    computed_field,
    field_serializer,
    field_validator,
    model_validator,
)

from . import configuration as cfg
from . import identity
from .coretypes import CPU, Memory, PositiveInt, Timezone
from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource

GROUP = "Scheduling"


@register_resource(group=GROUP)
class ImageRef(BaseModel, Ref):
    """Reference an existing image
    Example
    -------
    >>> from fbnconfig.scheduler import ImageRef
    >>> image_ref = ImageRef(dest_name="myimage", dest_tag="0.1.1")

    Attributes
    ----------
    id
        The unique fbnconfig resource identifier
    """

    id: str
    dest_name: str
    dest_tag: str

    def attach(self, client):
        # we only need to check it exists
        try:
            res = client.get(f"/scheduler2/api/images/repository/{self.dest_name}").json()
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Image with name {self.dest_name} and tag {self.dest_tag} not found")
            else:
                raise ex
        for img in res["values"]:
            names = {tag["name"] for tag in img["tags"]}
            if self.dest_tag in names:
                return
        raise RuntimeError(f"Image with name {self.dest_name} and tag {self.dest_tag} not found")


@register_resource(group=GROUP, keys=["destName", "destTag"])
class ImageResource(BaseModel, Resource, ListMixin, FetchMixin):
    """Define an image

    Example
    -------
    >>> from fbnconfig.scheduler import ImageResource
    >>> image = ImageResource(
            id="img1",
            source_image="docker.io/alpine:3.16.7",
            dest_name="myimage",
            dest_tag="3.16.7")

    Attributes
    ----------
    id
        The unique fbnconfig resource identifier
    """

    id: str
    source_image: str
    dest_name: str
    dest_tag: str
    pull_upstream: bool | None = Field(default=True, exclude=True)

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            return data | {"id": info.context.get("id")}
        return data

    def read(self, client, old_state):
        pass  # not needed

    def create(self, client):
        # create a unique tag so scheduler will give us commands and not complain about
        # reusing an existing one. We want to check hashes not tags
        body = {"imageName": f"{self.dest_name}:{time.time()}"}
        upload = client.post("/scheduler2/api/images", json=body).json()
        auth_cmd = upload["dockerLoginCommand"].split(" ")
        user = auth_cmd[3]
        password = auth_cmd[5]
        reghost = auth_cmd[6]
        tag_cmd = upload["tagVersionedDockerImageCommand"].split(" ")
        # combine the repo from the api with the real tag we want
        downstream_repo = tag_cmd[3].split(":")[0]
        downstream_image = ":".join([downstream_repo, self.dest_tag])
        # pull from the upstream and apply the downstream tag
        pull_cmd = self._pull_commands(self.source_image) if self.pull_upstream else []
        tag_cmd = self._tag_commands(downstream_image)
        for cmd in pull_cmd + tag_cmd:
            subprocess.run(cmd).check_returncode()
        # get local and downstream digests to see if they match
        local_digest = self._get_local_digest(downstream_image)
        # check if the local hash matches the remote hash. If so skip the rest
        if local_digest is not None:
            downstream_images = self.get_remote_tags(client, self.dest_name, local_digest)
            matching_tag = next((tag for tag in downstream_images if tag["name"] == self.dest_tag), None)
            if matching_tag is not None:  # this image/tag combo already exists
                print("image already exists in the remote with the same digest")
                return {
                    "id": self.id,
                    "source_image": self.source_image,
                    "dest_name": self.dest_name,
                    "dest_tag": self.dest_tag,
                }
        # push the tag we actually want to have using the auth from scheduler
        push_commands = self._push_commands(downstream_image, user, password, reghost)
        for cmd in push_commands:
            subprocess.run(cmd).check_returncode()
        return {
            "id": self.id,
            "source_image": self.source_image,
            "dest_name": self.dest_name,
            "dest_tag": self.dest_tag,
        }

    @staticmethod
    def get_remote_tags(client, dest_name, local_digest):
        repo = client.get(f"/scheduler2/api/images/repository/{dest_name}")
        # todo: this could be paged
        return next((img["tags"] for img in repo.json()["values"] if img["digest"] == local_digest), [])

    @staticmethod
    def _get_local_digest(tag):
        inspect = subprocess.run(
            ["docker", "inspect", "--format", "{{json .RepoDigests}}", tag],
            capture_output=True,
            text=True,
        )
        inspect.check_returncode()
        # inspect returns:
        #   [alpine@sha256:a8cb.. fbn-qa.lusid.com/fbn-qa/beany@sha256:b797...]
        repo = tag.split(":")[0]
        return next(
            (
                digest.split("@")[1]
                for digest in json.loads(inspect.stdout)
                if digest.split("@")[0] == repo
            ),
            None,
        )

    @staticmethod
    def _push_commands(downstream_image, user, password, reghost):
        return [
            ["docker", "login", "-u", user, "--password", password, reghost],
            ["docker", "push", "-q", downstream_image],
        ]

    def _pull_commands(self, source_image):
        return [["docker", "pull", "--platform", "linux/amd64", "-q", source_image]]

    def _tag_commands(self, tag):
        return [["docker", "tag", self.source_image, tag]]

    def update(self, client, old_state):
        if (
            [self.source_image, self.dest_name, self.dest_tag] ==
            [old_state.source_image, old_state.dest_name, old_state.dest_tag]
        ):
            return None
        else:
            return self.create(client)

    @staticmethod
    def delete(client, old_state):
        # no delete for images
        pass

    def deps(self):
        return []

    @classmethod
    def repository_list_endpoint(cls) -> str:
        return "/scheduler2/api/images/repository"

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/scheduler2/api/images/repository/{destName}"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/scheduler2/api/images/{destName}:{destTag}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"image_{'_'.join(data[x] for x in ('destName', 'destTag'))}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "destName": data["destName"],
            "destTag": data["destTag"]
        }

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data.pop("pushTime", None)
        data.pop("pullTime", None)
        data.pop("digest", None)
        data.pop("size", None)
        data.pop("scanReport", None)
        data.pop("scanStatus", None)
        data.pop("scanSummary", None)
        data.pop("link", None)
        data.pop("tags", None)
        data.pop("name", None)

        data["sourceImage"] = f"{data['destName']}:{data['destTag']}"

        data["id"] = cls.create_resource_id(data)

        return data

    @classmethod
    def extract_list_items(
            cls,
            data: dict[str, Any],
            query_params: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """
        Flattening the results if an image has multiple tags.
        """
        return [
            {
                "destName": image["name"],
                "destTag": tag["name"]
            }
            for image in data["values"]
            for tag in image["tags"]
        ]

    @classmethod
    async def list(
            cls,
            client: AsyncClient,
            query_params: dict[str, Any] | None = None,
            path_params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Retrieves Image repository records first as a part of List API journey since such a resource
        type does not exist and ImageResource can only be retrieved for a specific Image repository.
        Then retrieves ImageResource records for each Image repository.

        Page, limit and filter params are not supported since the result is flattened.
        """
        repository_url = cls.repository_list_endpoint()
        repository_response = await client.get(repository_url)
        repository_data = repository_response.json()

        try:
            async with asyncio.TaskGroup() as tg:
                base_list = super().list
                tasks = [
                    tg.create_task(base_list(client, path_params={"destName": repository["name"]}))
                    for repository
                    in repository_data["values"]
                ]

            results = [task.result() for task in tasks]

            return {
                "values": [
                    value
                    for data in results
                    for value in data.get("values", [])
                ]
            }
        except ExceptionGroup as eg:
            for exc in eg.exceptions:
                print(f"Sub-exception: {exc}")
            raise


def ser_image_key(value, info):
    if info.context and info.context.get("style") == "dump":
        return {"$ref": value.id}
    return value


def des_image_key(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


ImageKey = Annotated[
    ImageResource | ImageRef,
    BeforeValidator(des_image_key),
    PlainSerializer(ser_image_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.Image"}},
            "required": ["$ref"],
        }
    ),
]


class CommandlineArg(BaseModel, CamelAlias):
    """Define a commandline ArgumentDefinition for a JobResource"""

    data_type: Literal["String", "Int"]
    required: Optional[bool] = False
    description: str
    order: PositiveInt
    passed_as: Literal["CommandLine"] = "CommandLine"
    default_value: None | str = None


class EnvironmentArg(BaseModel, CamelAlias):
    """Define a environment ArgumentDefinition for a JobResource"""

    data_type: Literal["String", "Int", "SecureString", "Configuration"]
    required: Optional[bool] = False
    description: str
    order: PositiveInt
    passed_as: Literal["EnvironmentVariable"] = "EnvironmentVariable"
    default_value: None | str | cfg.ItemRef | cfg.ItemResource = None

    @field_serializer("default_value", when_used="always")
    def ser_value(self, value, info) -> Dict[str, str] | str | None:
        style = info.context.get("style", "api") if info.context else "api"
        if style == "dump":
            if isinstance(value, (cfg.ItemRef, cfg.ItemResource)):
                return {"$ref": value.id}
            return value
        # api style print is as config:abc
        if value is None:
            return None
        if isinstance(value, (cfg.ItemRef, cfg.ItemResource)):
            return value.ref
        return value

    @field_validator("default_value", mode="before")
    @classmethod
    def des_value(cls, value, info):
        if info.context and info.context.get("$refs"):
            if isinstance(value, dict) and value.get("$ref"):
                return info.context["$refs"][value["$ref"]]
        return value


JobArgument = Annotated[CommandlineArg | EnvironmentArg, Field(discriminator="passed_as")]


@register_resource(group=GROUP)
class JobRef(BaseModel, Ref):
    """Reference an existing scheduler job

    Attributes
    ----------
    code
        The code of the job
    id
        The unique fbnconfig resource identifier
    scope
        The scope of the job
    """

    id: str = Field(exclude=True)
    scope: str
    code: str

    _content_hash: str | None = None

    def attach(self, client):
        # just check it exists
        search = client.get(
            "/scheduler2/api/jobs",
            params={"filter": f"jobId.scope eq '{self.scope}' and jobId.code eq '{self.code}'"},
        )

        current = next((job for job in search.json()["values"]), None)
        if current is None:
            raise RuntimeError(
                f"Failed to attach JobRef to job with scope={self.scope} and code={self.code}"
            )

        self._content_hash = hashlib.sha256(json.dumps(current, sort_keys=True).encode()).hexdigest()


class JobState(BaseModel):
    id: str
    scope: str
    code: str


@register_resource(group=GROUP, keys=["scope", "code"])
class JobResource(BaseModel, Resource, ListMixin):
    """Manage a JobDefinition

    Attributes
    ----------
    argument_definitions
        All arguments for this job to run
    author
        Author of the job
    code
        The code of the job
    command_line_argument_separator
        Value to separate command line arguments e.g : If a job has a command line argument named
        'folder' and the runtime value is 's3://path' then this would be supplied to the command as
        'folder{separatorValue}s3://path' Default to a space
    date_created
        Date when job was created. Defaults to now.
    description
        Description of this job
    id
        The unique fbnconfig resource identifier
    max_cpu
        Specifies  maximum number of CPUs to be allocated for the job
    max_memory
        Specifies the maximum amount of memory to be allocated for the job
    min_cpu
        Specifies  minimum number of CPUs to be allocated for the job Default to 2
    min_memory
        Specifies the minimum amount of memory  to be allocated for the job
    name
        Name of the job
    scope
        The scope of the job
    ttl
        Time To Live of the job run in seconds Defaults to 5 minutes(300)
    """

    id: str = Field(exclude=True)
    scope: str = Field(exclude=False, init=True)
    code: str = Field(exclude=False, init=True)
    image: ImageKey
    name: str
    author: Optional[str] = None
    date_created: Optional[datetime] = None
    description: str
    ttl: Optional[PositiveInt] = None
    min_cpu: Optional[CPU] = None
    max_cpu: Optional[CPU] = None
    min_memory: Optional[Memory] = None
    max_memory: Optional[Memory] = None
    argument_definitions: Dict[str, JobArgument] = {}
    command_line_argument_separator: Optional[str] = None

    class ScanTimeoutParameters:
        tries = 120
        wait_time = 1

    @computed_field
    def job_id(self) -> Dict[str, str]:
        return {"scope": self.scope, "code": self.code}

    @computed_field
    def image_name(self) -> str:
        return self.image.dest_name

    @computed_field
    def image_tag(self) -> str:
        return self.image.dest_tag

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Dict[str, Any], info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # handle the list api returning dockerImage instead of image
        if data.get("dockerImage", None):
            data = data | {"image": data["dockerImage"]}
            data.pop("dockerImage")
        # Handle API list response format (jobIdd.scope and jobIdd.code)
        if isinstance(data.get("jobId", None), dict):
            data = data | data["jobId"]
            data.pop("jobId")
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    @field_validator("image", mode="before")
    @classmethod
    def des_image(cls, image, info) -> ImageResource | ImageRef:
        if info.context and info.context.get("$refs"):
            return info.context["$refs"][image["$ref"]]
        return image

    def read(self, client: Client, old_state):
        search = client.get(
            "/scheduler2/api/jobs",
            params={
                "filter": f"jobId.scope eq '{old_state.scope}' and jobId.code eq '{old_state.code}'"
            },
        )
        current = next(job for job in search.json()["values"])
        # normalise the current values
        current.pop("jobId")
        current.pop("requiredResources")
        current["imageName"] = current["dockerImage"].split(":")[
            0
        ]  # we get dockerImage but have to send separately :(
        current["imageTag"] = current["dockerImage"].split(":")[1]
        current.pop("dockerImage")
        return current

    def _wait_for_vulnerability_scan(self, client):
        tries = self.ScanTimeoutParameters.tries
        while True:
            values = client.get(f"/scheduler2/api/images/repository/{self.image_name}").json()["values"]

            filtered_images = [v for v in values if self.image_tag in [tag["name"] for tag in v["tags"]]]

            if any(v["scanStatus"] == "COMPLETE" for v in filtered_images):
                break
            if any(
                (
                    v["scanStatus"]
                    in (
                        "FAILED",
                        "UNSUPPORTED_IMAGE",
                        "SCAN_ELIGIBILITY_EXPIRED",
                        "FINDINGS_UNAVAILABLE",
                    )
                    for v in filtered_images
                )
            ):
                raise RuntimeError("Image vulnerability scan failed.")
            time.sleep(self.ScanTimeoutParameters.wait_time)
            tries -= 1
            if tries < 1:
                raise RuntimeError("Image vulnerability scan timed out.")

    def create(self, client):
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True,
                                  exclude={"scope", "code", "image"})
        self._wait_for_vulnerability_scan(client)
        client.post("/scheduler2/api/jobs", json=desired)
        new_state = JobState(id=self.id, scope=self.scope, code=self.code)
        return new_state.model_dump()

    def update(self, client: Client, old_state):
        if self.scope != old_state.scope or self.code != old_state.code:
            raise (RuntimeError("Cannot change identifier on job. Create a new one"))

        remote = self.read(client, old_state)
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True,
                                  exclude={"job_id", "scope", "code", "image"})
        effective = remote | desired
        remote_args = remote["argumentDefinitions"]
        effective_args: dict[str, dict] = defaultdict(None)
        for arg_key, arg_value in desired["argumentDefinitions"].items():
            v: dict[str, str] = remote_args.get(arg_key, {}) | arg_value
            # if desired state does not have a default value, remove it from effective
            if arg_value.get("defaultValue", None) is None:
                v.pop("defaultValue", None)
            effective_args[arg_key] = v

        effective["argumentDefinitions"] = effective_args
        if effective == remote:
            return None
        self._wait_for_vulnerability_scan(client)
        client.put(f"/scheduler2/api/jobs/{self.scope}/{self.code}", json=desired)
        new_state = JobState(id=self.id, scope=self.scope, code=self.code)
        return new_state.model_dump()

    @staticmethod
    def delete(client: Client, old_state):
        client.delete(f"/scheduler2/api/jobs/{old_state.scope}/{old_state.code}")

    def cleanup(self, client, old_state):
        if self.scope != old_state.scope or self.code != old_state.code:
            return self.delete(client, old_state)
        return None

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/scheduler2/api/jobs"

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data = data | data.pop("jobId")
        data.pop("requiredResources", None)
        docker_image = data.pop("dockerImage")
        dest_name, dest_tag = docker_image.rsplit(":", 1)

        data["id"] = cls.create_resource_id(data)

        image_keys = {
            "destName": dest_name,
            "destTag": dest_tag
        }
        data["image"] = {
            "$ref": ImageResource.create_resource_id(image_keys),
            "metadata": {
                "keys": image_keys,
                "resource": getattr(ImageResource, "resource_type")
            }
        }

        return data

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"job_{data['scope']}_{data['code']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return data["jobId"]

    def deps(self):
        config_args: List[cfg.ItemRef | cfg.ItemResource] = [
            arg.default_value
            for arg in self.argument_definitions.values()
            if isinstance(arg.default_value, (cfg.ItemRef, cfg.ItemResource))
        ]
        return [self.image] + config_args


def ser_job_key(value, info):
    if info.context and info.context.get("style") == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_job_key(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


JobKey = Annotated[
    JobResource | JobRef,
    BeforeValidator(des_job_key),
    PlainSerializer(ser_job_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.Job"}},
            "required": ["$ref"],
        }
    ),
]


class ScheduleState(BaseModel):
    id: str
    scope: str
    code: str
    # Suppress to keep backwards comp with existing state
    argKeys: List[str]  # noqa: N815


@register_resource(group=GROUP, keys=["scope", "code"])
class ScheduleResource(BaseModel, Resource, ListMixin, FetchMixin):
    """Manage a ScheduleDefinition

    Attributes
    ----------
    arguments
        All arguments specified by this Schedule that will be passed in to the Job
    author
        Name of the author of this schedule
    code
        The schedule cde
    description
        A description of the Schedule
    enabled
        Specify whether schedule is enabled or not Defaults to true
    id
        The unique fbnconfig resource identifier
    name
        A display name for this Schedule
    owner
        Name of owner of this schedule
    scope
        The schedule scope
    use_as_auth
        Id of user associated with schedule. All calls to FINBOURNE services as part of execution of this
        schedule will be authenticated as this  user. Can be null, in which case we'll default to that of
        the user  making this request
    """

    id: str = Field(exclude=True)
    name: str
    scope: str
    code: str
    expression: str
    timezone: Optional[Timezone] = None
    job: JobKey
    description: str
    author: Optional[str] = None
    owner: Optional[str] = None
    arguments: None | Dict[str, str | cfg.ItemKey] = None
    enabled: Optional[bool] = None
    use_as_auth: identity.UserKey | None = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # Handle API list response format (jobIdd.scope and jobIdd.code)
        if isinstance(data.get("scheduleIdentifier", None), dict):
            data = data | data["scheduleIdentifier"]
            data.pop("scheduleIdentifier")
        # api list format uses jobId.scope and jobId.code, we want job
        if isinstance(data.get("jobId", None), dict):
            data = data | {"job": data["jobId"]}
            data.pop("jobId")
        # promote the trigger fields up to the top and change case in timeZone
        if isinstance(data.get("trigger", None), dict):
            time_trigger = data["trigger"]["timeTrigger"]
            data = data | {
                "expression": time_trigger["expression"],
                "timezone": time_trigger["timeZone"]
            }
            data.pop("trigger")
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    @computed_field
    def job_id(self) -> Dict[str, str]:
        """Return the job identifier as a dictionary"""
        return {"scope": self.job.scope, "code": self.job.code}

    @computed_field
    def schedule_id(self) -> Dict[str, str]:
        return {"scope": self.scope, "code": self.code}

    @computed_field
    def trigger(self) -> Dict[str, Dict[str, str]]:
        time_trigger = {"timeTrigger": {"expression": self.expression}}

        if self.timezone is not None:
            time_trigger["timeTrigger"]["timeZone"] = self.timezone

        return time_trigger

    def read(self, client, old_state):
        get = client.get(f"/scheduler2/api/schedules/{old_state.scope}/{old_state.code}")
        current = get.json()
        # note scheduleId for create scheduleIdentifier for read :(
        current.pop("scheduleIdentifier")
        return current

    def create(self, client):
        body = self.model_dump(
            mode="json",
            exclude_none=True,
            by_alias=True,
            exclude={"job", "scope", "code", "expression", "timezone"},
        )
        client.post("/scheduler2/api/schedules", json=body)
        arg_keys = list(self.arguments.keys()) if self.arguments else []
        return ScheduleState(id=self.id, scope=self.scope, code=self.code, argKeys=arg_keys).model_dump()

    def update(self, client, old_state):
        if self.scope != old_state.scope or self.code != old_state.code:
            from_id = f"{old_state.scope}/{old_state.code}"
            to_id = f"{self.scope}/{self.code}"
            raise (RuntimeError(f"Cannot change schedule identifier. From: '{from_id}', to: '{to_id}'"))

        remote = self.read(client, old_state)
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True,
          exclude={"schedule_id", "job", "scope", "code", "expression", "timezone"}
        )
        effective = remote | desired
        # On read the schedule will contain schedule args and args from the job.
        # Only update if the user specified args are different to the remote
        effective["arguments"] = remote.get("arguments", {}) | desired.get("arguments", {})
        arg_keys = list(self.arguments.keys()) if self.arguments else []
        if effective == remote and arg_keys == getattr(old_state, "argKeys", []):
            return None
        client.put(f"/scheduler2/api/schedules/{self.scope}/{self.code}", json=desired)
        return ScheduleState(id=self.id, scope=self.scope, code=self.code, argKeys=arg_keys).model_dump()

    @staticmethod
    def delete(client, old_state):
        try:
            client.delete(f"/scheduler2/api/schedules/{old_state.scope}/{old_state.code}")
        except HTTPStatusError as ex:
            content = ex.response.json()
            if (
                ex.response.status_code == 404
                and content.get("name", None) == "ValidationError"
                and content.get("title", None) == "Schedule could not be found"
            ):
                pass  # don't throw if schedule was already deleted
            else:
                raise ex

    def deps(self):
        config_args: List[cfg.ItemRef | cfg.ItemResource] = (
            [
                value
                for value in self.arguments.values()
                if isinstance(value, (cfg.ItemRef, cfg.ItemResource))
            ]
            if self.arguments
            else []
        )

        return [self.job] + config_args + ([self.use_as_auth] if self.use_as_auth is not None else [])

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/scheduler2/api/schedules"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/scheduler2/api/schedules/{scope}/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"schedule_{'_'.join(data[x] for x in ('scope', 'code'))}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {k: data["scheduleIdentifier"][k] for k in ("scope", "code")}

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data.pop("notifications", None)
        data = data | data.pop("scheduleIdentifier")

        if job := data.pop("jobId", None):
            job_keys = {
                "scope": job["scope"],
                "code": job["code"]
            }
            data["job"] = {
                "$ref": JobResource.create_resource_id(job_keys),
                "metadata": {
                    "keys": job_keys,
                    "resource": getattr(JobResource, "resource_type")
                }
            }
        if use_as_auth := data.pop("useAsAuth", None):
            data["useAsAuth"] = {
                "$ref": identity.UserResource.create_resource_id({"id": use_as_auth}),
                "metadata": {
                    "keys": {"userId": use_as_auth},
                    "resource": getattr(identity.UserResource, "resource_type")
                }
            }
        if trigger := data.pop("trigger", None):
            time_trigger = trigger["timeTrigger"]
            data = data | {
                "expression": time_trigger["expression"],
                "timezone": time_trigger.get("timeZone", None)
            }

        data["id"] = cls.create_resource_id(data)

        return data


@register_resource(group=GROUP)
class ScheduleRef(BaseModel, Ref):
    """Used to reference an existing schedule

    Attributes
    ----------
    code
        The schedule cde
    id
        The unique fbnconfig resource identifier
    scope
        The schedule scope
    """

    id: str = Field(exclude=True)
    scope: str
    code: str

    def attach(self, client):
        scope, code = self.scope, self.code
        try:
            client.get(f"/scheduler2/api/schedules/{scope}/{code}")
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Schedule {scope}/{code} not found")
            else:
                raise ex
