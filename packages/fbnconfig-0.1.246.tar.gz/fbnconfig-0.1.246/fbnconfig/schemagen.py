import json
import re
from typing import Any, Dict, List, Union

import click
from pydantic import BaseModel, json_schema

from fbnconfig.resource_abc import RESOURCE_REGISTRY, CamelAlias


def _indent_len(line: str) -> int:
    """Count leading spaces in a line."""
    return len(line) - len(line.lstrip(" "))


def parse_docstring_attrs(doc: str | None) -> dict[str, str]:
    """Parse numpy-style Attributes section into {field_name: description}.

    Handles both formats:
        field_name : type            field_name
            Description.                 Description.
    """
    if not doc:
        return {}
    lines = doc.split("\n")
    in_attrs = False
    attrs: dict[str, str] = {}
    current_name: str | None = None
    current_indent = 0
    current_desc: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.rstrip(":") == "Attributes":
            in_attrs = True
            continue
        if in_attrs and stripped.startswith("---"):
            continue
        if not in_attrs:
            continue
        if stripped and not line.startswith((" ", "\t")):
            break
        if not stripped:
            continue
        indent = _indent_len(line)
        if current_name and indent > current_indent:
            current_desc.append(stripped)
        else:
            if current_name:
                attrs[current_name] = " ".join(current_desc).strip()
            current_name = stripped.split(":")[0].strip()
            current_indent = indent
            current_desc = []
    if current_name:
        attrs[current_name] = " ".join(current_desc).strip()
    return attrs


def trim_docstring(desc: str) -> str:
    """Remove Example and Attributes sections from a docstring."""
    lines = desc.split("\n")
    result = []
    for line in lines:
        stripped = line.strip()
        if stripped.rstrip(":") in ("Example", "Examples", "Attributes"):
            break
        result.append(line)
    return "\n".join(result).strip()


def create_resource_union():
    resource_classes = tuple(info["class"] for info in RESOURCE_REGISTRY.values())
    return Union[resource_classes]


# this is the class that will define the types that go into the schema
ResourceOrRef = create_resource_union()


class Resource(BaseModel, CamelAlias):
    resource_id: str
    resource_type: str
    value: ResourceOrRef  # pyright: ignore[reportInvalidTypeForm]


class Deployment(BaseModel, CamelAlias):
    deployment_id: str
    resources: List[Resource]


class CustomSchemaGenerator(json_schema.GenerateJsonSchema):

    def model_schema(self, schema):
        model_class = schema["cls"]
        json_schema = super().model_schema(schema)
        # trim Example/Attributes sections from class description
        if "description" in json_schema:
            trimmed = trim_docstring(json_schema["description"])
            if trimmed:
                json_schema["description"] = trimmed
            else:
                del json_schema["description"]
        # if it has been registered as a resource/ref remove the id field
        if getattr(model_class, "resource_type", None):
            json_schema["properties"].pop("id", None)
            json_schema["required"] = [i for i in json_schema["required"] if i != "id"]
        # build alias -> python field name map
        alias_to_field: dict[str, str] = {}
        for field_name, info in model_class.model_fields.items():
            alias_to_field[info.serialization_alias or field_name] = field_name
        doc_attrs = parse_docstring_attrs(model_class.__doc__)
        # for each json property, lookup the corresponding field in the python class
        for prop_name, prop in json_schema["properties"].items():
            field_name = alias_to_field.get(prop_name)
            if not field_name:
                continue
            model_field = model_class.model_fields[field_name]
            # if its not an init field, mark it as readonly so the ui can hide it
            if model_field.init is False or model_field.exclude:
                prop["readOnly"] = True
            # inject description from docstring
            desc = doc_attrs.get(field_name)
            if desc:
                prop["description"] = desc
        return json_schema

    def get_title_from_name(self, name):
        return camel_to_sentence(name)


def camel_to_sentence(inp):
    if len(inp) == 0:
        return inp
    output = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", inp)
    output = output[0].upper() + output[1:]
    return output


def simplify_prop(k, p):
    # if it is an anyOf remove any nulls
    if p.get("anyOf", None):
        options = [e for e in p["anyOf"] if e.get("type", None) != "null"]
        if len(options) == 1:
            p = p | options[0]
            p.pop("anyOf")
        if len(options) > 1:
            p = p | {"anyOf": options}
    # any allOf with only one element can be flattened
    if p.get("allOf", None) and len(p["allOf"]) == 1:
        p = p | p["allOf"][0]
        p.pop("allOf")
    # # create a title if there isn't one
    p = p | {"title": camel_to_sentence(k)}
    return p


def simplify_def(d):
    if d.get("description"):
        trimmed = trim_docstring(d["description"])
        if trimmed:
            d = d | {"description": trimmed}
        else:
            d = {k: v for k, v in d.items() if k != "description"}
    if d.get("properties"):
        new_props = {k: simplify_prop(k, p) for k, p in d["properties"].items()}
        d = d | {"properties": new_props}
    return d


def sanitize(schema: Dict[str, Any]) -> Dict[str, Any]:
    # top level properties
    schema = simplify_def(schema)
    # embedded defs
    defs = schema.get("$defs", None)
    if defs is None:
        return schema
    new_defs = {k: simplify_def(d) for k, d in defs.items()}
    return schema | {"$defs": new_defs}


class RegexOption(click.ParamType):
    name = "regex"

    def convert(self, value, param, ctx):
        try:
            return re.compile(value)
        except re.error as e:
            self.fail(f"Invalid regex: {e}", param, ctx)


@click.command()
@click.option("-m", "--mini-schemas", is_flag=True)
@click.option("-p", "--pattern", type=RegexOption(),
              help="Regexp to filter the mini-schema resource types")
def main(mini_schemas, pattern):
    if mini_schemas:
        schema = cmd_mini_schemas(pattern)
    else:
        schema = cmd_deployment_schema()
    print(json.dumps(schema, indent=2))


def schema(klass):
    schema = klass.model_json_schema(
        mode="validation",
        ref_template="#/$defs/{model}",
        schema_generator=CustomSchemaGenerator
    )
    return sanitize(schema)


def cmd_mini_schemas(pattern):
    return {
        key: schema(v["class"])
        for key, v in RESOURCE_REGISTRY.items()
        if pattern.match(key)
    }


def cmd_deployment_schema():
    return schema(Deployment)


if __name__ == "__main__":
    main()
