from __future__ import annotations

import copy
from enum import StrEnum
from typing import Annotated, Any, Dict, List

import httpx
from pydantic import BaseModel, BeforeValidator, Field, PlainSerializer, WithJsonSchema, model_validator

from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource

GROUP = "Data Model"


class TypeValueRange(StrEnum):
    OPEN = "Open"
    CLOSED = "Closed"


class ValueType(StrEnum):
    BOOLEAN = "Boolean"
    CODE = "Code"
    CURRENCY = "Currency"
    CURRENCY_AND_AMOUNT = "CurrencyAndAmount"
    CUT_LOCAL_TIME = "CutLocalTime"
    DATE_OR_CUTLABEL = "DateOrCutLabel"
    DATE_TIME = "DateTime"
    DECIMAL = "Decimal"
    ID = "Id"
    INT = "Int"
    LIST = "List"
    MAP = "Map"
    METRIC_VALUE = "MetricValue"
    PERCENTAGE = "Percentage"
    PROPERTY_ARRAY = "PropertyArray"
    RESOURCE_ID = "ResourceId"
    RESULT_VALUE = "ResultValue"
    STRING = "String"
    TRADE_PRICE = "TradePrice"
    UNINDEXED_TEXT = "UnindexedText"
    URI = "Uri"


class FieldValueType(StrEnum):
    STRING = "String"
    DECIMAL = "Decimal"


class Unit(BaseModel, CamelAlias):
    """
    Attributes
    ----------
    code
        The code used to identify an entity
    description
        The long form description of the portfolio.
    display_name
        The name of the portfolio.
    """
    code: str
    display_name: str
    description: str
    details: Any | None = None


class UnitSchema(StrEnum):
    NO_UNITS = "NoUnits"
    BASIC = "Basic"
    ISO4217_CURRENCY = "Iso4217Currency"


class FieldDefinition(BaseModel, CamelAlias):
    key: str
    is_required: bool
    is_unique: bool
    value_type: str | FieldValueType = FieldValueType.STRING


class FieldValue(BaseModel):
    value: str
    fields: Dict[str, str]  # limit to strings because get returns strings


class ReferenceData(BaseModel, CamelAlias):
    field_definitions: List[FieldDefinition]
    values: List[FieldValue]


@register_resource(group=GROUP)
class DataTypeRef(BaseModel, Ref):
    """
    Attributes
    ----------
    code
        The code of the data type. Together with the scope this uniquely defines the data type.
    id
        The unique fbnconfig resource identifier
    scope
        The scope that the data type will be created in.
    """
    id: str = Field(exclude=True)
    scope: str
    code: str

    def attach(self, client):
        scope, code = self.scope, self.code
        try:
            client.get(f"/api/api/datatypes/{scope}/{code}", params={"includeSystem": True})
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Datatype {scope}/{code} not found")
            else:
                raise ex


@register_resource(group=GROUP, keys=["scope", "code"])
class DataTypeResource(CamelAlias, BaseModel, Resource, ListMixin, FetchMixin):
    """
    Attributes
    ----------
    acceptable_units
        The definitions of the acceptable units.
    acceptable_values
        The acceptable set of values for this data type. Only applies to 'open' value type range.
    code
        The code of the data type. Together with the scope this uniquely defines the data type.
    description
        The description of the data type.
    display_name
        The display name of the data type.
    id
        The unique fbnconfig resource identifier
    scope
        The scope that the data type will be created in.
    type_value_range
        Indicates the range of data acceptable by a data type
    unit_schema
        The schema of the data type's units
    value_type
        The expected type of the values
    """
    id: str = Field(exclude=True)
    scope: str
    code: str
    type_value_range: TypeValueRange
    display_name: str
    description: str
    value_type: ValueType
    acceptable_values: List[str] | None = None
    unit_schema: UnitSchema = UnitSchema.NO_UNITS
    acceptable_units: List[Unit] | None = None
    reference_data: ReferenceData | None = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if isinstance(data.get("id", None), dict):
            data = data | data.pop("id")
        if info.context and info.context.get("id"):
            return data | {"id": info.context.get("id")}
        return data

    def read(self, client, old_state) -> Dict[str, Any]:
        return client.get(f"/api/api/datatypes/{old_state.scope}/{old_state.code}").json()

    def create(self, client: httpx.Client):
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        client.post("/api/api/datatypes", json=desired)
        return {"scope": self.scope, "code": self.code}

    def update(self, client: httpx.Client, old_state):
        if [self.scope, self.code] != [old_state.scope, old_state.code]:
            raise RuntimeError("Cannot change scope/code on datatype")
        remote = self.read(client, old_state)
        remote.pop("href")
        remote.pop("id")
        remote.pop("links")
        remote.pop("version")
        desired = self.model_dump(
            mode="json", exclude_none=True, exclude={"scope", "code"}, by_alias=True
        )
        effective = remote | copy.deepcopy(desired)
        if "referenceData" in remote and "referenceData" in effective:
            # sort the fields since the api changes the order they come back
            remote["referenceData"]["fieldDefinitions"].sort(key=lambda field: field["key"])
            effective["referenceData"]["fieldDefinitions"].sort(key=lambda field: field["key"])
            # sort the values since the api changes the order they come back
            remote["referenceData"]["values"].sort(key=lambda field: field["value"])
            effective["referenceData"]["values"].sort(key=lambda field: field["value"])
        if "acceptableValues" in remote and "acceptableValues" in effective:
            # sort the acceptableValues since the api changes the order they come back
            remote["acceptableValues"].sort()
            effective["acceptableValues"].sort()
        if effective == remote:
            return None
        # check for illegal modifications
        readonly_fields = ["typeValueRange", "unitSchema", "valueType"]
        modified = [field for field in readonly_fields if effective[field] != remote[field]]
        if len(modified) > 0:
            raise RuntimeError(f"Cannot change readonly fields {modified} on datatype")
        # update the reference data if modified
        if effective["referenceData"] != remote["referenceData"]:
            ref_payload = {
                "requestDefinitions": effective["referenceData"]["fieldDefinitions"],
                "requestValues": effective["referenceData"]["values"],
            }
            client.put(
                f"/api/api/datatypes/{self.scope}/{self.code}/referencedata",
                json=ref_payload
            )
        # update core data if required
        effective.pop("referenceData")
        remote.pop("referenceData")
        if effective != remote:
            client.put(f"/api/api/datatypes/{self.scope}/{self.code}", json=desired)
        return {"scope": self.scope, "code": self.code}

    @staticmethod
    def delete(client, old_state):
        client.delete(f"/api/api/datatypes/{old_state.scope}/{old_state.code}")

    def deps(self):
        return []

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/api/api/datatypes"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/api/api/datatypes/{scope}/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"datatype_{data['scope']}_{data['code']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return data["id"]

    @classmethod
    def from_api(cls, data: Dict[str, Any]) -> dict[str, Any]:
        data.pop("version", None)
        data.pop("links", None)
        data.pop("href", None)
        data.pop("stagedModifications", None)

        data = data | data["id"]
        data["id"] = cls.create_resource_id(data)
        return data


class ResourceId(BaseModel):
    scope: str
    code: str


def ser_datatype_key(value: ResourceId | DataTypeRef | DataTypeResource, info):
    style = info.context.get("style", "api") if info.context else "api"
    if style == "dump":
        if isinstance(value, (Resource, Ref)):
            return {"$ref": value.id}
        return value
    # uses str.format to interpolate the values for the api request
    return {"scope": value.scope, "code": value.code}


def des_datatype_key(value, info):
    if info.context and info.context.get("$refs"):
        return info.context["$refs"][value["$ref"]]
    return value


# as a special case, we allow system datatypes to be represented as ResourceId
# so users don't have to create refs for them.
DataTypeKey = Annotated[
    ResourceId | DataTypeRef | DataTypeResource,
    BeforeValidator(des_datatype_key),
    PlainSerializer(ser_datatype_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "DataTypeKey"}},
            "required": ["$ref"],
        }
    ),
]
