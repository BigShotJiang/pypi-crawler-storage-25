# Types used across multiple resources which do not depend on any other resource types
from __future__ import annotations

import datetime as dt
from typing import Annotated, Any, Dict, Mapping

from pydantic import BaseModel, BeforeValidator, EmailStr, PlainSerializer, WithJsonSchema


class ResourceId(BaseModel):
    """
    Attributes
    ----------
    code
        Portfolio name or code.
    scope
        The scope within which the portfolio or portfolio group lives.
    """
    scope: str
    code: str


def des_isodate(value: str | dt.date | dt.datetime) -> dt.date:
    """Deserialize ISO 8601 date."""
    if isinstance(value, dt.datetime):
        return value.astimezone(tz=dt.timezone.utc)
    if isinstance(value, str):
        return dt.datetime.fromisoformat(value)
    return value


def ser_isodate(value: dt.datetime) -> str:
    """Serialize datetime object to ISO 8601 string."""
    return value.isoformat()


IsoDateTime = Annotated[
    str | dt.datetime | dt.date,
    BeforeValidator(des_isodate), PlainSerializer(ser_isodate)
]

StrDateTime = Annotated[
    str,
    WithJsonSchema(
        {
            "type": "string",
            "format": "date-time"
        }
    )
]

JsonValue = Annotated[
    Any,
    WithJsonSchema(
        {
            "format": "json"
        }
    ),
]

JsonObject = Annotated[
    Dict[Any, Any],
    WithJsonSchema(
        {
            "type": "object",
            "format": "json"
        }
    ),
]

JsonMapping = Annotated[
    Mapping[str, Any],
    WithJsonSchema(
        {
            "type": "object",
            "format": "json"
        }
    ),
]


Timezone = Annotated[
    str,
    WithJsonSchema(
        {
            "type": "string",
            "format": "timezone"
        }
    )
]

Email = Annotated[
    EmailStr,
    WithJsonSchema(
        {
            "type": "string",
            "format": "email"
        }
    )
]

PositiveInt = Annotated[
    int,
    WithJsonSchema(
        {
            "type": "integer",
            "format": "positiveInt",
            "exclusiveMinimum": 0
        }
    )
]

SqlString = Annotated[
    str,
    WithJsonSchema(
        {
            "type": "string",
            "format": "sql"
        }
    )
]

Memory = Annotated[
    str,
    WithJsonSchema(
        {
            "type": "string",
            "format": "memory"
        }
    )
]

CPU = Annotated[
    str,
    WithJsonSchema(
        {
            "type": "string",
            "format": "cpu"
        }
    )
]
