from __future__ import annotations

import datetime as dt
import hashlib
import json
from enum import StrEnum
from typing import Annotated, Any, Dict, List, Sequence

import httpx
from pydantic import BaseModel, BeforeValidator, Field, PlainSerializer, model_validator

from .coretypes import IsoDateTime
from .resource_abc import CamelAlias, Ref, Resource, register_resource


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class ReferencePortfolioResource(BaseModel, Resource):
    """
    Attributes
    ----------
    base_currency
        The base currency of the transaction portfolio in ISO 4217 currency code format.
    code
        Unique identifier for the portfolio.
    created
        The original creation date, defaults to today if not specified when creating a portfolio.
    description
        A long form text description of the portfolio.
    display_name
        The name of the reference portfolio.
    id
        The unique fbnconfig resource identifier
    instrument_scopes
        Instrument Scopes.
    """
    id: str = Field(exclude=True)
    instance: str | None = None
    scope: str
    code: str
    display_name: str
    description: str | None = None
    base_currency: str | None = None
    created: IsoDateTime | None = None
    instrument_scopes: List[str] | None = None

    _PUT_FIELDS = ["displayName", "description"]
    _PATCH_FIELDS = ["created", "instrumentScopes"]

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if isinstance(data.get("id", None), dict):
            data = data | data["id"]
            data.pop("id", None)
        if info.context and info.context.get("id"):
            data["id"] = info.context["id"]
        return data

    def create(self, client: httpx.Client):
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"instance", "scope"}
        )
        resp = client.request("POST", f"/api/api/referenceportfolios/{self.scope}", json=desired).json()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        self.instance = resp["version"]["entityUniqueId"]
        return {
            "code": self.code,
            "scope": self.scope,
            "content_hash": content_hash,
            "instance": self.instance,
        }

    def read(self, client, old_state):
        scope, code = old_state.scope, old_state.code
        remote = client.request("GET", f"/api/api/portfolios/{scope}/{code}").json()
        remote.pop("version", None)
        remote.pop("links", None)
        return remote

    @staticmethod
    def _normalize_value(key, value):
        if key == "created" and isinstance(value, str):
            return dt.datetime.fromisoformat(value).date()
        return value

    def update(self, client: httpx.Client, old_state):
        self.instance = old_state.instance
        if [self.code, self.scope] != [old_state.code, old_state.scope]:
            self.delete(client, old_state)
            return self.create(client)
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"instance", "scope"}
        )
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if content_hash == old_state.content_hash:
            return None
        remote = self.read(client, old_state)
        changed = any([
            self._update_put_fields(client, desired, remote),
            self._update_patch_fields(client, desired, remote),
        ])
        if not changed:
            return None
        return {
            "code": self.code,
            "scope": self.scope,
            "content_hash": content_hash,
            "instance": old_state.instance,
        }

    def _update_put_fields(self, client, desired, remote):
        changes = {k: desired[k] for k in self._PUT_FIELDS
                   if k in desired and desired[k] != remote.get(k)}
        if not changes:
            return False
        client.request("PUT", f"/api/api/portfolios/{self.scope}/{self.code}", json=changes)
        return True

    def _update_patch_fields(self, client, desired, remote):
        ops = []
        for k in self._PATCH_FIELDS:
            if k not in desired:
                continue
            d = self._normalize_value(k, desired[k])
            r = self._normalize_value(k, remote.get(k))
            if d != r:
                ops.append({"op": "add", "path": f"/{k}", "value": desired[k]})
        if not ops:
            return False
        client.request("PATCH", f"/api/api/portfolios/{self.scope}/{self.code}", json=ops)
        return True

    @staticmethod
    def delete(client, old_state):
        client.request("DELETE", f"/api/api/portfolios/{old_state.scope}/{old_state.code}")

    def deps(self):
        return []


@register_resource(group="Portfolio Construction")
class ReferencePortfolioRef(CamelAlias, BaseModel, Ref):
    """
    Attributes
    ----------
    code
        Unique identifier for the portfolio.
    id
        The unique fbnconfig resource identifier
    """
    id: str = Field(exclude=True)
    instance: str | None = None
    scope: str
    code: str

    def attach(self, client):
        try:
            response = client.get(f"/api/api/portfolios/{self.scope}/{self.code}")
            data = response.json()
            self.instance = data["version"]["entityUniqueId"]
            return data
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(
                    f"ReferencePortfolio {self.scope}/{self.code} not found")
            raise


def ser_ref_portfolio_key(value, info):
    style = info.context.get("style", "api") if info.context else "api"
    if style == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_ref_portfolio_key(value, info):
    if not isinstance(value, dict):
        return value
    if "$ref" in value and info.context and info.context.get("$refs"):
        return info.context["$refs"][value["$ref"]]
    return value


ReferencePortfolioKey = Annotated[
    ReferencePortfolioResource | ReferencePortfolioRef,
    BeforeValidator(des_ref_portfolio_key), PlainSerializer(ser_ref_portfolio_key),
]


class WeightType(StrEnum):
    STATIC = "Static"
    FLOATING = "Floating"
    PERIODICAL = "Periodical"


class PeriodType(StrEnum):
    DAILY = "Daily"
    WEEKLY = "Weekly"
    MONTHLY = "Monthly"
    QUARTERLY = "Quarterly"
    ANNUALLY = "Annually"


class Constituent(BaseModel, CamelAlias):
    instrument_identifiers: Dict[str, str]
    weight: float
    currency: str | None = None


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class ReferencePortfolioConstituentsResource(BaseModel, Resource):
    """
    Attributes
    ----------
    constituents
        Set of constituents (instrument/weight pairings)
    effective_from
        The first date from which the weights will apply
    id
        The unique fbnconfig resource identifier
    period_type
        The available values are: Daily, Weekly, Monthly, Quarterly, Annually
    weight_type
        The available values are: Static, Floating, Periodical
    """
    id: str = Field(exclude=True)
    portfolio: ReferencePortfolioKey
    effective_from: IsoDateTime
    weight_type: str | WeightType
    period_type: str | PeriodType | None = None
    period_count: int | None = None
    constituents: Sequence[Constituent]

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            return data | {"id": info.context.get("id")}
        return data

    def _constituents_body(self):
        body = self.model_dump(
            mode="json", by_alias=True, exclude_none=True,
            exclude={"portfolio"},
        )
        return body

    def _content_hash(self, body):
        return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()

    def create(self, client: httpx.Client):
        body = self._constituents_body()
        client.request(
            "POST",
            f"/api/api/referenceportfolios/{self.portfolio.scope}/{self.portfolio.code}/constituents",
            json=body,
        )
        return {
            "portfolio_scope": self.portfolio.scope,
            "portfolio_code": self.portfolio.code,
            "portfolio_instance": self.portfolio.instance,
            "effective_from": body["effectiveFrom"],
            "content_hash": self._content_hash(body),
        }

    def read(self, client, old_state):
        resp = client.request(
            "GET",
            f"/api/api/referenceportfolios/{old_state.portfolio_scope}/{old_state.portfolio_code}/constituents",
        ).json()
        return resp.get("constituents", [])

    def update(self, client: httpx.Client, old_state):
        old_id = [old_state.portfolio_scope, old_state.portfolio_code]
        new_id = [self.portfolio.scope, self.portfolio.code]
        if old_id != new_id:
            self.delete(client, old_state)
            return self.create(client)
        portfolio_recreated = old_state.portfolio_instance != self.portfolio.instance
        if portfolio_recreated:
            return self.create(client)
        body = self._constituents_body()
        content_hash = self._content_hash(body)
        if content_hash == old_state.content_hash:
            return None
        return self.create(client)

    @staticmethod
    def delete(client, old_state):
        client.request(
            "POST",
            f"/api/api/referenceportfolios/{old_state.portfolio_scope}/{old_state.portfolio_code}/constituents",
            json={"effectiveFrom": old_state.effective_from, "weightType": "Static", "constituents": []},
        )

    def deps(self) -> List[Resource | Ref]:
        return [self.portfolio]
