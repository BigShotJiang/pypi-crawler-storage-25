from __future__ import annotations

import datetime as dt
import hashlib
import json
from enum import StrEnum
from typing import Annotated, Any, Dict, List, Sequence

import httpx
from pydantic import BaseModel, BeforeValidator, Field, PlainSerializer, model_validator

from fbnconfig import corporate_action, property, recipe, reference_portfolio

from .coretypes import IsoDateTime, ResourceId
from .properties import PropertyValueDict
from .resource_abc import CamelAlias, Ref, Resource, register_resource


class AccountingMethod(StrEnum):
    Default = "Default"
    AverageCost = "AverageCost"
    FirstInFirstOut = "FirstInFirstOut"
    LastInFirstOut = "LastInFirstOut"
    HighestCostFirst = "HighestCostFirst"
    LowestCostFirst = "LowestCostFirst"
    ProRateByUnits = "ProRateByUnits"
    ProRateByCost = "ProRateByCost"
    ProRateByCostPortfolioCurrency = "ProRateByCostPortfolioCurrency"
    IntraDayThenFirstInFirstOut = "IntraDayThenFirstInFirstOut"
    LongTermHighestCostFirst = "LongTermHighestCostFirst"
    LongTermHighestCostFirstPortfolioCurrency = "LongTermHighestCostFirstPortfolioCurrency"
    HighestCostFirstPortfolioCurrency = "HighestCostFirstPortfolioCurrency"
    LowestCostFirstPortfolioCurrency = "LowestCostFirstPortfolioCurrency"
    MaximumLossMinimumGain = "MaximumLossMinimumGain"
    MaximumLossMinimumGainPortfolioCurrency = "MaximumLossMinimumGainPortfolioCurrency"


class SettlementConfigurationCategory(BaseModel, CamelAlias):
    method: str | None = None


class SettlementConfiguration(BaseModel, CamelAlias):
    stock_settlement: SettlementConfigurationCategory
    cash_settlement: SettlementConfigurationCategory
    deferred_cash_receipt: SettlementConfigurationCategory


class InstrumentEventConfiguration(BaseModel, CamelAlias):
    recipe_id: recipe.RecipeKey | None = None   # note swagger says not null, but AD has some
    transaction_template_scopes: Sequence[str] | None


class _TransactionPortfolioMixin:
    """Shared read/update/delete logic for transaction and derived transaction portfolios."""
    scope: str
    code: str

    # PUT /api/portfolios/{scope}/{code} — displayName, description
    _PUT_FIELDS = ["displayName", "description"]

    def _update_put_fields(self, client, desired, remote):
        changes = {k: desired[k] for k in self._PUT_FIELDS
                   if k in desired and desired[k] != remote.get(k)}
        if not changes:
            return False
        client.request(
            "PUT", f"/api/api/portfolios/{self.scope}/{self.code}", json=changes,
        )
        return True

    # PATCH /api/transactionportfolios/{scope}/{code}/details
    _PATCH_DETAIL_FIELDS = [
        "accountingMethod", "subHoldingKeys",
        "amortisationMethod", "transactionTypeScope",
        "cashGainLossCalculationDate", "instrumentEventConfiguration",
        "amortisationRuleSetId", "taxRuleSetScope", "settlementConfiguration",
    ]

    def _update_patch_details(self, client, desired, remote):
        ops = []
        for k in self._PATCH_DETAIL_FIELDS:
            if k not in desired:
                continue
            if desired[k] != remote.get(k):
                ops.append({"op": "add", "path": f"/{k}", "value": desired[k]})
        if not ops:
            return False
        client.request(
            "PATCH",
            f"/api/api/transactionportfolios/{self.scope}/{self.code}/details",
            json=ops,
        )
        return True

    def read(self, client, old_state):
        scope, code = old_state.scope, old_state.code
        remote = client.request("get", f"/api/api/portfolios/{scope}/{code}").json()
        remote.pop("version", None)
        remote.pop("links", None)
        details = client.request(
            "get", f"/api/api/transactionportfolios/{scope}/{code}/details",
        ).json()
        remote["subHoldingKeys"] = details.get("subHoldingKeys", [])
        return remote

    @staticmethod
    def _normalize_value(key, value):
        if key == "created" and isinstance(value, str):
            return dt.datetime.fromisoformat(value).date()
        return value

    @staticmethod
    def delete(client, old_state):
        scope = old_state.scope
        code = old_state.code
        client.request("DELETE", f"/api/api/portfolios/{scope}/{code}")


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class PortfolioResource(BaseModel, _TransactionPortfolioMixin, Resource):
    """
    Attributes
    ----------
    accounting_method
        The available values are: Default, AverageCost, FirstInFirstOut, LastInFirstOut,
        HighestCostFirst, LowestCostFirst, ProRateByUnits, ProRateByCost, ProRateByCostPortfolioCurrency,
        IntraDayThenFirstInFirstOut, LongTermHighestCostFirst, LongTermHighestCostFirstPortfolioCurrency,
        HighestCostFirstPortfolioCurrency, LowestCostFirstPortfolioCurrency, MaximumLossMinimumGain,
        MaximumLossMinimumGainPortfolioCurrency
    amortisation_method
        The amortisation method used by the portfolio for the calculation
    base_currency
        The base currency of the portfolio.
    cash_gain_loss_calculation_date
        The scope of the transaction types.
    code
        The code used to identify an entity
    created
        The effective datetime at which the portfolio was created. No transactions or constituents can be
        added to the portfolio before this date.
    description
        The long form description of the portfolio.
    display_name
        The name of the portfolio.
    id
        The unique fbnconfig resource identifier
    instrument_scopes
        The instrument scope resolution strategy of this portfolio.
    scope
        The scope used to identify an entity
    transaction_type_scope
        The scope of the transaction types.
    """
    id: str = Field(exclude=True)
    instance: str | None = None
    scope: str
    code: str
    display_name: str
    description: str | None = None
    base_currency: str
    created: IsoDateTime
    instrument_scopes: List[str]
    transaction_type_scope: str | None = None
    transaction_type_source: str | None = None
    accounting_method: AccountingMethod | None = None
    amortisation_method: str | None = None
    cash_gain_loss_calculation_date: str | None = None
    tax_ruleset_scope: str | None = None
    settlement_configuration: SettlementConfiguration | None = None
    sub_holding_keys: Sequence[property.PropertyKey] | None = None
    instrument_event_configuration: InstrumentEventConfiguration | None = None
    corporate_action_source_id: corporate_action.CorporateActionSourceKey | None = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code
        if isinstance(data.get("id", None), dict):
            data = data | data["id"]
            data.pop("id", None)
        if info.context and info.context.get("id"):
            data["id"] = info.context["id"]
        return data

    def create(self, client: httpx.Client):
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"instance", "scope"}
        )
        url = f"/api/api/transactionportfolios/{self.scope}"
        resp = client.request("POST", url, json=desired).json()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        self.instance = resp["version"]["entityUniqueId"]
        return {
            "id": self.id,
            "code": self.code,
            "scope": self.scope,
            "content_hash": content_hash,
            "instance": self.instance   # tracks recreations of the portfolio
        }

    def update(self, client: httpx.Client, old_state):
        self.instance = old_state.instance
        if [self.code, self.scope] != [old_state.code, old_state.scope]:
            self.delete(client, old_state)
            return self.create(client)
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"instance", "scope"}
        )
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if content_hash == old_state.content_hash:
            return None
        remote = self.read(client, old_state)
        if desired.get("baseCurrency") != remote.get("baseCurrency"):
            self.delete(client, old_state)
            return self.create(client)
        changed = any([
            self._update_put_fields(client, desired, remote),
            self._update_patch_portfolio(client, desired, remote),
            self._update_patch_details(client, desired, remote),
        ])
        if not changed:
            return None
        return {
            "id": self.id,
            "code": self.code,
            "scope": self.scope,
            "content_hash": content_hash,
            "instance": old_state.instance,
        }

    # PATCH /api/portfolios/{scope}/{code} — created, instrumentScopes
    _PATCH_PORTFOLIO_FIELDS = ["created", "instrumentScopes"]

    def _update_patch_portfolio(self, client, desired, remote):
        ops = []
        for k in self._PATCH_PORTFOLIO_FIELDS:
            if k not in desired:
                continue
            d = self._normalize_value(k, desired[k])
            r = self._normalize_value(k, remote.get(k))
            if d != r:
                ops.append({"op": "add", "path": f"/{k}", "value": desired[k]})
        if not ops:
            return False
        client.request(
            "PATCH", f"/api/api/portfolios/{self.scope}/{self.code}", json=ops,
        )
        return True

    def deps(self):
        res = []
        if self.sub_holding_keys:
            for s in self.sub_holding_keys:
                res.append(s)
        if self.instrument_event_configuration:
            if self.instrument_event_configuration.recipe_id:
                res.append(self.instrument_event_configuration.recipe_id)
        if self.corporate_action_source_id:
            res.append(self.corporate_action_source_id)
        return res


@register_resource(group="Portfolio Construction")
class PortfolioRef(CamelAlias, BaseModel, Ref):
    """
    Attributes
    ----------
    code
        The code used to identify an entity
    id
        The unique fbnconfig resource identifier
    scope
        The scope used to identify an entity
    """
    id: str = Field(exclude=True)
    instance: str | None = None
    scope: str
    code: str

    def attach(self, client):
        try:
            response = client.get(f"/api/api/portfolios/{self.scope}/{self.code}")
            data = response.json()
            self.instance = data["version"]["entityUniqueId"]
            return data
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(
                    f"Portfolio {self.scope}/{self.code} not found")
            raise


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class DerivedTransactionPortfolioResource(BaseModel, _TransactionPortfolioMixin, Resource):
    """
    Attributes
    ----------
    accounting_method
        The available values are: Default, AverageCost, FirstInFirstOut, LastInFirstOut,
        HighestCostFirst, LowestCostFirst, ProRateByUnits, ProRateByCost, ProRateByCostPortfolioCurrency,
        IntraDayThenFirstInFirstOut, LongTermHighestCostFirst, LongTermHighestCostFirstPortfolioCurrency,
        HighestCostFirstPortfolioCurrency, LowestCostFirstPortfolioCurrency, MaximumLossMinimumGain,
        MaximumLossMinimumGainPortfolioCurrency
    amortisation_method
        The amortisation method used by the portfolio for the calculation
    cash_gain_loss_calculation_date
        The option when the Cash Gain Loss to be calulated, TransactionDate/SettlementDate. Defaults to
        SettlementDate.
    code
        The code of the derived transaction portfolio. Together with the scope this uniquely identifies
        the derived transaction portfolio.
    created
        This will be auto-populated to be the parent portfolio creation date.
    description
        A description for the derived transaction portfolio.
    display_name
        The name of the derived transaction portfolio.
    id
        The unique fbnconfig resource identifier
    instrument_scopes
        The resolution strategy used to resolve instruments of transactions/holdings upserted to this
        derived portfolio.
    scope
        The scope of the derived transaction portfolio.
    sub_holding_keys
        A set of unique transaction properties to group the derived transaction portfolio's holdings by,
        perhaps for strategy tagging. Each property must be from the 'Transaction' domain and identified
        by a key in the format {domain}/{scope}/{code}, for example 'Transaction/strategies/quantsignal'.
        See https://support.lusid.com/knowledgebase/article/KA-01879/en-us for more information.
    transaction_type_scope
        The scope of the transaction types.
    """
    id: str = Field(exclude=True)
    instance: str | None = None
    scope: str
    code: str
    display_name: str
    description: str | None = None
    parent_portfolio_id: PortfolioKey
    created: IsoDateTime | None = None
    instrument_scopes: List[str] | None = None
    transaction_type_scope: str | None = None
    accounting_method: AccountingMethod | None = None
    amortisation_method: str | None = None
    cash_gain_loss_calculation_date: str | None = None
    tax_ruleset_scope: str | None = None
    settlement_configuration: SettlementConfiguration | None = None
    sub_holding_keys: Sequence[property.PropertyKey] | None = None
    instrument_event_configuration: InstrumentEventConfiguration | None = None
    corporate_action_source_id: corporate_action.CorporateActionSourceKey | None = None
    amortisation_rule_set_id: ResourceId | None = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if isinstance(data.get("id", None), dict):
            data = data | data["id"]
            data.pop("id", None)
        if info.context and info.context.get("id"):
            data["id"] = info.context["id"]
        return data

    def create(self, client: httpx.Client):
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True,
            exclude={"instance", "scope", "parent_portfolio_id"},
        )
        desired["parentPortfolioId"] = {
            "scope": self.parent_portfolio_id.scope,
            "code": self.parent_portfolio_id.code,
        }
        resp = client.request(
            "POST", f"/api/api/derivedtransactionportfolios/{self.scope}", json=desired,
        ).json()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        self.instance = resp["version"]["entityUniqueId"]
        return {
            "code": self.code,
            "scope": self.scope,
            "content_hash": content_hash,
            "instance": self.instance,
        }

    def update(self, client: httpx.Client, old_state):
        self.instance = old_state.instance
        if [self.code, self.scope] != [old_state.code, old_state.scope]:
            self.delete(client, old_state)
            return self.create(client)
        desired = self.model_dump(
            mode="json", exclude_none=True, by_alias=True,
            exclude={"instance", "scope", "parent_portfolio_id"},
        )
        desired["parentPortfolioId"] = {
            "scope": self.parent_portfolio_id.scope,
            "code": self.parent_portfolio_id.code,
        }
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if content_hash == old_state.content_hash:
            return None
        remote = self.read(client, old_state)
        changed = any([
            self._update_put_fields(client, desired, remote),
            self._update_patch_details(client, desired, remote),
        ])
        if not changed:
            return None
        return {
            "code": self.code,
            "scope": self.scope,
            "content_hash": content_hash,
            "instance": old_state.instance,
        }

    def deps(self):
        res: list = [self.parent_portfolio_id]
        if self.sub_holding_keys:
            for s in self.sub_holding_keys:
                res.append(s)
        if self.instrument_event_configuration:
            if self.instrument_event_configuration.recipe_id:
                res.append(self.instrument_event_configuration.recipe_id)
        if self.corporate_action_source_id:
            res.append(self.corporate_action_source_id)
        return res


@register_resource(group="Portfolio Construction")
class DerivedTransactionPortfolioRef(CamelAlias, BaseModel, Ref):
    """
    Attributes
    ----------
    code
        The code of the derived transaction portfolio. Together with the scope this uniquely identifies
        the derived transaction portfolio.
    id
        The unique fbnconfig resource identifier
    scope
        The scope of the derived transaction portfolio.
    """
    id: str = Field(exclude=True)
    instance: str | None = None
    scope: str
    code: str

    def attach(self, client):
        try:
            response = client.get(f"/api/api/portfolios/{self.scope}/{self.code}")
            data = response.json()
            self.instance = data["version"]["entityUniqueId"]
            return data
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(
                    f"DerivedTransactionPortfolio {self.scope}/{self.code} not found")
            raise


def ser_portfolio_key(value, info):
    style = info.context.get("style", "api") if info.context else "api"
    if style == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_portfolio_key(value, info):
    if not isinstance(value, dict):
        return value
    if "$ref" in value and info.context and info.context.get("$refs"):
        return info.context["$refs"][value["$ref"]]
    return value


PortfolioKey = Annotated[
    PortfolioResource | PortfolioRef
    | DerivedTransactionPortfolioResource | DerivedTransactionPortfolioRef
    | reference_portfolio.ReferencePortfolioResource | reference_portfolio.ReferencePortfolioRef,
    BeforeValidator(des_portfolio_key), PlainSerializer(ser_portfolio_key),
]

DerivedTransactionPortfolioResource.model_rebuild()


@register_resource(group="Portfolio Construction", keys=["scope", "code"])
class PortfolioPropertiesResource(BaseModel, Resource):
    """
    Attributes
    ----------
    id
        The unique fbnconfig resource identifier
    properties
        The portfolio group properties. These will be from the 'PortfolioGroup' domain.
    """
    id: str = Field(exclude=True)
    portfolio: PortfolioKey
    properties: PropertyValueDict

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            return data | {"id": info.context.get("id")}
        return data

    def _serialize_properties(self):
        props = self.model_dump(mode="json", by_alias=True, exclude={"portfolio"})
        return props.get("properties", {})

    def read(self, client, old_state):
        resp = client.request(
            "GET",
            f"/api/api/portfolios/{old_state.portfolio_scope}/{old_state.portfolio_code}/properties",
        ).json()
        return resp.get("properties", {})

    def _make_state(self, content_hash):
        return {
            "portfolio_scope": self.portfolio.scope,
            "portfolio_code": self.portfolio.code,
            "portfolio_instance": self.portfolio.instance,
            "content_hash": content_hash,
        }

    def create(self, client):
        desired = self._serialize_properties()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if desired:
            client.request(
                "POST",
                f"/api/api/portfolios/{self.portfolio.scope}/{self.portfolio.code}/properties",
                json=desired,
            )
        return self._make_state(content_hash)

    def update(self, client: httpx.Client, old_state):
        old_id = [old_state.portfolio_scope, old_state.portfolio_code]
        new_id = [self.portfolio.scope, self.portfolio.code]
        if old_id != new_id:
            self.delete(client, old_state)
            return self.create(client)
        portfolio_recreated = old_state.portfolio_instance != self.portfolio.instance
        if portfolio_recreated:
            return self.create(client)
        desired = self._serialize_properties()
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        if content_hash == old_state.content_hash:
            return None
        remote = self.read(client, old_state)
        to_upsert = {k: v for k, v in desired.items() if remote.get(k) != v}
        if to_upsert:
            client.request(
                "POST",
                f"/api/api/portfolios/{self.portfolio.scope}/{self.portfolio.code}/properties",
                json=to_upsert,
            )
        to_delete = [k for k in remote if k not in desired]
        if to_delete:
            client.request(
                "DELETE",
                f"/api/api/portfolios/{self.portfolio.scope}/{self.portfolio.code}/properties",
                params={"propertyKeys": to_delete},
            )
        return self._make_state(content_hash)

    @staticmethod
    def delete(client, old_state):
        scope = old_state.portfolio_scope
        code = old_state.portfolio_code
        try:
            resp = client.request(
                "GET",
                f"/api/api/portfolios/{scope}/{code}/properties",
            ).json()
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                return
            raise
        remote_keys = list(resp.get("properties", {}).keys())
        if not remote_keys:
            return
        client.request(
            "DELETE",
            f"/api/api/portfolios/{scope}/{code}/properties",
            params={"propertyKeys": remote_keys},
        )

    def deps(self) -> List[Resource | Ref]:
        res: List[Resource | Ref] = [self.portfolio]
        for p in self.properties:
            res.append(p.property_key)
        return res
