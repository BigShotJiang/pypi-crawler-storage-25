"""Shared helpers for inline property resources."""
from __future__ import annotations

import csv
import textwrap
from io import StringIO
from typing import TYPE_CHECKING, Any, Dict, Sequence

import httpx

from .backoff_handler import BackoffHandler

if TYPE_CHECKING:
    from .lumi import InlineProperty


def _query(client: httpx.Client, sql: str, backoff_handler: BackoffHandler):
    """Lazy import of lumi.query to avoid circular imports."""
    from .lumi import query
    return query(client, sql, backoff_handler=backoff_handler)


class InlineProviderOps:
    """Pure class methods for inline property CRUD operations."""

    @classmethod
    def parse_csv(cls, rows: Any) -> dict[str, dict]:
        """Parse a Sys.File CSV response into a property dict keyed by Key."""
        csv_str = rows[0]["Content"]
        reader = csv.DictReader(StringIO(csv_str))
        data = [row for row in reader]
        return {
            prop["Key"]: {
                "Name": prop["Name"],
                "DataType": prop["DataType"],
                "Description": prop["Description"],
                "IsMain": prop.get("IsMain", None),
                "AsAt": prop.get("AsAt", None),
            }
            for prop in sorted(
                [d for d in data if "Name" in d],
                key=lambda x: x["Name"],
            )
        }

    @classmethod
    def configure_sql(
        cls,
        provider: str,
        properties: Sequence[InlineProperty],
        extension_clause: str = "",
    ) -> str:
        """Generate the Sys.Admin.Lusid.Provider.Configure SQL."""
        if len(properties) == 0:
            return textwrap.dedent(f"""\
                select * from Sys.Admin.Lusid.Provider.Configure
                    where Provider = '{provider}'
                    and WriteAction = 'Set'
                    {extension_clause}
                ;
            """)
        keys_right = ["(" + ", ".join(prop.sql_values()) + ")" for prop in properties]
        values_str = ",".join(keys_right)
        columns_str = (
            "column1 as [Key], column2 as Name, column3 as DataType, "
            "column4 as Description, column5 as IsMain, column6 as AsAt"
        )
        return textwrap.dedent(f"""\
            @keysToCatalog = values
                {values_str}
            ;
            @config = select
                {columns_str}
                from @keysToCatalog
            ;
            select * from Sys.Admin.Lusid.Provider.Configure
                where Provider = '{provider}'
                and Configuration = @config
                and WriteAction = 'Set'
                {extension_clause}
            ;
        """)

    @classmethod
    def read_csv(
        cls,
        client: httpx.Client,
        path: str,
        backoff_handler: BackoffHandler,
    ) -> Dict[str, Any] | None:
        """Read inline properties from Sys.File by path."""
        sql = textwrap.dedent(f"""\
            select Content from Sys.File
                where Path = 'config/lusid/factories/{path}providerfactory.csv'
            ;
        """)
        res = _query(client, sql, backoff_handler)
        if not res:
            return None
        return cls.parse_csv(res)

    @classmethod
    def reset_provider(
        cls,
        client: httpx.Client,
        provider: str,
        extension_clause: str = "",
    ) -> None:
        """Reset (delete) a provider's inline configuration."""
        sql = textwrap.dedent(f"""\
            select *
                from Sys.Admin.Lusid.Provider.Configure
                where Provider = '{provider}'
                and WriteAction = 'Reset'
                {extension_clause}
            ;
        """)
        _query(client, sql, BackoffHandler())
