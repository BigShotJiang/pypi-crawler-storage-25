from __future__ import annotations

import copy
import json
from enum import StrEnum
from hashlib import sha256
from typing import Annotated, Any, Dict, List, Literal, Optional, Sequence, Union

import httpx
from pydantic import (
    BaseModel,
    BeforeValidator,
    Field,
    PlainSerializer,
    WithJsonSchema,
    field_serializer,
    field_validator,
    model_validator,
)

from .coretypes import IsoDateTime, StrDateTime
from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource

GROUP = "Identity & Access"


class ActionId(CamelAlias, BaseModel):
    """ActionId resource used with IdSelector

    Example
    -------
    >>> from fbnconfig.access import ActionId
    >>> ActionId(scope="myscope", activity="execute", entity="Feature")

    -------
    """

    scope: str
    activity: str
    entity: str


class MatchAllSelector(CamelAlias, BaseModel):
    type_name: Literal["matchAllSelectorDefinition"] = Field("matchAllSelectorDefinition", init=False)
    actions: List[ActionId]
    name: Optional[str] = None
    description: Optional[str] = None


class IdSelector(CamelAlias, BaseModel):
    """IdSelector resource used with PolicyResource

    Example
    -------
    >>> from fbnconfig.access import IdSelector, ActionId
    >>> IdSelector(
            name="feature_id_selector",
            description="feature_id_selector",
            identifier={"scope": "myscope", "code": "mycode"},
            actions=[ActionId(scope="myscope", activity="execute", entity="Feature")])
    """

    type_name: Literal["idSelectorDefinition"] = Field("idSelectorDefinition", init=False)
    identifier: Dict[str, str]
    actions: List[ActionId]
    name: Optional[str] = None
    description: Optional[str] = None


class MetadataExpression(CamelAlias, BaseModel):
    metadata_key: str
    operator: str
    text_value: str | None


class MetadataSelector(CamelAlias, BaseModel):
    type_name: Literal["metadataSelectorDefinition"] = Field("metadataSelectorDefinition", init=False)
    actions: List[ActionId]
    name: str | None = None
    description: str | None = None
    expressions: List[MetadataExpression]


class PolicySelector(CamelAlias, BaseModel):
    type_name: Literal["policySelectorDefinition"] = Field("policySelectorDefinition", init=False)
    actions: List[ActionId]
    name: str | None = None
    description: str | None = None
    identity_restriction: Dict[str, str] | None = None
    restriction_selectors: Sequence[Selector] | None = None

    @field_serializer("restriction_selectors", when_used="always")
    def ser_selectors(self, selectors: Any, info):
        if selectors is None:
            return None
        if info.context and info.context.get("style") == "dump":
            # dump mode: serialise them fully
            return selectors
        # convert array of selectors to dict for the api
        return [
            {selector.type_name: selector.model_dump(exclude=["type_name"], by_alias=True)}
            for selector in selectors
        ]

    @field_validator("restriction_selectors", mode="before")
    @classmethod
    def des_selectors(cls, data, info) -> Sequence[Selector] | Dict | None:
        if data is None:
            return None
        style = info.context.get("style", "api") if info.context else "api"
        if style == "api" and isinstance(data, dict):
            data = [value | {"typeName": key} for key, value in data.items()]
        return data


Selector = Annotated[
    IdSelector | MatchAllSelector | MetadataSelector | PolicySelector,
    Field(discriminator="type_name")
]


class WhenSpec(CamelAlias, BaseModel):
    """
    WhenSpec resource used with PolicyResource

    Example
    -------
    >>> from fbnconfig.access import WhenSpec
    >>>WhenSpec(activate="2024-08-31T18:00:00.0000000+00:00")

    Notes
    -------
    When deactivate is not supplied, the policy is valid from time in activate until end of time
    """

    activate: StrDateTime
    deactivate: StrDateTime | None = None


class Grant(StrEnum):
    """Type of grant used with PolicyResource

    Available values are: Allow, Deny and Undefined
    """

    ALLOW = "Allow"
    DENY = "Deny"
    UNDEFINED = "Undefined"


class AsAtRangeForSpec(CamelAlias, BaseModel):
    type_name: Literal["asAtRangeForSpec"] = Field("asAtRangeForSpec", init=False)
    from_: AsAtPredicateContract = Field(serialization_alias="from", validation_alias="from")
    to: AsAtPredicateContract


class AsAtPredicateContract(CamelAlias, BaseModel):
    value: str | None = None
    date_time_offset: IsoDateTime | None = None


class AsAtRelative(CamelAlias, BaseModel):
    type_name: Literal["asAtRelative"] = Field("asAtRelative", init=False)
    date: RelativeDateEnum
    adjustment: int
    unit: RelativeUnitEnum
    relative_to_date_time: RelativeToDateTimeEnum


class RelativeDateEnum(StrEnum):
    UNDEFINED = "Undefined"
    NOW = "Now"
    FIRSTOFMONTH = "FirstOfMonth"
    FIRSTBUSINESSDAYOFTHEMONTH = "FirstBusinessDayOfTheMonth"
    LASTDAYOFTHEMONTH = "LastDayOfTheMonth"
    LASTBUSINESSDAYOFMONTH = "LastBusinessDayOfMonth"
    FIRSTDAYOFYEAR = "FirstDayOfYear"
    LASTDAYOFYEAR = "LastDayOfYear"


class RelativeUnitEnum(StrEnum):
    UNDEFINED = "Undefined"
    MINUTE = "Minute"
    HOUR = "Hour"
    DAY = "Day"
    BUSINESS_DAY = "BusinessDay"
    WEEKS = "Weeks"
    MONTHS = "Months"
    YEARS = "Years"


class RelativeToDateTimeEnum(StrEnum):
    UNDEFINED = "Undefined"
    BEFOREORON = "BeforeOrOn"
    BEFORE = "Before"
    ONDAYOF = "OnDayOf"
    AFTERORON = "AfterOrOn"
    AFTER = "After"
    EXACTLY = "Exactly"


class EffectiveDateHasQualityEnum(StrEnum):
    UNDEFINED = "Undefined"
    ISFIRSTDAYOFANYMONTH = "IsFirstDayOfAnyMonth"
    ISLASTDAYOFANYMONTH = "IsLastDayOfAnyMonth"
    ISBUSINESSDAYOFANYMONTH = "IsBusinessDayOfAnyMonth"
    ISFIRSTDAYOFTHECURRENTMONTH = "IsFirstDayOfTheCurrentMonth"
    ISLASTDAYOFTHECURRENTMONTH = "IsLastDayOfTheCurrentMonth"
    ISBUSINESSDAYOFTHECURRENTMONTH = "IsBusinessDayOfTheCurrentMonth"
    ISBEFOREMIDDAY = "IsBeforeMidday"
    ISBEFORE5PM = "IsBefore5pm"
    ISAFTER5PM = "IsAfter5pm"


class EffectiveDateHasQuality(CamelAlias, BaseModel):
    type_name: Literal["effectiveDateHasQuality"] = Field("effectiveDateHasQuality", init=False)
    quality: EffectiveDateHasQualityEnum


class EffectiveDateRelative(CamelAlias, BaseModel):
    type_name: Literal["effectiveDateRelative"] = Field("effectiveDateRelative", init=False)
    date: RelativeDateEnum
    adjustment: int
    unit: RelativeUnitEnum
    relative_to_date_time: RelativeToDateTimeEnum


class EffectiveRange(CamelAlias, BaseModel):
    type_name: Literal["effectiveRange"] = Field("effectiveRange", init=False)
    from_: IsoDateTime = Field(serialization_alias="from", validation_alias="from")
    to: IsoDateTime | None = None


ForSpec = Annotated[
    EffectiveRange | AsAtRangeForSpec | EffectiveDateHasQuality | EffectiveDateRelative | AsAtRelative,
    Field(discriminator="type_name"),
]


class IfRequestHeaderExpression(CamelAlias, BaseModel):
    type_name: Literal["ifRequestHeaderExpression"] = Field("ifRequestHeaderExpression", init=False)
    header_name: str
    operator: IfOperatorEnum
    value: str | None = None


class IfIdentityClaimExpression(CamelAlias, BaseModel):
    type_name: Literal["ifIdentityClaimExpression"] = Field("ifIdentityClaimExpression", init=False)
    claim_type: str
    claim_value_type: str | None = None
    claim_issuer: str | None = None
    operator: IfOperatorEnum
    value: str | None = None


class IfOperatorEnum(StrEnum):
    UNDEFINED = "Undefined"
    EQUALSCASESENSITIVE = "EqualsCaseSensitive"
    EQUALSCASEINSENSITIVE = "EqualsCaseInsensitive"
    NOTEQUALSCASESENSITIVE = "NotEqualsCaseSensitive"
    NOTEQUALSCASEINSENSITIVE = "NotEqualsCaseInsensitive"
    CONTAINSCASESENSITIVE = "ContainsCaseSensitive"
    NOTPRESENTORNOTCONTAINSCASESENSITIVE = "NotPresentOrNotContainsCaseSensitive"
    NOTPRESENT = "NotPresent"
    INCASEINSENSITIVE = "InCaseInsensitive"


class IfIdentityScopeExpression(CamelAlias, BaseModel):
    type_name: Literal["ifIdentityScopeExpression"] = Field("ifIdentityScopeExpression", init=False)
    scope_name: str


class IfViaApiExpression(CamelAlias, BaseModel):
    type_name: Literal["ifViaApiExpression"] = Field("ifViaApiExpression", init=False)
    api_feature_codes: str


IfExpression = Annotated[
    IfRequestHeaderExpression
    | IfIdentityClaimExpression
    | IfIdentityScopeExpression
    | IfViaApiExpression,
    Field(discriminator="type_name"),
]


def _des_tagged_seq(data, info):
    if data is None:
        return data
    style = info.context.get("style", "api") if info.context else "api"
    if style == "dump":
        return data
    result = []
    for obj in data:
        if isinstance(obj, dict):
            result.extend([v | {"typeName": k} for k, v in obj.items()])
        else:
            result.append(obj)
    return result


def _ser_tagged_seq(items, info):
    if (info.context or {}).get("style") == "dump":
        return items
    if all(isinstance(i, dict) for i in items):
        return items
    return [
        {i.type_name: i.model_dump(exclude=["type_name"], by_alias=True, exclude_none=True)}
        for i in items
    ]


SelectorSeq = Annotated[
    Sequence[Selector],
    BeforeValidator(_des_tagged_seq),
    PlainSerializer(_ser_tagged_seq, when_used="always")
    ]
ForSpecs = Annotated[
    Sequence[ForSpec],
    BeforeValidator(_des_tagged_seq),
    PlainSerializer(_ser_tagged_seq, when_used="always")
    ]
IfSpecs = Annotated[
    Sequence[IfExpression],
    BeforeValidator(_des_tagged_seq),
    PlainSerializer(_ser_tagged_seq, when_used="always")
    ]


@register_resource(group=GROUP)
class PolicyRef(BaseModel, Ref):
    """
    Attributes
    ----------
    code
        Code of the policy being created
    id
        The unique fbnconfig resource identifier
    scope
        Optional. Will use the default scope if not provided. The requested scope
    """
    id: str = Field(exclude=True, init=True)
    code: str
    scope: str = "default"

    def attach(self, client):
        try:
            client.request("get", f"/access/api/policies/{self.code}", params={"scope": self.scope})
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Policy {self.scope}/{self.code} not found")
            else:
                raise ex


@register_resource(group=GROUP, keys=["scope", "code"])
class PolicyResource(BaseModel, Resource, ListMixin, FetchMixin):
    """Manage a policy

    Attributes
    ----------
    applications
        Applications this policy is used with
    code
        Code of the policy being created
    description
        Description of what the policy will be used for
    for_spec
        Date constraints on the data being accessed (e.g. effective date restrictions)
    id
        The unique fbnconfig resource identifier
    if_spec
        Conditions evaluated against the runtime request context
    scope
        Optional. 'default' is the only valid value
    selectors
        Selectors that identify what resources this policy qualifies for
    """

    id: str = Field(exclude=True)
    code: str
    scope: str = Field("default", init=False, exclude=True)
    description: str
    applications: List[str]
    grant: Grant
    selectors: SelectorSeq
    when: WhenSpec
    for_spec: ForSpecs | None = Field(
        default=None, serialization_alias="for", validation_alias="for"
    )
    if_spec: IfSpecs | None = Field(
        default=None, serialization_alias="if", validation_alias="if"
    )

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code to top for api style
        if "id" in data and isinstance(data["id"], dict):
            data = data | data["id"]
            data.pop("id", None)
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    def read(self, client, old_state):
        remote = client.request(
            "get", f"/access/api/policies/{self.code}", params={"scope": self.scope}
        ).json()
        remote.pop("id")
        remote.pop("links")
        return remote

    def create(self, client: httpx.Client):
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        client.request("POST", "/access/api/policies", json=desired)
        return {"id": self.id, "code": self.code}

    def update(self, client: httpx.Client, old_state):
        if old_state.code != self.code:
            raise (RuntimeError("Cannot change the code on a policy"))
        get = self.read(client, old_state)
        remote = copy.deepcopy(get)
        desired = self.model_dump(
            mode="json", exclude_none=True, exclude={"scope", "code"}, by_alias=True
        )
        if (
            desired["when"].get("deactivate", None) is None
        ):  # deactivate is defaulted on the server so not a difference unless we set it
            remote["when"].pop("deactivate")
        remote_model = self.__class__.model_validate(
            remote | {"code": self.code},
            context={"id": self.id}
        )
        if desired == remote_model.model_dump(
            mode="json",
            exclude_none=True,
            exclude={"scope", "code"},
            by_alias=True
        ):
            return None
        client.request("put", f"/access/api/policies/{self.code}", json=desired)
        return {"id": self.id, "code": self.code}

    @staticmethod
    def delete(client, old_state):
        client.request("DELETE", f"/access/api/policies/{old_state.code}")

    def deps(self):
        return []

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/access/api/policies/page"

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return data["id"]

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/access/api/policies/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"policy_{data['scope']}_{data['code']}".lower()

    @classmethod
    def from_api(cls, data: Dict[str, Any]) -> dict[str, Any]:
        data.pop("links", None)
        data.pop("href", None)

        data = data | data["id"]
        data = data | {"id": cls.create_resource_id(data)}
        return data


def ser_policy_key(value, info):
    if info.context and info.context.get("style") == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_policy_key(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


PolicyKey = Annotated[
    PolicyResource | PolicyRef,
    BeforeValidator(des_policy_key),
    PlainSerializer(ser_policy_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.Policy"}},
            "required": ["$ref"],
        }
    ),
]


@register_resource(group=GROUP)
class PolicyCollectionRef(BaseModel, Ref):
    """
    Attributes
    ----------
    code
        The identifier for the PolicyCollection being created
    id
        The unique fbnconfig resource identifier
    scope
        Optional. Will use the default scope if not provided. The requested scope
    """
    id: str = Field(exclude=True, init=True)
    code: str
    scope: str = "default"

    def attach(self, client):
        try:
            client.get(f"/access/api/policycollections/{self.code}", params={"scope": self.scope})
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"PolicyCollection {self.scope}/{self.code} not found")
            else:
                raise ex


@register_resource(group=GROUP, keys=["scope", "code"])
class PolicyCollectionResource(CamelAlias, BaseModel, Resource, ListMixin, FetchMixin):
    """
    Attributes
    ----------
    code
        The identifier for the PolicyCollection being created
    description
        A description of this policy collection
    id
        The unique fbnconfig resource identifier
    metadata
        Any relevant metadata associated with this resource for controlling access to this resource
    policies
        The identifiers of the Policies in this collection
    policy_collections
        The identifiers of the PolicyCollections in this collection
    scope
        Optional. Will use the default scope if not provided. The requested scope
    """
    id: str = Field(exclude=True)
    # collections can be referenced by scope, but it can't be specified
    scope: str = Field("default", init=False, exclude=True)
    code: str
    description: str | None = None
    policies: Sequence[PolicyKey] = []
    policy_collections: Sequence[PolicyCollectionKey] | None = []
    metadata: Dict[str, List[str]] | None = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code to top for api style
        if "id" in data and isinstance(data["id"], dict):
            data = data | data["id"]
            data.pop("id", None)
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    def read(self, client, old_state) -> Dict[str, Any]:
        scope = old_state.scope
        code = old_state.code
        params = {"scope": scope} if scope is not None else None
        remote = client.get(f"/access/api/policycollections/{code}", params=params).json()
        remote.pop("links")
        remote.pop("id")
        return remote

    def create(self, client) -> Dict[str, Any]:
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        res = client.request("POST", "/access/api/policycollections", json=desired)
        return res.json()["id"]

    def update(self, client, old_state) -> Dict[str, Any] | None:
        if old_state.code != self.code:
            self.delete(client, old_state)
            return self.create(client)
        remote = self.read(client, old_state)
        desired = self.model_dump(mode="json", exclude_none=True, exclude={"code"}, by_alias=True)
        if desired == remote:
            return None
        client.request("put", f"/access/api/policycollections/{self.code}", json=desired)
        return {"code": self.code, "scope": old_state.scope}

    @staticmethod
    def delete(client, old_state):
        client.request("DELETE", f"/access/api/policycollections/{old_state.code}")

    def deps(self) -> List[Resource | Ref]:
        deps: List[Resource | Ref] = []
        for pol in self.policies:
            deps.append(pol)
        if self.policy_collections:
            for col in self.policy_collections:
                deps.append(col)
        return deps

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/access/api/policycollections/page"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/access/api/policycollections/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"policy-collection_{data['scope']}_{data['code']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return data["id"]

    @classmethod
    def from_api(cls, data: Dict[str, Any]) -> dict[str, Any]:
        data.pop("links", None)
        data.pop("href", None)

        data = data | data["id"]
        data["id"] = cls.create_resource_id(data)
        data["metadata"] = {}
        if "policies" in data and data["policies"] is not None:
            data["policies"] = [
                {
                    "$ref": PolicyResource.create_resource_id(keys),
                    "metadata": {
                        "keys": keys,
                        "resource": getattr(PolicyResource, "resource_type")
                    }
                }
                for policy in data["policies"]
                if (keys := {"scope": policy["scope"], "code": policy["code"]})
            ]
        if "policyCollections" in data and data["policyCollections"] is not None:
            data["policyCollections"] = [
                {
                    "$ref": cls.create_resource_id(keys),
                    "metadata": {
                        "keys": keys,
                        "resource": getattr(cls, "resource_type")
                    }
                }
                for policy_collection in data["policyCollections"]
                if (keys := {"scope": policy_collection["scope"], "code": policy_collection["code"]})
            ]
        return data


def ser_policycollection_key(value, info):
    if info.context and info.context.get("style") == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_policycollection_key(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


PolicyCollectionKey = Annotated[
    PolicyCollectionResource | PolicyCollectionRef,
    BeforeValidator(des_policycollection_key),
    PlainSerializer(ser_policycollection_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.PolicyCollection"}},
            "required": ["$ref"],
        }
    ),
]


# not an fbnconfig Resource despite the name
class PolicyIdRoleResource(CamelAlias, BaseModel):
    """Used to refer to a policy resource in a role resource"""

    policies: Sequence[PolicyKey] | None = []
    policy_collections: Sequence[PolicyCollectionKey] | None = []


class Permission(StrEnum):
    """Permission type used on a role resource"""

    READ = "Read"
    WRITE = "Write"
    EXECUTE = "Execute"
    UPDATE = "Update"


class NonTransitiveSupervisorRoleResource(BaseModel):
    roles: Sequence[RoleKey]


class RoleResourceRequest(BaseModel, CamelAlias):
    non_transitive_supervisor_role_resource: NonTransitiveSupervisorRoleResource | None = None
    policy_id_role_resource: PolicyIdRoleResource | None = None


@register_resource(group=GROUP)
class RoleRef(BaseModel, Ref):
    """Reference an existing Role

    Attributes
    ----------
    code
        The code of the role
    id
        The unique fbnconfig resource identifier
    scope
        The scope of the Role
    """

    id: str = Field(exclude=True, init=True)
    scope: str = "default"
    code: str

    def attach(self, client):
        try:
            params = {"scope": self.scope}
            client.request("get", f"/access/api/roles/{self.code}", params=params)
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Role {self.scope}/{self.code} not found")
            else:
                raise ex


@register_resource(group=GROUP, keys=["scope", "code"])
class RoleResource(CamelAlias, BaseModel, Resource, ListMixin, FetchMixin):
    """Define a role resource

    Attributes
    ----------
    code
        The code of the role
    description
        The description of the role
    id
        The unique fbnconfig resource identifier
    scope
        The scope of the Role
    """

    id: str = Field(exclude=True)
    scope: str = Field("default", exclude=True, init=False)
    code: str
    description: str | None = None
    resource: None | RoleResourceRequest = None
    when: WhenSpec
    permission: Permission
    role_hierarchy_index: Optional[int] = None

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code to top for api style
        if "id" in data and isinstance(data["id"], dict):
            data = data | data["id"]
            data.pop("id", None)
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    def read(self, client, old_state):
        get = client.request("get", f"/access/api/roles/{old_state.code}")
        remote = get.json()
        remote.pop("id")
        remote.pop("links")
        return remote

    def create(self, client):
        body = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        client.request("POST", "/access/api/roles", json=body)
        return {"id": self.id, "code": self.code}

    def update(self, client: httpx.Client, old_state):
        if old_state.code != self.code:
            raise (RuntimeError("Cannot change the code on a role"))

        remote = self.read(client, old_state)
        desired = self.model_dump(mode="json", exclude={"code"}, exclude_none=True, by_alias=True)
        remote["when"].pop(
            "deactivate"
        )  # deactivate is defaulted on the server so not a difference unless we set it
        remote.pop("roleHierarchyIndex")  # set by the server
        if desired == remote:
            return None
        client.request("put", f"/access/api/roles/{self.code}", json=desired)
        return {"id": self.id, "code": self.code}

    @staticmethod
    def delete(client, old_state):
        client.request("DELETE", f"/access/api/roles/{old_state.code}")

    def deps(self):
        if self.resource is None or self.resource.policy_id_role_resource is None:
            return []
        res = self.resource.policy_id_role_resource
        pol_deps = [v for v in res.policies] if res.policies is not None else []
        col_deps = [v for v in res.policy_collections] if res.policy_collections is not None else []
        return pol_deps + col_deps

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/access/api/roles"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/access/api/roles/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"role_{data['scope']}_{data['code']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {"code": data["id"]["code"]}

    @classmethod
    def from_api(cls, data: Dict[str, Any]) -> dict[str, Any]:
        data.pop("limit", None)
        data.pop("links", None)
        data.pop("href", None)

        data = data | data["id"]
        data["id"] = cls.create_resource_id(data)
        resource = data.get("resource")
        if resource and "policyIdRoleResource" in resource:
            pirr = resource["policyIdRoleResource"]
            if "policies" in pirr and pirr["policies"] is not None:
                pirr["policies"] = [
                    {
                        "$ref": PolicyResource.create_resource_id(policy),
                        "metadata": {
                            "keys": {
                                "scope": policy["scope"],
                                "code": policy["code"],
                            },
                            "resource": getattr(PolicyResource, "resource_type")
                        }
                    }
                    for policy in pirr["policies"]
                ]
            if "policyCollections" in pirr and pirr["policyCollections"] is not None:
                pirr["policyCollections"] = [
                    {
                        "$ref": PolicyCollectionResource.create_resource_id(policy_collection),
                        "metadata": {
                            "keys": {
                                "scope": policy_collection["scope"],
                                "code": policy_collection["code"],
                            },
                            "resource": getattr(PolicyCollectionResource, "resource_type")
                        }
                    }
                    for policy_collection in pirr["policyCollections"]
                ]
        return data


@register_resource(group=GROUP)
class PolicyTemplateRef(BaseModel, Ref):
    """Reference an existing policy template

    Example
    -------
    >>> from fbnconfig.access import PolicyTemplateRef
    >>> PolicyTemplateRef = PolicyTemplateRef(id="policy_templates", code="code_example")

    Attributes
    ----------
    code
        The Code of the policy template being created
    id
        The unique fbnconfig resource identifier
    scope
        The Scope of the policy template being created
    """

    id: str = Field(exclude=True, init=True)
    code: str
    scope: str = "default"

    def attach(self, client):
        try:
            params = {"scope": self.scope}
            client.request("get", f"/access/api/policytemplates/{self.code}", params=params)
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Policy Template {self.scope}/{self.code} not found")
            else:
                raise ex


class TemplatedSelector(BaseModel):
    """
    Attributes
    ----------
    application
        The application that this selector definition applies to
    tag
        The type of policy that this selector definition applies to
    """
    application: str
    tag: str
    selector: Selector

    @field_serializer("selector")
    def ser_selector(self, value: Selector, info) -> Any:
        style = info.context.get("style", "api") if info.context else "api"
        if style == "api":
            serialized = value.model_dump(exclude={"type_name"}, by_alias=True)
            return {
                value.type_name: serialized
            }
        else:
            return value

    @field_validator("selector", mode="before")
    @classmethod
    def des_selectors(cls, data, info) -> Sequence[Selector] | Dict | None:
        if data is None:
            return None
        style = info.context.get("style", "api") if info.context else "api"
        if style == "api" and isinstance(data, dict):
            unpacked = [value | {"typeName": key} for key, value in data.items()]
            data = unpacked[0]  # this is a dict with one element
        return data


@register_resource(group=GROUP, keys=["scope", "code"])
class PolicyTemplateResource(BaseModel, Resource, ListMixin, FetchMixin):
    """Define a policy template in LUSID

    Attributes
    ----------
    code
        The Code of the policy template being created
    description
        Description of the policy template being created
    display_name
        Display name of the policy template being created
    id
        The unique fbnconfig resource identifier
    scope
        The Scope of the policy template being created
    templated_selectors
        The selector definitions of policies included in this policy template
    """

    id: str = Field(exclude=True)
    display_name: str
    scope: str = Field("default", init=False, exclude=True)
    code: str
    description: str
    templated_selectors: List[TemplatedSelector]

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code to top for api style
        if "id" in data and isinstance(data["id"], dict):
            data = data | data["id"]
            data.pop("id", None)
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    def __get_content_hash__(self) -> str:
        dump = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        return sha256(json.dumps(dump, sort_keys=True).encode()).hexdigest()

    def read(self, client: httpx.Client, old_state) -> None | Dict[str, Any]:
        return client.get(f"/access/api/policytemplates/{old_state.code}").json()

    def create(self, client: httpx.Client) -> Optional[Dict[str, Any]]:
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        response = client.post("/access/api/policytemplates", json=desired).json()
        return {
            "id": self.id,
            "code": self.code,
            "source_version": self.__get_content_hash__(),
            "remote_version": sha256(json.dumps(response, sort_keys=True).encode()).hexdigest(),
        }

    def update(self, client: httpx.Client, old_state) -> Union[None, Dict[str, Any]]:
        if old_state.code != self.code:
            raise (RuntimeError("Cannot change the code on a policy template"))

        source_hash = self.__get_content_hash__()
        remote = self.read(client, old_state)
        remote_hash = sha256(json.dumps(remote, sort_keys=True).encode()).hexdigest()

        if remote_hash == old_state.remote_version and source_hash == old_state.source_version:
            return None

        desired = self.model_dump(mode="json", exclude={"code"}, exclude_none=True, by_alias=True)
        response = client.put(f"/access/api/policytemplates/{self.code}", json=desired).json()
        return {
            "id": self.id,
            "code": self.code,
            "source_version": self.__get_content_hash__(),
            "remote_version": sha256(json.dumps(response, sort_keys=True).encode()).hexdigest(),
        }

    @staticmethod
    def delete(client: httpx.Client, old_state) -> None:
        client.delete(f"/access/api/policytemplates/{old_state.code}")

    def deps(self):
        return []

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/access/api/policytemplates"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/access/api/policytemplates/{code}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"policy-template_{data['scope']}_{data['code']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {"code": data["code"]}

    @classmethod
    def from_api(cls, data: Dict[str, Any]) -> dict[str, Any]:
        data.pop("links", None)
        data.pop("href", None)
        data.pop("tags", [])
        data.pop("applications", [])
        data["id"] = cls.create_resource_id(data)
        return data


def ser_role_key(value, info):
    if info.context and info.context.get("style", "api") == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_role_key(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


RoleKey = Annotated[
    RoleResource | RoleRef,
    BeforeValidator(des_role_key),
    PlainSerializer(ser_role_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.Role"}},
            "required": ["$ref"],
        }
    ),
]
