from __future__ import annotations

import json
from hashlib import sha256
from typing import Annotated, Any, Dict, List, Literal, Union, get_args

import httpx
from pydantic import (
    BaseModel,
    BeforeValidator,
    Field,
    PlainSerializer,
    WithJsonSchema,
    computed_field,
    model_validator,
)

from fbnconfig.configuration import ItemKey
from fbnconfig.identity import UserKey

from .coretypes import Email, JsonValue
from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource

GROUP = "Notifications"


class SubscriptionStatus:
    ACTIVE = "Active"
    INACTIVE = "Inactive"


class MatchingPattern(BaseModel, CamelAlias):
    """
    Attributes
    ----------
    event_type
        The type of event to subscribe to. The list of available event types can be discovered by calling
        the ‘List available EventTypes’ API endpoint.
    filter
        A filter on the event. See https://support.lusid.com/filtering-results-from-lusid for more
        information. If not provided, all events will be matched
    """
    event_type: str
    filter: str | None = None


@register_resource(group=GROUP)
class SubscriptionRef(BaseModel, Ref):
    """
    Reference to a subscription resource.

    Example
    ----------
    >>> from fbnconfig import notifications
    >>> notifications.SubscriptionRef(
    ...  id="subscription-ref",
    ...  scope="myScope",
    ...  code="mySubscription")

    Attributes
    ----------
    code
        Code of the subscription.
    id
        Resource identifier.
    scope
        Scope of the subscription.
    """

    id: str = Field(exclude=True)
    scope: str
    code: str

    def attach(self, client):
        """Attach to an existing subscription resource."""
        try:
            client.get(f"/notification/api/subscriptions/{self.scope}/{self.code}")
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(f"Subscription {self.scope}/{self.code} does not exist")
            else:
                raise ex


@register_resource(group=GROUP, keys=["scope", "code"])
class SubscriptionResource(CamelAlias, BaseModel, Resource, ListMixin, FetchMixin):
    """Subscription resource

    Attributes
    ----------
    code
        The code used to identify an entity
    description
        The summary of the services provided by the subscription
    display_name
        The name of the subscription
    id
        The unique fbnconfig resource identifier
    scope
        The scope used to identify an entity
    status
        The current status of the subscription
    use_as_auth
        The user to use as auth for the subscription
    """

    id: str = Field(exclude=True)
    scope: str
    code: str
    display_name: str
    description: str | None = None
    status: str = Field(default=SubscriptionStatus.ACTIVE)
    matching_pattern: MatchingPattern
    use_as_auth: UserKey | None = None

    @computed_field(alias="id")
    def resource_id(self) -> dict[str, str]:
        return {"scope": self.scope, "code": self.code}

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # promote scope and code to top for api style
        if "id" in data and isinstance(data["id"], dict):
            data = data | data["id"]
            data.pop("id", None)
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}

        return data

    def __get_content_hash__(self) -> str:
        dump = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        return sha256(json.dumps(dump, sort_keys=True).encode()).hexdigest()

    def read(self, client: httpx.Client, old_state) -> Dict[str, Any]:
        response = client.get(f"/notification/api/subscriptions/{old_state.scope}/{old_state.code}")
        result = response.json()
        # Remove read-only fields
        result.pop("href", None)
        result.pop("createdAt", None)
        result.pop("userIdCreated", None)
        result.pop("modifiedAt", None)
        result.pop("userIdModified", None)
        return result

    def create(self, client: httpx.Client) -> Dict[str, Any]:
        body = self.model_dump(mode="json", exclude_none=True, by_alias=True, exclude={"scope", "code"})

        response = client.post("/notification/api/subscriptions", json=body)
        result = response.json()

        # Remove read-only fields
        result.pop("href", None)
        result.pop("createdAt", None)
        result.pop("userIdCreated", None)
        result.pop("modifiedAt", None)
        result.pop("userIdModified", None)

        # Calculate version hashes - convert to string for hashability
        source_version = self.__get_content_hash__()
        remote_version = sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()

        return {
            "scope": self.scope,
            "code": self.code,
            "source_version": source_version,
            "remote_version": remote_version
        }

    def update(self, client: httpx.Client, old_state) -> Union[None, Dict[str, Any]]:
        if old_state.code != self.code:
            raise (RuntimeError("Cannot change the code on an existing subscription"))

        if old_state.scope != self.scope:
            raise (RuntimeError("Cannot change the scope on an existing subscription"))

        # Check if source version changed - convert to string for hashability
        source_hash = self.__get_content_hash__()
        remote = self.read(client, old_state)
        remote_hash = sha256(json.dumps(remote, sort_keys=True).encode()).hexdigest()

        if remote_hash == old_state.remote_version and source_hash == old_state.source_version:
            return None

        body = self.model_dump(mode="json", exclude_none=True, by_alias=True, exclude={"scope", "code"})

        scope = self.scope
        code = self.code

        response = client.put(f"/notification/api/subscriptions/{scope}/{code}", json=body)
        result = response.json()

        # Remove read-only fields
        result.pop("href", None)
        result.pop("createdAt", None)
        result.pop("userIdCreated", None)
        result.pop("modifiedAt", None)
        result.pop("userIdModified", None)

        return {
            "scope": scope,
            "code": code,
            "source_version": self.__get_content_hash__(),
            "remote_version": sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()
        }

    @staticmethod
    def delete(client: httpx.Client, old_state) -> None:
        client.delete(f"/notification/api/subscriptions/{old_state.scope}/{old_state.code}")

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/notification/api/subscriptions"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/notification/api/subscriptions/{scope}/{code}"

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return data["id"]

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data = data | data["id"]
        data["id"] = cls.create_resource_id(data)
        data.pop("href", None)
        data.pop("createdAt", None)
        data.pop("userIdCreated", None)
        data.pop("modifiedAt", None)
        data.pop("userIdModified", None)
        data.pop("useAsAuth", None)
        return data

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"subscription_{data['scope']}_{data['code']}".lower()

    def deps(self) -> List:
        """Dependencies."""
        return [self.use_as_auth] if self.use_as_auth else []


def ser_sub_key(value, info):
    if info.context and info.context.get("style") == "dump":
        return {"$ref": value.id}
    return {"scope": value.scope, "code": value.code}


def des_sub_key(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


SubscriptionKey = Annotated[
    SubscriptionRef | SubscriptionResource,
    BeforeValidator(des_sub_key),
    PlainSerializer(ser_sub_key),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.Subscription"}},
            "required": ["$ref"],
        }
    ),
]


class EmailNotificationType(CamelAlias, BaseModel):
    """Email notification configuration.

    Attributes
    ----------
    email_address_bcc
        'Bcc' recipients of the email
    email_address_cc
        'Cc' recipients of the email
    email_address_to
        'To' recipients of the email
    html_body
        The HTML body of the email (if any)
    plain_text_body
        The plain text body of the email
    subject
        The subject of the email
    type
        The type of delivery mechanism for this notification
    """
    type: Literal["Email"] = "Email"
    subject: str
    plain_text_body: str | None = Field(default=None)
    html_body: str | None = Field(default=None)
    email_address_to: List[Email]
    email_address_cc: List[Email] | None = Field(default=None)
    email_address_bcc: List[Email] | None = Field(default=None)

    def deps(self) -> List:
        return []

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": data["type"],
            "subject": data["subject"],
            "plainTextBody": data.get("plainTextBody"),
            "htmlBody": data.get("htmlBody"),
            "emailAddressTo": data["emailAddressTo"],
            "emailAddressCc": data.get("emailAddressCc"),
            "emailAddressBcc": data.get("emailAddressBcc"),
        }


class AmazonSqsNotificationType(CamelAlias, BaseModel):
    """Amazon SQS notification configuration.

    Attributes
    ----------
    api_key_ref
        Reference to API key from Configuration Store
    api_secret_ref
        Reference to API secret from Configuration Store
    body
        The body of the Amazon Queue Message
    queue_url_ref
        Reference to queue url from Configuration Store
    type
        The type of delivery mechanism for this notification
    """
    type: Literal["AmazonSqs"] = "AmazonSqs"
    api_key_ref: ItemKey
    api_secret_ref: ItemKey
    body: str
    queue_url_ref: ItemKey

    def deps(self) -> List:
        return [
            self.api_key_ref,
            self.api_secret_ref,
            self.queue_url_ref]

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": data["type"],
            "apiKeyRef": {
                "$ref": f"item_{data['apiKeyRef']}".lower()
            },
            "apiSecretRef": {
                "$ref": f"item_{data['apiSecretRef']}".lower()
            },
            "body": data["body"],
            "queueUrlRef": {
                "$ref": f"item_{data['queueUrlRef']}".lower()
            }
        }


class AmazonSqsPrincipalAuthNotificationType(CamelAlias, BaseModel):
    """
    Attributes
    ----------
    body
        The body of the Amazon Queue Message
    queue_url_ref
        Reference to queue url from Configuration Store
    type
        The type of delivery mechanism for this notification
    """
    type: Literal["AmazonSqsPrincipalAuth"] = "AmazonSqsPrincipalAuth"
    body: str
    queue_url_ref: ItemKey

    def deps(self) -> List:
        return [self.queue_url_ref]

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": data["type"],
            "body": data["body"],
            "queueUrlRef": {
                "$ref": f"item_{data['queueUrlRef']}".lower()
            }
        }


class AzureServiceBusNotificationType(CamelAlias, BaseModel):
    """Azure Service Bus notification configuration.

    Attributes
    ----------
    body
        The body of the Azure service bus Message
    client_id_ref
        Reference to client id from Configuration Store
    client_secret_ref
        Reference to client secret from Configuration Store
    namespace_ref
        Reference to namespace from Configuration Store
    queue_name_ref
        Reference to queue name from Configuration Store
    tenant_id_ref
        Reference to tenant id  from Configuration Store
    type
        The type of delivery mechanism for this notification
    """
    type: Literal["AzureServiceBus"] = "AzureServiceBus"
    body: str
    namespace_ref: ItemKey
    queue_name_ref: ItemKey
    tenant_id_ref: ItemKey
    client_id_ref: ItemKey
    client_secret_ref: ItemKey

    def deps(self) -> List:
        return [
            self.namespace_ref,
            self.queue_name_ref,
            self.tenant_id_ref,
            self.client_id_ref,
            self.client_secret_ref
        ]

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": data["type"],
            "body": data["body"],
            "namespaceRef": {
                "$ref": f"item_{data['namespaceRef']}".lower()
            },
            "queueNameRef": {
                "$ref": f"item_{data['queueNameRef']}".lower()
            },
            "tenantIdRef": {
                "$ref": f"item_{data['tenantIdRef']}".lower()
            },
            "clientIdRef": {
                "$ref": f"item_{data['clientIdRef']}".lower()
            },
            "clientSecretRef": {
                "$ref": f"item_{data['clientSecretRef']}".lower()
            }
        }


class WebhookNotificationType(CamelAlias, BaseModel):
    """Webhook notification configuration.

    Attributes
    ----------
    authentication_configuration_item_paths
        The paths of the Configuration Store configuration items that contain the authentication
        configuration. Each authentication type requires different keys: - Lusid - None required -
        BasicAuth - Requires 'Username' and 'Password' - BearerToken - Requires 'BearerToken' and
        optionally 'BearerScheme' - None - None required              e.g. the following would be valid
        assuming that the config is present in the configuration store at the specified paths:
        "authenticationType": "BasicAuth",     "authenticationConfigurationItemPaths": {
        "Username": "config://personal/myUserId/WebhookConfigurations/ExampleService/AdminUser",
        "Password": "config://personal/myUserId/WebhookConfigurations/ExampleService/AdminPassword"     }
    authentication_type
        The type of authentication to use on the request, can be one of the following values: - Lusid -
        Internal LUSID call - BasicAuth - User specified Username and password - BearerToken -
        Authorization header with Bearer scheme and user specified key - None - No Authorization required
        on the webhook call
    content
        The content of the request
    content_type
        The type of the content e.g. Json
    http_method
        The HTTP method such as GET, POST, etc. to use on the request
    type
        The type of delivery mechanism for this notification
    url
        The URL to send the request to
    """
    type: Literal["Webhook"] = "Webhook"
    http_method: str
    url: str
    authentication_type: Literal["Lusid", "BasicAuth", "BearerToken", None]
    authentication_configuration_item_paths: Dict[str, ItemKey] | Dict[str, None] | None = None
    content_type: str
    content: JsonValue

    def deps(self) -> List:
        item_paths = self.authentication_configuration_item_paths

        if item_paths is None:
            return []

        # Loops through the item paths and adds any that are ItemKeys
        item_type = get_args(ItemKey)[0]
        item_dependencies = []

        for path in item_paths.values():
            if isinstance(path, item_type):
                item_dependencies.append(path)

        return item_dependencies

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        auth_config_item_paths = {}
        for key, value in data.get("authenticationConfigurationItemPaths", {}).items():
            if value:
                auth_config_item_paths[key] = {
                    "$ref": f"item_{value}".lower()
                }
            else:
                auth_config_item_paths[key] = None

        return {
            "type": data["type"],
            "httpMethod": data["httpMethod"],
            "url": data["url"],
            "authenticationType": data.get("authenticationType"),
            "authenticationConfigurationItemPaths": auth_config_item_paths or None,
            "contentType": data["contentType"],
            "content": data.get("content"),
        }


class SmsNotificationType(CamelAlias, BaseModel):
    """SMS notification configuration.

    Attributes
    ----------
    body
        The body of the SMS
    recipients
        The phone numbers to which the SMS will be sent to (E.164 format)
    type
        The type of delivery mechanism for this notification
    """
    type: Literal["Sms"] = "Sms"
    body: str
    recipients: list[str] | None

    def deps(self) -> List:
        return []

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": data["type"],
            "body": data["body"],
            "recipients": data.get("recipients"),
        }


NotificationTypes = Union[
    EmailNotificationType,
    AmazonSqsNotificationType,
    AmazonSqsPrincipalAuthNotificationType,
    AzureServiceBusNotificationType,
    WebhookNotificationType,
    SmsNotificationType,
]


@register_resource(group=GROUP)
class NotificationRef(BaseModel, Ref):
    """
    Reference to a notification

    Example
    ----------
    >>> from fbnconfig import notifications
    >>> subscription = notifications.SubscriptionRef(
    ...  id="subscription-ref",
    ...  scope="myScope",
    ...  code="mySubscription")


    >>> ref = notifications.NotificationRef(
    ...  id="notification-ref",
    ...  subscriptions=subscription
    ...  notification_id="myNotification")
    >>> ref.attach()  # Attach to an existing notification

    Attributes
    ----------
    id
        The unique fbnconfig resource identifier
    notification_id
        The identifier of the notification.
    """

    id: str = Field(exclude=True)
    subscription: SubscriptionKey
    notification_id: str

    def attach(self, client):
        """Attach to an existing notification resource."""
        try:
            client.get(
                f"/notification/api/subscriptions/{self.subscription.scope}/"
                f"{self.subscription.code}/notifications/{self.notification_id}"
            )
        except httpx.HTTPStatusError as ex:
            if ex.response.status_code == 404:
                raise RuntimeError(
                    f"Notification {self.notification_id} for subscription "
                    f"{self.subscription.scope}/{self.subscription.code} does not exist"
                )
            else:
                raise ex


@register_resource(
    group=GROUP,
    parent=SubscriptionResource,
    parent_key_mapping={
        "scope": "subscriptionScope",
        "code": "subscriptionCode",
    },
    keys=["subscriptionScope", "subscriptionCode", "notificationId"]
)
class NotificationResource(CamelAlias, BaseModel, Resource, ListMixin, FetchMixin):
    """
    Notification resource for managing notifications on subscriptions.

    Attributes
    ----------
    description
        The summary of the services provided by the notification
    display_name
        The name of the notification
    id
        The unique fbnconfig resource identifier
    notification_id
        The identifier of the notification.
    """

    id: str = Field(exclude=True)
    subscription: SubscriptionKey
    notification_id: str
    display_name: str
    description: str | None = Field(default=None)
    notification_type: NotificationTypes | dict[str, Any]

    def __get_content_hash__(self) -> str:
        dump = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        return sha256(json.dumps(dump, sort_keys=True).encode()).hexdigest()

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        # Handle id from context (for dump/undump)
        if info.context and info.context.get("id"):
            data = data | {"id": info.context.get("id")}
        return data

    def read(self, client: httpx.Client, old_state) -> Dict[str, Any] | None:
        response = client.get(
            f"/notification/api/subscriptions/{old_state.scope}/"
            f"{old_state.code}/notifications/{old_state.notification_id}"
        )
        result = response.json()
        # Remove read-only fields
        result.pop("href", None)
        result.pop("createdAt", None)
        result.pop("userIdCreated", None)
        result.pop("modifiedAt", None)
        result.pop("userIdModified", None)
        return result

    def create(self, client: httpx.Client) -> Dict[str, Any]:
        """POST - Create new notification on subscription."""
        body = self.model_dump(mode="json", exclude_none=True, by_alias=True, exclude={"subscription"})

        response = client.post(
            f"/notification/api/subscriptions/{self.subscription.scope}/"
            f"{self.subscription.code}/notifications",
            json=body
        )
        result = response.json()

        # Remove read-only fields
        result.pop("href", None)
        result.pop("createdAt", None)
        result.pop("userIdCreated", None)
        result.pop("modifiedAt", None)
        result.pop("userIdModified", None)

        # Calculate version hashes - convert to string for hashability
        source_version = self.__get_content_hash__()
        remote_version = sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()

        return {
            "id": self.id,
            "scope": self.subscription.scope,
            "code": self.subscription.code,
            "notification_id": self.notification_id,
            "source_version": source_version,
            "remote_version": remote_version
        }

    def update(self, client: httpx.Client, old_state) -> Dict[str, Any] | None:
        """PUT - Update existing notification."""
        if old_state.code != self.subscription.code:
            raise (RuntimeError("Cannot change the code on a notification"))

        if old_state.scope != self.subscription.scope:
            raise (RuntimeError("Cannot change the scope on a notification"))

        if old_state.notification_id != self.notification_id:
            self.delete(client, old_state)
            return self.create(client)

        source_hash = self.__get_content_hash__()
        remote = self.read(client, old_state)
        remote_hash = sha256(json.dumps(remote, sort_keys=True).encode()).hexdigest()

        if remote_hash == old_state.remote_version and source_hash == old_state.source_version:
            return None

        body = self.model_dump(mode="json", exclude_none=True, by_alias=True)

        response = client.put(
            f"/notification/api/subscriptions/{self.subscription.scope}/"
            f"{self.subscription.code}/notifications/{self.notification_id}",
            json=body
        )

        result = response.json()
        # Remove read-only fields
        result.pop("href", None)
        result.pop("createdAt", None)
        result.pop("userIdCreated", None)
        result.pop("modifiedAt", None)
        result.pop("userIdModified", None)

        return {
            "id": self.id,
            "scope": self.subscription.scope,
            "code": self.subscription.code,
            "notification_id": self.notification_id,
            "source_version": self.__get_content_hash__(),
            "remote_version": sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()
        }

    @staticmethod
    def delete(client: httpx.Client, old_state) -> None:
        client.delete(
            f"/notification/api/subscriptions/{old_state.scope}/"
            f"{old_state.code}/notifications/{old_state.notification_id}"
        )

    def deps(self) -> List:
        all_deps = [self.subscription]

        if isinstance(self.notification_type, NotificationTypes):
            all_deps += (self.notification_type.deps())

        return all_deps

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return ("/notification/api/subscriptions/{subscriptionScope}/{subscriptionCode}"
                "/notifications")

    @classmethod
    def fetch_endpoint(cls) -> str:
        return ("/notification/api/subscriptions/{subscriptionScope}/{subscriptionCode}"
                "/notifications/{notificationId}")

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        keys = ("subscriptionScope", "subscriptionCode", "notificationId")
        id_parts = f"{'_'.join(data[x] for x in keys)}"
        return f"notification_{id_parts}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {k: data[k] for k in ("subscriptionScope", "subscriptionCode", "notificationId")}

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data.pop("href", None)
        data.pop("createdAt", None)
        data.pop("modifiedAt", None)
        data.pop("userIdCreated", None)
        data.pop("userIdModified", None)

        data["id"] = cls.create_resource_id(data)

        subscription_keys = {
            "scope": data.pop("subscriptionScope"),
            "code": data.pop("subscriptionCode")
        }
        data["subscription"] = {
            "$ref": SubscriptionResource.create_resource_id(subscription_keys),
            "metadata": {
                "keys": subscription_keys,
                "resource": getattr(SubscriptionResource, "resource_type")
            }
        }

        type_map = {
            "AmazonSqs": AmazonSqsNotificationType,
            "AmazonSqsPrincipalAuth": AmazonSqsPrincipalAuthNotificationType,
            "AzureServiceBus": AzureServiceBusNotificationType,
            "Email": EmailNotificationType,
            "Sms": SmsNotificationType,
            "Webhook": WebhookNotificationType,
        }
        notification_type_data = data["notificationType"]
        notification_type = notification_type_data["type"]

        if cls := type_map.get(notification_type):
            data["notificationType"] = cls.from_api(notification_type_data)

        return data
