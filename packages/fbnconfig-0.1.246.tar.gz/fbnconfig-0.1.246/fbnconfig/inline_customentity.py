from __future__ import annotations

import hashlib
import json
from types import SimpleNamespace
from typing import Any, Dict, Sequence, Union

import httpx
from pydantic import BaseModel, Field, model_validator

from .backoff_handler import BackoffHandler
from .customentity import EntityTypeKey
from .inline_helpers import InlineProviderOps
from .inline_helpers import _query as query
from .lumi import InlineProperty
from .resource_abc import Ref, Resource, register_resource

GROUP = "Luminesce"


@register_resource(group=GROUP, keys=["provider"])
class CustomEntityInlineResource(BaseModel, Resource):
    """Inline properties for a Custom Entity Luminesce provider.

    Configures which columns appear in the Luminesce provider for
    a custom entity type. Unlike InlinePropertiesResource, this takes
    an entity type directly and derives the provider name from it.
    """
    id: str = Field(exclude=True)
    custom_entity_type: EntityTypeKey
    properties: Sequence[InlineProperty]

    @property
    def provider(self) -> str:
        """Derive the Lusid provider name from the entity type."""
        return f"Lusid.CustomEntity.{self._entity_name()}"

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Dict[str, Any]:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            return data | {"id": info.context.get("id")}
        return data

    def _entity_name(self) -> str:
        return self.custom_entity_type.entity_type_name

    def _entity_field_hash(self) -> str:
        """Hash the entity type's field schema to detect changes."""
        fields = [f.model_dump(mode="json") for f in self.custom_entity_type.field_schema]
        return hashlib.sha256(
            json.dumps(fields, sort_keys=True).encode()
        ).hexdigest()

    @staticmethod
    def _convert_entity_name_to_path(entity_name: str) -> str:
        """Convert an entity type name to the sys.file path format."""
        return f"{entity_name}customentity"

    def read(self, client: httpx.Client, old_state: SimpleNamespace) -> None | Dict[str, Any]:
        path = self._convert_entity_name_to_path(old_state.entity_name)
        return InlineProviderOps.read_csv(client, path, BackoffHandler())

    def generate_sql(self):
        return InlineProviderOps.configure_sql(self.provider, self.properties)

    def create(self, client: httpx.Client) -> None | Dict[str, Any]:
        sql = self.generate_sql()
        rows = query(client, sql, backoff_handler=BackoffHandler())
        if len(rows) > 0 and rows[0]["Error"]:
            raise RuntimeError(f"{self.id} Failed to inline:" + rows[0]["Error"] + "\n" + sql)
        properties_dict = InlineProviderOps.parse_csv(rows)
        remote_version = hashlib.sha256(json.dumps(properties_dict, sort_keys=True).encode()).hexdigest()
        desired = self.model_dump(mode="json", by_alias=True, exclude_none=True)
        source_version = hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        return {
            "provider": self.provider,
            "entity_name": self._entity_name(),
            "entity_unique_id": self.custom_entity_type.entity_unique_id,
            "entity_field_hash": self._entity_field_hash(),
            "source_version": source_version,
            "remote_version": remote_version,
        }

    def update(self, client: httpx.Client, old_state) -> Union[None, Dict[str, Any]]:
        if self.provider != old_state.provider:
            self.delete(client, old_state)
            return self.create(client)
        # check if the entity type itself changed
        current_uid = self.custom_entity_type.entity_unique_id
        current_field_hash = self._entity_field_hash()
        if (
            current_uid != getattr(old_state, "entity_unique_id", None)
            or current_field_hash != getattr(old_state, "entity_field_hash", None)
        ):
            return self.create(client)
        remote = self.read(client, old_state)
        if remote is None:
            raise RuntimeError(
                f"Updating {self.id}: expected to read inline of {old_state.provider} "
                f"from sys.registration but found none"
            )
        remote_version = hashlib.sha256(json.dumps(remote, sort_keys=True).encode()).hexdigest()
        desired = self.model_dump(mode="json", by_alias=True, exclude_none=True)
        source_version = hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        if source_version == old_state.source_version and remote_version == old_state.remote_version:
            return None
        return self.create(client)

    @staticmethod
    def delete(client: httpx.Client, old_state) -> None:
        InlineProviderOps.reset_provider(client, old_state.provider)

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"ce_inline_{data['provider']}".lower()

    def deps(self) -> Sequence[Resource | Ref]:
        deps: list[Resource | Ref] = [self.custom_entity_type]
        for v in self.properties:
            if v.key:
                deps.append(v.key)
        return deps
