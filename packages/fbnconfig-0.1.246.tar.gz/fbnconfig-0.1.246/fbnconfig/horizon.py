import json
import string
from hashlib import sha256
from typing import Annotated, Any, ClassVar, Sequence

from pydantic import (
    BaseModel,
    BeforeValidator,
    Field,
    PlainSerializer,
    WithJsonSchema,
    model_serializer,
    model_validator,
)

from .coretypes import JsonMapping, Timezone
from .resource_abc import CamelAlias, FetchMixin, ListMixin, Ref, Resource, register_resource
from .urlfmt import Urlfmt

GROUP = "Horizon Integrations"


class Trigger(BaseModel, CamelAlias):
    type: str
    cron_expression: str
    time_zone: Timezone


@register_resource(group=GROUP, keys=["instanceId"])
class IntegrationInstanceResource(BaseModel, Resource, CamelAlias, ListMixin, FetchMixin):
    """
    Attributes
    ----------
    description
        The description of the integration instance.
    enabled
        Whether the integration instance is enabled.
    id
        The unique fbnconfig resource identifier
    instance_id
        Identifier of the instance
    integration_type
        The type of the integration.
    name
        The name of the integration instance.
    triggers
        The triggers associated with the integration instance.
    """
    id: str = Field(exclude=True)
    integration_type: str
    name: str
    description: str
    enabled: bool
    triggers: Sequence[Trigger]
    details: JsonMapping
    instance_id: str | None = Field(None, exclude=True, init=False)
    u: ClassVar[string.Formatter] = Urlfmt("/horizon/api/integrations/instances")

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Any:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            context_id = info.context.get("id")
            data = data | {"id": context_id}
        return data

    def create(self, client):
        url = self.u.format("{base}")
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        desired_hash = sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        res = client.post(url, json=desired).json()
        self.instance_id = res["id"]
        return {
            "instanceId": res["id"],
            "content_hash": desired_hash
        }

    def read(self, client, old_state):
        instances = client.get(self.u.format("{base}")).json()
        me = next(i for i in instances if i["id"] == old_state.instanceId)
        return me

    def update(self, client, old_state):
        self.instance_id = old_state.instanceId
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        desired_hash = sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        if old_state.content_hash == desired_hash:
            return None
        url = IntegrationInstanceResource.u.format("{base}/{id}", id=old_state.instanceId)
        desired = desired | {"id": old_state.instanceId}
        client.put(url, json=desired)
        return {
            "instanceId": old_state.instanceId,
            "content_hash": desired_hash
        }

    @staticmethod
    def delete(client, old_state):
        client.delete(IntegrationInstanceResource.u.format("{base}/{id}", id=old_state.instanceId))

    def deps(self):
        return []

    @classmethod
    def list_endpoint(cls, **kwargs) -> str:
        return "/horizon/api/integrations/instances"

    @classmethod
    def fetch_endpoint(cls) -> str:
        return "/horizon/api/integrations/instances/{instanceId}"

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        return f"integration-instance_{data['instanceId']}".lower()

    @classmethod
    def get_keys(cls, data: dict[str, Any]) -> dict[str, Any]:
        return {
            "instanceId": data["id"]
        }

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data.pop("postProcessTasks", None)

        data["instanceId"] = data.pop("id")
        data["id"] = cls.create_resource_id(data)

        return data


def ser_instance(value, info):
    if info.context and info.context.get("style") == "dump":
        return {"$ref": value.id}
    return value.instance_id


def des_instance(value, info):
    if not isinstance(value, dict):
        return value
    if info.context and info.context.get("$refs"):
        ref = info.context["$refs"][value["$ref"]]
        return ref
    return value


InstanceKey = Annotated[
    IntegrationInstanceResource,
    BeforeValidator(des_instance),
    PlainSerializer(ser_instance),
    WithJsonSchema(
        {
            "type": "object",
            "properties": {"$ref": {"type": "string", "format": "Key.IntegrationInstance"}},
            "required": ["$ref"],
        }
    ),
]


class OptionalProp(BaseModel, CamelAlias):
    property: str
    display_name_override: str
    description_override: str
    entity_type: str | None = None
    entity_sub_type: Sequence[str] | None = None
    vendor_package: Sequence[str] | None = None


@register_resource(group=GROUP, keys=["instanceIntegrationType", "instanceId"])
class OptionalPropsResource(BaseModel, Resource, FetchMixin):
    """
    Attributes
    ----------
    id
        The unique fbnconfig resource identifier
    """
    id: str = Field(exclude=True)
    props: Sequence[OptionalProp]
    instance: InstanceKey
    u: ClassVar[string.Formatter] = Urlfmt("/horizon/api/integrations/instances/configuration")

    @model_serializer(mode="wrap")
    def ser_model(self, serializer, info):
        style = info.context.get("style", "api") if info.context else "api"
        if style == "dump":
            return serializer(self)
        res = {}
        # api just wants the props as a dict keyed by property
        for op in self.props:
            data = op.model_dump(mode="json", exclude_none=True, by_alias=True)
            prop_key = data.pop("property", None)
            res[prop_key] = data
        return res

    @model_validator(mode="before")
    @classmethod
    def des_model(cls, data: Any, info) -> Any:
        if not isinstance(data, dict):
            return data
        if info.context and info.context.get("id"):
            context_id = info.context.get("id")
            data = data | {"id": context_id}
        return data

    def create(self, client):
        url = self.u.format("{base}/{integration}/{instanceId}",
            integration=self.instance.integration_type,
            instanceId=self.instance.instance_id
        )
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        desired_hash = sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        client.put(url, json=desired)
        return {
            "content_hash": desired_hash,
            "integrationType": self.instance.integration_type,
            "instanceId": self.instance.instance_id
        }

    def read(self, client, old_state):
        url = self.u.format("{base}/{integration}/{instanceId}",
            integration=old_state.integrationType,
            instanceId=old_state.instanceId
        )
        return client.get(url).json()

    def update(self, client, old_state):
        old_id = old_state.instanceId
        old_type = old_state.integrationType
        if (self.instance.instance_id, self.instance.integration_type) != (old_id, old_type):
            new_state = self.create(client)
            self.delete(client, old_state)
            return new_state
        url = self.u.format("{base}/{integration}/{instanceId}",
            integration=old_type,
            instanceId=old_id
        )
        desired = self.model_dump(mode="json", exclude_none=True, by_alias=True)
        desired_hash = sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        if desired_hash == old_state.content_hash:
            return None
        client.put(url, json=desired)
        return {
            "content_hash": desired_hash,
            "integrationType": self.instance.integration_type,
            "instanceId": self.instance.instance_id
        }

    @staticmethod
    def delete(client, old_state):
        old_id = old_state.instanceId
        old_type = old_state.integrationType
        url = OptionalPropsResource.u.format("{base}/{integration}/{instanceId}",
            integration=old_type,
            instanceId=old_id
        )
        client.put(url, json={})

    def deps(self) -> Sequence[Resource | Ref]:
        return [self.instance]

    @classmethod
    def fetch_endpoint(cls) -> str:
        return ("/horizon/api/integrations/instances/configuration"
                "/{instanceIntegrationType}/{instanceId}")

    @classmethod
    def create_resource_id(cls, data: dict) -> str:
        id_parts = f"{'_'.join(data[x] for x in ('instanceIntegrationType', 'instanceId'))}"
        return f"integration-instance-optional-props_{id_parts}".lower()

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> dict[str, Any]:
        data_id = cls.create_resource_id(data)

        data.pop("instanceIntegrationType")
        instance_id = data.pop("instanceId")

        props = []
        for definition_key, opt_property in data.items():
            props.append({
                "property": definition_key,
                "displayNameOverride": opt_property["displayNameOverride"],
                "descriptionOverride": opt_property.get("descriptionOverride"),
                "entityType": opt_property.get("entityType"),
                "entitySubType": opt_property.get("entitySubType"),
                "vendorPackage": opt_property.get("vendorPackage"),
            })

        data.clear()
        data["props"] = props
        data["id"] = data_id

        instance_keys = {"instanceId": instance_id}
        data["instance"] = {
            "$ref": IntegrationInstanceResource.create_resource_id(instance_keys),
            "metadata": {
                "keys": instance_keys,
                "resource": getattr(IntegrationInstanceResource, "resource_type")
            }
        }

        return data
