import datetime as dt
import hashlib
import json
from types import SimpleNamespace

import httpx
import pytest

from fbnconfig import corporate_action as ca
from fbnconfig import portfolio as pf
from fbnconfig import property as prop
from fbnconfig import reference_portfolio as rp
from fbnconfig.properties import PropertyValue

TEST_BASE = "https://foo.lusid.com"
EUID_1 = "euid-00001"
EUID_2 = "euid-00002"


def _create_response(euid=EUID_1):
    return {"version": {"entityUniqueId": euid}}


def response_hook(response: httpx.Response):
    response.read()
    response.raise_for_status()


@pytest.mark.respx(base_url=TEST_BASE)
class DescribePortfolioResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create_simple_portfolio(self, respx_mock):
        respx_mock.post("/api/api/transactionportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response())
        )
        # given a simple portfolio
        sut = pf.PortfolioResource(
            id="simple-portfolio",
            scope="test-scope",
            code="simple-portfolio",
            display_name="Simple Portfolio",
            description="A simple portfolio for testing",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        # when we create it
        result = sut.create(self.client)
        # then the state is returned with content hash
        assert result["id"] == "simple-portfolio"
        assert result["code"] == "simple-portfolio"
        assert result["scope"] == "test-scope"
        assert "content_hash" in result
        # and a create request was sent
        request = respx_mock.calls.last.request
        assert request.method == "POST"
        assert request.url.path == "/api/api/transactionportfolios/test-scope"
        request_body = json.loads(request.content)
        expected_body = {
            "code": "simple-portfolio",
            "displayName": "Simple Portfolio",
            "description": "A simple portfolio for testing",
            "baseCurrency": "USD",
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"],
        }
        assert request_body == expected_body

    def test_create_portfolio_with_subholdings(self, respx_mock):
        respx_mock.post("/api/api/transactionportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response())
        )
        # given a portfolio with properties
        prop_def = prop.DefinitionRef(
            id="test-property-ref", domain=prop.Domain.Transaction, scope="test-scope", code="fees"
        )
        sut = pf.PortfolioResource(
            id="portfolio-with-shk",
            scope="test-scope",
            code="portfolio-with-shk",
            display_name="Portfolio With Properties",
            description="A portfolio with properties for testing",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
            sub_holding_keys=[prop_def],
        )
        # when we create it
        state = sut.create(self.client)
        # then the state is returned
        assert state
        # and a create request was sent with properties
        request = respx_mock.calls.last.request
        assert request.method == "POST"
        assert request.url.path == "/api/api/transactionportfolios/test-scope"
        request_body = json.loads(request.content)
        expected_body = {
            "code": "portfolio-with-shk",
            "displayName": "Portfolio With Properties",
            "description": "A portfolio with properties for testing",
            "baseCurrency": "USD",
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"],
            "subHoldingKeys": ["Transaction/test-scope/fees"],
        }
        assert request_body == expected_body

    def test_read_portfolio(self, respx_mock):
        read_mock = respx_mock.get("/api/api/portfolios/test-scope/read-portfolio").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "read-portfolio",
                    "scope": "test-scope",
                    "code": "read-portfolio",
                    "displayName": "Read Portfolio",
                    "description": "Portfolio for read testing",
                    "baseCurrency": "USD",
                    "created": "2024-01-01T12:00:00+00:00",
                    "instrumentScopes": ["test-scope"],
                    "version": {"effectiveFrom": "2024-01-01T12:00:00+00:00"},
                    "links": [],
                },
            )
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/read-portfolio/details").mock(
            return_value=httpx.Response(200, json={"subHoldingKeys": []})
        )
        # given a portfolio resource
        sut = pf.PortfolioResource(
            id="read-portfolio",
            scope="test-scope",
            code="read-portfolio",
            display_name="Read Portfolio",
            description="Portfolio for read testing",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        old_state = SimpleNamespace(scope="test-scope", code="read-portfolio")
        # when we read it
        result = sut.read(self.client, old_state)
        # then the portfolio data is returned without version and links
        assert result["id"] == "read-portfolio"
        assert result["scope"] == "test-scope"
        assert "version" not in result
        assert "links" not in result
        # and a read request was sent
        request = read_mock.calls[0].request
        assert request.method == "GET"
        assert request.url.path == "/api/api/portfolios/test-scope/read-portfolio"

    def test_update_portfolio_no_change(self, respx_mock):
        # given a portfolio with no changes from previous state
        sut = pf.PortfolioResource(
            id="no-change-portfolio",
            scope="test-scope",
            code="no-change-portfolio",
            display_name="No Change Portfolio",
            description="Portfolio with no changes",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        desired = sut.model_dump(
            mode="json", by_alias=True, exclude_none=True,
            exclude={"id", "instance", "scope"},
        )
        sorted_desired = json.dumps(desired, sort_keys=True)
        content_hash = hashlib.sha256(sorted_desired.encode()).hexdigest()
        old_state = SimpleNamespace(
            scope="test-scope", code="no-change-portfolio", content_hash=content_hash,
            tran_hash=None, instance=EUID_1,
        )
        # when we update it
        result = sut.update(self.client, old_state)
        # then no update occurs
        assert result is None

    def test_update_display_name(self, respx_mock):
        # given a remote portfolio with the old display name
        respx_mock.get("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Old Name", "description": "desc",
                "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/p1/details").mock(
            return_value=httpx.Response(200, json={"subHoldingKeys": []})
        )
        put_mock = respx_mock.put("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="New Name", description="desc",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        old_state = SimpleNamespace(
            scope="test-scope", code="p1", content_hash="old", instance=EUID_1,
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then PUT is called with the new display name
        assert result is not None
        assert len(put_mock.calls) == 1
        body = json.loads(put_mock.calls[0].request.content)
        assert body == {"displayName": "New Name"}
        # and instance is preserved
        assert result["instance"] == EUID_1

    def test_update_base_currency(self, respx_mock):
        # given a remote portfolio with USD
        respx_mock.get("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={
                "displayName": "P1", "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/p1/details").mock(
            return_value=httpx.Response(200, json={"subHoldingKeys": []})
        )
        delete_mock = respx_mock.delete("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={})
        )
        respx_mock.post("/api/api/transactionportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response(EUID_2))
        )
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="P1", base_currency="EUR",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        old_state = SimpleNamespace(
            scope="test-scope", code="p1", content_hash="old", instance=EUID_1,
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then the portfolio is deleted and recreated (baseCurrency requires recreate)
        assert result is not None
        assert len(delete_mock.calls) == 1
        assert result["instance"] == EUID_2

    def test_update_instrument_scopes(self, respx_mock):
        # given a remote portfolio with one scope
        respx_mock.get("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={
                "displayName": "P1", "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/p1/details").mock(
            return_value=httpx.Response(200, json={"subHoldingKeys": []})
        )
        patch_mock = respx_mock.patch("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="P1", base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope", "new-scope"],
        )
        old_state = SimpleNamespace(
            scope="test-scope", code="p1", content_hash="old", instance=EUID_1,
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then PATCH portfolio is called with instrumentScopes
        assert result is not None
        assert len(patch_mock.calls) == 1
        ops = json.loads(patch_mock.calls[0].request.content)
        assert ops == [
            {"op": "add", "path": "/instrumentScopes",
             "value": ["test-scope", "new-scope"]},
        ]

    def test_update_multiple_groups(self, respx_mock):
        # given changes to displayName (PUT) and instrumentScopes (PATCH portfolio)
        respx_mock.get("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Old", "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/p1/details").mock(
            return_value=httpx.Response(200, json={"subHoldingKeys": []})
        )
        put_mock = respx_mock.put("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={})
        )
        patch_mock = respx_mock.patch("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="New", base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope", "new-scope"],
        )
        old_state = SimpleNamespace(
            scope="test-scope", code="p1", content_hash="old", instance=EUID_1,
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then both PUT and PATCH portfolio are called
        assert result is not None
        assert len(put_mock.calls) == 1
        assert len(patch_mock.calls) == 1

    def test_update_scope_code_changed(self, respx_mock):
        # given a portfolio with a different code
        respx_mock.delete("/api/api/portfolios/test-scope/old-code").mock(
            return_value=httpx.Response(200, json={})
        )
        create_mock = respx_mock.post("/api/api/transactionportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response(EUID_2))
        )
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="new-code",
            display_name="P1", base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        old_state = SimpleNamespace(
            scope="test-scope", code="old-code", content_hash="old", instance=EUID_1,
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then the portfolio is deleted and recreated
        assert json.loads(create_mock.calls[0].request.content) == {
            "code": "new-code",
            "displayName": "P1",
            "baseCurrency": "USD",
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"],
        }
        assert result == {
            "id": "p1",
            "code": "new-code",
            "scope": "test-scope",
            "content_hash": "a2e22e2d4ae30b8c0bf8a95e2ac548c70d3e38b3782dc7f2f30048e3c7958d7e",
            "instance": EUID_2,
        }

    def test_update_preserves_instance(self, respx_mock):
        # given a remote portfolio with a changed description
        respx_mock.get("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={
                "displayName": "P1", "description": "old desc",
                "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/p1/details").mock(
            return_value=httpx.Response(200, json={"subHoldingKeys": []})
        )
        respx_mock.put("/api/api/portfolios/test-scope/p1").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="P1", description="new desc",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        old_state = SimpleNamespace(
            scope="test-scope", code="p1", content_hash="old", instance=EUID_2,
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then the instance is preserved (not bumped)
        assert result is not None
        assert result["instance"] == EUID_2

    def test_delete_portfolio(self, respx_mock):
        delete_mock = respx_mock.delete("/api/api/portfolios/test-scope/delete-portfolio").mock(
            return_value=httpx.Response(200, json={})
        )
        # given a portfolio to delete
        old_state = SimpleNamespace(scope="test-scope", code="delete-portfolio")
        # when we delete it
        pf.PortfolioResource.delete(self.client, old_state)
        # then a delete request was sent
        request = delete_mock.calls[0].request
        assert request.method == "DELETE"
        assert request.url.path == "/api/api/portfolios/test-scope/delete-portfolio"

    def test_portfolio_deps_no_properties(self):
        # given a portfolio without properties
        sut = pf.PortfolioResource(
            id="no-deps-portfolio",
            scope="test-scope",
            code="no-deps-portfolio",
            display_name="No Dependencies Portfolio",
            description="Portfolio without property dependencies",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        # when we get dependencies
        deps = sut.deps()
        # then no dependencies are returned
        assert len(deps) == 0

    def test_create_with_corporate_action_source(self, respx_mock):
        respx_mock.post("/api/api/transactionportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response())
        )
        # given a portfolio with a corporate action source
        ca_ref = ca.CorporateActionSourceRef(id="ca_ref", scope="src", code="ca1")
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="P1", base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
            corporate_action_source_id=ca_ref,
        )
        # when we create it
        result = sut.create(self.client)
        # then the request includes corporateActionSourceId
        assert result is not None
        body = json.loads(respx_mock.calls[0].request.content)
        assert body["corporateActionSourceId"] == {"scope": "src", "code": "ca1"}

    def test_deps_with_corporate_action_source(self):
        # given a portfolio with a corporate action source ref
        ca_ref = ca.CorporateActionSourceRef(id="ca_ref", scope="src", code="ca1")
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="P1", base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
            corporate_action_source_id=ca_ref,
        )
        # when we get dependencies
        deps = sut.deps()
        # then the corporate action source is a dependency
        assert ca_ref in deps

    def test_deps_without_corporate_action_source(self):
        # given a portfolio without corporate action source
        sut = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1",
            display_name="P1", base_currency="USD",
            created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        # when we get dependencies
        deps = sut.deps()
        # then no corporate action source dependency
        assert len(deps) == 0


@pytest.mark.respx(base_url=TEST_BASE)
class DescribePortfolioRef:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_attach_existing_portfolio(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-code").mock(
            return_value=httpx.Response(200, json={
                "id": {"scope": "test-scope", "code": "test-code"},
                "version": {"entityUniqueId": EUID_1},
            })
        )
        sut = pf.PortfolioRef(id="p-1", scope="test-scope", code="test-code")
        result = sut.attach(self.client)
        assert result["id"]["scope"] == "test-scope"
        assert sut.instance == EUID_1

    def test_attach_missing_portfolio(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/missing").mock(
            return_value=httpx.Response(404)
        )
        sut = pf.PortfolioRef(id="p-1", scope="test-scope", code="missing")
        with pytest.raises(RuntimeError, match="not found"):
            sut.attach(self.client)


def _make_portfolio(scope="test-scope", code="p1"):
    return pf.PortfolioResource(
        id="p1", scope=scope, code=code,
        display_name="P1", base_currency="USD",
        created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        instrument_scopes=[scope], instance=EUID_1,
    )


def _make_prop_def(scope="test-scope", code="rating"):
    return prop.DefinitionRef(
        id=f"prop-{code}", domain=prop.Domain.Portfolio, scope=scope, code=code,
    )


@pytest.mark.respx(base_url=TEST_BASE)
class DescribePortfolioPropertiesResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create_with_label_property(self, respx_mock):
        upsert_mock = respx_mock.post("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        result = sut.create(self.client)
        assert result["portfolio_scope"] == "test-scope"
        assert result["portfolio_code"] == "p1"
        assert result["portfolio_instance"] == EUID_1
        assert "content_hash" in result
        assert len(upsert_mock.calls) == 1
        body = json.loads(upsert_mock.calls[0].request.content)
        assert "Portfolio/test-scope/rating" in body

    def test_create_empty_properties(self, respx_mock):
        portfolio = _make_portfolio()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio, properties=[],
        )
        result = sut.create(self.client)
        assert result["content_hash"] is not None
        assert len(respx_mock.calls) == 0

    def test_update_no_change(self, respx_mock):
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        # compute the expected hash
        desired = sut._serialize_properties()
        content_hash = hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash=content_hash,
        )
        result = sut.update(self.client, old_state)
        assert result is None

    def test_update_add_property(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {}})
        )
        upsert_mock = respx_mock.post("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash="old",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(upsert_mock.calls) == 1

    def test_update_remove_property(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "Portfolio/test-scope/rating": {
                    "key": "Portfolio/test-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        delete_mock = respx_mock.delete("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        portfolio = _make_portfolio()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio, properties=[],
        )
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash="old",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(delete_mock.calls) == 1
        assert "propertyKeys" in str(delete_mock.calls[0].request.url)

    def test_update_change_value(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "Portfolio/test-scope/rating": {
                    "key": "Portfolio/test-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        upsert_mock = respx_mock.post("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="BBB")],
        )
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash="old",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(upsert_mock.calls) == 1

    def test_update_portfolio_recreated(self, respx_mock):
        upsert_mock = respx_mock.post("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        portfolio = _make_portfolio()
        portfolio.instance = EUID_2  # different from old_state
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash="old",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["portfolio_instance"] == EUID_2
        assert len(upsert_mock.calls) == 1

    def test_delete(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {
                "Portfolio/test-scope/rating": {
                    "key": "Portfolio/test-scope/rating",
                    "value": {"labelValue": "AAA"},
                },
            }})
        )
        delete_mock = respx_mock.delete("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        old_state = SimpleNamespace(portfolio_scope="test-scope", portfolio_code="p1")
        pf.PortfolioPropertiesResource.delete(self.client, old_state)
        assert len(delete_mock.calls) == 1

    def test_delete_no_properties(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={"properties": {}})
        )
        old_state = SimpleNamespace(portfolio_scope="test-scope", portfolio_code="p1")
        pf.PortfolioPropertiesResource.delete(self.client, old_state)
        # no delete call made
        assert len(respx_mock.calls) == 1  # only the GET

    def test_update_with_portfolio_ref(self, respx_mock):
        # PortfolioRef always triggers recreate (re-apply all properties)
        upsert_mock = respx_mock.post("/api/api/portfolios/test-scope/p1/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        ref = pf.PortfolioRef(id="p1-ref", scope="test-scope", code="p1")
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=ref,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash="old",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["portfolio_instance"] is None  # PortfolioRef has no instance
        assert len(upsert_mock.calls) == 1

    def test_deps(self):
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        deps = sut.deps()
        assert portfolio in deps
        assert prop_def in deps

    def test_nochange_portfolio_preserves_instance_for_properties(self, respx_mock):
        # given a portfolio resource without instance set (as it would be from config)
        portfolio = pf.PortfolioResource(
            id="p1", scope="test-scope", code="p1", display_name="P",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, tzinfo=dt.timezone.utc),
            instrument_scopes=["test-scope"],
        )
        # and the portfolio's logged state has an instance from a previous create
        portfolio_state = SimpleNamespace(
            code="p1", scope="test-scope", instance=EUID_1,
            content_hash=hashlib.sha256(b"matching").hexdigest(),
        )
        # and we compute the matching hash so update returns None
        desired = portfolio.model_dump(
            mode="json", exclude_none=True, by_alias=True, exclude={"instance", "scope"},
        )
        portfolio_state.content_hash = hashlib.sha256(
            json.dumps(desired, sort_keys=True).encode()
        ).hexdigest()
        portfolio.update(self.client, portfolio_state)
        # then the portfolio instance is carried forward from old_state
        assert portfolio.instance == EUID_1
        # and a dependent properties resource sees nochange (not a recreate)
        prop_def = _make_prop_def()
        props = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        props_desired = props._serialize_properties()
        props_hash = hashlib.sha256(json.dumps(props_desired, sort_keys=True).encode()).hexdigest()
        props_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="p1",
            portfolio_instance=EUID_1, content_hash=props_hash,
        )
        result = props.update(self.client, props_state)
        assert result is None

    def test_nochange_derived_portfolio_preserves_instance_for_properties(self, respx_mock):
        # given a derived portfolio without instance set
        parent = pf.PortfolioRef(id="parent", scope="test-scope", code="parent")
        portfolio = pf.DerivedTransactionPortfolioResource(
            id="d1", scope="test-scope", code="d1", display_name="D",
            parent_portfolio_id=parent,
        )
        portfolio_state = SimpleNamespace(
            code="d1", scope="test-scope", instance=EUID_1,
            content_hash=hashlib.sha256(b"matching").hexdigest(),
        )
        desired = portfolio.model_dump(
            mode="json", exclude_none=True, by_alias=True,
            exclude={"instance", "scope", "parent_portfolio_id"},
        )
        desired["parentPortfolioId"] = {"scope": parent.scope, "code": parent.code}
        portfolio_state.content_hash = hashlib.sha256(
            json.dumps(desired, sort_keys=True).encode()
        ).hexdigest()
        portfolio.update(self.client, portfolio_state)
        assert portfolio.instance == EUID_1
        prop_def = _make_prop_def()
        props = pf.PortfolioPropertiesResource(
            id="d1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        props_desired = props._serialize_properties()
        props_hash = hashlib.sha256(json.dumps(props_desired, sort_keys=True).encode()).hexdigest()
        props_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="d1",
            portfolio_instance=EUID_1, content_hash=props_hash,
        )
        result = props.update(self.client, props_state)
        assert result is None

    @pytest.mark.parametrize("portfolio_factory", [
        lambda: pf.PortfolioResource(
            id="p1", scope="s", code="c", display_name="P",
            base_currency="USD",
            created=dt.datetime(2024, 1, 1, tzinfo=dt.timezone.utc),
            instrument_scopes=["s"], instance=EUID_1,
        ),
        lambda: pf.DerivedTransactionPortfolioResource(
            id="d1", scope="s", code="c", display_name="D",
            parent_portfolio_id=pf.PortfolioRef(id="parent", scope="s", code="p"),
            instance=EUID_1,
        ),
        lambda: rp.ReferencePortfolioResource(
            id="r1", scope="s", code="c", display_name="R",
            instance=EUID_1,
        ),
    ], ids=["portfolio", "derived", "reference"])
    def test_accepts_all_portfolio_types(self, respx_mock, portfolio_factory):
        respx_mock.post("/api/api/portfolios/s/c/properties").mock(
            return_value=httpx.Response(200, json={})
        )
        prop_def = _make_prop_def(scope="s")
        sut = pf.PortfolioPropertiesResource(
            id="props", portfolio=portfolio_factory(),
            properties=[PropertyValue(property_key=prop_def, label_value="X")],
        )
        result = sut.create(self.client)
        assert result["portfolio_scope"] == "s"
        assert result["portfolio_code"] == "c"


class DescribeDumpUndump:
    dump_ctx = {"style": "dump"}

    def test_dump_portfolio(self):
        # given a portfolio resource
        sut = _make_portfolio()
        # when we dump it
        dumped = sut.model_dump(
            by_alias=True, round_trip=True, exclude_none=True, context=self.dump_ctx,
        )
        # then the fields are serialized and id is excluded
        assert dumped["scope"] == "test-scope"
        assert dumped["code"] == "p1"
        assert dumped["baseCurrency"] == "USD"
        assert "id" not in dumped

    def test_undump_portfolio(self):
        # given a dumped portfolio state
        dumped = {
            "scope": "test-scope", "code": "p1",
            "displayName": "P1", "baseCurrency": "USD",
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"], "instance": EUID_1,
        }
        # when we undump it
        sut = pf.PortfolioResource.model_validate(
            dumped, context={"style": "dump", "$refs": {}, "id": "p1"},
        )
        # then the resource is reconstructed with the id from context
        assert sut.id == "p1"
        assert sut.scope == "test-scope"
        assert sut.code == "p1"
        assert sut.base_currency == "USD"

    def test_dump_portfolio_properties(self):
        # given a portfolio properties resource with a label property
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        sut = pf.PortfolioPropertiesResource(
            id="p1-props", portfolio=portfolio,
            properties=[PropertyValue(property_key=prop_def, label_value="AAA")],
        )
        # when we dump it
        dumped = sut.model_dump(
            by_alias=True, round_trip=True, exclude_none=True, context=self.dump_ctx,
        )
        # then the portfolio is a $ref and id is excluded
        assert dumped["portfolio"] == {"$ref": "p1"}
        assert "id" not in dumped
        # and properties are in dump style (list with $ref keys, not api dict)
        assert isinstance(dumped["properties"], list)
        assert dumped["properties"][0]["propertyKey"] == {"$ref": "prop-rating"}
        assert dumped["properties"][0]["labelValue"] == "AAA"

    def test_undump_portfolio_properties(self):
        # given a dumped portfolio properties state with $refs
        portfolio = _make_portfolio()
        prop_def = _make_prop_def()
        dumped = {
            "portfolio": {"$ref": "p1"},
            "properties": [{"propertyKey": {"$ref": "prop-rating"}, "labelValue": "AAA"}],
        }
        # when we undump it with resolved refs
        refs = {"p1": portfolio, "prop-rating": prop_def}
        sut = pf.PortfolioPropertiesResource.model_validate(
            dumped, context={"style": "dump", "$refs": refs, "id": "p1-props"},
        )
        # then the refs are wired up to the original objects
        assert sut.id == "p1-props"
        assert sut.portfolio is portfolio
        assert len(sut.properties) == 1
        assert sut.properties[0].label_value == "AAA"
        assert sut.properties[0].property_key is prop_def
