import csv
import hashlib
import io
import json
import textwrap
from types import SimpleNamespace
from unittest.mock import patch

import httpx
import pytest
from respx import Router

from fbnconfig import customentity
from fbnconfig.inline_customentity import CustomEntityInlineResource
from fbnconfig.lumi import InlineDataType, InlineProperty, TaskStatus
from fbnconfig.property import DefinitionRef, Domain

TEST_BASE = "https://test.lusid.com"


@pytest.fixture(scope="module", autouse=True)
def dont_sleep():
    with patch("time.sleep", return_value=None) as _fixture:
        yield _fixture


def response_hook(response: httpx.Response):
    response.read()
    response.raise_for_status()


def setup_sql_background_routes(respx_mock, result_data):
    exec_id = "abcdefg"
    routes = {
        "put": respx_mock.put(
            "/honeycomb/api/SqlBackground", headers=[("Content-type", "text/plain")]
        ).mock(return_value=httpx.Response(202, json={"executionId": exec_id})),
        "status": respx_mock.get(f"/honeycomb/api/SqlBackground/{exec_id}").mock(
            return_value=httpx.Response(200, json={"status": TaskStatus.RAN_TO_COMPLETION}),
        ),
        "result": respx_mock.get(f"/honeycomb/api/SqlBackground/{exec_id}/jsonproper").mock(
            return_value=httpx.Response(200, json=result_data),
        ),
    }
    return routes


def make_csv(dict_data):
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=dict_data.keys())
    writer.writeheader()
    writer.writerow(dict_data)
    return output.getvalue()


def make_entity_type(name="TestEntity"):
    return customentity.EntityTypeResource(
        id="test-ce-type",
        entity_type_name=name,
        display_name="Test Entity",
        description="A test custom entity",
        field_schema=[],
    )


def make_entity_type_ref(name="TestEntity"):
    return customentity.EntityTypeRef(id="test-ce-ref", entity_type_name=name)


@pytest.mark.respx(base_url=TEST_BASE)
class DescribeCustomEntityInlineResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    @pytest.fixture()
    def default_content(self):
        return [{
            "Content": """Key,Name,DataType,Description,IsMain,AsAt\n"""
                       """cefield,PropName,Boolean,A description,false,""",
            "Error": "",
        }]

    def test_provider_from_entity_type(self):
        # given a CE inline with an entity type resource
        entity_type = make_entity_type("MyEntity")
        sut = CustomEntityInlineResource(
            id="test", custom_entity_type=entity_type, properties=[]
        )
        # then the provider is derived from the entity type name
        assert sut.provider == "Lusid.CustomEntity.MyEntity"

    def test_provider_from_entity_type_ref(self):
        # given a CE inline with an entity type ref
        ref = make_entity_type_ref("MyEntity")
        sut = CustomEntityInlineResource(
            id="test", custom_entity_type=ref, properties=[]
        )
        # then the provider is derived from the ref
        assert sut.provider == "Lusid.CustomEntity.MyEntity"

    def test_create_no_properties(self, respx_mock: Router, default_content):
        setup_sql_background_routes(respx_mock, result_data=default_content)
        # given a CE inline with no properties
        entity_type = make_entity_type()
        sut = CustomEntityInlineResource(
            id="test", custom_entity_type=entity_type, properties=[]
        )
        # when we create it
        sut.create(self.client)
        # then the SQL sets the provider with no config
        expected = textwrap.dedent("""\
            select * from Sys.Admin.Lusid.Provider.Configure
                where Provider = 'Lusid.CustomEntity.TestEntity'
                and WriteAction = 'Set'\n
            ;
        """)
        actual = respx_mock.calls[0].request.content.decode()
        assert actual == expected

    def test_create_with_field(self, respx_mock: Router, default_content):
        setup_sql_background_routes(respx_mock, result_data=default_content)
        # given a CE inline with a field property
        entity_type = make_entity_type()
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(
                    name="Test Field",
                    field="cefield",
                    data_type=InlineDataType.Text,
                    description="A CE field",
                )
            ],
        )
        # when we create it
        state = sut.create(self.client)
        # then state includes the provider and entity name
        assert state is not None
        assert state["provider"] == "Lusid.CustomEntity.TestEntity"
        assert state["entity_name"] == "TestEntity"
        # and the SQL includes the field
        actual = respx_mock.calls[0].request.content.decode()
        assert "'cefield'" in actual
        assert "Lusid.CustomEntity.TestEntity" in actual

    def test_create_with_identifier(self, respx_mock: Router, default_content):
        setup_sql_background_routes(respx_mock, result_data=default_content)
        # given a CE inline with an identifier property
        entity_type = make_entity_type()
        identifier = DefinitionRef(
            id="ce-id", domain=Domain.CustomEntity, scope="test", code="ExternalId"
        )
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(
                    key=identifier,
                    name="External ID",
                    description="An identifier",
                )
            ],
        )
        # when we create it
        state = sut.create(self.client)
        # then state is returned
        assert state is not None
        assert state["provider"] == "Lusid.CustomEntity.TestEntity"

    def test_create_with_nested_field(self, respx_mock: Router, default_content):
        setup_sql_background_routes(respx_mock, result_data=default_content)
        # given a CE inline with a structured property (key + field)
        entity_type = make_entity_type()
        prop_key = DefinitionRef(
            id="price-key", domain=Domain.CustomEntity, scope="test", code="Price"
        )
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(
                    key=prop_key,
                    field="Value",
                    name="Price Amount",
                    data_type=InlineDataType.Decimal,
                    description="The price amount",
                )
            ],
        )
        # when we create it
        sut.create(self.client)
        # then the SQL has the dotted key format
        actual = respx_mock.calls[0].request.content.decode()
        assert "'CustomEntity/test/Price.Value'" in actual

    def test_read(self, respx_mock):
        # given an existing CE inline
        existing = {
            "Key": "cefield",
            "Name": "Test Field",
            "DataType": "Text",
            "Description": "A test field",
        }
        csv_content = make_csv(existing)
        setup_sql_background_routes(respx_mock, result_data=[{"Content": csv_content}])
        entity_type = make_entity_type()
        sut = CustomEntityInlineResource(
            id="test", custom_entity_type=entity_type, properties=[]
        )
        old_state = SimpleNamespace(entity_name="TestEntity")
        # when we read it
        result = sut.read(self.client, old_state)
        # then the parsed properties are returned
        assert result == {
            "cefield": {
                "Name": "Test Field",
                "DataType": "Text",
                "Description": "A test field",
                "IsMain": None,
                "AsAt": None,
            }
        }
        # and the path uses the CE format
        actual = respx_mock.calls[0].request.content.decode()
        assert "TestEntitycustomentityproviderfactory.csv" in actual

    def test_update_no_changes(self, respx_mock):
        # given matching source and remote versions
        existing = {"Key": "cefield", "Name": "Test", "DataType": "Text", "Description": "desc"}
        csv_content = make_csv(existing)
        setup_sql_background_routes(respx_mock, result_data=[{"Content": csv_content}])
        entity_type = make_entity_type()
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(
                    name="Test", field="cefield",
                    data_type=InlineDataType.Text, description="desc",
                )
            ],
        )
        desired = sut.model_dump(mode="json", by_alias=True, exclude_none=True)
        source_version = hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()
        remote_version = hashlib.sha256(json.dumps({
            "cefield": {
                "Name": "Test", "DataType": "Text", "Description": "desc",
                "IsMain": None, "AsAt": None,
            }
        }, sort_keys=True).encode()).hexdigest()
        old_state = SimpleNamespace(
            source_version=source_version, remote_version=remote_version,
            provider="Lusid.CustomEntity.TestEntity", entity_name="TestEntity",
            entity_unique_id=entity_type.entity_unique_id,
            entity_field_hash=sut._entity_field_hash(),
        )
        # when we update
        result = sut.update(self.client, old_state)
        # then no update is performed
        assert result is None

    def test_update_entity_type_change_triggers_delete(self, respx_mock):
        # given an existing inline for a different entity type
        existing = {"Key": "cefield", "Name": "Test", "DataType": "Text", "Description": "desc"}
        csv_content = make_csv(existing)
        exec_id = "abcdefg"
        respx_mock.put("/honeycomb/api/SqlBackground", headers=[("Content-type", "text/plain")]).mock(
            return_value=httpx.Response(202, json={"executionId": exec_id})
        )
        respx_mock.get(f"/honeycomb/api/SqlBackground/{exec_id}").mock(
            return_value=httpx.Response(200, json={"status": TaskStatus.RAN_TO_COMPLETION})
        )
        respx_mock.get(f"/honeycomb/api/SqlBackground/{exec_id}/jsonproper").mock(
            return_value=httpx.Response(200, json=[{"Content": csv_content, "Error": ""}])
        )
        entity_type = make_entity_type("NewEntity")
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(
                    name="Test", field="cefield",
                    data_type=InlineDataType.Text, description="desc",
                )
            ],
        )
        old_state = SimpleNamespace(
            source_version="old", remote_version="old",
            provider="Lusid.CustomEntity.OldEntity", entity_name="OldEntity",
        )
        # when we update
        new_state = sut.update(self.client, old_state)
        # then delete is called first (reset on old provider)
        del_request = respx_mock.calls[0].request.content.decode()
        assert "Lusid.CustomEntity.OldEntity" in del_request
        assert "Reset" in del_request
        # and create returns state with new provider
        assert new_state is not None
        assert new_state["provider"] == "Lusid.CustomEntity.NewEntity"
        assert new_state["entity_name"] == "NewEntity"

    def test_delete(self, respx_mock):
        setup_sql_background_routes(respx_mock, result_data=[])
        # given an existing CE inline
        old_state = SimpleNamespace(
            provider="Lusid.CustomEntity.TestEntity", entity_name="TestEntity",
        )
        # when we delete it
        CustomEntityInlineResource.delete(self.client, old_state)
        # then the reset SQL is sent
        del_request = respx_mock.calls[0].request.content.decode()
        assert "Lusid.CustomEntity.TestEntity" in del_request
        assert "Reset" in del_request
        # and no extension clause
        assert "ProviderNameExtension" not in del_request

    def test_deps_includes_entity_type(self):
        # given a CE inline with entity type and properties
        entity_type = make_entity_type()
        prop_key = DefinitionRef(
            id="ce-id", domain=Domain.CustomEntity, scope="test", code="ExternalId"
        )
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(key=prop_key, name="External ID", description="An identifier")
            ],
        )
        # then deps includes both the entity type and the property key
        deps = sut.deps()
        assert entity_type in deps
        assert prop_key in deps

    def test_deps_field_only(self):
        # given a CE inline with only field properties (no key)
        entity_type = make_entity_type()
        sut = CustomEntityInlineResource(
            id="test",
            custom_entity_type=entity_type,
            properties=[
                InlineProperty(
                    name="Test", field="cefield",
                    data_type=InlineDataType.Text, description="desc",
                )
            ],
        )
        # then deps includes only the entity type
        deps = sut.deps()
        assert deps == [entity_type]

    def test_update_reconfigures_when_entity_type_fields_change(
        self, respx_mock
    ):
        # given a custom entity type with one field
        original_entity_type = make_entity_type("TestEntity")
        original_entity_type.field_schema = [
            customentity.FieldDefinition(
                name="FieldA",
                lifetime=customentity.LifeTime.PERPETUAL,
                type=customentity.FieldType.STRING,
                required=False,
            )
        ]
        # mock the entity type API
        respx_mock.post("/api/api/customentitytypes").mock(
            return_value=httpx.Response(200, json={
                "entityType": "~TestEntity",
                "version": {"entityUniqueId": "uuid-1"},
            })
        )
        original_fields_response = {
            "entityTypeName": "TestEntity",
            "displayName": "Test Entity",
            "description": "A test custom entity",
            "fieldSchema": [
                {"name": "FieldA", "lifetime": "Perpetual",
                 "type": "String", "required": False}
            ],
            "version": {"entityUniqueId": "uuid-1"},
        }
        updated_fields_response = {
            **original_fields_response,
            "fieldSchema": [
                *original_fields_response["fieldSchema"],
                {"name": "FieldB", "lifetime": "Perpetual",
                 "type": "String", "required": False},
            ],
        }
        respx_mock.get(
            "/api/api/customentitytypes/~TestEntity"
        ).mock(side_effect=[
            httpx.Response(200, json=original_fields_response),
            httpx.Response(200, json=updated_fields_response),
        ])
        respx_mock.put(
            "/api/api/customentitytypes/~TestEntity"
        ).mock(return_value=httpx.Response(200, json={
            "entityType": "~TestEntity",
            "version": {"entityUniqueId": "uuid-1"},
        }))
        # and a CE inline that inlines a field
        existing = {
            "Key": "IdentifierA",
            "Name": "Identifier A",
            "DataType": "Text",
            "Description": "First identifier",
        }
        csv_content = make_csv(existing)
        exec_id = "abcdefg"
        respx_mock.put(
            "/honeycomb/api/SqlBackground",
            headers=[("Content-type", "text/plain")],
        ).mock(return_value=httpx.Response(
            202, json={"executionId": exec_id}
        ))
        respx_mock.get(
            f"/honeycomb/api/SqlBackground/{exec_id}"
        ).mock(return_value=httpx.Response(
            200, json={"status": TaskStatus.RAN_TO_COMPLETION}
        ))
        respx_mock.get(
            f"/honeycomb/api/SqlBackground/{exec_id}/jsonproper"
        ).mock(return_value=httpx.Response(
            200, json=[{"Content": csv_content, "Error": ""}]
        ))
        inline_sut = CustomEntityInlineResource(
            id="test-ce-inline",
            custom_entity_type=original_entity_type,
            properties=[
                InlineProperty(
                    name="Identifier A", field="IdentifierA",
                    data_type=InlineDataType.Text,
                    description="First identifier",
                )
            ],
        )
        # when we first deploy
        ce_state_dict = original_entity_type.create(self.client)
        assert ce_state_dict is not None
        ce_state = SimpleNamespace(**ce_state_dict)
        inline_state_dict = inline_sut.create(self.client)
        assert inline_state_dict is not None
        inline_state = SimpleNamespace(**inline_state_dict)
        # and a new field is added to the entity type
        updated_entity_type = make_entity_type("TestEntity")
        updated_entity_type.field_schema = [
            *original_entity_type.field_schema,
            customentity.FieldDefinition(
                name="FieldB",
                lifetime=customentity.LifeTime.PERPETUAL,
                type=customentity.FieldType.STRING,
                required=False,
            ),
        ]
        updated_entity_type.update(self.client, ce_state)
        # then the inline detects the field change and reconfigures
        inline_sut.custom_entity_type = updated_entity_type
        new_state = inline_sut.update(self.client, inline_state)
        assert new_state == {
            "provider": "Lusid.CustomEntity.TestEntity",
            "entity_name": "TestEntity",
            "entity_unique_id": "uuid-1",
            "entity_field_hash": (
                "362d3f5aa565586618bc44808fb58bbb"
                "089f3d1633231f24006b364d161dab5d"
            ),
            "source_version": (
                "fa24d50e81395cf9d3e0c93beea6c7b6"
                "885e2381b6712de264c5945958285a73"
            ),
            "remote_version": (
                "0b8dee0e4f1b94ff2107ae7231b05e9f"
                "47d9feee8a23de1ac761c457f8a50f40"
            ),
        }
