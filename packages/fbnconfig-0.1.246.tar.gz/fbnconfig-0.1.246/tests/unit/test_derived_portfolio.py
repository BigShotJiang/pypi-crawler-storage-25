import datetime as dt
import hashlib
import json
from types import SimpleNamespace
from typing import Any

import httpx
import pytest

from fbnconfig import portfolio as pf

TEST_BASE = "https://foo.lusid.com"
EUID_1 = "euid-00001"
EUID_2 = "euid-00002"


def response_hook(response: httpx.Response):
    response.read()
    response.raise_for_status()


def _create_response(euid=EUID_1):
    return {"version": {"entityUniqueId": euid}}


def _make_parent():
    return pf.PortfolioResource(
        id="parent-pf", scope="test-scope", code="parent-pf",
        display_name="Parent", description="Parent portfolio",
        base_currency="USD",
        created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        instrument_scopes=["test-scope"],
    )


def _make_derived(parent=None, **overrides: Any):
    parent = parent or _make_parent()
    defaults: dict[str, Any] = dict(
        id="derived-pf", scope="test-scope", code="derived-pf",
        display_name="Derived", description="Derived portfolio",
        parent_portfolio_id=parent,
        created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        instrument_scopes=["test-scope"],
    )
    return pf.DerivedTransactionPortfolioResource(**(defaults | overrides))


def _remote_json(scope="test-scope", code="derived-pf"):
    return {
        "id": {"scope": scope, "code": code},
        "displayName": "Derived", "description": "Derived portfolio",
        "type": "DerivedTransaction", "isDerived": True,
        "parentPortfolioId": {"scope": "test-scope", "code": "parent-pf"},
        "created": "2024-01-01T12:00:00+00:00",
        "instrumentScopes": ["test-scope"],
        "version": {}, "links": [],
    }


def _details_json():
    return {"subHoldingKeys": [], "version": {}, "links": []}


@pytest.mark.respx(base_url=TEST_BASE)
class DescribeDerivedTransactionPortfolioResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create(self, respx_mock):
        create_mock = respx_mock.post(
            "/api/api/derivedtransactionportfolios/test-scope"
        ).mock(return_value=httpx.Response(201, json=_create_response()))
        # given a derived portfolio
        sut = _make_derived()
        # when we create it
        result = sut.create(self.client)
        # then a POST is sent to the derived endpoint with parentPortfolioId
        assert len(create_mock.calls) == 1
        body = json.loads(create_mock.calls[0].request.content)
        assert body["parentPortfolioId"] == {"scope": "test-scope", "code": "parent-pf"}
        assert body["displayName"] == "Derived"
        assert "scope" not in body
        # and the result has instance tracking
        assert result["scope"] == "test-scope"
        assert result["code"] == "derived-pf"
        assert "content_hash" in result
        assert result["instance"] == EUID_1

    def test_read(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json=_remote_json())
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/derived-pf/details").mock(
            return_value=httpx.Response(200, json=_details_json())
        )
        # given a derived portfolio
        sut = _make_derived()
        old_state = SimpleNamespace(scope="test-scope", code="derived-pf")
        # when we read it
        result = sut.read(self.client, old_state)
        # then both portfolio and details are fetched and merged
        assert result["displayName"] == "Derived"
        assert "version" not in result
        assert "links" not in result
        assert "subHoldingKeys" in result

    def test_update_no_change(self):
        # given a derived portfolio with matching content_hash
        sut = _make_derived()
        desired = sut.model_dump(
            mode="json", exclude_none=True, by_alias=True,
            exclude={"id", "instance", "scope", "parent_portfolio_id"},
        )
        desired["parentPortfolioId"] = {"scope": "test-scope", "code": "parent-pf"}
        content_hash = hashlib.sha256(
            json.dumps(desired, sort_keys=True).encode()
        ).hexdigest()
        old_state = SimpleNamespace(
            scope="test-scope", code="derived-pf", content_hash=content_hash,
            instance=EUID_1,
        )
        # when we update it
        result = sut.update(self.client, old_state)
        # then no change is detected
        assert result is None

    def test_update_display_name(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json=_remote_json())
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/derived-pf/details").mock(
            return_value=httpx.Response(200, json=_details_json())
        )
        put_mock = respx_mock.put("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json={})
        )
        # given a derived portfolio with a changed display name
        sut = _make_derived(display_name="Updated Name")
        old_state = SimpleNamespace(
            scope="test-scope", code="derived-pf", content_hash="old", instance=EUID_1,
        )
        # when we update it
        result = sut.update(self.client, old_state)
        # then a PUT is sent with the new display name
        assert result is not None
        assert len(put_mock.calls) == 1
        body = json.loads(put_mock.calls[0].request.content)
        assert body["displayName"] == "Updated Name"

    def test_update_description(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json=_remote_json())
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/derived-pf/details").mock(
            return_value=httpx.Response(200, json=_details_json())
        )
        put_mock = respx_mock.put("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json={})
        )
        # given a derived portfolio with a changed description
        sut = _make_derived(description="New description")
        old_state = SimpleNamespace(
            scope="test-scope", code="derived-pf", content_hash="old", instance=EUID_1,
        )
        # when we update it
        result = sut.update(self.client, old_state)
        # then a PUT is sent with the new description
        assert result is not None
        assert len(put_mock.calls) == 1
        body = json.loads(put_mock.calls[0].request.content)
        assert body["description"] == "New description"

    def test_update_accounting_method(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json=_remote_json())
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/derived-pf/details").mock(
            return_value=httpx.Response(200, json=_details_json())
        )
        patch_mock = respx_mock.patch(
            "/api/api/transactionportfolios/test-scope/derived-pf/details"
        ).mock(return_value=httpx.Response(200, json={}))
        # given a derived portfolio with accounting method set
        sut = _make_derived(accounting_method="AverageCost")
        old_state = SimpleNamespace(
            scope="test-scope", code="derived-pf", content_hash="old", instance=EUID_1,
        )
        # when we update it
        result = sut.update(self.client, old_state)
        # then a PATCH is sent to the details endpoint
        assert result is not None
        assert len(patch_mock.calls) == 1
        ops = json.loads(patch_mock.calls[0].request.content)
        assert ops == [{"op": "add", "path": "/accountingMethod", "value": "AverageCost"}]

    def test_update_scope_code_changed(self, respx_mock):
        delete_mock = respx_mock.delete("/api/api/portfolios/old-scope/old-code").mock(
            return_value=httpx.Response(200, json={})
        )
        create_mock = respx_mock.post(
            "/api/api/derivedtransactionportfolios/test-scope"
        ).mock(return_value=httpx.Response(201, json=_create_response()))
        # given a derived portfolio whose scope/code changed
        sut = _make_derived()
        old_state = SimpleNamespace(
            scope="old-scope", code="old-code", content_hash="old", instance=EUID_1,
        )
        # when we update it
        result = sut.update(self.client, old_state)
        # then the old one is deleted
        assert len(delete_mock.calls) == 1
        assert delete_mock.calls[0].request.url.path == "/api/api/portfolios/old-scope/old-code"
        # and a new one is created
        assert len(create_mock.calls) == 1
        assert result is not None
        assert result["scope"] == "test-scope"
        assert result["code"] == "derived-pf"

    def test_update_does_not_patch_created_or_instrument_scopes(self, respx_mock):
        remote = _remote_json()
        remote["created"] = "2023-06-15T00:00:00+00:00"  # different from desired
        remote["instrumentScopes"] = ["other-scope"]      # different from desired
        respx_mock.get("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json=remote)
        )
        respx_mock.get("/api/api/transactionportfolios/test-scope/derived-pf/details").mock(
            return_value=httpx.Response(200, json=_details_json())
        )
        # given a derived portfolio where remote has different created/instrumentScopes
        sut = _make_derived()
        old_state = SimpleNamespace(
            scope="test-scope", code="derived-pf", content_hash="old", instance=EUID_1,
        )
        # when we update it
        sut.update(self.client, old_state)
        # then NO PATCH is sent to the portfolios endpoint (created/instrumentScopes are inherited)
        patch_calls = [c for c in respx_mock.calls if c.request.method == "PATCH"]
        assert len(patch_calls) == 0

    def test_delete(self, respx_mock):
        delete_mock = respx_mock.delete("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json={})
        )
        # given a derived portfolio
        old_state = SimpleNamespace(scope="test-scope", code="derived-pf")
        # when we delete it
        pf.DerivedTransactionPortfolioResource.delete(self.client, old_state)
        # then a DELETE is sent to the portfolios endpoint
        assert len(delete_mock.calls) == 1
        assert delete_mock.calls[0].request.url.path == "/api/api/portfolios/test-scope/derived-pf"

    def test_deps(self):
        # given a derived portfolio with a parent
        parent = _make_parent()
        sut = _make_derived(parent=parent)
        # when we get dependencies
        deps = sut.deps()
        # then the parent is included
        assert parent in deps

    def test_dump(self):
        # given a derived portfolio
        sut = _make_derived()
        # when we dump it
        dumped = sut.model_dump(
            by_alias=True, round_trip=True, exclude_none=True,
            context={"style": "dump"},
        )
        # then the parent is a $ref and id/instance are excluded
        assert dumped == {
            "scope": "test-scope",
            "code": "derived-pf",
            "displayName": "Derived",
            "description": "Derived portfolio",
            "parentPortfolioId": {"$ref": "parent-pf"},
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"],
        }

    def test_undump(self):
        # given a dumped derived portfolio with $refs
        parent = _make_parent()
        dumped = {
            "scope": "test-scope",
            "code": "derived-pf",
            "displayName": "Derived",
            "description": "Derived portfolio",
            "parentPortfolioId": {"$ref": "parent-pf"},
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"],
        }
        refs = {"parent-pf": parent}
        # when we undump it
        sut = pf.DerivedTransactionPortfolioResource.model_validate(
            dumped, context={"style": "dump", "$refs": refs, "id": "derived-pf"},
        )
        # then the parent ref is resolved
        assert sut.id == "derived-pf"
        assert sut.parent_portfolio_id is parent
        assert sut.display_name == "Derived"


@pytest.mark.respx(base_url=TEST_BASE)
class DescribeDerivedTransactionPortfolioRef:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_attach(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/derived-pf").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Derived",
                "version": {"entityUniqueId": EUID_1},
            })
        )
        # given a derived portfolio ref
        ref = pf.DerivedTransactionPortfolioRef(
            id="ref1", scope="test-scope", code="derived-pf",
        )
        # when we attach it
        result = ref.attach(self.client)
        # then the portfolio data is returned and instance is set
        assert result["displayName"] == "Derived"
        assert ref.instance == EUID_1

    def test_attach_not_found(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/missing").mock(
            return_value=httpx.Response(404)
        )
        # given a ref to a non-existent portfolio
        ref = pf.DerivedTransactionPortfolioRef(
            id="ref1", scope="test-scope", code="missing",
        )
        # when we attach it, then a RuntimeError is raised
        with pytest.raises(RuntimeError, match="not found"):
            ref.attach(self.client)
