import datetime as dt
import hashlib
import json
from types import SimpleNamespace

import httpx
import pytest

from fbnconfig import reference_portfolio as rp

TEST_BASE = "https://foo.lusid.com"
EUID_1 = "euid-00001"
EUID_2 = "euid-00002"


def response_hook(response: httpx.Response):
    response.read()
    response.raise_for_status()


def _create_response(euid=EUID_1):
    return {"version": {"entityUniqueId": euid}}


def make_ref_portfolio(instance: str | None = EUID_1):
    return rp.ReferencePortfolioResource(
        id="rp1",
        scope="test-scope",
        code="test-refpf",
        display_name="Test Reference Portfolio",
        description="A reference portfolio",
        base_currency="USD",
        created=dt.datetime(2024, 1, 1, 12, 0, 0, tzinfo=dt.timezone.utc),
        instrument_scopes=["test-scope"],
        instance=instance,
    )


def ref_portfolio_hash(sut):
    desired = sut.model_dump(
        mode="json", exclude_none=True, by_alias=True, exclude={"id", "instance", "scope"},
    )
    return hashlib.sha256(json.dumps(desired, sort_keys=True).encode()).hexdigest()


@pytest.mark.respx(base_url=TEST_BASE)
class DescribeReferencePortfolioResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create(self, respx_mock):
        create_mock = respx_mock.post("/api/api/referenceportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response())
        )
        sut = make_ref_portfolio()
        result = sut.create(self.client)
        assert result["code"] == "test-refpf"
        assert result["scope"] == "test-scope"
        assert result["instance"] == EUID_1
        assert "content_hash" in result
        body = json.loads(create_mock.calls[0].request.content)
        assert body == {
            "code": "test-refpf",
            "displayName": "Test Reference Portfolio",
            "description": "A reference portfolio",
            "baseCurrency": "USD",
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"],
        }

    def test_read(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={
                "scope": "test-scope", "code": "test-refpf",
                "displayName": "Test Reference Portfolio",
                "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {"effectiveFrom": "2024-01-01T12:00:00+00:00"},
                "links": [],
            })
        )
        sut = make_ref_portfolio()
        old_state = SimpleNamespace(scope="test-scope", code="test-refpf")
        result = sut.read(self.client, old_state)
        assert result["scope"] == "test-scope"
        assert "version" not in result
        assert "links" not in result

    def test_update_no_change(self, respx_mock):
        sut = make_ref_portfolio()
        old_state = SimpleNamespace(
            scope="test-scope", code="test-refpf",
            content_hash=ref_portfolio_hash(sut), instance=EUID_1,
        )
        result = sut.update(self.client, old_state)
        assert result is None

    def test_update_display_name(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Old Name", "description": "A reference portfolio",
                "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        put_mock = respx_mock.put("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = make_ref_portfolio()
        sut.display_name = "New Name"
        old_state = SimpleNamespace(
            scope="test-scope", code="test-refpf", content_hash="old", instance=EUID_1,
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(put_mock.calls) == 1
        body = json.loads(put_mock.calls[0].request.content)
        assert body == {"displayName": "New Name"}
        assert result["instance"] == EUID_1

    def test_update_description(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Test Reference Portfolio", "description": "old desc",
                "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        put_mock = respx_mock.put("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = make_ref_portfolio()
        old_state = SimpleNamespace(
            scope="test-scope", code="test-refpf", content_hash="old", instance=EUID_1,
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(put_mock.calls) == 1
        body = json.loads(put_mock.calls[0].request.content)
        assert body == {"description": "A reference portfolio"}

    def test_update_created(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Test Reference Portfolio",
                "description": "A reference portfolio",
                "baseCurrency": "USD",
                "created": "2023-06-01T00:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        patch_mock = respx_mock.patch("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = make_ref_portfolio()
        old_state = SimpleNamespace(
            scope="test-scope", code="test-refpf", content_hash="old", instance=EUID_1,
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(patch_mock.calls) == 1
        ops = json.loads(patch_mock.calls[0].request.content)
        assert ops == [{"op": "add", "path": "/created", "value": "2024-01-01T12:00:00+00:00"}]

    def test_update_instrument_scopes(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={
                "displayName": "Test Reference Portfolio",
                "description": "A reference portfolio",
                "baseCurrency": "USD",
                "created": "2024-01-01T12:00:00+00:00",
                "instrumentScopes": ["test-scope"],
                "version": {}, "links": [],
            })
        )
        patch_mock = respx_mock.patch("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={})
        )
        sut = make_ref_portfolio()
        sut.instrument_scopes = ["test-scope", "new-scope"]
        old_state = SimpleNamespace(
            scope="test-scope", code="test-refpf", content_hash="old", instance=EUID_1,
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert len(patch_mock.calls) == 1
        ops = json.loads(patch_mock.calls[0].request.content)
        assert ops == [{"op": "add", "path": "/instrumentScopes", "value": ["test-scope", "new-scope"]}]

    def test_update_scope_code_changed(self, respx_mock):
        respx_mock.delete("/api/api/portfolios/test-scope/old-code").mock(
            return_value=httpx.Response(200, json={})
        )
        create_mock = respx_mock.post("/api/api/referenceportfolios/test-scope").mock(
            return_value=httpx.Response(200, json=_create_response(EUID_2))
        )
        sut = make_ref_portfolio()
        old_state = SimpleNamespace(
            scope="test-scope", code="old-code", content_hash="old", instance=EUID_1,
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["code"] == "test-refpf"
        assert result["instance"] == EUID_2
        assert len(create_mock.calls) == 1

    def test_delete(self, respx_mock):
        delete_mock = respx_mock.delete("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={})
        )
        old_state = SimpleNamespace(scope="test-scope", code="test-refpf")
        rp.ReferencePortfolioResource.delete(self.client, old_state)
        assert delete_mock.calls[0].request.method == "DELETE"

    def test_deps(self):
        sut = make_ref_portfolio()
        assert sut.deps() == []


@pytest.mark.respx(base_url=TEST_BASE)
class DescribeReferencePortfolioRef:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_attach(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/test-refpf").mock(
            return_value=httpx.Response(200, json={
                "scope": "test-scope", "code": "test-refpf",
                "version": {"entityUniqueId": EUID_1},
            })
        )
        sut = rp.ReferencePortfolioRef(id="rp-ref", scope="test-scope", code="test-refpf")
        result = sut.attach(self.client)
        assert result["scope"] == "test-scope"
        assert sut.instance == EUID_1

    def test_attach_not_found(self, respx_mock):
        respx_mock.get("/api/api/portfolios/test-scope/missing").mock(
            return_value=httpx.Response(404)
        )
        sut = rp.ReferencePortfolioRef(id="rp-ref", scope="test-scope", code="missing")
        with pytest.raises(RuntimeError, match="not found"):
            sut.attach(self.client)


def make_constituents_resource(portfolio=None):
    if portfolio is None:
        portfolio = make_ref_portfolio()
    return rp.ReferencePortfolioConstituentsResource(
        id="rc1",
        portfolio=portfolio,
        effective_from=dt.datetime(2024, 1, 5, tzinfo=dt.timezone.utc),
        weight_type="Static",
        constituents=[
            rp.Constituent(
                instrument_identifiers={"Instrument/default/Figi": "BBG000B9XRY4"},
                weight=0.6,
                currency="USD",
            ),
            rp.Constituent(
                instrument_identifiers={"Instrument/default/Figi": "BBG000BVPV84"},
                weight=0.4,
                currency="GBP",
            ),
        ],
    )


def constituents_hash(sut):
    body = sut._constituents_body()
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()


@pytest.mark.respx(base_url=TEST_BASE)
class DescribeReferencePortfolioConstituentsResource:
    client = httpx.Client(base_url=TEST_BASE, event_hooks={"response": [response_hook]})

    def test_create(self, respx_mock):
        create_mock = respx_mock.post(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        sut = make_constituents_resource()
        result = sut.create(self.client)
        assert result["portfolio_scope"] == "test-scope"
        assert result["portfolio_code"] == "test-refpf"
        assert result["portfolio_instance"] == EUID_1
        assert result["effective_from"] == "2024-01-05T00:00:00+00:00"
        assert "content_hash" in result
        body = json.loads(create_mock.calls[0].request.content)
        assert body["weightType"] == "Static"
        assert body["effectiveFrom"] == "2024-01-05T00:00:00+00:00"
        assert len(body["constituents"]) == 2

    def test_read(self, respx_mock):
        respx_mock.get(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={
            "constituents": [
                {"instrumentIdentifiers": {"Instrument/default/Figi": "BBG000B9XRY4"}, "weight": 0.6},
            ],
        }))
        sut = make_constituents_resource()
        old_state = SimpleNamespace(portfolio_scope="test-scope", portfolio_code="test-refpf")
        result = sut.read(self.client, old_state)
        assert len(result) == 1

    def test_update_no_change(self, respx_mock):
        sut = make_constituents_resource()
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            portfolio_instance=EUID_1, content_hash=constituents_hash(sut),
        )
        result = sut.update(self.client, old_state)
        assert result is None

    def test_update_changed_constituents(self, respx_mock):
        respx_mock.post(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        sut = make_constituents_resource()
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            portfolio_instance=EUID_1, content_hash="different",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["content_hash"] == constituents_hash(sut)

    def test_update_portfolio_recreated(self, respx_mock):
        respx_mock.post(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        sut = make_constituents_resource()
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            portfolio_instance=EUID_2, content_hash=constituents_hash(sut),
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["portfolio_instance"] == EUID_1

    def test_update_portfolio_moved(self, respx_mock):
        # delete the old constituents
        respx_mock.post(
            "/api/api/referenceportfolios/old-scope/old-code/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        # create the new constituents
        respx_mock.post(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        sut = make_constituents_resource()
        old_state = SimpleNamespace(
            portfolio_scope="old-scope", portfolio_code="old-code",
            portfolio_instance=EUID_1, content_hash=constituents_hash(sut),
            effective_from="2024-01-01T00:00:00+00:00",
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["portfolio_scope"] == "test-scope"

    def test_update_with_ref_recreates_on_instance_change(self, respx_mock):
        respx_mock.post(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        ref = rp.ReferencePortfolioRef(id="rp-ref", scope="test-scope", code="test-refpf")
        ref.instance = EUID_2
        sut = make_constituents_resource(portfolio=ref)
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            portfolio_instance=EUID_1, content_hash=constituents_hash(sut),
        )
        result = sut.update(self.client, old_state)
        assert result is not None
        assert result["portfolio_instance"] == EUID_2

    def test_update_with_ref_no_change(self, respx_mock):
        ref = rp.ReferencePortfolioRef(id="rp-ref", scope="test-scope", code="test-refpf")
        ref.instance = EUID_1
        sut = make_constituents_resource(portfolio=ref)
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            portfolio_instance=EUID_1, content_hash=constituents_hash(sut),
        )
        result = sut.update(self.client, old_state)
        assert result is None

    def test_delete(self, respx_mock):
        delete_mock = respx_mock.post(
            "/api/api/referenceportfolios/test-scope/test-refpf/constituents"
        ).mock(return_value=httpx.Response(200, json={}))
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            effective_from="2024-01-05T00:00:00+00:00",
        )
        rp.ReferencePortfolioConstituentsResource.delete(self.client, old_state)
        assert len(delete_mock.calls) == 1
        body = json.loads(delete_mock.calls[0].request.content)
        assert body == {
            "effectiveFrom": "2024-01-05T00:00:00+00:00",
            "weightType": "Static",
            "constituents": [],
        }

    def test_deps(self):
        sut = make_constituents_resource()
        deps = sut.deps()
        assert sut.portfolio in deps

    def test_nochange_portfolio_preserves_instance_for_constituents(self, respx_mock):
        # given a reference portfolio without instance (as from config)
        portfolio = make_ref_portfolio(instance=None)
        # and the portfolio's logged state has an instance from a previous create
        portfolio_state = SimpleNamespace(
            code="test-refpf", scope="test-scope", instance=EUID_1,
            content_hash=ref_portfolio_hash(portfolio),
        )
        # when the portfolio update returns None (nochange)
        portfolio.update(self.client, portfolio_state)
        # then the instance should be carried forward
        assert portfolio.instance == EUID_1
        # and a dependent constituents resource sees nochange
        sut = make_constituents_resource(portfolio=portfolio)
        old_state = SimpleNamespace(
            portfolio_scope="test-scope", portfolio_code="test-refpf",
            portfolio_instance=EUID_1, content_hash=constituents_hash(sut),
        )
        result = sut.update(self.client, old_state)
        assert result is None


class DescribeConstituent:
    def test_serialization(self):
        c = rp.Constituent(
            instrument_identifiers={"Instrument/default/Figi": "BBG000B9XRY4"},
            weight=0.6,
            currency="USD",
        )
        dumped = c.model_dump(by_alias=True)
        assert dumped["instrumentIdentifiers"] == {"Instrument/default/Figi": "BBG000B9XRY4"}
        assert dumped["weight"] == 0.6
        assert dumped["currency"] == "USD"


class DescribeDumpUndump:
    dump_ctx = {"style": "dump"}

    def test_dump_reference_portfolio(self):
        sut = make_ref_portfolio()
        dumped = sut.model_dump(
            by_alias=True, round_trip=True, exclude_none=True, context=self.dump_ctx,
        )
        assert dumped["scope"] == "test-scope"
        assert dumped["code"] == "test-refpf"
        assert dumped["baseCurrency"] == "USD"
        assert "id" not in dumped

    def test_undump_reference_portfolio(self):
        dumped = {
            "scope": "test-scope", "code": "test-refpf",
            "displayName": "Test Reference Portfolio",
            "description": "A reference portfolio",
            "baseCurrency": "USD",
            "created": "2024-01-01T12:00:00+00:00",
            "instrumentScopes": ["test-scope"], "instance": EUID_1,
        }
        sut = rp.ReferencePortfolioResource.model_validate(
            dumped, context={"style": "dump", "$refs": {}, "id": "rp1"},
        )
        assert sut.id == "rp1"
        assert sut.scope == "test-scope"
        assert sut.base_currency == "USD"

    def test_dump_constituents(self):
        portfolio = make_ref_portfolio()
        sut = make_constituents_resource(portfolio=portfolio)
        dumped = sut.model_dump(
            by_alias=True, round_trip=True, exclude_none=True, context=self.dump_ctx,
        )
        assert dumped["portfolio"] == {"$ref": "rp1"}
        assert dumped["weightType"] == "Static"
        assert len(dumped["constituents"]) == 2

    def test_undump_constituents(self):
        portfolio = make_ref_portfolio()
        dumped = {
            "portfolio": {"$ref": "rp1"},
            "effectiveFrom": "2024-01-05T00:00:00+00:00",
            "weightType": "Static",
            "constituents": [
                {"instrumentIdentifiers": {"Instrument/default/Figi": "BBG000B9XRY4"},
                 "weight": 0.6, "currency": "USD"},
            ],
        }
        refs = {"rp1": portfolio}
        sut = rp.ReferencePortfolioConstituentsResource.model_validate(
            dumped, context={"style": "dump", "$refs": refs, "id": "rc1"},
        )
        assert sut.id == "rc1"
        assert sut.portfolio is portfolio
        assert len(sut.constituents) == 1
        assert sut.weight_type == "Static"
