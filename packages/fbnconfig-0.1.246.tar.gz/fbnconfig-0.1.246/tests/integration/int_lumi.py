import json
import os
from types import SimpleNamespace

import pytest
from pytest import fixture, mark

import fbnconfig
import tests.integration.lumi as lumi
from fbnconfig import lumi as fbn_lumi
from tests.integration.generate_test_name import gen

pytestmark = mark.skip(reason="Flaky test - skipped")

if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
    raise (
        RuntimeError("Both FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set to run these tests")
    )

lusid_env = os.environ["LUSID_ENV"]
token = os.environ["FBN_ACCESS_TOKEN"]
host_vars = {}
client = fbnconfig.create_client(lusid_env, token)


def put_query(client, sql):
    res = client.put(
        "/honeycomb/api/Sql/json",
        content=sql,
        params={"jsonProper": True},
        headers={"Content-type": "text/plain"},
    )
    return res.json()


def get_protected_status(provider: str) -> bool | None:
    """Query sys.file for the view and return UpdateInfo.Protected from its metadata."""
    path = provider.replace(".", "/")
    r = put_query(client, f"""
        select Content from sys.file
        where path = 'databaseproviders/{path}.sql'
    """)
    if not r:
        return None
    metadata = json.loads(r[0]["Content"].split("--- MetaData ---")[1])
    return metadata.get("UpdateInfo", {}).get("Protected")


@fixture(scope="module")
def setup_deployment():
    deployment_name = gen("lumi")
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    # Teardown: Clean up resources (if any) after the test
    print("\nTearing down resources...")
    fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env, token)


@fixture
def setup_protected_deployment(setup_deployment):
    deployment_name = f"{setup_deployment.name}_prot"
    yield SimpleNamespace(name=deployment_name)
    fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env, token)


def test_teardown(setup_deployment):
    check = f"""
        select content from sys.file
        where path = 'databaseproviders/Views/fbnconfig/{setup_deployment.name}_vr.sql'
    """
    # create
    fbnconfig.deployex(lumi.configure(setup_deployment), lusid_env, token)
    # check it exists
    r = put_query(client, check)
    assert len(r) == 1
    # remove it
    fbnconfig.deployex(fbnconfig.Deployment(setup_deployment.name, []), lusid_env, token)
    # check it's gone
    r = put_query(client, check)
    assert len(r) == 0


def test_create(setup_deployment):
    fbnconfig.deployex(lumi.configure(setup_deployment), lusid_env, token)
    r = put_query(
        client,
        f"""
        select content from sys.file
        where path = 'databaseproviders/Views/fbnconfig/{setup_deployment.name}_vr.sql'
    """,
    )
    assert len(r) == 1


def test_nochange(setup_deployment):
    fbnconfig.deployex(lumi.configure(setup_deployment), lusid_env, token)
    update = fbnconfig.deployex(lumi.configure(setup_deployment), lusid_env, token)
    assert [a.change for a in update if a.type == "ViewResource"] == ["nochange"] * 4


def test_toggle_protected(setup_protected_deployment):
    provider = f"Views.fbnconfig.{setup_protected_deployment.name}"

    # create with protected=True
    view = fbn_lumi.ViewResource(
        id="protected-view",
        provider=provider,
        description="Test view for protected toggle",
        sql="select 1 as one",
        protected=True,
        use_dry_run=True,
    )
    actions = fbnconfig.deployex(
        fbnconfig.Deployment(setup_protected_deployment.name, [view]),
        lusid_env, token,
    )
    assert any(a.change == "create" for a in actions if a.type == "ViewResource")

    # verify it is protected
    assert get_protected_status(provider) is True

    # update to protected=False
    view = fbn_lumi.ViewResource(
        id="protected-view",
        provider=provider,
        description="Test view for protected toggle",
        sql="select 1 as one",
        protected=False,
        use_dry_run=True,
    )
    actions = fbnconfig.deployex(
        fbnconfig.Deployment(setup_protected_deployment.name, [view]),
        lusid_env, token,
    )
    assert any(a.change == "update" for a in actions if a.type == "ViewResource")

    # verify it is no longer protected
    assert get_protected_status(provider) is False


@pytest.mark.asyncio
async def test_view_fetch(setup_deployment):
    # GIVEN View is deployed
    fbnconfig.deployex(lumi.configure(setup_deployment), lusid_env, token)
    provider = f"Views.fbnconfig.{setup_deployment.name}_vr"
    client = fbnconfig.create_client(lusid_env, token, is_async=True)
    # WHEN the fetch method is called for that resource
    response = await lumi.lumi.ViewResource.fetch(
        client=client,
        keys={
            "provider": provider
        }
    )
    # THEN the response is as expected
    expected_response = {
        "id": f"view_{provider}".lower(),
        "provider": provider,
        "documentationLink": "http://example.com/query4",
        "description": "My resource test view",
        "allowExecuteIndirectly": False,
        "protected": False,
        "variableShape": False,
        "sql": """
            select 2+#PARAMETERVALUE(p1)
            as   twelve""",
        "parameters": [
            {
                "isMandatory": False,
                "name": "p1",
                "setAsDefaultValue": True,
                "tooltip": "a number, defaults to 10",
                "type": "Int",
                "value": 10
            },
            {
                "isMandatory": False,
                "name": "p2",
                "setAsDefaultValue": True,
                "tooltip": "a string",
                "type": "Text",
                "value": "a default"
            },
            {
                "isMandatory": False,
                "name": "no_tooltip",
                "setAsDefaultValue": True,
                "tooltip": None,
                "type": "Text",
                "value": "a default"
            }
        ],
    }
    assert response == expected_response


@pytest.mark.asyncio
async def test_view_list(setup_deployment):
    # GIVEN View is deployed
    fbnconfig.deployex(lumi.configure(setup_deployment), lusid_env, token)
    provider = f"Views.fbnconfig.{setup_deployment.name}_vr"
    client = fbnconfig.create_client(lusid_env, token, is_async=True)
    # WHEN calling list with limit of 2
    response = await lumi.lumi.ViewResource.list(
        client=client,
    )
    # THEN the response is as expected
    view = [view for view in response["values"] if view["value"]["provider"] == provider][0]
    expected_view = {
        "value": {
            "id": f"view_{provider}".lower(),
            "provider": provider,
            "documentationLink": "http://example.com/query4",
            "description": "My resource test view",
            "allowExecuteIndirectly": False,
            "protected": False,
            "variableShape": False,
            "sql": """
            select 2+#PARAMETERVALUE(p1)
            as   twelve""",
            "parameters": [
                {
                    "isMandatory": False,
                    "name": "p1",
                    "setAsDefaultValue": True,
                    "tooltip": "a number, defaults to 10",
                    "type": "Int",
                    "value": 10
                },
                {
                    "isMandatory": False,
                    "name": "p2",
                    "setAsDefaultValue": True,
                    "tooltip": "a string",
                    "type": "Text",
                    "value": "a default"
                },
                {
                    "isMandatory": False,
                    "name": "no_tooltip",
                    "setAsDefaultValue": True,
                    "tooltip": None,
                    "type": "Text",
                    "value": "a default"
                }
            ],
        },
        "keys": {
            "provider": provider
        }
    }
    assert view == expected_view
