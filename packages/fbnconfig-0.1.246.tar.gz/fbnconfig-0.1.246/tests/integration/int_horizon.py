import os
from types import SimpleNamespace

import pytest
from pytest import fixture

import fbnconfig
from fbnconfig import Deployment, horizon
from tests.integration.generate_test_name import gen

if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
    raise (
        RuntimeError("Both FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set to run these tests")
    )

lusid_env = os.environ["LUSID_ENV"]
token = os.environ["FBN_ACCESS_TOKEN"]
host_vars = {}
client = fbnconfig.create_client(lusid_env, token)


@fixture
def setup_deployment():
    deployment_name = gen("horizon")
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    print("\nTearing down resources...")
    fbnconfig.deploy(fbnconfig.Deployment(deployment_name, []), lusid_env, token)


@fixture
def coppclark_instance(setup_deployment):
    return horizon.IntegrationInstanceResource(
        id="test-horizon-instance",
        integration_type="copp-clark",
        name=f"test-integration-{setup_deployment.name}",
        description="Test integration instance for horizon tests",
        enabled=True,
        triggers=[
            horizon.Trigger(type="time", cron_expression="0 0 9 ? * MON-FRI", time_zone="Europe/London")
        ],
        details={
            "paymentSystemsCalendar": {"currencyFilter": ["GBP", "USD"], "importUnqualified": False}
        },
    )


@fixture
def aladdin_instance(setup_deployment):
    return horizon.IntegrationInstanceResource(
        id="aladdin-instance",
        integration_type="blackrock-aladdin",
        name=f"test_aladdin-{setup_deployment.name}",
        description="my first aladdin",
        enabled=False,
        triggers=[],
        details={
            "sourceFileLocation": "/sftp",
            "onboardingDate": "2022-01-01",
            "localTimeZone": "Australia/Melbourne",
            "unpackFromArchive": False,
            "archiveFileMask": "",
            "isFxNdfAllowed": True,
            "int29AnalyticsFileType": "NotApplicable",
            "allowCoreFieldUpdates": "Never",
            "blackRockAladdinInterfaceSelections": [{
                "interfaceNumber": "Int96",
                "fileMask": "^ATOM_R_newcash96_daily.*_*.xml$",
                "localCutTime": "00:00"
            }]
        }
    )


@fixture
def updated_instance(setup_deployment):
    return horizon.IntegrationInstanceResource(
        id="test-update-instance",
        integration_type="copp-clark",
        name=f"updated-integration-{setup_deployment.name}",
        description="Updated test integration instance",
        enabled=True,
        triggers=[
            horizon.Trigger(type="time", cron_expression="0 0 9 ? * MON-FRI", time_zone="Europe/London")
        ],
        details={
            "paymentSystemsCalendar": {"currencyFilter": ["GBP", "USD"], "importUnqualified": False}
        },
    )


@fixture
def optional_props(aladdin_instance):
    return horizon.OptionalPropsResource(
        id="test-horizon-props",
        instance=aladdin_instance,
        props=[
            horizon.OptionalProp(
                property="Portfolio/LUSID-BlackRock-Aladdin/FUND",
                display_name_override="Aladdin Fund Code",
                description_override="The BlackRock Aladdin fund identifier",
            )
        ],
    )


@fixture
def full_deployment(setup_deployment, coppclark_instance, aladdin_instance, optional_props):
    return Deployment(setup_deployment.name, [coppclark_instance, aladdin_instance, optional_props])


@fixture
def update_deployment(setup_deployment, updated_instance):
    return Deployment(setup_deployment.name, [updated_instance])


def test_create_integration_instance(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    instances = client.get("/horizon/api/integrations/instances").json()
    instance_names = [instance["name"] for instance in instances]
    expected_name = f"test-integration-{setup_deployment.name}"
    assert expected_name in instance_names


def test_update_integration_instance(setup_deployment, full_deployment, update_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    update = fbnconfig.deploy(update_deployment, lusid_env, token)
    instances = client.get("/horizon/api/integrations/instances").json()
    instance_names = [instance["name"] for instance in instances]
    expected_name = f"updated-integration-{setup_deployment.name}"
    assert expected_name in instance_names
    instance_changes = [a.change for a in update if a.type == "IntegrationInstanceResource"]
    props_changes = [a.change for a in update if a.type == "OptionalPropsResource"]
    assert "update" in instance_changes or "create" in instance_changes
    assert "remove" in props_changes


def test_teardown_integration_instance(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    instances_before = client.get("/horizon/api/integrations/instances").json()
    initial_count = len(instances_before)
    teardown = fbnconfig.deploy(fbnconfig.Deployment(setup_deployment.name, []), lusid_env, token)
    instances_after = client.get("/horizon/api/integrations/instances").json()
    final_count = len(instances_after)
    assert final_count < initial_count
    instance_changes = [a.change for a in teardown if a.type == "IntegrationInstanceResource"]
    props_changes = [a.change for a in teardown if a.type == "OptionalPropsResource"]
    assert instance_changes == ["remove"] * 2
    assert props_changes == ["remove"]


def test_optional_props_configuration(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    instances = client.get("/horizon/api/integrations/instances").json()
    aladdin = next(
        (i for i in instances if i["name"] == f"test_aladdin-{setup_deployment.name}"), None
    )
    assert aladdin is not None
    instance_id = aladdin["id"]
    config = client.get(
        f"/horizon/api/integrations/instances/configuration/blackrock-aladdin/{instance_id}"
    ).json()
    assert "Portfolio/LUSID-BlackRock-Aladdin/FUND" in config


def test_integration_instance_with_triggers(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    instances = client.get("/horizon/api/integrations/instances").json()
    test_instance = next(
        (i for i in instances if i["name"] == f"test-integration-{setup_deployment.name}"), None
    )
    assert test_instance is not None
    assert len(test_instance["triggers"]) > 0
    trigger = test_instance["triggers"][0]
    assert trigger["type"] == "time"
    assert trigger["cronExpression"] == "0 0 9 ? * MON-FRI"
    assert trigger["timeZone"] == "Europe/London"


def test_integration_instance_details(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    instances = client.get("/horizon/api/integrations/instances").json()
    test_instance = next(
        (i for i in instances if i["name"] == f"test-integration-{setup_deployment.name}"), None
    )
    assert test_instance is not None
    details = test_instance["details"]
    assert "paymentSystemsCalendar" in details
    calendar_config = details["paymentSystemsCalendar"]
    assert "GBP" in calendar_config["currencyFilter"]
    assert "USD" in calendar_config["currencyFilter"]
    assert calendar_config["importUnqualified"] is False


def test_update_nochanges(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    instances_first = client.get("/horizon/api/integrations/instances").json()
    first_count = len(instances_first)
    update = fbnconfig.deploy(full_deployment, lusid_env, token)
    instances_second = client.get("/horizon/api/integrations/instances").json()
    second_count = len(instances_second)
    assert first_count == second_count
    instance_changes = [a.change for a in update if a.type == "IntegrationInstanceResource"]
    props_changes = [a.change for a in update if a.type == "OptionalPropsResource"]
    assert instance_changes == ["nochange"] * 2
    assert props_changes == ["nochange"]


@pytest.mark.asyncio
async def test_integration_instance_list(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    deployment_name = setup_deployment.name
    async_client = fbnconfig.create_client(lusid_env, token, is_async=True)
    result = await horizon.IntegrationInstanceResource.list(
        client=async_client, query_params={}
    )
    instance_name = f"test-integration-{deployment_name}"
    instance = next(
        (i for i in result["values"] if i["value"]["name"] == instance_name)
    )
    instance_id = instance["keys"]["instanceId"]
    expected_instance = {
        "keys": {"instanceId": instance_id},
        "value": {
            "id": f"integration-instance_{instance_id}".lower(),
            "instanceId": instance_id,
            "name": instance_name,
            "integrationType": "copp-clark",
            "description": "Test integration instance for horizon tests",
            "enabled": True,
            "details": {
                "paymentSystemsCalendar": {
                    "currencyFilter": ["GBP", "USD"],
                    "importUnqualified": False
                }
            },
            "triggers": [
                {
                    "type": "time",
                    "cronExpression": "0 0 9 ? * MON-FRI",
                    "timeZone": "Europe/London"
                }
            ]
        }
    }
    assert instance == expected_instance


@pytest.mark.asyncio
async def test_integration_instance_fetch(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    deployment_name = setup_deployment.name
    async_client = fbnconfig.create_client(lusid_env, token, is_async=True)
    instances_response = await async_client.get("/horizon/api/integrations/instances")
    instances = instances_response.json()
    instance_name = f"test-integration-{deployment_name}"
    instance = next((i for i in instances if i["name"] == instance_name))
    instance_id = instance["id"]
    response = await horizon.IntegrationInstanceResource.fetch(
        client=async_client, keys={"instanceId": instance_id}
    )
    expected_response = {
        "id": f"integration-instance_{instance_id}".lower(),
        "instanceId": instance_id,
        "name": instance_name,
        "integrationType": "copp-clark",
        "description": "Test integration instance for horizon tests",
        "enabled": True,
        "details": {
            "paymentSystemsCalendar": {
                "currencyFilter": ["GBP", "USD"],
                "importUnqualified": False
            }
        },
        "triggers": [
            {
                "type": "time",
                "cronExpression": "0 0 9 ? * MON-FRI",
                "timeZone": "Europe/London"
            }
        ]
    }
    assert response == expected_response


@pytest.mark.asyncio
async def test_optional_props_fetch(setup_deployment, full_deployment):
    fbnconfig.deploy(full_deployment, lusid_env, token)
    deployment_name = setup_deployment.name
    async_client = fbnconfig.create_client(lusid_env, token, is_async=True)
    instances_response = await async_client.get("/horizon/api/integrations/instances")
    instances = instances_response.json()
    aladdin_name = f"test_aladdin-{deployment_name}"
    aladdin = next((i for i in instances if i["name"] == aladdin_name))
    instance_id = aladdin["id"]
    response = await horizon.OptionalPropsResource.fetch(
        client=async_client,
        keys={
            "instanceId": instance_id,
            "instanceIntegrationType": "blackrock-aladdin",
        }
    )
    assert response == {
        "id": f"integration-instance-optional-props_blackrock-aladdin_{instance_id}".lower(),
        "instance": {
            "$ref": f"integration-instance_{instance_id}".lower(),
            "metadata": {
                "keys": {"instanceId": instance_id},
                "resource": "IntegrationInstanceResource",
            },
        },
        "props": [
            {
                "property": "Portfolio/LUSID-BlackRock-Aladdin/FUND",
                "displayNameOverride": "Aladdin Fund Code",
                "descriptionOverride": "The BlackRock Aladdin fund identifier",
                "entityType": None,
                "entitySubType": None,
                "vendorPackage": None,
            }
        ],
    }
