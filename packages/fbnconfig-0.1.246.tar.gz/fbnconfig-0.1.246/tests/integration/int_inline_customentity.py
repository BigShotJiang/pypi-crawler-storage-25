import os
import time
from types import SimpleNamespace

from pytest import fixture

import fbnconfig
from fbnconfig import customentity, datatype, lumi
from fbnconfig import property as prop
from fbnconfig.inline_customentity import CustomEntityInlineResource
from fbnconfig.properties import MetricValue, PropertyValue
from tests.integration.generate_test_name import gen


@fixture(scope="module")
def lusid_env():
    if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
        raise RuntimeError(
            "FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set"
        )
    return SimpleNamespace(
        env=os.environ["LUSID_ENV"],
        token=os.environ["FBN_ACCESS_TOKEN"],
    )


@fixture(scope="module")
def client(lusid_env):
    return fbnconfig.create_client(lusid_env.env, lusid_env.token)


def put_query(client, sql):
    res = client.put(
        "/honeycomb/api/Sql/json",
        content=sql,
        params={"jsonProper": True},
        headers={"Content-type": "text/plain"},
    )
    return res.json()


def wait_for_it(client, sql, expected_rows, tries=10, sleep_secs=10):
    last_error = None
    while True:
        try:
            r = put_query(client, sql)
            last_error = None
        except Exception as e:
            r = None
            last_error = e
        if r is not None and len(r) == expected_rows:
            return r
        tries -= 1
        if tries == 0:
            if last_error:
                raise last_error
            assert r is not None and len(r) == expected_rows, (
                f"Expected {expected_rows} rows, got {len(r) if r else 'error'}"
            )
        time.sleep(sleep_secs)


def get_provider_fields(client, provider_name, tries=10, sleep_secs=10):
    sql = f"select FieldName from Sys.Field where TableName = '{provider_name}'"
    while tries > 0:
        try:
            result = put_query(client, sql)
            if result:
                return {row["FieldName"] for row in result}
        except Exception:
            pass
        tries -= 1
        time.sleep(sleep_secs)
    return set()


@fixture(scope="module")
def unique_name():
    name = gen("ceinline")
    print(f"\nRunning for deployment {name}...")
    return name


@fixture(scope="module")
def entity_type(unique_name):
    return customentity.EntityTypeResource(
        id="test-ce-type",
        entity_type_name=unique_name,
        display_name="Test Entity",
        description="A test custom entity",
        field_schema=[
            customentity.FieldDefinition(
                name="Status",
                lifetime=customentity.LifeTime.PERPETUAL,
                type=customentity.FieldType.STRING,
                required=False,
            ),
        ],
    )


@fixture(scope="module")
def string_type():
    return datatype.DataTypeRef(id="systemstring", scope="system", code="string")


@fixture(scope="module")
def ccy_type():
    return datatype.DataTypeRef(id="systemccy", scope="system", code="currencyAndAmount")


@fixture(scope="module")
def identifier_prop(unique_name, string_type):
    return prop.DefinitionResource(
        id="test-ce-identifier",
        domain=prop.Domain.CustomEntity,
        scope=unique_name,
        code="ExternalId",
        display_name="External ID",
        data_type_id=string_type,
        life_time=prop.LifeTime.Perpetual,
        constraint_style=prop.ConstraintStyle.Identifier,
    )


@fixture(scope="module")
def price_prop(unique_name, ccy_type):
    return prop.DefinitionResource(
        id="test-ce-price",
        domain=prop.Domain.CustomEntity,
        scope=unique_name,
        code="Price",
        display_name="Price",
        data_type_id=ccy_type,
        life_time=prop.LifeTime.Perpetual,
    )


@fixture(scope="module")
def ce_inline(entity_type, identifier_prop, price_prop):
    return CustomEntityInlineResource(
        id="test-ce-inline",
        custom_entity_type=entity_type,
        properties=[
            lumi.InlineProperty(
                key=identifier_prop,
                name="External ID",
                description="External identifier",
            ),
            lumi.InlineProperty(
                key=price_prop,
                field="Value",
                name="Price Amount",
                data_type=lumi.InlineDataType.Decimal,
                description="The price amount",
            ),
            lumi.InlineProperty(
                key=price_prop,
                field="Unit",
                name="Price Currency",
                data_type=lumi.InlineDataType.Text,
                description="The price currency",
            ),
        ],
    )


@fixture(scope="module")
def entity_instance(entity_type, identifier_prop, price_prop):
    return customentity.EntityResource(
        id="test-ce-instance",
        entity_type=entity_type,
        display_name="Test Widget",
        description="A test entity instance",
        identifiers=[
            customentity.EntityIdentifier(
                identifier_type=identifier_prop,
                identifier_value="WIDGET-001",
            ),
        ],
        fields=[
            customentity.EntityField(name="Status", value="Active"),
        ],
        properties=[
            PropertyValue(
                property_key=price_prop,
                metric_value=MetricValue(value=99.95, unit="GBP"),
            ),
        ],
    )


@fixture(scope="module")
def deployment(
    unique_name, entity_type, identifier_prop, price_prop,
    ce_inline, entity_instance, lusid_env,
):
    dep = fbnconfig.Deployment(
        unique_name, [entity_type, identifier_prop, price_prop, ce_inline, entity_instance]
    )
    yield dep
    print("\nTearing down deployment...")
    fbnconfig.deployex(fbnconfig.Deployment(unique_name, []), lusid_env.env, lusid_env.token)


def test_create(deployment, lusid_env):
    # given the deployment is created
    result = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    changes = {a.type: a.change for a in result}
    # then the CE inline is created
    assert changes["CustomEntityInlineResource"] == "create"
    assert changes["EntityResource"] == "create"


def test_nochange(deployment, unique_name, client, lusid_env):
    # given the deployment already exists
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # wait for the inline CSV to be readable in Sys.File
    path = f"{unique_name}customentityproviderfactory.csv"
    wait_for_it(client, f"select Content from Sys.File where Path = 'config/lusid/factories/{path}'", 1)
    # when we deploy again
    result = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    changes = {a.type: a.change for a in result}
    # then no changes
    assert changes["CustomEntityInlineResource"] == "nochange"


def test_query_view(deployment, unique_name, client, lusid_env):
    # given the deployment exists
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # when we query the CE view
    sql = (
        f"select DisplayName, Status, [External ID], [Price Amount], [Price Currency] "
        f"from [Lusid.CustomEntity.{unique_name}]"
    )
    rows = wait_for_it(client, sql, 1)
    # then the entity instance data comes back through the inlined columns
    row = rows[0]
    assert row["DisplayName"] == "Test Widget"
    assert row["Status"] == "Active"
    assert row["Price Amount"] == 99.95
    assert row["Price Currency"] == "GBP"


def test_reconfigures_when_entity_type_fields_change(
    deployment, unique_name, entity_type, client, lusid_env
):
    provider_name = f"Lusid.CustomEntity.{unique_name}"
    # given the deployment exists
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # and the provider has Status (entity field)
    fields_before = get_provider_fields(client, provider_name)
    assert "Status" in fields_before
    assert "FieldB" not in fields_before
    # when a new field is added to the entity type
    original_field_schema = list(entity_type.field_schema)
    entity_type.field_schema = [
        *original_field_schema,
        customentity.FieldDefinition(
            name="FieldB",
            lifetime=customentity.LifeTime.PERPETUAL,
            type=customentity.FieldType.STRING,
            required=False,
        ),
    ]
    result = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    changes = {a.type: a.change for a in result}
    # then the entity type is updated
    assert changes["EntityTypeResource"] == "update"
    # and the inline is reconfigured (not nochange)
    assert changes["CustomEntityInlineResource"] == "update"
    # and FieldB now appears in the provider
    fields_after = get_provider_fields(client, provider_name)
    assert "FieldB" in fields_after
    # restore original field schema for subsequent tests
    entity_type.field_schema = original_field_schema


def test_update_description(deployment, lusid_env, ce_inline):
    # given the deployment exists
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # when we change a property description
    ce_inline.properties[0].description = "Updated identifier description"
    result = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    changes = {a.type: a.change for a in result}
    # then the inline is updated
    assert changes["CustomEntityInlineResource"] == "update"
