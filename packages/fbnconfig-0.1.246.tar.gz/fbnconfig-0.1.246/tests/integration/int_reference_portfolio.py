import datetime as dt
import os
from types import SimpleNamespace

from pytest import fixture

import fbnconfig
from fbnconfig import reference_portfolio as rp
from tests.integration.generate_test_name import gen


@fixture(scope="module")
def lusid_env():
    if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
        raise (
            RuntimeError("Both FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set")
        )
    lusid_env = os.environ["LUSID_ENV"]
    token = os.environ["FBN_ACCESS_TOKEN"]
    return SimpleNamespace(env=lusid_env, token=token)


@fixture(scope="module")
def client(lusid_env):
    return fbnconfig.create_client(lusid_env.env, lusid_env.token)


@fixture()
def deployment_name():
    return gen("refpf")


@fixture()
def setup_deployment(deployment_name, lusid_env):
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    try:
        fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env.env, lusid_env.token)
    except Exception as r:
        print("Exceptions during teardown of the test data", r)
        pass


@fixture()
def base_resources(setup_deployment):
    scope = setup_deployment.name
    start_date = dt.date(2024, 1, 5)
    ref_portfolio = rp.ReferencePortfolioResource(
        id="ref_portfolio",
        scope=scope,
        code="int_refpf",
        display_name="Integration Test Reference Portfolio",
        description="Reference portfolio for integration testing",
        base_currency="USD",
        created=start_date,
        instrument_scopes=[scope],
    )
    constituents = rp.ReferencePortfolioConstituentsResource(
        id="constituents",
        portfolio=ref_portfolio,
        effective_from=start_date,
        weight_type="Static",
        constituents=[
            rp.Constituent(
                instrument_identifiers={"Instrument/default/Currency": "USD"},
                weight=0.6,
                currency="USD",
            ),
            rp.Constituent(
                instrument_identifiers={"Instrument/default/Currency": "GBP"},
                weight=0.4,
                currency="GBP",
            ),
        ],
    )
    return {"ref_portfolio": ref_portfolio, "constituents": constituents}


def test_create(client, setup_deployment, base_resources, lusid_env):
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    scope = setup_deployment.name
    # verify portfolio exists
    remote = client.get(f"/api/api/portfolios/{scope}/int_refpf").json()
    assert remote["displayName"] == "Integration Test Reference Portfolio"
    # verify constituents exist
    remote_c = client.get(
        f"/api/api/referenceportfolios/{scope}/int_refpf/constituents"
    ).json()
    assert len(remote_c["constituents"]) == 2


def test_update_display_name(client, setup_deployment, base_resources, lusid_env):
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    base_resources["ref_portfolio"].display_name = "Renamed Reference Portfolio"
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    updates = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    pf_changes = [u for u in updates if u.type == "ReferencePortfolioResource"]
    assert pf_changes[0].change == "update"
    scope = setup_deployment.name
    remote = client.get(f"/api/api/portfolios/{scope}/int_refpf").json()
    assert remote["displayName"] == "Renamed Reference Portfolio"


def test_update_constituents(client, setup_deployment, base_resources, lusid_env):
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # change weights
    base_resources["constituents"].constituents = [
        rp.Constituent(
            instrument_identifiers={"Instrument/default/Currency": "USD"},
            weight=0.8,
            currency="USD",
        ),
        rp.Constituent(
            instrument_identifiers={"Instrument/default/Currency": "GBP"},
            weight=0.2,
            currency="GBP",
        ),
    ]
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    updates = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    c_changes = [u for u in updates if u.type == "ReferencePortfolioConstituentsResource"]
    assert c_changes[0].change == "update"


def test_nochange(setup_deployment, base_resources, lusid_env):
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    updates = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    assert all(u.change == "nochange" for u in updates)


def test_constituents_replace_not_upsert(client, setup_deployment, base_resources, lusid_env):
    """Confirm that POSTing constituents replaces the full set, not appending."""
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    scope = setup_deployment.name
    # verify 2 constituents exist
    remote = client.get(f"/api/api/referenceportfolios/{scope}/int_refpf/constituents").json()
    assert len(remote["constituents"]) == 2
    # replace with a single constituent
    base_resources["constituents"].constituents = [
        rp.Constituent(
            instrument_identifiers={"Instrument/default/Currency": "EUR"},
            weight=1.0,
            currency="EUR",
        ),
    ]
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # verify only 1 constituent — not 3 (which would mean upsert/append)
    remote = client.get(f"/api/api/referenceportfolios/{scope}/int_refpf/constituents").json()
    assert len(remote["constituents"]) == 1
    assert remote["constituents"][0]["weight"] == 1.0


def test_delete_clears_constituents(client, setup_deployment, base_resources, lusid_env):
    """Confirm that removing the constituents resource clears them on the portfolio."""
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    scope = setup_deployment.name
    # remove constituents resource, keep portfolio
    resources = {"ref_portfolio": base_resources["ref_portfolio"]}
    deployment = fbnconfig.Deployment(setup_deployment.name, list(resources.values()))
    updates = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    c_changes = [u for u in updates if u.type == "ReferencePortfolioConstituentsResource"]
    assert c_changes[0].change == "remove"
    # verify constituents are empty
    remote = client.get(f"/api/api/referenceportfolios/{scope}/int_refpf/constituents").json()
    assert len(remote["constituents"]) == 0


def test_teardown(setup_deployment, base_resources, lusid_env):
    deployment = fbnconfig.Deployment(setup_deployment.name, base_resources.values())
    fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    # remove everything
    deployment = fbnconfig.Deployment(setup_deployment.name, [])
    updates = fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)
    assert all(u.change == "remove" for u in updates)
