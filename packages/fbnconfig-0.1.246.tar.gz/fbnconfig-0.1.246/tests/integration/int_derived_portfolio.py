import datetime as dt
import os
from types import SimpleNamespace

from pytest import fixture

import fbnconfig
from fbnconfig import portfolio
from tests.integration.generate_test_name import gen


@fixture(scope="module")
def lusid_env():
    if os.getenv("FBN_ACCESS_TOKEN") is None or os.getenv("LUSID_ENV") is None:
        raise (
            RuntimeError("Both FBN_ACCESS_TOKEN and LUSID_ENV variables need to be set")
        )
    lusid_env = os.environ["LUSID_ENV"]
    token = os.environ["FBN_ACCESS_TOKEN"]
    return SimpleNamespace(env=lusid_env, token=token)


@fixture(scope="module")
def client(lusid_env):
    return fbnconfig.create_client(lusid_env.env, lusid_env.token)


@fixture()
def deployment_name():
    return gen("derived_pf")


@fixture()
def setup_deployment(deployment_name, lusid_env):
    print(f"\nRunning for deployment {deployment_name}...")
    yield SimpleNamespace(name=deployment_name)
    try:
        fbnconfig.deployex(fbnconfig.Deployment(deployment_name, []), lusid_env.env, lusid_env.token)
    except Exception as r:
        print("Exceptions during teardown of the test data", r)
        pass


@fixture()
def base_resources(setup_deployment):
    scope = setup_deployment.name
    start_date = dt.date(2024, 1, 5)
    parent = portfolio.PortfolioResource(
        id="parent_pf", scope=scope, code="parent_pf",
        display_name="Parent Portfolio", description="Parent for derived tests",
        base_currency="USD", created=start_date, instrument_scopes=[scope],
    )
    derived = portfolio.DerivedTransactionPortfolioResource(
        id="derived_pf", scope=scope, code="derived_pf",
        display_name="Derived Portfolio", description="Derived from parent",
        parent_portfolio_id=parent,
        created=start_date, instrument_scopes=[scope],
    )
    return {"parent": parent, "derived": derived}


def _deploy(name, resources, lusid_env):
    deployment = fbnconfig.Deployment(name, resources)
    return fbnconfig.deployex(deployment, lusid_env.env, lusid_env.token)


class DescribeDerivedTransactionPortfolioResource:
    def test_create(self, client, setup_deployment, base_resources, lusid_env):
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfolios/{scope}/derived_pf").json()
        assert remote["displayName"] == "Derived Portfolio"
        assert remote["type"] == "DerivedTransaction"
        assert remote["isDerived"] is True
        assert remote["parentPortfolioId"]["code"] == "parent_pf"

    def test_update_display_name(self, client, setup_deployment, base_resources, lusid_env):
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        base_resources["derived"].display_name = "Updated Derived"
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        derived_changes = [u for u in updates if u.id == "derived_pf"]
        assert derived_changes[0].change == "update"
        scope = setup_deployment.name
        remote = client.get(f"/api/api/portfolios/{scope}/derived_pf").json()
        assert remote["displayName"] == "Updated Derived"

    def test_update_accounting_method(self, client, setup_deployment, base_resources, lusid_env):
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        base_resources["derived"].accounting_method = "AverageCost"
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        derived_changes = [u for u in updates if u.id == "derived_pf"]
        assert derived_changes[0].change == "update"
        scope = setup_deployment.name
        details = client.get(
            f"/api/api/transactionportfolios/{scope}/derived_pf/details"
        ).json()
        assert details["accountingMethod"] == "AverageCost"

    def test_nochange(self, setup_deployment, base_resources, lusid_env):
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        updates = _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        derived_changes = [u for u in updates if u.id == "derived_pf"]
        assert derived_changes[0].change == "nochange"

    def test_teardown(self, setup_deployment, base_resources, lusid_env):
        _deploy(setup_deployment.name, base_resources.values(), lusid_env)
        updates = _deploy(setup_deployment.name, [], lusid_env)
        derived_changes = [u for u in updates if u.id == "derived_pf"]
        assert derived_changes[0].change == "remove"
