merge:
  - template: resources/merge-request-core.tpl
  - template: resources/fbnconfig-semver.tpl

jobs:
  - name: merge-request
    plan:
    - get: source-code-fbnconfig
      resource: merge-request-core
      version: every
      trigger: true
    - get: fbnconfig-version
      params:
        bump: patch
    - put: merge-request-core
      params:
        repository: source-code-fbnconfig
        status: running
    - task: unit-tests
      timeout: 5m
      config:
        platform: linux
        image_resource:
            type: docker-image
            source:
              repository: harbor.finbourne.com/build/python-build-3-11
              username: ((harbor.tools_token_username))
              password: ((harbor.tools_token))
        inputs:
            - name: source-code-fbnconfig
        outputs:
            - name: source-code-fbnconfig
        run:
          dir: source-code-fbnconfig
          path: bash
          args:
          - -ce
          - -u
          - -o
          - pipefail
          - |
            export PYRIGHT_PYTHON_NODE_VERSION="24.10.0"
            uv sync
            uv run pytest --cov-branch --cov=fbnconfig --cov-report=xml --tb=no --cov-report=term tests/unit -n auto
            # check for schema drift in the MR build
            uv run pytest tests/integration/int_schemagen.py

            uv run pyright
            uv run ruff check

    {{ include "sonar.tpl" | indentSub 4 }}
    - task: affected-integration-tests
      timeout: 20m
      config:
        platform: linux
        image_resource:
          type: docker-image
          source:
            repository: harbor.finbourne.com/tools/fbn-task-runner
            tag: v1latest
            username: ((harbor.tools_token_username))
            password: ((harbor.tools_token))
        inputs:
          - name: source-code-fbnconfig
        params:
          LUSID_ENV: "https://fbn-qa.lusid.com"
          FBN_ACCESS_TOKEN: ((config-dsl.pat))
          HARBOR_USERNAME: ((harbor.tools_token_username))
          HARBOR_PASSWORD: ((harbor.tools_token))
        run:
          path: fbn-task-runner
          args:
            - --working-dir=source-code-fbnconfig
            - --team=client-engineering
            - --pipeline=fbnconfig
            - --job=merge-request
            - --script=./source-code-fbnconfig/ci/pipeline/scripts/run-affected-tests.sh
            - --image=harbor.finbourne.com/build/python-build-3-11-dind:0.0.2
            - --cpu=1000m
            - --memory=3Gi
            - --timeout-seconds=1200
            - --privileged
    on_failure:
        put: merge-request-core
        params:
          repository: source-code-fbnconfig
          status: failed
    on_success:
        put: merge-request-core
        params:
            repository: source-code-fbnconfig
            status: success
