"""MCP tool definitions."""
