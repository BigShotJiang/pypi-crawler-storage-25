"""Structured audit logging for all MCP tool invocations."""

from __future__ import annotations

import asyncio
import logging
import os
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, model_serializer

_logger = logging.getLogger(__name__)

_SENSITIVE_PATTERNS = frozenset(
    {
        "token",
        "password",
        "secret",
        "api_key",
        "authorization",
        "access_token",
        "refresh_token",
        "credential",
        "private_key",
        "bearer",
        "session_id",
    }
)


def _is_sensitive_key(key: str) -> bool:
    """Check if a key name matches any sensitive pattern."""
    lower = key.lower()
    return any(p in lower for p in _SENSITIVE_PATTERNS)


def _redact_sensitive(data: dict[str, object]) -> dict[str, object]:
    """Remove sensitive keys from a dictionary, recursively including lists."""
    result: dict[str, object] = {}
    for k, v in data.items():
        if _is_sensitive_key(k):
            continue
        if isinstance(v, dict):
            result[k] = _redact_sensitive(v)
        elif isinstance(v, list):
            result[k] = [_redact_sensitive(item) if isinstance(item, dict) else item for item in v]
        else:
            result[k] = v
    return result


class AuditRecord(BaseModel):
    timestamp: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())
    tool: str
    action: str
    prompt_id: str = ""
    nodes_used: list[str] = []
    warnings: list[str] = []
    duration_ms: int = 0
    status: str = ""
    extra: dict[str, object] = {}

    @model_serializer
    def serialize(self) -> dict[str, object]:
        data: dict[str, object] = {
            "timestamp": self.timestamp,
            "tool": self.tool,
            "action": self.action,
        }
        if self.prompt_id:
            data["prompt_id"] = self.prompt_id
        if self.nodes_used:
            data["nodes_used"] = self.nodes_used
        if self.warnings:
            data["warnings"] = self.warnings
        if self.duration_ms:
            data["duration_ms"] = self.duration_ms
        if self.status:
            data["status"] = self.status
        if self.extra:
            data["extra"] = _redact_sensitive(self.extra)
        return data


class AuditLogger:
    def __init__(self, audit_file: Path) -> None:
        self._audit_file = Path(audit_file)
        self._dir_created = False
        self._lock = threading.Lock()

    def _is_path_safe(self) -> bool:
        """Check that neither the audit file nor any parent is a symlink.

        Uses is_symlink() which detects both live and dangling symlinks
        (unlike exists() which returns False for dangling symlinks).
        """
        if self._audit_file.is_symlink():
            return False
        return all(not parent.is_symlink() for parent in self._audit_file.parents)

    def _ensure_dir(self) -> bool:
        """Create parent directories once. Returns False on failure."""
        if self._dir_created:
            return True
        try:
            self._audit_file.parent.mkdir(parents=True, exist_ok=True)
            self._dir_created = True
            return True
        except OSError as e:
            _logger.error("AUDIT LOG FAILURE: cannot create directory: %s", e)
            return False

    def _write_record(self, record: AuditRecord) -> None:
        """Synchronous, thread-safe write of a single audit record."""
        with self._lock:
            # Check symlink safety on every write (not cached) to detect
            # post-init symlink swaps on the file or any parent directory
            if not self._is_path_safe():
                _logger.error(
                    "AUDIT LOG REFUSED: path contains symlink: %s",
                    self._audit_file,
                )
                return
            if not self._ensure_dir():
                return
            try:
                flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT
                flags |= getattr(os, "O_NOFOLLOW", 0)
                fd = os.open(str(self._audit_file), flags, 0o600)
                try:
                    data = (record.model_dump_json() + "\n").encode()
                    view = memoryview(data)
                    while view:
                        written = os.write(fd, view)
                        if written <= 0:
                            raise OSError("Failed to write audit log record")
                        view = view[written:]
                finally:
                    os.close(fd)
            except OSError as e:
                _logger.error("AUDIT LOG FAILURE: %s", e)

    def log(self, *, tool: str, action: str, **kwargs: Any) -> AuditRecord:
        """Write an audit record as a JSON line (synchronous)."""
        record = AuditRecord(tool=tool, action=action, **kwargs)
        self._write_record(record)
        return record

    async def async_log(self, *, tool: str, action: str, **kwargs: Any) -> AuditRecord:
        """Write an audit record without blocking the event loop."""
        record = AuditRecord(tool=tool, action=action, **kwargs)
        await asyncio.to_thread(self._write_record, record)
        return record
