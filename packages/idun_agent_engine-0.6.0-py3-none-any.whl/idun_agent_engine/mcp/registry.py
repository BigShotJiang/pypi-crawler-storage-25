"""Registry for MCP server clients."""

from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING, Any, cast

from idun_agent_schema.engine.mcp_server import MCPServer
from langchain_core.tools import StructuredTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.sessions import Connection

if TYPE_CHECKING:
    from google.adk.tools import McpToolset
    from google.adk.tools.mcp_tool.mcp_session_manager import (
        SseConnectionParams,
        StdioConnectionParams,
        StreamableHTTPConnectionParams,
    )
    from mcp import StdioServerParameters

try:
    from google.adk.tools import McpToolset
    from google.adk.tools.mcp_tool.mcp_session_manager import (
        SseConnectionParams,
        StdioConnectionParams,
        StreamableHTTPConnectionParams,
    )
    from mcp import StdioServerParameters
except ImportError:
    McpToolset = None  # type: ignore
    StdioConnectionParams = None  # type: ignore
    StdioServerParameters = None  # type: ignore
    SseConnectionParams = None  # type: ignore
    StreamableHTTPConnectionParams = None  # type: ignore


class _DeepcopySafeStderr:
    """Stderr proxy that survives ``copy.deepcopy`` / ``model_copy(deep=True)``.

    Google ADK ``McpToolset`` stores an ``errlog`` attribute that defaults to
    ``sys.stderr`` (a ``TextIOWrapper``).  ``TextIOWrapper`` cannot be pickled
    or deep-copied, which causes ``ag_ui_adk`` to crash when it deep-copies
    the ADK agent.

    This thin wrapper delegates writes to the *current* ``sys.stderr`` at call
    time (so it follows any runtime reassignment) and simply returns ``self``
    on ``__deepcopy__`` — there is no mutable state to duplicate.
    """

    def write(self, s: str) -> int:
        return sys.stderr.write(s)

    def flush(self) -> None:
        sys.stderr.flush()

    def writable(self) -> bool:
        return True

    def fileno(self) -> int:
        return sys.stderr.fileno()

    def __deepcopy__(self, memo: dict[int, Any]) -> _DeepcopySafeStderr:
        return self


logger = logging.getLogger(__name__)


def _sanitize_schema(schema: Any) -> None:
    """Recursively patch array nodes missing ``items`` in JSON Schema.

    Some MCP servers omit ``items`` on array properties. Most LLM providers
    reject these with a 400 error, so we default to ``{"type": "string"}``.
    """
    if isinstance(schema, dict):
        if schema.get("type") == "array" and "items" not in schema:
            schema["items"] = {"type": "string"}
            logger.warning(
                "MCP tool schema had array without 'items', defaulted to string: %s",
                schema,
            )
        for value in schema.values():
            _sanitize_schema(value)
    elif isinstance(schema, list):
        for item in schema:
            _sanitize_schema(item)


def _serialization_safe_shim(mcp_tool: Any) -> StructuredTool:
    """Wrap an MCP-resolved LangChain tool so AG-UI can serialize it.

    Failure this fixes: ``langchain-mcp-adapters`` exposes each MCP tool
    as a ``StructuredTool`` whose coroutine accepts a ``runtime`` kwarg
    LangGraph injects with the live ``Runtime`` object. Inside that
    coroutine the tool builds an ``MCPToolCallRequest`` dataclass that
    captures the runtime. The AG-UI LangGraph adapter's
    ``make_json_safe`` then recursively ``dataclasses.asdict()``s every
    emitted event payload, which deep-copies the request — and
    transitively the runtime, which holds ``_GatheringFuture`` /
    ``TaskStepMethWrapper`` instances that are not picklable. Result:
    every LG MCP run aborts with ``cannot pickle '_GatheringFuture'``
    immediately after ``TOOL_CALL_END``.

    The shim's coroutine takes only ``**kwargs`` (no ``runtime``
    parameter). LangGraph's ToolNode doesn't pass ``runtime`` into a
    coroutine that doesn't declare it, so the runtime never lands in
    a closure or dataclass that AG-UI's recursion will visit. The
    shim forwards via ``await underlying.ainvoke(kwargs)`` — the
    underlying tool keeps its full request/runtime machinery, but it
    is held in a frame the AG-UI adapter never serializes.

    The wrapper returns plain ``str`` (or a flattened text join for
    list-of-content-block returns) instead of the underlying tool's
    ``content_and_artifact`` tuple. The artifact is dropped by design
    — agents calling MCP tools through AG-UI receive the visible text
    content, which is the format the LangGraph chat model already
    consumes via ``ToolNode``. Restoring ``MCPToolArtifact`` would
    re-introduce the serialization surface this shim is here to
    remove.
    """

    async def _forward(**kwargs: Any) -> str:
        result = await mcp_tool.ainvoke(kwargs)
        if isinstance(result, str):
            return result
        if isinstance(result, list):
            parts: list[str] = []
            for item in result:
                if isinstance(item, dict) and item.get("type") == "text":
                    parts.append(str(item.get("text", "")))
                else:
                    parts.append(str(item))
            return "\n".join(parts)
        return str(result)

    return StructuredTool(
        name=mcp_tool.name,
        description=mcp_tool.description or "",
        args_schema=mcp_tool.args_schema,
        coroutine=_forward,
    )


_active_registry: MCPClientRegistry | None = None


def set_active_registry(registry: MCPClientRegistry | None) -> None:
    """Set the process-wide active MCP registry.

    Called by the engine lifespan on startup so that helper functions
    (get_langchain_tools, get_adk_tools) can resolve tools from memory
    instead of re-fetching from the manager API.
    """
    global _active_registry
    _active_registry = registry


def get_active_registry() -> MCPClientRegistry | None:
    """Return the active MCP registry, or None if not set."""
    return _active_registry


class MCPClientRegistry:
    """Wraps `MultiServerMCPClient` with convenience helpers.

    Per-server failure isolation (D6): if one server fails to convert to
    a connection dict, the surviving servers continue to load. The
    registry exposes a ``failed`` list so embedders can surface per-server
    failure status (e.g. a red badge in the standalone admin UI).
    """

    def __init__(self, configs: list[MCPServer] | None = None) -> None:
        self._configs = configs or []
        self._client: MultiServerMCPClient | None = None
        # ``failed`` carries one entry per server whose init was skipped,
        # in the same order as ``configs``. Embedders join on ``name``.
        self._failed: list[dict[str, str]] = []

        if self._configs:
            connections: dict[str, Connection] = {}
            for config in self._configs:
                try:
                    connections[config.name] = cast(
                        Connection, config.as_connection_dict()
                    )
                except Exception as exc:
                    logger.warning(
                        "⚠️ MCP server '%s' (%s) failed to initialize: %s — "
                        "skipping; surviving servers continue to load.",
                        config.name,
                        config.transport,
                        exc,
                    )
                    self._failed.append(
                        {
                            "name": config.name,
                            "kind": str(config.transport),
                            "reason": str(exc) or repr(exc),
                        }
                    )

            if connections:
                try:
                    self._client = MultiServerMCPClient(connections)
                except Exception as exc:
                    logger.warning(
                        "⚠️ Failed to create MultiServerMCPClient (%s): %s — "
                        "marking every remaining server as failed and "
                        "continuing without MCP support.",
                        type(exc).__name__,
                        exc,
                    )
                    # Surface every server still in ``connections`` as a
                    # failure so the UI doesn't claim they are running.
                    for config in self._configs:
                        if config.name in connections and not any(
                            f["name"] == config.name for f in self._failed
                        ):
                            self._failed.append(
                                {
                                    "name": config.name,
                                    "kind": str(config.transport),
                                    "reason": f"client construction failed: {exc}",
                                }
                            )

    @property
    def failed(self) -> list[dict[str, str]]:
        """Return per-server failure records (read-only snapshot).

        Each entry is ``{"name": ..., "kind": <transport>, "reason": ...}``.
        Empty when every configured server initialised successfully.
        """
        return list(self._failed)

    @property
    def enabled(self) -> bool:
        """Return True if at least one MCP server is configured."""
        return self._client is not None

    @property
    def client(self) -> MultiServerMCPClient:
        """Return the underlying MultiServerMCPClient."""
        if not self._client:
            raise RuntimeError("No MCP servers configured.")
        return self._client

    def available_servers(self) -> list[str]:
        """Return the list of configured MCP server names."""
        if not self._client:
            return []
        return list(self._client.connections.keys())

    def _ensure_server(self, name: str) -> None:
        if not self._client:
            raise RuntimeError("MCP client registry is not enabled.")
        if name not in self._client.connections:
            available = ", ".join(self._client.connections.keys()) or "none"
            raise ValueError(
                f"MCP server '{name}' is not configured. Available: {available}"
            )

    def get_client(self, name: str | None = None) -> MultiServerMCPClient:
        """Return the MCP client, optionally ensuring a named server exists."""
        if name:
            self._ensure_server(name)
        return self.client

    def get_session(self, name: str):
        """Return an async context manager for the given server session."""
        self._ensure_server(name)
        return self.client.session(name)

    async def get_tools(self, name: str | None = None) -> list[Any]:
        """Load tools from all servers or a specific one.

        When loading from all servers, each server is tried individually
        so a single broken server does not prevent the others from loading.

        Each tool is wrapped via ``_serialization_safe_shim`` so the
        LangGraph runtime reference can't reach AG-UI's
        ``make_json_safe`` recursive ``dataclasses.asdict``. See that
        helper's docstring for the full failure mode.
        """
        if not self._client:
            raise RuntimeError("MCP client registry is not enabled.")

        if name:
            tools = await self._client.get_tools(server_name=name)
        else:
            tools = []
            for server_name in self._client.connections:
                try:
                    server_tools = await self._client.get_tools(server_name=server_name)
                    tools.extend(server_tools)
                except Exception:
                    logger.exception(
                        "⚠️ Failed to load tools from MCP server '%s', skipping.",
                        server_name,
                    )

        for tool in tools:
            if hasattr(tool, "args_schema"):
                _sanitize_schema(tool.args_schema)
        return [_serialization_safe_shim(tool) for tool in tools]

    async def get_langchain_tools(self, name: str | None = None) -> list[Any]:
        """Alias for get_tools to make intent explicit when using LangChain/LangGraph agents."""
        return await self.get_tools(name=name)

    def get_adk_toolsets(self) -> list[Any]:
        """Return a list of Google ADK McpToolset instances for configured servers."""
        if McpToolset is None or StdioServerParameters is None:
            raise ImportError(
                "google-adk and mcp packages are required for ADK toolsets."
            )

        safe_errlog = _DeepcopySafeStderr()
        toolsets = []
        for config in self._configs:
            connection_params: Any = None

            if config.transport == "stdio":
                if not config.command:
                    continue

                server_params = StdioServerParameters(
                    command=config.command,
                    args=config.args,
                    env=config.env,
                    cwd=config.cwd,
                    encoding=config.encoding or "utf-8",
                    encoding_error_handler=config.encoding_error_handler or "strict",
                )

                connection_params = (
                    StdioConnectionParams(server_params=server_params)
                    if StdioConnectionParams is not None
                    else server_params
                )

            elif config.transport == "sse":
                if SseConnectionParams is None:
                    logger.warning(
                        "MCP server '%s': google-adk SseConnectionParams not available, skipping.",
                        config.name,
                    )
                    continue

                params: dict[str, Any] = {"url": config.url}
                if config.headers:
                    params["headers"] = config.headers
                if config.timeout_seconds is not None:
                    params["timeout"] = config.timeout_seconds
                if config.sse_read_timeout_seconds is not None:
                    params["sse_read_timeout"] = config.sse_read_timeout_seconds

                connection_params = SseConnectionParams(**params)

            elif config.transport == "streamable_http":
                if StreamableHTTPConnectionParams is None:
                    logger.warning(
                        "MCP server '%s': google-adk StreamableHTTPConnectionParams not available, skipping.",
                        config.name,
                    )
                    continue

                params = {"url": config.url}
                if config.headers:
                    params["headers"] = config.headers
                if config.timeout_seconds is not None:
                    params["timeout"] = config.timeout_seconds
                if config.sse_read_timeout_seconds is not None:
                    params["sse_read_timeout"] = config.sse_read_timeout_seconds
                if config.terminate_on_close is not None:
                    params["terminate_on_close"] = config.terminate_on_close

                connection_params = StreamableHTTPConnectionParams(**params)

            elif config.transport == "websocket":
                logger.warning(
                    "MCP server '%s': websocket transport is not supported by ADK toolsets, skipping.",
                    config.name,
                )
                continue

            else:
                logger.warning(
                    "MCP server '%s': unsupported transport '%s', skipping.",
                    config.name,
                    config.transport,
                )
                continue

            try:
                toolset = McpToolset(
                    connection_params=connection_params,
                    errlog=safe_errlog,
                )
                toolsets.append(toolset)
            except Exception:
                logger.exception(
                    "Failed to create ADK toolset for MCP server '%s', skipping.",
                    config.name,
                )

        return toolsets
