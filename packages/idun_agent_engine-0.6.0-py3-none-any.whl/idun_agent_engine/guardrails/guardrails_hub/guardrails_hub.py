"""Guardrails."""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

from idun_agent_schema.engine.guardrails import Guardrail as GuardrailSchema
from idun_agent_schema.engine.guardrails_v2 import GuardrailConfigId

from ..base import BaseGuardrail

if TYPE_CHECKING:
    from guardrails import Validator

PII_ENTITY_MAP = {
    "Email": "EMAIL_ADDRESS",
    "Phone Number": "PHONE_NUMBER",
    "Credit Card": "CREDIT_CARD",
    "SSN": "SSN",
    "Location": "LOCATION",
}

logger = logging.getLogger(__name__)

_GUARDRAILS_EXTRA_HINT = (
    "guardrails-ai is required to use Guardrails Hub validators but is not "
    "installed. Install the optional extra: "
    "`pip install 'idun-agent-engine[guardrails]'`."
)


def _require_guardrails_ai() -> None:
    """Raise a clear ImportError when ``guardrails`` is unavailable.

    The dependency moved to an optional extra so the engine wheel stays
    installable when the upstream PyPI project is quarantined. Surfacing
    the install hint at the point of use is friendlier than letting a
    deep ``ModuleNotFoundError`` propagate from the internal hub import.

    The catch is narrowed to ``ModuleNotFoundError`` whose ``name`` is
    exactly ``"guardrails"`` so transitive import failures inside an
    installed guardrails-ai (e.g. a broken sub-dep) bubble up unmasked
    rather than being rewritten as "the extra is missing".
    """
    try:
        import guardrails  # noqa: F401
    except ModuleNotFoundError as exc:
        if exc.name == "guardrails":
            raise ImportError(_GUARDRAILS_EXTRA_HINT) from exc
        raise


def get_guard_instance(name: GuardrailConfigId) -> type[Validator]:
    """Returns a map of guard type -> guard instance."""
    _require_guardrails_ai()

    if name == GuardrailConfigId.BAN_LIST:
        from guardrails.hub import BanList

        return BanList

    elif name == GuardrailConfigId.DETECT_PII:
        from guardrails.hub import DetectPII

        return DetectPII

    elif name == GuardrailConfigId.NSFW_TEXT:
        from guardrails.hub import NSFWText

        return NSFWText

    elif name == GuardrailConfigId.COMPETITION_CHECK:
        from guardrails.hub import CompetitorCheck

        return CompetitorCheck

    elif name == GuardrailConfigId.BIAS_CHECK:
        from guardrails.hub import BiasCheck

        return BiasCheck

    elif name == GuardrailConfigId.CORRECT_LANGUAGE:
        from guardrails.hub import ValidLanguage

        return ValidLanguage

    elif name == GuardrailConfigId.GIBBERISH_TEXT:
        from guardrails.hub import GibberishText

        return GibberishText

    elif name == GuardrailConfigId.TOXIC_LANGUAGE:
        from guardrails.hub import ToxicLanguage

        return ToxicLanguage

    elif name == GuardrailConfigId.RESTRICT_TO_TOPIC:
        from guardrails.hub import RestrictToTopic

        return RestrictToTopic

    else:
        raise ValueError(f"Guard {name} not found.")


class GuardrailsHubGuard(BaseGuardrail):
    """Class for managing guardrails from `guardrailsai`'s hub."""

    def __init__(self, config: GuardrailSchema, position: str) -> None:
        # Surface a friendly install hint before any internal guardrails-ai
        # import is reached during setup/validate.
        _require_guardrails_ai()

        super().__init__(config)

        self.guard_id = self._guardrail_config.config_id
        self._guard_url = self._guardrail_config.guard_url
        self.reject_message: str = self._guardrail_config.reject_message
        self._guard: Validator | None = self.setup_guard()
        self.position: str = position

    def _install_model(self) -> None:
        import subprocess

        from guardrails import install

        try:
            api_key = self._guardrail_config.api_key or os.getenv(
                "GUARDRAILS_API_KEY", ""
            )
            if not api_key:
                raise ValueError(
                    f"Guardrail '{self.guard_id}' requires an api_key. "
                    "Set it in the guardrail config or via GUARDRAILS_API_KEY env var."
                )

            logger.info("Configuring guardrails...")
            result = subprocess.run(
                [
                    "guardrails",
                    "configure",
                    "--token",
                    api_key,
                    "--disable-remote-inferencing",
                    "--disable-metrics",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            logger.debug(f"Configure output: {result.stdout}")
            if result.stderr:
                logger.debug(f"Configure stderr: {result.stderr}")
            logger.info(f"Installing model: {self._guard_url}...")
            install(self._guard_url, quiet=False, install_local_models=True)
            logger.info(f"✅ Successfully installed: {self._guard_url}")
        except subprocess.CalledProcessError as e:
            raise OSError(
                f"Cannot configure guardrails: stdout={e.stdout}, stderr={e.stderr}"
            ) from e
        except Exception as e:
            raise e

    def setup_guard(self) -> Validator | None:
        """Installs and configures the guard based on its yaml config."""
        self._install_model()
        guard_name = self.guard_id
        guard = get_guard_instance(guard_name)
        if guard is None:
            raise ValueError(
                f"Guard: {self.guard_id} is not yet supported, or does not exist."
            )

        config_dict = self._guardrail_config.model_dump()
        # Fields handled separately — not passed to the guard constructor
        exclude_fields = {
            "config_id",
            "api_key",
            "reject_message",
            "guard_url",
            "on_fail",
        }
        guard_instance_params = {
            k: v for k, v in config_dict.items() if k not in exclude_fields
        }

        # Extract on_fail — defaults to "exception"
        on_fail = config_dict.get("on_fail", "exception")

        if (
            guard_name == GuardrailConfigId.DETECT_PII
            and "pii_entities" in guard_instance_params
        ):
            guard_instance_params["pii_entities"] = [
                PII_ENTITY_MAP.get(e, e) for e in guard_instance_params["pii_entities"]
            ]

        try:
            guard_instance = guard(on_fail=on_fail, **guard_instance_params)
            return guard_instance
        except SystemError:
            # sentencepiece mutex lock error when loading models in quick succession
            import time

            time.sleep(0.5)
            guard_instance = guard(on_fail=on_fail, **guard_instance_params)
            return guard_instance

    def validate(self, input: str) -> bool:
        """Validate input against this guardrail. Returns True if content is allowed."""
        from guardrails.classes.validation.validation_result import FailResult

        # Defensive: ensure input is always a plain string for hub validators
        text = str(input) if not isinstance(input, str) else input

        try:
            result = self._guard.validate(text, metadata={})
            return not isinstance(result, FailResult)
        except Exception:
            logger.exception(
                "Guardrail '%s' raised an unexpected error during validation; "
                "blocking request (fail-closed).",
                self.guard_id,
            )
            return False
