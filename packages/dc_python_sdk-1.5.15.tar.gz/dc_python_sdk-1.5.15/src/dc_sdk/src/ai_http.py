import logging
import subprocess
import time
import requests
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict
from typing import List, Dict, Optional, Any, Tuple, Literal
from openai import OpenAI
import atexit
import signal

logger = logging.getLogger(__name__)

logging.basicConfig(level=logging.INFO)

app = FastAPI()

client = None
workspace = os.getenv("WORKSPACE", "/workspace")

# -----------------------------
# MODELS
# -----------------------------
class ConnectorContext(BaseModel):
    name: str
    auth_type: str
    base_url: str
    objects_dynamic: bool
    notes: Optional[str] = None

class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")

    role: Literal["user", "assistant"]
    content: str


class FeedbackRequest(BaseModel):
    credentials: Dict
    feedback: str
    connector_context: Optional[ConnectorContext] = None
    failed_stage: Optional[str] = None
    # Prior turns from last response’s ai_messages; new user content is only req.feedback this round.
    ai_messages: Optional[List[ChatMessage]] = None
    # Same semantics as RunRequest.test_object_ids; required for a meaningful re-test after feedback.
    test_object_ids: Optional[List[str]] = None


class RunRequest(BaseModel):
    credentials: List[Dict]
    max_attempts: Optional[int] = 5
    connector_context: Optional[ConnectorContext] = None
    ai_messages: Optional[List[ChatMessage]] = None
    # When objects_dynamic is false: required — every id must appear in get_objects results.
    # When objects_dynamic is true and get_objects returns []: required — used to probe get_fields/get_data.
    test_object_ids: Optional[List[str]] = None


# -----------------------------
# UTIL
# -----------------------------
def get_free_port():
    import socket
    s = socket.socket()
    s.bind(('', 0))
    port = s.getsockname()[1]
    s.close()
    return port


def start_connector():
    global workspace
    port = int(os.getenv("PORT", 6060))

    proc = subprocess.Popen(
        ["dc-sdk", "http"],
        cwd=workspace,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # wait for health
    for _ in range(50):
        try:
            res = requests.get(f"http://localhost:{port}/health")
            if res.status_code == 200:
                logger.info("Connector ready on port %s", port)
                return {"process": proc, "port": port}
        except Exception:
            logger.debug("Health check not ready yet on port %s", port)
        time.sleep(0.1)

    logger.error("Connector failed to become healthy on port %s within timeout", port)
    proc.terminate()
    raise Exception("Failed to start connector")


def stop_connector(runtime):
    try:
        runtime["process"].terminate()
        runtime["process"].wait()
        logger.debug("Connector subprocess stopped")
    except Exception:
        logger.debug("Error stopping connector subprocess", exc_info=True)


def invoke(port, method, session_id=None, credentials=None, params=None):
    payload = {
        "method": method,
        "session_id": session_id,
        "credentials": credentials if not session_id else None,
        "params": params or {}
    }

    logger.debug("invoke port=%s method=%s session_id=%s", port, method, session_id)
    res = requests.post(f"http://localhost:{port}/invoke", json=payload)
    if res.status_code != 200:
        logger.warning(
            "invoke returned HTTP %s for method=%s", res.status_code, method
        )
    return res.json()


def read_connector():
    global workspace
    with open(f"{workspace}/src/connector.py", "r") as f:
        return f.read()


def _resolved_connector_context(opt: Optional[ConnectorContext]) -> ConnectorContext:
    from dc_sdk.src.ai import CONNECTOR_CONTEXT as defaults

    merged: Dict[str, Any] = {
        "name": defaults["name"],
        "auth_type": defaults["auth_type"],
        "base_url": defaults["base_url"],
        "objects_dynamic": False,
        "notes": None,
    }
    if opt is not None:
        for key, value in opt.model_dump(exclude_unset=True).items():
            if value is not None:
                merged[key] = value
    return ConnectorContext(**merged)


def _chat_messages_to_openai(messages: Optional[List[ChatMessage]]) -> List[Dict[str, str]]:
    if not messages:
        return []
    out: List[Dict[str, str]] = []
    for m in messages:
        if m.role not in ("user", "assistant"):
            continue
        out.append({"role": m.role, "content": m.content})
    return out


def _coerce_prior_dicts(prior: Optional[List[Dict[str, str]]]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    for m in prior or []:
        role = m.get("role")
        content = m.get("content")
        if role in ("user", "assistant") and isinstance(content, str):
            out.append({"role": role, "content": content})
    return out


def write_connector(code):
    global workspace
    with open(f"{workspace}/src/connector.py", "w") as f:
        f.write(code)


def _canon_object_id(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _object_ids_from_get_objects_results(objects: List[Any]) -> List[str]:
    seen = set()
    out: List[str] = []
    for o in objects:
        if not isinstance(o, dict):
            continue
        oid = _canon_object_id(o.get("object_id") if o.get("object_id") is not None else o.get("id"))
        if oid and oid not in seen:
            seen.add(oid)
            out.append(oid)
    return out


# -----------------------------
# TEST FLOW
# -----------------------------
def run_test(
    credentials,
    *,
    connector_context: ConnectorContext,
    test_object_ids: Optional[List[str]] = None,
):
    runtime = start_connector()
    requested_ids = [_canon_object_id(x) for x in (test_object_ids or []) if _canon_object_id(x)]
    print(requested_ids)

    try:
        session_id = None

        # authenticate
        res = invoke(runtime["port"], "authenticate", None, credentials)
        if res.get("results") is not True:
            logger.warning("run_test failed at stage=authenticate")
            return False, "authenticate", res

        session_id = res.get("session_id")

        # get_objects
        res = invoke(runtime["port"], "get_objects", session_id)
        if not isinstance(res.get("results"), list):
            logger.warning("run_test failed at stage=get_objects (invalid results type)")
            return False, "get_objects", res

        objects = res["results"]
        api_ids = _object_ids_from_get_objects_results(objects)
        dynamic = connector_context.objects_dynamic

        if dynamic:
            if api_ids:
                if requested_ids:
                    api_set = set(api_ids)
                    wanted = [x for x in requested_ids if x in api_set]
                    if not wanted:
                        logger.warning(
                            "run_test failed: test_object_ids disjoint from get_objects"
                        )
                        return False, "get_objects", {
                            "message": (
                                f"objects_dynamic is true: none of test_object_ids {requested_ids} "
                                f"appear in get_objects results {api_ids}."
                            ),
                        }
                    ids_for_fields = wanted
                else:
                    ids_for_fields = list(api_ids)
            else:
                if not requested_ids:
                    logger.warning(
                        "run_test failed: objects_dynamic with empty get_objects and no test_object_ids"
                    )
                    return False, "get_objects", {
                        "message": (
                            "objects_dynamic is true: get_objects returned no objects. "
                            "Provide test_object_ids in the request to probe get_fields and get_data."
                        ),
                    }
                ids_for_fields = list(requested_ids)
        else:
            print(requested_ids)
            if not requested_ids:
                logger.warning("run_test failed: static objects require test_object_ids")
                return False, "get_objects", {
                    "message": (
                        "objects_dynamic is false: test_object_ids is required and must list "
                        "object ids you expect get_objects to return."
                    ),
                }
            if not objects:
                logger.warning("run_test failed at stage=get_objects (empty list)")
                return False, "get_objects", {"message": "No objects returned from get_objects"}

            ids_for_fields = list(requested_ids)

        if not ids_for_fields:
            logger.warning("run_test failed: no object ids to probe")
            return False, "get_objects", {
                "message": "No object ids available to test get_fields (empty candidate list).",
            }

        objects_with_fields: List[Tuple[str, List[Any]]] = []
        last_fields_payload: Any = None

        print(ids_for_fields)

        for object_id in ids_for_fields:
            res = invoke(
                runtime["port"],
                "get_fields",
                session_id,
                params={"object_id": object_id},
            )
            if not isinstance(res.get("results"), list):
                logger.warning(
                    "run_test failed at stage=get_fields (invalid results type) object_id=%s",
                    object_id,
                )
                return False, "get_fields", res

            fields = res["results"]
            last_fields_payload = res
            logger.info("get_fields results for object_id=%s: %s", object_id, len(fields))
            if fields:
                fids = [
                    f.get("field_id") or f.get("id")
                    for f in fields[:5]
                    if (f.get("field_id") or f.get("id")) is not None
                ]
                if fids:
                    objects_with_fields.append((object_id, fids))

        if not objects_with_fields:
            logger.warning(
                "run_test failed: no fields on any object tried ids=%s",
                ids_for_fields,
            )
            return False, "get_fields", {
                "message": (
                    f"get_fields returned no usable fields for any tested object_id(s): {ids_for_fields}. "
                    "Verify object ids and connector field discovery."
                ),
                "last_invoke": last_fields_payload,
            }

        last_data_res: Any = None
        for object_id, field_ids in objects_with_fields:
            res = invoke(
                runtime["port"],
                "get_data",
                session_id,
                params={
                    "object_id": object_id,
                    "field_ids": field_ids,
                    "n_rows": 5,
                },
            )
            last_data_res = res
            if not isinstance(res.get("results"), dict):
                logger.warning(
                    "run_test failed at stage=get_data (invalid results type) object_id=%s",
                    object_id,
                )
                return False, "get_data", res

            payload = res["results"]
            rows = payload.get("data")
            if isinstance(rows, list) and len(rows) > 0:
                logger.info("run_test completed successfully object_id=%s, rows retrieved=%s", object_id, len(rows))
                return True, None, None

        logger.warning(
            "run_test failed: get_data returned no rows for any object with fields"
        )
        return False, "get_data", {
            "message": (
                f"get_data returned no rows for any object that had fields "
                f"(tried {len(objects_with_fields)} object(s))."
            ),
            "last_invoke": last_data_res,
        }

    finally:
        stop_connector(runtime)


def _validate_static_requires_object_ids(
    ctx: ConnectorContext,
    test_object_ids: Optional[List[str]],
    location: str,
) -> None:
    if ctx.objects_dynamic:
        return
    if not any(_canon_object_id(x) for x in (test_object_ids or [])):
        raise HTTPException(
            status_code=422,
            detail=(
                f"{location}: when objects_dynamic is false, test_object_ids must be a non-empty "
                "list of object ids that get_objects is expected to return."
            ),
        )


def _build_full_fix_prompt(
    code: str,
    error_message: str,
    *,
    stage: Optional[str],
    connector_context: ConnectorContext,
) -> str:
    from dc_sdk.src.ai import (
        METHOD_CONTEXT,
        METHOD_SHAPE_REFERENCE,
        REQUIRED_METHODS,
    )

    extra_block = ""
    if connector_context.notes:
        extra_block = f"\nAdditional connector details:\n{connector_context.notes}\n"

    expected_behavior = (
        METHOD_CONTEXT.get(stage)
        if stage
        else None
    ) or (
        "Fix the connector so all required methods exist and the current failing stage succeeds."
    )

    dyn_rules = ""
    if connector_context.objects_dynamic:
        dyn_rules = (
            "- Get the objects dynamically from the connector\n"
            "- Don't hardcode the objects in the connector. Just return an empty list with a comment that says objects pulled from API.\n"
        )

    harness_rules = """
Test harness behavior (align connector with this):
- objects_dynamic false: the client sends test_object_ids; every id must appear in get_objects; the harness probes those ids for get_fields then get_data (at least one object must have fields; at least one get_data must return a non-empty data list).
- objects_dynamic true: get_objects may return []. If it does, the client must send test_object_ids to probe get_fields/get_data. If get_objects returns objects and test_object_ids is omitted, every returned id is probed; if test_object_ids is set, only ids in the intersection with get_objects are probed. The harness fails if every probed object has no fields, or if every object that had fields returns no data rows.
""".strip()

    return f"""
You are fixing a dc-python-sdk connector.

Connector:
- Name: {connector_context.name}
- Auth Type: {connector_context.auth_type}
- Base URL: {connector_context.base_url}
- Objects Dynamically Pulled from API: {connector_context.objects_dynamic}

{harness_rules}

{extra_block}
The connector failed at: {stage or "unknown"}

Expected behavior for this stage (when applicable):
{expected_behavior}

Error:
{error_message}

Rules:
- Use requests, or other common libraries where appropriate.
- Use self.credentials.
{dyn_rules}- Return only valid Python code for the full connector module.
- Ensure all required connector methods exist ({", ".join(REQUIRED_METHODS)}).
- Use the method signatures exactly as shown in the reference below.
- Match expected return shapes for get_objects/get_fields/get_data/load_data.

Method shape reference:
{METHOD_SHAPE_REFERENCE}

Code:
{code}

Default method stubs reference:

from dc_sdk.errors import NotImplementedError

class Connector:
    def __init__(self, credentials):
        self.credentials = credentials

    def authenticate(self):
        raise NotImplementedError("Connect method not implemented. Please implement authenticate() in your connector class.")

    def get_objects(self):
        raise NotImplementedError("Get objects method not implemented. Please implement get_objects() in your connector class.")

    def get_fields(self, object_id, options=dict()):
        raise NotImplementedError("Get fields method not implemented. Please implement get_fields() in your connector class.")

    def get_data(self, object_id, field_ids, n_rows=None, filters=None, next_page=None, options=dict()):
        raise NotImplementedError("Read method not implemented. Please implement get_data() in your connector class.")

    def load_data(self, data, object_id, m, update_method, batch_number: int, total_batches: int):
        raise NotImplementedError("Write method not implemented. Please implement load_data() in your connector class.")

    def close(self):
        raise NotImplementedError("Close method not implemented. Please implement close() in your connector class.")

Valid dc_sdk errors (import from dc_sdk.errors; __init__ signatures and internal flag below match dc_sdk.src.models.errors):

External / client-visible (internal=False):
- AuthenticationError - dc_sdk.errors.AuthenticationError(message=None)
- WhitelistError - dc_sdk.errors.WhitelistError(message=None)
- NoObjectsFoundError - dc_sdk.errors.NoObjectsFoundError(message=None)
- NoFieldsFoundError - dc_sdk.errors.NoFieldsFoundError(object_id, message=None)
- FilterDataTypeError - dc_sdk.errors.FilterDataTypeError(datatype=None, field_to_filter=None, message=None)
- MappingError - dc_sdk.errors.MappingError(message)
- DataError - dc_sdk.errors.DataError(message)
- APIRequestError - dc_sdk.errors.APIRequestError(error_code_returned=None, message=None)
- APITimeoutError - dc_sdk.errors.APITimeoutError(message=None)
- FieldDataTypeError - dc_sdk.errors.FieldDataTypeError(datatype=None, field=None, message=None)
- APIPermissionError - dc_sdk.errors.APIPermissionError(message=None)
- LoadDataError - dc_sdk.errors.LoadDataError(message=None)

Internal (internal=True):
- GetObjectsError - dc_sdk.errors.GetObjectsError(message=None)
- GetFieldsError - dc_sdk.errors.GetFieldsError(object_id, message=None)
- BadFieldIDError - dc_sdk.errors.BadFieldIDError(field_id=None, object_id=None, message=None)
- BadObjectIDError - dc_sdk.errors.BadObjectIDError(object_id=None, message=None)
- UpdateMethodNotSupportedError - dc_sdk.errors.UpdateMethodNotSupportedError(update_method=None, connector=None, message=None)
- NotADestinationError - dc_sdk.errors.NotADestinationError(message=None)
- NoRowsFoundError - dc_sdk.errors.NoRowsFoundError(message=None)
- NotImplementedError - dc_sdk.errors.NotImplementedError(message=None)  # use when a core method is not supported (e.g. load_data, close)
"""


def _build_follow_up_user_prompt(
    code: str,
    error_message: str,
    *,
    stage: Optional[str],
) -> str:
    return f"""Prior messages already contain the full connector contract, method shapes, and dc_sdk errors. Do not ask to restate them.

New error, test failure detail, or user instruction:
{error_message}

Failing stage (if applicable): {stage or "n/a"}

Current connector.py (authoritative — return a complete updated file):
```python
{code}
```

Reply with only valid Python for the full connector module (same ```python fenced style as before if you use fences)."""


def fix_with_ai(
    code,
    error_message,
    *,
    stage: Optional[str] = None,
    connector_context: Optional[ConnectorContext] = None,
    prior_messages: Optional[List[Dict[str, str]]] = None,
) -> Tuple[str, List[Dict[str, str]]]:
    ctx = _resolved_connector_context(connector_context)
    prior_openai = _coerce_prior_dicts(prior_messages)
    use_follow_up = len(prior_openai) > 0

    if use_follow_up:
        user_prompt = _build_follow_up_user_prompt(
            code, error_message, stage=stage
        )
    else:
        user_prompt = _build_full_fix_prompt(
            code, error_message, stage=stage, connector_context=ctx
        )

    api_messages: List[Dict[str, str]] = (
        [{"role": "system", "content": "You fix ETL connectors."}]
        + prior_openai
        + [{"role": "user", "content": user_prompt}]
    )

    logger.info(
        "Requesting AI code fix from OpenAI (follow_up=%s, prior_turns=%s)",
        use_follow_up,
        len(prior_openai),
    )
    response = client.chat.completions.create(
        model="gpt-5.4",
        messages=api_messages,
    )

    content = response.choices[0].message.content
    logger.debug("OpenAI fix response length=%s chars", len(content) if content else 0)

    import re
    match = re.search(r"```python\s*(.*?)```", content, re.DOTALL | re.IGNORECASE)
    new_code = match.group(1).strip() if match else (content or "")

    updated: List[Dict[str, str]] = prior_openai + [
        {"role": "user", "content": user_prompt},
        {"role": "assistant", "content": content or ""},
    ]
    return new_code, updated


# -----------------------------
# ENDPOINT: RUN CONNECTOR
# -----------------------------
@app.post("/run-connector")
def run_connector(req: RunRequest):
    credentials_list = req.credentials
    ctx = _resolved_connector_context(req.connector_context)
    _validate_static_requires_object_ids(ctx, req.test_object_ids, "run-connector")

    logger.info(
        "run-connector: %s credential set(s), max_attempts=%s",
        len(credentials_list),
        req.max_attempts,
    )

    history = []
    latest_code = read_connector()
    ai_messages = _chat_messages_to_openai(req.ai_messages)

    for attempt in range(req.max_attempts):
        for credentials in credentials_list:
            success, stage, error = run_test(
                credentials,
                connector_context=ctx,
                test_object_ids=req.test_object_ids,
            )

            if success:
                logger.info("run-connector succeeded on attempt %s", attempt + 1)
                return {
                    "success": True,
                    "attempts": attempt + 1,
                    "code": latest_code,
                    "ai_messages": ai_messages,
                }

        # fix
        error_msg = str(error)
        logger.info(
            "run-connector: attempt %s failed at stage=%s, applying AI fix",
            attempt + 1,
            stage,
        )
        latest_code, ai_messages = fix_with_ai(
            latest_code,
            error_msg,
            stage=stage,
            connector_context=ctx,
            prior_messages=ai_messages,
        )
        write_connector(latest_code)

        history.append({
            "attempt": attempt + 1,
            "failed_stage": stage
        })

    logger.warning(
        "run-connector exhausted %s attempts without success", req.max_attempts
    )
    return {
        "success": False,
        "history": history,
        "code": latest_code,
        "ai_messages": ai_messages,
    }


# -----------------------------
# ENDPOINT: FEEDBACK
# -----------------------------
@app.post("/feedback")
def feedback(req: FeedbackRequest):
    logger.info("feedback: applying user feedback and re-running test")

    ctx = _resolved_connector_context(req.connector_context)
    _validate_static_requires_object_ids(ctx, req.test_object_ids, "feedback")

    current_code = read_connector()
    ai_messages = _chat_messages_to_openai(req.ai_messages)

    new_code, ai_messages = fix_with_ai(
        current_code,
        req.feedback,
        stage=req.failed_stage,
        connector_context=ctx,
        prior_messages=ai_messages,
    )
    write_connector(new_code)

    success, stage, error = run_test(
        req.credentials,
        connector_context=ctx,
        test_object_ids=req.test_object_ids,
    )
    if success:
        logger.info("feedback: test passed after applying changes")
    else:
        logger.warning("feedback: test failed at stage=%s", stage)

    return {
        "success": success,
        "failed_stage": stage if not success else None,
        "error": error if not success else None,
        "code": new_code,
        "ai_messages": ai_messages,
    }

def clone_repo():
    global workspace
    repo = os.getenv("GH_REPO_URL")
    token = os.getenv("GH_TOKEN")
    branch = os.getenv("GH_BRANCH", "development")

    if not repo:
        return

    if not os.path.exists(f"{workspace}/.git"):
        clone_url = repo.replace("https://", f"https://{token}@")
        subprocess.run(["git", "clone", clone_url, workspace], check=True)
    else:
        subprocess.run(["git", "-C", workspace, "fetch"], check=True)

    subprocess.run(["git", "-C", workspace, "checkout", branch], check=True)
    subprocess.run(["git", "-C", workspace, "pull"], check=True)

def start_ai_http():
    global client
    global workspace

    api_key = os.getenv("OPENAI_API_KEY")
    ai_port = int(os.getenv("AI_PORT", 5050))
    code_port = int(os.getenv("CODE_SERVER_PORT", 5002))

    clone_repo()

    code_server_proc = subprocess.Popen([
        "code-server",
        workspace,
        "--bind-addr", f"0.0.0.0:{code_port}",
        "--auth", "none"
    ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )

    # Optional: wait briefly to confirm startup
    time.sleep(1)

    if code_server_proc.poll() is not None:
        raise Exception("code-server failed to start")

    def shutdown():
        logger.info("Shutting down code-server...")
        if code_server_proc:
            code_server_proc.terminate()

    atexit.register(shutdown)

    def handle_signal(sig, frame):
        shutdown()
        exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    if not api_key:
        raise Exception("Missing OPENAI_API_KEY environment variable")

    client = OpenAI(api_key=api_key)

    port = int(os.getenv("AI_PORT", 5050))

    logger.info("Starting AI HTTP controller on 0.0.0.0:%s", port)

    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=port)

@app.get("/session-info")
def session_info():
    return {
        "workspace": workspace,
        "ai_port": int(os.getenv("AI_PORT", 5050)),
        "code_server_port": int(os.getenv("CODE_SERVER_PORT", 5002)),
        "api_base": f"http://localhost:{os.getenv('AI_PORT', 5050)}"
    }