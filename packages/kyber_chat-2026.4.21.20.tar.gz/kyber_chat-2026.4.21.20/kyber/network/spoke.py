"""Spoke-side of the Kyber network.

Runs inside the gateway process when ``config.network.role == "spoke"``.
Opens a persistent WebSocket to the configured host, sends a signed
``hello``, then pings a ``heartbeat`` every :data:`HEARTBEAT_INTERVAL_S`
seconds. Reconnects with backoff on any failure.

Outbound-only by design: spokes work behind NAT/firewall without any
port forwarding, because the connection is always initiated from the
spoke side.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from typing import Any

import httpx
import websockets
from websockets.exceptions import (
    ConnectionClosed,
    ConnectionClosedError,
    ConnectionClosedOK,
    WebSocketException,
)

from kyber.network.protocol import (
    ProtocolError,
    decode_signed,
    encode_signed,
    make_envelope,
)
from kyber.network.state import (
    ROLE_HOST,
    ROLE_SPOKE,
    NetworkState,
    PairedPeer,
    load_state,
    save_state,
)

logger = logging.getLogger(__name__)

HEARTBEAT_INTERVAL_S = 15.0
BACKOFF_MIN_S = 2.0
BACKOFF_MAX_S = 60.0


async def pair_with_host(
    host_http_url: str,
    pairing_code: str,
    *,
    display_name: str | None = None,
    timeout: float = 20.0,
) -> NetworkState:
    """One-time pairing: POST to the host's ``/network/pair``.

    Persists the resulting secret + peer info into ``~/.kyber/network.json``
    and returns the updated state. Raises ``RuntimeError`` with a clean
    message on any failure so callers can print it directly.
    """
    state = load_state()
    payload = {
        "code": pairing_code.strip().upper(),
        "peer_id": state.peer_id,
        "name": (display_name or state.name).strip() or state.name,
    }

    url = host_http_url.rstrip("/") + "/network/pair"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, json=payload)
    except httpx.HTTPError as e:
        raise RuntimeError(f"could not reach host at {host_http_url}: {e}") from e

    if resp.status_code == 403:
        raise RuntimeError("pairing code was rejected — expired or already used")
    if resp.status_code == 409:
        raise RuntimeError("the target is not running in host mode")
    if resp.status_code != 200:
        snippet = (resp.text or "")[:300]
        raise RuntimeError(f"host returned HTTP {resp.status_code}: {snippet}")

    try:
        data = resp.json()
    except ValueError as e:
        raise RuntimeError(f"host returned non-JSON response: {e}") from e

    host_peer_id = str(data.get("host_peer_id") or "")
    host_name = str(data.get("host_name") or "")
    secret = str(data.get("secret") or "")
    if not (host_peer_id and host_name and secret):
        raise RuntimeError("host returned an incomplete pairing response")

    now = time.time()
    # Flip BOTH the state role and persist it — the config.network.role is
    # updated separately by the caller (CLI flips it via save_config so
    # gateway restart picks it up).
    state.role = ROLE_SPOKE
    state.host_url = host_http_url.rstrip("/")
    state.name = payload["name"]  # update display name if user passed --as
    state.host_peer = PairedPeer(
        peer_id=host_peer_id,
        name=host_name,
        secret=secret,
        role=ROLE_HOST,
        added_at=now,
        last_seen=0.0,
    )
    save_state(state)
    return state


class SpokeClient:
    """Persistent WS client for a paired spoke.

    Usage::

        client = SpokeClient()
        await client.start()  # returns immediately; runs in background
        ...
        await client.stop()
    """

    def __init__(self) -> None:
        self._task: asyncio.Task | None = None
        self._stopping = asyncio.Event()
        self._last_connected_at: float = 0.0
        self._last_error: str = ""

    @property
    def status(self) -> dict[str, Any]:
        return {
            "running": self._task is not None and not self._task.done(),
            "last_connected_at": self._last_connected_at,
            "last_error": self._last_error,
        }

    async def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stopping.clear()
        self._task = asyncio.create_task(self._run_forever(), name="network-spoke")

    async def stop(self) -> None:
        self._stopping.set()
        t = self._task
        self._task = None
        if t is not None:
            t.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await t

    async def _run_forever(self) -> None:
        backoff = BACKOFF_MIN_S
        while not self._stopping.is_set():
            state = load_state()
            if state.role != ROLE_SPOKE or state.host_peer is None or not state.host_url:
                # Not configured to run — park quietly. A later `kyber network
                # join` will update state; we'll pick it up on the next cycle.
                await self._sleep_or_stop(10.0)
                continue

            try:
                await self._run_once(state)
                # Clean close — reset backoff and loop.
                backoff = BACKOFF_MIN_S
            except asyncio.CancelledError:
                raise
            except (ConnectionClosed, ConnectionClosedError, ConnectionClosedOK) as e:
                self._last_error = f"disconnected: {e}"
                logger.info("network: spoke disconnected (%s); reconnecting in %.1fs", e, backoff)
            except WebSocketException as e:
                self._last_error = f"ws error: {e}"
                logger.info("network: ws error (%s); reconnecting in %.1fs", e, backoff)
            except Exception as e:  # pragma: no cover
                self._last_error = f"{type(e).__name__}: {e}"
                logger.exception("network: spoke loop failed")

            await self._sleep_or_stop(backoff)
            backoff = min(BACKOFF_MAX_S, backoff * 1.7)

    async def _sleep_or_stop(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stopping.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _run_once(self, state: NetworkState) -> None:
        ws_url = _http_to_ws(state.host_url) + "/ws/network"
        peer = state.host_peer
        assert peer is not None  # guarded above

        async with websockets.connect(ws_url, max_size=16 * 1024 * 1024) as ws:
            # Handshake.
            hello = make_envelope(
                "hello",
                {
                    "peer_id": state.peer_id,
                    "name": state.name,
                    "role": ROLE_SPOKE,
                },
            )
            await ws.send(encode_signed(hello, peer.secret))
            raw = await asyncio.wait_for(ws.recv(), timeout=10.0)
            try:
                env = decode_signed(raw, peer.secret)
            except ProtocolError as e:
                raise RuntimeError(f"host handshake invalid: {e}") from e
            if env.type != "hello_ack":
                raise RuntimeError(f"unexpected handshake reply: {env.type}")

            self._last_connected_at = time.time()
            self._last_error = ""
            logger.info("network: connected to host %s at %s", peer.name, state.host_url)

            # Main loop: heartbeat on timer, drain any reply frames.
            while not self._stopping.is_set():
                beat = make_envelope("heartbeat", {})
                await ws.send(encode_signed(beat, peer.secret))
                # Pull whatever the host sends back, with a short deadline so
                # we tick the heartbeat reliably.
                try:
                    reply_raw = await asyncio.wait_for(
                        ws.recv(), timeout=HEARTBEAT_INTERVAL_S
                    )
                except asyncio.TimeoutError:
                    continue
                try:
                    reply = decode_signed(reply_raw, peer.secret)
                except ProtocolError as e:
                    raise RuntimeError(f"bad frame from host: {e}") from e
                if reply.type == "heartbeat_ack":
                    _touch_host_peer()


def _http_to_ws(url: str) -> str:
    """``http://host:port`` → ``ws://host:port``; ``https://`` → ``wss://``."""
    if url.startswith("https://"):
        return "wss://" + url[len("https://") :]
    if url.startswith("http://"):
        return "ws://" + url[len("http://") :]
    return url


def _touch_host_peer() -> None:
    state = load_state()
    if state.host_peer is not None:
        state.host_peer.last_seen = time.time()
        save_state(state)


# Module-level singleton so the gateway lifecycle and CLI status command can
# share the same running client.
_SPOKE: SpokeClient | None = None


def get_spoke_client() -> SpokeClient:
    global _SPOKE
    if _SPOKE is None:
        _SPOKE = SpokeClient()
    return _SPOKE
