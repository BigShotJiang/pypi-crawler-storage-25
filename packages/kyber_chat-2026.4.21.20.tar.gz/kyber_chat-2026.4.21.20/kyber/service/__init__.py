"""System service management for Kyber's gateway and dashboard.

Provides install/uninstall/status helpers that write launchd plists on
macOS and systemd user units on Linux. Used by the ``kyber service``
CLI command group so users can enable background mode after the initial
install.
"""

from kyber.service.manager import (
    ServiceInfo,
    UnitStatus,
    UnsupportedPlatformError,
    install_services,
    kill_orphan_kyber_processes,
    service_status,
    restart_services,
    uninstall_services,
)

__all__ = [
    "ServiceInfo",
    "UnitStatus",
    "UnsupportedPlatformError",
    "install_services",
    "kill_orphan_kyber_processes",
    "service_status",
    "restart_services",
    "uninstall_services",
]
