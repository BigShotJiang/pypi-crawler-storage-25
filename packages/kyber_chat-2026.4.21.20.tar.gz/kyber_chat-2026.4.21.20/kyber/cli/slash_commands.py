"""Slash-command registry for the Kyber CLI REPL.

This is the Phase-2 home for slash commands — the structure is intentionally
decoupled so Phase 1 can lift the registry into a shared location and wire
every channel (Discord, Telegram, dashboard chat) through the same dispatcher.

A command handler is an async callable taking ``(args, ctx, client)`` and
returning a :class:`SlashResult`. The ``ctx`` carries mutable per-REPL state
(session id, gateway URL, token, console) so handlers don't need global lookups.

For commands that still depend on Phase 1 plumbing (e.g. ``/model``, ``/usage``,
``/compress``) we register a short-circuit stub so tab-completion still works
and users get a clear "coming soon" message instead of silent failure.
"""

from __future__ import annotations

import shlex
from dataclasses import dataclass, field
from typing import Awaitable, Callable

import httpx
from rich.console import Console
from rich.table import Table


@dataclass
class REPLContext:
    session_id: str
    gateway_url: str
    gateway_token: str
    console: Console


@dataclass
class SlashResult:
    reply_text: str = ""
    should_exit: bool = False
    new_session_id: str | None = None


CommandHandler = Callable[[list[str], REPLContext, httpx.AsyncClient], Awaitable[SlashResult]]


@dataclass
class Command:
    name: str
    summary: str
    handler: CommandHandler
    usage: str = ""


_COMMANDS: dict[str, Command] = {}


def register(name: str, summary: str, usage: str = ""):
    """Decorator: register a slash command by name."""

    def wrap(fn: CommandHandler) -> CommandHandler:
        _COMMANDS[name] = Command(name=name, summary=summary, handler=fn, usage=usage)
        return fn

    return wrap


def available_command_names() -> list[str]:
    return sorted(_COMMANDS.keys())


def list_commands() -> list[Command]:
    """Return all registered commands (one entry per alias).

    Sorted by name. Use this when you need to display a palette/menu; for
    plain name lookup, :func:`available_command_names` is cheaper.
    """
    return [_COMMANDS[name] for name in sorted(_COMMANDS.keys())]


async def dispatch_slash(
    raw: str, ctx: REPLContext, *, client: httpx.AsyncClient
) -> SlashResult:
    """Parse and run a slash command. Returns a SlashResult."""
    stripped = raw.strip()
    if not stripped.startswith("/"):
        return SlashResult(reply_text="[red]internal: dispatch_slash called on non-slash input[/red]")
    try:
        tokens = shlex.split(stripped[1:])
    except ValueError as e:
        return SlashResult(reply_text=f"[red]parse error:[/red] {e}")
    if not tokens:
        return SlashResult(reply_text="[yellow]empty command[/yellow]")

    name, *args = tokens
    cmd = _COMMANDS.get(name.lower())
    if cmd is None:
        return SlashResult(
            reply_text=(
                f"[yellow]unknown command: /{name}[/yellow]\n"
                "Type [cyan]/help[/cyan] to see what's available."
            )
        )
    try:
        return await cmd.handler(args, ctx, client)
    except Exception as e:
        return SlashResult(reply_text=f"[red]/{name} failed:[/red] {e}")


# ── Built-in commands ─────────────────────────────────────────────────────


@register("help", summary="List available slash commands")
async def _help(args, ctx, client):
    table = Table(title="Slash commands", show_lines=False, header_style="bold")
    table.add_column("Command", style="cyan", no_wrap=True)
    table.add_column("Description")
    for name in sorted(_COMMANDS):
        cmd = _COMMANDS[name]
        label = f"/{cmd.name}"
        if cmd.usage:
            label += f" {cmd.usage}"
        table.add_row(label, cmd.summary)
    with ctx.console.capture() as cap:
        ctx.console.print(table)
    return SlashResult(reply_text=cap.get().rstrip())


@register("quit", summary="Exit the chat REPL")
@register("exit", summary="Exit the chat REPL")
async def _quit(args, ctx, client):
    return SlashResult(should_exit=True)


@register(
    "new",
    summary="Clear the current chat session and start fresh",
)
async def _new(args, ctx, client):
    headers = (
        {"Authorization": f"Bearer {ctx.gateway_token}"}
        if ctx.gateway_token
        else {}
    )
    resp = await client.post(
        f"{ctx.gateway_url.rstrip('/')}/chat/reset",
        headers=headers,
        json={"session_id": ctx.session_id},
        timeout=15.0,
    )
    if resp.status_code >= 400:
        return SlashResult(
            reply_text=f"[red]/new failed:[/red] HTTP {resp.status_code}"
        )
    return SlashResult(reply_text="[green]✓[/green] session cleared")


@register(
    "session",
    summary="Show or switch the current session id",
    usage="[id]",
)
async def _session(args, ctx, client):
    if not args:
        return SlashResult(reply_text=f"[dim]session:[/dim] {ctx.session_id}")
    new_id = args[0].strip()
    if not new_id:
        return SlashResult(reply_text="[yellow]session id cannot be empty[/yellow]")
    return SlashResult(
        reply_text=f"[green]✓[/green] switched session",
        new_session_id=new_id,
    )


# ── Stubs for Phase 1 ─────────────────────────────────────────────────────
#
# These commands are part of the shared vocabulary we'll wire up in Phase 1
# (across CLI + Discord + Telegram + dashboard). Registering stubs now means
# tab completion shows them and users get clear "coming soon" messages
# instead of silent "unknown command" errors.


def _phase1_stub(name: str, what: str):
    async def _handler(args, ctx, client):
        return SlashResult(
            reply_text=(
                f"[yellow]/{name}[/yellow] isn't implemented yet — coming in "
                "the shared command phase.\n"
                f"[dim]{what}[/dim]"
            )
        )

    return _handler


register("model", summary="Switch or list available LLM models", usage="[name]")(
    _phase1_stub("model", "Will call /api/providers to list + hot-swap the active model.")
)
register("skills", summary="List or search installed skills", usage="[query]")(
    _phase1_stub("skills", "Will read workspace/skills/ and skills.sh catalog.")
)
register("compress", summary="Summarize conversation and start a fresh context")(
    _phase1_stub("compress", "Will fold history into a summary message and reset.")
)
register("usage", summary="Show token usage for this session + today + month")(
    _phase1_stub("usage", "Will aggregate from the task registry + usage tracker.")
)
register("cost", summary="Show approximate spend by provider")(
    _phase1_stub("cost", "Will multiply token counts by provider rate cards.")
)
register("cancel", summary="Cancel the currently running task (if any)")(
    _phase1_stub("cancel", "Will look up the active task id and call /tasks/{ref}/cancel.")
)
