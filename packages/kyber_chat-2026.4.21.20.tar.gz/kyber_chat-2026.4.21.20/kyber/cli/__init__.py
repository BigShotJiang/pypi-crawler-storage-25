"""CLI module for kyber."""
