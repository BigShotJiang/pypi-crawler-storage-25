"""Reusable mixin for subprocess-isolated ASR models.

Some upstream model packages pin dependency versions that conflict with the
main ``modern-asr`` environment (e.g. ``transformers==4.57.6`` vs
``transformers>=5.7.0``).  Rather than forcing users to choose one environment,
this mixin lets a model adapter transparently spawn a dedicated Python
subprocess with its own virtual environment and communicate with it via
newline-delimited JSON over stdin/stdout.

The worker script (``scripts/subprocess_worker.py``) is **fully generic** — it
uses ``create_model()`` and ``model.transcribe()``, so any registered model can
run inside it.  The only model-specific pieces are:

1. **Conflict detection** — a callable that returns ``True`` when the current
   environment is incompatible (checked at ``load()`` time).
2. **Venv path** — where the isolated environment lives.
3. **Auto-install** — optional list of pip commands to run inside the venv when
   it is first created.  Users never have to manually set up isolated envs.

Usage in a model adapter::

    @register_model("my-model")
    class MyModel(SubprocessIsolatedMixin, AudioLLMModel):
        SUBPROCESS_VENV = ".venv_my_model"
        SUBPROCESS_ENV_VAR = "MODERN_ASR_MY_MODEL_VENV"
        SUBPROCESS_CHECK = staticmethod(
            lambda: int(transformers.__version__.split(".")[0]) >= 5
        )
        SUBPROCESS_AUTO_INSTALL = [
            "pip install torch transformers==4.57.6",
        ]

        def load(self):
            self._try_native_then_subprocess(native_load=super().load)

        def transcribe(self, audio, **kwargs):
            self._ensure_loaded()
            audio_path = self._audio_to_file(audio)
            if self._subprocess_backend is not None:
                return self._subprocess_transcribe(audio_path, **kwargs)
            return super().transcribe(audio, **kwargs)
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from modern_asr.utils.log import get_logger

if TYPE_CHECKING:
    from modern_asr.backends.subprocess_backend import SubprocessBackend
    from modern_asr.core.types import ASRResult

logger = get_logger(__name__)


class SubprocessIsolatedMixin:
    """Mixin that adds subprocess-isolation capabilities to an ASR model.

    Subclasses declare *class attributes* (no boilerplate methods required).
    """

    # ------------------------------------------------------------------ #
    # Configuration — override in subclass
    # ------------------------------------------------------------------ #

    SUBPROCESS_VENV: str | None = None
    """Path to the isolated virtual environment.

    May be absolute or relative to the current working directory.
    """

    SUBPROCESS_ENV_VAR: str | None = None
    """Environment variable name that can override ``SUBPROCESS_VENV``.

    Example: ``"MODERN_ASR_QWEN_VENV"``.
    """

    SUBPROCESS_CHECK: Callable[[], bool] | None = None
    """Callable that returns ``True`` when the current environment has a
    conflicting dependency version and subprocess isolation is required."""

    SUBPROCESS_WORKER: str | None = None
    """Path to the worker script, relative to CWD or absolute.

    Defaults to the bundled ``modern_asr/backends/subprocess_worker.py``.
    """

    SUBPROCESS_AUTO_INSTALL: list[str] | None = None
    """Optional list of shell commands to run inside the venv after creation.

    Each command is executed with the venv's pip/python.  This lets users
    use subprocess-isolated models **without any manual setup**.

    Example::

        SUBPROCESS_AUTO_INSTALL = [
            "pip install torch torchaudio sentencepiece accelerate",
            "pip install git+https://github.com/huggingface/transformers",
            "pip install librosa pydantic pyyaml rich",
        ]
    """

    # ------------------------------------------------------------------ #
    # Internal state
    # ------------------------------------------------------------------ #

    _subprocess_backend: "SubprocessBackend" | None = None

    # ------------------------------------------------------------------ #
    # Loading helpers
    # ------------------------------------------------------------------ #

    def _try_native_then_subprocess(self, native_load: Callable[[], None]) -> None:
        """Try native loading; fall back to subprocess if conflict detected.

        Args:
            native_load: Callable that performs the native (in-process) model
                loading, e.g. ``super().load``.
        """
        check = getattr(self, "SUBPROCESS_CHECK", None)
        if check is not None and check():
            try:
                native_load()
                return
            except Exception:
                self._load_via_subprocess()
        else:
            native_load()

    def _discover_venv(self) -> tuple[str | None, str | None]:
        """Return (python_executable, venv_path) or (None, None) if not found."""
        model_id = getattr(self, "model_id", "unknown")
        cwd = Path.cwd()
        env_var = getattr(self, "SUBPROCESS_ENV_VAR", None)
        venv = getattr(self, "SUBPROCESS_VENV", None)
        slug = model_id.replace("-", "_")

        candidates: list[str] = []
        if env_var:
            candidates.append(os.environ.get(env_var, ""))
        if venv:
            candidates.append(venv if os.path.isabs(venv) else str(cwd / venv))
        candidates.append(str(cwd / f".venv_{slug}"))

        for candidate in candidates:
            if candidate and os.path.isfile(os.path.join(candidate, "bin", "python")):
                return os.path.join(candidate, "bin", "python"), candidate
        return None, None

    def _auto_install_venv(self, venv_path: str) -> None:
        """Create venv and run SUBPROCESS_AUTO_INSTALL commands."""
        model_id = getattr(self, "model_id", "unknown")
        auto_install = getattr(self, "SUBPROCESS_AUTO_INSTALL", None) or []
        if not auto_install:
            return

        python = sys.executable
        logger.info("[%s] Creating isolated venv: %s", model_id, venv_path)
        subprocess.run([python, "-m", "venv", venv_path], check=True)

        pip = os.path.join(venv_path, "bin", "pip")
        for cmd in auto_install:
            logger.info("[%s] Installing: %s", model_id, cmd)
            # Run command inside the venv
            subprocess.run(cmd, shell=True, check=True, executable="/bin/bash",
                           env={**os.environ, "VIRTUAL_ENV": venv_path,
                                "PATH": os.path.join(venv_path, "bin") + ":" + os.environ.get("PATH", "")})

    def _load_via_subprocess(self) -> None:
        """Spawn a subprocess worker in an isolated virtual environment."""
        from modern_asr.backends.subprocess_backend import SubprocessBackend

        model_id = getattr(self, "model_id", "unknown")
        cwd = Path.cwd()

        python_exe, venv_path = self._discover_venv()

        # Auto-create venv if missing and SUBPROCESS_AUTO_INSTALL is defined
        if python_exe is None:
            auto_install = getattr(self, "SUBPROCESS_AUTO_INSTALL", None)
            if auto_install:
                # Determine where to create the venv
                env_var = getattr(self, "SUBPROCESS_ENV_VAR", None)
                venv = getattr(self, "SUBPROCESS_VENV", None)
                slug = model_id.replace("-", "_")
                target_venv = None
                if env_var and os.environ.get(env_var):
                    target_venv = os.environ.get(env_var)
                elif venv:
                    target_venv = venv if os.path.isabs(venv) else str(cwd / venv)
                else:
                    target_venv = str(cwd / f".venv_{slug}")

                self._auto_install_venv(target_venv)
                python_exe, venv_path = self._discover_venv()

        if python_exe is None:
            env_var = getattr(self, "SUBPROCESS_ENV_VAR", None)
            venv = getattr(self, "SUBPROCESS_VENV", None)
            slug = model_id.replace("-", "_")
            searched = []
            if env_var and os.environ.get(env_var):
                searched.append(os.environ.get(env_var))
            if venv:
                searched.append(venv if os.path.isabs(venv) else str(cwd / venv))
            searched.append(str(cwd / f".venv_{slug}"))
            raise RuntimeError(
                f"{model_id} requires an isolated virtual environment because "
                f"the current environment has conflicting dependencies.\n\n"
                f"Searched: {searched}\n\n"
                f"Please create one:\n"
                f"  cd {cwd}\n"
                f"  python3.10 -m venv {venv or '.venv_' + slug}\n"
                f"  source {venv or '.venv_' + slug}/bin/activate\n"
                f"  pip install <model-specific-deps>\n\n"
                f"Or set {env_var}=<path>"
                if env_var
                else ""
            )

        # --- discover worker script ---------------------------------------
        worker = getattr(self, "SUBPROCESS_WORKER", None)
        if worker:
            worker_script = worker if os.path.isabs(worker) else str(cwd / worker)
        else:
            # Try package-internal path first (pip-installed wheel)
            try:
                from importlib.resources import files

                pkg_path = files("modern_asr.backends") / "subprocess_worker.py"
                worker_script = str(pkg_path)
            except Exception:
                # Fallback to cwd scripts/ (editable install from project root)
                worker_script = str(cwd / "scripts" / "subprocess_worker.py")

        if not os.path.isfile(worker_script):
            raise RuntimeError(f"Worker script not found: {worker_script}")

        # --- resolve device for init payload ------------------------------
        resolve_device = getattr(self, "_resolve_device", None)
        device = resolve_device() if resolve_device else "cpu"

        # --- spawn backend ------------------------------------------------
        self._subprocess_backend = SubprocessBackend(
            python_executable=python_exe,
            worker_script=worker_script,
            env={
                "MODERN_ASR_CACHE_DIR": os.environ.get(
                    "MODERN_ASR_CACHE_DIR",
                    str(Path.home() / ".cache" / "modern-asr"),
                ),
            },
            init_payload={"model_id": model_id, "device": device},
        )
        self._is_loaded = True

    # ------------------------------------------------------------------ #
    # Inference helpers
    # ------------------------------------------------------------------ #

    def _subprocess_transcribe(
        self,
        audio_path: str,
        language: str | None = None,
        **kwargs: Any,
    ) -> "ASRResult":
        """Delegate transcription to the subprocess worker.

        Args:
            audio_path: Absolute path to the audio file.
            language: Target language (or ``None`` for auto).
            **kwargs: Unused — kept for API compatibility.

        Returns:
            An ``ASRResult`` built via ``self._build_result``.
        """
        backend = getattr(self, "_subprocess_backend", None)
        if backend is None:
            raise RuntimeError(
                "Subprocess backend not initialized; call load() first."
            )

        resp = backend.infer(audio=audio_path, language=language or "auto")
        if resp.get("status") != "ok":
            raise RuntimeError(f"Worker error: {resp.get('error', 'unknown')}")

        text = resp.get("text", "")
        detected_lang = resp.get("language", language or "auto")
        kw = dict(kwargs)
        kw.pop("language", None)
        # _build_result is provided by AudioLLMModel / ASRModel
        build_result = getattr(self, "_build_result", None)
        if build_result is None:
            from modern_asr.core.types import ASRResult, Segment
            return ASRResult(
                text=text.strip(),
                segments=[Segment(text=text.strip())],
                language=detected_lang,
                model_id=getattr(self, "model_id", "unknown"),
            )
        return build_result(text, language=detected_lang, **kw)

    def shutdown_subprocess(self) -> None:
        """Gracefully terminate the subprocess worker if running."""
        backend = getattr(self, "_subprocess_backend", None)
        if backend is not None:
            backend.shutdown()
            self._subprocess_backend = None
