---
title: Validate Command
description: Reference for `stacksats strategy validate`.
---

# Validate Command

## Prerequisites

- Strategy selector format: built-in `strategy_id` or `module_or_path:ClassName`
- Canonical source dataset is `merged_metrics*.parquet` (see [Merged Metrics Parquet Schema](../reference/merged-metrics-parquet-schema.md)).
- Runtime BRK-wide parquet available (`STACKSATS_ANALYTICS_PARQUET`, managed default `~/.stacksats/data/bitcoin_analytics.parquet`, or `./bitcoin_analytics.parquet`).

## Command

```bash
stacksats strategy validate \
  --strategy simple-zscore \
  --start-date 2024-01-01 \
  --end-date 2024-12-31
```

Built-in strategy catalog and expected behavior: [Strategies](../reference/strategies.md).

## Expected output

- Summary line with pass/fail and gate statuses.
- Strict validation is enabled by default for this CLI command.

## Key options

- `--strategy-config <path>`: strategy params JSON.
- default validation bounds if omitted: start `2018-01-01`, end `2025-12-31` (clamped to available data).
- `--min-win-rate <float>`: validation threshold (default `50.0`).
- `--no-strict`: disable strict robustness gates intentionally.

## Troubleshooting

- If strategy import fails, verify the built-in `strategy_id` or custom module path and editable install.
- If strict gates fail, inspect diagnostics with [Validation Checklist](../validation_checklist.md).

## Next step

- Run a historical evaluation: [Backtest Command](backtest.md).

## Feedback

- [Was this page helpful? Open docs feedback issue](https://github.com/hypertrial/stacksats/issues/new?template=docs_feedback.md&title=%5Bdocs%5D+Feedback%3A+Validate+Command)
