from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

ENV_PREFIX = "xmas_"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        extra="ignore",
        env_prefix=ENV_PREFIX,
        env_file=".env",
        env_file_encoding="utf-8",
    )

    db_srid: int = 25832
    db_schema: str | None = None
    db_views: bool = True
    db_pool_size: int = 10
    db_pool_max_overflow: int = 20
    db_pool_timeout: int = 30
    db_pool_recycle: int = 1800
    db_pool_pre_ping: bool = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
