"""This module contains a method to validate Feature Collections with the official XPlanValidator."""

import io
import logging
from pathlib import Path
from typing import Dict, Literal

import httpx
from pydantic_core import from_json, to_json

from xplan_tools.interface.gml import GMLRepository
from xplan_tools.model.base import BaseCollection
from xplan_tools.model.result.result_report import ResultReport, _ErrorCodes

logger = logging.getLogger(__name__)
logging.getLogger("httpx").propagate = False


async def xplan_validate(
    collection: BaseCollection,
    input: str = "xplan.gml",
    single_plans: bool = False,
    validator_url: str = "https://www.xplanungsplattform.de/xplan-api-validator/xvalidator/api/v1/",
) -> Dict[str, ResultReport]:
    """Validate a Feature Collection with the official XPlanValidator.

    Args:
        collection: A BaseCollection instance.
        input: An optional input file name to use in the validation report.
        single_plans: Whether to validate plans in the collection individually.
        validator_url: The base URL of the XPlanValidator instance. Must have a trailing slash.
    """
    input_path = Path(input)
    report_dict: Dict[str, ResultReport] = {}

    plans = (
        collection.get_single_plans(with_name=True)
        if single_plans
        else [(input_path.stem, collection)]
    )
    async with httpx.AsyncClient(timeout=10) as client:
        for plan_name, plan in plans:
            plan_id = getattr(
                next(
                    filter(
                        lambda value: "_Plan" in value.get_name(),
                        plan.features.values(),
                    )
                ),
                "id",
            )

            headers = {
                "accept": "application/json",
                "x-filename": f"{plan_name}{input_path.suffix}",
                "content-type": "application/gml+xml",
            }
            params = {"name": "report.json"}
            report = ResultReport()
            with io.BytesIO() as buffer:
                GMLRepository(buffer).save_all(plan)
                logger.debug(
                    f"Sending validation request for plan '{plan_name}' to XPlanValidator API @ {validator_url}"
                )
                try:
                    response = await client.post(
                        validator_url + "validate",
                        headers=headers,
                        params=params,
                        content=buffer.getvalue(),
                    )
                    response.raise_for_status()
                except httpx.HTTPError:
                    logger.exception(
                        f"Error while requesting validation for plan '{plan_name}', skipping"
                    )
                    report.add_error(
                        code=_ErrorCodes.ERR_VALIDATION_REQUEST_FAILED,
                        message=f"Error while requesting validation for plan '{plan_name}', skipping",
                        location=plan_name,
                    )
                    continue

            validation_report = from_json(response.content)
            report.evaluate_validation_report(validation_report)
            report_dict[plan_id] = report

    return report_dict


def save_validation_reports(
    report_dict: Dict[str, ResultReport],
    output: str = "report.json",
):
    """Save validation reports to JSON files."""
    if report_dict is None:
        return

    output_path = Path(output)

    for plan_id in report_dict.keys():
        if len(output_path.parents) > 1:
            output_path.parent.mkdir(parents=True, exist_ok=True)
        report_path = str(output_path.parent / f"{output_path.stem}_{plan_id}.json")
        with open(report_path, "wb") as f:
            f.write(to_json(report_dict[plan_id].validation_report, indent=4))
        logger.info(f"Validation report saved as {report_path}")
