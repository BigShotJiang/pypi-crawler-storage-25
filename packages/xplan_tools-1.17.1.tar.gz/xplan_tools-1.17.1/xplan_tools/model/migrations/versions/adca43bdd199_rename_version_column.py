"""Rename version column  to appschema_version.

Revision ID: adca43bdd199
Revises: bb320d6fb682
Create Date: 2026-04-15 16:02:11.028214

"""

from typing import Sequence, Union

from alembic import op

from xplan_tools.settings import get_settings

settings = get_settings()
schema = settings.db_schema

# revision identifiers, used by Alembic.
revision: str = "adca43bdd199"
down_revision: Union[str, Sequence[str], None] = "bb320d6fb682"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.alter_column(
        "coretable",
        "version",
        new_column_name="appschema_version",
        schema=schema,
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.alter_column(
        "coretable",
        "appschema_version",
        new_column_name="version",
        schema=schema,
    )
