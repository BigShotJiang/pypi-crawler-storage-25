"""Fix exponential fan-out for coretable_feature_graph.

With no `depth_limit`, exponential fan-out of nodes can happen under certain circumstance.
However, the appschemas have an inherent limit of 3 edges to reach all related nodes,
which is enforced by this migration.

Revision ID: bb320d6fb682
Revises: f2e9122a3447
Create Date: 2026-03-02 17:21:38.076848

"""

from typing import Sequence, Union

from alembic import op

from xplan_tools.settings import get_settings

# revision identifiers, used by Alembic.
revision: str = "bb320d6fb682"
down_revision: Union[str, Sequence[str], None] = "f2e9122a3447"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

settings = get_settings()
schema = settings.db_schema


def upgrade() -> None:
    """Upgrade schema."""
    op.execute(f"""
        CREATE OR REPLACE
        FUNCTION {schema or "public"}.coretable_feature_graph(
            start_id UUID,
            depth_limit INTEGER DEFAULT 3,
            include_forward BOOLEAN DEFAULT TRUE,
            include_backward BOOLEAN DEFAULT TRUE
        )
        RETURNS SETOF coretable
        LANGUAGE SQL
        PARALLEL SAFE
        STABLE
        AS $$
        WITH RECURSIVE graph_ids(id, depth) AS (
        -- Anchor - start_id
        SELECT id, 0::INTEGER AS depth
        FROM {schema or "public"}.coretable
        WHERE id = start_id
        UNION ALL
        -- Recursive term - traverse forward and/or inverse edges until depth limit is reached
        SELECT
            edge.id,
            g.depth + 1 AS depth
        FROM graph_ids g
        JOIN LATERAL (
            SELECT r.related_id AS id
            FROM {schema or "public"}.refs r
            WHERE include_forward
            AND r.base_id = g.id
            UNION ALL
            SELECT r.base_id AS id
            FROM {schema or "public"}.refs r
            WHERE include_backward
            AND r.related_id = g.id
        ) edge ON TRUE
        WHERE
            g.depth < GREATEST(1, LEAST(depth_limit, 3))
        ) CYCLE id SET is_cycle	USING id_path
        SELECT c.*
        FROM {schema or "public"}.coretable c
        WHERE EXISTS (
            SELECT 1
            FROM graph_ids g
            WHERE NOT g.is_cycle
            AND g.id = c.id
        );

        $$;
    """)


def downgrade() -> None:
    """Downgrade schema."""
    pass
