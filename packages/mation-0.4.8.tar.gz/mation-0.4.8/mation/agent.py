"""Agent abstraction — entry point for multi-agent support (Plan #14 walking skeleton).

This module defines the `Agent` Protocol that mation's daemon and CLI will
talk to once multi-agent support is fully wired up. Plan #11 designed the
full 5-method interface; Plan #14 is a spike that implements **only** the
`last_message()` method to validate the abstraction is buildable.

Concrete implementations live under `mation.agents.*`:
    - `mation.agents.cc.CCAgent` — Claude Code implementation (this plan)
    - (future) `mation.agents.codex.CodexAgent` — OpenAI Codex CLI

Design discrepancy from Plan #11 §3.1 captured in the walking skeleton
report: `AgentMessage.ts` is typed `str | None` here, not `datetime | None`
as originally specced. Reason: the current CC JSONL timestamp format
(`2026-04-09T01:55:03.323Z`) does not round-trip byte-identically through
Python's `datetime.isoformat()` (pads microseconds to 6 digits, rewrites
`Z` to `+00:00`). The `mation read` CLI must stay byte-identical per Plan
#14's acceptance criterion, and preserving the raw source string is the
least invasive way to satisfy both Plan #14 and Plan #11's spirit.
"""

from __future__ import annotations

from typing import Protocol

from pydantic import BaseModel, ConfigDict


class AgentMessage(BaseModel):
    """Single assistant reply from an agent session."""

    model_config = ConfigDict(extra="forbid")

    text: str
    ts: str | None = None
    """Raw ISO8601 timestamp string from the source, preserved verbatim.

    Deliberately `str`, not `datetime`: CC JSONL writes `2026-04-09T01:55:03.323Z`
    but `datetime.fromisoformat(...).isoformat()` round-trips to
    `2026-04-09T01:55:03.323000+00:00` — not byte-identical. Plan #14 accepts
    this field-level deviation from Plan #11 §3.1 so the `mation read` CLI can
    re-emit the timestamp unchanged. Plan #15+ may revisit.
    """

    turn_id: str | None = None
    """Opaque, agent-specific identifier for cross-referencing turns.
    Unused in Plan #14; reserved for future use."""


class Agent(Protocol):
    """Protocol for an AI coding agent that mation orchestrates.

    Plan #14 walking skeleton only implements `last_message()`. The other
    four methods from Plan #11 §3.2 (`status`, `poll_events`, `send`,
    `interrupt`) are intentionally **not** declared here yet — adding them
    as stubs would force every implementation to `NotImplementedError`
    them, which defeats the point of Protocol typing. They will be added
    in subsequent plans once their own walking skeletons pass.
    """

    def last_message(self, session: str) -> AgentMessage | None:
        """Return the most recent assistant reply for `session`, or None.

        None means no retrievable message: session log missing, malformed,
        empty, or no assistant entries yet. Query method — never raises;
        all errors collapse to None. Idempotent and non-consuming.

        `session` is an agent-specific identifier (CC session name or
        UUID, Codex thread_id, etc.). The concrete `Agent` implementation
        interprets it.
        """
        ...
