"""后台守护进程：纯事件接力，不做决策。

两个职责：
1. Stop  — Worker 完成 → 通知 Supervisor
2. Stall — JSONL 心跳停跳（3 分钟无写入）→ 通知 Supervisor

v0.3: 遍历所有 mission 的所有 worker。
"""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import time
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape, quoteattr

from mation import cmux
from mation.state import (
    STATE_DIR,
    append_transcript,
    find_supervisor,
    iter_workers,
    list_tasks,
    load_global,
    load_mission,
    list_missions,
    worker_session_id,
)
from mation.worker import resolve_worker

STATE_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = STATE_DIR / "daemon.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [daemon] %(message)s",
    handlers=[logging.FileHandler(LOG_FILE)],
)
log = logging.getLogger(__name__)

POLL_INTERVAL = 2
MIN_NOTIFY_INTERVAL = 10  # 最小通知间隔，防刷屏
STALL_TIMEOUT = 180  # JSONL 无写入多久后视为 stall（秒）
STALL_MAX_COUNT = 10  # 连续 stall 事件最多发送次数（到达上限后终止自动提醒）


def stop_file(session_id: str) -> Path:
    return STATE_DIR / f"stop-{session_id}"


def _send_to_surface(surface_id: str, message: str) -> None:
    try:
        cmux.send_text(surface_id, message)
    except RuntimeError as e:
        log.error(f"Failed to send to {surface_id}: {e}")


def notify_supervisor(mission: dict[str, Any], message: str) -> None:
    """通知 mission 的 supervisor。claim 缺失或 resolve 失败则丢事件。"""
    mission_name = mission.get("name", "?")
    sup = find_supervisor(mission)
    if not sup:
        # 理论上不可达：主循环已过滤 unclaimed mission。保留作为 defensive guard。
        log.debug(
            "notify_supervisor called on mission %r with no supervisor, dropping: %s",
            mission_name, message[:80],
        )
        return
    info = resolve_worker(sup["session"])
    if not info.running or not info.surface_id:
        log.warning(
            "Supervisor session %r for mission %r not reachable (not found via ps), dropping event",
            sup.get("session"), mission_name,
        )
        return
    # 替换换行符，避免 Escape 打断 Supervisor 正在运行的 generation
    safe_message = message.replace("\n", " ")
    log.info(
        "→ Supervisor[%s] %s: %s",
        mission_name, info.surface_id[:8], safe_message[:120],
    )
    _send_to_surface(info.surface_id, safe_message)


# 每个 (mission, worker) 组合的时间戳追踪
_last_notify: dict[str, float] = {}   # key: "mission:session"
_last_stall: dict[str, float] = {}
# 自治降级状态：连续 stall 计数。stop 到达时清零。
_stall_count: dict[str, int] = {}
# 终态（A0）只发一次，后续不再重复提醒。
_stall_closed: set[str] = set()


def _build_event_xml(
    kind: str,
    attrs: dict[str, str],
    body: str = "",
) -> str:
    """Build a well-formed `<mation event=... ...>body</mation>` element.

    - Attribute values go through `xml.sax.saxutils.quoteattr` (which
      handles both quoting and escaping in one step and returns the value
      already wrapped in quotes).
    - `body` is embedded **as-is**. The caller is responsible for
      constructing valid body content: plain text must already be
      `xml_escape`-d, nested elements must have their own text content
      escaped. The helper does not guess structure.
    - Empty body → self-closing tag `<mation ... />`.

    Returns a single-line XML string (no embedded newlines).
    """
    attr_str = " ".join(f"{k}={quoteattr(v)}" for k, v in attrs.items())
    if attr_str:
        open_tag = f"<mation event={quoteattr(kind)} {attr_str}"
    else:
        open_tag = f"<mation event={quoteattr(kind)}"
    if not body:
        return f"{open_tag}/>"
    return f"{open_tag}>{body}</mation>"


def _format_plan_queue(tasks: list[dict[str, Any]]) -> str:
    """单行 task 队列快照，仅含未完成的 tasks。名字净化后截断 30 字符。"""
    active = [task for task in tasks if task.get("status") != "completed"]
    if not active:
        return "empty"
    parts = []
    for task in active:
        subject = (task.get("subject") or "").replace("\n", " ").replace("\r", " ")[:30]
        parts.append(f"#{task.get('id', '?')}[{task.get('status', '?')}] {subject}")
    return ", ".join(parts)


def _format_stall_msg(
    mission_name: str,
    session: str,
    age: int,
    tasks: list[dict[str, Any]],
    *,
    long_form: bool,
    stall_count: int,
) -> str:
    """构造 stall 事件消息（自治降级 A3→A0）。

    说明：
    - 时间间隔策略不变，仍按 STALL_TIMEOUT 节奏触发。
    - 内容强度按连续 stall 次数升级：A3(1-2) → A2(3-5) → A1(6-9) → A0(=上限)。
    - A0 后由主流程停止继续发送，避免无限重试噪声。
    """
    queue = _format_plan_queue(tasks)

    if stall_count >= STALL_MAX_COUNT:
        body = (
            f"Worker 已空闲 {age // 60} 分钟（stall_count={stall_count}/{STALL_MAX_COUNT}）| queue: {queue} | "
            "已达连续 stall 上限，自动提醒将停止。请人工最终处置："
            "(1) mission 已完成则关闭 "
            "(2) 需继续则人工接管并下达明确指令 "
            "(3) 会话异常则重建 worker/supervisor。"
        )
    elif stall_count >= 6 or long_form:
        body = (
            f"Worker 已空闲 {age // 60} 分钟（stall_count={stall_count}/{STALL_MAX_COUNT}）| queue: {queue} | "
            "风险升高：请立即收敛。先 `supervisor read` 核验证据；"
            "完成则 `task update --status completed` 并推进下一项；"
            "未完成则 `supervisor send` 下发明确返工指令（输入/输出/验收标准）。"
        )
    elif stall_count >= 3:
        body = (
            f"Worker {age}s 无输出（stall_count={stall_count}/{STALL_MAX_COUNT}）| queue: {queue} | "
            "请在本轮内完成闭环：先 `supervisor read` 获取状态；"
            "可独立推进则直接 `supervisor send` 指令；"
            "已满足完成条件则 `task update` 收口。"
        )
    else:
        body = (
            f"Worker {age}s 无输出（stall_count={stall_count}/{STALL_MAX_COUNT}）| queue: {queue} | "
            "先 `supervisor read` 看状态，判断是否卡住。"
            "若出现“需要请示用户”的想法，先反思是否可独立完成；"
            "能独立决策则先推进，再决定是否上报。"
        )

    return _build_event_xml(
        "stall",
        {
            "mission": mission_name,
            "worker": session,
            "silent": f"{age}s",
            "stall_count": str(stall_count),
            "stall_max": str(STALL_MAX_COUNT),
        },
        xml_escape(body),
    )


def _format_stop_msg(mission_name: str, session: str, last_msg: str) -> str:
    """构造 stop 事件消息，含嵌套 `<reply>` 元素。

    `last_msg` 是 Worker 任意文本回复（经常包含 `<`, `>`, `&`, 甚至字面
    `</reply>` / `</mation>` ——review 报告、代码示例、XML 讨论都会命中），
    必须在包进 `<reply>` 前 `xml_escape`。外层标签和属性交给 `_build_event_xml`。
    """
    escaped_reply = xml_escape(last_msg)
    return _build_event_xml(
        "stop",
        {"mission": mission_name, "worker": session},
        f"<reply>{escaped_reply}</reply>",
    )


def _check_worker(
    mission_name: str,
    mission: dict[str, Any],
    worker: dict[str, Any],
) -> None:
    """对一个 worker 做 stop/stall 检测。"""
    session = worker.get("session")
    if not session:
        return

    session_id = worker_session_id(worker)
    if not session_id:
        return

    key = f"{mission_name}:{session}"
    sf = stop_file(session_id)

    if sf.exists():
        try:
            stop_data = json.loads(sf.read_text())
            last_msg = stop_data.get("last_assistant_message", "")
        except (json.JSONDecodeError, OSError):
            last_msg = ""

        sf.unlink(missing_ok=True)
        _last_stall.pop(key, None)
        _stall_count.pop(key, None)
        _stall_closed.discard(key)

        now = time.time()
        last = _last_notify.get(key, 0)
        if now - last < MIN_NOTIFY_INTERVAL:
            log.info("Stop signal consumed, throttled (%.0fs since last notify)", now - last)
        else:
            # Persist Worker→Supervisor reply to transcript before notifying.
            # append_transcript never raises — observability must not break
            # the main event-relay flow.
            append_transcript(
                mission_name,
                direction="worker_to_sup",
                worker=session,
                content=last_msg,
                kind="stop_reply",
            )
            msg = _format_stop_msg(mission_name, session, last_msg)
            notify_supervisor(mission, msg)
            _last_notify[key] = now
            log.info("Stop signal consumed [%s/%s]", mission_name, session)

    else:
        # Stall 检测：JSONL mtime 作为 Worker 活跃心跳
        cache = worker.get("cache") or {}
        jsonl = cache.get("jsonl_path")
        if jsonl:
            jsonl_path = Path(jsonl)
            if jsonl_path.exists():
                mtime = jsonl_path.stat().st_mtime
                now = time.time()
                age = now - mtime
                last_stall = _last_stall.get(key, 0)
                if age > STALL_TIMEOUT and now - last_stall > STALL_TIMEOUT:
                    if key in _stall_closed:
                        _last_stall[key] = now
                        log.info(
                            "JSONL stall suppressed (closed) [%s/%s] (%ds)",
                            mission_name,
                            session,
                            int(age),
                        )
                        return

                    count = _stall_count.get(key, 0) + 1
                    _stall_count[key] = count
                    msg = _format_stall_msg(
                        mission_name,
                        session,
                        int(age),
                        list_tasks(mission_name),
                        long_form=age > STALL_TIMEOUT * 2,
                        stall_count=count,
                    )
                    notify_supervisor(mission, msg)
                    _last_stall[key] = now
                    if count >= STALL_MAX_COUNT:
                        _stall_closed.add(key)
                    log.info(
                        "JSONL stall detected [%s/%s] (%ds) count=%d/%d",
                        mission_name,
                        session,
                        int(age),
                        count,
                        STALL_MAX_COUNT,
                    )


def run_daemon() -> None:
    log.info("Daemon started (pid=%d)", os.getpid())

    for f in STATE_DIR.glob("stop-*"):
        f.unlink(missing_ok=True)
        log.info(f"Cleaned stale signal: {f.name}")

    def handle_signal(signum: int, frame: Any) -> None:
        log.info("Daemon stopping")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    while True:
        try:
            g = load_global()
            if g is None:
                log.info("No active mation, exiting")
                break

            for mission_name in list_missions():
                mission = load_mission(mission_name)
                if mission is None or mission.get("status") == "stopped":
                    continue
                # Unclaimed mission = dormant. 没 supervisor 说明还没 wire 起来，
                # 主动跳过比"跑完再丢弃"更干净，也不留 warning 噪声。
                if not find_supervisor(mission):
                    continue
                for worker in iter_workers(mission):
                    _check_worker(mission_name, mission, worker)

        except Exception as e:
            log.error(f"Daemon error: {e}")

        time.sleep(POLL_INTERVAL)
