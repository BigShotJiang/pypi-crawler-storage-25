"""Mation 状态持久化。

v0.4: Participants 模型
  ~/.mation/global.json            — daemon_pid, stopped
  ~/.mation/missions/<name>.json   — 每个 mission 独立状态
    participants: [{session, role, cache}]  role ∈ {"worker", "supervisor"}

多 mission 场景下所有命令必须显式指定 -m <mission>；不再有 current_mission 全局默认。
"""

from __future__ import annotations

import json
import logging
import re
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

_log = logging.getLogger("mation.state")

STATE_DIR = Path.home() / ".mation"
GLOBAL_FILE = STATE_DIR / "global.json"
MISSIONS_DIR = STATE_DIR / "missions"

_MISSION_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")


def _ensure_dirs() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MISSIONS_DIR.mkdir(parents=True, exist_ok=True)


def _validate_mission_name(name: str) -> None:
    if not _MISSION_NAME_RE.match(name):
        raise ValueError(f"Mission name 不合法: '{name}'（只允许字母、数字、-、_，不能以 -/_ 开头）")


# ── v0.2 迁移 ────────────────────────────────────────────────

def _migrate_v2() -> None:
    """检测 v0.2 active.json 并迁移为 v0.3 格式。"""
    old_file = STATE_DIR / "active.json"
    if not old_file.exists():
        return
    if GLOBAL_FILE.exists():
        # 已经迁移过，清理旧文件
        old_file.unlink()
        return

    old = json.loads(old_file.read_text())
    _ensure_dirs()

    # 提取全局信息（v0.4 起不再存 supervisor_surface）
    global_state = new_global()
    global_state["daemon_pid"] = old.get("daemon_pid")

    # 提取 mission（用 worker_session 或 "default" 作为名字）
    mission_name = old.get("worker_session") or "default"
    # 清理名字中不合法字符
    mission_name = re.sub(r"[^a-zA-Z0-9_-]", "-", mission_name).strip("-") or "default"

    mission = new_mission(mission_name)
    mission["mission_prompt"] = old.get("mission_prompt")

    # 迁移 worker 为 participant(role=worker)
    worker_session = old.get("worker_session")
    if worker_session:
        mission["participants"] = [{
            "session": worker_session,
            "role": "worker",
            "cache": old.get("worker_cache"),
        }]

    save_global(global_state)
    save_mission(mission_name, mission)
    old_file.unlink()


# ── Global ────────────────────────────────────────────────────


def load_global() -> dict[str, Any] | None:
    _migrate_v2()
    if not GLOBAL_FILE.exists():
        return None
    return json.loads(GLOBAL_FILE.read_text())


def save_global(state: dict[str, Any]) -> None:
    _ensure_dirs()
    GLOBAL_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2))


def delete_global() -> None:
    if GLOBAL_FILE.exists():
        GLOBAL_FILE.unlink()


def new_global() -> dict[str, Any]:
    return {
        "daemon_pid": None,
    }


# ── Mission ───────────────────────────────────────────────────


def _mission_file(name: str) -> Path:
    return MISSIONS_DIR / f"{name}.json"


def new_mission(name: str) -> dict[str, Any]:
    return {
        "name": name,
        "status": "active",
        "participants": [],
        "relationships": [],
        "mission_prompt": None,
        "created_at": time.time(),
    }


def _migrate_mission_shape(mission: dict[str, Any]) -> bool:
    """把旧 schema 迁移到当前 participants + relationships 模型。返回是否有迁移。"""
    changed = False

    if "participants" not in mission:
        old = mission.get("workers", [])
        mission["participants"] = [
            {
                "session": w["session"],
                "role": "worker",
                "cache": w.get("cache"),
            }
            for w in old
        ]
        mission.pop("workers", None)
        changed = True
    else:
        for p in mission["participants"]:
            if "reach" in p:
                p.pop("reach")
                changed = True

    if "relationships" not in mission:
        mission["relationships"] = []
        changed = True

    if "plans" in mission:
        mission.pop("plans", None)
        changed = True
    if "next_plan_id" in mission:
        mission.pop("next_plan_id", None)
        changed = True

    return changed


def load_mission(name: str) -> dict[str, Any] | None:
    f = _mission_file(name)
    if not f.exists():
        return None
    mission = json.loads(f.read_text())
    if _migrate_mission_shape(mission):
        save_mission(name, mission)
    return mission


def save_mission(name: str, mission: dict[str, Any]) -> None:
    _ensure_dirs()
    _mission_file(name).write_text(json.dumps(mission, ensure_ascii=False, indent=2))


def delete_mission(name: str) -> bool:
    f = _mission_file(name)
    if not f.exists():
        return False
    f.unlink()
    # 对称于 append_transcript 里的 mkdir：删 mission 时一并清掉
    # per-mission 资源目录（transcript.jsonl 等）。ignore_errors 保证
    # 资源清理失败不会反向破坏主流程（state.json 已经删了）。
    shutil.rmtree(_mission_resource_dir(name), ignore_errors=True)
    return True


def list_missions() -> list[str]:
    """返回所有 mission 名（按文件名排序）。"""
    if not MISSIONS_DIR.exists():
        return []
    return sorted(f.stem for f in MISSIONS_DIR.glob("*.json"))


def create_mission(name: str) -> dict[str, Any]:
    """创建新 mission，如已存在则报错。"""
    _validate_mission_name(name)
    if _mission_file(name).exists():
        raise ValueError(f"Mission '{name}' 已存在")
    mission = new_mission(name)
    save_mission(name, mission)
    return mission


def delete_all() -> None:
    """清除所有状态（global + missions + signal files）。"""
    delete_global()
    if MISSIONS_DIR.exists():
        for f in MISSIONS_DIR.glob("*.json"):
            f.unlink()
            # 对称于 delete_mission：同步清掉 per-mission 资源目录
            # （transcript.jsonl 等）。ignore_errors 保证清理失败不反向破坏
            # 主流程。
            shutil.rmtree(_mission_resource_dir(f.stem), ignore_errors=True)
    for f in STATE_DIR.glob("stop-*"):
        f.unlink()
    # v0.4: submit-* 遗留文件清理（不再使用 UserPromptSubmit hook 确认投递）
    for f in STATE_DIR.glob("submit-*"):
        f.unlink()


# ── Participant & Relationship helpers ──────────────────────
#
# Supervisor 和 Worker 同源：两者都是 CC session，差别只在 role。
# 所有 participant 都通过 `claude --resume <X>` 或 `claude --name <X>` 启动，
# daemon 通知时动态 ps 反查到 PID 再读 cmux env 拿 surface。
#
# Participant = {session, role, cache?}
#   role:  "worker" | "supervisor"
#   cache: 运行时信息（pid/surface_id/jsonl_path），可选
#
# Relationships = [{kind, from, to}]，目前只用 "supervises"：
#   supervisor participant → worker participant
#
# Helpers 保证 role 和 relationships 同步。


def _participants_by_role(mission: dict[str, Any], role: str) -> list[dict[str, Any]]:
    return [p for p in mission.get("participants", []) if p.get("role") == role]


def worker_session_id(worker: dict[str, Any]) -> str | None:
    """从 participant dict 提取 session ID（JSONL 文件名 stem 或 session name）。"""
    cache = worker.get("cache") or {}
    jsonl = cache.get("jsonl_path", "")
    if jsonl:
        return Path(jsonl).stem
    return worker.get("session")


def iter_workers(mission: dict[str, Any]) -> list[dict[str, Any]]:
    """返回 mission 里所有 role=worker 的 participant。"""
    return _participants_by_role(mission, "worker")


def find_worker(mission: dict[str, Any], session: str) -> dict[str, Any] | None:
    return next(
        (p for p in iter_workers(mission) if p.get("session") == session),
        None,
    )


def find_worker_globally(session: str) -> str | None:
    """检查 session 是否已作为 worker 在任何 mission 中，返回 mission name 或 None。"""
    for name in list_missions():
        m = load_mission(name)
        if m and find_worker(m, session):
            return name
    return None


def find_supervisor(mission: dict[str, Any]) -> dict[str, Any] | None:
    """返回 mission 的 supervisor participant（若有）。"""
    return next(iter(_participants_by_role(mission, "supervisor")), None)


def _add_supervises_edge(mission: dict[str, Any], sup_session: str, worker_session: str) -> None:
    rels = mission.setdefault("relationships", [])
    edge = {"kind": "supervises", "from": sup_session, "to": worker_session}
    if edge not in rels:
        rels.append(edge)


def _remove_edges_touching(mission: dict[str, Any], session: str) -> None:
    rels = mission.get("relationships", [])
    mission["relationships"] = [
        e for e in rels if e.get("from") != session and e.get("to") != session
    ]


def add_worker(
    mission: dict[str, Any],
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
) -> dict[str, Any]:
    if find_worker(mission, session):
        raise ValueError(f"Worker '{session}' 已在此 mission 中")
    # 跨 mission 唯一性检查只限 role=worker，supervisor 不受限（允许同 session 在 A 做 worker、B 做 supervisor）
    existing = find_worker_globally(session)
    if existing and existing != mission.get("name"):
        raise ValueError(
            f"Worker '{session}' 已在 mission '{existing}' 中，"
            f"先用 mation {existing} worker remove {session} 移除"
        )
    participant = {
        "session": session,
        "role": "worker",
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "cache": cache,
    }
    mission.setdefault("participants", []).append(participant)
    sup = find_supervisor(mission)
    if sup:
        _add_supervises_edge(mission, sup["session"], session)
    return participant


def remove_worker(mission: dict[str, Any], session: str) -> bool:
    participants = mission.get("participants", [])
    before = len(participants)
    mission["participants"] = [
        p for p in participants
        if not (p.get("role") == "worker" and p.get("session") == session)
    ]
    if len(mission["participants"]) == before:
        return False
    _remove_edges_touching(mission, session)
    return True


def get_sole_worker(mission: dict[str, Any]) -> dict[str, Any] | None:
    """mission 只有一个 worker 时返回它，否则 None。"""
    workers = iter_workers(mission)
    if len(workers) == 1:
        return workers[0]
    return None


def add_supervisor(
    mission: dict[str, Any],
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
) -> dict[str, Any]:
    """添加或覆盖 mission 的 supervisor。mission 只允许一个 supervisor。"""
    mission.setdefault("participants", [])
    old_sup = find_supervisor(mission)
    if old_sup:
        _remove_edges_touching(mission, old_sup["session"])
        mission["participants"] = [
            p for p in mission["participants"] if p.get("role") != "supervisor"
        ]
    participant = {
        "session": session,
        "role": "supervisor",
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "cache": cache,
    }
    mission["participants"].append(participant)
    for w in iter_workers(mission):
        _add_supervises_edge(mission, session, w["session"])
    return participant


def remove_supervisor(mission: dict[str, Any]) -> bool:
    old_sup = find_supervisor(mission)
    if not old_sup:
        return False
    _remove_edges_touching(mission, old_sup["session"])
    mission["participants"] = [
        p for p in mission.get("participants", [])
        if p.get("role") != "supervisor"
    ]
    return True


# ── Task store ────────────────────────────────────────────────


def task_store_dir(mission_id: str) -> Path:
    return STATE_DIR / "mation_id" / "tasks" / mission_id


def task_file(mission_id: str, task_id: str) -> Path:
    return task_store_dir(mission_id) / f"{task_id}.json"


def highwatermark_file(mission_id: str) -> Path:
    return task_store_dir(mission_id) / ".highwatermark"


def lock_file(mission_id: str) -> Path:
    return task_store_dir(mission_id) / ".lock"


def _ensure_task_store(mission_id: str) -> Path:
    task_dir = task_store_dir(mission_id)
    task_dir.mkdir(parents=True, exist_ok=True)
    lf = lock_file(mission_id)
    if not lf.exists():
        lf.write_text("", encoding="utf-8")
    hw = highwatermark_file(mission_id)
    if not hw.exists():
        hw.write_text("0", encoding="utf-8")
    return task_dir


def _task_record(
    *,
    task_id: str,
    subject: str,
    description: str = "",
    status: str = "pending",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "id": task_id,
        "subject": subject,
        "description": description,
        "status": status,
        "owner": owner,
        "blocks": blocks or [],
        "blockedBy": blocked_by or [],
    }


def _write_task(mission_id: str, task: dict[str, Any]) -> None:
    _ensure_task_store(mission_id)
    task_file(mission_id, str(task["id"])).write_text(
        json.dumps(task, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def next_task_id(mission_id: str) -> str:
    _ensure_task_store(mission_id)
    hw = highwatermark_file(mission_id)
    current = int(hw.read_text(encoding="utf-8").strip() or "0")
    new_value = current + 1
    hw.write_text(str(new_value), encoding="utf-8")
    return str(new_value)


def create_task(
    mission_id: str,
    *,
    subject: str,
    description: str = "",
    status: str = "pending",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    task = _task_record(
        task_id=next_task_id(mission_id),
        subject=subject,
        description=description,
        status=status,
        owner=owner,
        blocks=blocks,
        blocked_by=blocked_by,
    )
    _write_task(mission_id, task)
    return task


def get_task(mission_id: str, task_id: str) -> dict[str, Any] | None:
    f = task_file(mission_id, task_id)
    if not f.exists():
        return None
    return json.loads(f.read_text(encoding="utf-8"))


def list_tasks(mission_id: str) -> list[dict[str, Any]]:
    task_dir = task_store_dir(mission_id)
    if not task_dir.exists():
        return []
    tasks = [
        json.loads(task_path.read_text(encoding="utf-8"))
        for task_path in task_dir.glob("*.json")
    ]
    return sorted(tasks, key=lambda task: int(task["id"]))


def update_task(mission_id: str, task_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    task = get_task(mission_id, task_id)
    if task is None:
        raise ValueError(f"Task '{task_id}' 不存在")
    allowed = {"subject", "description", "status", "owner", "blocks", "blockedBy"}
    for key, value in patch.items():
        if key in allowed:
            task[key] = value
    _write_task(mission_id, task)
    return task


def remove_task(mission_id: str, task_id: str) -> bool:
    f = task_file(mission_id, task_id)
    if not f.exists():
        return False
    f.unlink()
    return True


def resolve_content(value: str | None) -> str:
    """解析内容：如果是文件路径则读取文件，否则原样返回。

    CPython 3.12 `Path.is_file()` 没把 ENAMETOOLONG (errno 63) 加进 _ignore_error
    白名单——macOS 单段路径字节 > 255（中文 3 字节，inline 长内容很容易踩）会抛
    OSError 而不是返回 False。CPython 3.14 已修。这里手动兜底。
    """
    if not value:
        return ""
    path = Path(value).expanduser()
    try:
        is_file = path.is_file()
    except OSError:
        is_file = False
    if is_file:
        return path.read_text()
    return value


# ── Transcript (v0.5) ─────────────────────────────────────────
#
# Per-mission supervisor-worker dialogue record, append-only JSONL.
#
#   ~/.mation/missions/<name>.json          # mission state (schema unchanged)
#   ~/.mation/missions/<name>/transcript.jsonl   # dialogue record (new)
#
# Write points:
#   - cli.send / cli.kick   → sup_to_worker, kind=send|kick
#   - daemon stop handler   → worker_to_sup, kind=stop_reply
#
# Observability guarantee: `append_transcript` catches all errors and logs them
# at WARNING. It never raises. The observed system must not be broken by a
# failure to observe it.


Direction = Literal["sup_to_worker", "worker_to_sup"]
Kind = Literal["send", "kick", "stop_reply"]


class TranscriptEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ts: str
    direction: Direction
    worker: str
    content: str
    kind: Kind


def _mission_resource_dir(mission_name: str) -> Path:
    return MISSIONS_DIR / mission_name


def _transcript_file(mission_name: str) -> Path:
    return _mission_resource_dir(mission_name) / "transcript.jsonl"


def _parse_iso_utc(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def append_transcript(
    mission_name: str,
    *,
    direction: str,
    worker: str,
    content: str,
    kind: str,
) -> None:
    """Append one entry to a mission's transcript. Never raises.

    All failures (schema validation, filesystem, encoding) are caught and
    logged. Callers must not rely on successful persistence.
    """
    try:
        entry = TranscriptEntry(
            ts=datetime.now(timezone.utc).isoformat(),
            direction=direction,  # type: ignore[arg-type]
            worker=worker,
            content=content,
            kind=kind,  # type: ignore[arg-type]
        )
        d = _mission_resource_dir(mission_name)
        d.mkdir(parents=True, exist_ok=True)
        with open(_transcript_file(mission_name), "a", encoding="utf-8") as f:
            f.write(entry.model_dump_json() + "\n")
    except Exception as e:
        _log.warning(
            "Failed to append transcript (mission=%s, kind=%s): %s",
            mission_name, kind, e,
        )


def read_transcript(
    mission_name: str,
    *,
    worker: str | None = None,
    tail: int | None = None,
    since: str | None = None,
) -> list[TranscriptEntry]:
    """Return transcript entries oldest-first, with optional filters.

    - worker: keep only entries where `worker` matches
    - since:  keep only entries with ts >= since (ISO8601, tolerant of Z suffix)
    - tail:   keep only the last N entries (applied after worker/since)

    Missing file → []. Malformed lines are skipped silently.
    """
    f = _transcript_file(mission_name)
    if not f.exists():
        return []

    try:
        raw_lines = f.read_text(encoding="utf-8").splitlines()
    except OSError as e:
        _log.warning("Failed to read transcript for %s: %s", mission_name, e)
        return []

    since_dt = _parse_iso_utc(since) if since else None

    entries: list[TranscriptEntry] = []
    for raw in raw_lines:
        if not raw.strip():
            continue
        try:
            entry = TranscriptEntry.model_validate_json(raw)
        except Exception:
            # Partial writes or schema-skew lines are ignored silently.
            continue
        if worker is not None and entry.worker != worker:
            continue
        if since_dt is not None:
            entry_dt = _parse_iso_utc(entry.ts)
            if entry_dt is None or entry_dt < since_dt:
                continue
        entries.append(entry)

    if tail is not None and tail > 0:
        entries = entries[-tail:]
    return entries
