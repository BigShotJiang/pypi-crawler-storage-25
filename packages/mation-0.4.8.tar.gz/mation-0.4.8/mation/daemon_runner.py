"""Daemon 入口点，供 subprocess 调用。"""

from mation.daemon import run_daemon

if __name__ == "__main__":
    run_daemon()
