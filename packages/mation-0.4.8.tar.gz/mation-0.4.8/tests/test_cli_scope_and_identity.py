from pathlib import Path
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from mation import state
from mation.cli import _wait_for_worker_ready, app


runner = CliRunner()

W1 = "11111111-1111-4111-8111-111111111111"
W2 = "11111111-1111-4111-8111-222222222222"
WMISS = "11111111-1111-4111-8111-333333333333"
S1 = "22222222-2222-4222-8222-222222222222"
SMISS = "22222222-2222-4222-8222-333333333333"


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    missions_dir = state_dir / "missions"
    missions_dir.mkdir(parents=True)
    monkeypatch.setattr(state, "STATE_DIR", state_dir)
    monkeypatch.setattr(state, "GLOBAL_FILE", state_dir / "global.json")
    monkeypatch.setattr(state, "MISSIONS_DIR", missions_dir)
    state.save_global(state.new_global())
    return state_dir


def test_root_help_does_not_advertise_mission_flag_scope_fallback() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "MATION_MISSION" not in result.stdout
    assert "-m" not in result.stdout
    assert "--mission" not in result.stdout


def test_mission_scoped_help_uses_path_not_option_scope() -> None:
    result = runner.invoke(app, ["mission-123", "task", "--help"])
    assert result.exit_code == 0
    assert "create" in result.stdout
    assert "update" in result.stdout
    assert "remove" in result.stdout
    assert "list" in result.stdout
    assert "show" in result.stdout
    assert "-m" not in result.stdout
    assert "--mission" not in result.stdout


def test_supervisor_create_help_exposes_name_and_path_only() -> None:
    result = runner.invoke(app, ["mission-123", "supervisor", "create", "--help"])
    assert result.exit_code == 0
    assert "--name" in result.stdout
    assert "--path" in result.stdout
    assert "--session" not in result.stdout


def test_worker_create_help_exposes_name_and_path_only() -> None:
    result = runner.invoke(app, ["mission-123", "worker", "create", "--help"])
    assert result.exit_code == 0
    assert "--name" in result.stdout
    assert "--path" in result.stdout
    assert "--session" not in result.stdout


def test_worker_create_fails_fast_when_path_missing(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(
        app,
        ["mission-123", "worker", "create", "--path", "/tmp/mation-nonexistent-worker-path-xyz"],
    )

    assert result.exit_code == 1
    assert "path 不存在或不是目录" in result.stderr


def test_supervisor_create_fails_fast_when_path_missing(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(
        app,
        ["mission-123", "supervisor", "create", "--path", "/tmp/mation-nonexistent-supervisor-path-xyz"],
    )

    assert result.exit_code == 1
    assert "path 不存在或不是目录" in result.stderr


def test_mission_scoped_help_discoverable_without_mission_id() -> None:
    task_help = runner.invoke(app, ["task", "--help"])
    assert task_help.exit_code == 0
    assert "Usage: mation <mission_id> task" in task_help.stdout
    assert "create" in task_help.stdout

    supervisor_help = runner.invoke(app, ["supervisor", "--help"])
    assert supervisor_help.exit_code == 0
    assert "Usage: mation <mission_id> supervisor" in supervisor_help.stdout
    assert "send" in supervisor_help.stdout

    worker_help = runner.invoke(app, ["worker", "--help"])
    assert worker_help.exit_code == 0
    assert "Usage: mation <mission_id> worker" in worker_help.stdout
    assert "list" in worker_help.stdout


def test_create_help_discoverable_without_mission_id() -> None:
    supervisor_create_help = runner.invoke(app, ["supervisor", "create", "--help"])
    assert supervisor_create_help.exit_code == 0
    assert "Usage: mation <mission_id> supervisor create" in supervisor_create_help.stdout
    assert "--name" in supervisor_create_help.stdout
    assert "--path" in supervisor_create_help.stdout

    worker_create_help = runner.invoke(app, ["worker", "create", "--help"])
    assert worker_create_help.exit_code == 0
    assert "Usage: mation <mission_id> worker create" in worker_create_help.stdout
    assert "--name" in worker_create_help.stdout
    assert "--path" in worker_create_help.stdout


def test_mission_create_uses_mission_id_not_prompt_semantics(isolated_state: Path) -> None:
    result = runner.invoke(app, ["mission", "create", "mission-123"])
    assert result.exit_code == 0

    mission = state.load_mission("mission-123")
    assert mission is not None
    assert mission["name"] == "mission-123"
    assert mission["mission_prompt"] is None



def test_mission_scoped_task_commands_operate_on_path_scope(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    create_result = runner.invoke(app, ["mission-123", "task", "create", "first-task"])
    assert create_result.exit_code == 0
    assert "Task '1'" in create_result.stdout

    list_result = runner.invoke(app, ["mission-123", "task", "list"])
    assert list_result.exit_code == 0
    assert "first-task" in list_result.stdout

    show_result = runner.invoke(app, ["mission-123", "task", "show", "1"])
    assert show_result.exit_code == 0
    assert "first-task" in show_result.stdout


def test_mission_scoped_task_update_and_remove(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    runner.invoke(app, ["mission-123", "task", "create", "first-task"])

    update_result = runner.invoke(
        app,
        [
            "mission-123",
            "task",
            "update",
            "1",
            "--status",
            "in_progress",
            "--owner",
            W1,
            "--description",
            "desc",
        ],
    )
    assert update_result.exit_code == 0

    task = state.get_task("mission-123", "1")
    assert task is not None
    assert task["status"] == "in_progress"
    assert task["owner"] == W1
    assert task["description"] == "desc"

    remove_result = runner.invoke(app, ["mission-123", "task", "remove", "1"])
    assert remove_result.exit_code == 0

    show_result = runner.invoke(app, ["mission-123", "task", "show", "1"])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    list_result = runner.invoke(app, ["mission-123", "task", "list"])
    assert list_result.exit_code == 0
    assert "first-task" not in list_result.stdout


def test_mission_scoped_task_update_requires_id_and_rejects_unknown_field(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    runner.invoke(app, ["mission-123", "task", "create", "first-task"])

    missing_id_result = runner.invoke(app, ["mission-123", "task", "update"])
    assert missing_id_result.exit_code == 2
    assert "Task id is required" in missing_id_result.stderr

    unknown_field_result = runner.invoke(
        app,
        ["mission-123", "task", "update", "1", "--invalid", "x"],
    )
    assert unknown_field_result.exit_code == 2
    assert "No such option '--invalid'" in unknown_field_result.stderr


def test_worker_create_uses_uuid_prompt_contract_and_persists_contract_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    launches: list[tuple[str, str | None, str, str]] = []

    class FakeInfo:
        running = True
        pid = 123
        surface_id = "surface-1"
        jsonl_path = "/tmp/fake.jsonl"
        jsonl_search = None

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt):
        launches.append((session, path, bootstrap_prompt, append_system_prompt))

    monkeypatch.setattr("mation.cli._spawn_claude_session", fake_spawn)
    monkeypatch.setattr("mation.cli._generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr("mation.cli._wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": info.jsonl_path},
    )

    work_path = isolated_state / "work"
    work_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["mission-123", "worker", "create", "--name", "worker-a", "--path", str(work_path)],
    )
    assert result.exit_code == 0

    mission = state.load_mission("mission-123")
    worker = state.find_worker(mission, "11111111-1111-4111-8111-111111111111")
    assert worker is not None
    assert worker["name"] == "worker-a"
    assert worker["path"] == str(work_path)
    assert worker["contract"]["version"] == "v1"
    assert worker["contract"]["kind"] == "worker"
    assert worker["contract"]["applied_via"] == "claude-create"
    assert worker["contract"]["ready_expect"] == "any assistant reply"
    assert "session id: 11111111-1111-4111-8111-111111111111" in worker["contract"]["bootstrap_prompt"]
    assert "Participant id" not in worker["contract"]["bootstrap_prompt"]
    assert str(work_path) not in worker["contract"]["bootstrap_prompt"]
    assert launches == [(
        "11111111-1111-4111-8111-111111111111",
        str(work_path),
        worker["contract"]["bootstrap_prompt"],
        worker["contract"]["append_system_prompt"],
    )]


def test_supervisor_create_uses_uuid_prompt_contract_and_persists_contract_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    launches: list[tuple[str, str | None, str, str]] = []

    class FakeInfo:
        running = True
        pid = 456
        surface_id = "surface-2"
        jsonl_path = "/tmp/sup.jsonl"
        jsonl_search = None

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt):
        launches.append((session, path, bootstrap_prompt, append_system_prompt))

    monkeypatch.setattr("mation.cli._spawn_claude_session", fake_spawn)
    monkeypatch.setattr("mation.cli._generate_session_id", lambda: "22222222-2222-4222-8222-222222222222")
    monkeypatch.setattr("mation.cli._wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": info.jsonl_path},
    )

    sup_path = isolated_state / "sup"
    sup_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["mission-123", "supervisor", "create", "--name", "sup-a", "--path", str(sup_path)],
    )
    assert result.exit_code == 0

    mission = state.load_mission("mission-123")
    supervisor = state.find_supervisor(mission)
    assert supervisor is not None
    assert supervisor["session"] == "22222222-2222-4222-8222-222222222222"
    assert supervisor["name"] == "sup-a"
    assert supervisor["path"] == str(sup_path)
    assert supervisor["contract"]["version"] == "v1"
    assert supervisor["contract"]["kind"] == "supervisor"
    assert supervisor["contract"]["applied_via"] == "claude-create"
    assert supervisor["contract"]["ready_expect"] == "any assistant reply"
    assert "session_id: 22222222-2222-4222-8222-222222222222" in supervisor["contract"]["bootstrap_prompt"]
    assert "Participant id" not in supervisor["contract"]["bootstrap_prompt"]
    assert str(sup_path) not in supervisor["contract"]["bootstrap_prompt"]
    assert launches == [(
        "22222222-2222-4222-8222-222222222222",
        str(sup_path),
        supervisor["contract"]["bootstrap_prompt"],
        supervisor["contract"]["append_system_prompt"],
    )]


def test_wait_for_worker_ready_succeeds_when_ready_arrives_in_later_poll_round(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    info = SimpleNamespace(
        running=True,
        pid=123,
        surface_id="surface-1",
        jsonl_path="/tmp/fake.jsonl",
        jsonl_search=None,
    )
    ready = iter([False] * 12 + [True])
    sleeps: list[float] = []

    monkeypatch.setattr("mation.cli.resolve_worker", lambda session: info)
    monkeypatch.setattr("mation.cli._is_ready_message_present", lambda *args, **kwargs: next(ready))
    monkeypatch.setattr("mation.cli.time.sleep", lambda seconds: sleeps.append(seconds))

    from mation.cli import _wait_for_worker_ready

    result = _wait_for_worker_ready(W1)

    assert result is info
    assert sleeps == [0.2] * 12


def test_worker_create_waits_until_ready_ack_before_persisting(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    states = iter([
        SimpleNamespace(running=False, jsonl_path=None),
        SimpleNamespace(running=True, pid=123, surface_id="surface-1", jsonl_path="/tmp/fake.jsonl", jsonl_search=None),
    ])
    ready = iter([False, False, True])
    sleeps: list[float] = []

    monkeypatch.setattr("mation.cli._spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("mation.cli._generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr("mation.cli.resolve_worker", lambda session: next(states))
    monkeypatch.setattr("mation.cli._is_ready_message_present", lambda *args, **kwargs: next(ready))
    monkeypatch.setattr("mation.cli.time.sleep", lambda seconds: sleeps.append(seconds))
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": info.jsonl_path},
    )

    result = runner.invoke(app, ["mission-123", "worker", "create"])

    assert result.exit_code == 0
    assert sleeps == [0.2, 0.2, 0.2]


def test_worker_create_fails_when_ready_ack_never_arrives(isolated_state: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    monkeypatch.setattr("mation.cli._spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("mation.cli._generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(running=True, pid=123, surface_id="surface-1", jsonl_path="/tmp/fake.jsonl", jsonl_search=None),
    )
    monkeypatch.setattr("mation.cli._is_ready_message_present", lambda *args, **kwargs: False)
    monkeypatch.setattr("mation.cli.time.sleep", lambda seconds: None)

    result = runner.invoke(app, ["mission-123", "worker", "create"])

    assert result.exit_code == 1
    assert "ready" in result.stderr.lower()
    mission = state.load_mission("mission-123")
    assert state.find_worker(mission, "11111111-1111-4111-8111-111111111111") is None


def test_worker_create_succeeds_when_process_exits_but_ready_ack_is_present(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    monkeypatch.setattr("mation.cli._spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("mation.cli._generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(running=False, pid=123, surface_id="surface-1", jsonl_path="/tmp/fake.jsonl", jsonl_search=None),
    )
    monkeypatch.setattr("mation.cli._is_ready_message_present", lambda *args, **kwargs: True)
    monkeypatch.setattr("mation.cli.time.sleep", lambda seconds: None)
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": info.jsonl_path},
    )

    result = runner.invoke(app, ["mission-123", "worker", "create"])

    assert result.exit_code == 0
    mission = state.load_mission("mission-123")
    worker = state.find_worker(mission, "11111111-1111-4111-8111-111111111111")
    assert worker is not None
    assert worker["cache"]["jsonl_path"] == "/tmp/fake.jsonl"


def test_worker_create_rejects_manual_session_id(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(app, ["mission-123", "worker", "create", W1])

    assert result.exit_code == 2
    assert "No such argument" in result.stderr


def test_supervisor_create_rejects_manual_session_id(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(app, ["mission-123", "supervisor", "create", S1])

    assert result.exit_code == 2
    assert "No such argument" in result.stderr


def test_worker_list_show_update_remove_under_mission(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(
        mission,
        W1,
        name="worker-a",
        path="/tmp/work-a",
        cache={"pid": 101, "surface_id": "s1", "jsonl_path": "/tmp/worker-1.jsonl"},
    )
    state.save_mission("mission-123", mission)

    list_result = runner.invoke(app, ["mission-123", "worker", "list"])
    assert list_result.exit_code == 0
    assert W1 in list_result.stdout

    show_result = runner.invoke(app, ["mission-123", "worker", "show", W1])
    assert show_result.exit_code == 0
    assert f'"session": "{W1}"' in show_result.stdout
    assert '"name": "worker-a"' in show_result.stdout
    assert '"path": "/tmp/work-a"' in show_result.stdout
    assert '"role": "worker"' in show_result.stdout

    update_result = runner.invoke(
        app,
        ["mission-123", "worker", "update", W1, "--name", "worker-b", "--path", "/tmp/work-b"],
    )
    assert update_result.exit_code == 0

    mission = state.load_mission("mission-123")
    worker = state.find_worker(mission, W1)
    assert worker is not None
    assert worker["name"] == "worker-b"
    assert worker["path"] == "/tmp/work-b"

    remove_result = runner.invoke(app, ["mission-123", "worker", "remove", W1])
    assert remove_result.exit_code == 0

    list_after_remove = runner.invoke(app, ["mission-123", "worker", "list"])
    assert list_after_remove.exit_code == 0
    assert W1 not in list_after_remove.stdout

    show_after_remove = runner.invoke(app, ["mission-123", "worker", "show", W1])
    assert show_after_remove.exit_code == 1
    assert "不存在" in show_after_remove.stderr


def test_worker_show_update_remove_error_when_target_missing(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    show_result = runner.invoke(app, ["mission-123", "worker", "show", WMISS])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    update_result = runner.invoke(
        app,
        ["mission-123", "worker", "update", WMISS, "--name", "worker-b"],
    )
    assert update_result.exit_code == 1
    assert "不存在" in update_result.stderr

    remove_result = runner.invoke(app, ["mission-123", "worker", "remove", WMISS])
    assert remove_result.exit_code == 1
    assert "不存在" in remove_result.stderr


def test_supervisor_list_show_update_remove_under_mission(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_supervisor(
        mission,
        S1,
        name="sup-a",
        path="/tmp/sup-a",
        cache={"pid": 202, "surface_id": "s2", "jsonl_path": "/tmp/sup-1.jsonl"},
    )
    state.save_mission("mission-123", mission)

    list_result = runner.invoke(app, ["mission-123", "supervisor", "list"])
    assert list_result.exit_code == 0
    assert S1 in list_result.stdout

    show_result = runner.invoke(app, ["mission-123", "supervisor", "show", S1])
    assert show_result.exit_code == 0
    assert f'"session": "{S1}"' in show_result.stdout
    assert '"name": "sup-a"' in show_result.stdout
    assert '"path": "/tmp/sup-a"' in show_result.stdout
    assert '"role": "supervisor"' in show_result.stdout

    update_result = runner.invoke(
        app,
        ["mission-123", "supervisor", "update", S1, "--name", "sup-b", "--path", "/tmp/sup-b"],
    )
    assert update_result.exit_code == 0

    mission = state.load_mission("mission-123")
    supervisor = state.find_supervisor(mission)
    assert supervisor is not None
    assert supervisor["name"] == "sup-b"
    assert supervisor["path"] == "/tmp/sup-b"

    remove_result = runner.invoke(app, ["mission-123", "supervisor", "remove", S1])
    assert remove_result.exit_code == 0

    list_after_remove = runner.invoke(app, ["mission-123", "supervisor", "list"])
    assert list_after_remove.exit_code == 0
    assert S1 not in list_after_remove.stdout

    show_after_remove = runner.invoke(app, ["mission-123", "supervisor", "show", S1])
    assert show_after_remove.exit_code == 1
    assert "不存在" in show_after_remove.stderr


def test_supervisor_show_update_remove_error_when_target_missing(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    show_result = runner.invoke(app, ["mission-123", "supervisor", "show", SMISS])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    update_result = runner.invoke(
        app,
        ["mission-123", "supervisor", "update", SMISS, "--name", "sup-b"],
    )
    assert update_result.exit_code == 1
    assert "不存在" in update_result.stderr

    remove_result = runner.invoke(app, ["mission-123", "supervisor", "remove", SMISS])
    assert remove_result.exit_code == 1
    assert "不存在" in remove_result.stderr


def test_supervisor_read_outputs_last_message_for_explicit_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "surface-1"})
    state.save_mission("mission-123", mission)

    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(
            session=session,
            running=True,
            pid=101,
            surface_id="surface-1",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "mation.cli.CCAgent",
        lambda: SimpleNamespace(last_message=lambda session, **kwargs: SimpleNamespace(text="latest reply")),
    )

    result = runner.invoke(app, ["mission-123", "supervisor", "read", W1])
    assert result.exit_code == 0
    assert "latest reply" in result.stdout


def test_supervisor_send_uses_resolved_worker_surface(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "stale-surface"})
    state.save_mission("mission-123", mission)

    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(
            session=session,
            running=True,
            pid=202,
            surface_id="surface-live",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr("mation.cli.cmux.send_text", lambda surface, text: sent.append((surface, text)))

    result = runner.invoke(app, ["mission-123", "supervisor", "send", W1, "hello worker"])
    assert result.exit_code == 0
    assert sent == [("surface-live", "hello worker")]


def test_supervisor_kick_sends_enter_to_worker_surface(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "surface-1"})
    state.save_mission("mission-123", mission)

    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(
            session=session,
            running=True,
            pid=303,
            surface_id="surface-kick",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": str(info.jsonl_path)},
    )

    keys: list[tuple[str, dict]] = []
    monkeypatch.setattr("mation.cli.cmux.rpc", lambda method, params=None: keys.append((method, params or {})))

    result = runner.invoke(app, ["mission-123", "supervisor", "kick", W1])
    assert result.exit_code == 0
    assert keys == [(
        "surface.send_key",
        {"surface_id": "surface-kick", "key": "Enter"},
    )]


def test_supervisor_send_read_kick_fail_when_worker_missing(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    send_result = runner.invoke(app, ["mission-123", "supervisor", "send", WMISS, "hello"])
    assert send_result.exit_code == 1
    assert "Worker not found in mission" in send_result.stderr

    read_result = runner.invoke(app, ["mission-123", "supervisor", "read", WMISS])
    assert read_result.exit_code == 1
    assert "Worker not found in mission" in read_result.stderr

    kick_result = runner.invoke(app, ["mission-123", "supervisor", "kick", WMISS])
    assert kick_result.exit_code == 1
    assert "Worker not found in mission" in kick_result.stderr


def test_supervisor_send_read_kick_allow_omitting_worker_for_single_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "surface-1"})
    state.save_mission("mission-123", mission)

    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(
            session=session,
            running=True,
            pid=404,
            surface_id="surface-single",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": str(info.jsonl_path)},
    )
    monkeypatch.setattr(
        "mation.cli.CCAgent",
        lambda: SimpleNamespace(last_message=lambda session, **kwargs: SimpleNamespace(text="single latest")),
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr("mation.cli.cmux.send_text", lambda surface, text: sent.append((surface, text)))

    keys: list[tuple[str, dict]] = []
    monkeypatch.setattr("mation.cli.cmux.rpc", lambda method, params=None: keys.append((method, params or {})))

    send_result = runner.invoke(app, ["mission-123", "supervisor", "send", "hello single worker"])
    assert send_result.exit_code == 0
    assert sent == [("surface-single", "hello single worker")]

    read_result = runner.invoke(app, ["mission-123", "supervisor", "read"])
    assert read_result.exit_code == 0
    assert "single latest" in read_result.stdout

    kick_result = runner.invoke(app, ["mission-123", "supervisor", "kick"])
    assert kick_result.exit_code == 0
    assert keys == [(
        "surface.send_key",
        {"surface_id": "surface-single", "key": "Enter"},
    )]


def test_supervisor_send_read_kick_require_worker_for_multi_worker(
    isolated_state: Path,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "surface-1"})
    state.add_worker(mission, W2, cache={"surface_id": "surface-2"})
    state.save_mission("mission-123", mission)

    send_result = runner.invoke(app, ["mission-123", "supervisor", "send", "hello"])
    assert send_result.exit_code == 1
    assert "Multiple workers" in send_result.stderr

    read_result = runner.invoke(app, ["mission-123", "supervisor", "read"])
    assert read_result.exit_code == 1
    assert "Multiple workers" in read_result.stderr

    kick_result = runner.invoke(app, ["mission-123", "supervisor", "kick"])
    assert kick_result.exit_code == 1
    assert "Multiple workers" in kick_result.stderr


def test_worker_id_prefix_unique_match_for_show_update_remove(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, name="worker-a", path="/tmp/work-a", cache={"surface_id": "s1"})
    state.save_mission("mission-123", mission)

    prefix = W1[:8]
    show_result = runner.invoke(app, ["mission-123", "worker", "show", prefix])
    assert show_result.exit_code == 0
    assert W1 in show_result.stdout

    update_result = runner.invoke(app, ["mission-123", "worker", "update", prefix, "--name", "worker-b"])
    assert update_result.exit_code == 0

    remove_result = runner.invoke(app, ["mission-123", "worker", "remove", prefix])
    assert remove_result.exit_code == 0


def test_worker_id_prefix_ambiguous_reports_candidates(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "s1"})
    state.add_worker(mission, W2, cache={"surface_id": "s2"})
    state.save_mission("mission-123", mission)

    result = runner.invoke(app, ["mission-123", "worker", "show", "11111111"])
    assert result.exit_code == 1
    assert "歧义" in result.stderr
    assert W1 in result.stderr
    assert W2 in result.stderr


def test_alias_like_id_is_rejected(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "s1"})
    state.save_mission("mission-123", mission)

    result = runner.invoke(app, ["mission-123", "worker", "show", "alice"])
    assert result.exit_code == 1
    assert "UUID" in result.stderr


def test_supervisor_send_read_kick_consistent_offline_error(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "surface-1"})
    state.save_mission("mission-123", mission)

    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(
            session=session,
            running=False,
            pid=202,
            surface_id="surface-live",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )

    for cmd in (["send", W1, "hello"], ["read", W1], ["kick", W1]):
        result = runner.invoke(app, ["mission-123", "supervisor", *cmd])
        assert result.exit_code == 1
        assert "Worker is offline" in result.stderr


def test_supervisor_send_read_kick_consistent_surface_error(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={})
    state.save_mission("mission-123", mission)

    monkeypatch.setattr(
        "mation.cli.resolve_worker",
        lambda session: SimpleNamespace(
            session=session,
            running=True,
            pid=202,
            surface_id=None,
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "mation.cli.worker_cache_from_info",
        lambda info: {"pid": info.pid, "surface_id": info.surface_id, "jsonl_path": str(info.jsonl_path)},
    )

    for cmd in (["send", W1, "hello"], ["read", W1], ["kick", W1]):
        result = runner.invoke(app, ["mission-123", "supervisor", *cmd])
        assert result.exit_code == 1
        assert "Worker surface unavailable" in result.stderr


def test_task_create_help_does_not_create_task(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(app, ["mission-123", "task", "create", "-h"])
    assert result.exit_code == 0
    assert "Usage: mation <mission_id> task create" in result.stdout

    tasks = state.list_tasks("mission-123")
    assert tasks == []


def test_task_update_help_is_supported(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(app, ["mission-123", "task", "update", "-h"])
    assert result.exit_code == 0
    assert "Usage: mation <mission_id> task update" in result.stdout


def test_supervisor_send_help_does_not_send_message(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    mission = state.load_mission("mission-123")
    state.add_worker(mission, W1, cache={"surface_id": "surface-1"})
    state.save_mission("mission-123", mission)

    result = runner.invoke(app, ["mission-123", "supervisor", "send", "-h"])
    assert result.exit_code == 0
    assert "Usage: mation <mission_id> supervisor send" in result.stdout


def test_supervisor_read_help_is_supported(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(app, ["mission-123", "supervisor", "read", "-h"])
    assert result.exit_code == 0
    assert "Usage: mation <mission_id> supervisor read" in result.stdout


def test_supervisor_kick_help_is_supported(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])

    result = runner.invoke(app, ["mission-123", "supervisor", "kick", "-h"])
    assert result.exit_code == 0
    assert "Usage: mation <mission_id> supervisor kick" in result.stdout


def test_task_update_rejects_removed_and_accepts_deleted(isolated_state: Path) -> None:
    runner.invoke(app, ["mission", "create", "mission-123"])
    runner.invoke(app, ["mission-123", "task", "create", "first-task"])

    removed_result = runner.invoke(
        app,
        ["mission-123", "task", "update", "1", "--status", "removed"],
    )
    assert removed_result.exit_code == 2
    assert "Invalid --status" in removed_result.stderr

    deleted_result = runner.invoke(
        app,
        ["mission-123", "task", "update", "1", "--status", "deleted"],
    )
    assert deleted_result.exit_code == 0
    task = state.get_task("mission-123", "1")
    assert task is not None
    assert task["status"] == "deleted"
