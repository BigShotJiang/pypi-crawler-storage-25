"""Tests for `mation.agents.cc.CCAgent.last_message` (Plan #14 walking skeleton).

These tests exercise the DI hatch (`jsonl_path=` keyword arg) to bypass
`resolve_worker`, which requires cmux env vars and a running CC process
to succeed. The DI hatch is the same path Plan #14 Part 3's my-laptop
realistic test uses — see `mation/agents/cc.py` module docstring.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from mation.agent import AgentMessage
from mation.agents.cc import CCAgent


# ── JSONL fixtures ─────────────────────────────────────────────

_USER_LINE = (
    '{"type": "user", "message": {"role": "user", "content": [{"type": "text", '
    '"text": "what is 2+2"}]}, "timestamp": "2026-04-09T01:55:03.323Z"}'
)

_ASSISTANT_LINE_TEXT = "The answer is 4."
_ASSISTANT_LINE = (
    '{"type": "assistant", "message": {"role": "assistant", "content": '
    '[{"type": "text", "text": "' + _ASSISTANT_LINE_TEXT + '"}]}, '
    '"timestamp": "2026-04-09T01:55:04.557Z"}'
)

_ASSISTANT_LINE_2_TEXT = "Actually, let me reconsider: 2+2=4."
_ASSISTANT_LINE_2 = (
    '{"type": "assistant", "message": {"role": "assistant", "content": '
    '[{"type": "text", "text": "' + _ASSISTANT_LINE_2_TEXT + '"}]}, '
    '"timestamp": "2026-04-09T01:55:06.001Z"}'
)


@pytest.fixture
def jsonl_happy(tmp_path: Path) -> Path:
    """User + assistant + user + assistant — last assistant wins."""
    path = tmp_path / "session.jsonl"
    path.write_text(
        _USER_LINE + "\n" + _ASSISTANT_LINE + "\n"
        + _USER_LINE + "\n" + _ASSISTANT_LINE_2 + "\n",
        encoding="utf-8",
    )
    return path


# ── Cases ──────────────────────────────────────────────────────

def test_last_message_happy_path(jsonl_happy: Path) -> None:
    """Returns the newest assistant reply, not an earlier one."""
    agent = CCAgent()
    msg = agent.last_message("any-session", jsonl_path=jsonl_happy)
    assert msg is not None
    assert isinstance(msg, AgentMessage)
    assert msg.text == _ASSISTANT_LINE_2_TEXT
    assert msg.ts == "2026-04-09T01:55:06.001Z"  # raw string preserved


def test_last_message_preserves_raw_timestamp_string(jsonl_happy: Path) -> None:
    """Plan #14 design discrepancy #1: ts stays the raw source string,
    not a datetime. Verify byte-identity with the JSONL's own field."""
    msg = CCAgent().last_message("any", jsonl_path=jsonl_happy)
    assert msg is not None
    assert msg.ts == "2026-04-09T01:55:06.001Z"
    # Explicit: the `.Z` suffix and fractional-second precision are preserved
    # verbatim (unlike datetime.isoformat which would give `.001000+00:00`).
    assert msg.ts.endswith("Z")


def test_last_message_empty_file_returns_none(tmp_path: Path) -> None:
    empty = tmp_path / "empty.jsonl"
    empty.write_text("", encoding="utf-8")
    assert CCAgent().last_message("any", jsonl_path=empty) is None


def test_last_message_no_assistant_entries_returns_none(tmp_path: Path) -> None:
    """User-only JSONL → no assistant message → None."""
    path = tmp_path / "user-only.jsonl"
    path.write_text(_USER_LINE + "\n" + _USER_LINE + "\n", encoding="utf-8")
    assert CCAgent().last_message("any", jsonl_path=path) is None


def test_last_message_missing_file_returns_none(tmp_path: Path) -> None:
    missing = tmp_path / "nope.jsonl"
    assert CCAgent().last_message("any", jsonl_path=missing) is None


def test_last_message_skips_malformed_lines(tmp_path: Path) -> None:
    """Malformed JSON lines between valid ones must not prevent finding
    the last valid assistant reply."""
    path = tmp_path / "dirty.jsonl"
    path.write_text(
        _USER_LINE + "\n"
        + "{ not json at all\n"
        + _ASSISTANT_LINE + "\n"
        + "\n"   # blank line
        + '{"type": "garbage", "incomplete\n'
        + _ASSISTANT_LINE_2 + "\n",
        encoding="utf-8",
    )
    msg = CCAgent().last_message("any", jsonl_path=path)
    assert msg is not None
    assert msg.text == _ASSISTANT_LINE_2_TEXT


def test_last_message_string_path_accepted(jsonl_happy: Path) -> None:
    """jsonl_path accepts both Path and str (DI hatch convenience)."""
    msg = CCAgent().last_message("any", jsonl_path=str(jsonl_happy))
    assert msg is not None
    assert msg.text == _ASSISTANT_LINE_2_TEXT
