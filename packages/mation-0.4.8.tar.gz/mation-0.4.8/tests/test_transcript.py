"""Tests for mation.state transcript model and helpers (Plan #5)."""

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from mation import state
from mation.state import (
    TranscriptEntry,
    append_transcript,
    create_mission,
    delete_all,
    delete_mission,
    read_transcript,
)


@pytest.fixture
def isolated_missions(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect MISSIONS_DIR + STATE_DIR to an isolated tmp directory."""
    missions = tmp_path / "missions"
    missions.mkdir()
    monkeypatch.setattr(state, "MISSIONS_DIR", missions)
    monkeypatch.setattr(state, "STATE_DIR", tmp_path)
    return missions


# ── Schema ─────────────────────────────────────────────────────

def test_entry_valid() -> None:
    e = TranscriptEntry(
        ts="2026-04-09T11:20:12.003000+00:00",
        direction="sup_to_worker",
        worker="worker-1",
        content="hello",
        kind="send",
    )
    assert e.direction == "sup_to_worker"
    assert e.kind == "send"


def test_entry_rejects_bad_direction() -> None:
    with pytest.raises(ValidationError):
        TranscriptEntry(
            ts="2026-04-09T11:20:12+00:00",
            direction="wrong",  # type: ignore[arg-type]
            worker="w",
            content="c",
            kind="send",
        )


def test_entry_rejects_bad_kind() -> None:
    with pytest.raises(ValidationError):
        TranscriptEntry(
            ts="2026-04-09T11:20:12+00:00",
            direction="sup_to_worker",
            worker="w",
            content="c",
            kind="stall",  # type: ignore[arg-type]
        )


def test_entry_rejects_extra_fields() -> None:
    with pytest.raises(ValidationError):
        TranscriptEntry.model_validate(
            {
                "ts": "2026-04-09T11:20:12+00:00",
                "direction": "sup_to_worker",
                "worker": "w",
                "content": "c",
                "kind": "send",
                "extra": "nope",
            }
        )


# ── append_transcript ─────────────────────────────────────────

def test_append_creates_dir_and_file(isolated_missions: Path) -> None:
    append_transcript(
        "test-mission",
        direction="sup_to_worker",
        worker="worker-1",
        content="hello",
        kind="send",
    )
    path = isolated_missions / "test-mission" / "transcript.jsonl"
    assert path.exists()
    lines = path.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["direction"] == "sup_to_worker"
    assert parsed["worker"] == "worker-1"
    assert parsed["content"] == "hello"
    assert parsed["kind"] == "send"
    # ts is ISO8601 UTC with offset suffix
    assert parsed["ts"].endswith("+00:00")


def test_append_multiple_preserves_order(isolated_missions: Path) -> None:
    for i in range(3):
        append_transcript(
            "m",
            direction="sup_to_worker",
            worker="w",
            content=f"msg-{i}",
            kind="send",
        )
    path = isolated_missions / "m" / "transcript.jsonl"
    contents = [
        json.loads(line)["content"]
        for line in path.read_text(encoding="utf-8").strip().splitlines()
    ]
    assert contents == ["msg-0", "msg-1", "msg-2"]


def test_append_swallows_invalid_direction(isolated_missions: Path) -> None:
    # Pydantic validation fails → helper must swallow, not raise.
    append_transcript(
        "m",
        direction="bogus",
        worker="w",
        content="c",
        kind="send",
    )
    path = isolated_missions / "m" / "transcript.jsonl"
    assert not path.exists()


def test_append_swallows_invalid_kind(isolated_missions: Path) -> None:
    append_transcript(
        "m",
        direction="sup_to_worker",
        worker="w",
        content="c",
        kind="made_up",
    )
    path = isolated_missions / "m" / "transcript.jsonl"
    assert not path.exists()


def test_append_swallows_filesystem_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Point MISSIONS_DIR at a file → mkdir will raise NotADirectoryError.
    blocker = tmp_path / "blocker"
    blocker.write_text("not a dir")
    monkeypatch.setattr(state, "MISSIONS_DIR", blocker)
    # Must not raise.
    append_transcript(
        "m",
        direction="sup_to_worker",
        worker="w",
        content="c",
        kind="send",
    )


def test_append_handles_multibyte_content(isolated_missions: Path) -> None:
    # Chinese + newlines should round-trip through JSONL unmolested.
    append_transcript(
        "m",
        direction="worker_to_sup",
        worker="w",
        content="第一行\n第二行\n包含引号\"和反斜杠\\",
        kind="stop_reply",
    )
    entries = read_transcript("m")
    assert len(entries) == 1
    assert entries[0].content == "第一行\n第二行\n包含引号\"和反斜杠\\"


# ── read_transcript ───────────────────────────────────────────

def test_read_missing_returns_empty(isolated_missions: Path) -> None:
    assert read_transcript("nonexistent") == []


def test_read_returns_oldest_first(isolated_missions: Path) -> None:
    for i in range(3):
        append_transcript(
            "m",
            direction="sup_to_worker",
            worker="w",
            content=f"msg-{i}",
            kind="send",
        )
    entries = read_transcript("m")
    assert [e.content for e in entries] == ["msg-0", "msg-1", "msg-2"]


def test_read_filter_by_worker(isolated_missions: Path) -> None:
    append_transcript("m", direction="sup_to_worker", worker="w1", content="a", kind="send")
    append_transcript("m", direction="sup_to_worker", worker="w2", content="b", kind="send")
    append_transcript("m", direction="sup_to_worker", worker="w1", content="c", kind="send")
    entries = read_transcript("m", worker="w1")
    assert [e.content for e in entries] == ["a", "c"]


def test_read_tail(isolated_missions: Path) -> None:
    for i in range(5):
        append_transcript("m", direction="sup_to_worker", worker="w", content=f"{i}", kind="send")
    entries = read_transcript("m", tail=2)
    assert [e.content for e in entries] == ["3", "4"]


def test_read_tail_zero_returns_all(isolated_missions: Path) -> None:
    # tail=0 should be treated as "no tail limit" (not empty)
    for i in range(3):
        append_transcript("m", direction="sup_to_worker", worker="w", content=f"{i}", kind="send")
    entries = read_transcript("m", tail=0)
    assert len(entries) == 3


def test_read_since_filter(isolated_missions: Path) -> None:
    # Hand-craft a file with known timestamps for deterministic filtering.
    mission_dir = isolated_missions / "m"
    mission_dir.mkdir()
    path = mission_dir / "transcript.jsonl"
    path.write_text(
        '{"ts": "2026-01-01T10:00:00+00:00", "direction": "sup_to_worker", '
        '"worker": "w", "content": "early", "kind": "send"}\n'
        '{"ts": "2026-01-01T12:00:00+00:00", "direction": "sup_to_worker", '
        '"worker": "w", "content": "late", "kind": "send"}\n',
        encoding="utf-8",
    )
    entries = read_transcript("m", since="2026-01-01T11:00:00+00:00")
    assert [e.content for e in entries] == ["late"]


def test_read_since_tolerates_z_suffix(isolated_missions: Path) -> None:
    mission_dir = isolated_missions / "m"
    mission_dir.mkdir()
    path = mission_dir / "transcript.jsonl"
    path.write_text(
        '{"ts": "2026-01-01T10:00:00+00:00", "direction": "sup_to_worker", '
        '"worker": "w", "content": "a", "kind": "send"}\n',
        encoding="utf-8",
    )
    # Z suffix should be normalized to +00:00 by the helper
    entries = read_transcript("m", since="2026-01-01T09:00:00Z")
    assert len(entries) == 1


def test_read_skips_malformed_lines(isolated_missions: Path) -> None:
    mission_dir = isolated_missions / "m"
    mission_dir.mkdir()
    path = mission_dir / "transcript.jsonl"
    path.write_text(
        '{"bad": "json"\n'  # malformed JSON
        '{"ts": "2026-01-01T00:00:00+00:00", "direction": "sup_to_worker", '
        '"worker": "w", "content": "good", "kind": "send"}\n'
        "not json at all\n"
        "\n"  # blank line
        '{"ts": "2026-01-01T00:01:00+00:00", "direction": "worker_to_sup", '
        '"worker": "w", "content": "also good", "kind": "stop_reply"}\n',
        encoding="utf-8",
    )
    entries = read_transcript("m")
    assert [e.content for e in entries] == ["good", "also good"]


def test_read_combined_filters(isolated_missions: Path) -> None:
    append_transcript("m", direction="sup_to_worker", worker="w1", content="a1", kind="send")
    append_transcript("m", direction="sup_to_worker", worker="w2", content="b1", kind="send")
    append_transcript("m", direction="sup_to_worker", worker="w1", content="a2", kind="send")
    append_transcript("m", direction="sup_to_worker", worker="w1", content="a3", kind="send")
    entries = read_transcript("m", worker="w1", tail=2)
    assert [e.content for e in entries] == ["a2", "a3"]


# ── delete_mission cleanup (Plan #6) ──────────────────────────

def test_delete_mission_removes_resource_dir(isolated_missions: Path) -> None:
    # Reproduces the orphan-dir bug fixed in Plan #6:
    # create mission → append transcript → delete → both json and dir gone.
    create_mission("cleanme")
    append_transcript(
        "cleanme",
        direction="sup_to_worker",
        worker="w",
        content="hello",
        kind="send",
    )

    json_file = isolated_missions / "cleanme.json"
    resource_dir = isolated_missions / "cleanme"
    transcript_file = resource_dir / "transcript.jsonl"
    assert json_file.exists()
    assert transcript_file.exists()

    assert delete_mission("cleanme") is True

    assert not json_file.exists()
    assert not resource_dir.exists()


def test_delete_mission_without_resource_dir(isolated_missions: Path) -> None:
    # No transcript ever written — delete must still work, no error.
    create_mission("bare")
    assert (isolated_missions / "bare.json").exists()
    assert not (isolated_missions / "bare").exists()

    assert delete_mission("bare") is True
    assert not (isolated_missions / "bare.json").exists()


def test_delete_missing_mission_returns_false(isolated_missions: Path) -> None:
    # delete_mission on a nonexistent mission is still a no-op returning False,
    # even with the new rmtree step (which should also be a no-op).
    assert delete_mission("ghost") is False


def test_delete_mission_does_not_touch_siblings(isolated_missions: Path) -> None:
    # rmtree must target only the one mission's resource dir, not others.
    create_mission("alpha")
    create_mission("beta")
    append_transcript("alpha", direction="sup_to_worker", worker="w", content="a", kind="send")
    append_transcript("beta", direction="sup_to_worker", worker="w", content="b", kind="send")

    assert delete_mission("alpha") is True

    assert not (isolated_missions / "alpha.json").exists()
    assert not (isolated_missions / "alpha").exists()
    # beta untouched
    assert (isolated_missions / "beta.json").exists()
    assert (isolated_missions / "beta" / "transcript.jsonl").exists()


# ── delete_all cleanup (Plan #7) ──────────────────────────────

def test_delete_all_removes_all_resource_dirs(isolated_missions: Path) -> None:
    # Same orphan-dir symptom as Plan #6, but on the `mation reset` path.
    create_mission("first")
    create_mission("second")
    append_transcript("first", direction="sup_to_worker", worker="w", content="a", kind="send")
    append_transcript("second", direction="worker_to_sup", worker="w", content="b", kind="stop_reply")

    # Preconditions: both json + both resource dirs present
    assert (isolated_missions / "first.json").exists()
    assert (isolated_missions / "second.json").exists()
    assert (isolated_missions / "first" / "transcript.jsonl").exists()
    assert (isolated_missions / "second" / "transcript.jsonl").exists()

    delete_all()

    # Both json gone AND both resource dirs gone
    assert not (isolated_missions / "first.json").exists()
    assert not (isolated_missions / "second.json").exists()
    assert not (isolated_missions / "first").exists()
    assert not (isolated_missions / "second").exists()
