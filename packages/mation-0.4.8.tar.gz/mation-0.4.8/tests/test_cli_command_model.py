from typer.testing import CliRunner

from mation.cli import app


runner = CliRunner()


def combined_output(result) -> str:
    return result.stdout + result.stderr


def test_root_help_exposes_only_self_and_mission() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "self" in result.stdout
    assert "mission" in result.stdout
    assert "Mission-scoped 用法" not in result.stdout
    assert "mation <mission_id> task" not in result.stdout
    assert "plan" not in result.stdout
    assert "prompt" not in result.stdout
    assert "resume" not in result.stdout
    assert "status" not in result.stdout
    assert "transcript" not in result.stdout


def test_version_flags_are_not_routed_as_mission_scope() -> None:
    for flag in ["--version", "-V", "-v"]:
        result = runner.invoke(app, [flag])
        assert result.exit_code == 0
        assert result.stdout.strip() != ""
        assert "requires a scoped command" not in combined_output(result)


def test_self_help_exposes_show_start_stop_reset() -> None:
    result = runner.invoke(app, ["self", "--help"])
    assert result.exit_code == 0
    assert "show" in result.stdout
    assert "start" in result.stdout
    assert "stop" in result.stdout
    assert "reset" in result.stdout
    assert "resume" not in result.stdout
    assert "status" not in result.stdout


def test_mission_help_exposes_new_verbs_and_scoped_help_entrypoints() -> None:
    result = runner.invoke(app, ["mission", "--help"])
    assert result.exit_code == 0
    for command in ["create", "update", "remove", "list", "show", "start", "stop"]:
        assert command in result.stdout
    assert "Mission-scoped 用法" in result.stdout
    assert "mation <mission_id> task ..." in result.stdout
    assert "mation <mission_id> supervisor ..." in result.stdout
    assert "mation <mission_id> worker ..." in result.stdout
    assert "mation mission task -h" in result.stdout
    for command in ["ls", "rm", "pause", "resume", "claim", "unclaim"]:
        assert command not in result.stdout


def test_old_root_commands_fail_fast() -> None:
    for command in ["start", "stop", "resume", "status", "send", "read", "kick", "transcript"]:
        result = runner.invoke(app, [command])
        assert result.exit_code != 0
        assert "No such command" in combined_output(result)


def test_old_mission_commands_fail_fast() -> None:
    for command in ["ls", "rm", "pause", "resume", "claim", "unclaim"]:
        result = runner.invoke(app, ["mission", command])
        assert result.exit_code != 0
        assert "No such command" in combined_output(result)


def test_old_plan_and_prompt_trees_are_removed() -> None:
    for command in ["plan", "prompt"]:
        result = runner.invoke(app, [command, "--help"])
        assert result.exit_code != 0
        assert "No such command" in combined_output(result)


def test_mission_scoped_help_is_queryable_without_mission_id() -> None:
    task_help = runner.invoke(app, ["mission", "task", "--help"])
    assert task_help.exit_code == 0
    assert "Usage: mation <mission_id> task" in task_help.stdout

    supervisor_help = runner.invoke(app, ["mission", "supervisor", "--help"])
    assert supervisor_help.exit_code == 0
    assert "Usage: mation <mission_id> supervisor" in supervisor_help.stdout

    worker_help = runner.invoke(app, ["mission", "worker", "--help"])
    assert worker_help.exit_code == 0
    assert "Usage: mation <mission_id> worker" in worker_help.stdout
