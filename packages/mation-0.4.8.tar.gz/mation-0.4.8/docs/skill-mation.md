---
name: mation
description: mation 使用指南与监督心智模型。仅在“需要解释 mation 用法、建立心智模型、给出监督最佳实践、设计 mission/task/supervisor 工作流”时触发。
allowed-tools: Bash(mation:*)
---

## 启动

!`mation self show 2>&1`

## 双循环模型

### mission 外循环

- 对齐 mission 目标与当前任务队列。
- 若任务耗尽但目标未达成：基于 mission 生成新 task。
- 若目标达成：收口 mission。

### task 内循环

1. `mation <mission_id> task list`
2. `mation <mission_id> supervisor send [worker_id] "..."`
3. `mation <mission_id> supervisor kick [worker_id]`
4. `mation <mission_id> supervisor read [worker_id]`
5. `mation <mission_id> task update <task_id> --status ...`

## stop 事件

1. `mation <mission_id> supervisor read [worker_id]`
2. 完成则：`mation <mission_id> task update <task_id> --status completed`
3. 未完成则：`mation <mission_id> supervisor send [worker_id] "下一步指令"`

## stall 事件

1. `mation <mission_id> supervisor read [worker_id]`
2. 需要推进时：`mation <mission_id> supervisor kick [worker_id]`
3. 必要时：`mation <mission_id> supervisor send [worker_id] "下一步指令"`

## preference

- 主线优先：每轮只推进一件事（派发 / 读取 / 收口）。
- 禁止表演：不要结构化空话，不扩写无关内容。
- 强绑定 mation：所有判断与动作都落到 mission/task/supervisor 命令。
