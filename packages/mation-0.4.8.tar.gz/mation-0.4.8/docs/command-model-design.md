# 命令模型设计 — 草案

**状态**：交互式评审草案。

## 目标

降低 mation CLI 的心智负担，把命令按用户直觉中的主体组织。

核心思路：

- 全局主体只有 `self` 与 `mission`
- `supervisor` 和 `worker` 不是全局主体，而是某个 mission 之下的参与者
- `task` 是某个 mission 之下的运行态任务图节点
- 命令优先表达“主体的增删改查”，其次才是主体之间的关系与运行状态
- `show` 是唯一的详情查看动作，输出应包含当前运行态；不再引入单独的 `status` 动作
- 主文档与帮助信息优先展示完整动词：`list`、`remove`、`update`；不保留兼容别名

## 命令路径模型

```bash
mation self ...
mation mission ...
mation <mission_id> task ...
mation <mission_id> supervisor ...
mation <mission_id> worker ...
```

这套路径的含义是：

- 先通过 `mission` 管理任务本身
- 一旦进入某个 mission，就在该 mission 之下管理 task / supervisor / worker
- 用户不需要额外记 `-m <mission>` 这种外部作用域，因为 mission 已经体现在命令路径里

## 身份模型

为减少“name / session_name / participant.session”混淆，身份应拆成三层：

1. **id**：系统生成的完整 UUID，是主身份，保证唯一。
2. **name**：可选的人类可读显示名，不保证唯一。
3. **session**：运行时会话标识。它就是 `worker_id` / `supervisor_id` 的类型本体；如果底层 Claude / Codex 已生成，则直接复用；如果没有或受 mation 托管，则由 mation 生成。

规则：

- 命令主路径使用 `mission_id` / `task_id` / `worker_id` / `supervisor_id`
- `worker_id` / `supervisor_id` 本质上就是 session id，不额外引入 `--session`
- `task_id` 采用 task 风格的独立编号
- `--name` 只是显示名，不承担身份语义
- 默认流程优先用系统生成 ID，而不是用户手写名字

## 运行参数模型

以下参数不属于身份，而属于运行实例配置：

1. **path**：启动路径。是 `create/update` 的运行参数，不是 participant 身份的一部分；未指定时默认使用当前工作目录。
2. **terminal runtime**：participant 创建到哪个终端环境中，属于运行时承载配置。默认落在当前终端所在的同一个 workspace 中，并优先复用相同 surface；但在命令语义里，真正绑定的是 session，而不是 surface 参数。
3. **role skill injection**：按角色注入的初始协议。当前草案：supervisor 注入身份 + 偏好 + mation 工具 skill；worker 注入被指挥者身份 + 行为约束（例如禁止直接使用 mation 工具）。

## 当前命令 → 新命令映射

| 当前命令 | 新命令 | 说明 |
|---|---|---|
| `mation start` | `mation self start` | 启动 mation daemon / 系统。 |
| `mation stop` | `mation self stop` | 停止/锁住 mation daemon / 系统。 |
| `mation resume` | `mation self start` | 不保留单独的 `resume`；`start` 负责从 stopped 状态恢复。 |
| `mation status` | `mation self show` | `show` 包含 daemon 状态、全局锁状态、mission 概览、stall 事件等。 |
| `mation reset` | `mation self reset` | 重置系统状态。 |
| `mation mission create <name>` | `mation mission create <mission_id>` | 当前实现：创建命令接收 mission_id；prompt 通过 `mission update` 单独设置。 |
| `mation mission show <name>` | `mation mission show <mission_id>` | `show` 默认包含运行态。 |
| `mation mission pause <name>` | `mation mission stop <mission_id>` | 为一致性，把 mission 的 active/paused 表达成 start/stop。 |
| `mation mission resume <name>` | `mation mission start <mission_id>` | 与 `mission stop` 对称。 |
| `mation mission claim <session> -m <mission>` | `mation <mission_id> supervisor create [--name <name>] [--path <path>]` | 自动创建 supervisor Claude session，并作为该 mission 下的参与者。 |
| `mation worker add <session> -m <mission>` | `mation <mission_id> worker create [--name <name>] [--path <path>]` | 自动创建 worker Claude session，并作为该 mission 下的参与者。 |
| `mation worker rm <session> -m <mission>` | `mation <mission_id> worker remove <worker_id>` | 删除 mission 下的 worker。 |
| `mation send "..." -m <mission>` | `mation <mission_id> supervisor send <worker_id> "..."` | `send` 属于 supervisor 管 worker 的动作；单 worker 场景可省略 `worker_id`。 |
| `mation read -m <mission>` | `mation <mission_id> supervisor read <worker_id>` | `read` 属于 supervisor 读取 worker 最新回复；单 worker 场景可省略 `worker_id`。 |
| `mation kick -m <mission>` | `mation <mission_id> supervisor kick <worker_id>` | `kick` 属于 supervisor 对 worker 的控制动作；单 worker 场景可省略 `worker_id`。 |
| `mation transcript -m <mission>` | 并入只读视图，不保留独立命令 | 完整监督对话记录作为 `show` 或 debug/internal 能力存在，不再单独暴露。 |
| `mation plan add "..." -c <file> -m <mission>` | `mation <mission_id> task create <subject>` | 运行态 plan 统一收敛为 mission 下的 task。 |
| `mation plan done <id> -m <mission>` | `mation <mission_id> task update <task_id> --status completed` | 状态更新对齐 Task 心智。 |
| `mation prompt set <file> -m <mission>` | `mation mission update <mission_id> <prompt>` | mission 的本体是 prompt；`@file` 只是 prompt 输入语法，不是领域概念。 |

## 建议命令树

```bash
mation self show
mation self start
mation self stop
mation self reset
```

```bash
mation mission create <mission_id>
mation mission update <mission_id> <prompt>
mation mission remove <mission_id>
mation mission list
mation mission show <mission_id>
mation mission start <mission_id>
mation mission stop <mission_id>
```

```bash
mation <mission_id> task create <subject>
mation <mission_id> task update <task_id>
mation <mission_id> task remove <task_id>
mation <mission_id> task list
mation <mission_id> task show <task_id>
```

```bash
mation <mission_id> supervisor create [--name <name>] [--path <path>]
mation <mission_id> supervisor update <supervisor_id> [--name <name>] [--path <path>]
mation <mission_id> supervisor remove <supervisor_id>
mation <mission_id> supervisor list
mation <mission_id> supervisor show <supervisor_id>
mation <mission_id> supervisor send [worker_id] "..."
mation <mission_id> supervisor read [worker_id]
mation <mission_id> supervisor kick [worker_id]
```

```bash
mation <mission_id> worker create [--name <name>] [--path <path>]
mation <mission_id> worker update <worker_id> [--name <name>] [--path <path>]
mation <mission_id> worker remove <worker_id>
mation <mission_id> worker list
mation <mission_id> worker show <worker_id>
```

## Task 模型

mission 下的 task 直接克隆 Task 心智，而不是单独设计一套新的 plan 概念。

### CLI 参数

task 的 CLI 参数直接对齐 Task：

- `subject`
- `description`
- `status`
- `owner`
- `blocks`
- `blockedBy`

不主动暴露额外的 `verify` 参数。校验作为默认校验、后台校验或 supervisor 审视流程的一部分存在，而不是 task 主 schema 字段。

### 存储

task 的本地存储参考 Task：

```text
<mation task dir>/<mission_id>/
  .lock
  .highwatermark
  1.json
  2.json
  3.json
```

即：

- 一个 mission 对应一个 task 目录
- 每个 task 一个 JSON 文件
- `.highwatermark` 负责分配新 id
- `.lock` 负责修改时的互斥

### 单个 task 文件示例

```json
{
  "id": "1",
  "subject": "实现 CCAgent.status",
  "description": "为 CCAgent 增加 status 查询能力……",
  "status": "pending",
  "owner": "",
  "blocks": [],
  "blockedBy": []
}
```

## 一致性原则

### 1. 主体的增删改查一致

对 `mission / task / supervisor / worker`，优先使用统一动作：

- `create`
- `update`
- `remove`
- `list`
- `show`

### 2. 主体的状态变更一致

只有 `mission` 是任务状态机，因此只有 mission 暴露：

- `start`
- `stop`

因此：

- `mission` 不保留 `resume`
- `mission` 不保留 `pause`
- 不引入单独的 `status`
- `supervisor / worker` 不暴露 `start/stop`；它们不是任务状态机，而是 mission 下的参与者实例
- `task` 的运行状态通过 `update --status ...` 修改，而不是另造一套动词

### 3. 关系优先内化到路径里

不优先暴露 `connect / disconnect`。

原因：

- supervisor / worker 本身就在 mission 路径之下
- `mation <mission_id> worker create` 已天然表达“创建并属于这个 mission”
- 只有在“已有主体迁移到另一个 mission”这类专家场景时，才需要单独的连接命令

### 4. 输入载体不进入命令语义

当前实现把 mission 身份与 mission prompt 分离：

- `mission create` 负责创建 `<mission_id>`
- `mission update` 负责更新 `<prompt>`
- prompt 可以是 inline 文本或文件路径；文件路径在读取时解析
- 不把 `<file>` 写成领域对象

## 已确认结论

1. `mation self start` 完全替代 `mation self resume`。
2. `mission start/stop` 覆盖 `pause/resume`。
3. session 是需要暴露的身份本体，但不单独作为额外参数；`worker_id` / `supervisor_id` 即 session id。
4. `send/read/kick` 归属 `supervisor`，是 supervisor 管 worker 的动作。
5. `supervisor / worker create` 自动生成完整 UUID session id；`--name` 只是显示名。
6. `supervisor / worker create` 直接使用 Claude 原生启动参数：bootstrap `prompt`、`--session-id <uuid>`、`--append-system-prompt <contract>`。
7. `supervisor / worker create` 默认落在当前终端所在的同一个 workspace 中；`--path` 仅控制启动目录，不进入 prompt。surface 不是绑定参数，真正绑定的是 session。
8. `supervisor / worker create` 的 v1 contract 以内置常量实现：supervisor 注入监督者约束；worker 注入执行者约束；create 成功标准包含固定 ready 回执。
7. `worker show` 只展示 worker 对象详情；`supervisor show` 只展示 supervisor 对象详情；`supervisor read` 用于读取最新监督消息。完整监督对话记录不再保留独立 `transcript` 主命令，而是下沉到 debug/internal 只读视图。
8. mission 下的运行态 `plan` 改名为 `task`；CLI 参数对齐 Task，存储参考 Task。当前实现已移除旧 plan 命令树。
9. `task` 不主动暴露额外的 `verify` 参数；校验作为默认校验、后台校验与 supervisor 审视流程的一部分存在。

## 待后续讨论

当前命令模型已基本收敛，暂无必须继续讨论的开放项。
