import base64
import hashlib
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


class SecurityCrypto:
    """
    通用安全加密工具类（等保三级合规）

    核心功能：
    1. 基于 PBKDF2-HMAC-SHA256 算法生成不可逆哈希，用于用户密码、敏感数据摘要存储
    2. 基于 AES-256 算法实现对称加解密，用于个人身份信息（姓名、手机号、身份证、邮箱等）加密保护

    设计特点：
    - 哈希算法：慢哈希、抗暴力破解、随机盐、无输入长度限制
    - 加密算法：标准 AES-256 加密，支持任意长度字符串加解密
    - 密钥体系：主密钥 + 盐值双重固定密钥，确保加解密一致性
    - 全流程兼容中文、英文、特殊符号，UTF-8 编码保证跨平台稳定
    """
    # ====================== ✅ 修改位置 1：新增固定盐，专门用于查询检索 ======================
    QUERY_SALT = "上兵伐谋".encode("utf-8")

    def __init__(self, key_salt: str, master_password: str):
        """
        初始化 AES 加密与哈希验证核心工具类
        注意：密钥配置一旦设定，严禁修改，否则已加密数据将永久无法解密

        :param key_salt: 密钥派生盐值（字符串类型，支持汉字/英文/数字）
                         作用：参与生成 AES 密钥，全局固定不变
                         字符串长度不限，但是最好不要太长容易，自己容易记住
        :param master_password: AES 主密钥密码（字符串类型，支持汉字/英文/数字）
                                作用：加密体系核心密钥，全局固定不变
                                字符串长度不限，但是最好不要太长容易，自己容易记住
        """
        self._key_salt = key_salt.strip().encode("utf-8")
        self._master_password = master_password.strip().encode("utf-8")
        self._aes_key = self._generate_aes_key()
        self._fernet = Fernet(self._aes_key)

    def _generate_aes_key(self):
        """
        私有方法：基于固定盐与主密码生成AES-256密钥
        :return: 可直接用于Fernet的AES密钥
        """
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=self._key_salt,
            iterations=480000,
        )
        return base64.urlsafe_b64encode(kdf.derive(self._master_password))

    def generate_hash(self, text: str, salt_length: int = 16, hash_name="sha256", iterations: int = 310000):
        """
        传入的text长度不受限制
        生成不可逆哈希值（等保合规：PBKDF2-HMAC-SHA256 慢哈希）
        适用场景：用户密码存储、敏感数据摘要、防篡改验证

        函数内部参数说明：
        1. hash_name="sha256"
           - 哈希算法名称，可选值：sha1、sha224、sha256、sha384、sha512、md5
           - sha256：等保推荐、行业标准、安全高效
           - sha384: 安全，但更长；sha512: 最高安全，输出更长
           - md5/sha1：已破解，禁止使用

        2. text.encode("utf-8")
           - 将字符串转为字节流，哈希函数只支持bytes类型
           - 编码固定使用utf-8，支持全球语言（中文/英文/符号）
           - 不建议改为gbk，会导致跨平台乱码、哈希结果不一致

        3. salt = os.urandom(salt_length)
           - 生成系统级安全随机盐，每个哈希值使用独立盐
           - salt_length=16：16字节=128位，符合等保、NIST、OWASP安全标准
           - 数字越小安全性越低，数字越大越安全但存储体积略增

        4. iterations=迭代次数
           - PBKDF2 哈希迭代次数，次数越高计算越慢，抗暴力破解能力越强
           - 310000：企业标准、等保合规
           - 500000：更高安全级别，可根据性能需求调整
           - 最小不可低于100000

        存储格式：迭代次数$base64盐$base64哈希值
        """
        if not text.strip():
            return None

        salt = os.urandom(salt_length)
        hash_result = hashlib.pbkdf2_hmac(
            hash_name=hash_name,
            password=text.strip().encode("utf-8"),
            salt=salt,
            iterations=iterations
        )
        return f"{iterations}${base64.b64encode(salt).decode()}${base64.b64encode(hash_result).decode()}"

    def verify_hash(self, plain_text: str, hash_str: str, hash_name="sha256"):
        """
        验证原文与哈希值是否匹配
        :param plain_text: 待验证的明文文本
        :param hash_str: 已存储的哈希字符串
        :param hash_name: 哈希算法名称，必须与生成哈希时的本类中generate_hash中hash_name保持一致，否则验证失败。
        :return: 0=验证成功  1=明文与哈希不匹配  2=哈希格式非法/验证异常
        """
        try:
            iter_str, salt_b64, expected_b64 = hash_str.split("$")
            iterations = int(iter_str)
            salt = base64.b64decode(salt_b64)
            expected_hash = base64.b64decode(expected_b64)

            computed_hash = hashlib.pbkdf2_hmac(
                hash_name,
                plain_text.strip().encode("utf-8"),
                salt,
                iterations
            )
            return 0 if computed_hash == expected_hash else 1

        except Exception:
            return 2

    # ====================== ✅ 修改位置 2：新增【数据库检索专用哈希】函数 ======================
    def generate_query_hash(self, text: str):
        """
        数据库查询专用：固定盐哈希，相同明文永远输出相同哈希
        用于：WHERE name_hash = ?  精确查询
        不用于解密，只用于检索
        """
        if not text.strip():
            return None
        data = text.strip().encode("utf-8")
        return hashlib.sha256(self.QUERY_SALT + data).hexdigest()

    def encrypt(self, plain_text: str):
        """
        AES-256 对称加密（适用于个人敏感信息：姓名、手机号、身份证、邮箱等）
        :param plain_text: 明文内容，字符串长度不限
        :return: 加密后的字符串
        """
        if not plain_text.strip():
            return None
        return self._fernet.encrypt(plain_text.strip().encode("utf-8")).decode("utf-8")

    def decrypt(self, encrypted_text: str):
        """
        AES-256 对称解密
        :param encrypted_text: AES加密后的密文
        :return: 解密后的明文 / None（解密失败）
        """
        if not encrypted_text.strip():
            return None
        try:
            return self._fernet.decrypt(encrypted_text.strip().encode("utf-8")).decode("utf-8")
        except Exception:
            return None


# ====================== 测试 ======================
if __name__ == '__main__':
    # 全局实例
    security_crypto = SecurityCrypto(" 一朝红日出 ", " 依旧与天齐 ")
    # 原功能：密码哈希（不变）
    h = security_crypto.generate_hash("123456")
    print("哈希:", h, "长度：", len(h))
    print("验证:", security_crypto.verify_hash("123456", h))

    # 原功能：AES加解密（不变）
    enc = security_crypto.encrypt("17550629195")
    print("AES加密:", enc)
    print("AES解密:", security_crypto.decrypt(enc))

    print("\n" + "=" * 50)
    # ====================== ✅ 修改位置 3：演示双字段存储（查询用） ======================
    name = "00"

    # 1. 查询用哈希（固定盐，永远不变）
    name_query_hash = security_crypto.generate_query_hash(name)
    # 2. 存储用AES加密（随机IV，每次不同）
    name_aes_encrypt = security_crypto.encrypt(name)

    print("姓名明文：", name)
    print("数据库查询哈希(name_hash)：", name_query_hash)
    print("数据库AES加密存储(name_aes)：", name_aes_encrypt)

    # 模拟：根据姓名查询
    input_name = "张三"
    input_hash = security_crypto.generate_query_hash(input_name)
    input_hash2 = security_crypto.generate_query_hash(input_name)


    print("\n【查询】输入姓名生成哈希：", input_hash)
    print("WHERE name_hash = '", input_hash, "'  可以精准查到！")
    print(input_hash2)
