"""``aferiq-trace-run`` — wrapper command that auto-instruments OpenAI/Anthropic
SDKs before running a target Python script.

Usage:
    aferiq-trace-run python my_agent.py [args...]
    aferiq-trace-run my_agent.py [args...]            # python implicit
    AFERIQ_AUTO_INSTRUMENT=1 python my_agent.py       # env-var mode (uses .pth)

The wrapper:
  1. Calls ``patch_openai()`` and ``patch_anthropic()`` to install monkey
     patches on the respective SDKs (idempotent — safe even if neither is
     installed).
  2. Hands control to the target script via ``runpy.run_path``.

Captured data only flows when a trajectory is active (i.e. when an
integration like LangGraph callback or AgentExecutor wraps the run with
``start_trajectory`` / ``end_trajectory``). Outside a trajectory the patches
are no-ops, so ``aferiq-trace-run`` is safe to leave on by default.
"""

from __future__ import annotations

import os
import runpy
import sys
from typing import NoReturn


def main() -> NoReturn:
    args = sys.argv[1:]
    if not args:
        _print_usage_and_exit("aferiq-trace-run: missing command")

    # Strip optional leading "python" / "python3" — convention is for users to
    # write `aferiq-trace-run python my_agent.py` (mirrors `ddtrace-run python ...`).
    if args[0] in ("python", "python3", sys.executable):
        args = args[1:]
        if not args:
            _print_usage_and_exit("aferiq-trace-run: missing target script after python")

    target = args[0]
    if not os.path.exists(target) and not target.startswith("-"):
        _print_usage_and_exit(f"aferiq-trace-run: target not found: {target}")

    _install_patches()

    # Mirror `python script.py`: the script's own directory must be importable
    # so local imports (`from tools import ...`, `from utils import ...`) work.
    # runpy.run_path does NOT add it for us, so without this aferiq-trace-run
    # breaks scripts that run fine when invoked directly.
    if not target.startswith("-"):
        target_dir = os.path.dirname(os.path.abspath(target))
        if target_dir not in sys.path:
            sys.path.insert(0, target_dir)

    # Hand off argv to the target script as if it were invoked directly.
    sys.argv = args
    try:
        runpy.run_path(target, run_name="__main__")
    except SystemExit as e:
        # Preserve target's exit code.
        raise SystemExit(e.code) from None
    sys.exit(0)


def _install_patches() -> None:
    """Activate all available SDK patches. Each patch silently no-ops if its
    target SDK isn't installed — running aferiq-trace-run in a project that
    only uses OpenAI is fine even if anthropic isn't available."""
    from rageval.integrations.anthropic_patch import patch_anthropic
    from rageval.integrations.openai_patch import patch_openai

    patch_openai()
    patch_anthropic()


def _print_usage_and_exit(msg: str) -> NoReturn:
    print(msg, file=sys.stderr)
    print(
        "\nUsage:\n"
        "  aferiq-trace-run python my_agent.py [args...]\n"
        "  aferiq-trace-run my_agent.py [args...]\n",
        file=sys.stderr,
    )
    sys.exit(2)


if __name__ == "__main__":
    main()
