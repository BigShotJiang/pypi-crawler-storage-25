"""``aferiq doctor`` — diagnose why traces aren't showing up.

The most common support question for any tracing SDK is "I connected but
I don't see anything." This command answers it end-to-end from the dev's
terminal:

  1. Is the config present? (AFERIQ_DSN or AFERIQ_API_KEY + AFERIQ_INGEST_URL)
  2. Does it parse, and is the key not a placeholder?
  3. Is the endpoint reachable? (HEAD probe)
  4. Which LLM/framework SDKs are installed + patchable?
  5. Can we actually deliver a trace? (sends a real test trace, expects 200)

Each check prints ✓ / ✗ with an actionable next step. Exit code 0 only when
a test trace was accepted — so it's CI-friendly too.
"""

from __future__ import annotations

import importlib.util
import json
import os

import httpx

from rageval.cloud import _parse_dsn, _probe_ingest

OK = "✓"
BAD = "✗"
WARN = "!"


def _resolve_config() -> tuple[str, str, str]:
    """Return (api_key, ingest_url, source) from env, '' when missing."""
    dsn = os.getenv("AFERIQ_DSN", "")
    if dsn:
        try:
            key, url = _parse_dsn(dsn)
            return key, url, "AFERIQ_DSN"
        except ValueError:
            return "", "", "AFERIQ_DSN (invalid)"
    key = os.getenv("AFERIQ_API_KEY", "")
    url = os.getenv("AFERIQ_INGEST_URL", "")
    return key, url, "AFERIQ_API_KEY + AFERIQ_INGEST_URL"


def _detect_sdks() -> dict[str, bool]:
    """Which integration SDKs are importable in this environment."""
    names = ["openai", "anthropic", "langchain_core", "llama_index", "langgraph"]
    return {n: importlib.util.find_spec(n) is not None for n in names}


def _send_test_trace(api_key: str, ingest_url: str, timeout: float = 8.0) -> tuple[bool, str]:
    """POST a tiny test trace; return (ok, human-readable status)."""
    payload = {
        "query": "aferiq doctor: test trace",
        "context": ["diagnostic"],
        "answer": "ok",
        "metadata": {"source": "aferiq-doctor"},
        "language": "pt",
    }
    try:
        resp = httpx.post(
            ingest_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            content=json.dumps(payload),
            timeout=timeout,
        )
    except httpx.ConnectError:
        return False, "connection refused (DNS or network down)"
    except httpx.TimeoutException:
        return False, f"timeout after {timeout}s"
    except Exception as exc:  # noqa: BLE001
        return False, f"error: {type(exc).__name__}"

    if resp.status_code == 200:
        return True, "200 OK — trace accepted (check the dashboard)"
    if resp.status_code == 401:
        return False, "401 — key invalid or revoked (generate a new one)"
    if resp.status_code == 404:
        return False, "404 — endpoint not found (check the ingest URL)"
    return False, f"{resp.status_code} — {resp.text[:120]}"


def run_doctor(send_test: bool = True) -> int:
    """Run all checks, print a report, return an exit code (0 = healthy)."""
    print("aferiq doctor — diagnosing your connection\n")

    api_key, ingest_url, source = _resolve_config()

    # 1. Config present?
    if not api_key or not ingest_url:
        print(f"{BAD} config: not found ({source})")
        print("    → Set AFERIQ_DSN=https://rg_pk_live_xxx@aferiq.com.br/api/v1/traces")
        print("      (or AFERIQ_API_KEY + AFERIQ_INGEST_URL) in your .env, then re-run.")
        return 1
    print(f"{OK} config: found via {source}")
    print(f"    endpoint: {ingest_url}")

    # 2. Placeholder key?
    if api_key.startswith("rg_pk_live_<") or "<COLE" in api_key.upper() or "xxx" in api_key:
        print(f"{BAD} key: looks like a placeholder ({api_key[:16]}…)")
        print("    → Paste the real key from /dashboard/api-keys.")
        return 1
    print(f"{OK} key: present ({api_key[:11]}…)")

    # 3. Endpoint reachable?
    probe = _probe_ingest(api_key, ingest_url, timeout=8.0)
    reachable = probe.startswith(("200", "405"))
    print(f"{OK if reachable else WARN} endpoint probe: {probe}")

    # 4. SDKs installed
    sdks = _detect_sdks()
    installed = [n for n, ok in sdks.items() if ok]
    print(f"{OK if installed else WARN} SDKs detected: {', '.join(installed) or 'none'}")
    if sdks.get("openai") or sdks.get("anthropic"):
        print("    → import openai/anthropic BEFORE aferiq.start() so it can patch them.")

    # 5. Deliver a real test trace
    if not send_test:
        print(f"\n{WARN} skipped test-trace delivery (--no-send)")
        return 0
    ok, status = _send_test_trace(api_key, ingest_url)
    print(f"{OK if ok else BAD} test trace: {status}")

    if ok:
        print("\n✓ Healthy. If the dashboard is still empty, check you're looking at")
        print("  the right project and time range.")
        return 0
    print("\n✗ A test trace could not be delivered — fix the failing check above.")
    return 1
