"""Monkey-patch OpenAI's ``chat.completions.create`` to capture tokens + latency.

Activated by ``aferiq-trace-run`` (or the env-var-only mode). When an OpenAI
chat completion fires inside an active trajectory (see ``_context``), we
record an ``AgentStep`` of type ``llm`` with the response's prompt/completion
tokens and the wall-clock latency.

Outside a trajectory the call is untouched — no overhead beyond a single
ContextVar read.

Supports both:
  - openai >= 1.0 (current): ``client.chat.completions.create(...)``
  - openai >= 1.0 async:     ``await client.chat.completions.create(...)``

Legacy ``openai.ChatCompletion.create`` (openai < 1.0) is NOT supported —
that SDK is deprecated and barely used in 2026.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from rageval.integrations._context import has_active_trajectory, record_step

_log = logging.getLogger(__name__)
_patched = False


def patch_openai(*, emit_standalone: bool = False) -> bool:
    """Install the patch. Idempotent — calling twice is a no-op.

    Two modes:

    - **Trajectory mode** (default): when ``chat.completions.create`` fires
      inside an active ``@aferiq.trace`` function, the call is recorded as
      an ``AgentStep`` of the parent trajectory. Outside a trajectory the
      call is untouched — zero overhead, zero traces.

    - **Standalone mode** (``emit_standalone=True``, used by
      ``aferiq.start()``): same as trajectory mode AND additionally
      emits a standalone ``EvalSample`` (query=last user message,
      context=[], answer=response content) for every bare LLM call
      outside a trajectory. This makes the "1-line auto-capture every
      call" promise actually work.

    Args:
        emit_standalone: emit traces for bare LLM calls outside any
            ``@aferiq.trace`` function. Default ``False`` for backwards
            compat. ``aferiq.start()`` sets this to ``True`` automatically.

    Returns True if patched, False if openai is not importable (silent skip).
    """
    global _patched
    if _patched:
        return True
    try:
        from openai.resources.chat import (
            AsyncCompletions,
            Completions,
        )
        from openai.resources.chat import completions as _completions  # noqa: F401
    except ImportError:
        _log.debug("openai SDK not installed; patch skipped")
        return False

    _patch_sync(Completions, emit_standalone)
    _patch_async(AsyncCompletions, emit_standalone)

    _patched = True
    return True


def _patch_sync(Completions: Any, emit_standalone: bool) -> None:  # noqa: N803  -- mirrors openai SDK class name
    if getattr(Completions.create, "_aferiq_patched", False):
        return
    original = Completions.create

    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        in_traj = has_active_trajectory()
        if not in_traj and not emit_standalone:
            return original(self, *args, **kwargs)  # nothing to capture

        # Streaming: the SDK returns an iterator, not a ChatCompletion. Wrap
        # it so we accumulate the deltas and emit once the stream is drained.
        if kwargs.get("stream"):
            t0 = time.perf_counter()
            stream = original(self, *args, **kwargs)
            return _TracingStream(stream, kwargs, t0, emit_standalone, in_traj)

        if in_traj:
            t0 = time.perf_counter()
            try:
                response = original(self, *args, **kwargs)
            except Exception:
                latency = int((time.perf_counter() - t0) * 1000)
                _safe_record(latency_ms=latency, step_input=_summarize_messages(kwargs))
                raise
            latency = int((time.perf_counter() - t0) * 1000)
            tokens_in, tokens_out = _extract_usage(response)
            _safe_record(
                latency_ms=latency,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                step_input=_summarize_messages(kwargs),
                step_output=_summarize_response(response),
            )
            return response

        # No trajectory but emit_standalone — emit an EvalSample after the
        # response lands.
        response = original(self, *args, **kwargs)
        if emit_standalone:
            _emit_standalone_chat_trace(kwargs, response)
        return response

    wrapped._aferiq_patched = True  # type: ignore[attr-defined]
    Completions.create = wrapped


def _patch_async(AsyncCompletions: Any, emit_standalone: bool) -> None:  # noqa: N803  -- mirrors openai SDK class name
    if getattr(AsyncCompletions.create, "_aferiq_patched", False):
        return
    original = AsyncCompletions.create

    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        in_traj = has_active_trajectory()
        if not in_traj and not emit_standalone:
            return await original(self, *args, **kwargs)

        if kwargs.get("stream"):
            t0 = time.perf_counter()
            stream = await original(self, *args, **kwargs)
            return _AsyncTracingStream(stream, kwargs, t0, emit_standalone, in_traj)

        if in_traj:
            t0 = time.perf_counter()
            try:
                response = await original(self, *args, **kwargs)
            except Exception:
                latency = int((time.perf_counter() - t0) * 1000)
                _safe_record(latency_ms=latency, step_input=_summarize_messages(kwargs))
                raise
            latency = int((time.perf_counter() - t0) * 1000)
            tokens_in, tokens_out = _extract_usage(response)
            _safe_record(
                latency_ms=latency,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                step_input=_summarize_messages(kwargs),
                step_output=_summarize_response(response),
            )
            return response

        response = await original(self, *args, **kwargs)
        if emit_standalone:
            _emit_standalone_chat_trace(kwargs, response)
        return response

    wrapped._aferiq_patched = True  # type: ignore[attr-defined]
    AsyncCompletions.create = wrapped


# ---------------------------------------------------------------------------
# Streaming wrappers — accumulate deltas, emit once the stream is drained.
# Transparent proxies: delegate everything else to the wrapped SDK stream so
# `.response`, context-manager use, etc. keep working.
# ---------------------------------------------------------------------------


def _delta_text(event: Any) -> str | None:
    try:
        choices = getattr(event, "choices", None)
        if not choices:
            return None
        delta = getattr(choices[0], "delta", None)
        content = getattr(delta, "content", None) if delta else None
        return content if isinstance(content, str) and content else None
    except Exception:  # noqa: BLE001
        return None


def _finish_stream(
    kwargs: dict[str, Any],
    chunks: list[str],
    t0: float,
    emit_standalone: bool,
    in_traj: bool,
    usage: Any = None,
) -> None:
    answer = "".join(chunks)
    if not answer.strip():
        return
    if in_traj:
        # Tokens are only present when the caller (or the framework, e.g.
        # langchain) requested stream_options={"include_usage": True}; the
        # final chunk then carries `usage`. Capture it when available.
        tokens_in = tokens_out = None
        if usage is not None:
            tokens_in = getattr(usage, "prompt_tokens", None)
            tokens_out = getattr(usage, "completion_tokens", None)
        _safe_record(
            latency_ms=int((time.perf_counter() - t0) * 1000),
            tokens_in=int(tokens_in) if tokens_in is not None else None,
            tokens_out=int(tokens_out) if tokens_out is not None else None,
            step_input=_summarize_messages(kwargs),
            step_output={"preview": answer[:200], "streamed": True},
        )
    elif emit_standalone:
        _emit_standalone_query_answer(kwargs, answer)


class _TracingStream:
    """Sync proxy over an OpenAI Stream that captures the assembled answer."""

    def __init__(self, inner: Any, kwargs: dict[str, Any], t0: float,
                 emit_standalone: bool, in_traj: bool) -> None:
        self._inner = inner
        self._kwargs = kwargs
        self._t0 = t0
        self._emit_standalone = emit_standalone
        self._in_traj = in_traj
        self._chunks: list[str] = []
        self._usage: Any = None
        self._done = False

    def __iter__(self) -> _TracingStream:
        return self

    def __next__(self) -> Any:
        try:
            event = next(self._inner)
        except StopIteration:
            self._finish()
            raise
        d = _delta_text(event)
        if d:
            self._chunks.append(d)
        u = getattr(event, "usage", None)
        if u is not None:
            self._usage = u
        return event

    def _finish(self) -> None:
        if self._done:
            return
        self._done = True
        _finish_stream(
            self._kwargs, self._chunks, self._t0, self._emit_standalone, self._in_traj, self._usage
        )

    def __enter__(self) -> _TracingStream:
        self._inner.__enter__()
        return self

    def __exit__(self, *exc: Any) -> Any:
        self._finish()
        return self._inner.__exit__(*exc)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class _AsyncTracingStream:
    """Async proxy over an OpenAI AsyncStream that captures the answer."""

    def __init__(self, inner: Any, kwargs: dict[str, Any], t0: float,
                 emit_standalone: bool, in_traj: bool) -> None:
        self._inner = inner
        self._kwargs = kwargs
        self._t0 = t0
        self._emit_standalone = emit_standalone
        self._in_traj = in_traj
        self._chunks: list[str] = []
        self._usage: Any = None
        self._done = False

    def __aiter__(self) -> _AsyncTracingStream:
        return self

    async def __anext__(self) -> Any:
        try:
            event = await self._inner.__anext__()
        except StopAsyncIteration:
            self._finish()
            raise
        d = _delta_text(event)
        if d:
            self._chunks.append(d)
        u = getattr(event, "usage", None)
        if u is not None:
            self._usage = u
        return event

    def _finish(self) -> None:
        if self._done:
            return
        self._done = True
        _finish_stream(
            self._kwargs, self._chunks, self._t0, self._emit_standalone, self._in_traj, self._usage
        )

    async def __aenter__(self) -> _AsyncTracingStream:
        await self._inner.__aenter__()
        return self

    async def __aexit__(self, *exc: Any) -> Any:
        self._finish()
        return await self._inner.__aexit__(*exc)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


def _emit_standalone_chat_trace(kwargs: dict[str, Any], response: Any) -> None:
    """Emit a standalone EvalSample for a bare chat.completions.create call.

    Extracts:
      - query   = content of the last `user` message in kwargs.messages
      - context = [] (no retrieval visible at the patch layer)
      - answer  = response.choices[0].message.content

    Silently skips (no trace emitted) when:
      - No user message found
      - Response has no text content (e.g., tool_calls only — those happen
        in agent loops where @aferiq.trace on the entry function captures
        the turn instead)
      - Anything raises (handler must NEVER break user code)
    """
    try:
        from rageval.integrations.tracing import _emit
        from rageval.types import EvalSample

        messages = kwargs.get("messages") or []
        user_msgs = [
            m.get("content", "")
            for m in messages
            if isinstance(m, dict) and m.get("role") == "user"
        ]
        query = user_msgs[-1] if user_msgs else ""
        if not isinstance(query, str) or not query.strip():
            return

        # Pull answer from response (Pydantic or dict shape)
        answer: str = ""
        try:
            choices = getattr(response, "choices", None) or response.get("choices")
            if not choices:
                return
            first = choices[0]
            msg = getattr(first, "message", None) or first.get("message")
            content = getattr(msg, "content", None) or (
                msg.get("content") if isinstance(msg, dict) else None
            )
            if isinstance(content, str):
                answer = content
        except Exception:  # noqa: BLE001
            return

        if not answer.strip():
            return  # tool_calls or empty — skip

        sample = EvalSample(query=query, context=[], answer=answer)
        _emit(sample)
    except Exception as exc:  # noqa: BLE001
        _log.debug("standalone chat trace emit failed: %s", exc)


def _emit_standalone_query_answer(kwargs: dict[str, Any], answer: str) -> None:
    """Emit an EvalSample from a request's last user message + a ready answer.

    Used by the streaming path, where the answer is assembled from deltas
    rather than read off a ChatCompletion.
    """
    try:
        from rageval.integrations.tracing import _emit
        from rageval.types import EvalSample

        messages = kwargs.get("messages") or []
        user_msgs = [
            m.get("content", "")
            for m in messages
            if isinstance(m, dict) and m.get("role") == "user"
        ]
        query = user_msgs[-1] if user_msgs else ""
        if not isinstance(query, str) or not query.strip() or not answer.strip():
            return
        _emit(EvalSample(query=query, context=[], answer=answer))
    except Exception as exc:  # noqa: BLE001
        _log.debug("standalone stream trace emit failed: %s", exc)


def _extract_usage(response: Any) -> tuple[int | None, int | None]:
    """Pull (prompt_tokens, completion_tokens) from a ChatCompletion response.

    Tolerates dict-shape (legacy) and Pydantic-shape (current). Returns
    ``(None, None)`` if the shape is unrecognised — never raises.

    Handles the case where one field is present and the other is None on a
    class-instance shape (the SDK sometimes sets only prompt_tokens early).
    """
    usage: Any = None
    try:
        if isinstance(response, dict):
            usage = response.get("usage")
        else:
            usage = getattr(response, "usage", None)
    except Exception:
        return None, None
    if usage is None:
        return None, None

    if isinstance(usage, dict):
        pt = usage.get("prompt_tokens")
        ct = usage.get("completion_tokens")
    else:
        pt = getattr(usage, "prompt_tokens", None)
        ct = getattr(usage, "completion_tokens", None)

    return (
        int(pt) if pt is not None else None,
        int(ct) if ct is not None else None,
    )


def _summarize_messages(kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Compact representation of the request — model + last-user-message preview."""
    messages = kwargs.get("messages")
    model = kwargs.get("model")
    if not messages:
        return {"model": model} if model else None
    try:
        # Last user message preview, ≤200 chars.
        last_user = next(
            (m.get("content") for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        preview = (last_user or "")[:200] if isinstance(last_user, str) else None
        return {
            "model": model,
            "n_messages": len(messages),
            "last_user_preview": preview,
        }
    except Exception:
        return {"model": model}


def _summarize_response(response: Any) -> dict[str, Any] | None:
    """Compact representation of the response — first choice content preview + finish_reason."""
    try:
        choices = getattr(response, "choices", None) or response.get("choices")
        if not choices:
            return None
        first = choices[0]
        msg = getattr(first, "message", None) or first.get("message")
        content = getattr(msg, "content", None) or (msg.get("content") if msg else None)
        finish = getattr(first, "finish_reason", None) or first.get("finish_reason")
        preview = (content or "")[:200] if isinstance(content, str) else None
        return {"finish_reason": finish, "preview": preview}
    except Exception:
        return None


def _safe_record(**kwargs: Any) -> None:
    """Record an LLM step, swallowing any exception — never break user code."""
    try:
        record_step(step_type="llm", **kwargs)
    except Exception as e:
        _log.debug("record_step failed: %s", e)
