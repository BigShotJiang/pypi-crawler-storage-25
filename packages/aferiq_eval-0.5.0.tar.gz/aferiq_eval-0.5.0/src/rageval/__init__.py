"""rageval — RAG evaluation for Brazilian Portuguese.

Plug-and-play cloud tracing (recommended for new integrations):
    >>> import aferiq  # or: import rageval — both work
    >>> aferiq.start()  # 1 line: auto-patches openai/anthropic + traces
    >>> client.chat.completions.create(...)  # auto-captured

Programmatic eval (no cloud):
    >>> from rageval import evaluate
    >>> result = evaluate(
    ...     queries=["Qual o prazo do CDC?"],
    ...     contexts=[["Art. 49: 7 dias."]],
    ...     answers=["7 dias do recebimento."],
    ...     metrics=["faithfulness"],
    ... )

Decorator-style tracing:
    >>> from rageval import trace, register_trace_handler
    >>> samples = []
    >>> register_trace_handler(samples.append)
    >>> @trace
    ... def my_rag(query: str, context: list[str]) -> str:
    ...     return "..."
"""

from __future__ import annotations

from rageval.agent import AgentStep, AgentTrace, StepType, Trace
from rageval.client import AsyncCloudClient, CloudClient
from rageval.cloud import handler, init, redact_pii_br, start
from rageval.core import (
    AgentEvalResult,
    AgentTraceResult,
    aevaluate,
    aevaluate_agent,
    aevaluate_samples,
    evaluate,
    evaluate_agent,
    evaluate_samples,
)
from rageval.integrations import clear_trace_handlers, register_trace_handler, trace
from rageval.types import EvalResult, EvalSample, MetricScore, SampleResult

__version__ = "0.5.0"

__all__ = [
    "AgentEvalResult",
    "AgentStep",
    "AgentTrace",
    "AgentTraceResult",
    "AsyncCloudClient",
    "CloudClient",
    "EvalResult",
    "EvalSample",
    "MetricScore",
    "SampleResult",
    "StepType",
    "Trace",
    "__version__",
    "aevaluate",
    "aevaluate_agent",
    "aevaluate_samples",
    "clear_trace_handlers",
    "evaluate",
    "evaluate_agent",
    "evaluate_samples",
    "handler",
    "init",
    "redact_pii_br",
    "register_trace_handler",
    "start",
    "trace",
]
