"""Tests for `aferiq doctor` — connection diagnostics."""

from __future__ import annotations

import pytest

from rageval import doctor


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in ("AFERIQ_DSN", "AFERIQ_API_KEY", "AFERIQ_INGEST_URL"):
        monkeypatch.delenv(var, raising=False)


def test_resolve_config_from_dsn(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AFERIQ_DSN", "https://rg_pk_live_abc@aferiq.com.br/api/v1/traces")
    key, url, source = doctor._resolve_config()
    assert key == "rg_pk_live_abc"
    assert url == "https://aferiq.com.br/api/v1/traces"
    assert source == "AFERIQ_DSN"


def test_resolve_config_from_pair(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AFERIQ_API_KEY", "rg_pk_live_xyz")
    monkeypatch.setenv("AFERIQ_INGEST_URL", "http://localhost:3030/api/v1/traces")
    key, url, source = doctor._resolve_config()
    assert key == "rg_pk_live_xyz"
    assert url.endswith("/api/v1/traces")
    assert "AFERIQ_API_KEY" in source


def test_resolve_config_invalid_dsn(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AFERIQ_DSN", "not-a-valid-dsn")
    key, url, source = doctor._resolve_config()
    assert key == ""
    assert "invalid" in source


def test_run_doctor_exits_1_without_config() -> None:
    assert doctor.run_doctor(send_test=True) == 1


def test_run_doctor_exits_1_on_placeholder_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AFERIQ_API_KEY", "rg_pk_live_<COLE_AQUI>")
    monkeypatch.setenv("AFERIQ_INGEST_URL", "https://aferiq.com.br/api/v1/traces")
    assert doctor.run_doctor(send_test=True) == 1


def test_detect_sdks_returns_bools() -> None:
    sdks = doctor._detect_sdks()
    assert "openai" in sdks
    assert all(isinstance(v, bool) for v in sdks.values())


def test_send_test_trace_handles_connection_error() -> None:
    # Nothing listening on this port → ConnectError, reported gracefully.
    ok, status = doctor._send_test_trace(
        "rg_pk_live_x", "http://127.0.0.1:9/api/v1/traces", timeout=1.0
    )
    assert ok is False
    assert isinstance(status, str) and status


def test_run_doctor_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AFERIQ_API_KEY", "rg_pk_live_realkey")
    monkeypatch.setenv("AFERIQ_INGEST_URL", "https://aferiq.example/api/v1/traces")
    monkeypatch.setattr(doctor, "_probe_ingest", lambda *a, **k: "200 OK (key valid)")
    monkeypatch.setattr(
        doctor, "_send_test_trace", lambda *a, **k: (True, "200 OK — trace accepted")
    )
    assert doctor.run_doctor(send_test=True) == 0


def test_run_doctor_fails_when_test_trace_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AFERIQ_API_KEY", "rg_pk_live_realkey")
    monkeypatch.setenv("AFERIQ_INGEST_URL", "https://aferiq.example/api/v1/traces")
    monkeypatch.setattr(doctor, "_probe_ingest", lambda *a, **k: "200 OK (key valid)")
    monkeypatch.setattr(
        doctor, "_send_test_trace", lambda *a, **k: (False, "401 — key invalid")
    )
    assert doctor.run_doctor(send_test=True) == 1
