"""
Constants and enums for the KI4200A library.

Authors: Lucas LE DUDAL
"""

from enum import Enum

class SMUMode(Enum):
    """Enum of SMU types"""
    SMU = 0 # Full def
    VS = 1  # Voltage source only
    VM = 2  # Voltage meter only

class SourceType(Enum):
    """Enum of possible electrical units for measurements, sources, and limits."""
    NONE = 0 # OFF
    VOLT = 1
    AMPERE = 2
    COMMON = 3

class SourceFunction(Enum):
    """Enum of possible source functions"""
    NONE = 0
    SWEEP = 1
    STEP = 2
    CONSTANT = 3
    # SWEEP2 = 4

class BoardType(Enum):
    """Enum of possible board types that can be equipped in the KI4200A."""
    NONE = 0 # OFF
    SMU = 1
    CVU = 2
    PMU_RPM = 3

class Status(Enum):
    """Enum of all possible tasks and states an equipment can have"""
    INITIALIZING = "Initializing"
    CONNECTING = "Connecting"
    CONFIGURING = "Configuring"
    SCANNING = "Scanning"
    READY = "Ready"
    READY_NOT_RESET = "Ready, not reset"
    DISCONNECTED = "Disconnected"

class SweepType(Enum):
    """Enum of possible sweep types"""
    LINEAR = 1
    LOG10 = 2
    LOG25 = 3
    LOG50 = 4

class DisplayMode(Enum):
    """Enum for the 2 possible display modes"""
    NONE = 0
    GRAPH = 1
    LIST = 2

class GraphPosition(Enum):
    """Enum for the 3 axis of the graph display"""
    X = "XN"
    Y1 = "YA"
    Y2 = "YB"

class RPMMode(Enum):
    """Enum for the RPM switching modes"""
    PMU = 0
    CV_2W = 1
    SMU = 2
    CV_4W = 3

class IntegrationTime(Enum):
    """Enum for SMU integration time (IT)"""
    SHORT = 1
    NORMAL = 2
    LONG = 3

