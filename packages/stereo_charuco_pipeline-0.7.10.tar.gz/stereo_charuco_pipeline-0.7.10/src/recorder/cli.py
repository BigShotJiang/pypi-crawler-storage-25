"""
Command-line entry points for stereo-charuco-pipeline.

After `pip install .`, these commands are available:
  stereo-pipeline     Full workflow (Project Manager -> Calibration -> Pipeline)
  stereo-calibrate    Calibration UI only
  stereo-record       Pipeline UI only (record + reconstruct)
  stereo-home         Home edition UI (calibrate + monitor + 3D extract, simplified)
"""
import argparse
import logging
import sys
from pathlib import Path

from .paths import resolve_default_config


def main():
    """Full workflow: Project Manager -> Calibration UI -> Pipeline UI."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(description="Unified Stereo Pipeline")
    parser.add_argument(
        "--config", type=str, default=None,
        help="Path to YAML config file (default: built-in default.yaml)",
    )
    parser.add_argument(
        "--projects-base", type=str, default=None,
        help="Base directory for projects (default: ./projects)",
    )
    args = parser.parse_args()

    config_path = _resolve_config(args.config)
    projects_base = Path(args.projects_base) if args.projects_base else Path.cwd() / "projects"

    # Stage 1: Project Manager
    from .project_manager import ProjectManagerUI

    pm = ProjectManagerUI(projects_base)
    pm.wait_window(pm)

    context = pm.result
    if context is None:
        print("No project selected. Exiting.")
        return

    print(f"Project: {context.project_dir}")
    print(f"  New: {context.is_new}")
    print(f"  Needs calibration: {context.needs_calibration}")

    # Stage 2: Advanced Calibration UI (if needed)
    if context.needs_calibration:
        print("\nOpening Advanced Calibration Recording UI...")
        from .calibration_ui_advanced import CalibrationUIAdvanced

        calib_app = CalibrationUIAdvanced(
            config_path=config_path,
            project_dir=context.project_dir,
            on_complete=lambda: None,
        )
        calib_app.wait_window(calib_app)

    # Stage 3: Pipeline UI
    print("\nOpening Pipeline UI...")
    from .pipeline_ui import PipelineUI

    pipeline_app = PipelineUI(
        config_path=config_path,
        project_dir=context.project_dir,
    )
    pipeline_app.wait_window(pipeline_app)

    print("\nPipeline closed.")


def calibrate_only():
    """Advanced Calibration UI standalone."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(description="Stereo Calibration UI (Advanced)")
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--project-dir", type=str, default=None)
    args = parser.parse_args()

    config_path = _resolve_config(args.config)

    from .calibration_ui_advanced import CalibrationUIAdvanced

    app = CalibrationUIAdvanced(
        config_path=config_path,
        project_dir=Path(args.project_dir) if args.project_dir else None,
    )
    app.mainloop()


def pipeline_only():
    """Pipeline UI standalone."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(description="Stereo Pipeline UI")
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--project-dir", type=str, default=None)
    args = parser.parse_args()

    config_path = _resolve_config(args.config)

    from .pipeline_ui import PipelineUI

    app = PipelineUI(
        config_path=config_path,
        project_dir=Path(args.project_dir) if args.project_dir else None,
    )
    app.mainloop()


def home():
    """Home edition UI: simplified calibrate + auto-monitor + 3D extract."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(description="Stereo Home UI (家庭版)")
    parser.add_argument("--config", type=str, default=None,
                        help="Path to YAML config file")
    parser.add_argument("--project-dir", type=str, default=None,
                        help="Project directory (default: ./projects/home_project)")
    args = parser.parse_args()

    config_path = _resolve_config(args.config)

    from .home_ui import HomeUI

    app = HomeUI(
        config_path=config_path,
        project_dir=Path(args.project_dir) if args.project_dir else None,
    )
    app.mainloop()


def build_scene_model():
    """Build floor plane scene_model.toml from floor plane recording."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Build floor plane model (scene_model.toml) from stereo floor recording.",
        epilog=(
            "Expects:\n"
            "  <project_dir>/calibration/floor_plane/port_1.mp4\n"
            "  <project_dir>/calibration/floor_plane/port_2.mp4\n"
            "  <project_dir>/camera_array.toml\n\n"
            "Output:\n"
            "  <project_dir>/scene_model.toml"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "project_dir", nargs="?", default=None,
        help="Path to project directory (default: auto-detect ./projects/caliscope/caliscope_project)",
    )
    args = parser.parse_args()

    from .floor_plane import build_floor_plane

    # Resolve project dir
    if args.project_dir:
        project_dir = Path(args.project_dir)
    else:
        candidates = [
            Path.cwd() / "projects" / "caliscope" / "caliscope_project",
            Path.cwd() / "caliscope_project",
        ]
        project_dir = next((p for p in candidates if p.exists()), None)
        if project_dir is None:
            print("ERROR: No project directory found. Pass it as an argument:")
            print("  stereo-build-scene <project_dir>")
            sys.exit(1)

    floor_dir = project_dir / "calibration" / "floor_plane"
    video1 = floor_dir / "port_1.mp4"
    video2 = floor_dir / "port_2.mp4"
    camera_toml = project_dir / "camera_array.toml"
    output_toml = project_dir / "scene_model.toml"

    missing = [p for p in [video1, video2, camera_toml] if not p.exists()]
    if missing:
        for m in missing:
            print(f"  MISSING: {m}")
        print("\nRecord floor plane first via the calibration UI (② Record Floor Plane button).")
        sys.exit(1)

    print(f"Building scene_model.toml from {project_dir.name}...")
    ok = build_floor_plane(
        video_path_1=video1,
        video_path_2=video2,
        camera_array_toml=camera_toml,
        output_toml=output_toml,
        on_progress=lambda m: print(f"  {m}"),
    )
    if ok:
        print(f"\n✓ scene_model.toml saved → {output_toml}")
    else:
        print("\n✗ Failed. Check log above.")
        sys.exit(1)


def _resolve_config(user_config):
    """Resolve config path from user arg or built-in default."""
    if user_config:
        p = Path(user_config)
        if not p.is_absolute():
            p = Path.cwd() / p
        return p
    return resolve_default_config()
