# Copyright 2020 Andrzej Cichocki

# This file is part of Leytonium.
#
# Leytonium is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Leytonium is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Leytonium.  If not, see <http://www.gnu.org/licenses/>.

'Give the current branch its own identity.'
from .common import touchmsg, findproject, thisbranch
from lagoon.text import git
import os, time

def main():
    path = os.path.join(findproject(), 'TOUCHME')
    with open(path, 'w') as f:
        print(f"{time.strftime('%c %Z')} {thisbranch()}", file = f)
    git.add[print](path)
    git.commit._m[print](touchmsg())

if '__main__' == __name__:
    main()
