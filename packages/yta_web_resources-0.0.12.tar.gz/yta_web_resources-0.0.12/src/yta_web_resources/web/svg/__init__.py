"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > svg'
"""
from yta_web_resources import _WebResourceAnimatable


class _SvgAnimatedWebResource(_WebResourceAnimatable):
    """
    *For internal use only*

    Web resource to create a simple animation with
    different consecutive frames.

    This is associated with the next file:
    - `web.svg.index.html`
    """

    _element_id: str = 'container'

    # TODO: I think I'm not using 'fps' in the html
    # file but must be considered


# Instances to export here below
SvgAnimatedWebResource = lambda do_use_local_url = True, do_use_gui = False: _SvgAnimatedWebResource(
    local_path = 'src/yta_web_resources/web/svg/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1yhqCBbJ4HVBtFyr2miPBFYpU-IRE5gZg/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)