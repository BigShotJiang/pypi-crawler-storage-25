"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > quizz > answers >
normal'
"""
from yta_web_resources import _WebResource


class _AnswerNormalQuizzWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.

    This is associated with the next file:
    - `web.quizz.answers.normal.index.html`
    """

    _element_id: str = 'capture'

# Instances to export here below
AnswerNormalQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _AnswerNormalQuizzWebResource(
    local_path = 'src/yta_web_resources/web/quizz/answers/normal/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1iHkWSqQ1Fbc9wzd1B3NweHc25VDwnUl7/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)