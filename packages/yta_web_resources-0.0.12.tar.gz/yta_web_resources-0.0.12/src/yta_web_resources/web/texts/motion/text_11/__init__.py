"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > texts > motion >
text_11'

Inspired by: https://tobiasahlin.com/moving-letters/#11
"""
from yta_web_resources import _WebResourceAnimatable


class _TextNormalQuizzWebResource(_WebResourceAnimatable):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.

    This is associated with the next file:
    - `web.texts.motion.text_11.index.html`
    """

    _element_id: str = 'capture'

# Instances to export here below
TextNormalQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _TextNormalQuizzWebResource(
    local_path = 'src/yta_web_resources/web/texts/motion/text_11/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/18sLwNOEc7SgOdAl2UPg-GuPIkjWr_mel/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)