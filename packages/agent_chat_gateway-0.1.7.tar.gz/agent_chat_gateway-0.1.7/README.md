# agent-chat-gateway

[![CI](https://github.com/HammerMei/agent-chat-gateway/actions/workflows/ci.yml/badge.svg)](https://github.com/HammerMei/agent-chat-gateway/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-%3E%3D3.12-blue)
![License](https://img.shields.io/badge/license-MIT-green)

**Turn your AI agent into a team-shared chatbot — in minutes.**

Already running Claude Code or OpenCode? `agent-chat-gateway` connects it to your team's chat system (Rocket.Chat, and more) so everyone can talk to it directly from chat — no terminal required, no code changes to your agent.

Inspired by [OpenClaw](https://github.com/openclaw/openclaw)'s vision of making AI agents accessible from any messaging app — built for the team layer.

> **How it compares to Claude Code Channels:** Claude Code's native [Channels](https://code.claude.com/docs/en/channels) feature connects a single session to Telegram, Discord, or iMessage — great for personal use. `agent-chat-gateway` is built for teams: multiple agents, multiple chat systems, per-user roles, human oversight for sensitive operations, and shared sessions across your whole workspace.

---

## Features

- 💬 **[Works with Rocket.Chat](docs/supported-features.md#chat-platform-connectors)** — and extensible to Slack, Discord, or any other chat system you use
- 🤖 **[Bring your own agent](docs/supported-features.md#agent-backends)** — Claude Code and OpenCode work out of the box; plug in any other agent too
- 👥 **[User-aware in chat](docs/user-guide.md#user-aware-responses)** — the agent knows who sent each message and can personalize tone, language, and style per person using room profiles
- 🔒 **[Owner & Guest roles](docs/permission-reference.md#roles)** — control who can do what, with different permissions per role
- 🛡️ **[Human oversight for sensitive actions](docs/permission-reference.md#approval-workflow)** — the agent pauses and asks for your approval before executing risky operations like file writes or shell commands
- 🔗 **[Continue your session remotely](docs/user-guide.md#use-case-3--continue-an-existing-agent-session-remotely)** — pin a chat room to an existing agent session and pick up right where you left off, from anywhere
- 📎 **[File attachments](docs/user-guide.md#attachment-handling)** — send files in chat and the agent can read and work with them
- 🧠 **[Context injection](docs/user-guide.md#context-files)** — pre-load domain knowledge, system prompts, or project context into the agent at startup
- ⚡ **[Multiple chat systems at once](docs/user-guide.md#multi-connector-setup)** — connect to several chat platforms simultaneously

---

## What's Supported

| | Supported today | Can be extended |
|--|--|--|
| **Chat platforms** | Rocket.Chat | Slack, Discord, and others |
| **Agent backends** | Claude Code, OpenCode | Any agent with a CLI interface |

---

## Quick Start

The easiest way to install is to ask your AI agent to do it for you — it handles dependencies, configuration, and any troubleshooting automatically.

In Claude Code or OpenCode, run this prompt:

```
Please install agent-chat-gateway by following the instructions at https://raw.githubusercontent.com/HammerMei/agent-chat-gateway/main/docs/install-agent.md
```

> Prefer to install manually? See [INSTALL.md](INSTALL.md) for step-by-step instructions.

---

## Running the Gateway

```bash
# Start the gateway
agent-chat-gateway start

# Check status
agent-chat-gateway status

# Stop the gateway
agent-chat-gateway stop
```

See [docs/user-guide.md](docs/user-guide.md) for the full CLI reference, configuration options, and usage examples.

---

## Documentation

| Document | Description |
|---|---|
| [INSTALL.md](INSTALL.md) | Manual installation guide |
| [docs/user-guide.md](docs/user-guide.md) | Configuration reference, CLI usage, and operational guide |
| [docs/architecture.md](docs/architecture.md) | System architecture and module breakdown |
| [docs/permission-reference.md](docs/permission-reference.md) | Roles, permissions, and human oversight deep dive |
| [docs/supported-features.md](docs/supported-features.md) | Supported features, known limitations, and roadmap |
| [docs/requirements.md](docs/requirements.md) | Functional specification and behavioral requirements |
