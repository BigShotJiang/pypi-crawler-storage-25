"""In-process Shield capacity leases.

This is the Slice 5 local lease primitive used before provider dispatch. It is
process-local by design; route budget schema and later shared-counter work own
multi-replica enforcement.
"""

from __future__ import annotations

import asyncio
from collections import Counter
from types import TracebackType
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.admission import (
    AdmissionOutcome,
    ShieldAdmissionBudget,
    ShieldAdmissionContext,
    ShieldAdmissionDecision,
    ShieldCallMode,
    ShieldCapacitySnapshot,
    evaluate_shield_admission,
)


class ShieldCapacityLeaseError(Exception):
    """Raised when a lease cannot be acquired before provider dispatch."""

    def __init__(self, decision: ShieldAdmissionDecision) -> None:
        super().__init__(
            decision.reason.value if decision.reason is not None else decision.outcome.value
        )
        self.decision = decision


class ShieldCapacityLeaseState(BaseModel):
    """Content-free active lease counts for diagnostics and tests."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_active_calls: int = Field(ge=0)
    principal_active_calls: int = Field(ge=0)
    agent_run_active_calls: int = Field(ge=0)
    route_active_calls: int = Field(ge=0)
    route_streaming_calls: int = Field(ge=0)


class ShieldCapacityLeaser:
    """Process-local capacity lease manager.

    The manager is intentionally small and deterministic: under one lock it
    observes the current counters, evaluates admission, and increments all
    relevant dimensions only when the decision is admitted.
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._tenant_active: Counter[UUID] = Counter()
        self._principal_active: Counter[UUID] = Counter()
        self._agent_run_active: Counter[UUID] = Counter()
        self._route_active: Counter[UUID] = Counter()
        self._route_streaming: Counter[UUID] = Counter()

    async def acquire(
        self,
        context: ShieldAdmissionContext,
        budget: ShieldAdmissionBudget,
    ) -> ShieldCapacityLease:
        """Acquire a lease or raise with the content-free admission decision."""

        async with self._lock:
            snapshot = self.snapshot(context)
            decision = evaluate_shield_admission(context, budget, snapshot)
            if decision.outcome != AdmissionOutcome.ADMITTED:
                raise ShieldCapacityLeaseError(decision)
            self._tenant_active[context.tenant_id] += 1
            self._principal_active[context.principal_id] += 1
            if context.agent_run_id is not None:
                self._agent_run_active[context.agent_run_id] += 1
            self._route_active[context.route_id] += 1
            if context.mode == ShieldCallMode.STREAMING_SSE:
                self._route_streaming[context.route_id] += 1
            return ShieldCapacityLease(self, context)

    def snapshot(self, context: ShieldAdmissionContext) -> ShieldCapacitySnapshot:
        """Return the active counts relevant to one admission context."""

        return ShieldCapacitySnapshot(
            tenant_active_calls=self._tenant_active[context.tenant_id],
            principal_active_calls=self._principal_active[context.principal_id],
            agent_run_active_calls=(
                self._agent_run_active[context.agent_run_id]
                if context.agent_run_id is not None
                else 0
            ),
            route_active_calls=self._route_active[context.route_id],
            route_streaming_calls=self._route_streaming[context.route_id],
        )

    async def release(self, context: ShieldAdmissionContext) -> None:
        """Release a previously acquired lease without letting counts go negative."""

        async with self._lock:
            self._decrement(self._tenant_active, context.tenant_id)
            self._decrement(self._principal_active, context.principal_id)
            if context.agent_run_id is not None:
                self._decrement(self._agent_run_active, context.agent_run_id)
            self._decrement(self._route_active, context.route_id)
            if context.mode == ShieldCallMode.STREAMING_SSE:
                self._decrement(self._route_streaming, context.route_id)

    def state_for(self, context: ShieldAdmissionContext) -> ShieldCapacityLeaseState:
        """Return current active counts for one context."""

        snapshot = self.snapshot(context)
        return ShieldCapacityLeaseState(**snapshot.model_dump())

    @staticmethod
    def _decrement(counter: Counter[UUID], key: UUID) -> None:
        if counter[key] <= 1:
            counter.pop(key, None)
            return
        counter[key] -= 1


class ShieldCapacityLease:
    """Async context manager for one acquired capacity lease."""

    def __init__(self, leaser: ShieldCapacityLeaser, context: ShieldAdmissionContext) -> None:
        self._leaser = leaser
        self._context = context
        self._released = False
        self._release_lock = asyncio.Lock()

    async def __aenter__(self) -> ShieldCapacityLease:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.release()

    async def release(self) -> None:
        """Release at most once."""

        async with self._release_lock:
            if self._released:
                return
            await self._leaser.release(self._context)
            self._released = True
