"""Trusted response rehydration over session-scoped synthetic mappings."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Protocol

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.contracts import ShieldErrorCode


class RehydrationError(Exception):
    """Typed value-free rehydration failure."""

    def __init__(self, error_code: ShieldErrorCode) -> None:
        super().__init__(error_code.value)
        self.error_code = error_code


class RehydrationUnavailableError(RehydrationError):
    """Raised when session reverse lookup is unavailable."""

    def __init__(self) -> None:
        super().__init__(ShieldErrorCode.REHYDRATION_UNAVAILABLE)


class IncompleteRehydrationError(RehydrationError):
    """Raised when stream close leaves an incomplete synthetic prefix."""

    def __init__(self) -> None:
        super().__init__(ShieldErrorCode.STREAM_INCOMPLETE_REHYDRATION)


class RehydrationLookup(Protocol):
    """Session-scoped synthetic lookup source for trusted response text."""

    async def synthetic_values(self) -> tuple[str, ...]:
        """Return active synthetic values for one organization/session scope."""
        ...

    async def reverse_lookup(self, synthetic_value: str) -> str:
        """Return the trusted real value for one complete synthetic value."""
        ...


class StaticRehydrationLookup(BaseModel):
    """Deterministic in-memory lookup for tests and local contract consumers."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    mappings: Mapping[str, str] = Field(default_factory=dict)

    async def synthetic_values(self) -> tuple[str, ...]:
        return tuple(self.mappings)

    async def reverse_lookup(self, synthetic_value: str) -> str:
        try:
            return self.mappings[synthetic_value]
        except KeyError as error:
            raise RehydrationUnavailableError from error


class StreamingRehydrator:
    """Cross-chunk rehydrator that never emits partial synthetic values."""

    def __init__(
        self,
        lookup: RehydrationLookup,
        *,
        credential_placeholder_prefix: str = "[SECRET:",
    ) -> None:
        self._lookup = lookup
        self._credential_placeholder_prefix = credential_placeholder_prefix
        self._synthetics: tuple[str, ...] | None = None
        self._buffer = ""
        self._closed = False

    async def push(self, chunk: str) -> str:
        """Append provider text and return the trusted text safe to emit now."""

        if self._closed:
            raise RehydrationUnavailableError
        self._buffer += chunk
        return await self._drain(final=False)

    async def close(self) -> str:
        """Flush safe buffered text or fail if it could be an incomplete synthetic."""

        self._closed = True
        return await self._drain(final=True)

    async def _drain(self, *, final: bool) -> str:
        synthetics = await self._active_synthetics()
        output_parts: list[str] = []

        while self._buffer:
            if not final and _is_prefix_of_longer_synthetic(self._buffer, synthetics):
                break

            starting_match = _longest_synthetic_prefix(self._buffer, synthetics)
            if starting_match is not None:
                output_parts.append(await self._lookup.reverse_lookup(starting_match))
                self._buffer = self._buffer[len(starting_match) :]
                continue

            next_match_index = _first_synthetic_index(self._buffer, synthetics)
            if next_match_index is not None:
                output_parts.append(self._buffer[:next_match_index])
                self._buffer = self._buffer[next_match_index:]
                continue

            hold_length = _safe_suffix_hold_length(self._buffer, synthetics)
            if final:
                if hold_length == len(self._buffer) and _is_incomplete_synthetic_prefix(
                    self._buffer,
                    synthetics,
                ):
                    raise IncompleteRehydrationError
                hold_length = 0

            if hold_length == len(self._buffer):
                break

            emit_length = len(self._buffer) - hold_length
            output_parts.append(self._buffer[:emit_length])
            self._buffer = self._buffer[emit_length:]

        return "".join(output_parts)

    async def _active_synthetics(self) -> tuple[str, ...]:
        if self._synthetics is None:
            values = await self._lookup.synthetic_values()
            self._synthetics = tuple(
                sorted(
                    (
                        value
                        for value in values
                        if value and not value.startswith(self._credential_placeholder_prefix)
                    ),
                    key=len,
                    reverse=True,
                )
            )
        return self._synthetics


async def rehydrate_text(text: str, lookup: RehydrationLookup) -> str:
    """Rehydrate a non-streaming response through the same buffering semantics."""

    rehydrator = StreamingRehydrator(lookup)
    return await rehydrator.push(text) + await rehydrator.close()


def _longest_synthetic_prefix(buffer: str, synthetics: tuple[str, ...]) -> str | None:
    for synthetic in synthetics:
        if buffer.startswith(synthetic):
            return synthetic
    return None


def _first_synthetic_index(buffer: str, synthetics: tuple[str, ...]) -> int | None:
    indexes = [index for synthetic in synthetics if (index := buffer.find(synthetic)) >= 0]
    if not indexes:
        return None
    return min(indexes)


def _safe_suffix_hold_length(buffer: str, synthetics: tuple[str, ...]) -> int:
    max_hold = 0
    max_candidate = min(len(buffer), max((len(value) - 1 for value in synthetics), default=0))
    for length in range(1, max_candidate + 1):
        suffix = buffer[-length:]
        if any(synthetic.startswith(suffix) for synthetic in synthetics):
            max_hold = length
    return max_hold


def _is_prefix_of_longer_synthetic(buffer: str, synthetics: tuple[str, ...]) -> bool:
    return any(
        synthetic.startswith(buffer) and len(buffer) < len(synthetic) for synthetic in synthetics
    )


def _is_incomplete_synthetic_prefix(buffer: str, synthetics: tuple[str, ...]) -> bool:
    if _longest_synthetic_prefix(buffer, synthetics) is not None:
        return False
    return any(synthetic.startswith(buffer) for synthetic in synthetics)
