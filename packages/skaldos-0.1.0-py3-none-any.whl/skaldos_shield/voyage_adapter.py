"""Voyage embedding request serialization and HTTP transport for Shield."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal, Protocol

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from skaldos_shield.backpressure import ShieldProviderRateLimitError
from skaldos_shield.contracts import (
    MessagePartType,
    RouteCapability,
    ShieldErrorCode,
    TrustedEmbeddingResult,
)
from skaldos_shield.provider_adapters import (
    ProviderAdapterRequest,
    ProviderAdapterResponse,
    ShieldProviderAdapter,
    ShieldProviderCallError,
)
from skaldos_shield.redaction_pipeline import ProviderSafeMessagePart

VOYAGE_EMBEDDINGS_URL = "https://api.voyageai.com/v1/embeddings"
VOYAGE_DEFAULT_OUTPUT_DIMENSION = 1024
VOYAGE_DEFAULT_OUTPUT_DTYPE: Literal["float"] = "float"

_TEXT_PART_TYPES = frozenset(
    {
        MessagePartType.SYSTEM,
        MessagePartType.DEVELOPER,
        MessagePartType.USER_TEXT,
        MessagePartType.TOOL_RESULT,
    }
)
_SUPPORTED_CAPABILITIES = frozenset(
    {
        RouteCapability.EMBEDDING,
        RouteCapability.SEARCH_QUERY_EMBEDDING,
    }
)


class VoyageSerializationError(Exception):
    """Raised when provider-safe content cannot be expressed as Voyage embeddings."""

    error_code = ShieldErrorCode.UNSUPPORTED_PART


class VoyageProviderCallError(ShieldProviderCallError):
    """Raised when Voyage returns a non-rate-limit failure or malformed response."""


class VoyageEmbeddingsRequest(BaseModel):
    """Serializable Voyage embeddings request payload."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    input: tuple[str, ...] = Field(min_length=1)
    model: str
    input_type: Literal["document", "query"]
    output_dimension: int = Field(gt=0)
    output_dtype: Literal["float"] = VOYAGE_DEFAULT_OUTPUT_DTYPE


class VoyageEmbeddingItem(BaseModel):
    """One Voyage embedding result item."""

    model_config = ConfigDict(extra="allow", frozen=True)

    embedding: list[float] = Field(min_length=1)
    index: int | None = None


class VoyageEmbeddingsResponse(BaseModel):
    """Parsed Voyage embeddings response."""

    model_config = ConfigDict(extra="allow", frozen=True)

    data: list[VoyageEmbeddingItem] = Field(min_length=1)


@dataclass(frozen=True, repr=False)
class VoyageCredential:
    """Resolved Voyage credential kept outside serializable request payloads."""

    api_key: str

    def __repr__(self) -> str:
        return "VoyageCredential(<redacted>)"


class VoyageEmbeddingTransport(Protocol):
    """Injected transport boundary for Voyage embedding calls."""

    async def embed(
        self,
        payload: VoyageEmbeddingsRequest,
        *,
        credential: VoyageCredential,
    ) -> VoyageEmbeddingsResponse:
        """Send an already serialized Voyage embedding request."""
        ...


class HttpxVoyageEmbeddingTransport(VoyageEmbeddingTransport):
    """HTTPX transport for Voyage embeddings used only inside Shield."""

    def __init__(
        self,
        *,
        http_client: httpx.AsyncClient | None = None,
        timeout_seconds: float = 30.0,
    ) -> None:
        self._http_client = http_client
        self._timeout_seconds = timeout_seconds

    async def embed(
        self,
        payload: VoyageEmbeddingsRequest,
        *,
        credential: VoyageCredential,
    ) -> VoyageEmbeddingsResponse:
        """Call Voyage embeddings and return a typed, provider-neutral response."""

        client = self._http_client
        if client is None:
            async with httpx.AsyncClient(timeout=self._timeout_seconds) as transient_client:
                return await self._post(transient_client, payload, credential=credential)
        return await self._post(client, payload, credential=credential)

    async def _post(
        self,
        client: httpx.AsyncClient,
        payload: VoyageEmbeddingsRequest,
        *,
        credential: VoyageCredential,
    ) -> VoyageEmbeddingsResponse:
        try:
            response = await client.post(
                VOYAGE_EMBEDDINGS_URL,
                headers={
                    "Authorization": f"Bearer {credential.api_key}",
                    "Content-Type": "application/json",
                },
                json=payload.model_dump(mode="json"),
            )
        except httpx.HTTPError as error:
            raise VoyageProviderCallError("voyage embedding transport failed") from error

        if response.status_code == 429:
            raise ShieldProviderRateLimitError(
                retry_after_seconds=_retry_after_seconds(response.headers.get("Retry-After"))
            )
        if response.status_code < 200 or response.status_code >= 300:
            raise VoyageProviderCallError("voyage embedding provider call failed")

        try:
            return VoyageEmbeddingsResponse.model_validate(response.json())
        except (json.JSONDecodeError, ValidationError) as error:
            raise VoyageProviderCallError("voyage embedding response was malformed") from error


class VoyageEmbeddingProviderAdapter(ShieldProviderAdapter):
    """Shield provider adapter for Voyage document and search-query embeddings."""

    def __init__(
        self,
        *,
        transport: VoyageEmbeddingTransport,
        output_dimension: int = VOYAGE_DEFAULT_OUTPUT_DIMENSION,
        output_dtype: Literal["float"] = VOYAGE_DEFAULT_OUTPUT_DTYPE,
    ) -> None:
        self._transport = transport
        self._output_dimension = output_dimension
        self._output_dtype: Literal["float"]
        self._output_dtype = output_dtype

    async def complete(self, request: ProviderAdapterRequest) -> ProviderAdapterResponse:
        """Serialize provider-safe canonical parts and call the injected transport."""

        payload = serialize_voyage_embedding_request(
            request,
            output_dimension=self._output_dimension,
            output_dtype=self._output_dtype,
        )
        if request.credential is None:
            raise VoyageSerializationError("voyage credential is unavailable")
        credential = VoyageCredential(api_key=request.credential.plaintext())
        voyage_response = await self._transport.embed(payload, credential=credential)
        vectors = _ordered_vectors(
            voyage_response,
            expected_count=len(payload.input),
            expected_dimension=payload.output_dimension,
        )
        return ProviderAdapterResponse(
            result=TrustedEmbeddingResult(
                vectors=vectors,
                dimensions=payload.output_dimension,
                provider_safe_texts=payload.input,
            )
        )


def serialize_voyage_embedding_request(
    request: ProviderAdapterRequest,
    *,
    output_dimension: int = VOYAGE_DEFAULT_OUTPUT_DIMENSION,
    output_dtype: Literal["float"] = VOYAGE_DEFAULT_OUTPUT_DTYPE,
) -> VoyageEmbeddingsRequest:
    """Convert provider-safe canonical parts to a Voyage embeddings payload."""

    if request.route.provider != "voyage":
        raise VoyageSerializationError("voyage adapter requires a voyage route")
    if request.route.capability not in _SUPPORTED_CAPABILITIES:
        raise VoyageSerializationError("voyage adapter supports embedding routes only")

    inputs = tuple(_text_for_part(safe_part) for safe_part in request.provider_safe_parts)
    if not any(text.strip() for text in inputs):
        raise VoyageSerializationError("voyage embedding requests require provider-safe text")

    return VoyageEmbeddingsRequest(
        input=inputs,
        model=request.route.model_id,
        input_type=_input_type_for_capability(request.route.capability),
        output_dimension=output_dimension,
        output_dtype=output_dtype,
    )


def _input_type_for_capability(
    capability: RouteCapability | None,
) -> Literal["document", "query"]:
    if capability == RouteCapability.EMBEDDING:
        return "document"
    if capability == RouteCapability.SEARCH_QUERY_EMBEDDING:
        return "query"
    raise VoyageSerializationError("voyage adapter supports embedding routes only")


def _text_for_part(safe_part: ProviderSafeMessagePart) -> str:
    if safe_part.part.type in _TEXT_PART_TYPES:
        return safe_part.part.text or ""
    if safe_part.part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
        return json.dumps(
            safe_part.part.json_value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
    raise VoyageSerializationError("unsupported provider-safe part type")


def _ordered_vectors(
    response: VoyageEmbeddingsResponse,
    *,
    expected_count: int,
    expected_dimension: int,
) -> list[list[float]]:
    if len(response.data) != expected_count:
        raise VoyageProviderCallError("voyage embedding response count did not match request")
    indexes = [item.index for item in response.data]
    if any(index is not None for index in indexes):
        expected_indexes = list(range(expected_count))
        if sorted(index for index in indexes if index is not None) != expected_indexes:
            raise VoyageProviderCallError("voyage embedding response indexes were inconsistent")
        items = sorted(response.data, key=lambda item: item.index or 0)
    else:
        items = response.data
    vectors = [item.embedding for item in items]
    if any(len(vector) != expected_dimension for vector in vectors):
        raise VoyageProviderCallError("voyage embedding response dimensions were inconsistent")
    return vectors


def _retry_after_seconds(value: str | None) -> int:
    if value is None:
        return 1
    try:
        return int(value)
    except ValueError:
        return 1
