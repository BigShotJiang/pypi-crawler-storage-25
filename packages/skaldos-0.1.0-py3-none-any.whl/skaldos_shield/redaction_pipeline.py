"""Canonical Shield redaction pipeline.

This module ties normalized canonical message parts, scan-budget decisions,
detector analyses, and the replacement engine into one provider-safe pre-call
boundary. Raw request values may flow through memory while replacement runs,
but serializable pipeline metadata stays value-free.
"""

from __future__ import annotations

from collections.abc import Sequence
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos_shield.contracts import (
    CredentialReplacement,
    DetectionPlan,
    DetectionStatus,
    MessagePart,
    MessagePartType,
    ReplacementMode,
    RequiredSensitivity,
    SensitivityTier,
    ShieldErrorCode,
    ShieldMessageRole,
    effective_sensitivity,
)
from skaldos_shield.detectors import DetectorAnalysis
from skaldos_shield.redaction import ReplacementEngine
from skaldos_shield.request_normalizer import NormalizedMessagePart, NormalizedShieldRequest
from skaldos_shield.scan_budget import ScanBudgetDecision, ScanBudgetOutcome
from skaldos_shield.session_store import RedactionSessionStore

_TEXT_REPLACEMENT_TYPES = frozenset(
    {
        MessagePartType.SYSTEM,
        MessagePartType.DEVELOPER,
        MessagePartType.USER_TEXT,
        MessagePartType.TOOL_RESULT,
    }
)


class ProviderSafeMessagePart(BaseModel):
    """Provider-bound part plus value-free source coordinates."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    role: ShieldMessageRole
    part: MessagePart
    message_index: int = Field(ge=0)
    part_index: int = Field(ge=0)
    source_field: str


class RedactionPartMetadata(BaseModel):
    """Value-free metadata for one normalized part's redaction outcome."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    part_type: MessagePartType
    message_index: int = Field(ge=0)
    part_index: int = Field(ge=0)
    source_field: str
    scan_budget: ScanBudgetDecision
    detection_plan: DetectionPlan | None = None
    replacement_mode: ReplacementMode | None = None
    replacement_count: int = Field(ge=0)
    escaped_literal_placeholder_count: int = Field(ge=0)
    credential_replacement: CredentialReplacement = CredentialReplacement.NONE
    required_sensitivity: RequiredSensitivity
    blocks_provider_dispatch: bool
    error_code: ShieldErrorCode | None = None

    @model_validator(mode="after")
    def _blocked_parts_require_code(self) -> RedactionPartMetadata:
        if self.blocks_provider_dispatch and self.error_code is None:
            raise ValueError("blocked redaction parts require a stable error code")
        if not self.blocks_provider_dispatch and self.error_code is not None:
            raise ValueError("non-blocking redaction parts cannot carry an error code")
        return self


class RedactionPipelineResult(BaseModel):
    """Provider-safe parts and value-free aggregate redaction metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    provider_safe_parts: tuple[ProviderSafeMessagePart, ...]
    metadata: tuple[RedactionPartMetadata, ...]
    required_sensitivity: RequiredSensitivity
    credential_replacement: CredentialReplacement = CredentialReplacement.NONE
    blocks_provider_dispatch: bool = False
    error_code: ShieldErrorCode | None = None

    @model_validator(mode="after")
    def _blocked_result_requires_code(self) -> RedactionPipelineResult:
        if self.blocks_provider_dispatch and self.error_code is None:
            raise ValueError("blocked redaction pipeline results require a stable error code")
        if not self.blocks_provider_dispatch and self.error_code is not None:
            raise ValueError("non-blocking redaction pipeline results cannot carry an error code")
        return self


class RedactionPipeline:
    """Apply provider-safe replacement over normalized canonical parts."""

    def __init__(self, replacement_engine: ReplacementEngine | None = None) -> None:
        self._replacement_engine = replacement_engine or ReplacementEngine()

    async def apply(
        self,
        *,
        normalized_request: NormalizedShieldRequest,
        scan_budget_decisions: Sequence[ScanBudgetDecision],
        detector_analyses: Sequence[DetectorAnalysis],
        mode: ReplacementMode,
        session_id: UUID | None = None,
        session_store: RedactionSessionStore | None = None,
        requested_sensitivity: SensitivityTier | None = None,
    ) -> RedactionPipelineResult:
        """Return provider-safe parts plus serializable value-free metadata."""

        _validate_parallel_inputs(
            normalized_request.parts,
            scan_budget_decisions,
            detector_analyses,
        )

        tenant_id = UUID(normalized_request.tenant_id)
        safe_parts: list[ProviderSafeMessagePart] = []
        metadata: list[RedactionPartMetadata] = []
        aggregate_tier = requested_sensitivity or SensitivityTier.NON_PII
        aggregate_credential_replacement = CredentialReplacement.NONE
        blocked_code: ShieldErrorCode | None = None

        for normalized_part, scan_decision, detector_analysis in zip(
            normalized_request.parts,
            scan_budget_decisions,
            detector_analyses,
            strict=True,
        ):
            if scan_decision.outcome != ScanBudgetOutcome.OK:
                decision_code = (
                    ShieldErrorCode.UNSCANNABLE
                    if scan_decision.error_code is None
                    else scan_decision.error_code
                )
                blocked_code = blocked_code or decision_code
                part_metadata = _blocked_metadata(
                    normalized_part,
                    scan_decision,
                    detector_analysis.plan,
                    requested_sensitivity=requested_sensitivity,
                    error_code=decision_code,
                )
                metadata.append(part_metadata)
                aggregate_tier = max(
                    aggregate_tier,
                    part_metadata.required_sensitivity.effective_tier,
                )
                continue

            if detector_analysis.plan.status not in {
                DetectionStatus.CLEAN,
                DetectionStatus.DETECTED,
            }:
                detector_code: ShieldErrorCode = _detector_error_code(detector_analysis)
                if blocked_code is None:
                    blocked_code = detector_code
                part_metadata = _blocked_metadata(
                    normalized_part,
                    scan_decision,
                    detector_analysis.plan,
                    requested_sensitivity=requested_sensitivity,
                    error_code=detector_code,
                )
                metadata.append(part_metadata)
                aggregate_tier = max(
                    aggregate_tier,
                    part_metadata.required_sensitivity.effective_tier,
                )
                continue

            if _detector_analysis_has_span_mismatch(normalized_part, detector_analysis):
                if blocked_code is None:
                    blocked_code = ShieldErrorCode.DETECTOR_ERROR
                part_metadata = _blocked_metadata(
                    normalized_part,
                    scan_decision,
                    detector_analysis.plan,
                    requested_sensitivity=requested_sensitivity,
                    error_code=ShieldErrorCode.DETECTOR_ERROR,
                )
                metadata.append(part_metadata)
                aggregate_tier = max(
                    aggregate_tier,
                    part_metadata.required_sensitivity.effective_tier,
                )
                continue

            if normalized_part.part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
                if detector_analysis.plan.status == DetectionStatus.DETECTED:
                    if blocked_code is None:
                        blocked_code = ShieldErrorCode.UNSCANNABLE
                    part_metadata = _blocked_metadata(
                        normalized_part,
                        scan_decision,
                        detector_analysis.plan,
                        requested_sensitivity=requested_sensitivity,
                        error_code=ShieldErrorCode.UNSCANNABLE,
                    )
                    metadata.append(part_metadata)
                    aggregate_tier = max(
                        aggregate_tier,
                        part_metadata.required_sensitivity.effective_tier,
                    )
                    continue

                safe_part = normalized_part.part
                part_required = _required_sensitivity(
                    classified_tier=detector_analysis.plan.required_sensitivity,
                    requested_sensitivity=requested_sensitivity,
                )
                safe_parts.append(_safe_part(normalized_part, safe_part))
                metadata.append(
                    _metadata(
                        normalized_part,
                        scan_decision,
                        detector_analysis.plan,
                        mode=None,
                        required_sensitivity=part_required,
                        blocks=False,
                    )
                )
                aggregate_tier = max(aggregate_tier, part_required.effective_tier)
                continue

            if normalized_part.part.type not in _TEXT_REPLACEMENT_TYPES:
                if blocked_code is None:
                    blocked_code = ShieldErrorCode.UNSCANNABLE
                part_metadata = _blocked_metadata(
                    normalized_part,
                    scan_decision,
                    detector_analysis.plan,
                    requested_sensitivity=requested_sensitivity,
                    error_code=ShieldErrorCode.UNSCANNABLE,
                )
                metadata.append(part_metadata)
                aggregate_tier = max(
                    aggregate_tier,
                    part_metadata.required_sensitivity.effective_tier,
                )
                continue

            replacement = await self._replacement_engine.apply(
                text=normalized_part.part.text or "",
                spans=detector_analysis.spans,
                mode=mode,
                organization_id=tenant_id,
                session_id=session_id,
                session_store=session_store,
                requested_sensitivity=max(
                    requested_sensitivity or SensitivityTier.NON_PII,
                    detector_analysis.plan.required_sensitivity,
                ),
            )
            safe_message_part = MessagePart(
                type=normalized_part.part.type,
                text=replacement.provider_safe_text,
            )
            safe_parts.append(_safe_part(normalized_part, safe_message_part))
            metadata.append(
                _metadata(
                    normalized_part,
                    scan_decision,
                    detector_analysis.plan,
                    mode=mode,
                    required_sensitivity=replacement.required_sensitivity,
                    replacement_count=replacement.replacement_count,
                    escaped_literal_placeholder_count=(
                        replacement.escaped_literal_placeholder_count
                    ),
                    credential_replacement=replacement.credential_replacement,
                    blocks=False,
                )
            )
            aggregate_tier = max(
                aggregate_tier,
                replacement.required_sensitivity.effective_tier,
            )
            if replacement.credential_replacement is CredentialReplacement.INERT_PLACEHOLDER:
                aggregate_credential_replacement = CredentialReplacement.INERT_PLACEHOLDER

        result_required_sensitivity = _required_sensitivity(
            classified_tier=aggregate_tier,
            requested_sensitivity=requested_sensitivity,
        )
        return RedactionPipelineResult(
            provider_safe_parts=tuple(safe_parts) if blocked_code is None else (),
            metadata=tuple(metadata),
            required_sensitivity=result_required_sensitivity,
            credential_replacement=aggregate_credential_replacement,
            blocks_provider_dispatch=blocked_code is not None,
            error_code=blocked_code,
        )


def _validate_parallel_inputs(
    parts: tuple[NormalizedMessagePart, ...],
    scan_budget_decisions: Sequence[ScanBudgetDecision],
    detector_analyses: Sequence[DetectorAnalysis],
) -> None:
    if len(parts) != len(scan_budget_decisions):
        raise ValueError("scan-budget decisions must align with normalized parts")
    if len(parts) != len(detector_analyses):
        raise ValueError("detector analyses must align with normalized parts")

    for part, decision in zip(parts, scan_budget_decisions, strict=True):
        if (
            part.message_index != decision.message_index
            or part.part_index != decision.part_index
            or part.source_field != decision.source_field
            or part.part.type != decision.part_type
        ):
            raise ValueError("scan-budget decision source metadata mismatch")


def _safe_part(
    normalized_part: NormalizedMessagePart,
    safe_part: MessagePart,
) -> ProviderSafeMessagePart:
    return ProviderSafeMessagePart(
        role=normalized_part.role,
        part=safe_part,
        message_index=normalized_part.message_index,
        part_index=normalized_part.part_index,
        source_field=normalized_part.source_field,
    )


def _metadata(
    normalized_part: NormalizedMessagePart,
    scan_decision: ScanBudgetDecision,
    detection_plan: DetectionPlan | None,
    *,
    mode: ReplacementMode | None,
    required_sensitivity: RequiredSensitivity,
    replacement_count: int = 0,
    escaped_literal_placeholder_count: int = 0,
    credential_replacement: CredentialReplacement = CredentialReplacement.NONE,
    blocks: bool,
    error_code: ShieldErrorCode | None = None,
) -> RedactionPartMetadata:
    return RedactionPartMetadata(
        part_type=normalized_part.part.type,
        message_index=normalized_part.message_index,
        part_index=normalized_part.part_index,
        source_field=normalized_part.source_field,
        scan_budget=scan_decision,
        detection_plan=detection_plan,
        replacement_mode=mode,
        replacement_count=replacement_count,
        escaped_literal_placeholder_count=escaped_literal_placeholder_count,
        credential_replacement=credential_replacement,
        required_sensitivity=required_sensitivity,
        blocks_provider_dispatch=blocks,
        error_code=error_code,
    )


def _blocked_metadata(
    normalized_part: NormalizedMessagePart,
    scan_decision: ScanBudgetDecision,
    detection_plan: DetectionPlan | None,
    *,
    requested_sensitivity: SensitivityTier | None,
    error_code: ShieldErrorCode,
) -> RedactionPartMetadata:
    classified_tier = SensitivityTier.PII_STRICT
    if detection_plan is not None:
        classified_tier = max(classified_tier, detection_plan.required_sensitivity)
    return _metadata(
        normalized_part,
        scan_decision,
        detection_plan,
        mode=None,
        required_sensitivity=_required_sensitivity(
            classified_tier=classified_tier,
            requested_sensitivity=requested_sensitivity,
        ),
        blocks=True,
        error_code=error_code,
    )


def _required_sensitivity(
    *,
    classified_tier: SensitivityTier,
    requested_sensitivity: SensitivityTier | None,
) -> RequiredSensitivity:
    return RequiredSensitivity(
        classified_tier=classified_tier,
        requested_tier=requested_sensitivity,
        effective_tier=effective_sensitivity(classified_tier, requested_sensitivity),
    )


def _detector_error_code(detector_analysis: DetectorAnalysis) -> ShieldErrorCode:
    if detector_analysis.status_reason is not None:
        return detector_analysis.status_reason.error_code
    if detector_analysis.plan.status == DetectionStatus.TIMEOUT:
        return ShieldErrorCode.DETECTOR_TIMEOUT
    if detector_analysis.plan.status == DetectionStatus.SATURATED:
        return ShieldErrorCode.DETECTOR_SATURATED
    return ShieldErrorCode.DETECTOR_ERROR


def _detector_analysis_has_span_mismatch(
    normalized_part: NormalizedMessagePart,
    detector_analysis: DetectorAnalysis,
) -> bool:
    if detector_analysis.plan.status == DetectionStatus.CLEAN:
        return len(detector_analysis.spans) > 0
    if (
        detector_analysis.plan.status == DetectionStatus.DETECTED
        and normalized_part.part.type in _TEXT_REPLACEMENT_TYPES
    ):
        return len(detector_analysis.spans) == 0
    return False
