"""Bifrost provider-route lookup accessors for Shield.

This module is the data-access foundation for Slice 5 provider routing. It
loads active tenant-scoped route rows and projects them through Pydantic. It
does not choose a route.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any
from uuid import UUID

import aiosql
from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos_shield.admission import ShieldQueuePolicy
from skaldos_shield.contracts import RouteCapability, SensitivityTier

if TYPE_CHECKING:
    import asyncpg

__all__ = [
    "BifrostProviderRoute",
    "ProviderRoutes",
    "provider_routes",
    "record_to_provider_route",
]

_QUERIES_SQL_PATH: Path = Path(__file__).parent / "queries" / "provider_routes.sql"


def _load_queries() -> Any:  # noqa: ANN401 - aiosql exposes dynamic query attributes
    return aiosql.from_path(_QUERIES_SQL_PATH, "asyncpg")  # pyright: ignore[reportUnknownMemberType]


class BifrostProviderRoute(BaseModel):
    """Typed route-policy row returned by the Shield route store."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    sensitivity_tier: SensitivityTier
    provider: str
    model_id: str
    provider_secret_ref: str
    shield_enabled: bool
    priority: int = Field(ge=0)
    max_concurrent_calls: int = Field(ge=1)
    max_streaming_calls: int = Field(ge=1)
    requests_per_minute: int | None = Field(default=None, ge=1)
    tokens_per_minute: int | None = Field(default=None, ge=1)
    burst_limit: int | None = Field(default=None, ge=1)
    queue_policy: ShieldQueuePolicy
    queue_max_delay_ms: int = Field(ge=0, le=60_000)
    budget_scope: str
    base_url_override: str | None
    embedding_dimensions: int | None = Field(default=None, gt=0)
    embedding_dtype: str | None = None
    supports_chat: bool
    supports_agent_tool: bool
    supports_embedding: bool
    supports_search_query_embedding: bool
    supports_classification: bool
    supports_assertion_helper: bool
    is_active: bool
    created_at: datetime
    revoked_at: datetime | None

    @model_validator(mode="after")
    def _base_url_override_disabled_until_allowlisted(self) -> BifrostProviderRoute:
        if self.base_url_override is not None:
            raise ValueError("provider route base_url_override is disabled until allowlisted")
        has_embedding_capability = bool(
            self.capabilities
            & {
                RouteCapability.EMBEDDING,
                RouteCapability.SEARCH_QUERY_EMBEDDING,
            }
        )
        has_embedding_metadata = (
            self.embedding_dimensions is not None or self.embedding_dtype is not None
        )
        if has_embedding_metadata and (
            self.embedding_dimensions is None or self.embedding_dtype is None
        ):
            raise ValueError("embedding routes require embedding compatibility metadata")
        if not has_embedding_capability and has_embedding_metadata:
            raise ValueError("non-embedding routes cannot set embedding compatibility metadata")
        if (
            has_embedding_capability
            and self.provider == "voyage"
            and self.model_id == "voyage-4"
            and (self.embedding_dimensions != 1024 or self.embedding_dtype != "float")
        ):
            raise ValueError("voyage-4 embedding routes require 1024-dimensional float metadata")
        return self

    @property
    def capabilities(self) -> frozenset[RouteCapability]:
        """Return the route's explicit capability set."""

        capabilities: set[RouteCapability] = set()
        if self.supports_chat:
            capabilities.add(RouteCapability.CHAT)
        if self.supports_agent_tool:
            capabilities.add(RouteCapability.AGENT_TOOL)
        if self.supports_embedding:
            capabilities.add(RouteCapability.EMBEDDING)
        if self.supports_search_query_embedding:
            capabilities.add(RouteCapability.SEARCH_QUERY_EMBEDDING)
        if self.supports_classification:
            capabilities.add(RouteCapability.CLASSIFICATION)
        if self.supports_assertion_helper:
            capabilities.add(RouteCapability.ASSERTION_HELPER)
        return frozenset(capabilities)

    @property
    def usable_for_selection(self) -> bool:
        """Whether the route can be considered by route policy."""

        return self.is_active and self.revoked_at is None and self.shield_enabled


def _coerce_sensitivity(value: object) -> SensitivityTier:
    if isinstance(value, SensitivityTier):
        return value
    if isinstance(value, str):
        return SensitivityTier[value]
    raise TypeError(f"unsupported sensitivity_tier value: {value!r}")


def record_to_provider_route(record: Any) -> BifrostProviderRoute:  # noqa: ANN401 - asyncpg.Record stubs are partial
    """Project an asyncpg record into a typed provider-route row."""

    payload = dict(record)
    payload["sensitivity_tier"] = _coerce_sensitivity(payload["sensitivity_tier"])
    payload["provider"] = str(payload["provider"])
    return BifrostProviderRoute.model_validate(payload)


class ProviderRoutes:
    """aiosql-backed provider-route lookup wrapper."""

    def __init__(self, queries: Any | None = None) -> None:  # noqa: ANN401
        self._queries = queries if queries is not None else _load_queries()

    async def list_active_provider_routes(
        self,
        conn: asyncpg.Connection,
        *,
        tenant_id: UUID,
    ) -> tuple[BifrostProviderRoute, ...]:
        """Return active, non-revoked route rows visible for one tenant."""

        records = await self._queries.list_active_provider_routes(
            conn,
            tenant_id=tenant_id,
        )
        return tuple(record_to_provider_route(record) for record in records)


provider_routes: ProviderRoutes = ProviderRoutes()
