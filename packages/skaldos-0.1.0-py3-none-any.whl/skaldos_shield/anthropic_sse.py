"""Anthropic SSE frame assembly into Shield-safe stream events."""

from __future__ import annotations

import json
from enum import StrEnum
from typing import Annotated, Any, Literal, cast

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.contracts import ShieldErrorCode


class AnthropicSSEError(Exception):
    """Value-free Anthropic stream parsing failure."""

    error_code = ShieldErrorCode.PROVIDER_STREAM_MALFORMED

    def __init__(self) -> None:
        super().__init__(self.error_code.value)


class AnthropicStreamEventKind(StrEnum):
    """Low-cardinality stream event kinds emitted by the assembler."""

    MESSAGE_START = "message_start"
    MESSAGE_STOP = "message_stop"
    CONTENT_BLOCK_START = "content_block_start"
    CONTENT_BLOCK_STOP = "content_block_stop"
    TEXT_DELTA = "text_delta"
    TOOL_CALL_JSON = "tool_call_json"
    PING = "ping"


class AnthropicStreamSignal(BaseModel):
    """Payload-free stream signal."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[
        AnthropicStreamEventKind.MESSAGE_START,
        AnthropicStreamEventKind.MESSAGE_STOP,
        AnthropicStreamEventKind.CONTENT_BLOCK_START,
        AnthropicStreamEventKind.CONTENT_BLOCK_STOP,
        AnthropicStreamEventKind.PING,
    ]
    index: Annotated[int, Field(ge=0)] | None = None
    block_type: str | None = None
    tool_name: str | None = None


class AnthropicTextDelta(BaseModel):
    """Trusted provider text delta for later rehydration."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[AnthropicStreamEventKind.TEXT_DELTA] = AnthropicStreamEventKind.TEXT_DELTA
    index: Annotated[int, Field(ge=0)]
    text: str


class AnthropicToolCallJSON(BaseModel):
    """Complete tool-call JSON emitted only at content-block boundary."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[AnthropicStreamEventKind.TOOL_CALL_JSON] = AnthropicStreamEventKind.TOOL_CALL_JSON
    index: Annotated[int, Field(ge=0)]
    json_value: dict[str, Any] | list[Any] | str | int | float | bool | None


AnthropicStreamEvent = AnthropicStreamSignal | AnthropicTextDelta | AnthropicToolCallJSON


class AnthropicSSEAssembler:
    """Stateful Anthropic SSE assembler with buffered tool-call JSON deltas."""

    def __init__(self) -> None:
        self._tool_json_buffers: dict[int, list[str]] = {}

    def push_frame(self, frame: str) -> tuple[AnthropicStreamEvent, ...]:
        """Parse one SSE frame and return safe stream events."""

        event_name, payload = _parse_sse_frame(frame)
        if event_name in {"ping"}:
            return (
                AnthropicStreamSignal(
                    kind=AnthropicStreamEventKind.PING,
                ),
            )
        if event_name == "message_start":
            return (
                AnthropicStreamSignal(
                    kind=AnthropicStreamEventKind.MESSAGE_START,
                ),
            )
        if event_name in {"message_stop", "done"}:
            return (
                AnthropicStreamSignal(
                    kind=AnthropicStreamEventKind.MESSAGE_STOP,
                ),
            )
        if event_name == "content_block_start":
            return (self._handle_content_block_start(payload),)
        if event_name == "content_block_delta":
            return self._handle_content_block_delta(payload)
        if event_name == "content_block_stop":
            return self._handle_content_block_stop(payload)
        raise AnthropicSSEError

    def _handle_content_block_start(self, payload: dict[str, Any]) -> AnthropicStreamSignal:
        index = _event_index(payload)
        block = payload.get("content_block")
        if not isinstance(block, dict):
            raise AnthropicSSEError
        typed_block = cast(dict[str, Any], block)
        block_type = typed_block.get("type")
        if not isinstance(block_type, str):
            raise AnthropicSSEError
        tool_name = typed_block.get("name")
        if tool_name is not None and not isinstance(tool_name, str):
            raise AnthropicSSEError
        if block_type == "tool_use":
            self._tool_json_buffers[index] = []
        return AnthropicStreamSignal(
            kind=AnthropicStreamEventKind.CONTENT_BLOCK_START,
            index=index,
            block_type=block_type,
            tool_name=tool_name,
        )

    def _handle_content_block_delta(
        self,
        payload: dict[str, Any],
    ) -> tuple[AnthropicStreamEvent, ...]:
        index = _event_index(payload)
        delta = payload.get("delta")
        if not isinstance(delta, dict):
            raise AnthropicSSEError
        typed_delta = cast(dict[str, Any], delta)
        delta_type = typed_delta.get("type")
        if delta_type == "text_delta":
            text = typed_delta.get("text")
            if not isinstance(text, str):
                raise AnthropicSSEError
            return (AnthropicTextDelta(index=index, text=text),)
        if delta_type == "input_json_delta":
            partial_json = typed_delta.get("partial_json")
            if not isinstance(partial_json, str) or index not in self._tool_json_buffers:
                raise AnthropicSSEError
            self._tool_json_buffers[index].append(partial_json)
            return ()
        raise AnthropicSSEError

    def _handle_content_block_stop(
        self,
        payload: dict[str, Any],
    ) -> tuple[AnthropicStreamEvent, ...]:
        index = _event_index(payload)
        events: list[AnthropicStreamEvent] = []
        if index in self._tool_json_buffers:
            raw_json = "".join(self._tool_json_buffers.pop(index)) or "{}"
            try:
                json_value = json.loads(raw_json)
            except json.JSONDecodeError:
                raise AnthropicSSEError from None
            events.append(AnthropicToolCallJSON(index=index, json_value=json_value))
        events.append(
            AnthropicStreamSignal(
                kind=AnthropicStreamEventKind.CONTENT_BLOCK_STOP,
                index=index,
            )
        )
        return tuple(events)


def _parse_sse_frame(frame: str) -> tuple[str, dict[str, Any]]:
    event_name: str | None = None
    data_lines: list[str] = []
    for raw_line in frame.splitlines():
        line = raw_line.rstrip("\r")
        if not line or line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_name = line.removeprefix("event:").strip()
        elif line.startswith("data:"):
            data_lines.append(line.removeprefix("data:").lstrip())

    if event_name is None:
        raise AnthropicSSEError
    if data_lines == ["[DONE]"]:
        return "done", {}
    if not data_lines:
        payload: dict[str, Any] = {}
    else:
        try:
            loaded = json.loads("\n".join(data_lines))
        except json.JSONDecodeError:
            raise AnthropicSSEError from None
        if not isinstance(loaded, dict):
            raise AnthropicSSEError
        payload = cast(dict[str, Any], loaded)
    return event_name, payload


def _event_index(payload: dict[str, Any]) -> int:
    index = payload.get("index")
    if not isinstance(index, int) or index < 0:
        raise AnthropicSSEError
    return index
