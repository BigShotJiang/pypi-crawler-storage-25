"""Shared Shield contracts for Slice 5 Wave 0.

These types encode the master-plan contracts without adding detector,
provider, cache, or database dependencies. They are intentionally small and
provider-neutral so later features can consume one vocabulary for routing,
audit, session storage, streaming, and call-site adoption.
"""

from __future__ import annotations

from enum import IntEnum, StrEnum
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class SensitivityTier(IntEnum):
    """Ordinal Shield sensitivity tiers.

    The numeric values are part of the Slice 5 route-selection contract:
    callers may only raise sensitivity, never lower a detector result.
    """

    NON_PII = 0
    PII = 10
    PII_STRICT = 20
    CREDENTIALS = 30


class RouteCapability(StrEnum):
    """Model/provider capabilities that route selection filters before tier."""

    CHAT = "chat"
    AGENT_TOOL = "agent_tool"
    EMBEDDING = "embedding"
    SEARCH_QUERY_EMBEDDING = "search_query_embedding"
    CLASSIFICATION = "classification"
    ASSERTION_HELPER = "assertion_helper"


class TaskClass(StrEnum):
    """Canonical Shield task classes from the Slice 5 call surface."""

    CHAT = "chat"
    EMBEDDING = "embedding"
    SEARCH_QUERY = "search_query"
    AGENT_TOOL = "agent_tool"
    CLASSIFICATION = "classification"
    OTHER = "other"


_TASK_CAPABILITY: dict[TaskClass, RouteCapability] = {
    TaskClass.CHAT: RouteCapability.CHAT,
    TaskClass.EMBEDDING: RouteCapability.EMBEDDING,
    TaskClass.SEARCH_QUERY: RouteCapability.SEARCH_QUERY_EMBEDDING,
    TaskClass.AGENT_TOOL: RouteCapability.AGENT_TOOL,
    TaskClass.CLASSIFICATION: RouteCapability.CLASSIFICATION,
    TaskClass.OTHER: RouteCapability.CHAT,
}


def capability_for_task_class(task_class: TaskClass) -> RouteCapability:
    """Return the route capability required by a canonical task class."""

    return _TASK_CAPABILITY[task_class]


def effective_sensitivity(
    classified_tier: SensitivityTier,
    requested_tier: SensitivityTier | None,
) -> SensitivityTier:
    """Apply the no-downgrade rule for caller-requested sensitivity."""

    if requested_tier is None:
        return classified_tier
    return max(classified_tier, requested_tier)


class RequestShape(StrEnum):
    """Supported Shield request shapes for Slice 5."""

    CANONICAL = "canonical"


class LatencyMode(StrEnum):
    """Admission-control latency mode."""

    SYNC = "sync"
    BATCH = "batch"


class MessagePartType(StrEnum):
    """Provider message-part taxonomy used by policy and scanning."""

    SYSTEM = "system"
    DEVELOPER = "developer"
    USER_TEXT = "user_text"
    TOOL_RESULT = "tool_result"
    TOOL_CALL_ARGUMENTS = "tool_call_arguments"
    IMAGE = "image"
    BINARY = "binary"
    UNKNOWN = "unknown"


class ShieldMessageRole(StrEnum):
    """Provider-neutral role names accepted by the canonical surface."""

    SYSTEM = "system"
    DEVELOPER = "developer"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class MessagePart(BaseModel):
    """One canonical message part.

    ``text`` may contain user content before scanning. Tests for this model
    must not serialize it into audit/log metadata; it is request-body material.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: MessagePartType
    text: str | None = None
    json_value: dict[str, Any] | list[Any] | str | int | float | bool | None = None
    media_type: str | None = None

    @model_validator(mode="after")
    def _require_payload_for_text_parts(self) -> MessagePart:
        text_types = {
            MessagePartType.SYSTEM,
            MessagePartType.DEVELOPER,
            MessagePartType.USER_TEXT,
            MessagePartType.TOOL_RESULT,
        }
        if self.type in text_types and self.text is None:
            raise ValueError(f"{self.type.value} requires text")
        if self.type == MessagePartType.TOOL_CALL_ARGUMENTS and self.json_value is None:
            raise ValueError("tool_call_arguments requires json_value")
        return self


class ShieldMessage(BaseModel):
    """One canonical Shield message made from explicit parts."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    role: ShieldMessageRole
    parts: Annotated[list[MessagePart], Field(min_length=1)]


class ModelHint(BaseModel):
    """Optional provider/model constraints, not route-selection authority."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    provider: str | None = None
    model_id: str | None = None
    capabilities: frozenset[RouteCapability] = frozenset()


class RequestedRoute(BaseModel):
    """Optional policy route constraint copied from Hall's safe route snapshot.

    This is a Shield-side constraint, not Pi authority. It carries no provider
    endpoint, SDK configuration, or credential material.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    route_id: UUID | None = None
    provider: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_-]{0,63}$")] | None = None
    model_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}$")] | None = None
    capability: RouteCapability | None = None
    policy_version: (
        Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$")] | None
    ) = None


class ShieldBudgetConstraints(BaseModel):
    """Value-free request budget constraints copied from route policy data."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    max_input_tokens: Annotated[int, Field(gt=0)] | None = None
    max_output_tokens: Annotated[int, Field(gt=0)] | None = None
    max_cost_minor_units: Annotated[int, Field(ge=0)] | None = None
    scope: Literal["tenant", "principal", "agent_run", "route"] | None = None


class ShieldLatencyConstraints(BaseModel):
    """Value-free latency constraints copied from route policy data."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    max_latency_ms: Annotated[int, Field(gt=0)] | None = None
    queue_policy: Literal["reject", "queue", "batch"] | None = None


class CanonicalShieldRequest(BaseModel):
    """Provider-neutral Shield request.

    ``organization_id`` is the public/API compatibility field. Shield service
    internals should use the ``tenant_id`` property after this boundary.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["skaldos.shield.canonical.v1"] = "skaldos.shield.canonical.v1"
    organization_id: UUID
    principal_id: UUID
    redaction_session_id: UUID | None = None
    agent_run_id: UUID | None = None
    tool_call_id: UUID | None = None
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")] | None = None
    span_id: Annotated[str, Field(pattern=r"^[0-9a-f]{16}$")] | None = None
    parent_shield_call_id: UUID | None = None
    task_class: TaskClass
    request_shape: RequestShape = RequestShape.CANONICAL
    latency_mode: LatencyMode = LatencyMode.SYNC
    requested_sensitivity: SensitivityTier | None = None
    stream: bool = False
    messages: Annotated[list[ShieldMessage], Field(min_length=1)]
    model_hint: ModelHint | None = None
    requested_route: RequestedRoute | None = None
    budget: ShieldBudgetConstraints | None = None
    latency: ShieldLatencyConstraints | None = None

    @field_validator("request_shape")
    @classmethod
    def _canonical_only(cls, value: RequestShape) -> RequestShape:
        if value != RequestShape.CANONICAL:
            raise ValueError("Slice 5 supports only the canonical Shield request shape")
        return value

    @property
    def required_capability(self) -> RouteCapability:
        """Capability the route selector must require before tier filtering."""

        return capability_for_task_class(self.task_class)

    @property
    def tenant_id(self) -> UUID:
        """Storage/service tenant id normalized from the public field."""

        return self.organization_id


class DetectionStatus(StrEnum):
    """Detector result status; no non-clean failure may be treated as clean."""

    CLEAN = "clean"
    DETECTED = "detected"
    OVERSIZED = "oversized"
    UNSCANNABLE = "unscannable"
    TIMEOUT = "timeout"
    ERROR = "error"
    SATURATED = "saturated"


class DetectionAction(StrEnum):
    """Value-free action vocabulary recorded in Shield metadata."""

    NONE = "none"
    SUBSTITUTE = "substitute"
    STRIP = "strip"
    BLOCK = "block"
    ESCAPE_LITERAL_PLACEHOLDER = "escape_literal_placeholder"


class ReplacementMode(StrEnum):
    """Provider-safe replacement modes pinned by the detector contract."""

    SYNTHETIC_SUBSTITUTION = "synthetic_substitution"
    STRIP_PLACEHOLDERS = "strip_placeholders"
    ENCRYPT_HANDOFF = "encrypt_handoff"


class CredentialReplacement(StrEnum):
    """Credential handling is always inert; secrets are never synthetic PII."""

    NONE = "none"
    INERT_PLACEHOLDER = "inert_placeholder"


class ConfidenceBucket(StrEnum):
    """Coarse confidence buckets; raw scores stay detector-local."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class DetectionFinding(BaseModel):
    """Serializable detection metadata without values or raw spans."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    entity_type: str
    category: str
    count: Annotated[int, Field(ge=1)]
    confidence: ConfidenceBucket
    action: DetectionAction
    char_count_bucket: str

    @field_validator("entity_type", "category", "char_count_bucket")
    @classmethod
    def _non_empty_metadata(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("metadata fields must be non-empty")
        if "[" in value or "]" in value:
            raise ValueError("metadata fields must not carry placeholder text")
        return value


class RequiredSensitivity(BaseModel):
    """No-downgrade sensitivity decision consumed by routing and audit."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    classified_tier: SensitivityTier
    requested_tier: SensitivityTier | None = None
    effective_tier: SensitivityTier

    @model_validator(mode="after")
    def _effective_tier_matches_no_downgrade(self) -> RequiredSensitivity:
        expected_tier = effective_sensitivity(self.classified_tier, self.requested_tier)
        if self.effective_tier != expected_tier:
            raise ValueError("effective_tier must apply the no-downgrade rule")
        return self


class DetectionPlan(BaseModel):
    """Value-free detector plan handed to routing, audit, and policy."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: DetectionStatus
    registry_version: str
    rule_source_version: str
    required_sensitivity: SensitivityTier
    findings: tuple[DetectionFinding, ...] = ()
    input_size_bucket: str | None = None
    latency_ms_bucket: str | None = None

    @model_validator(mode="after")
    def _status_matches_findings(self) -> DetectionPlan:
        if self.status == DetectionStatus.CLEAN and self.findings:
            raise ValueError("clean detection plans cannot carry findings")
        if self.status == DetectionStatus.DETECTED and not self.findings:
            raise ValueError("detected detection plans require findings")
        if (
            self.status != DetectionStatus.CLEAN
            and self.required_sensitivity == SensitivityTier.NON_PII
        ):
            raise ValueError("non-clean detection plans cannot require NON_PII")
        return self


class PolicyOutcome(StrEnum):
    """Shield policy outcomes for safe responses and evidence rows."""

    PASSED = "passed"
    REDACTED = "redacted"
    BLOCKED = "blocked"
    FAIL_OPEN = "fail_open"


class ReplacementResult(BaseModel):
    """Provider-safe substitution output from the replacement boundary.

    ``provider_safe_text`` is the only text this contract exposes. Raw matched
    values and encrypted payloads stay behind detector/session-store internals.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    mode: ReplacementMode
    provider_safe_text: str
    required_sensitivity: RequiredSensitivity
    findings: tuple[DetectionFinding, ...] = ()
    replacement_count: Annotated[int, Field(ge=0)] = 0
    escaped_literal_placeholder_count: Annotated[int, Field(ge=0)] = 0
    credential_replacement: CredentialReplacement = CredentialReplacement.NONE
    encrypted_token_refs: tuple[str, ...] = ()

    @model_validator(mode="after")
    def _mode_specific_contract(self) -> ReplacementResult:
        if (
            self.required_sensitivity.effective_tier == SensitivityTier.CREDENTIALS
            and self.credential_replacement != CredentialReplacement.INERT_PLACEHOLDER
        ):
            raise ValueError("credential replacements must use inert placeholders")
        if (
            self.mode == ReplacementMode.ENCRYPT_HANDOFF
            and self.encrypted_token_refs
            and self.credential_replacement != CredentialReplacement.NONE
        ):
            raise ValueError("encrypt handoff cannot synthesize credential values")
        if self.mode != ReplacementMode.ENCRYPT_HANDOFF and self.encrypted_token_refs:
            raise ValueError("encrypted token refs are only valid for encrypt handoff")
        return self


class ShieldErrorCode(StrEnum):
    """Stable Slice 5 policy/error reason codes."""

    INVALID_REQUEST = "shield_invalid_request"
    IDENTITY_MISMATCH = "shield_identity_mismatch"
    TRACE_CONTEXT_REQUIRED = "shield_trace_context_required"
    REDACTION_SESSION_UNAVAILABLE = "shield_redaction_session_unavailable"
    CONTENT_UNSCANNABLE = "shield_content_unscannable"
    SENSITIVITY_DOWNGRADE_REJECTED = "shield_sensitivity_downgrade_rejected"
    OVERSIZED = "shield_oversized"
    UNSCANNABLE = "shield_unscannable"
    DETECTOR_TIMEOUT = "shield_detector_timeout"
    DETECTOR_ERROR = "shield_detector_error"
    UNSUPPORTED_PART = "shield_unsupported_part"
    ROUTE_UNAVAILABLE = "shield_route_unavailable"
    CREDENTIAL_ROUTE_REQUIRED = "shield_credential_route_required"
    CREDENTIAL_UNAVAILABLE = "credential_unavailable"
    CREDENTIAL_CONFIGURATION_ERROR = "credential_configuration_error"
    CREDENTIAL_DESTROYED = "credential_destroyed"
    STREAM_INCOMPLETE_REHYDRATION = "shield_stream_incomplete_rehydration"
    PROVIDER_STREAM_MALFORMED = "shield_provider_stream_malformed"
    AUDIT_UNAVAILABLE = "shield_audit_unavailable"
    SHIELD_DISABLED = "shield_disabled"
    KMS_UNAVAILABLE = "kms_unavailable"
    KEY_DESTROYED = "shield_key_destroyed"
    REHYDRATION_UNAVAILABLE = "shield_rehydration_unavailable"
    TENANT_CONCURRENCY_EXCEEDED = "shield_tenant_concurrency_exceeded"
    PRINCIPAL_CONCURRENCY_EXCEEDED = "shield_principal_concurrency_exceeded"
    AGENT_RUN_CONCURRENCY_EXCEEDED = "shield_agent_run_concurrency_exceeded"
    ROUTE_BUDGET_EXHAUSTED = "shield_route_budget_exhausted"
    STREAMING_CAPACITY_EXCEEDED = "shield_streaming_capacity_exceeded"
    DETECTOR_SATURATED = "shield_detector_saturated"
    PROVIDER_RATE_LIMITED = "shield_provider_rate_limited"
    PROVIDER_CALL_FAILED = "shield_provider_call_failed"
    UNAVAILABLE = "shield_unavailable"


class SafeShieldError(BaseModel):
    """Caller-visible Shield error envelope with no request/provider content."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    code: ShieldErrorCode
    http_status: Annotated[int, Field(ge=400, le=599)]
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")] | None = None
    shield_call_id: UUID | None = None
    retryable: bool = False

    @property
    def detail(self) -> str:
        """Safe FastAPI-style detail string; intentionally just the code."""

        return self.code.value


class RouteMetadata(BaseModel):
    """Safe selected-route metadata returned by Shield."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    route_id: UUID
    provider: str
    model_id: str
    sensitivity_used: SensitivityTier
    fallback_distance: Annotated[int, Field(ge=0)]
    capability: RouteCapability | None = None
    embedding_dimensions: Annotated[int, Field(gt=0)] | None = None
    embedding_dtype: str | None = None
    route_policy_version: str | None = None


class UsageMetadata(BaseModel):
    """Value-free provider usage metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tokens_in: int | None = None
    tokens_out: int | None = None
    cache_hit: bool = False
    estimated_cost_minor_units: int | None = None


class ShieldResultKind(StrEnum):
    """Trusted result envelope variants returned by canonical Shield calls."""

    MESSAGE = "message"
    EMBEDDING = "embedding"


class TrustedMessageResult(BaseModel):
    """Trusted rehydrated message result for chat/tool/classification calls."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[ShieldResultKind.MESSAGE] = ShieldResultKind.MESSAGE
    messages: Annotated[list[ShieldMessage], Field(min_length=1)]


class TrustedEmbeddingResult(BaseModel):
    """Trusted embedding/search-query result without provider-specific DTOs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[ShieldResultKind.EMBEDDING] = ShieldResultKind.EMBEDDING
    vectors: Annotated[list[list[float]], Field(min_length=1)]
    dimensions: Annotated[int, Field(gt=0)]
    dtype: Literal["float"] = "float"
    provider_safe_texts: tuple[str, ...] = Field(default=(), exclude=True)

    @model_validator(mode="after")
    def _dimensions_match_vectors(self) -> TrustedEmbeddingResult:
        if any(len(vector) != self.dimensions for vector in self.vectors):
            raise ValueError("embedding vector dimensions must match dimensions")
        if self.provider_safe_texts and len(self.provider_safe_texts) != len(self.vectors):
            raise ValueError("provider-safe embedding texts must match vector count")
        return self


ShieldTrustedResult = Annotated[
    TrustedMessageResult | TrustedEmbeddingResult,
    Field(discriminator="kind"),
]


class CanonicalShieldResponse(BaseModel):
    """Provider-neutral response with trusted result and safe metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    call_id: UUID
    route: RouteMetadata | None = None
    result: ShieldTrustedResult | None = None
    policy_outcome: PolicyOutcome
    usage: UsageMetadata = UsageMetadata()
    warnings: tuple[ShieldErrorCode, ...] = ()
    trace_id: str | None = None
    span_id: str | None = None

    @property
    def shield_call_id(self) -> UUID:
        """Evidence id vocabulary used by Slice 7 Hall/Pi contracts."""

        return self.call_id
