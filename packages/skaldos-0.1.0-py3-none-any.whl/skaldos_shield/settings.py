"""Shield settings contracts for Slice 5 Wave 0."""

from __future__ import annotations

from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from skaldos_shield.contracts import ShieldErrorCode


class ShieldEnvironment(StrEnum):
    """Deployment environment names consumed by Shield startup validation."""

    DEVELOPMENT = "development"
    TEST = "test"
    STAGING = "staging"
    PRODUCTION = "production"


class DetectorDependencyPosture(StrEnum):
    """Wave 0 detector dependency posture.

    No runtime detector dependency is approved by this enum. It records that
    implementation must use a reviewed registry adapter before adding a
    concrete detector/scanner package or tool.
    """

    ADR_REQUIRED = "adr_required"


class ProviderRouteSource(StrEnum):
    """Coarse provider-route configuration posture for readiness checks."""

    UNCONFIGURED = "unconfigured"
    FIXTURE = "fixture"
    CONFIGURED = "configured"


class DetectorRegistrySource(StrEnum):
    """Coarse detector registry posture for readiness checks."""

    UNCONFIGURED = "unconfigured"
    FIXTURE = "fixture"
    CONFIGURED = "configured"


class AuditSinkPosture(StrEnum):
    """Coarse audit sink posture for readiness checks."""

    UNCONFIGURED = "unconfigured"
    DISABLED_FOR_SCAFFOLD = "disabled_for_scaffold"
    CONFIGURED = "configured"


class ShieldSettings(BaseSettings):
    """Security-critical Shield process settings.

    Later service-foundation PRs will instantiate this during FastAPI lifespan
    startup. The model exists now so fail-closed defaults and dependency
    boundaries are pinned before implementation fanout.
    """

    model_config: ClassVar[SettingsConfigDict] = SettingsConfigDict(
        env_prefix="SHIELD_",
        env_file=None,
        case_sensitive=False,
        extra="ignore",
    )

    environment: ShieldEnvironment = ShieldEnvironment.DEVELOPMENT
    detector_dependency_posture: DetectorDependencyPosture = DetectorDependencyPosture.ADR_REQUIRED
    auth_issuer: str | None = None
    auth_audience: str | None = None
    kms_key_reference: str | None = None
    detector_registry_source: DetectorRegistrySource = DetectorRegistrySource.UNCONFIGURED
    detector_rule_source_version: str | None = None
    detector_registry_count: int = Field(default=0, ge=0)
    fixture_detector_enabled: bool = False
    provider_route_source: ProviderRouteSource = ProviderRouteSource.UNCONFIGURED
    audit_sink_posture: AuditSinkPosture = AuditSinkPosture.UNCONFIGURED
    fixture_provider_enabled: bool = False
    fixture_tenant_id: UUID | None = None
    fixture_detector_marker: str = "fixture-person-email-token"
    fail_open_enabled: bool = False
    production_audit_required: bool = True
    otlp_exporter_enabled: bool = True
    staging_smoke_enabled: bool = True
    route_budget_default_concurrency: int = Field(default=4, ge=1)
    route_budget_default_streaming_concurrency: int = Field(default=2, ge=1)
    route_budget_default_queue_max_delay_ms: int = Field(default=2_000, ge=0)
    route_credential_resolver_enabled: bool = False
    database_url: str | None = None
    configured_tenant_ids: str | None = None
    kms_backend: str = "gcp"

    @model_validator(mode="after")
    def _production_is_fail_closed(self) -> ShieldSettings:
        if self.environment == ShieldEnvironment.PRODUCTION:
            if self.fixture_detector_enabled:
                raise ValueError("Shield fixture detector mode is forbidden in production")
            if self.detector_registry_source == DetectorRegistrySource.FIXTURE:
                raise ValueError("Shield fixture detector source is forbidden in production")
            if self.detector_registry_source != DetectorRegistrySource.CONFIGURED:
                raise ValueError("production Shield requires a configured detector registry")
            if not self.detector_rule_source_version:
                raise ValueError("production Shield requires detector rule source version")
            if self.detector_registry_count < 1:
                raise ValueError("production Shield requires at least one detector")
            if self.fixture_provider_enabled:
                raise ValueError("Shield fixture provider mode is forbidden in production")
            if (
                self.provider_route_source == ProviderRouteSource.CONFIGURED
                and not self.route_credential_resolver_enabled
            ):
                raise ValueError(
                    "production live provider routes require route credential resolver"
                )
            if (
                self.provider_route_source == ProviderRouteSource.CONFIGURED
                and self.route_credential_resolver_enabled
                and not self.kms_key_reference
            ):
                raise ValueError("production live provider routes require KMS binding")
            if (
                self.provider_route_source == ProviderRouteSource.CONFIGURED
                and not self.database_url
            ):
                raise ValueError("production live provider routes require database URL")
            if self.fail_open_enabled:
                raise ValueError("Shield fail-open default is forbidden in production")
            if not self.production_audit_required:
                raise ValueError("production Shield calls require pre-provider audit evidence")
        return self


FAIL_CLOSED_ERROR_CODES: frozenset[ShieldErrorCode] = frozenset(
    {
        ShieldErrorCode.AUDIT_UNAVAILABLE,
        ShieldErrorCode.CREDENTIAL_ROUTE_REQUIRED,
        ShieldErrorCode.CREDENTIAL_UNAVAILABLE,
        ShieldErrorCode.CREDENTIAL_DESTROYED,
        ShieldErrorCode.CREDENTIAL_CONFIGURATION_ERROR,
        ShieldErrorCode.KMS_UNAVAILABLE,
        ShieldErrorCode.KEY_DESTROYED,
        ShieldErrorCode.REHYDRATION_UNAVAILABLE,
        ShieldErrorCode.ROUTE_UNAVAILABLE,
    }
)
"""Failure classes that must block provider dispatch by default."""
