"""Shield streaming response emission through trusted rehydration."""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping
from enum import StrEnum
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.anthropic_sse import (
    AnthropicSSEAssembler,
    AnthropicStreamEvent,
    AnthropicStreamEventKind,
    AnthropicStreamSignal,
    AnthropicTextDelta,
    AnthropicToolCallJSON,
)
from skaldos_shield.contracts import PolicyOutcome, RouteMetadata, ShieldErrorCode
from skaldos_shield.rehydration import RehydrationLookup, StreamingRehydrator


class ShieldStreamingEventKind(StrEnum):
    """Low-cardinality trusted streaming event kind."""

    PRELUDE = "prelude"
    SIGNAL = "signal"
    TEXT = "text"
    TOOL_CALL_JSON = "tool_call_json"


class ShieldStreamingPreludeEvent(BaseModel):
    """Content-free evidence event emitted before any streaming content."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[ShieldStreamingEventKind.PRELUDE] = ShieldStreamingEventKind.PRELUDE
    shield_call_id: UUID
    route: RouteMetadata
    policy_outcome: PolicyOutcome
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")]
    span_id: Annotated[str, Field(pattern=r"^[0-9a-f]{16}$")]
    redaction_session_id: UUID | None = None
    redaction_skipped: bool = False
    redaction_skip_reason: str | None = None
    warnings: tuple[ShieldErrorCode, ...] = ()


class ShieldStreamingSignalEvent(BaseModel):
    """Payload-free trusted stream signal."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[ShieldStreamingEventKind.SIGNAL] = ShieldStreamingEventKind.SIGNAL
    upstream_kind: AnthropicStreamEventKind
    index: Annotated[int, Field(ge=0)] | None = None
    block_type: str | None = None
    tool_name: str | None = None


class ShieldStreamingTextEvent(BaseModel):
    """Trusted text that is safe to emit downstream."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[ShieldStreamingEventKind.TEXT] = ShieldStreamingEventKind.TEXT
    index: Annotated[int, Field(ge=0)]
    text: str


class ShieldStreamingToolCallJSONEvent(BaseModel):
    """Complete tool-call JSON emitted at a safe content-block boundary."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal[ShieldStreamingEventKind.TOOL_CALL_JSON] = ShieldStreamingEventKind.TOOL_CALL_JSON
    index: Annotated[int, Field(ge=0)]
    json_value: dict[str, Any] | list[Any] | str | int | float | bool | None


ShieldStreamingEvent = (
    ShieldStreamingPreludeEvent
    | ShieldStreamingSignalEvent
    | ShieldStreamingTextEvent
    | ShieldStreamingToolCallJSONEvent
)


class ShieldStreamingTelemetry(BaseModel):
    """Value-free stream telemetry safe for logs, spans, and audit metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    upstream_event_counts: Mapping[str, int] = Field(default_factory=dict)
    emitted_event_counts: Mapping[str, int] = Field(default_factory=dict)
    trace_id: str | None = None


class ShieldStreamingEmitter:
    """Emit trusted Shield stream events from Anthropic SSE frames."""

    def __init__(
        self,
        lookup: RehydrationLookup,
        *,
        prelude: ShieldStreamingPreludeEvent,
        assembler: AnthropicSSEAssembler | None = None,
        trace_id: str | None = None,
    ) -> None:
        self._assembler = assembler or AnthropicSSEAssembler()
        self._rehydrator = StreamingRehydrator(lookup)
        self._prelude = prelude
        self._prelude_emitted = False
        self._trace_id = trace_id
        self._upstream_event_counts: Counter[str] = Counter()
        self._emitted_event_counts: Counter[str] = Counter()
        self._closed = False
        self._last_text_index = 0

    async def push_frame(self, frame: str) -> tuple[ShieldStreamingEvent, ...]:
        """Process one upstream SSE frame and return trusted events."""

        if self._closed:
            return ()
        trusted_events: list[ShieldStreamingEvent] = list(self._emit_prelude_once())
        for event in self._assembler.push_frame(frame):
            self._upstream_event_counts[event.kind.value] += 1
            trusted_events.extend(await self._emit_event(event))
        return tuple(trusted_events)

    async def close(self) -> tuple[ShieldStreamingEvent, ...]:
        """Flush trusted text on local stream close."""

        if self._closed:
            return ()
        self._closed = True
        trusted_events: list[ShieldStreamingEvent] = list(self._emit_prelude_once())
        trusted_text = await self._rehydrator.close()
        if trusted_text:
            trusted_events.append(
                self._record(
                    ShieldStreamingTextEvent(index=self._last_text_index, text=trusted_text)
                )
            )
        return tuple(trusted_events)

    def telemetry(self) -> ShieldStreamingTelemetry:
        """Return value-free stream telemetry."""

        return ShieldStreamingTelemetry(
            upstream_event_counts=dict(self._upstream_event_counts),
            emitted_event_counts=dict(self._emitted_event_counts),
            trace_id=self._trace_id,
        )

    async def _emit_event(self, event: AnthropicStreamEvent) -> tuple[ShieldStreamingEvent, ...]:
        if isinstance(event, AnthropicTextDelta):
            self._last_text_index = event.index
            trusted_text = await self._rehydrator.push(event.text)
            if not trusted_text:
                return ()
            return (self._record(ShieldStreamingTextEvent(index=event.index, text=trusted_text)),)

        if isinstance(event, AnthropicToolCallJSON):
            return (
                self._record(
                    ShieldStreamingToolCallJSONEvent(
                        index=event.index,
                        json_value=event.json_value,
                    )
                ),
            )

        if event.kind == AnthropicStreamEventKind.MESSAGE_STOP:
            stop_events = list(await self.close())
            stop_events.append(self._record(_signal(event)))
            return tuple(stop_events)
        return (self._record(_signal(event)),)

    def _record(self, event: ShieldStreamingEvent) -> ShieldStreamingEvent:
        self._emitted_event_counts[event.kind.value] += 1
        return event

    def _emit_prelude_once(self) -> tuple[ShieldStreamingEvent, ...]:
        if self._prelude_emitted:
            return ()
        self._prelude_emitted = True
        return (self._record(self._prelude),)


def _signal(event: AnthropicStreamSignal) -> ShieldStreamingSignalEvent:
    return ShieldStreamingSignalEvent(
        upstream_kind=event.kind,
        index=event.index,
        block_type=event.block_type,
        tool_name=event.tool_name,
    )
