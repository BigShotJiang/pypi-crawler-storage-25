"""Non-streaming Shield call core skeleton with fake-provider support."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import UTC, datetime
from enum import StrEnum
from time import monotonic
from typing import Protocol
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict

from skaldos_shield.admission import (
    ShieldAdmissionBudget,
    ShieldAdmissionContext,
    ShieldCallMode,
)
from skaldos_shield.audit_records import (
    AuditTraceContext,
    ShieldAuditDetection,
    ShieldAuditOutcome,
    ShieldCallCompletion,
    ShieldCallRecord,
    ShieldCallStart,
)
from skaldos_shield.backpressure import (
    ShieldBackpressureError,
    ShieldProviderRateLimitError,
    backpressure_response_from_capacity_error,
    provider_rate_limit_backpressure_response,
)
from skaldos_shield.capacity import ShieldCapacityLeaseError, ShieldCapacityLeaser
from skaldos_shield.contracts import (
    CanonicalShieldRequest,
    CanonicalShieldResponse,
    DetectionStatus,
    MessagePartType,
    ModelHint,
    PolicyOutcome,
    ReplacementMode,
    RequestShape,
    RouteCapability,
    RouteMetadata,
    SafeShieldError,
    SensitivityTier,
    ShieldErrorCode,
    ShieldResultKind,
    ShieldTrustedResult,
    TaskClass,
    TrustedMessageResult,
    capability_for_task_class,
    effective_sensitivity,
)
from skaldos_shield.credentials import (
    ResolvedRouteCredential,
    RouteCredentialResolutionError,
    RouteCredentialResolver,
    UnconfiguredRouteCredentialResolver,
)
from skaldos_shield.detectors import (
    DetectorAnalysis,
    DetectorRegistry,
    validate_production_detector_registry,
)
from skaldos_shield.provider_adapters import (
    ProviderAdapterRequest,
    ProviderAdapterResponse,
    ShieldProviderAdapter,
    ShieldProviderCallError,
)
from skaldos_shield.redaction_pipeline import (
    ProviderSafeMessagePart,
    RedactionPartMetadata,
    RedactionPipeline,
)
from skaldos_shield.request_normalizer import NormalizedMessagePart, normalize_canonical_request
from skaldos_shield.routes_store import BifrostProviderRoute
from skaldos_shield.routing import RouteSelectionError, select_shield_route
from skaldos_shield.scan_budget import evaluate_scan_budget_for_parts
from skaldos_shield.session_store import RedactionSessionStore


class ShieldAuditUnavailableError(Exception):
    """Raised when pre-provider audit cannot be durably written."""

    error_code = ShieldErrorCode.AUDIT_UNAVAILABLE


class ShieldRequestValidationError(Exception):
    """Raised before provider dispatch when canonical request constraints fail."""

    def __init__(self, safe_error: SafeShieldError) -> None:
        super().__init__(safe_error.code.value)
        self.safe_error = safe_error

    def with_shield_call_id(self, shield_call_id: UUID) -> ShieldRequestValidationError:
        """Return the same safe error code annotated with durable evidence id."""

        return ShieldRequestValidationError(
            self.safe_error.model_copy(update={"shield_call_id": shield_call_id})
        )


class ShieldPolicyBlockedError(Exception):
    """Raised after Shield records value-free evidence for a blocked call."""

    def __init__(
        self,
        *,
        response: CanonicalShieldResponse,
        blocked_parts: tuple[ShieldBlockedPartEvidence, ...],
        call_record_id: UUID,
    ) -> None:
        code = response.warnings[0] if response.warnings else ShieldErrorCode.UNSCANNABLE
        super().__init__(code.value)
        self.response = response
        self.blocked_parts = blocked_parts
        self.call_record_id = call_record_id


class ShieldBlockedPartEvidence(BaseModel):
    """Value-free blocked-part evidence safe for logs, tests, and audit metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    part_type: MessagePartType
    message_index: int
    part_index: int
    source_field: str
    scan_outcome: str
    policy_action: str
    char_size_bucket: str
    byte_size_bucket: str
    error_code: ShieldErrorCode


class DisabledShieldPolicy(StrEnum):
    """Local Slice 5 disabled-Shield policy posture."""

    FAIL_CLOSED = "fail_closed"
    DEV_FAIL_OPEN = "dev_fail_open"


class ShieldCallAuditWriter(Protocol):
    """Content-free audit writer boundary used by call core."""

    async def insert_call_attempt(self, attempt: ShieldCallStart) -> ShieldCallRecord:
        """Durably record a pre-provider Shield attempt."""
        ...

    async def complete_call(
        self,
        *,
        tenant_id: UUID,
        call_record_id: UUID,
        completion: ShieldCallCompletion,
    ) -> ShieldCallRecord:
        """Complete an existing Shield call record."""
        ...


class ShieldCallCoreResult(BaseModel):
    """Call-core result plus safe execution metadata for tests/call sites."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    response: CanonicalShieldResponse
    call_record_id: UUID


class ShieldCallCore:
    """Coordinate canonical normalization, redaction, audit, lease, and provider call."""

    def __init__(
        self,
        *,
        routes: tuple[BifrostProviderRoute, ...],
        detector_registry: DetectorRegistry,
        redaction_pipeline: RedactionPipeline | None,
        session_store: RedactionSessionStore | None,
        capacity_leaser: ShieldCapacityLeaser,
        audit_writer: ShieldCallAuditWriter,
        provider_adapter: ShieldProviderAdapter,
        capacity_budget: ShieldAdmissionBudget | None = None,
        disabled_shield_policies: Mapping[UUID, DisabledShieldPolicy] | None = None,
        production_detector_rule_source_version: str | None = None,
        route_credential_resolver: RouteCredentialResolver | None = None,
        require_route_credentials: bool = True,
    ) -> None:
        if production_detector_rule_source_version is not None:
            validate_production_detector_registry(
                detector_registry,
                rule_source_version=production_detector_rule_source_version,
            )
        self._routes = routes
        self._detector_registry = detector_registry
        self._redaction_pipeline = redaction_pipeline or RedactionPipeline()
        self._session_store = session_store
        self._capacity_leaser = capacity_leaser
        self._audit_writer = audit_writer
        self._provider_adapter = provider_adapter
        self._capacity_budget = capacity_budget or ShieldAdmissionBudget()
        self._disabled_shield_policies = dict(disabled_shield_policies or {})
        self._route_credential_resolver = (
            route_credential_resolver or UnconfiguredRouteCredentialResolver()
        )
        self._require_route_credentials = require_route_credentials

    async def complete(self, request: CanonicalShieldRequest) -> ShieldCallCoreResult:
        """Execute one non-streaming canonical Shield call."""

        if request.stream:
            raise ValueError("ShieldCallCore.complete handles non-streaming calls only")
        _require_trace_context(request)

        started_at = monotonic()
        call_id = uuid4()
        normalized = normalize_canonical_request(request)
        scan_decisions = evaluate_scan_budget_for_parts(normalized.parts)
        detector_analyses = tuple(self._analyze_part(part) for part in normalized.parts)
        redaction = await self._redaction_pipeline.apply(
            normalized_request=normalized,
            scan_budget_decisions=scan_decisions,
            detector_analyses=detector_analyses,
            mode=_replacement_mode_for_task_class(request.task_class),
            session_id=request.redaction_session_id,
            session_store=self._session_store,
            requested_sensitivity=request.requested_sensitivity,
        )
        if redaction.blocks_provider_dispatch:
            call_record = await self._insert_pre_provider_audit(
                request=request,
                sensitivity_classified=redaction.required_sensitivity.classified_tier,
                detections=_audit_detections(detector_analyses),
            )
            blocked_code = redaction.error_code or ShieldErrorCode.UNSCANNABLE
            blocked_parts = _blocked_part_evidence(redaction.metadata)
            await self._audit_writer.complete_call(
                tenant_id=request.tenant_id,
                call_record_id=call_record.id,
                completion=ShieldCallCompletion(
                    policy_outcome=ShieldAuditOutcome.BLOCKED,
                    latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
                    redaction_skipped=True,
                    redaction_skip_reason=_redaction_skip_reason(blocked_code),
                ),
            )
            raise ShieldPolicyBlockedError(
                response=CanonicalShieldResponse(
                    call_id=call_record.id,
                    policy_outcome=PolicyOutcome.BLOCKED,
                    warnings=(blocked_code,),
                    trace_id=call_record.trace_id,
                    span_id=call_record.span_id,
                ),
                blocked_parts=blocked_parts,
                call_record_id=call_record.id,
            )

        try:
            route_decision = select_shield_route(
                self._routes,
                tenant_id=request.tenant_id,
                task_class=request.task_class,
                classified_tier=redaction.required_sensitivity.classified_tier,
                requested_tier=redaction.required_sensitivity.requested_tier,
                model_hint=request.model_hint,
            )
        except RouteSelectionError:
            disabled_route = _select_disabled_route(
                self._routes,
                request=request,
                classified_tier=redaction.required_sensitivity.classified_tier,
                requested_tier=redaction.required_sensitivity.requested_tier,
            )
            if disabled_route is None:
                call_record = await self._insert_pre_provider_audit(
                    request=request,
                    sensitivity_classified=redaction.required_sensitivity.classified_tier,
                    detections=_audit_detections(detector_analyses),
                )
                await self._complete_route_selection_block(
                    request=request,
                    call_record=call_record,
                    started_at=started_at,
                )
                raise
            return await self._complete_disabled_route_with_possible_provider_dispatch(
                request=request,
                call_id=call_id,
                disabled_route=disabled_route,
                provider_safe_parts=redaction.provider_safe_parts,
                detections=_audit_detections(detector_analyses),
                started_at=started_at,
                classified_tier=redaction.required_sensitivity.classified_tier,
                required_tier=redaction.required_sensitivity.effective_tier,
            )
        call_record = await self._insert_pre_provider_audit(
            request=request,
            sensitivity_classified=redaction.required_sensitivity.classified_tier,
            detections=_audit_detections(detector_analyses),
        )
        selected_route = _route_by_id(self._routes, route_decision.metadata.route_id)
        try:
            _validate_requested_route_constraints(request, route_decision.metadata)
            _validate_budget_latency_constraints(request, selected_route)
            route_credential = await self._resolve_route_credential(
                request=request,
                route=selected_route,
            )
        except ShieldRequestValidationError as error:
            await self._complete_validation_block(
                request=request,
                call_record=call_record,
                route=route_decision.metadata,
                started_at=started_at,
            )
            raise error.with_shield_call_id(call_record.id) from error

        admission_context = ShieldAdmissionContext(
            tenant_id=request.tenant_id,
            principal_id=request.principal_id,
            route_id=route_decision.metadata.route_id,
            task_class=request.task_class,
            route_capability=route_decision.required_capability,
            sensitivity_tier=route_decision.metadata.sensitivity_used,
            mode=ShieldCallMode.REQUEST_RESPONSE,
            latency_mode=request.latency_mode,
            agent_run_id=request.agent_run_id,
            tool_call_id=request.tool_call_id,
        )
        try:
            capacity_lease = await self._capacity_leaser.acquire(
                admission_context,
                self._capacity_budget,
            )
        except ShieldCapacityLeaseError as error:
            await self._complete_backpressure_block(
                request=request,
                call_record=call_record,
                route=route_decision.metadata,
                started_at=started_at,
            )
            raise ShieldBackpressureError(
                backpressure_response_from_capacity_error(error)
            ) from error

        async with capacity_lease:
            try:
                provider_response = await self._provider_adapter.complete(
                    ProviderAdapterRequest(
                        call_id=call_id,
                        route=route_decision.metadata,
                        provider_safe_parts=redaction.provider_safe_parts,
                        credential=route_credential,
                    )
                )
            except ShieldProviderRateLimitError as error:
                await self._complete_backpressure_block(
                    request=request,
                    call_record=call_record,
                    route=route_decision.metadata,
                    started_at=started_at,
                )
                raise ShieldBackpressureError(
                    provider_rate_limit_backpressure_response(
                        admission_context,
                        retry_after_seconds=error.retry_after_seconds,
                        provider=route_decision.metadata.provider,
                    )
                ) from error
            except ShieldProviderCallError:
                await self._complete_provider_call_failure(
                    request=request,
                    call_record=call_record,
                    route=route_decision.metadata,
                    started_at=started_at,
                )
                raise

        usage = provider_response.usage
        await self._audit_writer.complete_call(
            tenant_id=request.tenant_id,
            call_record_id=call_record.id,
            completion=ShieldCallCompletion.from_route_usage(
                policy_outcome=PolicyOutcome.PASSED,
                route=route_decision.metadata,
                usage=usage,
                latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
            ),
        )
        trusted_result = _trusted_result_from_provider_response(provider_response)
        return ShieldCallCoreResult(
            call_record_id=call_record.id,
            response=CanonicalShieldResponse(
                call_id=call_record.id,
                route=route_decision.metadata,
                result=trusted_result,
                policy_outcome=PolicyOutcome.PASSED,
                usage=usage,
                trace_id=call_record.trace_id,
                span_id=call_record.span_id,
            ),
        )

    async def _complete_disabled_route_with_possible_provider_dispatch(
        self,
        *,
        request: CanonicalShieldRequest,
        call_id: UUID,
        disabled_route: BifrostProviderRoute,
        provider_safe_parts: tuple[ProviderSafeMessagePart, ...],
        detections: tuple[ShieldAuditDetection, ...],
        started_at: float,
        classified_tier: SensitivityTier,
        required_tier: SensitivityTier,
    ) -> ShieldCallCoreResult:
        route_metadata = _route_metadata_for_disabled_route(
            disabled_route,
            required_tier=required_tier,
            required_capability=capability_for_task_class(request.task_class),
        )
        call_record = await self._insert_pre_provider_audit(
            request=request,
            sensitivity_classified=classified_tier,
            detections=detections,
            shield_enabled=False,
        )
        try:
            _validate_requested_route_constraints(request, route_metadata)
            _validate_budget_latency_constraints(request, disabled_route)
        except ShieldRequestValidationError as error:
            await self._complete_validation_block(
                request=request,
                call_record=call_record,
                route=route_metadata,
                started_at=started_at,
            )
            raise error.with_shield_call_id(call_record.id) from error
        disabled_policy = self._disabled_shield_policies.get(
            request.tenant_id, DisabledShieldPolicy.FAIL_CLOSED
        )
        if not _can_fail_open_disabled_shield(
            disabled_policy,
            classified_tier=classified_tier,
            route_metadata=route_metadata,
        ):
            await self._audit_writer.complete_call(
                tenant_id=request.tenant_id,
                call_record_id=call_record.id,
                completion=ShieldCallCompletion(
                    policy_outcome=ShieldAuditOutcome.BLOCKED,
                    latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
                    redaction_skipped=True,
                    redaction_skip_reason="shield_disabled",
                    sensitivity_used=route_metadata.sensitivity_used,
                    route_fallback_distance=route_metadata.fallback_distance,
                    provider_route_id=route_metadata.route_id,
                    model_provider=route_metadata.provider,
                    model_id=route_metadata.model_id,
                ),
            )
            raise ShieldPolicyBlockedError(
                response=CanonicalShieldResponse(
                    call_id=call_record.id,
                    route=route_metadata,
                    policy_outcome=PolicyOutcome.BLOCKED,
                    warnings=(ShieldErrorCode.SHIELD_DISABLED,),
                    trace_id=call_record.trace_id,
                    span_id=call_record.span_id,
                ),
                blocked_parts=(),
                call_record_id=call_record.id,
            )

        try:
            route_credential = await self._resolve_route_credential(
                request=request,
                route=disabled_route,
            )
        except ShieldRequestValidationError as error:
            await self._complete_validation_block(
                request=request,
                call_record=call_record,
                route=route_metadata,
                started_at=started_at,
            )
            raise error.with_shield_call_id(call_record.id) from error

        admission_context = ShieldAdmissionContext(
            tenant_id=request.tenant_id,
            principal_id=request.principal_id,
            route_id=route_metadata.route_id,
            task_class=request.task_class,
            route_capability=capability_for_task_class(request.task_class),
            sensitivity_tier=route_metadata.sensitivity_used,
            mode=ShieldCallMode.REQUEST_RESPONSE,
            latency_mode=request.latency_mode,
            agent_run_id=request.agent_run_id,
            tool_call_id=request.tool_call_id,
        )
        try:
            capacity_lease = await self._capacity_leaser.acquire(
                admission_context,
                self._capacity_budget,
            )
        except ShieldCapacityLeaseError as error:
            await self._complete_backpressure_block(
                request=request,
                call_record=call_record,
                route=route_metadata,
                started_at=started_at,
            )
            raise ShieldBackpressureError(
                backpressure_response_from_capacity_error(error)
            ) from error

        async with capacity_lease:
            try:
                provider_response = await self._provider_adapter.complete(
                    ProviderAdapterRequest(
                        call_id=call_id,
                        route=route_metadata,
                        provider_safe_parts=provider_safe_parts,
                        credential=route_credential,
                    )
                )
            except ShieldProviderRateLimitError as error:
                await self._complete_backpressure_block(
                    request=request,
                    call_record=call_record,
                    route=route_metadata,
                    started_at=started_at,
                )
                raise ShieldBackpressureError(
                    provider_rate_limit_backpressure_response(
                        admission_context,
                        retry_after_seconds=error.retry_after_seconds,
                        provider=route_metadata.provider,
                    )
                ) from error
            except ShieldProviderCallError:
                await self._complete_provider_call_failure(
                    request=request,
                    call_record=call_record,
                    route=route_metadata,
                    started_at=started_at,
                )
                raise
        await self._audit_writer.complete_call(
            tenant_id=request.tenant_id,
            call_record_id=call_record.id,
            completion=ShieldCallCompletion(
                policy_outcome=ShieldAuditOutcome.FAIL_OPEN,
                latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
                redaction_skipped=True,
                redaction_skip_reason="shield_disabled",
                sensitivity_used=route_metadata.sensitivity_used,
                route_fallback_distance=route_metadata.fallback_distance,
                provider_route_id=route_metadata.route_id,
                model_provider=route_metadata.provider,
                model_id=route_metadata.model_id,
                tokens_in=provider_response.usage.tokens_in,
                tokens_out=provider_response.usage.tokens_out,
                cache_hit=provider_response.usage.cache_hit,
            ),
        )
        trusted_result = _trusted_result_from_provider_response(provider_response)
        return ShieldCallCoreResult(
            call_record_id=call_record.id,
            response=CanonicalShieldResponse(
                call_id=call_record.id,
                route=route_metadata,
                result=trusted_result,
                policy_outcome=PolicyOutcome.FAIL_OPEN,
                usage=provider_response.usage,
                warnings=(ShieldErrorCode.SHIELD_DISABLED,),
                trace_id=call_record.trace_id,
                span_id=call_record.span_id,
            ),
        )

    def _analyze_part(self, part: NormalizedMessagePart) -> DetectorAnalysis:
        if part.part.type in {
            MessagePartType.SYSTEM,
            MessagePartType.DEVELOPER,
            MessagePartType.USER_TEXT,
            MessagePartType.TOOL_RESULT,
        }:
            return self._detector_registry.analyze_text(part.part.text or "")
        if part.part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
            try:
                serialized = json.dumps(
                    part.part.json_value,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
            except (TypeError, ValueError):
                return DetectorRegistry().analyze_text("")
            return self._detector_registry.analyze_text(serialized)
        return DetectorRegistry().analyze_text("")

    async def _insert_pre_provider_audit(
        self,
        *,
        request: CanonicalShieldRequest,
        sensitivity_classified: SensitivityTier,
        detections: tuple[ShieldAuditDetection, ...],
        shield_enabled: bool = True,
    ) -> ShieldCallRecord:
        try:
            return await self._audit_writer.insert_call_attempt(
                ShieldCallStart(
                    tenant_id=request.tenant_id,
                    actor_principal_id=request.principal_id,
                    agent_run_id=request.agent_run_id,
                    tool_call_id=request.tool_call_id,
                    trace_id=request.trace_id,
                    span_id=request.span_id,
                    redaction_session_id=request.redaction_session_id,
                    mode="request-response",
                    request_shape=RequestShape.CANONICAL,
                    task_class=request.task_class,
                    sensitivity_classified=sensitivity_classified,
                    sensitivity_requested=request.requested_sensitivity,
                    shield_enabled=shield_enabled,
                    detections=detections,
                )
            )
        except Exception as error:
            raise ShieldAuditUnavailableError from error

    async def _resolve_route_credential(
        self,
        *,
        request: CanonicalShieldRequest,
        route: BifrostProviderRoute,
    ) -> ResolvedRouteCredential | None:
        if not self._require_route_credentials:
            return None
        try:
            return await self._route_credential_resolver.resolve(
                route,
                principal_id=request.principal_id,
            )
        except RouteCredentialResolutionError as error:
            raise ShieldRequestValidationError(
                SafeShieldError(
                    code=error.code,
                    http_status=503,
                    trace_id=request.trace_id,
                    retryable=error.code is ShieldErrorCode.KMS_UNAVAILABLE,
                )
            ) from error

    async def _complete_validation_block(
        self,
        *,
        request: CanonicalShieldRequest,
        call_record: ShieldCallRecord,
        route: RouteMetadata,
        started_at: float,
    ) -> None:
        await self._audit_writer.complete_call(
            tenant_id=request.tenant_id,
            call_record_id=call_record.id,
            completion=ShieldCallCompletion(
                policy_outcome=ShieldAuditOutcome.BLOCKED,
                latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
                sensitivity_used=route.sensitivity_used,
                route_fallback_distance=route.fallback_distance,
                provider_route_id=route.route_id,
                model_provider=route.provider,
                model_id=route.model_id,
            ),
        )

    async def _complete_route_selection_block(
        self,
        *,
        request: CanonicalShieldRequest,
        call_record: ShieldCallRecord,
        started_at: float,
    ) -> None:
        await self._audit_writer.complete_call(
            tenant_id=request.tenant_id,
            call_record_id=call_record.id,
            completion=ShieldCallCompletion(
                policy_outcome=ShieldAuditOutcome.BLOCKED,
                latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
            ),
        )

    async def _complete_backpressure_block(
        self,
        *,
        request: CanonicalShieldRequest,
        call_record: ShieldCallRecord,
        route: RouteMetadata,
        started_at: float,
    ) -> None:
        await self._audit_writer.complete_call(
            tenant_id=request.tenant_id,
            call_record_id=call_record.id,
            completion=ShieldCallCompletion(
                policy_outcome=ShieldAuditOutcome.BLOCKED,
                latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
                sensitivity_used=route.sensitivity_used,
                route_fallback_distance=route.fallback_distance,
                provider_route_id=route.route_id,
                model_provider=route.provider,
                model_id=route.model_id,
            ),
        )

    async def _complete_provider_call_failure(
        self,
        *,
        request: CanonicalShieldRequest,
        call_record: ShieldCallRecord,
        route: RouteMetadata,
        started_at: float,
    ) -> None:
        await self._audit_writer.complete_call(
            tenant_id=request.tenant_id,
            call_record_id=call_record.id,
            completion=ShieldCallCompletion(
                policy_outcome=ShieldAuditOutcome.BLOCKED,
                latency_total_ms=max(0, int((monotonic() - started_at) * 1000)),
                sensitivity_used=route.sensitivity_used,
                route_fallback_distance=route.fallback_distance,
                provider_route_id=route.route_id,
                model_provider=route.provider,
                model_id=route.model_id,
            ),
        )


def _audit_detections(
    analyses: tuple[DetectorAnalysis, ...],
) -> tuple[ShieldAuditDetection, ...]:
    detections: list[ShieldAuditDetection] = []
    for analysis in analyses:
        if analysis.plan.status not in {DetectionStatus.DETECTED, DetectionStatus.CLEAN}:
            continue
        for finding in analysis.plan.findings:
            detections.append(
                ShieldAuditDetection.from_finding(
                    finding,
                    detector_version="registry-v1",
                )
            )
    return tuple(detections)


def _blocked_part_evidence(
    metadata: tuple[RedactionPartMetadata, ...],
) -> tuple[ShieldBlockedPartEvidence, ...]:
    evidence: list[ShieldBlockedPartEvidence] = []
    for item in metadata:
        if not getattr(item, "blocks_provider_dispatch", False):
            continue
        scan_budget = item.scan_budget
        evidence.append(
            ShieldBlockedPartEvidence(
                part_type=item.part_type,
                message_index=item.message_index,
                part_index=item.part_index,
                source_field=item.source_field,
                scan_outcome=scan_budget.outcome.value,
                policy_action=scan_budget.policy_action.value,
                char_size_bucket=scan_budget.char_size_bucket.value,
                byte_size_bucket=scan_budget.byte_size_bucket.value,
                error_code=item.error_code or ShieldErrorCode.UNSCANNABLE,
            )
        )
    return tuple(evidence)


def _redaction_skip_reason(error_code: ShieldErrorCode) -> str:
    if error_code is ShieldErrorCode.SHIELD_DISABLED:
        return "shield_disabled"
    if error_code is ShieldErrorCode.OVERSIZED:
        return "oversized"
    if error_code is ShieldErrorCode.UNSUPPORTED_PART:
        return "unsupported_part"
    if error_code is ShieldErrorCode.DETECTOR_TIMEOUT:
        return "detector_timeout"
    return "unscannable"


def _replacement_mode_for_task_class(task_class: TaskClass) -> ReplacementMode:
    if task_class in {TaskClass.EMBEDDING, TaskClass.SEARCH_QUERY}:
        return ReplacementMode.STRIP_PLACEHOLDERS
    return ReplacementMode.SYNTHETIC_SUBSTITUTION


def _trusted_result_from_provider_response(
    provider_response: ProviderAdapterResponse,
) -> ShieldTrustedResult:
    if provider_response.result is not None:
        return provider_response.result
    return TrustedMessageResult(
        kind=ShieldResultKind.MESSAGE,
        messages=list(provider_response.messages),
    )


def _select_disabled_route(
    routes: tuple[BifrostProviderRoute, ...],
    *,
    request: CanonicalShieldRequest,
    classified_tier: SensitivityTier,
    requested_tier: SensitivityTier | None,
) -> BifrostProviderRoute | None:
    required_capability = capability_for_task_class(request.task_class)
    required_tier = effective_sensitivity(classified_tier, requested_tier)
    candidates = [
        route
        for route in routes
        if route.tenant_id == request.tenant_id
        and route.is_active
        and route.revoked_at is None
        and not route.shield_enabled
        and required_capability in route.capabilities
        and route.sensitivity_tier >= required_tier
        and _route_matches_model_hint(route, request.model_hint)
    ]
    if not candidates:
        return None
    return min(
        candidates,
        key=lambda route: (
            route.sensitivity_tier - required_tier,
            route.priority,
            route.created_at,
            route.id,
        ),
    )


def _route_metadata_for_disabled_route(
    route: BifrostProviderRoute,
    *,
    required_tier: SensitivityTier,
    required_capability: RouteCapability | None = None,
) -> RouteMetadata:
    fallback_distance = max(0, route.sensitivity_tier - required_tier)
    return RouteMetadata(
        route_id=route.id,
        provider=route.provider,
        model_id=route.model_id,
        sensitivity_used=route.sensitivity_tier,
        fallback_distance=fallback_distance,
        capability=required_capability,
        embedding_dimensions=route.embedding_dimensions,
        embedding_dtype=route.embedding_dtype,
    )


def _require_trace_context(request: CanonicalShieldRequest) -> None:
    if request.trace_id is None or request.span_id is None:
        raise ShieldRequestValidationError(
            SafeShieldError(
                code=ShieldErrorCode.TRACE_CONTEXT_REQUIRED,
                http_status=400,
                trace_id=request.trace_id,
            )
        )


def _route_by_id(
    routes: tuple[BifrostProviderRoute, ...],
    route_id: UUID,
) -> BifrostProviderRoute:
    for route in routes:
        if route.id == route_id:
            return route
    raise ShieldRequestValidationError(
        SafeShieldError(code=ShieldErrorCode.ROUTE_UNAVAILABLE, http_status=503)
    )


def _validate_requested_route_constraints(
    request: CanonicalShieldRequest,
    route_metadata: RouteMetadata,
) -> None:
    requested = request.requested_route
    if requested is None:
        return
    mismatch = (
        (requested.route_id is not None and requested.route_id != route_metadata.route_id)
        or (requested.provider is not None and requested.provider != route_metadata.provider)
        or (requested.model_id is not None and requested.model_id != route_metadata.model_id)
        or (requested.capability is not None and requested.capability != route_metadata.capability)
    )
    if mismatch:
        raise ShieldRequestValidationError(
            SafeShieldError(
                code=ShieldErrorCode.ROUTE_UNAVAILABLE,
                http_status=409,
                trace_id=request.trace_id,
            )
        )


def _validate_budget_latency_constraints(
    request: CanonicalShieldRequest,
    route: BifrostProviderRoute,
) -> None:
    budget = request.budget
    if budget is not None and budget.scope is not None and budget.scope != route.budget_scope:
        raise ShieldRequestValidationError(
            SafeShieldError(
                code=ShieldErrorCode.ROUTE_BUDGET_EXHAUSTED,
                http_status=429,
                trace_id=request.trace_id,
            )
        )

    latency = request.latency
    if latency is None:
        return
    if latency.queue_policy is not None and latency.queue_policy != route.queue_policy.value:
        raise ShieldRequestValidationError(
            SafeShieldError(
                code=ShieldErrorCode.ROUTE_UNAVAILABLE,
                http_status=409,
                trace_id=request.trace_id,
            )
        )
    if latency.max_latency_ms is not None and route.queue_max_delay_ms > latency.max_latency_ms:
        raise ShieldRequestValidationError(
            SafeShieldError(
                code=ShieldErrorCode.ROUTE_BUDGET_EXHAUSTED,
                http_status=429,
                trace_id=request.trace_id,
            )
        )


def _route_matches_model_hint(
    route: BifrostProviderRoute,
    model_hint: ModelHint | None,
) -> bool:
    if model_hint is None:
        return True
    return (
        (model_hint.provider is None or route.provider == model_hint.provider)
        and (model_hint.model_id is None or route.model_id == model_hint.model_id)
        and model_hint.capabilities.issubset(route.capabilities)
    )


def _can_fail_open_disabled_shield(
    policy: DisabledShieldPolicy,
    *,
    classified_tier: SensitivityTier,
    route_metadata: RouteMetadata,
) -> bool:
    if policy is not DisabledShieldPolicy.DEV_FAIL_OPEN:
        return False
    return (
        classified_tier < SensitivityTier.PII_STRICT
        and route_metadata.sensitivity_used < SensitivityTier.PII_STRICT
    )


class InMemoryShieldAuditWriter:
    """Deterministic audit writer for unit tests and local call-core fixtures."""

    def __init__(
        self,
        *,
        trace_context: AuditTraceContext | None = None,
        fail_attempt: bool = False,
    ) -> None:
        self._trace_context = trace_context or AuditTraceContext(
            trace_id="0" * 32,
            span_id="1" * 16,
        )
        self._fail_attempt = fail_attempt
        self.events: list[str] = []
        self.attempts: list[ShieldCallStart] = []
        self.completions: list[ShieldCallCompletion] = []

    async def insert_call_attempt(self, attempt: ShieldCallStart) -> ShieldCallRecord:
        self.events.append("audit_attempt")
        if self._fail_attempt:
            raise RuntimeError("audit unavailable")
        self.attempts.append(attempt)
        trace_context = self._trace_context
        if attempt.trace_id is not None and attempt.span_id is not None:
            trace_context = AuditTraceContext(trace_id=attempt.trace_id, span_id=attempt.span_id)
        return ShieldCallRecord(
            id=uuid4(),
            tenant_id=attempt.tenant_id,
            actor_principal_id=attempt.actor_principal_id,
            trace_id=trace_context.trace_id,
            span_id=trace_context.span_id,
            policy_outcome=ShieldAuditOutcome.ATTEMPTED.value,
            created_at=datetime.now(UTC),
            completed_at=None,
        )

    async def complete_call(
        self,
        *,
        tenant_id: UUID,
        call_record_id: UUID,
        completion: ShieldCallCompletion,
    ) -> ShieldCallRecord:
        self.events.append("audit_complete")
        self.completions.append(completion)
        return ShieldCallRecord(
            id=call_record_id,
            tenant_id=tenant_id,
            actor_principal_id=UUID("00000000-0000-0000-0000-000000000001"),
            trace_id=self._trace_context.trace_id,
            span_id=self._trace_context.span_id,
            policy_outcome=completion.policy_outcome.value,
            created_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
        )
