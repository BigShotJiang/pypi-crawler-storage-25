"""Anthropic Messages request serialization for Shield provider-safe content."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.contracts import MessagePartType, ShieldErrorCode, ShieldMessageRole
from skaldos_shield.provider_adapters import (
    ProviderAdapterRequest,
    ProviderAdapterResponse,
    ShieldProviderAdapter,
)
from skaldos_shield.redaction_pipeline import ProviderSafeMessagePart

_TEXT_PART_TYPES = frozenset(
    {
        MessagePartType.SYSTEM,
        MessagePartType.DEVELOPER,
        MessagePartType.USER_TEXT,
        MessagePartType.TOOL_RESULT,
    }
)
_SYSTEM_ROLES = frozenset({ShieldMessageRole.SYSTEM, ShieldMessageRole.DEVELOPER})


class AnthropicSerializationError(Exception):
    """Raised when provider-safe content cannot be expressed as Anthropic Messages."""

    error_code = ShieldErrorCode.UNSUPPORTED_PART


class AnthropicTextBlock(BaseModel):
    """Anthropic text content block with provider-safe text only."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: Literal["text"] = "text"
    text: str


class AnthropicMessage(BaseModel):
    """Anthropic Messages API message."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    role: Literal["user", "assistant"]
    content: tuple[AnthropicTextBlock, ...] = Field(min_length=1)


class AnthropicMessagesRequest(BaseModel):
    """Serializable Anthropic Messages API request payload."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    model: str
    max_tokens: int = Field(gt=0)
    messages: tuple[AnthropicMessage, ...] = Field(min_length=1)
    system: str | None = None


@dataclass(frozen=True, repr=False)
class AnthropicCredential:
    """Resolved Anthropic credential kept outside serializable request payloads."""

    api_key: str

    def __repr__(self) -> str:
        return "AnthropicCredential(<redacted>)"


class AnthropicTransport(Protocol):
    """Injected transport boundary; production HTTP wiring lands in a later PR."""

    async def complete(
        self,
        payload: AnthropicMessagesRequest,
        *,
        credential: AnthropicCredential,
    ) -> ProviderAdapterResponse:
        """Send an already serialized Anthropic request."""
        ...


class AnthropicProviderAdapter(ShieldProviderAdapter):
    """Shield provider adapter that delegates transport after safe serialization."""

    def __init__(
        self,
        *,
        transport: AnthropicTransport,
        max_tokens: int = 1024,
    ) -> None:
        self._transport = transport
        self._max_tokens = max_tokens

    async def complete(self, request: ProviderAdapterRequest) -> ProviderAdapterResponse:
        """Serialize provider-safe canonical parts and call the injected transport."""

        payload = serialize_anthropic_messages_request(
            request,
            max_tokens=self._max_tokens,
        )
        if request.credential is None:
            raise AnthropicSerializationError("anthropic credential is unavailable")
        credential = AnthropicCredential(api_key=request.credential.plaintext())
        return await self._transport.complete(payload, credential=credential)


def serialize_anthropic_messages_request(
    request: ProviderAdapterRequest,
    *,
    max_tokens: int = 1024,
) -> AnthropicMessagesRequest:
    """Convert provider-safe canonical parts to an Anthropic Messages payload."""

    if request.route.provider != "anthropic":
        raise AnthropicSerializationError("anthropic adapter requires an anthropic route")

    system_parts: list[str] = []
    messages: list[AnthropicMessage] = []
    current_role: Literal["user", "assistant"] | None = None
    current_blocks: list[AnthropicTextBlock] = []

    def flush_current_message() -> None:
        nonlocal current_role, current_blocks
        if current_role is not None:
            messages.append(
                AnthropicMessage(
                    role=current_role,
                    content=tuple(current_blocks),
                )
            )
        current_role = None
        current_blocks = []

    for safe_part in request.provider_safe_parts:
        if _is_system_part(safe_part):
            flush_current_message()
            system_parts.append(_text_for_part(safe_part))
            continue

        anthropic_role = _anthropic_role(safe_part.role)
        if current_role is not None and current_role != anthropic_role:
            flush_current_message()
        current_role = anthropic_role
        current_blocks.append(AnthropicTextBlock(text=_text_for_part(safe_part)))

    flush_current_message()
    if not messages:
        raise AnthropicSerializationError("anthropic requests require a message")

    return AnthropicMessagesRequest(
        model=request.route.model_id,
        max_tokens=max_tokens,
        system="\n\n".join(system_parts) or None,
        messages=tuple(messages),
    )


def _is_system_part(safe_part: ProviderSafeMessagePart) -> bool:
    return safe_part.role in _SYSTEM_ROLES or safe_part.part.type in {
        MessagePartType.SYSTEM,
        MessagePartType.DEVELOPER,
    }


def _anthropic_role(role: ShieldMessageRole) -> Literal["user", "assistant"]:
    if role == ShieldMessageRole.ASSISTANT:
        return "assistant"
    if role in {ShieldMessageRole.USER, ShieldMessageRole.TOOL}:
        return "user"
    raise AnthropicSerializationError("system content must be serialized separately")


def _text_for_part(safe_part: ProviderSafeMessagePart) -> str:
    if safe_part.part.type in _TEXT_PART_TYPES:
        return safe_part.part.text or ""
    if safe_part.part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
        return json.dumps(
            safe_part.part.json_value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
    raise AnthropicSerializationError("unsupported provider-safe part type")
