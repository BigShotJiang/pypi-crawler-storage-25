"""Value-free scan-budget policy for normalized Shield message parts."""

from __future__ import annotations

import json
from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos_shield.contracts import MessagePartType, ShieldErrorCode
from skaldos_shield.message_parts import MessagePartPolicyAction
from skaldos_shield.request_normalizer import NormalizedMessagePart


class ScanBudgetOutcome(StrEnum):
    """Low-cardinality scan-budget outcome for logs, audit, and policy."""

    OK = "ok"
    OVERSIZED = "oversized"
    UNSCANNABLE = "unscannable"
    TIMEOUT = "timeout"


class ScanBudgetPolicyAction(StrEnum):
    """Provider-dispatch action after scan-budget policy resolution."""

    SCAN = "scan"
    BLOCK = "block"
    FAIL_OPEN_REDACTION_SKIPPED_METADATA = "fail_open_redaction_skipped_metadata"


class ScanSizeBucket(StrEnum):
    """Coarse request-size buckets that do not expose exact content length."""

    EMPTY = "empty"
    LE_1KB = "le_1kb"
    LE_4KB = "le_4kb"
    LE_16KB = "le_16kb"
    LE_64KB = "le_64kb"
    GT_64KB = "gt_64kb"
    UNAVAILABLE = "unavailable"


class ScanBudgetLimits(BaseModel):
    """Per-part size limits applied before detector work starts."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    max_text_chars: Annotated[int, Field(ge=1)] = 16_384
    max_text_bytes: Annotated[int, Field(ge=1)] = 65_536
    max_structured_chars: Annotated[int, Field(ge=1)] = 16_384
    max_structured_bytes: Annotated[int, Field(ge=1)] = 65_536


class ScanBudgetDecision(BaseModel):
    """Value-free scan-budget decision for one normalized message part."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    part_type: MessagePartType
    message_index: Annotated[int, Field(ge=0)]
    part_index: Annotated[int, Field(ge=0)]
    source_field: str
    message_policy_action: MessagePartPolicyAction
    outcome: ScanBudgetOutcome
    policy_action: ScanBudgetPolicyAction
    char_size_bucket: ScanSizeBucket
    byte_size_bucket: ScanSizeBucket
    blocks_provider_dispatch: bool
    redaction_skipped: bool = False
    redaction_skip_reason: str | None = None
    error_code: ShieldErrorCode | None = None

    @model_validator(mode="after")
    def _decision_fields_match_outcome(self) -> ScanBudgetDecision:
        if self.outcome == ScanBudgetOutcome.OK:
            if self.policy_action != ScanBudgetPolicyAction.SCAN:
                raise ValueError("ok scan-budget decisions must scan")
            if self.error_code is not None or self.redaction_skipped:
                raise ValueError("ok scan-budget decisions cannot carry non-clean metadata")
            if self.blocks_provider_dispatch:
                raise ValueError("ok scan-budget decisions cannot block provider dispatch")
        else:
            if self.error_code is None:
                raise ValueError("non-clean scan-budget decisions require a stable error code")
            if self.policy_action == ScanBudgetPolicyAction.SCAN:
                raise ValueError("non-clean scan-budget decisions cannot scan")
            if (
                self.policy_action == ScanBudgetPolicyAction.BLOCK
                and not self.blocks_provider_dispatch
            ):
                raise ValueError("blocking scan-budget decisions must block provider dispatch")
            if self.policy_action == ScanBudgetPolicyAction.FAIL_OPEN_REDACTION_SKIPPED_METADATA:
                if not self.blocks_provider_dispatch:
                    raise ValueError("fail-open metadata is not provider-dispatch permission")
                if not self.redaction_skipped or self.redaction_skip_reason is None:
                    raise ValueError("fail-open metadata requires a redaction skip reason")
        return self

    @property
    def clean(self) -> bool:
        """Whether later detector stages may treat this part as clean to scan."""

        return self.outcome == ScanBudgetOutcome.OK


def evaluate_scan_budget(
    part: NormalizedMessagePart,
    *,
    limits: ScanBudgetLimits | None = None,
) -> ScanBudgetDecision:
    """Evaluate scan-budget policy for one normalized canonical message part.

    The returned decision intentionally excludes text, JSON values, media
    payloads, exact lengths, and exception details.
    """

    active_limits = limits or ScanBudgetLimits()
    if part.policy_decision.blocks_provider_dispatch:
        return _non_clean_decision(
            part,
            outcome=ScanBudgetOutcome.UNSCANNABLE,
            error_code=part.policy_decision.error_code or ShieldErrorCode.UNSCANNABLE,
            reason=part.policy_decision.audit_reason or "unscannable",
            char_size_bucket=ScanSizeBucket.UNAVAILABLE,
            byte_size_bucket=ScanSizeBucket.UNAVAILABLE,
            fail_open_metadata=False,
        )

    size = _payload_size(part)
    if size is None:
        return _non_clean_decision(
            part,
            outcome=ScanBudgetOutcome.UNSCANNABLE,
            error_code=ShieldErrorCode.UNSCANNABLE,
            reason="unscannable",
            char_size_bucket=ScanSizeBucket.UNAVAILABLE,
            byte_size_bucket=ScanSizeBucket.UNAVAILABLE,
            fail_open_metadata=False,
        )

    char_count, byte_count = size
    char_bucket = _bucket_for_size(char_count)
    byte_bucket = _bucket_for_size(byte_count)
    max_chars, max_bytes = _limits_for_part(part, active_limits)
    if char_count > max_chars or byte_count > max_bytes:
        return _non_clean_decision(
            part,
            outcome=ScanBudgetOutcome.OVERSIZED,
            error_code=ShieldErrorCode.OVERSIZED,
            reason="oversized",
            char_size_bucket=char_bucket,
            byte_size_bucket=byte_bucket,
            fail_open_metadata=False,
        )

    return ScanBudgetDecision(
        part_type=part.part.type,
        message_index=part.message_index,
        part_index=part.part_index,
        source_field=part.source_field,
        message_policy_action=part.policy_decision.action,
        outcome=ScanBudgetOutcome.OK,
        policy_action=ScanBudgetPolicyAction.SCAN,
        char_size_bucket=char_bucket,
        byte_size_bucket=byte_bucket,
        blocks_provider_dispatch=False,
    )


def timeout_scan_budget_decision(
    part: NormalizedMessagePart,
    *,
    fail_open_metadata: bool = False,
) -> ScanBudgetDecision:
    """Represent detector timeout as explicit value-free policy metadata."""

    return _non_clean_decision(
        part,
        outcome=ScanBudgetOutcome.TIMEOUT,
        error_code=ShieldErrorCode.DETECTOR_TIMEOUT,
        reason="detector_timeout",
        char_size_bucket=ScanSizeBucket.UNAVAILABLE,
        byte_size_bucket=ScanSizeBucket.UNAVAILABLE,
        fail_open_metadata=fail_open_metadata,
    )


def evaluate_scan_budget_for_parts(
    parts: tuple[NormalizedMessagePart, ...],
    *,
    limits: ScanBudgetLimits | None = None,
) -> tuple[ScanBudgetDecision, ...]:
    """Evaluate scan-budget decisions for a normalized request."""

    return tuple(evaluate_scan_budget(part, limits=limits) for part in parts)


def fail_open_scan_budget_metadata(
    decision: ScanBudgetDecision,
) -> ScanBudgetDecision:
    """Annotate a non-clean decision as fail-open metadata, not dispatch permission."""

    if decision.outcome == ScanBudgetOutcome.OK:
        raise ValueError("ok scan-budget decisions cannot become fail-open metadata")
    return decision.model_copy(
        update={
            "policy_action": ScanBudgetPolicyAction.FAIL_OPEN_REDACTION_SKIPPED_METADATA,
            "blocks_provider_dispatch": True,
            "redaction_skipped": True,
            "redaction_skip_reason": decision.redaction_skip_reason or decision.outcome.value,
        }
    )


def _payload_size(part: NormalizedMessagePart) -> tuple[int, int] | None:
    if part.part.type in {
        MessagePartType.SYSTEM,
        MessagePartType.DEVELOPER,
        MessagePartType.USER_TEXT,
        MessagePartType.TOOL_RESULT,
    }:
        if part.part.text is None:
            return None
        return len(part.part.text), len(part.part.text.encode("utf-8"))

    if part.part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
        try:
            serialized = json.dumps(
                part.part.json_value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        except (TypeError, ValueError):
            return None
        return len(serialized), len(serialized.encode("utf-8"))

    return None


def _limits_for_part(
    part: NormalizedMessagePart,
    limits: ScanBudgetLimits,
) -> tuple[int, int]:
    if part.part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
        return limits.max_structured_chars, limits.max_structured_bytes
    return limits.max_text_chars, limits.max_text_bytes


def _non_clean_decision(
    part: NormalizedMessagePart,
    *,
    outcome: ScanBudgetOutcome,
    error_code: ShieldErrorCode,
    reason: str,
    char_size_bucket: ScanSizeBucket,
    byte_size_bucket: ScanSizeBucket,
    fail_open_metadata: bool,
) -> ScanBudgetDecision:
    policy_action = (
        ScanBudgetPolicyAction.FAIL_OPEN_REDACTION_SKIPPED_METADATA
        if fail_open_metadata
        else ScanBudgetPolicyAction.BLOCK
    )
    return ScanBudgetDecision(
        part_type=part.part.type,
        message_index=part.message_index,
        part_index=part.part_index,
        source_field=part.source_field,
        message_policy_action=part.policy_decision.action,
        outcome=outcome,
        policy_action=policy_action,
        char_size_bucket=char_size_bucket,
        byte_size_bucket=byte_size_bucket,
        blocks_provider_dispatch=True,
        redaction_skipped=(
            policy_action == ScanBudgetPolicyAction.FAIL_OPEN_REDACTION_SKIPPED_METADATA
        ),
        redaction_skip_reason=(
            reason
            if policy_action == ScanBudgetPolicyAction.FAIL_OPEN_REDACTION_SKIPPED_METADATA
            else None
        ),
        error_code=error_code,
    )


def _bucket_for_size(size: int) -> ScanSizeBucket:
    if size == 0:
        return ScanSizeBucket.EMPTY
    if size <= 1_024:
        return ScanSizeBucket.LE_1KB
    if size <= 4_096:
        return ScanSizeBucket.LE_4KB
    if size <= 16_384:
        return ScanSizeBucket.LE_16KB
    if size <= 65_536:
        return ScanSizeBucket.LE_64KB
    return ScanSizeBucket.GT_64KB
