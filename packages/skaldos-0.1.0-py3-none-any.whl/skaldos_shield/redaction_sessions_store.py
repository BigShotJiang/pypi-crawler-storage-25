"""Typed redaction-session storage accessors for Shield.

This module is the Slice 5 schema/accessor foundation. It projects encrypted
session and mapping rows through Pydantic and deliberately exposes only scoped
ids, lookup digests, wrapped-DEK material, ciphertext, counts, and timestamps.
It does not implement KMS encryption or placeholder generation.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any
from uuid import UUID

import aiosql
from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    import asyncpg

__all__ = [
    "PIIRedactionMapping",
    "PIIRedactionSession",
    "RedactionSessionsStore",
    "record_to_redaction_mapping",
    "record_to_redaction_session",
    "redaction_sessions_store",
]

_QUERIES_SQL_PATH: Path = Path(__file__).parent / "queries" / "redaction_sessions.sql"


def _load_queries() -> Any:  # noqa: ANN401 - aiosql exposes dynamic query attributes
    return aiosql.from_path(_QUERIES_SQL_PATH, "asyncpg")  # pyright: ignore[reportUnknownMemberType]


class PIIRedactionSession(BaseModel):
    """Encrypted redaction-session row."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    parent_principal_id: UUID
    authn_session_id: UUID | None
    subject_key_id: UUID
    kms_key_ref: str = Field(min_length=1)
    wrapped_dek_ciphertext: bytes = Field(min_length=1)
    mapping_count: int = Field(ge=0)
    mapping_limit: int = Field(gt=0)
    started_at: datetime
    last_access_at: datetime
    expires_at: datetime
    purged_at: datetime | None
    purge_reason: str | None


class PIIRedactionMapping(BaseModel):
    """Encrypted redaction mapping row keyed only by scoped digests."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    session_id: UUID
    entity_type: str = Field(min_length=1)
    real_lookup_digest: bytes = Field(min_length=32, max_length=32)
    synthetic_lookup_digest: bytes = Field(min_length=32, max_length=32)
    mapping_ciphertext: bytes = Field(min_length=1)
    created_at: datetime


def record_to_redaction_session(record: Any) -> PIIRedactionSession:  # noqa: ANN401
    """Project an asyncpg record into a typed redaction-session row."""

    payload = dict(record)
    if payload["purge_reason"] is not None:
        payload["purge_reason"] = str(payload["purge_reason"])
    return PIIRedactionSession.model_validate(payload)


def record_to_redaction_mapping(record: Any) -> PIIRedactionMapping:  # noqa: ANN401
    """Project an asyncpg record into a typed encrypted mapping row."""

    return PIIRedactionMapping.model_validate(dict(record))


class RedactionSessionsStore:
    """aiosql-backed redaction-session lookup wrapper."""

    def __init__(self, queries: Any | None = None) -> None:  # noqa: ANN401
        self._queries = queries if queries is not None else _load_queries()

    async def create_session(
        self,
        conn: asyncpg.Connection,
        *,
        tenant_id: UUID,
        parent_principal_id: UUID,
        authn_session_id: UUID | None,
        subject_key_id: UUID,
        kms_key_ref: str,
        wrapped_dek_ciphertext: bytes,
        mapping_limit: int,
        expires_at: datetime,
    ) -> PIIRedactionSession:
        """Create one encrypted redaction session for a visible tenant."""

        record = await self._queries.create_redaction_session(
            conn,
            tenant_id=tenant_id,
            parent_principal_id=parent_principal_id,
            authn_session_id=authn_session_id,
            subject_key_id=subject_key_id,
            kms_key_ref=kms_key_ref,
            wrapped_dek_ciphertext=wrapped_dek_ciphertext,
            mapping_limit=mapping_limit,
            expires_at=expires_at,
        )
        return record_to_redaction_session(record)

    async def get_session(
        self,
        conn: asyncpg.Connection,
        *,
        tenant_id: UUID,
        session_id: UUID,
    ) -> PIIRedactionSession | None:
        """Return one session scoped by tenant and session id."""

        record = await self._queries.get_redaction_session(
            conn,
            tenant_id=tenant_id,
            session_id=session_id,
        )
        if record is None:
            return None
        return record_to_redaction_session(record)

    async def insert_mapping(
        self,
        conn: asyncpg.Connection,
        *,
        tenant_id: UUID,
        session_id: UUID,
        entity_type: str,
        real_lookup_digest: bytes,
        synthetic_lookup_digest: bytes,
        mapping_ciphertext: bytes,
    ) -> PIIRedactionMapping:
        """Insert or return an encrypted mapping keyed by session-scoped digests."""

        record = await self._queries.insert_redaction_mapping(
            conn,
            tenant_id=tenant_id,
            session_id=session_id,
            entity_type=entity_type,
            real_lookup_digest=real_lookup_digest,
            synthetic_lookup_digest=synthetic_lookup_digest,
            mapping_ciphertext=mapping_ciphertext,
        )
        if record is None:
            raise PermissionError("redaction mapping session is not visible for tenant")
        return record_to_redaction_mapping(record)

    async def get_mapping_by_synthetic_digest(
        self,
        conn: asyncpg.Connection,
        *,
        tenant_id: UUID,
        session_id: UUID,
        synthetic_lookup_digest: bytes,
    ) -> PIIRedactionMapping | None:
        """Return a reverse-lookup row scoped to one tenant and session."""

        record = await self._queries.get_mapping_by_synthetic_digest(
            conn,
            tenant_id=tenant_id,
            session_id=session_id,
            synthetic_lookup_digest=synthetic_lookup_digest,
        )
        if record is None:
            return None
        return record_to_redaction_mapping(record)


redaction_sessions_store: RedactionSessionsStore = RedactionSessionsStore()
