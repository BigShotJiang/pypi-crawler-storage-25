"""Detector registry facade for Shield.

This module defines the detector boundary without adding recognizer
dependencies. Concrete Presidio, checksum, or credential adapters can later
implement the same small protocol; tests use deterministic fixture detectors.
"""

from __future__ import annotations

import re
from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Protocol

from pydantic import BaseModel, ConfigDict, field_validator

from skaldos_shield.contracts import (
    ConfidenceBucket,
    DetectionAction,
    DetectionFinding,
    DetectionPlan,
    DetectionStatus,
    SensitivityTier,
    ShieldErrorCode,
)
from skaldos_shield.redaction import (
    CREDENTIAL_CATEGORY,
    PII_CATEGORY,
    STRUCTURED_ID_CATEGORY,
    RedactionSpan,
    safe_category,
    safe_entity_type,
)

_SAFE_METADATA_TOKEN_RE = re.compile(r"^[a-z0-9_.:-]+$")
_FIXTURE_MARKER_RE = re.compile(r"(^|[_.:-])fixture([_.:-]|$)")


class DetectorStatusReason(BaseModel):
    """Value-free detector failure metadata safe for logs and audit."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: DetectionStatus
    error_code: ShieldErrorCode
    detector_id: str

    @field_validator("detector_id")
    @classmethod
    def _safe_detector_id(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("detector_id must be non-empty")
        if _SAFE_METADATA_TOKEN_RE.fullmatch(value) is None:
            raise ValueError("detector_id must be a compact safe identifier")
        return value


class DetectorAnalysis(BaseModel):
    """Detector output: serializable plan plus in-process replacement spans."""

    model_config = ConfigDict(extra="forbid", frozen=True, arbitrary_types_allowed=True)

    plan: DetectionPlan
    spans: tuple[RedactionSpan, ...] = ()
    status_reason: DetectorStatusReason | None = None

    @property
    def clean(self) -> bool:
        """Whether the detector produced a clean result."""

        return self.plan.status == DetectionStatus.CLEAN


@dataclass(frozen=True, slots=True)
class DetectorMatch:
    """One in-process detector match with offsets but no matched value."""

    start: int
    end: int
    entity_type: str
    category: str
    confidence: ConfidenceBucket = ConfidenceBucket.HIGH
    action: DetectionAction = DetectionAction.SUBSTITUTE

    def to_redaction_span(self) -> RedactionSpan:
        """Convert to the replacement engine's in-process span shape."""

        return RedactionSpan(
            start=self.start,
            end=self.end,
            entity_type=safe_entity_type(self.entity_type),
            category=safe_category(self.category),
            confidence=self.confidence,
        )


class ShieldDetector(Protocol):
    """Small adapter contract for future detector implementations."""

    detector_id: str
    version: str

    def detect(self, text: str) -> Iterable[DetectorMatch]:
        """Return in-process matches for one text payload."""
        ...


class DetectorTimeoutError(Exception):
    """Detector timed out without exposing unsafe exception details."""


class DetectorSaturatedError(Exception):
    """Detector dependency was saturated and could not scan."""


class FixtureDetectorRule(BaseModel):
    """Deterministic test-only detector rule."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    marker: str
    entity_type: str
    category: str = PII_CATEGORY
    confidence: ConfidenceBucket = ConfidenceBucket.HIGH
    action: DetectionAction = DetectionAction.SUBSTITUTE

    @field_validator("marker", "entity_type", "category")
    @classmethod
    def _non_empty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("fixture detector rule fields must be non-empty")
        return value


class FixtureDetector:
    """Deterministic detector for tests and local contract examples."""

    detector_id = "fixture"
    version = "fixture-v1"

    def __init__(self, rules: Iterable[FixtureDetectorRule]) -> None:
        self._rules = tuple(rules)

    def detect(self, text: str) -> Iterable[DetectorMatch]:
        for rule in self._rules:
            start = 0
            while True:
                index = text.find(rule.marker, start)
                if index < 0:
                    break
                yield DetectorMatch(
                    start=index,
                    end=index + len(rule.marker),
                    entity_type=rule.entity_type,
                    category=rule.category,
                    confidence=rule.confidence,
                    action=rule.action,
                )
                start = index + len(rule.marker)


class FailingFixtureDetector:
    """Deterministic failure adapter used to pin sanitized failure handling."""

    def __init__(
        self,
        *,
        error: Exception,
        detector_id: str = "fixture-failing",
        version: str = "fixture-v1",
    ) -> None:
        self.detector_id = detector_id
        self.version = version
        self._error = error

    def detect(self, text: str) -> Iterable[DetectorMatch]:
        return _raise_detector_error(self._error)


@dataclass(frozen=True, slots=True)
class DetectorRegistry:
    """Dependency-free registry facade consumed by later Shield stages."""

    detectors: tuple[ShieldDetector, ...] = ()
    registry_version: str = "shield-detectors-v1"
    rule_source_version: str = "fixture-rules-v1"
    requested_sensitivity: SensitivityTier | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "detectors", tuple(self.detectors))
        _validate_safe_version(self.registry_version)
        _validate_safe_version(self.rule_source_version)

    def analyze_text(self, text: str) -> DetectorAnalysis:
        """Analyze one text payload through all registered detectors."""

        matches: list[DetectorMatch] = []
        for detector in self.detectors:
            try:
                matches.extend(detector.detect(text))
            except DetectorTimeoutError:
                return self._failure(
                    status=DetectionStatus.TIMEOUT,
                    error_code=ShieldErrorCode.DETECTOR_TIMEOUT,
                    detector_id=detector.detector_id,
                )
            except DetectorSaturatedError:
                return self._failure(
                    status=DetectionStatus.SATURATED,
                    error_code=ShieldErrorCode.DETECTOR_SATURATED,
                    detector_id=detector.detector_id,
                )
            except Exception:
                return self._failure(
                    status=DetectionStatus.ERROR,
                    error_code=ShieldErrorCode.DETECTOR_ERROR,
                    detector_id=detector.detector_id,
                )

        try:
            spans = _normalize_matches(text, matches)
            findings = tuple(_findings_for_matches(matches))
            classified_tier = _classified_tier(matches)
        except Exception:
            return self._failure(
                status=DetectionStatus.ERROR,
                error_code=ShieldErrorCode.DETECTOR_ERROR,
                detector_id="registry",
            )

        status = DetectionStatus.DETECTED if findings else DetectionStatus.CLEAN
        required_sensitivity = max(
            classified_tier,
            self.requested_sensitivity
            if self.requested_sensitivity is not None
            else SensitivityTier.NON_PII,
        )

        return DetectorAnalysis(
            plan=DetectionPlan(
                status=status,
                registry_version=self.registry_version,
                rule_source_version=self.rule_source_version,
                required_sensitivity=required_sensitivity,
                findings=findings,
                input_size_bucket=_char_count_bucket(len(text)),
            ),
            spans=spans,
        )

    def _failure(
        self,
        *,
        status: DetectionStatus,
        error_code: ShieldErrorCode,
        detector_id: str,
    ) -> DetectorAnalysis:
        reason = DetectorStatusReason(
            status=status,
            error_code=error_code,
            detector_id=detector_id,
        )
        return DetectorAnalysis(
            plan=DetectionPlan(
                status=status,
                registry_version=self.registry_version,
                rule_source_version=self.rule_source_version,
                required_sensitivity=SensitivityTier.PII_STRICT,
                findings=(),
            ),
            status_reason=reason,
        )


def validate_production_detector_registry(
    registry: DetectorRegistry,
    *,
    rule_source_version: str,
) -> None:
    """Reject fixture or empty detector registries for production call cores."""

    if not registry.detectors:
        raise ValueError("production_detector_registry_empty")
    if registry.rule_source_version != rule_source_version:
        raise ValueError("production_detector_rule_source_mismatch")
    safe_tokens = (registry.registry_version, registry.rule_source_version)
    detector_tokens = tuple(
        token
        for detector in registry.detectors
        for token in (detector.detector_id, detector.version)
    )
    if any(_is_fixture_marker(token) for token in (*safe_tokens, *detector_tokens)):
        raise ValueError("production_detector_fixture_marker")


def _normalize_matches(
    text: str,
    matches: Iterable[DetectorMatch],
) -> tuple[RedactionSpan, ...]:
    spans = tuple(
        sorted(
            (match.to_redaction_span() for match in matches),
            key=lambda span: (span.start, span.end),
        )
    )
    previous_end = 0
    for span in spans:
        if span.end > len(text):
            raise ValueError("detector span exceeds text length")
        if span.start < previous_end:
            raise ValueError("detector registry requires non-overlapping matches")
        previous_end = span.end
    return spans


def _validate_safe_version(value: str) -> None:
    if not value.strip():
        raise ValueError("detector registry versions must be non-empty")
    if _SAFE_METADATA_TOKEN_RE.fullmatch(value) is None:
        raise ValueError("detector registry versions must be compact safe identifiers")


def _is_fixture_marker(value: str) -> bool:
    return _FIXTURE_MARKER_RE.search(value.lower()) is not None


def _raise_detector_error(error: Exception) -> Iterable[DetectorMatch]:
    raise error
    yield DetectorMatch(
        start=0,
        end=1,
        entity_type="UNREACHABLE",
        category=PII_CATEGORY,
    )


def _findings_for_matches(matches: Iterable[DetectorMatch]) -> Iterable[DetectionFinding]:
    grouped: Counter[tuple[str, str, ConfidenceBucket, DetectionAction, str]] = Counter()
    for match in matches:
        grouped[
            (
                safe_entity_type(match.entity_type),
                safe_category(match.category),
                match.confidence,
                match.action,
                _char_count_bucket(match.end - match.start),
            )
        ] += 1

    for (entity_type, category, confidence, action, char_count_bucket), count in sorted(
        grouped.items(),
        key=lambda item: item[0],
    ):
        yield DetectionFinding(
            entity_type=entity_type,
            category=category,
            count=count,
            confidence=confidence,
            action=action,
            char_count_bucket=char_count_bucket,
        )


def _classified_tier(matches: Iterable[DetectorMatch]) -> SensitivityTier:
    tier = SensitivityTier.NON_PII
    for match in matches:
        category = safe_category(match.category)
        if category == CREDENTIAL_CATEGORY:
            return SensitivityTier.CREDENTIALS
        if category == STRUCTURED_ID_CATEGORY:
            tier = max(tier, SensitivityTier.PII_STRICT)
        elif category == PII_CATEGORY:
            tier = max(tier, SensitivityTier.PII)
    return tier


def _char_count_bucket(char_count: int) -> str:
    if char_count <= 0:
        return "0"
    if char_count <= 64:
        return "1-64"
    if char_count <= 256:
        return "65-256"
    return "257+"
