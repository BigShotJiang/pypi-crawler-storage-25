-- aiosql query module for Slice 5 Shield audit/query-log writers.
--
-- This surface accepts only value-free metadata, ids, counters, and digests.
-- Callers must never pass prompt text, response text, raw queries, raw detector
-- values, provider payloads, or credentials.

-- tenant_filter_required: Shield call records are tenant-scoped by tenant_id; RLS enforces visible tenants and actor_principal_id = app.principal_id().
-- name: insert_shield_call_record<!
INSERT INTO shield_call_records (
       tenant_id,
       actor_principal_id,
       agent_run_id,
       tool_call_id,
       trace_id,
       span_id,
       redaction_session_id,
       mode,
       request_shape,
       task_class,
       sensitivity_classified,
       sensitivity_requested,
       shield_enabled,
       detections,
       detection_count,
       policy_outcome
)
VALUES (
       :tenant_id,
       :actor_principal_id,
       :agent_run_id,
       :tool_call_id,
       :trace_id,
       :span_id,
       :redaction_session_id,
       :mode,
       :request_shape,
       :task_class,
       :sensitivity_classified,
       :sensitivity_requested,
       :shield_enabled,
       CAST(:detections AS jsonb),
       :detection_count,
       :policy_outcome
)
RETURNING id,
          tenant_id,
          actor_principal_id,
          trace_id,
          span_id,
          policy_outcome,
          created_at,
          completed_at;

-- tenant_filter_required: completion is scoped by tenant_id and id; GRANTs restrict the mutable columns.
-- name: complete_shield_call_record<!
UPDATE shield_call_records
   SET policy_outcome = :policy_outcome,
       latency_total_ms = :latency_total_ms,
       latency_redaction_ms = :latency_redaction_ms,
       latency_upstream_ms = :latency_upstream_ms,
       latency_rehydration_ms = :latency_rehydration_ms,
       tokens_in = :tokens_in,
       tokens_out = :tokens_out,
       cost_estimated_micros = :cost_estimated_micros,
       cost_currency = :cost_currency,
       cache_hit = :cache_hit,
       redaction_skipped = :redaction_skipped,
       redaction_skip_reason = :redaction_skip_reason,
       sensitivity_used = :sensitivity_used,
       route_fallback_distance = :route_fallback_distance,
       provider_route_id = :provider_route_id,
       model_provider = :model_provider,
       model_id = :model_id,
       completed_at = now()
 WHERE tenant_id = :tenant_id
   AND id = :call_record_id
   AND policy_outcome = 'attempted'
   AND completed_at IS NULL
RETURNING id,
          tenant_id,
          actor_principal_id,
          trace_id,
          span_id,
          policy_outcome,
          created_at,
          completed_at;

-- tenant_filter_required: query logs are tenant-scoped by tenant_id; RLS enforces visible tenants and principal_id = app.principal_id().
-- name: insert_pii_query_log<!
SELECT id,
       tenant_id,
       principal_id,
       trace_id,
       span_id,
       query_digest,
       query_digest_version,
       detected_entity_types,
       detection_count,
       created_at
FROM app.insert_pii_query_log_from_shield(
       :tenant_id,
       :principal_id,
       :trace_id,
       :span_id,
       :query_digest,
       :query_digest_version,
       :detected_entity_types,
       :detection_count
);

-- tenant_filter_required: existing audit_entries RLS anchors Shield evidence handles by tenant_id and actor_principal_id.
-- name: insert_shield_audit_entry<!
INSERT INTO audit_entries (
       tenant_id,
       actor_principal_id,
       subject_type,
       subject_id,
       action,
       intent,
       context_of_validity,
       outcome,
       policy_decision_metadata
)
SELECT
       :tenant_id,
       :actor_principal_id,
       :subject_type,
       :subject_id,
       :action,
       :intent,
       CAST(:context_of_validity AS jsonb),
       :outcome,
       CAST(:policy_decision_metadata AS jsonb)
WHERE (
       CAST(:shield_call_record_id AS uuid) IS NULL
       OR EXISTS (
          SELECT 1
          FROM shield_call_records
          WHERE id = CAST(:shield_call_record_id AS uuid)
            AND tenant_id = :tenant_id
            AND actor_principal_id = :actor_principal_id
       )
)
AND (
       CAST(:pii_query_log_id AS uuid) IS NULL
       OR EXISTS (
          SELECT 1
          FROM pii_query_logs
          WHERE id = CAST(:pii_query_log_id AS uuid)
            AND tenant_id = :tenant_id
            AND principal_id = :actor_principal_id
       )
)
RETURNING id,
          row_hash;
