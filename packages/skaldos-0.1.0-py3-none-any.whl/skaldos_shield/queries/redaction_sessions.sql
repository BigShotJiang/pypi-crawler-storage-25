-- aiosql query module for Slice 5 redaction-session storage.
--
-- This accessor surface is schema foundation only. It accepts lookup digests,
-- ciphertext, wrapped-DEK material, and scoped identifiers. Callers must never
-- pass raw PII, raw synthetic values, raw prompt text, or raw block text.

-- tenant_filter_required: Redaction sessions are tenant-scoped by tenant_id; every query filters tenant_id and RLS enforces visible tenants.
-- name: create_redaction_session<!
INSERT INTO pii_redaction_sessions (
       tenant_id,
       parent_principal_id,
       authn_session_id,
       subject_key_id,
       kms_key_ref,
       wrapped_dek_ciphertext,
       mapping_limit,
       expires_at
)
VALUES (
       :tenant_id,
       :parent_principal_id,
       :authn_session_id,
       :subject_key_id,
       :kms_key_ref,
       :wrapped_dek_ciphertext,
       :mapping_limit,
       :expires_at
)
RETURNING id,
          tenant_id,
          parent_principal_id,
          authn_session_id,
          subject_key_id,
          kms_key_ref,
          wrapped_dek_ciphertext,
          mapping_count,
          mapping_limit,
          started_at,
          last_access_at,
          expires_at,
          purged_at,
          purge_reason;

-- tenant_filter_required: session lookup is scoped by both tenant_id and redaction_session_id.
-- name: get_redaction_session^
SELECT id,
       tenant_id,
       parent_principal_id,
       authn_session_id,
       subject_key_id,
       kms_key_ref,
       wrapped_dek_ciphertext,
       mapping_count,
       mapping_limit,
       started_at,
       last_access_at,
       expires_at,
       purged_at,
       purge_reason
  FROM pii_redaction_sessions
 WHERE tenant_id = :tenant_id
   AND id = :session_id;

-- tenant_filter_required: mapping lookup is scoped by tenant_id and session_id; reverse lookup cannot cross sessions.
-- name: get_mapping_by_synthetic_digest^
SELECT id,
       tenant_id,
       session_id,
       entity_type,
       real_lookup_digest,
       synthetic_lookup_digest,
       mapping_ciphertext,
       created_at
  FROM pii_redaction_mappings
 WHERE tenant_id = :tenant_id
   AND session_id = :session_id
   AND synthetic_lookup_digest = :synthetic_lookup_digest;

-- tenant_filter_required: mapping insert is scoped by tenant_id and session_id; digest uniqueness enforces idempotency.
-- name: insert_redaction_mapping<!
INSERT INTO pii_redaction_mappings (
       tenant_id,
       session_id,
       entity_type,
       real_lookup_digest,
       synthetic_lookup_digest,
       mapping_ciphertext
)
SELECT parent_session.tenant_id,
       parent_session.id,
       :entity_type,
       :real_lookup_digest,
       :synthetic_lookup_digest,
       :mapping_ciphertext
  FROM pii_redaction_sessions parent_session
 WHERE parent_session.id = :session_id
   AND parent_session.tenant_id = :tenant_id
ON CONFLICT (session_id, real_lookup_digest) DO UPDATE
   SET real_lookup_digest = pii_redaction_mappings.real_lookup_digest
RETURNING id,
          tenant_id,
          session_id,
          entity_type,
          real_lookup_digest,
          synthetic_lookup_digest,
          mapping_ciphertext,
          created_at;
