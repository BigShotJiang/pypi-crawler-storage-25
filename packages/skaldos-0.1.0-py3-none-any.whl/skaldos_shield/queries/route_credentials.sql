-- aiosql query module for Shield-only Bifrost route credential resolution.
--
-- Plaintext provider keys are not stored here. This query returns encrypted
-- envelopes only to app_shield_runtime, filtered by tenant RLS and user-scope
-- ownership rules; the injected Shield decryptor owns plaintext recovery.

-- tenant_filter_required: route credentials are tenant-scoped and RLS-bound; this query also filters tenant_id explicitly.
-- name: get_active_route_credential_for_route^
SELECT id,
       tenant_id,
       provider,
       provider_secret_ref,
       scope,
       owner_principal_id,
       encrypted_secret_ciphertext,
       wrapped_dek,
       kms_key_reference,
       key_version,
       status
  FROM bifrost_route_credentials
 WHERE tenant_id = :tenant_id
   AND provider_secret_ref = :provider_secret_ref
   AND provider = :provider
   AND status = 'active'
   AND revoked_at IS NULL
   AND destroyed_at IS NULL
   AND (
        scope = 'org'
        OR (scope = 'user' AND owner_principal_id = :principal_id)
   );
