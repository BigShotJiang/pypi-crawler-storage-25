-- aiosql query module for Slice 5 provider-route policy lookup.
--
-- The query surface is intentionally limited to tenant-scoped active rows.
-- Worker A's pure routing selector owns capability filtering, sensitivity
-- no-downgrade checks, fallback distance, and provider/model hint handling.

-- tenant_filter_required: Slice 5 Bifrost routes are tenant-scoped by tenant_id per master-plan schema ownership; this query filters tenant_id and RLS enforces visible tenants.
-- name: list_active_provider_routes
SELECT id,
       tenant_id,
       sensitivity_tier,
       provider,
       model_id,
       provider_secret_ref,
       shield_enabled,
       priority,
       max_concurrent_calls,
       max_streaming_calls,
       requests_per_minute,
       tokens_per_minute,
       burst_limit,
       queue_policy,
       queue_max_delay_ms,
       budget_scope,
       base_url_override,
       embedding_dimensions,
       embedding_dtype,
       supports_chat,
       supports_agent_tool,
       supports_embedding,
       supports_search_query_embedding,
       supports_classification,
       supports_assertion_helper,
       is_active,
       created_at,
       revoked_at
  FROM bifrost_provider_route
 WHERE tenant_id = :tenant_id
   AND is_active
   AND revoked_at IS NULL
 ORDER BY created_at ASC, id ASC;
