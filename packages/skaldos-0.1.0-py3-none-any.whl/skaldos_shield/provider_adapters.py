"""Provider adapter contracts and fake adapter for Shield call-core tests."""

from __future__ import annotations

from typing import Protocol
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos_shield.contracts import (
    RouteMetadata,
    ShieldErrorCode,
    ShieldMessage,
    ShieldTrustedResult,
    UsageMetadata,
)
from skaldos_shield.credentials import ResolvedRouteCredential
from skaldos_shield.redaction_pipeline import ProviderSafeMessagePart


class ShieldProviderCallError(Exception):
    """Raised by provider adapters for safe, value-free provider call failures."""

    def __init__(self, message: str = "provider call failed") -> None:
        super().__init__(message)
        self.error_code = ShieldErrorCode.PROVIDER_CALL_FAILED


class ProviderAdapterRequest(BaseModel):
    """Provider-bound request with provider-safe content only."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    call_id: UUID
    route: RouteMetadata
    provider_safe_parts: tuple[ProviderSafeMessagePart, ...] = Field(min_length=1)
    credential: ResolvedRouteCredential | None = None


class ProviderAdapterResponse(BaseModel):
    """Provider response normalized before trusted rehydration exists."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    messages: tuple[ShieldMessage, ...] = ()
    result: ShieldTrustedResult | None = None
    usage: UsageMetadata = UsageMetadata()

    @model_validator(mode="after")
    def _requires_one_trusted_result(self) -> ProviderAdapterResponse:
        if self.result is None and not self.messages:
            raise ValueError("provider response requires messages or trusted result")
        return self


class ShieldProviderAdapter(Protocol):
    """Small non-streaming provider adapter boundary."""

    async def complete(self, request: ProviderAdapterRequest) -> ProviderAdapterResponse:
        """Execute a non-streaming provider call."""
        ...


class FakeProviderAdapter:
    """In-memory provider adapter that captures provider-safe requests."""

    def __init__(
        self,
        response: ProviderAdapterResponse,
        *,
        forbidden_fragments: tuple[str, ...] = (),
    ) -> None:
        self._response = response
        self._forbidden_fragments = forbidden_fragments
        self.captured_requests: list[ProviderAdapterRequest] = []

    async def complete(self, request: ProviderAdapterRequest) -> ProviderAdapterResponse:
        serialized = request.model_dump_json()
        for fragment in self._forbidden_fragments:
            if fragment and fragment in serialized:
                raise AssertionError("fake provider received forbidden fixture fragment")
        self.captured_requests.append(request)
        return self._response
