"""Pure Shield route selection for Slice 5 provider policy.

The selector is intentionally independent of HTTP, database access, provider
SDKs, and secret resolution. Later DAO code can hydrate
``BifrostProviderRoute`` records from Postgres, but selection remains a pure
policy function over in-memory route records.
"""

from __future__ import annotations

from collections.abc import Iterable
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Protocol
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos_shield.contracts import (
    ModelHint,
    RequiredSensitivity,
    RouteCapability,
    RouteMetadata,
    SensitivityTier,
    TaskClass,
    capability_for_task_class,
    effective_sensitivity,
)

_SENSITIVITY_ORDER: tuple[SensitivityTier, ...] = (
    SensitivityTier.NON_PII,
    SensitivityTier.PII,
    SensitivityTier.PII_STRICT,
    SensitivityTier.CREDENTIALS,
)
_SENSITIVITY_INDEX = {tier: index for index, tier in enumerate(_SENSITIVITY_ORDER)}


class RouteSelectionFailureReason(StrEnum):
    """Stable, PII-free route-policy rejection reasons."""

    NO_ACTIVE_ROUTE = "no_active_route"
    NO_CAPABILITY_ROUTE = "no_capability_route"
    CREDENTIAL_ROUTE_REQUIRED = "credential_route_required"
    NO_SENSITIVITY_ROUTE = "no_sensitivity_route"
    HINT_CONSTRAINT_UNSATISFIED = "hint_constraint_unsatisfied"


class RouteSelectionError(Exception):
    """Raised when Shield must reject before provider dispatch."""

    def __init__(
        self,
        reason: RouteSelectionFailureReason,
        required_sensitivity: RequiredSensitivity,
        required_capability: RouteCapability,
    ) -> None:
        super().__init__(reason.value)
        self.reason = reason
        self.required_sensitivity = required_sensitivity
        self.required_capability = required_capability


class BifrostProviderRoute(BaseModel):
    """In-memory provider route policy record suitable for DAO hydration."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    provider: str
    model_id: str
    sensitivity_tier: SensitivityTier
    capabilities: Annotated[frozenset[RouteCapability], Field(min_length=1)]
    priority: Annotated[int, Field(ge=0)] = 100
    created_at: datetime
    is_active: bool = True
    revoked_at: datetime | None = None
    shield_enabled: bool = True
    provider_secret_ref: str
    base_url_override: str | None = None
    embedding_dimensions: Annotated[int, Field(gt=0)] | None = None
    embedding_dtype: str | None = None

    @field_validator("provider", "model_id", "provider_secret_ref")
    @classmethod
    def _non_empty_string(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("route metadata fields must be non-empty")
        return value

    @model_validator(mode="after")
    def _active_route_is_usable(self) -> BifrostProviderRoute:
        if self.is_active and self.revoked_at is not None:
            raise ValueError("active routes cannot have revoked_at set")
        return self

    @property
    def usable_for_selection(self) -> bool:
        """Whether the route can be considered by route policy."""

        return self.is_active and self.revoked_at is None and self.shield_enabled


class RouteSelectionCandidate(Protocol):
    """Minimal route shape consumed by the pure selector."""

    id: UUID
    tenant_id: UUID
    provider: str
    model_id: str
    sensitivity_tier: SensitivityTier
    priority: int
    created_at: datetime
    embedding_dimensions: int | None
    embedding_dtype: str | None

    @property
    def capabilities(self) -> frozenset[RouteCapability]:
        """Explicit route capability set."""
        ...

    @property
    def usable_for_selection(self) -> bool:
        """Whether the route can be considered by route policy."""
        ...


class ShieldRouteDecision(BaseModel):
    """Safe selected-route decision returned by the pure selector."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    required_sensitivity: RequiredSensitivity
    required_capability: RouteCapability
    metadata: RouteMetadata


def select_shield_route(
    routes: Iterable[RouteSelectionCandidate],
    *,
    tenant_id: UUID,
    task_class: TaskClass,
    classified_tier: SensitivityTier,
    requested_tier: SensitivityTier | None = None,
    model_hint: ModelHint | None = None,
) -> ShieldRouteDecision:
    """Select a policy-approved route or raise a pre-provider rejection.

    Route filtering is deliberately ordered by the Slice 5 contract:
    tenant/active routes, capability, sensitivity, then provider/model
    hints as constraints inside the approved candidate set.
    """

    required_sensitivity = RequiredSensitivity(
        classified_tier=classified_tier,
        requested_tier=requested_tier,
        effective_tier=effective_sensitivity(classified_tier, requested_tier),
    )
    required_capability = capability_for_task_class(task_class)

    active_routes = [
        route for route in routes if route.tenant_id == tenant_id and route.usable_for_selection
    ]
    if not active_routes:
        raise RouteSelectionError(
            RouteSelectionFailureReason.NO_ACTIVE_ROUTE,
            required_sensitivity,
            required_capability,
        )

    capability_routes = [
        route for route in active_routes if required_capability in route.capabilities
    ]
    if not capability_routes:
        raise RouteSelectionError(
            RouteSelectionFailureReason.NO_CAPABILITY_ROUTE,
            required_sensitivity,
            required_capability,
        )

    if required_sensitivity.effective_tier == SensitivityTier.CREDENTIALS:
        sensitivity_routes = [
            route
            for route in capability_routes
            if route.sensitivity_tier == SensitivityTier.CREDENTIALS
        ]
        failure_reason = RouteSelectionFailureReason.CREDENTIAL_ROUTE_REQUIRED
    else:
        sensitivity_routes = [
            route
            for route in capability_routes
            if route.sensitivity_tier >= required_sensitivity.effective_tier
        ]
        failure_reason = RouteSelectionFailureReason.NO_SENSITIVITY_ROUTE

    if not sensitivity_routes:
        raise RouteSelectionError(
            failure_reason,
            required_sensitivity,
            required_capability,
        )

    hinted_routes = _apply_model_hint_constraints(sensitivity_routes, model_hint)
    if not hinted_routes:
        raise RouteSelectionError(
            RouteSelectionFailureReason.HINT_CONSTRAINT_UNSATISFIED,
            required_sensitivity,
            required_capability,
        )

    selected = min(
        hinted_routes,
        key=lambda route: (
            _fallback_distance(route.sensitivity_tier, required_sensitivity.effective_tier),
            route.priority,
            route.created_at,
            route.id,
        ),
    )
    distance = _fallback_distance(
        selected.sensitivity_tier,
        required_sensitivity.effective_tier,
    )
    return ShieldRouteDecision(
        required_sensitivity=required_sensitivity,
        required_capability=required_capability,
        metadata=RouteMetadata(
            route_id=selected.id,
            provider=selected.provider,
            model_id=selected.model_id,
            sensitivity_used=selected.sensitivity_tier,
            fallback_distance=distance,
            capability=required_capability,
            embedding_dimensions=selected.embedding_dimensions,
            embedding_dtype=selected.embedding_dtype,
        ),
    )


def _apply_model_hint_constraints(
    routes: list[RouteSelectionCandidate],
    model_hint: ModelHint | None,
) -> list[RouteSelectionCandidate]:
    if model_hint is None:
        return routes

    return [
        route
        for route in routes
        if (model_hint.provider is None or route.provider == model_hint.provider)
        and (model_hint.model_id is None or route.model_id == model_hint.model_id)
        and model_hint.capabilities.issubset(route.capabilities)
    ]


def _fallback_distance(
    selected_tier: SensitivityTier,
    required_tier: SensitivityTier,
) -> int:
    return _SENSITIVITY_INDEX[selected_tier] - _SENSITIVITY_INDEX[required_tier]
