"""Content-free Shield audit/query-log writer helpers."""

from __future__ import annotations

import hmac
import json
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from hashlib import sha256
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast
from uuid import UUID

import aiosql
from opentelemetry import trace
from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from skaldos_shield.contracts import (
    ConfidenceBucket,
    DetectionAction,
    DetectionFinding,
    PolicyOutcome,
    RequestShape,
    RouteMetadata,
    SensitivityTier,
    TaskClass,
    UsageMetadata,
)

if TYPE_CHECKING:
    import asyncpg  # pyright: ignore[reportMissingTypeStubs]

__all__ = [
    "AuditTraceContext",
    "ShieldAuditDetection",
    "ShieldAuditEntryReference",
    "ShieldAuditEntryRow",
    "ShieldAuditOutcome",
    "ShieldAuditRecords",
    "ShieldCallCompletion",
    "ShieldCallRecord",
    "ShieldCallStart",
    "ShieldPIIQueryDigest",
    "ShieldPIIQueryLog",
    "ShieldPIIQueryLogWrite",
    "current_audit_trace_context",
    "record_to_pii_query_log",
    "record_to_shield_audit_entry",
    "record_to_shield_call_record",
    "shield_audit_records",
]

_QUERIES_SQL_PATH: Path = Path(__file__).parent / "queries" / "audit_records.sql"
_ENTITY_TYPES = frozenset(
    {
        "EMAIL",
        "PHONE_NUMBER",
        "PERSON_NAME",
        "LOCATION",
        "ADDRESS",
        "NATIONAL_ID",
        "CREDIT_CARD",
        "IBAN",
        "API_KEY",
        "PASSWORD",
        "SECRET",
        "CREDENTIAL",
        "UNKNOWN",
    }
)
_DETECTOR_VERSIONS = frozenset(
    {
        "registry-v1",
        "presidio-baseline-v1",
        "gitleaks-ruleset-v1",
        "credential-ruleset-v1",
    }
)
_CHAR_COUNT_BUCKETS = frozenset({"1-64", "65-256", "257+"})
_AUDIT_OUTCOMES = frozenset({"permitted", "denied", "error"})
_AUDIT_INTENTS = frozenset({"assertive", "directive", "commissive", "expressive", "declarative"})
_QUERY_DIGEST_SCOPE = "tenant-environment-hmac-sha256-v1"
_QUERY_DIGEST_VERSION = 1
_QUERY_DIGEST_TRUST_TOKEN = object()


def _entity_type_tuple(value: object) -> tuple[str, ...]:
    if isinstance(value, str) or not isinstance(value, Sequence):
        raise TypeError("detected_entity_types must be a sequence")
    items: list[str] = []
    for item in cast("Sequence[object]", value):
        if not isinstance(item, str):
            raise TypeError("detected_entity_types must contain only strings")
        items.append(item)
    return tuple(items)


class AuditTraceContext(BaseModel):
    """Active OTel trace/span identifiers for Shield evidence rows."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    trace_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    span_id: str = Field(pattern=r"^[0-9a-f]{16}$")


def current_audit_trace_context() -> AuditTraceContext:
    """Return the current OTel trace/span or fail before audit writes."""

    span_context = trace.get_current_span().get_span_context()
    if not span_context.is_valid:
        raise RuntimeError("missing active OTel span for Shield audit write")
    return AuditTraceContext(
        trace_id=f"{span_context.trace_id:032x}",
        span_id=f"{span_context.span_id:016x}",
    )


class ShieldAuditAction(StrEnum):
    """Closed value-free action vocabulary persisted to Shield audit rows."""

    NONE = "none"
    SYNTHETIC_SUBSTITUTION = "synthetic_substitution"
    CREDENTIAL_PLACEHOLDER = "credential_placeholder"
    PLACEHOLDER_SUBSTITUTION = "placeholder_substitution"
    BLOCKED = "blocked"
    SKIPPED = "skipped"
    FAIL_CLOSED = "fail_closed"
    FAIL_OPEN = "fail_open"


class ShieldAuditOutcome(StrEnum):
    """Closed policy outcome vocabulary for Shield attempt/completion rows."""

    ATTEMPTED = "attempted"
    PASSED = "passed"
    REDACTED = "redacted"
    BLOCKED = "blocked"
    FAIL_OPEN = "fail_open"

    @classmethod
    def from_policy_outcome(cls, policy_outcome: PolicyOutcome) -> ShieldAuditOutcome:
        """Map canonical response outcomes into audit-row outcome values."""

        return cls(policy_outcome.value)


class ShieldAuditDetection(BaseModel):
    """One content-free detection summary object persisted as JSONB."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    entity_type: str
    confidence_bucket: ConfidenceBucket | None = None
    action: ShieldAuditAction | None = None
    count: int | None = Field(default=None, ge=0, le=1_000_000)
    char_count_bucket: str | None = None
    detector_version: str | None = None

    @field_validator("entity_type")
    @classmethod
    def _entity_type_closed_vocab(cls, value: str) -> str:
        normalized = value.strip().upper()
        aliases = {
            "PERSON": "PERSON_NAME",
            "PAYMENT_CARD": "CREDIT_CARD",
            "PRIVATE_KEY": "SECRET",
        }
        normalized = aliases.get(normalized, normalized)
        if normalized not in _ENTITY_TYPES:
            raise ValueError("entity_type must use the closed Shield audit vocabulary")
        return normalized

    @field_validator("char_count_bucket")
    @classmethod
    def _char_count_bucket_closed_vocab(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if value not in _CHAR_COUNT_BUCKETS:
            raise ValueError("char_count_bucket must use the closed Shield audit vocabulary")
        return value

    @field_validator("detector_version")
    @classmethod
    def _detector_version_closed_vocab(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if value not in _DETECTOR_VERSIONS:
            raise ValueError("detector_version must use the closed Shield audit vocabulary")
        return value

    @classmethod
    def from_finding(
        cls,
        finding: DetectionFinding,
        *,
        detector_version: str,
    ) -> ShieldAuditDetection:
        """Project detector metadata into the DB-safe audit vocabulary."""

        action = ShieldAuditAction.NONE
        if finding.action == DetectionAction.SUBSTITUTE:
            action = ShieldAuditAction.SYNTHETIC_SUBSTITUTION
        elif finding.action == DetectionAction.STRIP:
            action = ShieldAuditAction.PLACEHOLDER_SUBSTITUTION
        elif finding.action == DetectionAction.BLOCK:
            action = ShieldAuditAction.BLOCKED
        elif finding.action == DetectionAction.ESCAPE_LITERAL_PLACEHOLDER:
            action = ShieldAuditAction.PLACEHOLDER_SUBSTITUTION
        return cls(
            entity_type=finding.entity_type,
            confidence_bucket=finding.confidence,
            action=action,
            count=finding.count,
            char_count_bucket=finding.char_count_bucket,
            detector_version=detector_version,
        )

    def to_jsonable(self) -> dict[str, object]:
        """Return a compact value-free JSON object for Postgres."""

        return self.model_dump(mode="json", exclude_none=True)


class ShieldCallRecord(BaseModel):
    """Minimal row projection for Shield call evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    actor_principal_id: UUID
    trace_id: str
    span_id: str
    policy_outcome: str
    created_at: datetime
    completed_at: datetime | None


class ShieldPIIQueryLog(BaseModel):
    """Minimal row projection for a content-free PII query log."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    principal_id: UUID
    trace_id: str
    span_id: str
    query_digest: bytes = Field(min_length=32, max_length=32)
    query_digest_version: int = Field(gt=0)
    detected_entity_types: tuple[str, ...] = Field(min_length=1)
    detection_count: int = Field(gt=0)
    created_at: datetime

    @field_validator("detected_entity_types", mode="before")
    @classmethod
    def _detected_entity_types_tuple(cls, value: object) -> tuple[str, ...]:
        return _entity_type_tuple(value)

    @field_validator("detected_entity_types")
    @classmethod
    def _detected_entity_types_closed_vocab(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        for item in value:
            if item not in _ENTITY_TYPES:
                raise ValueError("detected_entity_types must use the closed Shield vocabulary")
        return value


class ShieldAuditEntryRow(BaseModel):
    """Minimal `audit_entries` projection anchoring Shield evidence handles."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    row_hash: bytes = Field(min_length=32, max_length=32)


@dataclass(frozen=True, slots=True)
class ShieldPIIQueryDigest:
    """Tenant/environment-scoped HMAC digest for PII-bearing queries."""

    digest: bytes
    version: int
    scope: str

    def __init__(
        self,
        *,
        digest: bytes,
        version: int = _QUERY_DIGEST_VERSION,
        scope: str = _QUERY_DIGEST_SCOPE,
        _trust_token: object | None = None,
    ) -> None:
        if _trust_token is not _QUERY_DIGEST_TRUST_TOKEN:
            raise TypeError("ShieldPIIQueryDigest must be built with from_query()")
        if len(digest) != 32:
            raise ValueError("query digest must be 32 bytes")
        if version != _QUERY_DIGEST_VERSION or scope != _QUERY_DIGEST_SCOPE:
            raise ValueError("query digest must use the current Shield HMAC version")
        object.__setattr__(self, "digest", digest)
        object.__setattr__(self, "version", version)
        object.__setattr__(self, "scope", scope)

    @classmethod
    def from_query(
        cls,
        *,
        query_text: str,
        tenant_id: UUID,
        environment_id: str,
        hmac_key: bytes,
    ) -> ShieldPIIQueryDigest:
        """Derive a stable tenant/environment-scoped digest without storing raw text."""

        if not query_text:
            raise ValueError("query_text must be non-empty")
        if len(hmac_key) < 32:
            raise ValueError("query HMAC key must be at least 32 bytes")
        if not environment_id or not environment_id.replace("-", "_").isalnum():
            raise ValueError("environment_id must be a safe slug")
        message = "\x1f".join(
            (
                _QUERY_DIGEST_SCOPE,
                str(tenant_id),
                environment_id,
                query_text,
            )
        ).encode("utf-8")
        return cls(
            digest=hmac.new(hmac_key, message, sha256).digest(),
            _trust_token=_QUERY_DIGEST_TRUST_TOKEN,
        )


class ShieldPIIQueryLogWrite(BaseModel):
    """Input for a hash-only PII query-log insert."""

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="forbid", frozen=True)

    tenant_id: UUID
    principal_id: UUID
    query_digest: ShieldPIIQueryDigest
    detected_entity_types: tuple[str, ...] = Field(min_length=1)

    @field_validator("detected_entity_types", mode="before")
    @classmethod
    def _detected_entity_types_tuple(cls, value: object) -> tuple[str, ...]:
        return _entity_type_tuple(value)

    @field_validator("detected_entity_types")
    @classmethod
    def _detected_entity_types_closed_vocab(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        for item in value:
            if item not in _ENTITY_TYPES:
                raise ValueError("detected_entity_types must use the closed Shield vocabulary")
        return value

    @property
    def detection_count(self) -> int:
        """Number of entity type summaries stored for this query digest."""

        return len(self.detected_entity_types)


class ShieldCallStart(BaseModel):
    """Input for the durable pre-provider Shield attempt row."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    actor_principal_id: UUID
    agent_run_id: UUID | None = None
    tool_call_id: UUID | None = None
    trace_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{32}$")
    span_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{16}$")
    redaction_session_id: UUID | None = None
    mode: str = "request-response"
    request_shape: RequestShape = RequestShape.CANONICAL
    task_class: TaskClass
    sensitivity_classified: SensitivityTier
    sensitivity_requested: SensitivityTier | None = None
    shield_enabled: bool = True
    detections: tuple[ShieldAuditDetection, ...] = ()

    @field_validator("mode")
    @classmethod
    def _mode_safe_shape(cls, value: str) -> str:
        if value not in {"request-response", "streaming-sse"}:
            raise ValueError("mode must use Shield audit vocabulary")
        return value


class ShieldAuditEntryReference(BaseModel):
    """Content-free AuditEntry link to Shield evidence handles."""

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    tenant_id: UUID = Field(validation_alias=AliasChoices("tenant_id", "organization_id"))
    actor_principal_id: UUID
    subject_type: str = Field(pattern=r"^[a-z][a-z0-9_:-]{0,63}$")
    subject_id: UUID | None = None
    action: str = Field(pattern=r"^[a-z][a-z0-9_.:-]{0,63}$")
    intent: str = "assertive"
    context_of_validity: dict[str, object]
    outcome: str
    shield_call_record_id: UUID | None = None
    pii_query_log_id: UUID | None = None
    policy_version: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$")
    hash_version: int = Field(gt=0)

    @property
    def organization_id(self) -> UUID:
        """Compatibility alias for product/API audit callers."""

        return self.tenant_id

    @field_validator("intent")
    @classmethod
    def _intent_closed_vocab(cls, value: str) -> str:
        if value not in _AUDIT_INTENTS:
            raise ValueError("intent must use the audit intent vocabulary")
        return value

    @field_validator("outcome")
    @classmethod
    def _outcome_closed_vocab(cls, value: str) -> str:
        if value not in _AUDIT_OUTCOMES:
            raise ValueError("outcome must use the audit outcome vocabulary")
        return value

    @model_validator(mode="after")
    def _has_evidence_handle(self) -> ShieldAuditEntryReference:
        if self.shield_call_record_id is None and self.pii_query_log_id is None:
            raise ValueError("Shield audit entry links require at least one evidence id")
        return self

    def metadata_jsonable(self) -> dict[str, object]:
        """Return handle-only policy metadata for `audit_entries`."""

        metadata: dict[str, object] = {
            "policy_version": self.policy_version,
            "hash_version": self.hash_version,
            "evidence_kind": "shield",
        }
        if self.shield_call_record_id is not None:
            metadata["shield_call_record_id"] = str(self.shield_call_record_id)
        if self.pii_query_log_id is not None:
            metadata["pii_query_log_id"] = str(self.pii_query_log_id)
        return metadata


class ShieldCallCompletion(BaseModel):
    """Column-limited completion metadata for a Shield attempt row."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_outcome: ShieldAuditOutcome
    latency_total_ms: int | None = Field(default=None, ge=0)
    latency_redaction_ms: int | None = Field(default=None, ge=0)
    latency_upstream_ms: int | None = Field(default=None, ge=0)
    latency_rehydration_ms: int | None = Field(default=None, ge=0)
    tokens_in: int | None = Field(default=None, ge=0)
    tokens_out: int | None = Field(default=None, ge=0)
    cost_estimated_micros: int | None = Field(default=None, ge=0)
    cost_currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    cache_hit: bool | None = None
    redaction_skipped: bool = False
    redaction_skip_reason: str | None = None
    sensitivity_used: SensitivityTier | None = None
    route_fallback_distance: int | None = Field(default=None, ge=0)
    provider_route_id: UUID | None = None
    model_provider: str | None = Field(default=None, pattern=r"^[a-z][a-z0-9_-]*$")
    model_id: str | None = Field(default=None, pattern=r"^[A-Za-z0-9][A-Za-z0-9._:/-]*$")

    @field_validator("redaction_skip_reason")
    @classmethod
    def _redaction_skip_reason_safe(cls, value: str | None) -> str | None:
        if value is None:
            return None
        allowed = {
            "oversized",
            "unscannable",
            "unsupported_part",
            "detector_timeout",
            "shield_disabled",
        }
        if value not in allowed:
            raise ValueError("redaction_skip_reason must use Shield audit vocabulary")
        return value

    @model_validator(mode="after")
    def _skip_reason_pair(self) -> ShieldCallCompletion:
        if not self.redaction_skipped and self.redaction_skip_reason is not None:
            raise ValueError("redaction_skip_reason requires redaction_skipped=true")
        return self

    @classmethod
    def from_route_usage(
        cls,
        *,
        policy_outcome: PolicyOutcome,
        route: RouteMetadata | None,
        usage: UsageMetadata,
        latency_total_ms: int | None = None,
        latency_redaction_ms: int | None = None,
        latency_upstream_ms: int | None = None,
        latency_rehydration_ms: int | None = None,
        cost_estimated_micros: int | None = None,
        cost_currency: str | None = None,
    ) -> ShieldCallCompletion:
        """Build completion metadata from safe route and usage contracts."""

        return cls(
            policy_outcome=ShieldAuditOutcome.from_policy_outcome(policy_outcome),
            latency_total_ms=latency_total_ms,
            latency_redaction_ms=latency_redaction_ms,
            latency_upstream_ms=latency_upstream_ms,
            latency_rehydration_ms=latency_rehydration_ms,
            tokens_in=usage.tokens_in,
            tokens_out=usage.tokens_out,
            cache_hit=usage.cache_hit,
            cost_estimated_micros=cost_estimated_micros,
            cost_currency=cost_currency,
            sensitivity_used=route.sensitivity_used if route is not None else None,
            route_fallback_distance=route.fallback_distance if route is not None else None,
            provider_route_id=route.route_id if route is not None else None,
            model_provider=route.provider if route is not None else None,
            model_id=route.model_id if route is not None else None,
        )


def _load_queries() -> Any:  # noqa: ANN401 - aiosql exposes dynamic query attributes
    return aiosql.from_path(_QUERIES_SQL_PATH, "asyncpg")  # pyright: ignore[reportUnknownMemberType]


def record_to_shield_call_record(record: Any) -> ShieldCallRecord:  # noqa: ANN401
    """Project an asyncpg record into a typed Shield call row."""

    return ShieldCallRecord.model_validate(dict(record))


def record_to_pii_query_log(record: Any) -> ShieldPIIQueryLog:  # noqa: ANN401
    """Project an asyncpg record into a typed PII query-log row."""

    return ShieldPIIQueryLog.model_validate(dict(record))


def record_to_shield_audit_entry(record: Any) -> ShieldAuditEntryRow:  # noqa: ANN401
    """Project an asyncpg record into a typed audit-entry handle row."""

    return ShieldAuditEntryRow.model_validate(dict(record))


class ShieldAuditRecords:
    """aiosql-backed Shield audit/query-log writer wrapper."""

    def __init__(self, queries: Any | None = None) -> None:  # noqa: ANN401
        self._queries = queries if queries is not None else _load_queries()

    async def insert_call_attempt(
        self,
        conn: asyncpg.Connection,
        attempt: ShieldCallStart,
        *,
        trace_context: AuditTraceContext | None = None,
    ) -> ShieldCallRecord:
        """Insert the durable pre-provider Shield attempt row."""

        if trace_context is None and attempt.trace_id is not None and attempt.span_id is not None:
            trace_context = AuditTraceContext(trace_id=attempt.trace_id, span_id=attempt.span_id)
        if trace_context is None:
            trace_context = current_audit_trace_context()
        detections = [detection.to_jsonable() for detection in attempt.detections]
        record = await self._queries.insert_shield_call_record(
            conn,
            tenant_id=attempt.tenant_id,
            actor_principal_id=attempt.actor_principal_id,
            agent_run_id=attempt.agent_run_id,
            tool_call_id=attempt.tool_call_id,
            trace_id=trace_context.trace_id,
            span_id=trace_context.span_id,
            redaction_session_id=attempt.redaction_session_id,
            mode=attempt.mode,
            request_shape=attempt.request_shape.value,
            task_class=attempt.task_class.value,
            sensitivity_classified=attempt.sensitivity_classified.name,
            sensitivity_requested=(
                attempt.sensitivity_requested.name
                if attempt.sensitivity_requested is not None
                else None
            ),
            shield_enabled=attempt.shield_enabled,
            detections=json.dumps(detections),
            detection_count=len(detections),
            policy_outcome=ShieldAuditOutcome.ATTEMPTED.value,
        )
        return record_to_shield_call_record(record)

    async def complete_call(
        self,
        conn: asyncpg.Connection,
        *,
        tenant_id: UUID,
        call_record_id: UUID,
        completion: ShieldCallCompletion,
    ) -> ShieldCallRecord:
        """Finalize column-limited completion metadata for one attempt row."""

        record = await self._queries.complete_shield_call_record(
            conn,
            tenant_id=tenant_id,
            call_record_id=call_record_id,
            policy_outcome=completion.policy_outcome.value,
            latency_total_ms=completion.latency_total_ms,
            latency_redaction_ms=completion.latency_redaction_ms,
            latency_upstream_ms=completion.latency_upstream_ms,
            latency_rehydration_ms=completion.latency_rehydration_ms,
            tokens_in=completion.tokens_in,
            tokens_out=completion.tokens_out,
            cost_estimated_micros=completion.cost_estimated_micros,
            cost_currency=completion.cost_currency,
            cache_hit=completion.cache_hit,
            redaction_skipped=completion.redaction_skipped,
            redaction_skip_reason=completion.redaction_skip_reason,
            sensitivity_used=completion.sensitivity_used.name
            if completion.sensitivity_used is not None
            else None,
            route_fallback_distance=completion.route_fallback_distance,
            provider_route_id=completion.provider_route_id,
            model_provider=completion.model_provider,
            model_id=completion.model_id,
        )
        if record is None:
            raise PermissionError(
                "Shield call record is not visible for tenant or already completed"
            )
        return record_to_shield_call_record(record)

    async def insert_pii_query_log(
        self,
        conn: asyncpg.Connection,
        query_log: ShieldPIIQueryLogWrite,
        *,
        trace_context: AuditTraceContext | None = None,
    ) -> ShieldPIIQueryLog:
        """Insert a hash-only PII query log row."""

        trace_context = (
            trace_context if trace_context is not None else current_audit_trace_context()
        )
        record = await self._queries.insert_pii_query_log(
            conn,
            tenant_id=query_log.tenant_id,
            principal_id=query_log.principal_id,
            trace_id=trace_context.trace_id,
            span_id=trace_context.span_id,
            query_digest=query_log.query_digest.digest,
            query_digest_version=query_log.query_digest.version,
            detected_entity_types=list(query_log.detected_entity_types),
            detection_count=query_log.detection_count,
        )
        return record_to_pii_query_log(record)

    async def link_audit_entry(
        self,
        conn: asyncpg.Connection,
        reference: ShieldAuditEntryReference,
    ) -> ShieldAuditEntryRow:
        """Anchor Shield evidence handles in the existing AuditEntry hash chain."""

        record = await self._queries.insert_shield_audit_entry(
            conn,
            tenant_id=reference.tenant_id,
            actor_principal_id=reference.actor_principal_id,
            subject_type=reference.subject_type,
            subject_id=reference.subject_id,
            action=reference.action,
            intent=reference.intent,
            shield_call_record_id=reference.shield_call_record_id,
            pii_query_log_id=reference.pii_query_log_id,
            context_of_validity=json.dumps(reference.context_of_validity, sort_keys=True),
            outcome=reference.outcome,
            policy_decision_metadata=json.dumps(reference.metadata_jsonable(), sort_keys=True),
        )
        if record is None:
            raise PermissionError("Shield audit entry references invisible evidence")
        return record_to_shield_audit_entry(record)


shield_audit_records: ShieldAuditRecords = ShieldAuditRecords()
