"""Span-safe Shield replacement engine.

The detector owns recognition. This module owns only provider-safe text
substitution and value-free metadata projection.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Final
from uuid import UUID

from skaldos_shield.contracts import (
    ConfidenceBucket,
    CredentialReplacement,
    DetectionAction,
    DetectionFinding,
    ReplacementMode,
    ReplacementResult,
    RequiredSensitivity,
    SensitivityTier,
)
from skaldos_shield.session_store import RedactionSessionStore

PII_CATEGORY: Final = "pii"
STRUCTURED_ID_CATEGORY: Final = "structured_id"
CREDENTIAL_CATEGORY: Final = "credential"


_STRIP_PLACEHOLDERS: Final[dict[str, str]] = {
    "EMAIL": "[EMAIL]",
    "PHONE_NUMBER": "[PHONE_NUMBER]",
    "PERSON": "[PERSON]",
    "LOCATION": "[LOCATION]",
    "ADDRESS": "[ADDRESS]",
    "PAYMENT_CARD": "[PAYMENT_CARD]",
    "IBAN": "[IBAN]",
    "ACCOUNT_ID": "[ACCOUNT_ID]",
    "FODSELSNUMMER": "[FODSELSNUMMER]",
    "ORGNR": "[ORGNR]",
}
_CREDENTIAL_PLACEHOLDERS: Final[dict[str, str]] = {
    "API_KEY": "[SECRET:API_KEY]",
    "PRIVATE_KEY": "[SECRET:PRIVATE_KEY]",
    "PASSWORD": "[SECRET:PASSWORD]",
}
_SAFE_ENTITY_TYPE_RE: Final = re.compile(r"^[A-Z][A-Z0-9_]*$")
_PLACEHOLDER_SHAPE_RE: Final = re.compile(r"\[[A-Z][A-Z0-9_]*(?::[A-Z0-9_]+)*\]")
_UNKNOWN_ENTITY_TYPE: Final = "UNKNOWN"
_SAFE_CATEGORIES: Final = frozenset({PII_CATEGORY, STRUCTURED_ID_CATEGORY, CREDENTIAL_CATEGORY})


@dataclass(frozen=True, slots=True)
class RedactionSpan:
    """In-process finding with raw span/value.

    Instances of this type must not be serialized into logs or audit rows.
    """

    start: int
    end: int
    entity_type: str
    category: str
    confidence: ConfidenceBucket = ConfidenceBucket.HIGH

    def __post_init__(self) -> None:
        if self.start < 0 or self.end <= self.start:
            raise ValueError("redaction span must have positive width")
        if not self.entity_type.strip():
            raise ValueError("entity_type must be non-empty")
        if not self.category.strip():
            raise ValueError("category must be non-empty")


class ReplacementEngine:
    """Apply provider-safe replacements for detector spans."""

    async def apply(
        self,
        *,
        text: str,
        spans: Iterable[RedactionSpan],
        mode: ReplacementMode,
        organization_id: UUID,
        session_id: UUID | None = None,
        session_store: RedactionSessionStore | None = None,
        requested_sensitivity: SensitivityTier | None = None,
    ) -> ReplacementResult:
        """Return provider-safe text and serializable value-free metadata."""

        ordered_spans = _normalize_spans(text, spans)
        classified_tier = _classified_tier(ordered_spans)
        required_sensitivity = RequiredSensitivity(
            classified_tier=classified_tier,
            requested_tier=requested_sensitivity,
            effective_tier=max(
                classified_tier,
                requested_sensitivity
                if requested_sensitivity is not None
                else SensitivityTier.NON_PII,
            ),
        )

        output_parts: list[str] = []
        replacement_count = 0
        escaped_count = 0
        credential_replacement = CredentialReplacement.NONE
        encrypted_token_refs: list[str] = []
        cursor = 0

        for span in ordered_spans:
            escaped_gap, gap_escaped_count = escape_literal_placeholders(text[cursor : span.start])
            output_parts.append(escaped_gap)
            escaped_count += gap_escaped_count

            raw_value = text[span.start : span.end]
            replacement, token_ref = await self._replacement_for_span(
                raw_value=raw_value,
                span=span,
                mode=mode,
                organization_id=organization_id,
                session_id=session_id,
                session_store=session_store,
                token_number=len(encrypted_token_refs) + 1,
            )
            output_parts.append(replacement)
            replacement_count += 1
            if token_ref is not None:
                encrypted_token_refs.append(token_ref)
            if safe_category(span.category) == CREDENTIAL_CATEGORY:
                credential_replacement = CredentialReplacement.INERT_PLACEHOLDER
            cursor = span.end

        escaped_tail, tail_escaped_count = escape_literal_placeholders(text[cursor:])
        output_parts.append(escaped_tail)
        escaped_count += tail_escaped_count

        return ReplacementResult(
            mode=mode,
            provider_safe_text="".join(output_parts),
            required_sensitivity=required_sensitivity,
            findings=tuple(_metadata_for_spans(ordered_spans, mode)),
            replacement_count=replacement_count,
            escaped_literal_placeholder_count=escaped_count,
            credential_replacement=credential_replacement,
            encrypted_token_refs=tuple(encrypted_token_refs),
        )

    async def _replacement_for_span(
        self,
        *,
        raw_value: str,
        span: RedactionSpan,
        mode: ReplacementMode,
        organization_id: UUID,
        session_id: UUID | None,
        session_store: RedactionSessionStore | None,
        token_number: int,
    ) -> tuple[str, str | None]:
        if safe_category(span.category) == CREDENTIAL_CATEGORY:
            return credential_placeholder(span.entity_type), None

        if mode == ReplacementMode.STRIP_PLACEHOLDERS:
            return placeholder_for_entity(span.entity_type), None

        if mode == ReplacementMode.ENCRYPT_HANDOFF:
            token_ref = f"redaction-token-{token_number}"
            return f"[ENCRYPTED:{safe_entity_type(span.entity_type)}:{token_number}]", token_ref

        if session_id is None or session_store is None:
            raise ValueError("synthetic substitution requires a session_id and session_store")

        mapping = await session_store.get_or_create_mapping(
            organization_id=organization_id,
            session_id=session_id,
            entity_type=safe_entity_type(span.entity_type),
            real_value=raw_value,
            sensitivity=SensitivityTier.PII,
        )
        return mapping.synthetic_value, None


def placeholder_for_entity(entity_type: str) -> str:
    """Return the stable strip-mode placeholder for a PII entity."""

    normalized = safe_entity_type(entity_type)
    return _STRIP_PLACEHOLDERS.get(normalized, f"[{normalized}]")


def credential_placeholder(entity_type: str) -> str:
    """Return an inert credential placeholder, never a synthetic secret."""

    normalized = safe_entity_type(entity_type)
    return _CREDENTIAL_PLACEHOLDERS.get(normalized, f"[SECRET:{normalized}]")


def safe_entity_type(entity_type: str) -> str:
    """Project detector labels to the provider-visible safe vocabulary."""

    normalized = entity_type.strip().upper()
    if _SAFE_ENTITY_TYPE_RE.fullmatch(normalized) is None:
        return _UNKNOWN_ENTITY_TYPE
    return normalized


def safe_category(category: str) -> str:
    """Project detector categories to the serializable safe vocabulary."""

    normalized = category.strip().lower()
    if normalized not in _SAFE_CATEGORIES:
        return PII_CATEGORY
    return normalized


def escape_literal_placeholders(text: str) -> tuple[str, int]:
    """Mark user-authored placeholder tokens so rehydration cannot mistake them."""

    escaped, count = _PLACEHOLDER_SHAPE_RE.subn(
        lambda match: f"[[LITERAL:{match.group(0)[1:-1]}]]",
        text,
    )
    return escaped, count


def _normalize_spans(text: str, spans: Iterable[RedactionSpan]) -> tuple[RedactionSpan, ...]:
    ordered_spans = tuple(sorted(spans, key=lambda span: (span.start, span.end)))
    previous_end = 0
    for span in ordered_spans:
        if span.end > len(text):
            raise ValueError("redaction span exceeds text length")
        if span.start < previous_end:
            raise ValueError("overlapping redaction spans must be resolved by the detector")
        previous_end = span.end
    return ordered_spans


def _classified_tier(spans: Iterable[RedactionSpan]) -> SensitivityTier:
    tier = SensitivityTier.NON_PII
    for span in spans:
        if safe_category(span.category) == CREDENTIAL_CATEGORY:
            return SensitivityTier.CREDENTIALS
        tier = SensitivityTier.PII
    return tier


def _metadata_for_spans(
    spans: Iterable[RedactionSpan],
    mode: ReplacementMode,
) -> Iterable[DetectionFinding]:
    action = DetectionAction.SUBSTITUTE
    if mode == ReplacementMode.STRIP_PLACEHOLDERS:
        action = DetectionAction.STRIP

    for span in spans:
        yield DetectionFinding(
            entity_type=safe_entity_type(span.entity_type),
            category=safe_category(span.category),
            count=1,
            confidence=span.confidence,
            action=action,
            char_count_bucket=_char_count_bucket(span.end - span.start),
        )


def _char_count_bucket(char_count: int) -> str:
    if char_count <= 64:
        return "1-64"
    if char_count <= 256:
        return "65-256"
    return "257+"
