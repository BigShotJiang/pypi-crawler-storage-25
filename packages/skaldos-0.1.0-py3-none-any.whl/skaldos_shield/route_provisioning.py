# pyright: reportPrivateUsage=false
"""Local/admin route provisioning helpers for Shield provider credentials."""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from typing import Literal
from uuid import UUID, uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator

from skaldos.kms.protocol import KMSClient
from skaldos_shield.credentials import (
    _AESGCM_NONCE_BYTES,
    _AESGCM_PREFIX,
    RouteCredentialEnvelope,
    RouteCredentialScope,
    RouteCredentialStatus,
)

VOYAGE_PROVIDER = "voyage"
VOYAGE_MODEL_ID = "voyage-4"
VOYAGE_OUTPUT_DIMENSION = 1024
VOYAGE_OUTPUT_DTYPE = "float"


class VoyageRouteProvisioningSpec(BaseModel):
    """Value-free org-scoped Voyage route provisioning inputs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    provider_secret_ref: str = Field(min_length=1)
    kms_key_reference: str = Field(min_length=1)
    key_version: str = Field(min_length=1)
    route_id: UUID = Field(default_factory=uuid4)
    credential_id: UUID = Field(default_factory=uuid4)
    sensitivity_tier: Literal["NON_PII", "PII", "PII_STRICT", "CREDENTIALS"] = "NON_PII"
    priority: int = Field(default=30, ge=0)
    max_concurrent_calls: int = Field(default=4, ge=1)
    max_streaming_calls: int = Field(default=1, ge=1)
    queue_policy: Literal["reject", "queue", "batch"] = "reject"
    queue_max_delay_ms: int = Field(default=0, ge=0, le=60_000)
    budget_scope: Literal["tenant", "principal", "agent_run", "route"] = "route"
    supports_embedding: bool = True
    supports_search_query_embedding: bool = True
    embedding_dimensions: Literal[1024] = 1024
    embedding_dtype: Literal["float"] = "float"

    @model_validator(mode="after")
    def _embedding_capability_required(self) -> VoyageRouteProvisioningSpec:
        if not (self.supports_embedding or self.supports_search_query_embedding):
            raise ValueError("voyage provisioning requires an embedding capability")
        if self.queue_policy != "reject" and self.queue_max_delay_ms <= 0:
            raise ValueError("queue and batch policies require queue_max_delay_ms > 0")
        return self


class VoyageRouteProvisioningPlan(BaseModel):
    """Generated SQL and value-free metadata for local/admin review."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    route_id: UUID
    credential_id: UUID
    tenant_id: UUID
    provider: Literal["voyage"] = VOYAGE_PROVIDER
    model_id: Literal["voyage-4"] = VOYAGE_MODEL_ID
    output_dimension: Literal[1024] = VOYAGE_OUTPUT_DIMENSION
    output_dtype: Literal["float"] = VOYAGE_OUTPUT_DTYPE
    provider_secret_ref: str
    kms_key_reference: str
    key_version: str
    sql: str


@dataclass(frozen=True)
class _EncryptedRouteCredential:
    ciphertext: bytes
    wrapped_dek: bytes
    secret_fingerprint: bytes


def build_voyage_route_provisioning_plan(
    *,
    spec: VoyageRouteProvisioningSpec,
    secret_value: SecretStr,
    kms_client: KMSClient,
) -> VoyageRouteProvisioningPlan:
    """Build SQL for an org-scoped Voyage credential and matching route row."""

    encrypted = _encrypt_route_credential(
        spec=spec,
        secret_value=secret_value,
        kms_client=kms_client,
    )
    return VoyageRouteProvisioningPlan(
        route_id=spec.route_id,
        credential_id=spec.credential_id,
        tenant_id=spec.tenant_id,
        provider_secret_ref=spec.provider_secret_ref,
        kms_key_reference=spec.kms_key_reference,
        key_version=spec.key_version,
        sql=_sql_for_plan(spec, encrypted),
    )


def _encrypt_route_credential(
    *,
    spec: VoyageRouteProvisioningSpec,
    secret_value: SecretStr,
    kms_client: KMSClient,
) -> _EncryptedRouteCredential:
    plaintext = secret_value.get_secret_value()
    if not plaintext:
        raise ValueError("route credential secret must be non-empty")
    plaintext_dek, wrapped_dek = kms_client.generate_dek(spec.kms_key_reference)
    envelope_for_aad = RouteCredentialEnvelope(
        id=spec.credential_id,
        tenant_id=spec.tenant_id,
        provider=VOYAGE_PROVIDER,
        provider_secret_ref=spec.provider_secret_ref,
        scope=RouteCredentialScope.ORG,
        owner_principal_id=None,
        encrypted_secret_ciphertext=b"pending",
        wrapped_dek=wrapped_dek,
        kms_key_reference=spec.kms_key_reference,
        key_version=spec.key_version,
        status=RouteCredentialStatus.ACTIVE,
    )
    nonce = os.urandom(_AESGCM_NONCE_BYTES)
    ciphertext = AESGCM(plaintext_dek).encrypt(
        nonce,
        plaintext.encode("utf-8"),
        envelope_for_aad.aad(),
    )
    return _EncryptedRouteCredential(
        ciphertext=_AESGCM_PREFIX + nonce + ciphertext,
        wrapped_dek=wrapped_dek,
        secret_fingerprint=hashlib.sha256(plaintext.encode("utf-8")).digest(),
    )


def _sql_for_plan(
    spec: VoyageRouteProvisioningSpec,
    encrypted: _EncryptedRouteCredential,
) -> str:
    return f"""-- Voyage route credential provisioning plan.
-- Review and run only in an approved non-production/admin database session.
-- Plaintext provider keys are intentionally absent from this SQL.

BEGIN;

INSERT INTO bifrost_route_credentials (
    id,
    tenant_id,
    provider,
    provider_secret_ref,
    scope,
    owner_principal_id,
    encrypted_secret_ciphertext,
    wrapped_dek,
    kms_key_reference,
    key_version,
    secret_fingerprint,
    status
) VALUES (
    '{spec.credential_id}'::uuid,
    '{spec.tenant_id}'::uuid,
    'voyage'::bifrost_provider,
    '{_sql_literal(spec.provider_secret_ref)}',
    'org'::bifrost_route_credential_scope,
    NULL,
    decode('{encrypted.ciphertext.hex()}', 'hex'),
    decode('{encrypted.wrapped_dek.hex()}', 'hex'),
    '{_sql_literal(spec.kms_key_reference)}',
    '{_sql_literal(spec.key_version)}',
    decode('{encrypted.secret_fingerprint.hex()}', 'hex'),
    'active'::bifrost_route_credential_status
);

INSERT INTO bifrost_provider_route (
    id,
    tenant_id,
    sensitivity_tier,
    provider,
    model_id,
    provider_secret_ref,
    shield_enabled,
    priority,
    max_concurrent_calls,
    max_streaming_calls,
    queue_policy,
    queue_max_delay_ms,
    budget_scope,
    supports_chat,
    supports_agent_tool,
    supports_embedding,
    supports_search_query_embedding,
    embedding_dimensions,
    embedding_dtype,
    supports_classification,
    supports_assertion_helper,
    is_active
) VALUES (
    '{spec.route_id}'::uuid,
    '{spec.tenant_id}'::uuid,
    '{spec.sensitivity_tier}'::shield_sensitivity_tier,
    'voyage'::bifrost_provider,
    'voyage-4',
    '{_sql_literal(spec.provider_secret_ref)}',
    true,
    {spec.priority},
    {spec.max_concurrent_calls},
    {spec.max_streaming_calls},
    '{spec.queue_policy}',
    {spec.queue_max_delay_ms},
    '{spec.budget_scope}',
    false,
    false,
    {_sql_bool(spec.supports_embedding)},
    {_sql_bool(spec.supports_search_query_embedding)},
    {spec.embedding_dimensions},
    '{spec.embedding_dtype}',
    false,
    false,
    true
);

COMMIT;
"""


def _sql_bool(value: bool) -> str:
    return "true" if value else "false"


def _sql_literal(value: str) -> str:
    return value.replace("'", "''")
