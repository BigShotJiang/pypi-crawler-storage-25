"""Pure Shield admission policy for Slice 5 backpressure.

This module does not own shared counters or provider dispatch. It evaluates a
content-free snapshot of current capacity and returns the pre-provider decision
that later lease/counter implementations must enforce.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated
from uuid import UUID

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, model_validator

from skaldos_shield.contracts import (
    LatencyMode,
    RouteCapability,
    SensitivityTier,
    ShieldErrorCode,
    TaskClass,
)


class ShieldCallMode(StrEnum):
    """Provider-call mode with separate streaming capacity."""

    REQUEST_RESPONSE = "request-response"
    STREAMING_SSE = "streaming-sse"


class ShieldQueuePolicy(StrEnum):
    """Admission posture when a capacity dimension is saturated."""

    REJECT = "reject"
    QUEUE = "queue"
    BATCH = "batch"


class AdmissionOutcome(StrEnum):
    """Stable content-free admission decision outcome."""

    ADMITTED = "admitted"
    REJECTED = "rejected"
    QUEUED = "queued"


class AdmissionRejectionReason(StrEnum):
    """Low-cardinality saturation reasons for errors, metrics, and evidence."""

    TENANT_CONCURRENCY_EXCEEDED = "tenant_concurrency_exceeded"
    PRINCIPAL_CONCURRENCY_EXCEEDED = "principal_concurrency_exceeded"
    AGENT_RUN_CONCURRENCY_EXCEEDED = "agent_run_concurrency_exceeded"
    ROUTE_BUDGET_EXHAUSTED = "route_budget_exhausted"
    STREAMING_CAPACITY_EXCEEDED = "streaming_capacity_exceeded"


_REASON_ERROR_CODE: dict[AdmissionRejectionReason, ShieldErrorCode] = {
    AdmissionRejectionReason.TENANT_CONCURRENCY_EXCEEDED: (
        ShieldErrorCode.TENANT_CONCURRENCY_EXCEEDED
    ),
    AdmissionRejectionReason.PRINCIPAL_CONCURRENCY_EXCEEDED: (
        ShieldErrorCode.PRINCIPAL_CONCURRENCY_EXCEEDED
    ),
    AdmissionRejectionReason.AGENT_RUN_CONCURRENCY_EXCEEDED: (
        ShieldErrorCode.AGENT_RUN_CONCURRENCY_EXCEEDED
    ),
    AdmissionRejectionReason.ROUTE_BUDGET_EXHAUSTED: ShieldErrorCode.ROUTE_BUDGET_EXHAUSTED,
    AdmissionRejectionReason.STREAMING_CAPACITY_EXCEEDED: (
        ShieldErrorCode.STREAMING_CAPACITY_EXCEEDED
    ),
}

_BATCHABLE_TASK_CLASSES = frozenset(
    {TaskClass.EMBEDDING, TaskClass.SEARCH_QUERY, TaskClass.CLASSIFICATION}
)


class ShieldAdmissionContext(BaseModel):
    """Content-free request dimensions needed before provider dispatch."""

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    tenant_id: UUID = Field(validation_alias=AliasChoices("tenant_id", "organization_id"))
    principal_id: UUID
    route_id: UUID
    task_class: TaskClass
    route_capability: RouteCapability
    sensitivity_tier: SensitivityTier
    mode: ShieldCallMode = ShieldCallMode.REQUEST_RESPONSE
    latency_mode: LatencyMode = LatencyMode.SYNC
    agent_run_id: UUID | None = None
    tool_call_id: UUID | None = None

    @property
    def organization_id(self) -> UUID:
        """Compatibility alias for product-facing admission tests/callers."""

        return self.tenant_id


class ShieldAdmissionBudget(BaseModel):
    """Capacity limits for one Shield route and caller context."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    max_tenant_concurrent_calls: Annotated[int, Field(ge=1)] = 4
    max_principal_concurrent_calls: Annotated[int, Field(ge=1)] = 2
    max_agent_run_concurrent_calls: Annotated[int, Field(ge=1)] = 2
    max_route_concurrent_calls: Annotated[int, Field(ge=1)] = 4
    max_route_streaming_calls: Annotated[int, Field(ge=1)] = 2
    retry_after_seconds: Annotated[int, Field(ge=1, le=60)] = 1
    queue_policy: ShieldQueuePolicy = ShieldQueuePolicy.REJECT
    queue_max_delay_ms: Annotated[int, Field(ge=0, le=60_000)] = 0
    priority: Annotated[int, Field(ge=0)] = 100

    @model_validator(mode="after")
    def _queued_budget_has_delay(self) -> ShieldAdmissionBudget:
        if self.queue_policy != ShieldQueuePolicy.REJECT and self.queue_max_delay_ms <= 0:
            raise ValueError("queued admission requires a positive queue_max_delay_ms")
        return self


class ShieldCapacitySnapshot(BaseModel):
    """Content-free active-call counters observed before lease acquisition."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_active_calls: Annotated[int, Field(ge=0)] = 0
    principal_active_calls: Annotated[int, Field(ge=0)] = 0
    agent_run_active_calls: Annotated[int, Field(ge=0)] = 0
    route_active_calls: Annotated[int, Field(ge=0)] = 0
    route_streaming_calls: Annotated[int, Field(ge=0)] = 0


class ShieldAdmissionDecision(BaseModel):
    """Content-free admission result safe for logs, spans, and audit metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    outcome: AdmissionOutcome
    error_code: ShieldErrorCode | None = None
    reason: AdmissionRejectionReason | None = None
    retry_after_seconds: Annotated[int, Field(ge=1, le=60)] | None = None
    queue_delay_ms: Annotated[int, Field(ge=0, le=60_000)] | None = None
    route_id: UUID
    task_class: TaskClass
    route_capability: RouteCapability
    mode: ShieldCallMode
    sensitivity_tier: SensitivityTier

    @model_validator(mode="after")
    def _outcome_fields_match(self) -> ShieldAdmissionDecision:
        if self.outcome == AdmissionOutcome.ADMITTED:
            if self.error_code is not None or self.reason is not None:
                raise ValueError("admitted decisions cannot carry rejection metadata")
            if self.retry_after_seconds is not None or self.queue_delay_ms is not None:
                raise ValueError("admitted decisions cannot carry retry or queue metadata")
        elif self.outcome == AdmissionOutcome.REJECTED:
            if self.error_code is None or self.reason is None or self.retry_after_seconds is None:
                raise ValueError("rejected decisions require error, reason, and retry metadata")
            if self.queue_delay_ms is not None:
                raise ValueError("rejected decisions cannot carry queue delay")
        elif self.outcome == AdmissionOutcome.QUEUED:
            if self.reason is None or self.queue_delay_ms is None:
                raise ValueError("queued decisions require reason and queue delay")
            if self.error_code is not None or self.retry_after_seconds is not None:
                raise ValueError("queued decisions cannot carry HTTP rejection metadata")
        return self

    @property
    def admitted(self) -> bool:
        """Whether provider dispatch may proceed now."""

        return self.outcome == AdmissionOutcome.ADMITTED


def evaluate_shield_admission(
    context: ShieldAdmissionContext,
    budget: ShieldAdmissionBudget,
    snapshot: ShieldCapacitySnapshot,
) -> ShieldAdmissionDecision:
    """Evaluate Shield admission before scanning/provider work.

    The check order is stable so callers get deterministic, low-cardinality
    reasons when multiple dimensions are saturated. Queueing is available only
    for batch latency mode and batchable task classes; interactive calls reject
    even when a route has a queue policy.
    """

    reason = _first_saturation_reason(context, budget, snapshot)
    if reason is None:
        return _decision(
            context,
            outcome=AdmissionOutcome.ADMITTED,
        )

    if _can_queue(context, budget):
        return _decision(
            context,
            outcome=AdmissionOutcome.QUEUED,
            reason=reason,
            queue_delay_ms=budget.queue_max_delay_ms,
        )

    return _decision(
        context,
        outcome=AdmissionOutcome.REJECTED,
        reason=reason,
        error_code=_REASON_ERROR_CODE[reason],
        retry_after_seconds=budget.retry_after_seconds,
    )


def _first_saturation_reason(
    context: ShieldAdmissionContext,
    budget: ShieldAdmissionBudget,
    snapshot: ShieldCapacitySnapshot,
) -> AdmissionRejectionReason | None:
    if snapshot.tenant_active_calls >= budget.max_tenant_concurrent_calls:
        return AdmissionRejectionReason.TENANT_CONCURRENCY_EXCEEDED
    if snapshot.principal_active_calls >= budget.max_principal_concurrent_calls:
        return AdmissionRejectionReason.PRINCIPAL_CONCURRENCY_EXCEEDED
    if (
        context.agent_run_id is not None
        and snapshot.agent_run_active_calls >= budget.max_agent_run_concurrent_calls
    ):
        return AdmissionRejectionReason.AGENT_RUN_CONCURRENCY_EXCEEDED
    if snapshot.route_active_calls >= budget.max_route_concurrent_calls:
        return AdmissionRejectionReason.ROUTE_BUDGET_EXHAUSTED
    if (
        context.mode == ShieldCallMode.STREAMING_SSE
        and snapshot.route_streaming_calls >= budget.max_route_streaming_calls
    ):
        return AdmissionRejectionReason.STREAMING_CAPACITY_EXCEEDED
    return None


def _can_queue(context: ShieldAdmissionContext, budget: ShieldAdmissionBudget) -> bool:
    return (
        context.mode == ShieldCallMode.REQUEST_RESPONSE
        and context.latency_mode == LatencyMode.BATCH
        and context.task_class in _BATCHABLE_TASK_CLASSES
        and budget.queue_policy in {ShieldQueuePolicy.QUEUE, ShieldQueuePolicy.BATCH}
    )


def _decision(
    context: ShieldAdmissionContext,
    *,
    outcome: AdmissionOutcome,
    reason: AdmissionRejectionReason | None = None,
    error_code: ShieldErrorCode | None = None,
    retry_after_seconds: int | None = None,
    queue_delay_ms: int | None = None,
) -> ShieldAdmissionDecision:
    return ShieldAdmissionDecision(
        outcome=outcome,
        error_code=error_code,
        reason=reason,
        retry_after_seconds=retry_after_seconds,
        queue_delay_ms=queue_delay_ms,
        route_id=context.route_id,
        task_class=context.task_class,
        route_capability=context.route_capability,
        mode=context.mode,
        sensitivity_tier=context.sensitivity_tier,
    )
