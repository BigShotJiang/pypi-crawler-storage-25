"""Shield app wiring helpers for configured provider dispatch."""

from __future__ import annotations

from dataclasses import dataclass

from skaldos_shield.call_core import ShieldCallAuditWriter, ShieldCallCore
from skaldos_shield.capacity import ShieldCapacityLeaser
from skaldos_shield.contracts import RouteCapability
from skaldos_shield.credentials import RouteCredentialResolver
from skaldos_shield.detectors import DetectorRegistry
from skaldos_shield.provider_adapters import (
    ProviderAdapterRequest,
    ProviderAdapterResponse,
    ShieldProviderAdapter,
    ShieldProviderCallError,
)
from skaldos_shield.routes_store import BifrostProviderRoute
from skaldos_shield.settings import (
    AuditSinkPosture,
    DetectorRegistrySource,
    ProviderRouteSource,
    ShieldSettings,
)
from skaldos_shield.voyage_adapter import (
    HttpxVoyageEmbeddingTransport,
    VoyageEmbeddingProviderAdapter,
)

ProviderAdapterKey = tuple[str, RouteCapability]


class ShieldConfiguredModeError(Exception):
    """Raised when configured mode is requested without required dependencies."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class DispatchingProviderAdapter(ShieldProviderAdapter):
    """Route provider-safe requests to provider/capability-specific adapters."""

    def __init__(self, adapters: dict[ProviderAdapterKey, ShieldProviderAdapter]) -> None:
        self._adapters = dict(adapters)

    async def complete(self, request: ProviderAdapterRequest) -> ProviderAdapterResponse:
        if request.route.capability is None:
            raise ShieldProviderCallError("provider route capability is unavailable")
        key = (request.route.provider, request.route.capability)
        adapter = self._adapters.get(key)
        if adapter is None:
            raise ShieldProviderCallError("provider adapter is unavailable for route")
        return await adapter.complete(request)

    def supports(self, provider: str, capability: RouteCapability) -> bool:
        """Return whether a provider/capability route has a registered adapter."""

        return (provider, capability) in self._adapters


@dataclass(frozen=True)
class ConfiguredShieldRuntime:
    """Configured-mode dependencies loaded before constructing the Shield app."""

    provider_routes: tuple[BifrostProviderRoute, ...]
    detector_registry: DetectorRegistry
    audit_writer: ShieldCallAuditWriter
    route_credential_resolver: RouteCredentialResolver
    capacity_leaser: ShieldCapacityLeaser | None = None
    provider_adapter: ShieldProviderAdapter | None = None


def build_default_dispatching_provider_adapter() -> DispatchingProviderAdapter:
    """Build the configured-mode provider adapter registry."""

    voyage = VoyageEmbeddingProviderAdapter(transport=HttpxVoyageEmbeddingTransport())
    return DispatchingProviderAdapter(
        {
            ("voyage", RouteCapability.EMBEDDING): voyage,
            ("voyage", RouteCapability.SEARCH_QUERY_EMBEDDING): voyage,
        }
    )


def build_configured_shield_call_core(
    *,
    settings: ShieldSettings,
    runtime: ConfiguredShieldRuntime,
) -> ShieldCallCore:
    """Build configured-mode call core or fail closed with a safe reason code."""

    _validate_configured_mode_settings(settings)
    provider_adapter = runtime.provider_adapter or build_default_dispatching_provider_adapter()
    _validate_configured_runtime(runtime, provider_adapter=provider_adapter)
    try:
        return ShieldCallCore(
            routes=runtime.provider_routes,
            detector_registry=runtime.detector_registry,
            redaction_pipeline=None,
            session_store=None,
            capacity_leaser=runtime.capacity_leaser or ShieldCapacityLeaser(),
            audit_writer=runtime.audit_writer,
            provider_adapter=provider_adapter,
            route_credential_resolver=runtime.route_credential_resolver,
            require_route_credentials=True,
            production_detector_rule_source_version=(
                settings.detector_rule_source_version
                if settings.detector_registry_source == DetectorRegistrySource.CONFIGURED
                else None
            ),
        )
    except ValueError as error:
        raise ShieldConfiguredModeError("shield_detector_registry_not_configured") from error


def _validate_configured_mode_settings(settings: ShieldSettings) -> None:
    if settings.provider_route_source != ProviderRouteSource.CONFIGURED:
        raise ShieldConfiguredModeError("shield_provider_routes_not_configured")
    if settings.detector_registry_source != DetectorRegistrySource.CONFIGURED:
        raise ShieldConfiguredModeError("shield_detector_registry_not_configured")
    if not settings.detector_rule_source_version or settings.detector_registry_count < 1:
        raise ShieldConfiguredModeError("shield_detector_registry_not_configured")
    if settings.audit_sink_posture != AuditSinkPosture.CONFIGURED:
        raise ShieldConfiguredModeError("shield_audit_not_configured")
    if not settings.route_credential_resolver_enabled:
        raise ShieldConfiguredModeError("shield_route_credential_resolver_not_configured")
    if not settings.kms_key_reference:
        raise ShieldConfiguredModeError("shield_kms_not_configured")


def _validate_configured_runtime(
    runtime: ConfiguredShieldRuntime,
    *,
    provider_adapter: ShieldProviderAdapter,
) -> None:
    if not runtime.provider_routes:
        raise ShieldConfiguredModeError("shield_provider_routes_not_configured")
    if runtime.detector_registry.rule_source_version.startswith("fixture"):
        raise ShieldConfiguredModeError("shield_detector_registry_not_configured")
    if isinstance(provider_adapter, DispatchingProviderAdapter):
        for route in runtime.provider_routes:
            for capability in route.capabilities:
                if not provider_adapter.supports(route.provider, capability):
                    raise ShieldConfiguredModeError("shield_provider_adapter_not_configured")


def configured_mode_error_code(settings: ShieldSettings) -> str | None:
    """Return a safe fail-closed reason when configured mode lacks settings."""

    try:
        _validate_configured_mode_settings(settings)
    except ShieldConfiguredModeError as error:
        return error.code
    return None
