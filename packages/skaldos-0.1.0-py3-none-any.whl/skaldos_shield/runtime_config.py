# pyright: reportMissingTypeStubs=false, reportUnknownMemberType=false, reportUnknownVariableType=false, reportUnknownArgumentType=false, reportArgumentType=false
"""Configured-mode Shield runtime loading from live service dependencies."""

from __future__ import annotations

import json
import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any
from uuid import UUID

import asyncpg

from skaldos.kms.gcp import GCPKMSClient
from skaldos.kms.protocol import KMSClient
from skaldos_shield.app_wiring import ConfiguredShieldRuntime
from skaldos_shield.audit_records import (
    ShieldAuditRecords,
    ShieldCallCompletion,
    ShieldCallRecord,
    ShieldCallStart,
)
from skaldos_shield.call_core import ShieldCallAuditWriter
from skaldos_shield.credentials import (
    RouteCredentialKMSDecryptor,
    RouteCredentialResolver,
    StoredRouteCredentialResolver,
)
from skaldos_shield.detectors import (
    DetectorMatch,
    DetectorRegistry,
    ShieldDetector,
)
from skaldos_shield.redaction import CREDENTIAL_CATEGORY, PII_CATEGORY
from skaldos_shield.routes_store import ProviderRoutes
from skaldos_shield.settings import ShieldSettings

_EMAIL_RE = re.compile(
    r"(?<![A-Za-z0-9._%+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![A-Za-z0-9._%+-])"
)
_SECRET_TOKEN_RE = re.compile(r"\bskaldos-secret-token\b")


@dataclass(frozen=True, slots=True)
class ConfiguredRuntimeHandle:
    """Configured runtime plus owned async resources."""

    runtime: ConfiguredShieldRuntime
    pool: asyncpg.Pool

    async def close(self) -> None:
        await self.pool.close()


async def build_configured_runtime_from_settings(
    settings: ShieldSettings,
    *,
    kms_client: KMSClient | None = None,
) -> ConfiguredRuntimeHandle:
    """Load DB-backed routes and build Shield configured runtime dependencies."""

    if not settings.database_url:
        raise RuntimeError("shield_database_url_not_configured")
    tenant_ids = _parse_configured_tenant_ids(settings.configured_tenant_ids)
    if not tenant_ids:
        raise RuntimeError("shield_configured_tenant_ids_not_configured")

    pool = await asyncpg.create_pool(
        dsn=_asyncpg_dsn(settings.database_url),
        min_size=1,
        max_size=5,
    )
    try:
        routes = []
        async with pool.acquire() as conn:
            for tenant_id in tenant_ids:
                async with conn.transaction():
                    await _set_principal_context(
                        conn,
                        tenant_id=tenant_id,
                        principal_id=tenant_id,
                    )
                    routes.extend(
                        await ProviderRoutes().list_active_provider_routes(
                            conn,
                            tenant_id=tenant_id,
                        )
                    )
        runtime = ConfiguredShieldRuntime(
            provider_routes=tuple(routes),
            detector_registry=_detector_registry(settings),
            audit_writer=PooledShieldAuditWriter(pool),
            route_credential_resolver=PooledRouteCredentialResolver(
                pool=pool,
                decryptor=RouteCredentialKMSDecryptor(
                    kms_client or _kms_client(settings),
                    expected_kms_key_reference=settings.kms_key_reference,
                ),
            ),
        )
    except Exception:
        await pool.close()
        raise
    return ConfiguredRuntimeHandle(runtime=runtime, pool=pool)


class PooledShieldAuditWriter(ShieldCallAuditWriter):
    """DB-backed Shield audit writer using one transaction per audit mutation."""

    def __init__(self, pool: asyncpg.Pool, records: ShieldAuditRecords | None = None) -> None:
        self._pool = pool
        self._records = records or ShieldAuditRecords()

    async def insert_call_attempt(self, attempt: ShieldCallStart) -> ShieldCallRecord:
        async with self._pool.acquire() as conn, conn.transaction():
            await _set_principal_context(
                conn,
                tenant_id=attempt.tenant_id,
                principal_id=attempt.actor_principal_id,
            )
            return await self._records.insert_call_attempt(conn, attempt)

    async def complete_call(
        self,
        *,
        tenant_id: UUID,
        call_record_id: UUID,
        completion: ShieldCallCompletion,
    ) -> ShieldCallRecord:
        async with self._pool.acquire() as conn, conn.transaction():
            await _set_principal_context(
                conn,
                tenant_id=tenant_id,
                principal_id=tenant_id,
            )
            actor_principal_id = await conn.fetchval(
                """
                SELECT actor_principal_id
                  FROM shield_call_records
                 WHERE tenant_id = $1
                   AND id = $2
                """,
                tenant_id,
                call_record_id,
            )
            if actor_principal_id is None:
                raise PermissionError("Shield call record is not visible for tenant")
            await _set_principal_context(
                conn,
                tenant_id=tenant_id,
                principal_id=actor_principal_id,
            )
            return await self._records.complete_call(
                conn,
                tenant_id=tenant_id,
                call_record_id=call_record_id,
                completion=completion,
            )


class PooledRouteCredentialResolver(RouteCredentialResolver):
    """DB-backed route credential resolver using per-call RLS context."""

    def __init__(
        self,
        *,
        pool: asyncpg.Pool,
        decryptor: RouteCredentialKMSDecryptor,
    ) -> None:
        self._pool = pool
        self._decryptor = decryptor

    async def resolve(self, route: Any, *, principal_id: UUID) -> Any:  # noqa: ANN401
        async with self._pool.acquire() as conn, conn.transaction():
            await _set_principal_context(
                conn,
                tenant_id=route.tenant_id,
                principal_id=principal_id,
            )
            return await StoredRouteCredentialResolver(
                conn=conn,
                decryptor=self._decryptor,
            ).resolve(route, principal_id=principal_id)


class ConfiguredPatternDetector:
    """Small built-in detector for staging/local configured Shield."""

    detector_id = "configured-pattern"
    version = "registry-v1"

    def detect(self, text: str) -> Sequence[DetectorMatch]:
        matches: list[DetectorMatch] = []
        for pattern, entity_type, category in (
            (_EMAIL_RE, "EMAIL", PII_CATEGORY),
            (_SECRET_TOKEN_RE, "API_KEY", CREDENTIAL_CATEGORY),
        ):
            for match in pattern.finditer(text):
                matches.append(
                    DetectorMatch(
                        start=match.start(),
                        end=match.end(),
                        entity_type=entity_type,
                        category=category,
                    )
                )
        return tuple(matches)


def _detector_registry(settings: ShieldSettings) -> DetectorRegistry:
    detectors: tuple[ShieldDetector, ...] = (ConfiguredPatternDetector(),)
    return DetectorRegistry(
        detectors=detectors,
        registry_version="shield-detectors-v1",
        rule_source_version=settings.detector_rule_source_version or "configured-pattern-rules-v1",
    )


async def _set_principal_context(
    conn: asyncpg.Connection,
    *,
    tenant_id: UUID,
    principal_id: UUID,
) -> None:
    await conn.execute(
        "SELECT set_config($1, $2, true)",
        "app.current_principal_id",
        str(principal_id),
    )
    await conn.execute(
        "SELECT set_config($1, $2, true)",
        "app.current_principal_visible",
        "{" + str(tenant_id) + "}",
    )
    await conn.execute(
        "SELECT set_config($1, $2, true)",
        "app.current_principal_context",
        json.dumps(
            {
                "tenants": [str(tenant_id)],
                "classification": "C1",
                "clearances": ["C1"],
                "verticals": ["foundation"],
                "ontology_versions": [],
            },
            sort_keys=True,
        ),
    )


def _parse_configured_tenant_ids(value: str | None) -> tuple[UUID, ...]:
    if value is None:
        return ()
    return tuple(UUID(item.strip()) for item in value.split(",") if item.strip())


def _asyncpg_dsn(value: str) -> str:
    return value.replace("postgresql+asyncpg://", "postgresql://", 1).replace(
        "postgresql+psycopg://",
        "postgresql://",
        1,
    )


def _kms_client(settings: ShieldSettings) -> KMSClient:
    if settings.kms_backend == "gcp":
        return GCPKMSClient()
    raise RuntimeError("shield_kms_backend_not_configured")
