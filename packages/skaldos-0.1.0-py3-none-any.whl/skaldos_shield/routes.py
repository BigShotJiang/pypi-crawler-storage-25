"""HTTP routes for the standalone Shield service scaffold."""

from __future__ import annotations

from typing import Any, Literal, cast

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict

from skaldos_shield.backpressure import ShieldBackpressureError
from skaldos_shield.call_core import (
    ShieldAuditUnavailableError,
    ShieldCallCore,
    ShieldPolicyBlockedError,
    ShieldRequestValidationError,
)
from skaldos_shield.contracts import CanonicalShieldRequest, CanonicalShieldResponse
from skaldos_shield.provider_adapters import ProviderAdapterRequest, ShieldProviderCallError
from skaldos_shield.settings import (
    AuditSinkPosture,
    DetectorRegistrySource,
    ProviderRouteSource,
    ShieldEnvironment,
    ShieldSettings,
)

router = APIRouter()


class HealthResponse(BaseModel):
    """Safe liveness response."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    service: Literal["shield"] = "shield"
    status: Literal["ok"] = "ok"


class ReadinessDependency(BaseModel):
    """Coarse dependency state with no secret, PII, or provider material."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str
    status: Literal["ok", "not_ready", "scaffold"]
    required: bool
    code: str


class ReadinessResponse(BaseModel):
    """Safe readiness response."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    service: Literal["shield"] = "shield"
    status: Literal["ready", "not_ready"]
    dependencies: tuple[ReadinessDependency, ...]


class ShieldErrorResponse(BaseModel):
    """Safe Shield error envelope."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    detail: str
    error_code: str
    trace_id: str | None = None
    shield_call_id: str | None = None
    retryable: bool = False


class FixtureProviderEvidenceResponse(BaseModel):
    """Staging-only fake-provider evidence with no prompt/query text."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    service: Literal["shield"] = "shield"
    provider_capture_count: int
    placeholder_counts: dict[str, int]
    forbidden_fragment_seen: bool
    route_ids: tuple[str, ...]


def _settings_from_request(request: Request) -> ShieldSettings:
    settings = getattr(request.app.state, "shield_settings", None)
    if isinstance(settings, ShieldSettings):
        return settings
    return ShieldSettings()


def _call_core_from_request(request: Request) -> Any | None:
    core = getattr(request.app.state, "shield_call_core", None)
    if isinstance(core, ShieldCallCore) or callable(getattr(core, "complete", None)):
        return core
    return None


def _dependency(
    *,
    name: str,
    ready: bool,
    required: bool,
    code: str,
    scaffold: bool = False,
) -> ReadinessDependency:
    if scaffold:
        dependency_status: Literal["ok", "not_ready", "scaffold"] = "scaffold"
    else:
        dependency_status = "ok" if ready else "not_ready"
    return ReadinessDependency(
        name=name,
        status=dependency_status,
        required=required,
        code=code,
    )


def build_readiness(
    settings: ShieldSettings,
    *,
    configured_call_core_ready: bool | None = None,
    configured_mode_error_code: str | None = None,
) -> ReadinessResponse:
    """Build readiness without live provider prompts or secret disclosure."""

    auth_ready = bool(settings.auth_issuer and settings.auth_audience)
    kms_ready = bool(settings.kms_key_reference)
    detector_ready = (
        settings.detector_registry_source == DetectorRegistrySource.CONFIGURED
        and bool(settings.detector_rule_source_version)
        and settings.detector_registry_count > 0
    )
    fixture_allowed = settings.environment in {
        ShieldEnvironment.DEVELOPMENT,
        ShieldEnvironment.TEST,
    } or (settings.environment == ShieldEnvironment.STAGING and settings.staging_smoke_enabled)
    fixture_detector_ready = (
        fixture_allowed
        and settings.fixture_detector_enabled
        and settings.detector_registry_source == DetectorRegistrySource.FIXTURE
        and bool(settings.detector_rule_source_version)
        and settings.detector_registry_count > 0
    )
    provider_ready = settings.provider_route_source == ProviderRouteSource.CONFIGURED
    if configured_call_core_ready is not None:
        provider_ready = provider_ready and configured_call_core_ready
    credential_resolver_ready = (
        settings.provider_route_source != ProviderRouteSource.CONFIGURED
        or settings.route_credential_resolver_enabled
    )
    fixture_provider_ready = (
        fixture_allowed
        and settings.fixture_provider_enabled
        and settings.provider_route_source == ProviderRouteSource.FIXTURE
    )
    audit_ready = settings.audit_sink_posture == AuditSinkPosture.CONFIGURED
    audit_scaffold = (
        fixture_allowed and settings.audit_sink_posture == AuditSinkPosture.DISABLED_FOR_SCAFFOLD
    )

    dependencies = (
        _dependency(
            name="auth_config",
            ready=auth_ready,
            required=True,
            code="shield_auth_configured" if auth_ready else "shield_auth_not_configured",
        ),
        _dependency(
            name="kms_binding",
            ready=kms_ready,
            required=True,
            code="shield_kms_configured" if kms_ready else "shield_kms_not_configured",
        ),
        _dependency(
            name="detector_registry",
            ready=detector_ready or fixture_detector_ready,
            required=True,
            code=(
                "shield_detector_registry_configured"
                if detector_ready
                else "shield_fixture_detector_configured"
                if fixture_detector_ready
                else "shield_detector_registry_not_configured"
            ),
            scaffold=fixture_detector_ready,
        ),
        _dependency(
            name="provider_route_source",
            ready=provider_ready or fixture_provider_ready,
            required=True,
            code=(
                "shield_provider_routes_configured"
                if provider_ready
                else configured_mode_error_code
                if configured_mode_error_code is not None
                else "shield_fixture_provider_configured"
                if fixture_provider_ready
                else "shield_provider_routes_not_configured"
            ),
            scaffold=fixture_provider_ready,
        ),
        _dependency(
            name="route_credential_resolver",
            ready=credential_resolver_ready,
            required=settings.provider_route_source == ProviderRouteSource.CONFIGURED,
            code=(
                "shield_route_credential_resolver_configured"
                if credential_resolver_ready
                else "shield_route_credential_resolver_not_configured"
            ),
        ),
        _dependency(
            name="audit_sink",
            ready=audit_ready or audit_scaffold,
            required=True,
            code=(
                "shield_audit_configured"
                if audit_ready
                else "shield_audit_disabled_for_scaffold"
                if audit_scaffold
                else "shield_audit_not_configured"
            ),
            scaffold=audit_scaffold,
        ),
        _dependency(
            name="provider_prompt",
            ready=False,
            required=False,
            code="shield_provider_prompt_not_performed",
            scaffold=True,
        ),
    )

    ready = all(
        dependency.status in {"ok", "scaffold"}
        for dependency in dependencies
        if dependency.required
    )
    return ReadinessResponse(
        status="ready" if ready else "not_ready",
        dependencies=dependencies,
    )


@router.get("/healthz", response_model=HealthResponse)
async def healthz() -> HealthResponse:
    """Process liveness only; performs no dependency checks."""

    return HealthResponse()


@router.get("/readyz", response_model=ReadinessResponse)
async def readyz(request: Request) -> JSONResponse:
    """Coarse readiness; never prompts a provider."""

    settings = _settings_from_request(request)
    configured_call_core_ready: bool | None = None
    configured_mode_error_code = getattr(request.app.state, "shield_configured_mode_error", None)
    if settings.provider_route_source == ProviderRouteSource.CONFIGURED:
        configured_call_core_ready = _call_core_from_request(request) is not None
    payload = build_readiness(
        settings,
        configured_call_core_ready=configured_call_core_ready,
        configured_mode_error_code=(
            configured_mode_error_code if isinstance(configured_mode_error_code, str) else None
        ),
    )
    http_status = (
        status.HTTP_200_OK if payload.status == "ready" else status.HTTP_503_SERVICE_UNAVAILABLE
    )
    return JSONResponse(status_code=http_status, content=payload.model_dump(mode="json"))


@router.post(
    "/v1/complete",
    response_model=CanonicalShieldResponse,
    responses={
        400: {"model": ShieldErrorResponse},
        429: {"model": ShieldErrorResponse},
        503: {"model": ShieldErrorResponse},
    },
)
async def canonical_complete(
    request: Request,
    body: CanonicalShieldRequest,
) -> JSONResponse:
    """Canonical deployable Shield completion route."""

    core = _call_core_from_request(request)
    if core is None:
        return _safe_error(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            code="shield_call_core_not_configured",
            trace_id=body.trace_id,
            retryable=True,
        )
    try:
        result = await core.complete(body)
    except ShieldRequestValidationError as exc:
        safe = exc.safe_error
        return _safe_error(
            status_code=safe.http_status,
            code=safe.code.value,
            trace_id=safe.trace_id,
            shield_call_id=str(safe.shield_call_id) if safe.shield_call_id else None,
            retryable=safe.retryable,
        )
    except ShieldPolicyBlockedError as exc:
        response = exc.response
        code = response.warnings[0].value if response.warnings else "shield_policy_blocked"
        return _safe_error(
            status_code=status.HTTP_400_BAD_REQUEST,
            code=code,
            trace_id=response.trace_id,
            shield_call_id=str(exc.call_record_id),
            retryable=False,
        )
    except ShieldBackpressureError as exc:
        response = exc.response
        code = response.error_code.value if response.error_code else response.kind.value
        return _safe_error(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            code=code,
            retryable=True,
        )
    except ShieldAuditUnavailableError:
        return _safe_error(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            code="audit_unavailable",
            trace_id=body.trace_id,
            retryable=True,
        )
    except ShieldProviderCallError:
        return _safe_error(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            code="shield_provider_call_failed",
            trace_id=body.trace_id,
            retryable=True,
        )
    return JSONResponse(
        status_code=status.HTTP_200_OK,
        content=result.response.model_dump(mode="json"),
    )


@router.get("/_staging/fixture-provider-evidence", response_model=FixtureProviderEvidenceResponse)
async def fixture_provider_evidence(request: Request) -> FixtureProviderEvidenceResponse:
    """Return staging fake-provider capture metadata without provider-bound text."""

    settings = _settings_from_request(request)
    if (
        settings.environment == ShieldEnvironment.PRODUCTION
        or not settings.fixture_provider_enabled
        or not settings.staging_smoke_enabled
    ):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="not_found")
    provider = getattr(request.app.state, "shield_fixture_provider_adapter", None)
    captured = getattr(provider, "captured_requests", None)
    if not isinstance(captured, list):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="not_found")
    captured_requests = cast(list[ProviderAdapterRequest], captured)

    placeholders = ("[EMAIL]", "[PHONE_NUMBER]", "[PERSON]", "[SECRET:API_KEY]")
    forbidden_fragments = (settings.fixture_detector_marker, "fixture-api-key-token")
    placeholder_counts = {placeholder: 0 for placeholder in placeholders}
    forbidden_seen = False
    route_ids: set[str] = set()
    for capture in captured_requests:
        route = getattr(capture, "route", None)
        route_id = getattr(route, "route_id", None)
        if route_id is not None:
            route_ids.add(str(route_id))
        for part in getattr(capture, "provider_safe_parts", ()):
            text = getattr(getattr(part, "part", None), "text", None)
            if not isinstance(text, str):
                continue
            for placeholder in placeholders:
                placeholder_counts[placeholder] += text.count(placeholder)
            if any(fragment and fragment in text for fragment in forbidden_fragments):
                forbidden_seen = True

    return FixtureProviderEvidenceResponse(
        provider_capture_count=len(captured_requests),
        placeholder_counts={key: value for key, value in placeholder_counts.items() if value},
        forbidden_fragment_seen=forbidden_seen,
        route_ids=tuple(sorted(route_ids)),
    )


def _safe_error(
    *,
    status_code: int,
    code: str,
    trace_id: str | None = None,
    shield_call_id: str | None = None,
    retryable: bool = False,
) -> JSONResponse:
    payload = ShieldErrorResponse(
        detail=code,
        error_code=code,
        trace_id=trace_id,
        shield_call_id=shield_call_id,
        retryable=retryable,
    )
    return JSONResponse(status_code=status_code, content=payload.model_dump(mode="json"))
