"""Shield message-part policy contract.

Slice 5 routes every provider-visible part through an explicit decision before
scan/substitution and before provider dispatch. This module is pure policy: it
does not normalize provider DTOs, scan content, call providers, or write audit
records.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict

from skaldos_shield.contracts import MessagePart, MessagePartType, ShieldErrorCode


class MessagePartSurface(StrEnum):
    """Request surface that produced a canonical message part."""

    CANONICAL = "canonical"
    NATIVE_ANTHROPIC_MESSAGES = "native_anthropic_messages"


class MessagePartPolicyAction(StrEnum):
    """Value-free action vocabulary for one message part."""

    SCAN_AND_SUBSTITUTE = "scan_and_substitute"
    SCAN_OR_BLOCK = "scan_or_block"
    STRUCTURED_SCAN_AND_SUBSTITUTE = "structured_scan_and_substitute"
    UNSUPPORTED = "unsupported"
    UNSCANNABLE = "unscannable"
    COMPATIBILITY_EXCEPTION = "compatibility_exception"


class MessagePartPolicyDecision(BaseModel):
    """Explicit policy decision for one provider message part."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    part_type: MessagePartType
    surface: MessagePartSurface
    action: MessagePartPolicyAction
    scannable: bool
    substitutes_provider_visible_content: bool
    blocks_provider_dispatch: bool
    error_code: ShieldErrorCode | None = None
    audit_reason: str | None = None


_TEXT_SCAN_TYPES = frozenset(
    {
        MessagePartType.USER_TEXT,
        MessagePartType.TOOL_RESULT,
    }
)

_INSTRUCTION_TYPES = frozenset(
    {
        MessagePartType.SYSTEM,
        MessagePartType.DEVELOPER,
    }
)

_UNSUPPORTED_TYPES = frozenset(
    {
        MessagePartType.IMAGE,
        MessagePartType.BINARY,
    }
)


def decide_message_part_policy(
    part: MessagePart,
    *,
    surface: MessagePartSurface = MessagePartSurface.CANONICAL,
    allow_native_compatibility_exception: bool = False,
) -> MessagePartPolicyDecision:
    """Return the explicit Slice 5 policy decision for one message part.

    Native compatibility exceptions are unavailable by default and never apply
    to the canonical Shield surface. A caller that enables them must still
    audit the exception and keep provider-visible content safe in later layers.
    """

    if (
        surface == MessagePartSurface.NATIVE_ANTHROPIC_MESSAGES
        and allow_native_compatibility_exception
        and part.type in _INSTRUCTION_TYPES
    ):
        return MessagePartPolicyDecision(
            part_type=part.type,
            surface=surface,
            action=MessagePartPolicyAction.COMPATIBILITY_EXCEPTION,
            scannable=True,
            substitutes_provider_visible_content=True,
            blocks_provider_dispatch=False,
            audit_reason="compatibility_exception",
        )

    if part.type in _INSTRUCTION_TYPES:
        return MessagePartPolicyDecision(
            part_type=part.type,
            surface=surface,
            action=MessagePartPolicyAction.SCAN_OR_BLOCK,
            scannable=True,
            substitutes_provider_visible_content=True,
            blocks_provider_dispatch=False,
        )

    if part.type in _TEXT_SCAN_TYPES:
        return MessagePartPolicyDecision(
            part_type=part.type,
            surface=surface,
            action=MessagePartPolicyAction.SCAN_AND_SUBSTITUTE,
            scannable=True,
            substitutes_provider_visible_content=True,
            blocks_provider_dispatch=False,
        )

    if part.type == MessagePartType.TOOL_CALL_ARGUMENTS:
        return MessagePartPolicyDecision(
            part_type=part.type,
            surface=surface,
            action=MessagePartPolicyAction.STRUCTURED_SCAN_AND_SUBSTITUTE,
            scannable=True,
            substitutes_provider_visible_content=True,
            blocks_provider_dispatch=False,
        )

    if part.type in _UNSUPPORTED_TYPES:
        return MessagePartPolicyDecision(
            part_type=part.type,
            surface=surface,
            action=MessagePartPolicyAction.UNSUPPORTED,
            scannable=False,
            substitutes_provider_visible_content=False,
            blocks_provider_dispatch=True,
            error_code=ShieldErrorCode.UNSUPPORTED_PART,
            audit_reason="unsupported_part",
        )

    return MessagePartPolicyDecision(
        part_type=part.type,
        surface=surface,
        action=MessagePartPolicyAction.UNSCANNABLE,
        scannable=False,
        substitutes_provider_visible_content=False,
        blocks_provider_dispatch=True,
        error_code=ShieldErrorCode.UNSCANNABLE,
        audit_reason="unscannable",
    )


def message_part_policy_table(
    *,
    surface: MessagePartSurface = MessagePartSurface.CANONICAL,
    allow_native_compatibility_exception: bool = False,
) -> dict[MessagePartType, MessagePartPolicyDecision]:
    """Return one explicit policy decision per known part type."""

    sample_parts = {
        MessagePartType.SYSTEM: MessagePart(type=MessagePartType.SYSTEM, text="system"),
        MessagePartType.DEVELOPER: MessagePart(
            type=MessagePartType.DEVELOPER,
            text="developer",
        ),
        MessagePartType.USER_TEXT: MessagePart(
            type=MessagePartType.USER_TEXT,
            text="user text",
        ),
        MessagePartType.TOOL_RESULT: MessagePart(
            type=MessagePartType.TOOL_RESULT,
            text="tool result",
        ),
        MessagePartType.TOOL_CALL_ARGUMENTS: MessagePart(
            type=MessagePartType.TOOL_CALL_ARGUMENTS,
            json_value={"argument": "value"},
        ),
        MessagePartType.IMAGE: MessagePart(type=MessagePartType.IMAGE),
        MessagePartType.BINARY: MessagePart(type=MessagePartType.BINARY),
        MessagePartType.UNKNOWN: MessagePart(type=MessagePartType.UNKNOWN),
    }
    return {
        part_type: decide_message_part_policy(
            part,
            surface=surface,
            allow_native_compatibility_exception=allow_native_compatibility_exception,
        )
        for part_type, part in sample_parts.items()
    }
