"""Shield-owned provider route credential resolution contracts."""

from __future__ import annotations

import json
from collections.abc import Mapping
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol
from uuid import UUID

import aiosql
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel, ConfigDict, Field, SecretStr

from skaldos.kms.protocol import KeyDestroyed, KMSClient
from skaldos_shield.contracts import ShieldErrorCode

if TYPE_CHECKING:
    import asyncpg

    from skaldos_shield.routes_store import BifrostProviderRoute

__all__ = [
    "ResolvedRouteCredential",
    "RouteCredentialKMSDecryptor",
    "RouteCredentialEnvelope",
    "RouteCredentialResolutionError",
    "RouteCredentialResolver",
    "RouteCredentialStore",
    "StaticRouteCredentialResolver",
    "StoredRouteCredentialResolver",
    "UnconfiguredRouteCredentialResolver",
    "route_credential_store",
]

_QUERIES_SQL_PATH: Path = Path(__file__).parent / "queries" / "route_credentials.sql"

_AESGCM_PREFIX = b"skaldos-route-credential-aesgcm-v1:"
_AESGCM_NONCE_BYTES = 12


class RouteCredentialScope(StrEnum):
    """Route credential authority scope."""

    ORG = "org"
    USER = "user"


class RouteCredentialStatus(StrEnum):
    """Persisted route credential lifecycle state."""

    ACTIVE = "active"
    REVOKED = "revoked"
    DESTROYED = "destroyed"


class RouteCredentialResolutionError(Exception):
    """Raised when Shield cannot safely resolve a route credential."""

    def __init__(
        self,
        code: ShieldErrorCode = ShieldErrorCode.CREDENTIAL_UNAVAILABLE,
    ) -> None:
        super().__init__(code.value)
        self.code = code


class RouteCredentialEnvelope(BaseModel):
    """Encrypted credential envelope loaded from Bifrost storage."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    provider: str
    provider_secret_ref: str
    scope: RouteCredentialScope
    owner_principal_id: UUID | None = None
    encrypted_secret_ciphertext: bytes = Field(min_length=1, repr=False)
    wrapped_dek: bytes = Field(min_length=1, repr=False)
    kms_key_reference: str = Field(min_length=1)
    key_version: str = Field(min_length=1)
    status: RouteCredentialStatus

    def aad(self) -> bytes:
        """Return the stable AAD bytes bound to this credential envelope."""

        payload = {
            "credential_id": str(self.id),
            "key_version": self.key_version,
            "owner_principal_id": (
                None if self.owner_principal_id is None else str(self.owner_principal_id)
            ),
            "provider": self.provider,
            "provider_secret_ref": self.provider_secret_ref,
            "scope": self.scope.value,
            "tenant_id": str(self.tenant_id),
        }
        return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")


class ResolvedRouteCredential(BaseModel):
    """Plaintext provider credential held only inside Shield dispatch."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    credential_id: UUID
    tenant_id: UUID
    provider: str
    provider_secret_ref: str
    key_version: str
    secret_value: SecretStr = Field(repr=False)

    def plaintext(self) -> str:
        """Return the provider key for the bounded adapter call path."""

        return self.secret_value.get_secret_value()


class RouteCredentialDecryptor(Protocol):
    """Boundary for KMS-backed envelope decryption."""

    def decrypt(self, envelope: RouteCredentialEnvelope) -> SecretStr:
        """Decrypt one stored envelope into a provider key."""
        ...


class RouteCredentialKMSDecryptor:
    """Decrypt route credential envelopes through the accepted KMS/AAD boundary."""

    def __init__(
        self,
        kms_client: KMSClient,
        *,
        expected_kms_key_reference: str | None = None,
    ) -> None:
        self._kms_client = kms_client
        self._expected_kms_key_reference = expected_kms_key_reference

    def decrypt(self, envelope: RouteCredentialEnvelope) -> SecretStr:
        """Decrypt one AES-GCM route credential envelope after KMS unwrap."""

        if envelope.status is RouteCredentialStatus.DESTROYED:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_DESTROYED)
        if envelope.status is not RouteCredentialStatus.ACTIVE:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_UNAVAILABLE)
        if (
            self._expected_kms_key_reference is not None
            and envelope.kms_key_reference != self._expected_kms_key_reference
        ):
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_CONFIGURATION_ERROR)

        try:
            plaintext_dek = self._kms_client.decrypt_dek(
                envelope.kms_key_reference,
                envelope.wrapped_dek,
            )
        except KeyDestroyed as error:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_DESTROYED) from error
        except ValueError as error:
            raise RouteCredentialResolutionError(
                ShieldErrorCode.CREDENTIAL_CONFIGURATION_ERROR
            ) from error
        except NotImplementedError as error:
            raise RouteCredentialResolutionError(
                ShieldErrorCode.CREDENTIAL_CONFIGURATION_ERROR
            ) from error
        except Exception as error:
            raise RouteCredentialResolutionError(ShieldErrorCode.KMS_UNAVAILABLE) from error

        try:
            credential_bytes = _aesgcm_decrypt(
                envelope.encrypted_secret_ciphertext,
                dek=plaintext_dek,
                aad=envelope.aad(),
            )
            plaintext = credential_bytes.decode("utf-8")
        except (InvalidTag, UnicodeDecodeError, ValueError) as error:
            raise RouteCredentialResolutionError(
                ShieldErrorCode.CREDENTIAL_CONFIGURATION_ERROR
            ) from error
        if not plaintext:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_CONFIGURATION_ERROR)
        return SecretStr(plaintext)


class RouteCredentialResolver(Protocol):
    """Shield-only provider credential resolver."""

    async def resolve(
        self,
        route: BifrostProviderRoute,
        *,
        principal_id: UUID,
    ) -> ResolvedRouteCredential:
        """Resolve plaintext credential for the selected route."""
        ...


class UnconfiguredRouteCredentialResolver:
    """Fail-closed resolver used when Shield has no decryptor configured."""

    async def resolve(
        self,
        route: BifrostProviderRoute,
        *,
        principal_id: UUID,
    ) -> ResolvedRouteCredential:
        """Reject before provider dispatch."""

        raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_UNAVAILABLE)


class StaticRouteCredentialResolver:
    """Value-redacting resolver for unit tests and local fixtures."""

    def __init__(self, credentials: Mapping[tuple[UUID, str, str], str]) -> None:
        self._credentials = dict(credentials)
        self.calls: list[tuple[UUID, UUID, str, str]] = []

    async def resolve(
        self,
        route: BifrostProviderRoute,
        *,
        principal_id: UUID,
    ) -> ResolvedRouteCredential:
        """Resolve from an in-memory route-key map."""

        self.calls.append(
            (principal_id, route.tenant_id, route.provider_secret_ref, route.provider)
        )
        key = (route.tenant_id, route.provider_secret_ref, route.provider)
        try:
            value = self._credentials[key]
        except KeyError as error:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_UNAVAILABLE) from error
        return ResolvedRouteCredential(
            credential_id=route.id,
            tenant_id=route.tenant_id,
            provider=route.provider,
            provider_secret_ref=route.provider_secret_ref,
            key_version="static-fixture",
            secret_value=SecretStr(value),
        )


class StoredRouteCredentialResolver:
    """Resolve route credentials from encrypted storage through a decryptor."""

    def __init__(
        self,
        *,
        conn: asyncpg.Connection,
        decryptor: RouteCredentialDecryptor,
        store: RouteCredentialStore | None = None,
    ) -> None:
        self._conn = conn
        self._decryptor = decryptor
        self._store = store or route_credential_store

    async def resolve(
        self,
        route: BifrostProviderRoute,
        *,
        principal_id: UUID,
    ) -> ResolvedRouteCredential:
        """Load and decrypt the active same-tenant credential envelope."""

        envelope = await self._store.load_active_envelope_for_route(
            self._conn,
            route=route,
            principal_id=principal_id,
        )
        if envelope.status is not RouteCredentialStatus.ACTIVE:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_UNAVAILABLE)
        return ResolvedRouteCredential(
            credential_id=envelope.id,
            tenant_id=envelope.tenant_id,
            provider=envelope.provider,
            provider_secret_ref=envelope.provider_secret_ref,
            key_version=envelope.key_version,
            secret_value=self._decryptor.decrypt(envelope),
        )


def _load_queries() -> Any:  # noqa: ANN401 - aiosql exposes dynamic query attributes
    return aiosql.from_path(_QUERIES_SQL_PATH, "asyncpg")  # pyright: ignore[reportUnknownMemberType]


class RouteCredentialStore:
    """aiosql-backed encrypted credential envelope lookup."""

    def __init__(self, queries: Any | None = None) -> None:  # noqa: ANN401
        self._queries = queries if queries is not None else _load_queries()

    async def load_active_envelope_for_route(
        self,
        conn: asyncpg.Connection,
        *,
        route: BifrostProviderRoute,
        principal_id: UUID,
    ) -> RouteCredentialEnvelope:
        """Load the active same-tenant credential envelope for a route."""

        record = await self._queries.get_active_route_credential_for_route(
            conn,
            tenant_id=route.tenant_id,
            provider_secret_ref=route.provider_secret_ref,
            provider=route.provider,
            principal_id=principal_id,
        )
        if record is None:
            raise RouteCredentialResolutionError(ShieldErrorCode.CREDENTIAL_UNAVAILABLE)
        return _record_to_envelope(record)


def _record_to_envelope(record: Any) -> RouteCredentialEnvelope:  # noqa: ANN401
    payload = dict(record)
    payload["provider"] = str(payload["provider"])
    return RouteCredentialEnvelope.model_validate(payload)


route_credential_store: RouteCredentialStore = RouteCredentialStore()


def _aesgcm_decrypt(ciphertext: bytes, *, dek: bytes, aad: bytes) -> bytes:
    if not ciphertext.startswith(_AESGCM_PREFIX):
        raise ValueError("route credential ciphertext envelope version is unsupported")
    payload = ciphertext[len(_AESGCM_PREFIX) :]
    if len(payload) <= _AESGCM_NONCE_BYTES:
        raise ValueError("route credential ciphertext envelope is truncated")
    nonce = payload[:_AESGCM_NONCE_BYTES]
    encrypted = payload[_AESGCM_NONCE_BYTES:]
    return AESGCM(dek).decrypt(nonce, encrypted, aad)
