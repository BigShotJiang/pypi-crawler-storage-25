"""Typed Shield backpressure and provider-rate-limit responses."""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos_shield.admission import (
    AdmissionOutcome,
    AdmissionRejectionReason,
    ShieldAdmissionContext,
    ShieldAdmissionDecision,
    ShieldCallMode,
)
from skaldos_shield.capacity import ShieldCapacityLeaseError
from skaldos_shield.contracts import (
    RouteCapability,
    SensitivityTier,
    ShieldErrorCode,
    TaskClass,
)


class ShieldBackpressureKind(StrEnum):
    """Low-cardinality Shield backpressure response kind."""

    REJECTED = "rejected"
    QUEUED = "queued"
    PROVIDER_RATE_LIMITED = "provider_rate_limited"


class ShieldBackpressureResponse(BaseModel):
    """Value-free response metadata for overload and provider-rate-limit events."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: ShieldBackpressureKind
    error_code: ShieldErrorCode | None = None
    reason: AdmissionRejectionReason | None = None
    retry_after_seconds: Annotated[int, Field(ge=1, le=60)] | None = None
    queue_delay_ms: Annotated[int, Field(ge=0, le=60_000)] | None = None
    route_id: UUID
    route_capability: RouteCapability
    task_class: TaskClass
    mode: ShieldCallMode
    sensitivity_tier: SensitivityTier
    provider: str | None = None

    @model_validator(mode="after")
    def _kind_fields_match(self) -> ShieldBackpressureResponse:
        if self.kind == ShieldBackpressureKind.REJECTED:
            if self.error_code is None or self.reason is None or self.retry_after_seconds is None:
                raise ValueError("rejected backpressure responses require retry metadata")
            if self.queue_delay_ms is not None:
                raise ValueError("rejected backpressure responses cannot carry queue delay")
        elif self.kind == ShieldBackpressureKind.QUEUED:
            if self.reason is None or self.queue_delay_ms is None:
                raise ValueError("queued backpressure responses require queue metadata")
            if self.error_code is not None or self.retry_after_seconds is not None:
                raise ValueError("queued backpressure responses cannot carry HTTP retry metadata")
        elif self.kind == ShieldBackpressureKind.PROVIDER_RATE_LIMITED:
            if (
                self.error_code != ShieldErrorCode.PROVIDER_RATE_LIMITED
                or self.retry_after_seconds is None
                or self.reason is not None
                or self.queue_delay_ms is not None
            ):
                raise ValueError("provider rate-limit responses require only retry metadata")
        return self


class ShieldBackpressureError(Exception):
    """Raised when Shield rejects or defers dispatch with safe metadata."""

    def __init__(self, response: ShieldBackpressureResponse) -> None:
        code = response.error_code or response.kind
        super().__init__(str(code))
        self.response = response


class ShieldProviderRateLimitError(Exception):
    """Raised by provider adapters when the upstream provider rate-limits a call."""

    def __init__(self, *, retry_after_seconds: int = 1) -> None:
        super().__init__("provider rate limited")
        self.retry_after_seconds = _bounded_retry_after_seconds(retry_after_seconds)


def backpressure_response_from_admission(
    decision: ShieldAdmissionDecision,
) -> ShieldBackpressureResponse:
    """Convert a non-admitted admission decision to response metadata."""

    if decision.outcome == AdmissionOutcome.ADMITTED:
        raise ValueError("admitted decisions are not backpressure responses")
    kind = (
        ShieldBackpressureKind.QUEUED
        if decision.outcome == AdmissionOutcome.QUEUED
        else ShieldBackpressureKind.REJECTED
    )
    return ShieldBackpressureResponse(
        kind=kind,
        error_code=decision.error_code,
        reason=decision.reason,
        retry_after_seconds=decision.retry_after_seconds,
        queue_delay_ms=decision.queue_delay_ms,
        route_id=decision.route_id,
        route_capability=decision.route_capability,
        task_class=decision.task_class,
        mode=decision.mode,
        sensitivity_tier=decision.sensitivity_tier,
    )


def backpressure_response_from_capacity_error(
    error: ShieldCapacityLeaseError,
) -> ShieldBackpressureResponse:
    """Convert a capacity lease rejection to typed response metadata."""

    return backpressure_response_from_admission(error.decision)


def provider_rate_limit_backpressure_response(
    context: ShieldAdmissionContext,
    *,
    retry_after_seconds: int,
    provider: str,
) -> ShieldBackpressureResponse:
    """Return safe provider-rate-limit metadata without fallback instructions."""

    return ShieldBackpressureResponse(
        kind=ShieldBackpressureKind.PROVIDER_RATE_LIMITED,
        error_code=ShieldErrorCode.PROVIDER_RATE_LIMITED,
        retry_after_seconds=retry_after_seconds,
        route_id=context.route_id,
        route_capability=context.route_capability,
        task_class=context.task_class,
        mode=context.mode,
        sensitivity_tier=context.sensitivity_tier,
        provider=provider,
    )


def retry_headers_for_backpressure(response: ShieldBackpressureResponse) -> dict[str, str]:
    """Return safe retry headers for rejected/provider-rate-limited responses."""

    if response.retry_after_seconds is None:
        return {}
    return {"Retry-After": str(response.retry_after_seconds)}


def _bounded_retry_after_seconds(value: int) -> int:
    return min(60, max(1, value))
