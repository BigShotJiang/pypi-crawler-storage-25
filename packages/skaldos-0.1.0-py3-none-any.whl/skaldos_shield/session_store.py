"""Redaction-session store contract for Slice 5 Wave 0."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Protocol
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.contracts import SensitivityTier


class RedactionSessionError(Exception):
    """Base class for typed redaction-session failures."""


class RedactionSessionExpiredError(RedactionSessionError):
    """Raised when a caller uses an expired or purged session."""


class RedactionMappingCapacityExceededError(RedactionSessionError):
    """Raised before a provider call when mapping capacity would be exceeded."""


class RedactionKMSUnavailableError(RedactionSessionError):
    """Raised when encryption/decryption cannot safely proceed."""


class RedactionMapping(BaseModel):
    """Session-scoped real/synthetic mapping metadata without raw values."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    organization_id: UUID
    session_id: UUID
    entity_type: str
    sensitivity: SensitivityTier
    synthetic_value: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class RedactionCacheKey(BaseModel):
    """Hash-keyed cache identity for an already processed input block."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    organization_id: UUID
    session_id: UUID
    detector_version: str
    policy_version: str
    mode: str
    input_block_hmac: str


class RedactionSessionStore(Protocol):
    """Durable, encrypted redaction-session mapping store.

    Implementations must scope every operation by organization and session,
    store no raw values in Postgres/cache/logs, and treat cache outage as an
    optimization failure rather than provider pass-through permission.
    """

    async def get_or_create_mapping(
        self,
        *,
        organization_id: UUID,
        session_id: UUID,
        entity_type: str,
        real_value: str,
        sensitivity: SensitivityTier,
    ) -> RedactionMapping:
        """Return the idempotent synthetic mapping for ``real_value``."""
        ...

    async def reverse_lookup(
        self,
        *,
        organization_id: UUID,
        session_id: UUID,
        synthetic_value: str,
    ) -> str:
        """Return the trusted real value for response rehydration."""
        ...

    async def purge_session(
        self,
        *,
        organization_id: UUID,
        session_id: UUID,
        reason: str,
    ) -> None:
        """Purge a session so mappings cannot be used again."""
        ...

    async def cache_lookup(self, key: RedactionCacheKey) -> bool:
        """Return whether a processed-block cache entry exists."""
        ...

    async def cache_store(self, key: RedactionCacheKey) -> None:
        """Record a processed-block cache entry without raw block text."""
        ...
