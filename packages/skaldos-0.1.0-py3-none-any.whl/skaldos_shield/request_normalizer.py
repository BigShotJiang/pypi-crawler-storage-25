"""Canonical Shield request normalizer.

Slice 5 keeps the native Anthropic/OpenAI proxy deferred. This module therefore
normalizes only the canonical Shield request envelope into the shared policy
core used before scan/substitution, routing, audit, or provider dispatch.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from skaldos_shield.contracts import (
    CanonicalShieldRequest,
    LatencyMode,
    MessagePart,
    RouteCapability,
    ShieldMessageRole,
    TaskClass,
)
from skaldos_shield.message_parts import (
    MessagePartPolicyDecision,
    MessagePartSurface,
    decide_message_part_policy,
)


class NormalizedMessagePart(BaseModel):
    """One canonical part plus value-free source metadata and policy decision."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    role: ShieldMessageRole
    part: MessagePart
    policy_decision: MessagePartPolicyDecision
    message_index: int = Field(ge=0)
    part_index: int = Field(ge=0)
    source_field: str


class NormalizedShieldRequest(BaseModel):
    """Canonical request material consumed by later Shield policy stages."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: str
    principal_id: str
    task_class: TaskClass
    required_capability: RouteCapability
    stream: bool
    latency_mode: LatencyMode
    surface: MessagePartSurface
    parts: tuple[NormalizedMessagePart, ...]


def normalize_canonical_request(request: CanonicalShieldRequest) -> NormalizedShieldRequest:
    """Flatten a canonical Shield request into policy-bearing message parts."""

    normalized: list[NormalizedMessagePart] = []
    for message_index, message in enumerate(request.messages):
        for part_index, part in enumerate(message.parts):
            normalized.append(
                NormalizedMessagePart(
                    role=message.role,
                    part=part,
                    policy_decision=decide_message_part_policy(
                        part,
                        surface=MessagePartSurface.CANONICAL,
                    ),
                    message_index=message_index,
                    part_index=part_index,
                    source_field=f"messages[{message_index}].parts[{part_index}]",
                )
            )

    return NormalizedShieldRequest(
        tenant_id=str(request.tenant_id),
        principal_id=str(request.principal_id),
        task_class=request.task_class,
        required_capability=request.required_capability,
        stream=request.stream,
        latency_mode=request.latency_mode,
        surface=MessagePartSurface.CANONICAL,
        parts=tuple(normalized),
    )
