"""Standalone FastAPI app factory for SkaldOS Shield."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from uuid import UUID

from fastapi import FastAPI

from skaldos_shield.admission import ShieldQueuePolicy
from skaldos_shield.app_wiring import (
    ConfiguredShieldRuntime,
    ShieldConfiguredModeError,
    build_configured_shield_call_core,
    configured_mode_error_code,
)
from skaldos_shield.call_core import InMemoryShieldAuditWriter, ShieldCallCore
from skaldos_shield.capacity import ShieldCapacityLeaser
from skaldos_shield.contracts import (
    MessagePart,
    MessagePartType,
    RouteCapability,
    SensitivityTier,
    ShieldMessage,
    ShieldMessageRole,
    ShieldResultKind,
    TrustedEmbeddingResult,
)
from skaldos_shield.detectors import DetectorRegistry, FixtureDetector, FixtureDetectorRule
from skaldos_shield.provider_adapters import (
    FakeProviderAdapter,
    ProviderAdapterRequest,
    ProviderAdapterResponse,
)
from skaldos_shield.redaction import PII_CATEGORY
from skaldos_shield.routes import router
from skaldos_shield.routes_store import BifrostProviderRoute
from skaldos_shield.runtime_config import build_configured_runtime_from_settings
from skaldos_shield.settings import ProviderRouteSource, ShieldEnvironment, ShieldSettings

__all__ = ["app", "create_app"]

_APP_TITLE = "SkaldOS Shield"
_APP_VERSION = "2.0.0"


def create_app(
    settings: ShieldSettings | None = None,
    *,
    configured_runtime: ConfiguredShieldRuntime | None = None,
) -> FastAPI:
    """Create the standalone Shield FastAPI app."""

    resolved_settings = settings or ShieldSettings()

    @asynccontextmanager
    async def lifespan(fastapi_app: FastAPI) -> AsyncGenerator[None]:
        handle = None
        if (
            resolved_settings.provider_route_source == ProviderRouteSource.CONFIGURED
            and configured_runtime is None
        ):
            try:
                handle = await build_configured_runtime_from_settings(resolved_settings)
                fastapi_app.state.shield_configured_runtime_handle = handle
                _configure_configured_core(
                    fastapi_app,
                    resolved_settings,
                    handle.runtime,
                )
            except Exception:
                fastapi_app.state.shield_configured_mode_error = (
                    "shield_configured_runtime_not_configured"
                )
        try:
            yield
        finally:
            if handle is not None:
                await handle.close()

    fastapi_app = FastAPI(
        title=_APP_TITLE,
        version=_APP_VERSION,
        openapi_version="3.1.0",
        lifespan=lifespan,
    )
    fastapi_app.state.shield_settings = resolved_settings
    _configure_staging_fixture_core(fastapi_app, resolved_settings)
    _configure_configured_core(fastapi_app, resolved_settings, configured_runtime)
    fastapi_app.include_router(router)
    return fastapi_app


def _configure_configured_core(
    fastapi_app: FastAPI,
    settings: ShieldSettings,
    configured_runtime: ConfiguredShieldRuntime | None,
) -> None:
    """Attach configured-mode call core when all dependencies are supplied."""

    if settings.provider_route_source != ProviderRouteSource.CONFIGURED:
        return
    if configured_runtime is None:
        fastapi_app.state.shield_configured_mode_error = (
            configured_mode_error_code(settings) or "shield_configured_runtime_not_configured"
        )
        return
    try:
        fastapi_app.state.shield_call_core = build_configured_shield_call_core(
            settings=settings,
            runtime=configured_runtime,
        )
    except ShieldConfiguredModeError as error:
        fastapi_app.state.shield_configured_mode_error = error.code


def _configure_staging_fixture_core(fastapi_app: FastAPI, settings: ShieldSettings) -> None:
    """Attach the synthetic provider route used by production-shaped staging smokes."""

    if not settings.fixture_provider_enabled:
        return
    if settings.environment == ShieldEnvironment.PRODUCTION:
        return
    if settings.provider_route_source != ProviderRouteSource.FIXTURE:
        return
    if settings.fixture_tenant_id is None:
        raise RuntimeError("SHIELD_FIXTURE_TENANT_ID is required when fixture provider is enabled")

    provider = _StagingFixtureProviderAdapter(
        forbidden_fragments=(settings.fixture_detector_marker, "fixture-api-key-token")
    )
    fastapi_app.state.shield_fixture_provider_adapter = provider
    fastapi_app.state.shield_call_core = ShieldCallCore(
        routes=(_fixture_route(settings.fixture_tenant_id),),
        detector_registry=DetectorRegistry(
            detectors=(
                FixtureDetector(
                    (
                        FixtureDetectorRule(
                            marker=settings.fixture_detector_marker,
                            entity_type="EMAIL",
                            category=PII_CATEGORY,
                        ),
                    )
                ),
            )
        ),
        redaction_pipeline=None,
        session_store=None,
        capacity_leaser=ShieldCapacityLeaser(),
        audit_writer=InMemoryShieldAuditWriter(),
        provider_adapter=provider,
        require_route_credentials=False,
    )


def _fixture_route(tenant_id: UUID) -> BifrostProviderRoute:
    return BifrostProviderRoute(
        id=UUID("2cd038eb-a912-45db-bb6f-bb6f090637f8"),
        tenant_id=tenant_id,
        sensitivity_tier=SensitivityTier.PII,
        provider="fixture",
        model_id="fixture-summary-model",
        provider_secret_ref="fixture-secret-ref",
        shield_enabled=True,
        priority=10,
        max_concurrent_calls=4,
        max_streaming_calls=1,
        queue_policy=ShieldQueuePolicy.REJECT,
        queue_max_delay_ms=0,
        budget_scope="route",
        base_url_override=None,
        embedding_dimensions=3,
        embedding_dtype="float",
        supports_chat=True,
        supports_agent_tool=True,
        supports_embedding=True,
        supports_search_query_embedding=True,
        supports_classification=False,
        supports_assertion_helper=False,
        is_active=True,
        created_at=datetime(2026, 5, 18, tzinfo=UTC),
        revoked_at=None,
    )


class _StagingFixtureProviderAdapter(FakeProviderAdapter):
    """Fixture provider with deterministic result shapes per route capability."""

    def __init__(self, *, forbidden_fragments: tuple[str, ...] = ()) -> None:
        super().__init__(
            _fixture_embedding_response(),
            forbidden_fragments=forbidden_fragments,
        )

    async def complete(self, request: ProviderAdapterRequest) -> ProviderAdapterResponse:
        await super().complete(request)
        if request.route.capability in {RouteCapability.AGENT_TOOL, RouteCapability.CHAT}:
            return ProviderAdapterResponse(
                messages=(
                    ShieldMessage(
                        role=ShieldMessageRole.ASSISTANT,
                        parts=[
                            MessagePart(
                                type=MessagePartType.USER_TEXT,
                                text="Fixture summary note.",
                            )
                        ],
                    ),
                )
            )
        return _fixture_embedding_response()


def _fixture_embedding_response() -> ProviderAdapterResponse:
    return ProviderAdapterResponse(
        result=TrustedEmbeddingResult(
            kind=ShieldResultKind.EMBEDDING,
            vectors=[[0.1, 0.2, 0.3]],
            dimensions=3,
        )
    )


app = create_app()
