"""Read-only calibration projection access for Slice 9."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from decimal import Decimal
from typing import Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict


class CalibrationReadError(RuntimeError):
    """Raised when calibration read-model access cannot complete safely."""


ClassifierCalibrationState = Literal["unknown", "stale", "low_sample", "usable"]


class ClassifierCalibrationProjection(BaseModel):
    """Content-free classifier-family calibration projection row."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    classification: str
    subject_kind: Literal["classifier-family"]
    subject_key: str
    action: Literal["classify"]
    subject_type: Literal["node"]
    scope: str
    context_fingerprint: str
    calibration_score: Decimal | None
    surprise_count: int
    missed_pattern4_count: int
    human_reviewed_outcome_count: int
    sample_size: int
    confidence_interval_bucket: str
    projection_stale: bool
    latest_threshold_config_id: UUID | None
    last_recompute_event_id: UUID | None
    last_surprise_at: datetime | None
    updated_at: datetime


class ClassifierThresholdVersion(BaseModel):
    """Read-only threshold config version metadata."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    ontology_version_id: UUID
    classification: str
    node_type_family: str
    classifier_name: str
    classifier_version: str
    config_version: int
    threshold: Decimal
    min_threshold: Decimal
    max_threshold: Decimal
    tightening_step: Decimal
    sample_size_floor: int
    miss_count_window: int
    supersedes_config_id: UUID | None
    created_from_surprise_id: UUID | None
    active_from: datetime
    active_to: datetime | None
    created_by_system: bool
    created_at: datetime


class PolicyCalibrationSignal(BaseModel):
    """Conservative policy-facing calibration input.

    This helper result is advisory only. Authorization/autonomy code may use it
    as one input, but it deliberately does not encode a final allow/deny
    decision.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    state: ClassifierCalibrationState
    projection_id: UUID | None = None
    calibration_score: Decimal | None = None
    sample_size: int = 0
    confidence_interval_bucket: str = "unknown"
    projection_stale: bool = True
    latest_threshold_config_id: UUID | None = None
    reason_code: str

    @property
    def usable_for_autonomy(self) -> bool:
        return self.state == "usable"


def classifier_family_subject_key(
    *,
    classifier_name: str,
    classifier_version: str,
    ontology_version_id: UUID,
    node_type_family: str,
) -> str:
    """Return the canonical classifier-family projection subject key."""

    return ":".join(
        (
            classifier_name,
            classifier_version,
            str(ontology_version_id),
            node_type_family,
        )
    )


class CalibrationReadRepository:
    """RLS-bound read repository for classifier calibration surfaces."""

    async def get_classifier_family_projection(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        ontology_version_id: UUID,
        node_type_family: str,
        classifier_name: str,
        classifier_version: str,
        context_fingerprint: str | None = None,
    ) -> ClassifierCalibrationProjection | None:
        subject_key = classifier_family_subject_key(
            classifier_name=classifier_name,
            classifier_version=classifier_version,
            ontology_version_id=ontology_version_id,
            node_type_family=node_type_family,
        )
        row = cast(
            Mapping[str, object] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT
  id,
  tenant_id,
  classification,
  subject_kind,
  subject_key,
  action,
  subject_type,
  scope,
  context_fingerprint,
  calibration_score,
  surprise_count,
  missed_pattern4_count,
  human_reviewed_outcome_count,
  sample_size,
  confidence_interval_bucket,
  projection_stale,
  latest_threshold_config_id,
  last_recompute_event_id,
  last_surprise_at,
  updated_at
FROM classifier_calibration_projection
WHERE tenant_id = $1
  AND subject_kind = 'classifier-family'
  AND subject_key = $2
  AND action = 'classify'
  AND subject_type = 'node'
  AND scope = $3
  AND ($4::text IS NULL OR context_fingerprint = $4)
ORDER BY updated_at DESC, id DESC
LIMIT 1
""",
                tenant_id,
                subject_key,
                node_type_family,
                context_fingerprint,
            ),
        )
        if row is None:
            return None
        return _projection_from_row(row)

    async def list_classifier_threshold_versions(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        ontology_version_id: UUID,
        node_type_family: str,
        classifier_name: str,
        classifier_version: str,
        limit: int = 50,
    ) -> tuple[ClassifierThresholdVersion, ...]:
        rows = cast(
            list[Mapping[str, object]],
            await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT
  id,
  tenant_id,
  ontology_version_id,
  classification,
  node_type_family,
  classifier_name,
  classifier_version,
  config_version,
  threshold,
  min_threshold,
  max_threshold,
  tightening_step,
  sample_size_floor,
  miss_count_window,
  supersedes_config_id,
  created_from_surprise_id,
  active_from,
  active_to,
  created_by_system,
  created_at
FROM classifier_threshold_config
WHERE tenant_id = $1
  AND ontology_version_id = $2
  AND node_type_family = $3
  AND classifier_name = $4
  AND classifier_version = $5
ORDER BY config_version DESC, created_at DESC
LIMIT $6
""",
                tenant_id,
                ontology_version_id,
                node_type_family,
                classifier_name,
                classifier_version,
                limit,
            ),
        )
        return tuple(_threshold_from_row(row) for row in rows)


async def read_classifier_policy_calibration(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
    context_fingerprint: str | None = None,
    min_sample_size: int = 5,
    repository: CalibrationReadRepository | None = None,
) -> PolicyCalibrationSignal:
    """Return a conservative policy/autonomy calibration input."""

    if min_sample_size < 1:
        raise CalibrationReadError("min_sample_size_invalid")
    repo = repository or CalibrationReadRepository()
    projection = await repo.get_classifier_family_projection(
        connection=connection,
        tenant_id=tenant_id,
        ontology_version_id=ontology_version_id,
        node_type_family=node_type_family,
        classifier_name=classifier_name,
        classifier_version=classifier_version,
        context_fingerprint=context_fingerprint,
    )
    if projection is None:
        return PolicyCalibrationSignal(state="unknown", reason_code="projection_missing")
    if projection.projection_stale:
        return PolicyCalibrationSignal(
            state="stale",
            projection_id=projection.id,
            calibration_score=projection.calibration_score,
            sample_size=projection.sample_size,
            confidence_interval_bucket=projection.confidence_interval_bucket,
            projection_stale=True,
            latest_threshold_config_id=projection.latest_threshold_config_id,
            reason_code="projection_stale",
        )
    if projection.sample_size < min_sample_size:
        return PolicyCalibrationSignal(
            state="low_sample",
            projection_id=projection.id,
            calibration_score=projection.calibration_score,
            sample_size=projection.sample_size,
            confidence_interval_bucket=projection.confidence_interval_bucket,
            projection_stale=False,
            latest_threshold_config_id=projection.latest_threshold_config_id,
            reason_code="sample_size_floor",
        )
    if projection.calibration_score is None:
        return PolicyCalibrationSignal(
            state="unknown",
            projection_id=projection.id,
            sample_size=projection.sample_size,
            confidence_interval_bucket=projection.confidence_interval_bucket,
            projection_stale=False,
            latest_threshold_config_id=projection.latest_threshold_config_id,
            reason_code="calibration_score_missing",
        )
    return PolicyCalibrationSignal(
        state="usable",
        projection_id=projection.id,
        calibration_score=projection.calibration_score,
        sample_size=projection.sample_size,
        confidence_interval_bucket=projection.confidence_interval_bucket,
        projection_stale=False,
        latest_threshold_config_id=projection.latest_threshold_config_id,
        reason_code="projection_usable",
    )


def _projection_from_row(row: Mapping[str, object]) -> ClassifierCalibrationProjection:
    return ClassifierCalibrationProjection(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        classification=cast(str, row["classification"]),
        subject_kind="classifier-family",
        subject_key=cast(str, row["subject_key"]),
        action="classify",
        subject_type="node",
        scope=cast(str, row["scope"]),
        context_fingerprint=cast(str, row["context_fingerprint"]),
        calibration_score=cast(Decimal | None, row["calibration_score"]),
        surprise_count=cast(int, row["surprise_count"]),
        missed_pattern4_count=cast(int, row["missed_pattern4_count"]),
        human_reviewed_outcome_count=cast(int, row["human_reviewed_outcome_count"]),
        sample_size=cast(int, row["sample_size"]),
        confidence_interval_bucket=cast(str, row["confidence_interval_bucket"]),
        projection_stale=cast(bool, row["projection_stale"]),
        latest_threshold_config_id=cast(UUID | None, row["latest_threshold_config_id"]),
        last_recompute_event_id=cast(UUID | None, row["last_recompute_event_id"]),
        last_surprise_at=cast(datetime | None, row["last_surprise_at"]),
        updated_at=cast(datetime, row["updated_at"]),
    )


def _threshold_from_row(row: Mapping[str, object]) -> ClassifierThresholdVersion:
    return ClassifierThresholdVersion(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        ontology_version_id=cast(UUID, row["ontology_version_id"]),
        classification=cast(str, row["classification"]),
        node_type_family=cast(str, row["node_type_family"]),
        classifier_name=cast(str, row["classifier_name"]),
        classifier_version=cast(str, row["classifier_version"]),
        config_version=cast(int, row["config_version"]),
        threshold=cast(Decimal, row["threshold"]),
        min_threshold=cast(Decimal, row["min_threshold"]),
        max_threshold=cast(Decimal, row["max_threshold"]),
        tightening_step=cast(Decimal, row["tightening_step"]),
        sample_size_floor=cast(int, row["sample_size_floor"]),
        miss_count_window=cast(int, row["miss_count_window"]),
        supersedes_config_id=cast(UUID | None, row["supersedes_config_id"]),
        created_from_surprise_id=cast(UUID | None, row["created_from_surprise_id"]),
        active_from=cast(datetime, row["active_from"]),
        active_to=cast(datetime | None, row["active_to"]),
        created_by_system=cast(bool, row["created_by_system"]),
        created_at=cast(datetime, row["created_at"]),
    )
