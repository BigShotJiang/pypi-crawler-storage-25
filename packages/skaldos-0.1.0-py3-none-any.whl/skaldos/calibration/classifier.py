"""Classifier calibration loop for missed Pattern-4 decisions.

Slice 9 keeps this path deliberately narrow: a human/supervisor review can
establish that a non-Pattern-4 classifier outcome was actually load-bearing,
which records a typed surprise, inserts a successor threshold version, and
marks the read projection stale in the same transaction.
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Annotated, Literal, Self, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.surprises.stream import (
    SubjectHandle,
    SurpriseContext,
    SurpriseRecordDraft,
    SurpriseRecordResult,
    write_surprise_record,
)

ObservedUpdatePattern = Literal[4]
PredictedUpdatePattern = Literal[1, 2, 3]


class ClassifierCalibrationError(RuntimeError):
    """Raised when classifier calibration cannot complete safely."""


class OriginalClassifierEvidence(BaseModel):
    """Content-free classifier metadata read from the original Node."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    classifier_name: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")]
    classifier_version: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")]
    threshold_version_id: UUID
    ontology_version_id: UUID
    node_type_family: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]
    predicted_update_pattern: PredictedUpdatePattern
    confidence: Decimal
    threshold: Decimal
    reason_code: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]

    @field_validator("confidence", "threshold", mode="before")
    @classmethod
    def _parse_probability(cls, value: object) -> Decimal:
        try:
            parsed = Decimal(str(value))
        except (InvalidOperation, ValueError) as exc:
            raise ValueError("invalid_probability") from exc
        if not parsed.is_finite() or parsed < 0 or parsed > 1:
            raise ValueError("invalid_probability")
        return parsed.quantize(Decimal("0.0001"))


class ClassifierMissedPattern4Draft(BaseModel):
    """Validated missed-decision evidence without raw graph content."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    original_node_id: UUID
    review_decision_id: UUID
    context_of_validity: SurpriseContext
    observed_node_type_family: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]
    observed_update_pattern: ObservedUpdatePattern = 4
    dependent_review_count: int = Field(default=0, ge=0)
    human_reviewed_outcome_count: int = Field(default=1, ge=1)
    agent_run_id: UUID | None = None
    trace_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")] | None = None
    occurred_at: datetime

    @field_validator("occurred_at")
    @classmethod
    def _normalize_occurred_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @model_validator(mode="after")
    def _context_matches_tenant(self) -> Self:
        if self.context_of_validity.tenant != self.tenant_id:
            raise ValueError("tenant_context_mismatch")
        return self


@dataclass(frozen=True, slots=True)
class ClassifierMissedPattern4Result:
    """Outcome of one missed Pattern-4 calibration attempt."""

    surprise: SurpriseRecordResult
    threshold_config_id: UUID | None
    threshold_successor_id: UUID | None
    projection_id: UUID | None
    projection_stale: bool
    skipped_reason: str | None = None


@dataclass(frozen=True, slots=True)
class _NodeEvidence:
    id: UUID
    tenant_id: UUID
    classification: str
    context_of_validity: Mapping[str, object]
    metadata: Mapping[str, object]


@dataclass(frozen=True, slots=True)
class _ThresholdConfig:
    id: UUID
    tenant_id: UUID
    ontology_version_id: UUID
    classification: str
    context_of_validity: Mapping[str, object]
    node_type_family: str
    classifier_name: str
    classifier_version: str
    config_version: int
    threshold: Decimal
    min_threshold: Decimal
    max_threshold: Decimal
    tightening_step: Decimal
    sample_size_floor: int
    miss_count_window: int
    active_from: datetime


async def record_classifier_missed_pattern4(
    *,
    connection: asyncpg.Connection,
    draft: ClassifierMissedPattern4Draft,
) -> ClassifierMissedPattern4Result:
    """Record a missed Pattern-4 surprise and tighten the scoped threshold.

    The caller must already be inside the review/falsification transaction and
    have set the normal principal context GUCs. The function emits no raw node
    content and never mutates the reviewed node.
    """

    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise ClassifierCalibrationError("classifier_calibration_transaction_required")

    original = await _load_node_evidence(connection, draft.original_node_id)
    review = await _load_node_evidence(connection, draft.review_decision_id)
    if original.tenant_id != draft.tenant_id or review.tenant_id != draft.tenant_id:
        raise ClassifierCalibrationError("tenant_mismatch")

    metadata = original.metadata.get("classifier")
    if not isinstance(metadata, Mapping):
        return await _record_low_fidelity_surprise(
            connection=connection,
            draft=draft,
            skipped_reason="metadata_missing",
        )
    try:
        evidence = OriginalClassifierEvidence.model_validate(metadata)
    except Exception:
        return await _record_low_fidelity_surprise(
            connection=connection,
            draft=draft,
            skipped_reason="metadata_invalid",
        )

    if evidence.ontology_version_id != draft.context_of_validity.ontology_version:
        return await _record_low_fidelity_surprise(
            connection=connection,
            draft=draft,
            skipped_reason="context_mismatch",
        )

    existing_surprise = await _find_existing_classifier_miss_surprise(
        connection=connection,
        tenant_id=draft.tenant_id,
        original_node_id=draft.original_node_id,
        review_decision_id=draft.review_decision_id,
    )
    if existing_surprise is not None:
        existing_successor_id = await _find_threshold_successor_for_surprise(
            connection=connection,
            surprise_id=existing_surprise.id,
        )
        return ClassifierMissedPattern4Result(
            surprise=existing_surprise,
            threshold_config_id=evidence.threshold_version_id,
            threshold_successor_id=existing_successor_id,
            projection_id=None,
            projection_stale=False,
        )

    magnitude = classifier_missed_pattern4_magnitude(
        confidence=evidence.confidence,
        threshold=evidence.threshold,
        dependent_review_count=draft.dependent_review_count,
    )
    surprise = await write_surprise_record(
        connection=connection,
        draft=SurpriseRecordDraft(
            tenant_id=draft.tenant_id,
            context_of_validity=draft.context_of_validity,
            prediction=SubjectHandle(
                subject_type="node",
                subject_id=draft.original_node_id,
            ),
            observation=SubjectHandle(
                subject_type="node",
                subject_id=draft.review_decision_id,
            ),
            comparator_kind="classifier_missed_pattern4_decision",
            magnitude=magnitude,
            loop_level="single",
            domain="classifier-calibration",
            task_type=evidence.node_type_family,
            agent_run_id=draft.agent_run_id,
            trace_id=draft.trace_id,
            occurred_at=draft.occurred_at,
        ),
    )
    if not surprise.inserted:
        existing_successor_id = await _find_threshold_successor_for_surprise(
            connection=connection,
            surprise_id=surprise.id,
        )
        return ClassifierMissedPattern4Result(
            surprise=surprise,
            threshold_config_id=evidence.threshold_version_id,
            threshold_successor_id=existing_successor_id,
            projection_id=None,
            projection_stale=False,
        )

    pinned_config = await _load_threshold_config_by_id(
        connection=connection,
        config_id=evidence.threshold_version_id,
        tenant_id=draft.tenant_id,
    )
    if pinned_config is None:
        projection_id = await _mark_projection_stale(
            connection=connection,
            draft=draft,
            evidence=evidence,
            surprise=surprise,
            latest_threshold_config_id=None,
        )
        return ClassifierMissedPattern4Result(
            surprise=surprise,
            threshold_config_id=evidence.threshold_version_id,
            threshold_successor_id=None,
            projection_id=projection_id,
            projection_stale=True,
            skipped_reason="threshold_config_missing",
        )
    if not _threshold_scope_matches(pinned_config, evidence):
        projection_id = await _mark_projection_stale(
            connection=connection,
            draft=draft,
            evidence=evidence,
            surprise=surprise,
            latest_threshold_config_id=pinned_config.id,
        )
        return ClassifierMissedPattern4Result(
            surprise=surprise,
            threshold_config_id=pinned_config.id,
            threshold_successor_id=None,
            projection_id=projection_id,
            projection_stale=True,
            skipped_reason="threshold_scope_mismatch",
        )
    active_config = await _load_active_threshold_config_for_scope(
        connection=connection,
        tenant_id=draft.tenant_id,
        ontology_version_id=evidence.ontology_version_id,
        node_type_family=evidence.node_type_family,
        classifier_name=evidence.classifier_name,
        classifier_version=evidence.classifier_version,
    )
    if active_config is None:
        projection_id = await _mark_projection_stale(
            connection=connection,
            draft=draft,
            evidence=evidence,
            surprise=surprise,
            latest_threshold_config_id=pinned_config.id,
        )
        return ClassifierMissedPattern4Result(
            surprise=surprise,
            threshold_config_id=pinned_config.id,
            threshold_successor_id=None,
            projection_id=projection_id,
            projection_stale=True,
            skipped_reason="active_threshold_config_missing",
        )

    skip_reason = await _threshold_update_skip_reason(
        connection=connection,
        config=active_config,
        draft=draft,
        surprise_id=surprise.id,
    )
    successor_id = None
    if skip_reason is None:
        successor_id = await _insert_threshold_successor(
            connection=connection,
            config=active_config,
            surprise_id=surprise.id,
            occurred_at=draft.occurred_at,
        )
    projection_id = await _mark_projection_stale(
        connection=connection,
        draft=draft,
        evidence=evidence,
        surprise=surprise,
        latest_threshold_config_id=successor_id or active_config.id,
    )
    return ClassifierMissedPattern4Result(
        surprise=surprise,
        threshold_config_id=active_config.id,
        threshold_successor_id=successor_id,
        projection_id=projection_id,
        projection_stale=True,
        skipped_reason=skip_reason,
    )


def classifier_missed_pattern4_magnitude(
    *,
    confidence: Decimal,
    threshold: Decimal,
    dependent_review_count: int,
) -> Decimal:
    """Return deterministic bounded magnitude for a missed load-bearing decision."""

    gap = max(Decimal("0"), threshold - confidence)
    dependency_bonus = min(Decimal(dependent_review_count), Decimal("5")) * Decimal("0.03")
    magnitude = Decimal("0.55") + (gap * Decimal("0.25")) + dependency_bonus
    return min(magnitude, Decimal("1")).quantize(Decimal("0.0001"))


async def _record_low_fidelity_surprise(
    *,
    connection: asyncpg.Connection,
    draft: ClassifierMissedPattern4Draft,
    skipped_reason: str,
) -> ClassifierMissedPattern4Result:
    existing_surprise = await _find_existing_classifier_miss_surprise(
        connection=connection,
        tenant_id=draft.tenant_id,
        original_node_id=draft.original_node_id,
        review_decision_id=draft.review_decision_id,
    )
    surprise = existing_surprise or await write_surprise_record(
        connection=connection,
        draft=SurpriseRecordDraft(
            tenant_id=draft.tenant_id,
            context_of_validity=draft.context_of_validity,
            prediction=SubjectHandle(subject_type="node", subject_id=draft.original_node_id),
            observation=SubjectHandle(subject_type="node", subject_id=draft.review_decision_id),
            comparator_kind="classifier_missed_pattern4_decision",
            magnitude=Decimal("0.5500"),
            loop_level="single",
            domain="classifier-calibration",
            task_type=draft.observed_node_type_family,
            agent_run_id=draft.agent_run_id,
            trace_id=draft.trace_id,
            occurred_at=draft.occurred_at,
        ),
    )
    return ClassifierMissedPattern4Result(
        surprise=surprise,
        threshold_config_id=None,
        threshold_successor_id=None,
        projection_id=None,
        projection_stale=False,
        skipped_reason=skipped_reason,
    )


async def _load_node_evidence(
    connection: asyncpg.Connection,
    node_id: UUID,
) -> _NodeEvidence:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id, tenant_id, classification, context_of_validity, metadata
FROM nodes
WHERE id = $1
  AND archived_at IS NULL
""",
            node_id,
        ),
    )
    if row is None:
        raise ClassifierCalibrationError("node_not_visible")
    return _NodeEvidence(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        classification=cast(str, row["classification"]),
        context_of_validity=_json_mapping(row["context_of_validity"]),
        metadata=_json_mapping(row["metadata"]),
    )


async def _load_threshold_config(
    *,
    connection: asyncpg.Connection,
    row: Mapping[str, object],
) -> _ThresholdConfig:
    return _ThresholdConfig(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        ontology_version_id=cast(UUID, row["ontology_version_id"]),
        classification=cast(str, row["classification"]),
        context_of_validity=_json_mapping(row["context_of_validity"]),
        node_type_family=cast(str, row["node_type_family"]),
        classifier_name=cast(str, row["classifier_name"]),
        classifier_version=cast(str, row["classifier_version"]),
        config_version=cast(int, row["config_version"]),
        threshold=cast(Decimal, row["threshold"]),
        min_threshold=cast(Decimal, row["min_threshold"]),
        max_threshold=cast(Decimal, row["max_threshold"]),
        tightening_step=cast(Decimal, row["tightening_step"]),
        sample_size_floor=cast(int, row["sample_size_floor"]),
        miss_count_window=cast(int, row["miss_count_window"]),
        active_from=cast(datetime, row["active_from"]),
    )


async def _load_threshold_config_by_id(
    *,
    connection: asyncpg.Connection,
    config_id: UUID,
    tenant_id: UUID,
) -> _ThresholdConfig | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT
  id,
  tenant_id,
  ontology_version_id,
  classification,
  context_of_validity,
  node_type_family,
  classifier_name,
  classifier_version,
  config_version,
  threshold,
  min_threshold,
  max_threshold,
  tightening_step,
  sample_size_floor,
  miss_count_window,
  active_from
FROM classifier_threshold_config
WHERE id = $1
  AND tenant_id = $2
""",
            config_id,
            tenant_id,
        ),
    )
    if row is None:
        return None
    return await _load_threshold_config(connection=connection, row=row)


async def _load_active_threshold_config_for_scope(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: str,
    classifier_name: str,
    classifier_version: str,
) -> _ThresholdConfig | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT
  id,
  tenant_id,
  ontology_version_id,
  classification,
  context_of_validity,
  node_type_family,
  classifier_name,
  classifier_version,
  config_version,
  threshold,
  min_threshold,
  max_threshold,
  tightening_step,
  sample_size_floor,
  miss_count_window,
  active_from
FROM classifier_threshold_config
WHERE tenant_id = $1
  AND ontology_version_id = $2
  AND node_type_family = $3
  AND classifier_name = $4
  AND classifier_version = $5
  AND active_to IS NULL
""",
            tenant_id,
            ontology_version_id,
            node_type_family,
            classifier_name,
            classifier_version,
        ),
    )
    if row is None:
        return None
    return await _load_threshold_config(connection=connection, row=row)


def _threshold_scope_matches(
    config: _ThresholdConfig,
    evidence: OriginalClassifierEvidence,
) -> bool:
    return (
        config.ontology_version_id == evidence.ontology_version_id
        and config.node_type_family == evidence.node_type_family
        and config.classifier_name == evidence.classifier_name
        and config.classifier_version == evidence.classifier_version
    )


async def _threshold_update_skip_reason(
    *,
    connection: asyncpg.Connection,
    config: _ThresholdConfig,
    draft: ClassifierMissedPattern4Draft,
    surprise_id: UUID,
) -> str | None:
    if config.threshold >= config.max_threshold:
        return "threshold_at_max"
    if draft.human_reviewed_outcome_count < config.sample_size_floor:
        return "sample_size_floor"
    eligible_miss_count = await _eligible_miss_count(
        connection=connection,
        config=config,
        surprise_id=surprise_id,
    )
    if eligible_miss_count < config.miss_count_window:
        return "miss_count_window"
    return None


async def _eligible_miss_count(
    *,
    connection: asyncpg.Connection,
    config: _ThresholdConfig,
    surprise_id: UUID,
) -> int:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
WITH anchor AS (
  SELECT created_at
  FROM surprise_stream
  WHERE id = $1
    AND tenant_id = $2
)
    SELECT count(*)::integer AS miss_count
    FROM surprise_stream raw
    JOIN anchor ON true
    JOIN nodes original
      ON original.id = raw.prediction_subject_id
     AND original.tenant_id = raw.tenant_id
    WHERE raw.tenant_id = $2
      AND raw.comparator_kind = 'classifier_missed_pattern4_decision'
      AND raw.domain = 'classifier-calibration'
      AND raw.task_type = $3
      AND raw.context_of_validity ->> 'ontology_version' = $5
      AND original.metadata #>> '{classifier,classifier_name}' = $6
      AND original.metadata #>> '{classifier,classifier_version}' = $7
      AND original.metadata #>> '{classifier,node_type_family}' = $3
      AND raw.created_at >= $4
      AND raw.created_at <= anchor.created_at
    """,
            surprise_id,
            config.tenant_id,
            config.node_type_family,
            config.active_from,
            str(config.ontology_version_id),
            config.classifier_name,
            config.classifier_version,
        ),
    )
    if row is None:
        return 0
    return cast(int, row["miss_count"])


async def _insert_threshold_successor(
    *,
    connection: asyncpg.Connection,
    config: _ThresholdConfig,
    surprise_id: UUID,
    occurred_at: datetime,
) -> UUID | None:
    if config.threshold >= config.max_threshold:
        return None

    new_threshold = min(config.max_threshold, config.threshold + config.tightening_step).quantize(
        Decimal("0.0001")
    )
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
WITH closed AS (
  UPDATE classifier_threshold_config
  SET active_to = $3
  WHERE id = $1
    AND tenant_id = $2
    AND active_to IS NULL
  RETURNING *
),
inserted AS (
  INSERT INTO classifier_threshold_config (
    tenant_id,
    ontology_version_id,
    classification,
    context_of_validity,
    node_type_family,
    classifier_name,
    classifier_version,
    config_version,
    threshold,
    min_threshold,
    max_threshold,
    tightening_step,
    sample_size_floor,
    miss_count_window,
    supersedes_config_id,
    created_from_surprise_id,
    active_from,
    created_by_system
  )
  SELECT
    tenant_id,
    ontology_version_id,
    classification,
    context_of_validity,
    node_type_family,
    classifier_name,
    classifier_version,
    config_version + 1,
    $4,
    min_threshold,
    max_threshold,
    tightening_step,
    sample_size_floor,
    miss_count_window,
    id,
    $5,
    $3,
    true
  FROM closed
  ON CONFLICT (created_from_surprise_id)
    WHERE created_from_surprise_id IS NOT NULL
  DO NOTHING
  RETURNING id
)
SELECT id FROM inserted
UNION ALL
SELECT id
FROM classifier_threshold_config
WHERE created_from_surprise_id = $5
  AND NOT EXISTS (SELECT 1 FROM inserted)
LIMIT 1
""",
            config.id,
            config.tenant_id,
            occurred_at,
            new_threshold,
            surprise_id,
        ),
    )
    if row is None:
        raise ClassifierCalibrationError("threshold_successor_insert_failed")
    return cast(UUID, row["id"])


async def _find_threshold_successor_for_surprise(
    *,
    connection: asyncpg.Connection,
    surprise_id: UUID,
) -> UUID | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id
FROM classifier_threshold_config
WHERE created_from_surprise_id = $1
""",
            surprise_id,
        ),
    )
    return None if row is None else cast(UUID, row["id"])


async def _find_existing_classifier_miss_surprise(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    original_node_id: UUID,
    review_decision_id: UUID,
) -> SurpriseRecordResult | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id, materialized_node_id
FROM surprise_stream
WHERE tenant_id = $1
  AND prediction_subject_type = 'node'
  AND prediction_subject_id = $2
  AND observation_subject_type = 'node'
  AND observation_subject_id = $3
  AND comparator_kind = 'classifier_missed_pattern4_decision'
  AND domain = 'classifier-calibration'
ORDER BY created_at ASC
LIMIT 1
""",
            tenant_id,
            original_node_id,
            review_decision_id,
        ),
    )
    if row is None:
        return None
    return SurpriseRecordResult(
        id=cast(UUID, row["id"]),
        inserted=False,
        materialized_node_id=cast(UUID | None, row["materialized_node_id"]),
        outbox_event=None,
    )


async def _mark_projection_stale(
    *,
    connection: asyncpg.Connection,
    draft: ClassifierMissedPattern4Draft,
    evidence: OriginalClassifierEvidence,
    surprise: SurpriseRecordResult,
    latest_threshold_config_id: UUID | None,
) -> UUID:
    subject_key = ":".join(
        (
            evidence.classifier_name,
            evidence.classifier_version,
            str(evidence.ontology_version_id),
            evidence.node_type_family,
        )
    )
    context_fingerprint = _context_fingerprint(draft.context_of_validity.model_dump(mode="json"))
    outbox_event_id = surprise.outbox_event.id if surprise.outbox_event is not None else None
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
INSERT INTO classifier_calibration_projection (
  tenant_id,
  classification,
  context_of_validity,
  subject_kind,
  subject_key,
  action,
  subject_type,
  scope,
  context_fingerprint,
  surprise_count,
  missed_pattern4_count,
  human_reviewed_outcome_count,
  sample_size,
  confidence_interval_bucket,
  projection_stale,
  latest_threshold_config_id,
  last_recompute_event_id,
  last_surprise_at
)
VALUES (
  $1,
  $2,
  $3::jsonb,
  'classifier-family',
  $4,
  'classify',
  'node',
  $5,
  $6,
  1,
  1,
  $7,
  $7,
  'unknown',
  true,
  $8,
  $9,
  $10
)
ON CONFLICT (
  tenant_id,
  subject_kind,
  subject_key,
  action,
  subject_type,
  scope,
  context_fingerprint
)
DO UPDATE SET
  surprise_count = classifier_calibration_projection.surprise_count + 1,
  missed_pattern4_count = classifier_calibration_projection.missed_pattern4_count + 1,
  human_reviewed_outcome_count =
    classifier_calibration_projection.human_reviewed_outcome_count
    + EXCLUDED.human_reviewed_outcome_count,
  sample_size = classifier_calibration_projection.sample_size + EXCLUDED.sample_size,
  projection_stale = true,
  latest_threshold_config_id = COALESCE(
    EXCLUDED.latest_threshold_config_id,
    classifier_calibration_projection.latest_threshold_config_id
  ),
  last_recompute_event_id = EXCLUDED.last_recompute_event_id,
  last_surprise_at = EXCLUDED.last_surprise_at,
  updated_at = now()
RETURNING id
""",
            draft.tenant_id,
            draft.context_of_validity.classification,
            _canonical_json_text(draft.context_of_validity.model_dump(mode="json")),
            subject_key,
            evidence.node_type_family,
            context_fingerprint,
            draft.human_reviewed_outcome_count,
            latest_threshold_config_id,
            outbox_event_id,
            draft.occurred_at,
        ),
    )
    if row is None:
        raise ClassifierCalibrationError("projection_stale_mark_failed")
    return cast(UUID, row["id"])


def _context_fingerprint(value: Mapping[str, object]) -> str:
    return hashlib.sha256(_canonical_json_text(value).encode("utf-8")).hexdigest()


def _json_mapping(value: object) -> Mapping[str, object]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if not isinstance(parsed, dict):
            raise ClassifierCalibrationError("json_object_expected")
        return cast(Mapping[str, object], parsed)
    if isinstance(value, Mapping):
        return cast(Mapping[str, object], value)
    raise ClassifierCalibrationError("json_object_expected")


def _canonical_json_text(value: object) -> str:
    return json.dumps(
        _normalize_json(value),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _normalize_json(value: object) -> object:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, datetime):
        return value.astimezone(UTC).replace(tzinfo=UTC).isoformat().replace("+00:00", "Z")
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        return {
            unicodedata.normalize("NFC", str(key)): _normalize_json(mapping[key])
            for key in sorted(mapping.keys(), key=str)
        }
    if isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
        sequence = cast(Sequence[object], value)
        return [_normalize_json(item) for item in sequence]
    return value
