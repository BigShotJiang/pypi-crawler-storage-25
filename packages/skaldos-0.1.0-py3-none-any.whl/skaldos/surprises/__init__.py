"""Slice 9 surprise stream primitives."""

from skaldos.surprises.stream import (
    LoopLevel,
    SubjectHandle,
    SurpriseContext,
    SurpriseRecordDraft,
    SurpriseRecordResult,
    SurpriseStreamError,
    SurpriseValidationError,
    build_surprise_recorded_envelope,
    derive_surprise_classification,
    surprise_idempotency_key,
    validate_surprise_record_draft,
    write_surprise_record,
)

__all__ = [
    "LoopLevel",
    "SubjectHandle",
    "SurpriseContext",
    "SurpriseRecordDraft",
    "SurpriseRecordResult",
    "SurpriseStreamError",
    "SurpriseValidationError",
    "build_surprise_recorded_envelope",
    "derive_surprise_classification",
    "surprise_idempotency_key",
    "validate_surprise_record_draft",
    "write_surprise_record",
]
