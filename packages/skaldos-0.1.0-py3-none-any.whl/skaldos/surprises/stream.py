"""Raw surprise stream service for Slice 9.

The raw stream stores predicted-vs-observed divergence as handles plus bounded
metadata. Event payloads remain strict Slice 8 ID-as-handle envelopes; consumers
dereference the raw ``surprise_stream.id`` through normal read paths.
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Annotated, Literal, Self, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.events.outbox import (
    OutboxContextOfValidity,
    OutboxEnvelope,
    OutboxInsertResult,
    insert_outbox_event,
)

Classification = Literal["C0", "C1", "C2", "C3", "C4"]
LoopLevel = Literal["single", "double", "triple"]
SubjectType = Literal["node", "execution-trace", "edge", "tag", "agent_run"]

_CLASSIFICATION_RANK: Mapping[Classification, int] = {
    "C0": 0,
    "C1": 1,
    "C2": 2,
    "C3": 3,
    "C4": 4,
}
_MATERIALIZATION_THRESHOLD = Decimal("0.75")


class SurpriseStreamError(RuntimeError):
    """Raised when surprise stream storage or event emission fails."""


class SurpriseValidationError(ValueError):
    """Raised when a surprise draft violates the Slice 9 boundary."""


class SurpriseContext(BaseModel):
    """First-class context-of-validity tuple copied to raw surprise rows."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant: UUID
    classification: Classification
    vertical: Annotated[str, Field(min_length=1, max_length=128)]
    ontology_version: UUID | Annotated[str, Field(min_length=1, max_length=128)]
    valid_from: datetime
    valid_to: datetime | None = None

    @field_validator("valid_from", "valid_to")
    @classmethod
    def _normalize_timestamp(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @model_validator(mode="after")
    def _validity_window_is_ordered(self) -> Self:
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError("invalid_validity_window")
        return self

    def to_outbox_context(self) -> OutboxContextOfValidity:
        return OutboxContextOfValidity.model_validate(self.model_dump(mode="python"))


class SubjectHandle(BaseModel):
    """Opaque reference to substrate evidence; never inline source content."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    subject_type: SubjectType
    subject_id: UUID


class SurpriseRecordDraft(BaseModel):
    """Validated request to append one raw surprise and emit one event."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    context_of_validity: SurpriseContext
    prediction: SubjectHandle
    observation: SubjectHandle
    comparator_kind: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")]
    magnitude: Decimal
    loop_level: LoopLevel
    domain: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")] | None = None
    task_type: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")] | None = None
    agent_run_id: UUID | None = None
    trace_id: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")] | None = None
    materialization_reason: (
        Literal["high_magnitude", "triple_loop", "human_referenced", "review_critical"] | None
    ) = None
    occurred_at: datetime

    @field_validator("occurred_at")
    @classmethod
    def _normalize_occurred_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @field_validator("magnitude", mode="before")
    @classmethod
    def _parse_magnitude(cls, value: object) -> Decimal:
        try:
            magnitude = Decimal(str(value))
        except (InvalidOperation, ValueError) as exc:
            raise ValueError("invalid_magnitude") from exc
        if not magnitude.is_finite() or magnitude < 0 or magnitude > 1:
            raise ValueError("invalid_magnitude")
        return magnitude.quantize(Decimal("0.0001"))

    @model_validator(mode="after")
    def _draft_context_matches_tenant(self) -> Self:
        if self.context_of_validity.tenant != self.tenant_id:
            raise ValueError("tenant_context_mismatch")
        return self

    @property
    def effective_materialization_reason(self) -> str | None:
        if self.materialization_reason is not None:
            return self.materialization_reason
        if self.loop_level == "triple":
            return "triple_loop"
        if self.magnitude >= _MATERIALIZATION_THRESHOLD:
            return "high_magnitude"
        return None


@dataclass(frozen=True, slots=True)
class SurpriseRecordResult:
    id: UUID
    inserted: bool
    materialized_node_id: UUID | None
    outbox_event: OutboxInsertResult | None


@dataclass(frozen=True, slots=True)
class _ResolvedSubject:
    tenant_id: UUID
    classification: Classification


def derive_surprise_classification(classifications: Sequence[Classification]) -> Classification:
    """Return the conservative max classification across source evidence."""

    if not classifications:
        raise SurpriseValidationError("classification_sources_required")
    return max(classifications, key=lambda value: _CLASSIFICATION_RANK[value])


def surprise_idempotency_key(draft: SurpriseRecordDraft) -> str:
    """Build the deterministic duplicate-suppression key for one divergence."""

    identity = {
        "tenant_id": str(draft.tenant_id),
        "prediction_subject_type": draft.prediction.subject_type,
        "prediction_subject_id": str(draft.prediction.subject_id),
        "observation_subject_type": draft.observation.subject_type,
        "observation_subject_id": str(draft.observation.subject_id),
        "comparator_kind": draft.comparator_kind,
        "magnitude": draft.magnitude,
        "loop_level": draft.loop_level,
        "context_of_validity": draft.context_of_validity.model_dump(mode="json"),
        "domain": draft.domain,
        "task_type": draft.task_type,
        "agent_run_id": str(draft.agent_run_id) if draft.agent_run_id is not None else None,
        "trace_id": draft.trace_id,
        "occurred_at": _canonical_timestamp(draft.occurred_at),
    }
    return hashlib.sha256(_canonical_json_bytes(identity)).hexdigest()


def validate_surprise_record_draft(
    draft: SurpriseRecordDraft,
    *,
    prediction: _ResolvedSubject,
    observation: _ResolvedSubject,
) -> SurpriseRecordDraft:
    """Validate resolved source handles against the requested context."""

    if prediction.tenant_id != draft.tenant_id or observation.tenant_id != draft.tenant_id:
        raise SurpriseValidationError("source_tenant_mismatch")
    derived_classification = derive_surprise_classification(
        (prediction.classification, observation.classification)
    )
    if derived_classification != draft.context_of_validity.classification:
        raise SurpriseValidationError("source_classification_mismatch")
    return draft


def build_surprise_recorded_envelope(
    draft: SurpriseRecordDraft, *, surprise_id: UUID
) -> OutboxEnvelope:
    """Build the strict handle-only `surprise.recorded` envelope."""

    return OutboxEnvelope(
        id_as_handle=True,
        event_type="surprise.recorded",
        subject_type="surprise",
        subject_id=surprise_id,
        tenant_id=draft.tenant_id,
        context_of_validity=draft.context_of_validity.to_outbox_context(),
        occurred_at=draft.occurred_at,
        intent="assertive",
    )


async def write_surprise_record(
    *,
    connection: asyncpg.Connection,
    draft: SurpriseRecordDraft,
) -> SurpriseRecordResult:
    """Append one surprise row and emit one same-transaction outbox event.

    Duplicate idempotency keys return the existing row and do not emit another
    event.
    """

    try:
        if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
            raise SurpriseStreamError("surprise_record_transaction_required")
        prediction = await _resolve_subject(connection, draft.prediction)
        observation = await _resolve_subject(connection, draft.observation)
        validate_surprise_record_draft(draft, prediction=prediction, observation=observation)
        row = cast(
            Mapping[str, object] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: surprise_stream insert carries tenant_id; RLS also applies.
WITH inserted AS (
  INSERT INTO surprise_stream (
    tenant_id,
    classification,
    context_of_validity,
    prediction_subject_type,
    prediction_subject_id,
    observation_subject_type,
    observation_subject_id,
    comparator_kind,
    magnitude,
    loop_level,
    domain,
    task_type,
    agent_run_id,
    trace_id,
    materialization_reason,
    idempotency_key
  )
  VALUES (
    $1, $2, $3::jsonb, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16
  )
  ON CONFLICT (tenant_id, idempotency_key) DO NOTHING
  RETURNING id, materialized_node_id, true AS inserted
)
SELECT id, materialized_node_id, inserted FROM inserted
UNION ALL
SELECT id, materialized_node_id, false AS inserted
FROM surprise_stream
WHERE tenant_id = $1
  AND idempotency_key = $16
  AND NOT EXISTS (SELECT 1 FROM inserted)
LIMIT 1
""",
                draft.tenant_id,
                draft.context_of_validity.classification,
                _canonical_json_text(draft.context_of_validity.model_dump(mode="json")),
                draft.prediction.subject_type,
                draft.prediction.subject_id,
                draft.observation.subject_type,
                draft.observation.subject_id,
                draft.comparator_kind,
                draft.magnitude,
                draft.loop_level,
                draft.domain,
                draft.task_type,
                draft.agent_run_id,
                draft.trace_id,
                draft.effective_materialization_reason,
                surprise_idempotency_key(draft),
            ),
        )
        if row is None:
            raise SurpriseStreamError("surprise_duplicate_not_visible")
        surprise_id = cast(UUID, row["id"])
        materialized_node_id = cast(UUID | None, row["materialized_node_id"])
        materialization_reason = draft.effective_materialization_reason
        if materialization_reason is not None:
            materialized_node_id = await _materialize_surprise_node(
                connection=connection,
                draft=draft,
                surprise_id=surprise_id,
                materialization_reason=materialization_reason,
            )
        inserted = bool(row["inserted"])
        if not inserted:
            return SurpriseRecordResult(
                id=surprise_id,
                inserted=False,
                materialized_node_id=materialized_node_id,
                outbox_event=None,
            )
        outbox_result = await insert_outbox_event(
            connection=connection,
            envelope=build_surprise_recorded_envelope(draft, surprise_id=surprise_id),
        )
        return SurpriseRecordResult(
            id=surprise_id,
            inserted=True,
            materialized_node_id=materialized_node_id,
            outbox_event=outbox_result,
        )
    except (SurpriseStreamError, SurpriseValidationError):
        raise
    except Exception as exc:
        raise SurpriseStreamError("surprise_record_write_failed") from exc


async def _materialize_surprise_node(
    *,
    connection: asyncpg.Connection,
    draft: SurpriseRecordDraft,
    surprise_id: UUID,
    materialization_reason: str,
) -> UUID:
    raw_row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: materialization locks one tenant-scoped surprise row.
SELECT materialized_node_id
FROM surprise_stream
WHERE id = $1
  AND tenant_id = $2
FOR UPDATE
""",
            surprise_id,
            draft.tenant_id,
        ),
    )
    if raw_row is None:
        raise SurpriseStreamError("surprise_materialization_row_not_visible")
    existing_node_id = cast(UUID | None, raw_row["materialized_node_id"])
    if existing_node_id is not None:
        return existing_node_id
    if not isinstance(draft.context_of_validity.ontology_version, UUID):
        raise SurpriseStreamError("surprise_materialization_requires_uuid_ontology")

    metadata = {
        "shape": "skaldos.surprise.v1",
        "raw_surprise_id": str(surprise_id),
        "prediction": draft.prediction.model_dump(mode="json"),
        "observation": draft.observation.model_dump(mode="json"),
        "comparator_kind": draft.comparator_kind,
        "magnitude": format(draft.magnitude, "f"),
        "loop_level": draft.loop_level,
        "materialization_reason": materialization_reason,
        "domain": draft.domain,
        "task_type": draft.task_type,
        "agent_run_id": str(draft.agent_run_id) if draft.agent_run_id is not None else None,
        "trace_id": draft.trace_id,
    }
    node_row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
WITH surprise_type AS (
  SELECT id
  FROM ontology_type
  WHERE ontology_version_id = $1
    AND name = 'surprise'
    AND lifecycle_state = 'active'
)
INSERT INTO nodes (
  type_id,
  context_of_validity,
  body,
  summary,
  metadata,
  authored_by_principal_id
)
SELECT
  surprise_type.id,
  $2::jsonb,
  '',
  'Surprise recorded',
  $3::jsonb,
  app.principal_id()
FROM surprise_type
RETURNING id
""",
            draft.context_of_validity.ontology_version,
            _canonical_json_text(draft.context_of_validity.model_dump(mode="json")),
            _canonical_json_text(metadata),
        ),
    )
    if node_row is None:
        raise SurpriseStreamError("surprise_node_type_not_found")
    node_id = cast(UUID, node_row["id"])
    updated_row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: materialization update is scoped by raw surprise id and tenant.
UPDATE surprise_stream
SET materialized_node_id = $3,
    materialization_reason = COALESCE(materialization_reason, $4)
WHERE id = $1
  AND tenant_id = $2
  AND materialized_node_id IS NULL
RETURNING materialized_node_id
""",
            surprise_id,
            draft.tenant_id,
            node_id,
            materialization_reason,
        ),
    )
    if updated_row is None:
        raise SurpriseStreamError("surprise_materialization_update_failed")
    return cast(UUID, updated_row["materialized_node_id"])


async def _resolve_subject(
    connection: asyncpg.Connection,
    handle: SubjectHandle,
) -> _ResolvedSubject:
    query = _subject_query(handle.subject_type)
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            query,
            handle.subject_id,
        ),
    )
    if row is None:
        raise SurpriseValidationError("source_handle_not_visible")
    return _ResolvedSubject(
        tenant_id=cast(UUID, row["tenant_id"]),
        classification=cast(Classification, row["classification"]),
    )


def _subject_query(subject_type: SubjectType) -> str:
    if subject_type == "node":
        return """
SELECT tenant_id, classification
FROM nodes
WHERE id = $1
  AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
  AND archived_at IS NULL
"""
    if subject_type == "execution-trace":
        return """
SELECT n.tenant_id, n.classification
FROM nodes n
JOIN ontology_type ot ON ot.id = n.type_id
    WHERE n.id = $1
      AND n.tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
      AND n.archived_at IS NULL
  AND ot.name = 'execution-trace'
"""
    if subject_type == "edge":
        return """
SELECT tenant_id, classification
FROM edges
WHERE id = $1
  AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
  AND archived_at IS NULL
"""
    if subject_type == "tag":
        return """
SELECT tenant_id, classification
FROM node_tags
WHERE id = $1
  AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
  AND superseded_by_tag_id IS NULL
"""
    if subject_type == "agent_run":
        return """
SELECT tenant_id, effective_clearance AS classification
FROM agent_run
WHERE id = $1
  AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
"""
    raise AssertionError(f"unsupported surprise subject type: {subject_type}")


def _canonical_timestamp(value: datetime) -> str:
    return value.astimezone(UTC).replace(tzinfo=UTC).isoformat().replace("+00:00", "Z")


def _canonical_json_bytes(value: object) -> bytes:
    return _canonical_json_text(value).encode("utf-8")


def _canonical_json_text(value: object) -> str:
    return json.dumps(
        _normalize_json(value),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _normalize_json(value: object) -> object:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, datetime):
        return _canonical_timestamp(value)
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dict):
        mapping = cast(Mapping[object, object], value)
        return {
            unicodedata.normalize("NFC", str(key)): _normalize_json(mapping[key])
            for key in sorted(mapping.keys(), key=str)
        }
    if isinstance(value, list):
        sequence = cast(Sequence[object], value)
        return [_normalize_json(item) for item in sequence]
    return value
