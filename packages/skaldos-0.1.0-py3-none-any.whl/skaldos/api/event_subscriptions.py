"""FastAPI routes for Slice 8 external event subscriptions."""

from __future__ import annotations

from typing import Annotated, Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos.api.target_tenant import target_tenant_from_body_or_query_field
from skaldos.events.subscription_store import (
    EventSubscriptionConflictError,
    EventSubscriptionNotFoundError,
    EventSubscriptionRecord,
    EventSubscriptionStorageError,
    EventSubscriptionStore,
)
from skaldos.events.subscriptions import (
    EndpointResolver,
    EventSubscriptionValidationError,
)
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize, load_event_subscription_by_id
from skaldos.policy.intent import Intent
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject, EventSubscriptionRow

router = APIRouter(tags=["events"])

_ALLOW_HTTP_FOR_TESTS = False
_ENDPOINT_RESOLVER: EndpointResolver | None = None


class EventSubscriptionCreateRequest(BaseModel):
    """Create payload for one external event subscription."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    subscriber_principal_id: UUID | None = None
    filter: dict[str, Any]
    delivery: dict[str, Any]
    state: Literal["active", "paused"] = "active"


class EventSubscriptionPatchRequest(BaseModel):
    """Patch payload for mutable registration fields."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    version: int = Field(ge=1)
    filter: dict[str, Any] | None = None
    delivery: dict[str, Any] | None = None
    state: Literal["active", "paused"] | None = None

    @model_validator(mode="after")
    def _has_change(self) -> EventSubscriptionPatchRequest:
        if self.filter is None and self.delivery is None and self.state is None:
            raise ValueError("event_subscription_patch_empty")
        return self


class EventSubscriptionTransitionRequest(BaseModel):
    """Optimistic lifecycle transition request."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    version: int = Field(ge=1)


class EventSubscriptionRepairRequest(BaseModel):
    """Repair a failed subscription and replace the push target."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    version: int = Field(ge=1)
    delivery: dict[str, Any]


class EventSubscriptionListResponse(BaseModel):
    """List response for tenant-scoped event subscriptions."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    subscriptions: tuple[EventSubscriptionRecord, ...]


async def _extract_event_subscription_target_tenant(request: Request) -> UUID:
    return await target_tenant_from_body_or_query_field(
        request,
        query_methods=frozenset({"GET"}),
    )


@router.post(
    "/event-subscriptions",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_201_CREATED,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        409: {"description": "An equivalent active subscription already exists."},
        422: {"description": "Subscription filter, endpoint, or subscriber principal is invalid."},
    },
)
async def post_event_subscription(
    body: EventSubscriptionCreateRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _event_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "create",
            AppSubject.EVENT_SUBSCRIPTION,
            intent=Intent.declarative,
            target_tenant_loader=_extract_event_subscription_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Create one tenant-scoped external subscription."""

    try:
        return await _subscription_store().create_subscription(
            connection=_request_connection(request),
            principal=principal,
            tenant_id=body.tenant_id,
            subscriber_principal_id=body.subscriber_principal_id,
            filter_payload=body.filter,
            delivery_payload=body.delivery,
            state=body.state,
        )
    except EventSubscriptionValidationError as exc:
        raise _validation_error(exc.reason_code) from exc
    except EventSubscriptionConflictError as exc:
        raise _conflict(str(exc)) from exc
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_create_failed") from exc


@router.get(
    "/event-subscriptions",
    response_model=EventSubscriptionListResponse,
    status_code=status.HTTP_200_OK,
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def list_event_subscriptions(
    tenant_id: UUID,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _event_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.EVENT_SUBSCRIPTION,
            target_tenant_loader=_extract_event_subscription_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
    include_archived: bool = False,
) -> EventSubscriptionListResponse:
    """List event subscriptions visible in one tenant through RLS."""

    try:
        subscriptions = await _subscription_store().list_subscriptions(
            connection=_request_connection(request),
            tenant_id=tenant_id,
            include_archived=include_archived,
        )
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_list_failed") from exc
    return EventSubscriptionListResponse(subscriptions=subscriptions)


@router.get(
    "/event-subscriptions/{subscription_id}",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Subscription was not found or is not visible."},
    },
)
async def get_event_subscription(
    subscription_id: UUID,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _event_subject: Annotated[
        EventSubscriptionRow,
        authorize(  # noqa: B008
            "read",
            AppSubject.EVENT_SUBSCRIPTION,
            subject_loader=load_event_subscription_by_id,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Load one active event subscription through RLS."""

    try:
        return await _subscription_store().get_subscription(
            connection=_request_connection(request),
            subscription_id=subscription_id,
        )
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_load_failed") from exc


@router.patch(
    "/event-subscriptions/{subscription_id}",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Subscription was not found or is not visible."},
        409: {"description": "Subscription version conflicted."},
        422: {"description": "Subscription patch is invalid."},
    },
)
async def patch_event_subscription(
    subscription_id: UUID,
    body: EventSubscriptionPatchRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    event_subject: Annotated[
        EventSubscriptionRow,
        authorize(  # noqa: B008
            "update",
            AppSubject.EVENT_SUBSCRIPTION,
            intent=Intent.declarative,
            subject_loader=load_event_subscription_by_id,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Patch filter, delivery target, or active/paused state."""

    try:
        return await _subscription_store().patch_subscription(
            connection=_request_connection(request),
            subscription_id=subscription_id,
            tenant_id=event_subject.organization_id,
            version=body.version,
            filter_payload=body.filter,
            delivery_payload=body.delivery,
            state=body.state,
        )
    except EventSubscriptionValidationError as exc:
        raise _validation_error(exc.reason_code) from exc
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionConflictError as exc:
        raise _conflict(str(exc)) from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_update_failed") from exc


@router.post(
    "/event-subscriptions/{subscription_id}/pause",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Subscription was not found or is not visible."},
        409: {"description": "Subscription transition conflicted."},
    },
)
async def pause_event_subscription(
    subscription_id: UUID,
    body: EventSubscriptionTransitionRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    event_subject: Annotated[
        EventSubscriptionRow,
        authorize(  # noqa: B008
            "pause",
            AppSubject.EVENT_SUBSCRIPTION,
            intent=Intent.declarative,
            subject_loader=load_event_subscription_by_id,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Pause an active or failed subscription without archiving it."""

    try:
        return await _subscription_store().transition_subscription(
            connection=_request_connection(request),
            subscription_id=subscription_id,
            tenant_id=event_subject.organization_id,
            version=body.version,
            action="pause",
        )
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionConflictError as exc:
        raise _conflict(str(exc)) from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_pause_failed") from exc


@router.post(
    "/event-subscriptions/{subscription_id}/resume",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Subscription was not found or is not visible."},
        409: {"description": "Subscription transition conflicted."},
    },
)
async def resume_event_subscription(
    subscription_id: UUID,
    body: EventSubscriptionTransitionRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    event_subject: Annotated[
        EventSubscriptionRow,
        authorize(  # noqa: B008
            "resume",
            AppSubject.EVENT_SUBSCRIPTION,
            intent=Intent.declarative,
            subject_loader=load_event_subscription_by_id,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Resume a paused subscription. Failed subscriptions require repair."""

    try:
        return await _subscription_store().transition_subscription(
            connection=_request_connection(request),
            subscription_id=subscription_id,
            tenant_id=event_subject.organization_id,
            version=body.version,
            action="resume",
        )
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionConflictError as exc:
        raise _conflict(str(exc)) from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_resume_failed") from exc


@router.post(
    "/event-subscriptions/{subscription_id}/repair",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Subscription was not found or is not visible."},
        409: {"description": "Subscription transition conflicted."},
        422: {"description": "Replacement delivery target is invalid."},
    },
)
async def repair_event_subscription(
    subscription_id: UUID,
    body: EventSubscriptionRepairRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    event_subject: Annotated[
        EventSubscriptionRow,
        authorize(  # noqa: B008
            "resume",
            AppSubject.EVENT_SUBSCRIPTION,
            intent=Intent.declarative,
            subject_loader=load_event_subscription_by_id,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Reactivate a failed subscription after validating a replacement target."""

    try:
        return await _subscription_store().repair_subscription(
            connection=_request_connection(request),
            subscription_id=subscription_id,
            tenant_id=event_subject.organization_id,
            version=body.version,
            delivery_payload=body.delivery,
        )
    except EventSubscriptionValidationError as exc:
        raise _validation_error(exc.reason_code) from exc
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionConflictError as exc:
        raise _conflict(str(exc)) from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_repair_failed") from exc


@router.delete(
    "/event-subscriptions/{subscription_id}",
    response_model=EventSubscriptionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Subscription was not found or is not visible."},
        409: {"description": "Subscription version conflicted."},
    },
)
async def archive_event_subscription(
    subscription_id: UUID,
    version: int,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    event_subject: Annotated[
        EventSubscriptionRow,
        authorize(  # noqa: B008
            "archive",
            AppSubject.EVENT_SUBSCRIPTION,
            intent=Intent.declarative,
            subject_loader=load_event_subscription_by_id,
            tier=Tier.STANDARD,
        ),
    ],
) -> EventSubscriptionRecord:
    """Archive a subscription without deleting its registration history."""

    try:
        return await _subscription_store().archive_subscription(
            connection=_request_connection(request),
            subscription_id=subscription_id,
            tenant_id=event_subject.organization_id,
            version=version,
        )
    except EventSubscriptionNotFoundError as exc:
        raise _not_found() from exc
    except EventSubscriptionConflictError as exc:
        raise _conflict(str(exc)) from exc
    except EventSubscriptionStorageError as exc:
        raise _server_error(str(exc) or "event_subscription_archive_failed") from exc


def _subscription_store() -> EventSubscriptionStore:
    return EventSubscriptionStore(
        allow_http_for_tests=_ALLOW_HTTP_FOR_TESTS,
        endpoint_resolver=_ENDPOINT_RESOLVER,
    )


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise _server_error("principal_transaction_missing")
    return cast(asyncpg.Connection, connection)


def _validation_error(reason_code: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        detail={"error_code": reason_code, "reason_code": reason_code},
    )


def _conflict(reason_code: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail={"error_code": reason_code, "reason_code": reason_code},
    )


def _not_found() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail={"error_code": "not_found", "reason_code": "not_found"},
    )


def _server_error(reason_code: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail={"error_code": reason_code, "reason_code": reason_code},
    )


__all__ = [
    "EventSubscriptionCreateRequest",
    "EventSubscriptionListResponse",
    "EventSubscriptionPatchRequest",
    "EventSubscriptionRepairRequest",
    "EventSubscriptionTransitionRequest",
    "archive_event_subscription",
    "get_event_subscription",
    "list_event_subscriptions",
    "patch_event_subscription",
    "pause_event_subscription",
    "post_event_subscription",
    "repair_event_subscription",
    "resume_event_subscription",
    "router",
]
