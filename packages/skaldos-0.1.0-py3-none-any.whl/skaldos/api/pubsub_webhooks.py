"""Signed Pub/Sub push subscriber endpoint for Phase 1.25 staging proof."""

from __future__ import annotations

from typing import cast

import httpx
from fastapi import APIRouter, HTTPException, Request, Response, status

from skaldos.events.push_subscriber import (
    GoogleOidcTokenVerifier,
    PushSubscriberConfigError,
    PushSubscriberService,
    SubscriberApiRefetchClient,
    config_from_env,
)

router = APIRouter(tags=["events"])


@router.post(
    "/webhooks/pubsub/events",
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        204: {"description": "Delivery was accepted, deduped, or safely denied at refetch."},
        401: {"description": "Google OIDC verification failed."},
        403: {"description": "SkaldOS HMAC verification failed."},
        422: {"description": "Push body or event handle was malformed."},
        503: {"description": "Subscriber config or refetch dependency failed."},
    },
)
async def post_pubsub_event_webhook(request: Request) -> Response:
    """Receive one no-wrapper Pub/Sub push and refetch through the API."""

    raw_body = await request.body()
    try:
        service = _subscriber_service(request)
        receipt = await service.receive_push(
            authorization_header=request.headers.get("Authorization"),
            headers=request.headers,
            raw_body=raw_body,
        )
    except PushSubscriberConfigError as exc:
        raise _error(status.HTTP_503_SERVICE_UNAVAILABLE, str(exc)) from exc

    if receipt.accepted or receipt.duplicate or receipt.reason_code == "subscriber_refetch_denied":
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    if receipt.reason_code == "pubsub_push_body_invalid":
        raise _error(status.HTTP_422_UNPROCESSABLE_CONTENT, receipt.reason_code)
    if receipt.reason_code and receipt.reason_code.startswith("pubsub_push_oidc_"):
        raise _error(status.HTTP_401_UNAUTHORIZED, receipt.reason_code)
    if receipt.reason_code and (
        receipt.reason_code.startswith("pubsub_push_signature_")
        or receipt.reason_code.startswith("pubsub_push_event_id_")
        or receipt.reason_code == "pubsub_push_header_missing"
    ):
        raise _error(status.HTTP_403_FORBIDDEN, receipt.reason_code)
    raise _error(status.HTTP_503_SERVICE_UNAVAILABLE, receipt.reason_code or "subscriber_rejected")


def _subscriber_service(request: Request) -> PushSubscriberService:
    configured = getattr(request.app.state, "pubsub_push_subscriber_service", None)
    if configured is not None:
        return cast(PushSubscriberService, configured)
    config = config_from_env()
    http_client = getattr(request.app.state, "pubsub_push_subscriber_http_client", None)
    if http_client is None:
        http_client = httpx.AsyncClient(timeout=config.http_timeout_seconds)
        request.app.state.pubsub_push_subscriber_http_client = http_client
    service = PushSubscriberService(
        config=config,
        refetch_client=SubscriberApiRefetchClient(
            config=config,
            http_client=cast(httpx.AsyncClient, http_client),
        ),
        oidc_token_verifier=GoogleOidcTokenVerifier(),
    )
    request.app.state.pubsub_push_subscriber_service = service
    return service


def _error(status_code: int, reason_code: str) -> HTTPException:
    return HTTPException(
        status_code=status_code,
        detail={"error_code": reason_code, "reason_code": reason_code},
    )


__all__ = ["post_pubsub_event_webhook", "router"]
