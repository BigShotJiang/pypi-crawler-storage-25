"""FastAPI routes for ``GET /me`` and ``GET /me/tenants`` (slice-frontend-api-gaps).

Per ``docs/slices/slice-frontend-api-gaps/03-technical-implementation.md``
§ "Module layout" → ``services/api/skaldos/api/me.py``: this module owns
the two identity-projection routes the Phase 2 frontend's app shell
calls on every authenticated page load.

Why a separate router from ``/whoami``
---------------------------------------

``/whoami`` (``services/api/skaldos/api/whoami.py``) is the **Slice 1
chokepoint gate target** --- a minimal handler that exercises the full
chokepoint, gated off in production at route-registration time so
identity surfaces don't leak via API once a production frontend
exists. The Slice 1 master plan's ADR resolution pinned that posture
and the two-tenant verification test relies on the ``/whoami`` shape
unchanged.

``/me`` is the **production frontend's identity surface**. It is
registered in *all* environments (production included), is the
canonical "who am I" call the Phase 2 frontend's app shell makes on
every page load, and emits a wider projection (display label, email
fingerprint) than ``/whoami`` does. The two routes share the same
chokepoint dependency (:func:`current_principal`) and rate-limit tier
but otherwise have different lifecycle gates.

Per the brainstorm E25 ("Two-tenant verification still passes"): PR0
does NOT modify ``/whoami``; the Slice 1 gate target stays pointed
there. ``/me`` is purely additive.

Why bare ``Depends(current_principal)`` (no ``Depends(authorize)``)
--------------------------------------------------------------------

Both ``/me`` and ``/me/tenants`` are **self-projections** --- they
return the principal's own identity / membership data, not a tenant-
scoped subject read. Pinning the routes behind ``Depends(authorize)``
would require a subject (the principal? a Membership row?) that
doesn't correspond to the read's semantics. ``/whoami`` makes the
same choice and is the canonical-route example for this pattern
(``WHOAMI_ROUTES`` in the route-protection audit's third disjoint-set
category alongside ``PUBLIC_ROUTES`` and the full
``Depends(authorize(...))`` set).

The chokepoint still runs: ``Depends(current_principal)`` performs
JWT verification (401 on missing/invalid token), principal hydration
(403 on disabled principal), and the PC1 GUC commit (500 on commit
failure). The route handler runs only after all three pass.

Per the route-protection audit (``test_route_protection_audit.py``):
the audit walks every route on the assembled app and asserts each
non-public route declares :func:`current_principal` in its dependency
tree. ``/me`` and ``/me/tenants`` satisfy this requirement; they do
not need to be added to the ``WHOAMI_ROUTES`` allowlist because they
are not gated against ``Depends(authorize)`` --- they are simply
``Depends(current_principal)`` routes (the audit's "directly or
transitively declares current_principal" rule is satisfied directly).

Production-safe; no env gate
----------------------------

The router is registered unconditionally in ``services/api/skaldos/app.py``
(no ``if SKALDOS_ENV != "production"`` branch). E24 / AP5: the route
is available in every environment; access is governed by the
chokepoint, not by env. This is the structural difference from
``/whoami`` --- whoami is structurally absent in production
(``register_whoami_if_enabled``); ``/me`` is structurally present
everywhere.

References
----------

- ``docs/slices/slice-frontend-api-gaps/01-user-stories.md`` S1, S2, S3.
- ``docs/slices/slice-frontend-api-gaps/02-edge-cases.md`` E1, E2, E3,
  E4, E5, E6, E7, E8, E9, E10, E11, E12, E22, E23, E24.
- ``docs/slices/slice-frontend-api-gaps/03-technical-implementation.md``
  § "Happy-path walkthrough", § "Error-management plan", § "Fault lines".
- §3.1 (plural-tenant principal); §4.1 (chokepoint); §10.2 (OpenAPI as
  contract); §13.6 / §20.2 (PII discipline); MP10 (humans + agents
  same shape); AP4 (verified end-to-end); AP5 (no debug bypass).
"""

from __future__ import annotations

from typing import Annotated, cast

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Request, status

from skaldos.api.read_contracts import ReadAPIRoute, read_route_error, read_route_error_response
from skaldos.graph.projections import (
    IdentityProjectionService,
    MeResponse,
    MeTenantsResponse,
)
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES

router = APIRouter(tags=["identity"], route_class=ReadAPIRoute)
"""The :class:`fastapi.APIRouter` carrying ``GET /me`` and
``GET /me/tenants``. Module-level so ``services/api/skaldos/app.py``
can ``include_router`` unconditionally (no env gate per E24 / AP5).

``route_class=ReadAPIRoute`` ensures every error path on these routes
renders the top-level :class:`ReadRouteErrorResponse` envelope rather
than FastAPI's default ``{"detail": ...}`` shape. Slice 11's
read-api-client-contracts work shipped the envelope; this router
consumes it so the Phase 2 frontend has a single error parser for
all read routes (S5)."""


@router.get(
    "/me",
    response_model=MeResponse,
    status_code=status.HTTP_200_OK,
    summary="Return the resolved principal's identity projection.",
    description=(
        "Production-safe identity surface for the Phase 2 frontend. "
        "Returns a projection of the resolved principal --- six fields "
        "the frontend's app shell needs at first paint: principal id, "
        "kind (human/agent), primary tenant id, visible tenant ids, "
        "email fingerprint (deterministic hash; the raw email never "
        "leaves the substrate), and a display label. "
        "Registered in every environment including production; access "
        "is governed by the chokepoint, not the env. "
        "Unlike /whoami (the Slice 1 chokepoint gate target, gated off "
        "in production), /me is the canonical identity surface for "
        "production callers."
    ),
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        500: read_route_error_response("Identity projection failed."),
    },
)
async def get_me(
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
) -> MeResponse:
    """Return the resolved principal's identity projection.

    The chokepoint runs ahead of this handler (see
    :mod:`skaldos.middleware.hydration` for the full lifecycle).
    On the happy path the handler reads the principal's row to
    pick up the ``email_fingerprint`` column (added by the
    slice-frontend-api-gaps migration; the Slice 1 ``Principal``
    model does not yet carry it) and projects to :class:`MeResponse`.

    Raises:
        :class:`~skaldos.api.read_contracts.ReadRouteHTTPException`:
            500 with ``error_code="identity_projection_failed"`` when
            the underlying query raises (asyncpg pool timeout,
            connection drop, etc.). The chokepoint's 401/403/503
            envelope shapes are upstream and inherited via the
            ``PROTECTED_ROUTE_RESPONSES`` floor.
    """
    try:
        return await IdentityProjectionService().build_me_response(
            connection=_request_connection(request),
            principal=principal,
        )
    except asyncpg.PostgresError as exc:  # pragma: no cover - infrastructure failure
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="identity_projection_failed",
            message="Identity projection failed.",
        ) from exc


@router.get(
    "/me/tenants",
    response_model=MeTenantsResponse,
    status_code=status.HTTP_200_OK,
    summary="Return the principal's visible non-archived tenants.",
    description=(
        "Lists the tenants the calling principal can read (RLS "
        "enforces visibility; the handler trusts the query). Excludes "
        "archived tenants. Includes an active_tenant_id hint the "
        "frontend renders as the first-paint default; the hint is "
        "non-authoritative (a future Slice C feature will define "
        "server-side active-tenant persistence)."
    ),
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        500: read_route_error_response("Tenant projection failed."),
    },
)
async def get_me_tenants(
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
) -> MeTenantsResponse:
    """Return the principal's visible-non-archived tenants + active hint.

    F3: the query runs on the request's GUC-bound connection so RLS
    sees the right principal context. The chokepoint's
    ``tenants_visible_to_principal`` policy filters to the visible
    set; the handler's explicit ``id = ANY($1)`` is defense-in-depth.

    Raises:
        :class:`~skaldos.api.read_contracts.ReadRouteHTTPException`:
            500 with ``error_code="tenants_projection_failed"`` when
            the underlying query raises.
    """
    try:
        return await IdentityProjectionService().build_me_tenants_response(
            connection=_request_connection(request),
            principal=principal,
        )
    except asyncpg.PostgresError as exc:  # pragma: no cover - infrastructure failure
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="tenants_projection_failed",
            message="Tenant projection failed.",
        ) from exc


def _request_connection(request: Request) -> asyncpg.Connection:
    """Pull the GUC-bound connection out of request state (F3).

    Mirrors the helper in ``graph_traverse.py``. The chokepoint
    stashes the runtime connection on ``request.state.connection``
    after committing the PC1 GUCs; the handler reads from there so
    every query runs under the principal's tenant + classification
    context.

    Raises:
        :class:`~skaldos.api.read_contracts.ReadRouteHTTPException`:
            500 with ``error_code="principal_transaction_missing"``
            when the connection is absent (substrate-integrity bug;
            the chokepoint should always stash it before yielding).
    """
    connection = getattr(request.state, "connection", None)
    if connection is None:  # pragma: no cover - chokepoint invariant
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="principal_transaction_missing",
            message="Principal transaction context is unavailable.",
        )
    return cast(asyncpg.Connection, connection)


__all__ = ["router", "get_me", "get_me_tenants"]
