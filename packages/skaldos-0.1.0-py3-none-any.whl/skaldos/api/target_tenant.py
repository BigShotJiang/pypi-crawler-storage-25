"""Shared target-tenant extraction helpers for protected route chokepoints."""

from __future__ import annotations

import json
from typing import Any, cast
from uuid import UUID

from fastapi import HTTPException, Request, status


def target_tenant_unprocessable(reason_code: str) -> HTTPException:
    """Return the canonical 422 body for target-tenant loader failures."""
    return HTTPException(
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        detail={"error_code": reason_code, "reason_code": reason_code},
    )


def parse_target_tenant_id(value: str, *, invalid_reason_code: str = "tenant_id_invalid") -> UUID:
    """Parse a target tenant UUID with the protected-route error shape."""
    try:
        return UUID(value)
    except ValueError as exc:
        raise target_tenant_unprocessable(invalid_reason_code) from exc


async def target_tenant_from_body_field(
    request: Request,
    *,
    field_name: str = "tenant_id",
    required_reason_code: str = "tenant_id_required",
    invalid_reason_code: str = "tenant_id_invalid",
    cache_state_attr: str | None = None,
) -> UUID:
    """Extract a tenant UUID from a JSON request body field."""
    parsed = await _json_object_body(request, required_reason_code=required_reason_code)
    tenant_id = parsed.get(field_name)
    if not isinstance(tenant_id, str):
        raise target_tenant_unprocessable(required_reason_code)
    parsed_tenant_id = parse_target_tenant_id(tenant_id, invalid_reason_code=invalid_reason_code)
    if cache_state_attr is not None:
        setattr(request.state, cache_state_attr, parsed_tenant_id)
    return parsed_tenant_id


def target_tenant_from_query_field(
    request: Request,
    *,
    field_name: str = "tenant_id",
    required_reason_code: str = "tenant_id_required",
    invalid_reason_code: str = "tenant_id_invalid",
) -> UUID:
    """Extract a tenant UUID from a query parameter."""
    tenant_id = request.query_params.get(field_name)
    if tenant_id is None:
        raise target_tenant_unprocessable(required_reason_code)
    return parse_target_tenant_id(tenant_id, invalid_reason_code=invalid_reason_code)


async def target_tenant_from_body_or_query_field(
    request: Request,
    *,
    query_methods: frozenset[str] = frozenset({"GET", "DELETE"}),
    field_name: str = "tenant_id",
    required_reason_code: str = "tenant_id_required",
    invalid_reason_code: str = "tenant_id_invalid",
) -> UUID:
    """Extract a tenant UUID from query parameters for read/delete, else body."""
    if request.method in query_methods:
        return target_tenant_from_query_field(
            request,
            field_name=field_name,
            required_reason_code=required_reason_code,
            invalid_reason_code=invalid_reason_code,
        )
    return await target_tenant_from_body_field(
        request,
        field_name=field_name,
        required_reason_code=required_reason_code,
        invalid_reason_code=invalid_reason_code,
    )


async def target_tenant_from_assertion_context(
    request: Request,
    *,
    required_reason_code: str = "context_of_validity_required",
    invalid_reason_code: str = "context_of_validity_tenant_invalid",
) -> UUID:
    """Extract ``claim.context[_of_validity].tenant`` from ``/graph/assert`` input."""
    parsed = await _json_object_body(request, required_reason_code=required_reason_code)
    claim = parsed.get("claim")
    if not isinstance(claim, dict):
        raise target_tenant_unprocessable(required_reason_code)

    claim_body = cast(dict[str, Any], claim)
    for key in ("context_of_validity", "context"):
        context = claim_body.get(key)
        if not isinstance(context, dict):
            continue
        tenant = cast(dict[str, Any], context).get("tenant")
        if not isinstance(tenant, str):
            continue
        return parse_target_tenant_id(tenant, invalid_reason_code=invalid_reason_code)

    raise target_tenant_unprocessable(required_reason_code)


async def _json_object_body(
    request: Request,
    *,
    required_reason_code: str,
) -> dict[str, Any]:
    body_bytes = await request.body()
    if not body_bytes:
        raise target_tenant_unprocessable(required_reason_code)
    try:
        parsed: Any = json.loads(body_bytes)
    except json.JSONDecodeError as exc:
        raise target_tenant_unprocessable(required_reason_code) from exc
    if not isinstance(parsed, dict):
        raise target_tenant_unprocessable(required_reason_code)
    return cast(dict[str, Any], parsed)
