"""FastAPI routes for Slice 6 context assembly and metric queries."""

from __future__ import annotations

from typing import Annotated, Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Request, status
from pydantic import BaseModel, ConfigDict, Field

from skaldos.api.read_contracts import ReadAPIRoute, read_route_error, read_route_error_response
from skaldos.api.target_tenant import target_tenant_from_body_field
from skaldos.graph.context_assembly import (
    ContextAssemblyRequest,
    ContextAssemblyService,
    ContextBundle,
    MetricDefinitionNotFoundError,
    MetricQueryRequest,
    MetricQueryStorageError,
    MetricResult,
    MixedCurrencyMetricError,
)
from skaldos.graph.context_shield_handoff import (
    ContextShieldAnswer,
    ContextShieldFailureReason,
    ContextShieldHandoffRequest,
    ContextShieldHandoffService,
    ContextShieldNonAnswer,
)
from skaldos.graph.read_audit import ReadAuditWriteError
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject
from skaldos.shield_client import ShieldClient
from skaldos_shield.contracts import SensitivityTier

router = APIRouter(tags=["graph"], route_class=ReadAPIRoute)


class ContextAnswerRequest(ContextAssemblyRequest):
    """Request for assembling context and answering via canonical Shield."""

    question: str = Field(min_length=1, max_length=8000)
    requested_sensitivity: SensitivityTier | None = None
    trace_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{32}$")
    span_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{16}$")


class ContextAnswerResponse(BaseModel):
    """Answer route response with assembled visible context."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: Literal["answer", "non_answer"]
    answer: str | None = None
    reason_code: ContextShieldFailureReason | None = None
    shield_call_id: UUID
    context: ContextBundle
    trace_id: str | None = None


async def _extract_context_target_tenant(request: Request) -> UUID:
    return await _extract_body_tenant_id(request)


async def _extract_metric_target_tenant(request: Request) -> UUID:
    return await _extract_body_tenant_id(request)


@router.post(
    "/graph/context",
    response_model=ContextBundle,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        500: read_route_error_response(
            "Context assembly failed or required C2+ read audit could not be written."
        ),
    },
)
async def post_graph_context(
    body: ContextAssemblyRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_context_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> ContextBundle:
    """Assemble visible tag spans into a context bundle."""

    try:
        return await ContextAssemblyService().assemble_context(
            connection=_request_connection(request),
            principal=principal,
            request=body,
        )
    except ReadAuditWriteError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="audit_write_failed",
            message="Required read audit evidence could not be written.",
        ) from exc
    except MetricQueryStorageError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="context_assembly_failed",
            message="Context assembly failed.",
        ) from exc


@router.post(
    "/graph/context/answer",
    response_model=ContextAnswerResponse,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        500: read_route_error_response(
            "Context answer failed or required C2+ read audit could not be written."
        ),
        503: read_route_error_response(
            "Canonical Shield is unavailable or did not produce call evidence."
        ),
    },
)
async def post_graph_context_answer(
    body: ContextAnswerRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_context_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> ContextAnswerResponse:
    """Assemble visible context, then answer only through canonical Shield."""

    shield_client = _request_shield_client(request)
    try:
        context_bundle = await ContextAssemblyService().assemble_context(
            connection=_request_connection(request),
            principal=principal,
            request=ContextAssemblyRequest.model_validate(
                body.model_dump(
                    exclude={"question", "requested_sensitivity", "trace_id", "span_id"}
                )
            ),
        )
    except ReadAuditWriteError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="audit_write_failed",
            message="Required read audit evidence could not be written.",
        ) from exc
    except MetricQueryStorageError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="context_assembly_failed",
            message="Context assembly failed.",
        ) from exc

    try:
        shield_result = await ContextShieldHandoffService(shield_client).answer_from_context(
            context_bundle=context_bundle,
            request=ContextShieldHandoffRequest(
                question=body.question,
                tenant_id=body.tenant_id,
                principal_id=principal.id,
                requested_sensitivity=body.requested_sensitivity,
                trace_id=body.trace_id,
                span_id=body.span_id,
            ),
        )
    except Exception as exc:
        raise read_route_error(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            error_code="shield_unavailable",
            message="Canonical Shield is unavailable.",
        ) from exc

    return _context_answer_response(context_bundle=context_bundle, shield_result=shield_result)


@router.post(
    "/graph/metrics/query",
    response_model=MetricResult,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Metric tag definition was not found or is not visible."),
        422: read_route_error_response(
            "Metric request is malformed or cannot be safely aggregated."
        ),
        500: read_route_error_response(
            "Metric query failed or required C2+ read audit could not be written."
        ),
    },
)
async def post_graph_metric_query(
    body: MetricQueryRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_metric_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> MetricResult:
    """Query a constrained metric over visible tag spans."""

    try:
        return await ContextAssemblyService().query_metric(
            connection=_request_connection(request),
            principal=principal,
            request=body,
        )
    except MetricDefinitionNotFoundError as exc:
        raise read_route_error(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="not_found",
            message="Metric tag definition was not found or is not visible.",
        ) from exc
    except MixedCurrencyMetricError as exc:
        raise read_route_error(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            error_code="metric_mixed_currency",
            message="Metric request spans mixed currencies.",
        ) from exc
    except ReadAuditWriteError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="audit_write_failed",
            message="Required read audit evidence could not be written.",
        ) from exc
    except MetricQueryStorageError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="metric_query_failed",
            message="Metric query failed.",
        ) from exc


async def _extract_body_tenant_id(request: Request) -> UUID:
    return await target_tenant_from_body_field(request)


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="principal_transaction_missing",
            message="Principal transaction context is unavailable.",
        )
    return cast(asyncpg.Connection, connection)


def _request_shield_client(request: Request) -> ShieldClient:
    shield_client = getattr(request.app.state, "shield_client", None)
    if not isinstance(shield_client, ShieldClient):
        raise read_route_error(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            error_code="context_answer_shield_unconfigured",
            message="Canonical Shield client is not configured.",
        )
    return shield_client


def _context_answer_response(
    *,
    context_bundle: ContextBundle,
    shield_result: ContextShieldAnswer | ContextShieldNonAnswer,
) -> ContextAnswerResponse:
    if isinstance(shield_result, ContextShieldAnswer):
        return ContextAnswerResponse(
            kind=shield_result.kind,
            answer=shield_result.answer,
            shield_call_id=shield_result.shield_call_id,
            context=context_bundle,
            trace_id=shield_result.trace_id,
        )
    return ContextAnswerResponse(
        kind=shield_result.kind,
        reason_code=shield_result.reason_code,
        shield_call_id=shield_result.shield_call_id,
        context=context_bundle,
        trace_id=shield_result.trace_id,
    )


__all__ = [
    "ContextAnswerRequest",
    "ContextAnswerResponse",
    "router",
    "post_graph_context",
    "post_graph_context_answer",
    "post_graph_metric_query",
]
