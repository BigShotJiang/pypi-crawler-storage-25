"""Route-local read API response contracts for Slice 11."""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from typing import Any

from fastapi import Request
from fastapi.exceptions import HTTPException
from fastapi.routing import APIRoute
from pydantic import BaseModel, ConfigDict, Field
from starlette.responses import JSONResponse, Response

from skaldos.agents.contracts import JsonValue


class ReadRouteErrorResponse(BaseModel):
    """Top-level route-local error envelope for read API failures."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    error_code: str
    reason_code: str
    message: str
    details: dict[str, JsonValue] = Field(default_factory=dict)


class ReadPage(BaseModel):
    """Content-free pagination page metadata."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    limit: int = Field(ge=0)
    has_more: bool
    next_cursor: str | None = None


class ReadRouteHTTPException(HTTPException):
    """HTTPException variant rendered as a top-level read-route envelope."""

    def __init__(
        self,
        *,
        status_code: int,
        error_code: str,
        reason_code: str | None = None,
        message: str,
        details: dict[str, JsonValue] | None = None,
    ) -> None:
        resolved_reason_code = reason_code if reason_code is not None else error_code
        self.envelope = ReadRouteErrorResponse(
            error_code=error_code,
            reason_code=resolved_reason_code,
            message=message,
            details=details or {},
        )
        super().__init__(status_code=status_code, detail=self.envelope.model_dump(mode="json"))


class ReadAPIRoute(APIRoute):
    """Render read-route exceptions without FastAPI's nested ``detail`` wrapper."""

    def get_route_handler(self) -> Callable[[Request], Coroutine[Any, Any, Response]]:
        original_handler = super().get_route_handler()

        async def custom_handler(request: Request) -> Response:
            try:
                return await original_handler(request)
            except ReadRouteHTTPException as exc:
                return JSONResponse(
                    status_code=exc.status_code,
                    content=exc.envelope.model_dump(mode="json"),
                )

        return custom_handler


def read_route_error(
    *,
    status_code: int,
    error_code: str,
    reason_code: str | None = None,
    message: str,
    details: dict[str, JsonValue] | None = None,
) -> ReadRouteHTTPException:
    """Create a route-local read error with a stable top-level envelope."""

    return ReadRouteHTTPException(
        status_code=status_code,
        error_code=error_code,
        reason_code=reason_code if reason_code is not None else error_code,
        message=message,
        details=details,
    )


def read_route_error_response(description: str) -> dict[str, Any]:
    """OpenAPI response entry for route-local read errors."""

    return {
        "model": ReadRouteErrorResponse,
        "description": description,
    }


__all__ = [
    "ReadAPIRoute",
    "ReadPage",
    "ReadRouteErrorResponse",
    "ReadRouteHTTPException",
    "read_route_error",
    "read_route_error_response",
]
