"""FastAPI route for protected source node snapshots."""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Request, status

from skaldos.agents.read_summarize import ReadAndSummarizeSourceSnapshot
from skaldos.api.read_contracts import ReadAPIRoute, read_route_error, read_route_error_response
from skaldos.api.target_tenant import target_tenant_from_body_field
from skaldos.graph.node_snapshot import (
    NodeSourceSnapshotNotFoundError,
    NodeSourceSnapshotQueryError,
    NodeSourceSnapshotRequest,
    NodeSourceSnapshotService,
)
from skaldos.graph.read_audit import ReadAuditWriteError
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject

router = APIRouter(tags=["graph"], route_class=ReadAPIRoute)


async def _extract_source_snapshot_target_tenant(request: Request) -> UUID:
    return await target_tenant_from_body_field(request)


@router.post(
    "/graph/source-snapshot",
    response_model=ReadAndSummarizeSourceSnapshot,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Source node was not found or is not visible."),
        500: read_route_error_response("Snapshot read failed or required C2+ audit failed."),
    },
)
async def post_graph_source_snapshot(
    body: NodeSourceSnapshotRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_source_snapshot_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> ReadAndSummarizeSourceSnapshot:
    """Read one visible node body/version/hash snapshot through the read chokepoint."""

    try:
        return await NodeSourceSnapshotService().read_snapshot(
            connection=_request_connection(request),
            principal=principal,
            request=body,
        )
    except NodeSourceSnapshotNotFoundError as exc:
        raise read_route_error(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="not_found",
            message="Source node was not found or is not visible.",
        ) from exc
    except ReadAuditWriteError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="audit_write_failed",
            message="Required read audit evidence could not be written.",
        ) from exc
    except NodeSourceSnapshotQueryError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="source_snapshot_query_failed",
            message="Source snapshot query failed.",
        ) from exc


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="principal_transaction_missing",
            message="Principal transaction context is unavailable.",
        )
    return cast(asyncpg.Connection, connection)


__all__ = ["router", "post_graph_source_snapshot"]
