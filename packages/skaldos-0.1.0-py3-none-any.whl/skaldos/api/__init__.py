"""HTTP API surface --- FastAPI route modules.

Slice 1, ``principal-hydration-middleware`` feature, T10. This package
hosts the FastAPI route modules that compose into the production app.
The first route is :mod:`skaldos.api.whoami` --- the slice gate's
read target (per master-plan ADR resolution; see
``docs/slices/slice-1-tenant-chokepoint/master-plan.md``
§ "ADRs surfaced for resolution" → "Slice-gate read target" row).

Surfaces (PR-sized tasks):

- :class:`~skaldos.api.whoami.WhoamiResponse` --- T10, the OpenAPI
  response shape for ``GET /whoami``.
- :func:`~skaldos.api.whoami.is_whoami_enabled` --- T10, the
  registration-time gate (returns ``False`` only when
  ``SKALDOS_ENV == "production"``).
- :func:`~skaldos.api.whoami.register_whoami_if_enabled` --- T10, the
  app-assembly hook that mounts the ``/whoami`` router on the FastAPI
  app when the gate allows.
- :data:`~skaldos.api.whoami.router` --- T10, the
  :class:`fastapi.APIRouter` carrying the ``GET /whoami`` route.

The ``/whoami`` endpoint is the **slice gate's** read target: it
exercises the full chokepoint
(:func:`~skaldos.auth.verify_token` → :func:`~skaldos.middleware.current_principal`
→ handler reads :class:`~skaldos.middleware.Principal` → returns its
identity), with no business logic in between. The slice's
``two-tenant-verification`` peer feature consumes this endpoint as
its read target.

References: §10.2 (OpenAPI as contract; routes declare
``Depends(current_principal)`` which makes them protected by
construction); §3.1 (plural-tenant principal: the response surfaces
``visible_tenant_ids``); AP4 ("compiled" is not "works" --- the
``/whoami`` integration tests exercise the endpoint end-to-end against
the real verifier, real pool, real chokepoint); AP5 (no debug bypass:
the production-gate is at registration time, not runtime --- gated
routes don't appear in OpenAPI in production at all);
``docs/slices/slice-1-tenant-chokepoint/master-plan.md``
§ "ADRs surfaced for resolution";
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/05-task-list.md``
§ T10.
"""

from __future__ import annotations

from .whoami import (
    WhoamiResponse,
    is_whoami_enabled,
    register_whoami_if_enabled,
    router,
)

__all__ = [
    "WhoamiResponse",
    "is_whoami_enabled",
    "register_whoami_if_enabled",
    "router",
]
