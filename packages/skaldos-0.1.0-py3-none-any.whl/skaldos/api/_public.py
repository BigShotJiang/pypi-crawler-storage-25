"""Public-route handlers + allowlist for Slice 2 FastAPI app skeleton (T2).

Per ``docs/slices/slice-2-authorization/policy-module-and-chokepoint/``
``03-technical-implementation.md`` § "Module layout" and
``05-task-list.md`` § T2:

This module owns two things:

1. **``PUBLIC_ROUTES``** --- the ``frozenset`` of paths that legitimately
   do *not* require a JWT or an authorization decision. These are the
   structural "public" surface of the API: health probes used by
   Cloud Run, the OpenAPI schema + docs, and the ``/redoc`` UI.

   Consuming code (unit tests, the disjoint-set assertion at slice-gate)
   walks :data:`PUBLIC_ROUTES` at *test time* to assert that no protected
   route accidentally lands in this set. The runtime never queries the
   frozenset to decide whether to skip auth --- the dependency tree
   (absence of ``Depends(authorize)``) makes the structural decision.

2. **``/health`` and ``/readyz`` handlers** registered on
   :data:`router` --- a single :class:`fastapi.APIRouter` that
   :func:`~skaldos.app.create_app` includes on the top-level
   :class:`fastapi.FastAPI` app.

Relationship to Slice 1's public-route module
---------------------------------------------

Slice 1 shipped ``services/api/skaldos/middleware/public_routes.py``
with a ``PUBLIC_ROUTES`` frozenset of its own (including ``/healthz``
and ``/docs/oauth2-redirect``). That Slice 1 constant was **middleware-
layer** infrastructure --- it never exposed route handlers. This module
is the **API-layer** definition that:

- Uses the canonical paths the production FastAPI app exposes (FastAPI's
  default OpenAPI paths are ``/openapi.json``, ``/docs``, ``/redoc``).
- Ships the actual ``/health`` and ``/readyz`` handlers that clients and
  Cloud Run liveness/readiness probes call.

The Slice 1 ``PUBLIC_ROUTES`` (in ``middleware/public_routes.py``) is
not removed by this PR --- it is still used by the CORS middleware and
by the Slice 1 disjoint-set unit test. This module defines the
**authoritative T2 public-route constant** that the Slice 2 app skeleton
and Slice 2 disjoint-set tests use.

AP5 alignment
-------------

:data:`PUBLIC_ROUTES` is *classification*, not bypass. Per AP5, no
runtime code calls ``path in PUBLIC_ROUTES`` to skip auth. The
structural defense is the route table: public routes have no
``Depends(authorize(...))`` in their dependency graph; protected routes
always do. The disjoint-set test pins this property:

    assert (routes_with_authorize ∩ PUBLIC_ROUTES) == ∅

References: §10.2 (OpenAPI 3.1 as contract); AP5 (classification, not
bypass); ``03-technical-implementation.md`` § "Module layout";
``05-task-list.md`` § T2; ``04-testing-strategy.md``
§ "Public route handling".
"""

from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict

__all__ = [
    "PUBLIC_ROUTES",
    "router",
]

# ---------------------------------------------------------------------------
# Public-route allowlist
# ---------------------------------------------------------------------------
# The canonical set of paths that do NOT require JWT + authorization.
# Adding a path here is a deliberate two-file change: this module *and*
# the disjoint-set unit tests that pin the set membership. The frozenset
# is immutable at runtime; mutation attempts raise ``AttributeError``
# (frozenset has no ``add``/``remove``).
PUBLIC_ROUTES: frozenset[str] = frozenset(
    {
        "/health",
        "/readyz",
        "/openapi.json",
        "/docs",
        "/webhooks/e2b/lifecycle",
        "/webhooks/pubsub/events",
        "/redoc",
    }
)


# ---------------------------------------------------------------------------
# Response model
# ---------------------------------------------------------------------------


class _HealthResponse(BaseModel):
    """Response shape for ``GET /health`` and ``GET /readyz``."""

    model_config = ConfigDict(frozen=True)

    status: str
    """Literal ``"ok"`` under normal operation."""


# ---------------------------------------------------------------------------
# Router + handlers
# ---------------------------------------------------------------------------

router = APIRouter(tags=["health"])
"""The :class:`fastapi.APIRouter` carrying ``GET /health`` and
``GET /readyz``.

Module-level so :func:`~skaldos.app.create_app` can include it via
``app.include_router(public_router)``. Tests that want to exercise
these endpoints directly can also include this router on a synthetic
:class:`fastapi.FastAPI` without pulling in the full app.
"""


@router.get(
    "/health",
    response_model=_HealthResponse,
    summary="Liveness probe.",
    description=(
        "Returns 200 + ``{status: 'ok'}`` if the process is alive. "
        "No database round-trip; suitable for Cloud Run liveness probes "
        "and shallow load-balancer health checks. "
        "Does not require a JWT (public route per PUBLIC_ROUTES)."
    ),
)
async def health() -> _HealthResponse:
    """Liveness probe --- returns 200 when the process is alive.

    No I/O; no database round-trip. The intent is the minimal response
    a Cloud Run liveness probe or a load-balancer shallow health check
    needs to decide the instance is not in a crash loop.

    Does not declare ``Depends(authorize(...))``: this is a public route
    per :data:`PUBLIC_ROUTES`. The absence of the authorize dependency
    is the structural decision (AP5: classification, not bypass).
    """
    return _HealthResponse(status="ok")


@router.get(
    "/readyz",
    response_model=_HealthResponse,
    summary="Readiness probe.",
    description=(
        "Returns 200 + ``{status: 'ok'}`` if the process is ready to "
        "serve traffic. Slice 2 ships a trivial implementation; Slice 5+ "
        "may add a database-pool health-check here. "
        "Does not require a JWT (public route per PUBLIC_ROUTES)."
    ),
)
async def readyz() -> _HealthResponse:
    """Readiness probe --- returns 200 when the process is ready.

    Slice 2 implementation is trivially ``ok``: if the process got here
    it is ready. Slice 5+ (observability + pool health checks) may wire
    a real database-ping here; the handler signature is forward-
    compatible (return type, path, and response model are stable).

    Does not declare ``Depends(authorize(...))``: public route per
    :data:`PUBLIC_ROUTES`. AP5: structural decision, not a runtime check.
    """
    return _HealthResponse(status="ok")
