"""FastAPI route for ``GET /graph/nodes/{node_id}`` (slice-frontend-api-gaps).

Per ``docs/slices/slice-frontend-api-gaps/03-technical-implementation.md``
§ "Module layout" → ``services/api/skaldos/api/graph_nodes.py``: this
module owns the node-detail projection the Phase 2 frontend's node
workspace opens when a user clicks a search result or follows an
edge chip.

Why a single GET (vs composing from three existing routes)
-----------------------------------------------------------

The node workspace needs the node's summary + tag chips + a small
neighborhood of related edges + a source-snapshot handle. The
brainstorm § S4 considered "compose from traverse + context +
source-snapshot" on the frontend; rejected because:

- Three requests per node-open means three error surfaces, three
  latency budgets, three RLS interaction surfaces. A single projection
  is the substrate-shaped answer (MP1: primitives over subsystems).
- Each of the three composite routes has a different visibility
  posture; reasoning about "what does the frontend see when one
  succeeds and one 404s?" is harder than reading the single
  projection's contract.
- The projection caps the related-neighborhood and tag set
  deterministically (E19), which the composite approach couldn't do
  without coordinating limits across three requests.

The projection is **summary + handles**, not "full graph snapshot":
the frontend follows up with ``POST /graph/source-snapshot`` to read
the node body, and with another ``GET /graph/nodes/{target_id}`` to
follow an edge. Each follow-up runs its own chokepoint.

Why ``Depends(authorize("read", NODE, target_tenant_loader=...))``
-------------------------------------------------------------------

Per §4.1 + §4.5: every protected route declares an action + subject
through the chokepoint. ``/graph/nodes/{id}`` reads a Node subject;
the action is ``"read"``. The ``target_tenant_loader`` resolves the
node's tenant from the path parameter so the chokepoint can evaluate
the Oso policy against the right tenant context.

The loader uses the **runtime connection** (which the chokepoint has
already opened with the GUC committed) so RLS naturally filters
invisible nodes --- the SELECT returns zero rows when the principal
cannot see the node, and the loader translates that to a 404 envelope
(F2). Existence is never leaked: cross-tenant nodes, archived nodes,
over-clearance nodes, and absent nodes all return identical 404
envelopes (E13, E15).

References
----------

- ``docs/slices/slice-frontend-api-gaps/01-user-stories.md`` S4.
- ``docs/slices/slice-frontend-api-gaps/02-edge-cases.md`` E13, E14,
  E15, E16, E17, E18, E19, E20.
- ``docs/slices/slice-frontend-api-gaps/03-technical-implementation.md``
  § "Happy-path walkthrough", § "Fault lines" F2 + F3.
- §3.5 (RLS predicate); §4.1 / §4.5 (chokepoint); §10.2 (OpenAPI as
  contract); §15.4 / §15.7 (classification + RLS).
"""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Path, Request, status

from skaldos.api.read_contracts import ReadAPIRoute, read_route_error, read_route_error_response
from skaldos.graph.projections import (
    GraphNodeDetailResponse,
    NodeDetailNotFoundError,
    NodeDetailProjectionService,
    NodeDetailQueryError,
)
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject

router = APIRouter(tags=["graph"], route_class=ReadAPIRoute)
"""The :class:`fastapi.APIRouter` carrying ``GET /graph/nodes/{node_id}``.
``route_class=ReadAPIRoute`` so error paths render the top-level
:class:`ReadRouteErrorResponse` envelope (S5)."""


async def _extract_node_target_tenant(request: Request) -> UUID:
    """Resolve the target tenant for the path-param node id.

    The chokepoint's ``Depends(authorize)`` calls this loader to extract
    the tenant the node belongs to so the policy decision evaluates
    against the right tenant context. The loader runs AFTER
    :func:`current_principal` has committed the PC1 GUCs, so the
    runtime connection at ``request.state.connection`` carries the
    principal's tenant + clearance context --- the SELECT below
    naturally filters via RLS to return only rows the principal can
    see.

    Behaviour:

    - Node visible (right tenant, in-clearance, not archived,
      not superseded): return ``tenant_id`` from the row.
    - Node absent or invisible (cross-tenant, over-clearance,
      archived, superseded, never existed): raise the read-route 404
      envelope. Existence is never leaked (F2): the four hidden
      states are indistinguishable on the wire.

    Path-param validation (E14): the route handler declares
    ``node_id: UUID``; FastAPI's standard path-param validator rejects
    non-UUID path values with a 422 envelope. The validation runs as
    part of the handler's dependency-resolution step, so by the time
    this loader's body executes the raw string in ``request.path_params``
    is already a syntactically valid UUID. The explicit ``UUID(...)``
    here is therefore defensive — it cannot raise in practice, but a
    defensive 422 keeps the behaviour aligned if a future FastAPI
    refactor changes the resolution order.
    """
    node_id_raw = request.path_params.get("node_id")
    if not isinstance(node_id_raw, str):  # pragma: no cover - FastAPI guarantees str
        # Defensive: FastAPI's path-param validation should have
        # surfaced this as 422 before the dep chain reached us.
        raise read_route_error(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            error_code="invalid_path_parameter",
            message="node_id must be a UUID.",
        )
    try:
        node_id = UUID(node_id_raw)
    except ValueError as exc:  # pragma: no cover - Path(UUID) validator catches first
        raise read_route_error(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            error_code="invalid_path_parameter",
            message="node_id must be a UUID.",
        ) from exc

    connection = getattr(request.state, "connection", None)
    if connection is None:  # pragma: no cover - chokepoint invariant
        # The chokepoint's current_principal step should have stashed
        # the runtime connection on request.state by the time the
        # authorize() dep runs. Absence is a substrate-integrity bug.
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="principal_transaction_missing",
            message="Principal transaction context is unavailable.",
        )
    typed_conn = cast(asyncpg.Connection, connection)
    row = cast(
        Any,
        await typed_conn.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
            SELECT tenant_id
            FROM nodes
            WHERE id = $1
              AND archived_at IS NULL
              AND superseded_by_node_id IS NULL
              AND app.principal_context_contains(context_of_validity)
            LIMIT 1
            """,
            node_id,
        ),
    )
    if row is None:
        # Not visible / not present / archived / over-clearance ---
        # all collapse to the same 404 (F2, E13, E15).
        raise read_route_error(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="not_found",
            message="Node was not found or is not visible.",
        )
    return cast(UUID, row["tenant_id"])


@router.get(
    "/graph/nodes/{node_id}",
    response_model=GraphNodeDetailResponse,
    status_code=status.HTTP_200_OK,
    summary="Return a node-detail projection for a visible node.",
    description=(
        "Reads one node's summary, classification, visible tags, "
        "visible related neighbors, and a source-snapshot handle in a "
        "single round-trip. The principal must be visible to the "
        "node's tenant context; cross-tenant / over-clearance / "
        "archived / absent nodes all return 404 (existence is never "
        "leaked). Tags and related arrays are capped (MAX_TAGS=50, "
        "MAX_RELATED=20) with truncated_* flags so the frontend can "
        "render a +N affordance."
    ),
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Node was not found or is not visible."),
        500: read_route_error_response("Node detail projection failed."),
    },
)
async def get_graph_node_detail(
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    node_id: Annotated[UUID, Path(description="The node's substrate id (UUID).")],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_node_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> GraphNodeDetailResponse:
    """Return the node-detail projection for the given ``node_id``.

    The chokepoint runs ahead of this handler: ``current_principal``
    commits the PC1 GUCs; ``authorize("read", NODE, ...)`` runs the
    ``_extract_node_target_tenant`` loader (which 404s on invisibility,
    so the handler only runs when the node is visible) and then
    evaluates the Oso policy against the resolved tenant.

    The handler delegates to :class:`NodeDetailProjectionService.build`
    for the single composite query that pulls the node row + tags +
    related edges. Errors are mapped to the read-route envelope:

    - :class:`NodeDetailNotFoundError` → 404 ``not_found``. Should be
      impossible in practice (the loader already 404'd if the node is
      invisible), but defensive: a race where the node is archived
      between the loader and the projection produces this.
    - :class:`NodeDetailQueryError` → 500 ``node_detail_query_failed``.
    """
    del principal  # Unused by handler; the chokepoint dep tree owns it.
    try:
        return await NodeDetailProjectionService().build(
            connection=_request_connection(request),
            node_id=node_id,
        )
    except NodeDetailNotFoundError as exc:  # pragma: no cover - loader 404s first
        raise read_route_error(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="not_found",
            message="Node was not found or is not visible.",
        ) from exc
    except NodeDetailQueryError as exc:  # pragma: no cover - infrastructure failure
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="node_detail_query_failed",
            message="Node detail projection failed.",
        ) from exc


def _request_connection(request: Request) -> asyncpg.Connection:
    """Pull the GUC-bound connection out of request state (F3).

    Mirrors ``graph_traverse.py``. The chokepoint stashes the runtime
    connection on ``request.state.connection`` after committing the PC1
    GUCs; the handler reads from there so every query runs under the
    principal's tenant + classification context.

    Raises:
        :class:`~skaldos.api.read_contracts.ReadRouteHTTPException`:
            500 with ``error_code="principal_transaction_missing"``
            when the connection is absent (substrate-integrity bug).
    """
    connection = getattr(request.state, "connection", None)
    if connection is None:  # pragma: no cover - chokepoint invariant
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="principal_transaction_missing",
            message="Principal transaction context is unavailable.",
        )
    return cast(asyncpg.Connection, connection)


__all__ = ["router", "get_graph_node_detail"]
