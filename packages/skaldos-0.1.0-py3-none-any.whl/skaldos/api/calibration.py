"""Read-only Slice 9 calibration API surfaces."""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, ConfigDict

from skaldos.api.target_tenant import target_tenant_from_query_field
from skaldos.calibration.read_model import (
    CalibrationReadRepository,
    ClassifierCalibrationProjection,
    ClassifierThresholdVersion,
)
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject

router = APIRouter(tags=["calibration"])


class ClassifierCalibrationResponse(BaseModel):
    """Read-only classifier-family calibration response."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    projection: ClassifierCalibrationProjection | None


class ClassifierThresholdHistoryResponse(BaseModel):
    """Read-only threshold version history response."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    thresholds: tuple[ClassifierThresholdVersion, ...]


async def _extract_calibration_target_tenant(request: Request) -> UUID:
    return target_tenant_from_query_field(request)


@router.get(
    "/calibration/classifier-family",
    response_model=ClassifierCalibrationResponse,
    status_code=status.HTTP_200_OK,
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def get_classifier_family_calibration(
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: Annotated[str, Query(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")],
    classifier_name: Annotated[str, Query(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")],
    classifier_version: Annotated[str, Query(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")],
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _calibration_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.ORG_CONFIG,
            target_tenant_loader=_extract_calibration_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
    context_fingerprint: Annotated[
        str | None,
        Query(pattern=r"^[a-f0-9]{64}$"),
    ] = None,
) -> ClassifierCalibrationResponse:
    """Return a permitted, content-free classifier-family calibration row."""

    projection = await CalibrationReadRepository().get_classifier_family_projection(
        connection=_request_connection(request),
        tenant_id=tenant_id,
        ontology_version_id=ontology_version_id,
        node_type_family=node_type_family,
        classifier_name=classifier_name,
        classifier_version=classifier_version,
        context_fingerprint=context_fingerprint,
    )
    return ClassifierCalibrationResponse(projection=projection)


@router.get(
    "/calibration/classifier-thresholds",
    response_model=ClassifierThresholdHistoryResponse,
    status_code=status.HTTP_200_OK,
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def list_classifier_threshold_history(
    tenant_id: UUID,
    ontology_version_id: UUID,
    node_type_family: Annotated[str, Query(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")],
    classifier_name: Annotated[str, Query(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")],
    classifier_version: Annotated[str, Query(pattern=r"^[A-Za-z0-9_.:-]{1,128}$")],
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _calibration_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.ORG_CONFIG,
            target_tenant_loader=_extract_calibration_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> ClassifierThresholdHistoryResponse:
    """Return permitted threshold config versions for one classifier scope."""

    thresholds = await CalibrationReadRepository().list_classifier_threshold_versions(
        connection=_request_connection(request),
        tenant_id=tenant_id,
        ontology_version_id=ontology_version_id,
        node_type_family=node_type_family,
        classifier_name=classifier_name,
        classifier_version=classifier_version,
        limit=limit,
    )
    return ClassifierThresholdHistoryResponse(thresholds=thresholds)


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error_code": "principal_transaction_missing",
                "reason_code": "principal_transaction_missing",
            },
        )
    return cast(asyncpg.Connection, connection)
