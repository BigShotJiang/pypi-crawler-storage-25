"""Slice gate read target: ``GET /whoami`` (T10, updated T11).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/05-task-list.md``
§ T10 + ``docs/slices/slice-1-tenant-chokepoint/master-plan.md``
§ "ADRs surfaced for resolution" → "Slice-gate read target" row: this
module ships the substrate's first production FastAPI route ---
``GET /whoami`` --- which is the **slice gate's** read target. The
endpoint's job is to be the smallest possible JWT-protected handler
that exercises the full chokepoint:

1. :func:`~skaldos.auth.verify_token` decodes the bearer token and
   produces :class:`~skaldos.auth.VerifiedClaims`.
2. :func:`~skaldos.middleware.current_principal` acquires a connection,
   opens a transaction, resolves the principal, commits the PC1 GUC
   contract, and yields a frozen
   :class:`~skaldos.middleware.Principal`.
3. The :func:`whoami` handler reads the :class:`Principal` and projects
   four identity fields into the public :class:`WhoamiResponse`.

There is intentionally no business logic between the chokepoint and
the response projection --- the endpoint *is* the chokepoint's
end-to-end test target. The slice's ``two-tenant-verification`` peer
feature uses this endpoint as its read target (per the master-plan
verification gate).

Production gating
-----------------

Per the master-plan ADR resolution, ``/whoami`` is registered on the
app only when ``SKALDOS_ENV != "production"``. The gate lives at
**route-registration time**, not runtime: when the env is production,
the route never gets attached to the app at all, so it does not appear
in the OpenAPI schema and a request to ``/whoami`` returns the same
404 a production deploy would return for any unknown path. This is the
AP5-aligned shape --- there is no separate code path, no runtime
``if testing:`` branch, no debug-flag bypass; the decision is structural.

The reason for the gate (per the ADR resolution): identity surfaces
shouldn't leak via API once the production frontend (Phase 2) has its
own profile UI. ``/whoami`` retains operator value in dev/staging/test
(quick sanity check during incident response, slice-gate read target
in the integration suite). The gate flips when a production-shaped
profile UI lands, at which point the route either moves to the
frontend's profile API or stays gated and the slice-gate target moves
to a different protected endpoint.

Why not a private smoke endpoint
--------------------------------

The brainstorm originally proposed ``/api/_smoke/principal``. The
master-plan ADR resolution chose ``/whoami`` instead. Reasons (verbatim
from the ADR row): "a real handler exercising the full stack is more
honest than a private smoke endpoint; ``/whoami`` has obvious operator
value (a quick sanity check during incident response);
``Depends(current_principal)`` makes it the smallest possible
end-to-end target. Slice 4's ``POST /graph/assert`` is still the first
*write* endpoint; ``/whoami`` is read-only and trivial. Gated off in
prod because identity surfaces shouldn't leak via API once a real
frontend (Phase 2) has its own profile UI."

Response shape
--------------

The response carries four fields (``principal_id``, ``kind``,
``primary_tenant_id``, ``visible_tenant_ids``) per the master-plan
"Shared artifacts & contracts" row for ``/whoami``. Slice 4+ may
extend the shape with delegation / trust / clearance fields when those
wires land; per CLAUDE.md "scaffold-now-wire-later", widening a
response shape with additional fields is forward-compatible if clients
parse the JSON loosely (Pydantic on the server, Zod on the frontend).

Crucially, the response **does not expose**
:attr:`~skaldos.middleware.Principal.verified_claims`,
:attr:`~skaldos.middleware.Principal.auth0_sub`, or
:attr:`~skaldos.middleware.Principal.disabled_at` --- the wire shape
is a *projection* of identity, not a memory dump. ``verified_claims``
in particular is in the §20.2 PII safelist as "never logged"; surfacing
it on the wire would be a regression of that contract. Slice 5's audit
emitter reads those fields server-side; the wire shape carries only
what an operator or a downstream client legitimately needs to see.

OpenAPI error-response floor (T11 — closes Slice 1 followups #9)
-----------------------------------------------------------------

The route decorator carries ``responses=PROTECTED_ROUTE_RESPONSES``
(from :mod:`skaldos.policy.responses`, engine T7). This makes the
OpenAPI schema enumerate the canonical error floor for every protected
route --- ``{401, 403, 404, 422, 429}`` with typed Pydantic models
(:class:`~skaldos.policy.responses.AuthorizationErrorResponse` for 403,
:class:`~skaldos.policy.responses.IntentErrorResponse` for 422, and a
placeholder for 429 that rate-limit T4 will replace with
:class:`~skaldos.policy.responses.RateLimitErrorResponse`).

``/whoami`` is the **canonical-route example** for this pattern. Every
future ``Depends(authorize(...))``, or any route on bare
``Depends(current_principal)`` that is not in ``PUBLIC_ROUTES``,
follows the same shape:

.. code-block:: python

    @router.get(
        "/path",
        response_model=MyResponse,
        responses={
            **PROTECTED_ROUTE_RESPONSES,
            # add 404 if the route has a subject_loader:
            # 404: {"description": "Resource not found."},
        },
    )

Per the master-plan ADR resolution, ``/whoami`` stays on bare
``Depends(current_principal)`` --- it is in the third disjoint-set
category (``WHOAMI_ROUTES = {"/whoami"}``) alongside ``PUBLIC_ROUTES``
and the full ``Depends(authorize(...))`` set. The flip to
``Depends(authorize)`` is verification feature's T2 (Wave 4) if ever
needed. T11 only adds the ``responses=`` dict to satisfy §10.2 and
close Slice 1 followups #9.

References: §10.2 (OpenAPI as contract); §3.1 (plural-tenant principal
--- ``visible_tenant_ids`` exposed in request scope from commit one);
§4.1 (verification is the *first* chokepoint; the response runs
*after* the chokepoint commits); §13.6 / §20.2 (PII discipline ---
``verified_claims`` not on the wire); MP10 (humans + agents same JWT
shape, same response shape; the handler does not branch on
``kind``); ML7 (agents are hub nodes in the same table as people; same
endpoint serves both); AP4 ("compiled" is not "works" --- the
integration tests exercise the endpoint end-to-end against the real
verifier, real pool, real chokepoint); AP5 (no debug bypass --- the
production-gate is at registration time, structural, not a runtime
side-channel); Slice 1 followups #9 (OpenAPI error-response wiring,
closed by this engine T11 change);
``docs/slices/slice-2-authorization/policy-module-and-chokepoint/05-task-list.md``
§ T11;
``docs/slices/slice-1-tenant-chokepoint/master-plan.md``
§ "ADRs surfaced for resolution" → "Slice-gate read target" row;
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/05-task-list.md``
§ T10.
"""

from __future__ import annotations

import os
from typing import Annotated, Literal
from uuid import UUID

from fastapi import APIRouter, Depends, FastAPI
from pydantic import BaseModel, ConfigDict

from skaldos.middleware import Principal, current_principal
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES

__all__ = [
    "WhoamiResponse",
    "is_whoami_enabled",
    "register_whoami_if_enabled",
    "router",
]


# ---------------------------------------------------------------------------
# OpenAPI response shape.
# ---------------------------------------------------------------------------


class WhoamiResponse(BaseModel):
    """Response shape for ``GET /whoami``.

    Frozen + strict-extra so:

    - The model is immutable after construction (``frozen=True``); a
      handler that builds the response and then mutates a field fails
      at the mutation site, not later in serialization.
    - Construction with unknown kwargs fails at validation
      (``extra="forbid"``); a typo'd field name surfaces as a unit-test
      failure, not as a silent drop.

    Field set per master-plan "Shared artifacts & contracts" → ``/whoami``
    row. Slice 4+ may extend this shape with delegation / trust /
    clearance projections when those wires land; widening a response
    shape with additional fields is forward-compatible.

    The model deliberately does **not** expose
    :attr:`Principal.verified_claims` or :attr:`Principal.auth0_sub`
    --- the wire shape is a projection of identity, not a memory dump.
    See the module docstring § "Response shape" for the rationale.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    """The substrate-internal surrogate PK of the resolved principal.
    Stable across renames; never reused. Mirrors
    :attr:`Principal.id`."""

    kind: Literal["human", "agent"]
    """The MP10 discriminator. ``"human"`` for org-member tokens;
    ``"agent"`` for M2M client-credentials tokens. Mirrors
    :attr:`Principal.kind`."""

    primary_tenant_id: UUID | None
    """The principal's "home tenant" (§3.1). Nullable for principals
    not yet docked into a primary tenant (e.g. freshly invited user
    whose membership row hasn't landed; an agent whose tenancy comes
    from delegation context). Mirrors
    :attr:`Principal.primary_tenant_id`."""

    visible_tenant_ids: list[UUID]
    """The principal's visible-tenant set. Empty list is the legal
    "no memberships yet" state (E14). Wire shape is a list (JSON has
    no tuple); :attr:`Principal.visible_tenant_ids` is a tuple for
    in-process immutability/hashability. The handler converts at the
    boundary."""


# ---------------------------------------------------------------------------
# Production gate.
# ---------------------------------------------------------------------------


def is_whoami_enabled() -> bool:
    """Return whether the ``/whoami`` route should be registered.

    Reads ``SKALDOS_ENV`` from the process environment. Returns
    ``False`` only when the value is exactly ``"production"``; every
    other value (including the unset case, which defaults to
    ``"development"``) returns ``True``.

    Per the master-plan ADR resolution, this is the **registration-time**
    gate: when this returns ``False``,
    :func:`register_whoami_if_enabled` is a no-op and the route never
    appears on the app. There is no runtime branch in the handler ---
    the decision is structural. AP5: no debug bypass; the gate is at
    the routing layer, not in the chokepoint.

    The function is intentionally simple (one ``os.environ.get`` call,
    one comparison) so a unit test can pin the four-way truth table
    (``development``/``staging``/``test``/unset → True; ``production``
    → False) without spinning a FastAPI app.
    """
    return os.environ.get("SKALDOS_ENV", "development") != "production"


# ---------------------------------------------------------------------------
# Router + handler.
# ---------------------------------------------------------------------------

router = APIRouter()
"""The :class:`fastapi.APIRouter` carrying ``GET /whoami``.

Module-level so :func:`register_whoami_if_enabled` can pass it to
:meth:`fastapi.FastAPI.include_router`. Tests that need to drive the
endpoint via :class:`fastapi.testclient.TestClient` /
:class:`httpx.AsyncClient` either include this router on a
:class:`fastapi.FastAPI` directly (bypassing
:func:`register_whoami_if_enabled` to avoid the env gate) or set
``SKALDOS_ENV`` to a non-production value and call the registration
helper.
"""


@router.get(
    "/whoami",
    response_model=WhoamiResponse,
    summary="Return the resolved principal's identity.",
    description=(
        "The slice gate's read target. Exercises the full chokepoint: "
        "verify_token decodes the JWT; current_principal acquires a "
        "connection, opens a transaction, resolves the principal, and "
        "commits the PC1 GUC contract; this handler reads the resolved "
        "Principal and projects to a public response. "
        "Available in dev/staging/test environments; gated off in "
        "production via SKALDOS_ENV != 'production' at route "
        "registration time."
    ),
    responses=PROTECTED_ROUTE_RESPONSES,
)
async def whoami(
    principal: Annotated[Principal, Depends(current_principal)],
) -> WhoamiResponse:
    """Return the resolved principal's identity.

    The full chokepoint runs ahead of this handler:

    1. :func:`~skaldos.auth.verify_token` decodes the bearer token and
       produces :class:`~skaldos.auth.VerifiedClaims`. Missing or
       invalid token → 401; JWKS infra failure → 503.
    2. :func:`~skaldos.middleware.current_principal` acquires a
       connection from the asyncpg pool, opens a transaction, resolves
       the principal (lookup-by-``auth0_sub`` → email-fallback →
       first-auth INSERT), commits the PC1 GUC contract, and yields a
       frozen :class:`~skaldos.middleware.Principal`. Disabled
       principal → 403; pool exhausted / lookup timeout → 503; GUC
       commit failure / integrity violation → 500.
    3. This handler reads the :class:`Principal` and constructs a
       :class:`WhoamiResponse` --- a projection that excludes the
       :attr:`Principal.verified_claims` and
       :attr:`Principal.auth0_sub` fields (per §20.2 PII discipline;
       see the module docstring § "Response shape").

    Returns:
        :class:`WhoamiResponse` carrying the four identity fields
        downstream clients legitimately need.
    """
    return WhoamiResponse(
        principal_id=principal.id,
        kind=principal.kind,
        primary_tenant_id=principal.primary_tenant_id,
        visible_tenant_ids=list(principal.visible_tenant_ids),
    )


# ---------------------------------------------------------------------------
# App-assembly hook.
# ---------------------------------------------------------------------------


def register_whoami_if_enabled(app: FastAPI) -> None:
    """Mount the ``/whoami`` router on *app* iff the env gate allows.

    Called once at app assembly (the slice's app-composition module
    that wires the FastAPI app together --- not in scope for this PR;
    Slice 1 ships the route + the registration helper, the actual
    ``app = FastAPI(...)`` lands separately or in a later slice).

    Calls :func:`is_whoami_enabled`; on ``True``, includes
    :data:`router` on the app via
    :meth:`fastapi.FastAPI.include_router`. On ``False``, no-op --- the
    route never appears on the app, in the OpenAPI schema, or in any
    routing table. AP5: the decision is structural, at registration
    time; there is no runtime side-channel.

    The helper exists separately from the
    :data:`router` so:

    - Tests that want to drive the endpoint without the env gate (the
      integration suite under
      ``tests/integration/api/test_whoami_e2e.py``) include
      :data:`router` directly on a synthetic :class:`fastapi.FastAPI`.
    - Production app-assembly only ever calls this helper, never
      :data:`router` directly. The structural assertion that
      ``SKALDOS_ENV == "production"`` produces a no-op is
      :func:`is_whoami_enabled`'s responsibility, pinned by
      ``test_is_whoami_enabled_returns_false_in_production`` in the
      unit suite.
    """
    if is_whoami_enabled():
        app.include_router(router)
