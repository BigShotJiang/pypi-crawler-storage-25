"""FastAPI routes for Slice 6 lens definitions."""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Request, status
from pydantic import BaseModel, ConfigDict, Field

from skaldos.api.read_contracts import (
    ReadAPIRoute,
    ReadPage,
    read_route_error,
    read_route_error_response,
)
from skaldos.api.target_tenant import target_tenant_from_body_or_query_field
from skaldos.lens.definition import LensDefinitionValidationError
from skaldos.lens.store import (
    LensDefinitionNotFoundError,
    LensDefinitionRecord,
    LensDefinitionStorageError,
    LensDefinitionStore,
)
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.intent import Intent
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject

router = APIRouter(tags=["graph"], route_class=ReadAPIRoute)


class LensDefinitionWriteRequest(BaseModel):
    """Create/update payload for a tenant-scoped lens definition."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    name: str = Field(min_length=1, max_length=160)
    definition: dict[str, Any]


class LensDefinitionListMetadata(BaseModel):
    """Content-free lens-list request metadata."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    include_archived: bool


class LensDefinitionListResponse(BaseModel):
    """List response for tenant-scoped lens definitions."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    lenses: tuple[LensDefinitionRecord, ...]
    metadata: LensDefinitionListMetadata
    page: ReadPage


async def _extract_lens_target_tenant(request: Request) -> UUID:
    return await _extract_body_or_query_tenant_id(request)


@router.post(
    "/graph/lenses",
    response_model=LensDefinitionRecord,
    status_code=status.HTTP_201_CREATED,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        422: read_route_error_response(
            "Lens definition is malformed or contains forbidden semantics."
        ),
        500: read_route_error_response("Lens definition could not be created."),
    },
)
async def post_graph_lens(
    body: LensDefinitionWriteRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "update",
            AppSubject.ORG_CONFIG,
            intent=Intent.declarative,
            target_tenant_loader=_extract_lens_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> LensDefinitionRecord:
    """Create a ranking-only lens definition."""

    try:
        return await LensDefinitionStore().create_lens(
            connection=_request_connection(request),
            principal=principal,
            tenant_id=body.tenant_id,
            name=body.name,
            definition_payload=body.definition,
        )
    except LensDefinitionValidationError as exc:
        raise _validation_error(exc.reason_code.value) from exc
    except LensDefinitionStorageError as exc:
        raise _server_error("lens_create_failed") from exc


@router.put(
    "/graph/lenses/{lens_id}",
    response_model=LensDefinitionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Lens definition was not found or is not visible."),
        422: read_route_error_response(
            "Lens definition is malformed or contains forbidden semantics."
        ),
        500: read_route_error_response("Lens definition could not be updated."),
    },
)
async def put_graph_lens(
    lens_id: UUID,
    body: LensDefinitionWriteRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "update",
            AppSubject.ORG_CONFIG,
            intent=Intent.declarative,
            target_tenant_loader=_extract_lens_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> LensDefinitionRecord:
    """Update an active ranking-only lens definition."""

    try:
        return await LensDefinitionStore().update_lens(
            connection=_request_connection(request),
            tenant_id=body.tenant_id,
            lens_id=lens_id,
            name=body.name,
            definition_payload=body.definition,
        )
    except LensDefinitionNotFoundError as exc:
        raise _not_found() from exc
    except LensDefinitionValidationError as exc:
        raise _validation_error(exc.reason_code.value) from exc
    except LensDefinitionStorageError as exc:
        raise _server_error("lens_update_failed") from exc


@router.get(
    "/graph/lenses/{lens_id}",
    response_model=LensDefinitionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Lens definition was not found or is not visible."),
        500: read_route_error_response("Lens definition could not be loaded."),
    },
)
async def get_graph_lens(
    lens_id: UUID,
    tenant_id: UUID,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.ORG_CONFIG,
            target_tenant_loader=_extract_lens_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> LensDefinitionRecord:
    """Load one active lens definition through RLS."""

    try:
        return await LensDefinitionStore().get_lens(
            connection=_request_connection(request),
            tenant_id=tenant_id,
            lens_id=lens_id,
        )
    except LensDefinitionNotFoundError as exc:
        raise _not_found() from exc
    except LensDefinitionStorageError as exc:
        raise _server_error("lens_load_failed") from exc


@router.get(
    "/graph/lenses",
    response_model=LensDefinitionListResponse,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        500: read_route_error_response("Lens definitions could not be listed."),
    },
)
async def list_graph_lenses(
    tenant_id: UUID,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.ORG_CONFIG,
            target_tenant_loader=_extract_lens_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
    include_archived: bool = False,
) -> LensDefinitionListResponse:
    """List tenant-scoped lens definitions through RLS."""

    try:
        lenses = await LensDefinitionStore().list_lenses(
            connection=_request_connection(request),
            tenant_id=tenant_id,
            include_archived=include_archived,
        )
    except LensDefinitionStorageError as exc:
        raise _server_error("lens_list_failed") from exc
    return LensDefinitionListResponse(
        lenses=lenses,
        metadata=LensDefinitionListMetadata(
            tenant_id=tenant_id,
            include_archived=include_archived,
        ),
        page=ReadPage(limit=len(lenses), has_more=False, next_cursor=None),
    )


@router.delete(
    "/graph/lenses/{lens_id}",
    response_model=LensDefinitionRecord,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Lens definition was not found or is not visible."),
        500: read_route_error_response("Lens definition could not be archived."),
    },
)
async def archive_graph_lens(
    lens_id: UUID,
    tenant_id: UUID,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "declare",
            AppSubject.ORG_CONFIG,
            intent=Intent.declarative,
            target_tenant_loader=_extract_lens_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> LensDefinitionRecord:
    """Archive a lens definition without deleting history."""

    try:
        return await LensDefinitionStore().archive_lens(
            connection=_request_connection(request),
            tenant_id=tenant_id,
            lens_id=lens_id,
        )
    except LensDefinitionNotFoundError as exc:
        raise _not_found() from exc
    except LensDefinitionStorageError as exc:
        raise _server_error("lens_archive_failed") from exc


async def _extract_body_or_query_tenant_id(request: Request) -> UUID:
    return await target_tenant_from_body_or_query_field(request)


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise _server_error("principal_transaction_missing")
    return cast(asyncpg.Connection, connection)


def _validation_error(reason_code: str) -> Exception:
    return read_route_error(
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        error_code=reason_code,
        message="Lens definition is malformed or contains forbidden semantics.",
    )


def _not_found() -> Exception:
    return read_route_error(
        status_code=status.HTTP_404_NOT_FOUND,
        error_code="not_found",
        message="Lens definition was not found or is not visible.",
    )


def _server_error(reason_code: str) -> Exception:
    return read_route_error(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        error_code=reason_code,
        message="Lens definition operation failed.",
    )


__all__ = [
    "LensDefinitionListResponse",
    "LensDefinitionListMetadata",
    "LensDefinitionWriteRequest",
    "archive_graph_lens",
    "get_graph_lens",
    "list_graph_lenses",
    "post_graph_lens",
    "put_graph_lens",
    "router",
]
