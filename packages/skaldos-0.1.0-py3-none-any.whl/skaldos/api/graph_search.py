"""FastAPI route for leakage-safe graph search."""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Request, status

from skaldos.api.read_contracts import ReadAPIRoute, read_route_error, read_route_error_response
from skaldos.api.target_tenant import target_tenant_from_body_field
from skaldos.graph.read_audit import ReadAuditWriteError
from skaldos.graph.search import (
    LensDefinitionNotFoundError,
    LensDefinitionStorageError,
    SearchQueryEmbedder,
    SearchQueryError,
    SearchRequest,
    SearchResult,
    SearchService,
)
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject
from skaldos.shield_call_sites import RuntimeSearchQueryLogWriter, SearchQueryEmbeddingProofService
from skaldos.shield_client import ShieldClient

router = APIRouter(tags=["graph"], route_class=ReadAPIRoute)


async def _extract_search_target_tenant(request: Request) -> UUID:
    return await target_tenant_from_body_field(request)


@router.post(
    "/graph/search",
    response_model=SearchResult,
    status_code=status.HTTP_200_OK,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: read_route_error_response("Lens definition was not found or is not visible."),
        500: read_route_error_response(
            "Search failed or required C2+ read audit could not be written."
        ),
        503: read_route_error_response("Search query embedding is required but unavailable."),
    },
)
async def post_graph_search(
    body: SearchRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_search_target_tenant,
            tier=Tier.STANDARD,
        ),
    ],
) -> SearchResult:
    """Search visible graph nodes and active chunks."""

    try:
        return await SearchService(query_embedder=_request_query_embedder(request)).search(
            connection=_request_connection(request),
            principal=principal,
            request=body,
        )
    except ReadAuditWriteError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="audit_write_failed",
            message="Required read audit evidence could not be written.",
        ) from exc
    except SearchQueryError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="search_query_failed",
            message="Search query failed.",
        ) from exc
    except LensDefinitionNotFoundError as exc:
        raise read_route_error(
            status_code=status.HTTP_404_NOT_FOUND,
            error_code="lens_not_found",
            message="Lens definition was not found or is not visible.",
        ) from exc
    except LensDefinitionStorageError as exc:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="lens_load_failed",
            message="Lens definition could not be loaded.",
        ) from exc


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise read_route_error(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            error_code="principal_transaction_missing",
            message="Principal transaction context is unavailable.",
        )
    return cast(asyncpg.Connection, connection)


def _request_query_embedder(request: Request) -> SearchQueryEmbedder | None:
    explicit_embedder = getattr(request.app.state, "search_query_embedder", None)
    if explicit_embedder is not None:
        return cast(SearchQueryEmbedder, explicit_embedder)

    shield_client = getattr(request.app.state, "shield_client", None)
    query_hash_key = getattr(request.app.state, "search_query_hash_key", None)
    if not isinstance(shield_client, ShieldClient) or not isinstance(query_hash_key, bytes):
        if bool(getattr(request.app.state, "search_query_embedder_required", False)):
            raise read_route_error(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                error_code="search_query_embedder_unconfigured",
                message="Search query embedder is required but not configured.",
            )
        return None

    return SearchQueryEmbeddingProofService(
        shield_client=shield_client,
        query_log_writer=RuntimeSearchQueryLogWriter(_request_connection(request)),
        query_hash_key=query_hash_key,
        query_hash_environment_id=str(
            getattr(request.app.state, "search_query_hash_environment_id", "runtime")
        ),
    )


__all__ = ["router", "post_graph_search"]
