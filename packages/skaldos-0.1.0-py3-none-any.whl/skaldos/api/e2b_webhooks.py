"""Public E2B lifecycle webhook endpoint."""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, HTTPException, Request, Response, status
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from skaldos.agents.contracts import SandboxLifecycleKind
from skaldos.agents.errors import (
    AgentSandboxLifecycleError,
    AgentSandboxWebhookAuthError,
)
from skaldos.agents.lifecycle import AgentRunLifecycleService, sandbox_webhook_signature
from skaldos.middleware.hydration import (
    GUC_PRINCIPAL_CONTEXT,
    GUC_PRINCIPAL_VISIBLE,
)
from skaldos.middleware.resolver import format_uuid_array
from skaldos.sandbox.e2b import (
    E2B_WEBHOOK_SIGNATURE_HEADER,
    E2B_WEBHOOK_SIGNATURE_VERSION_HEADER,
    map_e2b_lifecycle_event,
    verify_e2b_webhook_signature,
)

router = APIRouter(tags=["agents"])


class E2BWebhookPayload(BaseModel):
    """Content-free subset of E2B lifecycle webhook payloads."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    type: str = Field(min_length=1)
    event_label: str | None = None
    sandbox_id: str = Field(min_length=1)
    event_data: dict[str, Any] = Field(default_factory=dict)


@router.post(
    "/webhooks/e2b/lifecycle",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
    summary="E2B sandbox lifecycle webhook.",
)
async def post_e2b_lifecycle_webhook(request: Request) -> Response:
    raw_body = await request.body()
    signature = request.headers.get(E2B_WEBHOOK_SIGNATURE_HEADER)
    if not signature:
        raise _webhook_auth_http_error()
    try:
        verify_e2b_webhook_signature(
            signing_secret=_webhook_signing_secret(request),
            raw_body=raw_body,
            signature=signature,
            signature_version=request.headers.get(E2B_WEBHOOK_SIGNATURE_VERSION_HEADER),
        )
        payload = E2BWebhookPayload.model_validate_json(raw_body)
        metadata = _sandbox_metadata(payload)
        tenant_id = UUID(_required_metadata(metadata, "skaldos_tenant_id"))
        sandbox_id = UUID(_required_metadata(metadata, "skaldos_sandbox_id"))
        webhook_token = _required_metadata(metadata, "skaldos_webhook_token")
        event_kind = SandboxLifecycleKind(
            map_e2b_lifecycle_event(payload.type, payload.event_label)
        )
    except (
        AgentSandboxLifecycleError,
        AgentSandboxWebhookAuthError,
        KeyError,
        TypeError,
        ValueError,
        ValidationError,
        json.JSONDecodeError,
    ) as exc:
        if isinstance(exc, AgentSandboxWebhookAuthError):
            raise _webhook_auth_http_error() from exc
        raise _webhook_malformed_http_error() from exc

    try:
        try:
            connection = _request_connection(request)
        except _PoolBackedWebhookRequiredError:
            await _accept_lifecycle_event_from_pool(
                request=request,
                tenant_id=tenant_id,
                sandbox_id=sandbox_id,
                event_kind=event_kind,
                webhook_token=webhook_token,
            )
            return Response(status_code=status.HTTP_204_NO_CONTENT)

        await _accept_lifecycle_event(
            request=request,
            connection=connection,
            tenant_id=tenant_id,
            sandbox_id=sandbox_id,
            event_kind=event_kind,
            webhook_token=webhook_token,
        )
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    except AgentSandboxWebhookAuthError as exc:
        raise _webhook_auth_http_error() from exc
    except AgentSandboxLifecycleError as exc:
        raise _webhook_malformed_http_error() from exc


def _webhook_signing_secret(request: Request) -> str:
    configured = getattr(request.app.state, "e2b_webhook_signing_secret", None)
    if isinstance(configured, str) and configured.strip():
        return configured
    env_value = os.environ.get("E2B_WEBHOOK_SIGNING_SECRET")
    if env_value and env_value.strip():
        return env_value
    raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE)


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is not None:
        return cast(asyncpg.Connection, connection)
    pool = getattr(request.app.state, "runtime_pool", None)
    if pool is not None:
        raise _PoolBackedWebhookRequiredError()
    raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE)


class _PoolBackedWebhookRequiredError(Exception):
    """Internal sentinel for app-lifespan pool backed webhook processing."""


async def _accept_lifecycle_event_from_pool(
    *,
    request: Request,
    tenant_id: UUID,
    sandbox_id: UUID,
    event_kind: SandboxLifecycleKind,
    webhook_token: str,
) -> None:
    pool = getattr(request.app.state, "runtime_pool", None)
    if pool is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE)
    async with pool.acquire() as connection, connection.transaction():  # pyright: ignore[reportUnknownMemberType]
        await _accept_lifecycle_event(
            request=request,
            connection=cast(asyncpg.Connection, connection),
            tenant_id=tenant_id,
            sandbox_id=sandbox_id,
            event_kind=event_kind,
            webhook_token=webhook_token,
        )


async def _accept_lifecycle_event(
    *,
    request: Request,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    sandbox_id: UUID,
    event_kind: SandboxLifecycleKind,
    webhook_token: str,
) -> None:
    await _bind_webhook_tenant_context(connection=connection, tenant_id=tenant_id)
    await AgentRunLifecycleService(
        control_plane=getattr(request.app.state, "sandbox_control_plane", None),
        webhook_signing_secret=_webhook_signing_secret(request),
    ).accept_webhook(
        connection=connection,
        tenant_id=tenant_id,
        sandbox_id=sandbox_id,
        event_kind=event_kind,
        signature=sandbox_webhook_signature(
            signing_secret=_webhook_signing_secret(request),
            token=webhook_token,
            tenant_id=tenant_id,
            sandbox_id=sandbox_id,
            event_kind=event_kind,
        ),
        token=webhook_token,
    )


def _sandbox_metadata(payload: E2BWebhookPayload) -> dict[str, str]:
    raw_metadata = payload.event_data.get("sandbox_metadata")
    if not isinstance(raw_metadata, dict):
        raise ValueError("e2b_webhook_metadata_missing")
    metadata = cast(Mapping[object, object], raw_metadata)
    return {str(key): str(value) for key, value in metadata.items()}


def _required_metadata(metadata: dict[str, str], key: str) -> str:
    value = metadata.get(key)
    if value is None or not value.strip():
        raise ValueError("e2b_webhook_metadata_missing")
    return value


async def _bind_webhook_tenant_context(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
) -> None:
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_VISIBLE,
        format_uuid_array((tenant_id,)),
    )
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_CONTEXT,
        json.dumps(
            {
                "tenants": [str(tenant_id)],
                "classification": "C1",
                "clearances": {str(tenant_id): "C1"},
                "verticals": ["foundation"],
                "ontology_versions": [],
            },
            separators=(",", ":"),
        ),
    )


def _webhook_auth_http_error() -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)


def _webhook_malformed_http_error() -> HTTPException:
    return HTTPException(status_code=status.HTTP_400_BAD_REQUEST)


__all__ = ["router"]
