"""FastAPI surface for Slice 7 sync AgentRun launch."""

from __future__ import annotations

from typing import Annotated, Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict

from skaldos.agents import (
    AgentIdentityNotConfiguredError,
    AgentRouteCapabilityError,
    AgentRouteNotConfiguredError,
    AgentRouteUnavailableError,
    AgentRunE2BSandboxLaunchService,
    AgentRunLifecycleService,
    AgentRunStorageError,
    AgentRunSyncLaunchService,
    AgentSandboxLifecycleError,
    AgentSandboxWebhookAuthError,
    AgentServiceError,
    AgentTemplateInvalidError,
    AgentTemplateNotFoundError,
    AgentToolSecretError,
    AgentTypeNotFoundError,
    AgentWorkflowStartError,
    SandboxLifecycleResult,
    SyncAgentRunRequest,
    SyncAgentRunResponse,
)
from skaldos.api.target_tenant import target_tenant_from_body_field
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.intent import Intent
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject
from skaldos.sandbox.e2b import E2BConfig, E2BConfigError, E2BSandboxControlPlane

router = APIRouter(tags=["agents"])


class AgentRunSandboxLifecycleRequest(BaseModel):
    """Tenant-scoped request for protected sandbox lifecycle operations."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: UUID


class AgentRunSandboxLifecycleResponse(BaseModel):
    """Content-free sandbox lifecycle response for live validation."""

    model_config = ConfigDict(extra="forbid")

    agent_run_id: UUID
    sandbox_id: UUID
    status: str
    sandbox_state: str
    provider: str
    provider_handle: str | None
    transitioned: bool


async def _extract_agent_launch_target_tenant(request: Request) -> UUID:
    return await target_tenant_from_body_field(
        request,
        cache_state_attr="agent_launch_tenant_id",
    )


@router.post(
    "/agents/{org_agent_type_id}/runs",
    response_model=SyncAgentRunResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        400: {"description": "Agent run launch is not currently startable."},
        404: {"description": "Agent type, route, or template is missing or unavailable."},
        422: {"description": "Malformed or unsafe sync agent launch request."},
    },
)
async def post_sync_agent_run(
    org_agent_type_id: UUID,
    body: SyncAgentRunRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "direct",
            AppSubject.ORG_CONFIG,
            intent=Intent.directive,
            target_tenant_loader=_extract_agent_launch_target_tenant,
            tier=Tier.WRITE_HEAVY,
        ),
    ],
) -> SyncAgentRunResponse:
    """Create a sync AgentRun and start the durable workflow shell."""

    try:
        return await AgentRunSyncLaunchService(
            workflow_starter=getattr(request.app.state, "agent_workflow_starter", None)
        ).launch_sync_run(
            connection=_request_connection(request),
            launcher=principal,
            tenant_id=_tenant_id_from_body(request),
            org_agent_type_id=org_agent_type_id,
            request=body,
            api_base_url=_configured_base_url(request, "agent_api_base_url"),
            shield_base_url=_shield_base_url(request),
        )
    except AgentWorkflowStartError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"error_code": str(exc), "reason_code": str(exc)},
        ) from exc
    except (
        AgentIdentityNotConfiguredError,
        AgentRouteNotConfiguredError,
        AgentRouteUnavailableError,
        AgentRouteCapabilityError,
        AgentTemplateNotFoundError,
        AgentTypeNotFoundError,
    ) as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error_code": str(exc), "reason_code": str(exc)},
        ) from exc
    except (AgentTemplateInvalidError, AgentToolSecretError) as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"error_code": str(exc), "reason_code": str(exc)},
        ) from exc
    except (AgentRunStorageError, AgentServiceError) as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error_code": str(exc), "reason_code": str(exc)},
        ) from exc


@router.post(
    "/agents/{org_agent_type_id}/runs/{agent_run_id}/sandbox/start",
    response_model=AgentRunSandboxLifecycleResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        400: {"description": "Agent run sandbox is not currently startable."},
        404: {"description": "Agent run, type, route, or template is missing."},
        422: {"description": "Malformed sandbox lifecycle request."},
        503: {"description": "E2B runtime config is missing."},
    },
)
async def post_agent_run_sandbox_start(
    org_agent_type_id: UUID,
    agent_run_id: UUID,
    body: AgentRunSandboxLifecycleRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "direct",
            AppSubject.ORG_CONFIG,
            intent=Intent.directive,
            target_tenant_loader=_extract_agent_launch_target_tenant,
            tier=Tier.WRITE_HEAVY,
        ),
    ],
) -> AgentRunSandboxLifecycleResponse:
    """Start a real E2B sandbox for a persisted non-production AgentRun."""

    try:
        result = await AgentRunE2BSandboxLaunchService(
            config=_e2b_config(),
            control_plane=_e2b_control_plane(request),
        ).start_for_run(
            connection=_request_connection(request),
            tenant_id=body.tenant_id,
            org_agent_type_id=org_agent_type_id,
            agent_run_id=agent_run_id,
            api_base_url=_configured_base_url(request, "agent_api_base_url"),
            shield_base_url=_shield_base_url(request),
            agent_bearer_token=_bearer_token_from_request(request),
            caller_principal_id=_principal.id,
        )
    except E2BConfigError as exc:
        raise _safe_http_error(status.HTTP_503_SERVICE_UNAVAILABLE, str(exc)) from exc
    except AgentSandboxLifecycleError as exc:
        raise _safe_http_error(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    except (
        AgentTemplateInvalidError,
        AgentToolSecretError,
        AgentTypeNotFoundError,
        AgentTemplateNotFoundError,
    ) as exc:
        raise _safe_http_error(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    except (AgentRunStorageError, AgentServiceError) as exc:
        raise _safe_http_error(status.HTTP_500_INTERNAL_SERVER_ERROR, str(exc)) from exc
    return _sandbox_lifecycle_response(result)


@router.post(
    "/agents/runs/{agent_run_id}/cancel",
    response_model=AgentRunSandboxLifecycleResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        400: {"description": "Agent run cannot be cancelled."},
        422: {"description": "Malformed sandbox lifecycle request."},
        503: {"description": "E2B runtime config is missing."},
    },
)
async def post_agent_run_cancel(
    agent_run_id: UUID,
    body: AgentRunSandboxLifecycleRequest,
    request: Request,
    _principal: Annotated[Principal, Depends(current_principal)],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            "direct",
            AppSubject.ORG_CONFIG,
            intent=Intent.directive,
            target_tenant_loader=_extract_agent_launch_target_tenant,
            tier=Tier.WRITE_HEAVY,
        ),
    ],
) -> AgentRunSandboxLifecycleResponse:
    """Cancel an AgentRun by killing its persisted E2B provider handle."""

    try:
        result = await AgentRunLifecycleService(
            control_plane=_e2b_control_plane(request),
            webhook_signing_secret=_e2b_config().webhook_signing_secret,
        ).cancel_run(
            connection=_request_connection(request),
            tenant_id=body.tenant_id,
            agent_run_id=agent_run_id,
        )
    except E2BConfigError as exc:
        raise _safe_http_error(status.HTTP_503_SERVICE_UNAVAILABLE, str(exc)) from exc
    except (AgentSandboxLifecycleError, AgentSandboxWebhookAuthError) as exc:
        raise _safe_http_error(status.HTTP_400_BAD_REQUEST, str(exc)) from exc
    except AgentRunStorageError as exc:
        raise _safe_http_error(status.HTTP_500_INTERNAL_SERVER_ERROR, str(exc)) from exc
    return _sandbox_lifecycle_response(result)


def _tenant_id_from_body(request: Request) -> UUID:
    cached = getattr(request.state, "agent_launch_tenant_id", None)
    if isinstance(cached, UUID):
        return cached
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail={"error_code": "tenant_id_missing", "reason_code": "tenant_id_missing"},
    )


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error_code": "principal_transaction_missing",
                "reason_code": "principal_transaction_missing",
            },
        )
    return cast(asyncpg.Connection, connection)


def _shield_base_url(request: Request) -> str:
    return _configured_base_url(request, "shield_base_url")


def _bearer_token_from_request(request: Request) -> str | None:
    headers = getattr(request, "headers", {})
    authorization = headers.get("authorization") or headers.get("Authorization")
    if authorization is None or not authorization.startswith("Bearer "):
        return None
    token = authorization.removeprefix("Bearer ").strip()
    return token or None


def _configured_base_url(request: Request, state_attr: str) -> str:
    configured = getattr(request.app.state, state_attr, None)
    if isinstance(configured, str) and configured:
        return configured.rstrip("/")
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error_code": f"{state_attr}_unconfigured",
            "reason_code": f"{state_attr}_unconfigured",
        },
    )


def _e2b_config() -> E2BConfig:
    return E2BConfig.from_env()


def _e2b_control_plane(request: Request) -> E2BSandboxControlPlane:
    configured = getattr(request.app.state, "sandbox_control_plane", None)
    if isinstance(configured, E2BSandboxControlPlane):
        return configured
    return E2BSandboxControlPlane.from_env()


def _sandbox_lifecycle_response(
    result: SandboxLifecycleResult,
) -> AgentRunSandboxLifecycleResponse:
    return AgentRunSandboxLifecycleResponse(
        agent_run_id=result.agent_run.id,
        sandbox_id=result.sandbox.id,
        status=result.agent_run.status.value,
        sandbox_state=result.sandbox.state.value,
        provider=result.sandbox.provider,
        provider_handle=result.sandbox.provider_handle,
        transitioned=result.transitioned,
    )


def _safe_http_error(status_code: int, reason_code: str) -> HTTPException:
    return HTTPException(
        status_code=status_code,
        detail={"error_code": reason_code, "reason_code": reason_code},
    )


__all__ = ["router"]
