"""Public contract models and route shell for ``POST /graph/assert``.

This module owns the FastAPI/OpenAPI-facing envelope for Slice 4 and the first
production route shell. The shell validates the public envelope, reconciles the
body actor with the hydrated Principal, resolves source kind, authorizes the
request intent against a derived subject, and stages exactly one assertion.
Conflict/apply/audit lifecycle work stays in sibling Wave 2 PRs.

References: Slice 4 master plan "Shared artifacts & contracts";
``assert-endpoint-contract`` T2-T7; §10.2, §10.5, §10.12, AP1, AP12.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Annotated, Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.api.target_tenant import target_tenant_from_assertion_context
from skaldos.falsification.decision_revisions import DecisionRevisionError
from skaldos.graph.assert_contract import (
    DEFAULT_ASSERTION_CLAIM_MAX_BYTES,
    FactFamilyInput,
    GraphAssertPublicStatus,
    RegisteredSourceKind,
    resolve_source_kind,
    validate_claim_size,
)
from skaldos.graph.assert_service import GraphAssertCommand, execute_graph_assert_command
from skaldos.graph.assert_staging import (
    AssertionCanonicalInput,
    AssertionCanonicalizationError,
    AssertionIdempotencyMismatchError,
    AssertionLifecycleError,
)
from skaldos.graph.context_validity import (
    REQUIRED_CONTEXT_KEYS,
    ContextValidityError,
    validate_context_timestamps,
)
from skaldos.graph.edges import EdgeValidationError
from skaldos.graph.node_chunk_embeddings import NodeChunkEmbeddingGenerator
from skaldos.graph.node_tags import NodeTagValidationError
from skaldos.graph.pattern_validation import GraphPatternValidationError
from skaldos.graph.transaction import GraphPrincipalTransactionError
from skaldos.middleware import Principal
from skaldos.middleware.hydration import current_principal
from skaldos.policy import authorize
from skaldos.policy.assertion_authorization import (
    AssertionAuthorizationReason,
    AssertionPolicyDeniedError,
    AssertionPolicyEvaluationError,
    AssertionSubjectDerivationError,
)
from skaldos.policy.intent import Intent
from skaldos.policy.rate_limit.tier import Tier
from skaldos.policy.responses import PROTECTED_ROUTE_RESPONSES
from skaldos.policy.subjects import AppSubject

type JsonValue = str | int | float | bool | None | dict[str, "JsonValue"] | list["JsonValue"]

SUPPORTED_GRAPH_ASSERT_CLAIM_FAMILIES = frozenset(
    {
        "edge_create",
        "node_body_update",
        "node_tag",
        "observation",
        "note",
        "pattern4_revision",
    }
)

Confidence = Annotated[
    float,
    Field(ge=0.0, le=1.0, strict=True, allow_inf_nan=False),
]


class AssertionActor(BaseModel):
    """Body actor field that must match the hydrated Principal."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    principal_id: UUID
    kind: Literal["human", "agent"]


class AssertionSource(BaseModel):
    """Registered source-system handle supplied by every write surface."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: str = Field(min_length=1, max_length=63)
    locator: str | None = Field(default=None, min_length=1, max_length=2048)
    external_id: str | None = Field(default=None, min_length=1, max_length=512)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("kind")
    @classmethod
    def _source_kind_syntax(cls, value: str) -> str:
        return RegisteredSourceKind(kind=value).kind


class AssertionGroundingRef(BaseModel):
    """Content-free grounding handle for a graph assertion."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID | None = None
    edge_id: UUID | None = None
    span: dict[str, JsonValue] | None = None
    role: str | None = Field(default=None, min_length=1, max_length=128)


class AssertionWarning(BaseModel):
    """Stable warning code returned by the assertion service."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    code: str = Field(min_length=1, max_length=128)
    message: str | None = Field(default=None, max_length=512)


def _empty_uuid_list() -> list[UUID]:
    return []


def _empty_warning_list() -> list[AssertionWarning]:
    return []


class GraphAssertRequest(BaseModel):
    """Strict request envelope for the Slice 4 write chokepoint."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    claim: dict[str, JsonValue] = Field(
        json_schema_extra={
            "description": (
                "Graph assertion claim. Slice 11 supported families are "
                "observation, note, node_body_update, node_tag, edge_create, "
                "and pattern4_revision."
            ),
            "examples": [
                {
                    "kind": "node_body_update",
                    "target": {
                        "node_id": "00000000-0000-7000-8000-000000000001",
                        "expected_version": 1,
                    },
                    "new_body": "updated content",
                    "context": {
                        "tenant": "00000000-0000-7000-8000-000000000002",
                        "classification": "C1",
                        "vertical": "foundation",
                        "ontology_version": "00000000-0000-7000-8000-000000000302",
                        "valid_from": "2026-05-21T00:00:00Z",
                        "valid_to": None,
                    },
                },
                {
                    "kind": "edge_create",
                    "target": {
                        "source_node_id": "00000000-0000-7000-8000-000000000003",
                        "target_node_id": "00000000-0000-7000-8000-000000000004",
                        "relationship_type": "grounded-by",
                    },
                    "context": {
                        "tenant": "00000000-0000-7000-8000-000000000002",
                        "classification": "C1",
                        "vertical": "foundation",
                        "ontology_version": "00000000-0000-7000-8000-000000000302",
                        "valid_from": "2026-05-21T00:00:00Z",
                        "valid_to": None,
                    },
                },
                {
                    "kind": "pattern4_revision",
                    "target": {"source_decision_id": "00000000-0000-7000-8000-000000000005"},
                    "revised_body": "replacement decision",
                    "grounded_by_node_ids": ["00000000-0000-7000-8000-000000000006"],
                    "falsifier_node_id": "00000000-0000-7000-8000-000000000007",
                    "occurred_at": "2026-05-21T12:00:00Z",
                    "context": {
                        "tenant": "00000000-0000-7000-8000-000000000002",
                        "classification": "C1",
                        "vertical": "foundation",
                        "ontology_version": "00000000-0000-7000-8000-000000000302",
                        "valid_from": "2026-05-21T00:00:00Z",
                        "valid_to": None,
                    },
                },
            ],
        }
    )
    source: AssertionSource
    actor: AssertionActor
    grounding: list[AssertionGroundingRef]
    confidence: Confidence | None = None
    intent: Intent

    @field_validator("claim")
    @classmethod
    def _claim_is_not_empty_and_under_ap1(
        cls,
        value: dict[str, JsonValue],
    ) -> dict[str, JsonValue]:
        if not value:
            raise ValueError("claim must not be empty")
        return value


class GraphAssertResponse(BaseModel):
    """Stable response envelope for ``POST /graph/assert``."""

    model_config = ConfigDict(frozen=True, extra="forbid", populate_by_name=True)

    status: GraphAssertPublicStatus
    assertion_id: UUID = Field(alias="assertionId")
    pending_assertion_id: UUID | None = Field(default=None, alias="pendingAssertionId")
    applied_node_ids: list[UUID] = Field(default_factory=_empty_uuid_list, alias="appliedNodeIds")
    applied_edge_ids: list[UUID] = Field(default_factory=_empty_uuid_list, alias="appliedEdgeIds")
    warnings: list[AssertionWarning] = Field(default_factory=_empty_warning_list)
    conflict_id: UUID | None = Field(default=None, alias="conflictId")
    trace_id: str | None = Field(default=None, alias="traceId")


class AssertionActorMismatchError(ValueError):
    """Raised when body actor provenance does not match the trusted Principal."""

    def __init__(self, *, actor: AssertionActor, principal: Principal) -> None:
        self.actor = actor
        self.principal_id = principal.id
        self.principal_kind = principal.kind
        super().__init__("assertion_actor_mismatch")


def reconcile_assertion_actor(actor: AssertionActor, principal: Principal) -> AssertionActor:
    """Return ``actor`` only when it matches the hydrated Principal."""

    if actor.principal_id != principal.id or actor.kind != principal.kind:
        raise AssertionActorMismatchError(actor=actor, principal=principal)
    return actor


def resolve_assertion_source(source: AssertionSource) -> RegisteredSourceKind:
    """Resolve ``source.kind`` through the Slice 4 registry before staging."""

    return resolve_source_kind(source.kind)


async def _extract_assertion_target_tenant(request: Request) -> UUID:
    return await target_tenant_from_assertion_context(request)


router = APIRouter(tags=["graph"])


@router.post(
    "/graph/assert",
    response_model=GraphAssertResponse,
    response_model_by_alias=True,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        **PROTECTED_ROUTE_RESPONSES,
        404: {"description": "Target subject was not found or is not visible."},
        409: {"description": "Idempotency key was reused with a different payload."},
    },
)
async def post_graph_assert(
    body: GraphAssertRequest,
    request: Request,
    principal: Annotated[Principal, Depends(current_principal)],
    idempotency_key: Annotated[str, Header(min_length=1, alias="Idempotency-Key")],
    _chokepoint_subject: Annotated[
        Any,
        authorize(  # noqa: B008
            # Structural AP5/rate-limit chokepoint only. The request intent
            # maps to its real policy action after body validation below.
            "read",
            AppSubject.NODE,
            target_tenant_loader=_extract_assertion_target_tenant,
            tier=Tier.WRITE_HEAVY,
        ),
    ],
) -> GraphAssertResponse | JSONResponse:
    """Validate, authorize, and stage one graph assertion."""

    try:
        reconcile_assertion_actor(body.actor, principal)
    except AssertionActorMismatchError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error_code": "authorization_denied",
                "reason_code": "actor_principal_mismatch",
            },
        ) from exc

    try:
        resolved_source = resolve_assertion_source(body.source)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"error_code": "unknown_source_kind", "reason_code": "unknown_source_kind"},
        ) from exc
    try:
        validate_claim_size(body.claim, max_bytes=DEFAULT_ASSERTION_CLAIM_MAX_BYTES)
    except ValueError:
        return _error_response(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"error_code": "claim_too_large", "reason_code": "claim_too_large"},
        )
    unsupported_family = _unsupported_claim_family(body.claim)
    if unsupported_family is not None:
        return _error_response(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "error_code": "unsupported_claim_family",
                "reason_code": "unsupported_claim_family",
                "details": {"claim_family": unsupported_family},
            },
        )

    try:
        assertion = _canonical_input_from_request(
            body=body,
            principal=principal,
            resolved_source=resolved_source,
        )
        result = await execute_graph_assert_command(
            GraphAssertCommand(
                principal=principal,
                connection=_request_connection(request),
                assertion=assertion,
                idempotency_key=idempotency_key,
                node_chunk_embedding_generator=_request_node_chunk_embedding_generator(request),
            )
        )
    except AssertionSubjectDerivationError as exc:
        if exc.reason == AssertionAuthorizationReason.SUBJECT_NOT_FOUND:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"error_code": "not_found", "reason_code": exc.reason.value},
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={"error_code": exc.reason.value, "reason_code": exc.reason.value},
        ) from exc
    except AssertionPolicyDeniedError as exc:
        return _error_response(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error_code": "authorization_denied",
                "reason_code": exc.decision.reason_code.value if exc.decision.reason_code else None,
            },
        )
    except AssertionPolicyEvaluationError as exc:
        return _error_response(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error_code": "policy_evaluation_error",
                "reason_code": exc.metadata.reason_code.value,
            },
        )
    except AssertionIdempotencyMismatchError as exc:
        return _error_response(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error_code": "idempotency_payload_mismatch",
                "reason_code": "idempotency_payload_mismatch",
                "assertionId": str(exc.existing_assertion_id),
            },
        )
    except (
        AssertionCanonicalizationError,
        AssertionLifecycleError,
        GraphPatternValidationError,
        GraphPrincipalTransactionError,
        EdgeValidationError,
        NodeTagValidationError,
        DecisionRevisionError,
    ) as exc:
        detail: Mapping[str, object]
        if isinstance(exc, GraphPatternValidationError):
            detail = exc.to_safe_dict()
        elif isinstance(exc, EdgeValidationError):
            detail = {"error_code": "edge_validation_failed", "reason_code": exc.reason_code.value}
        elif isinstance(exc, NodeTagValidationError):
            detail = {
                "error_code": "node_tag_validation_failed",
                "reason_code": exc.reason_code.value,
            }
        else:
            detail = {"error_code": str(exc), "reason_code": str(exc)}
        return _error_response(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=detail,
        )

    return GraphAssertResponse(
        status=result.status,
        assertionId=result.assertion_id,
        pendingAssertionId=result.pending_assertion_id,
        appliedNodeIds=list(result.applied_node_ids),
        appliedEdgeIds=list(result.applied_edge_ids),
        warnings=[AssertionWarning(code=warning) for warning in result.warnings],
        conflictId=result.conflict_id,
    )


def _request_connection(request: Request) -> asyncpg.Connection:
    connection = getattr(request.state, "connection", None)
    if connection is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error_code": "principal_transaction_missing",
                "reason_code": "principal_transaction_missing",
            },
        )
    return cast(asyncpg.Connection, connection)


def _request_node_chunk_embedding_generator(
    request: Request,
) -> NodeChunkEmbeddingGenerator | None:
    app = getattr(request, "app", None)
    state = getattr(app, "state", None)
    if state is None:
        return None
    return cast(
        NodeChunkEmbeddingGenerator | None,
        getattr(state, "node_chunk_embedding_generator", None),
    )


def _error_response(*, status_code: int, detail: Mapping[str, object]) -> JSONResponse:
    return JSONResponse(status_code=status_code, content={"detail": dict(detail)})


def _canonical_input_from_request(
    *,
    body: GraphAssertRequest,
    principal: Principal,
    resolved_source: RegisteredSourceKind,
) -> AssertionCanonicalInput:
    claim = _claim_mapping(body.claim)
    source = cast(Mapping[str, Any], body.source.model_dump(mode="json", exclude_none=True))
    return AssertionCanonicalInput(
        actor_principal_id=principal.id,
        intent=body.intent,
        source={**source, "kind": resolved_source.kind},
        grounding=tuple(
            cast(Mapping[str, Any], grounding.model_dump(mode="json", exclude_none=True))
            for grounding in body.grounding
        ),
        confidence=body.confidence,
        context_of_validity=_context_of_validity(claim=claim, principal=principal),
        claim=claim,
        claim_kind=_claim_kind(claim),
        fact_family=_fact_family_from_claim(claim=claim, principal=principal),
    )


def _claim_mapping(claim: dict[str, JsonValue]) -> Mapping[str, Any]:
    return cast(Mapping[str, Any], claim)


def _claim_kind(claim: Mapping[str, Any]) -> str | None:
    value = claim.get("kind") or claim.get("type")
    return value.strip() if isinstance(value, str) and value.strip() else None


def _unsupported_claim_family(claim: Mapping[str, Any]) -> str | None:
    claim_kind = _claim_kind(claim)
    if claim_kind is None:
        return None
    if claim_kind in SUPPORTED_GRAPH_ASSERT_CLAIM_FAMILIES:
        return None
    return claim_kind


def _fact_family_from_claim(
    *,
    claim: Mapping[str, Any],
    principal: Principal,
) -> FactFamilyInput:
    context = _context_of_validity(claim=claim, principal=principal)
    tenant = str(context["tenant"])
    claim_kind = _claim_kind(claim) or "claim"
    target_value = claim.get("target")
    target = (
        dict(cast(Mapping[str, Any], target_value))
        if isinstance(target_value, Mapping)
        else {
            "kind": str(claim.get("subject_kind") or claim_kind),
            "id": str(claim.get("subject_id") or claim.get("target_id") or "unscoped"),
        }
    )
    fact = {
        "kind": claim_kind,
        "predicate": str(claim.get("predicate") or claim.get("field") or "body"),
        "value": claim.get("value", claim.get("body")),
    }
    return FactFamilyInput(
        tenant_id=tenant,
        context={
            "classification": context.get("classification"),
            "vertical": context.get("vertical"),
            "ontology_version": context.get("ontology_version"),
            "valid_from": context.get("valid_from"),
            "valid_to": context.get("valid_to"),
        },
        target=target,
        fact=fact,
    )


def _context_of_validity(
    *,
    claim: Mapping[str, Any],
    principal: Principal,
) -> Mapping[str, Any]:
    for key in ("context_of_validity", "context"):
        value = claim.get(key)
        if isinstance(value, Mapping):
            return _validated_context(value=cast(Mapping[str, Any], value), principal=principal)
    return _validated_context(value=claim, principal=principal)


def _validated_context(
    *,
    value: Mapping[str, Any],
    principal: Principal,
) -> Mapping[str, Any]:
    missing = sorted(key for key in REQUIRED_CONTEXT_KEYS if key not in value)
    if missing:
        raise AssertionCanonicalizationError("context_of_validity_required")
    tenant = value.get("tenant")
    if str(tenant) not in {str(tenant_id) for tenant_id in principal.visible_tenant_ids}:
        raise AssertionCanonicalizationError("context_of_validity_tenant_not_visible")
    try:
        validate_context_timestamps(value)
    except ContextValidityError as exc:
        raise AssertionCanonicalizationError(str(exc)) from exc
    return value
