"""Slice 9 conversation state machine primitives."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Literal

from skaldos.policy.intent import ActionLiteral, Intent, action_for_intent


class ConversationState(StrEnum):
    """Persisted Conversation node lifecycle states for Slice 9."""

    requested = "requested"
    promised = "promised"
    declined = "declined"
    completed = "completed"
    satisfied = "satisfied"
    rejected = "rejected"
    stalled = "stalled"


class ConversationTransition(StrEnum):
    """Closed transition set accepted by ConversationService."""

    open = "open"
    promise = "promise"
    decline = "decline"
    complete = "complete"
    satisfy = "satisfy"
    reject = "reject"
    reopen = "reopen"
    stall = "stall"


RequiredConversationActor = Literal[
    "requester",
    "requester_or_delegate",
    "requestee_or_delegate",
    "stalled_dispatcher",
]

ConversationEventType = Literal[
    "conversation.opened",
    "conversation.promised",
    "conversation.declined",
    "conversation.completed",
    "conversation.satisfied",
    "conversation.rejected",
    "conversation.stalled",
    "conversation.reopened",
]


@dataclass(frozen=True, slots=True)
class ConversationTransitionRule:
    """One legal state-machine edge for a Conversation transition."""

    from_state: ConversationState | None
    transition: ConversationTransition
    to_state: ConversationState
    intent: Intent
    policy_action: ActionLiteral
    required_actor: RequiredConversationActor
    event_type: ConversationEventType
    closes: bool
    requires_prior_promise: bool = False


_RULES: tuple[ConversationTransitionRule, ...] = (
    ConversationTransitionRule(
        from_state=None,
        transition=ConversationTransition.open,
        to_state=ConversationState.requested,
        intent=Intent.directive,
        policy_action=action_for_intent(Intent.directive),
        required_actor="requester",
        event_type="conversation.opened",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.requested,
        transition=ConversationTransition.promise,
        to_state=ConversationState.promised,
        intent=Intent.commissive,
        policy_action=action_for_intent(Intent.commissive),
        required_actor="requestee_or_delegate",
        event_type="conversation.promised",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.requested,
        transition=ConversationTransition.decline,
        to_state=ConversationState.declined,
        intent=Intent.commissive,
        policy_action=action_for_intent(Intent.commissive),
        required_actor="requestee_or_delegate",
        event_type="conversation.declined",
        closes=True,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.requested,
        transition=ConversationTransition.stall,
        to_state=ConversationState.stalled,
        intent=Intent.declarative,
        policy_action=action_for_intent(Intent.declarative),
        required_actor="stalled_dispatcher",
        event_type="conversation.stalled",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.promised,
        transition=ConversationTransition.complete,
        to_state=ConversationState.completed,
        intent=Intent.assertive,
        policy_action=action_for_intent(Intent.assertive),
        required_actor="requestee_or_delegate",
        event_type="conversation.completed",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.promised,
        transition=ConversationTransition.stall,
        to_state=ConversationState.stalled,
        intent=Intent.declarative,
        policy_action=action_for_intent(Intent.declarative),
        required_actor="stalled_dispatcher",
        event_type="conversation.stalled",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.completed,
        transition=ConversationTransition.satisfy,
        to_state=ConversationState.satisfied,
        intent=Intent.expressive,
        policy_action=action_for_intent(Intent.expressive),
        required_actor="requester_or_delegate",
        event_type="conversation.satisfied",
        closes=True,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.completed,
        transition=ConversationTransition.reject,
        to_state=ConversationState.rejected,
        intent=Intent.expressive,
        policy_action=action_for_intent(Intent.expressive),
        required_actor="requester_or_delegate",
        event_type="conversation.rejected",
        closes=True,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.rejected,
        transition=ConversationTransition.reopen,
        to_state=ConversationState.requested,
        intent=Intent.directive,
        policy_action=action_for_intent(Intent.directive),
        required_actor="requester_or_delegate",
        event_type="conversation.reopened",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.stalled,
        transition=ConversationTransition.promise,
        to_state=ConversationState.promised,
        intent=Intent.commissive,
        policy_action=action_for_intent(Intent.commissive),
        required_actor="requestee_or_delegate",
        event_type="conversation.promised",
        closes=False,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.stalled,
        transition=ConversationTransition.complete,
        to_state=ConversationState.completed,
        intent=Intent.assertive,
        policy_action=action_for_intent(Intent.assertive),
        required_actor="requestee_or_delegate",
        event_type="conversation.completed",
        closes=False,
        requires_prior_promise=True,
    ),
    ConversationTransitionRule(
        from_state=ConversationState.stalled,
        transition=ConversationTransition.reopen,
        to_state=ConversationState.requested,
        intent=Intent.directive,
        policy_action=action_for_intent(Intent.directive),
        required_actor="requester_or_delegate",
        event_type="conversation.reopened",
        closes=False,
    ),
)

CONVERSATION_TRANSITION_RULES: tuple[ConversationTransitionRule, ...] = _RULES
OPEN_CONVERSATION_STATES: frozenset[ConversationState] = frozenset(
    {
        ConversationState.requested,
        ConversationState.promised,
        ConversationState.completed,
        ConversationState.stalled,
    }
)
CLOSED_CONVERSATION_STATES: frozenset[ConversationState] = frozenset(
    {
        ConversationState.declined,
        ConversationState.satisfied,
        ConversationState.rejected,
    }
)

_RULES_BY_KEY: dict[
    tuple[ConversationState | None, ConversationTransition],
    ConversationTransitionRule,
] = {(rule.from_state, rule.transition): rule for rule in _RULES}


class ConversationTransitionError(ValueError):
    """Raised when a requested conversation transition is outside Slice 9's table."""


def get_transition_rule(
    from_state: ConversationState | None,
    transition: ConversationTransition,
) -> ConversationTransitionRule:
    """Return the legal transition rule or raise ``ConversationTransitionError``."""

    try:
        return _RULES_BY_KEY[(from_state, transition)]
    except KeyError as exc:
        state_value = "none" if from_state is None else from_state.value
        raise ConversationTransitionError(
            f"illegal conversation transition: {state_value} -> {transition.value}"
        ) from exc


def is_open_state(state: ConversationState) -> bool:
    """Return whether ``state`` belongs in open conversation queries."""

    return state in OPEN_CONVERSATION_STATES


def is_closed_state(state: ConversationState) -> bool:
    """Return whether ``state`` is a terminal Slice 9 conversation state."""

    return state in CLOSED_CONVERSATION_STATES


def validate_transition_intent(
    *,
    from_state: ConversationState | None,
    transition: ConversationTransition,
    intent: Intent,
) -> ConversationTransitionRule:
    """Return the transition rule when the supplied Searle intent matches."""

    rule = get_transition_rule(from_state, transition)
    if intent is not rule.intent:
        raise ConversationTransitionError(
            "conversation transition intent mismatch: "
            f"{transition.value} requires {rule.intent.value}, got {intent.value}"
        )
    return rule
