"""SLA deadline selection for Slice 9 conversations."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Literal
from uuid import UUID

PrincipalKind = Literal["human", "agent"]

DEFAULT_AGENT_SLA = timedelta(minutes=15)
DEFAULT_HUMAN_SLA = timedelta(hours=24)


@dataclass(frozen=True, slots=True)
class ConversationSlaPolicy:
    """Versionable SLA policy row shape used by the first Conversation service."""

    tenant_id: UUID
    task_type: str
    requestee_principal_kind: PrincipalKind
    duration: timedelta
    config_id: UUID | None = None


@dataclass(frozen=True, slots=True)
class ConversationSlaSelection:
    """The materialized SLA choice for a new Conversation."""

    duration: timedelta
    deadline: datetime
    source: Literal["default", "policy"]
    config_id: UUID | None


class ConversationSlaPolicyError(ValueError):
    """Raised when an SLA policy would create an invalid deadline."""


def default_sla_duration(requestee_principal_kind: PrincipalKind) -> timedelta:
    """Return Slice 9's default SLA duration for a requestee kind."""

    match requestee_principal_kind:
        case "agent":
            return DEFAULT_AGENT_SLA
        case "human":
            return DEFAULT_HUMAN_SLA


def select_conversation_sla(
    *,
    tenant_id: UUID,
    task_type: str,
    requestee_principal_kind: PrincipalKind,
    opened_at: datetime,
    policies: Iterable[ConversationSlaPolicy] = (),
) -> ConversationSlaSelection:
    """Select and materialize a Conversation SLA deadline.

    Policy changes after this function returns do not affect existing
    Conversations because callers persist the returned ``deadline`` at open time.
    """

    normalized_opened_at = _normalize_datetime(opened_at)
    matching_policy = _find_policy(
        tenant_id=tenant_id,
        task_type=task_type,
        requestee_principal_kind=requestee_principal_kind,
        policies=policies,
    )
    if matching_policy is None:
        duration = default_sla_duration(requestee_principal_kind)
        return ConversationSlaSelection(
            duration=duration,
            deadline=normalized_opened_at + duration,
            source="default",
            config_id=None,
        )
    if matching_policy.duration <= timedelta(0):
        raise ConversationSlaPolicyError("conversation_sla_duration_must_be_positive")
    return ConversationSlaSelection(
        duration=matching_policy.duration,
        deadline=normalized_opened_at + matching_policy.duration,
        source="policy",
        config_id=matching_policy.config_id,
    )


def _find_policy(
    *,
    tenant_id: UUID,
    task_type: str,
    requestee_principal_kind: PrincipalKind,
    policies: Iterable[ConversationSlaPolicy],
) -> ConversationSlaPolicy | None:
    for policy in policies:
        if (
            policy.tenant_id == tenant_id
            and policy.task_type == task_type
            and policy.requestee_principal_kind == requestee_principal_kind
        ):
            return policy
    return None


def _normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)
