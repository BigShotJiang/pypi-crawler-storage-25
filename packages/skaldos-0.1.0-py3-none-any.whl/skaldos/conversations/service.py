"""Conversation service primitives for Slice 9."""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.conversations.sla import (
    ConversationSlaPolicy,
    PrincipalKind,
    select_conversation_sla,
)
from skaldos.conversations.state import (
    OPEN_CONVERSATION_STATES,
    ConversationState,
    ConversationTransition,
    RequiredConversationActor,
    get_transition_rule,
)
from skaldos.events.outbox import (
    OutboxContextOfValidity,
    OutboxEnvelope,
    OutboxInsertResult,
    insert_outbox_event,
)
from skaldos.graph.assert_audit import AssertionAuditEntry, AuditOutcome, emit_assertion_audit_entry
from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal
from skaldos.policy.assertion_authorization import (
    AssertionPolicyDecision,
    authorize_assertion_intent,
)
from skaldos.policy.intent import Intent
from skaldos.policy.subjects import ConversationRow, OrgConfigRow

STALLED_DISPATCHER_AUTH0_SUB = "slice-9-stalled-dispatcher"


class ConversationServiceErrorCode(StrEnum):
    TRANSACTION_REQUIRED = "conversation_transaction_required"
    TENANT_CONTEXT_MISMATCH = "conversation_tenant_context_mismatch"
    REQUEST_ACT_NOT_VISIBLE = "conversation_request_act_not_visible"
    REQUEST_ACT_INTENT_MISMATCH = "conversation_request_act_intent_mismatch"
    REQUESTEE_MISSING = "conversation_requestee_missing"
    REQUESTEE_SELF_REVIEW = "conversation_requestee_self_review"
    REQUESTEE_CLEARANCE_TOO_LOW = "conversation_requestee_clearance_too_low"
    ONTOLOGY_TYPE_MISSING = "conversation_ontology_type_missing"
    IDEMPOTENCY_PAYLOAD_MISMATCH = "conversation_idempotency_payload_mismatch"
    CONVERSATION_NOT_VISIBLE = "conversation_not_visible"
    ACT_NOT_VISIBLE = "conversation_act_not_visible"
    ACT_INTENT_MISMATCH = "conversation_act_intent_mismatch"
    ILLEGAL_TRANSITION = "conversation_illegal_transition"
    WRONG_ACTOR = "conversation_wrong_actor"
    PRIOR_PROMISE_REQUIRED = "conversation_prior_promise_required"
    STALLED_DISPATCHER_REQUIRED = "conversation_stalled_dispatcher_required"
    ACT_AUTHOR_MISMATCH = "conversation_act_author_mismatch"


class ConversationServiceError(RuntimeError):
    """Raised when a Conversation open operation fails validation."""

    def __init__(self, reason_code: ConversationServiceErrorCode) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code.value)


class ConversationContext(BaseModel):
    """Content-free context tuple copied from the request act node."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant: UUID
    classification: Literal["C0", "C1", "C2", "C3", "C4"]
    vertical: Annotated[str, Field(min_length=1, max_length=128)] = "foundation"
    ontology_version: UUID
    valid_from: datetime
    valid_to: datetime | None = None

    @field_validator("valid_from", "valid_to")
    @classmethod
    def _normalize_timestamp(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @model_validator(mode="after")
    def _validity_window_is_ordered(self) -> ConversationContext:
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError("invalid_validity_window")
        return self

    def to_outbox_context(self) -> OutboxContextOfValidity:
        return OutboxContextOfValidity.model_validate(self.model_dump(mode="python"))


_CLASSIFICATION_RANK: Mapping[str, int] = {"C0": 0, "C1": 1, "C2": 2, "C3": 3, "C4": 4}


def _max_conversation_context(
    conversation_context: ConversationContext,
    act_context: ConversationContext,
) -> ConversationContext:
    classification = max(
        (conversation_context.classification, act_context.classification),
        key=_CLASSIFICATION_RANK.__getitem__,
    )
    valid_from = min(conversation_context.valid_from, act_context.valid_from)
    valid_to_values = tuple(
        value
        for value in (conversation_context.valid_to, act_context.valid_to)
        if value is not None
    )
    return conversation_context.model_copy(
        update={
            "classification": classification,
            "valid_from": valid_from,
            "valid_to": min(valid_to_values) if valid_to_values else None,
        }
    )


class ConversationOpenDraft(BaseModel):
    """Service-facing request to open a node-shaped Conversation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    request_act_id: UUID
    requestee_principal_id: UUID
    task_type: Annotated[str, Field(min_length=1, max_length=128)]
    occurred_at: datetime
    idempotency_key: Annotated[str, Field(min_length=1, max_length=256)] | None = None

    @field_validator("occurred_at")
    @classmethod
    def _occurred_at_is_utc(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)


@dataclass(frozen=True, slots=True)
class ConversationOpenResult:
    conversation_node_id: UUID
    tenant_id: UUID
    requester_principal_id: UUID
    requestee_principal_id: UUID
    requestee_principal_kind: PrincipalKind
    request_act_id: UUID
    current_state: ConversationState
    episode_id: UUID
    state_version: int
    opened_at: datetime
    sla_deadline: datetime
    replayed: bool
    audit_entry: AssertionAuditEntry | None
    outbox_event: OutboxInsertResult | None


class ConversationTransitionDraft(BaseModel):
    """Service-facing request to transition a node-shaped Conversation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    conversation_node_id: UUID
    transition: ConversationTransition
    act_id: UUID
    intent: Intent
    occurred_at: datetime
    idempotency_key: Annotated[str, Field(min_length=1, max_length=256)] | None = None

    @field_validator("occurred_at")
    @classmethod
    def _occurred_at_is_utc(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)


@dataclass(frozen=True, slots=True)
class ConversationTransitionResult:
    conversation_node_id: UUID
    tenant_id: UUID
    transition: ConversationTransition
    current_state: ConversationState
    previous_state: ConversationState
    episode_id: UUID
    state_version: int
    closed_at: datetime | None
    replayed: bool
    audit_entry: AssertionAuditEntry | None
    outbox_event: OutboxInsertResult | None


@dataclass(frozen=True, slots=True)
class ConversationRecord:
    conversation_node_id: UUID
    tenant_id: UUID
    requester_principal_id: UUID
    requestee_principal_id: UUID
    request_act_id: UUID
    current_state: ConversationState
    episode_id: UUID
    state_version: int
    task_type: str
    opened_at: datetime
    sla_deadline: datetime
    closed_at: datetime | None
    stalled_at: datetime | None
    created_at: datetime
    next_cursor: str


@dataclass(frozen=True, slots=True)
class ConversationListResult:
    conversations: tuple[ConversationRecord, ...]
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class StalledConversationResult:
    conversation_node_id: UUID
    tenant_id: UUID
    previous_state: ConversationState
    current_state: ConversationState
    episode_id: UUID
    state_version: int
    stalled_at: datetime
    outbox_event: OutboxInsertResult


@dataclass(frozen=True, slots=True)
class StalledScanResult:
    scanner_id: str
    scanned_at: datetime | None
    claimed: int
    stalled: tuple[StalledConversationResult, ...]


async def open_from_directive(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: ConversationOpenDraft,
    sla_policies: Iterable[ConversationSlaPolicy] = (),
) -> ConversationOpenResult:
    """Open a node-shaped Conversation from a visible directive act."""

    async def _open(bound_connection: asyncpg.Connection) -> ConversationOpenResult:
        return await _open_from_directive_bound(
            principal=principal,
            connection=bound_connection,
            draft=draft,
            sla_policies=sla_policies,
        )

    return await with_principal(principal=principal, connection=connection, fn=_open)


async def _open_from_directive_bound(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: ConversationOpenDraft,
    sla_policies: Iterable[ConversationSlaPolicy] = (),
) -> ConversationOpenResult:
    """Open after the caller's transaction has been bound to ``principal``."""

    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise ConversationServiceError(ConversationServiceErrorCode.TRANSACTION_REQUIRED)
    if principal.id == draft.requestee_principal_id:
        raise ConversationServiceError(ConversationServiceErrorCode.REQUESTEE_SELF_REVIEW)

    request_act = await _load_request_act(connection, draft.request_act_id)
    if request_act is None:
        raise ConversationServiceError(ConversationServiceErrorCode.REQUEST_ACT_NOT_VISIBLE)
    context = ConversationContext.model_validate(_json_mapping(request_act["context_of_validity"]))
    if context.tenant not in principal.visible_tenant_ids:
        raise ConversationServiceError(ConversationServiceErrorCode.TENANT_CONTEXT_MISMATCH)
    if _metadata_intent(_json_mapping(request_act["metadata"])) is not Intent.directive:
        raise ConversationServiceError(ConversationServiceErrorCode.REQUEST_ACT_INTENT_MISMATCH)

    requestee = await _load_requestee(
        connection,
        tenant_id=context.tenant,
        requestee_principal_id=draft.requestee_principal_id,
        classification=context.classification,
    )
    if requestee is None:
        raise ConversationServiceError(ConversationServiceErrorCode.REQUESTEE_MISSING)
    if not bool(requestee["clearance_sufficient"]):
        raise ConversationServiceError(ConversationServiceErrorCode.REQUESTEE_CLEARANCE_TOO_LOW)

    requestee_kind = cast(PrincipalKind, requestee["kind"])
    sla_selection = select_conversation_sla(
        tenant_id=context.tenant,
        task_type=draft.task_type,
        requestee_principal_kind=requestee_kind,
        opened_at=draft.occurred_at,
        policies=sla_policies,
    )
    policy_decision = _authorize_open(
        principal=principal,
        tenant_id=context.tenant,
        context=context,
    )
    existing = await _load_existing_conversation(
        connection,
        tenant_id=context.tenant,
        request_act_id=draft.request_act_id,
    )
    if existing is not None:
        await _ensure_request_act_edge(
            connection,
            tenant_id=context.tenant,
            conversation_node_id=cast(UUID, existing["id"]),
            request_act_id=draft.request_act_id,
            classification=context.classification,
        )
        return _existing_result(
            existing,
            principal=principal,
            requestee_kind=requestee_kind,
            draft=draft,
        )

    result = await _insert_conversation_node(
        connection,
        principal=principal,
        context=context,
        draft=draft,
        requestee_kind=requestee_kind,
        sla_deadline=sla_selection.deadline,
        sla_source=sla_selection.source,
        sla_config_id=sla_selection.config_id,
    )
    if result is None:
        existing_after_conflict = await _load_existing_conversation(
            connection,
            tenant_id=context.tenant,
            request_act_id=draft.request_act_id,
        )
        if existing_after_conflict is not None:
            await _ensure_request_act_edge(
                connection,
                tenant_id=context.tenant,
                conversation_node_id=cast(UUID, existing_after_conflict["id"]),
                request_act_id=draft.request_act_id,
                classification=context.classification,
            )
            return _existing_result(
                existing_after_conflict,
                principal=principal,
                requestee_kind=requestee_kind,
                draft=draft,
            )
        raise ConversationServiceError(ConversationServiceErrorCode.ONTOLOGY_TYPE_MISSING)

    await _ensure_request_act_edge(
        connection,
        tenant_id=context.tenant,
        conversation_node_id=result.conversation_node_id,
        request_act_id=draft.request_act_id,
        classification=context.classification,
    )
    audit_entry = await emit_assertion_audit_entry(
        connection=connection,
        policy=policy_decision,
        context_of_validity=context.model_dump(mode="json"),
        outcome=AuditOutcome.PERMITTED,
    )
    outbox_event = await insert_outbox_event(
        connection=connection,
        envelope=conversation_opened_envelope(
            conversation_node_id=result.conversation_node_id,
            tenant_id=context.tenant,
            context=context,
            occurred_at=draft.occurred_at,
            conversation_state=ConversationState.requested,
            conversation_state_version=1,
            conversation_episode_id=result.episode_id,
            requester_principal_id=principal.id,
            requestee_principal_id=draft.requestee_principal_id,
            request_act_id=draft.request_act_id,
            sla_deadline=sla_selection.deadline,
        ),
    )
    return ConversationOpenResult(
        conversation_node_id=result.conversation_node_id,
        tenant_id=context.tenant,
        requester_principal_id=principal.id,
        requestee_principal_id=draft.requestee_principal_id,
        requestee_principal_kind=requestee_kind,
        request_act_id=draft.request_act_id,
        current_state=ConversationState.requested,
        episode_id=result.episode_id,
        state_version=1,
        opened_at=draft.occurred_at,
        sla_deadline=sla_selection.deadline,
        replayed=False,
        audit_entry=audit_entry,
        outbox_event=outbox_event,
    )


def conversation_opened_envelope(
    *,
    conversation_node_id: UUID,
    tenant_id: UUID,
    context: ConversationContext,
    occurred_at: datetime,
    conversation_state: ConversationState | None = None,
    conversation_state_version: int | None = None,
    conversation_episode_id: UUID | None = None,
    requester_principal_id: UUID | None = None,
    requestee_principal_id: UUID | None = None,
    request_act_id: UUID | None = None,
    sla_deadline: datetime | None = None,
) -> OutboxEnvelope:
    """Build the handle-only `conversation.opened` event envelope."""

    return OutboxEnvelope(
        id_as_handle=True,
        event_type="conversation.opened",
        subject_type="conversation",
        subject_id=conversation_node_id,
        tenant_id=tenant_id,
        context_of_validity=context.to_outbox_context(),
        occurred_at=occurred_at,
        intent="directive",
        conversation_state=conversation_state.value if conversation_state is not None else None,
        conversation_state_version=conversation_state_version,
        conversation_episode_id=conversation_episode_id,
        requester_principal_id=requester_principal_id,
        requestee_principal_id=requestee_principal_id,
        request_act_id=request_act_id,
        sla_deadline=sla_deadline,
    )


async def transition(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: ConversationTransitionDraft,
) -> ConversationTransitionResult:
    """Apply one legal Conversation transition in a Principal-bound transaction."""

    async def _transition(bound_connection: asyncpg.Connection) -> ConversationTransitionResult:
        return await _transition_bound(
            principal=principal,
            connection=bound_connection,
            draft=draft,
        )

    return await with_principal(principal=principal, connection=connection, fn=_transition)


async def _transition_bound(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: ConversationTransitionDraft,
) -> ConversationTransitionResult:
    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise ConversationServiceError(ConversationServiceErrorCode.TRANSACTION_REQUIRED)

    conversation = await _load_conversation_for_update(
        connection,
        conversation_node_id=draft.conversation_node_id,
    )
    if conversation is None:
        raise ConversationServiceError(ConversationServiceErrorCode.CONVERSATION_NOT_VISIBLE)
    metadata = _json_mapping(conversation["metadata"])
    replayed = _replay_transition_if_idempotent(
        principal=principal,
        draft=draft,
        conversation=conversation,
        metadata=metadata,
    )
    if replayed is not None:
        return replayed

    current_state = ConversationState(str(metadata["current_state"]))
    try:
        rule = get_transition_rule(current_state, draft.transition)
    except ValueError as exc:
        raise ConversationServiceError(ConversationServiceErrorCode.ILLEGAL_TRANSITION) from exc
    if draft.intent is not rule.intent:
        raise ConversationServiceError(ConversationServiceErrorCode.ACT_INTENT_MISMATCH)
    if rule.requires_prior_promise and metadata.get("promised_at") is None:
        raise ConversationServiceError(ConversationServiceErrorCode.PRIOR_PROMISE_REQUIRED)

    context = ConversationContext.model_validate(_json_mapping(conversation["context_of_validity"]))
    if context.tenant not in principal.visible_tenant_ids:
        raise ConversationServiceError(ConversationServiceErrorCode.TENANT_CONTEXT_MISMATCH)
    if not _actor_matches_rule(
        principal=principal, metadata=metadata, required_actor=rule.required_actor
    ):
        raise ConversationServiceError(ConversationServiceErrorCode.WRONG_ACTOR)

    act = await _load_transition_act(connection, draft.act_id)
    if act is None:
        raise ConversationServiceError(ConversationServiceErrorCode.ACT_NOT_VISIBLE)
    act_context = ConversationContext.model_validate(_json_mapping(act["context_of_validity"]))
    if act_context.tenant != context.tenant:
        raise ConversationServiceError(ConversationServiceErrorCode.TENANT_CONTEXT_MISMATCH)
    transition_context = _max_conversation_context(context, act_context)
    if _metadata_intent(_json_mapping(act["metadata"])) is not rule.intent:
        raise ConversationServiceError(ConversationServiceErrorCode.ACT_INTENT_MISMATCH)
    if cast(UUID, act["authored_by_principal_id"]) != principal.id:
        raise ConversationServiceError(ConversationServiceErrorCode.ACT_AUTHOR_MISMATCH)

    policy_decision = authorize_assertion_intent(
        principal=principal,
        intent=rule.intent,
        subject=_conversation_subject(
            row=conversation,
            metadata=metadata,
        ),
    )
    updated = await _update_conversation_state(
        connection,
        conversation_node_id=draft.conversation_node_id,
        tenant_id=context.tenant,
        expected_state_version=_int_metadata(metadata["state_version"]),
        metadata=metadata,
        context=transition_context,
        rule_to_state=rule.to_state,
        transition=draft.transition,
        act_id=draft.act_id,
        principal_id=principal.id,
        idempotency_key=draft.idempotency_key,
        occurred_at=draft.occurred_at,
        closes=rule.closes,
    )
    if updated is None:
        raise ConversationServiceError(ConversationServiceErrorCode.ILLEGAL_TRANSITION)

    await _ensure_transition_edge(
        connection,
        tenant_id=context.tenant,
        conversation_node_id=draft.conversation_node_id,
        act_id=draft.act_id,
        transition=draft.transition,
        classification=transition_context.classification,
    )
    audit_entry = await emit_assertion_audit_entry(
        connection=connection,
        policy=policy_decision,
        context_of_validity=transition_context.model_dump(mode="json"),
        outcome=AuditOutcome.PERMITTED,
    )
    updated_metadata = _json_mapping(updated["metadata"])
    outbox_event = await insert_outbox_event(
        connection=connection,
        envelope=conversation_transition_envelope(
            conversation_node_id=draft.conversation_node_id,
            tenant_id=context.tenant,
            context=transition_context,
            occurred_at=draft.occurred_at,
            event_type=rule.event_type,
            intent=rule.intent,
            conversation_state=ConversationState(str(updated_metadata["current_state"])),
            conversation_state_version=_int_metadata(updated_metadata["state_version"]),
            conversation_episode_id=UUID(str(updated_metadata["episode_id"])),
            requester_principal_id=UUID(str(updated_metadata["requester_principal_id"])),
            requestee_principal_id=UUID(str(updated_metadata["requestee_principal_id"])),
            request_act_id=UUID(str(updated_metadata["request_act_id"])),
            response_act_id=draft.act_id
            if draft.transition
            in {
                ConversationTransition.promise,
                ConversationTransition.decline,
                ConversationTransition.complete,
            }
            else None,
            resolution_act_id=draft.act_id
            if draft.transition
            in {
                ConversationTransition.satisfy,
                ConversationTransition.reject,
                ConversationTransition.reopen,
            }
            else None,
            sla_deadline=_parse_optional_datetime(updated_metadata.get("sla_deadline")),
        ),
    )
    return ConversationTransitionResult(
        conversation_node_id=draft.conversation_node_id,
        tenant_id=context.tenant,
        transition=draft.transition,
        current_state=ConversationState(str(updated_metadata["current_state"])),
        previous_state=current_state,
        episode_id=UUID(str(updated_metadata["episode_id"])),
        state_version=_int_metadata(updated_metadata["state_version"]),
        closed_at=_parse_optional_datetime(updated_metadata.get("closed_at")),
        replayed=False,
        audit_entry=audit_entry,
        outbox_event=outbox_event,
    )


def conversation_transition_envelope(
    *,
    conversation_node_id: UUID,
    tenant_id: UUID,
    context: ConversationContext,
    occurred_at: datetime,
    event_type: str,
    intent: Intent,
    conversation_state: ConversationState | None = None,
    conversation_state_version: int | None = None,
    conversation_episode_id: UUID | None = None,
    requester_principal_id: UUID | None = None,
    requestee_principal_id: UUID | None = None,
    request_act_id: UUID | None = None,
    response_act_id: UUID | None = None,
    resolution_act_id: UUID | None = None,
    sla_deadline: datetime | None = None,
) -> OutboxEnvelope:
    """Build a handle-only `conversation.*` transition event envelope."""

    return OutboxEnvelope(
        id_as_handle=True,
        event_type=event_type,
        subject_type="conversation",
        subject_id=conversation_node_id,
        tenant_id=tenant_id,
        context_of_validity=context.to_outbox_context(),
        occurred_at=occurred_at,
        intent=cast(Any, intent.value),
        conversation_state=conversation_state.value if conversation_state is not None else None,
        conversation_state_version=conversation_state_version,
        conversation_episode_id=conversation_episode_id,
        requester_principal_id=requester_principal_id,
        requestee_principal_id=requestee_principal_id,
        request_act_id=request_act_id,
        response_act_id=response_act_id,
        resolution_act_id=resolution_act_id,
        sla_deadline=sla_deadline,
    )


async def scan_stalled_conversations(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    scanner_id: str,
    batch_size: int = 100,
) -> StalledScanResult:
    """Claim overdue open Conversations and emit one stalled event per episode."""

    async def _scan(bound_connection: asyncpg.Connection) -> StalledScanResult:
        return await _scan_stalled_conversations_bound(
            principal=principal,
            connection=bound_connection,
            scanner_id=scanner_id,
            batch_size=batch_size,
        )

    return await with_principal(principal=principal, connection=connection, fn=_scan)


async def _scan_stalled_conversations_bound(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    scanner_id: str,
    batch_size: int = 100,
) -> StalledScanResult:
    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise ConversationServiceError(ConversationServiceErrorCode.TRANSACTION_REQUIRED)
    if (
        principal.kind != "agent"
        or not principal.auth0_sub.startswith(STALLED_DISPATCHER_AUTH0_SUB)
        or not any(role in {"owner", "admin"} for _, role in principal.role_assignments)
    ):
        raise ConversationServiceError(ConversationServiceErrorCode.STALLED_DISPATCHER_REQUIRED)

    visible_tenant_ids = tuple(principal.visible_tenant_ids)
    if not visible_tenant_ids:
        return StalledScanResult(scanner_id=scanner_id, scanned_at=None, claimed=0, stalled=())

    rows = await _claim_due_stalled_conversations(
        connection,
        tenant_ids=visible_tenant_ids,
        batch_size=_query_limit(batch_size),
    )
    stalled: list[StalledConversationResult] = []
    scanned_at: datetime | None = None
    for row in rows:
        scanned_at = cast(datetime, row["scanner_now"]).astimezone(UTC).replace(tzinfo=UTC)
        metadata = _json_mapping(row["metadata"])
        context = ConversationContext.model_validate(_json_mapping(row["context_of_validity"]))
        current_state = ConversationState(str(metadata["current_state"]))
        updated = await _update_conversation_state(
            connection,
            conversation_node_id=cast(UUID, row["id"]),
            tenant_id=cast(UUID, row["tenant_id"]),
            expected_state_version=_int_metadata(metadata["state_version"]),
            metadata=metadata,
            context=context,
            rule_to_state=ConversationState.stalled,
            transition=ConversationTransition.stall,
            act_id=UUID("00000000-0000-0000-0000-000000000000"),
            principal_id=principal.id,
            idempotency_key=f"stalled:{metadata['episode_id']}",
            occurred_at=scanned_at,
            closes=False,
        )
        if updated is None:
            continue
        updated_metadata = _json_mapping(updated["metadata"])
        outbox_event = await insert_outbox_event(
            connection=connection,
            envelope=conversation_transition_envelope(
                conversation_node_id=cast(UUID, row["id"]),
                tenant_id=cast(UUID, row["tenant_id"]),
                context=context,
                occurred_at=scanned_at,
                event_type="conversation.stalled",
                intent=Intent.declarative,
                conversation_state=ConversationState.stalled,
                conversation_state_version=_int_metadata(updated_metadata["state_version"]),
                conversation_episode_id=UUID(str(updated_metadata["episode_id"])),
                requester_principal_id=UUID(str(updated_metadata["requester_principal_id"])),
                requestee_principal_id=UUID(str(updated_metadata["requestee_principal_id"])),
                request_act_id=UUID(str(updated_metadata["request_act_id"])),
                sla_deadline=_parse_optional_datetime(updated_metadata.get("sla_deadline")),
            ),
        )
        stalled.append(
            StalledConversationResult(
                conversation_node_id=cast(UUID, row["id"]),
                tenant_id=cast(UUID, row["tenant_id"]),
                previous_state=current_state,
                current_state=ConversationState.stalled,
                episode_id=UUID(str(updated_metadata["episode_id"])),
                state_version=_int_metadata(updated_metadata["state_version"]),
                stalled_at=_parse_datetime(updated_metadata["stalled_at"]),
                outbox_event=outbox_event,
            )
        )
    return StalledScanResult(
        scanner_id=scanner_id,
        scanned_at=scanned_at,
        claimed=len(rows),
        stalled=tuple(stalled),
    )


async def get_conversation(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    conversation_node_id: UUID,
) -> ConversationRecord | None:
    """Load one visible node-shaped Conversation through the caller's RLS context."""

    async def _get(bound_connection: asyncpg.Connection) -> ConversationRecord | None:
        row = cast(
            Mapping[str, object] | None,
            await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT id, tenant_id, metadata, created_at
FROM nodes
WHERE id = $1
  AND metadata ->> 'shape' = 'skaldos.conversation.v1'
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
""",
                conversation_node_id,
            ),
        )
        if row is None:
            return None
        return _record_from_row(row)

    return await with_principal(principal=principal, connection=connection, fn=_get)


async def list_open_for_requester(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    requester_principal_id: UUID | None = None,
    limit: int = 50,
    cursor: str | None = None,
) -> ConversationListResult:
    """List visible open Conversations requested by ``requester_principal_id``."""

    return await _list_open_for_party(
        principal=principal,
        connection=connection,
        party_metadata_key="requester_principal_id",
        party_principal_id=requester_principal_id or principal.id,
        limit=limit,
        cursor=cursor,
    )


async def list_open_for_requestee(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    requestee_principal_id: UUID | None = None,
    limit: int = 50,
    cursor: str | None = None,
) -> ConversationListResult:
    """List visible open Conversations assigned to ``requestee_principal_id``."""

    return await _list_open_for_party(
        principal=principal,
        connection=connection,
        party_metadata_key="requestee_principal_id",
        party_principal_id=requestee_principal_id or principal.id,
        limit=limit,
        cursor=cursor,
    )


async def list_stalled_in_supervised_domain(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    tenant_ids: Iterable[UUID] | None = None,
    limit: int = 50,
    cursor: str | None = None,
) -> ConversationListResult:
    """List visible stalled Conversations for supervisor-domain scans."""

    async def _list(bound_connection: asyncpg.Connection) -> ConversationListResult:
        cursor_created_at, cursor_id = _parse_list_cursor(cursor)
        domain_tenant_ids = tuple(tenant_ids or principal.visible_tenant_ids)
        rows = cast(
            list[Mapping[str, object]],
            await bound_connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT id, tenant_id, metadata, created_at
FROM nodes
WHERE metadata ->> 'shape' = 'skaldos.conversation.v1'
  AND metadata ->> 'current_state' = 'stalled'
  AND tenant_id = ANY($1::uuid[])
  AND (
    $2::timestamptz IS NULL
    OR (created_at, id) > ($2::timestamptz, $3::uuid)
  )
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
ORDER BY created_at, id
LIMIT $4
""",
                list(domain_tenant_ids),
                cursor_created_at,
                cursor_id,
                _query_limit(limit) + 1,
            ),
        )
        return _list_result_from_rows(rows, limit=_query_limit(limit))

    return await with_principal(principal=principal, connection=connection, fn=_list)


@dataclass(frozen=True, slots=True)
class _InsertedConversation:
    conversation_node_id: UUID
    episode_id: UUID


async def _load_request_act(
    connection: asyncpg.Connection,
    request_act_id: UUID,
) -> Mapping[str, object] | None:
    return cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id, tenant_id, classification, context_of_validity, metadata, authored_by_principal_id
FROM nodes
WHERE id = $1
  AND archived_at IS NULL
""",
            request_act_id,
        ),
    )


async def _load_transition_act(
    connection: asyncpg.Connection,
    act_id: UUID,
) -> Mapping[str, object] | None:
    return await _load_request_act(connection, act_id)


async def _load_conversation_for_update(
    connection: asyncpg.Connection,
    *,
    conversation_node_id: UUID,
) -> Mapping[str, object] | None:
    return cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id, tenant_id, context_of_validity, metadata, authored_by_principal_id, created_at
FROM nodes
WHERE id = $1
  AND metadata ->> 'shape' = 'skaldos.conversation.v1'
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
FOR UPDATE
""",
            conversation_node_id,
        ),
    )


async def _claim_due_stalled_conversations(
    connection: asyncpg.Connection,
    *,
    tenant_ids: tuple[UUID, ...],
    batch_size: int,
) -> list[Mapping[str, object]]:
    return cast(
        list[Mapping[str, object]],
        await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id,
       tenant_id,
       context_of_validity,
       metadata,
       transaction_timestamp() AS scanner_now
FROM nodes
WHERE tenant_id = ANY($1::uuid[])
  AND metadata ->> 'shape' = 'skaldos.conversation.v1'
  AND metadata ->> 'current_state' = ANY($2::text[])
  AND (metadata ->> 'sla_deadline')::timestamptz <= transaction_timestamp()
  AND metadata ->> 'stalled_at' IS NULL
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
ORDER BY (metadata ->> 'sla_deadline')::timestamptz, id
FOR UPDATE SKIP LOCKED
LIMIT $3
""",
            list(tenant_ids),
            [ConversationState.requested.value, ConversationState.promised.value],
            batch_size,
        ),
    )


async def _list_open_for_party(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    party_metadata_key: Literal["requester_principal_id", "requestee_principal_id"],
    party_principal_id: UUID,
    limit: int,
    cursor: str | None,
) -> ConversationListResult:
    async def _list(bound_connection: asyncpg.Connection) -> ConversationListResult:
        cursor_created_at, cursor_id = _parse_list_cursor(cursor)
        rows = cast(
            list[Mapping[str, object]],
            await bound_connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                f"""
SELECT id, tenant_id, metadata, created_at
FROM nodes
WHERE metadata ->> 'shape' = 'skaldos.conversation.v1'
  AND metadata ->> 'current_state' = ANY($1::text[])
  AND metadata ->> '{party_metadata_key}' = $2
  AND (
    $3::timestamptz IS NULL
    OR (created_at, id) > ($3::timestamptz, $4::uuid)
  )
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
ORDER BY created_at, id
LIMIT $5
""",
                [state.value for state in OPEN_CONVERSATION_STATES],
                str(party_principal_id),
                cursor_created_at,
                cursor_id,
                _query_limit(limit) + 1,
            ),
        )
        return _list_result_from_rows(rows, limit=_query_limit(limit))

    return await with_principal(principal=principal, connection=connection, fn=_list)


async def _load_requestee(
    connection: asyncpg.Connection,
    *,
    tenant_id: UUID,
    requestee_principal_id: UUID,
    classification: str,
) -> Mapping[str, object] | None:
    return cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT
  p.id,
  p.kind,
  m.max_clearance,
  app.classification_rank(m.max_clearance)
    >= app.classification_rank($3) AS clearance_sufficient
FROM principals p
JOIN memberships m
  ON m.principal_id = p.id
 AND m.tenant_id = $1
 AND m.revoked_at IS NULL
WHERE p.id = $2
""",
            tenant_id,
            requestee_principal_id,
            classification,
        ),
    )


def _conversation_subject(
    *,
    row: Mapping[str, object],
    metadata: Mapping[str, object],
) -> ConversationRow:
    return ConversationRow(
        id=cast(UUID, row["id"]),
        organization_id=cast(UUID, row["tenant_id"]),
        requester_principal_id=UUID(str(metadata["requester_principal_id"])),
        requestee_principal_id=UUID(str(metadata["requestee_principal_id"])),
    )


def _replay_transition_if_idempotent(
    *,
    principal: Principal,
    draft: ConversationTransitionDraft,
    conversation: Mapping[str, object],
    metadata: Mapping[str, object],
) -> ConversationTransitionResult | None:
    if draft.idempotency_key is None:
        return None
    entries = metadata.get("transition_idempotency")
    if not isinstance(entries, Mapping):
        return None
    transition_entries = cast(Mapping[str, object], entries)
    raw_record = transition_entries.get(draft.idempotency_key)
    if raw_record is None:
        return None
    if not isinstance(raw_record, Mapping):
        raise ConversationServiceError(ConversationServiceErrorCode.IDEMPOTENCY_PAYLOAD_MISMATCH)
    record = cast(Mapping[str, object], raw_record)
    expected = {
        "transition": draft.transition.value,
        "act_id": str(draft.act_id),
        "intent": draft.intent.value,
        "actor_principal_id": str(principal.id),
    }
    for key, value in expected.items():
        if record.get(key) != value:
            raise ConversationServiceError(
                ConversationServiceErrorCode.IDEMPOTENCY_PAYLOAD_MISMATCH
            )
    return ConversationTransitionResult(
        conversation_node_id=draft.conversation_node_id,
        tenant_id=cast(UUID, conversation["tenant_id"]),
        transition=draft.transition,
        current_state=ConversationState(str(record["result_state"])),
        previous_state=ConversationState(str(record["previous_state"])),
        episode_id=UUID(str(record["episode_id"])),
        state_version=_int_metadata(record["state_version"]),
        closed_at=_parse_optional_datetime(record.get("closed_at")),
        replayed=True,
        audit_entry=None,
        outbox_event=None,
    )


def _with_transition_idempotency_record(
    *,
    metadata: Mapping[str, object],
    idempotency_key: str,
    transition: ConversationTransition,
    act_id: UUID,
    actor_principal_id: UUID,
    previous_state: ConversationState,
    result_state: ConversationState,
    episode_id: UUID,
    state_version: int,
    occurred_at: datetime,
    closed_at: datetime | None,
) -> dict[str, object]:
    raw_entries = metadata.get("transition_idempotency")
    entries = (
        dict(cast(Mapping[str, object], raw_entries)) if isinstance(raw_entries, Mapping) else {}
    )
    entries[idempotency_key] = {
        "transition": transition.value,
        "act_id": str(act_id),
        "actor_principal_id": str(actor_principal_id),
        "intent": get_transition_rule(previous_state, transition).intent.value,
        "previous_state": previous_state.value,
        "result_state": result_state.value,
        "episode_id": str(episode_id),
        "state_version": state_version,
        "occurred_at": _datetime_text(occurred_at),
        "closed_at": None if closed_at is None else _datetime_text(closed_at),
    }
    return entries


def _actor_matches_rule(
    *,
    principal: Principal,
    metadata: Mapping[str, object],
    required_actor: RequiredConversationActor,
) -> bool:
    requester_id = UUID(str(metadata["requester_principal_id"]))
    requestee_id = UUID(str(metadata["requestee_principal_id"]))
    match required_actor:
        case "requester" | "requester_or_delegate":
            return principal.id == requester_id
        case "requestee_or_delegate":
            return principal.id == requestee_id
        case "stalled_dispatcher":
            return (
                principal.kind == "agent"
                and principal.auth0_sub.startswith(STALLED_DISPATCHER_AUTH0_SUB)
                and any(role in {"owner", "admin"} for _, role in principal.role_assignments)
            )
    return False


def _authorize_open(
    *,
    principal: Principal,
    tenant_id: UUID,
    context: ConversationContext,
) -> AssertionPolicyDecision:
    return authorize_assertion_intent(
        principal=principal,
        intent=Intent.directive,
        subject=OrgConfigRow(
            id=tenant_id,
            organization_id=tenant_id,
        ),
    )


async def _update_conversation_state(
    connection: asyncpg.Connection,
    *,
    conversation_node_id: UUID,
    tenant_id: UUID,
    expected_state_version: int,
    metadata: Mapping[str, object],
    context: ConversationContext,
    rule_to_state: ConversationState,
    transition: ConversationTransition,
    act_id: UUID,
    principal_id: UUID,
    idempotency_key: str | None,
    occurred_at: datetime,
    closes: bool,
) -> Mapping[str, object] | None:
    next_episode_id = UUID(str(metadata["episode_id"]))
    if transition is ConversationTransition.reopen:
        next_episode_id = cast(
            UUID,
            await connection.fetchval("SELECT uuidv7()"),  # pyright: ignore[reportUnknownMemberType]
        )

    next_metadata = dict(metadata)
    next_metadata["current_state"] = rule_to_state.value
    next_metadata["state_version"] = expected_state_version + 1
    if closes:
        next_metadata["closed_at"] = _datetime_text(occurred_at)
    elif transition is ConversationTransition.reopen:
        next_metadata["closed_at"] = None
        next_metadata["stalled_at"] = None
        next_metadata["episode_id"] = str(next_episode_id)
        next_metadata["request_act_id"] = str(act_id)
        next_metadata["opened_at"] = _datetime_text(occurred_at)
        next_metadata["promised_at"] = None
        next_metadata["completed_at"] = None
        requestee_kind = cast(PrincipalKind, str(next_metadata["requestee_principal_kind"]))
        sla_selection = select_conversation_sla(
            tenant_id=tenant_id,
            task_type=str(next_metadata["task_type"]),
            requestee_principal_kind=requestee_kind,
            opened_at=occurred_at,
        )
        next_metadata["sla_deadline"] = _datetime_text(sla_selection.deadline)
        next_metadata["sla_source"] = sla_selection.source
        next_metadata["sla_config_id"] = None
    if transition is ConversationTransition.promise:
        next_metadata["promised_at"] = _datetime_text(occurred_at)
    elif transition is ConversationTransition.complete:
        next_metadata["completed_at"] = _datetime_text(occurred_at)
    elif transition is ConversationTransition.stall:
        next_metadata["stalled_at"] = _datetime_text(occurred_at)
    if idempotency_key is not None:
        next_metadata["transition_idempotency"] = _with_transition_idempotency_record(
            metadata=metadata,
            idempotency_key=idempotency_key,
            transition=transition,
            act_id=act_id,
            actor_principal_id=principal_id,
            previous_state=ConversationState(str(metadata["current_state"])),
            result_state=rule_to_state,
            episode_id=next_episode_id,
            state_version=expected_state_version + 1,
            occurred_at=occurred_at,
            closed_at=_parse_optional_datetime(next_metadata.get("closed_at")),
        )

    return cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
UPDATE nodes
SET metadata = $2::jsonb,
    context_of_validity = $4::jsonb,
    authored_by_principal_id = app.principal_id()
WHERE id = $1
  AND (metadata ->> 'state_version')::int = $3
RETURNING metadata
""",
            conversation_node_id,
            _canonical_json_text(next_metadata),
            expected_state_version,
            _canonical_json_text(context.model_dump(mode="json")),
        ),
    )


async def _load_existing_conversation(
    connection: asyncpg.Connection,
    *,
    tenant_id: UUID,
    request_act_id: UUID,
) -> Mapping[str, object] | None:
    return cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id, tenant_id, metadata
FROM nodes
WHERE tenant_id = $1
  AND metadata ->> 'shape' = 'skaldos.conversation.v1'
  AND metadata ->> 'request_act_id' = $2
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
FOR UPDATE
""",
            tenant_id,
            str(request_act_id),
        ),
    )


_TRANSITION_EDGE_TYPES: Mapping[ConversationTransition, str] = {
    ConversationTransition.promise: "promised-by",
    ConversationTransition.complete: "completed-by",
    ConversationTransition.satisfy: "satisfied-by",
    ConversationTransition.reject: "rejected-by",
}


async def _ensure_transition_edge(
    connection: asyncpg.Connection,
    *,
    tenant_id: UUID,
    conversation_node_id: UUID,
    act_id: UUID,
    transition: ConversationTransition,
    classification: str,
) -> None:
    relationship_type = _TRANSITION_EDGE_TYPES.get(transition, "relates-to")
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        """
INSERT INTO edges (
  tenant_id,
  source_node_id,
  target_node_id,
  relationship_type,
  classification,
  authored_by_principal_id
)
VALUES ($1, $2, $3, $4, $5, app.principal_id())
ON CONFLICT (source_node_id, target_node_id, relationship_type)
WHERE archived_at IS NULL DO NOTHING
""",
        tenant_id,
        conversation_node_id,
        act_id,
        relationship_type,
        classification,
    )


async def _insert_conversation_node(
    connection: asyncpg.Connection,
    *,
    principal: Principal,
    context: ConversationContext,
    draft: ConversationOpenDraft,
    requestee_kind: PrincipalKind,
    sla_deadline: datetime,
    sla_source: str,
    sla_config_id: UUID | None,
) -> _InsertedConversation | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
WITH conversation_type AS (
  SELECT id
  FROM ontology_type
  WHERE ontology_version_id = $2
    AND name = 'conversation'
    AND lifecycle_state = 'active'
),
tenant_guard AS (
  SELECT $1::uuid AS tenant_id
),
episode AS (
  SELECT uuidv7() AS episode_id
),
inserted AS (
  INSERT INTO nodes (
    type_id,
    context_of_validity,
    body,
    summary,
    metadata,
    authored_by_principal_id,
    draft_state
  )
  SELECT
    conversation_type.id,
    $3::jsonb,
    '',
    'Conversation request',
    jsonb_build_object(
      'shape', 'skaldos.conversation.v1',
      'requester_principal_id', $4::uuid::text,
      'requestee_principal_id', $5::uuid::text,
      'requestee_principal_kind', $6::text,
      'request_act_id', $7::uuid::text,
      'task_type', $8::text,
      'current_state', 'requested',
      'opened_at', $9::text,
      'closed_at', NULL,
      'sla_deadline', $10::text,
      'sla_source', $11::text,
      'sla_config_id', CASE WHEN $12::uuid IS NULL THEN NULL ELSE $12::text END,
      'stalled_at', NULL,
      'episode_id', episode.episode_id::text,
      'state_version', 1,
      'idempotency_key', $13::text
    ),
    app.principal_id(),
    'confirmed'
  FROM conversation_type, tenant_guard, episode
  ON CONFLICT DO NOTHING
  RETURNING id, metadata ->> 'episode_id' AS episode_id
)
SELECT id, episode_id FROM inserted
""",
            context.tenant,
            context.ontology_version,
            _canonical_json_text(context.model_dump(mode="json")),
            principal.id,
            draft.requestee_principal_id,
            requestee_kind,
            draft.request_act_id,
            draft.task_type,
            _datetime_text(draft.occurred_at),
            _datetime_text(sla_deadline),
            sla_source,
            sla_config_id,
            draft.idempotency_key,
        ),
    )
    if row is None:
        return None
    return _InsertedConversation(
        conversation_node_id=cast(UUID, row["id"]),
        episode_id=UUID(str(row["episode_id"])),
    )


def _existing_result(
    row: Mapping[str, object],
    *,
    principal: Principal,
    requestee_kind: PrincipalKind,
    draft: ConversationOpenDraft,
) -> ConversationOpenResult:
    metadata = _json_mapping(row["metadata"])
    expected = {
        "requester_principal_id": str(principal.id),
        "requestee_principal_id": str(draft.requestee_principal_id),
        "request_act_id": str(draft.request_act_id),
        "task_type": draft.task_type,
        "current_state": ConversationState.requested.value,
    }
    for key, value in expected.items():
        if metadata.get(key) != value:
            raise ConversationServiceError(
                ConversationServiceErrorCode.IDEMPOTENCY_PAYLOAD_MISMATCH
            )
    if draft.idempotency_key is not None and metadata.get("idempotency_key") not in {
        None,
        draft.idempotency_key,
    }:
        raise ConversationServiceError(ConversationServiceErrorCode.IDEMPOTENCY_PAYLOAD_MISMATCH)
    return ConversationOpenResult(
        conversation_node_id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        requester_principal_id=principal.id,
        requestee_principal_id=draft.requestee_principal_id,
        requestee_principal_kind=requestee_kind,
        request_act_id=draft.request_act_id,
        current_state=ConversationState.requested,
        episode_id=UUID(str(metadata["episode_id"])),
        state_version=_int_metadata(metadata["state_version"]),
        opened_at=_parse_datetime(metadata["opened_at"]),
        sla_deadline=_parse_datetime(metadata["sla_deadline"]),
        replayed=True,
        audit_entry=None,
        outbox_event=None,
    )


async def _ensure_request_act_edge(
    connection: asyncpg.Connection,
    *,
    tenant_id: UUID,
    conversation_node_id: UUID,
    request_act_id: UUID,
    classification: str,
) -> None:
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        """
INSERT INTO edges (
  tenant_id,
  source_node_id,
  target_node_id,
  relationship_type,
  classification,
  authored_by_principal_id
)
VALUES ($1, $2, $3, 'relates-to', $4, app.principal_id())
ON CONFLICT (source_node_id, target_node_id, relationship_type)
WHERE archived_at IS NULL DO NOTHING
""",
        tenant_id,
        conversation_node_id,
        request_act_id,
        classification,
    )


def _metadata_intent(metadata: Mapping[str, object]) -> Intent | None:
    raw = metadata.get("intent")
    if raw is None:
        act = metadata.get("conversation_act")
        if isinstance(act, Mapping):
            conversation_act = cast(Mapping[str, object], act)
            raw = conversation_act.get("intent")
    if raw is None:
        return None
    try:
        return Intent(str(raw))
    except ValueError:
        return None


def _json_mapping(value: object) -> Mapping[str, object]:
    if isinstance(value, str):
        decoded = json.loads(value)
        if isinstance(decoded, Mapping):
            return cast(Mapping[str, object], decoded)
    if isinstance(value, Mapping):
        return cast(Mapping[str, object], value)
    raise ConversationServiceError(ConversationServiceErrorCode.IDEMPOTENCY_PAYLOAD_MISMATCH)


def _record_from_row(row: Mapping[str, object]) -> ConversationRecord:
    metadata = _json_mapping(row["metadata"])
    created_at = cast(datetime, row["created_at"]).astimezone(UTC).replace(tzinfo=UTC)
    return ConversationRecord(
        conversation_node_id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        requester_principal_id=UUID(str(metadata["requester_principal_id"])),
        requestee_principal_id=UUID(str(metadata["requestee_principal_id"])),
        request_act_id=UUID(str(metadata["request_act_id"])),
        current_state=ConversationState(str(metadata["current_state"])),
        episode_id=UUID(str(metadata["episode_id"])),
        state_version=_int_metadata(metadata["state_version"]),
        task_type=str(metadata["task_type"]),
        opened_at=_parse_datetime(metadata["opened_at"]),
        sla_deadline=_parse_datetime(metadata["sla_deadline"]),
        closed_at=_parse_optional_datetime(metadata.get("closed_at")),
        stalled_at=_parse_optional_datetime(metadata.get("stalled_at")),
        created_at=created_at,
        next_cursor=_format_list_cursor(created_at, cast(UUID, row["id"])),
    )


def _list_result_from_rows(
    rows: list[Mapping[str, object]],
    *,
    limit: int,
) -> ConversationListResult:
    visible_rows = rows[:limit]
    records = tuple(_record_from_row(row) for row in visible_rows)
    next_cursor = records[-1].next_cursor if len(rows) > limit and records else None
    return ConversationListResult(conversations=records, next_cursor=next_cursor)


def _query_limit(limit: int) -> int:
    return min(max(limit, 1), 200)


def _format_list_cursor(created_at: datetime, node_id: UUID) -> str:
    return f"{_datetime_text(created_at)}|{node_id}"


def _parse_list_cursor(cursor: str | None) -> tuple[datetime | None, UUID | None]:
    if cursor is None:
        return None, None
    timestamp_text, node_id_text = cursor.split("|", maxsplit=1)
    return _parse_datetime(timestamp_text), UUID(node_id_text)


def _int_metadata(value: object) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return int(value)
    raise ConversationServiceError(ConversationServiceErrorCode.IDEMPOTENCY_PAYLOAD_MISMATCH)


def _canonical_json_text(value: Mapping[str, Any]) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _datetime_text(value: datetime) -> str:
    return value.astimezone(UTC).replace(tzinfo=UTC).isoformat().replace("+00:00", "Z")


def _parse_datetime(value: object) -> datetime:
    text = str(value)
    normalized = text[:-1] + "+00:00" if text.endswith("Z") else text
    parsed = datetime.fromisoformat(normalized)
    return parsed.astimezone(UTC).replace(tzinfo=UTC)


def _parse_optional_datetime(value: object | None) -> datetime | None:
    if value is None:
        return None
    return _parse_datetime(value)
