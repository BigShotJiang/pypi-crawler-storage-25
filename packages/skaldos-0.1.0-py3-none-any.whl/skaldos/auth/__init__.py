"""Auth chokepoint --- Auth0 JWT verification (ADR 19, MP10, §4.1, §10.2).

Surface:

- :class:`TokenVerifier` --- runtime-checkable Protocol every JWT
  validator (production :class:`Auth0Verifier` in T4; any future test
  fake) implements. Single async method:
  ``verify(token: str) -> VerifiedClaims``. Defined here so consumer
  code (Slice 1's principal-hydration-middleware peer feature; Slice 4+
  protected endpoints) holds a ``TokenVerifier`` reference and never
  imports a concrete implementation --- the abstraction is the
  chokepoint that lets test injection happen without ``if testing:``
  branches (AP5).
- :class:`VerifiedClaims` --- the validator's output, frozen Pydantic
  model. Once a token is verified the claim shape is immutable;
  downstream consumers (principal-hydration-middleware, Slice 5 audit,
  Slice 7+ delegation) read named fields and never mutate.
  Field set per master-plan.md "Shared artifacts & contracts" table:
  ``kind, sub, auth0_sub, email, org_id, azp, iss, aud, exp, iat,
  scope_str, raw_claims``.
- :class:`RawClaims` --- the *internal* pre-discriminator model that
  the production validator uses to decode the JWT payload before the
  human/agent decision is made. Strict-typed; the
  ``@model_validator(mode="after")`` enforces the discriminator
  mutual-exclusivity rule from
  ``tests/fixtures/auth0/auth0_spec.json`` § ``validator_obligations``
  #5--#6: "reject if neither ``gty == 'client-credentials'`` nor
  ``org_id`` present" and "reject if BOTH are present". Exposed for
  unit-test pinning of the discriminator decision; production code
  outside the validator does not import it.
- Full exception hierarchy (re-exported from :mod:`.errors`) with
  :data:`event_name` constants per ``03-technical-implementation.md``
  § "Error management" --- one ``auth.<reason>`` event per failure
  class. Subsequent slices alert on these event names; renaming one
  is a breaking change to the operator runbook surface.

Pydantic ``model_validator(mode="after")`` exception flow
---------------------------------------------------------

The brainstorm in ``03-technical-implementation.md`` § "models.py"
chose to raise :class:`AmbiguousDiscriminator` / :class:`UnrecognizedFlow`
*directly* from inside the validator (not via ``ValueError`` →
``ValidationError``). Per Pydantic v2 docs and a verification probe
run during T1 implementation: ``mode="after"`` validators run
*after* the model has been constructed; exceptions raised inside
them propagate to the caller **unwrapped**. Only ``mode="before"``
validators land inside Pydantic's input-validation pipeline and
become ``ValidationError``. The unit tests in
``tests/unit/test_auth_models.py`` assert directly with
``pytest.raises(AmbiguousDiscriminator)`` --- not a ``ValidationError``
unwrap --- which pins the propagation contract.

The integration-test mock issuer
(``tests/integration/_framework/auth0_mock.py``, Slice 0 / T3) lives
in the test tree --- not here --- because it is test-only by
construction. The production ``Auth0Verifier`` (T4) consumes the
mock-issued tokens via ``AUTH0_JWKS_URL_OVERRIDE`` --- exactly the
same code path as production, just a different JWKS URL (AP5
recursive: no test-side bypass even in tests).

This package ships in PR-sized tasks (T1 plants this file; T2--T6
fill in ``config.py``, ``jwks.py``, ``verifier.py``, and
``fastapi.py``); see
``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/05-task-list.md``
for the orchestration. T7 lands the operator runbook at
``docs/runbooks/auth0-validator.md`` --- the operator-facing surface
for the env-var matrix, JWKS rotation / outage behavior, the
exception/HTTP-code/log-event table, debugging recipes, the fixture
re-record flow, and the PII discipline that this package's contract
encodes.

References: ADR 19 (Auth0 humans + agents same JWT shape), MP10
(humans-and-agents-as-equal Principals), §3.1 (plural-tenant principal
from commit one), §4.1 (verification is the *first* chokepoint;
authorization composes via Slice 2's ``can(action, subject)``),
§10.2 (OpenAPI + dependency surfaces), §13.2 (every rejection is
auditable), AP4/AP5 (no debug-mode bypass), MP6 (agents are clients;
same code path);
``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``,
``02-edge-cases.md`` (E8/E9/E12/E13 are property-test targets pinned
in T1).
"""

from __future__ import annotations

from .config import AuthConfig
from .errors import (
    AmbiguousDiscriminator,
    InvalidAlgorithm,
    InvalidAudience,
    InvalidIssuer,
    InvalidSignature,
    JWKSUnavailable,
    MalformedClaims,
    TokenExpired,
    TokenNotYetValid,
    TokenTooLarge,
    TokenVerificationError,
    UnknownKid,
    UnrecognizedFlow,
)
from .fastapi import (
    auth_lifespan,
    clear_global_verifier_for_tests,
    get_global_verifier,
    set_global_verifier_for_tests,
    verify_token,
)
from .jwks import JWKSCache
from .models import RawClaims, VerifiedClaims
from .protocol import TokenVerifier
from .verifier import Auth0Verifier

__all__ = [
    "AmbiguousDiscriminator",
    "Auth0Verifier",
    "AuthConfig",
    "InvalidAlgorithm",
    "InvalidAudience",
    "InvalidIssuer",
    "InvalidSignature",
    "JWKSCache",
    "JWKSUnavailable",
    "MalformedClaims",
    "RawClaims",
    "TokenExpired",
    "TokenNotYetValid",
    "TokenTooLarge",
    "TokenVerificationError",
    "TokenVerifier",
    "UnknownKid",
    "UnrecognizedFlow",
    "VerifiedClaims",
    "auth_lifespan",
    "clear_global_verifier_for_tests",
    "get_global_verifier",
    "set_global_verifier_for_tests",
    "verify_token",
]
