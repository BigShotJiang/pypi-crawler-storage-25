"""JWKS cache for the auth chokepoint (T3).

Per ``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``
§ "jwks.py" and ``05-task-list.md`` § T3: :class:`JWKSCache` is the
single network surface in the auth chokepoint. The production
:class:`~skaldos.auth.verifier.Auth0Verifier` (T4, blocked-by this
task) calls :meth:`JWKSCache.get_signing_key` once per token to obtain
the public RSA key the JWT library uses to verify the RS256 signature.

Salient behaviors
-----------------

- **Single-flight refresh** (:class:`asyncio.Lock`). 50 concurrent first
  requests fan out into exactly one upstream HTTP call (E26).
- **TTL** = ``min(AUTH0_JWKS_TTL_SECONDS, upstream Cache-Control max-age)``
  (E15, E27). Auth0 may say "refresh more often"; we honor that. We
  never trust upstream to say "refresh less often" --- key rotation
  safety overrides upstream-supplied longevity.
- **Refresh rate limit** (``time.monotonic() - last_refresh_attempt <
  AUTH0_JWKS_MIN_REFRESH_INTERVAL_SECONDS``). Bounds JWKS refresh
  traffic against forged-``kid`` DoS (E14).
- **Stale-while-revalidate**: on TTL expiry, the stale cache continues
  serving until the in-flight refresh resolves. Past
  ``AUTH0_JWKS_STALE_GRACE_SECONDS`` of TTL expiry,
  :class:`~skaldos.auth.errors.JWKSUnavailable` (E15).
- **Cold-start failure**: empty cache + first fetch fails →
  :class:`~skaldos.auth.errors.JWKSUnavailable` (E6.cold).
- **Warm-start failure**: refresh fails while cache is non-empty → log
  ``auth.jwks_refresh_failed`` (warn) + serve cached JWKS until TTL
  expires (E6.warm).
- **Refresh-on-unknown-kid (E7)**: ``get_signing_key(kid)`` with a kid
  not in cache triggers a refresh (subject to the rate limit). Still
  missing post-refresh → :class:`~skaldos.auth.errors.UnknownKid`.

Why ``RSAAlgorithm.from_jwk`` and not ``PyJWKClient``
-----------------------------------------------------

PyJWT ships two JWK consumption surfaces:

- :class:`jwt.PyJWKClient` --- a high-level client that does its own
  HTTP fetching, caching, and key resolution. It owns the ``httpx`` /
  ``urllib`` call. **Rejected** because it duplicates the cache
  semantics we need to own at this layer (single-flight, rate-limited
  refresh, stale-while-revalidate, structured-log warn on warm
  failure, ``AUTH0_JWKS_URL_OVERRIDE`` injection seam) --- using it
  would mean either configuring two layers of caching or bypassing
  one. The brainstorm pins this layer's behavior; ``PyJWKClient``
  cannot match it.
- :func:`jwt.algorithms.RSAAlgorithm.from_jwk` --- a stateless helper
  that converts a JWK dict (``{"kty": "RSA", "n": ..., "e": ...,
  "kid": ...}``) into a public-key object that ``jwt.decode`` accepts
  via the ``key=`` parameter. **Chosen.** Ownership of the HTTP fetch
  and the cache stays here; the conversion is a pure function on the
  cached JWK dict. Tests can drop a JWK dict into the cache directly
  without touching the network.

Why a separate module (vs folding into ``verifier.py``)
-------------------------------------------------------

Single responsibility per the brainstorm: this module owns the JWKS
network surface; ``verifier.py`` (T4) owns the JWT decode contract.
Splitting them lets the unit-test suite for this module
(``tests/unit/test_jwks_cache.py``) exercise cache semantics without
spinning up a JWT decoder, and lets T4's tests use a real cache
populated via :meth:`JWKSCache._fetch_and_install` (or by injecting a
:class:`httpx.MockTransport`-backed client).

Why the http_client is injected via ``__init__``
------------------------------------------------

The brainstorm originally said "instance-scoped, kept inside the
cache; not injected." On T3 implementation we relaxed to
constructor-injection so tests can pass an :class:`httpx.AsyncClient`
backed by an :class:`httpx.MockTransport` --- exactly the same code
path as production (AP5). Lifecycle ownership is the caller's
(T5's FastAPI ``lifespan`` constructs both the client and the
:class:`JWKSCache`, and tears the client down on shutdown);
:meth:`aclose` here only releases the cache's own state.

Why the clock is injected
-------------------------

The brainstorm pins :func:`time.monotonic` as the clock source for
the rate-limit gate ("``time.monotonic()`` - ``last_refresh_attempt``
< ``AUTH0_JWKS_MIN_REFRESH_INTERVAL_SECONDS``"). ``freezegun`` does
not patch :func:`time.monotonic` reliably across Python versions
(the underlying CPython API gates monotonic-clock patching), so a
test that needs to advance time must control the clock through a
clean seam. Constructor-injection of the clock callable
(default :func:`time.monotonic`) is the AP5-clean form: production
runs through the same code path; only the clock differs in tests.

References: §14.7 (rate-limited refresh + fail-on-startup hygiene
generalizes to "rate-limited refresh hygiene"), MP6 (agents are
clients --- same JWKS path for both), ADR 19 (Auth0 RS256), AP5 (no
test-only bypass --- the override seam is the only injection point);
``02-edge-cases.md`` E6 (cold/warm), E7 (refresh-on-unknown-kid),
E14 (Cache-Control), E15 (stale-while-revalidate), E26 (single-
flight), E27 (refresh rate limit);
``03-technical-implementation.md`` § "jwks.py";
``tests/fixtures/auth0/auth0_spec.json`` § ``validator_obligations``
#1 (signature + JWKS).
"""

from __future__ import annotations

import asyncio
import re
import time
from collections.abc import Callable
from typing import Any, cast

import httpx
from jwt.algorithms import RSAAlgorithm
from skaldos_log import log

from .config import AuthConfig
from .errors import JWKSUnavailable, UnknownKid

# ---------------------------------------------------------------------------
# Cache-Control parsing.
#
# Auth0's JWKS endpoint emits ``Cache-Control: public, max-age=600`` on
# successful responses (per the Auth0 docs and the captured fixture flow).
# We only consume ``max-age``; ``public`` / ``private`` / ``no-store`` etc.
# are ignored at this layer (the cache itself is process-local; HTTP cache
# semantics like ``private`` are not meaningful here).
#
# Special cases we honor:
# - ``no-cache``: treat as effective TTL = 0 (refresh every call). This is
#   the behavior the brainstorm pins in the testing strategy
#   ("test_cache_control_no_cache_treats_as_zero").
# - ``no-store``: same as ``no-cache`` for our purposes.
# - ``max-age=N``: parse N as a non-negative integer.
# - Header missing or unparseable: fall back to the configured TTL only.
#
# We do *not* honor ``s-maxage`` (shared-cache directive) --- the JWKS
# cache is per-process, not a shared cache. Stick to ``max-age``.
# ---------------------------------------------------------------------------

_MAX_AGE_RE: re.Pattern[str] = re.compile(r"max-age\s*=\s*(\d+)", re.IGNORECASE)


def _parse_cache_control_max_age(header_value: str | None) -> int | None:
    """Parse the ``max-age`` directive from a Cache-Control header.

    Returns the parsed seconds (int, ≥0), or ``None`` if the header is
    absent / unparseable. Returns ``0`` for ``no-cache`` / ``no-store``
    so the caller can treat upstream's "do not cache" as "effective
    TTL = 0".

    The match is case-insensitive on the directive name to be robust
    to upstream header-emitter quirks (HTTP headers are
    case-insensitive on names; values are case-sensitive but
    Cache-Control directives are conventionally lowercase).
    """
    if header_value is None:
        return None
    lowered = header_value.lower()
    if "no-cache" in lowered or "no-store" in lowered:
        return 0
    match = _MAX_AGE_RE.search(header_value)
    if match is None:
        return None
    try:
        return int(match.group(1))
    except ValueError:  # pragma: no cover -- regex guarantees \d+
        return None


# ---------------------------------------------------------------------------
# JWKSCache.
#
# State invariants (held under `_state_lock` for read-modify-write):
#
# - `_keys` is the latest successfully-fetched JWKS, keyed by `kid`.
#   Empty dict means "cache cold" (never successfully fetched). Each
#   value is the verbatim JWK dict (``{"kty": "RSA", "n": ..., "e": ...,
#   "kid": ...}``); conversion to a key object happens at lookup time
#   via `RSAAlgorithm.from_jwk`.
# - `_last_fetched_monotonic` is the clock reading at the last
#   successful fetch. None means "no successful fetch yet".
# - `_effective_ttl_seconds` is min(configured TTL, upstream max-age).
#   Recomputed on every successful fetch.
# - `_last_refresh_attempt_monotonic` is the clock reading at the
#   start of the most recent refresh attempt (success or failure).
#   None means "no attempt yet". Drives the rate-limit gate.
#
# `_refresh_lock` is the single-flight lock around the upstream HTTP
# call. It is *separate* from `_state_lock`: a long upstream call must
# not block readers of `_keys` during the stale-while-revalidate
# window. Concurrent readers hit `_keys` directly; one writer holds
# `_refresh_lock` while fetching, then briefly takes `_state_lock` to
# install the result.
# ---------------------------------------------------------------------------


class JWKSCache:
    """Single-flight, TTL-bounded, rate-limited JWKS cache.

    See module docstring for the full semantic contract. Public surface
    is two methods: :meth:`get_signing_key` (called once per token by
    :class:`~skaldos.auth.verifier.Auth0Verifier` in T4) and
    :meth:`aclose` (called by T5's FastAPI ``lifespan`` on shutdown).

    Construction parameters
    -----------------------

    - ``config``: the :class:`~skaldos.auth.config.AuthConfig` already
      instantiated by the lifespan. The cache reads ``auth0_issuer``,
      ``auth0_jwks_url_override``, ``auth0_jwks_ttl_seconds``,
      ``auth0_jwks_min_refresh_interval_seconds``, and
      ``auth0_jwks_stale_grace_seconds``.
    - ``http_client``: an :class:`httpx.AsyncClient`. Lifecycle is the
      caller's; we never call ``aclose`` on it from this class. Tests
      pass a client backed by :class:`httpx.MockTransport` to stub
      upstream without touching the network.
    - ``clock`` (kw-only, default :func:`time.monotonic`): the
      monotonic clock function. Tests inject a controllable clock so
      TTL expiry and rate-limit windows can be advanced
      deterministically without ``freezegun`` patching CPython's
      monotonic-clock internals.
    """

    def __init__(
        self,
        config: AuthConfig,
        http_client: httpx.AsyncClient,
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._config = config
        self._http_client = http_client
        self._jwks_url = self._derive_jwks_url(config)
        self._clock = clock

        # --- Cache state. ------------------------------------------------
        self._keys: dict[str, dict[str, Any]] = {}
        self._last_fetched_monotonic: float | None = None
        self._effective_ttl_seconds: float = float(config.auth0_jwks_ttl_seconds)
        self._last_refresh_attempt_monotonic: float | None = None

        # --- Locks. ------------------------------------------------------
        # Single-flight refresh: only one upstream HTTP call in flight
        # at a time (E26). Concurrent first-request fan-out → one fetch.
        self._refresh_lock = asyncio.Lock()
        # State guard: brief critical sections around state reads/writes
        # so a stale-window reader sees a consistent snapshot of
        # (_keys, _last_fetched_monotonic). The lock is taken for short
        # synchronous sections only --- never held across an `await`
        # that does network I/O.
        self._state_lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # URL derivation.
    # ------------------------------------------------------------------

    @staticmethod
    def _derive_jwks_url(config: AuthConfig) -> str:
        """Compute the JWKS URL from config.

        Production path: ``{auth0_issuer}.well-known/jwks.json``.
        ``auth0_issuer`` always has a trailing slash (validated by
        :class:`~skaldos.auth.config.AuthConfig`'s field validator),
        so plain string concatenation is correct --- no double-slash,
        no missing-slash defect.

        Test path: if ``auth0_jwks_url_override`` is set, use that
        verbatim. The override is the AP5-clean test seam: the
        production code runs through the same network path; only the
        URL changes. The :class:`AuthConfig` model validator refuses
        to construct in production with the override set, so by the
        time we reach this code path the override is known-safe.
        """
        if config.auth0_jwks_url_override is not None:
            return config.auth0_jwks_url_override
        return f"{config.auth0_issuer}.well-known/jwks.json"

    # ------------------------------------------------------------------
    # Public API.
    # ------------------------------------------------------------------

    async def get_signing_key(self, kid: str) -> Any:
        """Return the verifying key object for ``kid``, refreshing if needed.

        Returns the public-key object (a
        :class:`cryptography.hazmat.primitives.asymmetric.rsa.RSAPublicKey`
        produced by :func:`jwt.algorithms.RSAAlgorithm.from_jwk`)
        that :func:`jwt.decode` accepts as its ``key`` parameter.

        Raises:

        - :class:`~skaldos.auth.errors.UnknownKid` --- ``kid`` is
          not in the cache, refresh ran (or was rate-limit-skipped),
          and ``kid`` is still not present (E7).
        - :class:`~skaldos.auth.errors.JWKSUnavailable` --- cold
          start with upstream unreachable (E6.cold), or warm cache
          past the stale grace window with refresh still failing
          (E15 hard limit).

        Behavior matrix (see module docstring for the full edge-case
        list; cross-references in ``02-edge-cases.md``):

        +-------------------------+-------------------+-----------------------+
        | State                   | Action            | Outcome               |
        +=========================+===================+=======================+
        | Empty cache             | Fetch (single-    | Populated; return key |
        |                         | flight)           | OR `JWKSUnavailable`  |
        +-------------------------+-------------------+-----------------------+
        | Fresh cache, kid hit    | None              | Return key (no I/O)   |
        +-------------------------+-------------------+-----------------------+
        | Fresh cache, kid miss   | Refresh (rate-    | Return key OR         |
        |                         | limited)          | `UnknownKid`          |
        +-------------------------+-------------------+-----------------------+
        | TTL expired, in grace,  | Trigger refresh;  | Return stale key      |
        | kid hit                 | serve stale       | (eventually replaced) |
        +-------------------------+-------------------+-----------------------+
        | TTL expired, past grace | Force refresh;    | Return key OR         |
        |                         | no stale fallback | `JWKSUnavailable`     |
        +-------------------------+-------------------+-----------------------+

        Concurrency: 50 simultaneous calls with an empty cache produce
        exactly one upstream HTTP request (E26). Single-flight is
        enforced by :attr:`_refresh_lock`; non-fetching callers wait
        on it. After the lock releases, every waiter re-checks the
        cache before deciding whether to fetch itself --- the standard
        double-checked-locking idiom for caches.
        """
        # Fast path: cache is fresh AND kid is present. No locks beyond
        # the brief state read --- the common case is uncontended.
        async with self._state_lock:
            cached = self._keys.get(kid)
            is_fresh = self._is_fresh_locked()
        if cached is not None and is_fresh:
            return self._jwk_to_key(cached)

        # Slow path: either cache is cold, kid is missing, TTL has
        # expired, or some combination. The refresh-rate-limit gate
        # decides whether we actually fetch.
        return await self._refresh_and_lookup(kid)

    async def aclose(self) -> None:
        """Release the cache's own asyncio state.

        The injected :attr:`_http_client` is **not** closed here ---
        its lifecycle is the caller's (T5's FastAPI lifespan owns it).
        This method exists for symmetry with the lifecycle pattern
        used by other infrastructure components (a no-op today, kept
        as the documented teardown seam so callers don't grow a habit
        of skipping cleanup).
        """
        # Currently a no-op: asyncio.Lock has no resources to release
        # beyond what GC handles. Method is here for the lifespan-
        # contract symmetry described in the module docstring.
        return

    # ------------------------------------------------------------------
    # Internal: cache freshness + refresh orchestration.
    # ------------------------------------------------------------------

    def _is_fresh_locked(self) -> bool:
        """Return True iff the cache was populated and TTL has not expired.

        Caller must hold :attr:`_state_lock`. "Fresh" means
        ``clock() - last_fetched_monotonic < effective_ttl``. An empty
        cache (``_last_fetched_monotonic is None``) is never fresh.
        """
        if self._last_fetched_monotonic is None:
            return False
        elapsed = self._clock() - self._last_fetched_monotonic
        return elapsed < self._effective_ttl_seconds

    def _is_within_stale_grace_locked(self) -> bool:
        """Return True iff TTL has expired but we're still within the stale grace window.

        Caller must hold :attr:`_state_lock`. ``effective_ttl +
        stale_grace`` is the absolute hard cap; past that the warm-
        failure path degrades to :class:`JWKSUnavailable`.
        """
        if self._last_fetched_monotonic is None:
            return False
        elapsed = self._clock() - self._last_fetched_monotonic
        return elapsed < self._effective_ttl_seconds + self._config.auth0_jwks_stale_grace_seconds

    def _is_within_refresh_rate_limit_locked(self) -> bool:
        """Return True iff a refresh attempt happened recently enough to skip another.

        Caller must hold :attr:`_state_lock`. Bounds JWKS refresh
        traffic against forged-``kid`` DoS (E14): if the previous
        attempt is within the configured min-interval, skip the
        upstream call entirely.

        Returning ``True`` here means "DO NOT refresh"; the caller
        falls through to "serve from cache or raise UnknownKid".
        """
        if self._last_refresh_attempt_monotonic is None:
            return False
        elapsed = self._clock() - self._last_refresh_attempt_monotonic
        return elapsed < self._config.auth0_jwks_min_refresh_interval_seconds

    async def _refresh_and_lookup(self, kid: str) -> Any:
        """Run the refresh state machine for a non-fast-path lookup.

        This is the only place that decides between (a) fetching
        upstream, (b) serving stale, (c) raising
        :class:`UnknownKid` / :class:`JWKSUnavailable`. The state
        machine maps to ``02-edge-cases.md`` E6/E7/E14/E15/E26/E27 ---
        each branch is annotated with the edge case it implements.

        Rate-limit semantics
        --------------------

        Per E14: "an unknown-``kid`` lookup that triggered a refresh
        on its first miss falls through to UnknownKid on subsequent
        misses without re-fetching." This means the rate limit
        applies *only* when a previous miss-driven (or TTL-driven)
        refresh attempt has happened; the initial cache population is
        not a "refresh attempt" in the rate-limit sense. The state
        machine tracks ``_last_refresh_attempt_monotonic`` only at
        :meth:`_fetch_and_install` calls that happen *because* of a
        miss or TTL expiry --- not the first-ever cold-start fetch.
        """
        # Acquire the single-flight lock. After we hold it, re-check
        # cache state: another coroutine may have just refreshed it
        # while we were waiting (E26 fan-out path).
        async with self._refresh_lock:
            async with self._state_lock:
                cached = self._keys.get(kid)
                is_fresh = self._is_fresh_locked()
                in_grace = self._is_within_stale_grace_locked()
                rate_limited = self._is_within_refresh_rate_limit_locked()
                cache_empty = self._last_fetched_monotonic is None

            # Re-check the fast path after acquiring the lock --- the
            # waiter behind a single-flight fetch sees a populated cache.
            if cached is not None and is_fresh:
                return self._jwk_to_key(cached)

            # E14 short-circuit: if we tried to refresh too recently,
            # don't fetch again. Behavior depends on whether the cache
            # has anything usable.
            if rate_limited:
                if cached is not None and in_grace:
                    # Stale-but-trusted serve under rate limit. The
                    # caller never sees the rate-limit short-circuit.
                    return self._jwk_to_key(cached)
                if cache_empty:
                    # Cold + rate-limited cannot occur in practice
                    # because ``_last_refresh_attempt_monotonic`` is
                    # only set on miss/TTL-driven refreshes, not on
                    # cold-start fetches. Defense-in-depth: if we ever
                    # do reach this state, surface as JWKSUnavailable.
                    raise JWKSUnavailable(
                        f"JWKS cache empty and refresh rate-limited "
                        f"(min_interval="
                        f"{self._config.auth0_jwks_min_refresh_interval_seconds}s)."
                    )
                # Cache populated, kid missing, AND rate-limited.
                # The kid won't appear without a refresh, and we're
                # rate-limited (E14 forged-kid storm defense).
                raise UnknownKid(
                    f"kid={kid!r} not in cache and refresh rate-limited "
                    f"(min_interval="
                    f"{self._config.auth0_jwks_min_refresh_interval_seconds}s)."
                )

            # Past the stale grace window with a populated cache --- the
            # last successful fetch is too old to trust. Force refresh;
            # if it fails, raise JWKSUnavailable.
            past_grace = not cache_empty and not is_fresh and not in_grace

            # This refresh attempt is "miss-driven" iff the cache is
            # populated --- meaning a previous successful fetch is on
            # record, and we're refreshing because either the kid is
            # absent or TTL has expired. Cold-start fetches do not
            # update the rate-limit clock; only miss/TTL-driven
            # refreshes do (E14 contract).
            mark_rate_limit = not cache_empty

            try:
                await self._fetch_and_install(mark_rate_limit=mark_rate_limit)
            except (httpx.HTTPError, JWKSUnavailable) as fetch_err:
                # Refresh failed. Three cases:
                #
                # (a) Cold start (E6.cold): cache still empty → raise.
                # (b) Past stale grace (E15 hard limit): raise.
                # (c) Warm + within grace (E6.warm): log warn, serve
                #     stale.
                if cache_empty:
                    raise JWKSUnavailable(
                        f"JWKS cold-start fetch failed: {fetch_err!r}"
                    ) from fetch_err
                if past_grace:
                    raise JWKSUnavailable(
                        f"JWKS stale grace exceeded "
                        f"(grace="
                        f"{self._config.auth0_jwks_stale_grace_seconds}s) "
                        f"with upstream still failing: {fetch_err!r}"
                    ) from fetch_err
                # Warm failure: structured-warn and fall through to
                # serve from the existing cache.
                log.warning(
                    "auth.jwks_refresh_failed",
                    jwks_url=self._jwks_url,
                    error_class=type(fetch_err).__name__,
                    error_repr=repr(fetch_err),
                )
                async with self._state_lock:
                    cached_after = self._keys.get(kid)
                if cached_after is not None:
                    return self._jwk_to_key(cached_after)
                # Refresh failed AND kid still absent. We're in the
                # E14 "forged kid + warm cache + transient outage"
                # corner: serve the warm-cache rejection (UnknownKid)
                # rather than masking as JWKSUnavailable.
                raise UnknownKid(
                    f"kid={kid!r} not in cache; refresh attempt failed: {fetch_err!r}"
                ) from fetch_err

            # Refresh succeeded. Return the key for `kid` if present;
            # else raise UnknownKid (E7 negative path).
            async with self._state_lock:
                refreshed = self._keys.get(kid)
            if refreshed is not None:
                return self._jwk_to_key(refreshed)
            raise UnknownKid(
                f"kid={kid!r} not present in JWKS even after refresh (jwks_url={self._jwks_url!r})."
            )

    # ------------------------------------------------------------------
    # Internal: HTTP fetch + cache install.
    # ------------------------------------------------------------------

    async def _fetch_and_install(self, *, mark_rate_limit: bool = True) -> None:
        """Fetch JWKS from upstream and atomically replace the cache.

        When ``mark_rate_limit`` is true (the default --- miss/TTL-driven
        refreshes), marks ``_last_refresh_attempt_monotonic`` *before*
        the network call so the rate-limit gate counts the attempt
        regardless of outcome. When false (cold-start fetch), the
        timer stays None so the next miss-driven lookup is allowed to
        refresh per E14's "first miss triggers refresh" contract.

        On success, replaces ``_keys`` / ``_last_fetched_monotonic``
        / ``_effective_ttl_seconds`` under :attr:`_state_lock`. On
        failure, propagates the exception --- the orchestration layer
        in :meth:`_refresh_and_lookup` decides cold/warm/past-grace
        handling.

        Effective TTL = min(configured TTL, upstream Cache-Control
        max-age). When upstream sends ``no-cache`` / ``no-store`` we
        treat upstream as TTL=0 (refresh every call) per E27. When
        the header is absent or unparseable, fall back to the
        configured TTL only.
        """
        if mark_rate_limit:
            async with self._state_lock:
                self._last_refresh_attempt_monotonic = self._clock()

        # Network I/O outside any state lock. Concurrent readers can
        # continue serving stale entries during the fetch (stale-while-
        # revalidate, E15).
        response = await self._http_client.get(self._jwks_url)
        response.raise_for_status()
        # `response.json()` returns Any. Narrow via isinstance checks
        # before reading; everything beyond the JWKS parser sees a
        # well-typed dict[str, dict[str, Any]] (`new_keys`).
        payload_raw: Any = response.json()

        # Compute effective TTL from response headers.
        upstream_max_age = _parse_cache_control_max_age(response.headers.get("cache-control"))
        configured_ttl = self._config.auth0_jwks_ttl_seconds
        if upstream_max_age is None:
            effective_ttl = float(configured_ttl)
        else:
            effective_ttl = float(min(configured_ttl, upstream_max_age))

        # Validate payload shape minimally --- a malformed JWKS is a
        # contract violation that we treat as a fetch failure.
        if not isinstance(payload_raw, dict):
            raise JWKSUnavailable(f"JWKS payload not a dict (got {type(payload_raw).__name__}).")
        payload = cast("dict[str, Any]", payload_raw)
        keys_list_raw = payload.get("keys")
        if not isinstance(keys_list_raw, list):
            raise JWKSUnavailable(
                f"JWKS payload missing 'keys' array (got {type(keys_list_raw).__name__})."
            )
        keys_list = cast("list[Any]", keys_list_raw)

        new_keys: dict[str, dict[str, Any]] = {}
        for jwk_entry in keys_list:
            if not isinstance(jwk_entry, dict):
                continue
            jwk = cast("dict[str, Any]", jwk_entry)
            kid_value = jwk.get("kid")
            if isinstance(kid_value, str):
                new_keys[kid_value] = jwk

        # Atomic install under the state lock.
        async with self._state_lock:
            self._keys = new_keys
            self._last_fetched_monotonic = self._clock()
            self._effective_ttl_seconds = effective_ttl

    # ------------------------------------------------------------------
    # Internal: JWK → key conversion.
    # ------------------------------------------------------------------

    @staticmethod
    def _jwk_to_key(jwk: dict[str, Any]) -> Any:
        """Convert a JWK dict to a public-key object suitable for ``jwt.decode``.

        ``jwt.algorithms.RSAAlgorithm.from_jwk`` accepts either a JSON
        string or a dict-shaped JWK and returns an
        :class:`cryptography.hazmat.primitives.asymmetric.rsa.RSAPublicKey`.
        That key object is what :func:`jwt.decode` consumes via its
        ``key=`` parameter when ``algorithms=["RS256"]``.

        Pure function on the cached JWK dict --- can run inside hot
        paths without re-fetching.
        """
        return RSAAlgorithm.from_jwk(jwk)
