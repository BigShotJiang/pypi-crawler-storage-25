"""Pydantic models for the auth chokepoint (T1).

Per ``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``
§ "models.py": two models compose the validator's claim-shape
contract.

:class:`RawClaims` --- internal, pre-discriminator
--------------------------------------------------

The decoded JWT payload, before the human/agent decision is made.
Strict-typed (``ConfigDict(extra="allow", strict=True)``) so type
coercion does not silently fix Auth0 contract drift. ``extra="allow"``
preserves any custom claim that Auth0 (or an Auth0 Action) injects ---
:class:`VerifiedClaims.raw_claims` later carries the verbatim decoded
dict for downstream reads (Slice 7+ delegation reads ``act`` from
``raw_claims`` without changing this model's signature).

The ``@model_validator(mode="after")`` enforces ``auth0_spec.json``
§ ``validator_obligations`` #5--#6: "reject if neither
``gty == 'client-credentials'`` nor ``org_id`` present" and "reject if
BOTH are present". Failures raise
:class:`~skaldos.auth.errors.AmbiguousDiscriminator` and
:class:`~skaldos.auth.errors.UnrecognizedFlow` directly.

Pydantic v2 ``model_validator(mode="after")`` exception flow
............................................................

Verified empirically during T1 implementation: ``mode="after"``
validators run *after* the model has been constructed, so exceptions
raised inside them propagate to the caller **unwrapped** (not
wrapped in ``pydantic.ValidationError``). Only ``mode="before"``
validators land inside Pydantic's input-validation pipeline. The
unit test ``test_ambiguous_discriminator_raises_subclass`` in
:mod:`tests.unit.test_auth_models` asserts directly with
``pytest.raises(AmbiguousDiscriminator)`` (no
``ValidationError`` unwrap) which pins the propagation contract;
a future Pydantic that wraps after-validator exceptions would fail
that test loudly.

:class:`VerifiedClaims` --- frozen output
-----------------------------------------

The validator's externally-visible output. Frozen
(``ConfigDict(frozen=True)``) so once a token is verified, the
claim shape is immutable; downstream consumers
(principal-hydration-middleware in T6 of the peer feature; Slice 5
audit emitter; Slice 7+ delegation) read named fields and never
mutate. Any Pydantic field assignment after construction raises
:class:`pydantic.ValidationError`.

Field set is pinned in ``master-plan.md`` § "Shared artifacts &
contracts" (under ``VerifiedClaims``):
``kind, sub, auth0_sub, email, org_id, azp, iss, aud, exp, iat,
scope_str, raw_claims``. ``frozen=True`` is the only contract guard
beyond the field set.

References: ADR 19, MP10 (one model, one discriminator field --- not
parallel code paths); §3.1 (plural-tenant principal --- the validator
emits ``org_id`` for humans so principal-hydration-middleware can
resolve ``(sub, org_id) → primary_tenant_id``); ``02-edge-cases.md``
E8/E9/E12/E13 (claim shape and discriminator stress tests pinned in
T1's unit suite).
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, model_validator

from .errors import AmbiguousDiscriminator, UnrecognizedFlow


class RawClaims(BaseModel):
    """The decoded JWT payload, before the discriminator decision.

    Strict-typed (``strict=True``) so e.g. ``iat`` arriving as a
    string is rejected, not coerced --- coercion has bitten boundary
    validators historically (CVE-2018-1000136 lineage; E9). Allows
    extra fields (``extra="allow"``) so Auth0 Actions / future
    custom claims (e.g. Slice 7+ ``act`` for delegation) are
    preserved on the model and surface through
    :attr:`VerifiedClaims.raw_claims`.

    The ``@model_validator(mode="after")`` rejects the two
    discriminator-shape failures from
    ``tests/fixtures/auth0/auth0_spec.json``
    § ``validator_obligations`` #5--#6:

    - **Both** ``gty == "client-credentials"`` and ``org_id`` present
      → :class:`~skaldos.auth.errors.AmbiguousDiscriminator` (E12).
    - **Neither** present, OR ``gty`` present with the wrong value
      (e.g. ``"password"``) → :class:`~skaldos.auth.errors.UnrecognizedFlow`
      (E13).

    Production code outside the validator does not import this
    class --- consumers read :class:`VerifiedClaims`. Exposed at
    package surface for unit-test pinning of the discriminator
    decision.
    """

    model_config = ConfigDict(extra="allow", strict=True)

    iss: str
    sub: str
    aud: str | list[str]
    iat: int
    exp: int
    azp: str
    scope: str | None = None
    gty: str | None = None
    org_id: str | None = None
    email: str | None = None  # Auth0 emits this when the 'email' scope is granted.

    @model_validator(mode="after")
    def _discriminator_is_mutually_exclusive(self) -> RawClaims:
        """Enforce ``auth0_spec.json`` § ``validator_obligations`` #5--#6.

        Discriminators are mutually exclusive by construction; the
        validator rejects both co-occurrence (tenant misconfiguration,
        E12) and absence (unrecognized flow, E13). Per the module
        docstring, exceptions raised here propagate unwrapped (Pydantic
        v2 ``mode="after"`` behavior).
        """
        is_agent = self.gty == "client-credentials"
        is_human = self.org_id is not None
        if is_agent and is_human:
            raise AmbiguousDiscriminator(self)
        if not is_agent and not is_human:
            raise UnrecognizedFlow(self)
        if self.gty is not None and self.gty != "client-credentials":
            # gty present but wrong value (e.g. deprecated password grant)
            # AND no org_id → unrecognized flow.
            raise UnrecognizedFlow(self)
        return self


class VerifiedClaims(BaseModel):
    """The validator's output. Frozen --- once verified, immutable.

    Field set per ``master-plan.md`` § "Shared artifacts & contracts".
    Downstream consumers (principal-hydration-middleware in T6 of the
    peer feature; Slice 5 audit emitter; Slice 7+ delegation) read
    named fields. Any field-assignment after construction raises
    :class:`pydantic.ValidationError` (frozen=True).

    The :attr:`raw_claims` dict carries the verbatim decoded payload
    (post-signature-verify) so future Slice 7+ delegation work can
    read ``act`` without changing this model's signature
    (``01-user-stories.md`` § S8). Convention: downstream consumers
    only read named fields they expect; iterating ``raw_claims`` is
    a smell, and the ``03-technical-implementation.md`` § "Fault lines"
    note flags a future lint rule (Slice 2 or 3) that catches
    ``raw_claims["..."]`` access outside ``services/api/skaldos/auth/``.
    """

    model_config = ConfigDict(frozen=True)

    kind: Literal["human", "agent"]
    """Discriminator decision per ``auth0_spec.json``
    § ``principal_discriminators``. ``"human"`` if ``org_id`` was
    present in :class:`RawClaims`; ``"agent"`` if
    ``gty == "client-credentials"``."""

    sub: str
    """JWT ``sub`` claim. Opaque string. For humans: ``"auth0|<id>"``.
    For agents: ``"<client_id>@clients"``. Identity-resolution code
    (principal-hydration-middleware) treats this as a key, not a
    structured value."""

    auth0_sub: str
    """Same value as :attr:`sub`. Kept as a separate field to make the
    downstream lookup grep-visible (``WHERE auth0_sub = $1`` in
    aiosql files; the field name documents the source). Per the
    brainstorm § "models.py", a deliberate redundancy."""

    email: str | None
    """Auth0 emits this when the ``email`` scope is granted. May be
    ``None`` for human tokens that didn't request it (Auth0 omits
    rather than sending empty), and is always ``None`` for agent
    tokens (M2M Client Credentials has no human email)."""

    org_id: str | None
    """Auth0 Organization ID for humans (``"org_..."``). ``None`` for
    agents. The principal-hydration-middleware peer feature uses this
    to scope human principal lookup: ``(sub, org_id) → principal_id``
    per the §3.1 plural-tenant rule."""

    azp: str | None
    """Authorized party --- the requesting app's ``client_id``. Per
    ``auth0_spec.json`` ``common_required_claims.azp`` it's the agent
    principal lookup key. Typed as ``str | None`` to permit possible
    future flows where ``azp`` is omitted, though Auth0 always emits
    it on the captured fixtures."""

    iss: str
    """JWT issuer (``"https://skaldos[-<env>].eu.auth0.com/"``). Pinned
    by :class:`AuthConfig`'s startup-fail regex in T2."""

    aud: str | list[str]
    """JWT audience. Auth0 returns a string when only one was
    requested, an array when multiple (e.g. when the ``openid`` scope
    adds the userinfo audience). Validator must handle both shapes
    (E11). The captured human fixture has the array form; the captured
    agent fixture has the string form."""

    exp: int
    """JWT expiration (unix seconds). Already verified by the JWT
    library at construction; downstream code does not re-check."""

    iat: int
    """JWT issued-at (unix seconds). Already verified."""

    scope_str: str | None
    """Space-separated scope string from the JWT ``scope`` claim.

    Per ADR 2, Oso owns authorization; this field is *informational*
    --- the validator does not gate on specific scope values.
    Typed as a separate field (vs raw access via
    ``raw_claims["scope"]``) per the master-plan ADR resolution: a
    typed field is preferable for any future scope-based observability
    or rate-limiter input without re-decoding ``raw_claims``. The
    name ``scope_str`` (vs just ``scope``) signals the raw
    space-separated form, not a parsed list."""

    raw_claims: dict[str, Any]
    """Verbatim decoded JWT payload --- the dict the JWT library
    returned post-signature-verify, including any ``extra`` keys
    Auth0 (or an Auth0 Action) injected. Slice 7+ delegation reads
    ``act`` from here without changing this model's signature
    (``01-user-stories.md`` § S8). Per ``03-technical-implementation.md``
    § "Fault lines", convention is "downstream consumers only read
    named fields they expect; iterating ``raw_claims`` is a smell"
    --- a Slice 2 or 3 lint rule will flag
    ``raw_claims["..."]`` access outside ``services/api/skaldos/auth/``."""
