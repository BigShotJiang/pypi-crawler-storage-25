"""Auth verification exception hierarchy (T1).

Per ``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``
§ "errors.py" and § "Error management": every failure class the
:class:`~skaldos.auth.protocol.TokenVerifier` surfaces inherits from
:class:`TokenVerificationError`. Each subclass carries an
``event_name: ClassVar[str]`` constant in the ``auth.<reason>``
namespace; the FastAPI dependency from T5 emits ``event_name`` to the
structured-log stream on every rejection, and the operator runbook
(T7) alerts on those event names.

Why one base class
------------------

Consumer code does ``except TokenVerificationError`` to catch any
verification failure (the FastAPI dependency does this once and maps
to HTTP codes). Sub-class catches (``except TokenExpired``) are valid
where the call site needs to differentiate (e.g. T5 raises
``HTTP_503_SERVICE_UNAVAILABLE`` for :class:`JWKSUnavailable` and
``HTTP_401_UNAUTHORIZED`` for the others). The hierarchy is *flat*
under the base --- two-level hierarchies (``ClaimError`` >
``TokenExpired``) would invite catch-the-wrong-level bugs.

Why ``event_name`` is ``ClassVar[str]``
---------------------------------------

The constant is per-class, not per-instance --- every
``InvalidSignature`` raised emits the *same* event name. Declaring it
as ``ClassVar[str]`` (not just ``str``) tells pyright (strict, see
``pyproject.toml``) that the attribute lives on the class object, not
on each instance; mistyping ``event_name = "auth.foo"`` as a regular
field would silently break the audit-log shape under T5.

Why dotted-namespace event names
--------------------------------

Per §13.2 / §20.1, structured-log events use a ``<subsystem>.<reason>``
shape. ``auth.<reason>`` keeps every verification event filterable
with one prefix in Cloud Logging; ``test_event_names_use_dotted_namespace``
in :mod:`tests.unit.test_auth_errors` pins this property so a future
refactor that drops the ``auth.`` prefix is loud, not silent.

References: §13.2 (audit log shape); §14.7 (fail-on-startup
hygiene generalizes here --- exceptions during verification are the
boundary's loud-failure mode); ADR 19 (Auth0 contract); AP5 (no
test-only bypass --- exceptions are the *only* failure surface;
no ``return None`` paths). Edge cases in
``02-edge-cases.md``: every E* maps to one subclass below; the
"Error management" table in ``03-technical-implementation.md`` is
the per-event mapping.
"""

from __future__ import annotations

from typing import ClassVar


class TokenVerificationError(Exception):
    """Base class for every verification failure.

    Consumer code (T5's FastAPI dependency; the Slice 1 contract test
    in T6) catches this class to handle *any* verification failure.
    Sub-class catches are valid for differentiation (T5 differentiates
    :class:`JWKSUnavailable` --- 503 --- from the rest --- 401);
    cross-cutting code (audit, logging) catches the base.

    Subclasses MUST declare ``event_name: ClassVar[str]`` in the
    ``auth.<reason>`` namespace. The unit-test suite in
    ``tests/unit/test_auth_errors.py`` enforces both invariants
    (presence + uniqueness + dotted namespace) so a refactor that
    drops or duplicates an event name fails loudly.
    """

    event_name: ClassVar[str]


class InvalidSignature(TokenVerificationError):  # noqa: N818 -- name matches the §13.2 audit-event vocabulary; the brainstorm pins this class name verbatim (``03-technical-implementation.md`` § "errors.py"). Renaming to ``InvalidSignatureError`` would obscure the canon link and break the runbook (T7) audit-event mapping.
    """RS256 signature did not verify against the JWKS-resolved key.

    Triggered by a forged or modified token (E1, E10). The structured
    log carries ``kid`` (a public value) and the request correlation
    IDs --- never the token bytes, never claim values. HTTP 401 with
    ``WWW-Authenticate: Bearer error="invalid_token"``.
    """

    event_name: ClassVar[str] = "auth.invalid_signature"


class InvalidIssuer(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary; see InvalidSignature for rationale.
    """``iss`` claim did not match the configured ``AUTH0_ISSUER``.

    Triggered by a cross-environment replay (E18, E23, E28) or a
    misconfigured client. Cheap rejection --- happens before JWKS
    fetch in the production path. HTTP 401.
    """

    event_name: ClassVar[str] = "auth.invalid_issuer"


class InvalidAudience(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary; see InvalidSignature for rationale.
    """``aud`` claim did not contain ``AUTH0_AUDIENCE``.

    Triggered when a token minted for one SkaldOS API (e.g. dev) hits
    a different one (e.g. prod) (E21, E22). The aud-array variant
    (``aud`` is a list of strings, ours absent from the list) is
    handled by the JWT library's ``audience=`` parameter --- both
    string and array shapes flow through this same exception class.
    HTTP 401.
    """

    event_name: ClassVar[str] = "auth.invalid_audience"


class TokenExpired(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary; see InvalidSignature for rationale.
    """``exp`` is in the past beyond the configured leeway.

    Triggered by a stale client retry (browser back-button, paused
    tab, retry queue) (E3). Client must re-authenticate --- the
    validator never silently extends ``exp``. HTTP 401 with
    ``WWW-Authenticate: Bearer error="invalid_token",
    error_description="token expired"``.
    """

    event_name: ClassVar[str] = "auth.token_expired"


class TokenNotYetValid(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary; see InvalidSignature for rationale.
    """``nbf`` (or ``iat``) is in the future beyond the configured leeway.

    Triggered by clock skew exceeding ``AUTH0_CLOCK_SKEW_SECONDS``
    (default 60) (E4). Operator remediation is "check NTP". HTTP 401.
    """

    event_name: ClassVar[str] = "auth.token_nbf_future"


class MalformedClaims(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary; see InvalidSignature for rationale.
    """A required claim is missing, the wrong type, or the JWT header
    is malformed (e.g. missing ``kid``).

    Triggered by Auth0 outage / tenant config drift (E8) or by a
    malformed token (E9). The exception detail names the offending
    field; the structured log carries ``missing_field`` /
    ``malformed_field`` --- never the value. HTTP 401.
    """

    event_name: ClassVar[str] = "auth.claims_malformed"


class AmbiguousDiscriminator(TokenVerificationError):  # noqa: N818 -- name matches the auth0_spec.json validator-obligation #6 vocabulary; the brainstorm pins this class name verbatim. See InvalidSignature for the same rationale applied to all classes in this hierarchy.
    """Token has BOTH ``gty="client-credentials"`` AND ``org_id``.

    Triggered by Auth0 tenant misconfiguration (E12) --- e.g. an
    Action accidentally injecting ``org_id`` on M2M tokens, or a
    "machine user" with Organizations membership. Per
    ``auth0_spec.json`` § ``validator_obligations`` #6, discriminators
    are mutually exclusive by construction; co-occurrence is a
    structural bug.

    **Operator alerting threshold is low** (any occurrence) --- this
    is an Auth0 tenant-config bug, not a client bug.
    HTTP 401 with ``WWW-Authenticate: Bearer error="invalid_token"``.

    Constructed with the offending :class:`~skaldos.auth.models.RawClaims`
    payload (positional arg) so the audit emitter can record the
    discriminator-shape assertion failure without re-decoding.
    The structured log emits ``has_gty=True, has_org_id=True`` ---
    NEVER the actual claim values.
    """

    event_name: ClassVar[str] = "auth.claims_ambiguous_discriminator"


class UnrecognizedFlow(TokenVerificationError):  # noqa: N818 -- name matches the auth0_spec.json validator-obligation #5 vocabulary; see InvalidSignature for rationale.
    """Token has NEITHER ``gty="client-credentials"`` NOR ``org_id``.

    Triggered by a token from an unrecognized grant type (E13) ---
    deprecated password grant, implicit grant, or a client
    misconfigured against the wrong API. Also covers the case where
    ``gty`` is present but with the wrong value (e.g.
    ``gty="password"``).

    Per ``auth0_spec.json`` § ``validator_obligations`` #5, the
    validator rejects unrecognized flows; downstream code only sees
    `kind in {"human", "agent"}`. Operator audits the Auth0 app
    config. HTTP 401.

    Constructed with the offending :class:`~skaldos.auth.models.RawClaims`
    payload; the structured log emits ``has_gty=False, has_org_id=False``
    (or ``has_gty=True`` with the offending-but-not-logged ``gty``
    value flagged) --- NEVER claim values.
    """

    event_name: ClassVar[str] = "auth.claims_unrecognized_flow"


class UnknownKid(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary (JWKS ``kid`` lookup); see InvalidSignature for rationale.
    """Token's JWT header ``kid`` is not in the JWKS, even after refresh.

    Triggered after the refresh-once-on-unknown-kid path (E7) ran and
    still didn't find the key. Could be a forgery attempt OR a key
    just rotated mid-rate-limit (E14). Operator investigation:
    check log volume + ``AUTH0_JWKS_MIN_REFRESH_INTERVAL_SECONDS``.
    HTTP 401.
    """

    event_name: ClassVar[str] = "auth.unknown_kid"


class JWKSUnavailable(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary (JWKS endpoint); see InvalidSignature for rationale.
    """JWKS endpoint unreachable, with no usable cache.

    Cold start (no cache yet, fetch fails) raises this directly (E6.cold).
    Warm + stale cache + extended outage past
    ``AUTH0_JWKS_STALE_GRACE_SECONDS`` also raises this. Returned to
    the caller as **HTTP 503 Service Unavailable** with
    ``Retry-After: 5`` --- it is NOT an auth failure (don't return
    401), it is an infrastructure failure. Distinguishing is what
    lets the client back off + retry rather than re-authenticate.
    """

    event_name: ClassVar[str] = "auth.jwks_unavailable"


class InvalidAlgorithm(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary (JWT ``alg`` header); see InvalidSignature for rationale.
    """Token's JWT header ``alg`` is not in the pinned allow-list.

    Defense against the well-known ``alg=none`` and
    ``alg=HS256``-with-public-key downgrade attacks (E2). The pin
    (``_ALLOWED_ALGS = ("RS256",)`` in T4's :mod:`.verifier`) is a
    module-level tuple, never read from config or token header ---
    widening requires an ADR-class change. HTTP 401.
    """

    event_name: ClassVar[str] = "auth.invalid_algorithm"


class TokenTooLarge(TokenVerificationError):  # noqa: N818 -- name matches canon vocabulary (8KB token ceiling per E25); see InvalidSignature for rationale.
    """Token exceeds the validator's hard byte ceiling (8192 chars).

    Defense-in-depth against pathological inputs that slipped past
    the transport-layer ``MAX_REQUEST_HEADER_SIZE`` guard (E25).
    The check fires *before* JWKS fetch, so a stream of oversized
    tokens cannot drive cache traffic. HTTP 401.
    """

    event_name: ClassVar[str] = "auth.token_too_large"
