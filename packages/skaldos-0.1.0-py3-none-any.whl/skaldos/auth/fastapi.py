"""FastAPI dependency + lifespan-managed verifier (T5).

Per
``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/05-task-list.md``
§ T5 and ``03-technical-implementation.md`` § "fastapi.py": this module
hosts the **single FastAPI dependency** every protected route declares
(:func:`verify_token`) and the lifespan context manager that constructs
the process-wide :class:`~skaldos.auth.verifier.Auth0Verifier` once at
app startup. Together they form the auth chokepoint's outermost ring ---
``Authorization`` header in, frozen :class:`VerifiedClaims` out (or one
of the documented HTTP rejections).

What this module owns
---------------------

- **Bearer extraction.** The ``Authorization`` header arrives as a
  string from FastAPI's :class:`~fastapi.Header` primitive. We require
  the title-case prefix ``"Bearer "`` exactly (per
  ``03-technical-implementation.md`` § "Fault lines": RFC 6750 says
  the scheme is case-insensitive; we accept only the title-cased form
  because Auth0 always emits ``Bearer``. Widening to
  ``^bearer\\s+``-case-insensitive is documented as a one-line change
  if real-world traffic shows the need; not now).
- **Exception → HTTP code translation.** Every
  :class:`~skaldos.auth.errors.TokenVerificationError` subclass maps to
  one HTTP code per the table in ``03-technical-implementation.md``
  § "Error management":

  =============================== ====== ===========================================
  Failure class                   HTTP   Headers
  =============================== ====== ===========================================
  Missing/malformed bearer        401    ``WWW-Authenticate: Bearer``
  :class:`JWKSUnavailable`        503    ``Retry-After: 5``
  Any other ``TokenVerificationError`` 401    ``WWW-Authenticate: Bearer error="invalid_token"``
  =============================== ====== ===========================================

  The differentiation between 401 and 503 is **load-bearing**: 503
  tells a client "back off and retry" (it's our infrastructure's
  fault); 401 tells a client "the token is unacceptable, do not
  retry" (it's the caller's fault). Conflating them would defeat
  auto-retry policies on the client side.
- **Structured-log emission on rejection.** Per §13.2 every rejection
  logs the exception's :data:`event_name` constant with the public
  ``kid`` (when known) and the request's correlation IDs (handled by
  the ``skaldos_log`` chain's :func:`attach_otel_context`). No claim
  values, no token bytes --- the structured-log redaction layer
  (Slice 0 logging-infrastructure T1) is the structural backstop, but
  the rejection paths here never try to log them in the first place.
- **App-startup lifespan.** :func:`auth_lifespan` is the FastAPI
  ``lifespan`` context manager that brings the global
  :class:`Auth0Verifier` up at startup and tears its
  :class:`httpx.AsyncClient` down at shutdown. The slice's master
  ``app_lifespan`` (which Slice 1 does not yet ship --- the FastAPI
  app composition lands in a later slice) will compose this with
  :func:`~skaldos.db.pool.db_lifespan` via
  :class:`contextlib.AsyncExitStack` (master plan, Wave 3).

Why a module-level ``_global_verifier`` (and not ``Depends``-injected)
----------------------------------------------------------------------

The brainstorm pins this shape: the verifier is **process-singleton**
(the JWKS cache lives inside it; multi-instance verifiers would defeat
the cache's single-flight refresh + rate-limit + stale-while-revalidate
guarantees, all of which assume one cache per process per E14/E15/E26).
Re-creating the verifier per request would also pay the
:class:`httpx.AsyncClient` construction cost on every request --- not
acceptable at the auth boundary.

The :func:`auth_lifespan` context manager owns the lifecycle: it
constructs the verifier once at startup, stashes it in the module's
``_global_verifier`` slot, and clears + closes on shutdown. The
:func:`verify_token` dependency reads the slot; absence is a startup-
ordering bug that surfaces as a clean :class:`RuntimeError` at the
first request rather than a NoneType AttributeError deep in the
verifier.

**Test injection seam.** Per
``04-testing-strategy.md`` § "tests/integration/test_auth0_validator_fastapi.py"
the documented test-side override is::

    app.dependency_overrides[verify_token] = lambda: <fake VerifiedClaims>

Since :func:`verify_token` is the dependency callable itself, FastAPI's
override map intercepts the call before it reaches the verifier. Tests
that *do* want to exercise the real verifier (the round-trip cases in
``test_auth0_validator_fastapi.py``) build a per-test verifier pointed
at the in-process ``auth0_mock`` and install it via
:func:`set_global_verifier_for_tests` --- a documented test-only seam
that bypasses the lifespan ordering. Production wiring never calls
that helper; it goes through :func:`auth_lifespan`.

Why no FastAPI ``Header(...)`` default + missing-header HTTPException
---------------------------------------------------------------------

FastAPI's :class:`~fastapi.Header` with ``...`` (Ellipsis) as the default
auto-generates a 422 Unprocessable Entity response when the header is
missing --- which is wrong for an auth boundary (E16: clients reading
WWW-Authenticate to know how to retry get a 422 instead of a 401, and
auto-retry logic doesn't kick in). Per ``02-edge-cases.md`` E16 we
accept ``str | None`` and raise an explicit 401 ourselves with the
canonical ``WWW-Authenticate: Bearer`` header. The 422 path is
deliberately suppressed.

References: ADR 19 (Auth0); MP6 (agents are clients --- one
dependency, one validator); MP10 (humans + agents same JWT shape ---
the dependency does not branch on principal kind); §4.1 (verification
is the *first* chokepoint); §10.2 (OpenAPI as contract --- routes
declare ``Depends(verify_token)``); §13.2 (every rejection is
audited); AP4 ("compiled" is not "works" --- the manual-verification
checklist in ``04-testing-strategy.md`` § "Manual verification" is
load-bearing); AP5 (no test-only bypass --- the Header(...) default
22 is replaced with a chokepoint-side-channel-free 401 + the test
override goes through FastAPI's published API);
``02-edge-cases.md`` E16 (bearer extraction edge cases), E18 (config
validation surfaces as startup failure, not runtime 503), E20
(lifespan ordering --- the verifier must exist before the first
request).
"""

from __future__ import annotations

from contextlib import AsyncExitStack, asynccontextmanager
from typing import TYPE_CHECKING

import httpx
from fastapi import FastAPI, Header, HTTPException, status
from opentelemetry import trace
from skaldos_log import log

from .config import AuthConfig
from .errors import JWKSUnavailable, TokenVerificationError
from .jwks import JWKSCache
from .verifier import Auth0Verifier

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from .models import VerifiedClaims

__all__ = [
    "auth_lifespan",
    "clear_global_verifier_for_tests",
    "get_global_verifier",
    "set_global_verifier_for_tests",
    "verify_token",
]


# ---------------------------------------------------------------------------
# Module-level verifier slot.
#
# Lifecycle:
#   - Production: :func:`auth_lifespan` sets this on FastAPI startup and
#     clears + closes the underlying httpx client on shutdown.
#   - Tests: :func:`set_global_verifier_for_tests` installs a per-test
#     verifier (typically pointed at the in-process ``auth0_mock`` via
#     ``AUTH0_JWKS_URL_OVERRIDE``); :func:`clear_global_verifier_for_tests`
#     clears it on teardown.
# ---------------------------------------------------------------------------
_global_verifier: Auth0Verifier | None = None
_AUTH_LIFESPAN_TRACER = trace.get_tracer(__name__)


# ---------------------------------------------------------------------------
# WWW-Authenticate header values --- pinned constants per the Error-management
# table in ``03-technical-implementation.md``.
# ---------------------------------------------------------------------------
_WWW_AUTH_BEARER: str = "Bearer"
"""Sent on missing/malformed Authorization header (no token to evaluate).

Per RFC 6750 § 3, the response of a resource server that requires an
access token but the request lacks one carries the bare ``Bearer``
challenge with no ``error`` parameter --- the parameter is reserved for
*evaluated* tokens (the ones we have but rejected).
"""

_WWW_AUTH_INVALID_TOKEN: str = 'Bearer error="invalid_token"'
"""Sent on every evaluated-but-rejected token (RFC 6750 § 3.1).

The ``error="invalid_token"`` parameter is the canonical signal to a
client that the supplied token was checked and found unacceptable
(forged, expired, wrong audience, malformed claims, ambiguous
discriminator, etc.). The client should re-authenticate and retry; an
auto-retry with the same token will fail the same way.
"""

_RETRY_AFTER_SECONDS: str = "5"
"""``Retry-After`` value sent on 503 :class:`JWKSUnavailable`.

Per the Error-management table: "Auth0 outage or our outbound network
issue." 5 seconds is short enough that a polite client retries inside
typical request-timeout windows; long enough that the JWKS cache's
single-flight + rate-limit gates catch up if we're under cold-start
load. Documented as a fixed value (not config-driven) because the
client contract should be stable across deployments.
"""


# ---------------------------------------------------------------------------
# Verifier global accessors.
# ---------------------------------------------------------------------------


def get_global_verifier() -> Auth0Verifier:
    """Return the process-singleton verifier; raise if uninitialised.

    Reads the module-level slot. The slot is set by :func:`auth_lifespan`
    on FastAPI startup or by :func:`set_global_verifier_for_tests` in
    test setup; if neither has run, the dependency was reached before
    the lifespan resolved its startup phase --- E20 (lifespan ordering).
    Raising :class:`RuntimeError` with a descriptive message is the
    loud-failure surface.

    The accessor exists separately so the rejection path of
    :func:`verify_token` does not have to inline the None-check; tests
    asserting "the dependency surfaces a clean error when called outside
    a configured app" can hit this one entry point.
    """
    if _global_verifier is None:
        raise RuntimeError(
            "Auth0Verifier is not initialised. The auth chokepoint "
            "requires either ``auth_lifespan`` to have run during FastAPI "
            "startup (production wiring) or "
            "``set_global_verifier_for_tests`` to have installed a per-test "
            "verifier (test wiring). E20 (lifespan ordering) --- the "
            "dependency was reached before app startup completed."
        )
    return _global_verifier


def set_global_verifier_for_tests(verifier: Auth0Verifier) -> None:
    """Install ``verifier`` as the process-singleton (test seam only).

    Documented test-side override for integration tests that exercise
    the FastAPI dependency end-to-end against the in-process
    ``auth0_mock`` (per ``04-testing-strategy.md``
    § "tests/integration/test_auth0_validator_fastapi.py"). Production
    wiring goes through :func:`auth_lifespan`; this helper exists so
    tests can avoid the FastAPI app's startup-lifecycle overhead while
    still going through the same dependency code path (AP5: same code
    path, not a parallel test mode).

    Tests that finish must call :func:`clear_global_verifier_for_tests`
    in their teardown (typically via a pytest fixture's ``finally``
    block) so the slot doesn't leak into a sibling test's session.
    """
    global _global_verifier
    _global_verifier = verifier


def clear_global_verifier_for_tests() -> None:
    """Drop the process-singleton (test seam only). Idempotent.

    Companion to :func:`set_global_verifier_for_tests`. Idempotent ---
    calling on an already-cleared slot is a no-op so a fixture's
    ``finally`` block is safe even if setup raised before installing.
    """
    global _global_verifier
    _global_verifier = None


# ---------------------------------------------------------------------------
# The FastAPI dependency itself.
# ---------------------------------------------------------------------------


# FastAPI dependency declaration: ``str | None`` lets us own the "missing
# header" rejection path (a clean 401 with WWW-Authenticate: Bearer)
# rather than ceding to FastAPI's auto-generated 422 (which lacks the
# WWW-Authenticate header that clients use to know how to retry). The
# :class:`Header` default is ``None`` (not ``...``) for the same reason.
async def verify_token(
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> VerifiedClaims:
    """Verify the request's bearer token and return its :class:`VerifiedClaims`.

    The single FastAPI dependency every protected route declares::

        @app.get("/whoami")
        async def whoami(claims: VerifiedClaims = Depends(verify_token)) -> ...:
            ...

    Algorithm:

    1. Read ``Authorization`` from the request headers. Missing or
       malformed (does not start with the title-case ``"Bearer "``
       prefix) → 401 with ``WWW-Authenticate: Bearer``.
    2. Strip the prefix; trim whitespace.
    3. Delegate to the process-singleton verifier
       (:func:`get_global_verifier`).
    4. On :class:`JWKSUnavailable` (cold-start / past-stale-grace JWKS
       outage) → 503 with ``Retry-After: 5``.
    5. On any other :class:`TokenVerificationError` subclass → 401
       with ``WWW-Authenticate: Bearer error="invalid_token"``.
    6. Otherwise return the frozen :class:`VerifiedClaims` to the
       caller (the route handler, or the next dependency in the chain
       --- principal-hydration-middleware in T6 of the peer feature).

    Each rejection emits a structured-log warn record carrying the
    exception's :data:`event_name` and the public ``kid`` (when
    available). Correlation IDs (``trace_id`` / ``span_id`` /
    ``request_id``) are attached by the ``skaldos_log`` processor chain
    automatically per §13.2.

    Raises:

    - :class:`fastapi.HTTPException` with the right status code +
      headers per the table above. Never raises a bare
      :class:`TokenVerificationError` to the caller --- the boundary's
      contract is "HTTP-shaped or VerifiedClaims, never substrate
      exceptions."

    See ``02-edge-cases.md`` E16 (bearer extraction), E18 (config
    validation), E20 (lifespan ordering); ``03-technical-implementation.md``
    § "fastapi.py" + § "Error management".
    """
    # 1. Bearer extraction.
    if authorization is None or not authorization.startswith("Bearer "):
        # Pre-validator path: no token to evaluate, so RFC 6750 § 3
        # says the WWW-Authenticate challenge is the bare ``Bearer``
        # form (no ``error`` parameter). The structured-log event is
        # ``auth.bearer_missing`` per the Error-management table.
        log.warning("auth.bearer_missing")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header missing or not a Bearer token.",
            headers={"WWW-Authenticate": _WWW_AUTH_BEARER},
        )

    # 2. Strip the prefix; trim trailing whitespace some clients append.
    bearer: str = authorization.removeprefix("Bearer ").strip()

    # 3. Delegate to the verifier.
    verifier = get_global_verifier()
    try:
        return await verifier.verify(bearer)
    except JWKSUnavailable as e:
        # 4. Infrastructure failure --- 503 with Retry-After. The
        # client should back off and retry; this is NOT an auth
        # rejection (the caller's token may be perfectly fine; we
        # just couldn't verify it). Distinguishing 401 from 503 is
        # load-bearing per the Error-management table.
        log.warning(e.event_name, kid=getattr(e, "kid", None))
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="JWKS endpoint unavailable; retry shortly.",
            headers={"Retry-After": _RETRY_AFTER_SECONDS},
        ) from e
    except TokenVerificationError as e:
        # 5. Token rejection --- 401 with the canonical
        # ``error="invalid_token"`` challenge. Covers every other
        # subclass: InvalidSignature, InvalidIssuer, InvalidAudience,
        # TokenExpired, TokenNotYetValid, InvalidAlgorithm,
        # MalformedClaims, AmbiguousDiscriminator, UnrecognizedFlow,
        # UnknownKid, TokenTooLarge.
        log.warning(e.event_name, kid=getattr(e, "kid", None))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token verification failed.",
            headers={"WWW-Authenticate": _WWW_AUTH_INVALID_TOKEN},
        ) from e


# ---------------------------------------------------------------------------
# Lifespan --- constructs + tears down the global verifier.
# ---------------------------------------------------------------------------


@asynccontextmanager
async def auth_lifespan(_app: FastAPI) -> AsyncGenerator[None]:
    """FastAPI ``lifespan`` context manager owning the verifier lifecycle.

    Use::

        from contextlib import AsyncExitStack, asynccontextmanager
        from skaldos.auth import auth_lifespan
        from skaldos.db import db_lifespan

        @asynccontextmanager
        async def app_lifespan(app: FastAPI):
            async with AsyncExitStack() as stack:
                await stack.enter_async_context(auth_lifespan(app))
                await stack.enter_async_context(db_lifespan(app))
                yield

        app = FastAPI(lifespan=app_lifespan)

    On startup:

    1. Constructs an :class:`AuthConfig` from environment variables.
       The :class:`AuthConfig`'s ``model_validator`` raises if
       ``AUTH0_ISSUER`` is malformed (E18) or if
       ``AUTH0_JWKS_URL_OVERRIDE`` is set in production --- mirroring
       the §14.7 idiom "fail on startup if security-critical env vars
       are unset / misconfigured" (E18).
    2. Constructs an :class:`httpx.AsyncClient` (its lifecycle is the
       lifespan's; we close it on shutdown).
    3. Constructs a :class:`JWKSCache` against the client and config.
    4. Constructs an :class:`Auth0Verifier` against the cache + config.
    5. Stashes the verifier in the module-level ``_global_verifier``
       slot via :func:`set_global_verifier_for_tests` (the helper's
       name says "for_tests" but production also uses the slot ---
       the slot is the singleton, the helper just exposes it).

    On shutdown:

    1. Clears the module-level slot via
       :func:`clear_global_verifier_for_tests`.
    2. Calls :meth:`JWKSCache.aclose` (no-op today, kept for symmetry).
    3. Closes the :class:`httpx.AsyncClient` so connections are
       returned to the OS rather than abandoned.

    Per master-plan composition pattern, the slice's ``app_lifespan``
    composes this with :func:`~skaldos.db.pool.db_lifespan` via
    :class:`contextlib.AsyncExitStack`. Each lifespan owns its own
    resources; the stack ensures clean unwind even if one of them
    raises during startup.

    Per ``02-edge-cases.md`` E20 (lifespan ordering): the verifier
    must exist before the first request reaches :func:`verify_token`.
    The startup phase yields only *after* installing the verifier, so
    by the time FastAPI accepts traffic the slot is populated.
    """
    # ``_app`` is the FastAPI instance; we accept it because the
    # FastAPI lifespan signature requires it, but we touch nothing on
    # it --- the lifespan is a pure singleton-lifecycle hook. This
    # mirrors :func:`~skaldos.db.pool.db_lifespan`.
    del _app

    # Integration tests may install the real-verifier seam before app startup;
    # production startup reaches this path with no preinstalled verifier.
    if _global_verifier is not None:
        yield
        return

    # The :class:`AsyncExitStack` lets us register cleanup on each
    # successful step; if a later step raises during startup, the
    # earlier ones unwind cleanly (E20 partial-startup defense).
    async with AsyncExitStack() as stack:
        # 1. Config (raises on misconfigured env vars per §14.7 / E18).
        config = AuthConfig()  # pyright: ignore[reportCallIssue]

        # 2. httpx client. Lifecycle owned by the stack so a failure
        # in step 3+ still closes it.
        http_client = httpx.AsyncClient()
        stack.push_async_callback(http_client.aclose)

        # 3. JWKS cache. ``aclose`` is a no-op today but the symmetry
        # is preserved for future cache-side cleanup.
        jwks = JWKSCache(config, http_client)
        stack.push_async_callback(jwks.aclose)

        # 4. Verifier --- composes config + cache.
        verifier = Auth0Verifier(config, jwks)

        # 5. Install in the module-level slot. The slot is cleared in
        # the cleanup phase so a re-startup (e.g. test fixtures that
        # spin the lifespan up + down repeatedly) sees a clean slate.
        set_global_verifier_for_tests(verifier)
        stack.push_async_callback(_clear_global_async)

        with _AUTH_LIFESPAN_TRACER.start_as_current_span("auth.lifespan.startup"):
            log.info("auth.lifespan_startup_complete")
        try:
            yield
        finally:
            with _AUTH_LIFESPAN_TRACER.start_as_current_span("auth.lifespan.shutdown"):
                log.info("auth.lifespan_shutdown_complete")


async def _clear_global_async() -> None:
    """:class:`AsyncExitStack`-compatible wrapper around the sync clear.

    :meth:`AsyncExitStack.push_async_callback` requires an awaitable;
    :func:`clear_global_verifier_for_tests` is sync. The wrapper bridges
    the two without forcing the test seam to grow an async variant.
    """
    clear_global_verifier_for_tests()
