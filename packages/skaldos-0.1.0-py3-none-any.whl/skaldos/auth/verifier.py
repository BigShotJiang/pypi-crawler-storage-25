"""Auth0 production JWT validator (T4).

Per ``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``
§ "verifier.py" and ``05-task-list.md`` § T4: :class:`Auth0Verifier` is
the production implementation of the
:class:`~skaldos.auth.protocol.TokenVerifier` Protocol. Composes
:class:`~skaldos.auth.config.AuthConfig` and
:class:`~skaldos.auth.jwks.JWKSCache`; constructed once at FastAPI app
startup (T5's ``lifespan`` context manager) and reused across requests.

Algorithm
---------

The :meth:`verify` method runs the following pipeline. Each step's
failure mode maps to one :class:`~skaldos.auth.errors.TokenVerificationError`
subclass; the FastAPI dependency from T5 maps each subclass to the
correct HTTP code (401 for caller errors;
:class:`~skaldos.auth.errors.JWKSUnavailable` → 503).

1. **Size guard** (E2 / E25). Reject tokens longer than 8192 bytes via
   :class:`~skaldos.auth.errors.TokenTooLarge` *before* any decode. This
   is defense-in-depth against pathological inputs that slipped past
   the transport-layer ``MAX_REQUEST_HEADER_SIZE`` guard, and ensures a
   stream of oversized tokens cannot drive cache traffic.
2. **Header decode** (unauthenticated). :func:`jwt.get_unverified_header`
   parses the JOSE header. Decode failures raise
   :class:`~skaldos.auth.errors.MalformedClaims`.
3. **Algorithm pin** (E2 — load-bearing). Reject any token whose JOSE
   header ``alg`` is not in :attr:`_ALLOWED_ALGS` (currently
   ``("RS256",)``). The pin is a class-level constant; **never read from
   config**, **never read from the token's payload**. This is the
   structural defense against ``alg=none`` and ``alg=HS256``-with-public-
   key downgrade attacks: by rejecting non-RS256 *before* the signature-
   verification path runs, no key-confusion attack can reach
   :func:`jwt.decode`. Widening the allow-list requires an ADR-class
   change (``03-technical-implementation.md`` § "Fault lines").
4. **Kid extract**. Read ``kid`` from the JOSE header; missing kid →
   :class:`~skaldos.auth.errors.MalformedClaims`.
5. **JWKS lookup**. :meth:`JWKSCache.get_signing_key` resolves the
   ``kid`` to the verifying key. May raise
   :class:`~skaldos.auth.errors.UnknownKid` (E7 negative path) or
   :class:`~skaldos.auth.errors.JWKSUnavailable` (E6 cold start);
   propagate unwrapped — the FastAPI dependency translates.
6. **JWT decode + claim verification**. :func:`jwt.decode` runs the
   signature check (against the JWKS-resolved key), audience match
   (string-or-array per E11), issuer match (E18 / E23 / E28), and
   ``exp`` / ``nbf`` / ``iat`` checks with the configured leeway (E3 /
   E4 / E5). Each pyjwt exception class translates via ``from e`` to
   the matching :class:`TokenVerificationError` subclass; the catch-all
   :class:`jwt.PyJWTError` handler folds any residual decode failures
   into :class:`~skaldos.auth.errors.MalformedClaims`. The chained
   pyjwt exception is reachable via ``__cause__`` for diagnostic
   purposes (logged as ``error_class`` / ``error_repr`` by T5).
7. **RawClaims validation**. :meth:`RawClaims.model_validate` enforces
   the discriminator-mutual-exclusivity rule from
   ``auth0_spec.json`` § ``validator_obligations`` #5--#6:
   :class:`~skaldos.auth.errors.AmbiguousDiscriminator` (both
   discriminators present, E12) or
   :class:`~skaldos.auth.errors.UnrecognizedFlow` (neither present, or
   ``gty`` with a non-``client-credentials`` value, E13). Per the auth
   T1 docstring on Pydantic v2 ``mode="after"`` propagation, these
   exceptions surface to the caller **unwrapped** — the verifier does
   not catch and re-raise them.
8. **Discriminator decision**. ``kind = "human" if raw.org_id is not
   None else "agent"``. The decision is symmetric per MP10; identity
   resolution lives in the principal-hydration-middleware peer feature.
9. **VerifiedClaims construction**. Build the frozen output model from
   ``raw`` (the typed claim fields) plus ``decoded`` (the verbatim dict
   becomes :attr:`VerifiedClaims.raw_claims`). Slice 7+ delegation reads
   ``act`` from ``raw_claims`` without changing this model's signature.

Why ``_ALLOWED_ALGS`` is a ``ClassVar[tuple[str, ...]]``
--------------------------------------------------------

The brainstorm pins this as **load-bearing**: reading the allow-list
from config or from the token header is exactly what defeats the alg-
downgrade defense. ``ClassVar[tuple[str, ...]]`` tells pyright (strict)
that the attribute lives on the class object, not on instances; an
accidental ``self._allowed_algs = ...`` mutation in subclass-style
extension would fail the typecheck. The tuple form (vs list) is also
inspector-readable: a list could be mutated post-import; a tuple
cannot.

Why exception translation uses ``from e``
-----------------------------------------

Per ``04-testing-strategy.md`` § "tests/unit/test_auth_errors.py" →
``test_exception_chain_preserves_root_cause``: every translated pyjwt
exception is reachable via ``__cause__`` so an operator running
``traceback.format_exception`` sees both layers. The translation keeps
the *catch surface* clean (consumer code matches against
:class:`TokenVerificationError`) without losing the diagnostic chain
that pyjwt provides.

References: ADR 19 (Auth0 RS256), MP10 (humans + agents same JWT
shape, one validator), MP6 (agents are clients), AP5 (no test-only
bypass — the validator has one entry point, tests use it via the
mock JWKS server), §4.1 (verification is the first chokepoint),
§13.2 (every rejection is auditable), §14.7 (fail-on-startup hygiene
generalizes here);
``02-edge-cases.md`` E1--E27 (full failure taxonomy);
``03-technical-implementation.md`` § "verifier.py" (canonical sketch);
``04-testing-strategy.md`` § "tests/unit/test_alg_pinning.py",
§ "tests/integration/test_auth0_validator_*";
``tests/fixtures/auth0/auth0_spec.json``
§ ``validator_obligations``.
"""

from __future__ import annotations

from typing import ClassVar

import jwt

from .config import AuthConfig
from .errors import (
    AmbiguousDiscriminator,
    InvalidAlgorithm,
    InvalidAudience,
    InvalidIssuer,
    InvalidSignature,
    MalformedClaims,
    TokenExpired,
    TokenNotYetValid,
    TokenTooLarge,
    UnrecognizedFlow,
)
from .jwks import JWKSCache
from .models import RawClaims, VerifiedClaims

# Hard ceiling on token byte length. Defense-in-depth alongside the
# transport layer's ``MAX_REQUEST_HEADER_SIZE`` guard (E25). 8192 chars
# is the brainstorm-pinned upper bound — pathological tokens larger than
# this cannot reach the JWKS / decode path.
_MAX_TOKEN_LENGTH: int = 8192


class Auth0Verifier:
    """Production Auth0 JWT validator implementing :class:`TokenVerifier`.

    Composes :class:`~skaldos.auth.config.AuthConfig` (issuer / audience
    / leeway) and :class:`~skaldos.auth.jwks.JWKSCache` (single-flight,
    rate-limited, stale-while-revalidate JWKS lookup). Both are
    constructor-injected; the verifier holds no global state. T5's
    FastAPI ``lifespan`` constructs one verifier at app startup and
    re-uses it across requests; tests construct a per-test verifier
    pointed at the in-process Auth0 mock issuer (AP5: no separate
    test-mode code path).

    The single public method, :meth:`verify`, runs the algorithm in
    the module docstring. Every failure raises a subclass of
    :class:`~skaldos.auth.errors.TokenVerificationError`; T5's FastAPI
    dependency translates each subclass to the correct HTTP response.
    """

    _ALLOWED_ALGS: ClassVar[tuple[str, ...]] = ("RS256",)
    """Pinned signing-algorithm allow-list.

    **Class-level constant; never read from config; never read from
    the token header.** This is the structural defense against
    alg-downgrade attacks (``alg=none``, ``alg=HS256``-with-public-key,
    etc., E2). Widening the allow-list requires an ADR-class change.

    Tuple (not list) form is the inspector-readable invariant:
    ``test_supported_alg_constant_is_immutable`` in
    ``tests/unit/test_alg_pinning.py`` asserts both the type
    (``tuple``) and the exact value (``("RS256",)``) so a refactor
    that loosens the pin fails loudly.
    """

    def __init__(self, config: AuthConfig, jwks: JWKSCache) -> None:
        """Construct an :class:`Auth0Verifier`.

        Both ``config`` and ``jwks`` are injected so tests can swap
        either independently. Production wiring (T5's lifespan)
        constructs both from the same lifespan-scoped ``AuthConfig``;
        the JWKS cache holds an :class:`httpx.AsyncClient` whose
        teardown the lifespan owns.
        """
        self._config = config
        self._jwks = jwks

    async def verify(self, token: str) -> VerifiedClaims:
        """Verify ``token`` and return its :class:`VerifiedClaims`.

        Implements the :class:`~skaldos.auth.protocol.TokenVerifier`
        Protocol contract. See the module docstring for the full
        algorithm; see ``02-edge-cases.md`` E1--E27 for the
        failure taxonomy.

        Raises any subclass of
        :class:`~skaldos.auth.errors.TokenVerificationError`.
        """
        # 1. Size guard (E2 / E25). Defensive bound *before* any decode.
        if len(token) > _MAX_TOKEN_LENGTH:
            raise TokenTooLarge(
                f"token length {len(token)} exceeds the hard ceiling of {_MAX_TOKEN_LENGTH} bytes."
            )

        # 2. Header decode (unauthenticated metadata).
        try:
            header = jwt.get_unverified_header(token)
        except jwt.PyJWTError as e:
            # Malformed JOSE header (bad base64, bad JSON, missing
            # segments). Treat as a claim-shape failure; the structured
            # log emits ``auth.claims_malformed``.
            raise MalformedClaims(f"unable to decode JWT header: {e!r}") from e

        # 3. Algorithm pin (E2 — load-bearing alg-downgrade defense).
        # The header's `alg` value is checked against the class-level
        # tuple BEFORE any signature verification or JWKS fetch. A
        # missing `alg` (None) is also rejected here.
        alg = header.get("alg")
        if alg not in self._ALLOWED_ALGS:
            raise InvalidAlgorithm(
                f"JWT alg={alg!r} not in allow-list "
                f"{self._ALLOWED_ALGS!r}; alg-downgrade attempt rejected."
            )

        # 4. Kid extract.
        kid = header.get("kid")
        if not kid or not isinstance(kid, str):
            raise MalformedClaims(
                "JWT header missing 'kid' (Auth0 always emits kid; "
                "absence implies a malformed token)."
            )

        # 5. JWKS lookup. May raise UnknownKid / JWKSUnavailable; let
        # both propagate unwrapped.
        key = await self._jwks.get_signing_key(kid)

        # 6. JWT decode + claim verification.
        try:
            decoded = jwt.decode(
                token,
                key,
                algorithms=list(self._ALLOWED_ALGS),
                audience=self._config.auth0_audience,
                issuer=self._config.auth0_issuer,
                leeway=self._config.auth0_clock_skew_seconds,
            )
        except jwt.ExpiredSignatureError as e:
            raise TokenExpired(f"token exp claim is in the past: {e!r}") from e
        except jwt.ImmatureSignatureError as e:
            raise TokenNotYetValid(f"token nbf claim is in the future: {e!r}") from e
        except jwt.InvalidAudienceError as e:
            raise InvalidAudience(
                f"token aud does not contain configured audience "
                f"{self._config.auth0_audience!r}: {e!r}"
            ) from e
        except jwt.InvalidIssuerError as e:
            raise InvalidIssuer(
                f"token iss does not match configured issuer {self._config.auth0_issuer!r}: {e!r}"
            ) from e
        except jwt.InvalidSignatureError as e:
            raise InvalidSignature(f"JWT signature did not verify: {e!r}") from e
        except jwt.PyJWTError as e:
            # Catch-all for residual pyjwt failures (e.g.
            # ``MissingRequiredClaimError``, ``InvalidIssuedAtError``,
            # ``InvalidKeyError``). Folds into MalformedClaims; the
            # chained exception is reachable via ``__cause__``.
            raise MalformedClaims(f"JWT decode failed: {e!r}") from e

        # 7. RawClaims validation. May raise AmbiguousDiscriminator /
        # UnrecognizedFlow directly (Pydantic v2 mode="after"
        # propagates unwrapped — see auth/models.py docstring).
        # MalformedClaims is also raised by Pydantic if a typed field
        # fails strict validation; we let any ValidationError bubble
        # from RawClaims for the missing-required-claim case (E8/E9).
        try:
            raw = RawClaims.model_validate(decoded)
        except (AmbiguousDiscriminator, UnrecognizedFlow):
            # Re-raise unchanged; the FastAPI dependency translates each
            # to its event_name. Listed explicitly so the catch-all
            # below cannot accidentally swallow them.
            raise
        except Exception as e:  # noqa: BLE001 -- fold validation errors into MalformedClaims
            # Strict-typed Pydantic validation errors (e.g. iat as
            # string, sub as list) land here. Translate to
            # MalformedClaims for the FastAPI surface; the chained
            # exception preserves the field-level detail.
            raise MalformedClaims(f"claim shape validation failed: {e!r}") from e

        # 8. Discriminator decision. Symmetric per MP10.
        kind: str = "human" if raw.org_id is not None else "agent"

        # 9. VerifiedClaims construction. ``decoded`` is the verbatim
        # dict pyjwt produced post-signature-verify; storing it as
        # ``raw_claims`` is the forward-compat surface (Slice 7+ reads
        # ``act`` from here).
        return VerifiedClaims(
            kind=kind,  # type: ignore[arg-type] -- Literal narrowing via the discriminator decision.
            sub=raw.sub,
            auth0_sub=raw.sub,
            email=raw.email,
            org_id=raw.org_id,
            azp=raw.azp,
            iss=raw.iss,
            aud=raw.aud,
            exp=raw.exp,
            iat=raw.iat,
            scope_str=raw.scope,
            raw_claims=decoded,
        )
