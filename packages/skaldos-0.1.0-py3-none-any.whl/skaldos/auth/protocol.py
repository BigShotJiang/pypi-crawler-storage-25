"""``TokenVerifier`` Protocol --- minimum JWT-verification surface (T1).

Per ``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``
§ "protocol.py" and § "Reviewed canon" (ADR 19, MP6, MP10, §4.1,
§10.2): every JWT validator (production
:class:`~skaldos.auth.verifier.Auth0Verifier` from T4; any future test
fake) implements this Protocol. Consumer code (Slice 1's
principal-hydration-middleware peer feature; Slice 4+ protected
endpoints; Slice 5 Shield audit; Slice 7+ agent runtime) holds a
``TokenVerifier`` reference and never imports a concrete implementation
--- the abstraction is the chokepoint that lets test injection happen
without ``if testing:`` branches (AP5).

Why a Protocol (not an ABC)
---------------------------

- **Structural** --- pyright (strict, see ``pyproject.toml``) catches
  missing methods on every adapter without forcing inheritance. Adding
  a method here will fail the typecheck on whichever adapter doesn't
  implement it next; that surfaces at PR-CI time, not at deploy time.
  Mirror of the discipline ``KMSClient`` (T4) and ``Sandbox`` (T5)
  pinned in Slice 0.
- **``runtime_checkable``** --- a unit test
  (``tests/unit/test_auth_models.py`` and the future T6 contract test)
  can assert ``isinstance(verifier, TokenVerifier)`` for any adapter
  at module import time. Names exist; signatures are the static
  checker's job.

Why one method
--------------

Per ``02-edge-cases.md`` E12/E13 and the auth0_spec.json
``validator_obligations`` list, the validator's *only* externally-
visible operation is "decode + verify a token; produce a
:class:`VerifiedClaims`". Identity resolution, authorization,
session management --- all owned by peer features (principal-
hydration-middleware, Slice 2's ``can()``, etc.). The Protocol pins
the surface deliberately small: one input (``token: str``), one
output (:class:`VerifiedClaims`), one failure shape (subclasses of
:class:`~skaldos.auth.errors.TokenVerificationError`). Adding a
second method would invite split responsibilities; the brainstorm
(``03-technical-implementation.md`` § "Out of scope") explicitly
declines.

Forward-ref return type
-----------------------

:class:`VerifiedClaims` is imported only under
``if TYPE_CHECKING:`` so ``protocol.py`` stays decoupled from
``models.py`` at runtime --- the runtime dependency graph flows
``__init__.py`` -> ``protocol.py`` (no models import) and
``__init__.py`` -> ``models.py`` -> ``errors.py``, keeping
``protocol.py`` import-cheap. Combined with
``from __future__ import annotations`` at the top of the module, all
annotations are strings at runtime; pyright still resolves the type
fully for static checking. Runtime ``runtime_checkable`` introspection
ignores annotations entirely (it inspects method *names*), so the
deferred import has no runtime cost.

References: ADR 19 (Auth0); MP6 (agents are clients --- same Protocol);
MP10 (humans + agents same JWT shape; the discriminator decision is
inside :class:`~skaldos.auth.models.RawClaims`, not branching on the
caller side); §4.1 (verification is the first chokepoint); AP5
(no test-only bypass --- the Protocol is the only entry point;
tests use the real validator with a stubbed JWKS endpoint, not a
hand-written ``TokenVerifier`` fake);
``02-edge-cases.md`` E8/E9/E12/E13 (the failure classes the single
``verify()`` method surfaces).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    # Imported only at type-check time to keep the runtime dependency
    # graph one-directional (``models.py`` imports ``errors.py``;
    # ``protocol.py`` imports neither). pyright resolves the forward
    # reference for static-typecheck purposes; runtime
    # ``runtime_checkable`` introspection inspects method *names*, not
    # annotations, so the deferred import has no runtime cost.
    from .models import VerifiedClaims


@runtime_checkable
class TokenVerifier(Protocol):
    """JWT validator; implemented by every token-verification adapter.

    Method docstring describes the *contract* every adapter must honor.
    The production adapter (:class:`~skaldos.auth.verifier.Auth0Verifier`,
    landing in T4) decodes + verifies an Auth0-issued RS256 JWT and
    produces a :class:`~skaldos.auth.models.VerifiedClaims`. Adding a
    method here is a typecheck failure on every adapter that doesn't
    implement it --- that's the desired behavior (drift is loud, not
    silent).

    Composition with the rest of the auth chokepoint:

    - The FastAPI dependency from T5 (``verify_token`` in
      :mod:`skaldos.auth.fastapi`) extracts the bearer header and calls
      this Protocol's :meth:`verify` method.
    - The peer feature (principal-hydration-middleware) imports the
      :class:`~skaldos.auth.models.VerifiedClaims` returned here as a
      forward ref and resolves identity from it (lookup-by-
      ``auth0_sub`` for humans within ``org_id``; lookup-by-``azp``
      for agents).
    - Test code injects an alternate Protocol implementation via
      FastAPI's ``app.dependency_overrides``; the Protocol is the
      seam that makes that injection type-safe (AP5: no separate
      "test mode" code path; the test injects a real adapter, not a
      side-channel).
    """

    async def verify(self, token: str) -> VerifiedClaims:
        """Verify ``token`` and return its :class:`VerifiedClaims`.

        ``token`` is the bearer string (no ``"Bearer "`` prefix; the
        FastAPI dependency strips that before calling). Adapters do
        not interpret the prefix; they receive the raw JWT.

        On success, returns a frozen :class:`VerifiedClaims` carrying
        the discriminator decision (``kind``, ``"human"`` or
        ``"agent"``), the lookup keys downstream consumers need
        (``sub`` / ``auth0_sub`` / ``azp`` / ``org_id``), and the
        verbatim ``raw_claims`` dict for forward-compatible reads
        (Slice 7+ delegation reads ``act`` from ``raw_claims``).

        On failure, raises a subclass of
        :class:`~skaldos.auth.errors.TokenVerificationError`. The
        exact subclass tells the caller *why* verification failed;
        the FastAPI dependency in T5 maps each subclass to the right
        HTTP code (401 for caller errors --- expired, malformed,
        ambiguous discriminator; 503 for our infrastructure ---
        :class:`~skaldos.auth.errors.JWKSUnavailable` on cold start).
        Adapters MUST NOT raise bare :class:`Exception` --- the
        hierarchy is the contract that lets the FastAPI dependency
        translate without per-class branches.

        See ``02-edge-cases.md`` E1--E27 for the complete failure
        taxonomy this method surfaces, and § "Error management" in
        ``03-technical-implementation.md`` for the
        exception → log-event → HTTP-code mapping.
        """
        ...
