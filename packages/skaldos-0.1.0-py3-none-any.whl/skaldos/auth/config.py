"""Auth chokepoint configuration --- startup-fail env-var validation (T2).

Per ``docs/slices/slice-1-tenant-chokepoint/auth0-jwt-verification/03-technical-implementation.md``
§ "config.py" and ``05-task-list.md`` § T2: :class:`AuthConfig` is the
single source of truth for the auth chokepoint's per-environment
configuration. It loads from environment variables, validates on
construction, and crashes the process on misconfiguration --- mirroring
the §14.7 idiom "fail on startup if encryption-key env vars are unset"
applied to boundary-trust env vars.

Master-plan ADR resolution
--------------------------

The brainstorm (``05-task-list.md`` § T2) originally called for a
separate CI lint script (``scripts/check-auth-config.py``) that would
catch ``AUTH0_JWKS_URL_OVERRIDE`` appearing in non-test ``.env``
files. The master plan
(``docs/slices/slice-1-tenant-chokepoint/master-plan.md`` § "ADRs
surfaced for resolution" → row "``AUTH0_JWKS_URL_OVERRIDE`` lint")
collapsed that into this module's ``model_validator``:

    "§14.7 idiom --- 'fail on startup if encryption-key env vars are
    unset' generalizes to 'fail on startup if a test-only override is
    set in non-test env.' No new script needed."

The ``_validate_override_not_in_production`` model validator below
implements the resolution: in production (``SKALDOS_ENV=production``),
setting ``AUTH0_JWKS_URL_OVERRIDE`` raises a ``ValueError`` that
Pydantic surfaces as a ``ValidationError`` during ``AuthConfig()``
construction. The process never reaches its first request with a
misconfigured override; the operator gets a clear, named error.

Environment-variable contract
-----------------------------

Required (no default; absence raises on construction):

- ``AUTH0_ISSUER`` --- the Auth0 tenant URL. Validated against
  ``^https://skaldos(-[a-z0-9]+)?\\.eu\\.auth0\\.com/$`` per
  ``tests/fixtures/auth0/auth0_spec.json``
  § ``common_required_claims.iss.must_match_regex``. Trailing slash is
  significant (E29). Per-environment per §14.3.
- ``AUTH0_AUDIENCE`` --- the API audience identifier (e.g.
  ``https://api-dev.skaldos.io``). Required to be non-empty.
  Per-environment per §14.3.

Tunable (defaults documented in
``02-edge-cases.md`` E5/E14/E15/E27):

- ``AUTH0_CLOCK_SKEW_SECONDS`` (default 60) --- leeway on
  ``exp`` / ``nbf`` / ``iat`` checks (E5).
- ``AUTH0_JWKS_TTL_SECONDS`` (default 600) --- cap on JWKS cache
  age; effective TTL is ``min(this, upstream Cache-Control max-age)``
  per E27.
- ``AUTH0_JWKS_MIN_REFRESH_INTERVAL_SECONDS`` (default 10) ---
  minimum interval between JWKS refresh attempts. Defends against
  forged-``kid`` DoS (E14).
- ``AUTH0_JWKS_STALE_GRACE_SECONDS`` (default 60) --- how long the
  JWKS cache can serve stale entries past TTL during a warm-failure
  outage (E6.warm + E15) before degrading to ``JWKSUnavailable``.
  Used by :class:`~skaldos.auth.jwks.JWKSCache` (T3).

Test-only seam (production guarded):

- ``AUTH0_JWKS_URL_OVERRIDE`` (default ``None``) --- points the JWKS
  cache at an in-process mock during integration tests; production
  derives the JWKS URL from ``AUTH0_ISSUER``. The model validator
  refuses to construct when ``SKALDOS_ENV=production`` AND this is
  set, defending against a deployment-config leak that would point
  JWKS at an attacker-controlled URL (AP5: no test-only side
  channels).

Environment selector:

- ``SKALDOS_ENV`` (default ``"development"``) --- which environment
  this process is running in. Aligns with the existing convention in
  ``tests/integration/_framework/test_log_capture.py`` and the
  Slice 0 logging-infrastructure chokepoint canaries
  (``tests/integration/_framework/canaries/test_chokepoint_canaries.py``)
  which read ``SKALDOS_ENV`` from os.environ. The master plan's
  ``/whoami`` route registration (slice-gate) also keys on this var
  (gated off in ``SKALDOS_ENV=production``).

Why no ``.env`` autoload at unit-test time
------------------------------------------

``SettingsConfigDict(env_file=None)`` is intentional: a unit test
that constructs ``AuthConfig`` from env vars in ``monkeypatch`` must
not silently read a project ``.env`` file that the developer happens
to have on disk. The unit-test suite asserts this property
explicitly (``test_no_env_file_autoload``). Production wiring (the
T5 FastAPI lifespan) reads env vars from the deploy environment
(Cloud Run / mise), not from a ``.env`` file --- mise sets the env
in-shell per Slice 0's dev-env convention; production deploy injects
via the platform.

Why ``case_sensitive=False``
----------------------------

Pydantic Settings reads env vars case-insensitively when
``case_sensitive=False``: the field ``auth0_issuer`` matches
``AUTH0_ISSUER``, ``auth0_issuer``, or any case mix. The master
plan's deploy-config convention (``AUTH0_ISSUER`` uppercase) is
honored; developer-facing ``.env.example`` files use uppercase too.
Setting ``case_sensitive=True`` would force every consumer to write
``AUTH0_ISSUER`` exactly --- an unnecessary footgun.

References: §14.3 (per-environment tenants), §14.7 (fail on startup
if security-critical env vars are unset), §3.1 (plural-tenant
principal --- the validator emits ``org_id`` for humans),
§4.1 (auth as the first chokepoint), ADR 19 (Auth0 contract);
``master-plan.md`` § "ADRs surfaced for resolution" → row
``AUTH0_JWKS_URL_OVERRIDE`` lint;
``02-edge-cases.md`` E5/E14/E15/E18/E27/E29;
``04-testing-strategy.md`` § "tests/unit/test_auth_config.py";
``tests/fixtures/auth0/auth0_spec.json``
§ ``common_required_claims.iss.must_match_regex``.
"""

from __future__ import annotations

import re
from typing import ClassVar

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Anchored issuer regex from `tests/fixtures/auth0/auth0_spec.json`
# § `common_required_claims.iss.must_match_regex`. Trailing slash is
# significant (Auth0 issues with it; validator must compare with it).
# `(-[a-z0-9]+)?` is the per-env infix (e.g. `-dev`, `-staging`); the
# unnamed env (production) is the bare `https://skaldos.eu.auth0.com/`.
# Anchored with `^...$` so query strings / fragments / additional path
# components reject (E29).
_ISSUER_RE: re.Pattern[str] = re.compile(r"^https://skaldos(-[a-z0-9]+)?\.eu\.auth0\.com/$")


class AuthConfig(BaseSettings):
    """Auth chokepoint configuration loaded from environment variables.

    Constructed once at FastAPI app startup (T5's lifespan context
    manager). Field validation fires on construction; bad values
    raise :class:`pydantic.ValidationError`, which uvicorn surfaces
    as a clean process exit with a clear error message (mirroring
    §14.7's "fail on startup" idiom).

    Per master-plan ADR resolution, the
    :meth:`_validate_override_not_in_production` model validator is
    the encoded form of what the brainstorm called the
    "``AUTH0_JWKS_URL_OVERRIDE`` lint" --- a startup assertion, not a
    separate CI script. Defense-in-depth: even if a CI lint missed
    a misconfigured override, the running process refuses to start.

    Test code constructs ``AuthConfig`` with explicit kwargs (or via
    ``monkeypatch.setenv`` + bare ``AuthConfig()``); production
    wiring uses bare ``AuthConfig()`` at app startup.
    """

    # SettingsConfigDict is the Pydantic v2 idiom for BaseSettings
    # configuration --- analogous to Pydantic models' ``model_config``.
    #
    # ``env_file=None``: do not autoload a ``.env`` file. Production
    # deploys inject env vars via the platform (Cloud Run, mise);
    # developer machines load ``.env`` via mise (per Slice 0's
    # dev-environment T1). Pydantic Settings autoloading would
    # double-source the env, hiding which value won.
    # ``case_sensitive=False``: ``AUTH0_ISSUER`` and ``auth0_issuer``
    # both populate the same field. Deploy-config convention is
    # uppercase; developer-facing tools may emit lowercase.
    # ``extra="ignore"``: extra env vars (e.g. ``DATABASE_URL`` in the
    # process environment) do not raise; only the declared fields are
    # consumed.
    model_config: ClassVar[SettingsConfigDict] = SettingsConfigDict(
        env_file=None,
        case_sensitive=False,
        extra="ignore",
    )

    # ---- Required fields (no defaults). -------------------------------------
    auth0_issuer: str
    """The Auth0 tenant issuer URL.

    Validated against the regex from ``auth0_spec.json``
    § ``common_required_claims.iss.must_match_regex``. Trailing
    slash is significant (E18, E29). Per-environment per §14.3.
    """

    auth0_audience: str
    """The API audience identifier (e.g. ``https://api-dev.skaldos.io``).

    Per-environment per §14.3. Validated as non-empty; the JWT
    library compares this against the token's ``aud`` claim
    (string-equal or array-membership) per ``auth0_spec.json``
    § ``common_required_claims.aud``.
    """

    # ---- Tunables (sane defaults per the brainstorm). -----------------------
    auth0_clock_skew_seconds: int = 60
    """Leeway on JWT time-claim checks (``exp`` / ``nbf`` / ``iat``).

    Default 60s per E5 reasoning: Auth0's documented clock-skew
    tolerance is 60s; production NTP-synced servers stay within
    ±1s; widening past 60s shrinks the effective expiry window of
    short-lived tokens.
    """

    auth0_jwks_ttl_seconds: int = 600
    """Cap on JWKS cache age before forced refresh.

    Default 600s per E15 / E27 reasoning. Effective cache age in
    :class:`~skaldos.auth.jwks.JWKSCache` is
    ``min(this, upstream Cache-Control max-age)`` --- the cache
    refreshes more often if Auth0 says so but never less often.
    """

    auth0_jwks_min_refresh_interval_seconds: int = 10
    """Minimum interval between JWKS refresh attempts.

    Default 10s per E14 reasoning: bounds JWKS refresh traffic
    against forged-``kid`` DoS. Auth0 rotation can't realistically
    happen more than once per 10s, so this is operationally
    transparent.
    """

    auth0_jwks_stale_grace_seconds: int = 60
    """How long :class:`~skaldos.auth.jwks.JWKSCache` may serve stale
    entries past TTL during a warm-failure outage before degrading
    to :class:`~skaldos.auth.errors.JWKSUnavailable`.

    Default 60s per ``05-task-list.md`` § T2 scope. Used by
    :class:`~skaldos.auth.jwks.JWKSCache`'s
    stale-while-revalidate path (E6.warm + E15). Configurable via
    ``AUTH0_JWKS_STALE_GRACE_SECONDS`` if observed traffic justifies
    tuning.
    """

    # ---- Test-only seam (guarded by the model validator). -------------------
    auth0_jwks_url_override: str | None = None
    """Test-only override for the JWKS endpoint URL.

    Production derives the JWKS URL from :attr:`auth0_issuer`
    (``{issuer}.well-known/jwks.json``). The integration-test
    suite (``tests/integration/test_auth0_validator_*``) sets this
    to the in-process Auth0 mock issuer's JWKS endpoint, so the
    production validator runs through the same code path against
    a stubbed upstream (AP5: no separate test-mode bypass).

    The :meth:`_validate_override_not_in_production` model validator
    rejects this in production (``SKALDOS_ENV=production``). Per
    master-plan ADR resolution, the original "CI lint" for this
    var folded into this validator --- defense-in-depth, no
    separate script.
    """

    # ---- Environment selector. ----------------------------------------------
    skaldos_env: str = "development"
    """Which environment this process is running in.

    Read from the ``SKALDOS_ENV`` env var (the existing convention
    used by the Slice 0 logging-infrastructure chokepoint canaries
    and the master plan's ``/whoami`` route registration). Common
    values: ``"development"``, ``"test"``, ``"staging"``,
    ``"production"``. Only ``"production"`` triggers the override
    guard; other values are unconstrained.
    """

    # -------------------------------------------------------------------------
    # Validators
    # -------------------------------------------------------------------------

    @field_validator("auth0_issuer")
    @classmethod
    def _validate_issuer(cls, v: str) -> str:
        """Reject any ``AUTH0_ISSUER`` that doesn't match the spec regex.

        The regex is anchored with ``^...$`` and requires a trailing
        slash. Common failure modes:

        - Missing trailing slash (E18) --- ``https://skaldos-dev.eu.auth0.com``.
        - Wrong region (``us`` instead of ``eu``).
        - Wrong protocol (``http://``).
        - Tenant typo (``skaldoss-dev``).
        - Query string / fragment (E29) ---
          ``https://skaldos-dev.eu.auth0.com/?evil=1``.

        The error message names ``AUTH0_ISSUER`` explicitly so a
        deploy-config typo surfaces with the offending env var name
        in the stack trace. Operator remediation lives in the auth
        runbook (T7).

        Pins ``auth0_spec.json`` § ``common_required_claims.iss.must_match_regex``
        (E18, E29).
        """
        if not _ISSUER_RE.match(v):
            raise ValueError(
                f"AUTH0_ISSUER {v!r} does not match the expected shape "
                f"https://skaldos[-<env>].eu.auth0.com/ (note the trailing slash). "
                f"See tests/fixtures/auth0/auth0_spec.json "
                f"§ common_required_claims.iss.must_match_regex. "
                f"Common causes: missing trailing slash; wrong region "
                f"(us vs eu); typo in the tenant slug; query string "
                f"or fragment appended."
            )
        return v

    @field_validator("auth0_audience")
    @classmethod
    def _validate_audience_non_empty(cls, v: str) -> str:
        """Reject empty ``AUTH0_AUDIENCE``.

        An empty string would silently match against any token's ``aud``
        claim (depending on the JWT library's behavior) --- worse, it
        would reach the verifier as a non-error misconfiguration.
        Pydantic Settings doesn't validate empty strings out of the box
        for ``str`` fields; this validator makes the requirement
        explicit.

        Per ``02-edge-cases.md`` E21 / E22 --- audience checks are
        the second line of defense after ``iss`` for cross-environment
        isolation; an empty audience defeats both.
        """
        if not v:
            raise ValueError(
                "AUTH0_AUDIENCE must be a non-empty string "
                "(e.g. 'https://api-dev.skaldos.io'). An empty audience "
                "defeats the cross-environment isolation guard "
                "(02-edge-cases.md E21, E22)."
            )
        return v

    @model_validator(mode="after")
    def _validate_override_not_in_production(self) -> AuthConfig:
        """Reject ``AUTH0_JWKS_URL_OVERRIDE`` when running in production.

        Per master-plan ADR resolution
        (``master-plan.md`` § "ADRs surfaced for resolution" → row
        "``AUTH0_JWKS_URL_OVERRIDE`` lint"), the originally-separate
        ``scripts/check-auth-config.py`` lint folds into this model
        validator --- the §14.7 idiom "fail on startup if encryption-
        key env vars are unset" generalizes to "fail on startup if a
        test-only override is set in non-test env."

        Defense-in-depth: even if a CI lint or code-review missed a
        misconfigured deploy that sets ``AUTH0_JWKS_URL_OVERRIDE`` in
        production, the running process refuses to start. The
        override is a test-only seam; setting it in production
        points the JWKS cache at an attacker-controlled URL,
        defeating the entire signature-verification chokepoint
        (AP5).

        Pins ``02-edge-cases.md`` E29 (override-leak defense) and
        the master plan's ADR resolution. Unit tests in
        ``tests/unit/test_auth_config.py`` exercise both the
        production-rejection and the dev/test-acceptance paths.
        """
        if self.skaldos_env == "production" and self.auth0_jwks_url_override is not None:
            raise ValueError(
                f"AUTH0_JWKS_URL_OVERRIDE may not be set in production "
                f"(SKALDOS_ENV={self.skaldos_env!r}). The override is a "
                f"test-only seam used by the integration-test suite to "
                f"point JWKS at an in-process mock; setting it in "
                f"production points JWKS at a configurable URL, defeating "
                f"the signature-verification chokepoint (AP5). "
                f"See master-plan.md § 'ADRs surfaced for resolution' → "
                f"row 'AUTH0_JWKS_URL_OVERRIDE lint' for the rationale."
            )
        return self
