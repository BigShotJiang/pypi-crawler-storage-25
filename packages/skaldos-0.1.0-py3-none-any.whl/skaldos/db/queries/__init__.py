"""Canonical home for SkaldOS aiosql query files.

This directory holds every ``.sql`` file consumed by ``aiosql`` at
runtime. Per **§14.12** + **ADR 3**, queries are hand-written SQL
loaded into Python via aiosql; results cross the Python boundary
through Pydantic models (no ORM, no string-result tuples).

Slice 1's ``defense-in-depth-tenant-filter/T1`` plants this directory
as the default scan target of ``scripts/check_tenant_filter.py``;
real queries land slice-by-slice with their owning features. The
template below is the **shape every multi-tenant query takes** — it
is canonical, not aspirational, and the lint enforces it.

## Canonical multi-tenant query template

Every query that reads or writes a multi-tenant table must declare
the tenant predicate explicitly, even though Layer 1 (RLS) is also
filtering. Per §3.6, the two layers in lockstep are the load-bearing
defense:

.. code-block:: sql

    -- name: get_node_for_principal^
    SELECT id, kind, content, tenant_id, created_at
    FROM nodes
    WHERE tenant_id = ANY(:visible_tenants)
      AND id = :node_id;

The ``WHERE tenant_id = ANY(:visible_tenants)`` clause is what the
lint (R1) requires. Acceptable variants:

- ``tenant_id = :primary_tenant`` (write-path narrowing — see §3.1).
- ``tenant_id IN (:t1, :t2, …)`` (rare; static lists).
- For the ``tenants`` table itself: ``id = :primary_tenant`` /
  ``id = ANY(:visible_tenants)`` (its ``id`` *is* the tenant
  discriminator).

**Param-name allowlist (lint-enforced).** ``:visible_tenants``,
``:primary_tenant``, ``:tenant_id``. Anything else fails R1 with
"non-canonical tenant param name." This keeps the application's
predicate in lockstep with the GUC-driven RLS expression
(``app.principal_visible()``); divergence between the two layers is
the silent-disagreement fault line called out in
``03-technical-implementation.md``.

## Canonical principals query template

``principals`` is **global identity**, not multi-tenant. Queries
against it are governed by R6 (bound predicate or transitive multi-
tenant join), not R1. The chokepoint's identity lookup uses the
``-- principal_global:`` marker:

.. code-block:: sql

    -- principal_global: chokepoint identity lookup; bound by auth0_sub
    -- name: get_principal_by_auth0_sub^
    SELECT id, kind, auth0_sub, primary_tenant_id, visible_tenant_ids,
           display_name, created_at, updated_at
    FROM principals
    WHERE auth0_sub = :auth0_sub;

Cross-tenant principals reads (admin views in later slices) use the
**transitive multi-tenant join** shape — the lint accepts this
without a ``-- principal_global:`` marker because the FROM clause
flows through ``memberships``, which is multi-tenant and carries the
explicit filter:

.. code-block:: sql

    -- name: list_principals_in_visible_tenants^
    SELECT p.id, p.kind, p.display_name, m.tenant_id, m.role
    FROM principals p
    JOIN memberships m ON m.principal_id = p.id
    WHERE m.tenant_id = ANY(:visible_tenants);

## Marker conventions (escape hatches)

Two markers may opt a query out of the default rules. They live
**immediately above** the ``-- name:`` header for the query they
cover. Empty reasons are themselves a violation (R0b — mirrors
``check_migration.py``'s R1b idiom).

- ``-- tenant_filter_required: <reason>`` — opt out of R1. **No
  legitimate use is expected in Slice 1.** Any new use requires
  master-plan-level review (see ``docs/runbooks/tenant-filter-lint.md``
  when T3 lands the runbook).

- ``-- principal_global: <reason>`` — opt out of R6 for principals
  queries. Reserved for the chokepoint's own identity lookup
  (``get_principal_by_auth0_sub``) and other narrowly-justified
  cases.

References: §3.6, §3.1, §14.12, ML4, ML5, ADR 3.
"""
