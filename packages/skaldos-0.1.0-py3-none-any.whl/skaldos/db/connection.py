"""Request-scoped connection accessor (Slice 1, principal-hydration-middleware T4).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "Connection acquisition pattern" and
``05-task-list.md`` § T4: the FastAPI dependency :func:`get_connection`
returns the request-scoped asyncpg connection that the chokepoint
(T6's ``current_principal``) stashed in ``request.state.connection``.

Why one accessor, no second pool acquire
----------------------------------------

The load-bearing property of Slice 1 is **the connection that ran
``set_config`` is the connection that runs every subsequent query in
the request** (PC1 / §3.5 / §18.3 / S1 spike outcome). PgBouncer
transaction-mode hands the same backend for the duration of one
explicit transaction; if a handler accidentally acquired a *fresh*
connection mid-request via a second ``pool.acquire()`` call, that
backend would have empty GUCs, RLS would read NULL, and the chokepoint's
guarantee would silently lapse.

This dependency narrows the surface so handlers cannot do that. There
is exactly one chokepoint that calls ``pool.acquire()``
(``current_principal`` -- T6, follow-up); every aiosql query in a
handler reads its connection from this accessor; the accessor refuses
to fall back to a fresh pool.acquire when the chokepoint hasn't run
(E20 / AP5).

What happens on misconfiguration
--------------------------------

If a handler depends on :func:`get_connection` but the route lacks
``Depends(current_principal)``, ``request.state.connection`` is unset.
The accessor raises a developer-facing :class:`RuntimeError` naming
the missing chokepoint -- a load-bearing test
(``test_get_connection_raises_when_request_state_missing``) pins the
exception type and the message-content shape. The error never
ships to the wire (FastAPI's exception handler maps it to the
configured 500 response with no leak of internal state) but the test
catches the misconfiguration before merge.

References: §3.5 (single connection per request transaction); §18.3
(PgBouncer-tx; one acquire per request); ML2 (Depends() graph as the
substrate -- not a DI container); ML5.5 (no ``current_principal_id``
reads outside the chokepoint -- this dependency is the *only* legitimate
read of the request-scoped connection); AP5 (no debug bypass; the
``RuntimeError`` is loud, not silent); PC3 (``app_runtime`` is the
pool's role; the chokepoint never reaches ``app_migrate``).
"""

from __future__ import annotations

import asyncpg
from fastapi import Request

__all__ = ["get_connection"]


async def get_connection(request: Request) -> asyncpg.Connection:
    """Return the request-scoped asyncpg connection.

    The chokepoint (T6's ``current_principal``) stashes the connection
    in ``request.state.connection`` after acquiring it from the pool,
    opening a transaction, and committing the GUC contract (PC1).
    Every aiosql call in a handler reads from this accessor; there is
    no other legitimate path to the connection.

    Raises
    ------
    :class:`RuntimeError`
        When ``request.state.connection`` is unset. This is *always* a
        developer error (a route declared
        ``Depends(get_connection)`` without
        ``Depends(current_principal)``, or a caller invoked
        :func:`get_connection` outside the FastAPI request lifecycle).
        The error message names the missing chokepoint by file path so
        the fix is unambiguous.
    """
    conn: asyncpg.Connection | None = getattr(request.state, "connection", None)
    if conn is None:
        raise RuntimeError(
            "request.state.connection is not set. The current_principal "
            "FastAPI dependency (services/api/skaldos/middleware/hydration.py, "
            "T6) is the only legitimate setter. If you are seeing this, "
            "either (a) the route is missing Depends(current_principal), "
            "or (b) you are calling get_connection outside the FastAPI "
            "request lifecycle. AP5: there is no debug bypass -- use the "
            "chokepoint."
        )
    return conn
