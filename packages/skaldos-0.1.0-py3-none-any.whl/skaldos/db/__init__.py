"""``skaldos.db`` — database access surface (aiosql + Pydantic boundary).

Per **§14.12** and ADR 3, SkaldOS uses ``aiosql`` to load hand-written
SQL out of ``.sql`` files and Pydantic to validate every result-set
boundary. **No ORM.** This package is the Python-side shape that holds
the loaded queries and the Pydantic result types.

Slice 1's ``defense-in-depth-tenant-filter/T1`` plants this directory
+ ``db/queries/`` as the canonical home for aiosql query files (and as
the default scan target of ``scripts/check_tenant_filter.py``). Real
queries land slice-by-slice with their owning features.

Slice 1's ``principal-hydration-middleware/T4`` plants the asyncpg
runtime pool + the request-scoped connection accessor:

- :func:`get_pool` --- module-level asyncpg pool singleton; reads
  ``DATABASE_URL`` and sizing knobs (``POOL_MIN_SIZE`` /
  ``POOL_MAX_SIZE`` / ``POOL_CONNECT_TIMEOUT`` /
  ``POOL_COMMAND_TIMEOUT``) from env. The DSN points at the PgBouncer
  transaction-mode listener on port 5431 (§18.3).
- :func:`get_acquire_timeout` --- helper returning the per-acquire
  timeout (``POOL_ACQUIRE_TIMEOUT``, default ``5.0``). T6's
  chokepoint passes this on every ``pool.acquire()`` call so the
  exhaustion path fires fast (E9 → 503).
- :func:`close_pool` --- idempotent teardown; called at FastAPI
  shutdown via :func:`db_lifespan` and between integration-test
  scenarios that need to reconfigure pool sizing.
- :func:`db_lifespan` --- FastAPI ``lifespan`` context manager that
  brings :func:`get_pool` up at startup and down at shutdown.
- :func:`get_connection` --- the FastAPI dependency that returns
  ``request.state.connection`` (the chokepoint -- T6's
  ``current_principal`` -- is the only legitimate setter).

References: §14.12 (aiosql + Pydantic), §18.3 (PgBouncer-tx pool),
§14.7 (pool-as-budget), ML2 (per-request service instantiation), AP5
(no debug bypass), PC3 (three roles; the pool authors as
``app_runtime``).
"""

from __future__ import annotations

from .connection import get_connection
from .pool import close_pool, db_lifespan, get_acquire_timeout, get_pool

__all__ = [
    "close_pool",
    "db_lifespan",
    "get_acquire_timeout",
    "get_connection",
    "get_pool",
]
