"""asyncpg pool singleton (Slice 1, principal-hydration-middleware T4).

Per
``docs/slices/slice-1-tenant-chokepoint/principal-hydration-middleware/03-technical-implementation.md``
§ "Connection acquisition pattern" and
``05-task-list.md`` § T4: the runtime pool is a module-level singleton
wrapping :func:`asyncpg.create_pool`. The DSN points at PgBouncer in
**transaction-mode on port 5431** (§18.3, PC12); the application's RLS-
bound runtime traffic flows through this pool. Migrations and
LISTEN/NOTIFY take a different path on the direct port (5432) and are
*not* served from this pool (§18.3 / PC12 -- ``app_migrate`` runs
``alembic upgrade head`` direct, the dispatcher ``LISTEN``s direct).

Why a module-level singleton
----------------------------

ML2 ("per-request service instantiation; no DI container") means the
``Depends()`` graph composes fresh per request, but **the pool itself
is a singleton across the process**. Re-creating a pool per request
would defeat the whole point of pooling -- every request would pay the
TCP-handshake + scram-auth cost. The singleton is initialized lazily at
the first :func:`get_pool` call (or eagerly via :func:`db_lifespan`
during FastAPI startup), and torn down once at process exit.

Why the lazy init pattern
-------------------------

The dependency surface is shaped so a test can:

1. Import :func:`get_pool` and call it inside an event loop -- the pool
   comes up the first time it's needed.
2. Or, run a fake FastAPI app through :func:`db_lifespan` -- the pool
   comes up at startup.
3. Or, in unit-tier scopes that don't touch the DB, never call either
   -- the pool stays uninitialized; the module's import has no side
   effects.

Tests must call :func:`close_pool` between tests that reconfigure the
pool (e.g. ``POOL_MAX_SIZE=1`` for a pool-exhaustion test) so the
following test's first :func:`get_pool` call rebuilds the pool with
the new config. This is the single cleanup contract; the test file
documents it inline.

Configuration -- env vars
-------------------------

The DSN is read from ``DATABASE_URL`` (the canonical convention shared
with ``migrations/env.py`` -- see ``migrations/env.py`` § ``_get_url``).
A future configurable :class:`~skaldos.config.AppConfig` (Slice 2+
candidate) may supersede this, but in Slice 1 every Python entry point
that touches the DB reads the same env var so there's exactly one knob
to point at the cluster.

Pool sizing follows the §14.7 default:

- ``POOL_MIN_SIZE`` (default ``2``) -- minimum idle connections.
- ``POOL_MAX_SIZE`` (default ``20``) -- maximum concurrent connections.
- ``POOL_ACQUIRE_TIMEOUT`` (default ``5.0`` seconds) -- how long an
  individual ``pool.acquire()`` call waits before raising
  :class:`TimeoutError` (E9 / S13). T4 plants the env var name and
  exposes it via :func:`get_acquire_timeout`; T6's chokepoint reads
  it once at startup and passes ``timeout=POOL_ACQUIRE_TIMEOUT`` on
  every ``pool.acquire()`` call. T6 then translates the
  :class:`TimeoutError` to :class:`~skaldos.middleware.PoolExhausted`
  → HTTP 503 + ``Retry-After: 5``.

  *Why not bake it into the pool itself?* asyncpg's
  :meth:`Pool.acquire` accepts a per-call ``timeout`` keyword; the
  ``timeout`` parameter on :func:`asyncpg.create_pool` is the
  *connection-establishment* timeout, not a default acquire timeout.
  Wrapping every acquire in a fixed pool-level timeout would force
  the value into the pool's bind path; T6's chokepoint owning the
  per-acquire timeout keeps the policy at the chokepoint where the
  503-translation contract lives.

- ``POOL_CONNECT_TIMEOUT`` (default ``5.0`` seconds) -- how long
  the underlying asyncpg connect waits before failing. Passed as
  the ``timeout`` argument to :func:`asyncpg.create_pool`. Distinct
  from the per-acquire timeout above.

- ``POOL_COMMAND_TIMEOUT`` (default ``5.0`` seconds) -- per-command
  timeout for queries issued through pool-acquired connections.
  Distinct from ``SET LOCAL statement_timeout`` (E19) which the
  chokepoint sets at the *transaction* level; this is a defense-in-
  depth ceiling at the *connection* level.

References: §14.7 (pool sizing as a budget decision); §18.3 (dual-port
pool architecture); ML2 (per-request service instantiation, no DI
container -- the singleton is the *pool*, not the connections); PC3
(``app_runtime`` is the connection role; the DSN must be authored to
that role at deploy time); AP5 (no debug bypass -- there is no second
pool for "just for debug" paths). See also master-plan ``Slice 1, Wave
2``.
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

import asyncpg

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

__all__ = [
    "close_pool",
    "db_lifespan",
    "get_acquire_timeout",
    "get_pool",
]


# ---------------------------------------------------------------------------
# Module-level state. The single pool object lives here for the process'
# lifetime; tests close it via :func:`close_pool` between scenarios that
# need to reconfigure (e.g. exhausted-pool tests).
#
# ``asyncpg.Pool`` is not parameterizable at runtime (the asyncpg package
# ships no stubs and the class declares no ``__class_getitem__``); we
# annotate as the bare class to match :mod:`skaldos.middleware.resolver`
# which uses ``asyncpg.Connection`` the same way (T2 / PR #61).
# ---------------------------------------------------------------------------
_pool: asyncpg.Pool | None = None


def _resolve_dsn() -> str:
    """Return the runtime DSN.

    Reads the ``DATABASE_URL`` env var verbatim. The convention is
    shared with ``migrations/env.py`` (single source of truth for
    "where is the cluster?"). asyncpg accepts both ``postgresql://``
    and ``postgres://`` schemes; the SQLAlchemy ``+asyncpg`` /
    ``+psycopg`` qualifier is stripped if present so the same env var
    works for both Alembic (which uses SQLAlchemy's URL parser) and
    asyncpg.

    In production the DSN authors as ``app_runtime`` (PC3); the
    target host is the PgBouncer transaction-mode listener on port
    5431 (§18.3). Migrations -- which connect as ``app_migrate``
    against the direct port 5432 -- read a *different* env var
    (Slice 2+ MAY introduce ``DATABASE_URL_MIGRATE``); for Slice 1
    the migrations env-block is set out-of-band (CI / local dev's
    ``mise``).

    .. note::
       **Resolved by Slice 2 followups #3 (PR #<this PR>):** the
       chokepoint pool now uses the ``app_chokepoint`` BYPASSRLS role
       (migration ``20260507_app_chokepoint_role.py``). That role's
       BYPASSRLS attribute lets the resolver look up ``principals``
       before the PC1 GUC contract is committed, avoiding the
       "policies fail closed → zero rows → duplicate INSERT → 500"
       failure mode documented in
       ``docs/specs/2026-05-02-slice-1-followups.md`` entry #3.
       Engine T4 (the next PR in this wave) wires the pool to use
       ``CHOKEPOINT_POOL_DSN`` (the ``app_chokepoint`` DSN) instead
       of ``DATABASE_URL``; see ``services/api/skaldos/policy/pool.py``
       once that PR lands.

    Raises :class:`RuntimeError` when ``DATABASE_URL`` is unset --
    refusing to fall back to a default, mirroring
    ``migrations/env.py``'s ``_get_url`` discipline (E12 / fail-loud-
    on-missing-config).
    """
    raw = os.environ.get("DATABASE_URL")
    if not raw:
        raise RuntimeError(
            "DATABASE_URL is not set. The asyncpg runtime pool refuses to "
            "fall back to a default; set DATABASE_URL to the app_runtime "
            "DSN against the PgBouncer transaction-mode listener (port "
            "5431 per §18.3). For migrations the same env var is read by "
            "alembic env.py."
        )
    # Strip SQLAlchemy driver qualifiers; asyncpg only accepts the bare
    # ``postgresql://`` scheme. The same coercion lives in
    # ``migrations/env.py`` and ``tests/integration/_framework/sessions.py``;
    # keeping a private copy here avoids cross-module imports for a
    # one-line transform.
    return raw.replace("postgresql+psycopg://", "postgresql://", 1).replace(
        "postgresql+asyncpg://", "postgresql://", 1
    )


def _env_int(name: str, default: int) -> int:
    """Read an int env var with a default."""
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return int(raw)


def _env_float(name: str, default: float) -> float:
    """Read a float env var with a default."""
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return float(raw)


def get_acquire_timeout() -> float:
    """Return the per-acquire timeout (seconds) the chokepoint should pass.

    T6's :func:`current_principal` reads this once at startup and
    passes it as the ``timeout`` keyword to every ``pool.acquire()``
    call. Documented separately from :func:`get_pool` because the
    asyncpg pool's own ``timeout`` parameter is the connection-
    establishment timeout, not a default acquire timeout (see the
    module docstring's Configuration section).
    """
    return _env_float("POOL_ACQUIRE_TIMEOUT", 5.0)


async def get_pool() -> asyncpg.Pool:
    """Return the process-wide asyncpg pool, building it on first call.

    Lazy init -- the first call constructs the pool against
    ``DATABASE_URL`` with sizing from ``POOL_MIN_SIZE`` /
    ``POOL_MAX_SIZE`` / ``POOL_CONNECT_TIMEOUT`` /
    ``POOL_COMMAND_TIMEOUT`` (defaults documented in the module
    docstring). Subsequent calls return the same object (idempotent).

    T6's :func:`current_principal` chokepoint dependency calls this
    via ``Depends(get_pool)``; the chokepoint then calls
    ``pool.acquire(timeout=get_acquire_timeout())`` inside its async-
    generator body so the per-acquire timeout fires under exhaustion
    (E9). This function is **not** itself a context manager -- it
    returns the pool, never the connection. The test
    :func:`tests.integration.middleware.test_pool_connection_pattern.
    test_get_pool_is_idempotent` pins the singleton property.
    """
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(  # pyright: ignore[reportUnknownMemberType]
            dsn=_resolve_dsn(),
            min_size=_env_int("POOL_MIN_SIZE", 2),
            max_size=_env_int("POOL_MAX_SIZE", 20),
            command_timeout=_env_float("POOL_COMMAND_TIMEOUT", 5.0),
            timeout=_env_float("POOL_CONNECT_TIMEOUT", 5.0),
        )
    return _pool


async def close_pool() -> None:
    """Tear the pool down and clear the module-level handle.

    Idempotent: calling this when ``_pool is None`` is a no-op. Used
    by :func:`db_lifespan` at FastAPI shutdown and by integration
    tests between scenarios that reconfigure the pool (e.g. the
    ``test_pool_acquire_timeout_fires`` test sets ``POOL_MAX_SIZE=1``;
    the test fixture closes the pool first so the new sizing takes
    effect on the next :func:`get_pool` call).
    """
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


@asynccontextmanager
async def db_lifespan(app: object) -> AsyncGenerator[None]:
    """FastAPI ``lifespan`` context manager bringing the pool up + down.

    Use::

        app = FastAPI(lifespan=db_lifespan)

    On startup, the pool is constructed eagerly (so the first request
    doesn't pay the connection-establishment cost). On shutdown, the
    pool is closed cleanly so connections are returned to PgBouncer
    rather than abandoned (which would manifest as ``idle in
    transaction`` rows in ``pg_stat_activity`` until session timeout).

    The ``app`` parameter is the FastAPI instance; we accept it as
    ``object`` because this lifespan touches no FastAPI-specific
    state -- it's a pure pool-lifecycle hook. T6 will compose this
    with the auth feature's lifespan-managed JWKS verifier via the
    standard ``contextlib.AsyncExitStack`` pattern (Slice 1 Wave 3
    work).

    The fixture self-test
    :func:`tests.integration.middleware.test_pool_connection_pattern.
    test_db_lifespan_brings_pool_up_and_down` pins the lifecycle
    contract.
    """
    del app  # unused -- kept for the FastAPI lifespan signature
    await get_pool()
    try:
        yield
    finally:
        await close_pool()
