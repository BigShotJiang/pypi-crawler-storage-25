"""Review-marker substrate helpers for Slice 9 falsification flows.

The helpers keep falsification fallout as graph data: a content-free
``review-flag`` node plus a ``review-required-by`` edge from the dependent to
the marker. They do not rewrite dependent nodes.
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Annotated, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.events.outbox import (
    OutboxContextOfValidity,
    OutboxEnvelope,
    OutboxInsertResult,
    insert_outbox_event,
)

ReviewReason = Literal["upstream_falsified", "classifier_miss"]
ActiveReviewDecision = Literal["eligible", "requires_review"]


class ReviewFlagError(RuntimeError):
    """Raised when review marker storage or event emission fails."""


class ReviewFlagContext(BaseModel):
    """Content-free context tuple copied to review marker graph nodes."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant: UUID
    classification: Literal["C0", "C1", "C2", "C3", "C4"]
    vertical: Annotated[str, Field(min_length=1, max_length=128)] = "foundation"
    ontology_version: UUID
    valid_from: datetime
    valid_to: datetime | None = None

    @field_validator("valid_from", "valid_to")
    @classmethod
    def _normalize_timestamp(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @model_validator(mode="after")
    def _validity_window_is_ordered(self) -> ReviewFlagContext:
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError("invalid_validity_window")
        return self

    def to_outbox_context(self) -> OutboxContextOfValidity:
        return OutboxContextOfValidity.model_validate(self.model_dump(mode="python"))


@dataclass(frozen=True, slots=True)
class ReviewFlagResult:
    review_flag_node_id: UUID
    inserted: bool
    edge_inserted: bool
    outbox_event: OutboxInsertResult | None


@dataclass(frozen=True, slots=True)
class DependencyWalkResult:
    dependent_node_ids: tuple[UUID, ...]
    truncated: bool = False


def review_flag_key(
    *,
    tenant_id: UUID,
    source_decision_id: UUID,
    source_revision_id: UUID,
    dependent_node_id: UUID,
    reason: ReviewReason,
) -> str:
    """Return the deterministic review marker key for retry-safe writes."""

    identity = {
        "tenant_id": str(tenant_id),
        "source_decision_id": str(source_decision_id),
        "source_revision_id": str(source_revision_id),
        "dependent_node_id": str(dependent_node_id),
        "reason": reason,
    }
    return hashlib.sha256(_canonical_json_bytes(identity)).hexdigest()


async def walk_review_dependents(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    source_decision_id: UUID,
    max_depth: int = 32,
) -> DependencyWalkResult:
    """Walk reverse dependency edges from a falsified source decision."""

    if max_depth < 1:
        raise ReviewFlagError("dependency_walk_max_depth_invalid")
    rows = cast(
        list[Mapping[str, object]],
        await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: recursive dependency walk is scoped by tenant_id and RLS.
WITH RECURSIVE dependents(node_id, depth, path) AS (
  SELECT e.source_node_id, 1, ARRAY[$2, e.source_node_id]::uuid[]
  FROM edges e
  JOIN nodes n ON n.id = e.source_node_id
  WHERE e.tenant_id = $1
    AND e.target_node_id = $2
    AND e.relationship_type IN ('grounded-by', 'informed-by', 'derived-from')
    AND e.archived_at IS NULL
    AND n.tenant_id = $1
    AND n.archived_at IS NULL
  UNION ALL
  SELECT e.source_node_id, d.depth + 1, d.path || e.source_node_id
  FROM dependents d
  JOIN edges e ON e.target_node_id = d.node_id
  JOIN nodes n ON n.id = e.source_node_id
  WHERE e.tenant_id = $1
    AND e.relationship_type IN ('grounded-by', 'informed-by', 'derived-from')
    AND e.archived_at IS NULL
    AND n.tenant_id = $1
    AND n.archived_at IS NULL
    AND d.depth < $3
    AND NOT e.source_node_id = ANY(d.path)
)
SELECT
  d.node_id,
  bool_or(EXISTS (
    SELECT 1
    FROM edges next_edge
    JOIN nodes next_node ON next_node.id = next_edge.source_node_id
    WHERE d.depth >= $3
      AND next_edge.tenant_id = $1
      AND next_edge.target_node_id = d.node_id
      AND next_edge.relationship_type IN ('grounded-by', 'informed-by', 'derived-from')
      AND next_edge.archived_at IS NULL
      AND next_node.tenant_id = $1
      AND next_node.archived_at IS NULL
      AND NOT next_edge.source_node_id = ANY(d.path)
  )) AS truncated
FROM dependents d
WHERE node_id <> $2
GROUP BY d.node_id
ORDER BY node_id
""",
            tenant_id,
            source_decision_id,
            max_depth,
        ),
    )
    return DependencyWalkResult(
        dependent_node_ids=tuple(cast(UUID, row["node_id"]) for row in rows),
        truncated=any(bool(row["truncated"]) for row in rows),
    )


async def ensure_open_review_flag(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    context_of_validity: ReviewFlagContext,
    dependent_node_id: UUID,
    source_decision_id: UUID,
    source_revision_id: UUID,
    reason: ReviewReason,
    critical_path: bool,
    occurred_at: datetime,
) -> ReviewFlagResult:
    """Create or reuse one open review marker and its dependent edge."""

    try:
        if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
            raise ReviewFlagError("review_flag_transaction_required")
        if context_of_validity.tenant != tenant_id:
            raise ReviewFlagError("review_flag_tenant_context_mismatch")
        occurred_at = _normalize_datetime(occurred_at)
        key = review_flag_key(
            tenant_id=tenant_id,
            source_decision_id=source_decision_id,
            source_revision_id=source_revision_id,
            dependent_node_id=dependent_node_id,
            reason=reason,
        )
        metadata = {
            "shape": "skaldos.review_flag.v1",
            "review_key": key,
            "status": "open",
            "reason": reason,
            "source_decision_id": str(source_decision_id),
            "source_revision_id": str(source_revision_id),
            "dependent_node_id": str(dependent_node_id),
            "critical_path": critical_path,
        }
        row = cast(
            Mapping[str, object] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: review marker insert/select is scoped by tenant and RLS.
WITH review_type AS (
  SELECT id
  FROM ontology_type
  WHERE ontology_version_id = $2
    AND name = 'review-flag'
    AND lifecycle_state = 'active'
),
inserted AS (
  INSERT INTO nodes (
    type_id,
    context_of_validity,
    body,
    summary,
    metadata,
    authored_by_principal_id
  )
  SELECT
    review_type.id,
    $3::jsonb,
    '',
    'Needs review',
    $4::jsonb,
    app.principal_id()
  FROM review_type
  ON CONFLICT DO NOTHING
  RETURNING id, true AS inserted
)
SELECT id, inserted FROM inserted
UNION ALL
SELECT id, false AS inserted
FROM nodes
WHERE tenant_id = $1
  AND metadata ->> 'shape' = 'skaldos.review_flag.v1'
  AND metadata ->> 'review_key' = $5
  AND metadata ->> 'status' = 'open'
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
  AND NOT EXISTS (SELECT 1 FROM inserted)
LIMIT 1
""",
                tenant_id,
                context_of_validity.ontology_version,
                _canonical_json_text(context_of_validity.model_dump(mode="json")),
                _canonical_json_text(metadata),
                key,
            ),
        )
        if row is None:
            raise ReviewFlagError("review_flag_type_or_existing_row_not_visible")
        review_flag_node_id = cast(UUID, row["id"])
        inserted = bool(row["inserted"])
        edge_inserted = await _ensure_review_required_by_edge(
            connection=connection,
            tenant_id=tenant_id,
            dependent_node_id=dependent_node_id,
            review_flag_node_id=review_flag_node_id,
        )
        outbox_event: OutboxInsertResult | None = None
        if inserted:
            outbox_event = await insert_outbox_event(
                connection=connection,
                envelope=OutboxEnvelope(
                    id_as_handle=True,
                    event_type="review.needed",
                    subject_type="review-flag",
                    subject_id=review_flag_node_id,
                    tenant_id=tenant_id,
                    context_of_validity=context_of_validity.to_outbox_context(),
                    occurred_at=occurred_at,
                    intent="directive",
                ),
            )
        return ReviewFlagResult(
            review_flag_node_id=review_flag_node_id,
            inserted=inserted,
            edge_inserted=edge_inserted,
            outbox_event=outbox_event,
        )
    except ReviewFlagError:
        raise
    except Exception as exc:
        raise ReviewFlagError("review_flag_write_failed") from exc


async def evaluate_auto_approve_with_review_state(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    dependent_node_id: UUID,
    critical_path: bool,
) -> ActiveReviewDecision:
    """Return the policy consequence of active review state for a dependent."""

    if not critical_path:
        return "eligible"
    has_active_review = cast(
        bool,
        await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: active review lookup is scoped by tenant and RLS.
SELECT EXISTS (
  SELECT 1
  FROM edges e
  JOIN nodes marker ON marker.id = e.target_node_id
  WHERE e.tenant_id = $1
    AND e.source_node_id = $2
    AND e.relationship_type = 'review-required-by'
    AND e.archived_at IS NULL
    AND marker.tenant_id = $1
    AND marker.metadata ->> 'shape' = 'skaldos.review_flag.v1'
    AND marker.metadata ->> 'status' = 'open'
    AND marker.archived_at IS NULL
    AND marker.superseded_by_node_id IS NULL
)
""",
            tenant_id,
            dependent_node_id,
        ),
    )
    return "requires_review" if has_active_review else "eligible"


async def _ensure_review_required_by_edge(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    dependent_node_id: UUID,
    review_flag_node_id: UUID,
) -> bool:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: review edge insert carries tenant_id; endpoint RLS also applies.
WITH endpoint_classifications AS (
  SELECT
    source.classification AS source_classification,
    target.classification AS target_classification
  FROM nodes source
  JOIN nodes target ON target.id = $3
  WHERE source.id = $2
    AND source.tenant_id = $1
    AND target.tenant_id = $1
),
inserted AS (
  INSERT INTO edges (
    tenant_id,
    source_node_id,
    target_node_id,
    relationship_type,
    classification,
    authored_by_principal_id
  )
  SELECT
    $1,
    $2,
    $3,
    'review-required-by',
    CASE
      WHEN app.classification_rank(source_classification)
           >= app.classification_rank(target_classification)
      THEN source_classification
      ELSE target_classification
    END,
    app.principal_id()
  FROM endpoint_classifications
  ON CONFLICT DO NOTHING
  RETURNING true AS inserted
)
SELECT inserted FROM inserted
UNION ALL
SELECT false AS inserted
FROM edges
WHERE tenant_id = $1
  AND source_node_id = $2
  AND target_node_id = $3
  AND relationship_type = 'review-required-by'
  AND archived_at IS NULL
  AND NOT EXISTS (SELECT 1 FROM inserted)
UNION ALL
SELECT false AS inserted
FROM endpoint_classifications
WHERE NOT EXISTS (SELECT 1 FROM inserted)
  AND NOT EXISTS (
    SELECT 1
    FROM edges
    WHERE tenant_id = $1
      AND source_node_id = $2
      AND target_node_id = $3
      AND relationship_type = 'review-required-by'
      AND archived_at IS NULL
  )
LIMIT 1
""",
            tenant_id,
            dependent_node_id,
            review_flag_node_id,
        ),
    )
    if row is None:
        raise ReviewFlagError("review_required_by_edge_insert_failed")
    return bool(row["inserted"])


def _normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        raise ReviewFlagError("timestamp_requires_timezone")
    return value.astimezone(UTC).replace(tzinfo=UTC)


def _canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        _normalize_json(value),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _canonical_json_text(value: object) -> str:
    return _canonical_json_bytes(value).decode("utf-8")


def _normalize_json(value: object) -> object:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        return {
            unicodedata.normalize("NFC", str(key)): _normalize_json(child)
            for key, child in mapping.items()
        }
    if isinstance(value, list):
        children = cast(list[object], value)
        return [_normalize_json(child) for child in children]
    return value
