"""Decision revision service for Slice 9 falsification flows."""

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Annotated, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.events.outbox import OutboxEnvelope, OutboxInsertResult, insert_outbox_event
from skaldos.falsification.review_flags import (
    ReviewFlagContext,
    ReviewFlagResult,
    ensure_open_review_flag,
    evaluate_auto_approve_with_review_state,
    walk_review_dependents,
)
from skaldos.graph.assert_audit import AuditOutcome, emit_assertion_audit_entry
from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal
from skaldos.policy.assertion_authorization import (
    AssertionPolicyDeniedError,
    AssertionPolicyEvaluationError,
    authorize_assertion_intent,
)
from skaldos.policy.intent import Intent
from skaldos.policy.subjects import NodeRow
from skaldos.surprises.stream import (
    SubjectHandle,
    SurpriseContext,
    SurpriseRecordDraft,
    SurpriseRecordResult,
    write_surprise_record,
)

Classification = Literal["C0", "C1", "C2", "C3", "C4"]


class DecisionRevisionError(RuntimeError):
    """Raised when the falsifier revision service rejects or cannot complete."""


class DecisionRevisionContext(BaseModel):
    """Content-free context tuple for the replacement decision assertion."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant: UUID
    classification: Classification
    vertical: Annotated[str, Field(min_length=1, max_length=128)] = "foundation"
    ontology_version: UUID
    valid_from: datetime
    valid_to: datetime | None = None

    @field_validator("valid_from", "valid_to")
    @classmethod
    def _normalize_timestamp(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @model_validator(mode="after")
    def _validity_window_is_ordered(self) -> DecisionRevisionContext:
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError("invalid_validity_window")
        return self

    def to_review_context(self) -> ReviewFlagContext:
        return ReviewFlagContext.model_validate(self.model_dump(mode="python"))

    def to_surprise_context(self) -> SurpriseContext:
        return SurpriseContext.model_validate(self.model_dump(mode="python"))


class DecisionRevisionDraft(BaseModel):
    """Validated request to revise one current Pattern-4 decision."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    source_decision_id: UUID
    revised_body: Annotated[str, Field(min_length=1, max_length=16_384)]
    grounded_by_node_ids: tuple[UUID, ...]
    falsifier_node_id: UUID
    critical_path_dependent_node_ids: tuple[UUID, ...] = ()
    occurred_at: datetime
    surprise_magnitude: Annotated[Decimal, Field(ge=0, le=1)] = Decimal("0.8000")
    dependency_walk_max_depth: Annotated[int, Field(ge=1, le=128)] = 32

    @field_validator("occurred_at")
    @classmethod
    def _normalize_occurred_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)

    @model_validator(mode="after")
    def _revision_edges_are_well_formed(self) -> DecisionRevisionDraft:
        if not self.grounded_by_node_ids:
            raise ValueError("grounded_by_required")
        if len(set(self.grounded_by_node_ids)) != len(self.grounded_by_node_ids):
            raise ValueError("duplicate_grounded_by")
        if self.source_decision_id in self.grounded_by_node_ids:
            raise ValueError("source_decision_cannot_ground_revision")
        if self.falsifier_node_id == self.source_decision_id:
            raise ValueError("source_decision_cannot_be_falsifier")
        return self


@dataclass(frozen=True, slots=True)
class DecisionRevisionResult:
    source_decision_id: UUID
    revision_node_id: UUID
    review_flags: tuple[ReviewFlagResult, ...]
    dependency_walk_truncated: bool
    surprise: SurpriseRecordResult
    decision_events: tuple[OutboxInsertResult, ...]
    auto_approve_events: tuple[OutboxInsertResult, ...]
    replayed: bool = False


def decision_revision_key(draft: DecisionRevisionDraft) -> str:
    """Return the deterministic key for replay-safe revision writes."""

    identity = {
        "tenant_id": str(draft.tenant_id),
        "source_decision_id": str(draft.source_decision_id),
        "revised_body_hash": hashlib.sha256(draft.revised_body.encode("utf-8")).hexdigest(),
        "grounded_by_node_ids": sorted(str(node_id) for node_id in draft.grounded_by_node_ids),
        "falsifier_node_id": str(draft.falsifier_node_id),
        "occurred_at": _canonical_timestamp(draft.occurred_at),
    }
    return hashlib.sha256(_canonical_json_bytes(identity)).hexdigest()


async def revise_with_falsifier(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    draft: DecisionRevisionDraft,
    audit_connection: asyncpg.Connection | None = None,
) -> DecisionRevisionResult:
    """Revise a current Pattern-4 decision and flag affected dependents."""

    async def _revise(bound_connection: asyncpg.Connection) -> DecisionRevisionResult:
        if not bound_connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
            raise DecisionRevisionError("decision_revision_transaction_required")
        key = decision_revision_key(draft)
        source = await _lock_source_decision(
            connection=bound_connection,
            tenant_id=draft.tenant_id,
            source_decision_id=draft.source_decision_id,
        )
        if source is None:
            raise DecisionRevisionError("source_decision_not_visible")
        _validate_source_decision(source)
        evidence = await _validate_revision_evidence(
            connection=bound_connection,
            tenant_id=draft.tenant_id,
            evidence_node_ids=(*draft.grounded_by_node_ids, draft.falsifier_node_id),
        )
        context = _derived_revision_context(
            source=source,
            evidence=evidence,
            occurred_at=draft.occurred_at,
        )
        _ensure_principal_can_write_classification(
            principal=principal,
            tenant_id=draft.tenant_id,
            classification=context.classification,
        )
        await _authorize_and_audit_revision(
            connection=bound_connection,
            audit_connection=audit_connection,
            principal=principal,
            source=source,
            context=context,
        )
        if source.superseded_by_node_id is not None:
            replay = await _load_replay_revision(
                connection=bound_connection,
                tenant_id=draft.tenant_id,
                revision_node_id=source.superseded_by_node_id,
                revision_key=key,
            )
            if replay is None:
                raise DecisionRevisionError("source_decision_stale_current_head")
            return replay
        revision_node_id = await _insert_revision_node(
            connection=bound_connection,
            source=source,
            context=context,
            draft=draft,
            revision_key=key,
            actor_principal_id=principal.id,
        )
        await _insert_revision_edges(
            connection=bound_connection,
            tenant_id=draft.tenant_id,
            revision_node_id=revision_node_id,
            source_decision_id=draft.source_decision_id,
            grounded_by_node_ids=draft.grounded_by_node_ids,
            falsifier_node_id=draft.falsifier_node_id,
            actor_principal_id=principal.id,
        )
        updated = cast(
            bool | None,
            await bound_connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: supersession update is scoped by tenant and source id.
UPDATE nodes
SET superseded_by_node_id = $3
WHERE tenant_id = $1
  AND id = $2
  AND superseded_by_node_id IS NULL
  AND archived_at IS NULL
RETURNING true
""",
                draft.tenant_id,
                draft.source_decision_id,
                revision_node_id,
            ),
        )
        if updated is not True:
            raise DecisionRevisionError("source_decision_supersession_race")

        decision_events = await _emit_decision_events(
            connection=bound_connection,
            tenant_id=draft.tenant_id,
            context=context,
            source_decision_id=draft.source_decision_id,
            revision_node_id=revision_node_id,
            occurred_at=draft.occurred_at,
        )
        surprise = await _record_decision_surprise(
            connection=bound_connection,
            draft=draft,
            context=context,
            revision_node_id=revision_node_id,
        )
        decision_outcome_event = await insert_outbox_event(
            connection=bound_connection,
            envelope=OutboxEnvelope(
                id_as_handle=True,
                event_type="surprise.decision_outcome_mismatch",
                subject_type="surprise",
                subject_id=surprise.id,
                tenant_id=draft.tenant_id,
                context_of_validity=context.to_review_context().to_outbox_context(),
                occurred_at=draft.occurred_at,
                intent="assertive",
            ),
        )
        walk = await walk_review_dependents(
            connection=bound_connection,
            tenant_id=draft.tenant_id,
            source_decision_id=draft.source_decision_id,
            max_depth=draft.dependency_walk_max_depth,
        )
        review_flags: list[ReviewFlagResult] = []
        auto_approve_events: list[OutboxInsertResult] = []
        critical_path_dependents = set(draft.critical_path_dependent_node_ids)
        dependent_classifications = await _load_node_classifications(
            connection=bound_connection,
            tenant_id=draft.tenant_id,
            node_ids=walk.dependent_node_ids,
        )
        for dependent_node_id in walk.dependent_node_ids:
            critical_path = dependent_node_id in critical_path_dependents
            review_context = _derived_review_context(
                context=context,
                dependent_classification=dependent_classifications[dependent_node_id],
            )
            review_flag = await ensure_open_review_flag(
                connection=bound_connection,
                tenant_id=draft.tenant_id,
                context_of_validity=review_context,
                dependent_node_id=dependent_node_id,
                source_decision_id=draft.source_decision_id,
                source_revision_id=revision_node_id,
                reason="upstream_falsified",
                critical_path=critical_path,
                occurred_at=draft.occurred_at,
            )
            review_flags.append(review_flag)
            decision = await evaluate_auto_approve_with_review_state(
                connection=bound_connection,
                tenant_id=draft.tenant_id,
                dependent_node_id=dependent_node_id,
                critical_path=critical_path,
            )
            if decision == "requires_review":
                auto_approve_events.append(
                    await insert_outbox_event(
                        connection=bound_connection,
                        envelope=OutboxEnvelope(
                            id_as_handle=True,
                            event_type="auto_approve.suspended",
                            subject_type="review-flag",
                            subject_id=review_flag.review_flag_node_id,
                            tenant_id=draft.tenant_id,
                            context_of_validity=review_context.to_outbox_context(),
                            occurred_at=draft.occurred_at,
                            intent="directive",
                        ),
                    )
                )

        return DecisionRevisionResult(
            source_decision_id=draft.source_decision_id,
            revision_node_id=revision_node_id,
            review_flags=tuple(review_flags),
            dependency_walk_truncated=walk.truncated,
            surprise=surprise,
            decision_events=(*decision_events, decision_outcome_event),
            auto_approve_events=tuple(auto_approve_events),
        )

    try:
        return await with_principal(principal=principal, connection=connection, fn=_revise)
    except DecisionRevisionError:
        raise
    except Exception as exc:
        raise DecisionRevisionError("decision_revision_write_failed") from exc


@dataclass(frozen=True, slots=True)
class _SourceDecision:
    id: UUID
    tenant_id: UUID
    type_id: UUID
    ontology_version_id: UUID
    classification: Classification
    draft_state: str
    archived_at: datetime | None
    superseded_by_node_id: UUID | None
    authored_by_principal_id: UUID
    created_at: datetime
    type_name: str
    update_pattern: int
    context: DecisionRevisionContext


@dataclass(frozen=True, slots=True)
class _EvidenceNode:
    id: UUID
    classification: Classification


async def _lock_source_decision(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    source_decision_id: UUID,
) -> _SourceDecision | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: source decision lock is scoped by tenant and RLS.
SELECT
  n.id,
  n.tenant_id,
  n.type_id,
  n.ontology_version_id,
  n.classification,
  n.draft_state,
  n.archived_at,
  n.superseded_by_node_id,
  n.authored_by_principal_id,
  n.created_at,
  n.context_of_validity,
  ot.name AS type_name,
  ot.update_pattern
FROM nodes n
JOIN ontology_type ot
  ON ot.id = n.type_id
 AND ot.ontology_version_id = n.ontology_version_id
WHERE n.tenant_id = $1
  AND n.id = $2
FOR UPDATE
""",
            tenant_id,
            source_decision_id,
        ),
    )
    if row is None:
        return None
    return _SourceDecision(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        type_id=cast(UUID, row["type_id"]),
        ontology_version_id=cast(UUID, row["ontology_version_id"]),
        classification=cast(Classification, row["classification"]),
        draft_state=cast(str, row["draft_state"]),
        archived_at=cast(datetime | None, row["archived_at"]),
        superseded_by_node_id=cast(UUID | None, row["superseded_by_node_id"]),
        authored_by_principal_id=cast(UUID, row["authored_by_principal_id"]),
        created_at=cast(datetime, row["created_at"]),
        type_name=cast(str, row["type_name"]),
        update_pattern=cast(int, row["update_pattern"]),
        context=DecisionRevisionContext.model_validate(_json_mapping(row["context_of_validity"])),
    )


def _validate_source_decision(source: _SourceDecision) -> None:
    if source.archived_at is not None:
        raise DecisionRevisionError("source_decision_archived")
    if source.type_name != "decision" or source.update_pattern != 4:
        raise DecisionRevisionError("source_decision_not_pattern4")
    if source.draft_state != "confirmed":
        raise DecisionRevisionError("source_decision_not_confirmed")


async def _authorize_and_audit_revision(
    *,
    connection: asyncpg.Connection,
    audit_connection: asyncpg.Connection | None,
    principal: Principal,
    source: _SourceDecision,
    context: DecisionRevisionContext,
) -> None:
    subject = NodeRow(
        id=source.id,
        organization_id=source.tenant_id,
        type=source.type_name,
        created_by_principal_id=source.authored_by_principal_id,
        created_at=source.created_at,
    )
    try:
        decision = authorize_assertion_intent(
            principal=principal,
            intent=Intent.assertive,
            subject=subject,
        )
    except AssertionPolicyDeniedError as exc:
        await emit_assertion_audit_entry(
            connection=audit_connection or connection,
            policy=exc.decision,
            context_of_validity=context.model_dump(mode="json"),
            outcome=AuditOutcome.DENIED,
            reason_code=exc.decision.reason_code.value if exc.decision.reason_code else None,
        )
        raise DecisionRevisionError("decision_revision_authorization_denied") from exc
    except AssertionPolicyEvaluationError as exc:
        await emit_assertion_audit_entry(
            connection=audit_connection or connection,
            policy=exc.metadata,
            context_of_validity=context.model_dump(mode="json"),
            outcome=AuditOutcome.ERROR,
            reason_code=exc.metadata.reason_code.value,
        )
        raise DecisionRevisionError("decision_revision_authorization_error") from exc

    await emit_assertion_audit_entry(
        connection=connection,
        policy=decision,
        context_of_validity=context.model_dump(mode="json"),
        outcome=AuditOutcome.PERMITTED,
    )


async def _load_replay_revision(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    revision_node_id: UUID,
    revision_key: str,
) -> DecisionRevisionResult | None:
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: replay lookup is scoped by tenant and revision handle.
SELECT id, metadata
FROM nodes
WHERE tenant_id = $1
  AND id = $2
  AND metadata ->> 'shape' = 'skaldos.decision_revision.v1'
  AND metadata ->> 'revision_key' = $3
  AND archived_at IS NULL
""",
            tenant_id,
            revision_node_id,
            revision_key,
        ),
    )
    if row is None:
        return None
    metadata = _json_mapping(row["metadata"])
    source_decision_id = UUID(cast(str, metadata["source_decision_id"]))
    surprise_id = UUID(cast(str, metadata["raw_surprise_id"]))
    return DecisionRevisionResult(
        source_decision_id=source_decision_id,
        revision_node_id=cast(UUID, row["id"]),
        review_flags=(),
        dependency_walk_truncated=False,
        surprise=SurpriseRecordResult(
            id=surprise_id,
            inserted=False,
            materialized_node_id=None,
            outbox_event=None,
        ),
        decision_events=(),
        auto_approve_events=(),
        replayed=True,
    )


async def _validate_revision_evidence(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    evidence_node_ids: Sequence[UUID],
) -> tuple[_EvidenceNode, ...]:
    rows = cast(
        Sequence[Mapping[str, object]],
        await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: evidence validation is scoped by tenant and RLS.
SELECT id, classification
FROM nodes
WHERE tenant_id = $1
  AND id = ANY($2::uuid[])
  AND archived_at IS NULL
  AND superseded_by_node_id IS NULL
""",
            tenant_id,
            list(evidence_node_ids),
        ),
    )
    if {cast(UUID, row["id"]) for row in rows} != set(evidence_node_ids):
        raise DecisionRevisionError("revision_evidence_not_visible")
    return tuple(
        _EvidenceNode(
            id=cast(UUID, row["id"]),
            classification=cast(Classification, row["classification"]),
        )
        for row in rows
    )


def _derived_revision_context(
    *,
    source: _SourceDecision,
    evidence: Sequence[_EvidenceNode],
    occurred_at: datetime,
) -> DecisionRevisionContext:
    return source.context.model_copy(
        update={
            "classification": _max_classification(
                (source.classification, *(node.classification for node in evidence))
            ),
            "valid_from": occurred_at,
        }
    )


def _derived_review_context(
    *,
    context: DecisionRevisionContext,
    dependent_classification: Classification,
) -> ReviewFlagContext:
    return ReviewFlagContext.model_validate(
        context.model_copy(
            update={
                "classification": _max_classification(
                    (context.classification, dependent_classification)
                )
            }
        ).model_dump(mode="python")
    )


def _ensure_principal_can_write_classification(
    *,
    principal: Principal,
    tenant_id: UUID,
    classification: Classification,
) -> None:
    clearance = _principal_clearance_for_tenant(principal=principal, tenant_id=tenant_id)
    if _classification_rank(classification) > _classification_rank(clearance):
        raise DecisionRevisionError("classification_clearance_insufficient")


def _principal_clearance_for_tenant(
    *,
    principal: Principal,
    tenant_id: UUID,
) -> Classification:
    for assigned_tenant_id, clearance in principal.clearance_assignments:
        if assigned_tenant_id == tenant_id:
            return clearance
    return principal.clearance


async def _insert_revision_node(
    *,
    connection: asyncpg.Connection,
    source: _SourceDecision,
    context: DecisionRevisionContext,
    draft: DecisionRevisionDraft,
    revision_key: str,
    actor_principal_id: UUID,
) -> UUID:
    metadata = {
        "shape": "skaldos.decision_revision.v1",
        "revision_key": revision_key,
        "source_decision_id": str(draft.source_decision_id),
        "falsifier_node_id": str(draft.falsifier_node_id),
        "grounded_by_node_ids": [str(node_id) for node_id in draft.grounded_by_node_ids],
    }
    row = cast(
        Mapping[str, object] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
INSERT INTO nodes (
  type_id,
  context_of_validity,
  body,
  summary,
  metadata,
  authored_by_principal_id,
  draft_state
)
VALUES ($1, $2::jsonb, $3, 'Decision revision', $4::jsonb, $5, 'confirmed')
RETURNING id
""",
            source.type_id,
            _canonical_json_text(context.model_dump(mode="json")),
            draft.revised_body,
            _canonical_json_text(metadata),
            actor_principal_id,
        ),
    )
    if row is None:
        raise DecisionRevisionError("revision_node_insert_failed")
    return cast(UUID, row["id"])


async def _insert_revision_edges(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    revision_node_id: UUID,
    source_decision_id: UUID,
    grounded_by_node_ids: Sequence[UUID],
    falsifier_node_id: UUID,
    actor_principal_id: UUID,
) -> None:
    edge_specs = [
        (revision_node_id, source_decision_id, "revises"),
        *((revision_node_id, node_id, "grounded-by") for node_id in grounded_by_node_ids),
        (revision_node_id, falsifier_node_id, "falsified-by"),
    ]
    await connection.executemany(  # pyright: ignore[reportUnknownMemberType]
        """
-- tenant_filter_required: edge insert carries tenant_id and endpoint RLS applies.
WITH endpoint_classifications AS (
  SELECT
    source.classification AS source_classification,
    target.classification AS target_classification
  FROM nodes source
  JOIN nodes target ON target.id = $3
  WHERE source.id = $2
    AND source.tenant_id = $1
    AND target.tenant_id = $1
)
INSERT INTO edges (
  tenant_id,
  source_node_id,
  target_node_id,
  relationship_type,
  classification,
  authored_by_principal_id
)
SELECT
  $1,
  $2,
  $3,
  $4,
  CASE
    WHEN app.classification_rank(source_classification)
         >= app.classification_rank(target_classification)
    THEN source_classification
    ELSE target_classification
  END,
  $5
FROM endpoint_classifications
""",
        [
            (tenant_id, source_node_id, target_node_id, relationship_type, actor_principal_id)
            for source_node_id, target_node_id, relationship_type in edge_specs
        ],
    )


async def _emit_decision_events(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    context: DecisionRevisionContext,
    source_decision_id: UUID,
    revision_node_id: UUID,
    occurred_at: datetime,
) -> tuple[OutboxInsertResult, OutboxInsertResult]:
    outbox_context = context.to_review_context().to_outbox_context()
    revised = await insert_outbox_event(
        connection=connection,
        envelope=OutboxEnvelope(
            id_as_handle=True,
            event_type="decision.revised",
            subject_type="node",
            subject_id=revision_node_id,
            tenant_id=tenant_id,
            context_of_validity=outbox_context,
            occurred_at=occurred_at,
            intent="declarative",
        ),
    )
    falsified = await insert_outbox_event(
        connection=connection,
        envelope=OutboxEnvelope(
            id_as_handle=True,
            event_type="decision.falsified",
            subject_type="node",
            subject_id=source_decision_id,
            tenant_id=tenant_id,
            context_of_validity=outbox_context,
            occurred_at=occurred_at,
            intent="assertive",
        ),
    )
    return revised, falsified


async def _record_decision_surprise(
    *,
    connection: asyncpg.Connection,
    draft: DecisionRevisionDraft,
    context: DecisionRevisionContext,
    revision_node_id: UUID,
) -> SurpriseRecordResult:
    surprise = await write_surprise_record(
        connection=connection,
        draft=SurpriseRecordDraft(
            tenant_id=draft.tenant_id,
            context_of_validity=context.to_surprise_context(),
            prediction=SubjectHandle(
                subject_type="node",
                subject_id=draft.source_decision_id,
            ),
            observation=SubjectHandle(
                subject_type="node",
                subject_id=revision_node_id,
            ),
            comparator_kind="decision_outcome_mismatch",
            magnitude=draft.surprise_magnitude,
            loop_level="double",
            materialization_reason="review_critical",
            occurred_at=draft.occurred_at,
        ),
    )
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        """
UPDATE nodes
SET metadata = metadata || jsonb_build_object('raw_surprise_id', $2::text)
WHERE id = $1
""",
        revision_node_id,
        str(surprise.id),
    )
    return surprise


async def _load_node_classifications(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    node_ids: Sequence[UUID],
) -> dict[UUID, Classification]:
    if not node_ids:
        return {}
    rows = cast(
        Sequence[Mapping[str, object]],
        await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: dependent classification lookup is scoped by tenant and RLS.
SELECT id, classification
FROM nodes
WHERE tenant_id = $1
  AND id = ANY($2::uuid[])
  AND archived_at IS NULL
""",
            tenant_id,
            list(node_ids),
        ),
    )
    classifications: dict[UUID, Classification] = {
        cast(UUID, row["id"]): cast(Classification, row["classification"]) for row in rows
    }
    if set(classifications) != set(node_ids):
        raise DecisionRevisionError("dependent_node_not_visible")
    return classifications


def _canonical_timestamp(value: datetime) -> str:
    return value.astimezone(UTC).replace(tzinfo=UTC).isoformat().replace("+00:00", "Z")


def _max_classification(values: Sequence[Classification]) -> Classification:
    if not values:
        raise DecisionRevisionError("classification_sources_required")
    return max(values, key=_classification_rank)


def _classification_rank(value: Classification) -> int:
    try:
        return ("C0", "C1", "C2", "C3", "C4").index(value)
    except ValueError as exc:
        raise DecisionRevisionError("classification_invalid") from exc


def _json_mapping(value: object) -> Mapping[str, object]:
    if isinstance(value, Mapping):
        return cast(Mapping[str, object], value)
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, Mapping):
            return cast(Mapping[str, object], parsed)
    raise DecisionRevisionError("jsonb_mapping_invalid")


def _canonical_json_bytes(value: object) -> bytes:
    return _canonical_json_text(value).encode("utf-8")


def _canonical_json_text(value: object) -> str:
    return json.dumps(
        _normalize_json(value),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _normalize_json(value: object) -> object:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, datetime):
        return _canonical_timestamp(value)
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        return {
            unicodedata.normalize("NFC", str(key)): _normalize_json(mapping[key])
            for key in sorted(mapping.keys(), key=str)
        }
    if isinstance(value, Sequence) and not isinstance(value, str):
        sequence = cast(Sequence[object], value)
        return [_normalize_json(child) for child in sequence]
    return value
