"""Provider-free Slice 7 agent runtime contracts.

These DTOs are deliberately small Wave 0 contracts. They do not start DBOS,
spawn a sandbox, or select a provider route; they pin the data shapes later
services use so Pi remains a harness/runtime and Shield remains the model
policy boundary.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Any, Literal, cast
from uuid import UUID, uuid4

from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos_shield.contracts import RouteCapability, SensitivityTier

type JsonScalar = str | int | float | bool | None
type JsonValue = JsonScalar | dict[str, "JsonValue"] | list["JsonValue"]

_FORBIDDEN_PAYLOAD_KEYS = frozenset(
    {
        "api_key",
        "apikey",
        "authorization",
        "base_url",
        "content",
        "credentials",
        "env",
        "messages",
        "model_output",
        "model_response",
        "openai_api_key",
        "persona",
        "prompt",
        "provider_payload",
        "raw_model_response",
        "raw_prompt",
        "reasoning",
        "response",
        "response_text",
        "sandbox_env",
        "secret",
        "source_body",
        "stderr",
        "stdout",
        "token",
    }
)
_ALLOWED_HANDLE_KEYS = frozenset({"provider_secret_ref", "credential_ref", "credential_scope"})
_PROVIDER_HOST_HINTS = tuple(f"api.{provider}.com" for provider in ("openai", "anthropic")) + (
    ".".join(("api", "mistral", "ai")),
    ".".join(("openrouter", "ai")),
)
_PROVIDER_KEY_PREFIXES = ("sk-", "sk-ant-", "or-")


class AgentRunStatus(StrEnum):
    """Canonical row status vocabulary for Slice 7 AgentRun projections."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentTriggerKind(StrEnum):
    """Agent invocation source vocabulary."""

    SYNC = "sync"
    EVENT = "event"


class SandboxLifecycleKind(StrEnum):
    """Provider-neutral sandbox lifecycle event vocabulary."""

    STARTED = "started"
    ENDED = "ended"
    ERRORED = "errored"
    CANCELLED = "cancelled"


Clearance = Literal["C0", "C1", "C2", "C3", "C4"]


class ToolSecretEnvMapping(BaseModel):
    """Declared tool/integration secret injection mapping.

    Model-provider credentials are not tool secrets. The explicit provider
    env-name denial is defense in depth for Slice 7 launch validation.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    secret_name: Annotated[str, Field(min_length=1, max_length=128)]
    env_var: Annotated[str, Field(pattern=r"^[A-Z][A-Z0-9_]*$", min_length=1, max_length=128)]

    @field_validator("secret_name", "env_var")
    @classmethod
    def _reject_provider_credential_names(cls, value: str) -> str:
        normalized = value.lower()
        if any(term in normalized for term in ("openai", "anthropic", "openrouter")):
            raise ValueError("model_provider_credential_not_tool_secret")
        if normalized in {"api_key", "provider_api_key", "model_api_key"}:
            raise ValueError("model_provider_credential_not_tool_secret")
        return value


class ModelRouteSnapshot(BaseModel):
    """Safe model-route facts copied onto AgentRun before sandbox spawn."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    snapshot_version: Literal[1] = 1
    route_id: UUID
    provider: Annotated[str, Field(min_length=1, max_length=64)]
    model_id: Annotated[str, Field(min_length=1, max_length=256)]
    provider_secret_ref: Annotated[str, Field(min_length=1, max_length=256)]
    credential_scope: Literal["org", "user"]
    sensitivity_tier: SensitivityTier
    capability: RouteCapability
    fallback_policy: dict[str, JsonValue] = Field(default_factory=dict)
    budget_policy: dict[str, JsonValue] = Field(default_factory=dict)
    latency_policy: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("provider", "model_id", "provider_secret_ref")
    @classmethod
    def _reject_plaintext_key_values(cls, value: str) -> str:
        _raise_if_plaintext_credential(value)
        return value

    @model_validator(mode="after")
    def _policies_are_content_free(self) -> ModelRouteSnapshot:
        _raise_if_forbidden_payload(self.model_dump(mode="json"))
        return self


class PiLaunchEnvelope(BaseModel):
    """Typed Hall-to-Pi launch envelope.

    The envelope carries only agent identity, pinned template, Shield-safe
    route metadata, declared tool-secret mappings, and first-party endpoints.
    Provider SDK config, provider URLs, and plaintext model credentials are
    rejected by `extra="forbid"` and the content-free validator.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    protocol_version: Literal["skaldos.pi.launch.v1"] = "skaldos.pi.launch.v1"
    harness: Literal["pi"] = "pi"
    agent_run_id: UUID
    tenant_id: UUID
    effective_principal_id: UUID
    org_agent_type_id: UUID
    template_version_id: UUID
    trigger_kind: AgentTriggerKind = AgentTriggerKind.SYNC
    effective_clearance: Clearance
    api_base_url: AnyHttpUrl
    shield_base_url: AnyHttpUrl
    model_route_snapshot: ModelRouteSnapshot
    redaction_session_id: UUID | None = None
    required_secrets: tuple[str, ...] = ()
    secret_env_mapping: tuple[ToolSecretEnvMapping, ...] = ()
    tool_manifest: dict[str, JsonValue] = Field(default_factory=dict)
    timeout_seconds: Annotated[int, Field(gt=0, le=3600)] = 300

    @model_validator(mode="after")
    def _launch_payload_is_content_free(self) -> PiLaunchEnvelope:
        _raise_if_forbidden_payload(self.model_dump(mode="json"))
        return self


class PiEventKind(StrEnum):
    """Versioned Pi runtime event vocabulary consumed by Hall."""

    RUNTIME_READY = "runtime.ready"
    RUNTIME_ERROR = "runtime.error"
    RUNTIME_COMPLETED = "runtime.completed"
    TOOL_STARTED = "tool.started"
    TOOL_COMPLETED = "tool.completed"
    TOOL_FAILED = "tool.failed"
    LLM_REQUESTED = "llm.requested"
    LLM_COMPLETED = "llm.completed"
    LLM_FAILED = "llm.failed"
    DECISION_RECORDED = "decision.recorded"
    VERIFIER_STARTED = "verifier.started"
    VERIFIER_VERDICT = "verifier.verdict"
    LOG_STDOUT = "log.stdout"
    LOG_STDERR = "log.stderr"


class PiRuntimeEvent(BaseModel):
    """Content-free event emitted by the Pi runtime protocol."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    protocol_version: Literal["skaldos.pi.event.v1"] = "skaldos.pi.event.v1"
    kind: PiEventKind
    event_id: UUID
    agent_run_id: UUID
    sequence: Annotated[int, Field(ge=0)]
    runtime_timestamp: datetime
    trace_id: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    span_id: Annotated[str, Field(min_length=1, max_length=64)] | None = None
    tool_call_id: UUID | None = None
    shield_call_id: UUID | None = None
    payload: dict[str, JsonValue] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _event_payload_is_content_free(self) -> PiRuntimeEvent:
        _raise_if_forbidden_payload(self.payload)
        return self


class SyncAgentTriggerRef(BaseModel):
    """Allowlisted content-free launch correlation handles."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    source_ref: Annotated[str, Field(min_length=1, max_length=256)] | None = None
    correlation_id: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    idempotency_key: Annotated[str, Field(min_length=1, max_length=128)] | None = None

    @model_validator(mode="after")
    def _trigger_ref_is_content_free(self) -> SyncAgentTriggerRef:
        _raise_if_forbidden_payload(self.model_dump(mode="json"))
        return self


class EventAgentTriggerRef(BaseModel):
    """Content-free event launch correlation handles."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id_hash: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    outbox_event_id: UUID
    event_type: Annotated[str, Field(min_length=1, max_length=128)]
    subject_type: Annotated[str, Field(min_length=1, max_length=64)]
    subject_id: UUID
    pattern_node_id: UUID
    subscription_source_node_id: UUID
    idempotency_key: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]

    @model_validator(mode="after")
    def _trigger_ref_is_content_free(self) -> EventAgentTriggerRef:
        _raise_if_forbidden_payload(self.model_dump(mode="json"))
        return self


class SyncAgentRunRequest(BaseModel):
    """HTTP contract for sync-only Slice 7 agent launch."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    trigger_kind: AgentTriggerKind = AgentTriggerKind.SYNC
    request_id: UUID = Field(default_factory=uuid4)
    clearance_cap: Clearance | None = None
    trace_id: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    span_id: Annotated[str, Field(min_length=1, max_length=64)] | None = None
    timeout_seconds: Annotated[int, Field(gt=0, le=3600)] = 300
    trigger_ref: SyncAgentTriggerRef = Field(default_factory=SyncAgentTriggerRef)

    @model_validator(mode="after")
    def _request_payload_is_content_free(self) -> SyncAgentRunRequest:
        _raise_if_forbidden_payload(self.model_dump(mode="json"))
        return self


class SyncAgentRunResponse(BaseModel):
    """Content-free response returned after the workflow shell starts."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    agent_run_id: UUID
    status: AgentRunStatus
    dbos_workflow_id: Annotated[str, Field(min_length=1)]
    effective_principal_id: UUID
    effective_clearance: Clearance
    template_version_id: UUID


def _raise_if_plaintext_credential(value: str) -> None:
    lowered = value.lower()
    if any(host in lowered for host in _PROVIDER_HOST_HINTS):
        raise ValueError("provider_url_not_allowed")
    if any(value.startswith(prefix) for prefix in _PROVIDER_KEY_PREFIXES):
        raise ValueError("plaintext_provider_credential_not_allowed")


def _raise_if_forbidden_payload(value: JsonValue | Mapping[str, Any]) -> None:
    def visit(candidate: object, *, key_path: tuple[str, ...]) -> None:
        if isinstance(candidate, dict):
            mapping = cast(Mapping[object, object], candidate)
            for key, nested in mapping.items():
                normalized = str(key).lower()
                if normalized in _FORBIDDEN_PAYLOAD_KEYS and normalized not in _ALLOWED_HANDLE_KEYS:
                    raise ValueError(f"forbidden_content_field:{'.'.join((*key_path, str(key)))}")
                visit(nested, key_path=(*key_path, str(key)))
            return
        if isinstance(candidate, list):
            sequence = cast(Sequence[object], candidate)
            for index, nested in enumerate(sequence):
                visit(nested, key_path=(*key_path, str(index)))
            return
        if isinstance(candidate, str):
            _raise_if_plaintext_credential(candidate)

    visit(value, key_path=())


__all__ = [
    "AgentRunStatus",
    "AgentTriggerKind",
    "Clearance",
    "EventAgentTriggerRef",
    "ModelRouteSnapshot",
    "PiEventKind",
    "PiLaunchEnvelope",
    "PiRuntimeEvent",
    "SyncAgentRunRequest",
    "SyncAgentRunResponse",
    "SyncAgentTriggerRef",
    "ToolSecretEnvMapping",
]
