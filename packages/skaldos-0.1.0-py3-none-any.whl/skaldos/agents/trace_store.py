"""Persistence for Slice 7 execution trace graph artifacts."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Protocol, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.agents.graph_outputs import ValidatedGraphOutputTrace
from skaldos.agents.run_store import AgentRunStore
from skaldos.agents.trace import ExecutionTracePayload
from skaldos.graph import canonical_json_bytes, with_principal
from skaldos.middleware import Principal

_FORBIDDEN_TRACE_TOKENS = frozenset(
    {
        "api_key",
        "apikey",
        "authorization",
        "base_url",
        "content",
        "credentials",
        "env",
        "messages",
        "model_output",
        "model_response",
        "openai_api_key",
        "patient",
        "persona",
        "prompt",
        "provider_payload",
        "raw_model_response",
        "raw_prompt",
        "reasoning",
        "response",
        "response_text",
        "sandbox_env",
        "secret",
        "source_body",
        "stderr",
        "stdout",
        "token",
    }
)


class ExecutionTracePersistenceError(RuntimeError):
    """Content-free failure for execution trace graph persistence."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True, slots=True)
class ExecutionTraceNodeRecord:
    """Persisted graph node handle for an ExecutionTrace payload."""

    node_id: UUID
    execution_trace_id: UUID
    agent_run_id: UUID
    step_index: int
    authored_by_principal_id: UUID
    ontology_type_id: UUID
    replayed: bool


class ExecutionTraceRunStore(Protocol):
    """Minimal AgentRun lookup dependency for trace persistence."""

    async def get_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
    ) -> object: ...


class ExecutionTraceStore:
    """Write normalized ExecutionTrace payloads as content-free graph nodes."""

    def __init__(self, *, run_store: ExecutionTraceRunStore | None = None) -> None:
        self._run_store = run_store or AgentRunStore()

    async def persist_trace(
        self,
        *,
        principal: Principal,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        trace: ExecutionTracePayload,
        context_of_validity: Mapping[str, Any],
    ) -> ExecutionTraceNodeRecord:
        """Persist one trace node idempotently inside a Principal-bound transaction."""

        return await self._persist_trace(
            principal=principal,
            connection=connection,
            tenant_id=tenant_id,
            trace=trace,
            context_of_validity=context_of_validity,
            output_refs_validated=False,
        )

    async def persist_validated_output_trace(
        self,
        *,
        principal: Principal,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        validated_trace: ValidatedGraphOutputTrace,
        context_of_validity: Mapping[str, Any],
    ) -> ExecutionTraceNodeRecord:
        """Persist a graph-output trace whose refs passed author validation."""

        return await self._persist_trace(
            principal=principal,
            connection=connection,
            tenant_id=tenant_id,
            trace=validated_trace.trace,
            context_of_validity=context_of_validity,
            output_refs_validated=True,
        )

    async def _persist_trace(
        self,
        *,
        principal: Principal,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        trace: ExecutionTracePayload,
        context_of_validity: Mapping[str, Any],
        output_refs_validated: bool,
    ) -> ExecutionTraceNodeRecord:
        _validate_trace_context(context_of_validity, tenant_id=tenant_id)
        _validate_output_refs(trace, output_refs_validated=output_refs_validated)

        async def _persist(bound_connection: asyncpg.Connection) -> ExecutionTraceNodeRecord:
            run = await self._run_store.get_run(
                connection=bound_connection,
                tenant_id=tenant_id,
                agent_run_id=trace.agent_run_id,
            )
            if getattr(run, "effective_principal_id", None) != principal.id:
                raise ExecutionTracePersistenceError("execution_trace_principal_mismatch")

            type_id = cast(
                UUID | None,
                await bound_connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                    """
                    SELECT id
                    FROM ontology_type
                    WHERE ontology_version_id =
                          ($1::jsonb ->> 'ontology_version')::uuid
                      AND name = 'execution-trace'
                      AND lifecycle_state = 'active'
                    """,
                    _json(context_of_validity),
                ),
            )
            if type_id is None:
                raise ExecutionTracePersistenceError("execution_trace_type_not_found")

            metadata = _trace_metadata(trace)
            row = cast(
                Mapping[str, Any] | None,
                await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
                    INSERT INTO nodes (
                        id,
                        type_id,
                        context_of_validity,
                        body,
                        summary,
                        metadata,
                        authored_by_principal_id,
                        draft_state
                    )
                    VALUES (
                        $1,
                        $2,
                        $3::jsonb,
                        '',
                        NULL,
                        $4::jsonb,
                        $5,
                        NULL
                    )
                    ON CONFLICT (id) DO NOTHING
                    RETURNING
                        id,
                        type_id,
                        metadata,
                        authored_by_principal_id,
                        false AS replayed
                    """,
                    trace.execution_trace_id,
                    type_id,
                    _json(context_of_validity),
                    _json(metadata),
                    principal.id,
                ),
            )
            if row is None:
                row = await self._load_existing(
                    connection=bound_connection,
                    trace=trace,
                    context_of_validity=context_of_validity,
                    metadata=metadata,
                    principal_id=principal.id,
                    type_id=type_id,
                )
            return _record_from_row(row, trace=trace)

        return await with_principal(principal=principal, connection=connection, fn=_persist)

    async def _load_existing(
        self,
        *,
        connection: asyncpg.Connection,
        trace: ExecutionTracePayload,
        context_of_validity: Mapping[str, Any],
        metadata: Mapping[str, Any],
        principal_id: UUID,
        type_id: UUID,
    ) -> Mapping[str, Any]:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
                SELECT
                    id,
                    type_id,
                    context_of_validity,
                    metadata,
                    authored_by_principal_id,
                    true AS replayed
                FROM nodes
                WHERE id = $1
                """,
                trace.execution_trace_id,
            ),
        )
        if row is None:
            raise ExecutionTracePersistenceError("execution_trace_replay_not_visible")
        if row["type_id"] != type_id:
            raise ExecutionTracePersistenceError("execution_trace_idempotency_mismatch")
        if row["authored_by_principal_id"] != principal_id:
            raise ExecutionTracePersistenceError("execution_trace_idempotency_mismatch")
        if _canonical(_jsonb_mapping(row["context_of_validity"])) != _canonical(
            context_of_validity
        ):
            raise ExecutionTracePersistenceError("execution_trace_idempotency_mismatch")
        if _canonical(_jsonb_mapping(row["metadata"])) != _canonical(metadata):
            raise ExecutionTracePersistenceError("execution_trace_idempotency_mismatch")
        return row


def _record_from_row(
    row: Mapping[str, Any],
    *,
    trace: ExecutionTracePayload,
) -> ExecutionTraceNodeRecord:
    return ExecutionTraceNodeRecord(
        node_id=cast(UUID, row["id"]),
        execution_trace_id=trace.execution_trace_id,
        agent_run_id=trace.agent_run_id,
        step_index=trace.step_index,
        authored_by_principal_id=cast(UUID, row["authored_by_principal_id"]),
        ontology_type_id=cast(UUID, row["type_id"]),
        replayed=cast(bool, row["replayed"]),
    )


def _trace_metadata(trace: ExecutionTracePayload) -> dict[str, Any]:
    payload = trace.model_dump(mode="json")
    _validate_metadata_content_free(payload)
    return {
        "execution_trace": payload,
        "execution_trace_schema": trace.protocol_version,
        "execution_trace_digest": _canonical(payload).hex(),
    }


def _validate_trace_context(
    context_of_validity: Mapping[str, Any],
    *,
    tenant_id: UUID,
) -> None:
    required = {
        "tenant",
        "classification",
        "vertical",
        "ontology_version",
        "valid_from",
        "valid_to",
    }
    if not required.issubset(context_of_validity):
        raise ExecutionTracePersistenceError("execution_trace_context_missing_required_keys")
    if context_of_validity.get("tenant") != str(tenant_id):
        raise ExecutionTracePersistenceError("execution_trace_context_tenant_mismatch")
    if context_of_validity.get("classification") not in {"C0", "C1", "C2", "C3", "C4"}:
        raise ExecutionTracePersistenceError("execution_trace_context_invalid_classification")
    if str(context_of_validity.get("vertical", "")).strip() == "":
        raise ExecutionTracePersistenceError("execution_trace_context_invalid_vertical")


def _validate_output_refs(
    trace: ExecutionTracePayload,
    *,
    output_refs_validated: bool,
) -> None:
    if (trace.output_node_ids or trace.graph_write_ids) and not output_refs_validated:
        raise ExecutionTracePersistenceError("execution_trace_output_refs_unvalidated")


def _validate_metadata_content_free(value: object) -> None:
    if isinstance(value, str):
        lowered = value.lower()
        normalized = lowered.replace("-", "_").replace(".", "_").replace(":", "_")
        tokens = {part for part in normalized.split("_") if part}
        if (
            lowered in _FORBIDDEN_TRACE_TOKENS
            or normalized in _FORBIDDEN_TRACE_TOKENS
            or any(forbidden in normalized for forbidden in _FORBIDDEN_TRACE_TOKENS)
            or tokens & _FORBIDDEN_TRACE_TOKENS
        ):
            raise ExecutionTracePersistenceError("execution_trace_metadata_content_rejected")
        return
    if isinstance(value, Mapping):
        typed_mapping = cast(Mapping[str, Any], value)
        for key, nested in typed_mapping.items():
            _validate_metadata_content_free(str(key))
            _validate_metadata_content_free(nested)
        return
    if isinstance(value, list | tuple):
        typed_sequence = cast(list[Any] | tuple[Any, ...], value)
        for nested in typed_sequence:
            _validate_metadata_content_free(nested)


def _json(value: Mapping[str, Any]) -> str:
    return canonical_json_bytes(value).decode("utf-8")


def _canonical(value: Any) -> bytes:
    return canonical_json_bytes(value)


def _jsonb_mapping(value: object) -> Mapping[str, Any]:
    if isinstance(value, str):
        decoded = json.loads(value)
        if isinstance(decoded, Mapping):
            return cast(Mapping[str, Any], decoded)
    if isinstance(value, Mapping):
        return cast(Mapping[str, Any], value)
    raise ExecutionTracePersistenceError("execution_trace_jsonb_shape_invalid")


__all__ = [
    "ExecutionTraceNodeRecord",
    "ExecutionTracePersistenceError",
    "ExecutionTraceRunStore",
    "ExecutionTraceStore",
]
