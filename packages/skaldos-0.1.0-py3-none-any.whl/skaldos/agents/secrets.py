"""Encrypted agent tool secret resolution for Slice 11."""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator

from skaldos.agents.contracts import Clearance
from skaldos.agents.errors import AgentSecretResolutionError, AgentToolSecretError
from skaldos.kms.protocol import KeyDestroyed, KMSClient

_SECRET_CIPHERTEXT_PREFIX = b"skaldos-agent-secret-aesgcm-v1:"
_AES_GCM_NONCE_BYTES = 12
_AES_256_KEY_BYTES = 32
_PROVIDER_NAME_HINTS = ("openai", "anthropic", "openrouter", "mistral", "provider")
_CLEARANCE_RANK: Mapping[Clearance, int] = {"C0": 0, "C1": 1, "C2": 2, "C3": 3, "C4": 4}


class AgentSecretScope(StrEnum):
    """Agent tool secret ownership scope."""

    ORG = "org"
    USER = "user"


class AgentSecretStatus(StrEnum):
    """Agent tool secret lifecycle status."""

    ACTIVE = "active"
    REVOKED = "revoked"
    DESTROYED = "destroyed"


class AgentSecretEnvelope(BaseModel):
    """Storage facts that bind encrypted secret plaintext to one owner/scope."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    org_agent_type_id: UUID
    secret_name: str = Field(min_length=1, max_length=128)
    scope: AgentSecretScope
    owner_principal_id: UUID | None = None
    encrypted_secret_ciphertext: bytes
    wrapped_dek: bytes
    kms_key_reference: str = Field(min_length=1)
    key_version: str = Field(min_length=1)
    secret_fingerprint: bytes
    status: AgentSecretStatus = AgentSecretStatus.ACTIVE

    @field_validator("secret_name")
    @classmethod
    def _validate_secret_name(cls, value: str) -> str:
        normalized = _normalize_secret_name(value)
        if any(hint in normalized for hint in _PROVIDER_NAME_HINTS):
            raise AgentToolSecretError("model_provider_credential_not_tool_secret")
        return normalized

    @model_validator(mode="after")
    def _validate_scope_owner(self) -> AgentSecretEnvelope:
        if self.scope is AgentSecretScope.ORG and self.owner_principal_id is not None:
            raise AgentSecretResolutionError("agent_secret_org_owner_forbidden")
        if self.scope is AgentSecretScope.USER and self.owner_principal_id is None:
            raise AgentSecretResolutionError("agent_secret_user_owner_required")
        return self

    def aad(self) -> bytes:
        """Stable AAD for local fake-KMS proof and production envelope parity."""

        payload = {
            "tenant_id": str(self.tenant_id),
            "org_agent_type_id": str(self.org_agent_type_id),
            "secret_name": self.secret_name,
            "scope": self.scope.value,
            "owner_principal_id": (
                str(self.owner_principal_id) if self.owner_principal_id is not None else None
            ),
            "key_version": self.key_version,
        }
        return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()


@dataclass(frozen=True, slots=True)
class AgentSecretEncryptedMaterial:
    """Encrypted values safe to persist in ``agent_secrets``."""

    encrypted_secret_ciphertext: bytes
    wrapped_dek: bytes
    secret_fingerprint: bytes


class AgentSecretKMSCodec:
    """Envelope-encrypt/decrypt tool secrets with KMS-wrapped DEKs."""

    def __init__(self, kms_client: KMSClient) -> None:
        self._kms_client = kms_client

    def encrypt(
        self,
        *,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        secret_name: str,
        scope: AgentSecretScope,
        owner_principal_id: UUID | None,
        kms_key_reference: str,
        key_version: str,
        plaintext_secret: SecretStr,
    ) -> AgentSecretEncryptedMaterial:
        plaintext = plaintext_secret.get_secret_value().encode()
        if not plaintext:
            raise AgentSecretResolutionError("agent_secret_plaintext_empty")
        dek = os.urandom(_AES_256_KEY_BYTES)
        try:
            wrapped_dek = self._kms_client.encrypt_dek(kms_key_reference, dek)
        except KeyDestroyed as exc:
            raise AgentSecretResolutionError("agent_secret_key_destroyed") from exc
        except Exception as exc:
            raise AgentSecretResolutionError("agent_secret_kms_unavailable") from exc
        envelope = AgentSecretEnvelope(
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            secret_name=secret_name,
            scope=scope,
            owner_principal_id=owner_principal_id,
            encrypted_secret_ciphertext=b"\x00",
            wrapped_dek=wrapped_dek,
            kms_key_reference=kms_key_reference,
            key_version=key_version,
            secret_fingerprint=hashlib.sha256(plaintext).digest(),
        )
        nonce = os.urandom(_AES_GCM_NONCE_BYTES)
        ciphertext = AESGCM(dek).encrypt(nonce, plaintext, envelope.aad())
        return AgentSecretEncryptedMaterial(
            encrypted_secret_ciphertext=_SECRET_CIPHERTEXT_PREFIX + nonce + ciphertext,
            wrapped_dek=wrapped_dek,
            secret_fingerprint=envelope.secret_fingerprint,
        )

    def decrypt(self, envelope: AgentSecretEnvelope) -> SecretStr:
        if envelope.status is AgentSecretStatus.DESTROYED:
            raise AgentSecretResolutionError("agent_secret_destroyed")
        if envelope.status is not AgentSecretStatus.ACTIVE:
            raise AgentSecretResolutionError("agent_secret_unavailable")
        if not envelope.encrypted_secret_ciphertext.startswith(_SECRET_CIPHERTEXT_PREFIX):
            raise AgentSecretResolutionError("agent_secret_configuration_error")
        payload = envelope.encrypted_secret_ciphertext[len(_SECRET_CIPHERTEXT_PREFIX) :]
        if len(payload) <= _AES_GCM_NONCE_BYTES:
            raise AgentSecretResolutionError("agent_secret_configuration_error")
        try:
            dek = self._kms_client.decrypt_dek(envelope.kms_key_reference, envelope.wrapped_dek)
        except KeyDestroyed as exc:
            raise AgentSecretResolutionError("agent_secret_destroyed") from exc
        except ValueError as exc:
            raise AgentSecretResolutionError("agent_secret_configuration_error") from exc
        except Exception as exc:
            raise AgentSecretResolutionError("agent_secret_kms_unavailable") from exc
        nonce = payload[:_AES_GCM_NONCE_BYTES]
        ciphertext = payload[_AES_GCM_NONCE_BYTES:]
        try:
            plaintext = AESGCM(dek).decrypt(nonce, ciphertext, envelope.aad())
        except InvalidTag as exc:
            raise AgentSecretResolutionError("agent_secret_configuration_error") from exc
        if hashlib.sha256(plaintext).digest() != envelope.secret_fingerprint:
            raise AgentSecretResolutionError("agent_secret_configuration_error")
        return SecretStr(plaintext.decode())


class AgentSecretStore:
    """Resolve declared secrets with user-over-org precedence at fire time."""

    async def resolve_for_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        required_secrets: Sequence[str],
        bound_user_principal_id: UUID | None,
        run_effective_clearance: Clearance,
        codec: AgentSecretKMSCodec,
    ) -> dict[str, SecretStr]:
        required = tuple(_normalize_secret_name(secret) for secret in required_secrets)
        if not required:
            return {}
        rows = await self._load_rows(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            required_secrets=required,
            bound_user_principal_id=bound_user_principal_id,
            run_effective_clearance=run_effective_clearance,
        )
        selected = _select_effective_rows(rows, required, bound_user_principal_id)
        missing = sorted(set(required).difference(selected))
        if missing:
            raise AgentSecretResolutionError("agent_tool_secret_missing")
        return {name: codec.decrypt(envelope) for name, envelope in selected.items()}

    async def _load_rows(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        required_secrets: Sequence[str],
        bound_user_principal_id: UUID | None,
        run_effective_clearance: Clearance,
    ) -> tuple[AgentSecretEnvelope, ...]:
        _ = _CLEARANCE_RANK[run_effective_clearance]
        rows = cast(
            Sequence[Mapping[str, Any]],
            await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: agent secrets are tenant scoped; RLS also applies.
SELECT s.tenant_id,
       s.org_agent_type_id,
       s.secret_name,
       s.scope,
       s.owner_principal_id,
       s.encrypted_secret_ciphertext,
       s.wrapped_dek,
       s.kms_key_reference,
       s.key_version,
       s.secret_fingerprint,
       s.status
FROM agent_secrets AS s
LEFT JOIN principals AS p
  ON p.id = s.owner_principal_id
LEFT JOIN memberships AS m
  ON m.principal_id = s.owner_principal_id
 AND m.tenant_id = s.tenant_id
 AND m.revoked_at IS NULL
WHERE s.tenant_id = $1
  AND s.org_agent_type_id = $2
  AND s.secret_name = ANY($3::text[])
  AND s.status = 'active'
  AND s.revoked_at IS NULL
  AND s.destroyed_at IS NULL
  AND (
    s.scope = 'org'
    OR (
      s.scope = 'user'
      AND s.owner_principal_id = $4
      AND p.disabled_at IS NULL
      AND m.principal_id IS NOT NULL
      AND app.classification_rank(m.max_clearance) >= app.classification_rank($5)
    )
  )
""",
                tenant_id,
                org_agent_type_id,
                list(required_secrets),
                bound_user_principal_id,
                run_effective_clearance,
            ),
        )
        return tuple(_row_to_envelope(row) for row in rows)


def build_tool_secret_env(
    *,
    required_secrets: Sequence[str],
    env_mapping: Mapping[str, str],
    resolved_secrets: Mapping[str, SecretStr],
) -> dict[str, str]:
    """Materialize sandbox env values after storage/runtime checks pass."""

    env: dict[str, str] = {}
    for secret_name in required_secrets:
        normalized = _normalize_secret_name(secret_name)
        env_var = env_mapping.get(normalized)
        if env_var is None:
            raise AgentToolSecretError("agent_tool_secret_mapping_missing")
        secret = resolved_secrets.get(normalized)
        if secret is None:
            raise AgentSecretResolutionError("agent_tool_secret_missing")
        env[env_var] = secret.get_secret_value()
    return env


def _select_effective_rows(
    rows: Sequence[AgentSecretEnvelope],
    required: Sequence[str],
    bound_user_principal_id: UUID | None,
) -> dict[str, AgentSecretEnvelope]:
    selected: dict[str, AgentSecretEnvelope] = {}
    for name in required:
        user_row = next(
            (
                row
                for row in rows
                if row.secret_name == name
                and row.scope is AgentSecretScope.USER
                and row.owner_principal_id == bound_user_principal_id
            ),
            None,
        )
        if user_row is not None:
            selected[name] = user_row
            continue
        org_row = next(
            (row for row in rows if row.secret_name == name and row.scope is AgentSecretScope.ORG),
            None,
        )
        if org_row is not None:
            selected[name] = org_row
    return selected


def _row_to_envelope(row: Mapping[str, Any]) -> AgentSecretEnvelope:
    return AgentSecretEnvelope(
        tenant_id=cast(UUID, row["tenant_id"]),
        org_agent_type_id=cast(UUID, row["org_agent_type_id"]),
        secret_name=str(row["secret_name"]),
        scope=AgentSecretScope(str(row["scope"])),
        owner_principal_id=cast(UUID | None, row["owner_principal_id"]),
        encrypted_secret_ciphertext=bytes(row["encrypted_secret_ciphertext"]),
        wrapped_dek=bytes(row["wrapped_dek"]),
        kms_key_reference=str(row["kms_key_reference"]),
        key_version=str(row["key_version"]),
        secret_fingerprint=bytes(row["secret_fingerprint"]),
        status=AgentSecretStatus(str(row["status"])),
    )


def _normalize_secret_name(value: str) -> str:
    normalized = value.strip().lower()
    if not normalized or len(normalized) > 128:
        raise AgentToolSecretError("agent_tool_secret_name_invalid")
    if not normalized[0].isalpha():
        raise AgentToolSecretError("agent_tool_secret_name_invalid")
    if any(char not in "abcdefghijklmnopqrstuvwxyz0123456789_" for char in normalized):
        raise AgentToolSecretError("agent_tool_secret_name_invalid")
    return normalized


__all__ = [
    "AgentSecretEncryptedMaterial",
    "AgentSecretEnvelope",
    "AgentSecretKMSCodec",
    "AgentSecretScope",
    "AgentSecretStatus",
    "AgentSecretStore",
    "build_tool_secret_env",
]
