"""Local DBOS replay adapter for Slice 7 agent.run workflows."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos.agents.contracts import AgentRunStatus, JsonValue
from skaldos.agents.errors import AgentWorkflowReplayError
from skaldos.agents.run_store import AgentRunRecord, AgentRunStore
from skaldos.agents.runtime import AgentRunRuntimeService, ReadAndSummarizeRuntimeResult
from skaldos.agents.sync_run import AgentRunWorkflowStart, bind_effective_principal_context
from skaldos.middleware import Principal

_READ_SUMMARIZE_ACTIVITY_KEY = "agent.run.read_and_summarize.v1"
type AgentWorkflowEventType = Literal[
    "workflow.started",
    "activity.started",
    "activity.completed",
    "workflow.replayed",
]
_FORBIDDEN_EVENT_TERMS = (
    "api_key",
    "apikey",
    "authorization",
    "model_response",
    "provider_payload",
    "raw_prompt",
    "raw_response",
    "sandbox_env",
    "secret_value",
    "source_body",
    "stderr",
    "stdout",
    "summary_text",
)


class AgentWorkflowEventRecord(BaseModel):
    """Content-free event-log row returned by the local DBOS adapter."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    workflow_id: str
    agent_run_id: UUID
    event_type: AgentWorkflowEventType
    event_key: str
    payload: dict[str, JsonValue] = Field(default_factory=dict)


class AgentWorkflowReplayResult(BaseModel):
    """Replay or first-execution outcome from the local DBOS adapter."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    agent_run: AgentRunRecord
    workflow_id: str
    activity_key: str
    replayed: bool
    event_payload: dict[str, JsonValue]

    @model_validator(mode="after")
    def _payload_is_content_free(self) -> AgentWorkflowReplayResult:
        _raise_if_unsafe_event_payload(self.event_payload)
        return self


class LocalDBOSAgentWorkflowAdapter:
    """Postgres-backed local adapter for DBOS start and replay semantics.

    This is intentionally smaller than a production DBOS worker. It records the
    durable workflow/activity evidence Slice 7 needs locally, then serves replay
    from that evidence instead of re-running Shield or graph writeback.
    """

    def __init__(self, *, run_store: AgentRunStore | None = None) -> None:
        self._run_store = run_store or AgentRunStore()

    async def start_agent_run(
        self,
        *,
        connection: asyncpg.Connection,
        start: AgentRunWorkflowStart,
    ) -> None:
        """Record the workflow start event idempotently."""

        payload: dict[str, JsonValue] = {
            "schema": "skaldos.agent_workflow.start.v1",
            "agent_run_id": str(start.agent_run_id),
            "harness": start.launch_envelope.harness,
            "template_version_id": str(start.launch_envelope.template_version_id),
            "org_agent_type_id": str(start.launch_envelope.org_agent_type_id),
            "effective_principal_id": str(start.launch_envelope.effective_principal_id),
            "trigger_kind": start.launch_envelope.trigger_kind.value,
            "model_route": {
                "route_id": str(start.launch_envelope.model_route_snapshot.route_id),
                "provider": start.launch_envelope.model_route_snapshot.provider,
                "model_id": start.launch_envelope.model_route_snapshot.model_id,
                "provider_secret_ref": (
                    start.launch_envelope.model_route_snapshot.provider_secret_ref
                ),
                "credential_scope": (start.launch_envelope.model_route_snapshot.credential_scope),
                "sensitivity_tier": str(
                    start.launch_envelope.model_route_snapshot.sensitivity_tier
                ),
                "capability": str(start.launch_envelope.model_route_snapshot.capability),
            },
        }
        await _persist_event_idempotently(
            connection=connection,
            tenant_id=start.tenant_id,
            workflow_id=start.workflow_id,
            agent_run_id=start.agent_run_id,
            event_type="workflow.started",
            event_key="start",
            payload=payload,
        )

    async def run_or_replay_read_and_summarize(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        agent_principal: Principal,
        runtime_service: AgentRunRuntimeService,
    ) -> AgentWorkflowReplayResult:
        """Run the activity once, then replay from the recorded event log."""

        if _connection_in_transaction(connection):
            raise AgentWorkflowReplayError("agent_workflow_transaction_boundary_required")

        async with connection.transaction():  # pyright: ignore[reportUnknownMemberType]
            await _bind_agent_context(connection=connection, principal=agent_principal)
            run = await self._run_store.get_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
            )
        async with connection.transaction():  # pyright: ignore[reportUnknownMemberType]
            await _bind_agent_context(connection=connection, principal=agent_principal)
            completed = await _load_event(
                connection=connection,
                tenant_id=tenant_id,
                workflow_id=run.dbos_workflow_id,
                event_type="activity.completed",
                event_key=_READ_SUMMARIZE_ACTIVITY_KEY,
            )
            if completed is not None:
                await self._record_replay(connection=connection, run=run, completed=completed)
                return AgentWorkflowReplayResult(
                    agent_run=run,
                    workflow_id=run.dbos_workflow_id,
                    activity_key=_READ_SUMMARIZE_ACTIVITY_KEY,
                    replayed=True,
                    event_payload=completed.payload,
                )

            _, started_inserted = await _persist_event_once(
                connection=connection,
                tenant_id=tenant_id,
                workflow_id=run.dbos_workflow_id,
                agent_run_id=agent_run_id,
                event_type="activity.started",
                event_key=_READ_SUMMARIZE_ACTIVITY_KEY,
                payload=_activity_started_payload(run=run),
            )
            if not started_inserted:
                raise AgentWorkflowReplayError("agent_workflow_activity_incomplete")

        async with connection.transaction():  # pyright: ignore[reportUnknownMemberType]
            await _bind_agent_context(connection=connection, principal=agent_principal)
            runtime_result = await runtime_service.run_read_and_summarize(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                agent_principal=agent_principal,
            )

        payload = _activity_payload(runtime_result=runtime_result)
        async with connection.transaction():  # pyright: ignore[reportUnknownMemberType]
            await _bind_agent_context(connection=connection, principal=agent_principal)
            completed = await _persist_event_idempotently(
                connection=connection,
                tenant_id=tenant_id,
                workflow_id=runtime_result.agent_run.dbos_workflow_id,
                agent_run_id=agent_run_id,
                event_type="activity.completed",
                event_key=_READ_SUMMARIZE_ACTIVITY_KEY,
                payload=payload,
            )

        return AgentWorkflowReplayResult(
            agent_run=runtime_result.agent_run,
            workflow_id=runtime_result.agent_run.dbos_workflow_id,
            activity_key=_READ_SUMMARIZE_ACTIVITY_KEY,
            replayed=False,
            event_payload=completed.payload,
        )

    async def replay_read_and_summarize(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
    ) -> AgentWorkflowReplayResult:
        """Replay from durable evidence only; never executes the activity."""

        run = await self._run_store.get_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        completed = await _load_event(
            connection=connection,
            tenant_id=tenant_id,
            workflow_id=run.dbos_workflow_id,
            event_type="activity.completed",
            event_key=_READ_SUMMARIZE_ACTIVITY_KEY,
        )
        if completed is None:
            raise AgentWorkflowReplayError("agent_workflow_replay_event_missing")
        await self._record_replay(connection=connection, run=run, completed=completed)
        return AgentWorkflowReplayResult(
            agent_run=run,
            workflow_id=run.dbos_workflow_id,
            activity_key=_READ_SUMMARIZE_ACTIVITY_KEY,
            replayed=True,
            event_payload=completed.payload,
        )

    async def _record_replay(
        self,
        *,
        connection: asyncpg.Connection,
        run: AgentRunRecord,
        completed: AgentWorkflowEventRecord,
    ) -> None:
        payload: dict[str, JsonValue] = {
            "schema": "skaldos.agent_workflow.replay.v1",
            "agent_run_id": str(run.id),
            "activity_key": completed.event_key,
            "replayed_event_type": completed.event_type,
            "terminal_status": run.status.value,
            "result": _json_safe_result(run.result),
        }
        await _persist_event_idempotently(
            connection=connection,
            tenant_id=run.tenant_id,
            workflow_id=run.dbos_workflow_id,
            agent_run_id=run.id,
            event_type="workflow.replayed",
            event_key=completed.event_key,
            payload=payload,
        )


def _activity_started_payload(*, run: AgentRunRecord) -> dict[str, JsonValue]:
    payload: dict[str, JsonValue] = {
        "schema": "skaldos.agent_workflow.activity_started.v1",
        "activity_key": _READ_SUMMARIZE_ACTIVITY_KEY,
        "agent_run_id": str(run.id),
        "harness": "pi",
        "template_version_id": str(run.template_version_id),
    }
    _raise_if_unsafe_event_payload(payload)
    return payload


def _activity_payload(*, runtime_result: ReadAndSummarizeRuntimeResult) -> dict[str, JsonValue]:
    run = runtime_result.agent_run
    payload: dict[str, JsonValue] = {
        "schema": "skaldos.agent_workflow.activity_result.v1",
        "activity_key": _READ_SUMMARIZE_ACTIVITY_KEY,
        "agent_run_id": str(run.id),
        "harness": "pi",
        "template_version_id": str(run.template_version_id),
        "terminal_status": run.status.value,
        "shield_call_ids": [str(call_id) for call_id in run.shield_call_ids],
        "result": _json_safe_result(run.result),
    }
    _raise_if_unsafe_event_payload(payload)
    if run.status not in {AgentRunStatus.SUCCEEDED, AgentRunStatus.FAILED}:
        raise AgentWorkflowReplayError("agent_workflow_activity_not_terminal")
    return payload


async def _persist_event_idempotently(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    workflow_id: str,
    agent_run_id: UUID,
    event_type: AgentWorkflowEventType,
    event_key: str,
    payload: dict[str, JsonValue],
) -> AgentWorkflowEventRecord:
    record, _inserted = await _persist_event_once(
        connection=connection,
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        agent_run_id=agent_run_id,
        event_type=event_type,
        event_key=event_key,
        payload=payload,
    )
    return record


async def _persist_event_once(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    workflow_id: str,
    agent_run_id: UUID,
    event_type: AgentWorkflowEventType,
    event_key: str,
    payload: dict[str, JsonValue],
) -> tuple[AgentWorkflowEventRecord, bool]:
    _raise_if_unsafe_event_payload(payload)
    payload_json = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    try:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: workflow event insert carries tenant_id; RLS also applies.
INSERT INTO agent_workflow_event_log (
  tenant_id,
  workflow_id,
  agent_run_id,
  event_type,
  event_key,
  payload
)
VALUES ($1, $2, $3, $4, $5, $6::jsonb)
ON CONFLICT (tenant_id, workflow_id, event_type, event_key) DO NOTHING
RETURNING tenant_id, workflow_id, agent_run_id, event_type, event_key, payload
""",
                tenant_id,
                workflow_id,
                agent_run_id,
                event_type,
                event_key,
                payload_json,
            ),
        )
    except Exception as exc:
        raise AgentWorkflowReplayError("agent_workflow_event_persist_failed") from exc
    if row is None:
        existing = await _load_event(
            connection=connection,
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            event_type=event_type,
            event_key=event_key,
        )
        if existing is None:
            raise AgentWorkflowReplayError("agent_workflow_event_missing_after_conflict")
        if _canonical_json(existing.payload) != _canonical_json(payload):
            raise AgentWorkflowReplayError("agent_workflow_event_payload_mismatch")
        return existing, False
    return _event_from_row(row), True


async def _bind_agent_context(*, connection: asyncpg.Connection, principal: Principal) -> None:
    await bind_effective_principal_context(
        connection=connection,
        principal_id=principal.id,
        visible_tenant_ids=principal.visible_tenant_ids,
        clearance=principal.clearance,
    )


def _connection_in_transaction(connection: asyncpg.Connection) -> bool:
    is_in_transaction = getattr(connection, "is_in_transaction", None)
    if not callable(is_in_transaction):
        return False
    return bool(is_in_transaction())


async def _load_event(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    workflow_id: str,
    event_type: AgentWorkflowEventType,
    event_key: str,
) -> AgentWorkflowEventRecord | None:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: workflow event lookup is tenant scoped; RLS also applies.
SELECT tenant_id, workflow_id, agent_run_id, event_type, event_key, payload
FROM agent_workflow_event_log
WHERE tenant_id = $1
  AND workflow_id = $2
  AND event_type = $3
  AND event_key = $4
""",
            tenant_id,
            workflow_id,
            event_type,
            event_key,
        ),
    )
    if row is None:
        return None
    return _event_from_row(row)


def _event_from_row(row: Mapping[str, Any]) -> AgentWorkflowEventRecord:
    return AgentWorkflowEventRecord(
        tenant_id=cast(UUID, row["tenant_id"]),
        workflow_id=str(row["workflow_id"]),
        agent_run_id=cast(UUID, row["agent_run_id"]),
        event_type=cast(
            AgentWorkflowEventType,
            str(row["event_type"]),
        ),
        event_key=str(row["event_key"]),
        payload=_json_dict(row["payload"]),
    )


def _json_dict(value: object) -> dict[str, JsonValue]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, JsonValue], parsed)
        raise AgentWorkflowReplayError("agent_workflow_event_payload_not_object")
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, JsonValue], value))
    raise AgentWorkflowReplayError("agent_workflow_event_payload_not_object")


def _json_safe_result(value: Mapping[str, JsonValue]) -> dict[str, JsonValue]:
    result = dict(value)
    _raise_if_unsafe_event_payload(result)
    return result


def _canonical_json(value: Mapping[str, JsonValue]) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)


def _raise_if_unsafe_event_payload(payload: Mapping[str, object]) -> None:
    lowered = _canonical_json(cast(Mapping[str, JsonValue], payload)).lower()
    if any(term in lowered for term in _FORBIDDEN_EVENT_TERMS):
        raise AgentWorkflowReplayError("agent_workflow_event_payload_not_content_free")


__all__ = [
    "AgentWorkflowEventRecord",
    "AgentWorkflowReplayResult",
    "LocalDBOSAgentWorkflowAdapter",
]
