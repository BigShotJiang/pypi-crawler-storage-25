"""Hall-side Shield evidence ordering helpers for Slice 7."""

from __future__ import annotations

from typing import Protocol
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.agents.logging import AgentExecutionLogContext, emit_shield_evidence_log
from skaldos.agents.run_store import AgentRunStore


class ShieldEvidenceResponse(Protocol):
    """Minimal Shield response surface needed before accepting model output."""

    @property
    def shield_call_id(self) -> UUID:
        """Durable Shield evidence id."""
        ...


async def accept_model_output_after_shield_evidence[T](
    *,
    connection: asyncpg.Connection,
    run_store: AgentRunStore,
    tenant_id: UUID,
    agent_run_id: UUID,
    shield_response: ShieldEvidenceResponse,
    trusted_output: T,
    log_context: AgentExecutionLogContext | None = None,
    tool_call_id: UUID | None = None,
    execution_trace_id: UUID | None = None,
) -> T:
    """Append Shield evidence before exposing trusted model output to Hall/Pi."""

    if log_context is not None:
        _validate_log_context_matches(
            log_context=log_context,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
    await run_store.append_shield_call_id(
        connection=connection,
        tenant_id=tenant_id,
        agent_run_id=agent_run_id,
        shield_call_id=shield_response.shield_call_id,
    )
    if log_context is not None and tool_call_id is not None:
        emit_shield_evidence_log(
            context=log_context,
            shield_call_id=shield_response.shield_call_id,
            tool_call_id=tool_call_id,
            execution_trace_id=execution_trace_id,
        )
    return trusted_output


def _validate_log_context_matches(
    *,
    log_context: AgentExecutionLogContext,
    tenant_id: UUID,
    agent_run_id: UUID,
) -> None:
    if log_context.tenant_id != tenant_id or log_context.agent_run_id != agent_run_id:
        raise ValueError("agent_log_context_mismatch")


__all__ = ["ShieldEvidenceResponse", "accept_model_output_after_shield_evidence"]
