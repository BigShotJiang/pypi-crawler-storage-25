"""Content-free Pi event normalization for Slice 7 execution traces."""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping, Sequence
from enum import StrEnum
from typing import Annotated, Literal, cast
from uuid import NAMESPACE_URL, UUID, uuid5

from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.agents.contracts import JsonValue, PiEventKind, PiRuntimeEvent

_TRACE_NAMESPACE = "skaldos.execution_trace.v1"
_TRACE_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_SPAN_ID_RE = re.compile(r"^[0-9a-f]{16}$")

_SAFE_PAYLOAD_KEYS = frozenset(
    {
        "action_mode",
        "alternatives",
        "confidence",
        "graph_write_ids",
        "input_node_ids",
        "input_trace_ids",
        "output_node_ids",
        "protocol_used",
        "reason_codes",
        "shield_call_ids",
    }
)


class TraceActionMode(StrEnum):
    """Stored action-mode vocabulary from canon §7.5."""

    ACT = "act"
    ANALYZE = "analyze"
    PROBE = "probe"
    STABILIZE = "stabilize"


class TraceProtocol(StrEnum):
    """Stored execution protocol labels for normalized traces."""

    ANALYTICAL = "analytical"
    SENSING = "sensing"
    EXPERT_FAST_PATH = "expert-fast-path"


class ExecutionTracePayload(BaseModel):
    """Content-free normalized trace artifact payload.

    This is the Hall-side shape that can later be persisted as an
    `execution-trace` graph node. It carries handles and safe metadata only:
    no prompts, model responses, provider payloads, sandbox env, or secrets.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    protocol_version: Literal["skaldos.execution_trace.v1"] = "skaldos.execution_trace.v1"
    execution_trace_id: UUID
    agent_run_id: UUID
    pi_event_id: UUID
    step_index: Annotated[int, Field(ge=0)]
    pi_event_kind: PiEventKind
    action_mode: TraceActionMode
    protocol_used: TraceProtocol
    confidence: Annotated[float, Field(ge=0.0, le=1.0)] | None = None
    tool_call_id: UUID | None = None
    shield_call_ids: tuple[UUID, ...] = ()
    input_node_ids: tuple[UUID, ...] = ()
    input_trace_ids: tuple[UUID, ...] = ()
    output_node_ids: tuple[UUID, ...] = ()
    graph_write_ids: tuple[UUID, ...] = ()
    alternatives: tuple[Annotated[str, Field(min_length=1, max_length=64)], ...] = ()
    reason_codes: tuple[Annotated[str, Field(min_length=1, max_length=64)], ...] = ()
    trace_id: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    span_id: Annotated[str, Field(min_length=1, max_length=64)] | None = None

    @field_validator("trace_id")
    @classmethod
    def _trace_id_shape(cls, value: str | None) -> str | None:
        if value is not None and _TRACE_ID_RE.fullmatch(value) is None:
            raise ValueError("trace_id_must_be_lower_hex_32")
        if value == "0" * 32:
            raise ValueError("trace_id_must_not_be_zero")
        return value

    @field_validator("span_id")
    @classmethod
    def _span_id_shape(cls, value: str | None) -> str | None:
        if value is not None and _SPAN_ID_RE.fullmatch(value) is None:
            raise ValueError("span_id_must_be_lower_hex_16")
        if value == "0" * 16:
            raise ValueError("span_id_must_not_be_zero")
        return value

    @field_validator("alternatives", "reason_codes")
    @classmethod
    def _safe_labels(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        for value in values:
            normalized = value.replace("_", "").replace("-", "").replace(".", "").replace(":", "")
            if not normalized.isalnum():
                raise ValueError("trace_label_must_be_safe_token")
        return values


def normalize_pi_runtime_event(
    raw_event: PiRuntimeEvent | Mapping[str, object],
) -> ExecutionTracePayload:
    """Reduce a Pi runtime event into one idempotent ExecutionTrace payload."""

    event = _event_from_raw(raw_event)
    payload = event.payload
    shield_call_ids = _dedupe_uuids(
        [
            *(_uuid_sequence(payload.get("shield_call_ids"))),
            *(() if event.shield_call_id is None else (event.shield_call_id,)),
        ]
    )
    return ExecutionTracePayload(
        execution_trace_id=execution_trace_id_for_event(
            agent_run_id=event.agent_run_id,
            pi_event_id=event.event_id,
        ),
        agent_run_id=event.agent_run_id,
        pi_event_id=event.event_id,
        step_index=event.sequence,
        pi_event_kind=event.kind,
        action_mode=_action_mode(payload.get("action_mode"), event.kind),
        protocol_used=_protocol(payload.get("protocol_used")),
        confidence=_confidence(payload.get("confidence")),
        tool_call_id=event.tool_call_id,
        shield_call_ids=shield_call_ids,
        input_node_ids=_uuid_sequence(payload.get("input_node_ids")),
        input_trace_ids=_uuid_sequence(payload.get("input_trace_ids")),
        output_node_ids=_uuid_sequence(payload.get("output_node_ids")),
        graph_write_ids=_uuid_sequence(payload.get("graph_write_ids")),
        alternatives=_string_sequence(payload.get("alternatives")),
        reason_codes=_string_sequence(payload.get("reason_codes")),
        trace_id=event.trace_id,
        span_id=event.span_id,
    )


def execution_trace_id_for_event(*, agent_run_id: UUID, pi_event_id: UUID) -> UUID:
    """Stable trace id for DBOS retry/replay of the same Pi event."""

    return uuid5(NAMESPACE_URL, f"{_TRACE_NAMESPACE}:{agent_run_id}:{pi_event_id}")


def _event_from_raw(raw_event: PiRuntimeEvent | Mapping[str, object]) -> PiRuntimeEvent:
    if isinstance(raw_event, PiRuntimeEvent):
        return raw_event
    allowed = set(PiRuntimeEvent.model_fields)
    candidate = {key: value for key, value in raw_event.items() if key in allowed}
    candidate["payload"] = _safe_payload(raw_event.get("payload", {}))
    return PiRuntimeEvent.model_validate(candidate)


def _safe_payload(payload: object) -> dict[str, JsonValue]:
    if not isinstance(payload, Mapping):
        return {}
    mapping = cast(Mapping[object, object], payload)
    safe: dict[str, JsonValue] = {}
    for key, value in mapping.items():
        normalized_key = str(key)
        if normalized_key in _SAFE_PAYLOAD_KEYS:
            safe[normalized_key] = cast(JsonValue, value)
    return safe


def _action_mode(value: object, kind: PiEventKind) -> TraceActionMode:
    if isinstance(value, str):
        return TraceActionMode(value)
    if kind in {PiEventKind.TOOL_STARTED, PiEventKind.TOOL_COMPLETED, PiEventKind.TOOL_FAILED}:
        return TraceActionMode.ACT
    if kind in {PiEventKind.VERIFIER_STARTED, PiEventKind.VERIFIER_VERDICT}:
        return TraceActionMode.PROBE
    if kind in {
        PiEventKind.RUNTIME_READY,
        PiEventKind.RUNTIME_ERROR,
        PiEventKind.RUNTIME_COMPLETED,
    }:
        return TraceActionMode.STABILIZE
    return TraceActionMode.ANALYZE


def _protocol(value: object) -> TraceProtocol:
    if isinstance(value, str):
        return TraceProtocol(value)
    return TraceProtocol.ANALYTICAL


def _confidence(value: object) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _uuid_sequence(value: object) -> tuple[UUID, ...]:
    if not isinstance(value, Sequence) or isinstance(value, str):
        return ()
    sequence = cast(Sequence[object], value)
    return tuple(UUID(str(item)) for item in sequence)


def _string_sequence(value: object) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, str):
        return ()
    sequence = cast(Sequence[object], value)
    return tuple(str(item) for item in sequence)


def _dedupe_uuids(values: Iterable[UUID]) -> tuple[UUID, ...]:
    seen: set[UUID] = set()
    ordered: list[UUID] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            ordered.append(value)
    return tuple(ordered)


__all__ = [
    "ExecutionTracePayload",
    "TraceActionMode",
    "TraceProtocol",
    "execution_trace_id_for_event",
    "normalize_pi_runtime_event",
]
