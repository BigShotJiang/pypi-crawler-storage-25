"""Local Slice 7 runtime activity wiring for read-and-summarize@v1."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Literal, cast
from uuid import NAMESPACE_URL, UUID, uuid5

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from opentelemetry import trace
from pydantic import BaseModel, ConfigDict

from skaldos.agents.contracts import AgentRunStatus, Clearance, ModelRouteSnapshot, PiEventKind
from skaldos.agents.errors import AgentRunStorageError, AgentServiceError
from skaldos.agents.graph_outputs import AgentGraphWriteOutput, attach_graph_output_to_trace
from skaldos.agents.model_output import accept_model_output_after_shield_evidence
from skaldos.agents.read_summarize import (
    READ_AND_SUMMARIZE_AGENT_TYPE,
    ReadAndSummarizeAgentFailure,
    ReadAndSummarizeAgentResult,
    ReadAndSummarizeAgentService,
    ReadAndSummarizeFailureReason,
    ReadAndSummarizeGraphAssertClient,
    ReadAndSummarizeRunContext,
    ReadAndSummarizeShieldResult,
    ReadAndSummarizeShieldService,
    ReadAndSummarizeSourceClient,
    ReadAndSummarizeSourceRequest,
    ReadAndSummarizeSourceResult,
    ReadAndSummarizeSourceUnavailable,
    ReadAndSummarizeWritebackService,
)
from skaldos.agents.run_store import AgentRunRecord, AgentRunStore
from skaldos.agents.sync_run import bind_effective_principal_context
from skaldos.agents.trace import ExecutionTracePayload, TraceActionMode, TraceProtocol
from skaldos.agents.trace_evidence import persist_required_trace_or_fail_run
from skaldos.api.graph_assert import GraphAssertRequest, GraphAssertResponse, post_graph_assert
from skaldos.graph.assert_contract import GraphAssertPublicStatus
from skaldos.graph.node_snapshot import (
    NodeSourceSnapshotNotFoundError,
    NodeSourceSnapshotQueryError,
    NodeSourceSnapshotRequest,
    NodeSourceSnapshotService,
)
from skaldos.graph.read_audit import ReadAuditWriteError
from skaldos.middleware import Principal
from skaldos.middleware.hydration import (
    GUC_PRINCIPAL_CONTEXT,
    GUC_PRINCIPAL_ID,
    GUC_PRINCIPAL_VISIBLE,
)
from skaldos.middleware.resolver import format_uuid_array
from skaldos.shield_client import ShieldClient

_RUNTIME_NAMESPACE = "skaldos.slice_7.read_summarize_runtime.v1"
_TRACER = trace.get_tracer(__name__)


class ReadAndSummarizeRuntimeResult(BaseModel):
    """Terminal AgentRun state produced by the local runtime activity."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    agent_run: AgentRunRecord
    vertical_result: ReadAndSummarizeAgentResult


class AgentRunRuntimeService:
    """Run one Slice 7 sync AgentRun through the local synthetic Pi path."""

    def __init__(
        self,
        *,
        run_store: AgentRunStore | None = None,
        source_client: ReadAndSummarizeSourceClient | None = None,
        graph_assert_client: ReadAndSummarizeGraphAssertClient | None = None,
        shield_client: ShieldClient | None = None,
    ) -> None:
        self._run_store = run_store or AgentRunStore()
        self._source_client = source_client
        self._graph_assert_client = graph_assert_client
        self._shield_client = shield_client

    async def run_read_and_summarize(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        agent_principal: Principal,
    ) -> ReadAndSummarizeRuntimeResult:
        """Invoke ``read-and-summarize@v1`` and terminalize the AgentRun."""

        if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
            raise AgentServiceError("agent_runtime_transaction_required")
        run_state = await _load_runtime_state(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        if run_state.agent_type_name != READ_AND_SUMMARIZE_AGENT_TYPE:
            raise AgentServiceError("agent_runtime_unsupported_agent_type")
        if run_state.effective_principal_id != agent_principal.id:
            raise AgentServiceError("agent_runtime_principal_mismatch")

        await bind_effective_principal_context(
            connection=connection,
            principal_id=agent_principal.id,
            visible_tenant_ids=agent_principal.visible_tenant_ids,
            clearance=run_state.effective_clearance,
        )
        await _bind_run_context(
            connection=connection,
            agent_principal=agent_principal,
            run_state=run_state,
        )
        run = await self._run_store.get_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        source_node_id = _source_node_id_from_trigger(run_state.trigger_ref)
        service = self._build_vertical_service(
            connection=connection,
            tenant_id=tenant_id,
            agent_principal=agent_principal,
        )
        context = ReadAndSummarizeRunContext(
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            effective_principal_id=agent_principal.id,
            effective_clearance=run.effective_clearance,
            source_node_id=source_node_id,
            tool_call_id=_stable_uuid(agent_run_id, "tool", source_node_id),
            model_route_snapshot=run_state.model_route_snapshot,
            trace_id=_trace_id(agent_run_id),
            span_id=_span_id(agent_run_id),
            idempotency_key=f"agent-run:{agent_run_id}:read-and-summarize:{source_node_id}",
        )
        with _TRACER.start_as_current_span("agent.run.read_and_summarize"):
            vertical_result = await service.run(context=context)
        terminal_status = (
            AgentRunStatus.SUCCEEDED if vertical_result.kind == "success" else AgentRunStatus.FAILED
        )
        trace = _trace_for_result(context=context, result=vertical_result)
        if vertical_result.kind == "success":
            trace_to_persist = attach_graph_output_to_trace(
                trace=trace,
                graph_output=AgentGraphWriteOutput(
                    graph_write_id=vertical_result.writeback.assertion_id,
                    authored_by_principal_id=agent_principal.id,
                    status=_graph_output_status(vertical_result.writeback.status),
                    output_node_ids=vertical_result.writeback.output_node_ids,
                    grounding_node_ids=(source_node_id,),
                    provenance_role="source",
                ),
                principal=agent_principal,
            )
        else:
            trace_to_persist = trace
        trace_record = await persist_required_trace_or_fail_run(
            principal=agent_principal,
            connection=connection,
            tenant_id=tenant_id,
            trace=trace_to_persist,
            context_of_validity=run_state.context_of_validity,
            run_store=self._run_store,
        )
        terminal_run = await self._run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            status=terminal_status,
            result_json=json.dumps(
                _agent_run_result(
                    vertical_result=vertical_result,
                    execution_trace_id=trace_record.execution_trace_id,
                ),
                separators=(",", ":"),
                sort_keys=True,
            ),
        )
        return ReadAndSummarizeRuntimeResult(
            agent_run=terminal_run,
            vertical_result=vertical_result,
        )

    def _build_vertical_service(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_principal: Principal,
    ) -> ReadAndSummarizeAgentService:
        if self._shield_client is None:
            raise AgentServiceError("agent_runtime_shield_client_required")
        graph_assert_client = self._graph_assert_client or InProcessGraphAssertClient(
            connection=connection,
            principal=agent_principal,
        )
        source_client = self._source_client or NodeSnapshotSourceClient(
            connection=connection,
            principal=agent_principal,
        )
        return ReadAndSummarizeAgentService(
            source_client=source_client,
            shield_service=ReadAndSummarizeShieldService(self._shield_client),
            writeback_service=ReadAndSummarizeWritebackService(graph_assert_client),
            shield_evidence_recorder=AgentRunShieldEvidenceRecorder(
                connection=connection,
                run_store=self._run_store,
                tenant_id=tenant_id,
            ),
        )


class AgentRunShieldEvidenceRecorder:
    """Append ``shield_call_id`` before returning Shield output to the agent."""

    def __init__(
        self,
        *,
        connection: asyncpg.Connection,
        run_store: AgentRunStore,
        tenant_id: UUID,
    ) -> None:
        self._connection = connection
        self._run_store = run_store
        self._tenant_id = tenant_id

    async def accept_shield_result(
        self,
        *,
        context: ReadAndSummarizeRunContext,
        shield_result: ReadAndSummarizeShieldResult,
    ) -> ReadAndSummarizeShieldResult:
        return await accept_model_output_after_shield_evidence(
            connection=self._connection,
            run_store=self._run_store,
            tenant_id=self._tenant_id,
            agent_run_id=context.agent_run_id,
            shield_response=shield_result,
            trusted_output=shield_result,
            tool_call_id=context.tool_call_id,
        )


class NodeSnapshotSourceClient:
    """Source client that uses the protected source-snapshot read service."""

    def __init__(self, *, connection: asyncpg.Connection, principal: Principal) -> None:
        self._connection = connection
        self._principal = principal
        self._service = NodeSourceSnapshotService()

    async def read_source(
        self,
        request: ReadAndSummarizeSourceRequest,
    ) -> ReadAndSummarizeSourceResult:
        try:
            return await self._service.read_snapshot(
                connection=self._connection,
                principal=self._principal,
                request=NodeSourceSnapshotRequest(
                    tenant_id=request.tenant_id,
                    node_id=request.source_node_id,
                    trace_id=request.trace_id,
                ),
            )
        except NodeSourceSnapshotNotFoundError:
            return ReadAndSummarizeSourceUnavailable(
                reason_code=ReadAndSummarizeFailureReason.SOURCE_UNAVAILABLE,
                source_node_id=request.source_node_id,
            )
        except (NodeSourceSnapshotQueryError, ReadAuditWriteError) as exc:
            raise AgentServiceError("agent_runtime_source_snapshot_failed") from exc


class LocalGraphAssertClient:
    """Test/local graph assert client; production HTTP client lands later."""

    def __init__(self, response: GraphAssertResponse) -> None:
        self.response = response
        self.calls: list[tuple[GraphAssertRequest, str]] = []

    async def post_assertion(
        self,
        *,
        request: GraphAssertRequest,
        idempotency_key: str,
    ) -> GraphAssertResponse:
        self.calls.append((request, idempotency_key))
        return self.response


class InProcessGraphAssertClient:
    """Graph assert client that invokes the existing route boundary in-process."""

    def __init__(self, *, connection: asyncpg.Connection, principal: Principal) -> None:
        self._request = _InProcessRequest(connection)
        self._principal = principal

    async def post_assertion(
        self,
        *,
        request: GraphAssertRequest,
        idempotency_key: str,
    ) -> GraphAssertResponse:
        response = await post_graph_assert(
            body=request,
            request=cast(Any, self._request),
            principal=self._principal,
            idempotency_key=idempotency_key,
            _chokepoint_subject=None,
        )
        if isinstance(response, GraphAssertResponse):
            return response
        raise AgentServiceError("agent_runtime_graph_assert_failed")


class _RuntimeState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    agent_run_id: UUID
    agent_type_name: str
    effective_principal_id: UUID
    effective_clearance: Clearance
    trigger_ref: dict[str, Any]
    model_route_snapshot: ModelRouteSnapshot
    context_of_validity: dict[str, Any]


class _InProcessRequest:
    def __init__(self, connection: asyncpg.Connection) -> None:
        self.state = _InProcessRequestState(connection)


class _InProcessRequestState:
    def __init__(self, connection: asyncpg.Connection) -> None:
        self.connection = connection


async def _load_runtime_state(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    agent_run_id: UUID,
) -> _RuntimeState:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: AgentRun runtime lookup is tenant scoped; RLS also applies.
SELECT ar.id,
       ar.tenant_id,
       ar.effective_principal_id,
       ar.effective_clearance,
       ar.trigger_ref,
       ar.model_route_snapshot,
       oat.name AS agent_type_name,
       (
         SELECT jsonb_build_object(
           'tenant', ar.tenant_id::text,
           'classification', ar.effective_clearance::text,
           'vertical', 'foundation',
           'ontology_version', ov.id::text,
           'valid_from', '2026-05-12T00:00:00Z',
           'valid_to', ''
         )
         FROM ontology_version ov
         WHERE ov.version_number = 1
         ORDER BY ov.id
         LIMIT 1
       ) AS context_of_validity
FROM agent_run ar
JOIN org_agent_type oat
  ON oat.id = ar.org_agent_type_id
 AND oat.tenant_id = ar.tenant_id
WHERE ar.id = $1
  AND ar.tenant_id = $2
""",
            agent_run_id,
            tenant_id,
        ),
    )
    if row is None:
        raise AgentRunStorageError("agent_run_not_found")
    return _RuntimeState(
        tenant_id=cast(UUID, row["tenant_id"]),
        agent_run_id=cast(UUID, row["id"]),
        agent_type_name=str(row["agent_type_name"]),
        effective_principal_id=cast(UUID, row["effective_principal_id"]),
        effective_clearance=cast(Clearance, str(row["effective_clearance"])),
        trigger_ref=_json_dict(row["trigger_ref"]),
        model_route_snapshot=ModelRouteSnapshot.model_validate(
            _json_dict(row["model_route_snapshot"])
        ),
        context_of_validity=_json_dict(row["context_of_validity"]),
    )


def _source_node_id_from_trigger(trigger_ref: Mapping[str, Any]) -> UUID:
    raw = trigger_ref.get("trigger_ref", {})
    if not isinstance(raw, Mapping):
        raise AgentServiceError("agent_runtime_source_ref_required")
    trigger_body = cast(Mapping[str, Any], raw)
    source_ref = trigger_body.get("source_ref")
    if not isinstance(source_ref, str):
        raise AgentServiceError("agent_runtime_source_ref_required")
    candidate = source_ref.removeprefix("node:")
    try:
        return UUID(candidate)
    except ValueError as exc:
        raise AgentServiceError("agent_runtime_source_ref_invalid") from exc


async def _bind_run_context(
    *,
    connection: asyncpg.Connection,
    agent_principal: Principal,
    run_state: _RuntimeState,
) -> None:
    context = run_state.context_of_validity
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_ID,
        str(agent_principal.id),
    )
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_VISIBLE,
        format_uuid_array(agent_principal.visible_tenant_ids),
    )
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_CONTEXT,
        json.dumps(
            {
                "tenants": [str(tenant_id) for tenant_id in agent_principal.visible_tenant_ids],
                "classification": run_state.effective_clearance,
                "clearances": {
                    str(tenant_id): run_state.effective_clearance
                    for tenant_id in agent_principal.visible_tenant_ids
                },
                "vertical": context["vertical"],
                "ontology_version": context["ontology_version"],
                "verticals": [context["vertical"]],
                "ontology_versions": [context["ontology_version"]],
            },
            separators=(",", ":"),
        ),
    )


def _trace_for_result(
    *,
    context: ReadAndSummarizeRunContext,
    result: ReadAndSummarizeAgentResult,
) -> ExecutionTracePayload:
    shield_call_ids: tuple[UUID, ...] = (
        (result.shield_call_id,) if result.shield_call_id is not None else ()
    )
    if isinstance(result, ReadAndSummarizeAgentFailure):
        reason_codes = (result.reason_code.value,)
        output_node_ids: tuple[UUID, ...] = ()
        graph_write_ids: tuple[UUID, ...] = ()
    else:
        reason_codes = ("note_asserted",)
        output_node_ids = result.writeback.output_node_ids
        graph_write_ids = (result.writeback.assertion_id,)
    return ExecutionTracePayload(
        execution_trace_id=_stable_uuid(context.agent_run_id, "trace", context.source_node_id),
        agent_run_id=context.agent_run_id,
        pi_event_id=_stable_uuid(context.agent_run_id, "pi-event", context.source_node_id),
        step_index=1,
        pi_event_kind=PiEventKind.TOOL_COMPLETED,
        action_mode=TraceActionMode.ACT,
        protocol_used=TraceProtocol.ANALYTICAL,
        confidence=0.8,
        tool_call_id=context.tool_call_id,
        shield_call_ids=shield_call_ids,
        input_node_ids=(context.source_node_id,),
        output_node_ids=output_node_ids,
        graph_write_ids=graph_write_ids,
        reason_codes=reason_codes,
        trace_id=context.trace_id,
        span_id=context.span_id,
    )


def _agent_run_result(
    *,
    vertical_result: ReadAndSummarizeAgentResult,
    execution_trace_id: UUID,
) -> dict[str, Any]:
    if vertical_result.kind == "failure":
        return {
            "outcome": "failed",
            "reason_code": vertical_result.reason_code.value,
            "source_node_id": str(vertical_result.source_node_id),
            "shield_call_id": (
                str(vertical_result.shield_call_id)
                if vertical_result.shield_call_id is not None
                else None
            ),
            "execution_trace_id": str(execution_trace_id),
        }
    return {
        "outcome": "note_asserted",
        "source_node_id": str(vertical_result.source_node_id),
        "source_version": vertical_result.source_version,
        "source_hash": vertical_result.source_hash,
        "shield_call_id": str(vertical_result.shield_call_id),
        "assertion_id": str(vertical_result.writeback.assertion_id),
        "pending_assertion_id": (
            str(vertical_result.writeback.pending_assertion_id)
            if vertical_result.writeback.pending_assertion_id is not None
            else None
        ),
        "output_node_ids": [str(node_id) for node_id in vertical_result.writeback.output_node_ids],
        "conflict_id": (
            str(vertical_result.writeback.conflict_id)
            if vertical_result.writeback.conflict_id is not None
            else None
        ),
        "writeback_status": vertical_result.writeback.status.value,
        "execution_trace_id": str(execution_trace_id),
    }


def _graph_output_status(status: GraphAssertPublicStatus) -> Literal["staged", "applied"]:
    if status is GraphAssertPublicStatus.APPLIED:
        return "applied"
    return "staged"


def _stable_uuid(agent_run_id: UUID, label: str, source_node_id: UUID) -> UUID:
    return uuid5(NAMESPACE_URL, f"{_RUNTIME_NAMESPACE}:{agent_run_id}:{label}:{source_node_id}")


def _trace_id(agent_run_id: UUID) -> str:
    return _stable_uuid(agent_run_id, "trace-id", agent_run_id).hex


def _span_id(agent_run_id: UUID) -> str:
    return _stable_uuid(agent_run_id, "span-id", agent_run_id).hex[:16]


def _json_dict(value: object) -> dict[str, Any]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, Any], parsed)
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, Any], value))
    raise AgentServiceError("agent_runtime_json_object_required")


__all__ = [
    "AgentRunRuntimeService",
    "AgentRunShieldEvidenceRecorder",
    "InProcessGraphAssertClient",
    "LocalGraphAssertClient",
    "NodeSnapshotSourceClient",
    "ReadAndSummarizeRuntimeResult",
]
