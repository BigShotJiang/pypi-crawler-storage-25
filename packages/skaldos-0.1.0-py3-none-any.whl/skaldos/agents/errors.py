"""Slice 7 agent service error vocabulary."""

from __future__ import annotations


class AgentServiceError(RuntimeError):
    """Base class for content-free agent service failures."""

    code = "agent_service_error"

    def __init__(self, message: str | None = None) -> None:
        super().__init__(message or self.code)


class AgentTypeNotFoundError(AgentServiceError):
    """Agent type row is absent, archived, or invisible under RLS."""

    code = "agent_type_not_found"


class AgentIdentityNotConfiguredError(AgentServiceError):
    """Agent type has no first-class agent Principal configured."""

    code = "agent_identity_not_configured"


class AgentWorkflowStartError(AgentServiceError):
    """Durable workflow start failed or was not configured."""

    code = "agent_workflow_start_failed"


class AgentWorkflowReplayError(AgentServiceError):
    """Durable workflow replay evidence is absent, unsafe, or inconsistent."""

    code = "agent_workflow_replay_failed"


class AgentTemplateNotFoundError(AgentServiceError):
    """Agent type has no current Pi template row."""

    code = "agent_template_not_found"


class AgentRouteNotConfiguredError(AgentServiceError):
    """No model route policy is configured for the agent type or tenant."""

    code = "agent_route_not_configured"


class AgentRouteUnavailableError(AgentServiceError):
    """Configured model route is inactive, revoked, invisible, or unusable."""

    code = "agent_route_unavailable"


class AgentRouteCapabilityError(AgentServiceError):
    """Configured model route does not support Slice 7 agent tool calls."""

    code = "agent_route_missing_agent_tool_capability"


class AgentRunStorageError(AgentServiceError):
    """Unexpected persistence failure while writing AgentRun state."""

    code = "agent_run_storage_error"


class AgentTemplateInvalidError(AgentServiceError):
    """Configured Pi sandbox template is malformed or unsafe to spawn."""

    code = "agent_template_invalid"


class AgentToolSecretError(AgentServiceError):
    """Declared tool secret mapping is missing, duplicated, or provider-shaped."""

    code = "agent_tool_secret_invalid"


class AgentSecretResolutionError(AgentServiceError):
    """Required agent tool secret is absent, unavailable, or undecryptable."""

    code = "agent_tool_secret_unavailable"


class AgentEgressPolicyError(AgentServiceError):
    """Sandbox egress allowlist would widen beyond Slice 7 policy."""

    code = "agent_egress_policy_invalid"


class AgentSandboxLifecycleError(AgentServiceError):
    """Sandbox lifecycle state, handle, or evidence update failed."""

    code = "agent_sandbox_lifecycle_failed"


class AgentSandboxWebhookAuthError(AgentServiceError):
    """Sandbox lifecycle webhook signature or token did not verify."""

    code = "agent_sandbox_webhook_auth_failed"
