"""Safe model-route snapshot construction for Slice 7 agents."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.agents.contracts import ModelRouteSnapshot
from skaldos.agents.errors import (
    AgentRouteCapabilityError,
    AgentRouteNotConfiguredError,
    AgentRouteUnavailableError,
)
from skaldos_shield.contracts import RouteCapability, SensitivityTier


class AgentModelRouteResolver:
    """Resolve an agent's configured Shield route into safe snapshot data."""

    async def resolve_snapshot(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
    ) -> ModelRouteSnapshot:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: scoped by agent type tenant and route tenant; RLS also applies.
WITH selected_route AS (
  SELECT COALESCE(oat.model_policy_id, oac.default_model_route) AS route_id
  FROM org_agent_type oat
  LEFT JOIN org_agent_config oac ON oac.tenant_id = oat.tenant_id
  WHERE oat.id = $1
    AND oat.tenant_id = $2
    AND oat.archived_at IS NULL
)
SELECT r.id,
       r.tenant_id,
       r.sensitivity_tier,
       r.provider,
       r.model_id,
       r.provider_secret_ref,
       r.shield_enabled,
       r.priority,
       r.max_concurrent_calls,
       r.max_streaming_calls,
       r.requests_per_minute,
       r.tokens_per_minute,
       r.burst_limit,
       r.queue_policy,
       r.queue_max_delay_ms,
       r.budget_scope,
       r.supports_agent_tool,
       r.is_active,
       r.created_at,
       r.revoked_at,
       credential.scope AS credential_scope
FROM selected_route sr
JOIN bifrost_provider_route r ON r.id = sr.route_id
JOIN bifrost_route_credentials credential
  ON credential.tenant_id = r.tenant_id
 AND credential.provider_secret_ref = r.provider_secret_ref
 AND credential.provider = r.provider
 AND credential.status = 'active'
 AND credential.revoked_at IS NULL
 AND credential.destroyed_at IS NULL
WHERE sr.route_id IS NOT NULL
""",
                org_agent_type_id,
                tenant_id,
            ),
        )
        if row is None:
            route_configured = cast(
                bool | None,
                await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                    """
-- tenant_filter_required: scoped by agent type tenant; RLS also applies.
SELECT COALESCE(oat.model_policy_id, oac.default_model_route) IS NOT NULL
FROM org_agent_type oat
LEFT JOIN org_agent_config oac ON oac.tenant_id = oat.tenant_id
WHERE oat.id = $1
  AND oat.tenant_id = $2
  AND oat.archived_at IS NULL
""",
                    org_agent_type_id,
                    tenant_id,
                ),
            )
            if route_configured:
                raise AgentRouteUnavailableError()
            raise AgentRouteNotConfiguredError()

        if (
            not bool(row["is_active"])
            or row["revoked_at"] is not None
            or not bool(row["shield_enabled"])
        ):
            raise AgentRouteUnavailableError()
        if not bool(row["supports_agent_tool"]):
            raise AgentRouteCapabilityError()

        return _snapshot_from_route_row(row)


def _snapshot_from_route_row(row: Mapping[str, Any]) -> ModelRouteSnapshot:
    sensitivity_tier = _coerce_sensitivity(row["sensitivity_tier"])
    created_at = row["created_at"]
    if not isinstance(created_at, datetime):
        created_at = datetime.fromisoformat(str(created_at))

    return ModelRouteSnapshot(
        route_id=cast(UUID, row["id"]),
        provider=str(row["provider"]),
        model_id=str(row["model_id"]),
        provider_secret_ref=str(row["provider_secret_ref"]),
        credential_scope=_credential_scope(row["credential_scope"]),
        sensitivity_tier=sensitivity_tier,
        capability=RouteCapability.AGENT_TOOL,
        fallback_policy={
            "priority": cast(int, row["priority"]),
            "route_created_at": created_at.isoformat(),
        },
        budget_policy={
            "budget_scope": str(row["budget_scope"]),
            "max_concurrent_calls": cast(int, row["max_concurrent_calls"]),
            "max_streaming_calls": cast(int, row["max_streaming_calls"]),
            "requests_per_minute": cast(int | None, row["requests_per_minute"]),
            "tokens_per_minute": cast(int | None, row["tokens_per_minute"]),
            "burst_limit": cast(int | None, row["burst_limit"]),
        },
        latency_policy={
            "queue_policy": str(row["queue_policy"]),
            "queue_max_delay_ms": cast(int, row["queue_max_delay_ms"]),
        },
    )


def _coerce_sensitivity(value: object) -> SensitivityTier:
    if isinstance(value, SensitivityTier):
        return value
    if isinstance(value, str):
        return SensitivityTier[value]
    raise AgentRouteUnavailableError("agent_route_sensitivity_unrecognized")


def _credential_scope(value: object) -> Literal["org"]:
    scope = str(value)
    if scope == "org":
        return scope
    if scope == "user":
        raise AgentRouteUnavailableError("agent_route_user_credential_scope_unsupported")
    raise AgentRouteUnavailableError("agent_route_credential_scope_unrecognized")


__all__ = ["AgentModelRouteResolver"]
