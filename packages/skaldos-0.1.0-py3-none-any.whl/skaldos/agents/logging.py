"""Content-free structured log helpers for Slice 7 agent execution."""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator
from skaldos_log import log  # pyright: ignore[reportMissingTypeStubs]

from skaldos.sandbox import ExecResult

_WORKFLOW_ID_RE = re.compile(r"^agent\.run\.[a-z0-9_.-]{1,220}$")


class AgentExecutionLogContext(BaseModel):
    """Opaque correlation handles attached to Pi agent operational logs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    principal_id: UUID
    agent_run_id: UUID
    sandbox_id: UUID
    workflow_id: str = Field(min_length=1)
    template_version: UUID
    harness: Literal["pi"] = "pi"

    @field_validator("workflow_id")
    @classmethod
    def _workflow_id_safe_shape(cls, value: str) -> str:
        if _WORKFLOW_ID_RE.fullmatch(value) is None:
            raise ValueError("agent_log_workflow_id_shape_invalid")
        return value


class SandboxStream(StrEnum):
    """Allowed sandbox stream labels for the log safelist."""

    STDOUT = "stdout"
    STDERR = "stderr"


class SandboxStreamLogSummary(BaseModel):
    """Content-free summary of one captured sandbox stream."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    stream: SandboxStream
    count: int = Field(ge=0)
    emitted: bool


def emit_sandbox_exec_stream_logs(
    *,
    context: AgentExecutionLogContext,
    result: ExecResult,
) -> tuple[SandboxStreamLogSummary, ...]:
    """Emit content-free stdout/stderr capture logs for a sandbox exec result.

    The raw stream text is intentionally not logged. The structured record
    carries only correlation handles, stream name, and a line count so
    operators can query the run without turning logs into prompt/output
    storage.
    """

    summaries = (
        _emit_sandbox_stream_log(
            context=context,
            stream=SandboxStream.STDOUT,
            text=result.stdout,
        ),
        _emit_sandbox_stream_log(
            context=context,
            stream=SandboxStream.STDERR,
            text=result.stderr,
        ),
    )
    return tuple(summary for summary in summaries if summary.emitted)


def emit_shield_evidence_log(
    *,
    context: AgentExecutionLogContext,
    shield_call_id: UUID,
    tool_call_id: UUID,
    execution_trace_id: UUID | None = None,
) -> None:
    """Log that Shield evidence was correlated after AgentRun append."""

    fields: dict[str, object] = {
        **_context_fields(context),
        "event_type": "agent.run.shield_evidence_correlated",
        "shield_call_id": str(shield_call_id),
        "tool_call_id": str(tool_call_id),
        "outcome": "recorded",
    }
    if execution_trace_id is not None:
        fields["execution_trace_id"] = str(execution_trace_id)
    log.info("agent.run.shield_evidence_correlated", **fields)


def emit_trace_persistence_failure_log(
    *,
    context: AgentExecutionLogContext,
    execution_trace_id: UUID,
    reason_code: str,
) -> None:
    """Log required trace persistence failure with safe handles only."""

    log.error(
        "agent.run.trace_persistence_failed",
        **_context_fields(context),
        event_type="agent.run.trace_persistence_failed",
        execution_trace_id=str(execution_trace_id),
        reason_code=reason_code,
        outcome="failed",
    )


def _emit_sandbox_stream_log(
    *,
    context: AgentExecutionLogContext,
    stream: SandboxStream,
    text: str,
) -> SandboxStreamLogSummary:
    line_count = _line_count(text)
    if line_count == 0:
        return SandboxStreamLogSummary(stream=stream, count=0, emitted=False)

    log.info(
        "agent.run.sandbox_stream_captured",
        **_context_fields(context),
        event_type="agent.run.sandbox_stream_captured",
        stream=stream.value,
        count=line_count,
    )
    return SandboxStreamLogSummary(stream=stream, count=line_count, emitted=True)


def _line_count(text: str) -> int:
    if text == "":
        return 0
    return len(text.splitlines()) or 1


def _context_fields(context: AgentExecutionLogContext) -> dict[str, object]:
    return {
        "tenant_id": str(context.tenant_id),
        "principal_id": str(context.principal_id),
        "agent_run_id": str(context.agent_run_id),
        "sandbox_id": str(context.sandbox_id),
        "workflow_id": context.workflow_id,
        "template_version": str(context.template_version),
        "harness": context.harness,
    }


__all__ = [
    "AgentExecutionLogContext",
    "SandboxStream",
    "SandboxStreamLogSummary",
    "emit_sandbox_exec_stream_logs",
    "emit_shield_evidence_log",
    "emit_trace_persistence_failure_log",
]
