"""E2B-backed sandbox lifecycle orchestration for Slice 7 AgentRuns."""

from __future__ import annotations

import asyncio
import json
import os
import secrets
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.agents.contracts import AgentRunStatus, Clearance, JsonValue, ModelRouteSnapshot
from skaldos.agents.errors import (
    AgentSandboxLifecycleError,
    AgentSecretResolutionError,
    AgentTemplateInvalidError,
)
from skaldos.agents.lifecycle import (
    SandboxControlPlane,
    SandboxLifecycleResult,
    SandboxStore,
)
from skaldos.agents.run_store import AgentRunStore
from skaldos.agents.sandbox_plan import SandboxTemplateStore, build_sandbox_spawn_plan
from skaldos.agents.secrets import AgentSecretKMSCodec, AgentSecretStore, build_tool_secret_env
from skaldos.agents.sync_run import load_agent_type_launch_config
from skaldos.sandbox.e2b import E2BConfig, E2BProviderError, E2BSandbox

_DEFAULT_PROBE_DENIED_HOSTS = ("example.com",)
_DEFAULT_EGRESS_PROBE_PATH = "/opt/skaldos/bin/skaldos-egress-probe"
_DEFAULT_READ_SUMMARIZE_COMMAND_PATH = "/opt/skaldos/bin/skaldos-read-and-summarize"
_INLINE_PYTHON_EGRESS_PROBE = "inline-python"
_READ_SUMMARIZE_COMMAND_CONTRACT = "skaldos.read_and_summarize.command.v1"


@dataclass(frozen=True, slots=True)
class E2BPostStartProbeConfig:
    """Opt-in content-free egress probe run before the envd token is dropped."""

    enabled: bool = False
    probe_path: str = _DEFAULT_EGRESS_PROBE_PATH
    denied_hosts: tuple[str, ...] = _DEFAULT_PROBE_DENIED_HOSTS
    timeout_seconds: int = 4

    @classmethod
    def from_env(cls) -> E2BPostStartProbeConfig:
        enabled = os.environ.get("E2B_POST_START_EGRESS_PROBE", "").lower() in {
            "1",
            "true",
            "yes",
        }
        denied_hosts = tuple(
            item.strip()
            for item in os.environ.get(
                "E2B_POST_START_DENIED_HOSTS",
                ",".join(_DEFAULT_PROBE_DENIED_HOSTS),
            ).split(",")
            if item.strip()
        )
        timeout_raw = os.environ.get("E2B_POST_START_PROBE_TIMEOUT_SECONDS", "4")
        try:
            timeout_seconds = int(timeout_raw)
        except ValueError as exc:
            raise AgentSandboxLifecycleError("agent_sandbox_probe_timeout_invalid") from exc
        if timeout_seconds <= 0 or timeout_seconds > 30:
            raise AgentSandboxLifecycleError("agent_sandbox_probe_timeout_invalid")
        return cls(
            enabled=enabled,
            probe_path=os.environ.get("E2B_EGRESS_PROBE_PATH", _DEFAULT_EGRESS_PROBE_PATH),
            denied_hosts=denied_hosts,
            timeout_seconds=timeout_seconds,
        )


@dataclass(frozen=True, slots=True)
class E2BReadSummarizeCommandConfig:
    """Opt-in task command run after sandbox start and egress probe."""

    enabled: bool = False
    command_path: str = _DEFAULT_READ_SUMMARIZE_COMMAND_PATH
    timeout_seconds: int = 120

    @classmethod
    def from_env(cls) -> E2BReadSummarizeCommandConfig:
        enabled = os.environ.get("E2B_RUN_READ_SUMMARIZE_COMMAND", "").lower() in {
            "1",
            "true",
            "yes",
        }
        timeout_raw = os.environ.get("E2B_READ_SUMMARIZE_COMMAND_TIMEOUT_SECONDS", "120")
        try:
            timeout_seconds = int(timeout_raw)
        except ValueError as exc:
            raise AgentSandboxLifecycleError("agent_sandbox_command_timeout_invalid") from exc
        if timeout_seconds <= 0 or timeout_seconds > 600:
            raise AgentSandboxLifecycleError("agent_sandbox_command_timeout_invalid")
        return cls(
            enabled=enabled,
            command_path=os.environ.get(
                "E2B_READ_SUMMARIZE_COMMAND_PATH",
                _DEFAULT_READ_SUMMARIZE_COMMAND_PATH,
            ),
            timeout_seconds=timeout_seconds,
        )


class _ReadSummarizeCommandState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    trigger_ref: dict[str, Any]
    model_route_snapshot: ModelRouteSnapshot


class _ReadSummarizeCommandOutput(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    status: str
    reason_code: str | None = None
    source_node_id: UUID | None = None
    source_version: int | None = None
    source_hash: str | None = None
    shield_call_id: UUID | None = None
    assertion_id: UUID | None = None
    pending_assertion_id: UUID | None = None
    conflict_id: UUID | None = None
    output_node_ids: tuple[UUID, ...] = ()
    writeback_status: str | None = None
    evidence_hash: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.status in {"succeeded", "note_asserted"}

    def result_payload(self) -> dict[str, JsonValue]:
        payload: dict[str, JsonValue] = {"outcome": self.status}
        for key in (
            "reason_code",
            "source_version",
            "source_hash",
            "writeback_status",
            "evidence_hash",
        ):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        for key in (
            "source_node_id",
            "shield_call_id",
            "assertion_id",
            "pending_assertion_id",
            "conflict_id",
        ):
            value = getattr(self, key)
            if value is not None:
                payload[key] = str(value)
        if self.output_node_ids:
            payload["output_node_ids"] = [str(node_id) for node_id in self.output_node_ids]
        return payload


class AgentRunE2BSandboxLaunchService:
    """Start a real E2B sandbox from persisted AgentRun/template state."""

    def __init__(
        self,
        *,
        run_store: AgentRunStore | None = None,
        sandbox_store: SandboxStore | None = None,
        template_store: SandboxTemplateStore | None = None,
        sandbox_factory: type[E2BSandbox] = E2BSandbox,
        config: E2BConfig | None = None,
        control_plane: SandboxControlPlane | None = None,
        post_start_probe: E2BPostStartProbeConfig | None = None,
        read_summarize_command: E2BReadSummarizeCommandConfig | None = None,
        secret_store: AgentSecretStore | None = None,
        secret_codec: AgentSecretKMSCodec | None = None,
    ) -> None:
        self._run_store = run_store or AgentRunStore()
        self._sandbox_store = sandbox_store or SandboxStore()
        self._template_store = template_store or SandboxTemplateStore()
        self._sandbox_factory = sandbox_factory
        self._config = config
        self._control_plane = control_plane
        self._post_start_probe = post_start_probe or E2BPostStartProbeConfig.from_env()
        self._read_summarize_command = (
            read_summarize_command or E2BReadSummarizeCommandConfig.from_env()
        )
        self._secret_store = secret_store or AgentSecretStore()
        self._secret_codec = secret_codec

    async def start_for_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        agent_run_id: UUID,
        api_base_url: str,
        shield_base_url: str,
        agent_bearer_token: str | None = None,
        caller_principal_id: UUID | None = None,
    ) -> SandboxLifecycleResult:
        run = await self._run_store.get_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        if run.org_agent_type_id != org_agent_type_id:
            raise AgentSandboxLifecycleError("agent_run_type_mismatch")
        if run.status is AgentRunStatus.RUNNING and run.sandbox_id is not None:
            sandbox = await self._sandbox_store.load_for_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
            )
            return SandboxLifecycleResult(agent_run=run, sandbox=sandbox, transitioned=False)
        if run.status is not AgentRunStatus.PENDING:
            raise AgentSandboxLifecycleError("agent_run_not_startable")

        agent_type = await load_agent_type_launch_config(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
        )
        template = await self._template_store.current_template_manifest(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
        )
        if template.template_version_id != run.template_version_id:
            raise AgentTemplateInvalidError("agent_template_version_mismatch")
        spawn_plan = build_sandbox_spawn_plan(
            template=template,
            required_secrets=agent_type.required_secrets,
            secret_env_mapping=agent_type.secret_env_mapping,
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
        )
        try:
            tool_secret_env = await self._resolve_tool_secret_env(
                connection=connection,
                tenant_id=tenant_id,
                org_agent_type_id=org_agent_type_id,
                agent_run_id=run.id,
                run_effective_clearance=run.effective_clearance,
                required_secrets=spawn_plan.tool_secret_plan.required_secrets,
                env_mapping=spawn_plan.tool_secret_plan.env_mapping,
                bound_user_principal_id=run.launcher_principal_id,
            )
        except AgentSecretResolutionError as exc:
            await self._terminalize_run_failure(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=run.id,
                reason_code=str(exc),
            )
            raise AgentSandboxLifecycleError(str(exc)) from exc
        webhook_token = secrets.token_urlsafe(32)
        sandbox_record = await self._sandbox_store.create_pending_sandbox(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            spawn_plan=spawn_plan,
            webhook_token=webhook_token,
        )

        provider_handle: str | None = None
        sandbox = self._sandbox_factory(
            config=self._config,
            metadata={
                "skaldos_tenant_id": str(tenant_id),
                "skaldos_agent_run_id": str(agent_run_id),
                "skaldos_webhook_token": webhook_token,
            },
        )
        try:
            await asyncio.to_thread(
                sandbox.start,
                allowlist=spawn_plan.egress_policy.allowed_hosts,
                sandbox_id=str(sandbox_record.id),
            )
            provider_handle = sandbox.provider_handle
            if provider_handle is None:
                raise AgentSandboxLifecycleError("agent_sandbox_provider_handle_missing")
            await self._run_post_start_probe(
                sandbox=sandbox,
                api_base_url=api_base_url,
                shield_base_url=shield_base_url,
            )
            sandbox_record = await self._sandbox_store.persist_provider_handle(
                connection=connection,
                tenant_id=tenant_id,
                sandbox_id=sandbox_record.id,
                provider_handle=provider_handle,
            )
            run = await self._run_store.mark_running(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                sandbox_id=sandbox_record.id,
            )
            command_result = await self._run_read_summarize_command(
                connection=connection,
                run=run,
                sandbox_record=sandbox_record,
                sandbox=sandbox,
                tenant_id=tenant_id,
                api_base_url=api_base_url,
                shield_base_url=shield_base_url,
                agent_bearer_token=agent_bearer_token,
                caller_principal_id=caller_principal_id,
                tool_secret_env=tool_secret_env,
            )
            if command_result is not None:
                run, sandbox_record = command_result
        except AgentSandboxLifecycleError:
            await self._kill_orphan(provider_handle=provider_handle)
            raise
        except E2BProviderError as exc:
            await self._kill_orphan(provider_handle=provider_handle)
            raise AgentSandboxLifecycleError("agent_sandbox_provider_error") from exc
        except Exception as exc:
            await self._kill_orphan(provider_handle=provider_handle)
            raise AgentSandboxLifecycleError("agent_sandbox_start_failed") from exc

        return SandboxLifecycleResult(agent_run=run, sandbox=sandbox_record, transitioned=True)

    async def _resolve_tool_secret_env(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        agent_run_id: UUID,
        run_effective_clearance: Clearance,
        required_secrets: Sequence[str],
        env_mapping: Mapping[str, str],
        bound_user_principal_id: UUID | None,
    ) -> dict[str, str]:
        if not required_secrets:
            return {}
        if self._secret_codec is None:
            await self._terminalize_run_failure(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                reason_code="agent_secret_resolver_unconfigured",
            )
            raise AgentSandboxLifecycleError("agent_secret_resolver_unconfigured")
        resolved = await self._secret_store.resolve_for_run(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            required_secrets=required_secrets,
            bound_user_principal_id=bound_user_principal_id,
            run_effective_clearance=run_effective_clearance,
            codec=self._secret_codec,
        )
        return build_tool_secret_env(
            required_secrets=required_secrets,
            env_mapping=env_mapping,
            resolved_secrets=resolved,
        )

    async def _terminalize_run_failure(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        reason_code: str,
    ) -> None:
        await self._run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            status=AgentRunStatus.FAILED,
            result_json=_safe_result_json({"outcome": "failed", "reason_code": reason_code}),
        )

    async def _run_post_start_probe(
        self,
        *,
        sandbox: E2BSandbox,
        api_base_url: str,
        shield_base_url: str,
    ) -> None:
        probe = self._post_start_probe
        if not probe.enabled:
            return
        command = _egress_probe_command(
            probe_path=probe.probe_path,
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
            denied_hosts=probe.denied_hosts,
            timeout_seconds=probe.timeout_seconds,
        )
        try:
            result = await asyncio.to_thread(sandbox.run, command)
        except E2BProviderError as exc:
            raise AgentSandboxLifecycleError("agent_sandbox_post_start_probe_failed") from exc
        if result.exit_code != 0:
            raise AgentSandboxLifecycleError("agent_sandbox_post_start_probe_failed")

    async def _run_read_summarize_command(
        self,
        *,
        connection: asyncpg.Connection,
        run: Any,
        sandbox_record: Any,
        sandbox: E2BSandbox,
        tenant_id: UUID,
        api_base_url: str,
        shield_base_url: str,
        agent_bearer_token: str | None,
        caller_principal_id: UUID | None,
        tool_secret_env: Mapping[str, str],
    ) -> tuple[Any, Any] | None:
        command = self._read_summarize_command
        if not command.enabled:
            return None
        if caller_principal_id != run.effective_principal_id or not agent_bearer_token:
            raise AgentSandboxLifecycleError("agent_sandbox_agent_token_required")
        state = await _load_read_summarize_command_state(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=run.id,
        )
        source_node_id = _source_node_id_from_trigger(state.trigger_ref)
        env = _read_summarize_command_env(
            tenant_id=tenant_id,
            run=run,
            source_node_id=source_node_id,
            command_state=state,
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
            agent_bearer_token=agent_bearer_token,
            tool_secret_env=tool_secret_env,
        )
        try:
            exec_result = await asyncio.to_thread(
                sandbox.run,
                (command.command_path,),
                env=env,
                timeout_seconds=command.timeout_seconds,
            )
        except E2BProviderError as exc:
            await self._terminalize_command_failure(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=run.id,
                sandbox_id=sandbox_record.id,
                provider_handle=sandbox_record.provider_handle,
                reason_code="agent_sandbox_command_failed",
            )
            raise AgentSandboxLifecycleError("agent_sandbox_command_failed") from exc

        try:
            output = _parse_read_summarize_command_output(exec_result.stdout)
        except AgentSandboxLifecycleError:
            await self._terminalize_command_failure(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=run.id,
                sandbox_id=sandbox_record.id,
                provider_handle=sandbox_record.provider_handle,
                reason_code="agent_sandbox_command_output_invalid",
            )
            raise
        terminal_status = (
            AgentRunStatus.SUCCEEDED
            if exec_result.exit_code == 0 and output.succeeded
            else AgentRunStatus.FAILED
        )
        if output.shield_call_id is not None:
            run = await self._run_store.append_shield_call_id(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=run.id,
                shield_call_id=output.shield_call_id,
            )
        if terminal_status is AgentRunStatus.FAILED:
            await self._kill_orphan(provider_handle=sandbox_record.provider_handle)
        terminal_run = await self._run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=run.id,
            status=terminal_status,
            result_json=_safe_result_json(output.result_payload()),
        )
        terminal_sandbox = await self._sandbox_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            sandbox_id=sandbox_record.id,
            status=terminal_status,
        )
        if terminal_status is AgentRunStatus.SUCCEEDED:
            await self._kill_orphan(provider_handle=sandbox_record.provider_handle)
        return terminal_run, terminal_sandbox

    async def _terminalize_command_failure(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        sandbox_id: UUID,
        provider_handle: str | None,
        reason_code: str,
    ) -> None:
        await self._kill_orphan(provider_handle=provider_handle)
        await self._run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            status=AgentRunStatus.FAILED,
            result_json=_safe_result_json({"outcome": "failed", "reason_code": reason_code}),
        )
        await self._sandbox_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            sandbox_id=sandbox_id,
            status=AgentRunStatus.FAILED,
        )

    async def _kill_orphan(self, *, provider_handle: str | None) -> None:
        if provider_handle is None or self._control_plane is None:
            return
        try:
            await self._control_plane.kill(
                provider="e2b",
                provider_handle=provider_handle,
                reason="spawn_persistence_failed",
            )
        except AgentSandboxLifecycleError:
            return


def _egress_probe_command(
    *,
    probe_path: str,
    api_base_url: str,
    shield_base_url: str,
    denied_hosts: Sequence[str],
    timeout_seconds: int,
) -> tuple[str, ...]:
    if probe_path == _INLINE_PYTHON_EGRESS_PROBE:
        return _inline_python_egress_probe_command(
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
            denied_hosts=denied_hosts,
            timeout_seconds=timeout_seconds,
        )
    command = [
        probe_path,
        "--api-url",
        f"{api_base_url.rstrip('/')}/readyz",
        "--shield-url",
        f"{shield_base_url.rstrip('/')}/readyz",
        "--timeout",
        str(timeout_seconds),
    ]
    for host in denied_hosts:
        command.extend(("--deny-host", host))
    return tuple(command)


async def _load_read_summarize_command_state(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    agent_run_id: UUID,
) -> _ReadSummarizeCommandState:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: AgentRun command state is tenant scoped; RLS also applies.
SELECT trigger_ref, model_route_snapshot
FROM agent_run
WHERE id = $1
  AND tenant_id = $2
""",
            agent_run_id,
            tenant_id,
        ),
    )
    if row is None:
        raise AgentSandboxLifecycleError("agent_run_not_found")
    return _ReadSummarizeCommandState(
        trigger_ref=_json_dict(row["trigger_ref"]),
        model_route_snapshot=ModelRouteSnapshot.model_validate(
            _json_dict(row["model_route_snapshot"])
        ),
    )


def _source_node_id_from_trigger(trigger_ref: Mapping[str, Any]) -> UUID:
    raw = trigger_ref.get("trigger_ref", {})
    if not isinstance(raw, Mapping):
        raise AgentSandboxLifecycleError("agent_runtime_source_ref_required")
    trigger_body = cast(Mapping[str, Any], raw)
    source_ref = trigger_body.get("source_ref")
    if not isinstance(source_ref, str):
        raise AgentSandboxLifecycleError("agent_runtime_source_ref_required")
    try:
        return UUID(source_ref.removeprefix("node:"))
    except ValueError as exc:
        raise AgentSandboxLifecycleError("agent_runtime_source_ref_invalid") from exc


def _read_summarize_command_env(
    *,
    tenant_id: UUID,
    run: Any,
    source_node_id: UUID,
    command_state: _ReadSummarizeCommandState,
    api_base_url: str,
    shield_base_url: str,
    agent_bearer_token: str,
    tool_secret_env: Mapping[str, str] | None = None,
) -> dict[str, str]:
    trace_seed = str(run.id).replace("-", "")
    env = {
        "SKALDOS_TASK_CONTRACT": _READ_SUMMARIZE_COMMAND_CONTRACT,
        "SKALDOS_AGENT_BEARER_TOKEN": agent_bearer_token,
        "SKALDOS_API_BASE_URL": api_base_url.rstrip("/"),
        "SKALDOS_SHIELD_COMPLETE_URL": f"{shield_base_url.rstrip('/')}/v1/complete",
        "SKALDOS_AGENT_RUN_ID": str(run.id),
        "SKALDOS_TENANT_ID": str(tenant_id),
        "SKALDOS_EFFECTIVE_PRINCIPAL_ID": str(run.effective_principal_id),
        "SKALDOS_EFFECTIVE_CLEARANCE": str(run.effective_clearance),
        "SKALDOS_SOURCE_NODE_ID": str(source_node_id),
        "SKALDOS_TOOL_CALL_ID": str(run.id),
        "SKALDOS_TRACE_ID": trace_seed[:32],
        "SKALDOS_SPAN_ID": trace_seed[:16],
        "SKALDOS_MODEL_ROUTE_SNAPSHOT": command_state.model_route_snapshot.model_dump_json(),
        "SKALDOS_IDEMPOTENCY_KEY": (f"agent-run:{run.id}:read-and-summarize:{source_node_id}"),
    }
    env.update(dict(tool_secret_env or {}))
    return env


def _parse_read_summarize_command_output(stdout: str) -> _ReadSummarizeCommandOutput:
    try:
        parsed = json.loads(stdout.strip())
    except json.JSONDecodeError as exc:
        raise AgentSandboxLifecycleError("agent_sandbox_command_output_invalid") from exc
    if not isinstance(parsed, dict):
        raise AgentSandboxLifecycleError("agent_sandbox_command_output_invalid")
    try:
        return _ReadSummarizeCommandOutput.model_validate(parsed)
    except ValueError as exc:
        raise AgentSandboxLifecycleError("agent_sandbox_command_output_invalid") from exc


def _safe_result_json(payload: Mapping[str, JsonValue]) -> str:
    return json.dumps(dict(payload), separators=(",", ":"), sort_keys=True)


def _json_dict(value: object) -> dict[str, Any]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, Any], parsed)
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, Any], value))
    raise AgentSandboxLifecycleError("agent_sandbox_json_object_required")


def _inline_python_egress_probe_command(
    *,
    api_base_url: str,
    shield_base_url: str,
    denied_hosts: Sequence[str],
    timeout_seconds: int,
) -> tuple[str, ...]:
    script = r"""
import json
import sys
import urllib.request

timeout = int(sys.argv[1])
api_url = sys.argv[2]
shield_url = sys.argv[3]
denied_hosts = sys.argv[4:]

def allowed(url):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return 200 <= response.status < 500
    except Exception:
        return False

def denied(host):
    try:
        with urllib.request.urlopen(f"https://{host}/", timeout=timeout):
            return False
    except Exception:
        return True

results = {
    "api": "reachable" if allowed(api_url) else "blocked",
    "shield": "reachable" if allowed(shield_url) else "blocked",
    "denied": {host: ("blocked" if denied(host) else "reachable") for host in denied_hosts},
}
print(json.dumps(results, sort_keys=True))
if results["api"] != "reachable" or results["shield"] != "reachable":
    raise SystemExit(2)
if any(status != "blocked" for status in results["denied"].values()):
    raise SystemExit(3)
"""
    return (
        "python3",
        "-c",
        script,
        str(timeout_seconds),
        f"{api_base_url.rstrip('/')}/readyz",
        f"{shield_base_url.rstrip('/')}/readyz",
        *denied_hosts,
    )


__all__ = [
    "AgentRunE2BSandboxLaunchService",
    "E2BPostStartProbeConfig",
    "E2BReadSummarizeCommandConfig",
]
