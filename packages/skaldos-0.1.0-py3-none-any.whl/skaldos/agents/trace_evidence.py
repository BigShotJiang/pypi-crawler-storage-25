"""Required trace evidence orchestration for Slice 7 agent runs."""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator, Callable
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from typing import Any, Protocol, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.agents.contracts import AgentRunStatus
from skaldos.agents.graph_outputs import ValidatedGraphOutputTrace
from skaldos.agents.logging import AgentExecutionLogContext, emit_trace_persistence_failure_log
from skaldos.agents.run_store import AgentRunStore
from skaldos.agents.sync_run import bind_effective_principal_context
from skaldos.agents.trace import ExecutionTracePayload
from skaldos.agents.trace_store import (
    ExecutionTraceNodeRecord,
    ExecutionTracePersistenceError,
    ExecutionTraceStore,
)
from skaldos.middleware import Principal


class RequiredTraceEvidenceError(RuntimeError):
    """Raised after required trace persistence failure is made visible."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class RequiredTraceRunStore(Protocol):
    async def get_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
    ) -> object: ...

    async def mark_terminal(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        status: AgentRunStatus,
        result_json: str = "{}",
    ) -> object: ...


class RequiredTraceStore(Protocol):
    async def persist_trace(
        self,
        *,
        principal: Principal,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        trace: ExecutionTracePayload,
        context_of_validity: dict[str, Any],
    ) -> ExecutionTraceNodeRecord: ...

    async def persist_validated_output_trace(
        self,
        *,
        principal: Principal,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        validated_trace: ValidatedGraphOutputTrace,
        context_of_validity: dict[str, Any],
    ) -> ExecutionTraceNodeRecord: ...


RequiredTraceRecoveryConnectionFactory = Callable[[], AbstractAsyncContextManager[Any]]


async def persist_required_trace_or_fail_run(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    trace: ExecutionTracePayload | ValidatedGraphOutputTrace,
    context_of_validity: dict[str, Any],
    run_store: RequiredTraceRunStore | None = None,
    trace_store: RequiredTraceStore | None = None,
    log_context: AgentExecutionLogContext | None = None,
    recovery_connection_factory: RequiredTraceRecoveryConnectionFactory | None = None,
) -> ExecutionTraceNodeRecord:
    """Persist required trace evidence or mark the run failed content-free."""

    trace_store = trace_store or ExecutionTraceStore()
    run_store = run_store or AgentRunStore()
    trace_payload = trace.trace if isinstance(trace, ValidatedGraphOutputTrace) else trace
    try:
        if isinstance(trace, ValidatedGraphOutputTrace):
            return await trace_store.persist_validated_output_trace(
                principal=principal,
                connection=connection,
                tenant_id=tenant_id,
                validated_trace=trace,
                context_of_validity=context_of_validity,
            )
        return await trace_store.persist_trace(
            principal=principal,
            connection=connection,
            tenant_id=tenant_id,
            trace=trace_payload,
            context_of_validity=context_of_validity,
        )
    except Exception as exc:
        reason = (
            exc.reason
            if isinstance(exc, ExecutionTracePersistenceError)
            else "execution_trace_persistence_failed"
        )
        result = {
            "outcome": "failed",
            "reason_code": "required_trace_persistence_failed",
            "trace_error_code": reason,
            "execution_trace_id": str(trace_payload.execution_trace_id),
        }
        await _mark_trace_failure_terminal(
            principal=principal,
            run_store=run_store,
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=trace_payload.agent_run_id,
            result=result,
            recovery_connection_factory=recovery_connection_factory,
        )
        if log_context is not None:
            emit_trace_persistence_failure_log(
                context=log_context,
                execution_trace_id=trace_payload.execution_trace_id,
                reason_code=reason,
            )
        raise RequiredTraceEvidenceError("required_trace_persistence_failed") from exc


async def _mark_trace_failure_terminal(
    *,
    principal: Principal,
    run_store: RequiredTraceRunStore,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    agent_run_id: UUID,
    result: dict[str, str],
    recovery_connection_factory: RequiredTraceRecoveryConnectionFactory | None,
) -> None:
    try:
        await run_store.mark_terminal(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            status=AgentRunStatus.FAILED,
            result_json=json.dumps(result, separators=(",", ":"), sort_keys=True),
        )
    except Exception as exc:
        try:
            current = await run_store.get_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
            )
        except Exception:
            await _mark_trace_failure_terminal_on_recovery_connection(
                principal=principal,
                run_store=run_store,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                result=result,
                recovery_connection_factory=(
                    recovery_connection_factory or _default_recovery_connection
                ),
                original_exception=exc,
            )
            return
        if getattr(current, "status", None) is AgentRunStatus.SUCCEEDED:
            raise RequiredTraceEvidenceError(
                "required_trace_failure_after_terminal_success"
            ) from exc
        raise RequiredTraceEvidenceError("required_trace_failure_mark_failed_failed") from exc


async def _mark_trace_failure_terminal_on_recovery_connection(
    *,
    principal: Principal,
    run_store: RequiredTraceRunStore,
    tenant_id: UUID,
    agent_run_id: UUID,
    result: dict[str, str],
    recovery_connection_factory: RequiredTraceRecoveryConnectionFactory,
    original_exception: Exception,
) -> None:
    try:
        async with recovery_connection_factory() as raw_recovery_connection:  # noqa: SIM117
            recovery_connection = cast(asyncpg.Connection, raw_recovery_connection)
            async with recovery_connection.transaction():  # pyright: ignore[reportUnknownMemberType]
                await bind_effective_principal_context(
                    connection=recovery_connection,
                    principal_id=principal.id,
                    visible_tenant_ids=principal.visible_tenant_ids,
                    clearance=principal.clearance,
                )
                await run_store.mark_terminal(
                    connection=recovery_connection,
                    tenant_id=tenant_id,
                    agent_run_id=agent_run_id,
                    status=AgentRunStatus.FAILED,
                    result_json=json.dumps(result, separators=(",", ":"), sort_keys=True),
                )
    except Exception as exc:
        current = await _try_get_run_on_recovery_connection(
            principal=principal,
            run_store=run_store,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            recovery_connection_factory=recovery_connection_factory,
        )
        if getattr(current, "status", None) is AgentRunStatus.SUCCEEDED:
            raise RequiredTraceEvidenceError(
                "required_trace_failure_after_terminal_success"
            ) from exc
        raise RequiredTraceEvidenceError("required_trace_failure_mark_failed_failed") from (
            original_exception
        )


async def _try_get_run_on_recovery_connection(
    *,
    principal: Principal,
    run_store: RequiredTraceRunStore,
    tenant_id: UUID,
    agent_run_id: UUID,
    recovery_connection_factory: RequiredTraceRecoveryConnectionFactory,
) -> object | None:
    try:
        async with recovery_connection_factory() as raw_recovery_connection:  # noqa: SIM117
            recovery_connection = cast(asyncpg.Connection, raw_recovery_connection)
            async with recovery_connection.transaction():  # pyright: ignore[reportUnknownMemberType]
                await bind_effective_principal_context(
                    connection=recovery_connection,
                    principal_id=principal.id,
                    visible_tenant_ids=principal.visible_tenant_ids,
                    clearance=principal.clearance,
                )
                return await run_store.get_run(
                    connection=recovery_connection,
                    tenant_id=tenant_id,
                    agent_run_id=agent_run_id,
                )
    except Exception:
        return None


@asynccontextmanager
async def _default_recovery_connection() -> AsyncGenerator[asyncpg.Connection]:
    from skaldos.db import get_pool

    pool = await get_pool()
    async with pool.acquire() as connection:  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        yield cast(asyncpg.Connection, cast(Any, connection))


__all__ = [
    "RequiredTraceEvidenceError",
    "RequiredTraceRecoveryConnectionFactory",
    "RequiredTraceRunStore",
    "RequiredTraceStore",
    "persist_required_trace_or_fail_run",
]
