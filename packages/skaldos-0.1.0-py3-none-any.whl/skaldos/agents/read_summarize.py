"""Read-and-summarize@v1 agent vertical primitives.

This module owns the PR-A contract and Shield handoff only. Source content may
enter the source-read response, canonical Shield request body, and transient
trusted summary intended for later writeback. Run context, failure outcomes,
logs, traces, and AgentRun results remain handle-only.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Literal, Protocol
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.agents.contracts import Clearance, JsonValue, ModelRouteSnapshot
from skaldos.api.graph_assert import (
    AssertionActor,
    AssertionGroundingRef,
    AssertionSource,
    GraphAssertRequest,
    GraphAssertResponse,
)
from skaldos.graph.assert_contract import GraphAssertPublicStatus
from skaldos.policy.intent import Intent
from skaldos.shield_client import ShieldCallContext, ShieldClient, text_message
from skaldos_shield.contracts import (
    LatencyMode,
    ModelHint,
    PolicyOutcome,
    RequestedRoute,
    RouteCapability,
    SensitivityTier,
    ShieldMessageRole,
    ShieldResultKind,
    TaskClass,
)

READ_AND_SUMMARIZE_AGENT_TYPE = "read-and-summarize@v1"


class ReadAndSummarizeFailureReason(StrEnum):
    """Safe reason vocabulary for the minimal vertical."""

    SOURCE_UNAVAILABLE = "source_unavailable"
    SOURCE_STALE = "source_stale"
    SHIELD_POLICY_BLOCKED = "shield_policy_blocked"
    SHIELD_NO_SUMMARY = "shield_no_summary"
    SHIELD_UNSUPPORTED_RESULT = "shield_unsupported_result"


class ReadAndSummarizeSourceValidationError(RuntimeError):
    """Raised when a source snapshot violates agent read constraints."""

    def __init__(self, reason: ReadAndSummarizeFailureReason) -> None:
        super().__init__(reason.value)
        self.reason = reason


class ReadAndSummarizeRunContext(BaseModel):
    """Content-free context for one read-and-summarize tool invocation."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    agent_run_id: UUID
    effective_principal_id: UUID
    effective_clearance: Clearance
    source_node_id: UUID
    tool_call_id: UUID
    model_route_snapshot: ModelRouteSnapshot
    redaction_session_id: UUID | None = None
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")] | None = None
    span_id: Annotated[str, Field(pattern=r"^[0-9a-f]{16}$")] | None = None
    idempotency_key: Annotated[str, Field(min_length=1, max_length=256)] | None = None

    @model_validator(mode="after")
    def _route_supports_agent_tool(self) -> ReadAndSummarizeRunContext:
        if self.model_route_snapshot.capability is not RouteCapability.AGENT_TOOL:
            raise ValueError("read_summarize_route_requires_agent_tool")
        return self


class ReadAndSummarizeSourceRequest(BaseModel):
    """API-only source read request issued under the agent Principal."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    principal_id: UUID
    source_node_id: UUID
    effective_clearance: Clearance
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")] | None = None


class ReadAndSummarizeSourceSnapshot(BaseModel):
    """Visible source payload returned by the SkaldOS read API."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    node_id: UUID
    tenant_id: UUID
    body_text: Annotated[str, Field(min_length=1, max_length=64_000)]
    ontology_type: Annotated[str, Field(min_length=1, max_length=128)]
    source_version: Annotated[int, Field(ge=1)]
    source_hash: Annotated[str, Field(min_length=16, max_length=128)]
    classification: Clearance
    context_of_validity: dict[str, JsonValue] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _tenant_context_matches(self) -> ReadAndSummarizeSourceSnapshot:
        tenant = self.context_of_validity.get("tenant")
        if tenant is not None and str(tenant) != str(self.tenant_id):
            raise ValueError("source_context_tenant_mismatch")
        return self


class ReadAndSummarizeSourceUnavailable(BaseModel):
    """Safe no-source result for hidden/missing/stale source reads."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["source_unavailable"] = "source_unavailable"
    reason_code: ReadAndSummarizeFailureReason
    source_node_id: UUID

    @field_validator("reason_code")
    @classmethod
    def _source_reason_only(
        cls, value: ReadAndSummarizeFailureReason
    ) -> ReadAndSummarizeFailureReason:
        if value not in {
            ReadAndSummarizeFailureReason.SOURCE_UNAVAILABLE,
            ReadAndSummarizeFailureReason.SOURCE_STALE,
        }:
            raise ValueError("source_failure_reason_required")
        return value


ReadAndSummarizeSourceResult = ReadAndSummarizeSourceSnapshot | ReadAndSummarizeSourceUnavailable


class ReadAndSummarizeSourceClient(Protocol):
    """Boundary for agent-side reads through SkaldOS API/read chokepoints."""

    async def read_source(
        self, request: ReadAndSummarizeSourceRequest
    ) -> ReadAndSummarizeSourceResult:
        """Return one visible source snapshot or a safe no-source result."""
        ...


class ReadAndSummarizeSummary(BaseModel):
    """Trusted Shield summary text and evidence handles."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["summary"] = "summary"
    summary_text: Annotated[str, Field(min_length=1, max_length=64_000)]
    shield_call_id: UUID
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")] | None = None
    span_id: Annotated[str, Field(pattern=r"^[0-9a-f]{16}$")] | None = None


class ReadAndSummarizeNonSummary(BaseModel):
    """Typed no-summary result with only safe Shield evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["non_summary"] = "non_summary"
    reason_code: ReadAndSummarizeFailureReason
    shield_call_id: UUID
    trace_id: Annotated[str, Field(pattern=r"^[0-9a-f]{32}$")] | None = None
    span_id: Annotated[str, Field(pattern=r"^[0-9a-f]{16}$")] | None = None


ReadAndSummarizeShieldResult = ReadAndSummarizeSummary | ReadAndSummarizeNonSummary


class ReadAndSummarizeShieldEvidenceRecorder(Protocol):
    """Boundary that makes Shield evidence durable before model output is used."""

    async def accept_shield_result(
        self,
        *,
        context: ReadAndSummarizeRunContext,
        shield_result: ReadAndSummarizeShieldResult,
    ) -> ReadAndSummarizeShieldResult:
        """Return ``shield_result`` only after its Shield call id is durable."""
        ...


class ReadAndSummarizeGraphAssertWrite(BaseModel):
    """Prepared `/graph/assert` note writeback request and idempotency key."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    request: GraphAssertRequest
    idempotency_key: Annotated[str, Field(min_length=1, max_length=512)]


class ReadAndSummarizeWritebackResult(BaseModel):
    """Content-free writeback outcome handles returned after `/graph/assert`."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: GraphAssertPublicStatus
    assertion_id: UUID
    pending_assertion_id: UUID | None = None
    output_node_ids: tuple[UUID, ...] = ()
    conflict_id: UUID | None = None
    shield_call_id: UUID
    idempotency_key: Annotated[str, Field(min_length=1, max_length=512)]


class ReadAndSummarizeAgentSuccess(BaseModel):
    """Content-free successful vertical outcome handles."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["success"] = "success"
    source_node_id: UUID
    source_version: Annotated[int, Field(ge=1)]
    source_hash: Annotated[str, Field(min_length=16, max_length=128)]
    shield_call_id: UUID
    writeback: ReadAndSummarizeWritebackResult


class ReadAndSummarizeAgentFailure(BaseModel):
    """Content-free terminal no-write/no-summary outcome."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: Literal["failure"] = "failure"
    reason_code: ReadAndSummarizeFailureReason
    source_node_id: UUID
    shield_call_id: UUID | None = None


ReadAndSummarizeAgentResult = ReadAndSummarizeAgentSuccess | ReadAndSummarizeAgentFailure


class ReadAndSummarizeGraphAssertClient(Protocol):
    """Boundary for posting note writeback through `/graph/assert`."""

    async def post_assertion(
        self,
        *,
        request: GraphAssertRequest,
        idempotency_key: str,
    ) -> GraphAssertResponse:
        """Post one assertion through the public write chokepoint."""
        ...


class ReadAndSummarizeShieldService:
    """Submit visible source content to canonical Shield for summarization."""

    def __init__(self, shield_client: ShieldClient) -> None:
        self._shield_client = shield_client

    async def summarize_source(
        self,
        *,
        context: ReadAndSummarizeRunContext,
        source: ReadAndSummarizeSourceSnapshot,
    ) -> ReadAndSummarizeShieldResult:
        """Return a trusted summary or safe no-summary result."""

        _validate_source_against_context(context=context, source=source)
        response = await self._shield_client.complete(
            context=ShieldCallContext(
                tenant_id=context.tenant_id,
                principal_id=context.effective_principal_id,
                task_class=TaskClass.AGENT_TOOL,
                latency_mode=LatencyMode.SYNC,
                stream=False,
                requested_sensitivity=_sensitivity_for_clearance(source.classification),
                redaction_session_id=context.redaction_session_id,
                agent_run_id=context.agent_run_id,
                tool_call_id=context.tool_call_id,
                trace_id=context.trace_id,
                span_id=context.span_id,
                model_hint=ModelHint(capabilities=frozenset({RouteCapability.AGENT_TOOL})),
                requested_route=_requested_route(context.model_route_snapshot),
            ),
            messages=(
                text_message(
                    ShieldMessageRole.SYSTEM,
                    "Summarize the provided SkaldOS source as one concise note. "
                    "Use only the source content.",
                ),
                text_message(
                    ShieldMessageRole.USER,
                    f"Summarize source node {source.node_id} for {READ_AND_SUMMARIZE_AGENT_TYPE}.",
                ),
                text_message(
                    ShieldMessageRole.TOOL,
                    _source_prompt(context=context, source=source),
                ),
            ),
        )

        if response.policy_outcome not in {PolicyOutcome.PASSED, PolicyOutcome.REDACTED}:
            return ReadAndSummarizeNonSummary(
                reason_code=ReadAndSummarizeFailureReason.SHIELD_POLICY_BLOCKED,
                shield_call_id=response.shield_call_id,
                trace_id=response.trace_id or context.trace_id,
                span_id=response.span_id or context.span_id,
            )
        if response.result is None:
            return ReadAndSummarizeNonSummary(
                reason_code=ReadAndSummarizeFailureReason.SHIELD_NO_SUMMARY,
                shield_call_id=response.shield_call_id,
                trace_id=response.trace_id or context.trace_id,
                span_id=response.span_id or context.span_id,
            )
        if response.result.kind is not ShieldResultKind.MESSAGE:
            return ReadAndSummarizeNonSummary(
                reason_code=ReadAndSummarizeFailureReason.SHIELD_UNSUPPORTED_RESULT,
                shield_call_id=response.shield_call_id,
                trace_id=response.trace_id or context.trace_id,
                span_id=response.span_id or context.span_id,
            )

        for message in response.result.messages:
            if message.role is ShieldMessageRole.ASSISTANT:
                summary = "\n".join(
                    part.text for part in message.parts if part.text is not None
                ).strip()
                if summary:
                    return ReadAndSummarizeSummary(
                        summary_text=summary,
                        shield_call_id=response.shield_call_id,
                        trace_id=response.trace_id or context.trace_id,
                        span_id=response.span_id or context.span_id,
                    )
        return ReadAndSummarizeNonSummary(
            reason_code=ReadAndSummarizeFailureReason.SHIELD_NO_SUMMARY,
            shield_call_id=response.shield_call_id,
            trace_id=response.trace_id or context.trace_id,
            span_id=response.span_id or context.span_id,
        )


class ReadAndSummarizeWritebackService:
    """Write a trusted summary note only through `/graph/assert`."""

    def __init__(self, graph_assert_client: ReadAndSummarizeGraphAssertClient) -> None:
        self._graph_assert_client = graph_assert_client

    async def write_summary(
        self,
        *,
        context: ReadAndSummarizeRunContext,
        source: ReadAndSummarizeSourceSnapshot,
        summary: ReadAndSummarizeSummary,
        confidence: float,
    ) -> ReadAndSummarizeWritebackResult:
        """Post one note assertion and return safe writeback handles."""

        prepared = build_read_and_summarize_note_assertion(
            context=context,
            source=source,
            summary=summary,
            confidence=confidence,
        )
        response = await self._graph_assert_client.post_assertion(
            request=prepared.request,
            idempotency_key=prepared.idempotency_key,
        )
        return ReadAndSummarizeWritebackResult(
            status=response.status,
            assertion_id=response.assertion_id,
            pending_assertion_id=response.pending_assertion_id,
            output_node_ids=tuple(response.applied_node_ids),
            conflict_id=response.conflict_id,
            shield_call_id=summary.shield_call_id,
            idempotency_key=prepared.idempotency_key,
        )


class ReadAndSummarizeAgentService:
    """Compose the minimal read-and-summarize vertical through safe clients."""

    def __init__(
        self,
        *,
        source_client: ReadAndSummarizeSourceClient,
        shield_service: ReadAndSummarizeShieldService,
        writeback_service: ReadAndSummarizeWritebackService,
        shield_evidence_recorder: ReadAndSummarizeShieldEvidenceRecorder | None = None,
    ) -> None:
        self._source_client = source_client
        self._shield_service = shield_service
        self._writeback_service = writeback_service
        self._shield_evidence_recorder = shield_evidence_recorder

    async def run(
        self,
        *,
        context: ReadAndSummarizeRunContext,
        confidence: Annotated[float, Field(ge=0.0, le=1.0)] = 0.8,
    ) -> ReadAndSummarizeAgentResult:
        """Run one source read, Shield summary, and graph-assert writeback."""

        source = await self._source_client.read_source(
            build_read_and_summarize_source_request(context)
        )
        if isinstance(source, ReadAndSummarizeSourceUnavailable):
            return ReadAndSummarizeAgentFailure(
                reason_code=source.reason_code,
                source_node_id=source.source_node_id,
            )

        try:
            shield_result = await self._shield_service.summarize_source(
                context=context,
                source=source,
            )
        except ReadAndSummarizeSourceValidationError as exc:
            return ReadAndSummarizeAgentFailure(
                reason_code=exc.reason,
                source_node_id=context.source_node_id,
            )
        if self._shield_evidence_recorder is not None:
            shield_result = await self._shield_evidence_recorder.accept_shield_result(
                context=context,
                shield_result=shield_result,
            )
        if isinstance(shield_result, ReadAndSummarizeNonSummary):
            return ReadAndSummarizeAgentFailure(
                reason_code=shield_result.reason_code,
                source_node_id=source.node_id,
                shield_call_id=shield_result.shield_call_id,
            )

        writeback = await self._writeback_service.write_summary(
            context=context,
            source=source,
            summary=shield_result,
            confidence=confidence,
        )
        return ReadAndSummarizeAgentSuccess(
            source_node_id=source.node_id,
            source_version=source.source_version,
            source_hash=source.source_hash,
            shield_call_id=shield_result.shield_call_id,
            writeback=writeback,
        )


def build_read_and_summarize_source_request(
    context: ReadAndSummarizeRunContext,
) -> ReadAndSummarizeSourceRequest:
    """Build the API-only source read request from handle-only run context."""

    return ReadAndSummarizeSourceRequest(
        tenant_id=context.tenant_id,
        principal_id=context.effective_principal_id,
        source_node_id=context.source_node_id,
        effective_clearance=context.effective_clearance,
        trace_id=context.trace_id,
    )


def build_read_and_summarize_note_assertion(
    *,
    context: ReadAndSummarizeRunContext,
    source: ReadAndSummarizeSourceSnapshot,
    summary: ReadAndSummarizeSummary,
    confidence: float,
) -> ReadAndSummarizeGraphAssertWrite:
    """Build one `/graph/assert` note request authored by the agent Principal."""

    _validate_source_against_context(context=context, source=source)
    idempotency_key = read_and_summarize_idempotency_key(context=context, source=source)
    request = GraphAssertRequest(
        claim={
            "kind": "note",
            "body": summary.summary_text,
            "context_of_validity": source.context_of_validity,
            "target": {
                "kind": "node",
                "id": str(source.node_id),
                "version": source.source_version,
                "hash": source.source_hash,
            },
        },
        source=AssertionSource(
            kind="agent",
            locator=f"agent-run:{context.agent_run_id}",
            metadata={
                "agent_type": READ_AND_SUMMARIZE_AGENT_TYPE,
                "agent_run_id": str(context.agent_run_id),
                "tool_call_id": str(context.tool_call_id),
                "source_node_id": str(source.node_id),
                "source_version": source.source_version,
                "source_hash": source.source_hash,
                "shield_call_id": str(summary.shield_call_id),
            },
        ),
        actor=AssertionActor(
            principal_id=context.effective_principal_id,
            kind="agent",
        ),
        grounding=[
            AssertionGroundingRef(
                node_id=source.node_id,
                role="source",
            )
        ],
        confidence=confidence,
        intent=Intent.assertive,
    )
    return ReadAndSummarizeGraphAssertWrite(
        request=request,
        idempotency_key=idempotency_key,
    )


def read_and_summarize_idempotency_key(
    *,
    context: ReadAndSummarizeRunContext,
    source: ReadAndSummarizeSourceSnapshot,
) -> str:
    """Return the deterministic PR-A idempotency seed for later writeback."""

    prefix = (
        context.idempotency_key
        if context.idempotency_key is not None
        else (
            f"agent-run:{context.agent_run_id}:"
            f"{READ_AND_SUMMARIZE_AGENT_TYPE}:source:{context.source_node_id}:"
            f"tool:{context.tool_call_id}"
        )
    )
    return f"{prefix}:source-version:{source.source_version}:source-hash:{source.source_hash}"


def _validate_source_against_context(
    *,
    context: ReadAndSummarizeRunContext,
    source: ReadAndSummarizeSourceSnapshot,
) -> None:
    if source.tenant_id != context.tenant_id or source.node_id != context.source_node_id:
        raise ReadAndSummarizeSourceValidationError(
            ReadAndSummarizeFailureReason.SOURCE_UNAVAILABLE
        )
    if _clearance_rank(source.classification) > _clearance_rank(context.effective_clearance):
        raise ReadAndSummarizeSourceValidationError(
            ReadAndSummarizeFailureReason.SOURCE_UNAVAILABLE
        )


def _requested_route(snapshot: ModelRouteSnapshot) -> RequestedRoute:
    return RequestedRoute(
        route_id=snapshot.route_id,
        provider=snapshot.provider,
        model_id=snapshot.model_id,
        capability=snapshot.capability,
    )


def _source_prompt(
    *,
    context: ReadAndSummarizeRunContext,
    source: ReadAndSummarizeSourceSnapshot,
) -> str:
    return "\n\n".join(
        (
            f"task={READ_AND_SUMMARIZE_AGENT_TYPE}",
            f"agent_run_id={context.agent_run_id}",
            f"tool_call_id={context.tool_call_id}",
            f"source_node_id={source.node_id}",
            f"source_version={source.source_version}",
            f"source_hash={source.source_hash}",
            "source_content:",
            source.body_text,
        )
    )


def _sensitivity_for_clearance(clearance: Clearance) -> SensitivityTier:
    if clearance == "C4":
        return SensitivityTier.PII_STRICT
    if clearance in {"C2", "C3"}:
        return SensitivityTier.PII
    return SensitivityTier.NON_PII


def _clearance_rank(clearance: Clearance) -> int:
    return {"C0": 0, "C1": 1, "C2": 2, "C3": 3, "C4": 4}[clearance]


__all__ = [
    "READ_AND_SUMMARIZE_AGENT_TYPE",
    "ReadAndSummarizeAgentFailure",
    "ReadAndSummarizeAgentResult",
    "ReadAndSummarizeAgentService",
    "ReadAndSummarizeAgentSuccess",
    "ReadAndSummarizeFailureReason",
    "ReadAndSummarizeGraphAssertClient",
    "ReadAndSummarizeGraphAssertWrite",
    "ReadAndSummarizeNonSummary",
    "ReadAndSummarizeRunContext",
    "ReadAndSummarizeShieldResult",
    "ReadAndSummarizeShieldEvidenceRecorder",
    "ReadAndSummarizeShieldService",
    "ReadAndSummarizeSourceClient",
    "ReadAndSummarizeSourceRequest",
    "ReadAndSummarizeSourceResult",
    "ReadAndSummarizeSourceSnapshot",
    "ReadAndSummarizeSourceUnavailable",
    "ReadAndSummarizeSourceValidationError",
    "ReadAndSummarizeSummary",
    "ReadAndSummarizeWritebackResult",
    "ReadAndSummarizeWritebackService",
    "build_read_and_summarize_note_assertion",
    "build_read_and_summarize_source_request",
    "read_and_summarize_idempotency_key",
]
