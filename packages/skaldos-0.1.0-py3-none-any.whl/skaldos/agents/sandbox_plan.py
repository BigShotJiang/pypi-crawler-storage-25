"""Sandbox template and egress planning for Slice 7 Pi launches."""

from __future__ import annotations

import hashlib
import ipaddress
import json
import re
from collections.abc import Mapping, Sequence
from typing import Annotated, Literal, cast
from urllib.parse import urlparse
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.agents.contracts import JsonValue
from skaldos.agents.errors import (
    AgentEgressPolicyError,
    AgentTemplateInvalidError,
    AgentTemplateNotFoundError,
    AgentToolSecretError,
)

_DENIED_PROVIDER_HOSTS = frozenset(
    ".".join(parts)
    for parts in (
        ("api", "openai", "com"),
        ("api", "anthropic", "com"),
        ("api", "mistral", "ai"),
        ("api", "openrouter", "ai"),
        ("api", "voyageai", "com"),
        ("openrouter", "ai"),
    )
)
_DENIED_PACKAGE_HOSTS = frozenset(
    {
        "files.pythonhosted.org",
        "packages.npmjs.com",
        "npmjs.com",
        "pypi.org",
        "pythonhosted.org",
        "repo.maven.apache.org",
        "registry.npmjs.org",
        "registry.yarnpkg.com",
        "rubygems.org",
    }
)
_DENIED_METADATA_HOSTS = frozenset(
    {
        "169.254.169.254",
        "metadata.google.internal",
    }
)
_DENIED_HOST_CLASSES = (
    "model_provider",
    "package_registry",
    "metadata_service",
    "private_or_local_network",
    "wildcard",
    "undeclared_service",
)
_PROVIDER_DEPENDENCY_HINTS = (
    "anthropic",
    "mistral",
    "openai",
    "openrouter",
    "voyage",
    "voyageai",
    "provider_api_key",
)
_SECRET_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,127}$")
_ENV_VAR_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,127}$")


class SandboxTemplateManifest(BaseModel):
    """Safe immutable template metadata consumed before sandbox spawn."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    template_version_id: UUID
    tenant_id: UUID
    org_agent_type_id: UUID
    version: Annotated[str, Field(min_length=1, max_length=128)]
    harness: Literal["pi"] = "pi"
    image_uri: Annotated[str, Field(min_length=1, max_length=512)]
    pi_runtime_version: Annotated[str, Field(min_length=1, max_length=128)]
    pi_runtime_path: Annotated[str, Field(min_length=1, max_length=512)]
    tool_manifest: dict[str, JsonValue] = Field(default_factory=dict)
    dependency_manifest: dict[str, JsonValue] = Field(default_factory=dict)
    no_runtime_install: Literal[True] = True
    superseded: bool = False

    @field_validator("tool_manifest", "dependency_manifest")
    @classmethod
    def _reject_provider_sdk_or_key_hints(cls, value: dict[str, JsonValue]) -> dict[str, JsonValue]:
        _raise_if_provider_dependency_hint(value)
        return value

    @model_validator(mode="after")
    def _reject_superseded_template(self) -> SandboxTemplateManifest:
        if self.superseded:
            raise AgentTemplateInvalidError("agent_template_superseded")
        return self


class ToolSecretPlan(BaseModel):
    """Declared tool/integration secrets that may enter sandbox env."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    required_secrets: tuple[str, ...]
    env_mapping: dict[str, str]

    @model_validator(mode="after")
    def _validate_secret_mapping(self) -> ToolSecretPlan:
        required = tuple(_normalize_secret_name(secret) for secret in self.required_secrets)
        if len(set(required)) != len(required):
            raise AgentToolSecretError("agent_tool_secret_duplicate")

        mapping: dict[str, str] = {}
        seen_env_vars: set[str] = set()
        for secret_name, env_var in self.env_mapping.items():
            normalized_secret = _normalize_secret_name(secret_name)
            normalized_env = _normalize_env_var(env_var)
            if normalized_env in seen_env_vars:
                raise AgentToolSecretError("agent_tool_secret_env_duplicate")
            mapping[normalized_secret] = normalized_env
            seen_env_vars.add(normalized_env)

        missing = sorted(set(required).difference(mapping))
        if missing:
            raise AgentToolSecretError("agent_tool_secret_mapping_missing")
        extra = sorted(set(mapping).difference(required))
        if extra:
            raise AgentToolSecretError("agent_tool_secret_mapping_extra")

        object.__setattr__(self, "required_secrets", required)
        object.__setattr__(self, "env_mapping", mapping)
        return self


class EgressPolicy(BaseModel):
    """Content-free deterministic sandbox egress policy."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_version: Literal[1] = 1
    allowed_hosts: tuple[str, ...]
    denied_host_classes: tuple[str, ...] = _DENIED_HOST_CLASSES
    policy_hash: Annotated[str, Field(min_length=64, max_length=64)]


class SandboxSpawnPlan(BaseModel):
    """Provider-neutral data needed to create a Slice 7 sandbox row/spawn."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: UUID
    org_agent_type_id: UUID
    template_version_id: UUID
    template: SandboxTemplateManifest
    tool_secret_plan: ToolSecretPlan
    egress_policy: EgressPolicy
    persistence: Literal["ephemeral"] = "ephemeral"


class SandboxTemplateStore:
    """Resolve Pi template metadata through tenant-scoped agent type state."""

    async def current_template_manifest(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
    ) -> SandboxTemplateManifest:
        row = cast(
            Mapping[str, object] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: scoped by agent type tenant/template tenant; RLS also applies.
SELECT st.id AS template_version_id,
       st.tenant_id,
       st.org_agent_type_id,
       st.version,
       st.harness,
       st.image_uri,
       st.pi_runtime_version,
       st.pi_runtime_path,
       st.tool_manifest,
       st.dependency_manifest,
       st.no_runtime_install,
       st.superseded_at IS NOT NULL AS superseded
FROM org_agent_type oat
JOIN sandbox_template st ON st.id = oat.current_template_version_id
WHERE oat.id = $1
  AND oat.tenant_id = $2
  AND oat.archived_at IS NULL
  AND st.tenant_id = oat.tenant_id
  AND st.org_agent_type_id = oat.id
""",
                org_agent_type_id,
                tenant_id,
            ),
        )
        if row is None:
            raise AgentTemplateNotFoundError()
        return _template_manifest_from_row(row)


def build_sandbox_spawn_plan(
    *,
    template: SandboxTemplateManifest,
    required_secrets: Sequence[str],
    secret_env_mapping: Mapping[str, str],
    api_base_url: str,
    shield_base_url: str,
) -> SandboxSpawnPlan:
    """Build a safe spawn plan without touching secrets or providers."""

    tool_secret_plan = ToolSecretPlan(
        required_secrets=tuple(required_secrets),
        env_mapping=dict(secret_env_mapping),
    )
    return SandboxSpawnPlan(
        tenant_id=template.tenant_id,
        org_agent_type_id=template.org_agent_type_id,
        template_version_id=template.template_version_id,
        template=template,
        tool_secret_plan=tool_secret_plan,
        egress_policy=build_egress_policy(
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
            declared_tool_hosts=declared_tool_hosts(
                template.tool_manifest,
                required_secrets=tool_secret_plan.required_secrets,
            ),
        ),
    )


def _template_manifest_from_row(row: Mapping[str, object]) -> SandboxTemplateManifest:
    return SandboxTemplateManifest(
        template_version_id=cast(UUID, row["template_version_id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        org_agent_type_id=cast(UUID, row["org_agent_type_id"]),
        version=str(row["version"]),
        harness=cast(Literal["pi"], row["harness"]),
        image_uri=str(row["image_uri"]),
        pi_runtime_version=str(row["pi_runtime_version"]),
        pi_runtime_path=str(row["pi_runtime_path"]),
        tool_manifest=cast(dict[str, JsonValue], _json_object(row["tool_manifest"])),
        dependency_manifest=cast(dict[str, JsonValue], _json_object(row["dependency_manifest"])),
        no_runtime_install=cast(Literal[True], row["no_runtime_install"]),
        superseded=bool(row["superseded"]),
    )


def _json_object(value: object) -> dict[str, object]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, object], parsed)
        raise AgentTemplateInvalidError("agent_template_manifest_not_object")
    if isinstance(value, dict):
        return cast(dict[str, object], value)
    raise AgentTemplateInvalidError("agent_template_manifest_not_object")


def build_egress_policy(
    *,
    api_base_url: str,
    shield_base_url: str,
    declared_tool_hosts: Sequence[str] = (),
) -> EgressPolicy:
    """Construct the deterministic allowlist used by sandbox providers."""

    allowed_hosts = tuple(
        sorted(
            {
                _normalize_allowed_host(api_base_url),
                _normalize_allowed_host(shield_base_url),
                *(_normalize_allowed_host(host) for host in declared_tool_hosts),
            }
        )
    )
    if not allowed_hosts:
        raise AgentEgressPolicyError("agent_egress_policy_empty")

    payload: dict[str, object] = {
        "policy_version": 1,
        "allowed_hosts": allowed_hosts,
        "denied_host_classes": _DENIED_HOST_CLASSES,
    }
    return EgressPolicy(
        allowed_hosts=allowed_hosts,
        policy_hash=hashlib.sha256(
            json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        ).hexdigest(),
    )


def declared_tool_hosts(
    tool_manifest: Mapping[str, object],
    *,
    required_secrets: Sequence[str],
) -> tuple[str, ...]:
    """Extract exact external hosts backed by declared tool secrets."""

    hosts: list[str] = []
    allowed_secrets = frozenset(_normalize_secret_name(secret) for secret in required_secrets)

    def visit(candidate: object, *, active_secrets: frozenset[str]) -> None:
        if isinstance(candidate, dict):
            mapping = cast(Mapping[object, object], candidate)
            node_secrets = active_secrets
            raw_node_secrets = mapping.get("required_secrets")
            if raw_node_secrets is not None:
                if not isinstance(raw_node_secrets, list):
                    raise AgentEgressPolicyError("agent_tool_host_secrets_not_array")
                node_secrets = frozenset(
                    _normalize_secret_name(str(secret))
                    for secret in cast(Sequence[object], raw_node_secrets)
                )
                if not node_secrets:
                    raise AgentEgressPolicyError("agent_tool_host_secret_missing")
                undeclared = node_secrets.difference(allowed_secrets)
                if undeclared:
                    raise AgentEgressPolicyError("agent_tool_host_secret_undeclared")
            for key, nested in mapping.items():
                if str(key) == "required_secrets":
                    continue
                if str(key) in {"external_hosts", "allowed_hosts", "egress_hosts"}:
                    if not node_secrets:
                        raise AgentEgressPolicyError("agent_tool_host_secret_missing")
                    if not isinstance(nested, list):
                        raise AgentEgressPolicyError("agent_tool_hosts_not_array")
                    host_items = cast(Sequence[object], nested)
                    hosts.extend(str(item) for item in host_items)
                    continue
                visit(nested, active_secrets=node_secrets)
            return
        if isinstance(candidate, list):
            nested_items = cast(Sequence[object], candidate)
            for nested in nested_items:
                visit(nested, active_secrets=active_secrets)

    visit(tool_manifest, active_secrets=frozenset())
    return tuple(sorted({_normalize_allowed_host(host) for host in hosts}))


def _normalize_secret_name(value: str) -> str:
    normalized = value.strip()
    lowered = normalized.lower()
    if not _SECRET_NAME_RE.fullmatch(normalized):
        raise AgentToolSecretError("agent_tool_secret_name_invalid")
    if any(term in lowered for term in _PROVIDER_DEPENDENCY_HINTS):
        raise AgentToolSecretError("model_provider_credential_not_tool_secret")
    if lowered in {"api_key", "model_api_key", "provider_api_key"}:
        raise AgentToolSecretError("model_provider_credential_not_tool_secret")
    return normalized


def _normalize_env_var(value: str) -> str:
    normalized = value.strip()
    lowered = normalized.lower()
    if not _ENV_VAR_RE.fullmatch(normalized):
        raise AgentToolSecretError("agent_tool_secret_env_invalid")
    if any(term in lowered for term in _PROVIDER_DEPENDENCY_HINTS):
        raise AgentToolSecretError("model_provider_credential_not_tool_secret")
    if lowered in {"api_key", "model_api_key", "provider_api_key"}:
        raise AgentToolSecretError("model_provider_credential_not_tool_secret")
    return normalized


def _normalize_allowed_host(value: str) -> str:
    candidate = value.strip()
    if not candidate:
        raise AgentEgressPolicyError("agent_egress_host_empty")

    parsed = urlparse(candidate if "://" in candidate else f"//{candidate}")
    host = (parsed.hostname or "").lower().rstrip(".")
    if not host:
        raise AgentEgressPolicyError("agent_egress_host_invalid")
    if "*" in host:
        raise AgentEgressPolicyError("agent_egress_host_wildcard")
    if host in _DENIED_PROVIDER_HOSTS:
        raise AgentEgressPolicyError("agent_egress_provider_host_denied")
    if host in _DENIED_PACKAGE_HOSTS:
        raise AgentEgressPolicyError("agent_egress_package_host_denied")
    if host in _DENIED_METADATA_HOSTS:
        raise AgentEgressPolicyError("agent_egress_metadata_host_denied")
    if host == "localhost" or host.endswith(".local"):
        raise AgentEgressPolicyError("agent_egress_private_host_denied")

    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return host
    if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
        raise AgentEgressPolicyError("agent_egress_private_host_denied")
    return host


def _raise_if_provider_dependency_hint(value: Mapping[str, object]) -> None:
    def visit(candidate: object) -> None:
        if isinstance(candidate, dict):
            mapping = cast(Mapping[object, object], candidate)
            for key, nested in mapping.items():
                _raise_if_provider_hint_string(str(key))
                visit(nested)
            return
        if isinstance(candidate, list):
            nested_items = cast(Sequence[object], candidate)
            for nested in nested_items:
                visit(nested)
            return
        if isinstance(candidate, str):
            _raise_if_provider_hint_string(candidate)

    visit(value)


def _raise_if_provider_hint_string(value: str) -> None:
    lowered = value.lower()
    if any(hint in lowered for hint in _PROVIDER_DEPENDENCY_HINTS):
        raise AgentTemplateInvalidError("agent_template_provider_dependency_denied")


__all__ = [
    "EgressPolicy",
    "SandboxSpawnPlan",
    "SandboxTemplateManifest",
    "SandboxTemplateStore",
    "ToolSecretPlan",
    "build_egress_policy",
    "build_sandbox_spawn_plan",
    "declared_tool_hosts",
]
