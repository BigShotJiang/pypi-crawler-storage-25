"""Sync AgentRun launch shell for Slice 7."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from typing import Any, Protocol, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.agents.contracts import (
    AgentTriggerKind,
    Clearance,
    EventAgentTriggerRef,
    PiLaunchEnvelope,
    SyncAgentRunRequest,
    SyncAgentRunResponse,
    ToolSecretEnvMapping,
)
from skaldos.agents.errors import (
    AgentIdentityNotConfiguredError,
    AgentRunStorageError,
    AgentServiceError,
    AgentTypeNotFoundError,
    AgentWorkflowStartError,
)
from skaldos.agents.model_routes import AgentModelRouteResolver
from skaldos.agents.run_store import AgentRunRecord, AgentRunStore
from skaldos.agents.sandbox_plan import SandboxTemplateStore, build_sandbox_spawn_plan
from skaldos.middleware import Principal
from skaldos.middleware.hydration import (
    GUC_PRINCIPAL_CONTEXT,
    GUC_PRINCIPAL_ID,
    GUC_PRINCIPAL_VISIBLE,
)
from skaldos.middleware.resolver import format_uuid_array

_CLEARANCE_RANK: Mapping[Clearance, int] = {"C0": 0, "C1": 1, "C2": 2, "C3": 3, "C4": 4}


class AgentRunWorkflowStart(BaseModel):
    """Content-free facts handed to the durable workflow starter."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    workflow_id: str
    agent_run_id: UUID
    tenant_id: UUID
    occurred_at: datetime
    launch_envelope: PiLaunchEnvelope


class AgentWorkflowStarter(Protocol):
    """Durable in-transaction workflow enqueue boundary."""

    async def start_agent_run(
        self,
        *,
        connection: asyncpg.Connection,
        start: AgentRunWorkflowStart,
    ) -> None:
        """Persist or idempotently acknowledge a future `agent.run` start."""


class RecordingAgentWorkflowStarter:
    """Dev/test starter that records requested starts in memory."""

    def __init__(self) -> None:
        self.starts: list[AgentRunWorkflowStart] = []

    async def start_agent_run(
        self,
        *,
        connection: asyncpg.Connection,
        start: AgentRunWorkflowStart,
    ) -> None:
        self.starts.append(start)


class AgentTypeLaunchConfig(BaseModel):
    """Safe launch facts loaded from `org_agent_type`."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    agent_principal_id: UUID
    max_clearance: Clearance
    required_secrets: tuple[str, ...]
    secret_env_mapping: dict[str, str]


class AgentRunSyncLaunchService:
    """Create an AgentRun and start the sync workflow shell."""

    def __init__(
        self,
        *,
        run_store: AgentRunStore | None = None,
        route_resolver: AgentModelRouteResolver | None = None,
        template_store: SandboxTemplateStore | None = None,
        workflow_starter: AgentWorkflowStarter | None = None,
    ) -> None:
        self._run_store = run_store or AgentRunStore()
        self._route_resolver = route_resolver or AgentModelRouteResolver()
        self._template_store = template_store or SandboxTemplateStore()
        self._workflow_starter = workflow_starter

    async def launch_sync_run(
        self,
        *,
        connection: asyncpg.Connection,
        launcher: Principal,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        request: SyncAgentRunRequest,
        api_base_url: str,
        shield_base_url: str,
    ) -> SyncAgentRunResponse:
        workflow_id = sync_agent_workflow_id(
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            request_id=request.request_id,
        )
        return await self._launch_run(
            connection=connection,
            launcher=launcher,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            trigger_kind=AgentTriggerKind.SYNC,
            trigger_ref_json=json.dumps(
                {
                    "request_id": str(request.request_id),
                    "trace_id": request.trace_id,
                    "span_id": request.span_id,
                    "trigger_ref": request.trigger_ref.model_dump(
                        mode="json",
                        exclude_none=True,
                    ),
                },
                separators=(",", ":"),
                sort_keys=True,
            ),
            workflow_id=workflow_id,
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
            timeout_seconds=request.timeout_seconds,
            clearance_cap=request.clearance_cap,
            idempotent=True,
        )

    async def launch_event_run(
        self,
        *,
        connection: asyncpg.Connection,
        launcher: Principal,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        trigger_ref: EventAgentTriggerRef,
        effective_clearance: Clearance,
        api_base_url: str,
        shield_base_url: str,
        timeout_seconds: int = 300,
    ) -> SyncAgentRunResponse:
        return await self._launch_run(
            connection=connection,
            launcher=launcher,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            trigger_kind=AgentTriggerKind.EVENT,
            trigger_ref_json=json.dumps(
                trigger_ref.model_dump(mode="json"),
                separators=(",", ":"),
                sort_keys=True,
            ),
            workflow_id=event_agent_workflow_id(
                tenant_id=tenant_id,
                idempotency_key=trigger_ref.idempotency_key,
            ),
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
            timeout_seconds=timeout_seconds,
            effective_clearance_override=effective_clearance,
            idempotent=True,
        )

    async def _launch_run(
        self,
        *,
        connection: asyncpg.Connection,
        launcher: Principal,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        trigger_kind: AgentTriggerKind,
        trigger_ref_json: str,
        workflow_id: str,
        api_base_url: str,
        shield_base_url: str,
        timeout_seconds: int,
        clearance_cap: Clearance | None = None,
        effective_clearance_override: Clearance | None = None,
        idempotent: bool,
    ) -> SyncAgentRunResponse:
        agent_type = await load_agent_type_launch_config(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
        )
        effective_clearance = (
            effective_clearance_override
            if effective_clearance_override is not None
            else _effective_clearance(
                launcher=launcher,
                tenant_id=tenant_id,
                agent_type_max=agent_type.max_clearance,
                request_cap=clearance_cap,
            )
        )
        template = await self._template_store.current_template_manifest(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
        )
        if template.template_version_id != await self._run_store.current_template_id(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
        ):
            raise AgentRunStorageError("agent_template_version_mismatch")

        route_snapshot = await self._route_resolver.resolve_snapshot(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
        )
        spawn_plan = build_sandbox_spawn_plan(
            template=template,
            required_secrets=agent_type.required_secrets,
            secret_env_mapping=agent_type.secret_env_mapping,
            api_base_url=api_base_url,
            shield_base_url=shield_base_url,
        )
        if trigger_kind is AgentTriggerKind.EVENT:
            run = await self._run_store.create_event_run(
                connection=connection,
                tenant_id=tenant_id,
                org_agent_type_id=org_agent_type_id,
                launcher_principal_id=launcher.id,
                effective_principal_id=agent_type.agent_principal_id,
                effective_clearance=effective_clearance,
                dbos_workflow_id=workflow_id,
                template_version_id=template.template_version_id,
                model_route_snapshot_json=route_snapshot.model_dump_json(),
                trigger_ref_json=trigger_ref_json,
            )
        else:
            run = await self._run_store.create_sync_run(
                connection=connection,
                tenant_id=tenant_id,
                org_agent_type_id=org_agent_type_id,
                launcher_principal_id=launcher.id,
                effective_principal_id=agent_type.agent_principal_id,
                effective_clearance=effective_clearance,
                dbos_workflow_id=workflow_id,
                template_version_id=template.template_version_id,
                model_route_snapshot_json=route_snapshot.model_dump_json(),
                trigger_ref_json=trigger_ref_json,
                idempotent=idempotent,
            )
        launch_envelope = PiLaunchEnvelope.model_validate(
            {
                "agent_run_id": run.id,
                "tenant_id": tenant_id,
                "effective_principal_id": agent_type.agent_principal_id,
                "org_agent_type_id": org_agent_type_id,
                "template_version_id": spawn_plan.template_version_id,
                "trigger_kind": trigger_kind,
                "effective_clearance": effective_clearance,
                "api_base_url": api_base_url,
                "shield_base_url": shield_base_url,
                "model_route_snapshot": route_snapshot,
                "required_secrets": spawn_plan.tool_secret_plan.required_secrets,
                "secret_env_mapping": tuple(
                    ToolSecretEnvMapping(secret_name=secret_name, env_var=env_var)
                    for secret_name, env_var in sorted(
                        spawn_plan.tool_secret_plan.env_mapping.items()
                    )
                ),
                "tool_manifest": template.tool_manifest,
                "timeout_seconds": timeout_seconds,
            }
        )
        if self._workflow_starter is not None and (not idempotent or run.created_by_insert):
            try:
                await self._workflow_starter.start_agent_run(
                    connection=connection,
                    start=AgentRunWorkflowStart(
                        workflow_id=workflow_id,
                        agent_run_id=run.id,
                        tenant_id=tenant_id,
                        occurred_at=run.created_at,
                        launch_envelope=launch_envelope,
                    ),
                )
            except Exception as exc:
                raise AgentWorkflowStartError() from exc

        return _response_from_record(run)


async def load_agent_type_launch_config(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    org_agent_type_id: UUID,
) -> AgentTypeLaunchConfig:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
-- tenant_filter_required: scoped by agent type tenant; RLS also applies.
SELECT id,
       tenant_id,
       agent_principal_id,
       max_clearance,
       required_secrets,
       secret_env_mapping
FROM org_agent_type
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
""",
            org_agent_type_id,
            tenant_id,
        ),
    )
    if row is None:
        raise AgentTypeNotFoundError()
    if row["agent_principal_id"] is None:
        raise AgentIdentityNotConfiguredError()
    return AgentTypeLaunchConfig(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        agent_principal_id=cast(UUID, row["agent_principal_id"]),
        max_clearance=cast(Clearance, str(row["max_clearance"])),
        required_secrets=tuple(str(item) for item in _json_array(row["required_secrets"])),
        secret_env_mapping={
            str(key): str(value) for key, value in _json_object(row["secret_env_mapping"]).items()
        },
    )


async def bind_effective_principal_context(
    *,
    connection: asyncpg.Connection,
    principal_id: UUID,
    visible_tenant_ids: tuple[UUID, ...],
    clearance: Clearance,
) -> None:
    """Set Slice 1/3 Principal GUCs inside a workflow activity transaction."""

    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise AgentWorkflowStartError("agent_workflow_transaction_required")
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_ID,
        str(principal_id),
    )
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_VISIBLE,
        format_uuid_array(visible_tenant_ids),
    )
    await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        "SELECT set_config($1, $2, true)",
        GUC_PRINCIPAL_CONTEXT,
        json.dumps(
            {
                "tenants": [str(tenant_id) for tenant_id in visible_tenant_ids],
                "classification": clearance,
                "clearances": {str(tenant_id): clearance for tenant_id in visible_tenant_ids},
                "verticals": [],
                "ontology_versions": [],
            },
            separators=(",", ":"),
        ),
    )


def sync_agent_workflow_id(
    *,
    tenant_id: UUID,
    org_agent_type_id: UUID,
    request_id: UUID,
) -> str:
    return f"agent.run.sync.{tenant_id}.{org_agent_type_id}.{request_id}"


def event_agent_workflow_id(
    *,
    tenant_id: UUID,
    idempotency_key: str,
) -> str:
    return f"agent.run.event.{tenant_id}.{idempotency_key}"


def _effective_clearance(
    *,
    launcher: Principal,
    tenant_id: UUID,
    agent_type_max: Clearance,
    request_cap: Clearance | None,
) -> Clearance:
    launcher_clearance = _launcher_tenant_clearance(launcher, tenant_id)
    candidates: list[Clearance] = [launcher_clearance, agent_type_max]
    if request_cap is not None:
        candidates.append(request_cap)
    return min(candidates, key=_CLEARANCE_RANK.__getitem__)


def _launcher_tenant_clearance(launcher: Principal, tenant_id: UUID) -> Clearance:
    for candidate_tenant_id, clearance in launcher.clearance_assignments:
        if candidate_tenant_id == tenant_id:
            return clearance
    return "C0"


def _response_from_record(record: AgentRunRecord) -> SyncAgentRunResponse:
    return SyncAgentRunResponse(
        agent_run_id=record.id,
        status=record.status,
        dbos_workflow_id=record.dbos_workflow_id,
        effective_principal_id=record.effective_principal_id,
        effective_clearance=record.effective_clearance,
        template_version_id=record.template_version_id,
    )


def _json_object(value: object) -> Mapping[str, object]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(Mapping[str, object], parsed)
    if isinstance(value, dict):
        return cast(Mapping[str, object], value)
    raise AgentServiceError("agent_launch_config_not_object")


def _json_array(value: object) -> tuple[object, ...]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return tuple(cast(list[object], parsed))
    if isinstance(value, list | tuple):
        return tuple(cast(list[object] | tuple[object, ...], value))
    raise AgentServiceError("agent_launch_config_not_array")


__all__ = [
    "AgentRunSyncLaunchService",
    "AgentRunWorkflowStart",
    "AgentTypeLaunchConfig",
    "AgentWorkflowStarter",
    "bind_effective_principal_context",
    "event_agent_workflow_id",
    "load_agent_type_launch_config",
    "RecordingAgentWorkflowStarter",
    "sync_agent_workflow_id",
]
