"""AgentRun persistence primitives for Slice 7 service wiring."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field

from skaldos.agents.contracts import AgentRunStatus, AgentTriggerKind, Clearance, JsonValue
from skaldos.agents.errors import AgentRunStorageError, AgentTemplateNotFoundError


class AgentRunRecord(BaseModel):
    """Content-free persisted AgentRun projection."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    org_agent_type_id: UUID
    launcher_principal_id: UUID
    effective_principal_id: UUID
    effective_clearance: Clearance
    trigger_kind: AgentTriggerKind
    dbos_workflow_id: str
    template_version_id: UUID
    shield_call_ids: tuple[UUID, ...] = ()
    sandbox_id: UUID | None = None
    status: AgentRunStatus
    result: dict[str, JsonValue] = Field(default_factory=dict)
    created_at: datetime
    started_at: datetime | None = None
    terminal_at: datetime | None = None
    updated_at: datetime
    created_by_insert: bool = True


class AgentRunStore:
    """Small asyncpg-backed store for sync AgentRun state transitions."""

    async def current_template_id(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
    ) -> UUID:
        template_id = cast(
            UUID | None,
            await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: scoped by agent type tenant; RLS also applies.
SELECT current_template_version_id
FROM org_agent_type
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
""",
                org_agent_type_id,
                tenant_id,
            ),
        )
        if template_id is None:
            raise AgentTemplateNotFoundError()
        return template_id

    async def create_sync_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        launcher_principal_id: UUID,
        effective_principal_id: UUID,
        effective_clearance: Clearance,
        dbos_workflow_id: str,
        template_version_id: UUID,
        model_route_snapshot_json: str,
        trigger_ref_json: str = "{}",
        idempotent: bool = False,
    ) -> AgentRunRecord:
        return await self._create_run(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            launcher_principal_id=launcher_principal_id,
            effective_principal_id=effective_principal_id,
            effective_clearance=effective_clearance,
            trigger_kind=AgentTriggerKind.SYNC,
            dbos_workflow_id=dbos_workflow_id,
            template_version_id=template_version_id,
            model_route_snapshot_json=model_route_snapshot_json,
            trigger_ref_json=trigger_ref_json,
            idempotent=idempotent,
        )

    async def create_event_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        launcher_principal_id: UUID,
        effective_principal_id: UUID,
        effective_clearance: Clearance,
        dbos_workflow_id: str,
        template_version_id: UUID,
        model_route_snapshot_json: str,
        trigger_ref_json: str,
    ) -> AgentRunRecord:
        return await self._create_run(
            connection=connection,
            tenant_id=tenant_id,
            org_agent_type_id=org_agent_type_id,
            launcher_principal_id=launcher_principal_id,
            effective_principal_id=effective_principal_id,
            effective_clearance=effective_clearance,
            trigger_kind=AgentTriggerKind.EVENT,
            dbos_workflow_id=dbos_workflow_id,
            template_version_id=template_version_id,
            model_route_snapshot_json=model_route_snapshot_json,
            trigger_ref_json=trigger_ref_json,
            idempotent=True,
        )

    async def _create_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        org_agent_type_id: UUID,
        launcher_principal_id: UUID,
        effective_principal_id: UUID,
        effective_clearance: Clearance,
        trigger_kind: AgentTriggerKind,
        dbos_workflow_id: str,
        template_version_id: UUID,
        model_route_snapshot_json: str,
        trigger_ref_json: str,
        idempotent: bool,
    ) -> AgentRunRecord:
        conflict_clause = (
            """
ON CONFLICT (tenant_id, dbos_workflow_id) DO UPDATE
SET dbos_workflow_id = EXCLUDED.dbos_workflow_id
"""
            if idempotent
            else ""
        )
        try:
            row = cast(
                Mapping[str, Any],
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    f"""
-- tenant_filter_required: AgentRun insert carries tenant_id; RLS also applies.
INSERT INTO agent_run (
  tenant_id,
  org_agent_type_id,
  launcher_principal_id,
  effective_principal_id,
  effective_clearance,
  trigger_kind,
  trigger_ref,
  dbos_workflow_id,
  template_version_id,
  model_route_snapshot,
  status
)
VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9, $10::jsonb, 'pending')
{conflict_clause}
RETURNING id, tenant_id, org_agent_type_id, launcher_principal_id,
          effective_principal_id, effective_clearance, trigger_kind,
          dbos_workflow_id, template_version_id, shield_call_ids, sandbox_id,
          status, result, created_at, started_at, terminal_at, updated_at,
          (xmax = 0) AS created_by_insert
""",
                    tenant_id,
                    org_agent_type_id,
                    launcher_principal_id,
                    effective_principal_id,
                    effective_clearance,
                    trigger_kind.value,
                    trigger_ref_json,
                    dbos_workflow_id,
                    template_version_id,
                    model_route_snapshot_json,
                ),
            )
        except Exception as exc:
            raise AgentRunStorageError("agent_run_create_failed") from exc
        return _record_from_row(row)

    async def mark_running(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        sandbox_id: UUID,
    ) -> AgentRunRecord:
        return await self._update_and_return(
            connection=connection,
            query="""
-- tenant_filter_required: running transition is scoped by tenant_id; RLS also applies.
UPDATE agent_run
SET sandbox_id = $3,
    status = 'running',
    started_at = COALESCE(started_at, now()),
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND (
    status = 'pending'
    OR (status = 'running' AND sandbox_id = $3)
  )
RETURNING id, tenant_id, org_agent_type_id, launcher_principal_id,
          effective_principal_id, effective_clearance, trigger_kind,
          dbos_workflow_id, template_version_id, shield_call_ids, sandbox_id,
          status, result, created_at, started_at, terminal_at, updated_at
""",
            args=(agent_run_id, tenant_id, sandbox_id),
            error_code="agent_run_mark_running_failed",
        )

    async def get_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
    ) -> AgentRunRecord:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: AgentRun lookup is scoped by tenant_id; RLS also applies.
SELECT id, tenant_id, org_agent_type_id, launcher_principal_id,
       effective_principal_id, effective_clearance, trigger_kind,
       dbos_workflow_id, template_version_id, shield_call_ids, sandbox_id,
       status, result, created_at, started_at, terminal_at, updated_at
FROM agent_run
WHERE id = $1
  AND tenant_id = $2
""",
                agent_run_id,
                tenant_id,
            ),
        )
        if row is None:
            raise AgentRunStorageError("agent_run_not_found")
        return _record_from_row(row)

    async def append_shield_call_id(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        shield_call_id: UUID,
    ) -> AgentRunRecord:
        return await self._update_and_return(
            connection=connection,
            query="""
-- tenant_filter_required: Shield evidence append is scoped by tenant_id; RLS also applies.
UPDATE agent_run
SET shield_call_ids = CASE
      WHEN $3 = ANY(shield_call_ids) THEN shield_call_ids
      ELSE array_append(shield_call_ids, $3)
    END,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
RETURNING id, tenant_id, org_agent_type_id, launcher_principal_id,
          effective_principal_id, effective_clearance, trigger_kind,
          dbos_workflow_id, template_version_id, shield_call_ids, sandbox_id,
          status, result, created_at, started_at, terminal_at, updated_at
""",
            args=(agent_run_id, tenant_id, shield_call_id),
            error_code="agent_run_append_shield_call_failed",
        )

    async def mark_terminal(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        status: AgentRunStatus,
        result_json: str = "{}",
    ) -> AgentRunRecord:
        if status not in {
            AgentRunStatus.SUCCEEDED,
            AgentRunStatus.FAILED,
            AgentRunStatus.CANCELLED,
        }:
            raise AgentRunStorageError("agent_run_terminal_status_required")
        return await self._update_and_return(
            connection=connection,
            query="""
-- tenant_filter_required: terminal transition is scoped by tenant_id; RLS also applies.
UPDATE agent_run
SET status = $3,
    result = $4::jsonb,
    terminal_at = COALESCE(terminal_at, now()),
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND status IN ('pending', 'running')
RETURNING id, tenant_id, org_agent_type_id, launcher_principal_id,
          effective_principal_id, effective_clearance, trigger_kind,
          dbos_workflow_id, template_version_id, shield_call_ids, sandbox_id,
          status, result, created_at, started_at, terminal_at, updated_at
""",
            args=(agent_run_id, tenant_id, status.value, result_json),
            error_code="agent_run_mark_terminal_failed",
        )

    async def _update_and_return(
        self,
        *,
        connection: asyncpg.Connection,
        query: str,
        args: tuple[object, ...],
        error_code: str,
    ) -> AgentRunRecord:
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(query, *args),  # pyright: ignore[reportUnknownMemberType]
            )
        except Exception as exc:
            raise AgentRunStorageError(error_code) from exc
        if row is None:
            raise AgentRunStorageError(error_code)
        return _record_from_row(row)


def _record_from_row(row: Mapping[str, Any]) -> AgentRunRecord:
    return AgentRunRecord(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        org_agent_type_id=cast(UUID, row["org_agent_type_id"]),
        launcher_principal_id=cast(UUID, row["launcher_principal_id"]),
        effective_principal_id=cast(UUID, row["effective_principal_id"]),
        effective_clearance=cast(Clearance, row["effective_clearance"]),
        trigger_kind=AgentTriggerKind(str(row["trigger_kind"])),
        dbos_workflow_id=str(row["dbos_workflow_id"]),
        template_version_id=cast(UUID, row["template_version_id"]),
        shield_call_ids=tuple(cast(tuple[UUID, ...], row["shield_call_ids"])),
        sandbox_id=cast(UUID | None, row["sandbox_id"]),
        status=AgentRunStatus(str(row["status"])),
        result=_json_dict(row["result"]),
        created_at=cast(datetime, row["created_at"]),
        started_at=cast(datetime | None, row["started_at"]),
        terminal_at=cast(datetime | None, row["terminal_at"]),
        updated_at=cast(datetime, row["updated_at"]),
        created_by_insert=bool(row.get("created_by_insert", True)),
    )


def _json_dict(value: object) -> dict[str, JsonValue]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, JsonValue], parsed)
        raise AgentRunStorageError("agent_run_result_not_object")
    if isinstance(value, dict):
        return cast(dict[str, JsonValue], value)
    raise AgentRunStorageError("agent_run_result_not_object")


__all__ = ["AgentRunRecord", "AgentRunStore"]
