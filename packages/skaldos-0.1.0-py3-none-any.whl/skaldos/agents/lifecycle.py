"""Sandbox lifecycle foundation for Slice 7 AgentRun execution."""

from __future__ import annotations

import hashlib
import hmac
import json
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any, Protocol, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.agents.contracts import AgentRunStatus, JsonValue, SandboxLifecycleKind
from skaldos.agents.errors import (
    AgentRunStorageError,
    AgentSandboxLifecycleError,
    AgentSandboxWebhookAuthError,
)
from skaldos.agents.run_store import AgentRunRecord, AgentRunStore
from skaldos.agents.sandbox_plan import SandboxSpawnPlan
from skaldos.events.outbox import insert_outbox_event

_TERMINAL_STATUSES = {
    AgentRunStatus.SUCCEEDED,
    AgentRunStatus.FAILED,
    AgentRunStatus.CANCELLED,
}


class SandboxRecord(BaseModel):
    """Content-free persisted sandbox projection."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: UUID
    tenant_id: UUID
    agent_run_id: UUID | None
    template_version_id: UUID
    provider: str
    provider_handle: str | None
    state: AgentRunStatus
    persistence: str
    egress_policy: dict[str, JsonValue]
    created_at: datetime
    started_at: datetime | None = None
    ended_at: datetime | None = None


class SandboxLifecycleResult(BaseModel):
    """Outcome of an idempotent lifecycle transition."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    agent_run: AgentRunRecord
    sandbox: SandboxRecord
    transitioned: bool
    outbox_event_type: str | None = None


class SandboxControlPlane(Protocol):
    """Provider-neutral control-plane boundary for sandbox kill."""

    async def kill(
        self,
        *,
        provider: str,
        provider_handle: str,
        reason: str,
    ) -> None:
        """Terminate or idempotently acknowledge a persisted sandbox handle."""


class RecordingSandboxControlPlane:
    """Dev/test control plane that records kill requests without providers."""

    def __init__(self) -> None:
        self.kills: list[tuple[str, str, str]] = []

    async def kill(
        self,
        *,
        provider: str,
        provider_handle: str,
        reason: str,
    ) -> None:
        self.kills.append((provider, provider_handle, reason))


class SandboxStore:
    """Asyncpg-backed sandbox row and lifecycle projection helpers."""

    async def create_pending_sandbox(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        spawn_plan: SandboxSpawnPlan,
        webhook_token: str,
    ) -> SandboxRecord:
        token_digest = hashlib.sha256(webhook_token.encode("utf-8")).digest()
        try:
            row = cast(
                Mapping[str, Any],
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
-- tenant_filter_required: sandbox insert carries tenant_id; RLS also applies.
INSERT INTO sandbox (
  tenant_id,
  agent_run_id,
  template_version_id,
  egress_policy,
  webhook_token_digest,
  persistence,
  state
)
VALUES ($1, $2, $3, $4::jsonb, $5, 'ephemeral', 'pending')
ON CONFLICT (agent_run_id) DO UPDATE
SET agent_run_id = EXCLUDED.agent_run_id
RETURNING id, tenant_id, agent_run_id, template_version_id, provider,
          provider_handle, state, persistence, egress_policy, created_at,
          started_at, ended_at
""",
                    tenant_id,
                    agent_run_id,
                    spawn_plan.template_version_id,
                    spawn_plan.egress_policy.model_dump_json(),
                    token_digest,
                ),
            )
        except Exception as exc:
            raise AgentSandboxLifecycleError("agent_sandbox_create_failed") from exc
        return _sandbox_from_row(row)

    async def persist_provider_handle(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        sandbox_id: UUID,
        provider_handle: str,
    ) -> SandboxRecord:
        if not provider_handle.strip():
            raise AgentSandboxLifecycleError("agent_sandbox_provider_handle_required")
        return await self._update_and_return(
            connection=connection,
            query="""
-- tenant_filter_required: handle update is scoped by tenant_id; RLS also applies.
UPDATE sandbox
SET provider_handle = COALESCE(provider_handle, $3),
    state = 'running',
    started_at = COALESCE(started_at, now())
WHERE id = $1
  AND tenant_id = $2
  AND (
    state = 'pending'
    OR (state = 'running' AND provider_handle = $3)
  )
RETURNING id, tenant_id, agent_run_id, template_version_id, provider,
          provider_handle, state, persistence, egress_policy, created_at,
          started_at, ended_at
""",
            args=(sandbox_id, tenant_id, provider_handle),
            error_code="agent_sandbox_handle_persist_failed",
        )

    async def load_for_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
    ) -> SandboxRecord:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: sandbox lookup is scoped by tenant_id; RLS also applies.
SELECT s.id, s.tenant_id, s.agent_run_id, s.template_version_id, s.provider,
       s.provider_handle, s.state, s.persistence, s.egress_policy, s.created_at,
       s.started_at, s.ended_at
FROM sandbox s
JOIN agent_run ar ON ar.sandbox_id = s.id
WHERE ar.id = $1
  AND ar.tenant_id = $2
  AND s.tenant_id = ar.tenant_id
""",
                agent_run_id,
                tenant_id,
            ),
        )
        if row is None:
            raise AgentSandboxLifecycleError("agent_sandbox_not_found")
        return _sandbox_from_row(row)

    async def load_for_webhook(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        sandbox_id: UUID,
    ) -> tuple[SandboxRecord, bytes]:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: webhook lookup is scoped by tenant_id; RLS also applies.
SELECT id, tenant_id, agent_run_id, template_version_id, provider,
       provider_handle, state, persistence, egress_policy, webhook_token_digest,
       created_at, started_at, ended_at
FROM sandbox
WHERE id = $1
  AND tenant_id = $2
""",
                sandbox_id,
                tenant_id,
            ),
        )
        if row is None:
            raise AgentSandboxLifecycleError("agent_sandbox_not_found")
        return _sandbox_from_row(row), bytes(cast(bytes, row["webhook_token_digest"]))

    async def mark_terminal(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        sandbox_id: UUID,
        status: AgentRunStatus,
    ) -> SandboxRecord:
        if status not in _TERMINAL_STATUSES:
            raise AgentSandboxLifecycleError("agent_sandbox_terminal_status_required")
        return await self._update_and_return(
            connection=connection,
            query="""
-- tenant_filter_required: sandbox terminal update is scoped by tenant_id; RLS also applies.
UPDATE sandbox
SET state = $3,
    ended_at = COALESCE(ended_at, now())
WHERE id = $1
  AND tenant_id = $2
  AND state = 'running'
  AND provider_handle IS NOT NULL
RETURNING id, tenant_id, agent_run_id, template_version_id, provider,
          provider_handle, state, persistence, egress_policy, created_at,
          started_at, ended_at
""",
            args=(sandbox_id, tenant_id, status.value),
            error_code="agent_sandbox_mark_terminal_failed",
        )

    async def _update_and_return(
        self,
        *,
        connection: asyncpg.Connection,
        query: str,
        args: tuple[object, ...],
        error_code: str,
    ) -> SandboxRecord:
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(query, *args),  # pyright: ignore[reportUnknownMemberType]
            )
        except Exception as exc:
            raise AgentSandboxLifecycleError(error_code) from exc
        if row is None:
            raise AgentSandboxLifecycleError(error_code)
        return _sandbox_from_row(row)


class AgentRunLifecycleService:
    """Persist sandbox handles, cancellations, webhooks, and outbox evidence."""

    def __init__(
        self,
        *,
        run_store: AgentRunStore | None = None,
        sandbox_store: SandboxStore | None = None,
        control_plane: SandboxControlPlane | None = None,
        webhook_signing_secret: str,
    ) -> None:
        if not webhook_signing_secret.strip():
            raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_signing_secret_required")
        self._run_store = run_store or AgentRunStore()
        self._sandbox_store = sandbox_store or SandboxStore()
        self._control_plane = control_plane or RecordingSandboxControlPlane()
        self._webhook_signing_secret = webhook_signing_secret

    async def record_spawned_sandbox(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        spawn_plan: SandboxSpawnPlan,
        webhook_token: str,
        provider_handle: str,
    ) -> SandboxLifecycleResult:
        sandbox = await self._sandbox_store.create_pending_sandbox(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            spawn_plan=spawn_plan,
            webhook_token=webhook_token,
        )
        sandbox = await self._sandbox_store.persist_provider_handle(
            connection=connection,
            tenant_id=tenant_id,
            sandbox_id=sandbox.id,
            provider_handle=provider_handle,
        )
        run = await self._run_store.mark_running(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            sandbox_id=sandbox.id,
        )
        return SandboxLifecycleResult(agent_run=run, sandbox=sandbox, transitioned=True)

    async def cancel_run(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        reason: str = "cancel_requested",
    ) -> SandboxLifecycleResult:
        run = await self._run_store.get_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        sandbox = await self._sandbox_store.load_for_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        if run.status in _TERMINAL_STATUSES:
            return SandboxLifecycleResult(agent_run=run, sandbox=sandbox, transitioned=False)
        if not sandbox.provider_handle:
            raise AgentSandboxLifecycleError("agent_sandbox_provider_handle_missing")
        await self._control_plane.kill(
            provider=sandbox.provider,
            provider_handle=sandbox.provider_handle,
            reason=reason,
        )
        result = await self._terminal_transition(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
            sandbox_id=sandbox.id,
            status=AgentRunStatus.CANCELLED,
        )
        return result

    async def accept_webhook(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        sandbox_id: UUID,
        event_kind: SandboxLifecycleKind,
        signature: str,
        token: str,
    ) -> SandboxLifecycleResult:
        sandbox, token_digest = await self._sandbox_store.load_for_webhook(
            connection=connection,
            tenant_id=tenant_id,
            sandbox_id=sandbox_id,
        )
        _verify_webhook_token(token=token, expected_digest=token_digest)
        _verify_webhook_signature(
            signing_secret=self._webhook_signing_secret,
            token=token,
            signature=signature,
            tenant_id=tenant_id,
            sandbox_id=sandbox_id,
            event_kind=event_kind,
        )
        if sandbox.agent_run_id is None:
            raise AgentSandboxLifecycleError("agent_sandbox_run_missing")
        status = lifecycle_kind_to_status(event_kind)
        if status is AgentRunStatus.RUNNING:
            run = await self._run_store.get_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=sandbox.agent_run_id,
            )
            return SandboxLifecycleResult(agent_run=run, sandbox=sandbox, transitioned=False)
        return await self._terminal_transition(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=sandbox.agent_run_id,
            sandbox_id=sandbox.id,
            status=status,
        )

    async def _terminal_transition(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        agent_run_id: UUID,
        sandbox_id: UUID,
        status: AgentRunStatus,
    ) -> SandboxLifecycleResult:
        prior = await self._run_store.get_run(
            connection=connection,
            tenant_id=tenant_id,
            agent_run_id=agent_run_id,
        )
        if prior.status in _TERMINAL_STATUSES:
            sandbox = await self._sandbox_store.load_for_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
            )
            return SandboxLifecycleResult(agent_run=prior, sandbox=sandbox, transitioned=False)

        try:
            sandbox = await self._sandbox_store.mark_terminal(
                connection=connection,
                tenant_id=tenant_id,
                sandbox_id=sandbox_id,
                status=status,
            )
            run = await self._run_store.mark_terminal(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                status=status,
            )
        except (AgentRunStorageError, AgentSandboxLifecycleError):
            run = await self._run_store.get_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
            )
            sandbox = await self._sandbox_store.load_for_run(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
            )
            if run.status in _TERMINAL_STATUSES:
                return SandboxLifecycleResult(agent_run=run, sandbox=sandbox, transitioned=False)
            raise
        event_type = lifecycle_event_type(status)
        outbox_event_type: str | None = event_type
        try:
            await emit_agent_run_outbox_event(
                connection=connection,
                tenant_id=tenant_id,
                agent_run_id=agent_run_id,
                event_type=event_type,
                clearance=run.effective_clearance,
            )
        except AgentSandboxLifecycleError:
            outbox_event_type = None
        return SandboxLifecycleResult(
            agent_run=run,
            sandbox=sandbox,
            transitioned=True,
            outbox_event_type=outbox_event_type,
        )


def lifecycle_kind_to_status(kind: SandboxLifecycleKind) -> AgentRunStatus:
    if kind is SandboxLifecycleKind.STARTED:
        return AgentRunStatus.RUNNING
    if kind is SandboxLifecycleKind.ENDED:
        return AgentRunStatus.SUCCEEDED
    if kind is SandboxLifecycleKind.ERRORED:
        return AgentRunStatus.FAILED
    if kind is SandboxLifecycleKind.CANCELLED:
        return AgentRunStatus.CANCELLED
    raise AgentSandboxLifecycleError("agent_sandbox_lifecycle_unknown")


def lifecycle_event_type(status: AgentRunStatus) -> str:
    if status is AgentRunStatus.SUCCEEDED:
        return "agent.run.completed"
    if status is AgentRunStatus.FAILED:
        return "agent.run.errored"
    if status is AgentRunStatus.CANCELLED:
        return "agent.run.cancelled"
    raise AgentSandboxLifecycleError("agent_run_terminal_status_required")


def sandbox_webhook_signature(
    *,
    signing_secret: str,
    token: str,
    tenant_id: UUID,
    sandbox_id: UUID,
    event_kind: SandboxLifecycleKind,
) -> str:
    if not signing_secret.strip():
        raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_signing_secret_required")
    message = f"{tenant_id}.{sandbox_id}.{event_kind.value}.{token}".encode()
    return hmac.new(signing_secret.encode(), message, hashlib.sha256).hexdigest()


async def emit_agent_run_outbox_event(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    agent_run_id: UUID,
    event_type: str,
    clearance: str,
) -> None:
    occurred_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    try:
        async with connection.transaction():  # pyright: ignore[reportUnknownMemberType]
            await insert_outbox_event(
                connection=connection,
                envelope={
                    "id_as_handle": True,
                    "subject_id": str(agent_run_id),
                    "subject_type": "agent_run",
                    "event_type": event_type,
                    "tenant_id": str(tenant_id),
                    "occurred_at": occurred_at,
                    "context_of_validity": {
                        "tenant": str(tenant_id),
                        "classification": clearance,
                        "vertical": "foundation",
                        "ontology_version": "slice-7",
                        "valid_from": "2026-05-12T00:00:00Z",
                        "valid_to": None,
                    },
                    "intent": "directive",
                },
            )
    except Exception as exc:
        raise AgentSandboxLifecycleError("agent_run_outbox_emit_failed") from exc


def _verify_webhook_token(*, token: str, expected_digest: bytes) -> None:
    actual = hashlib.sha256(token.encode("utf-8")).digest()
    if not hmac.compare_digest(actual, expected_digest):
        raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_token_invalid")


def _verify_webhook_signature(
    *,
    signing_secret: str,
    token: str,
    signature: str,
    tenant_id: UUID,
    sandbox_id: UUID,
    event_kind: SandboxLifecycleKind,
) -> None:
    expected = sandbox_webhook_signature(
        signing_secret=signing_secret,
        token=token,
        tenant_id=tenant_id,
        sandbox_id=sandbox_id,
        event_kind=event_kind,
    )
    if not hmac.compare_digest(signature, expected):
        raise AgentSandboxWebhookAuthError("agent_sandbox_webhook_signature_invalid")


def _sandbox_from_row(row: Mapping[str, Any]) -> SandboxRecord:
    return SandboxRecord(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        agent_run_id=cast(UUID | None, row["agent_run_id"]),
        template_version_id=cast(UUID, row["template_version_id"]),
        provider=str(row["provider"]),
        provider_handle=cast(str | None, row["provider_handle"]),
        state=AgentRunStatus(str(row["state"])),
        persistence=str(row["persistence"]),
        egress_policy=_json_dict(row["egress_policy"]),
        created_at=cast(datetime, row["created_at"]),
        started_at=cast(datetime | None, row["started_at"]),
        ended_at=cast(datetime | None, row["ended_at"]),
    )


def _json_dict(value: object) -> dict[str, JsonValue]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, JsonValue], parsed)
        raise AgentRunStorageError("agent_sandbox_json_not_object")
    if isinstance(value, dict):
        return cast(dict[str, JsonValue], value)
    raise AgentRunStorageError("agent_sandbox_json_not_object")


__all__ = [
    "AgentRunLifecycleService",
    "RecordingSandboxControlPlane",
    "SandboxControlPlane",
    "SandboxLifecycleResult",
    "SandboxRecord",
    "SandboxStore",
    "lifecycle_event_type",
    "lifecycle_kind_to_status",
    "sandbox_webhook_signature",
]
