"""Graph output correlation helpers for Slice 7 execution traces."""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from skaldos.agents.trace import ExecutionTracePayload
from skaldos.middleware import Principal

_VALIDATED_GRAPH_OUTPUT_TOKEN = object()


class AgentGraphOutputCorrelationError(ValueError):
    """Content-free graph output correlation failure."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class AgentGraphWriteOutput(BaseModel):
    """Safe graph write handles returned by the graph chokepoint."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    graph_write_id: UUID
    authored_by_principal_id: UUID
    status: Literal["staged", "applied"]
    output_node_ids: tuple[UUID, ...] = ()
    grounding_node_ids: tuple[UUID, ...] = ()
    grounding_edge_ids: tuple[UUID, ...] = ()
    provenance_role: str | None = Field(default=None, min_length=1, max_length=128)


class ValidatedGraphOutputTrace:
    """ExecutionTrace payload whose graph output refs passed author validation."""

    __slots__ = ("trace",)

    def __init__(
        self,
        *,
        trace: ExecutionTracePayload,
        _token: object | None = None,
    ) -> None:
        if _token is not _VALIDATED_GRAPH_OUTPUT_TOKEN:
            raise AgentGraphOutputCorrelationError("graph_output_trace_validation_required")
        self.trace = trace


def attach_graph_output_to_trace(
    *,
    trace: ExecutionTracePayload,
    graph_output: AgentGraphWriteOutput,
    principal: Principal,
) -> ValidatedGraphOutputTrace:
    """Return a trace payload with graph write/output handles attached.

    The helper verifies the graph write is authored by the same effective
    agent Principal before adding graph handles to the trace. It does not
    inspect graph bodies or claim text.
    """

    if principal.kind != "agent":
        raise AgentGraphOutputCorrelationError("graph_output_agent_principal_required")
    if graph_output.authored_by_principal_id != principal.id:
        raise AgentGraphOutputCorrelationError("graph_output_principal_mismatch")

    return ValidatedGraphOutputTrace(
        trace=trace.model_copy(
            update={
                "graph_write_ids": _dedupe((*trace.graph_write_ids, graph_output.graph_write_id)),
                "output_node_ids": _dedupe((*trace.output_node_ids, *graph_output.output_node_ids)),
                "input_node_ids": _dedupe(
                    (*trace.input_node_ids, *graph_output.grounding_node_ids)
                ),
            }
        ),
        _token=_VALIDATED_GRAPH_OUTPUT_TOKEN,
    )


def _dedupe(values: tuple[UUID, ...]) -> tuple[UUID, ...]:
    return tuple(dict.fromkeys(values))


__all__ = [
    "AgentGraphOutputCorrelationError",
    "AgentGraphWriteOutput",
    "attach_graph_output_to_trace",
]
