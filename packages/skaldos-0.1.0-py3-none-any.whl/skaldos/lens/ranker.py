"""Pure Slice 6 lens ranking over already-visible candidates."""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .definition import LensDefinition, LensRule, LensSignalKind, LensSort

LensCandidateKind = Literal["node", "document", "node_chunk", "chunk"]

DEFAULT_LENS_SORT: tuple[LensSort, ...] = (
    LensSort(by="lens_score", direction="desc"),
    LensSort(by="upstream_rank", direction="asc"),
    LensSort(by="created_at", direction="desc"),
    LensSort(by="candidate_id", direction="asc"),
)


class LensCandidate(BaseModel):
    """Minimal visible candidate contract consumed by the pure ranker."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    candidate_id: str = Field(min_length=1, max_length=128)
    candidate_kind: LensCandidateKind
    tenant_id: str = Field(min_length=1, max_length=128)
    classification: str = Field(min_length=1, max_length=16)
    created_at: datetime
    upstream_rank: int = Field(ge=1)
    upstream_score: float | None = None
    type_id: str | None = Field(default=None, min_length=1, max_length=128)
    domain_signals: tuple[str, ...] = ()
    topic_signals: tuple[str, ...] = ()
    tag_signals: tuple[str, ...] = ()
    recency_signal: str | None = Field(default=None, min_length=1, max_length=128)

    @field_validator("created_at")
    @classmethod
    def _created_at_is_timezone_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("candidate created_at must be timezone-aware")
        return value

    @field_validator("upstream_score")
    @classmethod
    def _upstream_score_is_finite(cls, value: float | None) -> float | None:
        if value is not None and not math.isfinite(value):
            raise ValueError("candidate upstream_score must be finite")
        return value


class LensRuleContribution(BaseModel):
    """Content-free ranking explanation for one matched rule."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    rule_id: str
    contribution: float


class LensRankedCandidate(BaseModel):
    """Ranker output preserving the original visible candidate value."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    candidate: LensCandidate
    lens_score: float
    final_rank: int = Field(ge=1)
    contributions: tuple[LensRuleContribution, ...] = ()

    @field_validator("lens_score")
    @classmethod
    def _lens_score_is_finite(cls, value: float) -> float:
        if not math.isfinite(value):
            raise ValueError("lens_score must be finite")
        return value


@dataclass(frozen=True)
class _ScoredCandidate:
    candidate: LensCandidate
    lens_score: float
    contributions: tuple[LensRuleContribution, ...]
    input_index: int


def rank_visible_candidates(
    candidates: tuple[LensCandidate, ...],
    lens_definition: LensDefinition | None = None,
) -> tuple[LensRankedCandidate, ...]:
    """Rank supplied visible candidates without changing membership.

    ``lens_definition=None`` is the neutral omitted-lens behavior. The ranker
    never loads rows, computes corpus statistics, filters candidates, or applies
    limits; callers own visibility and pagination before/after this pure step.
    """

    if not candidates:
        return ()

    scored = tuple(
        _score_candidate(candidate, lens_definition, input_index=index)
        for index, candidate in enumerate(candidates)
    )
    ranked = _sort_scored_candidates(scored, lens_definition)

    return tuple(
        LensRankedCandidate(
            candidate=item.candidate,
            lens_score=item.lens_score,
            final_rank=index,
            contributions=item.contributions,
        )
        for index, item in enumerate(ranked, start=1)
    )


def _score_candidate(
    candidate: LensCandidate,
    lens_definition: LensDefinition | None,
    *,
    input_index: int,
) -> _ScoredCandidate:
    if lens_definition is None:
        return _ScoredCandidate(candidate, 0.0, (), input_index)

    contributions: list[LensRuleContribution] = []
    score = 0.0
    for rule in lens_definition.rules:
        contribution = _rule_contribution(candidate, rule)
        if contribution == 0.0:
            continue
        score += contribution
        contributions.append(LensRuleContribution(rule_id=rule.rule_id, contribution=contribution))

    return _ScoredCandidate(candidate, score, tuple(contributions), input_index)


def _rule_contribution(candidate: LensCandidate, rule: LensRule) -> float:
    if _candidate_matches_signal(candidate, rule.signal.kind, rule.signal.value):
        return rule.weight
    return 0.0


def _candidate_matches_signal(
    candidate: LensCandidate,
    signal_kind: LensSignalKind,
    signal_value: str,
) -> bool:
    if signal_kind == "type":
        return candidate.type_id == signal_value
    if signal_kind == "domain":
        return signal_value in candidate.domain_signals
    if signal_kind == "topic":
        return signal_value in candidate.topic_signals
    if signal_kind == "tag":
        return signal_value in candidate.tag_signals
    if signal_kind == "recency":
        return candidate.recency_signal == signal_value
    return False


def _sort_scored_candidates(
    scored: tuple[_ScoredCandidate, ...],
    lens_definition: LensDefinition | None,
) -> tuple[_ScoredCandidate, ...]:
    sort_specs = _effective_sort(lens_definition)
    ranked = list(scored)

    ranked.sort(key=lambda item: item.input_index)
    for sort_spec in reversed(sort_specs):
        ranked.sort(
            key=lambda item, by=sort_spec.by: _sort_value(item, by),
            reverse=sort_spec.direction == "desc",
        )

    return tuple(ranked)


def _effective_sort(lens_definition: LensDefinition | None) -> tuple[LensSort, ...]:
    requested = lens_definition.sort if lens_definition is not None else ()
    if not requested:
        return DEFAULT_LENS_SORT

    present = {sort.by for sort in requested}
    suffix = tuple(sort for sort in DEFAULT_LENS_SORT if sort.by not in present)
    return (*requested, *suffix)


def _sort_value(
    item: _ScoredCandidate,
    by: Literal["lens_score", "upstream_rank", "created_at", "candidate_id"],
) -> float | int | datetime | str:
    if by == "lens_score":
        return item.lens_score
    if by == "upstream_rank":
        return item.candidate.upstream_rank
    if by == "created_at":
        return item.candidate.created_at
    return item.candidate.candidate_id
