"""Tenant-scoped lens definition persistence and reference validation."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.lens.definition import (
    LensDefinition,
    LensDefinitionValidationError,
    LensValidationReason,
    validate_lens_definition_payload,
)
from skaldos.middleware import Principal


class LensDefinitionRecord(BaseModel):
    """Persisted lens definition row exposed by the API."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    name: str
    definition: LensDefinition
    created_by_principal_id: UUID
    created_at: str
    updated_at: str
    archived_at: str | None = None


class LensDefinitionNotFoundError(LookupError):
    """Lens definition was absent, archived, or invisible under RLS."""


class LensDefinitionStorageError(RuntimeError):
    """Unexpected database failure while storing lens definitions."""


class LensDefinitionStore:
    """Validate and persist Slice 6 table-backed lenses."""

    async def create_lens(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        tenant_id: UUID,
        name: str,
        definition_payload: object,
    ) -> LensDefinitionRecord:
        definition = validate_lens_definition_payload(definition_payload)
        await _validate_references(
            connection=connection, tenant_id=tenant_id, definition=definition
        )
        try:
            row = cast(
                Mapping[str, Any],
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
INSERT INTO lens_definitions (
  tenant_id, name, definition_version, definition, created_by_principal_id
)
VALUES ($1, $2, $3, $4::jsonb, $5)
RETURNING id, tenant_id, name, definition, created_by_principal_id,
          created_at::text, updated_at::text, archived_at::text
""",
                    tenant_id,
                    name,
                    definition.definition_version,
                    definition.model_dump_json(),
                    principal.id,
                ),
            )
        except Exception as exc:
            raise LensDefinitionStorageError("lens_create_failed") from exc
        return _record_from_row(row)

    async def update_lens(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        lens_id: UUID,
        name: str,
        definition_payload: object,
    ) -> LensDefinitionRecord:
        definition = validate_lens_definition_payload(definition_payload)
        await _validate_references(
            connection=connection, tenant_id=tenant_id, definition=definition
        )
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE lens_definitions
SET name = $3,
    definition_version = $4,
    definition = $5::jsonb,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
RETURNING id, tenant_id, name, definition, created_by_principal_id,
          created_at::text, updated_at::text, archived_at::text
""",
                    lens_id,
                    tenant_id,
                    name,
                    definition.definition_version,
                    definition.model_dump_json(),
                ),
            )
        except Exception as exc:
            raise LensDefinitionStorageError("lens_update_failed") from exc
        if row is None:
            raise LensDefinitionNotFoundError("lens_not_found")
        return _record_from_row(row)

    async def archive_lens(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        lens_id: UUID,
    ) -> LensDefinitionRecord:
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE lens_definitions
SET archived_at = COALESCE(archived_at, now()),
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
RETURNING id, tenant_id, name, definition, created_by_principal_id,
          created_at::text, updated_at::text, archived_at::text
""",
                    lens_id,
                    tenant_id,
                ),
            )
        except Exception as exc:
            raise LensDefinitionStorageError("lens_archive_failed") from exc
        if row is None:
            raise LensDefinitionNotFoundError("lens_not_found")
        return _record_from_row(row)

    async def get_lens(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        lens_id: UUID,
    ) -> LensDefinitionRecord:
        row = await _fetch_lens(connection=connection, tenant_id=tenant_id, lens_id=lens_id)
        if row is None:
            raise LensDefinitionNotFoundError("lens_not_found")
        return _record_from_row(row)

    async def list_lenses(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        include_archived: bool = False,
    ) -> tuple[LensDefinitionRecord, ...]:
        try:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    """
SELECT id, tenant_id, name, definition, created_by_principal_id,
       created_at::text, updated_at::text, archived_at::text
FROM lens_definitions
WHERE tenant_id = $1
  AND ($2::boolean OR archived_at IS NULL)
ORDER BY archived_at NULLS FIRST, created_at DESC, id ASC
""",
                    tenant_id,
                    include_archived,
                ),
            )
        except Exception as exc:
            raise LensDefinitionStorageError("lens_list_failed") from exc
        return tuple(_record_from_row(row) for row in rows)


async def _fetch_lens(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    lens_id: UUID,
) -> Mapping[str, Any] | None:
    try:
        return cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT id, tenant_id, name, definition, created_by_principal_id,
       created_at::text, updated_at::text, archived_at::text
FROM lens_definitions
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
""",
                lens_id,
                tenant_id,
            ),
        )
    except Exception as exc:
        raise LensDefinitionStorageError("lens_load_failed") from exc


async def _validate_references(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    definition: LensDefinition,
) -> None:
    for rule in definition.rules:
        if rule.signal.kind == "type":
            await _validate_type_reference(
                connection=connection,
                tenant_id=tenant_id,
                value=rule.signal.value,
            )
        if rule.signal.kind == "tag":
            await _validate_tag_reference(
                connection=connection,
                tenant_id=tenant_id,
                value=rule.signal.value,
            )


async def _validate_type_reference(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    value: str,
) -> None:
    reference_id = _parse_reference_uuid(value)
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT o.tenant_id, ot.lifecycle_state
FROM ontology_type ot
JOIN ontology_version ov ON ov.id = ot.ontology_version_id
JOIN ontology o ON o.id = ov.ontology_id
WHERE ot.id = $1
""",
            reference_id,
        ),
    )
    if row is None:
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_NOT_FOUND,
            "lens type reference was not found",
        )
    row_tenant_id = row["tenant_id"]
    if row_tenant_id is not None and row_tenant_id != tenant_id:
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_CROSS_TENANT,
            "lens type reference belongs to another tenant",
        )
    if row["lifecycle_state"] != "active":
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_STALE,
            "lens type reference is not active",
        )


async def _validate_tag_reference(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    value: str,
) -> None:
    reference_id = _parse_reference_uuid(value)
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT tenant_id, lifecycle_state
FROM tag_definitions
WHERE id = $1
""",
            reference_id,
        ),
    )
    if row is None or row["tenant_id"] is None:
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_NOT_FOUND,
            "lens tag reference was not found",
        )
    if row["tenant_id"] != tenant_id:
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_CROSS_TENANT,
            "lens tag reference belongs to another tenant",
        )
    if row["lifecycle_state"] != "active":
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_STALE,
            "lens tag reference is not active",
        )


def _parse_reference_uuid(value: str) -> UUID:
    try:
        return UUID(value)
    except ValueError as exc:
        raise LensDefinitionValidationError(
            LensValidationReason.REFERENCE_NOT_FOUND,
            "lens reference must be a UUID",
        ) from exc


def _record_from_row(row: Mapping[str, Any]) -> LensDefinitionRecord:
    definition = row["definition"]
    definition_payload = json.loads(definition) if isinstance(definition, str) else definition
    return LensDefinitionRecord(
        id=row["id"],
        tenant_id=row["tenant_id"],
        name=str(row["name"]),
        definition=LensDefinition.model_validate(definition_payload),
        created_by_principal_id=row["created_by_principal_id"],
        created_at=str(row["created_at"]),
        updated_at=str(row["updated_at"]),
        archived_at=str(row["archived_at"]) if row["archived_at"] is not None else None,
    )


__all__ = [
    "LensDefinitionNotFoundError",
    "LensDefinitionRecord",
    "LensDefinitionStorageError",
    "LensDefinitionStore",
]
