"""Lens definition contracts for Slice 6 read-path ranking."""

from __future__ import annotations

from .definition import (
    LENS_DEFINITION_VERSION,
    MAX_LENS_RULES,
    MAX_LENS_TOTAL_ABS_WEIGHT,
    MAX_LENS_WEIGHT,
    LensDefinition,
    LensDefinitionValidationError,
    LensRule,
    LensSignal,
    LensSort,
    LensValidationReason,
    validate_lens_definition_payload,
)
from .ranker import (
    DEFAULT_LENS_SORT,
    LensCandidate,
    LensRankedCandidate,
    LensRuleContribution,
    rank_visible_candidates,
)
from .store import (
    LensDefinitionNotFoundError,
    LensDefinitionRecord,
    LensDefinitionStorageError,
    LensDefinitionStore,
)

__all__ = [
    "LENS_DEFINITION_VERSION",
    "LensDefinition",
    "LensDefinitionNotFoundError",
    "LensDefinitionRecord",
    "LensDefinitionStorageError",
    "LensDefinitionStore",
    "LensDefinitionValidationError",
    "LensCandidate",
    "LensRankedCandidate",
    "LensRule",
    "LensRuleContribution",
    "LensSignal",
    "LensSort",
    "LensValidationReason",
    "MAX_LENS_RULES",
    "MAX_LENS_TOTAL_ABS_WEIGHT",
    "MAX_LENS_WEIGHT",
    "DEFAULT_LENS_SORT",
    "rank_visible_candidates",
    "validate_lens_definition_payload",
]
