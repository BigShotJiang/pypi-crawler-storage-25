"""Strict lens definition models and forbidden-gating validation.

Slice 6 lenses are ranking contracts only. They may weight, boost, sort, and
rerank candidates already made visible by the read chokepoint; they may not
encode filtering, ACL, customer-scope, classification, or post-ranking limit
semantics.

References: canon §3.3, Slice 6 master-plan Lens Ranking Contract.
"""

from __future__ import annotations

import math
import re
from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import Literal, cast

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

LENS_DEFINITION_VERSION: Literal[1] = 1
MAX_LENS_WEIGHT = 10.0
MAX_LENS_RULES = 50
MAX_LENS_TOTAL_ABS_WEIGHT = 100.0

LensRuleKind = Literal["weight", "boost"]
LensSignalKind = Literal["domain", "type", "topic", "tag", "recency"]
LensSortKey = Literal["lens_score", "upstream_rank", "created_at", "candidate_id"]
LensSortDirection = Literal["asc", "desc"]

_CAMEL_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_TOKEN_SPLIT = re.compile(r"[^A-Za-z0-9]+")
_NON_ALNUM = re.compile(r"[^A-Za-z0-9]+")

_GATING_TOKENS = frozenset(
    {
        "acl",
        "allow",
        "allowed",
        "deny",
        "disallow",
        "exclude",
        "filter",
        "gate",
        "gating",
        "hide",
        "limit",
        "mustnot",
        "only",
        "permission",
        "permissions",
        "policy",
        "rls",
        "skip",
        "take",
        "visible",
        "visibility",
        "where",
        "without",
    },
)
_GATING_COMPACT = frozenset(
    {
        "denylist",
        "excludetypes",
        "hideengineeringfromsales",
        "mustnotmatch",
        "notin",
        "onlyshow",
        "postrankinglimit",
        "topk",
    },
)
_CUSTOMER_TOKENS = frozenset({"customer", "customers", "prospect"})
_CUSTOMER_COMPACT = frozenset(
    {
        "customerid",
        "customerscope",
        "customervisible",
        "customervisibility",
        "enforcecustomerscope",
    },
)
_CLASSIFICATION_TOKENS = frozenset({"classification", "classifications", "clearance"})
_CLASSIFICATION_COMPACT = frozenset(
    {
        "classificationgate",
        "classificationsignal",
        "enforceclassification",
        "maxclearance",
        "securityclassification",
    },
)


class LensValidationReason(StrEnum):
    """Stable reason codes for lens definition validation failures."""

    DEFINITION_MALFORMED = "lens_definition_malformed"
    WEIGHT_INVALID = "lens_weight_invalid"
    REFERENCE_NOT_FOUND = "lens_reference_not_found"
    REFERENCE_CROSS_TENANT = "lens_reference_cross_tenant"
    REFERENCE_STALE = "lens_reference_stale"
    GATING_SEMANTICS_FORBIDDEN = "lens_gating_semantics_forbidden"
    CUSTOMER_SCOPE_FORBIDDEN = "lens_customer_scope_forbidden"
    CLASSIFICATION_GATE_FORBIDDEN = "lens_classification_gate_forbidden"
    CANDIDATE_KIND_UNSUPPORTED = "lens_candidate_kind_unsupported"


class LensDefinitionValidationError(ValueError):
    """Validation error with the public stable reason code attached."""

    def __init__(self, reason_code: LensValidationReason, detail: str) -> None:
        super().__init__(reason_code.value)
        self.reason_code = reason_code
        self.detail = detail


class LensSignal(BaseModel):
    """A positive or negative ranking feature, never a visibility predicate."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: LensSignalKind
    value: str = Field(min_length=1, max_length=128)


class LensRule(BaseModel):
    """A bounded additive ranking rule."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    rule_id: str = Field(min_length=1, max_length=64)
    kind: LensRuleKind
    signal: LensSignal
    weight: float = Field(ge=-MAX_LENS_WEIGHT, le=MAX_LENS_WEIGHT)

    @field_validator("weight")
    @classmethod
    def _weight_is_finite(cls, value: float) -> float:
        if not math.isfinite(value):
            raise ValueError("lens weight must be finite")
        return value


class LensSort(BaseModel):
    """Deterministic sort key allowed after visible candidates exist."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    by: LensSortKey
    direction: LensSortDirection = "desc"


class LensDefinition(BaseModel):
    """Versioned Slice 6 lens definition shape.

    The model deliberately has no fields named ``filter``, ``where``, ``limit``,
    ``classification``, or ``customer_visible``. Unknown fields are rejected and
    raw-payload validation maps forbidden semantics to stable reason codes.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    definition_version: Literal[1] = LENS_DEFINITION_VERSION
    rules: tuple[LensRule, ...] = Field(default=(), max_length=MAX_LENS_RULES)
    sort: tuple[LensSort, ...] = ()

    @model_validator(mode="after")
    def _total_weight_is_bounded(self) -> LensDefinition:
        total_abs_weight = sum(abs(rule.weight) for rule in self.rules)
        if total_abs_weight > MAX_LENS_TOTAL_ABS_WEIGHT:
            raise ValueError("lens total absolute rule weight is too large")
        return self


def validate_lens_definition_payload(payload: object) -> LensDefinition:
    """Validate untrusted lens JSON and return the strict contract model.

    Forbidden semantics are scanned before Pydantic shape validation so
    recursive or disguised ACL/filter attempts get stable security reason codes.
    """

    if not isinstance(payload, Mapping):
        raise LensDefinitionValidationError(
            LensValidationReason.DEFINITION_MALFORMED,
            "lens definition root must be an object",
        )

    _reject_forbidden_semantics(cast(Mapping[object, object], payload))
    try:
        return LensDefinition.model_validate(payload)
    except ValidationError as exc:
        reason = _reason_for_pydantic_error(exc)
        raise LensDefinitionValidationError(reason, "lens definition shape is invalid") from exc


def _reason_for_pydantic_error(exc: ValidationError) -> LensValidationReason:
    for error in exc.errors():
        location = tuple(str(part) for part in error.get("loc", ()))
        if (
            ("weight" in location and error.get("type") != "missing")
            or location == ("rules",)
            or str(error.get("msg", "")).startswith("Value error, lens total absolute rule weight")
        ):
            return LensValidationReason.WEIGHT_INVALID
    return LensValidationReason.DEFINITION_MALFORMED


def _reject_forbidden_semantics(value: object) -> None:
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        for raw_key, child in mapping.items():
            if isinstance(raw_key, str):
                _reject_forbidden_text(raw_key, is_key=True)
            _reject_forbidden_semantics(child)
    elif isinstance(value, str):
        _reject_forbidden_text(value, is_key=False)
    elif isinstance(value, Sequence) and not isinstance(value, bytes | bytearray):
        sequence = cast(Sequence[object], value)
        for child in sequence:
            _reject_forbidden_semantics(child)


def _reject_forbidden_text(text: str, *, is_key: bool) -> None:
    normalized = _normalize_text(text)
    compact = _compact_text(text)

    if compact in _CLASSIFICATION_COMPACT or (
        "classification" in normalized or (is_key and normalized & _CLASSIFICATION_TOKENS)
    ):
        raise LensDefinitionValidationError(
            LensValidationReason.CLASSIFICATION_GATE_FORBIDDEN,
            "classification cannot be used in Slice 6 lens definitions",
        )
    if compact in _CUSTOMER_COMPACT or (is_key and normalized & _CUSTOMER_TOKENS):
        raise LensDefinitionValidationError(
            LensValidationReason.CUSTOMER_SCOPE_FORBIDDEN,
            "customer scope cannot be enforced by lens definitions",
        )
    if compact in _GATING_COMPACT or normalized & _GATING_TOKENS:
        raise LensDefinitionValidationError(
            LensValidationReason.GATING_SEMANTICS_FORBIDDEN,
            "lens definitions may rank only and cannot gate visible candidates",
        )


def _normalize_text(text: str) -> set[str]:
    camel_spaced = _CAMEL_BOUNDARY.sub(" ", text)
    return {token.lower() for token in _TOKEN_SPLIT.split(camel_spaced) if token}


def _compact_text(text: str) -> str:
    return _NON_ALNUM.sub("", text).lower()
