"""Canonical Shield client contract for SkaldOS API call sites."""

from __future__ import annotations

from typing import Protocol
from uuid import UUID

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from skaldos_shield.contracts import (
    CanonicalShieldRequest,
    CanonicalShieldResponse,
    LatencyMode,
    MessagePart,
    MessagePartType,
    ModelHint,
    RequestedRoute,
    RequestShape,
    SensitivityTier,
    ShieldBudgetConstraints,
    ShieldLatencyConstraints,
    ShieldMessage,
    ShieldMessageRole,
    TaskClass,
)


class ShieldCallContext(BaseModel):
    """Explicit call-site metadata required for every Shield request.

    API/Auth0 call sites may still provide ``organization_id``. This boundary
    model normalizes that product name to the storage/service tenant name.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    tenant_id: UUID = Field(validation_alias=AliasChoices("tenant_id", "organization_id"))
    principal_id: UUID
    task_class: TaskClass
    latency_mode: LatencyMode
    stream: bool
    requested_sensitivity: SensitivityTier | None = None
    redaction_session_id: UUID | None = None
    agent_run_id: UUID | None = None
    tool_call_id: UUID | None = None
    trace_id: str | None = None
    span_id: str | None = None
    parent_shield_call_id: UUID | None = None
    model_hint: ModelHint | None = None
    requested_route: RequestedRoute | None = None
    budget: ShieldBudgetConstraints | None = None
    latency: ShieldLatencyConstraints | None = None

    @property
    def organization_id(self) -> UUID:
        """Compatibility alias for API/Auth0-facing callers."""

        return self.tenant_id


class ShieldCanonicalTransport(Protocol):
    """Transport boundary for canonical Shield requests."""

    async def complete(self, request: CanonicalShieldRequest) -> CanonicalShieldResponse:
        """Send a canonical Shield request."""
        ...


class ShieldClient:
    """Build and submit canonical Shield requests for API call sites."""

    def __init__(self, transport: ShieldCanonicalTransport) -> None:
        self._transport = transport

    async def complete(
        self,
        *,
        context: ShieldCallContext,
        messages: tuple[ShieldMessage, ...],
    ) -> CanonicalShieldResponse:
        """Submit an explicit canonical Shield request."""

        return await self._transport.complete(
            build_canonical_shield_request(context=context, messages=messages)
        )


def build_canonical_shield_request(
    *,
    context: ShieldCallContext,
    messages: tuple[ShieldMessage, ...],
) -> CanonicalShieldRequest:
    """Build a canonical-only Shield request from explicit call-site metadata."""

    return CanonicalShieldRequest(
        organization_id=context.tenant_id,
        principal_id=context.principal_id,
        redaction_session_id=context.redaction_session_id,
        agent_run_id=context.agent_run_id,
        tool_call_id=context.tool_call_id,
        trace_id=context.trace_id,
        span_id=context.span_id,
        parent_shield_call_id=context.parent_shield_call_id,
        task_class=context.task_class,
        request_shape=RequestShape.CANONICAL,
        latency_mode=context.latency_mode,
        requested_sensitivity=context.requested_sensitivity,
        stream=context.stream,
        messages=list(messages),
        model_hint=context.model_hint,
        requested_route=context.requested_route,
        budget=context.budget,
        latency=context.latency,
    )


def text_message(role: ShieldMessageRole, text: str) -> ShieldMessage:
    """Create one canonical text message for call-site tests and simple calls."""

    part_type = (
        MessagePartType.SYSTEM
        if role == ShieldMessageRole.SYSTEM
        else MessagePartType.DEVELOPER
        if role == ShieldMessageRole.DEVELOPER
        else MessagePartType.TOOL_RESULT
        if role == ShieldMessageRole.TOOL
        else MessagePartType.USER_TEXT
    )
    return ShieldMessage(
        role=role,
        parts=[MessagePart(type=part_type, text=text)],
    )


__all__ = [
    "ShieldCallContext",
    "ShieldCanonicalTransport",
    "ShieldClient",
    "build_canonical_shield_request",
    "text_message",
]
