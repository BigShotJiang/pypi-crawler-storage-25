"""Staging Pub/Sub push subscriber runtime for Phase 1.25.

The subscriber accepts Pub/Sub no-wrapper push deliveries. The raw request body
is the canonical outbox envelope; Pub/Sub writes message attributes as request
headers when ``noWrapper.writeMetadata`` is enabled.
"""

from __future__ import annotations

import asyncio
import os
import time
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol, cast

import httpx
import jwt
from opentelemetry import trace
from pydantic import BaseModel, ConfigDict, Field
from skaldos_log import log

from skaldos.events.outbox import OutboxEnvelope, event_id_hash
from skaldos.events.pubsub_delivery import (
    ExternalEventPushAuthError,
    OidcTokenVerifier,
    verify_pubsub_push_hmac,
    verify_pubsub_push_oidc,
)

_TRACER = trace.get_tracer(__name__)
_GOOGLE_JWKS_URL = "https://www.googleapis.com/oauth2/v3/certs"
_ROUTE_PATH = "/webhooks/pubsub/events"


class PushSubscriberConfigError(ValueError):
    """Raised when staging subscriber configuration is incomplete."""


class PushSubscriberDedupeStore(Protocol):
    def has_seen(self, event_hash: str) -> bool:
        """Return True when this event hash has already reached a terminal outcome."""
        ...  # pragma: no cover

    def mark_seen(self, event_hash: str) -> bool:
        """Mark an event hash as terminal and return True when already seen."""
        ...  # pragma: no cover


class InMemoryPushSubscriberDedupeStore:
    """Process-local dedupe store for the smallest staging proof."""

    def __init__(self) -> None:
        self._seen: set[str] = set()

    def has_seen(self, event_hash: str) -> bool:
        return event_hash in self._seen

    def mark_seen(self, event_hash: str) -> bool:
        duplicate = event_hash in self._seen
        self._seen.add(event_hash)
        return duplicate


@dataclass(frozen=True, slots=True)
class PushSubscriberConfig:
    oidc_audience: str
    oidc_service_account: str
    hmac_secret: str
    api_base_url: str
    auth0_token_url: str
    auth0_client_id: str
    auth0_client_secret: str
    auth0_audience: str
    http_timeout_seconds: float = 10.0


class PushSubscriberReceipt(BaseModel):
    """Content-free receipt evidence for one push attempt."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    event_id_hash: str | None
    event_type: str | None
    tenant_id: str | None
    subject_type: str | None
    subject_id: str | None
    oidc_verified: bool = False
    hmac_verified: bool = False
    duplicate: bool = False
    accepted: bool = False
    refetch_attempted: bool = False
    refetch_status: int | None = Field(default=None, ge=100, le=599)
    reason_code: str | None = None


class GoogleOidcTokenVerifier:
    """Verify Google-signed Pub/Sub push OIDC tokens with Google's JWKS."""

    def __init__(self, *, jwks_url: str = _GOOGLE_JWKS_URL) -> None:
        self._client = jwt.PyJWKClient(jwks_url)

    async def verify_oidc_token(self, *, token: str, audience: str) -> Mapping[str, object]:
        return await asyncio.to_thread(self._verify_sync, token, audience)

    def _verify_sync(self, token: str, audience: str) -> Mapping[str, object]:
        signing_key = self._client.get_signing_key_from_jwt(token)
        claims = cast(
            Mapping[str, object],
            jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=audience,
                options={"require": ["aud", "exp", "iss"]},
            ),
        )
        return claims


class SubscriberApiRefetchClient:
    """Refetch event subjects through SkaldOS API using subscriber M2M auth."""

    def __init__(self, *, config: PushSubscriberConfig, http_client: httpx.AsyncClient) -> None:
        self._config = config
        self._http_client = http_client

    async def refetch_subject(self, envelope: OutboxEnvelope) -> int:
        if envelope.subject_type != "node":
            return 422
        token = await self._mint_token()
        try:
            response = await self._http_client.post(
                f"{self._config.api_base_url.rstrip('/')}/graph/source-snapshot",
                json={
                    "tenant_id": str(envelope.tenant_id),
                    "node_id": str(envelope.subject_id),
                },
                headers={"Authorization": f"Bearer {token}"},
            )
        except httpx.RequestError as exc:
            raise PushSubscriberConfigError("subscriber_api_refetch_request_failed") from exc
        return response.status_code

    async def _mint_token(self) -> str:
        try:
            response = await self._http_client.post(
                self._config.auth0_token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._config.auth0_client_id,
                    "client_secret": self._config.auth0_client_secret,
                    "audience": self._config.auth0_audience,
                },
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise PushSubscriberConfigError("subscriber_auth0_token_rejected") from exc
        except httpx.RequestError as exc:
            raise PushSubscriberConfigError("subscriber_auth0_token_failed") from exc
        payload = cast(object, response.json())
        if not isinstance(payload, dict):
            raise PushSubscriberConfigError("subscriber_auth0_token_response_invalid")
        payload_mapping = cast(Mapping[str, object], payload)
        access_token = payload_mapping.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise PushSubscriberConfigError("subscriber_auth0_token_missing")
        return access_token


class PushSubscriberService:
    """Verify, dedupe, and refetch one Pub/Sub push delivery."""

    def __init__(
        self,
        *,
        config: PushSubscriberConfig,
        refetch_client: SubscriberApiRefetchClient,
        oidc_token_verifier: OidcTokenVerifier,
        dedupe_store: PushSubscriberDedupeStore | None = None,
    ) -> None:
        self._config = config
        self._refetch_client = refetch_client
        self._oidc_token_verifier = oidc_token_verifier
        self._dedupe_store = dedupe_store or InMemoryPushSubscriberDedupeStore()

    async def receive_push(
        self,
        *,
        authorization_header: str | None,
        headers: Mapping[str, str],
        raw_body: bytes,
        received_at: datetime | None = None,
    ) -> PushSubscriberReceipt:
        started = time.monotonic()
        now = received_at or datetime.now(tz=UTC)
        envelope: OutboxEnvelope | None = None
        event_hash: str | None = None
        reason_code: str | None = None
        oidc_verified = False
        hmac_verified = False
        duplicate = False
        accepted = False
        refetch_attempted = False
        refetch_status: int | None = None

        with _TRACER.start_as_current_span("pubsub.subscriber.receive") as span:
            try:
                envelope = OutboxEnvelope.model_validate_json(raw_body)
                event_hash = event_id_hash(envelope)
            except ValueError:
                reason_code = "pubsub_push_body_invalid"
            if envelope is not None and event_hash is not None:
                try:
                    await verify_pubsub_push_oidc(
                        authorization_header=authorization_header,
                        expected_audience=self._config.oidc_audience,
                        expected_service_account=self._config.oidc_service_account,
                        token_verifier=self._oidc_token_verifier,
                    )
                    oidc_verified = True
                    verify_pubsub_push_hmac(
                        headers=headers,
                        raw_body=raw_body,
                        secret=self._config.hmac_secret,
                        now=now,
                        expected_event_id_hash=event_hash,
                    )
                    hmac_verified = True
                    duplicate = self._dedupe_store.has_seen(event_hash)
                    if duplicate:
                        reason_code = "duplicate_event"
                    else:
                        refetch_attempted = True
                        refetch_status = await self._refetch_client.refetch_subject(envelope)
                        accepted = 200 <= refetch_status <= 299
                        if not accepted:
                            reason_code = _refetch_reason_code(refetch_status)
                        if accepted or reason_code == "subscriber_refetch_denied":
                            self._dedupe_store.mark_seen(event_hash)
                except ExternalEventPushAuthError as exc:
                    reason_code = str(exc)
                except httpx.HTTPError:
                    reason_code = "subscriber_refetch_failed"
                except PushSubscriberConfigError as exc:
                    reason_code = str(exc)

            receipt = PushSubscriberReceipt(
                event_id_hash=event_hash,
                event_type=envelope.event_type if envelope is not None else None,
                tenant_id=str(envelope.tenant_id) if envelope is not None else None,
                subject_type=envelope.subject_type if envelope is not None else None,
                subject_id=str(envelope.subject_id) if envelope is not None else None,
                oidc_verified=oidc_verified,
                hmac_verified=hmac_verified,
                duplicate=duplicate,
                accepted=accepted,
                refetch_attempted=refetch_attempted,
                refetch_status=refetch_status,
                reason_code=reason_code,
            )
            _set_receipt_span_attributes(span=span, receipt=receipt)
            _log_receipt(receipt=receipt, duration_ms=_duration_ms(started))
            return receipt


def config_from_env(env: Mapping[str, str] = os.environ) -> PushSubscriberConfig:
    return PushSubscriberConfig(
        oidc_audience=_required_env(env, "PUBSUB_PUSH_OIDC_AUDIENCE"),
        oidc_service_account=_required_env(env, "PUBSUB_PUSH_SERVICE_ACCOUNT"),
        hmac_secret=_required_env(env, "PUBSUB_PUSH_HMAC_SECRET"),
        api_base_url=_required_env(env, "SUBSCRIBER_API_BASE_URL"),
        auth0_token_url=_required_env(env, "SUBSCRIBER_AUTH0_TOKEN_URL"),
        auth0_client_id=_required_env(env, "SUBSCRIBER_AUTH0_CLIENT_ID"),
        auth0_client_secret=_required_env(env, "SUBSCRIBER_AUTH0_CLIENT_SECRET"),
        auth0_audience=_required_env(env, "SUBSCRIBER_AUTH0_AUDIENCE"),
        http_timeout_seconds=_float_env(env, "SUBSCRIBER_HTTP_TIMEOUT_SECONDS", 10.0),
    )


def _refetch_reason_code(status_code: int) -> str:
    if status_code in {401, 403, 404}:
        return "subscriber_refetch_denied"
    if status_code == 422:
        return "subscriber_refetch_subject_unsupported"
    if 500 <= status_code <= 599:
        return "subscriber_refetch_failed"
    return "subscriber_refetch_rejected"


def _set_receipt_span_attributes(*, span: trace.Span, receipt: PushSubscriberReceipt) -> None:
    if receipt.event_id_hash is not None:
        span.set_attribute("event_id_hash", receipt.event_id_hash)
    if receipt.event_type is not None:
        span.set_attribute("event_type", receipt.event_type)
    if receipt.tenant_id is not None:
        span.set_attribute("tenant_id", receipt.tenant_id)
    if receipt.subject_type is not None:
        span.set_attribute("subject_type", receipt.subject_type)
    if receipt.subject_id is not None:
        span.set_attribute("subject_id", receipt.subject_id)
    span.set_attribute("subscriber.oidc_verified", receipt.oidc_verified)
    span.set_attribute("subscriber.hmac_verified", receipt.hmac_verified)
    span.set_attribute("subscriber.duplicate", receipt.duplicate)
    span.set_attribute("subscriber.accepted", receipt.accepted)
    span.set_attribute("subscriber.refetch_attempted", receipt.refetch_attempted)
    if receipt.refetch_status is not None:
        span.set_attribute("http.status_code", receipt.refetch_status)
    if receipt.reason_code is not None:
        span.set_attribute("subscriber.reason_code", receipt.reason_code)


def _log_receipt(*, receipt: PushSubscriberReceipt, duration_ms: float) -> None:
    fields: dict[str, object] = {
        "route_path": _ROUTE_PATH,
        "http_method": "POST",
        "duration_ms": duration_ms,
        "outcome": _receipt_outcome(receipt),
        "count": 1,
    }
    if receipt.event_id_hash is not None:
        fields["event_id_hash"] = receipt.event_id_hash
    if receipt.event_type is not None:
        fields["event_type"] = receipt.event_type
    if receipt.tenant_id is not None:
        fields["tenant_id"] = receipt.tenant_id
    if receipt.reason_code is not None:
        fields["reason_code"] = receipt.reason_code
    log.info("pubsub.subscriber.receipt", **fields)


def _receipt_outcome(receipt: PushSubscriberReceipt) -> str:
    if receipt.accepted:
        return "accepted"
    if receipt.duplicate:
        return "duplicate"
    if receipt.refetch_attempted and receipt.reason_code == "subscriber_refetch_denied":
        return "denied"
    return "rejected"


def _duration_ms(started: float) -> float:
    return max(0.0, round((time.monotonic() - started) * 1000, 3))


def _required_env(env: Mapping[str, str], name: str) -> str:
    value = env.get(name)
    if not value:
        raise PushSubscriberConfigError(f"{name.lower()}_missing")
    return value


def _float_env(env: Mapping[str, str], name: str, default: float) -> float:
    raw = env.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise PushSubscriberConfigError(f"{name.lower()}_invalid") from exc
    if value <= 0:
        raise PushSubscriberConfigError(f"{name.lower()}_invalid")
    return value


__all__ = [
    "GoogleOidcTokenVerifier",
    "InMemoryPushSubscriberDedupeStore",
    "PushSubscriberConfig",
    "PushSubscriberConfigError",
    "PushSubscriberReceipt",
    "PushSubscriberService",
    "SubscriberApiRefetchClient",
    "config_from_env",
]
