"""FastAPI entrypoint for the dedicated Pub/Sub push subscriber surface."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from skaldos_log import register_auto_instrumentation

from skaldos.api._public import router as public_router
from skaldos.api.pubsub_webhooks import router as pubsub_webhooks_router

_APP_TITLE = "SkaldOS Event Subscriber"
_APP_VERSION = "2.0.0"


@asynccontextmanager
async def _subscriber_lifespan(fastapi_app: FastAPI) -> AsyncGenerator[None, None]:
    try:
        yield
    finally:
        pubsub_push_http_client = getattr(
            fastapi_app.state,
            "pubsub_push_subscriber_http_client",
            None,
        )
        if pubsub_push_http_client is not None:
            await pubsub_push_http_client.aclose()


def create_subscriber_app() -> FastAPI:
    """Create the event-subscriber-only app without DB or policy pools."""

    register_auto_instrumentation(only=("fastapi", "httpx"))
    app = FastAPI(
        title=_APP_TITLE,
        version=_APP_VERSION,
        openapi_version="3.1.0",
        lifespan=_subscriber_lifespan,
    )
    FastAPIInstrumentor.instrument_app(app)  # pyright: ignore[reportUnknownMemberType]
    app.include_router(public_router)
    app.include_router(pubsub_webhooks_router)
    return app


app: FastAPI = create_subscriber_app()

__all__ = ["app", "create_subscriber_app"]
