"""External Pub/Sub delivery seam for Slice 8."""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol, cast
from uuid import UUID

import httpx
from opentelemetry import trace
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.events.outbox import (
    OutboxEnvelope,
    OutboxEventRecord,
    canonical_event_envelope_bytes,
    event_id_hash,
)
from skaldos.events.subscription_store import (
    DeliveryFailureTerminalState,
    EventSubscriptionDeliveryTarget,
    EventSubscriptionRecord,
    EventSubscriptionStore,
)

PUBSUB_TOPIC_PREFIX = "graph-events"
PUBSUB_RETENTION_SECONDS = 7 * 24 * 60 * 60
PUBSUB_SCHEMA_VERSION = "slice-8.v1"
PUBSUB_PUSH_HMAC_VERSION = "v1"
PUBSUB_PUSH_REPLAY_WINDOW_SECONDS = 5 * 60
PUBSUB_PUSH_EVENT_ID_HEADER = "X-SkaldOS-Event-Id"
PUBSUB_PUSH_TIMESTAMP_HEADER = "X-SkaldOS-Timestamp"
PUBSUB_PUSH_SIGNATURE_HEADER = "X-SkaldOS-Signature"
PUBSUB_PUSH_SIGNATURE_VERSION_HEADER = "X-SkaldOS-Signature-Version"
PUBSUB_PUSH_OIDC_ISSUERS = frozenset(
    {
        "https://accounts.google.com",
        "accounts.google.com",
    }
)
DEFAULT_REGION_STORAGE_POLICY: Mapping[str, tuple[str, ...]] = {
    "europe-west1": ("europe-west1",),
    "europe-west3": ("europe-west3",),
}
_TRACER = trace.get_tracer(__name__)

_PROJECT_ID_RE = re.compile(r"^[a-z][a-z0-9-]{4,62}$")
_ENVIRONMENT_RE = re.compile(r"^[a-z][a-z0-9-]{1,31}$")
_GCP_REGION_RE = re.compile(r"^[a-z]+-[a-z]+[0-9]$")
_TOPIC_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9._~+%-]{2,254}$")
_EVENT_HASH_RE = re.compile(r"^[0-9a-f]{64}$")


class ExternalEventTopicConfigError(ValueError):
    """Raised when per-organization Pub/Sub topic config is unsafe."""


class ExternalEventPublishError(RuntimeError):
    """Raised when building or publishing an external event message fails."""


class ExternalEventPushAuthError(RuntimeError):
    """Raised when a pushed Pub/Sub request fails subscriber auth checks."""


class ExternalEventTopic(BaseModel):
    """Resolved per-organization Pub/Sub topic handle."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    project_id: str
    environment: str
    topic_id: str
    full_name: str
    allowed_storage_regions: tuple[str, ...]
    retention_seconds: int = PUBSUB_RETENTION_SECONDS
    dead_letter_topic_id: str | None = None

    @field_validator("project_id")
    @classmethod
    def _project_id_is_safe(cls, value: str) -> str:
        if not _PROJECT_ID_RE.fullmatch(value):
            raise ValueError("external_event_topic_project_invalid")
        return value

    @field_validator("environment")
    @classmethod
    def _environment_is_safe(cls, value: str) -> str:
        if not _ENVIRONMENT_RE.fullmatch(value):
            raise ValueError("external_event_topic_environment_invalid")
        return value

    @field_validator("topic_id", "dead_letter_topic_id")
    @classmethod
    def _topic_id_is_safe(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if not _TOPIC_ID_RE.fullmatch(value):
            raise ValueError("external_event_topic_id_invalid")
        if "/" in value or "{" in value or "}" in value:
            raise ValueError("external_event_topic_id_invalid")
        return value

    @field_validator("allowed_storage_regions")
    @classmethod
    def _regions_are_safe(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if not value:
            raise ValueError("external_event_topic_regions_empty")
        for region in value:
            if not _GCP_REGION_RE.fullmatch(region):
                raise ValueError("external_event_topic_region_invalid")
        return tuple(dict.fromkeys(value))

    @model_validator(mode="after")
    def _full_name_matches_project_and_topic(self) -> ExternalEventTopic:
        expected = f"projects/{self.project_id}/topics/{self.topic_id}"
        if self.full_name != expected:
            raise ValueError("external_event_topic_full_name_mismatch")
        if self.retention_seconds != PUBSUB_RETENTION_SECONDS:
            raise ValueError("external_event_topic_retention_invalid")
        return self


class ExternalEventTopicResolver(BaseModel):
    """Resolve Organization storage facts to one transport-isolated topic."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    project_id: str
    environment: str
    region_storage_policy: Mapping[str, tuple[str, ...]] = Field(
        default_factory=lambda: dict(DEFAULT_REGION_STORAGE_POLICY)
    )
    topic_prefix: str = PUBSUB_TOPIC_PREFIX
    retention_seconds: int = PUBSUB_RETENTION_SECONDS

    @field_validator("project_id")
    @classmethod
    def _project_id_is_safe(cls, value: str) -> str:
        if not _PROJECT_ID_RE.fullmatch(value):
            raise ValueError("external_event_topic_project_invalid")
        return value

    @field_validator("environment")
    @classmethod
    def _environment_is_safe(cls, value: str) -> str:
        if not _ENVIRONMENT_RE.fullmatch(value):
            raise ValueError("external_event_topic_environment_invalid")
        return value

    @field_validator("topic_prefix")
    @classmethod
    def _topic_prefix_is_safe(cls, value: str) -> str:
        if value != PUBSUB_TOPIC_PREFIX:
            raise ValueError("external_event_topic_prefix_invalid")
        return value

    @field_validator("region_storage_policy")
    @classmethod
    def _region_policy_is_safe(
        cls,
        value: Mapping[str, tuple[str, ...]],
    ) -> Mapping[str, tuple[str, ...]]:
        if not value:
            raise ValueError("external_event_topic_region_policy_empty")
        normalized: dict[str, tuple[str, ...]] = {}
        for org_region, storage_regions in value.items():
            if not _GCP_REGION_RE.fullmatch(org_region):
                raise ValueError("external_event_topic_region_invalid")
            if not storage_regions:
                raise ValueError("external_event_topic_regions_empty")
            for storage_region in storage_regions:
                if not _GCP_REGION_RE.fullmatch(storage_region):
                    raise ValueError("external_event_topic_region_invalid")
            normalized[org_region] = tuple(dict.fromkeys(storage_regions))
        return normalized

    @model_validator(mode="after")
    def _retention_is_slice_8_default(self) -> ExternalEventTopicResolver:
        if self.retention_seconds != PUBSUB_RETENTION_SECONDS:
            raise ValueError("external_event_topic_retention_invalid")
        return self

    def resolve_topic(
        self,
        *,
        tenant_id: UUID,
        organization_region: str,
        dead_letter_topic_id: str | None = None,
    ) -> ExternalEventTopic:
        try:
            allowed_storage_regions = self.region_storage_policy[organization_region]
        except KeyError as exc:
            raise ExternalEventTopicConfigError("external_event_topic_region_unsupported") from exc
        topic_id = topic_id_for_tenant(tenant_id)
        return ExternalEventTopic(
            tenant_id=tenant_id,
            project_id=self.project_id,
            environment=self.environment,
            topic_id=topic_id,
            full_name=f"projects/{self.project_id}/topics/{topic_id}",
            allowed_storage_regions=allowed_storage_regions,
            retention_seconds=self.retention_seconds,
            dead_letter_topic_id=dead_letter_topic_id,
        )


@dataclass(frozen=True, slots=True)
class PubSubPublishRequest:
    """Provider-facing publish request with canonical envelope bytes."""

    topic: ExternalEventTopic
    event_id_hash: str
    data: bytes
    attributes: Mapping[str, str]
    ordering_key: str


@dataclass(frozen=True, slots=True)
class PubSubPublishResult:
    """Content-free publish result."""

    topic_id: str
    event_id_hash: str
    message_id: str


class ExternalEventPublisher(Protocol):
    async def publish_external_event(self, request: PubSubPublishRequest) -> PubSubPublishResult:
        """Publish one externally eligible ID-as-handle event."""
        ...


class OrganizationRegionResolver(Protocol):
    async def organization_region_for_event(
        self,
        *,
        connection: object,
        tenant_id: UUID,
    ) -> str:
        """Return the tenant's Organization residency region."""
        ...  # pragma: no cover


class OidcTokenVerifier(Protocol):
    async def verify_oidc_token(
        self,
        *,
        token: str,
        audience: str,
    ) -> Mapping[str, object]:
        """Verify and decode one Google-signed push OIDC token."""
        ...  # pragma: no cover


class PubSubPushHmacSecretResolver(Protocol):
    def secret_for_delivery_target(self, target: EventSubscriptionDeliveryTarget) -> str | bytes:
        """Return the HMAC secret for one eligible delivery target."""
        ...  # pragma: no cover


BearerTokenProvider = Callable[[], str | Awaitable[str]]


class PubSubRestExternalEventPublisher:
    """Publish to GCP Pub/Sub's REST API or the local emulator via httpx."""

    def __init__(
        self,
        *,
        http_client: httpx.AsyncClient,
        api_base_url: str = "https://pubsub.googleapis.com",
        bearer_token_provider: BearerTokenProvider | None = None,
    ) -> None:
        self._http_client = http_client
        self._api_base_url = api_base_url.rstrip("/")
        self._bearer_token_provider = bearer_token_provider

    async def publish_external_event(self, request: PubSubPublishRequest) -> PubSubPublishResult:
        headers: dict[str, str] = {}
        if self._bearer_token_provider is not None:
            token = self._bearer_token_provider()
            if not isinstance(token, str):
                token = await token
            if not token:
                raise ExternalEventPublishError("pubsub_bearer_token_missing")
            headers["Authorization"] = f"Bearer {token}"

        body = {
            "messages": [
                {
                    "data": base64.b64encode(request.data).decode("ascii"),
                    "attributes": dict(request.attributes),
                    "orderingKey": request.ordering_key,
                }
            ]
        }
        try:
            response = await self._http_client.post(
                f"{self._api_base_url}/v1/{request.topic.full_name}:publish",
                json=body,
                headers=headers,
            )
            response.raise_for_status()
            payload = cast(object, response.json())
        except httpx.HTTPError as exc:
            raise ExternalEventPublishError("pubsub_publish_failed") from exc
        except ValueError as exc:
            raise ExternalEventPublishError("pubsub_publish_response_invalid") from exc

        if not isinstance(payload, dict):
            raise ExternalEventPublishError("pubsub_publish_response_invalid")
        payload_mapping = cast(Mapping[str, object], payload)
        message_ids_value = payload_mapping.get("messageIds")
        if not isinstance(message_ids_value, list):
            raise ExternalEventPublishError("pubsub_publish_response_invalid")
        message_ids = cast(list[object], message_ids_value)
        if len(message_ids) != 1 or not isinstance(message_ids[0], str) or not message_ids[0]:
            raise ExternalEventPublishError("pubsub_publish_response_invalid")
        return PubSubPublishResult(
            topic_id=request.topic.topic_id,
            event_id_hash=request.event_id_hash,
            message_id=message_ids[0],
        )


@dataclass(frozen=True, slots=True)
class ExternalEventDeliveryResult:
    """Content-free external fan-out result for one outbox event."""

    matched: int
    published: int
    failed: int


@dataclass(frozen=True, slots=True)
class PubSubPushHmacHeaders:
    """Headers a reference subscriber expects on a Pub/Sub push request."""

    event_id: str
    timestamp: str
    signature: str
    signature_version: str = PUBSUB_PUSH_HMAC_VERSION

    def as_mapping(self) -> dict[str, str]:
        return {
            PUBSUB_PUSH_EVENT_ID_HEADER: self.event_id,
            PUBSUB_PUSH_TIMESTAMP_HEADER: self.timestamp,
            PUBSUB_PUSH_SIGNATURE_HEADER: self.signature,
            PUBSUB_PUSH_SIGNATURE_VERSION_HEADER: self.signature_version,
        }


@dataclass(frozen=True, slots=True)
class PubSubPushFailureMapping:
    """Content-free mapping from push evidence to subscription state update."""

    reason_code: str
    terminal_state: DeliveryFailureTerminalState | None
    retryable: bool


class ExternalEventFanoutDispatcher:
    """Outbox fan-out handler for externally eligible Pub/Sub deliveries."""

    def __init__(
        self,
        *,
        topic_resolver: ExternalEventTopicResolver,
        publisher: ExternalEventPublisher,
        organization_region_resolver: OrganizationRegionResolver | None = None,
        subscription_store: EventSubscriptionStore | None = None,
        push_hmac_secret_resolver: PubSubPushHmacSecretResolver | None = None,
    ) -> None:
        self._subscription_store = subscription_store or EventSubscriptionStore()
        self._topic_resolver = topic_resolver
        self._publisher = publisher
        self._push_hmac_secret_resolver = push_hmac_secret_resolver
        self._organization_region_resolver = (
            organization_region_resolver or TenantOrganizationRegionStore()
        )

    async def __call__(
        self,
        _connection: object,
        event: OutboxEventRecord,
    ) -> None:
        await self.dispatch_event(connection=_connection, event=event)

    async def dispatch_event(
        self,
        *,
        connection: object,
        failure_connection: object | None = None,
        event: OutboxEventRecord,
    ) -> ExternalEventDeliveryResult:
        failure_recording_connection = failure_connection or connection
        with _TRACER.start_as_current_span("pubsub.delivery.match") as match_span:
            _set_pubsub_match_span_attributes(span=match_span, event=event)
            targets = await self._subscription_store.list_delivery_eligible_subscriptions(
                connection=connection,  # type: ignore[arg-type]
                event=event,
            )
            match_span.set_attribute("pubsub.matched_count", len(targets))
            match_span.set_attribute(
                "pubsub.outcome",
                "matched" if targets else "no_eligible_subscriptions",
            )
        if not targets:
            return ExternalEventDeliveryResult(
                matched=0,
                published=0,
                failed=0,
            )
        organization_region = (
            await self._organization_region_resolver.organization_region_for_event(
                connection=connection,
                tenant_id=event.tenant_id,
            )
        )
        topic = self._topic_resolver.resolve_topic(
            tenant_id=event.tenant_id,
            organization_region=organization_region,
        )
        published = 0
        for target in targets:
            started = time.monotonic()
            with _TRACER.start_as_current_span("pubsub.publish") as span:
                _set_pubsub_publish_span_attributes(
                    span=span,
                    event=event,
                    target=target,
                    topic=topic,
                    attempt_count=event.attempt_count,
                )
                try:
                    publish_request = pubsub_publish_request_for_target(
                        event=event,
                        topic=topic,
                        target=target,
                        hmac_secret=(
                            self._push_hmac_secret_resolver.secret_for_delivery_target(target)
                            if self._push_hmac_secret_resolver is not None
                            else None
                        ),
                    )
                    publish_result = await self._publisher.publish_external_event(publish_request)
                except ExternalEventPublishError:
                    await self._subscription_store.record_delivery_failure(
                        connection=failure_recording_connection,  # type: ignore[arg-type]
                        subscription_id=target.subscription_id,
                        tenant_id=target.tenant_id,
                        reason_code="pubsub_publish_failed",
                    )
                    span.set_attribute("pubsub.outcome", "failed")
                    span.set_attribute("pubsub.reason_code", "pubsub_publish_failed")
                    span.set_attribute("pubsub.duration_ms", _duration_ms(started))
                    raise
                span.set_attribute("pubsub.outcome", "published")
                span.set_attribute("pubsub.message_id_present", bool(publish_result.message_id))
                span.set_attribute("pubsub.duration_ms", _duration_ms(started))
                await self._subscription_store.mark_delivery_succeeded(
                    connection=connection,  # type: ignore[arg-type]
                    subscription_id=target.subscription_id,
                    tenant_id=target.tenant_id,
                    event_id_hash=event.event_id_hash,
                )
                span.set_attribute("subscription.outcome", "delivery_cursor_advanced")
                published += 1
        return ExternalEventDeliveryResult(
            matched=len(targets),
            published=published,
            failed=0,
        )


class TenantOrganizationRegionStore:
    """Load the event tenant's Organization residency region for topic resolution."""

    async def organization_region_for_event(
        self,
        *,
        connection: object,
        tenant_id: UUID,
    ) -> str:
        raw_fetchval = getattr(connection, "fetchval", None)
        if not callable(raw_fetchval):
            raise ExternalEventTopicConfigError("external_event_topic_region_lookup_unavailable")
        fetchval = cast(Callable[..., Awaitable[object]], raw_fetchval)
        try:
            region = await fetchval(
                """
SELECT region
FROM tenants
WHERE id = $1
""",
                tenant_id,
            )
        except Exception as exc:
            raise ExternalEventTopicConfigError(
                "external_event_topic_region_lookup_failed"
            ) from exc
        if not isinstance(region, str) or not region:
            raise ExternalEventTopicConfigError("external_event_topic_region_missing")
        return region


def sign_pubsub_push_hmac(
    *,
    event_id_hash: str,
    raw_body: bytes,
    secret: str | bytes,
    timestamp: datetime,
) -> PubSubPushHmacHeaders:
    """Return Slice 8 HMAC headers for a canonical Pub/Sub push body."""

    _validate_event_hash(event_id_hash)
    timestamp_text = _format_push_timestamp(timestamp)
    signature = _compute_push_hmac(
        raw_body=raw_body,
        secret=secret,
        timestamp=timestamp_text,
    )
    return PubSubPushHmacHeaders(
        event_id=event_id_hash,
        timestamp=timestamp_text,
        signature=f"{PUBSUB_PUSH_HMAC_VERSION}={signature}",
    )


def verify_pubsub_push_hmac(
    *,
    headers: Mapping[str, str],
    raw_body: bytes,
    secret: str | bytes,
    now: datetime,
    expected_event_id_hash: str,
    replay_window: timedelta = timedelta(seconds=PUBSUB_PUSH_REPLAY_WINDOW_SECONDS),
) -> str:
    """Verify Slice 8 HMAC push headers and return the event id hash."""

    event_id_hash = _header_value(headers, PUBSUB_PUSH_EVENT_ID_HEADER)
    _validate_event_hash_for_auth(event_id_hash)
    if event_id_hash != expected_event_id_hash:
        raise ExternalEventPushAuthError("pubsub_push_event_id_mismatch")

    signature_version = _header_value(headers, PUBSUB_PUSH_SIGNATURE_VERSION_HEADER)
    if signature_version != PUBSUB_PUSH_HMAC_VERSION:
        raise ExternalEventPushAuthError("pubsub_push_signature_version_unsupported")

    timestamp_text = _header_value(headers, PUBSUB_PUSH_TIMESTAMP_HEADER)
    timestamp = _parse_push_timestamp(timestamp_text)
    _validate_push_timestamp(timestamp=timestamp, now=now, replay_window=replay_window)

    signature = _header_value(headers, PUBSUB_PUSH_SIGNATURE_HEADER)
    expected_prefix = f"{PUBSUB_PUSH_HMAC_VERSION}="
    if not signature.startswith(expected_prefix):
        raise ExternalEventPushAuthError("pubsub_push_signature_invalid")
    expected_signature = _compute_push_hmac(
        raw_body=raw_body,
        secret=secret,
        timestamp=timestamp_text,
    )
    if not hmac.compare_digest(signature.removeprefix(expected_prefix), expected_signature):
        raise ExternalEventPushAuthError("pubsub_push_signature_mismatch")
    return event_id_hash


async def verify_pubsub_push_oidc(
    *,
    authorization_header: str | None,
    expected_audience: str,
    expected_service_account: str,
    token_verifier: OidcTokenVerifier,
) -> Mapping[str, object]:
    """Verify Google push OIDC posture using an injected verifier boundary."""

    if not authorization_header or not authorization_header.startswith("Bearer "):
        raise ExternalEventPushAuthError("pubsub_push_oidc_authorization_missing")
    token = authorization_header.removeprefix("Bearer ").strip()
    if not token:
        raise ExternalEventPushAuthError("pubsub_push_oidc_authorization_missing")
    if not expected_audience:
        raise ExternalEventPushAuthError("pubsub_push_oidc_audience_missing")
    if not expected_service_account:
        raise ExternalEventPushAuthError("pubsub_push_oidc_service_account_missing")

    try:
        claims = await token_verifier.verify_oidc_token(
            token=token,
            audience=expected_audience,
        )
    except Exception as exc:
        raise ExternalEventPushAuthError("pubsub_push_oidc_verification_failed") from exc

    if claims.get("aud") != expected_audience:
        raise ExternalEventPushAuthError("pubsub_push_oidc_audience_mismatch")
    if claims.get("iss") not in PUBSUB_PUSH_OIDC_ISSUERS:
        raise ExternalEventPushAuthError("pubsub_push_oidc_issuer_mismatch")
    email = claims.get("email")
    if email != expected_service_account:
        raise ExternalEventPushAuthError("pubsub_push_oidc_service_account_mismatch")
    if claims.get("email_verified") is not True:
        raise ExternalEventPushAuthError("pubsub_push_oidc_email_unverified")
    return claims


def classify_pubsub_push_failure(
    *,
    status_code: int | None = None,
    timed_out: bool = False,
    dead_lettered: bool = False,
) -> PubSubPushFailureMapping:
    """Map push delivery evidence to content-free subscription failure state."""

    if dead_lettered:
        return PubSubPushFailureMapping(
            reason_code="pubsub_dead_lettered",
            terminal_state="failed",
            retryable=False,
        )
    if timed_out:
        return PubSubPushFailureMapping(
            reason_code="endpoint_timeout",
            terminal_state=None,
            retryable=True,
        )
    if status_code is None:
        return PubSubPushFailureMapping(
            reason_code="pubsub_retry",
            terminal_state=None,
            retryable=True,
        )
    if 500 <= status_code <= 599:
        return PubSubPushFailureMapping(
            reason_code="endpoint_5xx",
            terminal_state=None,
            retryable=True,
        )
    if 400 <= status_code <= 499:
        return PubSubPushFailureMapping(
            reason_code="endpoint_4xx",
            terminal_state="failed",
            retryable=False,
        )
    return PubSubPushFailureMapping(
        reason_code="subscriber_rejected",
        terminal_state="failed",
        retryable=False,
    )


async def record_pubsub_push_failure(
    *,
    subscription_store: EventSubscriptionStore,
    connection: object,
    subscription_id: UUID,
    tenant_id: UUID,
    failure: PubSubPushFailureMapping,
) -> EventSubscriptionRecord:
    """Apply a content-free push failure mapping to an EventSubscription."""

    return await subscription_store.record_delivery_failure(
        connection=connection,  # type: ignore[arg-type]
        subscription_id=subscription_id,
        tenant_id=tenant_id,
        reason_code=failure.reason_code,
        terminal_state=failure.terminal_state,
    )


def _duration_ms(started: float) -> float:
    return max(0.0, round((time.monotonic() - started) * 1000, 3))


def _set_pubsub_publish_span_attributes(
    *,
    span: trace.Span,
    event: OutboxEventRecord,
    target: EventSubscriptionDeliveryTarget,
    topic: ExternalEventTopic,
    attempt_count: int,
) -> None:
    span.set_attribute("tenant_id", str(event.tenant_id))
    span.set_attribute("event_id_hash", event.event_id_hash)
    span.set_attribute("event_type", event.event_type)
    span.set_attribute("subscription_id", str(target.subscription_id))
    span.set_attribute("pubsub.topic_id", topic.topic_id)
    span.set_attribute("pubsub.ordering_key", ordering_key_for_event(event))
    span.set_attribute("pubsub.attempt_count", attempt_count)


def _set_pubsub_match_span_attributes(
    *,
    span: trace.Span,
    event: OutboxEventRecord,
) -> None:
    span.set_attribute("tenant_id", str(event.tenant_id))
    span.set_attribute("event_id_hash", event.event_id_hash)
    span.set_attribute("event_type", event.event_type)
    span.set_attribute("subject_type", event.subject_type)
    span.set_attribute("subject_id", str(event.subject_id))


def topic_id_for_tenant(tenant_id: UUID) -> str:
    """Return the Slice 8 per-organization topic id."""

    return f"{PUBSUB_TOPIC_PREFIX}-{tenant_id}"


def ordering_key_for_event(event: OutboxEventRecord) -> str:
    """Return the per-entity Pub/Sub ordering key."""

    if not event.subject_type:
        raise ExternalEventPublishError("pubsub_ordering_key_missing_subject")
    return f"{event.subject_type}:{event.subject_id}"


def pubsub_attributes_for_event(event: OutboxEventRecord) -> dict[str, str]:
    """Return safe Pub/Sub message attributes for an outbox event."""

    _validate_event_hash(event.event_id_hash)
    return {
        "event_type": event.event_type,
        "tenant_id": str(event.tenant_id),
        "subject_type": event.subject_type,
        "subject_id": str(event.subject_id),
        "event_id_hash": event.event_id_hash,
        "schema_version": PUBSUB_SCHEMA_VERSION,
    }


def pubsub_publish_request_for_event(
    *,
    event: OutboxEventRecord,
    topic: ExternalEventTopic,
) -> PubSubPublishRequest:
    """Build a provider request without changing the canonical event identity."""

    if event.tenant_id != topic.tenant_id:
        raise ExternalEventPublishError("pubsub_topic_tenant_mismatch")
    try:
        envelope = OutboxEnvelope.model_validate(event.envelope)
        data = canonical_event_envelope_bytes(envelope)
        computed_hash = event_id_hash(envelope)
    except ValueError as exc:
        raise ExternalEventPublishError("pubsub_envelope_invalid") from exc
    _validate_event_record_matches_envelope(event=event, envelope=envelope)
    if computed_hash != event.event_id_hash:
        raise ExternalEventPublishError("pubsub_event_hash_mismatch")
    return PubSubPublishRequest(
        topic=topic,
        event_id_hash=event.event_id_hash,
        data=data,
        attributes=pubsub_attributes_for_event(event),
        ordering_key=ordering_key_for_event(event),
    )


def pubsub_publish_request_for_target(
    *,
    event: OutboxEventRecord,
    topic: ExternalEventTopic,
    target: EventSubscriptionDeliveryTarget,
    hmac_secret: str | bytes | None = None,
    timestamp: datetime | None = None,
) -> PubSubPublishRequest:
    """Build a per-subscription publish request for an eligible target."""

    _validate_target_matches_event(target=target, event=event)
    request = pubsub_publish_request_for_event(event=event, topic=topic)
    hmac_attributes = (
        sign_pubsub_push_hmac(
            event_id_hash=request.event_id_hash,
            raw_body=request.data,
            secret=hmac_secret,
            timestamp=timestamp or datetime.now(tz=UTC),
        ).as_mapping()
        if hmac_secret is not None
        else {}
    )
    return PubSubPublishRequest(
        topic=request.topic,
        event_id_hash=request.event_id_hash,
        data=request.data,
        attributes={
            **request.attributes,
            "event_subscription_id": str(target.subscription_id),
            **hmac_attributes,
        },
        ordering_key=request.ordering_key,
    )


def assert_topic_posture(
    *,
    topic: ExternalEventTopic,
    actual_full_name: str,
    actual_storage_regions: tuple[str, ...],
    actual_retention_seconds: int,
) -> None:
    """Fail closed when observed topic metadata drifts from Slice 8 posture."""

    if actual_full_name != topic.full_name:
        raise ExternalEventTopicConfigError("external_event_topic_name_mismatch")
    if frozenset(actual_storage_regions) != frozenset(topic.allowed_storage_regions):
        raise ExternalEventTopicConfigError("external_event_topic_region_mismatch")
    if actual_retention_seconds != topic.retention_seconds:
        raise ExternalEventTopicConfigError("external_event_topic_retention_mismatch")


def _validate_event_hash(value: str) -> None:
    if not _EVENT_HASH_RE.fullmatch(value):
        raise ExternalEventPublishError("pubsub_event_hash_invalid")


def _validate_event_hash_for_auth(value: str) -> None:
    if not _EVENT_HASH_RE.fullmatch(value):
        raise ExternalEventPushAuthError("pubsub_push_event_id_invalid")


def _header_value(headers: Mapping[str, str], name: str) -> str:
    value = headers.get(name)
    if value is None or not value:
        raise ExternalEventPushAuthError("pubsub_push_header_missing")
    return value


def _format_push_timestamp(timestamp: datetime) -> str:
    if timestamp.tzinfo is None:
        raise ExternalEventPushAuthError("pubsub_push_timestamp_naive")
    return timestamp.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _parse_push_timestamp(value: str) -> datetime:
    try:
        timestamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ExternalEventPushAuthError("pubsub_push_timestamp_invalid") from exc
    if timestamp.tzinfo is None:
        raise ExternalEventPushAuthError("pubsub_push_timestamp_naive")
    return timestamp.astimezone(UTC)


def _validate_push_timestamp(
    *,
    timestamp: datetime,
    now: datetime,
    replay_window: timedelta,
) -> None:
    if now.tzinfo is None:
        raise ExternalEventPushAuthError("pubsub_push_now_naive")
    normalized_now = now.astimezone(UTC)
    if timestamp < normalized_now - replay_window:
        raise ExternalEventPushAuthError("pubsub_push_timestamp_stale")
    if timestamp > normalized_now + replay_window:
        raise ExternalEventPushAuthError("pubsub_push_timestamp_future")


def _compute_push_hmac(
    *,
    raw_body: bytes,
    secret: str | bytes,
    timestamp: str,
) -> str:
    secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
    if not secret_bytes:
        raise ExternalEventPushAuthError("pubsub_push_hmac_secret_missing")
    canonical = b".".join(
        (PUBSUB_PUSH_HMAC_VERSION.encode("ascii"), timestamp.encode("utf-8"), raw_body)
    )
    return hmac.new(secret_bytes, canonical, hashlib.sha256).hexdigest()


def _validate_event_record_matches_envelope(
    *,
    event: OutboxEventRecord,
    envelope: OutboxEnvelope,
) -> None:
    if event.tenant_id != envelope.tenant_id:
        raise ExternalEventPublishError("pubsub_envelope_record_tenant_mismatch")
    if event.event_type != envelope.event_type:
        raise ExternalEventPublishError("pubsub_envelope_record_event_type_mismatch")
    if event.subject_type != envelope.subject_type:
        raise ExternalEventPublishError("pubsub_envelope_record_subject_type_mismatch")
    if event.subject_id != envelope.subject_id:
        raise ExternalEventPublishError("pubsub_envelope_record_subject_id_mismatch")


def _validate_target_matches_event(
    *,
    target: EventSubscriptionDeliveryTarget,
    event: OutboxEventRecord,
) -> None:
    if target.tenant_id != event.tenant_id:
        raise ExternalEventPublishError("pubsub_target_tenant_mismatch")
    if target.event_id_hash != event.event_id_hash:
        raise ExternalEventPublishError("pubsub_target_event_hash_mismatch")
    if target.event_type != event.event_type:
        raise ExternalEventPublishError("pubsub_target_event_type_mismatch")
    if target.subject_type != event.subject_type:
        raise ExternalEventPublishError("pubsub_target_subject_type_mismatch")
    if target.subject_id != event.subject_id:
        raise ExternalEventPublishError("pubsub_target_subject_id_mismatch")


__all__ = [
    "DEFAULT_REGION_STORAGE_POLICY",
    "ExternalEventDeliveryResult",
    "ExternalEventFanoutDispatcher",
    "ExternalEventPublishError",
    "ExternalEventPublisher",
    "ExternalEventPushAuthError",
    "ExternalEventTopic",
    "ExternalEventTopicConfigError",
    "ExternalEventTopicResolver",
    "OrganizationRegionResolver",
    "PubSubPushHmacSecretResolver",
    "OidcTokenVerifier",
    "PUBSUB_PUSH_EVENT_ID_HEADER",
    "PUBSUB_PUSH_HMAC_VERSION",
    "PUBSUB_PUSH_OIDC_ISSUERS",
    "PUBSUB_PUSH_REPLAY_WINDOW_SECONDS",
    "PUBSUB_PUSH_SIGNATURE_HEADER",
    "PUBSUB_PUSH_SIGNATURE_VERSION_HEADER",
    "PUBSUB_PUSH_TIMESTAMP_HEADER",
    "PUBSUB_RETENTION_SECONDS",
    "PUBSUB_SCHEMA_VERSION",
    "PUBSUB_TOPIC_PREFIX",
    "PubSubPushFailureMapping",
    "PubSubPushHmacHeaders",
    "PubSubPublishRequest",
    "PubSubPublishResult",
    "PubSubRestExternalEventPublisher",
    "TenantOrganizationRegionStore",
    "assert_topic_posture",
    "classify_pubsub_push_failure",
    "ordering_key_for_event",
    "pubsub_attributes_for_event",
    "pubsub_publish_request_for_event",
    "pubsub_publish_request_for_target",
    "record_pubsub_push_failure",
    "sign_pubsub_push_hmac",
    "topic_id_for_tenant",
    "verify_pubsub_push_hmac",
    "verify_pubsub_push_oidc",
]
