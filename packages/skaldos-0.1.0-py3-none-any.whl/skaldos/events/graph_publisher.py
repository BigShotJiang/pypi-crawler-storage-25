"""Service-layer graph-change event publisher for Slice 8."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from enum import StrEnum
from typing import Protocol, Self
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, model_validator

from skaldos.events.outbox import (
    Intent,
    OutboxContextOfValidity,
    OutboxEnvelope,
    OutboxInsertResult,
    insert_outbox_event,
)


class GraphChangeEventType(StrEnum):
    NODE_CREATED = "node.created"
    NODE_UPDATED = "node.updated"
    EDGE_CREATED = "edge.created"
    EDGE_ARCHIVED = "edge.archived"
    TAG_CREATED = "tag.created"
    TAG_SUPERSEDED = "tag.superseded"


ACTIVE_GRAPH_EVENT_TYPES = frozenset(event_type.value for event_type in GraphChangeEventType)
RESERVED_GRAPH_EVENT_TYPES = frozenset(
    {
        "node.archived",
        "edge.deleted",
    }
)

_SUBJECT_TYPE_BY_EVENT: Mapping[GraphChangeEventType, str] = {
    GraphChangeEventType.NODE_CREATED: "node",
    GraphChangeEventType.NODE_UPDATED: "node",
    GraphChangeEventType.EDGE_CREATED: "edge",
    GraphChangeEventType.EDGE_ARCHIVED: "edge",
    GraphChangeEventType.TAG_CREATED: "tag",
    GraphChangeEventType.TAG_SUPERSEDED: "tag",
}


class GraphChangeEventDraft(BaseModel):
    """Content-free event candidate produced by graph service write paths."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    event_type: GraphChangeEventType
    subject_id: UUID
    tenant_id: UUID
    context_of_validity: OutboxContextOfValidity
    intent: Intent
    actor_principal_id: UUID
    occurred_at: datetime

    @model_validator(mode="after")
    def _tenant_matches_context(self) -> Self:
        if self.context_of_validity.tenant != self.tenant_id:
            raise ValueError("graph_event_tenant_context_mismatch")
        return self

    @property
    def subject_type(self) -> str:
        return _SUBJECT_TYPE_BY_EVENT[self.event_type]

    def to_envelope(self) -> OutboxEnvelope:
        return OutboxEnvelope(
            id_as_handle=True,
            event_type=self.event_type.value,
            subject_type=self.subject_type,
            subject_id=self.subject_id,
            tenant_id=self.tenant_id,
            context_of_validity=self.context_of_validity,
            occurred_at=self.occurred_at,
            intent=self.intent,
        )


class GraphChangeEventPublisher(Protocol):
    async def publish_graph_change_event(
        self,
        draft: GraphChangeEventDraft,
    ) -> OutboxInsertResult:
        """Publish one graph-change event inside the caller's write transaction."""
        ...


class OutboxGraphChangeEventPublisher:
    """Write graph-change events to the Slice 8 outbox in the active transaction."""

    def __init__(self, *, connection: asyncpg.Connection) -> None:
        self._connection = connection

    async def publish_graph_change_event(
        self,
        draft: GraphChangeEventDraft,
    ) -> OutboxInsertResult:
        return await insert_outbox_event(
            connection=self._connection,
            envelope=draft.to_envelope(),
            suppress_current_transaction_duplicate=True,
        )


def graph_change_event_draft_for_tag(
    *,
    event_type: GraphChangeEventType,
    tag_id: UUID,
    tenant_id: UUID,
    context_of_validity: Mapping[str, object],
    actor_principal_id: UUID,
    occurred_at: datetime,
) -> GraphChangeEventDraft:
    if event_type not in {
        GraphChangeEventType.TAG_CREATED,
        GraphChangeEventType.TAG_SUPERSEDED,
    }:
        raise ValueError("graph_event_tag_event_type_required")
    return GraphChangeEventDraft(
        event_type=event_type,
        subject_id=tag_id,
        tenant_id=tenant_id,
        context_of_validity=OutboxContextOfValidity.model_validate(context_of_validity),
        intent="assertive",
        actor_principal_id=actor_principal_id,
        occurred_at=occurred_at.astimezone(UTC),
    )


__all__ = [
    "ACTIVE_GRAPH_EVENT_TYPES",
    "RESERVED_GRAPH_EVENT_TYPES",
    "GraphChangeEventDraft",
    "GraphChangeEventPublisher",
    "GraphChangeEventType",
    "OutboxGraphChangeEventPublisher",
    "graph_change_event_draft_for_tag",
]
