"""Minimal outbox dispatcher drain loop for Slice 8."""

from __future__ import annotations

import asyncio
import inspect
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Protocol, cast

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from opentelemetry import trace
from skaldos_log import log  # pyright: ignore[reportMissingTypeStubs]

from skaldos.events.outbox import (
    OUTBOX_DEFAULT_BATCH_SIZE,
    OUTBOX_DEFAULT_MAX_ATTEMPTS,
    OUTBOX_DEFAULT_RECLAIM_TIMEOUT_SECONDS,
    OutboxEventRecord,
    OutboxStorageError,
    claim_outbox_events,
    mark_outbox_attempt_failed,
    mark_outbox_dispatched,
)

FanoutHandler = Callable[[asyncpg.Connection, OutboxEventRecord], Awaitable[None]]

_TRACER = trace.get_tracer(__name__)


class OutboxDispatcherError(RuntimeError):
    """Raised when the dispatcher loop cannot make progress safely."""


class AsyncConnectionFactory(Protocol):
    async def __call__(self) -> asyncpg.Connection: ...


@dataclass(frozen=True, slots=True)
class OutboxDispatcherConfig:
    dispatcher_id: str
    batch_size: int = OUTBOX_DEFAULT_BATCH_SIZE
    reclaim_timeout_seconds: int = OUTBOX_DEFAULT_RECLAIM_TIMEOUT_SECONDS
    max_attempts: int = OUTBOX_DEFAULT_MAX_ATTEMPTS
    idle_sleep_seconds: float = 1.0


@dataclass(frozen=True, slots=True)
class OutboxDispatchBatchResult:
    claimed: int
    dispatched: int
    retry: int
    failed: int


class OutboxDispatcher:
    """Drain claimed outbox rows through an injected fan-out handler.

    The dispatcher owns only outbox lifecycle transitions. External Pub/Sub,
    subscription matching, and event-triggered AgentRun starts plug in through
    ``fanout_handler`` in later Slice 8 bundles.
    """

    def __init__(
        self,
        *,
        config: OutboxDispatcherConfig,
        connection_factory: AsyncConnectionFactory,
        fanout_handler: FanoutHandler,
        lifecycle_connection_factory: AsyncConnectionFactory | None = None,
    ) -> None:
        if config.idle_sleep_seconds < 0:
            raise OutboxDispatcherError("outbox_dispatcher_idle_sleep_invalid")
        self._config = config
        self._connection_factory = connection_factory
        self._lifecycle_connection_factory = lifecycle_connection_factory
        self._fanout_handler = fanout_handler

    async def drain_once(self) -> OutboxDispatchBatchResult:
        connection = await self._connection_factory()
        lifecycle_connection = (
            connection
            if self._lifecycle_connection_factory is None
            else await self._lifecycle_connection_factory()
        )
        try:
            return await self.drain_once_on_connection(
                connection=connection,
                lifecycle_connection=lifecycle_connection,
            )
        finally:
            if lifecycle_connection is not connection:
                await lifecycle_connection.close()  # pyright: ignore[reportUnknownMemberType]
            await connection.close()  # pyright: ignore[reportUnknownMemberType]

    async def drain_once_on_connection(
        self,
        *,
        connection: asyncpg.Connection,
        lifecycle_connection: asyncpg.Connection | None = None,
    ) -> OutboxDispatchBatchResult:
        lifecycle = lifecycle_connection or connection
        started = time.monotonic()
        with _TRACER.start_as_current_span("outbox.dispatch.batch") as span:
            try:
                claimed = await claim_outbox_events(
                    connection=lifecycle,
                    dispatcher_id=self._config.dispatcher_id,
                    batch_size=self._config.batch_size,
                    reclaim_timeout_seconds=self._config.reclaim_timeout_seconds,
                    max_attempts=self._config.max_attempts,
                )
            except OutboxStorageError:
                span.set_attribute("outbox.outcome", "failed")
                span.set_attribute("outbox.reason_code", "claim_failed")
                _log_batch(
                    claimed=0,
                    duration_ms=_duration_ms(started),
                    outcome="failed",
                    reason_code="claim_failed",
                )
                raise

            dispatched = 0
            retry = 0
            failed = 0
            for event in claimed:
                outcome = await self._handle_event(
                    connection=connection,
                    lifecycle_connection=lifecycle,
                    event=event,
                )
                if outcome == "dispatched":
                    dispatched += 1
                elif outcome == "failed":
                    failed += 1
                else:
                    retry += 1

            span.set_attribute("outbox.claimed_count", len(claimed))
            span.set_attribute("outbox.dispatched_count", dispatched)
            span.set_attribute("outbox.retry_count", retry)
            span.set_attribute("outbox.failed_count", failed)
            batch_outcome, batch_reason_code = _batch_observability(
                claimed=len(claimed),
                dispatched=dispatched,
                retry=retry,
                failed=failed,
            )
            span.set_attribute("outbox.outcome", batch_outcome)
            if batch_reason_code is not None:
                span.set_attribute("outbox.reason_code", batch_reason_code)
            _log_batch(
                claimed=len(claimed),
                duration_ms=_duration_ms(started),
                outcome=batch_outcome,
                reason_code=batch_reason_code,
            )
            return OutboxDispatchBatchResult(
                claimed=len(claimed),
                dispatched=dispatched,
                retry=retry,
                failed=failed,
            )

    async def run_until_stopped(
        self,
        *,
        stop_event: asyncio.Event,
    ) -> None:
        while not stop_event.is_set():
            result = await self.drain_once()
            if result.claimed == 0:
                try:
                    await asyncio.wait_for(
                        stop_event.wait(),
                        timeout=self._config.idle_sleep_seconds,
                    )
                except TimeoutError:
                    continue

    async def _handle_event(
        self,
        *,
        connection: asyncpg.Connection,
        lifecycle_connection: asyncpg.Connection,
        event: OutboxEventRecord,
    ) -> str:
        started = time.monotonic()
        with _TRACER.start_as_current_span("outbox.dispatch.event") as span:
            span.set_attribute("outbox.event_type", event.event_type)
            span.set_attribute("outbox.attempt_count", event.attempt_count)
            span.set_attribute("tenant_id", str(event.tenant_id))
            span.set_attribute("outbox_event_id", str(event.id))
            try:
                transaction = getattr(connection, "transaction", None)
                if callable(transaction):
                    async with cast(Any, transaction()):
                        await _call_fanout_handler(
                            self._fanout_handler,
                            connection=connection,
                            lifecycle_connection=lifecycle_connection,
                            event=event,
                        )
                else:
                    await _call_fanout_handler(
                        self._fanout_handler,
                        connection=connection,
                        lifecycle_connection=lifecycle_connection,
                        event=event,
                    )
            except Exception:
                outcome = await mark_outbox_attempt_failed(
                    connection=lifecycle_connection,
                    outbox_event_id=event.id,
                    dispatcher_id=self._config.dispatcher_id,
                    failure_reason_code="fanout_failed",
                    max_attempts=self._config.max_attempts,
                )
                _log_event(
                    event=event,
                    duration_ms=_duration_ms(started),
                    outcome=outcome,
                    reason_code="fanout_failed",
                )
                span.set_attribute("outbox.outcome", outcome)
                span.set_attribute("outbox.reason_code", "fanout_failed")
                return outcome

            marked = await mark_outbox_dispatched(
                connection=lifecycle_connection,
                outbox_event_id=event.id,
                dispatcher_id=self._config.dispatcher_id,
            )
            if not marked:
                _log_event(
                    event=event,
                    duration_ms=_duration_ms(started),
                    outcome="retry",
                    reason_code="claim_lost",
                )
                span.set_attribute("outbox.outcome", "retry")
                span.set_attribute("outbox.reason_code", "claim_lost")
                return "retry"
            _log_event(
                event=event,
                duration_ms=_duration_ms(started),
                outcome="dispatched",
                reason_code=None,
            )
            span.set_attribute("outbox.outcome", "dispatched")
            return "dispatched"


def _duration_ms(started: float) -> float:
    return max(0.0, round((time.monotonic() - started) * 1000, 3))


async def _call_fanout_handler(
    fanout_handler: FanoutHandler,
    *,
    connection: asyncpg.Connection,
    lifecycle_connection: asyncpg.Connection,
    event: OutboxEventRecord,
) -> None:
    dispatch_event = getattr(fanout_handler, "dispatch_event", None)
    accepts_failure_connection = callable(dispatch_event) and (
        "failure_connection" in inspect.signature(dispatch_event).parameters
    )
    if accepts_failure_connection:
        await cast(Any, dispatch_event)(
            connection=connection,
            failure_connection=lifecycle_connection,
            event=event,
        )
        return
    await fanout_handler(connection, event)


def _batch_observability(
    *,
    claimed: int,
    dispatched: int,
    retry: int,
    failed: int,
) -> tuple[str, str | None]:
    if claimed == 0:
        return "idle", None
    if failed > 0:
        return "failed", "event_failed"
    if retry > 0:
        return "retry", "event_retry"
    return "dispatched", None


def _log_batch(
    *,
    claimed: int,
    duration_ms: float,
    outcome: str,
    reason_code: str | None,
) -> None:
    fields: dict[str, object] = {
        "event_type": "outbox.dispatch.batch",
        "count": claimed,
        "duration_ms": duration_ms,
        "outcome": outcome,
    }
    if reason_code is not None:
        fields["reason_code"] = reason_code
    log.info("outbox.dispatch.batch", **fields)


def _log_event(
    *,
    event: OutboxEventRecord,
    duration_ms: float,
    outcome: str,
    reason_code: str | None,
) -> None:
    fields: dict[str, object] = {
        "event_type": event.event_type,
        "outbox_event_id": str(event.id),
        "tenant_id": str(event.tenant_id),
        "duration_ms": duration_ms,
        "outcome": outcome,
    }
    if reason_code is not None:
        fields["reason_code"] = reason_code
    log.info("outbox.dispatch.event", **fields)


__all__ = [
    "AsyncConnectionFactory",
    "FanoutHandler",
    "OutboxDispatchBatchResult",
    "OutboxDispatcher",
    "OutboxDispatcherConfig",
    "OutboxDispatcherError",
]
