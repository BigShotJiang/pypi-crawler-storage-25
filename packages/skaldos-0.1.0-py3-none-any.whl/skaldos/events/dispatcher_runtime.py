"""Runtime entrypoint for the outbox-to-Pub/Sub dispatcher.

The dispatcher uses two database roles:

* ``app_dispatcher`` on a direct connection for outbox lifecycle helpers.
* ``app_runtime`` for RLS-bound subscription eligibility and cursor updates.

This keeps the claim/mark privilege narrow while preserving the normal tenant
and classification policies for the delivery matching query.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from collections.abc import Awaitable, Callable, Coroutine, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, cast

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
import httpx
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider

from skaldos.events.dispatcher import (
    AsyncConnectionFactory,
    OutboxDispatcher,
    OutboxDispatcherConfig,
)
from skaldos.events.outbox import OutboxEventRecord
from skaldos.events.pubsub_delivery import (
    DEFAULT_REGION_STORAGE_POLICY,
    ExternalEventFanoutDispatcher,
    ExternalEventTopicResolver,
    PubSubPushHmacSecretResolver,
    PubSubRestExternalEventPublisher,
)
from skaldos.events.subscription_store import EventSubscriptionDeliveryTarget

DEFAULT_DISPATCHER_ID = "skaldos-outbox-dispatcher"
DEFAULT_PUBSUB_ENVIRONMENT = "phase125"
DEFAULT_HTTP_TIMEOUT_SECONDS = 10.0
_METADATA_TOKEN_URL = (
    "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"
)
_TRACER = trace.get_tracer(__name__)


class DispatcherRuntimeConfigError(ValueError):
    """Raised when runtime environment is incomplete or unsafe."""


@dataclass(frozen=True, slots=True)
class DispatcherRuntimeConfig:
    lifecycle_database_url: str
    fanout_database_url: str
    pubsub_project_id: str
    pubsub_environment: str = DEFAULT_PUBSUB_ENVIRONMENT
    dispatcher_id: str = DEFAULT_DISPATCHER_ID
    batch_size: int = 100
    reclaim_timeout_seconds: int = 300
    max_attempts: int = 10
    http_timeout_seconds: float = DEFAULT_HTTP_TIMEOUT_SECONDS
    pubsub_api_base_url: str = "https://pubsub.googleapis.com"
    pubsub_bearer_token: str | None = None
    pubsub_push_hmac_secret_ref: str | None = None
    pubsub_push_hmac_secret: str | None = None
    region_storage_policy: Mapping[str, tuple[str, ...]] | None = None


@dataclass(frozen=True, slots=True)
class StaticPubSubPushHmacSecretResolver:
    expected_secret_ref: str
    secret: str

    def secret_for_delivery_target(self, target: EventSubscriptionDeliveryTarget) -> str:
        if target.delivery.hmac_secret_ref != self.expected_secret_ref:
            raise DispatcherRuntimeConfigError("pubsub_push_hmac_secret_ref_mismatch")
        return self.secret


class EventTenantRuntimeContextFanout:
    """Set per-event RLS GUCs before evaluating external delivery eligibility."""

    def __init__(
        self,
        delegate: ExternalEventFanoutDispatcher,
        *,
        failure_connection_factory: AsyncConnectionFactory | None = None,
    ) -> None:
        self._delegate = delegate
        self._failure_connection_factory = failure_connection_factory

    async def dispatch_event(
        self,
        *,
        connection: asyncpg.Connection,
        failure_connection: asyncpg.Connection | None = None,
        event: OutboxEventRecord,
    ) -> object:
        await set_event_runtime_context(connection=connection, event=event)
        failure_runtime_connection: asyncpg.Connection | None = None
        try:
            if self._failure_connection_factory is not None:
                failure_runtime_connection = await self._failure_connection_factory()
                await set_event_runtime_context(
                    connection=failure_runtime_connection,
                    event=event,
                )
            return await self._delegate.dispatch_event(
                connection=connection,
                failure_connection=failure_runtime_connection or failure_connection,
                event=event,
            )
        finally:
            if failure_runtime_connection is not None:
                await failure_runtime_connection.close()  # pyright: ignore[reportUnknownMemberType]


def config_from_env(env: Mapping[str, str] = os.environ) -> DispatcherRuntimeConfig:
    lifecycle_database_url = _required_env(env, "OUTBOX_DISPATCHER_DATABASE_URL")
    fanout_database_url = _required_env(env, "OUTBOX_FANOUT_DATABASE_URL")
    pubsub_project_id = _required_env(env, "PUBSUB_PROJECT_ID")
    return DispatcherRuntimeConfig(
        lifecycle_database_url=lifecycle_database_url,
        fanout_database_url=fanout_database_url,
        pubsub_project_id=pubsub_project_id,
        pubsub_environment=env.get("PUBSUB_ENVIRONMENT", DEFAULT_PUBSUB_ENVIRONMENT),
        dispatcher_id=env.get("OUTBOX_DISPATCHER_ID", DEFAULT_DISPATCHER_ID),
        batch_size=_int_env(env, "OUTBOX_DISPATCHER_BATCH_SIZE", 100),
        reclaim_timeout_seconds=_int_env(env, "OUTBOX_RECLAIM_TIMEOUT_SECONDS", 300),
        max_attempts=_int_env(env, "OUTBOX_MAX_ATTEMPTS", 10),
        http_timeout_seconds=_float_env(env, "PUBSUB_HTTP_TIMEOUT_SECONDS", 10.0),
        pubsub_api_base_url=env.get("PUBSUB_API_BASE_URL", "https://pubsub.googleapis.com"),
        pubsub_bearer_token=env.get("PUBSUB_BEARER_TOKEN"),
        pubsub_push_hmac_secret_ref=env.get("PUBSUB_PUSH_HMAC_SECRET_REF"),
        pubsub_push_hmac_secret=env.get("PUBSUB_PUSH_HMAC_SECRET"),
        region_storage_policy=_region_storage_policy_from_env(env),
    )


async def drain_once(config: DispatcherRuntimeConfig) -> dict[str, int]:
    _install_tracer_provider_if_needed()
    async with httpx.AsyncClient(timeout=config.http_timeout_seconds) as http_client:
        dispatcher = _build_dispatcher(config=config, http_client=http_client)
        with _TRACER.start_as_current_span("outbox.dispatcher_runtime.drain_once"):
            result = await dispatcher.drain_once()
    return {
        "claimed": result.claimed,
        "dispatched": result.dispatched,
        "retry": result.retry,
        "failed": result.failed,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="skaldos-outbox-dispatcher")
    parser.add_argument("command", choices=("drain-once",))
    args = parser.parse_args(argv)
    try:
        config = config_from_env()
        if args.command == "drain-once":
            result = asyncio.run(drain_once(config))
        else:  # pragma: no cover - argparse choices make this unreachable.
            raise DispatcherRuntimeConfigError("dispatcher_command_unknown")
    except DispatcherRuntimeConfigError as exc:
        sys.stderr.write(f"error: {exc}\n")
        return 2
    except Exception as exc:
        sys.stderr.write(f"error: dispatcher_drain_failed: {type(exc).__name__}\n")
        return 1
    sys.stdout.write(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")
    return 0


def _build_dispatcher(
    *,
    config: DispatcherRuntimeConfig,
    http_client: httpx.AsyncClient,
) -> OutboxDispatcher:
    topic_resolver = ExternalEventTopicResolver(
        project_id=config.pubsub_project_id,
        environment=config.pubsub_environment,
        region_storage_policy=config.region_storage_policy or DEFAULT_REGION_STORAGE_POLICY,
    )
    publisher = PubSubRestExternalEventPublisher(
        http_client=http_client,
        api_base_url=config.pubsub_api_base_url,
        bearer_token_provider=_bearer_token_provider(
            configured_token=config.pubsub_bearer_token,
            http_client=http_client,
        ),
    )
    fanout = EventTenantRuntimeContextFanout(
        ExternalEventFanoutDispatcher(
            topic_resolver=topic_resolver,
            publisher=publisher,
            push_hmac_secret_resolver=_push_hmac_secret_resolver(config),
        ),
        failure_connection_factory=cast(
            AsyncConnectionFactory,
            _connection_factory(config.fanout_database_url),
        ),
    )
    return OutboxDispatcher(
        config=OutboxDispatcherConfig(
            dispatcher_id=config.dispatcher_id,
            batch_size=config.batch_size,
            reclaim_timeout_seconds=config.reclaim_timeout_seconds,
            max_attempts=config.max_attempts,
        ),
        connection_factory=cast(
            AsyncConnectionFactory,
            _connection_factory(config.fanout_database_url),
        ),
        lifecycle_connection_factory=cast(
            AsyncConnectionFactory,
            _connection_factory(config.lifecycle_database_url),
        ),
        fanout_handler=cast(Any, fanout),
    )


def _push_hmac_secret_resolver(
    config: DispatcherRuntimeConfig,
) -> PubSubPushHmacSecretResolver | None:
    if config.pubsub_push_hmac_secret_ref is None and config.pubsub_push_hmac_secret is None:
        return None
    if not config.pubsub_push_hmac_secret_ref:
        raise DispatcherRuntimeConfigError("pubsub_push_hmac_secret_ref_missing")
    if not config.pubsub_push_hmac_secret:
        raise DispatcherRuntimeConfigError("pubsub_push_hmac_secret_missing")
    return StaticPubSubPushHmacSecretResolver(
        expected_secret_ref=config.pubsub_push_hmac_secret_ref,
        secret=config.pubsub_push_hmac_secret,
    )


def _install_tracer_provider_if_needed() -> None:
    current = trace.get_tracer_provider()
    if isinstance(current, TracerProvider):
        return
    trace.set_tracer_provider(TracerProvider())


def _connection_factory(database_url: str) -> Callable[[], Coroutine[Any, Any, asyncpg.Connection]]:
    async def _connect() -> asyncpg.Connection:
        connect = cast(
            Callable[[str], Awaitable[asyncpg.Connection]],
            asyncpg.connect,  # pyright: ignore[reportUnknownMemberType]
        )
        return await connect(database_url)

    return _connect


def _bearer_token_provider(
    *,
    configured_token: str | None,
    http_client: httpx.AsyncClient,
) -> Callable[[], Awaitable[str]] | Callable[[], str]:
    if configured_token:
        return lambda: configured_token

    async def _metadata_token() -> str:
        response = await http_client.get(
            _METADATA_TOKEN_URL,
            headers={"Metadata-Flavor": "Google"},
        )
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise DispatcherRuntimeConfigError("metadata_token_response_invalid")
        payload_mapping = cast(Mapping[str, object], payload)
        access_token = payload_mapping.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise DispatcherRuntimeConfigError("metadata_token_missing")
        return access_token

    return _metadata_token


async def set_event_runtime_context(
    *,
    connection: asyncpg.Connection,
    event: OutboxEventRecord,
) -> None:
    tenant_id = str(event.tenant_id)
    vertical = event.context_of_validity.get("vertical")
    ontology_version = event.context_of_validity.get("ontology_version")
    context = {
        "tenants": [tenant_id],
        "classification": "C4",
        "clearances": {tenant_id: "C4"},
        "verticals": [vertical] if isinstance(vertical, str) else [],
        "ontology_versions": [ontology_version] if isinstance(ontology_version, str) else [],
    }
    execute = cast(
        Callable[[str, str, str], Awaitable[str]],
        connection.execute,  # pyright: ignore[reportUnknownMemberType]
    )
    await execute(
        "SELECT set_config($1, $2, true)",
        "app.current_principal_id",
        "00000000-0000-0000-0000-000000000000",
    )
    await execute(
        "SELECT set_config($1, $2, true)",
        "app.current_principal_visible",
        "{" + tenant_id + "}",
    )
    await execute(
        "SELECT set_config($1, $2, true)",
        "app.current_principal_context",
        json.dumps(context, separators=(",", ":")),
    )


def _required_env(env: Mapping[str, str], name: str) -> str:
    value = env.get(name)
    if not value:
        raise DispatcherRuntimeConfigError(f"{name.lower()}_missing")
    return value


def _int_env(env: Mapping[str, str], name: str, default: int) -> int:
    raw = env.get(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise DispatcherRuntimeConfigError(f"{name.lower()}_invalid") from exc
    if value < 1:
        raise DispatcherRuntimeConfigError(f"{name.lower()}_invalid")
    return value


def _float_env(env: Mapping[str, str], name: str, default: float) -> float:
    raw = env.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise DispatcherRuntimeConfigError(f"{name.lower()}_invalid") from exc
    if value <= 0:
        raise DispatcherRuntimeConfigError(f"{name.lower()}_invalid")
    return value


def _region_storage_policy_from_env(
    env: Mapping[str, str],
) -> Mapping[str, tuple[str, ...]] | None:
    raw = env.get("PUBSUB_REGION_STORAGE_POLICY_JSON")
    if not raw:
        return None
    try:
        payload = json.loads(raw)
    except ValueError as exc:
        raise DispatcherRuntimeConfigError("pubsub_region_storage_policy_json_invalid") from exc
    if not isinstance(payload, dict):
        raise DispatcherRuntimeConfigError("pubsub_region_storage_policy_json_invalid")
    payload_mapping = cast(Mapping[object, object], payload)
    policy: dict[str, tuple[str, ...]] = {}
    for region, storage_regions in payload_mapping.items():
        if not isinstance(region, str) or not isinstance(storage_regions, list):
            raise DispatcherRuntimeConfigError("pubsub_region_storage_policy_json_invalid")
        normalized_storage_regions: list[str] = []
        storage_region_items = cast(Sequence[object], storage_regions)
        for storage_region in storage_region_items:
            if not isinstance(storage_region, str):
                raise DispatcherRuntimeConfigError("pubsub_region_storage_policy_json_invalid")
            normalized_storage_regions.append(storage_region)
        policy[region] = tuple(normalized_storage_regions)
    return policy


if __name__ == "__main__":
    raise SystemExit(main())
