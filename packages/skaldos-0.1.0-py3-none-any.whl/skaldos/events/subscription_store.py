"""Storage service for external event subscriptions."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping, Sequence
from datetime import datetime
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.events.outbox import OutboxEventRecord
from skaldos.events.subscriptions import (
    EndpointResolver,
    EventSubscriptionFilter,
    EventSubscriptionValidationError,
    PushDeliveryTarget,
    normalize_push_delivery_target,
    validate_event_subscription_filter,
)
from skaldos.middleware import Principal

EventSubscriptionState = Literal["active", "paused", "failed"]
DeliveryFailureTerminalState = Literal["paused", "failed"]
DELIVERY_FAILURE_REASON_CODES = frozenset(
    {
        "delivery_timeout",
        "endpoint_4xx",
        "endpoint_5xx",
        "endpoint_timeout",
        "hmac_verification_failed",
        "oidc_verification_failed",
        "pubsub_dead_lettered",
        "pubsub_publish_failed",
        "pubsub_retry",
        "subscriber_rejected",
    }
)
_SAFE_REASON_CODE_SHAPE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
_EVENT_HASH = re.compile(r"^[0-9a-f]{64}$")


class EventSubscriptionRecord(BaseModel):
    """API-safe projection of one external event subscription."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    subscriber_kind: Literal["external"]
    subscriber_principal_id: UUID
    filter: EventSubscriptionFilter
    delivery: PushDeliveryTarget
    state: EventSubscriptionState
    last_delivered_event_ref: str | None
    failure_count: int
    failure_reason_code: str | None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None
    version: int


class EventSubscriptionDeliveryTarget(BaseModel):
    """Delivery-safe active subscription projection for one outbox event."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    subscription_id: UUID
    tenant_id: UUID
    subscriber_principal_id: UUID
    event_id_hash: str
    event_type: str
    subject_type: str
    subject_id: UUID
    delivery: PushDeliveryTarget
    filter: EventSubscriptionFilter
    last_delivered_event_ref: str | None
    failure_count: int


class EventSubscriptionCreate(BaseModel):
    """Validated create payload consumed by the storage layer."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    subscriber_principal_id: UUID
    filter: EventSubscriptionFilter
    delivery: PushDeliveryTarget
    state: Literal["active", "paused"] = "active"


class EventSubscriptionPatch(BaseModel):
    """Validated patch payload consumed by the storage layer."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    version: int
    filter: EventSubscriptionFilter | None = None
    delivery: PushDeliveryTarget | None = None
    state: Literal["active", "paused"] | None = None


class EventSubscriptionNotFoundError(LookupError):
    """Subscription was absent, archived, or invisible under RLS."""


class EventSubscriptionConflictError(RuntimeError):
    """Optimistic version or duplicate-active-subscription conflict."""


class EventSubscriptionStorageError(RuntimeError):
    """Unexpected database failure while storing subscriptions."""


class EventSubscriptionStore:
    """Validate and persist Slice 8 external subscription rows."""

    def __init__(
        self,
        *,
        allow_http_for_tests: bool = False,
        endpoint_resolver: EndpointResolver | None = None,
    ) -> None:
        self._allow_http_for_tests = allow_http_for_tests
        self._endpoint_resolver = endpoint_resolver

    async def create_subscription(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        tenant_id: UUID,
        filter_payload: object,
        delivery_payload: object,
        subscriber_principal_id: UUID | None = None,
        state: Literal["active", "paused"] = "active",
    ) -> EventSubscriptionRecord:
        if tenant_id not in principal.visible_tenant_ids:
            raise EventSubscriptionNotFoundError("event_subscription_tenant_not_visible")
        subscriber_id = subscriber_principal_id or principal.id
        await _ensure_subscriber_principal_in_tenant(
            connection=connection,
            tenant_id=tenant_id,
            subscriber_principal_id=subscriber_id,
        )
        normalized_filter = await validate_event_subscription_filter(
            connection=connection,
            tenant_id=tenant_id,
            payload=filter_payload,
        )
        normalized_delivery = self._normalize_delivery(delivery_payload)
        create = EventSubscriptionCreate(
            tenant_id=tenant_id,
            subscriber_principal_id=subscriber_id,
            filter=normalized_filter,
            delivery=normalized_delivery,
            state=state,
        )
        await _raise_if_duplicate_active(
            connection=connection,
            subscription=create,
            exclude_subscription_id=None,
        )
        try:
            row = cast(
                Mapping[str, Any],
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
INSERT INTO event_subscription (
  tenant_id, subscriber_kind, subscriber_principal_id, "filter", delivery, state
)
VALUES ($1, 'external', $2, $3::jsonb, $4::jsonb, $5)
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    create.tenant_id,
                    create.subscriber_principal_id,
                    _filter_json(create.filter),
                    create.delivery.model_dump_json(),
                    create.state,
                ),
            )
        except asyncpg.UniqueViolationError as exc:  # pyright: ignore[reportUnknownMemberType]
            raise EventSubscriptionConflictError("event_subscription_duplicate_active") from exc
        except Exception as exc:
            raise EventSubscriptionStorageError("event_subscription_create_failed") from exc
        return _record_from_row(row)

    async def get_subscription(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
    ) -> EventSubscriptionRecord:
        row = await _fetch_subscription(connection=connection, subscription_id=subscription_id)
        if row is None:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        return _record_from_row(row)

    async def list_subscriptions(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        include_archived: bool = False,
    ) -> tuple[EventSubscriptionRecord, ...]:
        try:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    """
SELECT id, tenant_id, subscriber_kind, subscriber_principal_id,
       "filter", delivery, state, last_delivered_event_ref,
       failure_count, failure_reason_code, created_at, updated_at,
       archived_at, version
FROM event_subscription
WHERE tenant_id = $1
  AND ($2::boolean OR archived_at IS NULL)
ORDER BY archived_at NULLS FIRST, created_at DESC, id ASC
""",
                    tenant_id,
                    include_archived,
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError("event_subscription_list_failed") from exc
        return tuple(_record_from_row(row) for row in rows)

    async def patch_subscription(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
        tenant_id: UUID,
        version: int,
        filter_payload: object | None = None,
        delivery_payload: object | None = None,
        state: Literal["active", "paused"] | None = None,
    ) -> EventSubscriptionRecord:
        current = await self.get_subscription(
            connection=connection,
            subscription_id=subscription_id,
        )
        if current.tenant_id != tenant_id:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        if current.version != version:
            raise EventSubscriptionConflictError("event_subscription_version_conflict")
        normalized_filter = (
            await validate_event_subscription_filter(
                connection=connection,
                tenant_id=tenant_id,
                payload=filter_payload,
            )
            if filter_payload is not None
            else None
        )
        normalized_delivery = (
            self._normalize_delivery(delivery_payload) if delivery_payload is not None else None
        )
        patch = EventSubscriptionPatch(
            version=version,
            filter=normalized_filter,
            delivery=normalized_delivery,
            state=state,
        )
        if patch.state == "active" and current.state == "failed":
            raise EventSubscriptionValidationError("event_subscription_failed_requires_repair")
        next_state = patch.state or current.state
        if next_state == "active":
            await _raise_if_duplicate_active(
                connection=connection,
                subscription=EventSubscriptionCreate(
                    tenant_id=tenant_id,
                    subscriber_principal_id=current.subscriber_principal_id,
                    filter=patch.filter or current.filter,
                    delivery=patch.delivery or current.delivery,
                    state="active",
                ),
                exclude_subscription_id=subscription_id,
            )
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE event_subscription
SET "filter" = COALESCE($4::jsonb, "filter"),
    delivery = COALESCE($5::jsonb, delivery),
    state = COALESCE($6::text, state),
    version = version + 1,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND version = $3
  AND archived_at IS NULL
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    subscription_id,
                    tenant_id,
                    patch.version,
                    _filter_json(patch.filter) if patch.filter is not None else None,
                    patch.delivery.model_dump_json() if patch.delivery is not None else None,
                    patch.state,
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError("event_subscription_update_failed") from exc
        if row is None:
            raise EventSubscriptionConflictError("event_subscription_version_conflict")
        return _record_from_row(row)

    async def transition_subscription(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
        tenant_id: UUID,
        version: int,
        action: Literal["pause", "resume"],
    ) -> EventSubscriptionRecord:
        current = await self.get_subscription(
            connection=connection,
            subscription_id=subscription_id,
        )
        if current.tenant_id != tenant_id:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        if current.version != version:
            raise EventSubscriptionConflictError("event_subscription_version_conflict")
        if current.state == "paused" and action == "pause":
            return current
        if current.state == "active" and action == "resume":
            return current
        next_state = "paused" if action == "pause" else "active"
        allowed_current = ("active", "failed") if action == "pause" else ("paused",)
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE event_subscription
SET state = $5,
    version = version + 1,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND version = $3
  AND archived_at IS NULL
  AND state = ANY($4::text[])
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    subscription_id,
                    tenant_id,
                    version,
                    list(allowed_current),
                    next_state,
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError("event_subscription_transition_failed") from exc
        if row is None:
            raise EventSubscriptionConflictError("event_subscription_transition_conflict")
        return _record_from_row(row)

    async def repair_subscription(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
        tenant_id: UUID,
        version: int,
        delivery_payload: object,
    ) -> EventSubscriptionRecord:
        current = await self.get_subscription(
            connection=connection,
            subscription_id=subscription_id,
        )
        if current.tenant_id != tenant_id:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        normalized_delivery = self._normalize_delivery(delivery_payload)
        await _raise_if_duplicate_active(
            connection=connection,
            subscription=EventSubscriptionCreate(
                tenant_id=tenant_id,
                subscriber_principal_id=current.subscriber_principal_id,
                filter=current.filter,
                delivery=normalized_delivery,
                state="active",
            ),
            exclude_subscription_id=subscription_id,
        )
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE event_subscription
SET delivery = $4::jsonb,
    state = 'active',
    failure_count = 0,
    failure_reason_code = NULL,
    version = version + 1,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND version = $3
  AND archived_at IS NULL
  AND state = 'failed'
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    subscription_id,
                    tenant_id,
                    version,
                    normalized_delivery.model_dump_json(),
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError("event_subscription_repair_failed") from exc
        if row is None:
            raise EventSubscriptionConflictError("event_subscription_repair_conflict")
        return _record_from_row(row)

    async def archive_subscription(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
        tenant_id: UUID,
        version: int,
    ) -> EventSubscriptionRecord:
        current = await self.get_subscription(
            connection=connection,
            subscription_id=subscription_id,
        )
        if current.tenant_id != tenant_id:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE event_subscription
SET archived_at = COALESCE(archived_at, now()),
    updated_at = now(),
    version = version + 1
WHERE id = $1
  AND tenant_id = $2
  AND version = $3
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    subscription_id,
                    tenant_id,
                    version,
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError("event_subscription_archive_failed") from exc
        if row is None:
            raise EventSubscriptionConflictError("event_subscription_version_conflict")
        return _record_from_row(row)

    async def list_delivery_eligible_subscriptions(
        self,
        *,
        connection: asyncpg.Connection,
        event: OutboxEventRecord,
    ) -> tuple[EventSubscriptionDeliveryTarget, ...]:
        """Return active external subscriptions eligible for one outbox event.

        This is the app-side pre-push gate consumed by the Pub/Sub delivery
        bundle. It deliberately returns only delivery handles and secret refs;
        no graph content is loaded or exposed.
        """

        event_classification = _classification_from_event(event)
        try:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    _DELIVERY_ELIGIBILITY_SQL,
                    event.tenant_id,
                    event.event_type,
                    event.subject_type,
                    event.subject_id,
                    event.event_id_hash,
                    event_classification,
                    json.dumps(event.context_of_validity, separators=(",", ":")),
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError(
                "event_subscription_delivery_eligibility_failed"
            ) from exc
        return tuple(_delivery_target_from_row(row) for row in rows)

    async def mark_delivery_succeeded(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
        tenant_id: UUID,
        event_id_hash: str,
    ) -> EventSubscriptionRecord:
        """Advance the delivery cursor after a successful push publish."""

        _validate_event_hash(event_id_hash)
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE event_subscription
SET last_delivered_event_ref = $3,
    failure_reason_code = NULL,
    version = version + 1,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
  AND state = 'active'
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    subscription_id,
                    tenant_id,
                    event_id_hash,
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError(
                "event_subscription_delivery_success_failed"
            ) from exc
        if row is None:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        return _record_from_row(row)

    async def record_delivery_failure(
        self,
        *,
        connection: asyncpg.Connection,
        subscription_id: UUID,
        tenant_id: UUID,
        reason_code: str,
        terminal_state: DeliveryFailureTerminalState | None = None,
    ) -> EventSubscriptionRecord:
        """Record a delivery failure without storing endpoint response content."""

        _validate_reason_code(reason_code)
        if terminal_state not in (None, "paused", "failed"):
            raise EventSubscriptionValidationError(
                "event_subscription_delivery_terminal_state_invalid"
            )
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
UPDATE event_subscription
SET failure_count = failure_count + 1,
    failure_reason_code = $3,
    state = COALESCE($4::text, state),
    version = version + 1,
    updated_at = now()
WHERE id = $1
  AND tenant_id = $2
  AND archived_at IS NULL
  AND state = ANY(ARRAY['active', 'paused', 'failed']::text[])
RETURNING id, tenant_id, subscriber_kind, subscriber_principal_id,
          "filter", delivery, state, last_delivered_event_ref,
          failure_count, failure_reason_code, created_at, updated_at,
          archived_at, version
""",
                    subscription_id,
                    tenant_id,
                    reason_code,
                    terminal_state,
                ),
            )
        except Exception as exc:
            raise EventSubscriptionStorageError(
                "event_subscription_delivery_failure_failed"
            ) from exc
        if row is None:
            raise EventSubscriptionNotFoundError("event_subscription_not_found")
        return _record_from_row(row)

    def _normalize_delivery(self, payload: object) -> PushDeliveryTarget:
        return normalize_push_delivery_target(
            payload,
            allow_http_for_tests=self._allow_http_for_tests,
            resolve_endpoint=self._endpoint_resolver,
        )


_DELIVERY_EVENT_FACT_CTE_SQL = """
event_fact AS (
  SELECT
    $1::uuid AS tenant_id,
    $2::text AS event_type,
    $3::text AS subject_type,
    $4::uuid AS subject_id,
    $5::text AS event_id_hash,
    $6::text AS event_classification,
    $7::jsonb AS event_context,
    split_part($2::text, '.', 1) || '.*' AS event_wildcard
)
"""

_DELIVERY_SUBJECT_ELIGIBILITY_LATERAL_SQL = """
JOIN LATERAL (
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'node'
    AND EXISTS (
      SELECT 1
      FROM nodes n
      WHERE n.id = e.subject_id
        AND n.tenant_id = e.tenant_id
        AND n.archived_at IS NULL
        AND n.superseded_by_node_id IS NULL
        AND app.classification_rank(n.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND n.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND n.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND n.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
    )
  UNION ALL
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'edge'
    AND EXISTS (
      SELECT 1
      FROM edges ge
      JOIN nodes source_node ON source_node.id = ge.source_node_id
      JOIN nodes target_node ON target_node.id = ge.target_node_id
      WHERE ge.id = e.subject_id
        AND ge.tenant_id = e.tenant_id
        AND source_node.tenant_id = e.tenant_id
        AND target_node.tenant_id = e.tenant_id
        AND source_node.archived_at IS NULL
        AND target_node.archived_at IS NULL
        AND app.classification_rank(ge.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND app.classification_rank(source_node.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND app.classification_rank(target_node.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND source_node.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND target_node.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND source_node.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND target_node.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND source_node.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
        AND target_node.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
    )
  UNION ALL
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'agent_run'
    AND EXISTS (
      SELECT 1
      FROM agent_run ar
      WHERE ar.id = e.subject_id
        AND ar.tenant_id = e.tenant_id
        AND app.classification_rank(ar.effective_clearance)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND (
          (e.event_type = 'agent.run.completed' AND ar.status = 'succeeded')
          OR (e.event_type = 'agent.run.errored' AND ar.status = 'failed')
          OR (e.event_type = 'agent.run.cancelled' AND ar.status = 'cancelled')
        )
        AND e.event_context ->> 'tenant' = e.tenant_id::text
        AND e.event_context ->> 'vertical' = 'foundation'
        AND e.event_context ->> 'ontology_version' = 'slice-7'
    )
  UNION ALL
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'surprise'
    AND EXISTS (
      SELECT 1
      FROM surprise_stream s
      WHERE s.id = e.subject_id
        AND s.tenant_id = e.tenant_id
        AND app.classification_rank(s.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND s.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND s.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND s.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
    )
  UNION ALL
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'conversation'
    AND EXISTS (
      SELECT 1
      FROM nodes n
      WHERE n.id = e.subject_id
        AND n.tenant_id = e.tenant_id
        AND n.archived_at IS NULL
        AND n.superseded_by_node_id IS NULL
        AND n.metadata ->> 'shape' = 'skaldos.conversation.v1'
        AND app.classification_rank(n.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND n.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND n.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND n.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
    )
  UNION ALL
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'review-flag'
    AND EXISTS (
      SELECT 1
      FROM nodes n
      WHERE n.id = e.subject_id
        AND n.tenant_id = e.tenant_id
        AND n.archived_at IS NULL
        AND n.superseded_by_node_id IS NULL
        AND n.metadata ->> 'shape' = 'skaldos.review_flag.v1'
        AND n.metadata ->> 'status' = 'open'
        AND app.classification_rank(n.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND n.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND n.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND n.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
    )
  UNION ALL
  SELECT 1 AS eligible_subject
  WHERE
    e.subject_type = 'tag'
    AND EXISTS (
      SELECT 1
      FROM node_tags nt
      JOIN nodes n ON n.id = nt.node_id
      WHERE nt.id = e.subject_id
        AND nt.tenant_id = e.tenant_id
        AND n.tenant_id = e.tenant_id
        AND n.archived_at IS NULL
        AND nt.superseded_by_tag_id IS NULL
        AND app.classification_rank(nt.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND app.classification_rank(n.classification)
            <= app.classification_rank(subscriber_membership.max_clearance)
        AND nt.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND n.context_of_validity ->> 'tenant' = e.event_context ->> 'tenant'
        AND nt.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND n.context_of_validity ->> 'vertical' = e.event_context ->> 'vertical'
        AND nt.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
        AND n.context_of_validity ->> 'ontology_version'
            = e.event_context ->> 'ontology_version'
    )
  LIMIT 1
) eligible_subject ON TRUE
"""

_DELIVERY_SUBSCRIPTION_FILTER_SQL = """
  AND (
    es."filter"->'event_types' ? e.event_type
    OR es."filter"->'event_types' ? e.event_wildcard
  )
  AND (
    NOT (es."filter" ? 'subject_types')
    OR es."filter"->'subject_types' = 'null'::jsonb
    OR es."filter"->'subject_types' ? e.subject_type
  )
  AND (
    NOT (es."filter" ? 'tag_filters')
    OR es."filter"->'tag_filters' = 'null'::jsonb
    OR (
      e.subject_type = 'node'
      AND EXISTS (
        SELECT 1
        FROM node_tags nt
        WHERE nt.node_id = e.subject_id
          AND nt.tenant_id = e.tenant_id
          AND nt.superseded_by_tag_id IS NULL
          AND es."filter"#>'{tag_filters,tag_definition_ids}' ? nt.tag_definition_id::text
      )
    )
    OR (
      e.subject_type IN ('conversation', 'review-flag')
      AND EXISTS (
        SELECT 1
        FROM node_tags nt
        WHERE nt.node_id = e.subject_id
          AND nt.tenant_id = e.tenant_id
          AND nt.superseded_by_tag_id IS NULL
          AND es."filter"#>'{tag_filters,tag_definition_ids}' ? nt.tag_definition_id::text
      )
    )
    OR (
      e.subject_type = 'tag'
      AND EXISTS (
        SELECT 1
        FROM node_tags nt
        WHERE nt.id = e.subject_id
          AND nt.tenant_id = e.tenant_id
          AND nt.superseded_by_tag_id IS NULL
          AND es."filter"#>'{tag_filters,tag_definition_ids}' ? nt.tag_definition_id::text
      )
    )
  )
  AND (
    NOT (es."filter" ? 'lens_id')
    OR es."filter"->'lens_id' = 'null'::jsonb
    OR EXISTS (
      SELECT 1
      FROM lens_definitions ld
      WHERE ld.id = (es."filter"->>'lens_id')::uuid
        AND ld.tenant_id = es.tenant_id
        AND ld.archived_at IS NULL
        AND (
          jsonb_array_length(COALESCE(ld.definition->'rules', '[]'::jsonb)) = 0
          OR EXISTS (
            SELECT 1
            FROM jsonb_array_elements(COALESCE(ld.definition->'rules', '[]'::jsonb)) AS rule(value)
            WHERE (
                 rule.value#>>'{signal,kind}' = 'tag'
                 AND (
                   (
                     e.subject_type IN ('node', 'conversation', 'review-flag')
                     AND EXISTS (
                       SELECT 1
                       FROM node_tags nt
                       WHERE nt.node_id = e.subject_id
                         AND nt.tenant_id = e.tenant_id
                         AND nt.superseded_by_tag_id IS NULL
                         AND nt.tag_definition_id::text = rule.value#>>'{signal,value}'
                     )
                   )
                   OR (
                     e.subject_type = 'tag'
                     AND EXISTS (
                       SELECT 1
                       FROM node_tags nt
                       WHERE nt.id = e.subject_id
                         AND nt.tenant_id = e.tenant_id
                         AND nt.superseded_by_tag_id IS NULL
                         AND nt.tag_definition_id::text = rule.value#>>'{signal,value}'
                     )
                   )
                 )
               )
               OR (
                 rule.value#>>'{signal,kind}' = 'type'
                 AND e.subject_type IN ('node', 'conversation', 'review-flag')
                 AND EXISTS (
                   SELECT 1
                   FROM nodes n
                   WHERE n.id = e.subject_id
                     AND n.tenant_id = e.tenant_id
                     AND n.type_id::text = rule.value#>>'{signal,value}'
                 )
               )
          )
        )
    )
  )
"""

_DELIVERY_ELIGIBILITY_SQL = f"""
WITH {_DELIVERY_EVENT_FACT_CTE_SQL}
SELECT
  es.id AS subscription_id,
  es.tenant_id,
  es.subscriber_principal_id,
  e.event_id_hash,
  e.event_type,
  e.subject_type,
  e.subject_id,
  es.delivery,
  es."filter",
  es.last_delivered_event_ref,
  es.failure_count
FROM event_subscription es
JOIN event_fact e ON e.tenant_id = es.tenant_id
JOIN principals subscriber_principal
  ON subscriber_principal.id = es.subscriber_principal_id
 AND subscriber_principal.disabled_at IS NULL
JOIN memberships subscriber_membership
  ON subscriber_membership.tenant_id = es.tenant_id
 AND subscriber_membership.principal_id = es.subscriber_principal_id
 AND subscriber_membership.revoked_at IS NULL
 AND subscriber_membership.role = ANY(ARRAY['owner', 'admin', 'member']::membership_role[])
{_DELIVERY_SUBJECT_ELIGIBILITY_LATERAL_SQL}
WHERE es.state = 'active'
  AND es.archived_at IS NULL
  AND es.subscriber_kind = 'external'
  AND app.classification_rank(subscriber_membership.max_clearance)
      >= app.classification_rank(e.event_classification)
{_DELIVERY_SUBSCRIPTION_FILTER_SQL}
ORDER BY es.id ASC
"""


async def _ensure_subscriber_principal_in_tenant(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    subscriber_principal_id: UUID,
) -> None:
    try:
        raw_has_membership = cast(
            object,
            await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT EXISTS (
  SELECT 1
      FROM memberships m
      JOIN principals p
        ON p.id = m.principal_id
       AND p.disabled_at IS NULL
      WHERE m.tenant_id = $1
        AND m.principal_id = $2
        AND m.revoked_at IS NULL
    )
""",
                tenant_id,
                subscriber_principal_id,
            ),
        )
        has_membership = bool(raw_has_membership)
    except Exception as exc:
        raise EventSubscriptionStorageError("event_subscription_subscriber_lookup_failed") from exc
    if not has_membership:
        raise EventSubscriptionValidationError("event_subscription_subscriber_principal_not_found")


async def _raise_if_duplicate_active(
    *,
    connection: asyncpg.Connection,
    subscription: EventSubscriptionCreate,
    exclude_subscription_id: UUID | None,
) -> None:
    try:
        raw_duplicate = cast(
            object,
            await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                """
-- tenant_filter_required: duplicate check is scoped by subscription tenant; RLS also applies.
SELECT EXISTS (
  SELECT 1
  FROM event_subscription
  WHERE tenant_id = $1
    AND subscriber_principal_id = $2
    AND state = 'active'
    AND archived_at IS NULL
    AND jsonb_strip_nulls("filter") = jsonb_strip_nulls($3::jsonb)
    AND delivery->>'endpoint_url' = $4
    AND ($5::uuid IS NULL OR id <> $5)
)
""",
                subscription.tenant_id,
                subscription.subscriber_principal_id,
                _filter_json(subscription.filter),
                subscription.delivery.endpoint_url,
                exclude_subscription_id,
            ),
        )
        duplicate = bool(raw_duplicate)
    except Exception as exc:
        raise EventSubscriptionStorageError("event_subscription_duplicate_check_failed") from exc
    if duplicate:
        raise EventSubscriptionConflictError("event_subscription_duplicate_active")


async def _fetch_subscription(
    *,
    connection: asyncpg.Connection,
    subscription_id: UUID,
) -> Mapping[str, Any] | None:
    try:
        return cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT id, tenant_id, subscriber_kind, subscriber_principal_id,
       "filter", delivery, state, last_delivered_event_ref,
       failure_count, failure_reason_code, created_at, updated_at,
       archived_at, version
FROM event_subscription
WHERE id = $1
  AND archived_at IS NULL
""",
                subscription_id,
            ),
        )
    except Exception as exc:
        raise EventSubscriptionStorageError("event_subscription_load_failed") from exc


def _record_from_row(row: Mapping[str, Any]) -> EventSubscriptionRecord:
    return EventSubscriptionRecord(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        subscriber_kind=cast(Literal["external"], row["subscriber_kind"]),
        subscriber_principal_id=cast(UUID, row["subscriber_principal_id"]),
        filter=EventSubscriptionFilter.model_validate(_json_object(row["filter"])),
        delivery=PushDeliveryTarget.model_validate(_json_object(row["delivery"])),
        state=cast(EventSubscriptionState, row["state"]),
        last_delivered_event_ref=cast(str | None, row["last_delivered_event_ref"]),
        failure_count=int(row["failure_count"]),
        failure_reason_code=cast(str | None, row["failure_reason_code"]),
        created_at=cast(datetime, row["created_at"]),
        updated_at=cast(datetime, row["updated_at"]),
        archived_at=cast(datetime | None, row["archived_at"]),
        version=int(row["version"]),
    )


def _filter_json(value: EventSubscriptionFilter) -> str:
    """Persist optional predicates as absent keys so SQL presence tests are exact."""

    return value.model_dump_json(exclude_none=True)


def _delivery_target_from_row(row: Mapping[str, Any]) -> EventSubscriptionDeliveryTarget:
    return EventSubscriptionDeliveryTarget(
        subscription_id=cast(UUID, row["subscription_id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        subscriber_principal_id=cast(UUID, row["subscriber_principal_id"]),
        event_id_hash=cast(str, row["event_id_hash"]),
        event_type=cast(str, row["event_type"]),
        subject_type=cast(str, row["subject_type"]),
        subject_id=cast(UUID, row["subject_id"]),
        delivery=PushDeliveryTarget.model_validate(_json_object(row["delivery"])),
        filter=EventSubscriptionFilter.model_validate(_json_object(row["filter"])),
        last_delivered_event_ref=cast(str | None, row["last_delivered_event_ref"]),
        failure_count=int(row["failure_count"]),
    )


def _classification_from_event(event: OutboxEventRecord) -> str:
    classification = event.context_of_validity.get("classification")
    if not isinstance(classification, str):
        raise EventSubscriptionStorageError("event_subscription_event_classification_missing")
    if classification not in {"C0", "C1", "C2", "C3", "C4"}:
        raise EventSubscriptionStorageError("event_subscription_event_classification_invalid")
    return classification


def _validate_reason_code(reason_code: str) -> None:
    if not _SAFE_REASON_CODE_SHAPE.fullmatch(reason_code):
        raise EventSubscriptionValidationError("event_subscription_failure_reason_code_invalid")
    if reason_code not in DELIVERY_FAILURE_REASON_CODES:
        raise EventSubscriptionValidationError("event_subscription_failure_reason_code_unknown")


def _validate_event_hash(event_id_hash: str) -> None:
    if not _EVENT_HASH.fullmatch(event_id_hash):
        raise EventSubscriptionValidationError("event_subscription_event_hash_invalid")


def _json_object(value: object) -> dict[str, object]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, object], parsed)
    if isinstance(value, dict):
        return cast(dict[str, object], value)
    raise EventSubscriptionStorageError("event_subscription_json_not_object")


__all__ = [
    "EventSubscriptionConflictError",
    "EventSubscriptionCreate",
    "EventSubscriptionDeliveryTarget",
    "EventSubscriptionNotFoundError",
    "EventSubscriptionPatch",
    "EventSubscriptionRecord",
    "EventSubscriptionState",
    "EventSubscriptionStorageError",
    "EventSubscriptionStore",
    "DeliveryFailureTerminalState",
    "DELIVERY_FAILURE_REASON_CODES",
]
