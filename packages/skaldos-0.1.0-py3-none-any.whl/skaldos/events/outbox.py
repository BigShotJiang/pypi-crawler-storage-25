"""Canonical outbox event envelope helpers for Slice 8."""

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Annotated, Any, Literal, Self, cast
from urllib.parse import urlparse
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

OUTBOX_NOTIFY_CHANNEL = "outbox"
OUTBOX_NOTIFY_BATCH_PAYLOAD = "batch"
OUTBOX_LISTENER_DIRECT_PORT = 5432
OUTBOX_LISTENER_FORBIDDEN_POOLED_PORT = 5431
OUTBOX_DEFAULT_BATCH_SIZE = 100
OUTBOX_DEFAULT_RECLAIM_TIMEOUT_SECONDS = 300
OUTBOX_DEFAULT_MAX_ATTEMPTS = 10

ACTIVE_EVENT_TYPES = frozenset(
    {
        "node.created",
        "node.updated",
        "edge.created",
        "edge.archived",
        "tag.created",
        "tag.superseded",
        "agent.run.completed",
        "agent.run.errored",
        "agent.run.cancelled",
        "surprise.recorded",
        "decision.revised",
        "decision.falsified",
        "review.needed",
        "auto_approve.suspended",
        "surprise.decision_outcome_mismatch",
    }
)

RESERVED_EVENT_TYPES = frozenset(
    {
        "conversation.opened",
        "conversation.promised",
        "conversation.declined",
        "conversation.completed",
        "conversation.satisfied",
        "conversation.rejected",
        "conversation.stalled",
        "conversation.reopened",
    }
)

KNOWN_EVENT_TYPES = ACTIVE_EVENT_TYPES | RESERVED_EVENT_TYPES

_FORBIDDEN_ENVELOPE_KEYS = frozenset(
    {
        "api_key",
        "apikey",
        "authorization",
        "body",
        "claim",
        "content",
        "credentials",
        "endpoint_secret",
        "exact",
        "excerpt",
        "grounding",
        "hmac",
        "payload",
        "prompt",
        "provider_payload",
        "quote",
        "raw_request",
        "raw_response",
        "secret",
        "source",
        "stderr",
        "stdout",
        "text",
        "token",
        "value_text",
    }
)

Clearance = Literal["C0", "C1", "C2", "C3", "C4"]
Intent = Literal["assertive", "directive", "commissive", "expressive", "declarative"]


class OutboxStorageError(RuntimeError):
    """Raised when an outbox storage helper cannot complete safely."""


class OutboxListenerConfigError(ValueError):
    """Raised when dispatcher LISTEN configuration violates PC12."""


@dataclass(frozen=True, slots=True)
class OutboxInsertResult:
    id: UUID
    event_id_hash: str
    inserted: bool


@dataclass(frozen=True, slots=True)
class OutboxEventRecord:
    id: UUID
    tenant_id: UUID
    event_type: str
    subject_type: str
    subject_id: UUID
    event_id_hash: str
    dispatch_state: str
    attempt_count: int
    claimed_by_dispatcher_id: str | None
    claimed_at: datetime | None
    dispatched_at: datetime | None
    failed_at: datetime | None
    failure_reason_code: str | None
    occurred_at: datetime
    context_of_validity: dict[str, Any]
    intent: str
    envelope: dict[str, Any]
    created_at: datetime


class OutboxContextOfValidity(BaseModel):
    """Content-free context handles copied from the accepted write."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant: UUID
    classification: Clearance
    vertical: Annotated[str, Field(min_length=1, max_length=128)] = "foundation"
    ontology_version: UUID | Annotated[str, Field(min_length=1, max_length=128)]
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    @field_validator("valid_from", "valid_to")
    @classmethod
    def _normalize_context_timestamp(cls, value: datetime | None) -> datetime | None:
        return _normalize_datetime(value) if value is not None else None


class OutboxEnvelope(BaseModel):
    """Canonical ID-as-handle event envelope.

    The model intentionally accepts only handles, enums, and timestamps. Full
    graph content, prompts, provider payloads, endpoint material, and secrets are
    rejected before the envelope can be hashed or inserted.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    id_as_handle: Literal[True] = True
    event_type: Annotated[str, Field(min_length=1, max_length=128)]
    subject_type: Annotated[str, Field(min_length=1, max_length=64)]
    subject_id: UUID
    tenant_id: UUID
    context_of_validity: OutboxContextOfValidity
    occurred_at: datetime
    intent: Intent
    conversation_state: Annotated[str, Field(min_length=1, max_length=64)] | None = None
    conversation_state_version: Annotated[int, Field(ge=1)] | None = None
    conversation_episode_id: UUID | None = None
    requester_principal_id: UUID | None = None
    requestee_principal_id: UUID | None = None
    request_act_id: UUID | None = None
    response_act_id: UUID | None = None
    resolution_act_id: UUID | None = None
    sla_deadline: datetime | None = None

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:  # pyright: ignore[reportIncompatibleMethodOverride]
        dumped = super().model_dump(**kwargs)
        return {key: value for key, value in dumped.items() if value is not None}

    @field_validator("event_type")
    @classmethod
    def _event_type_is_known(cls, value: str) -> str:
        if value not in KNOWN_EVENT_TYPES:
            raise ValueError("unknown_event_type")
        return value

    @field_validator("occurred_at", "sla_deadline")
    @classmethod
    def _timestamp_is_utc(cls, value: datetime | None) -> datetime | None:
        return _normalize_datetime(value) if value is not None else None

    @model_validator(mode="after")
    def _envelope_is_handle_only(self) -> Self:
        if self.context_of_validity.tenant != self.tenant_id:
            raise ValueError("tenant_context_mismatch")
        _reject_forbidden_keys(_envelope_json_mapping(self))
        return self


def canonical_event_envelope_bytes(envelope: OutboxEnvelope | dict[str, Any]) -> bytes:
    """Return the service-owned canonical bytes used for `event_id_hash`."""

    model = (
        envelope
        if isinstance(envelope, OutboxEnvelope)
        else OutboxEnvelope.model_validate(envelope)
    )
    normalized = _normalize_json(_envelope_json_mapping(model))
    return json.dumps(
        normalized,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def event_id_hash(envelope: OutboxEnvelope | dict[str, Any]) -> str:
    """Return the hex SHA-256 hash of the canonical envelope bytes."""

    return hashlib.sha256(canonical_event_envelope_bytes(envelope)).hexdigest()


async def insert_outbox_event(
    *,
    connection: asyncpg.Connection,
    envelope: OutboxEnvelope | dict[str, Any],
    suppress_current_transaction_duplicate: bool = False,
) -> OutboxInsertResult:
    """Insert one canonical outbox event inside the caller's transaction.

    PostgreSQL delivers NOTIFY only after commit, so this helper can safely emit
    the wakeup in the same transaction as the durable row. Rollback removes both
    the row and the wakeup.
    """

    model = (
        envelope
        if isinstance(envelope, OutboxEnvelope)
        else OutboxEnvelope.model_validate(envelope)
    )
    envelope_hash = event_id_hash(model)
    envelope_json = _canonical_json_text(_envelope_json_mapping(model))
    context_json = _canonical_json_text(model.context_of_validity.model_dump(mode="json"))
    duplicate_predicate = (
        """
      AND existing.tenant_id = $1
      AND existing.event_type = $2
      AND existing.subject_type = $3
      AND existing.subject_id = $4
      AND existing.intent = $8::assertion_intent
      AND existing.created_at = transaction_timestamp()
"""
        if suppress_current_transaction_duplicate
        else "      AND false\n"
    )
    try:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                f"""
-- tenant_filter_required: outbox insert carries tenant_id; RLS also applies.
WITH inserted AS (
  INSERT INTO outbox_events (
    tenant_id,
    event_type,
    subject_type,
    subject_id,
    event_id_hash,
    occurred_at,
    context_of_validity,
    intent,
    envelope
  )
  SELECT $1, $2, $3, $4, $5, $6, $7::jsonb, $8::assertion_intent, $9::jsonb
  WHERE NOT EXISTS (
    SELECT 1
    FROM outbox_events existing
    WHERE true
{duplicate_predicate}
  )
  ON CONFLICT (event_id_hash) DO NOTHING
  RETURNING id, event_id_hash, true AS inserted
)
SELECT id, event_id_hash, inserted FROM inserted
UNION ALL
SELECT id, event_id_hash, false AS inserted
FROM outbox_events
WHERE event_id_hash = $5
  AND NOT EXISTS (SELECT 1 FROM inserted)
UNION ALL
SELECT id, event_id_hash, false AS inserted
FROM outbox_events existing
WHERE true
{duplicate_predicate}
  AND NOT EXISTS (SELECT 1 FROM inserted)
LIMIT 1
""",
                model.tenant_id,
                model.event_type,
                model.subject_type,
                model.subject_id,
                envelope_hash,
                model.occurred_at,
                context_json,
                model.intent,
                envelope_json,
            ),
        )
        if row is None:
            raise OutboxStorageError("outbox_event_hash_conflict_not_visible")
        if bool(row["inserted"]):
            await connection.execute(  # pyright: ignore[reportUnknownMemberType]
                "SELECT pg_notify($1, $2)",
                OUTBOX_NOTIFY_CHANNEL,
                envelope_hash,
            )
        return OutboxInsertResult(
            id=cast(UUID, row["id"]),
            event_id_hash=cast(str, row["event_id_hash"]),
            inserted=bool(row["inserted"]),
        )
    except OutboxStorageError:
        raise
    except Exception as exc:
        raise OutboxStorageError("outbox_event_insert_failed") from exc


async def claim_outbox_events(
    *,
    connection: asyncpg.Connection,
    dispatcher_id: str,
    batch_size: int = OUTBOX_DEFAULT_BATCH_SIZE,
    reclaim_timeout_seconds: int = OUTBOX_DEFAULT_RECLAIM_TIMEOUT_SECONDS,
    max_attempts: int = OUTBOX_DEFAULT_MAX_ATTEMPTS,
) -> tuple[OutboxEventRecord, ...]:
    """Claim pending or stale outbox rows with the database SKIP LOCKED helper."""

    try:
        rows = cast(
            Sequence[Mapping[str, Any]],
            await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                """
SELECT *
FROM app.outbox_claim_events($1, $2, $3, $4)
""",
                dispatcher_id,
                batch_size,
                reclaim_timeout_seconds,
                max_attempts,
            ),
        )
    except Exception as exc:
        raise OutboxStorageError("outbox_event_claim_failed") from exc
    return tuple(_outbox_record_from_row(row) for row in rows)


async def mark_outbox_dispatched(
    *,
    connection: asyncpg.Connection,
    outbox_event_id: UUID,
    dispatcher_id: str,
) -> bool:
    """Mark one dispatcher-owned claim as dispatched."""

    return await _outbox_bool_function(
        connection=connection,
        function_name="app.outbox_mark_dispatched",
        args=(outbox_event_id, dispatcher_id),
        error_code="outbox_event_mark_dispatched_failed",
    )


async def mark_outbox_attempt_failed(
    *,
    connection: asyncpg.Connection,
    outbox_event_id: UUID,
    dispatcher_id: str,
    failure_reason_code: str,
    max_attempts: int = OUTBOX_DEFAULT_MAX_ATTEMPTS,
) -> str:
    """Record a failed attempt; retryable rows return to pending until exhausted."""

    try:
        outcome = cast(
            str | None,
            await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                "SELECT app.outbox_mark_attempt_failed($1, $2, $3, $4)",
                outbox_event_id,
                dispatcher_id,
                failure_reason_code,
                max_attempts,
            ),
        )
    except Exception as exc:
        raise OutboxStorageError("outbox_event_mark_failed_failed") from exc
    if outcome is None:
        raise OutboxStorageError("outbox_event_mark_failed_no_result")
    return outcome


def validate_outbox_listener_dsn(dsn: str) -> None:
    """Reject PgBouncer transaction-pool listener DSNs.

    LISTEN registration is backend-local, so the dispatcher must hold a direct
    PostgreSQL 5432 session. This guard intentionally keys on the repo's
    canonical local/prod port split rather than attempting network discovery.
    """

    parsed = urlparse(dsn.replace("postgresql+asyncpg://", "postgresql://", 1))
    try:
        port = parsed.port
    except ValueError as exc:
        raise OutboxListenerConfigError("outbox_listener_dsn_invalid_port") from exc
    if port == OUTBOX_LISTENER_FORBIDDEN_POOLED_PORT:
        raise OutboxListenerConfigError("outbox_listener_requires_direct_postgres_5432")


def outbox_notify_payload(event_hash: str | None = None) -> str:
    """Return the content-free NOTIFY payload for one event or a batch wakeup."""

    if event_hash is None:
        return OUTBOX_NOTIFY_BATCH_PAYLOAD
    if len(event_hash) != 64 or any(ch not in "0123456789abcdef" for ch in event_hash):
        raise ValueError("outbox_notify_payload_requires_event_hash")
    return event_hash


def _normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        raise ValueError("timestamp_requires_timezone")
    return value.astimezone(UTC).replace(tzinfo=UTC)


def _envelope_json_mapping(model: OutboxEnvelope) -> dict[str, Any]:
    """Serialize without irrelevant top-level null extension fields.

    Nested context keys intentionally keep ``null`` values: RLS context
    predicates require the full context-of-validity shape, including
    ``valid_to`` when it is open-ended.
    """

    dumped = model.model_dump(mode="json")
    return {key: value for key, value in dumped.items() if value is not None}


def _normalize_json(value: object) -> object:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, dict):
        mapping = cast(Mapping[object, object], value)
        normalized: dict[str, object] = {}
        for key in sorted(mapping.keys(), key=str):
            normalized[unicodedata.normalize("NFC", str(key))] = _normalize_json(mapping[key])
        return normalized
    if isinstance(value, list):
        sequence = cast(Sequence[object], value)
        return [_normalize_json(item) for item in sequence]
    return value


def _reject_forbidden_keys(value: object, *, path: tuple[str, ...] = ()) -> None:
    if isinstance(value, dict):
        mapping = cast(Mapping[object, object], value)
        for key, nested in mapping.items():
            normalized = str(key).lower()
            if normalized in _FORBIDDEN_ENVELOPE_KEYS:
                raise ValueError(f"forbidden_event_content:{'.'.join((*path, str(key)))}")
            _reject_forbidden_keys(nested, path=(*path, str(key)))
        return
    if isinstance(value, list):
        sequence = cast(Sequence[object], value)
        for index, nested in enumerate(sequence):
            _reject_forbidden_keys(nested, path=(*path, str(index)))


def _canonical_json_text(value: object) -> str:
    return json.dumps(
        _normalize_json(value),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


async def _outbox_bool_function(
    *,
    connection: asyncpg.Connection,
    function_name: str,
    args: tuple[object, ...],
    error_code: str,
) -> bool:
    try:
        value = cast(
            bool | None,
            await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                f"SELECT {function_name}($1, $2)",
                *args,
            ),
        )
    except Exception as exc:
        raise OutboxStorageError(error_code) from exc
    return bool(value)


def _outbox_record_from_row(row: Mapping[str, Any]) -> OutboxEventRecord:
    return OutboxEventRecord(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        event_type=cast(str, row["event_type"]),
        subject_type=cast(str, row["subject_type"]),
        subject_id=cast(UUID, row["subject_id"]),
        event_id_hash=cast(str, row["event_id_hash"]),
        dispatch_state=cast(str, row["dispatch_state"]),
        attempt_count=cast(int, row["attempt_count"]),
        claimed_by_dispatcher_id=cast(str | None, row["claimed_by_dispatcher_id"]),
        claimed_at=cast(datetime | None, row["claimed_at"]),
        dispatched_at=cast(datetime | None, row["dispatched_at"]),
        failed_at=cast(datetime | None, row["failed_at"]),
        failure_reason_code=cast(str | None, row["failure_reason_code"]),
        occurred_at=cast(datetime, row["occurred_at"]),
        context_of_validity=_json_mapping(row["context_of_validity"]),
        intent=cast(str, row["intent"]),
        envelope=_json_mapping(row["envelope"]),
        created_at=cast(datetime, row["created_at"]),
    )


def _json_mapping(value: object) -> dict[str, Any]:
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return cast(dict[str, Any], parsed)
    if isinstance(value, dict):
        return cast(dict[str, Any], value)
    return cast(dict[str, Any], json.loads(json.dumps(value)))
