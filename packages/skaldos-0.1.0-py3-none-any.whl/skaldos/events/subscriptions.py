"""External event subscription validation for Slice 8."""

from __future__ import annotations

import ipaddress
import socket
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Literal, cast
from urllib.parse import urlparse, urlunparse
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field

from skaldos.events.outbox import ACTIVE_EVENT_TYPES, RESERVED_EVENT_TYPES

APPROVED_EVENT_WILDCARDS: frozenset[str] = frozenset(
    {
        "node.*",
        "edge.*",
        "tag.*",
        "agent.run.*",
        "conversation.*",
        "surprise.*",
    }
)
KNOWN_SUBJECT_TYPES: frozenset[str] = frozenset(
    {"node", "edge", "tag", "agent_run", "conversation", "surprise", "review-flag"}
)
DEFERRED_EXTERNAL_EVENT_TYPES: frozenset[str] = frozenset(
    {
        "decision.revised",
        "decision.falsified",
    }
)
DEFERRED_EXTERNAL_SUBJECT_TYPES: frozenset[str] = frozenset()
EVENT_SUBSCRIPTION_FILTER_KEYS: frozenset[str] = frozenset(
    {"event_types", "subject_types", "tag_filters", "lens_id"}
)
EVENT_SUBSCRIPTION_DELIVERY_KEYS: frozenset[str] = frozenset(
    {"kind", "endpoint_url", "hmac_secret_ref", "oidc_audience"}
)
FORBIDDEN_FILTER_KEYS: frozenset[str] = frozenset(
    {
        "classification",
        "deny",
        "exclude",
        "except",
        "hide",
        "max_classification",
        "min_classification",
        "not",
        "organization_id",
        "raw_sql",
        "sql",
        "tenant_id",
        "where",
    }
)
_TAG_FILTER_KEYS = frozenset({"tag_definition_ids"})
_MAX_ENDPOINT_URL_LENGTH = 2048
_METADATA_HOSTS = frozenset({"169.254.169.254", "metadata.google.internal"})
_HTTPS_ALLOWED_PORTS = frozenset({443})
_HTTP_TEST_ALLOWED_PORTS = frozenset({80})
_SECRET_REF_PREFIXES = ("kms://", "secret://")

type IPAddress = ipaddress.IPv4Address | ipaddress.IPv6Address


class EventSubscriptionValidationError(ValueError):
    """Stable reason-code error for subscription filter/target validation."""

    def __init__(self, reason_code: str) -> None:
        super().__init__(reason_code)
        self.reason_code = reason_code


class EventSubscriptionFilter(BaseModel):
    """Normalized content-free external subscription filter."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    event_types: tuple[str, ...]
    subject_types: tuple[str, ...] | None = None
    tag_filters: dict[str, tuple[UUID, ...]] | None = None
    lens_id: UUID | None = None


class PushDeliveryTarget(BaseModel):
    """Normalized external push delivery target with secret handles only."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: Literal["push"] = "push"
    endpoint_url: str = Field(min_length=1, max_length=_MAX_ENDPOINT_URL_LENGTH)
    hmac_secret_ref: str = Field(min_length=1, max_length=512)
    oidc_audience: str = Field(min_length=1, max_length=512)


@dataclass(frozen=True, slots=True)
class EndpointAddress:
    """Resolved endpoint address used for SSRF classification."""

    host: str
    ip: str


EndpointResolver = Callable[[str, int | None], Sequence[EndpointAddress]]


def normalize_event_subscription_filter(payload: object) -> EventSubscriptionFilter:
    """Validate and normalize the Slice 8 external subscription filter shape."""

    if not isinstance(payload, Mapping):
        raise EventSubscriptionValidationError("event_subscription_filter_not_object")
    raw = cast(Mapping[object, object], payload)
    _reject_forbidden_filter_keys(raw)

    keys = {str(key) for key in raw}
    unknown = keys.difference(EVENT_SUBSCRIPTION_FILTER_KEYS)
    if unknown:
        raise EventSubscriptionValidationError("event_subscription_filter_unknown_key")

    event_types = _normalize_event_types(raw.get("event_types"))
    subject_types = _normalize_subject_types(raw.get("subject_types"))
    tag_filters = _normalize_tag_filters(raw.get("tag_filters"))
    lens_id = _normalize_optional_uuid(raw.get("lens_id"), "event_subscription_filter_lens_invalid")

    return EventSubscriptionFilter(
        event_types=event_types,
        subject_types=subject_types,
        tag_filters=tag_filters,
        lens_id=lens_id,
    )


async def validate_event_subscription_filter(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    payload: object,
) -> EventSubscriptionFilter:
    """Validate filter syntax and same-tenant active lens references."""

    normalized = normalize_event_subscription_filter(payload)
    if normalized.lens_id is not None:
        try:
            raw_exists = cast(
                object,
                await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                    """
-- tenant_filter_required: lens reference is scoped by active request tenant; RLS also applies.
SELECT EXISTS (
  SELECT 1
  FROM lens_definitions
  WHERE id = $1
    AND tenant_id = $2
    AND archived_at IS NULL
)
""",
                    normalized.lens_id,
                    tenant_id,
                ),
            )
            exists = bool(raw_exists)
        except Exception as exc:
            raise EventSubscriptionValidationError(
                "event_subscription_filter_lens_lookup_failed"
            ) from exc
        if not exists:
            raise EventSubscriptionValidationError("event_subscription_filter_lens_not_found")
    return normalized


def normalize_push_delivery_target(
    payload: object,
    *,
    allow_http_for_tests: bool = False,
    resolve_endpoint: EndpointResolver | None = None,
) -> PushDeliveryTarget:
    """Validate and normalize external push endpoint metadata before storage."""

    if not isinstance(payload, Mapping):
        raise EventSubscriptionValidationError("event_subscription_delivery_not_object")
    raw = cast(Mapping[object, object], payload)
    keys = {str(key) for key in raw}
    unknown = keys.difference(EVENT_SUBSCRIPTION_DELIVERY_KEYS)
    if unknown:
        raise EventSubscriptionValidationError("event_subscription_delivery_unknown_key")
    if raw.get("kind") != "push":
        raise EventSubscriptionValidationError("event_subscription_delivery_kind_invalid")

    endpoint_url = _normalized_endpoint_url(
        raw.get("endpoint_url"),
        allow_http_for_tests=allow_http_for_tests,
        resolve_endpoint=resolve_endpoint or _resolve_endpoint,
    )
    hmac_secret_ref = _normalize_secret_ref(raw.get("hmac_secret_ref"))
    oidc_audience = _normalize_nonempty_string(
        raw.get("oidc_audience"),
        "event_subscription_delivery_oidc_audience_invalid",
        max_length=512,
    )

    return PushDeliveryTarget(
        kind="push",
        endpoint_url=endpoint_url,
        hmac_secret_ref=hmac_secret_ref,
        oidc_audience=oidc_audience,
    )


def reject_push_endpoint_redirect(location: str | None) -> None:
    """Reject redirecting registration probes without following the Location."""

    if location:
        raise EventSubscriptionValidationError("event_subscription_endpoint_redirect_denied")


def _normalize_event_types(value: object) -> tuple[str, ...]:
    items = _string_tuple(value, "event_subscription_filter_event_types_invalid")
    if not items:
        raise EventSubscriptionValidationError("event_subscription_filter_event_types_empty")

    normalized: list[str] = []
    known = ACTIVE_EVENT_TYPES | RESERVED_EVENT_TYPES
    for item in items:
        event_type = item.strip().lower()
        if event_type != item:
            raise EventSubscriptionValidationError("event_subscription_filter_event_type_invalid")
        if event_type in DEFERRED_EXTERNAL_EVENT_TYPES:
            raise EventSubscriptionValidationError("event_subscription_filter_event_type_deferred")
        if event_type in known or event_type in APPROVED_EVENT_WILDCARDS:
            normalized.append(event_type)
            continue
        raise EventSubscriptionValidationError("event_subscription_filter_event_type_unknown")
    return tuple(dict.fromkeys(normalized))


def _normalize_subject_types(value: object) -> tuple[str, ...] | None:
    if value is None:
        return None
    items = _string_tuple(value, "event_subscription_filter_subject_types_invalid")
    if not items:
        raise EventSubscriptionValidationError("event_subscription_filter_subject_types_empty")
    normalized: list[str] = []
    for item in items:
        subject_type = item.strip().lower()
        if subject_type in DEFERRED_EXTERNAL_SUBJECT_TYPES:
            raise EventSubscriptionValidationError(
                "event_subscription_filter_subject_type_deferred"
            )
        if subject_type != item or subject_type not in KNOWN_SUBJECT_TYPES:
            raise EventSubscriptionValidationError("event_subscription_filter_subject_type_unknown")
        normalized.append(subject_type)
    return tuple(dict.fromkeys(normalized))


def _normalize_tag_filters(value: object) -> dict[str, tuple[UUID, ...]] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise EventSubscriptionValidationError("event_subscription_filter_tag_filters_invalid")
    raw = cast(Mapping[object, object], value)
    _reject_forbidden_filter_keys(raw)
    keys = {str(key) for key in raw}
    if keys.difference(_TAG_FILTER_KEYS):
        raise EventSubscriptionValidationError("event_subscription_filter_tag_filters_unknown_key")
    ids_value = raw.get("tag_definition_ids")
    if ids_value is None:
        raise EventSubscriptionValidationError("event_subscription_filter_tag_filters_empty")
    ids = _uuid_tuple(
        ids_value,
        "event_subscription_filter_tag_definition_ids_invalid",
    )
    if not ids:
        raise EventSubscriptionValidationError("event_subscription_filter_tag_filters_empty")
    return {"tag_definition_ids": ids}


def _normalized_endpoint_url(
    value: object,
    *,
    allow_http_for_tests: bool,
    resolve_endpoint: EndpointResolver,
) -> str:
    raw = _normalize_nonempty_string(
        value,
        "event_subscription_endpoint_url_invalid",
        max_length=_MAX_ENDPOINT_URL_LENGTH,
    )
    try:
        parsed = urlparse(raw)
    except ValueError as exc:
        raise EventSubscriptionValidationError("event_subscription_endpoint_host_invalid") from exc
    scheme = parsed.scheme.lower()
    if scheme == "http" and not allow_http_for_tests:
        raise EventSubscriptionValidationError("event_subscription_endpoint_https_required")
    if scheme not in ({"https"} | ({"http"} if allow_http_for_tests else set())):
        raise EventSubscriptionValidationError("event_subscription_endpoint_scheme_invalid")
    if parsed.username or parsed.password:
        raise EventSubscriptionValidationError("event_subscription_endpoint_credentials_denied")
    if parsed.fragment:
        raise EventSubscriptionValidationError("event_subscription_endpoint_fragment_denied")
    if parsed.params:
        raise EventSubscriptionValidationError("event_subscription_endpoint_params_denied")

    try:
        host = (parsed.hostname or "").lower().rstrip(".")
    except ValueError as exc:
        raise EventSubscriptionValidationError("event_subscription_endpoint_host_invalid") from exc
    if not host or "*" in host:
        raise EventSubscriptionValidationError("event_subscription_endpoint_host_invalid")
    if host in _METADATA_HOSTS:
        raise EventSubscriptionValidationError("event_subscription_endpoint_metadata_denied")
    if host == "localhost" or host.endswith(".local"):
        raise EventSubscriptionValidationError("event_subscription_endpoint_private_denied")

    try:
        port = parsed.port
    except ValueError as exc:
        raise EventSubscriptionValidationError("event_subscription_endpoint_port_denied") from exc
    _validate_endpoint_port(scheme=scheme, port=port)
    _validate_resolved_endpoint(host=host, port=port, resolve_endpoint=resolve_endpoint)

    netloc = f"[{host}]" if ":" in host else host
    if port is not None:
        default_port = 443 if scheme == "https" else 80
        if port != default_port:
            netloc = f"{host}:{port}"
    return urlunparse((scheme, netloc, parsed.path or "/", "", parsed.query, ""))


def _validate_endpoint_port(*, scheme: str, port: int | None) -> None:
    if port is None:
        return
    allowed = _HTTPS_ALLOWED_PORTS if scheme == "https" else _HTTP_TEST_ALLOWED_PORTS
    if port not in allowed:
        raise EventSubscriptionValidationError("event_subscription_endpoint_port_denied")


def _validate_resolved_endpoint(
    *,
    host: str,
    port: int | None,
    resolve_endpoint: EndpointResolver,
) -> None:
    direct_ip = _parse_ip(host)
    if direct_ip is not None:
        _raise_if_forbidden_ip(direct_ip)
        return

    try:
        addresses = tuple(resolve_endpoint(host, port))
    except EventSubscriptionValidationError:
        raise
    except Exception as exc:
        raise EventSubscriptionValidationError("event_subscription_endpoint_dns_failed") from exc
    if not addresses:
        raise EventSubscriptionValidationError("event_subscription_endpoint_dns_failed")
    for address in addresses:
        if address.host.lower().rstrip(".") != host:
            raise EventSubscriptionValidationError("event_subscription_endpoint_dns_host_mismatch")
        _raise_if_forbidden_ip(ipaddress.ip_address(address.ip))


def _raise_if_forbidden_ip(ip: IPAddress) -> None:
    if str(ip) == "169.254.169.254":
        raise EventSubscriptionValidationError("event_subscription_endpoint_metadata_denied")
    if (
        not ip.is_global
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_private
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    ):
        raise EventSubscriptionValidationError("event_subscription_endpoint_private_denied")


def _resolve_endpoint(host: str, port: int | None) -> tuple[EndpointAddress, ...]:
    infos = socket.getaddrinfo(host, port or 443, type=socket.SOCK_STREAM)
    addresses: set[EndpointAddress] = set()
    for info in infos:
        sockaddr = info[4]
        ip = str(sockaddr[0])
        addresses.add(EndpointAddress(host=host, ip=ip))
    return tuple(sorted(addresses, key=lambda item: item.ip))


def _parse_ip(host: str) -> IPAddress | None:
    try:
        return ipaddress.ip_address(host)
    except ValueError:
        return None


def _string_tuple(value: object, reason_code: str) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise EventSubscriptionValidationError(reason_code)
    result: list[str] = []
    items = cast(Sequence[object], value)
    for item in items:
        if not isinstance(item, str) or not item.strip():
            raise EventSubscriptionValidationError(reason_code)
        result.append(item)
    return tuple(result)


def _uuid_tuple(value: object, reason_code: str) -> tuple[UUID, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise EventSubscriptionValidationError(reason_code)
    result: list[UUID] = []
    items = cast(Sequence[object], value)
    for item in items:
        try:
            result.append(item if isinstance(item, UUID) else UUID(str(item)))
        except (TypeError, ValueError) as exc:
            raise EventSubscriptionValidationError(reason_code) from exc
    return tuple(dict.fromkeys(result))


def _normalize_optional_uuid(value: object, reason_code: str) -> UUID | None:
    if value is None:
        return None
    try:
        return value if isinstance(value, UUID) else UUID(str(value))
    except (TypeError, ValueError) as exc:
        raise EventSubscriptionValidationError(reason_code) from exc


def _normalize_nonempty_string(value: object, reason_code: str, *, max_length: int) -> str:
    if not isinstance(value, str):
        raise EventSubscriptionValidationError(reason_code)
    normalized = value.strip()
    if not normalized or len(normalized) > max_length:
        raise EventSubscriptionValidationError(reason_code)
    return normalized


def _normalize_secret_ref(value: object) -> str:
    normalized = _normalize_nonempty_string(
        value,
        "event_subscription_delivery_hmac_secret_ref_invalid",
        max_length=512,
    )
    lowered = normalized.lower()
    if not lowered.startswith(_SECRET_REF_PREFIXES):
        raise EventSubscriptionValidationError(
            "event_subscription_delivery_hmac_secret_ref_invalid"
        )
    return normalized


def _reject_forbidden_filter_keys(value: Mapping[object, object]) -> None:
    for key, nested in value.items():
        if str(key) in FORBIDDEN_FILTER_KEYS:
            raise EventSubscriptionValidationError("event_subscription_filter_forbidden_key")
        if isinstance(nested, Mapping):
            _reject_forbidden_filter_keys(cast(Mapping[object, object], nested))
        elif isinstance(nested, Sequence) and not isinstance(nested, (str, bytes, bytearray)):
            nested_items = cast(Sequence[object], nested)
            for item in nested_items:
                if isinstance(item, Mapping):
                    _reject_forbidden_filter_keys(cast(Mapping[object, object], item))


__all__ = [
    "APPROVED_EVENT_WILDCARDS",
    "EVENT_SUBSCRIPTION_DELIVERY_KEYS",
    "EVENT_SUBSCRIPTION_FILTER_KEYS",
    "EndpointAddress",
    "EndpointResolver",
    "EventSubscriptionFilter",
    "EventSubscriptionValidationError",
    "PushDeliveryTarget",
    "normalize_event_subscription_filter",
    "normalize_push_delivery_target",
    "reject_push_endpoint_redirect",
    "validate_event_subscription_filter",
]
