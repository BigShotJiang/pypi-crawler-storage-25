"""Reactive agent subscription matching for Slice 8."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from decimal import Decimal
from typing import Annotated, Any, Literal, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos.agents.contracts import Clearance, EventAgentTriggerRef
from skaldos.agents.sync_run import AgentRunSyncLaunchService
from skaldos.events.outbox import ACTIVE_EVENT_TYPES, RESERVED_EVENT_TYPES, OutboxEventRecord
from skaldos.events.subscriptions import APPROVED_EVENT_WILDCARDS
from skaldos.middleware import Principal

EVENT_PATTERN_NODE_TYPE = "event-pattern"
REACTIVE_AGENT_SOURCE_NODE_TYPE = "principal-hub"
REACTIVE_PATTERN_FILTER_KEYS = frozenset(
    {
        "subject_type",
        "ontology_type",
        "edge_type",
        "tag_definition_ids",
        "classification_lte_agent_clearance",
        "magnitude_gte",
        "domain",
        "loop_level_in",
        "requester_or_requestee_domain",
    }
)
REACTIVE_SOURCE_METADATA_KEYS = frozenset({"org_agent_type_id", "principal_id"})
_FORBIDDEN_PATTERN_KEYS = frozenset(
    {
        "body",
        "content",
        "credentials",
        "env",
        "payload",
        "prompt",
        "provider_payload",
        "raw_sql",
        "secret",
        "sql",
        "stdout",
        "stderr",
        "tenant_id",
        "text",
        "token",
        "where",
    }
)


class ReactiveAgentSubscriptionError(RuntimeError):
    """Raised when reactive matching or launch cannot complete safely."""


class EventPatternValidationError(ValueError):
    """Stable reason-code error for event-pattern metadata."""

    def __init__(self, reason_code: str) -> None:
        super().__init__(reason_code)
        self.reason_code = reason_code


class EventPatternPredicate(BaseModel):
    """Closed declarative predicate for an event-pattern Node."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    subject_type: Literal["node", "edge", "tag", "agent_run", "conversation", "surprise"] | None = (
        None
    )
    ontology_type: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    edge_type: Annotated[str, Field(min_length=1, max_length=128)] | None = None
    tag_definition_ids: tuple[UUID, ...] = ()
    classification_lte_agent_clearance: bool = True
    magnitude_gte: Annotated[Decimal, Field(ge=0, le=1)] | None = None
    domain: Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")] | None = None
    loop_level_in: tuple[Literal["single", "double", "triple"], ...] = ()
    requester_or_requestee_domain: (
        Annotated[str, Field(pattern=r"^[a-z][a-z0-9_.-]{0,63}$")] | None
    ) = None

    @model_validator(mode="after")
    def _supervisor_filters_match_subject(self) -> EventPatternPredicate:
        if (
            self.magnitude_gte is not None or self.domain is not None or self.loop_level_in
        ) and self.subject_type not in {None, "surprise"}:
            raise ValueError("event_pattern_surprise_filter_subject_mismatch")
        if self.requester_or_requestee_domain is not None and self.subject_type not in {
            None,
            "conversation",
        }:
            raise ValueError("event_pattern_conversation_filter_subject_mismatch")
        return self


class EventPatternNodeMetadata(BaseModel):
    """Content-free metadata stored on an ``event-pattern`` Node."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    event_type: Annotated[str, Field(min_length=1, max_length=128)]
    filter_predicate: EventPatternPredicate = Field(default_factory=EventPatternPredicate)
    lens_id: UUID | None = None

    @model_validator(mode="after")
    def _event_type_is_known_or_wildcard(self) -> EventPatternNodeMetadata:
        if (
            self.event_type not in ACTIVE_EVENT_TYPES
            and self.event_type not in RESERVED_EVENT_TYPES
            and self.event_type not in APPROVED_EVENT_WILDCARDS
        ):
            raise ValueError("event_pattern_event_type_unknown")
        _reject_forbidden_pattern_payload(self.model_dump(mode="json"))
        return self


@dataclass(frozen=True, slots=True)
class ReactiveAgentMatch:
    tenant_id: UUID
    outbox_event_id: UUID
    event_id_hash: str
    event_type: str
    subject_type: str
    subject_id: UUID
    source_node_id: UUID
    pattern_node_id: UUID
    org_agent_type_id: UUID
    effective_principal_id: UUID
    effective_clearance: Clearance
    idempotency_key: str

    def trigger_ref(self) -> EventAgentTriggerRef:
        return EventAgentTriggerRef(
            event_id_hash=self.event_id_hash,
            outbox_event_id=self.outbox_event_id,
            event_type=self.event_type,
            subject_type=self.subject_type,
            subject_id=self.subject_id,
            pattern_node_id=self.pattern_node_id,
            subscription_source_node_id=self.source_node_id,
            idempotency_key=self.idempotency_key,
        )


def normalize_event_pattern_metadata(payload: object) -> EventPatternNodeMetadata:
    """Validate and normalize the event-pattern Node metadata contract."""

    if not isinstance(payload, Mapping):
        raise EventPatternValidationError("event_pattern_metadata_not_object")
    raw = cast(Mapping[object, object], payload)
    _reject_forbidden_pattern_payload(raw)
    try:
        return EventPatternNodeMetadata.model_validate(raw)
    except ValueError as exc:
        raise EventPatternValidationError(_validation_reason(exc)) from exc


def validate_reactive_source_metadata(payload: object) -> None:
    """Validate the source hub metadata shape used by ``subscribes-to`` edges."""

    if not isinstance(payload, Mapping):
        raise EventPatternValidationError("reactive_source_metadata_not_object")
    raw = cast(Mapping[object, object], payload)
    keys = {str(key) for key in raw}
    if not keys.intersection(REACTIVE_SOURCE_METADATA_KEYS):
        raise EventPatternValidationError("reactive_source_metadata_missing_handle")
    if len(keys.intersection(REACTIVE_SOURCE_METADATA_KEYS)) != 1:
        raise EventPatternValidationError("reactive_source_metadata_ambiguous")


def reactive_agent_idempotency_key(
    *,
    tenant_id: UUID,
    event_id_hash: str,
    source_node_id: UUID,
    pattern_node_id: UUID,
    org_agent_type_id: UUID,
    effective_principal_id: UUID,
    event_type: str,
) -> str:
    canonical = json.dumps(
        {
            "effective_principal_id": str(effective_principal_id),
            "event_id_hash": event_id_hash,
            "event_type": event_type,
            "org_agent_type_id": str(org_agent_type_id),
            "pattern_node_id": str(pattern_node_id),
            "source_node_id": str(source_node_id),
            "tenant_id": str(tenant_id),
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


class ReactiveAgentSubscriptionStore:
    """Repository for matching claimed outbox rows to reactive agent subscriptions."""

    async def list_matches(
        self,
        *,
        connection: asyncpg.Connection,
        event: OutboxEventRecord,
    ) -> tuple[ReactiveAgentMatch, ...]:
        try:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    """
-- tenant_filter_required: matcher is scoped by claimed outbox event tenant; RLS also applies.
WITH event_fact AS (
  SELECT $1::uuid AS outbox_event_id,
         $2::uuid AS tenant_id,
         $3::text AS event_type,
         $4::text AS subject_type,
         $5::uuid AS subject_id,
         $6::text AS event_id_hash,
         $7::jsonb AS context_of_validity
),
candidate AS (
  SELECT e.source_node_id,
         e.target_node_id AS pattern_node_id,
         oat.id AS org_agent_type_id,
         oat.agent_principal_id AS effective_principal_id,
         CASE
           WHEN app.classification_rank(oat.max_clearance)
                <= app.classification_rank(m.max_clearance) THEN oat.max_clearance
           ELSE m.max_clearance
         END AS effective_clearance,
         row_number() OVER (
           PARTITION BY e.source_node_id, e.target_node_id, oat.id, oat.agent_principal_id
           ORDER BY e.created_at, e.id
         ) AS duplicate_rank
  FROM event_fact ev
  JOIN edges e
    ON e.tenant_id = ev.tenant_id
   AND e.relationship_type = 'subscribes-to'
   AND e.archived_at IS NULL
  JOIN nodes source_node
    ON source_node.id = e.source_node_id
   AND source_node.tenant_id = ev.tenant_id
   AND source_node.archived_at IS NULL
   AND source_node.superseded_by_node_id IS NULL
  JOIN ontology_type source_type
    ON source_type.id = source_node.type_id
   AND source_type.ontology_version_id = source_node.ontology_version_id
   AND source_type.name = 'principal-hub'
  JOIN nodes pattern_node
    ON pattern_node.id = e.target_node_id
   AND pattern_node.tenant_id = ev.tenant_id
   AND pattern_node.archived_at IS NULL
   AND pattern_node.superseded_by_node_id IS NULL
  JOIN ontology_type pattern_type
    ON pattern_type.id = pattern_node.type_id
   AND pattern_type.ontology_version_id = pattern_node.ontology_version_id
   AND pattern_type.name = 'event-pattern'
  JOIN org_agent_type oat
    ON oat.tenant_id = ev.tenant_id
   AND oat.archived_at IS NULL
   AND (
        (
          source_node.metadata ->> 'org_agent_type_id'
            ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
          AND oat.id = (source_node.metadata ->> 'org_agent_type_id')::uuid
        )
        OR (
          source_node.metadata ->> 'principal_id'
            ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
          AND oat.agent_principal_id = (source_node.metadata ->> 'principal_id')::uuid
        )
   )
  JOIN principals agent_principal
    ON agent_principal.id = oat.agent_principal_id
   AND agent_principal.kind = 'agent'
   AND agent_principal.disabled_at IS NULL
  JOIN memberships m
    ON m.principal_id = agent_principal.id
   AND m.tenant_id = ev.tenant_id
   AND m.revoked_at IS NULL
  LEFT JOIN nodes subject_node
    ON ev.subject_type = 'node'
   AND subject_node.id = ev.subject_id
   AND subject_node.tenant_id = ev.tenant_id
   AND subject_node.archived_at IS NULL
   AND subject_node.superseded_by_node_id IS NULL
  LEFT JOIN ontology_type subject_type
    ON subject_type.id = subject_node.type_id
   AND subject_type.ontology_version_id = subject_node.ontology_version_id
  LEFT JOIN edges subject_edge
    ON ev.subject_type = 'edge'
   AND subject_edge.id = ev.subject_id
   AND subject_edge.tenant_id = ev.tenant_id
   AND subject_edge.archived_at IS NULL
  LEFT JOIN surprise_stream subject_surprise
    ON ev.subject_type = 'surprise'
   AND subject_surprise.id = ev.subject_id
   AND subject_surprise.tenant_id = ev.tenant_id
  LEFT JOIN nodes subject_conversation
    ON ev.subject_type = 'conversation'
   AND subject_conversation.id = ev.subject_id
   AND subject_conversation.tenant_id = ev.tenant_id
   AND subject_conversation.archived_at IS NULL
   AND subject_conversation.superseded_by_node_id IS NULL
  WHERE pattern_node.metadata ? 'event_type'
    AND pattern_node.metadata ? 'filter_predicate'
    AND jsonb_typeof(pattern_node.metadata -> 'filter_predicate') = 'object'
    AND NOT EXISTS (
      SELECT 1
      FROM jsonb_object_keys(pattern_node.metadata -> 'filter_predicate') AS filter_key(key)
      WHERE filter_key.key NOT IN (
        'subject_type',
        'ontology_type',
        'edge_type',
        'tag_definition_ids',
        'classification_lte_agent_clearance',
        'magnitude_gte',
        'domain',
        'loop_level_in',
        'requester_or_requestee_domain'
      )
    )
    AND (
      pattern_node.metadata ->> 'event_type' = ev.event_type
      OR (
        pattern_node.metadata ->> 'event_type' IN (
          'node.*',
          'edge.*',
          'tag.*',
          'agent.run.*',
          'surprise.*',
          'conversation.*'
        )
        AND split_part(pattern_node.metadata ->> 'event_type', '.', 1)
            = split_part(ev.event_type, '.', 1)
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'subject_type')
      OR lower(pattern_node.metadata #>> '{filter_predicate,subject_type}') = ev.subject_type
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'ontology_type')
      OR (
        ev.subject_type = 'node'
        AND subject_type.name = pattern_node.metadata #>> '{filter_predicate,ontology_type}'
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'edge_type')
      OR (
        ev.subject_type = 'edge'
        AND subject_edge.relationship_type
            = pattern_node.metadata #>> '{filter_predicate,edge_type}'
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'tag_definition_ids')
      OR (
        jsonb_typeof(pattern_node.metadata #> '{filter_predicate,tag_definition_ids}') = 'array'
        AND EXISTS (
          SELECT 1
          FROM jsonb_array_elements_text(
                 pattern_node.metadata #> '{filter_predicate,tag_definition_ids}'
               ) AS tag_filter(tag_definition_id)
          WHERE tag_filter.tag_definition_id
                  ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
            AND (
              (
                ev.subject_type = 'node'
                AND EXISTS (
                  SELECT 1
                  FROM node_tags nt
                  WHERE nt.node_id = ev.subject_id
                    AND nt.tenant_id = ev.tenant_id
                    AND nt.superseded_by_tag_id IS NULL
                    AND nt.tag_definition_id = tag_filter.tag_definition_id::uuid
                )
              )
              OR (
                ev.subject_type = 'tag'
                AND EXISTS (
                  SELECT 1
                  FROM node_tags nt
                  WHERE nt.id = ev.subject_id
                    AND nt.tenant_id = ev.tenant_id
                    AND nt.superseded_by_tag_id IS NULL
                    AND nt.tag_definition_id = tag_filter.tag_definition_id::uuid
                )
              )
            )
        )
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'magnitude_gte')
      OR (
        ev.subject_type = 'surprise'
        AND subject_surprise.magnitude
            >= (pattern_node.metadata #>> '{filter_predicate,magnitude_gte}')::numeric
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'domain')
      OR (
        ev.subject_type = 'surprise'
        AND subject_surprise.domain = pattern_node.metadata #>> '{filter_predicate,domain}'
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'loop_level_in')
      OR (
        ev.subject_type = 'surprise'
        AND jsonb_typeof(pattern_node.metadata #> '{filter_predicate,loop_level_in}') = 'array'
        AND subject_surprise.loop_level IN (
          SELECT jsonb_array_elements_text(
            pattern_node.metadata #> '{filter_predicate,loop_level_in}'
          )
        )
      )
    )
    AND (
      NOT (pattern_node.metadata -> 'filter_predicate' ? 'requester_or_requestee_domain')
      OR (
        ev.subject_type = 'conversation'
        AND (
          subject_conversation.metadata ->> 'domain'
            = pattern_node.metadata #>> '{filter_predicate,requester_or_requestee_domain}'
          OR subject_conversation.metadata ->> 'task_type'
            = pattern_node.metadata #>> '{filter_predicate,requester_or_requestee_domain}'
        )
      )
    )
    AND (
      NOT (pattern_node.metadata ? 'lens_id')
      OR (
        pattern_node.metadata ->> 'lens_id'
          ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
        AND EXISTS (
          SELECT 1
          FROM lens_definitions ld
          WHERE ld.id = (pattern_node.metadata ->> 'lens_id')::uuid
            AND ld.tenant_id = ev.tenant_id
            AND ld.archived_at IS NULL
            AND (
              jsonb_array_length(COALESCE(ld.definition -> 'rules', '[]'::jsonb)) = 0
              OR EXISTS (
                SELECT 1
                FROM jsonb_array_elements(COALESCE(ld.definition -> 'rules', '[]'::jsonb))
                  AS rule(value)
                WHERE (
                  rule.value #>> '{signal,kind}' = 'tag'
                  AND (
                    (
                      ev.subject_type = 'node'
                      AND EXISTS (
                        SELECT 1
                        FROM node_tags nt
                        WHERE nt.node_id = ev.subject_id
                          AND nt.tenant_id = ev.tenant_id
                          AND nt.superseded_by_tag_id IS NULL
                          AND nt.tag_definition_id::text = rule.value #>> '{signal,value}'
                      )
                    )
                    OR (
                      ev.subject_type = 'tag'
                      AND EXISTS (
                        SELECT 1
                        FROM node_tags nt
                        WHERE nt.id = ev.subject_id
                          AND nt.tenant_id = ev.tenant_id
                          AND nt.superseded_by_tag_id IS NULL
                          AND nt.tag_definition_id::text = rule.value #>> '{signal,value}'
                      )
                    )
                  )
                )
                OR (
                  rule.value #>> '{signal,kind}' = 'type'
                  AND ev.subject_type = 'node'
                  AND subject_node.type_id::text = rule.value #>> '{signal,value}'
                )
              )
            )
        )
      )
    )
    AND app.classification_rank(ev.context_of_validity ->> 'classification')
        <= app.classification_rank(
             CASE
               WHEN app.classification_rank(oat.max_clearance)
                    <= app.classification_rank(m.max_clearance) THEN oat.max_clearance
               ELSE m.max_clearance
             END
           )
)
SELECT *
FROM candidate
WHERE duplicate_rank = 1
ORDER BY source_node_id, pattern_node_id, org_agent_type_id
""",
                    event.id,
                    event.tenant_id,
                    event.event_type,
                    event.subject_type.lower(),
                    event.subject_id,
                    event.event_id_hash,
                    json.dumps(event.context_of_validity, separators=(",", ":"), sort_keys=True),
                ),
            )
        except Exception as exc:
            raise ReactiveAgentSubscriptionError("reactive_agent_match_failed") from exc
        return tuple(_match_from_row(event=event, row=row) for row in rows)


@dataclass(frozen=True, slots=True)
class ReactiveAgentLaunchResult:
    matched: int
    started: int


class ReactiveAgentDispatcher:
    """Fan-out handler that starts existing Slice 7 AgentRun workflows."""

    def __init__(
        self,
        *,
        matcher: ReactiveAgentSubscriptionStore | None = None,
        launch_service: AgentRunSyncLaunchService | None = None,
        dispatcher_principal: Principal,
        api_base_url: str,
        shield_base_url: str,
    ) -> None:
        self._matcher = matcher or ReactiveAgentSubscriptionStore()
        self._launch_service = launch_service or AgentRunSyncLaunchService()
        self._dispatcher_principal = dispatcher_principal
        self._api_base_url = api_base_url
        self._shield_base_url = shield_base_url

    async def __call__(
        self,
        connection: asyncpg.Connection,
        event: OutboxEventRecord,
    ) -> None:
        await self.dispatch_event(connection=connection, event=event)

    async def dispatch_event(
        self,
        *,
        connection: asyncpg.Connection,
        event: OutboxEventRecord,
    ) -> ReactiveAgentLaunchResult:
        matches = await self._matcher.list_matches(connection=connection, event=event)
        started = 0
        for match in matches:
            await self._launch_service.launch_event_run(
                connection=connection,
                launcher=self._dispatcher_principal,
                tenant_id=match.tenant_id,
                org_agent_type_id=match.org_agent_type_id,
                trigger_ref=match.trigger_ref(),
                effective_clearance=match.effective_clearance,
                api_base_url=self._api_base_url,
                shield_base_url=self._shield_base_url,
            )
            started += 1
        return ReactiveAgentLaunchResult(matched=len(matches), started=started)


def _match_from_row(
    *,
    event: OutboxEventRecord,
    row: Mapping[str, Any],
) -> ReactiveAgentMatch:
    source_node_id = cast(UUID, row["source_node_id"])
    pattern_node_id = cast(UUID, row["pattern_node_id"])
    org_agent_type_id = cast(UUID, row["org_agent_type_id"])
    effective_principal_id = cast(UUID, row["effective_principal_id"])
    return ReactiveAgentMatch(
        tenant_id=event.tenant_id,
        outbox_event_id=event.id,
        event_id_hash=event.event_id_hash,
        event_type=event.event_type,
        subject_type=event.subject_type.lower(),
        subject_id=event.subject_id,
        source_node_id=source_node_id,
        pattern_node_id=pattern_node_id,
        org_agent_type_id=org_agent_type_id,
        effective_principal_id=effective_principal_id,
        effective_clearance=cast(Clearance, str(row["effective_clearance"])),
        idempotency_key=reactive_agent_idempotency_key(
            tenant_id=event.tenant_id,
            event_id_hash=event.event_id_hash,
            source_node_id=source_node_id,
            pattern_node_id=pattern_node_id,
            org_agent_type_id=org_agent_type_id,
            effective_principal_id=effective_principal_id,
            event_type=event.event_type,
        ),
    )


def _reject_forbidden_pattern_payload(value: object) -> None:
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        for key, nested in mapping.items():
            nested_object: object = nested
            normalized = str(key).lower()
            if normalized in _FORBIDDEN_PATTERN_KEYS:
                raise EventPatternValidationError("event_pattern_forbidden_key")
            if isinstance(nested_object, Mapping):
                nested_mapping = cast(Mapping[object, object], nested_object)
                if normalized == "filter_predicate":
                    unknown = {str(item) for item in nested_mapping}.difference(
                        REACTIVE_PATTERN_FILTER_KEYS
                    )
                    if unknown:
                        raise EventPatternValidationError("event_pattern_filter_unknown_key")
                _reject_forbidden_pattern_payload(nested_mapping)
            else:
                _reject_forbidden_pattern_payload(nested_object)
    elif isinstance(value, list | tuple):
        sequence = cast(Sequence[object], value)
        for nested in sequence:
            _reject_forbidden_pattern_payload(nested)


def _validation_reason(exc: ValueError) -> str:
    message = str(exc)
    if "event_pattern_event_type_unknown" in message:
        return "event_pattern_event_type_unknown"
    if "extra_forbidden" in message:
        return "event_pattern_unknown_key"
    return "event_pattern_invalid"


__all__ = [
    "EVENT_PATTERN_NODE_TYPE",
    "EventPatternNodeMetadata",
    "EventPatternPredicate",
    "EventPatternValidationError",
    "ReactiveAgentMatch",
    "ReactiveAgentDispatcher",
    "ReactiveAgentLaunchResult",
    "ReactiveAgentSubscriptionError",
    "ReactiveAgentSubscriptionStore",
    "normalize_event_pattern_metadata",
    "reactive_agent_idempotency_key",
    "validate_reactive_source_metadata",
]
