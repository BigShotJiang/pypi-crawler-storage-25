"""Thin CLI client for ``POST /graph/assert``.

The CLI is a Shell surface over the API contract. It builds the shared Slice 4
assertion envelope and sends it to the protected endpoint; it does not stage,
deduplicate, authorize, or resolve graph writes locally.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast
from urllib import error, request

from pydantic import ValidationError

from skaldos.graph.assert_contract import RegisteredSourceKind
from skaldos.policy.intent import Intent

DEFAULT_API_URL = "http://127.0.0.1:8000"
DEFAULT_TIMEOUT_SECONDS = 30.0


class CliUsageError(ValueError):
    """Raised for local CLI usage errors that must not call the API."""


@dataclass(frozen=True)
class GraphAssertCliConfig:
    api_url: str
    token: str
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS


@dataclass(frozen=True)
class GraphAssertCommand:
    claim: Mapping[str, Any]
    source_kind: str
    source_id: str
    actor_principal_id: uuid.UUID
    actor_kind: str
    intent: Intent
    confidence: float | None
    grounding: Sequence[Mapping[str, Any]]
    idempotency_key: str


def build_graph_assert_request(command: GraphAssertCommand) -> dict[str, object]:
    """Build the exact public assertion envelope sent by the CLI."""

    _validate_actor_kind(command.actor_kind)
    try:
        source_kind = RegisteredSourceKind(kind=command.source_kind).kind
    except ValidationError as exc:
        raise CliUsageError("source.kind is invalid") from exc
    return {
        "claim": dict(command.claim),
        "source": {
            "kind": source_kind,
            "locator": command.source_id,
        },
        "actor": {
            "principal_id": str(command.actor_principal_id),
            "kind": command.actor_kind,
        },
        "grounding": [dict(item) for item in command.grounding],
        "confidence": command.confidence,
        "intent": command.intent.value,
    }


def post_graph_assert(
    *,
    config: GraphAssertCliConfig,
    command: GraphAssertCommand,
) -> tuple[int, dict[str, Any]]:
    """POST one assertion envelope and return the response status/body."""

    body = json.dumps(
        build_graph_assert_request(command),
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    api_url = config.api_url.rstrip("/")
    http_request = request.Request(
        f"{api_url}/graph/assert",
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {config.token}",
            "Content-Type": "application/json",
            "Idempotency-Key": command.idempotency_key,
        },
    )
    try:
        with request.urlopen(http_request, timeout=config.timeout_seconds) as response:
            return response.status, _read_json_response(response.read())
    except error.HTTPError as exc:
        return exc.code, _read_json_response(exc.read())


def render_graph_assert_result(*, status_code: int, body: Mapping[str, Any]) -> str:
    """Render compact stable output without implying direct graph mutation."""

    if 200 <= status_code < 300:
        state = body.get("status", "unknown")
        assertion_id = body.get("assertionId") or body.get("pendingAssertionId")
        return f"status={state} assertion_id={assertion_id}"
    detail = body.get("detail")
    if isinstance(detail, Mapping):
        detail_mapping = cast(Mapping[str, object], detail)
        reason = (
            detail_mapping.get("reason_code") or detail_mapping.get("error_code") or "unknown_error"
        )
    else:
        reason = "unknown_error"
    return f"error status={status_code} reason={reason}"


def main(argv: Sequence[str] | None = None) -> int:
    """Standalone entry point preserved for the existing unit-test regression net.

    Accepts the legacy positional shape (``graph assert ...``). The dispatcher
    at ``skaldos.cli.__main__.main`` is the production entry point; this
    function is retained so ``tests/unit/cli/test_graph_assert_cli.py``
    continues to drive the underlying handler unchanged.
    """
    parser = _parser()
    args = parser.parse_args(argv)
    if args.resource != "graph" or args.action != "assert":
        parser.error("expected command: graph assert")
    return main_invoke(args, parser)


def main_invoke(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    """Run the ``graph assert`` handler using an already-parsed argparse namespace.

    Used by both ``main()`` (legacy positional parser) and the dispatcher in
    ``skaldos.cli.__main__`` (subparser shape). Centralising the handler body
    here keeps the two entry shapes from drifting (E13: ``python -m skaldos.cli``
    and ``skald`` must behave identically).
    """
    try:
        command = _command_from_args(args)
        config = _config_from_env(args)
        status_code, body = post_graph_assert(config=config, command=command)
    except CliUsageError as exc:
        parser.exit(2, f"error: {exc}\n")
    except OSError as exc:
        parser.exit(1, f"error: request_failed: {exc}\n")
    sys.stdout.write(render_graph_assert_result(status_code=status_code, body=body) + "\n")
    return 0 if status_code < 400 else 1


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="skald")
    parser.add_argument("resource", choices=("graph",))
    parser.add_argument("action", choices=("assert",))
    configure_assert_parser(parser)
    return parser


def configure_assert_parser(parser: argparse.ArgumentParser) -> None:
    """Attach the ``graph assert`` argument set to ``parser``.

    Shared between the legacy positional parser in ``_parser()`` and the
    dispatcher's ``graph assert`` subparser. Adding an argument here updates
    both invocation routes simultaneously; arguments diverge only when a route
    consciously declines one (none today).
    """
    parser.add_argument("--api-url", default=None)
    parser.add_argument("--token", default=None)
    parser.add_argument("--intent", required=True, choices=tuple(intent.value for intent in Intent))
    parser.add_argument("--source-kind", default="cli")
    parser.add_argument("--source-id", required=True)
    parser.add_argument("--claim-file", required=True)
    parser.add_argument("--grounding-file", default=None)
    parser.add_argument("--confidence", type=float, default=None)
    parser.add_argument("--actor-principal-id", required=True)
    parser.add_argument("--actor-kind", choices=("human", "agent"), required=True)
    parser.add_argument("--by", default=None)
    parser.add_argument("--idempotency-key", default=None)
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT_SECONDS)


def _command_from_args(args: argparse.Namespace) -> GraphAssertCommand:
    if args.by == "cli":
        raise CliUsageError("--by cli is forbidden; authenticate as a human or agent Principal")
    try:
        actor_principal_id = uuid.UUID(args.actor_principal_id)
    except ValueError as exc:
        raise CliUsageError("--actor-principal-id must be a UUID") from exc
    claim = _read_json_mapping(args.claim_file, label="claim")
    grounding = _read_grounding(args.grounding_file)
    confidence = _validate_confidence(args.confidence)
    return GraphAssertCommand(
        claim=claim,
        source_kind=args.source_kind,
        source_id=args.source_id,
        actor_principal_id=actor_principal_id,
        actor_kind=args.actor_kind,
        intent=Intent(args.intent),
        confidence=confidence,
        grounding=grounding,
        idempotency_key=args.idempotency_key or str(uuid.uuid4()),
    )


def _config_from_env(args: argparse.Namespace) -> GraphAssertCliConfig:
    token = args.token or os.getenv("SKALDOS_TOKEN")
    if not token:
        raise CliUsageError("missing token; pass --token or set SKALDOS_TOKEN")
    return GraphAssertCliConfig(
        api_url=args.api_url or os.getenv("SKALDOS_API_URL") or DEFAULT_API_URL,
        token=token,
        timeout_seconds=args.timeout,
    )


def _read_json_mapping(path: str, *, label: str) -> dict[str, Any]:
    value = _read_json(path)
    if not isinstance(value, dict):
        raise CliUsageError(f"{label} JSON must be an object")
    return cast(dict[str, Any], value)


def _read_grounding(path: str | None) -> list[dict[str, Any]]:
    if path is None:
        return []
    value = _read_json(path)
    if not isinstance(value, list):
        raise CliUsageError("grounding JSON must be a list of objects")
    items = cast(list[object], value)
    if not all(isinstance(item, dict) for item in items):
        raise CliUsageError("grounding JSON must be a list of objects")
    return [dict(cast(Mapping[str, Any], item)) for item in items]


def _read_json(path: str) -> object:
    try:
        raw = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8")
        return json.loads(raw)
    except OSError as exc:
        raise CliUsageError(f"could not read {path}") from exc
    except json.JSONDecodeError as exc:
        raise CliUsageError(f"invalid JSON in {path}") from exc


def _validate_actor_kind(actor_kind: str) -> None:
    if actor_kind not in {"human", "agent"}:
        raise CliUsageError("--actor-kind must be human or agent")


def _validate_confidence(confidence: float | None) -> float | None:
    if confidence is None:
        return None
    if not 0.0 <= confidence <= 1.0:
        raise CliUsageError("--confidence must be between 0 and 1")
    return confidence


def _read_json_response(raw: bytes) -> dict[str, Any]:
    try:
        value = json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError:
        return {"detail": {"reason_code": "invalid_json_response"}}
    if isinstance(value, dict):
        return cast(dict[str, Any], value)
    return {"detail": {"reason_code": "unexpected_json_response"}}
