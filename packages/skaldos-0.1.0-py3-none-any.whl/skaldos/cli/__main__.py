"""Top-level dispatcher for the ``skald`` CLI.

The CLI is a Shell surface over the public SkaldOS API. Today it exposes one
command (``skald graph assert``); the dispatcher is shaped with argparse
subparsers so future commands (``skald graph search``, ``skald me``, etc.)
plug in trivially without restructuring.

The dispatcher delegates to handler modules. ``services/api/skaldos/cli/graph_assert.py``
keeps its existing module-level ``main(argv)`` callable so the existing unit-test
regression net (`tests/unit/cli/test_graph_assert_cli.py`) continues to pass
unchanged, *and* exposes a ``main_invoke(args, parser)`` callable the dispatcher
uses to skip re-parsing the resource/action positionals.

Per `docs/canon/build-plan.md` ADR 27 (CLI release lane channel — PyPI, bundled)
and `docs/slices/cli-release-lane/03-technical-implementation.md` § Refactor
decision (S5 Option A).

Both invocation routes (``skald`` console-script entry and ``python -m skaldos.cli``)
flow through ``main()`` here so they produce identical behavior (E13).
"""

from __future__ import annotations

import argparse
from collections.abc import Sequence

from skaldos.cli import graph_assert


def _build_parser() -> argparse.ArgumentParser:
    """Build the top-level dispatcher parser.

    Each top-level resource (``graph`` today) is a subparser, and each
    sub-resource action (``assert``) is a sub-subparser under it. Adding a
    new command means: declare a new subparser; register its action sub-
    subparsers; route to its handler from :func:`main`. Existing commands
    are not touched.
    """
    parser = argparse.ArgumentParser(prog="skald")
    resource = parser.add_subparsers(dest="resource", metavar="resource")
    resource.required = True

    graph_parser = resource.add_parser(
        "graph",
        help="Graph operations (read/write via the API contract).",
        description="Graph operations (read/write via the API contract).",
    )
    graph_action = graph_parser.add_subparsers(dest="action", metavar="action")
    graph_action.required = True

    assert_parser = graph_action.add_parser(
        "assert",
        help="Send one assertion to POST /graph/assert.",
        description="Send one assertion envelope to the protected /graph/assert endpoint.",
    )
    graph_assert.configure_assert_parser(assert_parser)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point for both the ``skald`` console-script and ``python -m skaldos.cli``.

    Returns:
        The exit code from the routed command. Any ``SystemExit`` raised by a
        handler propagates so argparse-style ``parser.exit(...)`` calls keep their
        intended exit codes (used by the existing ``graph assert`` error paths).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.resource == "graph" and args.action == "assert":
        return graph_assert.main_invoke(args, parser)
    # argparse with `required=True` subparsers should have refused this case
    # already; the fallback keeps the typechecker honest.
    parser.error(f"unknown command: {args.resource} {args.action}")


if __name__ == "__main__":
    raise SystemExit(main())
