"""Pure TagDefinition validation helpers for Slice 3 tag vocabulary.

This module deliberately stops at Pydantic/domain validation. It has no
database, route, migration, or service-write dependency; later tag vocabulary
service methods can call these helpers before touching the storage contract
landed by PR #163.

References: §1.6, §1.8, §1.10, §1.11, §1.12, §1.14, §1.15, AP5, AP11.
"""

from __future__ import annotations

import json
import re
import unicodedata
from collections.abc import Callable, Mapping, Sequence
from enum import StrEnum
from typing import Any, Literal, Protocol, cast
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

MAX_VALIDATION_RULE_BYTES = 8192
MAX_VALIDATION_RULE_DEPTH = 16

type JsonObject = dict[str, Any]
type RuleValidator = Callable[["ValidationRuleEnvelope"], None]


class TagValueType(StrEnum):
    """Storage-backed tag definition value types."""

    STRING = "string"
    NUMBER = "number"
    BOOLEAN = "boolean"
    ENUM = "enum"
    REFERENCE = "reference"
    COMPUTED = "computed"


class TagDefinitionLifecycleState(StrEnum):
    """Storage-backed tag definition lifecycle states."""

    ACTIVE = "active"
    DEPRECATED = "deprecated"
    RETIRED = "retired"


class TagDefinitionValidationReason(StrEnum):
    """Low-cardinality reason codes for pure tag definition validation."""

    NAME_EMPTY = "tag_definition_name_empty"
    VALUE_TYPE_UNKNOWN = "tag_value_type_unknown"
    CURRENCY_REQUIRES_NUMBER = "currency_requires_number"
    ENUM_VALUES_REQUIRED = "enum_values_required"
    ENUM_VALUES_FORBIDDEN = "enum_values_forbidden"
    ENUM_VALUE_INVALID = "enum_value_invalid"
    ENUM_VALUE_EMPTY = "enum_value_empty"
    ENUM_VALUE_DUPLICATE = "enum_value_duplicate"
    COMPUTED_DEPENDENCIES_REQUIRED = "computed_dependencies_required"
    COMPUTED_DEPENDENCIES_FORBIDDEN = "computed_dependencies_forbidden"
    COMPUTED_DEPENDENCY_INVALID = "computed_dependency_invalid"
    COMPUTED_DEPENDENCY_EMPTY = "computed_dependency_empty"
    COMPUTED_DEPENDENCY_DUPLICATE = "computed_dependency_duplicate"
    COMPUTED_DEPENDENCY_MISSING = "computed_dependency_missing"
    COMPUTED_DEPENDENCY_TEMPLATE = "computed_dependency_template"
    COMPUTED_DEPENDENCY_CROSS_SCOPE = "computed_dependency_cross_scope"
    COMPUTED_DEPENDENCY_INACTIVE = "computed_dependency_inactive"
    COMPUTED_DEPENDENCY_COMPUTED = "computed_dependency_computed"
    COMPUTED_DEPENDENCY_CYCLE = "computed_dependency_cycle"
    VALIDATION_RULE_OBJECT_REQUIRED = "validation_rule_object_required"
    VALIDATION_RULE_TOO_LARGE = "validation_rule_too_large"
    VALIDATION_RULE_TOO_DEEP = "validation_rule_too_deep"
    VALIDATION_RULE_ENVELOPE_INVALID = "validation_rule_envelope_invalid"
    VALIDATION_RULE_SCHEMA_UNKNOWN = "validation_rule_schema_unknown"
    VALIDATION_RULE_OPERATOR_UNKNOWN = "validation_rule_operator_unknown"
    VALIDATION_RULE_EVAL_FAILED = "validation_rule_eval_failed"
    LIFECYCLE_TRANSITION_INVALID = "tag_definition_lifecycle_transition_invalid"
    VALUE_CONTRACT_IMMUTABLE = "tag_definition_value_contract_immutable"


class TagDefinitionValidationError(ValueError):
    """Domain validation error with a stable reason code."""

    def __init__(self, reason_code: TagDefinitionValidationReason, message: str) -> None:
        self.reason_code = reason_code
        super().__init__(f"{reason_code.value}: {message}")


def normalize_tag_name(value: str) -> str:
    """Normalize a tag definition/dependency name to the storage canonical key."""

    canonical = unicodedata.normalize("NFC", value).strip().lower()
    if canonical == "":
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.NAME_EMPTY,
            "tag definition name must not be empty",
        )
    return canonical


def _json_depth(value: object) -> int:
    if isinstance(value, Mapping):
        if not value:
            return 1
        mapping = cast(Mapping[object, object], value)
        return 1 + max(_json_depth(child) for child in mapping.values())
    if isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
        if not value:
            return 1
        sequence = cast(Sequence[object], value)
        return 1 + max(_json_depth(child) for child in sequence)
    return 1


def validate_json_object_limits(
    value: Mapping[str, Any],
    *,
    reason_prefix: Literal["validation_rules"] = "validation_rules",
) -> JsonObject:
    """Validate object shape plus bounded size/depth before storage."""

    del reason_prefix
    rules = dict(value)
    encoded = json.dumps(rules, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    if len(encoded.encode("utf-8")) > MAX_VALIDATION_RULE_BYTES:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_TOO_LARGE,
            "validation rule JSON exceeds the Slice 3 size bound",
        )
    if _json_depth(rules) > MAX_VALIDATION_RULE_DEPTH:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_TOO_DEEP,
            "validation rule JSON exceeds the Slice 3 nesting bound",
        )
    return rules


def normalize_unique_names(
    values: Sequence[str],
    *,
    empty_reason: TagDefinitionValidationReason,
    duplicate_reason: TagDefinitionValidationReason,
) -> tuple[str, ...]:
    """Normalize names and reject canonical duplicates while preserving order."""

    normalized: list[str] = []
    seen: set[str] = set()
    for value in values:
        try:
            canonical = normalize_tag_name(value)
        except TagDefinitionValidationError as exc:
            if exc.reason_code is TagDefinitionValidationReason.NAME_EMPTY:
                raise TagDefinitionValidationError(
                    empty_reason,
                    "canonical value is empty",
                ) from exc
            raise
        if canonical in seen:
            raise TagDefinitionValidationError(
                duplicate_reason,
                f"canonical value {canonical!r} appears more than once",
            )
        seen.add(canonical)
        normalized.append(canonical)
    return tuple(normalized)


class ValidationRuleEnvelope(BaseModel):
    """Stored validation-rule envelope for registered Slice 3 grammars."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    schema_id: str = "base.noop"
    schema_version: int = Field(default=1, ge=1)
    payload: JsonObject = Field(default_factory=dict)

    @field_validator("schema_id")
    @classmethod
    def _schema_id_nonempty(cls, value: str) -> str:
        normalized = value.strip()
        if normalized == "":
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
                "schema_id must not be empty",
            )
        return normalized


class ValidationRuleEvaluation(BaseModel):
    """Fail-closed result shape for future rule consumers."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    allowed: bool
    reason_code: TagDefinitionValidationReason | None = None


class ValidationRuleRegistry:
    """Small schema-id/version registry for write-time rule validation."""

    def __init__(self) -> None:
        self._validators: dict[tuple[str, int], RuleValidator] = {}

    def register(self, schema_id: str, schema_version: int, validator: RuleValidator) -> None:
        key = (schema_id.strip(), schema_version)
        if key[0] == "" or schema_version < 1:
            raise ValueError("validation rule schema registration requires id and positive version")
        self._validators[key] = validator

    def validate(self, rules: Mapping[str, Any]) -> ValidationRuleEnvelope:
        bounded_rules = validate_json_object_limits(rules)
        try:
            envelope = ValidationRuleEnvelope.model_validate(bounded_rules or {})
        except Exception as exc:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
                "validation rule envelope is invalid",
            ) from exc

        validator = self._validators.get((envelope.schema_id, envelope.schema_version))
        if validator is None:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.VALIDATION_RULE_SCHEMA_UNKNOWN,
                "validation rule schema is not registered",
            )
        validator(envelope)
        return envelope

    def evaluate(
        self,
        rules: Mapping[str, Any],
        *,
        value: Any = None,
    ) -> ValidationRuleEvaluation:
        """Evaluate a registered rule and deny on parser/evaluator failures.

        Slice 3 only needs the fail-closed contract. Registered validators are
        write-time grammar checks; future evaluators can replace this without
        changing the failure posture.
        """

        del value
        try:
            self.validate(rules)
        except Exception:
            return ValidationRuleEvaluation(
                allowed=False,
                reason_code=TagDefinitionValidationReason.VALIDATION_RULE_EVAL_FAILED,
            )
        return ValidationRuleEvaluation(allowed=True)


def _validate_noop_rule(envelope: ValidationRuleEnvelope) -> None:
    if envelope.payload:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_OPERATOR_UNKNOWN,
            "base.noop does not accept operators or operands",
        )


def _validate_scalar_rule(envelope: ValidationRuleEnvelope) -> None:
    operator = envelope.payload.get("operator")
    if operator not in {"one_of", "min", "max", "regex"}:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_OPERATOR_UNKNOWN,
            "unsupported validation rule operator",
        )
    if set(envelope.payload) != {"operator", "operand"}:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
            "scalar validation rule payload must contain operator and operand only",
        )

    operand = envelope.payload["operand"]
    if operator == "one_of":
        scalar_operands = (
            cast(Sequence[object], operand)
            if not isinstance(operand, str | bytes | bytearray) and isinstance(operand, Sequence)
            else None
        )
        if (
            scalar_operands is None
            or len(scalar_operands) == 0
            or not all(isinstance(item, str | int | float | bool) for item in scalar_operands)
        ):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
                "one_of operand must be a non-empty JSON scalar array",
            )
        return

    if operator in {"min", "max"}:
        if isinstance(operand, bool) or not isinstance(operand, int | float):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
                "min/max operand must be a JSON number",
            )
        return

    if not isinstance(operand, str):
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
            "regex operand must be a string pattern",
        )
    try:
        re.compile(operand)
    except re.error as exc:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALIDATION_RULE_ENVELOPE_INVALID,
            "regex operand must compile",
        ) from exc


DEFAULT_VALIDATION_RULE_REGISTRY = ValidationRuleRegistry()
DEFAULT_VALIDATION_RULE_REGISTRY.register("base.noop", 1, _validate_noop_rule)
DEFAULT_VALIDATION_RULE_REGISTRY.register("scalar", 1, _validate_scalar_rule)


class TagDefinitionValueContract(BaseModel):
    """Immutable value-shape contract for a tag definition row."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    value_type: TagValueType
    requires_currency: bool = False
    enum_values_canonical: tuple[str, ...] | None = None
    computed_depends_on_canonical: tuple[str, ...] | None = None


class ValidatedTagDefinitionPayload(BaseModel):
    """Validated create/update payload shape for tag definition writes."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    name_canonical: str = ""
    value_type: TagValueType
    requires_currency: bool = False
    enum_values: tuple[str, ...] | None = None
    enum_values_canonical: tuple[str, ...] | None = None
    computed_depends_on: tuple[str, ...] | None = None
    computed_depends_on_canonical: tuple[str, ...] | None = None
    validation_rules: JsonObject = Field(default_factory=dict)
    attrs: JsonObject = Field(default_factory=dict)

    @field_validator("name")
    @classmethod
    def _name_nonempty(cls, value: str) -> str:
        normalize_tag_name(value)
        return value

    @field_validator("validation_rules", "attrs", mode="before")
    @classmethod
    def _json_fields_must_be_objects(cls, value: Any) -> JsonObject:
        if value is None or not isinstance(value, Mapping):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.VALIDATION_RULE_OBJECT_REQUIRED,
                "validation_rules and attrs must be JSON objects",
            )
        json_object = cast(Mapping[str, Any], value)
        return dict(json_object)

    @field_validator("enum_values", mode="before")
    @classmethod
    def _enum_values_must_be_strings(cls, value: Any) -> tuple[str, ...] | None:
        if value is None:
            return None
        if isinstance(value, str | bytes | bytearray) or not isinstance(value, Sequence):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.ENUM_VALUE_INVALID,
                "enum_values must be a sequence of strings",
            )
        raw_values = cast(Sequence[object], value)
        if not all(isinstance(item, str) for item in raw_values):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.ENUM_VALUE_INVALID,
                "enum_values must contain only strings",
            )
        return tuple(cast(Sequence[str], raw_values))

    @field_validator("computed_depends_on", mode="before")
    @classmethod
    def _computed_dependencies_must_be_strings(cls, value: Any) -> tuple[str, ...] | None:
        if value is None:
            return None
        if isinstance(value, str | bytes | bytearray) or not isinstance(value, Sequence):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_INVALID,
                "computed_depends_on must be a sequence of strings",
            )
        raw_values = cast(Sequence[object], value)
        if not all(isinstance(item, str) for item in raw_values):
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_INVALID,
                "computed_depends_on must contain only strings",
            )
        return tuple(cast(Sequence[str], raw_values))

    @model_validator(mode="after")
    def _validate_value_contract(self) -> ValidatedTagDefinitionPayload:
        name_canonical = normalize_tag_name(self.name)
        enum_values_canonical: tuple[str, ...] | None = None
        computed_depends_on_canonical: tuple[str, ...] | None = None

        if self.requires_currency and self.value_type is not TagValueType.NUMBER:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.CURRENCY_REQUIRES_NUMBER,
                "requires_currency is allowed only for number definitions",
            )

        if self.value_type is TagValueType.ENUM:
            if not self.enum_values:
                raise TagDefinitionValidationError(
                    TagDefinitionValidationReason.ENUM_VALUES_REQUIRED,
                    "enum definitions require non-empty enum_values",
                )
            enum_values_canonical = normalize_unique_names(
                self.enum_values,
                empty_reason=TagDefinitionValidationReason.ENUM_VALUE_EMPTY,
                duplicate_reason=TagDefinitionValidationReason.ENUM_VALUE_DUPLICATE,
            )
        elif self.enum_values is not None:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.ENUM_VALUES_FORBIDDEN,
                "enum_values are allowed only for enum definitions",
            )

        if self.value_type is TagValueType.COMPUTED:
            if not self.computed_depends_on:
                raise TagDefinitionValidationError(
                    TagDefinitionValidationReason.COMPUTED_DEPENDENCIES_REQUIRED,
                    "computed definitions require non-empty computed_depends_on",
                )
            computed_depends_on_canonical = normalize_unique_names(
                self.computed_depends_on,
                empty_reason=TagDefinitionValidationReason.COMPUTED_DEPENDENCY_EMPTY,
                duplicate_reason=TagDefinitionValidationReason.COMPUTED_DEPENDENCY_DUPLICATE,
            )
        elif self.computed_depends_on is not None:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCIES_FORBIDDEN,
                "computed_depends_on is allowed only for computed definitions",
            )

        DEFAULT_VALIDATION_RULE_REGISTRY.validate(self.validation_rules)
        return self.model_copy(
            update={
                "name_canonical": name_canonical,
                "enum_values_canonical": enum_values_canonical,
                "computed_depends_on_canonical": computed_depends_on_canonical,
                "validation_rules": validate_json_object_limits(self.validation_rules),
                "attrs": validate_json_object_limits(self.attrs),
            },
        )

    @property
    def value_contract(self) -> TagDefinitionValueContract:
        return TagDefinitionValueContract(
            value_type=self.value_type,
            requires_currency=self.requires_currency,
            enum_values_canonical=self.enum_values_canonical,
            computed_depends_on_canonical=self.computed_depends_on_canonical,
        )


def validate_tag_definition_payload(
    payload: Mapping[str, Any],
) -> ValidatedTagDefinitionPayload:
    """Validate and canonicalize a tag definition payload."""

    try:
        return ValidatedTagDefinitionPayload.model_validate(payload)
    except TagDefinitionValidationError:
        raise
    except Exception as exc:
        error_text = str(exc)
        for reason_code in TagDefinitionValidationReason:
            if reason_code.value in error_text:
                raise TagDefinitionValidationError(
                    reason_code,
                    "tag definition payload is invalid",
                ) from exc
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALUE_TYPE_UNKNOWN,
            "tag definition payload is invalid",
        ) from exc


def allows_lifecycle_transition(
    current: TagDefinitionLifecycleState,
    proposed: TagDefinitionLifecycleState,
) -> bool:
    """Return whether a lifecycle update is allowed by §1.10."""

    if current is proposed:
        return True
    return (current, proposed) in {
        (TagDefinitionLifecycleState.ACTIVE, TagDefinitionLifecycleState.DEPRECATED),
        (TagDefinitionLifecycleState.DEPRECATED, TagDefinitionLifecycleState.RETIRED),
    }


def validate_lifecycle_transition(
    current: TagDefinitionLifecycleState,
    proposed: TagDefinitionLifecycleState,
) -> None:
    if not allows_lifecycle_transition(current, proposed):
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.LIFECYCLE_TRANSITION_INVALID,
            f"cannot transition tag definition from {current.value} to {proposed.value}",
        )


def validate_value_contract_immutable(
    existing: TagDefinitionValueContract,
    proposed: TagDefinitionValueContract,
) -> None:
    """Reject in-place edits to fields that determine stored NodeTag meaning."""

    if existing != proposed:
        raise TagDefinitionValidationError(
            TagDefinitionValidationReason.VALUE_CONTRACT_IMMUTABLE,
            "value_type, requires_currency, enum_values, and computed_depends_on are immutable",
        )


class TagDefinitionReference(BaseModel):
    """Pure row-like shape for dependency validation and tests."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID | None
    name: str
    value_type: TagValueType
    lifecycle_state: TagDefinitionLifecycleState = TagDefinitionLifecycleState.ACTIVE
    ontology_version_id: UUID | None = None
    computed_depends_on_canonical: tuple[str, ...] | None = None

    @property
    def name_canonical(self) -> str:
        return normalize_tag_name(self.name)


class TagDefinitionDependencyRepository(Protocol):
    """Pure lookup surface for computed dependency validation."""

    def find_by_canonical_name(
        self,
        *,
        tenant_id: UUID,
        name_canonical: str,
        ontology_version_id: UUID | None = None,
    ) -> TagDefinitionReference | None:
        """Return an org-scoped tag definition by canonical name."""
        ...


class InMemoryTagDefinitionDependencyRepository:
    """Dependency lookup fixture that mirrors the storage uniqueness contract."""

    def __init__(self, definitions: Sequence[TagDefinitionReference]) -> None:
        self._definitions = tuple(definitions)

    def find_by_canonical_name(
        self,
        *,
        tenant_id: UUID,
        name_canonical: str,
        ontology_version_id: UUID | None = None,
    ) -> TagDefinitionReference | None:
        matches = [
            definition
            for definition in self._definitions
            if definition.name_canonical == name_canonical
            and (definition.tenant_id in {tenant_id, None})
            and (
                ontology_version_id is None
                or definition.ontology_version_id is None
                or definition.ontology_version_id == ontology_version_id
            )
        ]
        if not matches:
            matches = [
                definition
                for definition in self._definitions
                if definition.name_canonical == name_canonical
                and (
                    ontology_version_id is None
                    or definition.ontology_version_id is None
                    or definition.ontology_version_id == ontology_version_id
                )
            ]
        if not matches:
            return None
        return matches[0]


def validate_computed_dependencies(
    *,
    definition_id: UUID | None,
    tenant_id: UUID,
    dependency_names: Sequence[str],
    repository: TagDefinitionDependencyRepository,
    ontology_version_id: UUID | None = None,
) -> tuple[TagDefinitionReference, ...]:
    """Resolve computed dependencies to active org-scoped source definitions."""

    canonical_dependencies = normalize_unique_names(
        dependency_names,
        empty_reason=TagDefinitionValidationReason.COMPUTED_DEPENDENCY_EMPTY,
        duplicate_reason=TagDefinitionValidationReason.COMPUTED_DEPENDENCY_DUPLICATE,
    )
    resolved: list[TagDefinitionReference] = []
    for dependency_name in canonical_dependencies:
        dependency = repository.find_by_canonical_name(
            tenant_id=tenant_id,
            name_canonical=dependency_name,
            ontology_version_id=ontology_version_id,
        )
        if dependency is None:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_MISSING,
                f"computed dependency {dependency_name!r} was not found",
            )
        if dependency.tenant_id is None:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_TEMPLATE,
                "computed dependencies must not resolve to templates",
            )
        if dependency.tenant_id != tenant_id:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_CROSS_SCOPE,
                "computed dependencies must be in the same organization",
            )
        if dependency.lifecycle_state is not TagDefinitionLifecycleState.ACTIVE:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_INACTIVE,
                "computed dependencies must be active source definitions",
            )
        if dependency.value_type is TagValueType.COMPUTED:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_COMPUTED,
                "computed-on-computed dependencies are forbidden",
            )
        if dependency.id == definition_id:
            raise TagDefinitionValidationError(
                TagDefinitionValidationReason.COMPUTED_DEPENDENCY_CYCLE,
                "computed definition cannot depend on itself",
            )
        resolved.append(dependency)
    return tuple(resolved)
