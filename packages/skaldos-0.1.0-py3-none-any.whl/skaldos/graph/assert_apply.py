"""Canonical graph application for accepted ``pending_assertions`` rows.

The Slice 4 endpoint originally stopped at staging/resolver handoff. Slice 10
needs the walking skeleton to prove that an accepted public assertion reaches
canonical graph storage, outbox, and read indexes through the write chokepoint.
This module owns that narrow bridge without broadening the public route.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.events.graph_publisher import (
    GraphChangeEventDraft,
    GraphChangeEventType,
    OutboxGraphChangeEventPublisher,
)
from skaldos.events.outbox import OutboxContextOfValidity
from skaldos.graph.assert_staging import AssertionLifecycleError, PendingAssertionStatus
from skaldos.graph.node_chunk_embeddings import NodeChunkEmbeddingGenerator
from skaldos.graph.pattern_validation import (
    GraphPatternValidationError,
    GraphPatternValidationReason,
    PatternOperation,
    ResolvedGraphPattern,
    validate_pattern_operation,
    validate_state_transition_create,
)
from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal
from skaldos.policy.intent import Intent

_PUBLIC_CLAIM_KIND_TYPE_ALIASES: dict[str, str] = {
    "observation": "note",
    "note": "note",
}


class AppliedAssertionRecord(BaseModel):
    """Projection returned after a resolved assertion is applied."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    status: PendingAssertionStatus
    applied_node_ids: tuple[UUID, ...] = ()
    applied_edge_ids: tuple[UUID, ...] = ()
    applied_tag_ids: tuple[UUID, ...] = ()
    warnings: tuple[str, ...] = ()


async def apply_resolved_assertion_as_node(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    staged_assertion_id: UUID,
    node_chunk_embedding_generator: NodeChunkEmbeddingGenerator | None = None,
) -> AppliedAssertionRecord:
    """Apply one resolved assertion as a canonical node and searchable chunk.

    This is intentionally conservative: it does not infer edges or tags and it
    does not mutate rows already terminal. Richer classification/tagging remains
    explicit Slice 10 follow-up work, but the public write path now creates a
    durable graph handle that downstream read/event paths can compose around.
    """

    async def _apply(bound_connection: asyncpg.Connection) -> AppliedAssertionRecord:
        pending = await _lock_pending_assertion(
            bound_connection,
            principal=principal,
            staged_assertion_id=staged_assertion_id,
        )
        if pending["status"] == PendingAssertionStatus.APPLIED:
            return _applied_record_from_pending(pending)
        current_status = cast(PendingAssertionStatus, pending["status"])
        if current_status is not PendingAssertionStatus.RESOLVED:
            raise AssertionLifecycleError(current_status, PendingAssertionStatus.APPLIED)

        claim = _jsonb_mapping(pending["claim"])
        context = _jsonb_mapping(pending["context_of_validity"])
        source = _jsonb_mapping(pending["source"])
        body = _claim_body(claim)
        resolved_pattern = await _resolve_ontology_type(
            bound_connection,
            context_of_validity=context,
            claim_kind=cast(str | None, pending["claim_kind"]),
        )
        metadata = _node_metadata(
            claim=claim,
            claim_kind=cast(str | None, pending["claim_kind"]),
            source=source,
            intent=cast(Intent, pending["intent"]),
            pending_assertion_id=staged_assertion_id,
        )
        _validate_public_node_create(resolved_pattern, metadata=metadata)
        node_id = await _insert_node(
            bound_connection,
            principal=principal,
            context_of_validity=context,
            claim=claim,
            claim_kind=cast(str | None, pending["claim_kind"]),
            source=source,
            intent=cast(Intent, pending["intent"]),
            pending_assertion_id=staged_assertion_id,
            type_id=resolved_pattern.ontology_type_id,
            body=body,
            metadata=metadata,
        )
        warnings: tuple[str, ...] = ()
        if node_chunk_embedding_generator is None:
            await _insert_node_chunk(
                bound_connection,
                context_of_validity=context,
                node_id=node_id,
                body=body,
            )
        else:
            try:
                await node_chunk_embedding_generator.generate_for_node(
                    principal=principal,
                    connection=bound_connection,
                    node_id=node_id,
                )
            except Exception:
                warnings = ("node_chunk_embedding_unavailable",)
        await OutboxGraphChangeEventPublisher(
            connection=bound_connection,
        ).publish_graph_change_event(
            GraphChangeEventDraft(
                event_type=GraphChangeEventType.NODE_CREATED,
                subject_id=node_id,
                tenant_id=cast(UUID, pending["tenant_id"]),
                context_of_validity=OutboxContextOfValidity.model_validate(
                    _outbox_context(context)
                ),
                intent=cast(Intent, pending["intent"]).value,
                actor_principal_id=principal.id,
                occurred_at=datetime.now(UTC),
            )
        )

        row = cast(
            Mapping[str, Any] | None,
            await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
UPDATE pending_assertions
SET status = 'applied',
    status_reason = 'accepted_new_node',
    applied_at = now(),
    applied_node_ids = ARRAY[$2::uuid],
    applied_edge_ids = '{}'::uuid[],
    applied_tag_ids = '{}'::uuid[],
    resolution_attempts = resolution_attempts + 1,
    last_attempt_at = now()
WHERE id = $1
  AND actor_principal_id = $3
  AND status = 'resolved'
RETURNING
    id,
    status::text AS status,
    applied_node_ids,
    applied_edge_ids,
    applied_tag_ids
""",
                staged_assertion_id,
                node_id,
                principal.id,
            ),
        )
        if row is None:
            raise AssertionLifecycleError(current_status, PendingAssertionStatus.APPLIED)
        return _applied_record_from_pending(
            {
                "id": row["id"],
                "status": PendingAssertionStatus(cast(str, row["status"])),
                "applied_node_ids": row["applied_node_ids"],
                "applied_edge_ids": row["applied_edge_ids"],
                "applied_tag_ids": row["applied_tag_ids"],
                "warnings": warnings,
            }
        )

    return await with_principal(principal=principal, connection=connection, fn=_apply)


def assertion_supports_node_application(claim: Mapping[str, Any]) -> bool:
    """Return whether the current narrow applier can project ``claim``."""

    kind = claim.get("kind") or claim.get("type")
    if isinstance(kind, str) and kind.strip() in {
        "edge_create",
        "node_body_update",
        "node_tag",
        "pattern4_revision",
    }:
        return False

    value = claim.get("body", claim.get("value"))
    return isinstance(value, str) and bool(value.strip())


def _jsonb_mapping(value: object) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return cast(Mapping[str, Any], value)
    if isinstance(value, str):
        try:
            loaded = json.loads(value)
        except json.JSONDecodeError as exc:
            raise AssertionLifecycleError(
                PendingAssertionStatus.RESOLVED,
                PendingAssertionStatus.REJECTED,
            ) from exc
        if isinstance(loaded, Mapping):
            return cast(Mapping[str, Any], loaded)
    raise AssertionLifecycleError(PendingAssertionStatus.RESOLVED, PendingAssertionStatus.REJECTED)


async def _lock_pending_assertion(
    connection: asyncpg.Connection,
    *,
    principal: Principal,
    staged_assertion_id: UUID,
) -> Mapping[str, Any]:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT
    id,
    status::text AS status,
    tenant_id,
    actor_principal_id,
    intent::text AS intent,
    source,
    claim,
    claim_kind,
    context_of_validity,
    applied_node_ids,
    applied_edge_ids,
    applied_tag_ids
FROM pending_assertions
WHERE id = $1
  AND actor_principal_id = $2
FOR UPDATE
""",
            staged_assertion_id,
            principal.id,
        ),
    )
    if row is None:
        raise AssertionLifecycleError(
            PendingAssertionStatus.REJECTED,
            PendingAssertionStatus.APPLIED,
        )
    return {
        **dict(row),
        "status": PendingAssertionStatus(cast(str, row["status"])),
        "intent": Intent(cast(str, row["intent"])),
    }


async def _resolve_ontology_type(
    connection: asyncpg.Connection,
    *,
    context_of_validity: Mapping[str, Any],
    claim_kind: str | None,
) -> ResolvedGraphPattern:
    ontology_version_id = UUID(str(context_of_validity["ontology_version"]))
    preferred = claim_kind.strip() if claim_kind is not None else ""
    type_name = _PUBLIC_CLAIM_KIND_TYPE_ALIASES.get(preferred, preferred or "note")
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
SELECT id, name, kind_discriminator, update_pattern
FROM ontology_type
WHERE ontology_version_id = $1
  AND name = $2
  AND lifecycle_state = 'active'
LIMIT 1
""",
            ontology_version_id,
            type_name,
        ),
    )
    if row is None:
        raise GraphPatternValidationError(
            GraphPatternValidationReason.ONTOLOGY_TYPE_NOT_FOUND,
            "public assertion claim kind did not resolve to an active ontology type",
            ontology_version_id=ontology_version_id,
            type_name=type_name,
        )
    return ResolvedGraphPattern(
        ontology_type_id=cast(UUID, row["id"]),
        ontology_version_id=ontology_version_id,
        type_name=str(row["name"]),
        kind_discriminator=cast(Any, str(row["kind_discriminator"])),
        update_pattern=cast(Any, int(row["update_pattern"])),
    )


def _validate_public_node_create(
    resolved_pattern: ResolvedGraphPattern,
    *,
    metadata: Mapping[str, Any],
) -> None:
    validate_pattern_operation(
        pattern=resolved_pattern.update_pattern,
        operation=PatternOperation.CREATE,
        ontology_type_id=resolved_pattern.ontology_type_id,
        ontology_version_id=resolved_pattern.ontology_version_id,
        type_name=resolved_pattern.type_name,
    )
    if resolved_pattern.update_pattern == 1:
        validate_state_transition_create(resolved=resolved_pattern, metadata=metadata)


def _node_metadata(
    *,
    claim: Mapping[str, Any],
    claim_kind: str | None,
    source: Mapping[str, Any],
    intent: Intent,
    pending_assertion_id: UUID,
) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "applied_from": "pending_assertion",
        "pending_assertion_id": str(pending_assertion_id),
        "assertion_intent": intent.value,
        "claim_kind": claim_kind,
        "source_kind": source.get("kind"),
        "claim_field": "body" if "body" in claim else "value",
    }
    previous_status: object | None = claim.get("previous_status")
    claim_metadata = claim.get("metadata")
    if previous_status is None and isinstance(claim_metadata, Mapping):
        previous_status = cast(Mapping[str, object], claim_metadata).get("previous_status")
    if previous_status is not None:
        metadata["previous_status"] = previous_status
    return metadata


async def _insert_node(
    connection: asyncpg.Connection,
    *,
    principal: Principal,
    context_of_validity: Mapping[str, Any],
    claim: Mapping[str, Any],
    claim_kind: str | None,
    source: Mapping[str, Any],
    intent: Intent,
    pending_assertion_id: UUID,
    type_id: UUID,
    body: str,
    metadata: Mapping[str, Any],
) -> UUID:
    row = cast(
        Mapping[str, Any] | None,
        await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
            """
INSERT INTO nodes (
    type_id,
    context_of_validity,
    body,
    metadata,
    authored_by_principal_id
)
VALUES ($1, $2::jsonb, $3, $4::jsonb, $5)
RETURNING id
""",
            type_id,
            json.dumps(dict(context_of_validity), sort_keys=True, separators=(",", ":")),
            body,
            json.dumps(metadata, sort_keys=True, separators=(",", ":")),
            principal.id,
        ),
    )
    if row is None:
        raise AssertionLifecycleError(
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.APPLIED,
        )
    return cast(UUID, row["id"])


async def _insert_node_chunk(
    connection: asyncpg.Connection,
    *,
    context_of_validity: Mapping[str, Any],
    node_id: UUID,
    body: str,
) -> None:
    result = await connection.execute(  # pyright: ignore[reportUnknownMemberType]
        """
INSERT INTO node_chunks (
    tenant_id,
    node_id,
    generation_id,
    chunk_index,
    offset_start,
    offset_end,
    body,
    classification,
    derives_from_hash,
    redaction_policy_version,
    scanner_version,
    generation_status
)
SELECT
    n.tenant_id,
    n.id,
    uuidv7(),
    0,
    0,
    char_length($2),
    $2,
    n.classification,
    n.body_nfc_hash,
    'graph-assert-v1',
    'shield-index-placeholder-v1',
    'complete'
FROM nodes n
WHERE n.id = $1
  AND n.tenant_id = (($3::jsonb ->> 'tenant')::uuid)
""",
        node_id,
        body,
        json.dumps(dict(context_of_validity), sort_keys=True, separators=(",", ":")),
    )
    if result != "INSERT 0 1":
        raise AssertionLifecycleError(
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.APPLIED,
        )


def _claim_body(claim: Mapping[str, Any]) -> str:
    value = claim.get("body", claim.get("value"))
    if not isinstance(value, str) or not value.strip():
        raise AssertionLifecycleError(
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.REJECTED,
        )
    return value


def _outbox_context(context: Mapping[str, Any]) -> dict[str, Any]:
    normalized = dict(context)
    if normalized.get("valid_to") == "":
        normalized["valid_to"] = None
    if normalized.get("valid_from") == "":
        normalized["valid_from"] = None
    return normalized


def _applied_record_from_pending(row: Mapping[str, Any]) -> AppliedAssertionRecord:
    return AppliedAssertionRecord(
        id=cast(UUID, row["id"]),
        status=cast(PendingAssertionStatus, row["status"]),
        applied_node_ids=tuple(cast(list[UUID], row["applied_node_ids"])),
        applied_edge_ids=tuple(cast(list[UUID], row["applied_edge_ids"])),
        applied_tag_ids=tuple(cast(list[UUID], row["applied_tag_ids"])),
        warnings=tuple(cast(tuple[str, ...], row.get("warnings", ()))),
    )


__all__ = [
    "AppliedAssertionRecord",
    "apply_resolved_assertion_as_node",
    "assertion_supports_node_application",
]
