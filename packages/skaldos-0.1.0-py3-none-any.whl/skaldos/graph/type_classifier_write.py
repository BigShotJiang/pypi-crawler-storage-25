"""Write-path bridge for Slice 3 server-side node type classification.

This module is deliberately DB-independent. It converts the pure classifier
result into the only two shapes a future Node write path may consume:

- canonical server-resolved type fields; or
- safe draft metadata suitable for ``nodes.metadata`` plus ``draft_state='draft'``.

It does not persist nodes, run pattern validation, or expose a route.
"""

from __future__ import annotations

from collections.abc import Mapping
from enum import StrEnum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, model_validator
from skaldos_log import log

from .type_classifier import (
    KindDiscriminator,
    TypeClassificationReason,
    TypeClassificationRequest,
    TypeClassificationResult,
    TypeClassificationStatus,
    TypeClassifier,
    UpdatePattern,
)


class NodeTypeWriteDisposition(StrEnum):
    """Whether a node write can proceed canonically or only as a draft."""

    CANONICAL = "canonical"
    DRAFT = "draft"


class NodeTypeWriteDecision(BaseModel):
    """Server-derived type decision for a future Node write."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    disposition: NodeTypeWriteDisposition
    ontology_type_id: UUID | None = None
    type_name: str | None = None
    kind_discriminator: KindDiscriminator | None = None
    update_pattern: UpdatePattern | None = None
    draft_state: str | None = None
    draft_metadata: dict[str, Any] = {}

    @model_validator(mode="after")
    def _shape_matches_disposition(self) -> NodeTypeWriteDecision:
        if self.disposition is NodeTypeWriteDisposition.CANONICAL:
            missing = [
                name
                for name in (
                    "ontology_type_id",
                    "type_name",
                    "kind_discriminator",
                    "update_pattern",
                )
                if getattr(self, name) is None
            ]
            if missing:
                raise ValueError(f"canonical node type decision missing fields: {missing}")
            if self.draft_state is not None or self.draft_metadata:
                raise ValueError("canonical node type decision must not carry draft fields")
            return self

        if self.draft_state != "draft":
            raise ValueError("draft node type decision must set draft_state='draft'")
        if self.ontology_type_id is not None:
            raise ValueError("draft node type decision must not select an ontology_type_id")
        if self.type_name is not None:
            raise ValueError("draft node type decision must not carry top-level type_name")
        if not self.draft_metadata:
            raise ValueError("draft node type decision must carry draft metadata")
        return self


def classifier_metadata(
    result: TypeClassificationResult,
    *,
    ontology_version_id: UUID,
) -> dict[str, Any]:
    """Return safe classifier metadata for draft persistence.

    The metadata intentionally omits raw node content and body previews. It is
    low-cardinality enough for logs/review and rich enough for human resolution.
    """

    metadata: dict[str, Any] = {
        "status": result.status.value,
        "reason_code": result.reason_code.value,
        "confidence": result.confidence,
        "threshold": result.threshold,
        "ontology_version_id": str(ontology_version_id),
        "classifier_name": result.classifier_name,
        "classifier_version": result.classifier_version,
        "candidate_type_ids": [str(candidate_id) for candidate_id in result.candidate_type_ids],
    }
    if result.threshold_version_id is not None:
        metadata["threshold_version_id"] = str(result.threshold_version_id)
    if result.type_name is not None:
        metadata["requested_type_name"] = result.type_name
        metadata["node_type_family"] = result.type_name
    if result.update_pattern is not None:
        metadata["predicted_update_pattern"] = result.update_pattern
    return metadata


def node_type_decision_from_result(
    result: TypeClassificationResult,
    *,
    ontology_version_id: UUID,
) -> NodeTypeWriteDecision:
    """Convert a classifier result into canonical fields or draft metadata."""

    if result.status is TypeClassificationStatus.RESOLVED:
        return NodeTypeWriteDecision(
            disposition=NodeTypeWriteDisposition.CANONICAL,
            ontology_type_id=result.ontology_type_id,
            type_name=result.type_name,
            kind_discriminator=result.kind_discriminator,
            update_pattern=result.update_pattern,
        )

    return NodeTypeWriteDecision(
        disposition=NodeTypeWriteDisposition.DRAFT,
        draft_state="draft",
        draft_metadata={
            "classifier": classifier_metadata(
                result,
                ontology_version_id=ontology_version_id,
            ),
        },
    )


def classifier_event_fields(
    *,
    result: TypeClassificationResult,
    request: TypeClassificationRequest,
    disposition: NodeTypeWriteDisposition,
) -> dict[str, Any]:
    """Return low-cardinality structured fields for classifier observability."""

    return {
        "decision": disposition.value,
        "status": result.status.value,
        "reason_code": result.reason_code.value,
        "ontology_version_id": str(request.ontology_version_id),
        "classifier_name": result.classifier_name,
        "classifier_version": result.classifier_version,
        "confidence": result.confidence,
        "threshold": result.threshold,
        "candidate_count": len(result.candidate_type_ids),
    }


async def classify_node_type_for_write(
    *,
    classifier: TypeClassifier,
    request: TypeClassificationRequest,
    client_payload: Mapping[str, Any] | None = None,
) -> NodeTypeWriteDecision:
    """Run the server classifier before canonical Node persistence.

    ``client_payload`` is accepted only so callers can pass their raw envelope
    and prove malicious classifier fields are ignored. The server request/result
    objects remain the only authority for type, kind, pattern, and confidence.
    """

    del client_payload
    try:
        result = await classifier.classify(request)
    except Exception:
        result = TypeClassificationResult.draft(
            reason_code=TypeClassificationReason.CLASSIFIER_UNAVAILABLE,
            requested_type_name=request.requested_type_name,
        )
    try:
        decision = node_type_decision_from_result(
            result,
            ontology_version_id=request.ontology_version_id,
        )
    except Exception:
        result = TypeClassificationResult.draft(
            reason_code=TypeClassificationReason.CLASSIFIER_INVALID_RESULT,
            requested_type_name=request.requested_type_name,
        )
        decision = node_type_decision_from_result(
            result,
            ontology_version_id=request.ontology_version_id,
        )

    log.info(
        "graph.type_classifier.decision",
        **classifier_event_fields(
            result=result,
            request=request,
            disposition=decision.disposition,
        ),
    )
    return decision
