"""Leakage-safe hybrid SearchService for Slice 6."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from datetime import datetime
from enum import StrEnum
from typing import Any, Protocol, cast
from uuid import UUID, uuid4

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.graph.edges import ClassificationLevel
from skaldos.graph.read_audit import (
    ReadAuditAction,
    ReadAuditSubjectType,
    emit_c2_read_audit_entry,
    max_read_classification,
)
from skaldos.graph.traversal import visible_result_count_bucket
from skaldos.lens.ranker import LensCandidate, rank_visible_candidates
from skaldos.lens.store import (
    LensDefinitionNotFoundError,
    LensDefinitionRecord,
    LensDefinitionStorageError,
    LensDefinitionStore,
)
from skaldos.middleware import Principal
from skaldos.shield_call_sites import (
    SearchQueryEmbeddingProofResult,
    SearchQueryEmbeddingUnavailableError,
    ShieldCallSiteIdentity,
)

DEFAULT_SEARCH_LIMIT = 20
MAX_SEARCH_LIMIT = 100
MAX_SEARCH_QUERY_LENGTH = 512
DEFAULT_RRF_K = 60
DEFAULT_TRIGRAM_THRESHOLD = 0.25


class SearchBranch(StrEnum):
    """Branch labels safe for production response metadata."""

    FTS = "fts"
    ILIKE = "ilike"
    TRIGRAM = "trigram"
    VECTOR = "vector"


class SearchSourceType(StrEnum):
    """Searchable source projections owned by the Slice 6 read path."""

    NODE = "node"
    NODE_CHUNK = "node_chunk"


class SearchDegradationCode(StrEnum):
    """Value-free degradation labels. None imply hidden result counts."""

    SHORT_QUERY_TRIGRAM_SKIPPED = "short_query_trigram_skipped"
    SHORT_QUERY_VECTOR_SKIPPED = "short_query_vector_skipped"
    SHIELD_EMBEDDING_FAILED_LEXICAL_ONLY = "shield_embedding_failed_lexical_only"
    VECTOR_UNAVAILABLE_NO_EMBEDDER = "vector_unavailable_no_embedder"
    VECTOR_INCOMPATIBLE_QUERY_EMBEDDING = "vector_incompatible_query_embedding"


class SearchQueryEmbedder(Protocol):
    """Canonical Shield search-query embedding seam consumed by SearchService."""

    async def embed_query(
        self,
        *,
        identity: ShieldCallSiteIdentity,
        query: str,
        entity_types: tuple[str, ...],
    ) -> SearchQueryEmbeddingProofResult:
        """Return Shield embedding proof metadata for a search query."""
        ...


class SearchLensStore(Protocol):
    """Minimal tenant-safe lens loader consumed by SearchService."""

    async def get_lens(
        self,
        *,
        connection: asyncpg.Connection,
        tenant_id: UUID,
        lens_id: UUID,
    ) -> LensDefinitionRecord:
        """Load one active lens definition through the request transaction."""
        ...


class SearchRequest(BaseModel):
    """Public/service request model for graph search."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    query: str = Field(min_length=1, max_length=MAX_SEARCH_QUERY_LENGTH)
    limit: int = Field(default=DEFAULT_SEARCH_LIMIT, ge=1, le=MAX_SEARCH_LIMIT)
    lens_id: UUID | None = None

    @field_validator("query")
    @classmethod
    def _query_must_be_nonempty_after_strip(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError("query_empty")
        return stripped


class SearchResultRow(BaseModel):
    """Visible search result row."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    source_type: SearchSourceType
    tenant_id: UUID
    classification: ClassificationLevel
    node_id: UUID
    chunk_id: UUID | None = None
    chunk_index: int | None = None
    summary: str | None = None
    score: float = Field(ge=0.0, le=1.0)
    branches: tuple[SearchBranch, ...]


class SearchMetadata(BaseModel):
    """Value-free response metadata."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    executed_branches: tuple[SearchBranch, ...]
    degradation_codes: tuple[SearchDegradationCode, ...]
    limit: int
    truncated: bool
    shield_call_id: UUID | None = None
    query_digest: str | None = Field(default=None, pattern=r"^sha256:[0-9a-f]{6,128}$")


class SearchPage(BaseModel):
    """Content-free search pagination metadata."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    limit: int = Field(ge=1)
    has_more: bool
    next_cursor: str | None = None


class SearchResult(BaseModel):
    """Leakage-safe graph search response."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    results: tuple[SearchResultRow, ...]
    metadata: SearchMetadata
    page: SearchPage


class SearchQueryError(RuntimeError):
    """Unexpected storage error while executing search."""


SEARCH_SQL = """
WITH visible_candidates AS MATERIALIZED (
    SELECT
        'node'::text AS source_type,
        n.id AS result_id,
        n.id AS node_id,
        NULL::uuid AS chunk_id,
        NULL::integer AS chunk_index,
        n.tenant_id,
        n.classification,
        n.context_of_validity,
        n.type_id,
        n.summary,
        n.body_nfc AS searchable_text,
        NULL::halfvec AS embedding,
        NULL::text AS embedding_provider,
        NULL::text AS embedding_model_id,
        NULL::integer AS embedding_dimensions,
        NULL::text AS embedding_dtype,
        n.created_at,
        ARRAY(
            SELECT nt.tag_definition_id::text
            FROM node_tags nt
            WHERE nt.node_id = n.id
              AND nt.tenant_id = n.tenant_id
              AND nt.superseded_by_tag_id IS NULL
              AND NOT (nt.attrs @> '{"stale": true}'::jsonb)
              AND app.principal_context_contains(nt.context_of_validity)
              AND app.classification_rank(nt.classification)
                  <= app.classification_rank(
                       COALESCE(
                         app.principal_context() #>> ARRAY['clearances', nt.tenant_id::text],
                         app.principal_context() ->> 'classification'
                       )
                     )
            ORDER BY nt.tag_definition_id::text
        ) AS tag_signals
    FROM nodes n
    WHERE n.tenant_id = $1
      AND n.archived_at IS NULL
      AND n.superseded_by_node_id IS NULL
      AND app.principal_context_contains(n.context_of_validity)

    UNION ALL

    SELECT
        'node_chunk'::text AS source_type,
        c.id AS result_id,
        c.node_id,
        c.id AS chunk_id,
        c.chunk_index,
        c.tenant_id,
        c.classification,
        n.context_of_validity,
        n.type_id,
        n.summary,
        c.body AS searchable_text,
        c.embedding,
        c.embedding_provider::text,
        c.embedding_model_id,
        c.embedding_dimensions,
        c.embedding_dtype,
        c.created_at,
        ARRAY(
            SELECT nt.tag_definition_id::text
            FROM node_tags nt
            WHERE nt.node_id = n.id
              AND nt.tenant_id = n.tenant_id
              AND nt.superseded_by_tag_id IS NULL
              AND NOT (nt.attrs @> '{"stale": true}'::jsonb)
              AND app.principal_context_contains(nt.context_of_validity)
              AND app.classification_rank(nt.classification)
                  <= app.classification_rank(
                       COALESCE(
                         app.principal_context() #>> ARRAY['clearances', nt.tenant_id::text],
                         app.principal_context() ->> 'classification'
                       )
                     )
            ORDER BY nt.tag_definition_id::text
        ) AS tag_signals
    FROM active_node_chunks_read c
    JOIN nodes n ON n.id = c.node_id
    WHERE c.tenant_id = $1
      AND n.tenant_id = $1
      AND n.archived_at IS NULL
      AND app.principal_context_contains(n.context_of_validity)
      AND app.classification_rank(
            COALESCE(
              app.principal_context() #>> ARRAY['clearances', c.tenant_id::text],
              app.principal_context() ->> 'classification'
            )
          ) >= app.classification_rank(c.classification)
),
fts_branch AS (
    SELECT
        ranked.source_type,
        ranked.result_id,
        'fts'::text AS branch,
        row_number() OVER (
            ORDER BY ranked.branch_score DESC, ranked.created_at DESC, ranked.result_id ASC
        )::integer AS branch_rank
    FROM (
        SELECT
            vc.source_type,
            vc.result_id,
            vc.created_at,
            ts_rank_cd(
                to_tsvector('norwegian', COALESCE(vc.searchable_text, '')),
                websearch_to_tsquery('norwegian', $2)
            ) AS branch_score
        FROM visible_candidates vc
        WHERE to_tsvector('norwegian', COALESCE(vc.searchable_text, ''))
              @@ websearch_to_tsquery('norwegian', $2)
        ORDER BY branch_score DESC, vc.created_at DESC, vc.result_id ASC
        LIMIT $4
    ) ranked
),
ilike_branch AS (
    SELECT
        ranked.source_type,
        ranked.result_id,
        'ilike'::text AS branch,
        row_number() OVER (
            ORDER BY ranked.branch_score DESC, ranked.created_at DESC, ranked.result_id ASC
        )::integer AS branch_rank
    FROM (
        SELECT
            vc.source_type,
            vc.result_id,
            vc.created_at,
            CASE
              WHEN lower(COALESCE(vc.searchable_text, '')) = lower($2) THEN 2.0
              ELSE 1.0
            END AS branch_score
        FROM visible_candidates vc
        WHERE vc.searchable_text ILIKE $3
        ORDER BY branch_score DESC, vc.created_at DESC, vc.result_id ASC
        LIMIT $4
    ) ranked
),
trigram_branch AS (
    SELECT
        ranked.source_type,
        ranked.result_id,
        'trigram'::text AS branch,
        row_number() OVER (
            ORDER BY ranked.branch_score DESC, ranked.created_at DESC, ranked.result_id ASC
        )::integer AS branch_rank
    FROM (
        SELECT
            vc.source_type,
            vc.result_id,
            vc.created_at,
            word_similarity($2, COALESCE(vc.searchable_text, '')) AS branch_score
        FROM visible_candidates vc
        WHERE $5::boolean
          AND word_similarity($2, COALESCE(vc.searchable_text, '')) >= $6
        ORDER BY branch_score DESC, vc.created_at DESC, vc.result_id ASC
        LIMIT $4
    ) ranked
),
vector_branch AS (
    SELECT
        ranked.source_type,
        ranked.result_id,
        'vector'::text AS branch,
        row_number() OVER (
            ORDER BY ranked.distance ASC, ranked.created_at DESC, ranked.result_id ASC
        )::integer AS branch_rank
    FROM (
        SELECT
            vc.source_type,
            vc.result_id,
            vc.created_at,
            vc.embedding <=> $9::halfvec AS distance
        FROM visible_candidates vc
        WHERE $10::boolean
          AND vc.embedding IS NOT NULL
          AND vc.embedding_provider = $11
          AND vc.embedding_model_id = $12
          AND vc.embedding_dimensions = $13
          AND vc.embedding_dtype = $14
        ORDER BY vc.embedding <=> $9::halfvec ASC, vc.created_at DESC, vc.result_id ASC
        LIMIT $4
    ) ranked
),
unioned AS (
    SELECT * FROM fts_branch
    UNION ALL
    SELECT * FROM ilike_branch
    UNION ALL
    SELECT * FROM trigram_branch
    UNION ALL
    SELECT * FROM vector_branch
),
rrf AS (
    SELECT
        source_type,
        result_id,
        SUM(1.0 / ($7::double precision + branch_rank)) AS rrf_score,
        array_agg(branch ORDER BY branch) AS branch_names
    FROM unioned
    GROUP BY source_type, result_id
)
SELECT
    vc.source_type,
    vc.result_id,
    vc.node_id,
    vc.chunk_id,
    vc.chunk_index,
    vc.tenant_id,
    vc.classification,
    vc.context_of_validity,
    vc.type_id,
    vc.summary,
    vc.created_at,
    vc.tag_signals,
    rrf.rrf_score,
    rrf.branch_names
FROM rrf
JOIN visible_candidates vc
  ON vc.source_type = rrf.source_type
 AND vc.result_id = rrf.result_id
ORDER BY rrf.rrf_score DESC, vc.created_at DESC, vc.result_id ASC
LIMIT $8;
"""


class SearchService:
    """Hybrid-search service foundation over visible nodes and active chunks."""

    def __init__(
        self,
        *,
        query_embedder: SearchQueryEmbedder | None = None,
        lens_store: SearchLensStore | None = None,
        allow_lexical_degradation_on_shield_unavailable: bool = False,
    ) -> None:
        self._query_embedder = query_embedder
        self._lens_store = lens_store or LensDefinitionStore()
        self._allow_lexical_degradation_on_shield_unavailable = (
            allow_lexical_degradation_on_shield_unavailable
        )

    async def search(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: SearchRequest,
    ) -> SearchResult:
        branch_limit = max(50, 3 * request.limit)
        enable_trigram = len(request.query) >= 3
        degradation_codes: list[SearchDegradationCode] = []
        if not enable_trigram:
            degradation_codes.extend(
                [
                    SearchDegradationCode.SHORT_QUERY_TRIGRAM_SKIPPED,
                    SearchDegradationCode.SHORT_QUERY_VECTOR_SKIPPED,
                ]
            )
        shield_proof = await self._try_embed_query(
            principal=principal,
            request=request,
            degradation_codes=degradation_codes,
            vector_candidate=enable_trigram,
        )
        query_vector = _compatible_query_vector_literal(
            shield_proof,
            degradation_codes=degradation_codes,
        )
        enable_vector = query_vector is not None
        lens = await self._load_lens(connection=connection, request=request)

        try:
            rows = cast(
                Sequence[Mapping[str, Any]],
                await connection.fetch(  # pyright: ignore[reportUnknownMemberType]
                    SEARCH_SQL,
                    request.tenant_id,
                    request.query,
                    f"%{request.query}%",
                    branch_limit,
                    enable_trigram,
                    DEFAULT_TRIGRAM_THRESHOLD,
                    DEFAULT_RRF_K,
                    request.limit + 1,
                    query_vector,
                    enable_vector,
                    shield_proof.provider if enable_vector and shield_proof is not None else None,
                    shield_proof.model_id if enable_vector and shield_proof is not None else None,
                    shield_proof.dimensions if enable_vector and shield_proof is not None else None,
                    shield_proof.dtype if enable_vector and shield_proof is not None else None,
                ),
            )
        except Exception as exc:
            raise SearchQueryError("search_query_failed") from exc

        truncated = len(rows) > request.limit
        visible_rows = tuple(rows[: request.limit])
        visible_rows = _apply_lens_ranking(visible_rows, lens)
        results = _result_rows(visible_rows)
        await _emit_search_read_audit(
            connection=connection,
            principal=principal,
            request=request,
            rows=visible_rows,
            results=results,
            shield_proof=shield_proof,
        )

        return SearchResult(
            tenant_id=request.tenant_id,
            results=results,
            metadata=SearchMetadata(
                executed_branches=_executed_branches(
                    enable_trigram=enable_trigram,
                    enable_vector=enable_vector,
                ),
                degradation_codes=tuple(degradation_codes),
                limit=request.limit,
                truncated=truncated,
                shield_call_id=shield_proof.call_id if shield_proof is not None else None,
                query_digest=_safe_query_digest(shield_proof),
            ),
            page=SearchPage(limit=request.limit, has_more=truncated, next_cursor=None),
        )

    async def _try_embed_query(
        self,
        *,
        principal: Principal,
        request: SearchRequest,
        degradation_codes: list[SearchDegradationCode],
        vector_candidate: bool,
    ) -> SearchQueryEmbeddingProofResult | None:
        if not vector_candidate:
            return None
        if self._query_embedder is None:
            degradation_codes.append(SearchDegradationCode.VECTOR_UNAVAILABLE_NO_EMBEDDER)
            return None
        try:
            proof = await self._query_embedder.embed_query(
                identity=ShieldCallSiteIdentity(
                    tenant_id=request.tenant_id,
                    principal_id=principal.id,
                ),
                query=request.query,
                entity_types=("UNKNOWN",),
            )
        except SearchQueryEmbeddingUnavailableError as exc:
            if not self._allow_lexical_degradation_on_shield_unavailable:
                raise SearchQueryError("search_query_shield_unavailable") from exc
            degradation_codes.append(SearchDegradationCode.SHIELD_EMBEDDING_FAILED_LEXICAL_ONLY)
            return None
        return proof

    async def _load_lens(
        self,
        *,
        connection: asyncpg.Connection,
        request: SearchRequest,
    ) -> LensDefinitionRecord | None:
        if request.lens_id is None:
            return None
        return await self._lens_store.get_lens(
            connection=connection,
            tenant_id=request.tenant_id,
            lens_id=request.lens_id,
        )


def _apply_lens_ranking(
    rows: tuple[Mapping[str, Any], ...],
    lens: LensDefinitionRecord | None,
) -> tuple[Mapping[str, Any], ...]:
    if lens is None or not rows:
        return rows

    row_by_candidate_id = {str(row["result_id"]): row for row in rows}
    candidates = tuple(
        _lens_candidate_from_row(row, upstream_rank=index)
        for index, row in enumerate(rows, start=1)
    )
    ranked = rank_visible_candidates(candidates, lens.definition)
    ranked_rows = tuple(row_by_candidate_id[item.candidate.candidate_id] for item in ranked)
    if {row["result_id"] for row in ranked_rows} != {row["result_id"] for row in rows}:
        raise SearchQueryError("lens_ranker_changed_visible_set")
    return ranked_rows


def _lens_candidate_from_row(row: Mapping[str, Any], *, upstream_rank: int) -> LensCandidate:
    created_at = row["created_at"]
    if isinstance(created_at, str):
        parsed_created_at = datetime.fromisoformat(created_at)
    else:
        parsed_created_at = cast(datetime, created_at)
    return LensCandidate(
        candidate_id=str(row["result_id"]),
        candidate_kind="node_chunk" if row["source_type"] == "node_chunk" else "node",
        tenant_id=str(row["tenant_id"]),
        classification=str(row["classification"]),
        created_at=parsed_created_at,
        upstream_rank=upstream_rank,
        upstream_score=float(row["rrf_score"]),
        type_id=str(row["type_id"]) if row.get("type_id") is not None else None,
        tag_signals=tuple(str(value) for value in row.get("tag_signals", ()) or ()),
    )


def _result_rows(rows: Sequence[Mapping[str, Any]]) -> tuple[SearchResultRow, ...]:
    raw_scores = [float(row["rrf_score"]) for row in rows]
    max_score = max(raw_scores, default=0.0)
    normalized_denominator = max_score if max_score > 0 else 1.0
    return tuple(
        SearchResultRow(
            id=row["result_id"],
            source_type=SearchSourceType(row["source_type"]),
            tenant_id=row["tenant_id"],
            classification=ClassificationLevel(row["classification"]),
            node_id=row["node_id"],
            chunk_id=row["chunk_id"],
            chunk_index=row["chunk_index"],
            summary=row["summary"],
            score=float(row["rrf_score"]) / normalized_denominator,
            branches=tuple(SearchBranch(branch) for branch in row["branch_names"]),
        )
        for row in rows
    )


async def _emit_search_read_audit(
    *,
    connection: asyncpg.Connection,
    principal: Principal,
    request: SearchRequest,
    rows: Sequence[Mapping[str, Any]],
    results: Sequence[SearchResultRow],
    shield_proof: SearchQueryEmbeddingProofResult | None,
) -> None:
    classifications = tuple(result.classification for result in results)
    max_classification = max_read_classification(classifications)
    if max_classification is None:
        return

    context = _audit_context(rows)
    context["classification"] = max_classification.value
    metadata: dict[str, Any] = {
        "service": "SearchService",
        "route": "POST /graph/search",
        "visible_result_count_bucket": visible_result_count_bucket(len(results)),
        "subject_handles": [str(result.id) for result in results[:20]],
    }
    if shield_proof is not None:
        metadata["shield_call_id"] = str(shield_proof.call_id)
        metadata["query_digest"] = f"sha256:{shield_proof.query_hash}"
    if request.lens_id is not None:
        metadata["lens_id"] = str(request.lens_id)

    await emit_c2_read_audit_entry(
        connection=connection,
        tenant_id=request.tenant_id,
        actor_principal_id=principal.id,
        subject_type=ReadAuditSubjectType.READ_RESULT_SET,
        subject_id=uuid4(),
        action=ReadAuditAction.SEARCH,
        result_classifications=classifications,
        context_of_validity=context,
        metadata=metadata,
    )


def _audit_context(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if not rows:
        return {}
    value = rows[0]["context_of_validity"]
    if isinstance(value, str):
        parsed = json.loads(value)
        if not isinstance(parsed, Mapping):
            return {}
        return dict(cast(Mapping[str, Any], parsed))
    if isinstance(value, Mapping):
        return dict(cast(Mapping[str, Any], value))
    return {}


def _executed_branches(
    *,
    enable_trigram: bool,
    enable_vector: bool,
) -> tuple[SearchBranch, ...]:
    branches = [SearchBranch.FTS, SearchBranch.ILIKE]
    if enable_trigram:
        branches.append(SearchBranch.TRIGRAM)
    if enable_vector:
        branches.append(SearchBranch.VECTOR)
    return tuple(branches)


def _safe_query_digest(proof: SearchQueryEmbeddingProofResult | None) -> str | None:
    if proof is None:
        return None
    return f"sha256:{proof.query_hash}"


def _compatible_query_vector_literal(
    proof: SearchQueryEmbeddingProofResult | None,
    *,
    degradation_codes: list[SearchDegradationCode],
) -> str | None:
    if proof is None:
        return None
    if (
        proof.dimensions != len(proof.vector)
        or proof.dimensions <= 0
        or proof.dtype != "float"
        or not proof.provider.strip()
        or not proof.model_id.strip()
    ):
        degradation_codes.append(SearchDegradationCode.VECTOR_INCOMPATIBLE_QUERY_EMBEDDING)
        return None
    return "[" + ",".join(str(value) for value in proof.vector) + "]"


__all__ = [
    "DEFAULT_SEARCH_LIMIT",
    "DEFAULT_RRF_K",
    "MAX_SEARCH_LIMIT",
    "MAX_SEARCH_QUERY_LENGTH",
    "SEARCH_SQL",
    "SearchBranch",
    "SearchDegradationCode",
    "SearchMetadata",
    "SearchLensStore",
    "SearchQueryEmbedder",
    "SearchQueryError",
    "SearchRequest",
    "SearchResult",
    "SearchResultRow",
    "SearchService",
    "SearchSourceType",
    "LensDefinitionNotFoundError",
    "LensDefinitionStorageError",
]
