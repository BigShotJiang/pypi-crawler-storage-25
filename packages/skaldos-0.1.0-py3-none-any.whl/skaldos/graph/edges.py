"""Edge service contracts and validation helpers for Slice 3 graph writes.

This module stays deliberately service-facing: it validates the Edge primitive
landed by the Slice 3 Bundle A schema, exposes repository/service Protocols for
RLS-bound callers, and maps storage races into stable domain reason codes. It
does not define public routes or bypass endpoint visibility checks.

References: §1.13, §1.15, §6.1, §15.4, ML5(1), AP5.
"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from datetime import datetime
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Any, Literal, Protocol, runtime_checkable
from uuid import UUID

import asyncpg
from pydantic import BaseModel, ConfigDict

type EdgeEndpointPosition = Literal["source", "target"]

_PAYLOAD_FIELDS = frozenset(
    {
        "source_node_id",
        "target_node_id",
        "relationship_type",
        "weight",
        "requested_classification",
    }
)
_RELATIONSHIP_ATTRIBUTE_KEYS = frozenset(
    {
        "attrs",
        "metadata",
        "attributes",
        "valid_from",
        "valid_to",
        "confidence",
        "role",
        "provenance",
    }
)
_ACTIVE_EDGE_UNIQUE_CONSTRAINTS = frozenset({"edges_active_semantic_unique"})
_EDGE_FK_CONSTRAINTS = frozenset(
    {
        "edges_source_node_id_fkey",
        "edges_target_node_id_fkey",
        "edges_relationship_type_fkey",
    }
)


class ClassificationLevel(StrEnum):
    """Fixed substrate classification levels, ordered by sensitivity."""

    C0 = "C0"
    C1 = "C1"
    C2 = "C2"
    C3 = "C3"
    C4 = "C4"

    @property
    def rank(self) -> int:
        return _CLASSIFICATION_RANKS[self]


_CLASSIFICATION_RANKS: Mapping[ClassificationLevel, int] = {
    ClassificationLevel.C0: 0,
    ClassificationLevel.C1: 1,
    ClassificationLevel.C2: 2,
    ClassificationLevel.C3: 3,
    ClassificationLevel.C4: 4,
}


class EdgeRelationshipType(StrEnum):
    """Closed Slice 3 relationship vocabulary seeded by the edge schema."""

    GROUNDED_BY = "grounded-by"
    WARRANTED_BY = "warranted-by"
    REBUTTED_BY = "rebutted-by"
    FALSIFIED_BY = "falsified-by"
    QUALIFIED_BY = "qualified-by"
    REVISES = "revises"
    SUPERSEDED_BY = "superseded-by"
    DERIVED_FROM = "derived-from"
    INFORMED_BY = "informed-by"
    RELATES_TO = "relates-to"
    REVIEW_REQUIRED_BY = "review-required-by"
    SUBSCRIBES_TO = "subscribes-to"
    REQUESTED_OF = "requested-of"
    PROMISED_BY = "promised-by"
    COMPLETED_BY = "completed-by"
    SATISFIED_BY = "satisfied-by"
    REJECTED_BY = "rejected-by"


ACTIVE_RELATIONSHIP_TYPES: frozenset[EdgeRelationshipType] = frozenset(
    {
        EdgeRelationshipType.GROUNDED_BY,
        EdgeRelationshipType.WARRANTED_BY,
        EdgeRelationshipType.REBUTTED_BY,
        EdgeRelationshipType.FALSIFIED_BY,
        EdgeRelationshipType.QUALIFIED_BY,
        EdgeRelationshipType.REVISES,
        EdgeRelationshipType.DERIVED_FROM,
        EdgeRelationshipType.INFORMED_BY,
        EdgeRelationshipType.RELATES_TO,
        EdgeRelationshipType.REVIEW_REQUIRED_BY,
    }
)
RESERVED_RELATIONSHIP_TYPES: frozenset[EdgeRelationshipType] = frozenset(
    set(EdgeRelationshipType) - set(ACTIVE_RELATIONSHIP_TYPES)
)


class EdgeValidationReason(StrEnum):
    """Low-cardinality reason codes for caller-visible edge validation."""

    INVALID_RELATIONSHIP_TYPE = "invalid_relationship_type"
    RESERVED_RELATIONSHIP_TYPE = "reserved_relationship_type"
    RELATIONSHIP_ATTRIBUTES_REQUIRE_NODE = "relationship_attributes_require_node"
    UNKNOWN_PAYLOAD_KEYS = "edge_payload_unknown_keys"
    INVALID_WEIGHT = "invalid_weight"
    SELF_EDGE = "self_edge"
    SOURCE_NOT_FOUND = "source_not_found"
    TARGET_NOT_FOUND = "target_not_found"
    ARCHIVED_ENDPOINT = "archived_endpoint"
    SUPERSEDED_ENDPOINT = "superseded_endpoint"
    ENDPOINT_TENANT_MISMATCH = "endpoint_tenant_mismatch"
    DUPLICATE_EDGE = "duplicate_edge"
    GROUNDED_BY_REQUIRED = "grounded_by_required"
    FALSIFIED_BY_REQUIRED = "falsified_by_required"
    RELATIONSHIP_NODE_ENDPOINTS_REQUIRED = "relationship_node_endpoints_required"
    ENDPOINT_CHANGED = "endpoint_changed"
    EDGE_NOT_FOUND = "edge_not_found"
    EDGE_STORAGE_CONFLICT = "edge_storage_conflict"


class EdgeValidationError(ValueError):
    """Domain validation error with a stable reason code and safe details."""

    def __init__(
        self,
        reason_code: EdgeValidationReason,
        message: str,
        *,
        rejected_keys: Sequence[str] = (),
        endpoint_position: EdgeEndpointPosition | None = None,
    ) -> None:
        self.reason_code = reason_code
        self.rejected_keys = tuple(rejected_keys)
        self.endpoint_position = endpoint_position
        super().__init__(f"{reason_code.value}: {message}")


class EdgeEndpointSnapshot(BaseModel):
    """RLS-bound endpoint projection used before creating an edge."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    classification: ClassificationLevel
    archived_at: datetime | None = None
    superseded_by_node_id: UUID | None = None

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None


class EdgeCreatePayload(BaseModel):
    """Strict service payload for creating an edge.

    Use :func:`validate_edge_create_payload` for untrusted mappings so unknown
    keys and relationship-attribute attempts receive domain reason codes before
    Pydantic's structural validation runs.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    source_node_id: UUID
    target_node_id: UUID
    relationship_type: EdgeRelationshipType
    weight: Decimal | None = None
    requested_classification: ClassificationLevel | None = None

    def model_post_init(self, __context: Any) -> None:
        validate_no_self_edge(self.source_node_id, self.target_node_id)
        validate_relationship_type(self.relationship_type)
        object.__setattr__(self, "weight", validate_edge_weight(self.weight))


class EdgeArchivePayload(BaseModel):
    """Strict service payload for archiving an active edge."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    edge_id: UUID


class EdgeRow(BaseModel):
    """Storage row shape returned by edge repositories."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    source_node_id: UUID
    target_node_id: UUID
    relationship_type: EdgeRelationshipType
    weight: Decimal | None = None
    classification: ClassificationLevel
    authored_by_principal_id: UUID
    created_at: datetime
    archived_at: datetime | None = None
    archived_by_principal_id: UUID | None = None


class EdgeWriteContext(BaseModel):
    """Service write context derived from the hydrated Principal/chokepoint."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    actor_principal_id: UUID


class Pattern4DecisionEdgeBundlePayload(BaseModel):
    """Atomic Pattern-4 edge bundle shape for decision-node transactions.

    Callers should stage the decision Node and every returned Edge payload in
    one transaction, then run Pattern-4 finalizer validation before commit.
    The contract pins edge direction: the decision node is always the source.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    decision_node_id: UUID
    grounded_by_node_ids: tuple[UUID, ...]
    falsified_by_node_ids: tuple[UUID, ...]
    warranted_by_node_ids: tuple[UUID, ...] = ()
    rebutted_by_node_ids: tuple[UUID, ...] = ()
    qualified_by_node_ids: tuple[UUID, ...] = ()
    weight: Decimal | None = None
    requested_classification: ClassificationLevel | None = None

    def model_post_init(self, __context: Any) -> None:
        if not self.grounded_by_node_ids:
            raise EdgeValidationError(
                EdgeValidationReason.GROUNDED_BY_REQUIRED,
                "Pattern 4 decision requires at least one grounded-by edge",
            )
        if not self.falsified_by_node_ids:
            raise EdgeValidationError(
                EdgeValidationReason.FALSIFIED_BY_REQUIRED,
                "Pattern 4 decision requires at least one falsified-by edge",
            )
        self._validate_unique_targets(
            EdgeRelationshipType.GROUNDED_BY,
            self.grounded_by_node_ids,
        )
        self._validate_unique_targets(
            EdgeRelationshipType.FALSIFIED_BY,
            self.falsified_by_node_ids,
        )
        self._validate_unique_targets(
            EdgeRelationshipType.WARRANTED_BY,
            self.warranted_by_node_ids,
        )
        self._validate_unique_targets(
            EdgeRelationshipType.REBUTTED_BY,
            self.rebutted_by_node_ids,
        )
        self._validate_unique_targets(
            EdgeRelationshipType.QUALIFIED_BY,
            self.qualified_by_node_ids,
        )
        for target_node_id in self._all_target_node_ids():
            validate_no_self_edge(self.decision_node_id, target_node_id)
        object.__setattr__(self, "weight", validate_edge_weight(self.weight))

    def edge_payloads(self) -> tuple[EdgeCreatePayload, ...]:
        """Return create-edge payloads to persist inside the caller transaction."""

        return tuple(
            EdgeCreatePayload(
                source_node_id=self.decision_node_id,
                target_node_id=target_node_id,
                relationship_type=relationship_type,
                weight=self.weight,
                requested_classification=self.requested_classification,
            )
            for relationship_type, target_node_ids in self._relationship_targets()
            for target_node_id in target_node_ids
        )

    def _relationship_targets(
        self,
    ) -> tuple[tuple[EdgeRelationshipType, tuple[UUID, ...]], ...]:
        return (
            (EdgeRelationshipType.GROUNDED_BY, self.grounded_by_node_ids),
            (EdgeRelationshipType.FALSIFIED_BY, self.falsified_by_node_ids),
            (EdgeRelationshipType.WARRANTED_BY, self.warranted_by_node_ids),
            (EdgeRelationshipType.REBUTTED_BY, self.rebutted_by_node_ids),
            (EdgeRelationshipType.QUALIFIED_BY, self.qualified_by_node_ids),
        )

    def _all_target_node_ids(self) -> tuple[UUID, ...]:
        return tuple(
            target_node_id
            for _, target_node_ids in self._relationship_targets()
            for target_node_id in target_node_ids
        )

    @staticmethod
    def _validate_unique_targets(
        relationship_type: EdgeRelationshipType,
        target_node_ids: tuple[UUID, ...],
    ) -> None:
        if len(set(target_node_ids)) != len(target_node_ids):
            raise EdgeValidationError(
                EdgeValidationReason.DUPLICATE_EDGE,
                f"Pattern 4 bundle contains duplicate {relationship_type.value} targets",
            )


class RelationshipNodeEdgeBundlePayload(BaseModel):
    """Relationship-node modeling contract for attributed relationships.

    Attribute-bearing relationships are represented as a relationship Node plus
    two outgoing ``relates-to`` edges. Edge payloads remain attribute-free.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    relationship_node_id: UUID
    endpoint_node_ids: tuple[UUID, UUID]
    weight: Decimal | None = None
    requested_classification: ClassificationLevel | None = None

    def model_post_init(self, __context: Any) -> None:
        if len(self.endpoint_node_ids) != 2:
            raise EdgeValidationError(
                EdgeValidationReason.RELATIONSHIP_NODE_ENDPOINTS_REQUIRED,
                "relationship node modeling requires exactly two endpoint nodes",
            )
        if self.endpoint_node_ids[0] == self.endpoint_node_ids[1]:
            raise EdgeValidationError(
                EdgeValidationReason.RELATIONSHIP_NODE_ENDPOINTS_REQUIRED,
                "relationship node endpoint ids must differ",
            )
        for endpoint_node_id in self.endpoint_node_ids:
            validate_no_self_edge(self.relationship_node_id, endpoint_node_id)
        object.__setattr__(self, "weight", validate_edge_weight(self.weight))

    def edge_payloads(self) -> tuple[EdgeCreatePayload, EdgeCreatePayload]:
        """Return the two attribute-free ``relates-to`` create payloads."""

        return (
            EdgeCreatePayload(
                source_node_id=self.relationship_node_id,
                target_node_id=self.endpoint_node_ids[0],
                relationship_type=EdgeRelationshipType.RELATES_TO,
                weight=self.weight,
                requested_classification=self.requested_classification,
            ),
            EdgeCreatePayload(
                source_node_id=self.relationship_node_id,
                target_node_id=self.endpoint_node_ids[1],
                relationship_type=EdgeRelationshipType.RELATES_TO,
                weight=self.weight,
                requested_classification=self.requested_classification,
            ),
        )


def validate_relationship_type(value: str | EdgeRelationshipType) -> EdgeRelationshipType:
    """Return an active relationship type or raise a stable domain error."""

    try:
        relationship_type = (
            value if isinstance(value, EdgeRelationshipType) else EdgeRelationshipType(value)
        )
    except ValueError as exc:
        raise EdgeValidationError(
            EdgeValidationReason.INVALID_RELATIONSHIP_TYPE,
            "relationship type is not in the Slice 3 edge vocabulary",
        ) from exc

    if relationship_type in RESERVED_RELATIONSHIP_TYPES:
        raise EdgeValidationError(
            EdgeValidationReason.RESERVED_RELATIONSHIP_TYPE,
            f"{relationship_type.value!r} is reserved for a future runtime path",
        )
    return relationship_type


def validate_no_relationship_attributes(payload: Mapping[str, Any]) -> None:
    """Reject edge payload keys that would make Edge carry relationship attrs."""

    keys = frozenset(payload)
    relationship_keys = sorted(keys & _RELATIONSHIP_ATTRIBUTE_KEYS)
    if relationship_keys:
        raise EdgeValidationError(
            EdgeValidationReason.RELATIONSHIP_ATTRIBUTES_REQUIRE_NODE,
            "relationship attributes belong on a relationship Node plus relates-to edges",
            rejected_keys=relationship_keys,
        )

    unknown_keys = sorted(keys - _PAYLOAD_FIELDS)
    if unknown_keys:
        raise EdgeValidationError(
            EdgeValidationReason.UNKNOWN_PAYLOAD_KEYS,
            "edge create payload contains unknown keys",
            rejected_keys=unknown_keys,
        )


def validate_edge_weight(value: Decimal | float | int | str | None) -> Decimal | None:
    """Validate nullable traversal/ranking weight in the inclusive [0, 1] range."""

    if value is None:
        return None
    try:
        if isinstance(value, float):
            if not math.isfinite(value):
                raise InvalidOperation
            normalized = Decimal(str(value))
        else:
            normalized = Decimal(value)
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise EdgeValidationError(
            EdgeValidationReason.INVALID_WEIGHT,
            "edge weight must be a finite decimal in [0, 1]",
        ) from exc

    if normalized.is_nan() or normalized.is_infinite() or normalized < 0 or normalized > 1:
        raise EdgeValidationError(
            EdgeValidationReason.INVALID_WEIGHT,
            "edge weight must be a finite decimal in [0, 1]",
        )
    return normalized


def validate_no_self_edge(source_node_id: UUID, target_node_id: UUID) -> None:
    """Reject reflexive edges for the substrate-mandated vocabulary."""

    if source_node_id == target_node_id:
        raise EdgeValidationError(
            EdgeValidationReason.SELF_EDGE,
            "source_node_id and target_node_id must differ",
        )


def derive_edge_classification(
    *,
    source_classification: ClassificationLevel,
    target_classification: ClassificationLevel,
    requested_classification: ClassificationLevel | None = None,
) -> ClassificationLevel:
    """Return MAX(source, target, requested) across the C0-C4 scale."""

    candidates = [
        source_classification,
        target_classification,
        requested_classification or ClassificationLevel.C0,
    ]
    return max(candidates, key=lambda level: level.rank)


def validate_requested_classification(
    *,
    source_classification: ClassificationLevel,
    target_classification: ClassificationLevel,
    requested_classification: ClassificationLevel | None,
) -> ClassificationLevel:
    """Derive classification by conservative MAX across endpoints and request."""

    return derive_edge_classification(
        source_classification=source_classification,
        target_classification=target_classification,
        requested_classification=requested_classification,
    )


def validate_endpoint_for_active_edge(
    endpoint: EdgeEndpointSnapshot | None,
    *,
    position: EdgeEndpointPosition,
) -> EdgeEndpointSnapshot:
    """Validate an RLS-loaded endpoint projection for a new active edge."""

    if endpoint is None:
        reason = (
            EdgeValidationReason.SOURCE_NOT_FOUND
            if position == "source"
            else EdgeValidationReason.TARGET_NOT_FOUND
        )
        raise EdgeValidationError(
            reason,
            f"{position} node was not found or is not visible",
            endpoint_position=position,
        )
    if endpoint.is_archived:
        raise EdgeValidationError(
            EdgeValidationReason.ARCHIVED_ENDPOINT,
            f"{position} node is archived",
            endpoint_position=position,
        )
    if endpoint.superseded_by_node_id is not None:
        raise EdgeValidationError(
            EdgeValidationReason.SUPERSEDED_ENDPOINT,
            f"{position} node is superseded",
            endpoint_position=position,
        )
    return endpoint


def validate_endpoint_tenant(
    endpoint: EdgeEndpointSnapshot,
    *,
    context: EdgeWriteContext,
    position: EdgeEndpointPosition,
) -> None:
    """Reject visible endpoints that are outside the asserted write tenant."""

    if endpoint.tenant_id == context.tenant_id:
        return
    raise EdgeValidationError(
        EdgeValidationReason.ENDPOINT_TENANT_MISMATCH,
        f"{position} node is outside the assertion context tenant",
        endpoint_position=position,
    )


def validate_edge_create_payload(payload: Mapping[str, Any]) -> EdgeCreatePayload:
    """Validate an untrusted create-edge mapping with stable edge reason codes."""

    validate_no_relationship_attributes(payload)
    normalized = dict(payload)
    if "source_node_id" in normalized and "target_node_id" in normalized:
        source_node_id = normalized["source_node_id"]
        target_node_id = normalized["target_node_id"]
        if isinstance(source_node_id, UUID) and isinstance(target_node_id, UUID):
            validate_no_self_edge(source_node_id, target_node_id)
        elif str(source_node_id) == str(target_node_id):
            raise EdgeValidationError(
                EdgeValidationReason.SELF_EDGE,
                "source_node_id and target_node_id must differ",
            )
    if "relationship_type" in normalized:
        normalized["relationship_type"] = validate_relationship_type(
            normalized["relationship_type"]
        )
    if "weight" in normalized:
        normalized["weight"] = validate_edge_weight(normalized["weight"])
    return EdgeCreatePayload.model_validate(normalized)


def build_edge_insert(
    *,
    payload: EdgeCreatePayload,
    context: EdgeWriteContext,
    source: EdgeEndpointSnapshot,
    target: EdgeEndpointSnapshot,
) -> EdgeRowDraft:
    """Build the repository insert draft after endpoint preloads succeed."""

    classification = validate_requested_classification(
        source_classification=source.classification,
        target_classification=target.classification,
        requested_classification=payload.requested_classification,
    )
    return EdgeRowDraft(
        tenant_id=context.tenant_id,
        source_node_id=payload.source_node_id,
        target_node_id=payload.target_node_id,
        relationship_type=payload.relationship_type,
        weight=payload.weight,
        classification=classification,
        authored_by_principal_id=context.actor_principal_id,
    )


class EdgeRowDraft(BaseModel):
    """Validated values passed to a repository create operation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    source_node_id: UUID
    target_node_id: UUID
    relationship_type: EdgeRelationshipType
    weight: Decimal | None
    classification: ClassificationLevel
    authored_by_principal_id: UUID


def _constraint_name(exc: BaseException) -> str | None:
    return getattr(exc, "constraint_name", None)


def map_edge_storage_error(exc: BaseException) -> EdgeValidationError:
    """Map asyncpg integrity errors to caller-stable edge categories."""

    constraint = _constraint_name(exc)
    if isinstance(exc, asyncpg.UniqueViolationError):
        reason = (
            EdgeValidationReason.DUPLICATE_EDGE
            if constraint in _ACTIVE_EDGE_UNIQUE_CONSTRAINTS or constraint is None
            else EdgeValidationReason.EDGE_STORAGE_CONFLICT
        )
        return EdgeValidationError(reason, "active semantic edge already exists")

    if isinstance(exc, asyncpg.ForeignKeyViolationError):
        reason = (
            EdgeValidationReason.ENDPOINT_CHANGED
            if constraint in _EDGE_FK_CONSTRAINTS or constraint is None
            else EdgeValidationReason.EDGE_STORAGE_CONFLICT
        )
        return EdgeValidationError(reason, "edge endpoint changed before insert committed")

    if isinstance(exc, asyncpg.CheckViolationError):
        return EdgeValidationError(
            EdgeValidationReason.EDGE_STORAGE_CONFLICT,
            "edge storage constraint rejected the write",
        )

    return EdgeValidationError(
        EdgeValidationReason.EDGE_STORAGE_CONFLICT,
        "edge storage rejected the write",
    )


@runtime_checkable
class EdgeRepository(Protocol):
    """RLS-bound repository surface for edge create/archive/read/list operations."""

    async def load_endpoint(self, node_id: UUID) -> EdgeEndpointSnapshot | None:
        """Load a visible, RLS-filtered endpoint projection by node id."""
        ...

    async def get_edge(self, edge_id: UUID) -> EdgeRow | None:
        """Return a visible edge by id, or None when absent/hidden."""
        ...

    async def list_outgoing_edges(
        self,
        source_node_id: UUID,
        *,
        relationship_types: Sequence[EdgeRelationshipType] = (),
        include_archived: bool = False,
    ) -> Sequence[EdgeRow]:
        """List visible outgoing edges for a source node."""
        ...

    async def list_incoming_edges(
        self,
        target_node_id: UUID,
        *,
        relationship_types: Sequence[EdgeRelationshipType] = (),
        include_archived: bool = False,
    ) -> Sequence[EdgeRow]:
        """List visible incoming edges for a target node."""
        ...

    async def create_edge(self, draft: EdgeRowDraft) -> EdgeRow:
        """Insert a validated edge row through the caller's RLS-bound connection."""
        ...

    async def archive_edge(
        self,
        edge_id: UUID,
        *,
        archived_by_principal_id: UUID,
    ) -> EdgeRow | None:
        """Archive a visible edge and return the updated row."""
        ...


@runtime_checkable
class EdgeService(Protocol):
    """Service surface consumed by future graph routes and Pattern-4 validators."""

    async def create_edge(
        self,
        payload: EdgeCreatePayload,
        *,
        context: EdgeWriteContext,
    ) -> EdgeRow:
        """Create a validated edge after endpoint visibility preloads."""
        ...

    async def archive_edge(
        self,
        payload: EdgeArchivePayload,
        *,
        context: EdgeWriteContext,
    ) -> EdgeRow:
        """Archive, not hard-delete, a visible edge."""
        ...


class RepositoryEdgeService:
    """Small service implementation around an RLS-bound EdgeRepository."""

    def __init__(self, repository: EdgeRepository) -> None:
        self._repository = repository

    async def create_edge(
        self,
        payload: EdgeCreatePayload,
        *,
        context: EdgeWriteContext,
    ) -> EdgeRow:
        source = validate_endpoint_for_active_edge(
            await self._repository.load_endpoint(payload.source_node_id),
            position="source",
        )
        target = validate_endpoint_for_active_edge(
            await self._repository.load_endpoint(payload.target_node_id),
            position="target",
        )
        validate_endpoint_tenant(source, context=context, position="source")
        validate_endpoint_tenant(target, context=context, position="target")
        draft = build_edge_insert(
            payload=payload,
            context=context,
            source=source,
            target=target,
        )
        try:
            return await self._repository.create_edge(draft)
        except asyncpg.PostgresError as exc:
            raise map_edge_storage_error(exc) from exc

    async def archive_edge(
        self,
        payload: EdgeArchivePayload,
        *,
        context: EdgeWriteContext,
    ) -> EdgeRow:
        try:
            row = await self._repository.archive_edge(
                payload.edge_id,
                archived_by_principal_id=context.actor_principal_id,
            )
        except asyncpg.PostgresError as exc:
            raise map_edge_storage_error(exc) from exc
        if row is None:
            raise EdgeValidationError(
                EdgeValidationReason.EDGE_NOT_FOUND,
                "edge was not found or is not visible",
            )
        return row
