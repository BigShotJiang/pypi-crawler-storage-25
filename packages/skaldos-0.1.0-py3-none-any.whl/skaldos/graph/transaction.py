"""Graph write transaction helpers for Slice 4.

The existing ``current_principal`` dependency owns pool acquisition,
explicit transaction lifetime, and PC1 ``set_config(..., true)`` calls. This
module adds a graph-write callback guard that verifies the provided connection
is already inside that Principal-bound transaction before assertion services
run on it.

References: ``assert-endpoint-contract`` T4; ``ARCHITECTURE.md`` §2.1, PC1,
M9, AP5.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import cast

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.middleware import Principal
from skaldos.middleware.hydration import (
    GUC_PRINCIPAL_CONTEXT,
    GUC_PRINCIPAL_ID,
    GUC_PRINCIPAL_VISIBLE,
)
from skaldos.middleware.resolver import format_uuid_array


class GraphPrincipalTransactionError(RuntimeError):
    """Raised when a graph write is attempted outside the Principal transaction."""

    def __init__(self, message: str = "graph_write_requires_principal_transaction") -> None:
        super().__init__(message)


async def with_principal[T](
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    fn: Callable[[asyncpg.Connection], Awaitable[T]],
) -> T:
    """Run ``fn`` only on a connection bound to ``principal`` by PC1 GUCs."""

    if not connection.is_in_transaction():  # pyright: ignore[reportUnknownMemberType]
        raise GraphPrincipalTransactionError()

    principal_id = cast(
        str | None,
        await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
            "SELECT current_setting($1, true)",
            GUC_PRINCIPAL_ID,
        ),
    )
    if principal_id != str(principal.id):
        raise GraphPrincipalTransactionError()

    principal_visible = cast(
        str | None,
        await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
            "SELECT current_setting($1, true)",
            GUC_PRINCIPAL_VISIBLE,
        ),
    )
    if principal_visible != format_uuid_array(principal.visible_tenant_ids):
        raise GraphPrincipalTransactionError("graph_write_requires_principal_visible")

    principal_context = cast(
        str | None,
        await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
            "SELECT current_setting($1, true)",
            GUC_PRINCIPAL_CONTEXT,
        ),
    )
    if not isinstance(principal_context, str) or principal_context == "":
        raise GraphPrincipalTransactionError("graph_write_requires_principal_context")

    return await fn(connection)
