"""C2+ read-audit helper for Slice 6 read services.

The helper records content-free read evidence in the existing
``audit_entries`` table before a service returns C2/C3/C4 payloads. C0/C1
result sets do not require a read-audit row. Audit write failures raise a
stable exception so callers fail closed instead of returning classified
content without evidence.

References: Slice 6 read path master plan "C2+ Read Audit Contract";
classification-clearance-and-read-chokepoint T6; §13.2, §15.5, AP5.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping, Sequence
from enum import StrEnum
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict

from skaldos.graph.edges import ClassificationLevel
from skaldos.policy.intent import Intent


class ReadAuditAction(StrEnum):
    """Stable Slice 6 read-audit action vocabulary."""

    READ = "read"
    SEARCH = "search"
    TRAVERSE = "traverse"
    ASSEMBLE_CONTEXT = "assemble_context"
    QUERY_METRIC = "query_metric"


class ReadAuditSubjectType(StrEnum):
    """Subject shapes supported by the shared read-audit helper."""

    NODE = "Node"
    EDGE = "Edge"
    NODE_TAG = "NodeTag"
    NODE_CHUNK = "NodeChunk"
    DOCUMENT = "Document"
    READ_RESULT_SET = "ReadResultSet"


class ReadAuditEntry(BaseModel):
    """Projection returned after writing a read-audit entry."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    row_hash: bytes


class ReadAuditWriteError(RuntimeError):
    """Raised when C2+ read-audit evidence cannot be durably written."""


_AUDIT_THRESHOLD = ClassificationLevel.C2.rank
_MAX_SUBJECT_HANDLES = 20
_ALLOWED_METADATA_KEYS = frozenset(
    {
        "audit_correlation_id",
        "lens_id",
        "query_digest",
        "route",
        "service",
        "shield_call_id",
        "subject_handles",
        "trace_id",
        "visible_result_count_bucket",
        "visible_subject_handles",
    }
)
_SUBJECT_HANDLE_KEYS = frozenset({"subject_handles", "visible_subject_handles"})
_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
_SAFE_SERVICE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_.:-]{0,127}$")
_SAFE_ROUTE_RE = re.compile(r"^(?:[A-Z]+ )?/[A-Za-z0-9_./:{}-]{1,160}$")
_COUNT_BUCKET_RE = re.compile(r"^(?:0|1|[1-9][0-9]*-[1-9][0-9]*|[1-9][0-9]*\+)$")
_SHA256_DIGEST_RE = re.compile(r"^sha256:[0-9A-Fa-f]{6,128}$")


def requires_c2_read_audit(classifications: Iterable[ClassificationLevel | str]) -> bool:
    """Return true when any visible result classification is C2 or higher."""

    return any(_classification_level(value).rank >= _AUDIT_THRESHOLD for value in classifications)


def max_read_classification(
    classifications: Iterable[ClassificationLevel | str],
) -> ClassificationLevel | None:
    """Return the highest classification in a visible result set."""

    levels = tuple(_classification_level(value) for value in classifications)
    if not levels:
        return None
    return max(levels, key=lambda level: level.rank)


async def emit_c2_read_audit_entry(
    *,
    connection: asyncpg.Connection,
    tenant_id: UUID,
    actor_principal_id: UUID,
    subject_type: ReadAuditSubjectType | str,
    subject_id: UUID | None,
    action: ReadAuditAction | str,
    result_classifications: Iterable[ClassificationLevel | str],
    context_of_validity: Mapping[str, Any],
    metadata: Mapping[str, Any] | None = None,
    intent: Intent = Intent.directive,
) -> ReadAuditEntry | None:
    """Write one content-free audit row when visible results include C2+ data.

    Aggregate reads pass ``ReadResultSet`` and a request/result-set handle as
    ``subject_id``. Direct opens pass the concrete subject type and id.
    """

    max_classification = max_read_classification(result_classifications)
    if max_classification is None or max_classification.rank < _AUDIT_THRESHOLD:
        return None

    policy_metadata = _read_audit_metadata(
        action=str(action),
        subject_type=str(subject_type),
        max_classification=max_classification,
        metadata=metadata,
    )
    try:
        row = cast(
            Mapping[str, Any] | None,
            await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
        INSERT INTO audit_entries (
            tenant_id,
            actor_principal_id,
            subject_type,
            subject_id,
            action,
            intent,
            context_of_validity,
            outcome,
            policy_decision_metadata
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, 'permitted', $8::jsonb)
        RETURNING id, row_hash
        """,
                tenant_id,
                actor_principal_id,
                str(subject_type),
                subject_id,
                str(action),
                intent.value,
                json.dumps(dict(context_of_validity), sort_keys=True),
                json.dumps(policy_metadata, sort_keys=True),
            ),
        )
    except Exception as exc:
        raise ReadAuditWriteError("read_audit_write_failed") from exc
    if row is None:
        raise ReadAuditWriteError("read_audit_write_failed")
    return ReadAuditEntry(
        id=row["id"],  # pyright: ignore[reportUnknownArgumentType]
        row_hash=bytes(row["row_hash"]),  # pyright: ignore[reportUnknownArgumentType]
    )


def _read_audit_metadata(
    *,
    action: str,
    subject_type: str,
    max_classification: ClassificationLevel,
    metadata: Mapping[str, Any] | None,
) -> dict[str, Any]:
    safe_metadata = dict(metadata or {})
    _validate_content_free_metadata(safe_metadata)
    safe_metadata["audit_kind"] = "c2_read"
    safe_metadata["action"] = action
    safe_metadata["subject_type"] = subject_type
    safe_metadata["max_classification"] = max_classification.value
    return safe_metadata


def _validate_content_free_metadata(value: object, *, path: tuple[str, ...] = ()) -> None:
    if path:
        raise ValueError("read audit metadata must be a top-level object")
    if not isinstance(value, Mapping):
        raise ValueError("read audit metadata must be a top-level object")

    mapping = cast(Mapping[object, object], value)
    for raw_key, nested in mapping.items():
        key = str(raw_key)
        if key not in _ALLOWED_METADATA_KEYS:
            raise ValueError(f"read audit metadata contains unsupported key: {key}")
        _validate_allowed_metadata_value(key, nested)


def _validate_allowed_metadata_value(key: str, value: object) -> None:
    if key in _SUBJECT_HANDLE_KEYS:
        _validate_subject_handles(value, path=(key,))
        return
    if key in {"audit_correlation_id", "lens_id", "shield_call_id"}:
        _validate_uuid_value(key, value)
        return
    if key == "query_digest":
        _validate_string_pattern(key, value, pattern=_SHA256_DIGEST_RE)
        return
    if key == "route":
        _validate_string_pattern(key, value, pattern=_SAFE_ROUTE_RE)
        return
    if key == "service":
        _validate_string_pattern(key, value, pattern=_SAFE_SERVICE_RE)
        return
    if key == "trace_id":
        _validate_string_pattern(key, value, pattern=_SAFE_TOKEN_RE)
        return
    if key == "visible_result_count_bucket":
        _validate_string_pattern(key, value, pattern=_COUNT_BUCKET_RE)
        return
    raise AssertionError(f"unhandled read audit metadata key: {key}")


def _validate_subject_handles(value: object, *, path: tuple[str, ...]) -> None:
    if not isinstance(value, list | tuple):
        raise ValueError(f"{'.'.join(path)} must be a bounded list of UUID handles")
    handles = cast(Sequence[object], value)
    if len(handles) > _MAX_SUBJECT_HANDLES:
        raise ValueError(f"{'.'.join(path)} exceeds bounded subject handle limit")
    for handle in handles:
        try:
            UUID(str(handle))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{'.'.join(path)} must contain UUID handles only") from exc


def _validate_uuid_value(key: str, value: object) -> None:
    try:
        UUID(str(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{key} must be a UUID handle") from exc


def _validate_string_pattern(key: str, value: object, *, pattern: re.Pattern[str]) -> None:
    if not isinstance(value, str) or pattern.fullmatch(value) is None:
        raise ValueError(f"{key} must be content-free metadata")


def _classification_level(value: ClassificationLevel | str) -> ClassificationLevel:
    if isinstance(value, ClassificationLevel):
        return value
    return ClassificationLevel(str(value))
