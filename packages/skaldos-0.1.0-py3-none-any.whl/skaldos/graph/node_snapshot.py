"""Protected single-node source snapshot read service."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field

from skaldos.agents.read_summarize import ReadAndSummarizeSourceSnapshot
from skaldos.graph.edges import ClassificationLevel
from skaldos.graph.read_audit import (
    ReadAuditAction,
    ReadAuditSubjectType,
    emit_c2_read_audit_entry,
)
from skaldos.middleware import Principal


class NodeSourceSnapshotRequest(BaseModel):
    """Request for one visible source node snapshot."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    node_id: UUID
    trace_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{32}$")


class NodeSourceSnapshotNotFoundError(LookupError):
    """Node is missing, hidden, archived, cross-tenant, or over-clearance."""


class NodeSourceSnapshotQueryError(RuntimeError):
    """Unexpected storage error while reading a node snapshot."""


NODE_SOURCE_SNAPSHOT_SQL = """
SELECT
  n.id,
  n.tenant_id,
  n.body_nfc,
  encode(n.body_nfc_hash, 'hex') AS body_nfc_hash,
  ot.name AS ontology_type,
  n.version,
  n.classification,
  n.context_of_validity
FROM nodes n
JOIN ontology_type ot
  ON ot.id = n.type_id
 AND ot.ontology_version_id = n.ontology_version_id
WHERE n.id = $1
  AND n.tenant_id = $2
  AND n.archived_at IS NULL
  AND n.superseded_by_node_id IS NULL
  AND app.principal_context_contains(n.context_of_validity)
"""


class NodeSourceSnapshotService:
    """Read one source node through the API/read chokepoint transaction."""

    async def read_snapshot(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: NodeSourceSnapshotRequest,
    ) -> ReadAndSummarizeSourceSnapshot:
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    NODE_SOURCE_SNAPSHOT_SQL,
                    request.node_id,
                    request.tenant_id,
                ),
            )
        except Exception as exc:
            raise NodeSourceSnapshotQueryError("node_source_snapshot_query_failed") from exc
        if row is None:
            raise NodeSourceSnapshotNotFoundError("not_found")

        try:
            snapshot = ReadAndSummarizeSourceSnapshot(
                node_id=cast(UUID, row["id"]),
                tenant_id=cast(UUID, row["tenant_id"]),
                body_text=str(row["body_nfc"]),
                ontology_type=str(row["ontology_type"]),
                source_version=int(row["version"]),
                source_hash=str(row["body_nfc_hash"]),
                classification=cast(Any, str(row["classification"])),
                context_of_validity=_json_mapping(row["context_of_validity"]),
            )
        except Exception as exc:
            raise NodeSourceSnapshotQueryError("node_source_snapshot_query_failed") from exc
        await emit_c2_read_audit_entry(
            connection=connection,
            tenant_id=request.tenant_id,
            actor_principal_id=principal.id,
            subject_type=ReadAuditSubjectType.NODE,
            subject_id=request.node_id,
            action=ReadAuditAction.READ,
            result_classifications=(ClassificationLevel(snapshot.classification),),
            context_of_validity=snapshot.context_of_validity,
            metadata={
                "service": "NodeSourceSnapshotService",
                "route": "POST /graph/source-snapshot",
                **({"trace_id": request.trace_id} if request.trace_id is not None else {}),
            },
        )
        return snapshot


def _json_mapping(value: object) -> dict[str, Any]:
    if isinstance(value, str):
        parsed: Any = json.loads(value)
        if not isinstance(parsed, Mapping):
            raise NodeSourceSnapshotQueryError("node_source_snapshot_query_failed")
        return dict(cast(Mapping[str, Any], parsed))
    if not isinstance(value, Mapping):
        raise NodeSourceSnapshotQueryError("node_source_snapshot_query_failed")
    return dict(cast(Mapping[str, Any], value))


__all__ = [
    "NodeSourceSnapshotNotFoundError",
    "NodeSourceSnapshotQueryError",
    "NodeSourceSnapshotRequest",
    "NodeSourceSnapshotService",
]
