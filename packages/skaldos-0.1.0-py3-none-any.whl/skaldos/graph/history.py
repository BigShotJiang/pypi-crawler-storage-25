"""Historical graph belief queries for Slice 9."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from skaldos.graph.edges import ClassificationLevel, EdgeRelationshipType
from skaldos.middleware import Principal

DEFAULT_BELIEF_HISTORY_DEPTH = 3
MAX_BELIEF_HISTORY_DEPTH = 5
DEFAULT_BELIEF_HISTORY_LIMIT = 100
MAX_BELIEF_HISTORY_LIMIT = 500

_BELIEF_RELATIONSHIP_TYPES = (
    EdgeRelationshipType.GROUNDED_BY,
    EdgeRelationshipType.WARRANTED_BY,
    EdgeRelationshipType.FALSIFIED_BY,
    EdgeRelationshipType.INFORMED_BY,
    EdgeRelationshipType.DERIVED_FROM,
    EdgeRelationshipType.REVISES,
    EdgeRelationshipType.REVIEW_REQUIRED_BY,
)


class GraphHistoryTruncationReason(StrEnum):
    """Safe truncation reason codes for historical graph reads."""

    RESULT_LIMIT = "result_limit"


class GraphHistoryRequest(BaseModel):
    """Request for one belief-at-time query."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tenant_id: UUID
    subject_node_id: UUID
    as_of: datetime | None = None
    max_depth: int = Field(default=DEFAULT_BELIEF_HISTORY_DEPTH, ge=0, le=MAX_BELIEF_HISTORY_DEPTH)
    limit: int = Field(default=DEFAULT_BELIEF_HISTORY_LIMIT, ge=1, le=MAX_BELIEF_HISTORY_LIMIT)

    @field_validator("as_of")
    @classmethod
    def _as_of_is_utc(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("timestamp_requires_timezone")
        return value.astimezone(UTC).replace(tzinfo=UTC)


class GraphHistoryResult(BaseModel):
    """Handle-only belief-at-time response shape."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    subject_node_id: UUID
    tenant_id: UUID
    as_of: datetime
    visible_nodes: tuple[UUID, ...]
    visible_edges: tuple[UUID, ...]
    visible_tags: tuple[UUID, ...]
    source_trace_ids: tuple[UUID, ...] = ()
    surprise_ids: tuple[UUID, ...] = ()
    conversation_ids: tuple[UUID, ...] = ()
    truncated: bool = False
    truncation_reason: GraphHistoryTruncationReason | None = None
    max_visible_classification: ClassificationLevel | None = None

    @model_validator(mode="after")
    def _truncation_reason_matches_flag(self) -> GraphHistoryResult:
        if self.truncated and self.truncation_reason is None:
            raise ValueError("truncation_reason_required")
        if not self.truncated and self.truncation_reason is not None:
            raise ValueError("truncation_reason_without_truncation")
        return self


class GraphHistorySubjectNotFoundError(LookupError):
    """Subject is missing, hidden, or not active at the requested time."""


class GraphHistoryTemporalIntegrityError(RuntimeError):
    """Historical selector found corrupt temporal state and failed closed."""

    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code
        super().__init__(reason_code)


class GraphHistoryQueryError(RuntimeError):
    """Unexpected storage failure while reading historical graph state."""


DEFAULT_AS_OF_SQL = """
SELECT n.created_at
FROM nodes n
WHERE n.id = $1
  AND n.tenant_id = $2
  AND n.archived_at IS NULL
  AND app.principal_context_contains(n.context_of_validity)
"""


BELIEF_AT_TIME_SQL = """
WITH RECURSIVE node_supersession_chain AS (
  SELECT
    n.id AS root_node_id,
    n.id AS node_id,
    0 AS depth,
    ARRAY[n.id]::uuid[] AS path,
    false AS cycle_detected
  FROM nodes n
  WHERE n.tenant_id = $2

  UNION ALL

  SELECT
    chain.root_node_id,
    successor.id AS node_id,
    chain.depth + 1 AS depth,
    chain.path || successor.id AS path,
    successor.id = ANY(chain.path) AS cycle_detected
  FROM node_supersession_chain chain
  JOIN nodes current_node
    ON current_node.id = chain.node_id
   AND current_node.tenant_id = $2
  JOIN nodes successor
    ON successor.id = current_node.superseded_by_node_id
   AND successor.tenant_id = current_node.tenant_id
  WHERE chain.depth < 32
    AND NOT chain.cycle_detected
),
active_nodes_at_time AS (
  SELECT
    chain.root_node_id,
    n.id,
    n.tenant_id,
    n.classification,
    n.type_id,
    n.ontology_version_id,
    n.metadata,
    n.created_at,
    count(*) OVER (PARTITION BY chain.root_node_id) AS active_family_count
  FROM node_supersession_chain chain
  JOIN nodes n
    ON n.id = chain.node_id
   AND n.tenant_id = $2
  LEFT JOIN nodes successor
    ON successor.id = n.superseded_by_node_id
   AND successor.tenant_id = n.tenant_id
  WHERE n.created_at <= $3
    AND (n.superseded_by_node_id IS NULL OR successor.created_at > $3)
    AND (n.archived_at IS NULL OR n.archived_at > $3)
    AND (n.context_of_validity ->> 'valid_from')::timestamptz <= $3
    AND (
      (n.context_of_validity ->> 'valid_to') IS NULL
      OR (n.context_of_validity ->> 'valid_to') = ''
      OR (n.context_of_validity ->> 'valid_to')::timestamptz > $3
    )
    AND app.principal_context_contains(n.context_of_validity)
),
tag_supersession_chain AS (
  SELECT
    nt.id AS root_tag_id,
    nt.id AS tag_id,
    0 AS depth,
    ARRAY[nt.id]::uuid[] AS path,
    false AS cycle_detected
  FROM node_tags nt
  WHERE nt.tenant_id = $2

  UNION ALL

  SELECT
    chain.root_tag_id,
    successor.id AS tag_id,
    chain.depth + 1 AS depth,
    chain.path || successor.id AS path,
    successor.id = ANY(chain.path) AS cycle_detected
  FROM tag_supersession_chain chain
  JOIN node_tags current_tag
    ON current_tag.id = chain.tag_id
   AND current_tag.tenant_id = $2
  JOIN node_tags successor
    ON successor.id = current_tag.superseded_by_tag_id
   AND successor.tenant_id = current_tag.tenant_id
  WHERE chain.depth < 32
    AND NOT chain.cycle_detected
),
active_tags_at_time AS (
  SELECT
    chain.root_tag_id,
    nt.id,
    nt.node_id,
    nt.tenant_id,
    nt.classification,
    count(*) OVER (PARTITION BY chain.root_tag_id) AS active_family_count
  FROM tag_supersession_chain chain
  JOIN node_tags nt
    ON nt.id = chain.tag_id
   AND nt.tenant_id = $2
  LEFT JOIN node_tags successor
    ON successor.id = nt.superseded_by_tag_id
   AND successor.tenant_id = nt.tenant_id
  WHERE nt.created_at <= $3
    AND (nt.superseded_by_tag_id IS NULL OR successor.created_at > $3)
    AND (nt.context_of_validity ->> 'valid_from')::timestamptz <= $3
    AND (
      (nt.context_of_validity ->> 'valid_to') IS NULL
      OR (nt.context_of_validity ->> 'valid_to') = ''
      OR (nt.context_of_validity ->> 'valid_to')::timestamptz > $3
    )
    AND app.principal_context_contains(nt.context_of_validity)
),
temporal_integrity AS (
  SELECT CASE
    WHEN EXISTS (
      SELECT 1 FROM node_supersession_chain WHERE cycle_detected
    ) THEN 'node_supersession_cycle_detected'
    WHEN EXISTS (
      SELECT 1 FROM tag_supersession_chain WHERE cycle_detected
    ) THEN 'tag_supersession_cycle_detected'
    WHEN EXISTS (
      SELECT 1 FROM active_nodes_at_time WHERE active_family_count > 1
    ) THEN 'node_temporal_validity_overlap'
    WHEN EXISTS (
      SELECT 1 FROM active_tags_at_time WHERE active_family_count > 1
    ) THEN 'tag_temporal_validity_overlap'
    ELSE NULL
  END AS reason_code
),
active_edges_at_time AS (
  SELECT
    e.id,
    e.tenant_id,
    e.source_node_id,
    e.target_node_id,
    e.relationship_type,
    e.classification
  FROM edges e
  WHERE e.tenant_id = $2
    AND e.relationship_type = ANY($4::text[])
    AND e.created_at <= $3
    AND (e.archived_at IS NULL OR e.archived_at > $3)
    AND app.classification_rank(
          COALESCE(
            app.principal_context() #>> ARRAY['clearances', e.tenant_id::text],
            app.principal_context() ->> 'classification'
          )
        ) >= app.classification_rank(e.classification)
),
visible_walk AS (
  SELECT
    n.id AS node_id,
    n.tenant_id AS node_tenant_id,
    n.classification AS node_classification,
    ot.name AS node_type_name,
    n.metadata AS node_metadata,
    n.created_at AS node_created_at,
    0 AS depth,
    ARRAY[n.id]::uuid[] AS path,
    NULL::uuid AS edge_id,
    NULL::uuid AS edge_source_node_id,
    NULL::uuid AS edge_target_node_id,
    NULL::text AS edge_classification
  FROM active_nodes_at_time n
  JOIN ontology_type ot
    ON ot.id = n.type_id
   AND ot.ontology_version_id = n.ontology_version_id
  WHERE n.root_node_id = $1

  UNION ALL

  SELECT
    target.id AS node_id,
    target.tenant_id AS node_tenant_id,
    target.classification AS node_classification,
    target_type.name AS node_type_name,
    target.metadata AS node_metadata,
    target.created_at AS node_created_at,
    visible_walk.depth + 1 AS depth,
    visible_walk.path || target.id AS path,
    e.id AS edge_id,
    e.source_node_id AS edge_source_node_id,
    e.target_node_id AS edge_target_node_id,
    e.classification AS edge_classification
  FROM visible_walk
  JOIN active_edges_at_time e
    ON e.source_node_id = visible_walk.node_id
    OR e.target_node_id = visible_walk.node_id
  JOIN active_nodes_at_time target
    ON target.root_node_id = CASE
         WHEN e.source_node_id = visible_walk.node_id THEN e.target_node_id
         ELSE e.source_node_id
       END
   AND target.tenant_id = e.tenant_id
  JOIN ontology_type target_type
    ON target_type.id = target.type_id
   AND target_type.ontology_version_id = target.ontology_version_id
  WHERE visible_walk.depth < $5
    AND NOT target.id = ANY(visible_walk.path)
),
deduped_nodes AS (
  SELECT DISTINCT ON (node_id)
    node_id,
    node_tenant_id,
    node_classification,
    node_type_name,
    node_metadata,
    depth,
    node_created_at
  FROM visible_walk
  ORDER BY node_id, depth ASC, node_created_at ASC
),
deduped_edges AS (
  SELECT DISTINCT edge_id, edge_source_node_id, edge_target_node_id, edge_classification
  FROM visible_walk
  WHERE edge_id IS NOT NULL
),
limited_nodes AS (
  SELECT *
  FROM deduped_nodes
  ORDER BY depth ASC, node_created_at ASC, node_id ASC
  LIMIT $6
),
limited_node_ids AS (
  SELECT node_id FROM limited_nodes
),
visible_edges AS (
  SELECT DISTINCT e.edge_id, e.edge_classification
  FROM deduped_edges e
  JOIN limited_node_ids source_node ON source_node.node_id = e.edge_source_node_id
  JOIN limited_node_ids target_node ON target_node.node_id = e.edge_target_node_id
),
visible_tags AS (
  SELECT DISTINCT nt.id, nt.classification
  FROM active_tags_at_time nt
  JOIN limited_node_ids ln ON ln.node_id = nt.node_id
),
source_trace_handles AS (
  SELECT DISTINCT COALESCE(
    CASE
      WHEN limited_nodes.node_metadata #>> '{execution_trace,execution_trace_id}'
           ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      THEN (limited_nodes.node_metadata #>> '{execution_trace,execution_trace_id}')::uuid
      ELSE NULL::uuid
    END,
    limited_nodes.node_id
  ) AS id
  FROM limited_nodes
  WHERE limited_nodes.node_type_name = 'execution-trace'
),
surprise_handles AS (
  SELECT DISTINCT COALESCE(
    CASE
      WHEN limited_nodes.node_metadata ->> 'raw_surprise_id'
           ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      THEN (limited_nodes.node_metadata ->> 'raw_surprise_id')::uuid
      ELSE NULL::uuid
    END,
    limited_nodes.node_id
  ) AS id
  FROM limited_nodes
  WHERE limited_nodes.node_type_name = 'surprise'
),
conversation_handles AS (
  SELECT DISTINCT limited_nodes.node_id AS id
  FROM limited_nodes
  WHERE limited_nodes.node_type_name = 'conversation'
)
SELECT
  (SELECT reason_code FROM temporal_integrity) AS temporal_reason_code,
  COALESCE(
    jsonb_agg(DISTINCT limited_nodes.node_id)
      FILTER (WHERE limited_nodes.node_id IS NOT NULL),
    '[]'::jsonb
  ) AS visible_nodes,
  COALESCE(
    jsonb_agg(DISTINCT visible_edges.edge_id)
      FILTER (WHERE visible_edges.edge_id IS NOT NULL),
    '[]'::jsonb
  ) AS visible_edges,
  COALESCE(
    jsonb_agg(DISTINCT visible_tags.id)
      FILTER (WHERE visible_tags.id IS NOT NULL),
    '[]'::jsonb
  ) AS visible_tags,
  COALESCE(
    (SELECT jsonb_agg(source_trace_handles.id ORDER BY source_trace_handles.id)
     FROM source_trace_handles),
    '[]'::jsonb
  ) AS source_trace_ids,
  COALESCE(
    (SELECT jsonb_agg(surprise_handles.id ORDER BY surprise_handles.id)
     FROM surprise_handles),
    '[]'::jsonb
  ) AS surprise_ids,
  COALESCE(
    (SELECT jsonb_agg(conversation_handles.id ORDER BY conversation_handles.id)
     FROM conversation_handles),
    '[]'::jsonb
  ) AS conversation_ids,
  (
    SELECT COUNT(*) > $6
    FROM deduped_nodes
  ) AS truncated,
  (
    SELECT max(app.classification_rank(classification))
    FROM (
      SELECT node_classification AS classification FROM limited_nodes
      UNION ALL
      SELECT edge_classification AS classification FROM visible_edges
      UNION ALL
      SELECT classification FROM visible_tags
    ) classifications
  ) AS max_classification_rank
FROM limited_nodes
FULL JOIN visible_edges ON true
FULL JOIN visible_tags ON true;
"""


class GraphHistoryService:
    """Historical graph read service for belief-at-time answers."""

    async def belief_at_time(
        self,
        *,
        connection: asyncpg.Connection,
        principal: Principal,
        request: GraphHistoryRequest,
    ) -> GraphHistoryResult:
        as_of = request.as_of or await self._default_as_of(
            connection=connection,
            request=request,
        )
        relationship_types = [edge.value for edge in _BELIEF_RELATIONSHIP_TYPES]
        try:
            row = cast(
                Mapping[str, Any] | None,
                await connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    BELIEF_AT_TIME_SQL,
                    request.subject_node_id,
                    request.tenant_id,
                    as_of,
                    relationship_types,
                    request.max_depth,
                    request.limit,
                ),
            )
        except Exception as exc:
            raise GraphHistoryQueryError("belief_at_time_query_failed") from exc
        if row is None:
            raise GraphHistorySubjectNotFoundError("subject_not_active_at_time")
        temporal_reason_code = row.get("temporal_reason_code")
        if temporal_reason_code is not None:
            raise GraphHistoryTemporalIntegrityError(str(temporal_reason_code))
        visible_nodes = _uuid_tuple(row["visible_nodes"])
        if not visible_nodes:
            raise GraphHistorySubjectNotFoundError("subject_not_active_at_time")
        truncated = bool(row["truncated"])
        return GraphHistoryResult(
            subject_node_id=request.subject_node_id,
            tenant_id=request.tenant_id,
            as_of=as_of,
            visible_nodes=visible_nodes,
            visible_edges=_uuid_tuple(row["visible_edges"]),
            visible_tags=_uuid_tuple(row["visible_tags"]),
            source_trace_ids=_uuid_tuple(row["source_trace_ids"]),
            surprise_ids=_uuid_tuple(row["surprise_ids"]),
            conversation_ids=_uuid_tuple(row["conversation_ids"]),
            truncated=truncated,
            truncation_reason=(GraphHistoryTruncationReason.RESULT_LIMIT if truncated else None),
            max_visible_classification=_classification_from_rank(row["max_classification_rank"]),
        )

    async def _default_as_of(
        self,
        *,
        connection: asyncpg.Connection,
        request: GraphHistoryRequest,
    ) -> datetime:
        try:
            value = cast(
                datetime | None,
                await connection.fetchval(  # pyright: ignore[reportUnknownMemberType]
                    DEFAULT_AS_OF_SQL,
                    request.subject_node_id,
                    request.tenant_id,
                ),
            )
        except Exception as exc:
            raise GraphHistoryQueryError("belief_at_time_default_as_of_failed") from exc
        if value is None:
            raise GraphHistorySubjectNotFoundError("subject_not_visible")
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC).replace(tzinfo=UTC)


def _uuid_tuple(value: object) -> tuple[UUID, ...]:
    parsed = json.loads(value) if isinstance(value, str) else value
    if parsed is None:
        return ()
    if not isinstance(parsed, Sequence) or isinstance(parsed, bytes | bytearray | str):
        raise GraphHistoryQueryError("belief_at_time_query_failed")
    sequence = cast(Sequence[object], parsed)
    return tuple(UUID(str(item)) for item in sequence)


def _classification_from_rank(value: object) -> ClassificationLevel | None:
    if value is None:
        return None
    if not isinstance(value, int | str):
        raise GraphHistoryQueryError("belief_at_time_query_failed")
    ranks = {
        0: ClassificationLevel.C0,
        1: ClassificationLevel.C1,
        2: ClassificationLevel.C2,
        3: ClassificationLevel.C3,
        4: ClassificationLevel.C4,
    }
    return ranks.get(int(value))


__all__ = [
    "BELIEF_AT_TIME_SQL",
    "DEFAULT_AS_OF_SQL",
    "DEFAULT_BELIEF_HISTORY_DEPTH",
    "DEFAULT_BELIEF_HISTORY_LIMIT",
    "GraphHistoryQueryError",
    "GraphHistoryRequest",
    "GraphHistoryResult",
    "GraphHistoryService",
    "GraphHistorySubjectNotFoundError",
    "GraphHistoryTemporalIntegrityError",
    "GraphHistoryTruncationReason",
    "MAX_BELIEF_HISTORY_DEPTH",
    "MAX_BELIEF_HISTORY_LIMIT",
]
