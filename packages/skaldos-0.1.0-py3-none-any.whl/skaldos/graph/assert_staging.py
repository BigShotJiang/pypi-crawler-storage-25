"""Pure staging helpers for Slice 4 graph assertions.

This module owns deterministic canonicalization, idempotency replay
classification, and lifecycle transition validation for ``pending_assertions``.
It intentionally does not define the public endpoint envelope, open database
transactions, or mutate canonical Node/Edge/Tag rows.

References: Slice 4 ``staging-and-resolution-pipeline`` T2; §10.5, §10.6,
§10.7, §10.12, AP5, AP11, PC10.
"""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from enum import StrEnum
from hashlib import sha256
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, field_validator

from skaldos.graph.assert_contract import FactFamilyInput, fact_family_key
from skaldos.graph.transaction import with_principal
from skaldos.middleware import Principal
from skaldos.policy.intent import Intent

ASSERTION_DIGEST_VERSION = 1
"""Current deterministic digest version for Slice 4 staged assertions."""


class PendingAssertionStatus(StrEnum):
    """Internal lifecycle statuses stored in ``pending_assertions``."""

    STAGED = "staged"
    CLASSIFIED = "classified"
    RESOLVED = "resolved"
    APPLIED = "applied"
    REJECTED = "rejected"
    DISAGREEMENT = "disagreement"


TERMINAL_PENDING_ASSERTION_STATUSES: frozenset[PendingAssertionStatus] = frozenset(
    {
        PendingAssertionStatus.APPLIED,
        PendingAssertionStatus.REJECTED,
        PendingAssertionStatus.DISAGREEMENT,
    }
)

ALLOWED_PENDING_ASSERTION_TRANSITIONS: Mapping[
    PendingAssertionStatus,
    frozenset[PendingAssertionStatus],
] = {
    PendingAssertionStatus.STAGED: frozenset(
        {
            PendingAssertionStatus.STAGED,
            PendingAssertionStatus.CLASSIFIED,
            PendingAssertionStatus.REJECTED,
        }
    ),
    PendingAssertionStatus.CLASSIFIED: frozenset(
        {
            PendingAssertionStatus.CLASSIFIED,
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.REJECTED,
        }
    ),
    PendingAssertionStatus.RESOLVED: frozenset(
        {
            PendingAssertionStatus.RESOLVED,
            PendingAssertionStatus.APPLIED,
            PendingAssertionStatus.REJECTED,
            PendingAssertionStatus.DISAGREEMENT,
        }
    ),
    PendingAssertionStatus.APPLIED: frozenset({PendingAssertionStatus.APPLIED}),
    PendingAssertionStatus.REJECTED: frozenset({PendingAssertionStatus.REJECTED}),
    PendingAssertionStatus.DISAGREEMENT: frozenset({PendingAssertionStatus.DISAGREEMENT}),
}
"""Allowed semantic transitions plus same-status retry bookkeeping updates."""


class AssertionCanonicalizationError(ValueError):
    """Raised when assertion data cannot be encoded as canonical JSON."""


class AssertionLifecycleError(ValueError):
    """Raised when a staged assertion transition violates lifecycle rules."""

    def __init__(
        self,
        current: PendingAssertionStatus,
        requested: PendingAssertionStatus,
    ) -> None:
        self.current = current
        self.requested = requested
        super().__init__(f"invalid_pending_assertion_transition:{current.value}->{requested.value}")


class IdempotencyDecision(StrEnum):
    """Service classification for a client idempotency key lookup."""

    INSERT = "insert"
    REPLAY = "replay"
    PAYLOAD_MISMATCH = "idempotency_payload_mismatch"


class AssertionStagingReason(StrEnum):
    """Low-cardinality staging reason codes safe for logs and audit handoff."""

    IDEMPOTENT_REPLAY = "idempotent_replay"
    IDEMPOTENCY_PAYLOAD_MISMATCH = "idempotency_payload_mismatch"
    CLASSIFIER_UNRESOLVED = "classifier_unresolved"
    CLASSIFIER_REJECTED = "classifier_rejected"
    VALIDATOR_REJECTED = "validator_rejected"
    CONFLICT_DISAGREEMENT = "conflict_disagreement"
    REFERENCE_NOT_VISIBLE_OR_MISSING = "reference_not_visible_or_missing"
    SERIALIZATION_RETRY = "serialization_retry"
    LIFECYCLE_TRANSITION_REJECTED = "lifecycle_transition_rejected"


class AssertionStagingFailureKind(StrEnum):
    """Failure categories mapped to stable staging reason codes."""

    IDEMPOTENT_REPLAY = "idempotent_replay"
    IDEMPOTENCY_PAYLOAD_MISMATCH = "idempotency_payload_mismatch"
    CLASSIFIER_UNRESOLVED = "classifier_unresolved"
    CLASSIFIER_REJECTED = "classifier_rejected"
    VALIDATOR_REJECTED = "validator_rejected"
    CONFLICT = "conflict"
    RLS_REFERENCE = "rls_reference"
    SERIALIZATION = "serialization"
    LIFECYCLE = "lifecycle"


STAGING_FAILURE_REASON: Mapping[AssertionStagingFailureKind, AssertionStagingReason] = {
    AssertionStagingFailureKind.IDEMPOTENT_REPLAY: AssertionStagingReason.IDEMPOTENT_REPLAY,
    AssertionStagingFailureKind.IDEMPOTENCY_PAYLOAD_MISMATCH: (
        AssertionStagingReason.IDEMPOTENCY_PAYLOAD_MISMATCH
    ),
    AssertionStagingFailureKind.CLASSIFIER_UNRESOLVED: AssertionStagingReason.CLASSIFIER_UNRESOLVED,
    AssertionStagingFailureKind.CLASSIFIER_REJECTED: AssertionStagingReason.CLASSIFIER_REJECTED,
    AssertionStagingFailureKind.VALIDATOR_REJECTED: AssertionStagingReason.VALIDATOR_REJECTED,
    AssertionStagingFailureKind.CONFLICT: AssertionStagingReason.CONFLICT_DISAGREEMENT,
    AssertionStagingFailureKind.RLS_REFERENCE: (
        AssertionStagingReason.REFERENCE_NOT_VISIBLE_OR_MISSING
    ),
    AssertionStagingFailureKind.SERIALIZATION: AssertionStagingReason.SERIALIZATION_RETRY,
    AssertionStagingFailureKind.LIFECYCLE: AssertionStagingReason.LIFECYCLE_TRANSITION_REJECTED,
}


class AssertionStagingLogContext(BaseModel):
    """Safelisted operator fields for staging logs and audit handoff.

    Raw claim, source, and grounding payloads are intentionally absent.
    """

    model_config = ConfigDict(frozen=True, extra="forbid", use_enum_values=True)

    assertion_id: UUID | None = None
    actor_principal_id: UUID
    tenant_id: UUID
    intent: Intent
    source_kind: str = Field(min_length=1, max_length=63)
    status: PendingAssertionStatus
    reason_code: AssertionStagingReason
    digest_version: int = ASSERTION_DIGEST_VERSION
    resolution_attempts: int = Field(default=0, ge=0)


class AssertionCanonicalInput(BaseModel):
    """Normalized internal assertion shape consumed by staging helpers.

    Endpoint and ingest surfaces may have different public envelopes; they
    should normalize into this service-facing shape before computing digests.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    actor_principal_id: UUID
    intent: Intent
    source: Mapping[str, Any]
    grounding: Sequence[Mapping[str, Any]] = ()
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    context_of_validity: Mapping[str, Any]
    claim: Mapping[str, Any]
    claim_kind: str | None = None
    fact_family: FactFamilyInput | None = None

    @field_validator("source", "context_of_validity", "claim")
    @classmethod
    def _mapping_is_canonical_json(cls, value: Mapping[str, Any]) -> Mapping[str, Any]:
        canonical_json_bytes(value)
        return value

    @field_validator("grounding")
    @classmethod
    def _grounding_is_canonical_json(
        cls,
        value: Sequence[Mapping[str, Any]],
    ) -> Sequence[Mapping[str, Any]]:
        canonical_json_bytes(value)
        return value


class AssertionDigestSet(BaseModel):
    """Deterministic digests stored on ``pending_assertions``."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    claim_content_digest: bytes
    normalized_fact_digest: bytes | None
    idempotency_payload_digest: bytes
    digest_version: int = ASSERTION_DIGEST_VERSION


class StagedAssertionRecord(BaseModel):
    """Service projection returned after a single-row staging attempt."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    status: PendingAssertionStatus
    idempotency_decision: IdempotencyDecision
    idempotency_key: str
    actor_principal_id: UUID
    tenant_id: UUID
    source_kind: str
    claim_kind: str | None = None
    digest_version: int


class ResolverHandoffDecision(StrEnum):
    """Service outcome for handing a staged row to the resolver."""

    RESOLVED = "resolved"
    REPLAY = "replay"
    REJECTED = "rejected"


class ResolverHandoffRecord(BaseModel):
    """Projection returned after resolver-owned staging handoff."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    status: PendingAssertionStatus
    decision: ResolverHandoffDecision
    reason_code: str | None = None
    fact_family_key: str | None = None


class AssertionIdempotencyMismatchError(ValueError):
    """Raised when a client idempotency key is replayed with a new payload."""

    def __init__(self, *, idempotency_key: str, existing_assertion_id: UUID) -> None:
        self.idempotency_key = idempotency_key
        self.existing_assertion_id = existing_assertion_id
        super().__init__(AssertionStagingReason.IDEMPOTENCY_PAYLOAD_MISMATCH.value)


def _source_kind(source: Mapping[str, Any]) -> str:
    value = source.get("kind")
    if not isinstance(value, str) or value.strip() == "":
        raise AssertionCanonicalizationError("source.kind must be a non-empty string")
    return value


def _normalize_json(value: Any) -> Any:
    if value is None or isinstance(value, str | bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise AssertionCanonicalizationError("canonical JSON rejects non-finite numbers")
        return value
    if isinstance(value, Mapping):
        normalized: dict[str, Any] = {}
        for key, nested in cast(Mapping[object, object], value).items():
            if not isinstance(key, str):
                raise AssertionCanonicalizationError("canonical JSON object keys must be strings")
            normalized[key] = _normalize_json(nested)
        return normalized
    if isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
        return [_normalize_json(item) for item in cast(Sequence[object], value)]
    raise AssertionCanonicalizationError(
        f"unsupported canonical JSON value: {type(value).__name__}"
    )


def canonical_json_bytes(value: Any) -> bytes:
    """Return deterministic UTF-8 JSON bytes for a JSON-compatible value."""

    try:
        encoded = json.dumps(
            _normalize_json(value),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise AssertionCanonicalizationError(str(exc)) from exc
    return encoded.encode("utf-8")


def assertion_sha256_digest(domain: str, value: Any) -> bytes:
    """Hash canonical JSON with an explicit domain and digest version prefix."""

    digest = sha256()
    digest.update(f"skaldos.assertion.{domain}.v{ASSERTION_DIGEST_VERSION}\0".encode("ascii"))
    digest.update(canonical_json_bytes(value))
    return digest.digest()


def build_assertion_digests(assertion: AssertionCanonicalInput) -> AssertionDigestSet:
    """Compute content, fact-family, and idempotency payload digests."""

    normalized = assertion.model_dump(mode="json")
    normalized.pop("fact_family")
    claim = normalized["claim"]
    return AssertionDigestSet(
        claim_content_digest=assertion_sha256_digest("claim-content", claim),
        normalized_fact_digest=(
            assertion_sha256_digest("fact-family", fact_family_key(assertion.fact_family))
            if assertion.fact_family is not None
            else None
        ),
        idempotency_payload_digest=assertion_sha256_digest("idempotency-payload", normalized),
    )


def classify_idempotency(
    *,
    existing_payload_digest: bytes | None,
    incoming_payload_digest: bytes,
) -> IdempotencyDecision:
    """Classify a pending assertion insert/retry by payload digest."""

    if existing_payload_digest is None:
        return IdempotencyDecision.INSERT
    if existing_payload_digest == incoming_payload_digest:
        return IdempotencyDecision.REPLAY
    return IdempotencyDecision.PAYLOAD_MISMATCH


def staging_reason_for_failure(
    failure_kind: AssertionStagingFailureKind,
) -> AssertionStagingReason:
    """Map a staging failure category to a stable low-cardinality reason."""

    return STAGING_FAILURE_REASON[failure_kind]


def staging_event_fields(context: AssertionStagingLogContext) -> dict[str, object]:
    """Return safelisted staging event fields without raw assertion payloads."""

    return context.model_dump(mode="json", exclude_none=True)


def validate_pending_assertion_transition(
    current: PendingAssertionStatus,
    requested: PendingAssertionStatus,
) -> None:
    """Fail unless ``current -> requested`` is an allowed staging transition."""

    if requested not in ALLOWED_PENDING_ASSERTION_TRANSITIONS[current]:
        raise AssertionLifecycleError(current, requested)


def pending_assertion_sql_primitive(*, batch_size: int) -> str:
    """Return the PC10 SQL primitive expected for single-row or batch staging."""

    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    return "insert_on_conflict" if batch_size == 1 else "merge"


async def stage_single_assertion(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    assertion: AssertionCanonicalInput,
    idempotency_key: str,
) -> StagedAssertionRecord:
    """Stage one normalized assertion through ``pending_assertions``.

    The caller supplies the Principal-bound transaction connection; this
    function verifies that GUC binding with :func:`with_principal`, computes
    staging-owned digests, and uses the PC10 single-row
    ``INSERT ... ON CONFLICT`` posture. A same-key/same-payload retry returns
    the existing row. A same-key/different-payload retry raises
    :class:`AssertionIdempotencyMismatchError` and creates no new row.
    """

    if assertion.actor_principal_id != principal.id:
        raise AssertionCanonicalizationError("assertion actor must match principal")
    if idempotency_key.strip() == "":
        raise AssertionCanonicalizationError("idempotency_key must not be empty")

    async def _stage(bound_connection: asyncpg.Connection) -> StagedAssertionRecord:
        digests = build_assertion_digests(assertion)
        source_kind = _source_kind(assertion.source)
        statement_args = (
            canonical_json_bytes(assertion.context_of_validity).decode("utf-8"),
            assertion.actor_principal_id,
            assertion.intent.value,
            canonical_json_bytes(assertion.source).decode("utf-8"),
            canonical_json_bytes(assertion.grounding).decode("utf-8"),
            assertion.confidence,
            canonical_json_bytes(assertion.claim).decode("utf-8"),
            assertion.claim_kind,
            digests.claim_content_digest,
            digests.normalized_fact_digest,
            idempotency_key,
            digests.idempotency_payload_digest,
            digests.digest_version,
        )
        row: Any | None = None
        for _attempt in range(2):
            row = cast(
                Any,
                await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                    """
                WITH inserted AS (
                    INSERT INTO pending_assertions (
                        context_of_validity,
                        actor_principal_id,
                        intent,
                        source,
                        grounding,
                        confidence,
                        claim,
                        claim_kind,
                        claim_content_digest,
                        normalized_fact_digest,
                        idempotency_key,
                        idempotency_payload_digest,
                        digest_version
                    )
                    VALUES (
                        $1::jsonb,
                        $2,
                        $3::assertion_intent,
                        $4::jsonb,
                        $5::jsonb,
                        $6,
                        $7::jsonb,
                        $8,
                        $9,
                        $10,
                        $11,
                        $12,
                        $13
                    )
                    ON CONFLICT (tenant_id, actor_principal_id, idempotency_key)
                    DO NOTHING
                    RETURNING
                        id,
                        status::text AS status,
                        actor_principal_id,
                        tenant_id,
                        source_kind,
                        claim_kind,
                        digest_version,
                        idempotency_payload_digest,
                        true AS inserted
                ),
                existing AS (
                    SELECT
                        id,
                        status::text AS status,
                        actor_principal_id,
                        tenant_id,
                        source_kind,
                        claim_kind,
                        digest_version,
                        idempotency_payload_digest,
                        false AS inserted
                    FROM pending_assertions
                    WHERE tenant_id = (($1::jsonb ->> 'tenant')::uuid)
                      AND actor_principal_id = $2
                      AND idempotency_key = $11
                      AND NOT EXISTS (SELECT 1 FROM inserted)
                )
                SELECT *
                FROM inserted
                UNION ALL
                SELECT *
                FROM existing
                LIMIT 1
                """,
                    *statement_args,
                ),
            )
            if row is not None:
                break
        if row is None:
            raise RuntimeError("pending_assertion_insert_returned_no_row")

        existing_digest = cast(bytes, row["idempotency_payload_digest"])
        decision = (
            IdempotencyDecision.INSERT
            if bool(row["inserted"])
            else classify_idempotency(
                existing_payload_digest=existing_digest,
                incoming_payload_digest=digests.idempotency_payload_digest,
            )
        )
        assertion_id = cast(UUID, row["id"])
        if decision is IdempotencyDecision.PAYLOAD_MISMATCH:
            raise AssertionIdempotencyMismatchError(
                idempotency_key=idempotency_key,
                existing_assertion_id=assertion_id,
            )

        return StagedAssertionRecord(
            id=assertion_id,
            status=PendingAssertionStatus(cast(str, row["status"])),
            idempotency_decision=decision,
            idempotency_key=idempotency_key,
            actor_principal_id=cast(UUID, row["actor_principal_id"]),
            tenant_id=cast(UUID, row["tenant_id"]),
            source_kind=cast(str, row["source_kind"] or source_kind),
            claim_kind=cast(str | None, row["claim_kind"]),
            digest_version=cast(int, row["digest_version"]),
        )

    return await with_principal(principal=principal, connection=connection, fn=_stage)


async def handoff_staged_assertion_to_resolver(
    *,
    principal: Principal,
    connection: asyncpg.Connection,
    staged_assertion_id: UUID,
) -> ResolverHandoffRecord:
    """Move a freshly staged assertion into the resolver-owned lifecycle path.

    This T4 handoff validates the row through the resolver entry point and
    advances valid candidates to ``resolved`` without applying canonical graph
    mutations. Malformed rows are returned as typed ``rejected`` outcomes by
    the resolver. Idempotent replay payloads are surfaced without reopening or
    mutating staged history.
    """

    from skaldos.graph.assert_resolution import consume_staged_assertion  # noqa: PLC0415

    consumed = await consume_staged_assertion(
        principal=principal,
        connection=connection,
        staged_assertion_id=staged_assertion_id,
    )
    if consumed.kind == "replay":
        return ResolverHandoffRecord(
            id=staged_assertion_id,
            status=PendingAssertionStatus.REJECTED,
            decision=ResolverHandoffDecision.REPLAY,
            reason_code=consumed.outcome.reason.value if consumed.outcome is not None else None,
            fact_family_key=(
                consumed.outcome.fact_family_key if consumed.outcome is not None else None
            ),
        )
    if consumed.kind == "rejected":
        return ResolverHandoffRecord(
            id=staged_assertion_id,
            status=PendingAssertionStatus.REJECTED,
            decision=ResolverHandoffDecision.REJECTED,
            reason_code=consumed.outcome.reason.value if consumed.outcome is not None else None,
            fact_family_key=(
                consumed.outcome.fact_family_key if consumed.outcome is not None else None
            ),
        )

    if consumed.candidate is None:
        raise AssertionLifecycleError(
            PendingAssertionStatus.STAGED, PendingAssertionStatus.REJECTED
        )
    candidate = consumed.candidate
    validate_pending_assertion_transition(candidate.status, PendingAssertionStatus.CLASSIFIED)
    validate_pending_assertion_transition(
        PendingAssertionStatus.CLASSIFIED,
        PendingAssertionStatus.RESOLVED,
    )

    async def _mark_resolved(bound_connection: asyncpg.Connection) -> ResolverHandoffRecord:
        metadata = {
            "resolver_handoff": "ready_for_conflict_resolution",
            "reason_code": "resolver_candidate_validated",
            "fact_family_key": candidate.fact_family_key,
            "claim_kind": candidate.claim_kind,
            "source_kind": candidate.source_kind,
            "digest_version": candidate.digest_version,
        }
        classifier_metadata = {
            "status": "resolved",
            "reason_code": "resolver_handoff",
            "classifier_name": "staging_resolver_handoff",
            "classifier_version": "1",
        }
        row = cast(
            Any | None,
            await bound_connection.fetchrow(  # pyright: ignore[reportUnknownMemberType]
                """
                UPDATE pending_assertions
                SET status = 'resolved',
                    status_reason = $2,
                    classifier_result = $3::jsonb,
                    validator_result = $4::jsonb,
                    resolution_attempts = resolution_attempts + 1,
                    last_attempt_at = now()
                WHERE id = $1
                  AND status = 'staged'
                RETURNING id, status::text AS status, validator_result
                """,
                candidate.id,
                "resolver_candidate_validated",
                json.dumps(classifier_metadata, sort_keys=True, separators=(",", ":")),
                json.dumps(metadata, sort_keys=True, separators=(",", ":")),
            ),
        )
        if row is None:
            raise AssertionLifecycleError(candidate.status, PendingAssertionStatus.RESOLVED)
        validator_result = json.loads(cast(str, row["validator_result"]))
        return ResolverHandoffRecord(
            id=cast(UUID, row["id"]),
            status=PendingAssertionStatus(cast(str, row["status"])),
            decision=ResolverHandoffDecision.RESOLVED,
            reason_code=cast(str, validator_result["reason_code"]),
            fact_family_key=cast(str, validator_result["fact_family_key"]),
        )

    return await with_principal(principal=principal, connection=connection, fn=_mark_resolved)
