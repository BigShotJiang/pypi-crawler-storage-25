"""RLS-bound asyncpg repository for graph Edge writes."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, cast
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]

from skaldos.graph.edges import (
    ClassificationLevel,
    EdgeEndpointSnapshot,
    EdgeRelationshipType,
    EdgeRepository,
    EdgeRow,
    EdgeRowDraft,
)


class AsyncEdgeRepository(EdgeRepository):  # pragma: no cover - exercised by route tests
    """RLS-bound ``EdgeRepository`` backed by an existing asyncpg transaction."""

    def __init__(self, connection: asyncpg.Connection) -> None:
        self._connection = connection

    async def load_endpoint(self, node_id: UUID) -> EdgeEndpointSnapshot | None:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            SELECT id, tenant_id, classification, archived_at, superseded_by_node_id
            FROM nodes
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            node_id,
        )
        if row is None:
            return None
        row = cast(Mapping[str, Any], row)
        return EdgeEndpointSnapshot(
            id=cast(UUID, row["id"]),
            tenant_id=cast(UUID, row["tenant_id"]),
            classification=ClassificationLevel(str(row["classification"])),
            archived_at=row["archived_at"],
            superseded_by_node_id=cast(UUID | None, row["superseded_by_node_id"]),
        )

    async def get_edge(self, edge_id: UUID) -> EdgeRow | None:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            _EDGE_SELECT
            + """
            WHERE id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            """,
            edge_id,
        )
        return None if row is None else _edge_row(cast(asyncpg.Record, row))

    async def list_outgoing_edges(
        self,
        source_node_id: UUID,
        *,
        relationship_types: Sequence[EdgeRelationshipType] = (),
        include_archived: bool = False,
    ) -> tuple[EdgeRow, ...]:
        rows = await self._connection.fetch(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            _EDGE_SELECT
            + """
            WHERE source_node_id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
              AND ($2::text[] = '{}'::text[] OR relationship_type = ANY($2::text[]))
              AND ($3 OR archived_at IS NULL)
            ORDER BY created_at, id
            """,
            source_node_id,
            [relationship_type.value for relationship_type in relationship_types],
            include_archived,
        )
        return tuple(_edge_row(row) for row in cast(Sequence[asyncpg.Record], rows))

    async def list_incoming_edges(
        self,
        target_node_id: UUID,
        *,
        relationship_types: Sequence[EdgeRelationshipType] = (),
        include_archived: bool = False,
    ) -> tuple[EdgeRow, ...]:
        rows = await self._connection.fetch(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            _EDGE_SELECT
            + """
            WHERE target_node_id = $1
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
              AND ($2::text[] = '{}'::text[] OR relationship_type = ANY($2::text[]))
              AND ($3 OR archived_at IS NULL)
            ORDER BY created_at, id
            """,
            target_node_id,
            [relationship_type.value for relationship_type in relationship_types],
            include_archived,
        )
        return tuple(_edge_row(row) for row in cast(Sequence[asyncpg.Record], rows))

    async def create_edge(self, draft: EdgeRowDraft) -> EdgeRow:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            INSERT INTO edges (
              tenant_id,
              source_node_id,
              target_node_id,
              relationship_type,
              weight,
              classification,
              authored_by_principal_id
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING
              id,
              tenant_id,
              source_node_id,
              target_node_id,
              relationship_type::text AS relationship_type,
              weight,
              classification,
              authored_by_principal_id,
              created_at,
              archived_at,
              archived_by_principal_id
            """,
            draft.tenant_id,
            draft.source_node_id,
            draft.target_node_id,
            draft.relationship_type.value,
            draft.weight,
            draft.classification.value,
            draft.authored_by_principal_id,
        )
        if row is None:
            raise RuntimeError("edge_insert_failed")
        return _edge_row(cast(asyncpg.Record, row))

    async def archive_edge(
        self,
        edge_id: UUID,
        *,
        archived_by_principal_id: UUID,
    ) -> EdgeRow | None:
        row = await self._connection.fetchrow(  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            """
            UPDATE edges
            SET archived_at = now(),
                archived_by_principal_id = $2
            WHERE id = $1
              AND archived_at IS NULL
              AND tenant_id = ANY ((SELECT app.principal_visible())::uuid[])
            RETURNING
              id,
              tenant_id,
              source_node_id,
              target_node_id,
              relationship_type::text AS relationship_type,
              weight,
              classification,
              authored_by_principal_id,
              created_at,
              archived_at,
              archived_by_principal_id
            """,
            edge_id,
            archived_by_principal_id,
        )
        return None if row is None else _edge_row(cast(asyncpg.Record, row))


_EDGE_SELECT = """
SELECT
  id,
  tenant_id,
  source_node_id,
  target_node_id,
  relationship_type::text AS relationship_type,
  weight,
  classification,
  authored_by_principal_id,
  created_at,
  archived_at,
  archived_by_principal_id
FROM edges
"""


def _edge_row(row: asyncpg.Record) -> EdgeRow:
    return EdgeRow(
        id=cast(UUID, row["id"]),
        tenant_id=cast(UUID, row["tenant_id"]),
        source_node_id=cast(UUID, row["source_node_id"]),
        target_node_id=cast(UUID, row["target_node_id"]),
        relationship_type=EdgeRelationshipType(str(row["relationship_type"])),
        weight=row["weight"],
        classification=ClassificationLevel(str(row["classification"])),
        authored_by_principal_id=cast(UUID, row["authored_by_principal_id"]),
        created_at=row["created_at"],
        archived_at=row["archived_at"],
        archived_by_principal_id=row["archived_by_principal_id"],
    )


__all__ = ["AsyncEdgeRepository"]
