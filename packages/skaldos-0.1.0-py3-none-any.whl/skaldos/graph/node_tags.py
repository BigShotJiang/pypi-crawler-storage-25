"""NodeTag validation helpers for Slice 3 tag application.

This module owns pure, service-facing checks for the ``node_tags`` primitive:
codepoint spans over NFC body, one typed value family, currency safety, context
inheritance/override, and conservative classification. It has no database or
route dependency; storage and service layers call these helpers before writing.

References: §1.6, §1.7, §1.8, §1.9, §1.15, §15.4, ML6, AP5.
"""

from __future__ import annotations

import unicodedata
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from decimal import Decimal
from enum import StrEnum
from hashlib import sha256
from typing import Any, Protocol, runtime_checkable
from uuid import UUID

import asyncpg  # pyright: ignore[reportMissingTypeStubs]
from pydantic import BaseModel, ConfigDict, Field, model_validator

from skaldos.events.graph_publisher import (
    GraphChangeEventPublisher,
    GraphChangeEventType,
    graph_change_event_draft_for_tag,
)

from .edges import ClassificationLevel
from .tag_definitions import TagDefinitionLifecycleState, TagValueType, normalize_tag_name
from .tag_definitions_service import (
    TagDefinitionApplicationContract,
    TagDefinitionServiceContext,
    TagDefinitionServiceReason,
    TagDefinitionServiceResult,
)

type JsonObject = dict[str, Any]

_CONTEXT_KEYS = frozenset(
    {
        "tenant",
        "classification",
        "vertical",
        "ontology_version",
        "valid_from",
        "valid_to",
    }
)


class NodeTagValidationReason(StrEnum):
    """Stable reason codes for NodeTag validation failures."""

    SPAN_OUT_OF_RANGE = "node_tag_span_out_of_range"
    SPAN_EMPTY = "node_tag_span_empty"
    TEXT_QUOTE_SELECTOR_INVALID = "node_tag_text_quote_selector_invalid"
    TEXT_QUOTE_EXACT_MISMATCH = "node_tag_text_quote_exact_mismatch"
    VALUE_FAMILY_REQUIRED = "node_tag_value_family_required"
    VALUE_FAMILY_MULTIPLE = "node_tag_value_family_multiple"
    VALUE_TYPE_MISMATCH = "node_tag_value_type_mismatch"
    CURRENCY_REQUIRED = "node_tag_currency_required"
    CURRENCY_FORBIDDEN = "node_tag_currency_forbidden"
    CURRENCY_INVALID = "node_tag_currency_invalid"
    ENUM_VALUE_INVALID = "node_tag_enum_value_invalid"
    COMPUTED_WRITE_FORBIDDEN = "node_tag_computed_write_forbidden"
    CONTEXT_REQUIRED_KEY_MISSING = "node_tag_context_required_key_missing"
    CONTEXT_OVERRIDE_PROVENANCE_REQUIRED = "node_tag_context_override_provenance_required"
    CONTEXT_TENANT_WIDENING = "node_tag_context_tenant_widening"
    CONTEXT_VERTICAL_CHANGE = "node_tag_context_vertical_change"
    CONTEXT_VALIDITY_INVALID = "node_tag_context_validity_invalid"
    CONTEXT_VALIDITY_WIDENING = "node_tag_context_validity_widening"
    CONTEXT_CLASSIFICATION_INVALID = "node_tag_context_classification_invalid"
    CONTEXT_CLASSIFICATION_WIDENING = "node_tag_context_classification_widening"
    CLASSIFICATION_DOWNGRADE = "node_tag_classification_downgrade"
    SOURCE_NODE_NOT_FOUND = "node_tag_source_node_not_found"
    SOURCE_NODE_ARCHIVED = "node_tag_source_node_archived"
    REFERENCE_NODE_NOT_FOUND = "node_tag_reference_node_not_found"
    REFERENCE_NODE_ARCHIVED = "node_tag_reference_node_archived"
    REFERENCE_NODE_CROSS_SCOPE = "node_tag_reference_node_cross_scope"
    DEFINITION_NOT_FOUND = "node_tag_definition_not_found"
    DEFINITION_TEMPLATE = "node_tag_definition_template"
    DEFINITION_CROSS_SCOPE = "node_tag_definition_cross_scope"
    DEFINITION_LIFECYCLE_REJECTED = "node_tag_definition_lifecycle_rejected"
    CONTENT_DIGEST_STALE = "node_tag_content_digest_stale"
    TAG_NOT_FOUND = "node_tag_not_found"
    VERIFIED_TAG_IMMUTABLE = "node_tag_verified_immutable"
    VERIFIED_TAG_CONFLICT = "node_tag_verified_conflict"
    SUPERSESSION_SELF = "node_tag_supersession_self"
    SUPERSESSION_CROSS_FAMILY = "node_tag_supersession_cross_family"
    SUPERSESSION_CYCLE = "node_tag_supersession_cycle"
    STALE_MARK_REQUIRES_ACTIVE_TAG = "node_tag_stale_mark_requires_active_tag"
    ONTOLOGY_VERSION_MISMATCH = "node_tag_ontology_version_mismatch"
    STORAGE_CONFLICT = "node_tag_storage_conflict"


class NodeTagValidationError(ValueError):
    """Domain validation error with a stable reason code."""

    def __init__(self, reason_code: NodeTagValidationReason, message: str) -> None:
        self.reason_code = reason_code
        super().__init__(f"{reason_code.value}: {message}")


class TextQuoteSelector(BaseModel):
    """Small text-quote selector envelope for Slice 3 span checks."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    exact: str
    prefix: str = ""
    suffix: str = ""


class NodeTagValue(BaseModel):
    """Exactly-one value family supplied for a NodeTag."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    value_text: str | None = None
    value_number: Decimal | None = None
    value_boolean: bool | None = None
    value_reference_node_id: UUID | None = None

    @model_validator(mode="after")
    def _exactly_one_value_family(self) -> NodeTagValue:
        populated = self.populated_families()
        if not populated:
            raise NodeTagValidationError(
                NodeTagValidationReason.VALUE_FAMILY_REQUIRED,
                "exactly one NodeTag value family is required",
            )
        if len(populated) > 1:
            raise NodeTagValidationError(
                NodeTagValidationReason.VALUE_FAMILY_MULTIPLE,
                "only one NodeTag value family may be populated",
            )
        return self

    def populated_families(self) -> tuple[str, ...]:
        """Return populated value family names in storage-column terms."""

        families: list[str] = []
        if self.value_text is not None:
            families.append("value_text")
        if self.value_number is not None:
            families.append("value_number")
        if self.value_boolean is not None:
            families.append("value_boolean")
        if self.value_reference_node_id is not None:
            families.append("value_reference_node_id")
        return tuple(families)


class NodeTagDefinitionMetadata(BaseModel):
    """Definition facts needed for pure NodeTag validation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    value_type: TagValueType
    requires_currency: bool = False
    classification: ClassificationLevel = ClassificationLevel.C0
    enum_values_canonical: tuple[str, ...] | None = None


class NodeTagContextOverride(BaseModel):
    """Explicit context override with provenance required by §1.15."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    context: JsonObject
    reason: str = Field(min_length=1)
    source: str = Field(min_length=1)


class NodeTagSourceSnapshot(BaseModel):
    """RLS-bound source Node projection needed for applying a tag."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    classification: ClassificationLevel
    body_nfc: str
    body_nfc_hash: bytes
    context_of_validity: JsonObject
    archived_at: datetime | None = None

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None


class NodeTagReferenceSnapshot(BaseModel):
    """RLS-bound reference target projection for reference-valued tags."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: UUID
    tenant_id: UUID
    archived_at: datetime | None = None

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None


class NodeTagApplyRequest(BaseModel):
    """Strict request for applying one active NodeTag through the service."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    tag_definition_id: UUID
    value: NodeTagValue
    span_offset_start: int
    span_offset_end: int
    expected_content_digest: bytes
    text_quote_selector: TextQuoteSelector | None = None
    currency: str | None = None
    confidence: Decimal = Field(ge=0, le=1)
    context_override: NodeTagContextOverride | None = None
    attrs: JsonObject = Field(default_factory=dict)


class NodeTagVerifyRequest(BaseModel):
    """Strict request for human verification of an existing active NodeTag."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tag_id: UUID


class NodeTagSupersedeRequest(BaseModel):
    """Strict request for linking one active tag to a newer same-family tag."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    superseded_tag_id: UUID
    superseding_tag_id: UUID


class NodeTagDisagreementRequest(BaseModel):
    """Apply a candidate tag that disagrees with an active verified tag."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    verified_tag_id: UUID
    candidate: NodeTagApplyRequest


class NodeTagMarkStaleRequest(BaseModel):
    """Strict request for marking an active tag stale without moving its span."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tag_id: UUID


class NodeTagListStaleRequest(BaseModel):
    """Strict request for finding active tags stale against a source Node body."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID


class NodeTagStaleCandidate(BaseModel):
    """Active tag whose locator digest no longer matches its source Node."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    tag: NodeTagRow
    current_content_digest: bytes


class NodeTagRowDraft(BaseModel):
    """Validated values passed to repository insert."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    node_id: UUID
    tenant_id: UUID
    tag_definition_id: UUID
    value_text: str | None = None
    value_number: Decimal | None = None
    value_boolean: bool | None = None
    value_reference_node_id: UUID | None = None
    currency: str | None = None
    attrs: JsonObject = Field(default_factory=dict)
    span_offset_start: int
    span_offset_end: int
    content_digest: bytes
    text_quote_selector: JsonObject
    context_of_validity: JsonObject
    classification: ClassificationLevel
    tagged_by_principal_id: UUID
    confidence: Decimal


class NodeTagRow(NodeTagRowDraft):
    """Storage row shape returned after insert."""

    id: UUID
    verified_by_principal_id: UUID | None = None
    verified_at: datetime | None = None
    superseded_by_tag_id: UUID | None = None
    created_at: datetime

    @property
    def is_verified(self) -> bool:
        return self.verified_at is not None

    @property
    def is_active(self) -> bool:
        return self.superseded_by_tag_id is None


@runtime_checkable
class NodeTagRepository(Protocol):
    """RLS-bound repository surface for one transactional tag application.

    Implementations must run source/definition/reference loads and the insert
    on the same connection and database transaction. Definition loads should
    lock or otherwise stabilize lifecycle facts until ``create_tag`` returns.
    """

    async def load_source_node(self, node_id: UUID) -> NodeTagSourceSnapshot | None:
        """Load a visible source Node projection by id."""
        ...

    async def get_definition_for_application(
        self,
        *,
        context: TagDefinitionServiceContext,
        definition_id: UUID,
    ) -> TagDefinitionServiceResult:
        """Load a visible TagDefinition application contract in this transaction."""
        ...

    async def load_reference_node(self, node_id: UUID) -> NodeTagReferenceSnapshot | None:
        """Load a visible reference target projection by id."""
        ...

    async def create_tag(self, draft: NodeTagRowDraft) -> NodeTagRow:
        """Insert a validated NodeTag row through the current transaction."""
        ...

    async def load_tag(self, tag_id: UUID) -> NodeTagRow | None:
        """Load a visible NodeTag row by id."""
        ...

    async def lock_active_tag_family(
        self,
        *,
        node_id: UUID,
        tag_definition_id: UUID,
    ) -> Sequence[NodeTagRow]:
        """Lock active visible rows in a NodeTag semantic family for update."""
        ...

    async def verify_tag(
        self,
        tag_id: UUID,
        *,
        verified_by_principal_id: UUID,
    ) -> NodeTagRow:
        """Mark an active tag as human-verified without changing value/locator fields."""
        ...

    async def supersede_tag(
        self,
        superseded_tag_id: UUID,
        *,
        superseding_tag_id: UUID,
    ) -> NodeTagRow:
        """Set superseded_by_tag_id on one active same-family tag."""
        ...

    async def mark_tag_attrs(
        self,
        tag_id: UUID,
        *,
        attrs: Mapping[str, Any],
    ) -> NodeTagRow:
        """Replace attrs for a visible tag after service-side validation."""
        ...

    async def list_active_tags_for_node(self, node_id: UUID) -> Sequence[NodeTagRow]:
        """List active visible NodeTags for stale locator evaluation."""
        ...


class RepositoryNodeTagService:
    """Service implementation for applying NodeTag rows through RLS-bound repositories."""

    def __init__(
        self,
        *,
        repository: NodeTagRepository,
        event_publisher: GraphChangeEventPublisher,
    ) -> None:
        self._repository = repository
        self._event_publisher = event_publisher

    async def apply_tag(
        self,
        request: NodeTagApplyRequest,
        *,
        context: TagDefinitionServiceContext,
    ) -> NodeTagRow:
        source = validate_source_node_for_tag(
            await self._repository.load_source_node(request.node_id)
        )
        definition_result = await self._repository.get_definition_for_application(
            context=context,
            definition_id=request.tag_definition_id,
        )
        if definition_result.application_contract is None:
            raise _definition_application_error(definition_result.reason_code)
        contract = validate_definition_for_tag_application(definition_result.application_contract)

        reference = None
        if request.value.value_reference_node_id is not None:
            reference = validate_reference_node_for_tag(
                await self._repository.load_reference_node(request.value.value_reference_node_id),
                tenant_id=context.tenant_id,
            )

        draft = build_node_tag_insert(
            request=request,
            context=context,
            source=source,
            definition_contract=contract,
            reference=reference,
        )
        try:
            row = await self._repository.create_tag(draft)
        except asyncpg.PostgresError as exc:
            raise NodeTagValidationError(
                NodeTagValidationReason.STORAGE_CONFLICT,
                "NodeTag storage rejected the write",
            ) from exc
        await self._event_publisher.publish_graph_change_event(
            graph_change_event_draft_for_tag(
                event_type=GraphChangeEventType.TAG_CREATED,
                tag_id=row.id,
                tenant_id=row.tenant_id,
                context_of_validity=row.context_of_validity,
                actor_principal_id=context.principal_id,
                occurred_at=row.created_at,
            )
        )
        return row

    async def create_disagreement_candidate(
        self,
        request: NodeTagDisagreementRequest,
        *,
        context: TagDefinitionServiceContext,
    ) -> NodeTagRow:
        verified = validate_verified_conflict_target(
            await self._repository.load_tag(request.verified_tag_id)
        )
        family = await self._repository.lock_active_tag_family(
            node_id=verified.node_id,
            tag_definition_id=verified.tag_definition_id,
        )
        if not any(row.id == verified.id and row.is_verified for row in family):
            raise NodeTagValidationError(
                NodeTagValidationReason.VERIFIED_TAG_CONFLICT,
                "verified conflict target must remain active while creating disagreement",
            )
        if (
            request.candidate.node_id != verified.node_id
            or request.candidate.tag_definition_id != verified.tag_definition_id
        ):
            raise NodeTagValidationError(
                NodeTagValidationReason.SUPERSESSION_CROSS_FAMILY,
                "disagreement candidate must stay within the verified tag family",
            )
        candidate = request.candidate.model_copy(
            update={
                "attrs": {
                    **request.candidate.attrs,
                    "disagreement_with_tag_id": str(verified.id),
                    "disagreement_reason": NodeTagValidationReason.VERIFIED_TAG_CONFLICT.value,
                }
            }
        )
        row = await self.apply_tag(candidate, context=context)
        return row

    async def verify_tag(
        self,
        request: NodeTagVerifyRequest,
        *,
        context: TagDefinitionServiceContext,
    ) -> NodeTagRow:
        tag = validate_existing_tag(await self._repository.load_tag(request.tag_id))
        await self._repository.lock_active_tag_family(
            node_id=tag.node_id,
            tag_definition_id=tag.tag_definition_id,
        )
        if not tag.is_active:
            raise NodeTagValidationError(
                NodeTagValidationReason.TAG_NOT_FOUND,
                "only active visible NodeTags can be verified",
            )
        try:
            return await self._repository.verify_tag(
                tag.id,
                verified_by_principal_id=context.principal_id,
            )
        except asyncpg.PostgresError as exc:
            raise NodeTagValidationError(
                NodeTagValidationReason.STORAGE_CONFLICT,
                "NodeTag verification storage rejected the write",
            ) from exc

    async def supersede_tag(
        self,
        request: NodeTagSupersedeRequest,
        *,
        context: TagDefinitionServiceContext,
    ) -> NodeTagRow:
        if request.superseded_tag_id == request.superseding_tag_id:
            raise NodeTagValidationError(
                NodeTagValidationReason.SUPERSESSION_SELF,
                "NodeTag cannot supersede itself",
            )
        superseded = validate_existing_tag(
            await self._repository.load_tag(request.superseded_tag_id)
        )
        superseding = validate_existing_tag(
            await self._repository.load_tag(request.superseding_tag_id)
        )
        validate_same_tag_family(superseded, superseding)
        family = await self._repository.lock_active_tag_family(
            node_id=superseded.node_id,
            tag_definition_id=superseded.tag_definition_id,
        )
        validate_supersession_request(
            superseded=superseded,
            superseding=superseding,
            family=family,
        )
        try:
            row = await self._repository.supersede_tag(
                superseded.id,
                superseding_tag_id=superseding.id,
            )
        except asyncpg.PostgresError as exc:
            raise NodeTagValidationError(
                NodeTagValidationReason.STORAGE_CONFLICT,
                "NodeTag supersession storage rejected the write",
            ) from exc
        await self._event_publisher.publish_graph_change_event(
            graph_change_event_draft_for_tag(
                event_type=GraphChangeEventType.TAG_SUPERSEDED,
                tag_id=row.id,
                tenant_id=row.tenant_id,
                context_of_validity=row.context_of_validity,
                actor_principal_id=context.principal_id,
                occurred_at=datetime.now(UTC),
            )
        )
        return row

    async def mark_tag_stale(
        self,
        request: NodeTagMarkStaleRequest,
        *,
        context: TagDefinitionServiceContext,
    ) -> NodeTagRow:
        del context
        tag = validate_existing_tag(await self._repository.load_tag(request.tag_id))
        if not tag.is_active:
            raise NodeTagValidationError(
                NodeTagValidationReason.STALE_MARK_REQUIRES_ACTIVE_TAG,
                "only active visible NodeTags can be marked stale",
            )
        attrs = mark_tag_attrs_stale(tag.attrs)
        try:
            return await self._repository.mark_tag_attrs(tag.id, attrs=attrs)
        except asyncpg.PostgresError as exc:
            raise NodeTagValidationError(
                NodeTagValidationReason.STORAGE_CONFLICT,
                "NodeTag stale marker storage rejected the write",
            ) from exc

    async def list_stale_tags(
        self,
        request: NodeTagListStaleRequest,
        *,
        context: TagDefinitionServiceContext,
    ) -> tuple[NodeTagStaleCandidate, ...]:
        del context
        source = validate_existing_source_node_for_stale_check(
            await self._repository.load_source_node(request.node_id)
        )
        stale: list[NodeTagStaleCandidate] = []
        for tag in await self._repository.list_active_tags_for_node(source.id):
            current_digest = current_node_tag_content_digest_for_source(tag, source)
            if tag.content_digest != current_digest:
                stale.append(
                    NodeTagStaleCandidate(
                        tag=tag,
                        current_content_digest=current_digest,
                    )
                )
        return tuple(stale)


def validate_existing_tag(tag: NodeTagRow | None) -> NodeTagRow:
    """Return a visible NodeTag row or raise the stable not-found reason."""

    if tag is None:
        raise NodeTagValidationError(
            NodeTagValidationReason.TAG_NOT_FOUND,
            "NodeTag was not found or is not visible",
        )
    return tag


def validate_existing_source_node_for_stale_check(
    source: NodeTagSourceSnapshot | None,
) -> NodeTagSourceSnapshot:
    """Return a visible source Node for stale checks, including archived sources."""

    if source is None:
        raise NodeTagValidationError(
            NodeTagValidationReason.SOURCE_NODE_NOT_FOUND,
            "source Node was not found or is not visible",
        )
    return source


def validate_verified_conflict_target(tag: NodeTagRow | None) -> NodeTagRow:
    """Validate a verified active tag can anchor a disagreement candidate."""

    existing = validate_existing_tag(tag)
    if not existing.is_active or not existing.is_verified:
        raise NodeTagValidationError(
            NodeTagValidationReason.VERIFIED_TAG_CONFLICT,
            "disagreement candidate requires an active verified target",
        )
    return existing


def validate_same_tag_family(left: NodeTagRow, right: NodeTagRow) -> None:
    """Supersession/disagreement stays within node + organization + definition."""

    if (
        left.node_id != right.node_id
        or left.tenant_id != right.tenant_id
        or left.tag_definition_id != right.tag_definition_id
    ):
        raise NodeTagValidationError(
            NodeTagValidationReason.SUPERSESSION_CROSS_FAMILY,
            "NodeTag supersession must stay within the same semantic family",
        )


def validate_supersession_request(
    *,
    superseded: NodeTagRow,
    superseding: NodeTagRow,
    family: Sequence[NodeTagRow],
) -> None:
    """Reject cross-family, inactive, self, and cyclic supersession requests."""

    if superseded.id == superseding.id:
        raise NodeTagValidationError(
            NodeTagValidationReason.SUPERSESSION_SELF,
            "NodeTag cannot supersede itself",
        )
    validate_same_tag_family(superseded, superseding)

    by_id = {row.id: row for row in family}
    current_id = superseding.superseded_by_tag_id
    while current_id is not None:
        if current_id == superseded.id:
            raise NodeTagValidationError(
                NodeTagValidationReason.SUPERSESSION_CYCLE,
                "NodeTag supersession cycle rejected",
            )
        current = by_id.get(current_id)
        if current is None:
            break
        current_id = current.superseded_by_tag_id

    if not superseded.is_active or not superseding.is_active:
        raise NodeTagValidationError(
            NodeTagValidationReason.TAG_NOT_FOUND,
            "only active visible NodeTags can participate in supersession",
        )


def is_tag_stale_for_source(tag: NodeTagRow, source: NodeTagSourceSnapshot) -> bool:
    """Return whether a tag locator digest mismatches the current source body hash."""

    return tag.content_digest != current_node_tag_content_digest_for_source(tag, source)


def current_node_tag_content_digest_for_source(
    tag: NodeTagRow,
    source: NodeTagSourceSnapshot,
) -> bytes:
    """Compute the digest a tag would have against the source Node's current body."""

    if tag.node_id != source.id:
        raise NodeTagValidationError(
            NodeTagValidationReason.SOURCE_NODE_NOT_FOUND,
            "stale evaluation source Node must match the NodeTag",
        )
    return compute_node_tag_content_digest(
        source.body_nfc_hash,
        start=tag.span_offset_start,
        end=tag.span_offset_end,
    )


def stale_tag_candidates_for_source(
    tags: Sequence[NodeTagRow],
    source: NodeTagSourceSnapshot,
) -> tuple[NodeTagStaleCandidate, ...]:
    """Return active stale candidates for a source without mutating rows."""

    stale: list[NodeTagStaleCandidate] = []
    for tag in tags:
        if not tag.is_active:
            continue
        current_digest = current_node_tag_content_digest_for_source(tag, source)
        if tag.content_digest != current_digest:
            stale.append(
                NodeTagStaleCandidate(
                    tag=tag,
                    current_content_digest=current_digest,
                )
            )
    return tuple(stale)


def mark_tag_attrs_stale(attrs: Mapping[str, Any]) -> JsonObject:
    """Return attrs with the Slice 3 stale affordance set."""

    updated = dict(attrs)
    updated["stale"] = True
    return updated


def normalize_body_nfc(body: str) -> str:
    """Return NFC-normalized body text, matching the Node generated column."""

    return unicodedata.normalize("NFC", body)


def compute_node_tag_content_digest(
    body_nfc_hash: bytes,
    *,
    start: int,
    end: int,
) -> bytes:
    """Mirror ``app.node_tag_content_digest`` for service stale-write checks."""

    return sha256(body_nfc_hash + f"{start}:{end}".encode()).digest()


def substring_by_codepoints(body_nfc: str, start: int, end: int) -> str:
    """Slice a body by Python codepoints after validating range bounds."""

    validate_span(body_nfc, start, end)
    return body_nfc[start:end]


def validate_span(body_nfc: str, start: int, end: int) -> None:
    """Validate non-empty codepoint offsets into an NFC body."""

    if start < 0 or end < 0 or start > len(body_nfc) or end > len(body_nfc):
        raise NodeTagValidationError(
            NodeTagValidationReason.SPAN_OUT_OF_RANGE,
            "span offsets must fall within the NFC body codepoint length",
        )
    if end <= start:
        raise NodeTagValidationError(
            NodeTagValidationReason.SPAN_EMPTY,
            "NodeTag spans must be non-empty",
        )


def validate_text_quote_selector(
    body_nfc: str,
    *,
    start: int,
    end: int,
    selector: Mapping[str, Any] | TextQuoteSelector | None,
) -> TextQuoteSelector | None:
    """Validate optional prefix/exact/suffix selector against the body span."""

    if selector is None:
        return None
    try:
        parsed = (
            selector
            if isinstance(selector, TextQuoteSelector)
            else TextQuoteSelector.model_validate(dict(selector))
        )
    except Exception as exc:
        raise NodeTagValidationError(
            NodeTagValidationReason.TEXT_QUOTE_SELECTOR_INVALID,
            "text quote selector must contain exact/prefix/suffix fields only",
        ) from exc

    exact = substring_by_codepoints(body_nfc, start, end)
    if parsed.exact != exact:
        raise NodeTagValidationError(
            NodeTagValidationReason.TEXT_QUOTE_EXACT_MISMATCH,
            "text quote exact selector does not match the selected span",
        )
    if parsed.prefix and body_nfc[:start].endswith(parsed.prefix) is False:
        raise NodeTagValidationError(
            NodeTagValidationReason.TEXT_QUOTE_EXACT_MISMATCH,
            "text quote prefix does not match the selected span",
        )
    if parsed.suffix and body_nfc[end:].startswith(parsed.suffix) is False:
        raise NodeTagValidationError(
            NodeTagValidationReason.TEXT_QUOTE_EXACT_MISMATCH,
            "text quote suffix does not match the selected span",
        )
    return parsed


def validate_value_for_definition(
    value: NodeTagValue,
    definition: NodeTagDefinitionMetadata,
    *,
    currency: str | None = None,
) -> None:
    """Validate the populated value family and currency against a definition."""

    expected_family = {
        TagValueType.STRING: "value_text",
        TagValueType.NUMBER: "value_number",
        TagValueType.BOOLEAN: "value_boolean",
        TagValueType.ENUM: "value_text",
        TagValueType.REFERENCE: "value_reference_node_id",
        TagValueType.COMPUTED: "value_text",
    }[definition.value_type]
    if value.populated_families() != (expected_family,):
        raise NodeTagValidationError(
            NodeTagValidationReason.VALUE_TYPE_MISMATCH,
            f"{definition.value_type.value} definitions require {expected_family}",
        )
    if definition.value_type is TagValueType.ENUM:
        if definition.enum_values_canonical is None:
            raise NodeTagValidationError(
                NodeTagValidationReason.ENUM_VALUE_INVALID,
                "enum definitions require canonical enum values",
            )
        assert value.value_text is not None
        if normalize_tag_name(value.value_text) not in definition.enum_values_canonical:
            raise NodeTagValidationError(
                NodeTagValidationReason.ENUM_VALUE_INVALID,
                "enum value is not allowed by the tag definition",
            )

    if definition.requires_currency:
        if currency is None:
            raise NodeTagValidationError(
                NodeTagValidationReason.CURRENCY_REQUIRED,
                "definition requires an ISO 4217 currency code",
            )
        validate_currency(currency)
    elif currency is not None:
        raise NodeTagValidationError(
            NodeTagValidationReason.CURRENCY_FORBIDDEN,
            "currency is forbidden for definitions that do not require it",
        )


def validate_currency(currency: str) -> str:
    """Return normalized ISO-like currency code or raise."""

    normalized = currency.strip().upper()
    if len(normalized) != 3 or not normalized.isalpha() or not normalized.isascii():
        raise NodeTagValidationError(
            NodeTagValidationReason.CURRENCY_INVALID,
            "currency must be a three-letter ASCII code",
        )
    return normalized


def inherit_or_apply_context_override(
    node_context: Mapping[str, Any],
    override: NodeTagContextOverride | None = None,
) -> JsonObject:
    """Inherit Node context by default and allow only narrowing overrides."""

    inherited = _validate_context_shape(node_context)
    if override is None:
        return inherited

    candidate = _validate_context_shape(override.context)
    if candidate["tenant"] != inherited["tenant"]:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_TENANT_WIDENING,
            "NodeTag context cannot change tenant until lifting-rule runtime exists",
        )
    if candidate["vertical"] != inherited["vertical"]:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_VERTICAL_CHANGE,
            "NodeTag context cannot change vertical until lifting-rule runtime exists",
        )
    inherited_classification = ClassificationLevel(str(inherited["classification"]))
    candidate_classification = ClassificationLevel(str(candidate["classification"]))
    if candidate_classification.rank < inherited_classification.rank:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_CLASSIFICATION_WIDENING,
            "NodeTag context classification cannot be less restrictive than source context",
        )
    _validate_context_validity_narrows(inherited, candidate)
    return candidate


def _validate_context_shape(context: Mapping[str, Any]) -> JsonObject:
    missing = sorted(_CONTEXT_KEYS - set(context))
    if missing:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_REQUIRED_KEY_MISSING,
            f"NodeTag context missing required keys: {', '.join(missing)}",
        )
    copied = dict(context)
    try:
        ClassificationLevel(str(copied["classification"]))
    except ValueError as exc:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_CLASSIFICATION_INVALID,
            "context classification must be C0-C4",
        ) from exc
    return copied


def _parse_context_datetime(value: object, *, key: str) -> datetime | None:
    if value is None or value == "":
        return None
    if not isinstance(value, str):
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_VALIDITY_INVALID,
            f"context {key} must be an ISO timestamp or null",
        )
    normalized = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_VALIDITY_INVALID,
            f"context {key} must be an ISO timestamp or null",
        ) from exc


def _validate_context_validity_narrows(
    inherited: Mapping[str, Any],
    candidate: Mapping[str, Any],
) -> None:
    inherited_from = _parse_context_datetime(inherited["valid_from"], key="valid_from")
    candidate_from = _parse_context_datetime(candidate["valid_from"], key="valid_from")
    inherited_to = _parse_context_datetime(inherited["valid_to"], key="valid_to")
    candidate_to = _parse_context_datetime(candidate["valid_to"], key="valid_to")

    if inherited_from is not None and (candidate_from is None or candidate_from < inherited_from):
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_VALIDITY_WIDENING,
            "NodeTag context valid_from cannot move earlier than the source context",
        )
    if inherited_to is not None and (candidate_to is None or candidate_to > inherited_to):
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_VALIDITY_WIDENING,
            "NodeTag context valid_to cannot move later than the source context",
        )
    if candidate_from is not None and candidate_to is not None and candidate_to < candidate_from:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTEXT_VALIDITY_INVALID,
            "NodeTag context valid_to must not be earlier than valid_from",
        )


def derive_tag_classification(
    *,
    node_classification: ClassificationLevel,
    definition_classification: ClassificationLevel,
    context_classification: ClassificationLevel,
) -> ClassificationLevel:
    """Return the conservative MAX classification for a NodeTag row."""

    return max(
        (node_classification, definition_classification, context_classification),
        key=lambda item: item.rank,
    )


def validate_tag_classification(
    stored_classification: ClassificationLevel,
    *,
    node_classification: ClassificationLevel,
    definition_classification: ClassificationLevel,
    context_classification: ClassificationLevel,
) -> None:
    """Reject attempts to store a tag below the required MAX classification."""

    expected = derive_tag_classification(
        node_classification=node_classification,
        definition_classification=definition_classification,
        context_classification=context_classification,
    )
    if stored_classification.rank < expected.rank:
        raise NodeTagValidationError(
            NodeTagValidationReason.CLASSIFICATION_DOWNGRADE,
            "NodeTag classification must be at least source/definition/context MAX",
        )


def validate_source_node_for_tag(
    source: NodeTagSourceSnapshot | None,
) -> NodeTagSourceSnapshot:
    """Validate a visible source Node for new active tag application."""

    if source is None:
        raise NodeTagValidationError(
            NodeTagValidationReason.SOURCE_NODE_NOT_FOUND,
            "source Node was not found or is not visible",
        )
    if source.is_archived:
        raise NodeTagValidationError(
            NodeTagValidationReason.SOURCE_NODE_ARCHIVED,
            "new active tags cannot be applied to archived Nodes",
        )
    return source


def validate_reference_node_for_tag(
    reference: NodeTagReferenceSnapshot | None,
    *,
    tenant_id: UUID,
) -> NodeTagReferenceSnapshot:
    """Validate a visible reference-valued tag target."""

    if reference is None:
        raise NodeTagValidationError(
            NodeTagValidationReason.REFERENCE_NODE_NOT_FOUND,
            "reference Node was not found or is not visible",
        )
    if reference.tenant_id != tenant_id:
        raise NodeTagValidationError(
            NodeTagValidationReason.REFERENCE_NODE_CROSS_SCOPE,
            "reference Node must be in the same organization",
        )
    if reference.is_archived:
        raise NodeTagValidationError(
            NodeTagValidationReason.REFERENCE_NODE_ARCHIVED,
            "reference Node must be active",
        )
    return reference


def validate_definition_for_tag_application(
    contract: TagDefinitionApplicationContract,
) -> TagDefinitionApplicationContract:
    """Validate lifecycle/template facts for a NodeTag application contract."""

    definition = contract.definition
    if definition.tenant_id is None:
        raise NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_TEMPLATE,
            "template definitions cannot be applied directly",
        )
    if not contract.accepts_new_applications:
        raise NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_LIFECYCLE_REJECTED,
            "tag definition lifecycle rejects new applications",
        )
    return contract


def validate_definition_ontology_version(
    *,
    definition_ontology_version_id: UUID | None,
    source_context: Mapping[str, Any],
    tag_context: Mapping[str, Any],
    has_context_override: bool,
) -> None:
    """Reject definition ontology drift unless an explicit override pins it."""

    if definition_ontology_version_id is None:
        return
    definition_version = str(definition_ontology_version_id)
    if str(source_context["ontology_version"]) == definition_version:
        return
    if has_context_override and str(tag_context["ontology_version"]) == definition_version:
        return
    raise NodeTagValidationError(
        NodeTagValidationReason.ONTOLOGY_VERSION_MISMATCH,
        "TagDefinition ontology_version_id must match source context or explicit override",
    )


def build_node_tag_insert(
    *,
    request: NodeTagApplyRequest,
    context: TagDefinitionServiceContext,
    source: NodeTagSourceSnapshot,
    definition_contract: TagDefinitionApplicationContract,
    reference: NodeTagReferenceSnapshot | None = None,
) -> NodeTagRowDraft:
    """Build the repository insert draft after source/definition preloads succeed."""

    definition = definition_contract.definition
    if source.tenant_id != context.tenant_id:
        raise NodeTagValidationError(
            NodeTagValidationReason.SOURCE_NODE_NOT_FOUND,
            "source Node was not found or is not visible in the write organization",
        )
    if definition.tenant_id != context.tenant_id:
        raise NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_CROSS_SCOPE,
            "tag definition must be scoped to the write organization",
        )
    if definition.lifecycle_state is TagDefinitionLifecycleState.RETIRED:
        raise NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_LIFECYCLE_REJECTED,
            "retired tag definitions cannot receive new applications",
        )
    if definition.value_type is TagValueType.COMPUTED:
        raise NodeTagValidationError(
            NodeTagValidationReason.COMPUTED_WRITE_FORBIDDEN,
            "computed tags require the dedicated computed-tag service path",
        )
    if request.value.value_reference_node_id is not None and reference is None:
        raise NodeTagValidationError(
            NodeTagValidationReason.REFERENCE_NODE_NOT_FOUND,
            "reference Node was not found or is not visible",
        )

    selector = validate_text_quote_selector(
        source.body_nfc,
        start=request.span_offset_start,
        end=request.span_offset_end,
        selector=request.text_quote_selector,
    )
    content_digest = compute_node_tag_content_digest(
        source.body_nfc_hash,
        start=request.span_offset_start,
        end=request.span_offset_end,
    )
    if request.expected_content_digest != content_digest:
        raise NodeTagValidationError(
            NodeTagValidationReason.CONTENT_DIGEST_STALE,
            "NodeTag source body hash or span changed before write",
        )

    metadata = NodeTagDefinitionMetadata(
        value_type=definition.value_type,
        requires_currency=definition.requires_currency,
        classification=ClassificationLevel(str(definition.attrs.get("classification", "C0"))),
        enum_values_canonical=definition.enum_values_canonical,
    )
    currency = None if request.currency is None else validate_currency(request.currency)
    validate_value_for_definition(request.value, metadata, currency=currency)

    tag_context = inherit_or_apply_context_override(
        source.context_of_validity,
        request.context_override,
    )
    validate_definition_ontology_version(
        definition_ontology_version_id=definition.ontology_version_id,
        source_context=source.context_of_validity,
        tag_context=tag_context,
        has_context_override=request.context_override is not None,
    )
    context_classification = ClassificationLevel(str(tag_context["classification"]))
    classification = derive_tag_classification(
        node_classification=source.classification,
        definition_classification=metadata.classification,
        context_classification=context_classification,
    )
    attrs = dict(request.attrs)
    if definition_contract.is_deprecated_grace:
        attrs["deprecated_grace"] = True
        if definition_contract.deprecated_grace_expires_at is not None:
            attrs["deprecated_grace_expires_at"] = (
                definition_contract.deprecated_grace_expires_at.isoformat()
            )
    if request.context_override is not None:
        attrs["context_override_reason"] = request.context_override.reason
        attrs["context_override_source"] = request.context_override.source

    return NodeTagRowDraft(
        node_id=source.id,
        tenant_id=context.tenant_id,
        tag_definition_id=definition.id,
        value_text=request.value.value_text,
        value_number=request.value.value_number,
        value_boolean=request.value.value_boolean,
        value_reference_node_id=request.value.value_reference_node_id,
        currency=currency,
        attrs=attrs,
        span_offset_start=request.span_offset_start,
        span_offset_end=request.span_offset_end,
        content_digest=content_digest,
        text_quote_selector={} if selector is None else selector.model_dump(),
        context_of_validity=tag_context,
        classification=classification,
        tagged_by_principal_id=context.principal_id,
        confidence=request.confidence,
    )


def _definition_application_error(
    reason_code: TagDefinitionServiceReason,
) -> NodeTagValidationError:
    if reason_code is TagDefinitionServiceReason.NOT_FOUND:
        return NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_NOT_FOUND,
            "tag definition was not found or is not visible",
        )
    if reason_code is TagDefinitionServiceReason.TEMPLATE_REQUIRED:
        return NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_TEMPLATE,
            "template definitions cannot be applied directly",
        )
    if reason_code is TagDefinitionServiceReason.CROSS_SCOPE_REFERENCE:
        return NodeTagValidationError(
            NodeTagValidationReason.DEFINITION_CROSS_SCOPE,
            "tag definition must be scoped to the write organization",
        )
    return NodeTagValidationError(
        NodeTagValidationReason.DEFINITION_LIFECYCLE_REJECTED,
        "tag definition does not accept new applications",
    )
